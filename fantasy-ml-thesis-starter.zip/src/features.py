
from __future__ import annotations
import pandas as pd
import numpy as np
from typing import Tuple, List, Dict
from .utils import safe_mean

def _history_mask(df: pd.DataFrame, season: int, week: int) -> pd.Series:
    return ((df["season"] < season) | ((df["season"] == season) & (df["week"] < week)))

def _current_week_mask(df: pd.DataFrame, season: int, week: int) -> pd.Series:
    return (df["season"] == season) & (df["week"] == week)

def _defense_allowed_table(hist_pos: pd.DataFrame) -> pd.DataFrame:
    g = hist_pos.groupby("opponent_team", as_index=False)["fpts"].mean()
    g = g.rename(columns={"fpts":"allowed_avg"})
    return g

def _league_pos_avg(hist_pos: pd.DataFrame) -> float:
    return safe_mean(hist_pos["fpts"])

def _league_def_allowed_avg(def_table: pd.DataFrame) -> float:
    return safe_mean(def_table["allowed_avg"])

def build_features_for_week(df: pd.DataFrame, season: int, week: int, position: str) -> Tuple[pd.DataFrame, pd.Series, pd.DataFrame]:
    position = position.upper()
    cur_mask = _current_week_mask(df, season, week) & (df["position"] == position)
    hist_mask = _history_mask(df, season, week) & (df["position"] == position)

    cur = df.loc[cur_mask].copy()
    hist_pos = df.loc[hist_mask].copy()

    if hist_pos.empty or cur.empty:
        return pd.DataFrame(columns=["PlayerAvg","PlayerRel","DefAvgAllowed","DefRelAllowed"]), pd.Series([], dtype=float), cur

    player_avg = hist_pos.groupby("player_id")["fpts"].mean().rename("PlayerAvg")
    cur = cur.merge(player_avg, on="player_id", how="left")

    league_pos_avg = _league_pos_avg(hist_pos)
    cur["PlayerRel"] = cur["PlayerAvg"] - league_pos_avg

    def_tbl = _defense_allowed_table(hist_pos)
    league_def_allowed_avg = _league_def_allowed_avg(def_tbl)

    cur = cur.merge(def_tbl, on="opponent_team", how="left")
    cur = cur.rename(columns={"allowed_avg":"DefAvgAllowed"})
    cur["DefRelAllowed"] = cur["DefAvgAllowed"] - league_def_allowed_avg

    cur = cur.dropna(subset=["PlayerAvg","DefAvgAllowed"]).copy()

    X = cur[["PlayerAvg","PlayerRel","DefAvgAllowed","DefRelAllowed"]].copy()
    y = cur["fpts"].copy()
    meta = cur[["season","week","player_id","player_name","position","team","opponent_team"]].copy()

    return X, y, meta

def build_feature_cube(df: pd.DataFrame, season: int, week: int, positions: List[str]) -> Dict[str, Tuple[pd.DataFrame, pd.Series, pd.DataFrame]]:
    out = {}
    for p in positions:
        X, y, meta = build_features_for_week(df, season, week, p)
        out[p] = (X, y, meta)
    return out
