
from __future__ import annotations
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Iterable

POSITIONS = ["QB","RB","WR","TE","K"]

def read_player_weekly(path: str | Path) -> pd.DataFrame:
    """Read a player-week CSV with required columns."""
    df = pd.read_csv(path)
    required = ["season","week","player_id","player_name","position","team","opponent_team","fpts"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    df["season"] = df["season"].astype(int)
    df["week"] = df["week"].astype(int)
    df["position"] = df["position"].astype(str).str.upper()
    return df

def filter_positions(df: pd.DataFrame, positions: Iterable[str]) -> pd.DataFrame:
    pos = [str(p).upper() for p in positions]
    return df[df["position"].isin(pos)].copy()

def ensure_sorted(df: pd.DataFrame) -> pd.DataFrame:
    return df.sort_values(["season","week","position","player_id"]).reset_index(drop=True)

def mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))

def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred)**2)))

def safe_mean(s: pd.Series) -> float:
    return float(s.mean()) if len(s) else float("nan")

def write_parquet(df: pd.DataFrame, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)

def write_csv(df: pd.DataFrame, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)

def compute_fpts_espm_standard(row: pd.Series) -> float:
    """Example ESPN-ish scoring stub; not used by default."""
    f = 0.0
    f += 4.0 * row.get("pass_td", 0.0)
    f += 2.0 * (row.get("pass_yds", 0.0) / 25.0)
    f += -2.0 * row.get("pass_int", 0.0)
    f += 6.0 * row.get("rush_td", 0.0)
    f += 1.0 * (row.get("rush_yds", 0.0) / 10.0)
    f += 6.0 * row.get("rec_td", 0.0)
    f += 1.0 * (row.get("rec_yds", 0.0) / 10.0)
    f += -2.0 * row.get("fumbles_lost", 0.0)
    return float(f)
