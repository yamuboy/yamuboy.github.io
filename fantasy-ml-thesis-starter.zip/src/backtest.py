
from __future__ import annotations
import pandas as pd
import numpy as np
from typing import List, Dict, Any
from .utils import ensure_sorted, mae, rmse
from .features import build_feature_cube
from .models import ModelSpec, fit_with_cv

def walk_forward_backtest(df: pd.DataFrame,
                          season: int,
                          week_start: int,
                          week_end: int,
                          positions: List[str],
                          model_spec: ModelSpec) -> Dict[str, Any]:
    df = ensure_sorted(df)
    preds_records = []
    metrics = {p: {"n":0, "mae_sum":0.0, "rmse_sum":0.0} for p in positions}

    for wk in range(week_start, week_end+1):
        cube = build_feature_cube(df, season, wk, positions)
        for p, (X, y, meta) in cube.items():
            if len(y) < 5 or len(X) < 5:
                continue
            model = fit_with_cv(X, y, model_spec)
            yhat = model.predict(X)
            m_mae = mae(y.to_numpy(), yhat)
            m_rmse = rmse(y.to_numpy(), yhat)
            metrics[p]["n"] += len(y)
            metrics[p]["mae_sum"] += m_mae * len(y)
            metrics[p]["rmse_sum"] += m_rmse * len(y)

            tmp = meta.copy()
            tmp["y_true"] = y.to_numpy()
            tmp["y_pred"] = yhat
            tmp["abs_err"] = np.abs(tmp["y_true"] - tmp["y_pred"])
            tmp["position_model"] = p
            tmp["week_model"] = wk
            preds_records.append(tmp)

    preds = pd.concat(preds_records, ignore_index=True) if preds_records else pd.DataFrame()

    summary_rows = []
    for p in positions:
        n = metrics[p]["n"]
        if n > 0:
            summary_rows.append({
                "position": p,
                "n_obs": n,
                "MAE": metrics[p]["mae_sum"] / n,
                "RMSE": metrics[p]["rmse_sum"] / n
            })
    summary = pd.DataFrame(summary_rows).sort_values("position")
    return {"preds": preds, "summary": summary}
