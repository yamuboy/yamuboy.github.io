
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Tuple
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV, KFold

@dataclass
class ModelSpec:
    name: str  # 'knn' or 'svm'
    params: Dict[str, Any] | None = None

def build_pipeline(spec: ModelSpec) -> Tuple[Pipeline, Dict[str, Any]]:
    if spec.name.lower() == "knn":
        pipe = Pipeline([
            ("scaler", StandardScaler()),
            ("est", KNeighborsRegressor(weights="distance"))
        ])
        grid = {"est__n_neighbors": spec.params.get("k_grid", list(range(10, 201, 10))) if spec.params else list(range(10, 201, 10))}
        return pipe, grid
    elif spec.name.lower() in ("svm","svr"):
        pipe = Pipeline([
            ("scaler", StandardScaler()),
            ("est", SVR(kernel="rbf"))
        ])
        if spec.params is None:
            C_grid = [1.0, 10.0, 13.0, 100.0]
            gamma_grid = [0.1, 0.5, 1.0, 7.0, 0.01]
        else:
            C_grid = spec.params.get("C_grid", [1.0, 10.0, 13.0, 100.0])
            gamma_grid = spec.params.get("gamma_grid", [0.1, 0.5, 1.0, 7.0, 0.01])
        grid = {"est__C": C_grid, "est__gamma": gamma_grid}
        return pipe, grid
    else:
        raise ValueError(f"Unknown model spec: {spec.name}")

def fit_with_cv(X, y, spec: ModelSpec, cv_splits: int = 5, n_jobs: int = -1, scoring: str = "neg_mean_absolute_error"):
    pipe, grid = build_pipeline(spec)
    n_splits = 2 if len(y) < 3 else min(cv_splits, len(y))
    cv = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    gs = GridSearchCV(pipe, grid, cv=cv, n_jobs=n_jobs, scoring=scoring, refit=True, verbose=0)
    gs.fit(X, y)
    return gs
