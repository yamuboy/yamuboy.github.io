# Fantasy Football ML — Thesis Starter

This repo is a **code scaffold** that reproduces the core methodology from the uploaded thesis:
- Build **four features** per player-week using league and opponent-defense aggregates up to the week _before_ prediction.
- Train **position-specific** models (KNN and SVM/SVR) with walk-forward evaluation.
- Report weekly and total **projection error** (MAE / RMSE) by position.

> Source inspiration: Parikh (2015), *Interactive Tools for Fantasy Football Analytics and Predictions using Machine Learning*.

## Data expectations

Provide a single CSV, e.g. `data/player_weekly.csv`, with **one row per player-game** (regular season only). Required columns:

| column | type | example |
|---|---|---|
| `season` | int | 2014 |
| `week` | int | 1..17 |
| `player_id` | str | 'DAL-D.Prescott' |
| `player_name` | str | 'Dak Prescott' |
| `position` | str | 'QB','RB','WR','TE','K' |
| `team` | str | 'DAL' |
| `opponent_team` | str | 'NYG' |
| `fpts` | float | 24.1 (ESPN standard scoring or your chosen system) |

> If you don’t have fantasy points precomputed, add your own scorer (see `src/utils.py` stub).

## Feature definition (per Parikh §4.2.1)

For a given week *w* and position *P*:
1. **PlayerAvg** — Player’s avg fantasy points **up to week w−1** (same season + prior seasons if loaded)
2. **PlayerRel** — PlayerAvg − LeagueAvg_P (league average for position P up to w−1)
3. **DefAvgAllowed** — Opponent defense’s avg points **allowed to position P up to w−1**
4. **DefRelAllowed** — DefAvgAllowed − LeagueAvgAllowed_P (league avg defense-allowed for P up to w−1)

The label is **actual `fpts` in week w**.

## Quickstart

```bash
# 1) Create a virtualenv and install deps
pip install -r requirements.txt

# 2) Put your CSV here (or change --data path)
#    e.g., /path/to/player_weekly.csv

# 3) Run a backtest for 2014 weeks 2..11 (to match thesis window style)
python -m scripts.run_backtest --data /path/to/player_weekly.csv --season 2014 --week-start 2 --week-end 11 --positions QB RB WR TE K --model svm

# Example: KNN with automatic k-search:
python -m scripts.run_backtest --data /path/to/player_weekly.csv --season 2014 --week-start 2 --week-end 11 --positions WR --model knn
```

The script writes per-week predictions and an **evaluation summary** to `outputs/`.

## Notes

- The SVM in the thesis used RBF kernels with tuned (C, gamma). This code performs a light grid search.
- KNN tries a grid of k in [10, 200] by default (you can change it).
- The pipeline is intentionally simple so you can plug in richer features later.
- For multi-season training, just include prior seasons in the CSV—features automatically respect the *as-of* cutoff.

---

**Folder layout**
```
src/
  backtest.py      # walk-forward orchestration
  features.py      # feature builders (per §4.2.1)
  models.py        # KNN/SVR trainers w/ scaling + grids
  utils.py         # IO helpers, fantasy scoring stub, evaluation metrics
scripts/
  run_backtest.py  # CLI entry point
requirements.txt
```
