
from __future__ import annotations
import argparse
from pathlib import Path
from src.utils import read_player_weekly, filter_positions, write_csv, write_parquet
from src.models import ModelSpec
from src.backtest import walk_forward_backtest

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, required=True, help="Path to player_weekly.csv")
    ap.add_argument("--season", type=int, required=True)
    ap.add_argument("--week-start", type=int, default=2)
    ap.add_argument("--week-end", type=int, default=11)
    ap.add_argument("--positions", nargs="+", default=["QB","RB","WR","TE","K"])
    ap.add_argument("--model", type=str, choices=["knn","svm"], default="svm")
    ap.add_argument("--outdir", type=str, default="outputs")
    args = ap.parse_args()

    df = read_player_weekly(args.data)
    df = filter_positions(df, args.positions)

    if args.model == "knn":
        spec = ModelSpec(name="knn", params={"k_grid": list(range(10, 201, 10))})
    else:
        spec = ModelSpec(name="svm", params={"C_grid":[1.0,10.0,13.0,100.0], "gamma_grid":[0.1,0.5,1.0,7.0,0.01]})

    res = walk_forward_backtest(df, args.season, args.week_start, args.week_end, args.positions, spec)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    if not res["preds"].empty:
        write_csv(res["preds"], outdir / f"predictions_{args.model}_{args.season}_{args.week_start}-{args.week_end}.csv")
        write_parquet(res["preds"], outdir / f"predictions_{args.model}_{args.season}_{args.week_start}-{args.week_end}.parquet")
    res["summary"].to_csv(outdir / f"summary_{args.model}_{args.season}_{args.week_start}-{args.week_end}.csv", index=False)
    print("\n=== Summary ===")
    print(res["summary"].to_string(index=False))

if __name__ == "__main__":
    main()
