# 10-K downloader + LLM extractor

This project downloads **13 years** of a company's 10‑K filings using the `sec_api` Python module and then uses the **OpenAI API** (Structured Outputs) to extract **key metrics** and **identify core financial tables** from the HTML.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate   # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
cp .env.sample .env
# edit .env with your keys
```

### .env
```
SEC_API_KEY=your_sec_api_key_here
OPENAI_API_KEY=your_openai_key_here
OPENAI_MODEL=gpt-4o   # or o4-mini for cheaper runs
```

## Quickstart

Download + extract for a ticker (e.g., AAPL):
```bash
python -m src.run_pipeline --ticker AAPL
```

Advanced options:
```bash
# specify cik and year window explicitly
python -m src.run_pipeline --cik 0000320193 --start-year 2012 --end-year 2024

# force-refresh downloads, and run with a cheaper model
python -m src.run_pipeline --ticker NVDA --refresh --model o4-mini
```

Outputs go to `outputs/`:
- `metrics.jsonl` — one JSON object per filing with extracted metrics
- `tables_index.parquet` — index of tables found & labeled
- per‑filing artifacts under `data/raw/<ticker_or_cik>/...` (HTML, section dumps, tables as CSV)

## Notes
- Uses **sec_api** Query + Render APIs to find and download original 10‑K HTML.
- Extracts **Item 1, 7, 7A, 8** text, and harvests HTML tables; LLM does **metric extraction** (rev, NI, EPS, CF, capex, etc.) and **table labeling**.
- Respects SEC fair‑use rate limits (sec_api client handles pacing).

