
from __future__ import annotations
import os, json
from pathlib import Path
from typing import Dict, Any
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_exponential
from openai import OpenAI

load_dotenv()
MODEL = os.getenv("OPENAI_MODEL", "gpt-4o")

def build_schema() -> Dict[str, Any]:
    return {
      "name": "sec_10k_metrics",
      "schema": {
        "type": "object",
        "properties": {
          "company_name": {"type": "string"},
          "fiscal_year": {"type": "string"},
          "period_end_date": {"type": "string"},
          "metrics": {
            "type": "object",
            "properties": {
              "revenue": {"type":"number"},
              "operating_income": {"type":"number"},
              "net_income": {"type":"number"},
              "diluted_eps": {"type":"number"},
              "total_assets": {"type":"number"},
              "total_liabilities": {"type":"number"},
              "cash_from_operations": {"type":"number"},
              "capital_expenditures": {"type":"number"}
            },
            "additionalProperties": False
          },
          "segment_revenue": {
            "type": "array",
            "items": {"type":"object", "properties": {"segment": {"type":"string"}, "revenue":{"type":"number"}}, "required":["segment","revenue"]}
          },
          "mdna_themes": {"type": "array", "items":{"type":"string"}},
          "risk_factors_summary": {"type": "string"},
          "tables": {
            "type":"array",
            "items":{"type":"object","properties":{
              "label":{"type":"string"},
              "table_idx":{"type":"integer"},
              "reason":{"type":"string"}
            }, "required":["label","table_idx"]}
          },
          "notes": {"type":"string"}
        },
        "required": ["company_name","metrics"]
      },
      "strict": True
    }

@retry(wait=wait_exponential(multiplier=1, min=2, max=30), stop=stop_after_attempt(3))
def extract_metrics_for_doc(html_text: str, tables_index: list[dict]) -> dict:
    client = OpenAI()
    schema = build_schema()
    table_summ = "\n".join([f"[{t.get('table_idx')}] {t.get('caption','(no caption)')}" for t in tables_index[:100]])
    sys = "You are a financial analyst extracting structured data from 10-Ks. Return ONLY valid JSON conforming to the provided schema. If a metric is missing, omit it."
    user = f"""Extract key metrics and tag the primary financial tables.
Text excerpt from a 10-K (mix from Items 7/8 and elsewhere). Values should be numeric in USD where possible (strip $ and commas).

TABLE CANDIDATES (index -> caption):
{table_summ}

TEXT:
{html_text[:120000]}
"""
    resp = client.responses.create(
        model=MODEL,
        input=[
            {"role":"system","content":sys},
            {"role":"user","content":user}
        ],
        response_format={
            "type":"json_schema",
            "json_schema": schema
        }
    )
    try:
        js = json.loads(resp.output_text)
    except Exception:
        js = json.loads(resp.output[0].content[0].text)
    return js
