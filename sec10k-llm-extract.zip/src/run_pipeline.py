
from __future__ import annotations
import os, json, argparse
from pathlib import Path
from dotenv import load_dotenv
from tqdm import tqdm
import pandas as pd
from .fetch_10k import fetch_10k_listing, download_html, years_window
from .utils import find_10k_sections_text, extract_html_tables
from .llm_extract import extract_metrics_for_doc

def main():
    load_dotenv()
    sec_key = os.getenv("SEC_API_KEY")
    if not sec_key:
        raise SystemExit("Missing SEC_API_KEY in env.")
    parser = argparse.ArgumentParser()
    parser.add_argument("--ticker", type=str)
    parser.add_argument("--cik", type=str)
    parser.add_argument("--start-year", type=int, default=None)
    parser.add_argument("--end-year", type=int, default=None)
    parser.add_argument("--include-10k-a", action="store_true")
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--model", type=str, default=None, help="override OPENAI_MODEL (set env)")
    args = parser.parse_args()

    if not (args.ticker or args.cik):
        raise SystemExit("Provide --ticker or --cik")

    if args.start_year and args.end_year:
        start = f"{args.start_year}-01-01"
        end = f"{args.end_year}-12-31"
    else:
        start, end = years_window(13)

    filings = fetch_10k_listing(sec_key, ticker=args.ticker, cik=args.cik, start_date=start, end_date=end, include_10k_a=args.include_10k_a)
    ident = args.ticker or args.cik
    raw_dir = Path("data/raw") / ident
    raw_dir.mkdir(parents=True, exist_ok=True)

    html_paths = []
    for f in tqdm(filings, desc="Downloading filings"):
        acc = f.get("accessionNo","unknown")
        date = f.get("filedAt","")[:10]
        fname = f"{f.get('ticker', f.get('cik',''))}_{date}_{acc}.html"
        path = raw_dir / fname
        if path.exists() and not args.refresh:
            html_paths.append(path)
            continue
        try:
            p = download_html(sec_key, f, raw_dir)
            html_paths.append(p)
        except Exception as e:
            print("Download failed:", e)

    metrics_out = []
    tables_index_rows = []
    for hp in tqdm(html_paths, desc="Extracting & analyzing"):
        html = Path(hp).read_text(encoding="utf-8", errors="ignore")
        sec = find_10k_sections_text(html)
        excerpt = (sec.get("item_7","") + "\n\n" + sec.get("item_8","")) or sec.get("item_1","") or sec.get("item_7a","") or ""
        if not excerpt:
            excerpt = html
        tbl_idx = extract_html_tables(html)
        tbl_idx["source_file"] = hp.name
        tables_index_rows.append(tbl_idx)
        js = extract_metrics_for_doc(excerpt, tbl_idx[["table_idx","caption"]].to_dict(orient="records"))
        js["source_file"] = hp.name
        metrics_out.append(js)

    Path("outputs").mkdir(parents=True, exist_ok=True)
    with open("outputs/metrics.jsonl","w",encoding="utf-8") as f:
        for m in metrics_out:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")

    if tables_index_rows:
        pd.concat(tables_index_rows, ignore_index=True).to_parquet("outputs/tables_index.parquet", index=False)

    print(f"Done. Filings: {len(html_paths)} | outputs written.")

if __name__ == "__main__":
    main()
