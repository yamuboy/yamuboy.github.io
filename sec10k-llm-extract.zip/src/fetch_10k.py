
from __future__ import annotations
import datetime as dt
from pathlib import Path
from typing import List, Dict, Any, Optional
from sec_api import QueryApi, RenderApi

def years_window(last_n: int = 13) -> (str, str):
    today = dt.date.today()
    start = dt.date(today.year - (last_n-1), 1, 1)
    return start.isoformat(), today.isoformat()

def fetch_10k_listing(api_key: str, ticker: Optional[str] = None, cik: Optional[str] = None, start_date: Optional[str]=None, end_date: Optional[str]=None, include_10k_a=False) -> List[Dict[str, Any]]:
    q = QueryApi(api_key=api_key)
    if not (ticker or cik):
        raise ValueError("provide ticker or cik")
    ft = ["10-K"] + (["10-K/A"] if include_10k_a else [])
    if not start_date or not end_date:
        start_date, end_date = years_window(13)

    clauses = [ {"query": {"query_string": {"query": f"ticker:{ticker}"}}} ] if ticker else [ {"query": {"query_string": {"query": f"cik:{cik}"}}} ]
    form_clause = {"query": {"query_string": {"query": " OR ".join([f"formType:{f}" for f in ft])}}}
    date_clause = {"query": {"query_string": {"query": f"filedAt:[{start_date} TO {end_date}]"}}}
    query = {
        "query": { "bool": { "must": [c for c in clauses + [form_clause, date_clause]] } },
        "from": "0", "size": "100",
        "sort": [{"filedAt": {"order": "desc"}}]
    }
    res = q.get_filings(query)
    return res.get("filings", [])

def download_html(api_key: str, filing: Dict[str, Any], outdir: Path) -> Path:
    r = RenderApi(api_key=api_key)
    url = filing.get("linkToHtml") or filing.get("linkToFilingDetails")
    if not url:
        raise RuntimeError("No HTML link in filing")
    html = r.get_filing(url)
    outdir.mkdir(parents=True, exist_ok=True)
    accession = filing.get("accessionNo", "unknown")
    fname = f"{filing.get('ticker', filing.get('cik',''))}_{filing.get('filedAt','')[:10]}_{accession}.html"
    path = outdir / fname
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    with open(outdir / (fname + ".meta.json"), "w", encoding="utf-8") as f:
        import json; json.dump(filing, f, indent=2)
    return path
