
from __future__ import annotations
import re
from bs4 import BeautifulSoup
import pandas as pd

SAFE_FN_RX = re.compile(r"[^A-Za-z0-9_.-]+")

def safe_filename(name: str) -> str:
    return SAFE_FN_RX.sub("_", name)

def html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script","style","noscript"]):
        tag.decompose()
    text = soup.get_text("\n")
    text = re.sub(r"\n\s*\n+", "\n\n", text)
    return text.strip()

def find_10k_sections_text(html: str):
    text = html_to_text(html)
    items = {
        "item_1": r"\bitem\s*1\s*\.?\s*business\b",
        "item_7": r"\bitem\s*7\s*\.?\s*management.?s discussion",
        "item_7a": r"\bitem\s*7a\s*\.?\s*quantitative",
        "item_8": r"\bitem\s*8\s*\.?\s*financial statements"
    }
    spans = {}
    for k, pat in items.items():
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m: spans[k] = m.start()
    out = {}
    if spans:
        keys = sorted(spans.keys(), key=lambda k: spans[k])
        positions = [spans[k] for k in keys] + [len(text)]
        for i, k in enumerate(keys):
            start = spans[k]
            end = positions[i+1]
            out[k] = text[start:end].strip()
    return out

def extract_html_tables(html: str) -> pd.DataFrame:
    soup = BeautifulSoup(html, "lxml")
    tables = soup.find_all("table")
    records = []
    for ti, tbl in enumerate(tables):
        caption = ""
        cap = tbl.find("caption")
        if cap: caption = cap.get_text(" ", strip=True)
        if not caption:
            prev = tbl.find_previous(lambda tag: tag.name in ["h1","h2","h3","h4","strong"] and len(tag.get_text(strip=True))>0)
            if prev: caption = prev.get_text(" ", strip=True)[:200]
        outer = str(tbl)[:5000]
        records.append({"table_idx": ti, "caption": caption, "html_snippet": outer})
    return pd.DataFrame(records)
