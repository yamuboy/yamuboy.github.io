
from __future__ import annotations
import argparse
from pathlib import Path
from src.backtest_rl import run_rl_backtest, run_compare

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, required=True, help="CSV with concatenated slates")
    ap.add_argument("--site", type=str, choices=["DK"], default="DK")
    ap.add_argument("--episodes", type=str, default="all")
    ap.add_argument("--outdir", type=str, default="outputs")
    ap.add_argument("--baseline", type=str, choices=["none","greedy","random","compare"], default="none")
    ap.add_argument("--ownership-lambda", type=float, default=0.0)
    ap.add_argument("--ownership-p", type=float, default=1.0)
    ap.add_argument("--qb-stack-min", type=int, default=0)
    ap.add_argument("--bring-back-min", type=int, default=0)
    ap.add_argument("--allow-te-stack", type=int, default=1)
    ap.add_argument("--alpha", type=float, default=1.0, help="LinTS prior std scale")
    ap.add_argument("--lam", type=float, default=1.0, help="LinTS ridge prior")
    ap.add_argument("--max-from-team", type=int, default=4)
    args = ap.parse_args()

    Path(args.outdir).mkdir(parents=True, exist_ok=True)

    if args.baseline == "compare":
        res = run_compare(args.data, site=args.site, episodes=args.episodes, max_from_team=args.max_from_team)
        for k, df in res.items():
            df.to_csv(Path(args.outdir) / f"summary_{k}.csv", index=False)
        print("Wrote:", ", ".join([f"summary_{k}.csv" for k in res.keys()]))
    else:
        strategy = "rl" if args.baseline == "none" else args.baseline
        res = run_rl_backtest(args.data, site=args.site, episodes=args.episodes,
                              strategy=strategy, alpha=args.alpha, lam=args.lam,
                              max_from_team=args.max_from_team,
                              ownership_lambda=args.ownership_lambda, ownership_p=args.ownership_p,
                              qb_stack_min=args.qb_stack_min, bring_back_min=args.bring_back_min,
                              allow_te_stack=bool(args.allow_te_stack))
        import pandas as pd
        pd.DataFrame(res["records"]).to_csv(Path(args.outdir) / f"summary_{strategy}.csv", index=False)
        print(f"Wrote summary_{strategy}.csv")

if __name__ == "__main__":
    main()
