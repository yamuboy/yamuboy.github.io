
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from src.env import load_slates_csv
from src.roster import TEMPLATES
from src.features import player_feature_matrix
from src.pg_policy import PGSequentialPicker, PGConfig

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, required=True)
    ap.add_argument("--site", type=str, choices=["DK","FD"], default="DK")
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--outdir", type=str, default="outputs_pg")
    args = ap.parse_args()

    slates = load_slates_csv(args.data, args.site)
    rules = TEMPLATES[args.site]()

    # feature dim from first slate
    d = player_feature_matrix(slates[0].df.head(1)).shape[1]
    agent = PGSequentialPicker(rules, d_features=d, cfg=PGConfig(epochs=args.epochs))

    Path(args.outdir).mkdir(parents=True, exist_ok=True)
    records = []

    for s in sorted(slates, key=lambda x: (x.date, x.slate_id)):
        lineup, logps, entropies = agent.pick_lineup(s.df)
        reward = float(lineup["actual"].sum())  # raw points as reward (you can add ownership shaping offline)
        agent.update(reward, logps, entropies)

        records.append({
            "slate_id": s.slate_id,
            "date": s.date,
            "reward_points": reward,
            "salary_used": int(lineup["salary"].sum())
        })

    pd.DataFrame(records).to_csv(Path(args.outdir) / "summary_pg.csv", index=False)
    print("Wrote summary_pg.csv")

if __name__ == "__main__":
    main()
