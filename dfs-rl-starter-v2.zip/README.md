# DFS Reinforcement Learning — Backtest Starter

This repo adds a **reinforcement-learning / contextual slate-bandit** extension to your thesis pipeline so you can **generate and backtest DFS lineups** on historical slates.

## Key ideas
- Treat each slate (e.g., NFL Sunday main) as one **episode**.
- Use **contextual Thompson Sampling** (Bayesian linear regression) to learn weights for player features **by position**.
- Each episode, **sample weights** → build **player utilities** → solve an **integer program** to assemble a valid lineup under site constraints (salary cap, roster template).
- Observe **reward** = lineup's actual fantasy points from the slate; **update** posterior per position.
- Compare to baselines (greedy optimizer with point projections; random valid lineup).

This works offline on historical data with actual points.

## Data expectations
Provide one CSV per slate with rows = players available on that slate. Required columns:
```
slate_id, date, site, player_id, player_name, position, team, opponent, salary, proj, actual
```
- `proj` can come from your thesis model outputs (per-week player projections).
- `actual` is realized fantasy points for that slate (for backtesting reward).

Concatenate all slates into one CSV, or point the script to a directory of per-slate CSVs.

## Roster rules (configurable)
We include DraftKings NFL Classic by default:
- slots: QB, RB, RB, WR, WR, WR, TE, FLEX(RB/WR/TE), DST
- cap: 50000
- max_from_team: 4  (changeable; set None to disable)

You can add FanDuel or custom templates in `src/roster.py`.

## Quickstart
```bash
pip install -r requirements.txt

# Run RL backtest (DraftKings template) across slates:
python -m scripts.run_backtest_rl   --data /path/to/slates.csv   --site DK   --episodes all   --outdir outputs

# Compare with greedy optimizer baseline (no exploration):
python -m scripts.run_backtest_rl --data /path/to/slates.csv --site DK --episodes all --baseline greedy
```

Outputs:
- `outputs/lineups_{strategy}.csv` — selected lineup per episode with reward
- `outputs/summary_{strategy}.csv` — cumulative stats (mean/median points)

Integrations:
- Use your thesis projections to populate the `proj` column; the RL will learn **value adjustments** beyond raw projections.
