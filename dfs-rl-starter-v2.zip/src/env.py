
from __future__ import annotations
import pandas as pd
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from .roster import RosterRules

@dataclass
class Slate:
    slate_id: str
    site: str
    date: str
    df: pd.DataFrame  # players on this slate
    rules: RosterRules

    def split_by_position(self) -> Dict[str, pd.DataFrame]:
        pos_groups = {}
        for p in self.df["position"].unique():
            pos_groups[p] = self.df[self.df["position"] == p].reset_index(drop=True)
        return pos_groups

def load_slates_csv(path: str, site: str) -> List[Slate]:
    df = pd.read_csv(path)
    # basic checks
    required = ["slate_id","date","site","player_id","player_name","position","team","opponent","salary","proj","actual"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")

    df = df[df["site"].str.upper() == site.upper()].copy()
    if df.empty:
        raise ValueError(f"No slates for site={site}")

    # ensure types
    df["salary"] = df["salary"].astype(int)
    df["proj"] = df["proj"].astype(float)
    df["actual"] = df["actual"].astype(float)

    slates = []
    for sid, g in df.groupby("slate_id"):
        date = str(g["date"].iloc[0])
        slates.append(Slate(slate_id=str(sid), site=site, date=date, df=g.reset_index(drop=True), rules=None))  # rules attached in runner
    return slates
