
from __future__ import annotations
import pandas as pd
from typing import Dict, List, Optional, Tuple
import pulp
from .roster import RosterRules

def optimize_lineup(players: pd.DataFrame,
                    rules: RosterRules,
                    utilities: pd.Series,
                    random_tiebreak: bool = False,
                    stacking: Optional[dict] = None) -> Tuple[pd.DataFrame, float]:
    """
    Solve lineup selection maximizing 'utilities' under roster rules.
    Optional stacking (dict):
      {
        "qb_stack_min": 1,            # min WR/TE from same team as chosen QB
        "bring_back_min": 0,          # min WR/TE from opponent of chosen QB
        "allow_te_stack": True        # count TE in stack (default True)
      }
    """
    players = players.copy()
    players["util"] = utilities
    idx = list(players.index)
    x = pulp.LpVariable.dicts("x", idx, lowBound=0, upBound=1, cat=pulp.LpBinary)
    prob = pulp.LpProblem("DFS_Lineup", pulp.LpMaximize)

    # Objective
    if random_tiebreak:
        import numpy as np
        jitter = pd.Series(np.random.uniform(-1e-6,1e-6,len(idx)), index=idx)
        obj = pulp.lpSum((players.loc[i, "util"] + jitter[i]) * x[i] for i in idx)
    else:
        obj = pulp.lpSum(players.loc[i, "util"] * x[i] for i in idx)
    prob += obj

    # Salary cap
    prob += pulp.lpSum(players.loc[i, "salary"] * x[i] for i in idx) <= rules.salary_cap

    # Slots: exactly one per slot (with eligibility)
    for slot in rules.slots:
        elig_idx = [i for i in idx if players.loc[i, "position"] in slot.eligible]
        prob += pulp.lpSum(x[i] for i in elig_idx) >= 1, f"{slot.name}_min1"
    # Total players = #slots
    prob += pulp.lpSum(x[i] for i in idx) == len(rules.slots)

    # Team max constraint (optional)
    if rules.max_from_team is not None:
        for team, g in players.groupby("team"):
            prob += pulp.lpSum(x[i] for i in g.index) <= rules.max_from_team

    # Position lower bounds (non-FLEX slots)
    req_counts = {}
    for slot in rules.slots:
        if len(slot.eligible) == 1:
            p = next(iter(slot.eligible))
            req_counts[p] = req_counts.get(p, 0) + 1
    for p, c in req_counts.items():
        elig_idx = [i for i in idx if players.loc[i, "position"] == p]
        prob += pulp.lpSum(x[i] for i in elig_idx) >= c

    # --- Stacking constraints (linearized on chosen QB) ---
    stacking = stacking or {}
    qb_stack_min = int(stacking.get("qb_stack_min", 0))
    bring_back_min = int(stacking.get("bring_back_min", 0))
    allow_te = bool(stacking.get("allow_te_stack", True))

    if qb_stack_min > 0 or bring_back_min > 0:
        # For each QB candidate, enforce: sum(WR/TE same team) >= qb_stack_min * x_qb
        # and sum(WR/TE opponent team) >= bring_back_min * x_qb
        for qb_i, qb_row in players[players["position"] == "QB"].iterrows():
            x_qb = x[qb_i]
            team = qb_row["team"]
            opp = qb_row["opponent"]
            same_team_idx = [i for i, r in players.iterrows()
                             if (r["position"] in (["WR","TE"] if allow_te else ["WR"])) and r["team"] == team]
            opp_team_idx = [i for i, r in players.iterrows()
                            if (r["position"] in (["WR","TE"] if allow_te else ["WR"])) and r["team"] == opp]
            if qb_stack_min > 0:
                prob += pulp.lpSum(x[i] for i in same_team_idx) >= qb_stack_min * x_qb, f"stack_with_{qb_i}"
            if bring_back_min > 0:
                prob += pulp.lpSum(x[i] for i in opp_team_idx) >= bring_back_min * x_qb, f"bringback_with_{qb_i}"

    # Solve
    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    chosen_idx = [i for i in idx if x[i].value() == 1]
    sel = players.loc[chosen_idx].copy()
    return sel, pulp.value(prob.objective)
