
from __future__ import annotations
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional
from .env import load_slates_csv, Slate
from .roster import TEMPLATES, RosterRules
from .features import player_feature_matrix
from .bandits import PositionBandits
from .optimizer import optimize_lineup

def attach_rules(slates: List[Slate], site: str, max_from_team: int | None = 4) -> List[Slate]:
    rules = TEMPLATES[site](max_from_team=max_from_team)
    for s in slates:
        s.rules = rules
    return slates

def select_lineup_for_slate(slate: Slate, bandit: PositionBandits, strategy: str = "rl",
                            stacking: Optional[dict] = None) -> pd.DataFrame:
    df = slate.df.copy().reset_index(drop=True)
    X = player_feature_matrix(df)
    if strategy == "rl":
        # Thompson-sampled utilities per position
        utilities = pd.Series(0.0, index=df.index)
        for pos, g in df.groupby("position"):
            scores = bandit.sample_scores(pos, X[g.index.values, :])
            utilities.loc[g.index] = scores
    elif strategy == "greedy":
        utilities = df["proj"]
    elif strategy == "random":
        utilities = df["proj"] + np.random.normal(scale=0.01, size=len(df))
    else:
        raise ValueError("Unknown strategy")

    lineup, _ = optimize_lineup(df, slate.rules, utilities, random_tiebreak=True, stacking=stacking)
    return lineup

def episode_reward(lineup: pd.DataFrame,
                   ownership_lambda: float = 0.0,
                   ownership_p: float = 1.0) -> float:
    base = float(lineup["actual"].sum())
    if ownership_lambda <= 0:
        return base
    own = lineup.get("ownership", None)
    if own is None:
        return base
    penalty = ownership_lambda * float(np.sum(np.power(own.astype(float).to_numpy(), ownership_p)))
    return base - penalty

def bandit_update(bandit: PositionBandits, slate: Slate, lineup: pd.DataFrame):
    X_sel = player_feature_matrix(lineup)
    y_sel = lineup["actual"].to_numpy()
    for pos, g in lineup.groupby("position"):
        bandit.update(pos, player_feature_matrix(g), g["actual"].to_numpy())

def run_rl_backtest(csv_path: str, site: str = "DK", episodes: str = "all",
                    strategy: str = "rl", alpha: float = 1.0, lam: float = 1.0,
                    max_from_team: int | None = 4,
                    ownership_lambda: float = 0.0, ownership_p: float = 1.0,
                    qb_stack_min: int = 0, bring_back_min: int = 0, allow_te_stack: bool = True) -> Dict[str, Any]:
    slates = load_slates_csv(csv_path, site)
    slates = sorted(slates, key=lambda s: (s.date, s.slate_id))
    slates = attach_rules(slates, site, max_from_team=max_from_team)

    positions = sorted(slates[0].df["position"].unique())
    d = player_feature_matrix(slates[0].df.head(1)).shape[1]
    bandit = PositionBandits(positions=positions, d=d, alpha=alpha, lam=lam)

    stacking = {"qb_stack_min": qb_stack_min, "bring_back_min": bring_back_min, "allow_te_stack": allow_te_stack}

    records = []
    for s in slates:
        lineup = select_lineup_for_slate(s, bandit, strategy=strategy, stacking=stacking)
        r = episode_reward(lineup, ownership_lambda=ownership_lambda, ownership_p=ownership_p)
        records.append({
            "slate_id": s.slate_id,
            "date": s.date,
            "strategy": strategy,
            "reward_points_shaped": r,
            "points_raw": float(lineup["actual"].sum()),
            "ownership_sum": float(lineup.get("ownership", pd.Series(0.0)).sum()),
            "salary_used": int(lineup["salary"].sum())
        })
        if strategy == "rl":
            bandit_update(bandit, s, lineup)

    summary = pd.DataFrame(records)
    return {"summary": summary, "records": records}
