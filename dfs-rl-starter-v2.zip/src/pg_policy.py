
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any, List
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim

from .features import player_feature_matrix
from .optimizer import optimize_lineup  # we won't use the ILP inside PG, kept for sanity checks
from .roster import RosterRules

def masked_softmax(logits: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    logits = logits.clone()
    logits[~mask] = -1e9
    return torch.softmax(logits, dim=-1)

class PolicyNet(nn.Module):
    def __init__(self, d_in: int, hidden: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1)
        )
    def forward(self, X: torch.Tensor) -> torch.Tensor:
        # returns logits per player (N,1) -> squeeze to (N,)
        return self.net(X).squeeze(-1)

@dataclass
class PGConfig:
    lr: float = 1e-3
    entropy_coef: float = 1e-3
    salary_cap_slack: int = 0  # allow small slack during sequential selection (then prune)
    epochs: int = 1  # online, per-episode updates

class PGSequentialPicker:
    """REINFORCE-like sequential lineup builder with action masking.
    Selects players slot-by-slot using a policy net over player features.
    """
    def __init__(self, rules: RosterRules, d_features: int, cfg: PGConfig = PGConfig()):
        self.rules = rules
        self.policy = PolicyNet(d_features)
        self.opt = optim.Adam(self.policy.parameters(), lr=cfg.lr)
        self.cfg = cfg
        self.baseline = 0.0  # moving average baseline

    def _action_mask(self, players: pd.DataFrame, chosen_idx: List[int], slot_eligible: set, salary_used: int) -> np.ndarray:
        # mask players: must be eligible for current slot, not already chosen, and cap-respecting (rough check)
        mask = np.ones(len(players), dtype=bool)
        for i, row in players.iterrows():
            if i in chosen_idx:
                mask[i] = False
                continue
            if row['position'] not in slot_eligible:
                mask[i] = False
                continue
            # rough salary feasibility check
            remaining_slots = len(self.rules.slots) - len(chosen_idx) - 1
            if remaining_slots < 0:
                mask[i] = False
                continue
            # optimistic check: assume min remaining salary players can fill the rest
            # this is a heuristic; ILP will always be exact
        return mask

    def pick_lineup(self, slate_df: pd.DataFrame) -> (pd.DataFrame, List[torch.Tensor], List[torch.Tensor]):
        X = torch.tensor(player_feature_matrix(slate_df), dtype=torch.float32)
        chosen = []
        logps = []
        entropies = []
        salary_used = 0

        for slot in self.rules.slots:
            elig = slot.eligible
            mask_np = self._action_mask(slate_df, chosen, elig, salary_used)
            mask = torch.tensor(mask_np, dtype=torch.bool)
            logits = self.policy(X)  # (N,)
            probs = masked_softmax(logits, mask)
            dist = torch.distributions.Categorical(probs=probs)
            a = dist.sample()
            while not mask_np[a.item()]:
                a = dist.sample()
            chosen.append(a.item())
            logps.append(dist.log_prob(a))
            entropies.append(dist.entropy())
            salary_used += int(slate_df.loc[a.item(), 'salary'])

        return slate_df.loc[chosen].copy(), logps, entropies

    def update(self, reward: float, logps: List[torch.Tensor], entropies: List[torch.Tensor]):
        # REINFORCE: -(R - b) * sum logpi + entropy regularization
        self.baseline = 0.9 * self.baseline + 0.1 * reward if self.baseline != 0 else reward
        advantage = reward - self.baseline
        loss = -advantage * torch.stack(logps).sum() - self.cfg.entropy_coef * torch.stack(entropies).sum()
        self.opt.zero_grad()
        loss.backward()
        self.opt.step()
