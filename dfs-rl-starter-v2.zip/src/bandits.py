
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Tuple

@dataclass
class LinTS:
    """Bayesian linear Thompson Sampling with ridge prior per position.
    Model: reward ~ x^T theta + eps, prior theta ~ N(0, alpha^2 I)
    We maintain A = (X^T X + lambda I), b = X^T y
    """
    d: int
    alpha: float = 1.0   # prior std
    lam: float = 1.0     # ridge term
    A: np.ndarray = field(init=False)
    b: np.ndarray = field(init=False)

    def __post_init__(self):
        self.A = self.lam * np.eye(self.d)
        self.b = np.zeros((self.d, 1))

    def sample_theta(self, sigma2: float = 1.0) -> np.ndarray:
        A_inv = np.linalg.inv(self.A)
        mu = A_inv @ self.b  # posterior mean
        # Posterior covariance ~ sigma2 * A_inv (up to scaling with prior); scale by alpha^2
        cov = (self.alpha**2) * A_inv * sigma2
        # Sample theta ~ N(mu, cov)
        L = np.linalg.cholesky(cov + 1e-8 * np.eye(self.d))
        z = np.random.randn(self.d, 1)
        return mu + L @ z

    def update(self, x: np.ndarray, r: float):
        x = x.reshape(-1,1)
        self.A += x @ x.T
        self.b += x * r

class PositionBandits:
    """Maintain a LinTS per position with shared feature dimension."""
    def __init__(self, positions, d=4, alpha=1.0, lam=1.0):
        self.models = {p: LinTS(d=d, alpha=alpha, lam=lam) for p in positions}
        self.d = d

    def sample_scores(self, position: str, X: np.ndarray, sigma2: float = 1.0) -> np.ndarray:
        theta = self.models[position].sample_theta(sigma2=sigma2)  # (d,1)
        return (X @ theta).ravel()

    def update(self, position: str, X: np.ndarray, y: np.ndarray):
        for x, r in zip(X, y):
            self.models[position].update(x, float(r))
