
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Optional, Set

@dataclass
class Slot:
    name: str
    eligible: Set[str]

@dataclass
class RosterRules:
    site: str
    salary_cap: int
    slots: List[Slot]
    max_from_team: Optional[int] = None

    def all_eligible(self) -> Dict[str, Set[str]]:
        return {s.name: set(s.eligible) for s in self.slots}

# --- DraftKings Classic ---
def dk_nfl_rules(max_from_team: Optional[int] = 4) -> RosterRules:
    # DK Classic: QB, RB, RB, WR, WR, WR, TE, FLEX(RB/WR/TE), DST; cap = 50,000
    return RosterRules(
        site="DK",
        salary_cap=50000,
        slots=[
            Slot("QB", {"QB"}),
            Slot("RB1", {"RB"}),
            Slot("RB2", {"RB"}),
            Slot("WR1", {"WR"}),
            Slot("WR2", {"WR"}),
            Slot("WR3", {"WR"}),
            Slot("TE", {"TE"}),
            Slot("FLEX", {"RB","WR","TE"}),
            Slot("DST", {"DST"}),
        ],
        max_from_team=max_from_team
    )

# --- FanDuel Classic ---
def fd_nfl_rules(max_from_team: Optional[int] = 4) -> RosterRules:
    # FD Classic (2024+): QB, RB, RB, WR, WR, WR, TE, FLEX(RB/WR/TE), DEF; cap = 60,000
    return RosterRules(
        site="FD",
        salary_cap=60000,
        slots=[
            Slot("QB", {"QB"}),
            Slot("RB1", {"RB"}),
            Slot("RB2", {"RB"}),
            Slot("WR1", {"WR"}),
            Slot("WR2", {"WR"}),
            Slot("WR3", {"WR"}),
            Slot("TE", {"TE"}),
            Slot("FLEX", {"RB","WR","TE"}),
            Slot("DEF", {"DST"}),
        ],
        max_from_team=max_from_team
    )

TEMPLATES = {"DK": dk_nfl_rules, "FD": fd_nfl_rules}
