#!/usr/bin/env python
#####################################
#Usage: myva2ael.py vafiles
######################################
# create ael files from veriloga files
# Apr 2015
#####################################

import sys, glob,re
tab = "\t"
unit_list = ['STRING_UNIT','UNITLESS_UNIT','FREQUENCY_UNIT','RESISTANCE_UNIT','CONDUCTANCE_UNIT','INDUCTANCE_UNIT','CAPACITANCE_UNIT','LENGTH_UNIT','TIME_UNIT','ANGLE_UNIT','POWER_UNIT','VOLTAGE_UNIT','CURRENT_UNIT','DISTANCE_UNIT','TEMPERATURE_UNIT','DB_GAIN_UNIT']
unit_symbol_list = ['','','Hz','Ohm','Mho','H','F','m','s','radians','dB','V','A','m','C','dB']
def parse_va_parameter(va_parameter_list):
    temp = va_parameter_list
    name = temp[2]
    default = temp[4]
    if default[-1] == ';':
        default = default[0:len(default)-1]
    unit = temp[-1]
    if '\\' not in unit:
        unit = 'UNITLESS_UNIT'
    else:
        unit = unit[2:len(unit)]
        if unit not in unit_list:
            unit = 'UNITLESS_UNIT'
        default += unit_symbol_list[unit_list.index(unit)]
    return (name,default,unit)
    
def va2ael(va_fn):
    va_file = open(va_fn,'r')
    model_name = va_fn[0:-3]
    ael_fn = '../networks/' + model_name + '.ael'
    #ael_fn = model_name + '.ael'
    ael_file = open(ael_fn,'w')
    ael_file.write("/* AEL counterpart to the verilog model " + model_name + "*/" + "\n")
    ael_file.write("create_item(\"" + model_name + "\","+ "\n")
    ael_file.write(tab+"\"Verilog-A implementation of " + model_name +"\","+ "\n")
    ael_file.write(tab+"\"" + model_name + "\","+ "\n")
    ael_file.write(tab+"NULL,"+ "\n")
    ael_file.write(tab+"NULL,"+ "\n")
    ael_file.write(tab+"\"" + model_name + "\","+ "\n")
    ael_file.write(tab+"standard_dialog,"+ "\n")
    ael_file.write(tab+"\"*\","+ "\n")
    ael_file.write(tab+"ComponentNetlistFmt,"+ "\n")
    ael_file.write(tab+"\"" + model_name + "\","+ "\n")
    ael_file.write(tab+"ComponentAnnotFmt,"+ "\n")
    ael_file.write(tab+"\"SYM_" + model_name + "\","+ "\n")
    ael_file.write(tab+"no_artwork,"+ "\n")
    ael_file.write(tab+"NULL,"+ "\n")
    ael_file.write(tab+"ITEM_PRIMITIVE_EX")
    
    for line in va_file:
        #if line.startswith("\s+parameter"):
        if re.match(r'\s+parameter\s+.*',line):
            temp = line.strip().split()
            temp = parse_va_parameter(temp)
            name = temp[0]
            default = temp[1]
            unit = temp[2]
            ael_file.write(","+ "\n"+tab+"create_parm(\"" + name + "\",\"...\", PARM_OPTIMIZABLE | PARM_STATISTICAL,\"StdFileFormSet\", "+ unit + ", prm(\"StdForm\", \"" + default + "\"))")
    ael_file.write(");")
    ael_file.close()
    va_file.close()

def main():
    flist = glob.glob('*.va')
    for f in flist: 
        va2ael(f)
        print '%s.ael is created' %f[0:-3]
                    
if __name__ == '__main__':
    main()