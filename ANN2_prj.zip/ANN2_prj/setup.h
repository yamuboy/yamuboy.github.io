
#include "file.h"

#ifndef _ST_H_
#define _ST_H_

//#define TRANSFORM(a,b,c) (asin(sqrt(((a)-(b))/((c)-(b)))))
//#define UNTRANSFORM(a,b,c) ((b)+((c)-(b))*sin((a))*sin((a)))

#define MAXout 10 
#define MAXin 10
#define MAX_Neurons 400 
#define MAX_Inputs 400 
#define MAX_Outputs 400 
#define MAX_Layers 7
#define MAX_Data 400
#define zero 0
#define PI 3.14159265358979323846264338327950288

//#define Tx(x,l,u) ( sqr(sin(0.5*PI*((x)-(l))/((u)-(l)))) ) 
//#define UnTx(x,l,u) ( (l) + ((u)-(l))*2*asin( sqrt(x) )/PI  ) 
#define Tx(x,l,u) ( ((x)-(l))/((u)-(l)) ) 
#define UnTx(x,l,u) ( (l) + ((u)-(l))*(x) ) 



typedef struct 
{
	FILE *Input, *Output;
    char Infile[MAXLINELENGTH],Outfile[MAXLINELENGTH];
  	char Dfile[MAXLINELENGTH], Wfile[MAXLINELENGTH] ;
    
    char sval[MAXLINELENGTH],seq[MAXLINELENGTH],svar[MAXLINELENGTH];
    char delim ;
	double Vgs[MAX_Data], Vds[MAX_Data], Ids[MAX_Data];
	int Load_The_Weights, Randomize_The_Weights ;
	int Vg_col, Vd_col, Id_col ;
	int Ninputs, N1, N2, N3, N4, N5, N6, NNpl[MAX_Layers]; 
	double HeatFactor, AlphaMax, AlphaMin ;
	double Tmin, Tmax, OptError ;
	int nAlpha, nTemp, nRelax, nOptIters; 
} Cntrl;
 

typedef struct 
{
   double SLamda, Eta, minERROR;
   int nITER, MAXITER;
   int DB, DATAmax, MRI;
   double WF, PEC, Alpha, Beta, Temp;

} SETUP;


typedef struct 
{
   int Layer, Index, Ninputs;
   double e, o, *w, dode, oerror, *wold, *wtemp, b, bold, btemp;

} Neuron;


typedef struct 
{
   int Ni, No, Nmax, Nlayers, Total_Neurons;
   int *Nl, *Ni_col, *No_col, Nweights;
   Neuron *N, **Nron;
   double **D, **R, Error;

} NeuralNet;

typedef struct 
{
   double dT[3], dR;

} TData;

typedef struct 
{
   double **dT, **dR;
   double *dThigh, *dTlow, *dRhigh, *dRlow ;
   int NTsamples;

} Data;



#endif
