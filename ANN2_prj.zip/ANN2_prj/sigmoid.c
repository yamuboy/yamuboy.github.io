
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

//#include "protos.h"

extern double sigmoid(double , double);
extern double ds_dx(double , double );


double sigmoid(double lamda, double x)
{
	double output, dx;
	
	dx = exp(-lamda*x) ;
	output = 1/(1+dx) ;

	return output;
}


double ds_dx(double lamda, double x)
{
	double do_dx, dx;
	
	dx = sigmoid(lamda,x);
	do_dx = lamda*dx*(1-dx);
	
	return do_dx;
}