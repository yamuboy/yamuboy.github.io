
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

extern void free_Nmatrix(Neuron **, long , long , long , long );
extern double sigmoid(double , double);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);
extern void Load_Weights(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Allocate_Neural_Memory(NeuralNet *, SETUP *, Cntrl *);

void Load_Weights(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{ 
   int i;
   char seq[MAXLINELENGTH];
   char LAYER[MAXLINELENGTH],NEURON[MAXLINELENGTH],WEIGHT[MAXLINELENGTH], VAL[MAXLINELENGTH];
   int line=0, words;
   char linebuffer[MAXLINELENGTH];


   
   C->Input  = fopen(C->Wfile,READ);

   printf("\n\n");
   printf("====================================================================\n");
   printf("=====>>> Loading all Neural synaptic weights to file: %s \n", C->Wfile);
   printf("====================================================================\n");
   printf("\n");
   
   line=0;
   while (getline(C->Input,linebuffer,MAXLINELENGTH) > 0)
   {

		if (line==0)
		{
		    get_word_o(linebuffer,MAXLINELENGTH,1, seq );
			NNet->Ni = atoi(seq);
	        get_word_o(linebuffer,MAXLINELENGTH,2, seq);
			NNet->No = atoi(seq);
       	    get_word_o(linebuffer,MAXLINELENGTH,3, seq);
			NNet->Nlayers = atoi(seq);
			get_word_o(linebuffer,MAXLINELENGTH,4, seq);
			NNet->Nmax = atoi(seq);
			NNet->Nl = ivector(1,NNet->Nlayers);
			for (i=1 ; i<=NNet->Nlayers-1 ; i++)
			{
			   get_word_o(linebuffer,MAXLINELENGTH,i+4  ,seq );
			   NNet->Nl[i] = atoi(seq);
			}
			NNet->Nl[NNet->Nlayers] = NNet->No;
			Allocate_Neural_Memory(NNet, Parms, C);
		} 
		line++ ;


        words = count_words_o(linebuffer,MAXLINELENGTH);
        if (words == 3)
		{  
		   get_word_o(linebuffer,MAXLINELENGTH,1,LAYER);
		   get_word_o(linebuffer,MAXLINELENGTH,2,NEURON);
		   get_word_o(linebuffer,MAXLINELENGTH,3,VAL);
		   NNet->Nron[atoi(LAYER)][atoi(NEURON)].b = atof(VAL);
		}
		else if (words == 4)
		{
		   get_word_o(linebuffer,MAXLINELENGTH,1,LAYER);
		   get_word_o(linebuffer,MAXLINELENGTH,2,NEURON);
		   get_word_o(linebuffer,MAXLINELENGTH,3,WEIGHT);
		   get_word_o(linebuffer,MAXLINELENGTH,4,VAL);
		   NNet->Nron[atoi(LAYER)][atoi(NEURON)].w[atoi(WEIGHT)] = atof(VAL);
		}
   }  
   
   fclose(C->Input);

}







