


#ifndef _NN_H_
#define _NN_H_

extern Neuron *Nalloc(long, long);
extern void free_Neuron(Neuron *, long, long);
extern Neuron **Nmatrix(long , long , long , long );
extern void free_Nmatrix(Neuron **, long , long , long , long );
extern Data *Dalloc(long, long);
extern void free_Data(Data *, long, long);

#endif
