

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

//#include "protos.h"
//#include "neuron.h"

//extern void Validate(NeuralNet NNet, SETUP Parms, TData TD[], Cntrl C);
extern void Parse_Infile(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
//extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
//extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *);
extern void Update_Weights(NeuralNet *);
extern void Load_Data(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Validat(NeuralNet , SETUP , Data, Cntrl);
extern void Random_Initialization(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Allocate_Neural_Memory(NeuralNet *, SETUP *, Cntrl *);
extern void Set_Up_Neural_Network(NeuralNet *, SETUP *, Cntrl *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Train_Network(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);
extern void Load_Weights(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Anneal_Network(NeuralNet *, SETUP *, Data *, Cntrl *);
extern double ran1(long *);

extern float OptFun(float *);
extern void dOF(float *, float *);
extern void amoeba(float **p, float y[], int ndim, float ftol, 
				   float (*funk)(float *), int *nfunk);
extern float amotry(float **p, float y[], float psum[], int ndim,
	                float (*funk)(float []), int ihi, float fac);
extern void amebsa(float **p, float y[], int ndim, float pb[], float *yb, float ftol,
	               float (*funk)(float []), int *iter, float temptr);
extern void frprmn(float p[], int n, float ftol, int *iter, float *fret,
                   float (*func)(float []), void (*dfunc)(float [], float []));
extern void dfpmin(float p[], int n, float gtol, int *iter, float *fret,
	               float(*func)(float []), void (*dfunc)(float [], float []));
extern void powell(float p[], float **xi, int n, float ftol, int *iter, float *fret,
                   float (*func)(float []));





NeuralNet  NNet; 
SETUP Parms;
Cntrl C;
Data TDat;

long idum;



int main(int argc,char *argv[])
{
   char *nlist[10]={"0","1","2","3","4","5","6","7","8","9"};
   

   float  (*Opt_Fun_fcn)(float *);
   float **Starting_Simplex, *Starting_Point, char_length;
   float *FOM_Vector, FOM_tolerance;
   int j,i,ii,NWeights, Number_of_Evals;
float aT, To, deltaT, FOM;
float *End_Point;
float *Weight;
int ndx,ne;

goto start;

Number_of_Evals = 0;
char_length = 1;
NWeights = 4;
FOM_tolerance = (float)0.00000001 ;
            
Starting_Point   = vector(1,NWeights+1);
End_Point        = vector(1,NWeights);
Starting_Simplex = matrix(1,NWeights+1,1,NWeights);
FOM_Vector       = vector(1,NWeights+1);

for ( i=1 ; i <= NWeights ; i++ )
{
   Starting_Point[i] = 0.25;
}

for ( i=0 ; i <=NWeights ; i++) 
{
   for ( j=1 ; j <= NWeights ; j++ ) 
   {
      Starting_Simplex[i+1][j] = Starting_Point[j];
      if ( i == j) Starting_Simplex[i+1][j] += char_length;
   }
}
for ( i=0 ; i <=NWeights ; i++ )  
{
   FOM_Vector[i+1] = (*OptFun)(Starting_Simplex[i+1]);
}

printf("Starting Optimization   num_evals = %d\n", Number_of_Evals);
//==========================================================================
//amoeba(Starting_Simplex, FOM_Vector, NWeights, FOM_tolerance, 
//                    OptFun, &Number_of_Evals);
//==========================================================================
/*
FOM = 1e9 ;
To = 100 ;
deltaT = 50 ;

for ( aT = To ; aT >= 0.0 ; aT -= deltaT )
{
    Number_of_Evals = 10000 ;
	amebsa(Starting_Simplex, FOM_Vector, NWeights, End_Point, &FOM, 
          FOM_tolerance, OptFun, &Number_of_Evals, aT);
}
free_vector(End_Point,1,NWeights);
*/
//==========================================================================

printf("Starting FRPMRN\n\n");

//powell(Starting_Point, **xi, NWeights, FOM_tolerance, &Number_of_Evals, &FOM, OptFun);

frprmn(Starting_Point, NWeights, FOM_tolerance, &Number_of_Evals, &FOM, OptFun, dOF);
//dfpmin(Starting_Point, NWeights, FOM_tolerance, &Number_of_Evals, &FOM,	OptFun, dOF);

printf("Optimization  Completed =====> FOM = %.12f\n", FOM);
printf("Optimization  Completed =====> p1 = %.12f  p2 = %.12f\n", Starting_Point[1],Starting_Point[2]);
printf("Optimization  Completed =====> p3 = %.12f  p4 = %.12f\n", Starting_Point[3],Starting_Point[4]);
printf("Optimization  Completed =====> num_evals = %d\n", Number_of_Evals);

goto end;









 start:



   if (argc < 2) 
   {
      fprintf(stderr,"Not enough command line parameters.\n");
      fprintf(stderr,"Usage: ANN infile \n");
      fprintf(stderr,"Enter input file name\n");
      fscanf(stdin,"%s",&C.Infile);
   }
   else 
   {
      strcpy(C.Infile, argv[1]);
   }

   	
/*
* ----- Initialize the number layers and number of neurons per layer to zero
*/

   Parse_Infile(&NNet, &Parms, &TDat, &C);
  	

/*
* ----- Open the input data file and construct the Inputs and Targets for the NET
*/
   
   Load_Data(&NNet, &Parms, &TDat,  &C);

   if (C.Load_The_Weights==0)
   {

      /*
       * ----- Set up Neural Map from User Inputs
       */

      Set_Up_Neural_Network(&NNet, &Parms, &C);

      /*
       * ----- Allocate Main Memory Space for Neural Map
       */

      Allocate_Neural_Memory(&NNet, &Parms, &C);
	  /*
       * ----- Use Random Initialization to Find Set of Optimum Weights before Training
       */
      
	  Random_Initialization(&NNet, &Parms, &TDat, &C);
     
   }
   else if (C.Load_The_Weights==1)
   {
	   Load_Weights(&NNet, &Parms, &TDat, &C);
   }
/*
* ----- Display Initial Weights
*/
//   display_weights(NNet);
   

/*
* ----- Train Network Over All Data Sets - Implement Forward and Back Propagation
*/
   Anneal_Network(&NNet, &Parms, &TDat, &C);
   Train_Network(&NNet, &Parms, &TDat, &C);
     
   
   
   
   
          
   Weight   = vector(1,NNet.Nweights);
   FOM = 1e9 ;

   ndx = 0;
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
         ndx++;
	     Weight[ndx] = NNet.Nron[i][j].b;
		 if (i>1)
		 {
		    for (ii=1; ii<=NNet.Nl[i-1]; ii++)
			{
				ndx++;
                Weight[ndx] = NNet.Nron[i][j].w[ii];
			}
		 }
	     else
		 {
		    for (ii=1; ii<=NNet.Ni; ii++)
			{
			   ndx++;
			   Weight[ndx] = NNet.Nron[i][j].w[ii];
			}
		 }
 	  }
   }

// - FRPRMN works well........
//   frprmn(Weight, NNet.Nweights, C.OptError, 
//	    &Number_of_Evals, &FOM, OptFun, dOF);

// - DFPMIN doesnt work well........
//   dfpmin(Weight, NNet.Nweights, C.OptError, 
//		    &Number_of_Evals, &FOM, OptFun, dOF);

//====================================================================
   
/**/   
Number_of_Evals = 0;
char_length = 0.1;

            
Starting_Point   = vector(1,NNet.Nweights);
End_Point        = vector(1,NNet.Nweights);
Starting_Simplex = matrix(1,NNet.Nweights+1,1,NNet.Nweights);
FOM_Vector       = vector(1,NNet.Nweights+1);

for ( i=1 ; i <= NNet.Nweights ; i++ )
{
   Starting_Point[i] = Weight[i];
}

for ( i=1 ; i <=NNet.Nweights+1 ; i++) 
{
   for ( j=1 ; j <= NNet.Nweights ; j++ ) 
   {
      Starting_Simplex[i][j] = Starting_Point[j] + 0.01*ran1(&idum);
//	  printf("i=%d  j=%d  S = %f  \n",i,j, Starting_Simplex[i][j]);
//	  Starting_Simplex[i][j] += 0.1*ran1(&idum);
//      if ( i == j) Starting_Simplex[i][j] += 0.1*ran1(&idum);
//	  if ( i == j) Starting_Simplex[i][j] += 0.1;
   }
}
for ( i=1 ; i <=NNet.Nweights+1 ; i++ )  
{
   FOM_Vector[i] = (*OptFun)(Starting_Simplex[i]);
}

FOM = 1e9 ;
To = 1 ;
deltaT = 0.1 ;
/**/


/*
for ( aT = To ; aT >= 0.0 ; aT -= deltaT )
{
    Number_of_Evals = 20000 ;
	amebsa(Starting_Simplex, FOM_Vector, NNet.Nweights, Weight, &FOM, 
          C.OptError, OptFun, &Number_of_Evals, aT);
}
//free_vector(End_Point,1,NWeights);   
*/

amoeba(Starting_Simplex, FOM_Vector, NNet.Nweights, C.OptError, 
               OptFun, &Number_of_Evals);


/*
free_matrix(Starting_Simplex, 1, NNet.Nweights+1, 1, NNet.Nweights);

Starting_Simplex = matrix(1,NNet.Nweights,1,NNet.Nweights);

for ( i=1 ; i <=NNet.Nweights ; i++) 
{
   for ( j=1 ; j <= NNet.Nweights ; j++ ) 
   {
      Starting_Simplex[i][j] = ran1(&idum);
      if ( i == j) Starting_Simplex[i][j] += char_length;
   }
}

powell(Starting_Point, Starting_Simplex, NNet.Nweights, C.OptError, 
	     &Number_of_Evals, &FOM, OptFun);
*/

   
 //====================================================================  
   
   
   
   ne = 2 ;
   ndx = 0;
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
         ndx++;
	     NNet.Nron[i][j].b = Weight[ndx];
		 NNet.Nron[i][j].b = Starting_Simplex[ne][ndx];
		 if (i>1)
		 {
		    for (ii=1; ii<=NNet.Nl[i-1]; ii++)
			{
				ndx++;
                NNet.Nron[i][j].w[ii] = Weight[ndx];
				NNet.Nron[i][j].w[ii] = Starting_Simplex[ne][ndx];
			}
		 }
	     else
		 {
		    for (ii=1; ii<=NNet.Ni; ii++)
			{
			   ndx++;
			   NNet.Nron[i][j].w[ii] = Weight[ndx];
			   NNet.Nron[i][j].w[ii] = Starting_Simplex[ne][ndx];
			}
		 }
 	  }
   }



/*
* ----- Send training data through the network to validate network
* ----- Save All data to output file for plotting
*/
	
   Validat(NNet, Parms, TDat, C);

/*
* ----- Display Final Weights
*/

//   display_weights(NNet);

/*
* ----- Save ALL Final Weight to File
*/

   Save_Weights_To_File(&NNet, &Parms, &TDat, &C);

/*
* ----- Graph the output results
*/
//	system("notepad") ;
//   system("p c:\\taw\\code\\ann_prj\\debug\\dplot") ;
    system("p c:\\taw\\code\\ann_prj\\debug\\mplot") ;
//   system("p c:\\taw\\code\\ann_prj\\debug\\splot") ;


/*
* ----- Deallocate all memory
*/

   Deallocate_Memory(&NNet, &Parms);

   printf("\n\n");
   printf("========================================\n");
   printf("============= EXIT PROGRAM =============\n");

/*
* ----- Exit main()
*/

   end:
   return 0;

}
