

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern void free_Nmatrix(Neuron **, long , long , long , long );
extern double sigmoid(double , double);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);




#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define MASK 123459876

double ran0(long *idum)
{
	long k;
	double ans;

	*idum ^= MASK;
	k=(*idum)/IQ;
	*idum=IA*(*idum-k*IQ)-IR*k;
	if (*idum < 0) *idum += IM;
	ans=AM*(*idum);
	*idum ^= MASK;
	return ans;
}
#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef MASK

