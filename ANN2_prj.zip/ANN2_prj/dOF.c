

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern NeuralNet  NNet; 
extern SETUP Parms;
extern Cntrl C;
extern Data TDat;

extern void dOF(float *, float *);
extern float OptFun(float *);


void dOF(float *Weights, float *Derivitive)
{
   float Fvalplus,Fval,delh,wsave;
   int i;
	
   delh = (float)0.00001 ;
/* 
* ----- Compute Numerical Derivitives ----- 
*/  

   for (i=1; i<=NNet.Nweights; i++)
   {
	  Fval       = OptFun(Weights);
      wsave      = Weights[i] ;
	  Weights[i] = Weights[i] + delh ;
	  Fvalplus   = OptFun(Weights);
	  Weights[i] = wsave ;
      
	  Derivitive[i] = (Fvalplus - Fval) / delh ; 
   }

   
  	   
}

