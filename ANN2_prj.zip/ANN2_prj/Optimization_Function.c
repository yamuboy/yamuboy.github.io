

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

extern NeuralNet  NNet; 
extern SETUP Parms;
extern Cntrl C;
extern Data TDat;

extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);

extern float OptFun(float *);

float OptFun(float *Weights)
{
   int ndx, ic, i, j, ii, k;


/* 
* ----- Translate Opt Vars into Weights ----- 
*/  
   ndx = 0;
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
         ndx++;
	     NNet.Nron[i][j].b = Weights[ndx];
		 if (i>1)
		 {
		    for (ii=1; ii<=NNet.Nl[i-1]; ii++)
			{
				ndx++;
                NNet.Nron[i][j].w[ii] = Weights[ndx];
			}
		 }
	     else
		 {
		    for (ii=1; ii<=NNet.Ni; ii++)
			{
			   ndx++;
			   NNet.Nron[i][j].w[ii] = Weights[ndx];
			}
		 }
 	  }
   }


   NNet.Error = 0 ;

   for (ic=1; ic<=TDat.NTsamples ; ic++)
   {
      Forward_Prop(ic, &NNet, &Parms, &TDat);
      for (k=1; k<=NNet.Nl[NNet.Nlayers]; k++)
	  {		 
		 NNet.Error = NNet.Error + sqr(TDat.dR[ic][k] - NNet.Nron[NNet.Nlayers][k].o);
	  }
   }
       
   NNet.Error = 0.5*NNet.Error/(TDat.NTsamples*NNet.No);

//   printf("OF: W1=%.9f  W2=%.9f Error = %.9f  \n",Weights[1],Weights[NNet.Nweights],NNet.Error);

   return (float)NNet.Error;

}
