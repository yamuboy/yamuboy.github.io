

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

//#include "protos.h"
//#include "neuron.h"

extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Train_Network(NeuralNet *, SETUP *, Data *, Cntrl *);
extern double ran1(long *);
extern long idum;


void Train_Network(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{
	double ERRORold, ERRORacc, ERRORdifference, temp ;
	int iter, niter, ic, k, smp ;
	
    printf("\n\n============ Forward Propagation ===========\n");
    

	iter       = 0;
	niter      = 0;
	NNet->Error = 1e9;

    niter = 0;
    temp = Parms->WF ;
	NNet->Error = 100 ;
	ERRORold = 1e9 ;


	ERRORold = 0.0;
	ERRORacc = 0.0;
	ERRORdifference = 1000;

    while (NNet->Error > Parms->minERROR && niter < Parms->MAXITER && ERRORdifference > Parms->PEC)
	{
	   NNet->Error = 0 ;

/*
	   for (ic=1; ic<=TDat->NTsamples ; ic++)
	   {
	
          smp = (int)((double)TDat->NTsamples*ran1(&idum));
		  if (smp < 1) smp = 1;
		  if (smp > TDat->NTsamples) smp = TDat->NTsamples;
		  Weight_Correct(smp, NNet, Parms, TDat);
	      for (k=1; k<=NNet->Nl[NNet->Nlayers]; k++)
		  {		 
			 NNet->Error = NNet->Error + sqr(TDat->dR[ic][k] - NNet->Nron[NNet->Nlayers][k].o);
		  }
	   }
*/
  
/**/
       for (ic=1; ic<=TDat->NTsamples ; ic++)
	   {
          Weight_Correct(ic, NNet, Parms, TDat);
	      for (k=1; k<=NNet->Nl[NNet->Nlayers]; k++)
		  {		 
			 NNet->Error = NNet->Error + sqr(TDat->dR[ic][k] - NNet->Nron[NNet->Nlayers][k].o);
		  }
	   }
/**/	   
       iter++ ;
       niter++ ;
       
	   NNet->Error = NNet->Error/(TDat->NTsamples*NNet->No);
	   ERRORold = ERRORacc ;
       ERRORacc = (NNet->Error + ERRORacc);
	   ERRORdifference = fabs((ERRORold - ERRORacc)/(ERRORold+1e-10)) ;

       if (iter == Parms->nITER)
	   { 
	       iter = 0;
		   printf("Iteration: %4.4d   Error: %12.11f  ErrDIFF = %10.9f of %10.9f \n",
			                          niter, NNet->Error, ERRORdifference, Parms->PEC);
	   }
    }

}
