

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern void free_Nmatrix(Neuron **, long , long , long , long );
extern double sigmoid(double , double);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);


void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms)
{ 

	int ii, j; 

    printf("\n\n");
    printf("========================================\n");
    printf("======= Deallocating ALL Memory ========\n");
    printf("========================================\n");


    free_ivector(NNet->Nl, 1, NNet->Nlayers);
    free_Nmatrix(NNet->Nron,1,NNet->Nlayers, 1,NNet->Nmax);
    for (ii=1; ii<=NNet->Nlayers; ii++)
    {
       for (j=1; j<=NNet->Nl[ii]; j++)
	   {
	      if (ii>1)
		  {
	         free_dvector(NNet->Nron[ii][j].w, 1, NNet->Nl[ii-1]);
			 free_dvector(NNet->Nron[ii][j].wold, 1, NNet->Nl[ii-1]);
		  }
	      else
		  {
             free_dvector(NNet->Nron[ii][j].w, 1,NNet->Ni);
			 free_dvector(NNet->Nron[ii][j].wold, 1,NNet->Ni);
		  }
	   }
    }

    printf("\n======= DONE Deallocating Memory =======\n");

}


