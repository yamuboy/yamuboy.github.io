import wx
import numpy as np
import os
import re
import network_params as net_params
import numpy as n
from modeling.mct_files import split_file
import matplotlib
matplotlib.use('WxAgg')
from matplotlib.backends.backend_wxagg import Toolbar, FigureCanvasWxAgg
from matplotlib.figure import Figure


class spar_container( object ):

    def __init__(self, fname):

        self.fname = fname
        self.data = []
        self.extracted_params = {'cgs':[], 'cgd':[], 'cds':[], 'gm':[], 'gds':[], 'ft':[], 'freq':[]}
        self.periphery = 0.6

        self.read()
        
    def read(self):
        
        d = net_params.BiasedTouchstone( self.fname )
        data_y = d.extract_and_convert( convert_to = 'y')
        for item in data_y:

            real_y11 = n.real(item.matrix[0,0])
            imag_y11 = n.imag(item.matrix[0,0])
            real_y21 = n.real(item.matrix[1,0])
            imag_y21 = n.imag(item.matrix[1,0])
            real_y12 = n.real(item.matrix[0,1])
            imag_y12 = n.imag(item.matrix[0,1])
            real_y22 = n.real(item.matrix[1,1])
            imag_y22 = n.imag(item.matrix[1,1]) 

            # extract cgs in pF/mm
            cgs_pfmm = 1e12*(imag_y11 + imag_y12)/(2*n.pi*item.freq*self.periphery)
            self.extracted_params['cgs'].append(cgs_pfmm)

            # extract cgd in pF/mm
            cgd_pfmm = -1e12*(imag_y12)/(2*n.pi*item.freq*self.periphery)
            self.extracted_params['cgd'].append(cgd_pfmm)

            # extract cds in pF/mm
            cds_pfmm = 1e12*(imag_y22 + imag_y12)/(2*n.pi*item.freq*self.periphery)
            self.extracted_params['cds'].append(cds_pfmm)

            # extract gm in mS/mm
            gm = 1000*(real_y21 - real_y12)/self.periphery
            self.extracted_params['gm'].append(gm)

            # extract gds in mS/mm
            gds = 1000*(real_y22 + real_y12)/self.periphery
            self.extracted_params['gds'].append(gds)

            # extract ft
            ft = gm/(2*n.pi*cgs_pfmm)
            self.extracted_params['ft'].append(ft)

            self.extracted_params['freq'].append(item.freq)         

    def params_at_freq(self, freq):
        self.current_data = {}
        for i in self.extracted_params['freq']:
            if i == freq:
                pass

    def params_at_freq_range(self):
        pass

    def write(self):
        pass

    @property
    def cgs(self):
        return self.extracted_params['cgs']

    @property
    def freq_list(self):
        return self.extracted_params['freq']

    @property
    def cds(self):
        return self.extracted_params['cds']

    @property
    def cgd(self):
        return self.extracted_params['cgd']
    
    @property
    def gm(self):
        return self.extracted_params['gm']

    @property
    def gds(self):
        return self.extracted_params['gds'] 

    @property
    def filename(self):
        return self.filename

class deembedding_dialog(wx.Dialog):
    def __init__(self, parent, id, title = "Deembedding Dialog"):
        wx.Dialog.__init__(self, parent, id, title, size = (800,500))
        panel = wx.Panel( self, -1, (75,20), (100,127), style = wx.SUNKEN_BORDER)
        self.picture = wx.StaticBitmap(panel)
        panel.SetBackgroundColour(wx.WHITE)

        self.picture.SetFocus()
        self.picture.SetBitmap(wx.Bitmap('cal.bmp'))

        self.Centre()




class MainWindow(wx.Frame):
    def __init__(self, parent = None, *args, **kwargs ):

        super(MainWindow,self).__init__(parent, *args,**kwargs)
        
        self.init()

    def init(self):
        
        menubar = wx.MenuBar()

        # file menu
        file_menu = wx.Menu()
        file1 = file_menu.Append( wx.ID_ANY, "Add Datasets")
        file2 = file_menu.Append( wx.ID_ANY, "Edit Datasets")
        file3 = file_menu.Append( wx.ID_ANY, "Clear Datasets")
        file4 = file_menu.Append( wx.ID_ANY, "Save Plots")
        file_menu.AppendSeparator()
        file5 = file_menu.Append( wx.ID_EXIT, "Exit")

        # de-embed data 
        deembed_menu = wx.Menu()
        deembed1 = deembed_menu.Append( wx.ID_ANY, "Deembed Data")

        utils_menu = wx.Menu()
        utils1 = utils_menu.Append( wx.ID_ANY, "Split Touchstone")
        
        self.Bind( wx.EVT_MENU, self.OnAddDataset, file1 )
        self.Bind( wx.EVT_MENU, self.OnEditDataset, file2 )
        self.Bind( wx.EVT_MENU, self.OnClearDataset, file3)
        self.Bind( wx.EVT_MENU, self.OnSave, file4)
        self.Bind( wx.EVT_MENU, self.OnExit, file5)

        self.Bind( wx.EVT_MENU, self.OnDeembed, deembed1)

        self.Bind( wx.EVT_MENU, self.OnSplit, utils1)

        menubar.Append( file_menu, "File")
        menubar.Append( deembed_menu, "De-Embed")
        menubar.Append( utils_menu, "Utils")

        self.SetMenuBar(menubar) 

        main_sizer = wx.BoxSizer(wx.VERTICAL)
        sizer = wx.BoxSizer(wx.VERTICAL)
        plot_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.choices = ['Extracted Cgs (pF/mm)', 'Extracted Cgd (pF/mm)','Extracted Cds (pF/mm)', 'Gm (pF/mm)', 'Gds (pF/mm)']
        self.combo_box = wx.ComboBox(self, -1, choices = self.choices)
        plot_button = wx.Button(self, 1, "Plot Parameter")

        sizer.Add(self.combo_box, 0, wx.CENTER|wx.ALL, 8)
        sizer.Add(plot_button, 0, wx.CENTER|wx.ALL, 8)        

        self.Bind( wx.EVT_BUTTON, self.OnPlot, plot_button)
        self.Bind( wx.EVT_COMBOBOX, self.PlotType, self.combo_box)
        
        self.fig = Figure((5,4), 75)
        self.canvas = FigureCanvasWxAgg(self, -1, self.fig)
        
        plot_sizer.Add(self.canvas, wx.EXPAND|wx.CENTER)
        
        main_sizer.Add(sizer, 0, wx.ALL|wx.CENTER)
        main_sizer.Add(plot_sizer, 0, wx.EXPAND|wx.ALL)

        # show this Window
        
        self.SetSizerAndFit(main_sizer)
        self.SetSize((800,800))
        self.Centre()
        self.Show(True)
        

    def PlotType(self, event):
        # plot mapping
        mapping = [(0,'cgs'),(1,'cgd'),(2,'cds'),(3,'gm'),(4,'gds')]
        for i in range(len(mapping)):
            if mapping[i][0] == int(event.GetSelection()):
                self.plot_type = mapping[i][1]

    def OnSplit(self, event):
        self.files_to_split = []
        dlg = wx.FileDialog(self, "Select S-Par Files to Split", style = wx.FD_OPEN|wx.FD_FILE_MUST_EXIST|wx.FD_MULTIPLE)
        if dlg.ShowModal() == wx.ID_OK:
            for fname in dlg.GetPaths():
                extension = os.path.splitext(fname)[-1].lower()
                # include support for raw files
                if extension == '.s2p' or extension == '.raw':
                    self.files_to_split.append(fname)

            dlg.Destroy()

        root = os.getcwd()

        for f in self.files_to_split:
            # split the filename to get the root dir
            os.chdir(os.path.split(f)[0])
            dir_name = os.path.split(f)[1].split('.')[0]
            os.mkdir(dir_name)
            new_dir = os.path.join(os.getcwd(), dir_name)
            os.chdir(new_dir)
            split_file(f)
            os.chdir(root)


    def OnAddDataset(self, event):
        self.files = []
        dlg = wx.FileDialog(self, "Select S-Par Data File", style = wx.FD_OPEN|wx.FD_FILE_MUST_EXIST|wx.FD_MULTIPLE)
        if dlg.ShowModal() == wx.ID_OK:
            # go through the files and check to make sure only S2P files exist
            for fname in dlg.GetPaths():
                extension = os.path.splitext(fname)[-1].lower()
                # include support for raw files
                if extension == '.s2p' or extension == '.raw':
                    self.files.append(fname)

            dlg.Destroy()  

    def OnPlot(self, event):
        self.data = []
        labels = []
        for f in self.files:
            self.data.append(spar_container(f))
            labels.append(os.path.basename(f))
        self.a = self.fig.add_subplot(111)
        if self.plot_type == 'cgs':
            self.a.clear()
            for data in self.data:
                self.a.plot(data.freq_list, data.cgs)
            self.a.set_ylabel('Cgs (pF/mm)')
            self.a.set_xlabel('Freq (Hz)')
            self.a.set_title('Cgs vs. Frequency')
            self.a.legend(labels, loc = 'upper right')
            self.canvas.draw() 
        elif self.plot_type == 'cgd':
            self.a.clear()
            for data in self.data:
                self.a.plot(data.freq_list, data.cgd)        
            self.a.set_ylabel('Cgd (pF/mm)')
            self.a.set_xlabel('Freq (Hz)')
            self.a.set_title('Cgd vs. Frequency')
            self.a.legend(labels, loc = 'upper right')
            self.canvas.draw()
        elif self.plot_type == 'cds':
            self.a.clear()
            for data in self.data:
                self.a.plot(data.freq_list, data.cds)
            self.a.set_ylabel('Cds (pF/mm)')
            self.a.set_xlabel('Freq (Hz)')
            self.a.set_title('Cds vs. Frequency')
            self.a.legend(labels, loc = 'lower left')
            self.canvas.draw() 
        elif self.plot_type == 'gm':
            self.a.clear()
            for data in self.data:
                self.a.plot(data.freq_list, data.gm)
            self.a.set_ylabel('Gm (mS/mm)')
            self.a.set_xlabel('Freq (Hz)')
            self.a.set_title('Gm vs. Frequency')
            self.a.legend(labels, loc = 'lower right')
            self.canvas.draw()
        elif self.plot_type == 'gds':
            self.a.clear()
            for data in self.data:
                self.a.plot(data.freq_list, data.gds)
            self.a.set_ylabel('Gds (mS/mm)')
            self.a.set_xlabel('Freq (Hz)')
            self.a.set_title('Gds vs. Frequency')
            self.a.legend(labels, loc = 'upper left')
            self.canvas.draw() 
                 
        
    def OnEditDataset(self, event):
        # create dialog to edit the data set
        pass

    def OnClearDataset(self, event):
        self.files = []
        self.a.clear() 
        self.canvas.draw()       

    def OnSave(self, event):
        # write the file to data or save the files
        pass

    def OnExit(self, event):
        self.Close()

    def OnDeembed(self, event):
        # deembedding GUI
        from network_params.deembed import DeembeddingUtil
        a = deembedding_dialog(self, -1)
        a.Show()
        '''
        General deembedding procedure
        frequency lists of deembedding structures and file to deembed must match
        kwargs = {fname1 : left_deembedding.s2p, 'swap1': False, 'invert1': True, 'fname2': right_deembed.s2p, 'swap2': False, 'invert2': True}
        a = DeembeddingUtil(**kwargs)
        b = a.deembed(file_to_deembed.s2p)
        b.write(deembedded_file.s2p)
        '''          
       
    
if __name__ == "__main__":
    
    app = wx.App()
    frame = MainWindow(None)
    app.SetTopWindow(frame)
    app.MainLoop()
    




