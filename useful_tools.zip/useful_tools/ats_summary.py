import sys
import math
from loadpull.ats_parser import maury_ats_parser

#  ---------------------------------------------------------------------------------
#         Maury Data summary tool
#  ---------------------------------------------------------------------------------

### a tuple of valid Maury data column names
maury_valid_col_names = (
    'Pout_dBm', 'Pin_avail_dBm', 'Pin_deliv_dBm', 'Gt_dB', 'Gp_dB', 'Iout_mA',
    'Iin_mA', 'Eff_%', 'Refl_coef', 'Refl_dB', 'C_dBm', 'C_2nd', 'C_3rd', 'IP3_dBm',
    'IP5_dBm', 'I3_dBm', 'I5_dBm', 'I7_dBm', 'Vout_v', 'Vin_v',
    )

# numerical tolerance for compression calculation
_compression_tol = 0.002
_numeric_tol = 1.0e-8

def translate_col( col ):
    """Translate a column name to the exact name and case
    required by the summary tool.
    
    This allows looser column names to be used on the
    user interface side, which should make things easier...
    """
    if col is None or col in maury_valid_col_names:
        return col
    
    c = col.lower()
    if c in ['pout','pout_dbm']:
        n = 'Pout_dBm'
    elif c in ['gain','gt','gt_db']:
        n = 'Gt_dB'
    elif c in ['gp','gp_db']:
        n = 'Gp_dB'
    elif c in ['iout','iout_ma']:
        n = 'Iout_mA'
    elif c in ['iin','iin_ma']:
        n = 'Iin_mA'
    elif c in ['eff','eff_%']:
        n = 'Eff_%'
    elif c in ['refl','refl_coef']:
        n = 'Refl_coef'
    elif c in ['refl_db','refldb']:
        n = 'Refl_dB'
    elif c in ['c','c_dbm']:
        n = 'C_dBm'
    elif c in ['c_3rd']:
        n = 'C_2nd'
    elif c in ['c_2nd']:
        n = 'C_3rd'
    elif c in ['ip3','ip3_dbm']:
        n = 'IP3_dBm'
    elif c in ['ip5','ip5_dbm']:
        n = 'IP5_dBm'
    elif c in ['i3','i3_dBm']:
        n = 'I3_dBm'
    elif c in ['i5','i5_dBm']:
        n = 'I5_dBm'
    elif c in ['i7','i7_dBm']:
        n = 'I7_dBm'
    else:
        raise ValueError("Invalid column name: '%s'" % c)
    return n

class maury_ats_summary(object):
    """Summarize Maury ATS data files based on a specified set
    of summary conditions.
    """
    
    def __init__( self, filename=None, column=None, condition=None, value=None, minimize=False, **kwargs ):
        """Create a maury_ats_summary object.
        
        filename - a string representing the filename of the Maury data file
           to summarize, or a file-like object of an already opened Maury
           data file, or a maury_ats_parser object.
        column - a string indicating the name of the column used when
           generating the summary. If this is not None then the column,
           condition, and value parameters will be passed to the
           set_condition() method.
        condition - the summary condition, see set_condition().
        value - the condition value, see set_condition().
        """
        
        self.__atsfile = None
        self.__summary = None
        self.__bestblock = -1
        self.__printcols = ('Pout_dBm', 'Eff_%')
        self.__condition = ('Pout_dBm','comp_gt',1.0)
        self.__findmin = bool(minimize)
        self.__cfg = dict()
        
        if column is not None:
            self.set_condition(column, condition, value)
        if filename is not None:
            self.set_file(filename)
        
    def find_minimum(self, flag=None):
        """Find the minimum value of the summary column instead
        of finding the maximum (default).

        Parameters:
        flag - (boolean) If True then find the minimum, otherwise
           find the maximum.
        """
        if flag is not None:
            self.__findmin = bool(flag)
            if self.__atsfile:
                self.summarize()
        return self.__findmin
    minimize = property(find_minimum,find_minimum)

    def reset(self):
        """Delete file data and clear the summary and condition."""
        self.__atsfile = None
        self.__summary = None
        self.__bestblock = -1
        self.__condition = ('Pout_dBm','comp_gt',1.0)
        self.__findmin = False
        
    def clear(self):
        """Delete file data and clear the summary but leave conditions intact."""
        self.__atsfile = None
        self.__summary = None
        self.__bestblock = -1
        
    def set_file(self, filename, auto_summarize=True):
        """Set the ATS data file to use for the summary.
        
        filename - a string representing the file name, or a file-like
           object representing an already opened ATS data file, or
           a maury_ats_parser object that has already been used to
           parse an ATS data file.
        """
        if isinstance(filename,maury_ats_parser):
            self.__atsfile = filename
        else:
            self.__atsfile = maury_ats_parser(filename)
            
        if auto_summarize:
            self.summarize()
        
    def set_condition( self, column=None, condition=None, value=None ):
        """Set the summarizing condition and resummarize the data.
        
        Parameters:
        column - a string representing the column name to use for computation of
           the summary condition and the optimimal data block.
        condition - a string describing the condition at which to summarize.
           The supported summary conditions are listed below.
        value - (optional) a floating-point value that is used by certain
           summary conditions to specify the value of the condition.
           
        Summary conditions:
        min - compute the data set using the minimum value of the 'column'
           parameter. The 'column' 
        max - compute the data set using the maximum value of the 'column'
           parameter
        at - compute the data set at the specified value of the 'column'
           parameter.  NOTE: for this case the best_block/best_index properties
           will not be computed in multi-block data sets since the computation
           will result in the values for the 'column' in each data block being
           exactly equal.
        comp_gt - compute the data set using the specified value of the
           compression relative to the 'Gt_dB' column.  NOTE: for this case
           the 'column' parameter is only used for computation of the
           best_block/best_index properties.
        comp_gp - compute the data set using the specified value of the
           compression relative to the 'Gp_dB' column.  NOTE: for this case
           the 'column' parameter is only used for computation of the
           best_block/best_index properties.
        at_pin - compute the data set using the specified value of
           'Pin_avail_dBm' column. NOTE: for this case the 'column' parameter
           is only used for computation of the best_block/best_index
           properties.
        at_pout - compute the data set using the specified value of
           'Pout_dBm' column. NOTE: for this case the 'column' parameter
           is only used for computation of the best_block/best_index
           properties.
        """
        
        # set some defaults
        col,cond,val = self.__condition
        
        # check that the column name is legal
        if column is not None:
            col = translate_col(column)
        
        # check the condition
        if condition is not None:
            if condition not in ('min','max','at','comp_gt','comp_gp','at_pin','at_pout'):
                raise ValueError("The condition '%s' is not valid"%condition)
            cond = condition
        
        # check the value
        if value is not None:
            try:
                val = float(value)
            except ValueError:
                raise ValueError("The specified value is not a real number.")
        
        # store the new condition
        self.__condition = (col,cond,val)
        
        # resummarize the data
        if self.__atsfile:
            self.summarize()
    
    def summarize(self, **kwargs):
        """Summarize the data set
        
        Find the block of data that maximizes (or minimizes)
        the summary condition column.
        
        This step is only meaningful for sweep plan data files
        that contain multiple data blocks. For simple sweep
        data files, the one (and only) block of summary data
        will be returned.
        """
        if len(kwargs):
            # use keywords to set up the summary condition
            # this operation also does the summary
            # so there is no need to run the rest of the function 
            self.set_condition(**kwargs)
            return
        
        self.__summary = None
        self.__bestblock = -1
        
        if self.__atsfile is None:
            raise RuntimeError("No file has been read yet.")
        elif not len(self.__atsfile):
            raise ValueError("'%s' - no data." % self.__atsfile.filename)
        
        # special case for single-sweep data
        if len(self.__atsfile) == 1:
            self.__summary = [self._block_summary(self.__atsfile.data[0].copy())]
            self.__bestblock = 0
            return
        
        ### start multi-sweep data analysis ###
        self.__summary = []
        col,cond,_ = self.__condition
        if col not in self.__atsfile[0]:
            raise ValueError("'%s' is not a valid column for this data set."%col)
        m,t = None,-1
        for i,d in enumerate(self.__atsfile):
            s = self._block_summary(d.copy())
            self.__summary.append(s)
            if s is not None:
                if m is None:
                    # this is the first block that has a valid summary result
                    m = s[col]
                    t = i
                else:
                    # need to compare this block against the previous best block
                    v = s[col]
                    if self.__findmin and v < m:
                        m,t = v,i
                    elif not self.__findmin and v > m:
                        m,t = v,i
        self.__bestblock = t
        
    def _block_summary(self, data):
        """Summarize a single block of data."""
        # summarize this data
        ret = { 'gamma_src':data['gamma_src'], 'gamma_ld':data['gamma_ld'] }
        del data['gamma_src']
        del data['gamma_ld']
        for c,d in data.iteritems():
            if not isinstance(d,list): ret[c] = d
        summary = self._process_condition(data)
        if summary is None:
            return None
        ret.update(summary)
        return ret
        
    def _process_condition(self, data):
        """Process the summary condition, called by _block_summary()"""
        col,cond,val = self.__condition
        
        if col not in data:
            raise ValueError("Summarizing column '%s' does not exist in the data set."%col)
        elif col in ("gamma_src","gamma_ld") or not isinstance(data[col],list):
            raise ValueError("Fixed data column '%s' cannot be used as a summary column."%col)
            
        usecol = col
        usecomp = False
        if cond == 'at_pin':
            usecol = 'Pin_avail_dBm'
        elif cond == 'at_pout':
            usecol = 'Pout_dBm'
        elif cond == 'comp_gt':
            usecol,usecomp = "Gt_dB",True
        elif cond == 'comp_gp':
            usecol,usecomp = "Gp_dB",True
        elif cond == 'min':
            val = min(data[usecol])
        elif cond == 'max':
            val = max(data[usecol])
        elif cond == 'at': 
            pass
        else:
            raise ValueError("'%s' is not a valid summarizing condition." % cond)
        
        # compute the values of all non-fixed columns in the data block
        # at the summary condition
        try:
            if usecomp:
                return _interp(data, _find_compression(data[usecol],float(val)))
            else:
                return _interp(data, _find_point(data[usecol],float(val)))
        except KeyError:
            raise ValueError("The '%s' summary condition requires that the '%s' column exists in the data set."%(cond,usecol))
        except ValueError:
            raise ValueError("The '%s' summary condition requires a valid floating point value."%cond)
        
    def print_summary(self):
        """Print a text summary of the data set."""
        print self
        
    def __str__(self):
        """Stringify the data for pretty printing."""
        def _print_gamma( g ):
            m = abs(g[0])
            a = math.atan2(g[0].imag,g[0].real) * 180. / math.pi
            mastr = "(%5.3f <%6.1f)" % (m, a)
            s = "%-20s %-20s" % (g[0],mastr)
            return s
            
        s = "=======================================================\nFile: %s\nFreq: %.3f GHz\n" % (self.__atsfile.filename,self.__atsfile.frequency)
        s += "Summary Condition:\n  Column: %s\n  Criteria: %s\n" % (self.__condition[0],self.__condition[1])
        if self.__condition[1] not in ('min','max'):
            s += "  Value: %s\n" % self.__condition[2]
        if self.__findmin: s += "  Find: minimum over all sweeps\n"
        else: s += "  Find: maximum over all sweeps\n"
        if self.best_index > -1 and self.__condition[1] != 'at':
            s += "Best data block (per summary conditions):\n"
            s += "  Index: %d\n" % self.best_index
            for k in self.__printcols:
                v = self.best_block.get(k) 
                if v is not None:
                    s += "  %-15s = %s\n" % (k,v)
            s += "  Gamma:\n"
            s += "    %-11s = %s\n" % ("gamma_src",_print_gamma(self.__summary[self.best_index]["gamma_src"])) 
            s += "    %-11s = %s\n" % ("gamma_ld",_print_gamma(self.__summary[self.best_index]["gamma_ld"]))
        return s
            
            
    def _getfname(self):
        if not self.__atsfile:
            raise RuntimeError("A file has not been read yet.")
        return self.__atsfile.filename
    filename = property(_getfname)
    
    def _getsummary(self):
        if not self.__summary:
            raise RuntimeError("Summary has not been done yet.")
        return self.__summary
    summary = property(_getsummary)
    
    def _getatsfile(self):
        return self.__atsfile
    data = property(_getatsfile)
    
    def _getbestdata(self):
        if self.__bestblock < 0:
            raise RuntimeError("A valid 'best block' summary has not been done.")
        return self.__atsfile[self.__bestblock]
    best_data = property(_getbestdata)
    
    def _getbestblock(self):
        if self.__bestblock < 0:
            raise RuntimeError("A valid 'best block' summary has not been done.")
        return self.__summary[self.__bestblock]
    best_block = property(_getbestblock)
    
    def _getbestindex(self):
        if self.__bestblock < 0:
            raise RuntimeError("A valid 'best block' summary has not been done.")
        return self.__bestblock
    best_index = property(_getbestindex)
    
    def _getcondition(self):
        return self.__condition
    condition = property(_getcondition)
    
    
def _find_compression(gain, val, use_peak_gain=False):
    """Find a (probably floating-point) index of where val exists in
    the vector dat.
    """
    if use_peak_gain:
        mx = max(gain)
        search = mx - val
        f = False
    else:
        mx = gain[0]
        search = mx - val
        f = True
    for i,g in enumerate(gain):
        if not f and g >= mx - 0.001: f = True
        if f:
            if abs(g-search) < _compression_tol: return i
            elif i and g < search:
                fact = (search - gain[i-1]) / (g - gain[i-1])
                return (i - 1.0 + fact)
    return None

def _find_point(dat, val):
    """Find a (possibly floating-point) index of where val exists in
    the vector dat.
    """
    exact = None
    interp = None
    for i,v in enumerate(dat):
        if abs(v-val) < _numeric_tol:
            exact = i
        elif i and (dat[i-1] < val < v) or (dat[i-1] > val > v):
            fact = (val - dat[i-1]) / (v - dat[i-1])
            interp = (i - 1.0 + fact)
    if exact is not None:
        return exact
    elif interp is not None:
        return interp
    return None

def _interp(data, p):
    """Interpolate the load pull data set."""
    if p is None: return None
    ret = {}
    if isinstance(p,int):
        for k,v in data.iteritems():
            if isinstance(v,list):
                ret[k] = v[p]
    else:
        i = int(p)
        f = p - i
        for k,v in data.iteritems():
            if isinstance(v,list):
                ret[k] = v[i] + (v[i+1] - v[i]) * f
    return ret
        

