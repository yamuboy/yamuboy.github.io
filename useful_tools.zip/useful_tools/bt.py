import numpy as np
class node( object):
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
    
    def add(self, value):
        if self.value:
            if value < self.value:
                if self.left == None:
                    self.left = node(value)
                else:
                    self.left.add(value)
            else:
                if self.right == None:
                    self.right = node(value)
                else:
                    self.right.add(value)
        else:
            self.value = value

    def display_tree(self):
        if self.left:
            self.left.display_tree()
        print self.value 
        if self.right:
            self.right.display_tree()

    def contains(self, val):
        if val < self.value:
            if self.left is None:
                print "%d not found"%val
            return self.left.contains(val)
        elif val > self.value:
            if self.right is None:
                print "%d not found"%val
            return self.right.contains(val)
        else:
            print( str(self.value)+' is found')   

def fun(a):
    return a**2
    
def num_integrate(a,b,N):
    dx = (b - a)/float(N)
    I = 0
    for i in range(N):
        x = a + dx*i
        I += fun(x)*dx

    print I

def num_integrate_trap(a,b,N):
    dx = (b - a)/float(N)
    I = 0
    for i in range(N):
        if i == 0:
            x = a + dx
            I += fun(x)*dx
        if i > 0:
            x1 = a + dx*i
            x2 = a + dx*(i-1)
            I += ((fun(x1) + fun(x2))/2.0)*dx                     

    print I

# solving system of eqns
def solve(m,b):
    # solve eqns of the form mx = b
    # method one
    import numpy as np
    y = np.dot(np.linalg.inv(m),b)
    # method 2
    z = np.linalg.solve(m,b)
    return y,z

def knn( inX, dataset, labels, k):
    import operator
    # classify the input vector
    # get the number of rows
    dataSetSize = np.shape(dataset)[0]
    # create an input matrix of the same dims as the group, in this case 4X1
    diffMat = np.tile(inX, (dataSetSize,1)) - dataset
    # take the square of the matrix
    # basically calculating the Euclidean distance between [0,0] - the input
    # and each element of the group. d = sqrt( (xA - xB)**2 + (yA - yB)**2)
    sqdiffmat = diffMat**2
    sqdistances = sqdiffmat.sum(axis = 1)
    # take sqrt
    distances = sqdistances**0.5
    sortedIndices = distances.argsort()
    classCount = {}
    for i in range(k):
        votelabel = labels[sortedIndices[i]]
        classCount[votelabel] = classCount.get(votelabel,0) + 1
    sortedClassCount = sorted(classCount.iteritems(), key = operator.itemgetter(1), reverse = True )
    print classCount
    print sortedClassCount[0][0]

def id3_classifier(dataset, labels):
    # create a classifier based on ID3 method
    pass

def split_dataset(dataset, axis, value):
    retDataset = []
    for featVec in dataset:
        if featVec[axis] == value:
            reducedfeatvec = featVec[:axis]
            reducedfeatvec.extend(featVec[axis+1:])
            retDataset.append(reducedfeatvec)
    print retDataset 

def shannonent(dataset):
    from math import log
    numentries = len(dataset)
    labelcounts = {}
    for feat in dataset:
        currlabel = feat[-1]
        if currlabel not in labelcounts.keys():
            labelcounts[currlabel] = 0
        labelcounts[currlabel] += 1
    entropy = 0
    for key in labelcounts:
        prob = float(labelcounts[key])/numentries
        print prob
        entropy -= prob*log(prob,2)
    print entropy 
    

if __name__ == "__main__":
    '''
    group = np.array([[1,1],[1,1.1],[0,0],[0,0.1]])
    labels = ['A','A','B','B']
    
    inX = [1,0.5]
    knn( inX, group, labels, 3)
    '''
    dataset = [[1,1,'yes'],[1,1,'yes'],[1,0,'no'],[0,1,'no'],[0,1,'no']]
    labels = ['no surfacing', 'flippers']
    split_dataset(dataset, 0, 1)
    shannonent(dataset)





                