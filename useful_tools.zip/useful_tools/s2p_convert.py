#!/usr/bin/env python
from network_params import Touchstone
from optparse import OptionParser
import sys
import glob,os

def main(inname, outname, use_s22=False):
    "entry point"
    i = Touchstone(inname)
    if i.nports != 2:
        raise ValueError("'%s' is not a 2-port data file"%inname)
    
    o = i.copy_truncated()
    for p in i:
        if use_s22:
            d = p.data[1,1]
        else:
            d = p.data[0,0]
        o.insert(p.freq,d)
    
    o.write(outname)
    
if __name__ == "__main__":
    # Find all filenames with s2p extension
    print os.getcwd()
    files = []
    for file in glob.glob("*.s2p"):
        o_name = file.split('.')[0]+'.s1p'
        main(inname = file, outname = o_name)
        
    
