"""
Implement the multilayer perceptron algorithm for black box modeling techniques
The training set is s-parameter data
The values that will be optimized are the intrinsic parameters.
This is a supervised learning problem. The algorithm learns from previous examples. The dataset we learn from
has the correct output values for each data point. 
"""
import numpy as np

# Simple or neural net simulation
def net_train(inputs,training_set):
    max_iterations = 25
    iter_count = 0
    learning_factor = 0.25
    weights = np.array([-0.05,0.02,0.02])
    print np.shape(weights), np.shape(inputs)
    while True:
        if iter_count >= max_iterations:
            break
        # calculate the output
        try:
            activations = np.dot(inputs,weights)
            activations = np.where(activations>0,1,0)
            if np.array_equal(activations,training_set):
                print weights,activations
                break
            else:
                weights += learning_factor*np.dot(np.transpose(inputs),training_set-activations)                                
        except ValueError:
            print "Matrix Dimensions must match"
            break
        iter_count+=1
        
if __name__ == "__main__":
    inputs = np.array([[-1,0,0],[-1,0,1],[-1,1,0],[-1,1,1]])
    training_set = np.array([0,1,1,1])
    net_train(inputs,training_set)
    
    