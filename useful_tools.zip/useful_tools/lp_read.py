from loadpull import ats_parser
from matplotlib import pyplot as pp
from macomplot.smithplot import SmithAxes

def file_read( fname ):
    obj = ats_parser.MaurySplFile( fname )
    load_impedances = []
    for i in range(len(obj)):
        load_impedances.append(obj.flat_data[i].gamma_ld[0])

    return load_impedances

def plot_gammas( data ):
    for d in data:
        pp.plot(d, datatype = SmithAxes.S_PARAMETER)
        pp.title("Load Gammas")

    pp.show()    

def main():
    fname = "dev1_run2_28V.spl"
    data = file_read( fname )
    plot_gammas( data )

if __name__ == "__main__":

    main()

