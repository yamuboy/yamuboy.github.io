import network_params as np
import numpy as n
import os
from modeling.mct_files import split_file

def s2p_to_s1p(inname, outname, use_s22 = False):
    "entry point"
    i = np.Touchstone(inname)
    if i.nports != 2:
        raise ValueError("'%s' is not a 2-port data file"%inname)
    
    o = i.copy_truncated()
    for p in i:
        if use_s22:
            d = p.data[1,1]
        else:
            d = p.data[0,0]
        o.insert(p.freq,d)
    
    o.write(outname)

def split_file_new( fname):
    # split the biased Toushtone by bias
    split_file(fname)


def read_sparams(dir_name, extraction_freq):
    fnames = os.listdir(dir_name)
    spar_fnames = []
    for f in fnames:
        if f.split('.')[1] == 's2p':
            spar_fnames.append(f)

    data = []
    # convert to y-params, extract data for a freq point and store in a container 
    # container is a tuple of fname and data
    for f in spar_fnames:
        
        d = np.BiasedTouchstone(os.path.join(dir_name, f))
        data_y = d.extract_and_convert( freq = extraction_freq, convert_to = 'y')
        tmp = f.split('_')
        #dev_name = tmp[0]
        dev_name = f
        #device_periphery = int(tmp[1].split('x')[0])*int(tmp[1].split('x')[1])/1000.0
        device_periphery = 0.6
        d1 = {}
        d1['dev_name'] = dev_name
        d1['periphery'] = device_periphery
        d1['data'] = data_y
        d1['extract_f'] = extraction_freq
        d1['v1'] = d.v1
        d1['v2'] = d.v2
        d1['i1'] = d.i1
        d1['i2'] = d.i2
        data.append(d1)

    return data


def write_ss_data(data, fname):
    f = open(fname, 'w')
    f.write('Extracted Small Signal Params\n')
    f.write('Wafer : \n')
    f.write('Dev_name\tPeriphery(mm)\tv1(V)\tv2(V)\tI1(A)\tI2(A)\tFrequency(Hz)\tCgs(pF\mm)\tCgd(pF\mm)\tCds(pF\mm)\tgm(mS\mm)\tgds(mS\mm)\tFt(GHz)\n')
    
    for d in data:
        for h in ['dev_name', 'periphery', 'v1', 'v2', 'i1', 'i2', 'frequency', 'cgs_pfmm', 'cgd_pfmm', 'cds_pfmm', 'gm','gds', 'ft']:
            if h == 'dev_name':
                f.write('%s\t'%d[h])
            else:
                f.write('%0.4f\t'%d[h])                
        f.write('\n')

    f.close()

def extract_ss_params_allfreqs(fname):
    # extracts the small signal parameters for a single file at all frequencies
    d = np.BiasedTouchstone(fname)
    # convert to y_params
    data_y = d.extract_and_convert( convert_to = 'y')
    outfile = raw_input("Enter the name of the output file: ")
    periphery = float(raw_input("Enter the device periphery in mm: "))
    f = open(outfile, 'w')
    f.write('Small Signal Device Parameters\n')
    f.write('Filename: %s\n'%d.filename)
    f.write('V1: %f(V) V2: %f(V) I1: %f(A) I2: %f(A)\n'%(d.v1, d.v2, d.i1, d.i2))
    f.write('Frequency(Hz)\tCgs(pF\mm)\tCgd(pF\mm)\tCds(pF\mm)\tgm(mS\mm)\tgds(mS\mm)\tFt(GHz)\n')
    for item in data_y:
                
        real_y11 = n.real(item.matrix[0,0])
        imag_y11 = n.imag(item.matrix[0,0])
        real_y21 = n.real(item.matrix[1,0])
        imag_y21 = n.imag(item.matrix[1,0])
        real_y12 = n.real(item.matrix[0,1])
        imag_y12 = n.imag(item.matrix[0,1])
        real_y22 = n.real(item.matrix[1,1])
        imag_y22 = n.imag(item.matrix[1,1])    

        
        # extract cgs in pF/mm
        cgs_pfmm = 1e12*(imag_y11 + imag_y12)/(2*n.pi*item.freq*periphery)

        # extract cgd in pF/mm
        cgd_pfmm = -1e12*(imag_y12)/(2*n.pi*item.freq*periphery)

        # extract cds in pF/mm
        cds_pfmm = 1e12*(imag_y22 + imag_y12)/(2*n.pi*item.freq*periphery)

        # extract gm in mS/mm
        gm = 1000*(real_y21 - real_y12)/periphery

        # extract gds in mS/mm
        gds = 1000*(real_y22 + real_y12)/periphery

        # extract ft
        ft = gm/(2*n.pi*cgs_pfmm)

        f.write('%0.3e\t%0.4f\t%0.4f\t%0.4f\t%0.4f\t%0.4f\t%0.4f\n'%(item.freq,cgs_pfmm,cgd_pfmm,cds_pfmm,gm,gds,ft))

    f.close()
            

def extract_ss_params(data):
    
    updated_data = []

    for d in data:

        ss_params = {}  

        device_periphery = d['periphery']
        extract_f = d['extract_f']  

        # now extract the SS params
        real_y11 = n.real(d['data'].matrix[0,0])
        imag_y11 = n.imag(d['data'].matrix[0,0])
        real_y21 = n.real(d['data'].matrix[1,0])
        imag_y21 = n.imag(d['data'].matrix[1,0])
        real_y12 = n.real(d['data'].matrix[0,1])
        imag_y12 = n.imag(d['data'].matrix[0,1])
        real_y22 = n.real(d['data'].matrix[1,1])
        imag_y22 = n.imag(d['data'].matrix[1,1])    

        # extract cgs in pF/mm
        ss_params['cgs_pfmm'] = 1e12*(imag_y11 + imag_y12)/(2*n.pi*extract_f*device_periphery)

        # extract cgd in pF/mm
        ss_params['cgd_pfmm'] = -1e12*(imag_y12)/(2*n.pi*extract_f*device_periphery)

        # extract cds in pF/mm
        ss_params['cds_pfmm'] = 1e12*(imag_y22 + imag_y12)/(2*n.pi*extract_f*device_periphery)

        # extract gm in mS/mm
        ss_params['gm'] = 1000*(real_y21 - real_y12)/device_periphery

        # extract gds in mS/mm
        ss_params['gds'] = 1000*(real_y22 + real_y12)/device_periphery

        # extract ft
        ss_params['ft'] = ss_params['gm']/(2*n.pi*ss_params['cgs_pfmm'])

        # calculate K-factor
        #k_fact = 2*real_y11*real_y22 - (real_y12*real_y21 - imag_y12*imag_y21)/(n.sqrt(real_y12**2+imag_y12**2)*n.sqrt(real_y21**2+imag_y21**2))
        ss_params['v1'] = d['v1']
        ss_params['v2'] = d['v2']
        ss_params['i1'] = d['i1']
        ss_params['i2'] = d['i2']
        ss_params['dev_name'] = d['dev_name']
        ss_params['periphery'] = device_periphery
        ss_params['frequency'] = d['extract_f']

        updated_data.append(ss_params)

    
    return updated_data  
        

if __name__ == "__main__":

    dir_name = raw_input("Enter the data directory: ")
    extract_f = float(raw_input("Model Extraction Frequency: "))
    outfile = raw_input("Output File: ")
    
    cwd = os.getcwd()
    
    data = read_sparams(os.path.join(cwd, dir_name), extract_f)
    extracted_data = extract_ss_params(data)
    write_ss_data(extracted_data, outfile) 