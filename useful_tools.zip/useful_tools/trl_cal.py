import network_params as net_params
import numpy as np

def trl_cal(s_thru, s_line, s_reflect, REFLECT_STD):
    
    thru = net_params.Touchstone(s_thru)
    line = net_params.Touchstone(s_line)

def open_short(s_open, s_short):

    pass



    

