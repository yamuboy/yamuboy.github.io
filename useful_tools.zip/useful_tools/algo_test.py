import functools

# classic singleton
# 
class singleton(object):
    def __new__(self):
        if not hasattr(self, 'instance'):
            self.instance = super(singleton, self).__new__(self)
        return self.instance

# borg pattern - objects share the same state
class borg(object):

    _shared_dict = {}
    def __new__(self, *args, **kwargs):
        obj = super(borg, self).__new__(self, *args, **kwargs)
        obj.__dict__ = self._shared_dict
        return obj

def sorted_linear_search( l_to_search, item):
    l_to_search.sort()
    loop_counter = 0
    for i in range(len(l_to_search)):
        if l_to_search[i] == item:
            return True
        else:
            loop_counter += 1

    print loop_counter    
    return False

def bin_search( l_to_search, item ):
    l_to_search.sort()
    print l_to_search
    loop_counter = 0 
    low = 0
    high = len(l_to_search)-1
    while low < high:
        mid = (low+high)//2
        if l_to_search[mid] == item:
            return True, loop_counter
        elif item > l_to_search[mid]:
            low = mid + 1
        elif item < l_to_search[mid]:
            high = mid - 1
        loop_counter += 1 
           
    return False, loop_counter

def bubble_sort( l_to_sort ):
    n = len( l_to_sort )
    print "Initial List", l_to_sort
    for i in range(n-1,0,-1):
        for j in range(i):
            if l_to_sort[j] > l_to_sort[j+1]:
                # swap values
                l_to_sort[j+1], l_to_sort[j] = l_to_sort[j], l_to_sort[j+1]
            print l_to_sort

    print "final list", l_to_sort

def generate_sample( list_len ):
    import random
    return random.sample( range(100), 100)

def generate_sample_2( list_len ):
    import random
    l = []
    for i in range(list_len):
        l.append(random.randint(0,101))
    return l

def selection_sort( l_to_sort ):
    l = len(l_to_sort)
    for i in range(l-1):
        smallidx = i
        for j in range(i+1,l):
            if (l_to_sort[j] <  l_to_sort[smallidx]):
                smallidx = j
        if smallidx != i:
            l_to_sort[smallidx],l_to_sort[i] = l_to_sort[i], l_to_sort[smallidx]

    print l_to_sort

def switch_dict(operator, x,y ):
    return {
        'add':lambda: x+y,
        'subtract':lambda:x-y,
        'mult':lambda:x*y
    }.get(operator, lambda:None)()

import functools
def my_decorator( func ):
    @functools.wraps( func)
    def wrapper():
        print "Yes"
        func()
    return wrapper

@my_decorator
def test():
    print "Hello"

# general decorator template
# generally used to selectively execute a function by wrapping it 
def decorator(func):
    @functools.wraps(func)
    def wrapper_decorator(*args, **kwargs):
        # Do something before
        value = func(*args, **kwargs)
        # Do something after
        return value
    return wrapper_decorator

# Decorator that keeps track of state
def count_calls( func ):
    @functools.wraps( func )
    def wrapper( *args, **kwargs ):
        wrapper.num_calls += 1
        print "Call %d of %s"%(wrapper.num_calls, func.__name__)
        return func( *args, **kwargs )
    wrapper.num_calls = 0
    return wrapper

@count_calls
def test1():
    print "Hello"


if __name__ == "__main__":
    test1()
    
        

