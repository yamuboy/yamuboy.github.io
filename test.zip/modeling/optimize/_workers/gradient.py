from __future__ import unicode_literals, absolute_import, division, print_function
from .. import register, Worker, OptimizableParam, StopOptimization
import logging
from ... import ConfigData

## add configuration parameters for the workers defined here
_cfg = ConfigData(search_path=('optimize',))
_cfg.add('gradient_ss_frac',0.1,float,help="gradient starting step size as a fraction of the parameter range")
_cfg.add('gradient_grad_frac',0.002,float,help="gradient computation delta as a fraction of the parameter range")
_cfg.add('gradient_ss_reduce_frac',0.2,float,help="gradient step size reduction factor for each iteration of the reduction loop")
_cfg.add('gradient_reduce_maxsteps',8,int,help="the maximum number of iterations of the step size reduction loop")
_cfg.add('gradient_search_maxsteps',5,int,help="the maximum number of iterations of the local minima search loop")
_cfg.add('gradient_internal_iterations',6,int,help="the maximum number of internal iterations of the simultaneous gradient search loop before gradients are discarded")
_cfg.add('gradient_reuse_frac',0.1,float,help="the fraction of the previous gradient vector that is 're-used' in the current iteration of the internal simultaneous gradient search loop")

class GradientWorker(Worker):
    """
    The GradientWorker is a optimization worker class that optimizes parameters
    by working with them one at a time.  Each parameter in its list of parameters
    is individually optimized.
    
    This type of optimization generally performs very poorly in highly non-linear
    problem spaces or when there are abundant local minima in the problem space.
    Tuning the step size parameters can improve the performance of this Worker
    when these conditions exist at the cost of increased optimization time.
    
    If a set of parameters is already very close to the ideal solution in a
    problem space, then this Worker is possibly the best one to use UNLESS there
    are lots of local minima surrounding the ideal solution.
    
    This can be a very good Worker to use to "finalize" an optimization once
    some other Worker has gotten the solution very close to the ideal value.
    """
    
    def __init__(self, cb, params, **kwargs):
        """
        Arguments:
        cb - a callable object (function) that will return a computed
           optimization error.  The object will be called with no arguments.
           The optimization error that is computed by the object must be tied
           to the values of the parameters that are being optimized, otherwise
           optimization will be impossible.
        params - an iterable (list or tuple) containing OptimizableParam objects
           These are the parameters to optimize.
        """
        # init the parent
        Worker.__init__(self, cb, params)
        
        # create a log target
        self._log = logging.getLogger('modeling.optimize.GradientWorker')
        
        # no value for optimization error yet
        self._eval = None
        
        # set default values for tunable optimization parameters
        self.__tune = { 'ss_frac':0.1, 'grad_frac':0.002, 'ss_reduce_frac':0.2,
            'reduce_maxsteps':8, 'search_maxsteps':5 }
        
        self._cfgdata_prefix = 'gradient_'
        self._cfgdata_vars = ('ss_frac', 'grad_frac', 'ss_reduce_frac', 'reduce_maxsteps', 'search_maxsteps')
        
        # pass keywords to config
        self.config(**kwargs)
    __init__.__doc__ = __doc__ + __init__.__doc__
        
    def config(self, **kwargs):
        """
        
        Keywords:
        ss_frac - float, a positive number less than 1.0 that defines how big the
           initial step size will be as a fraction of the optimization range
           for each parameter
        grad_frac - float, a positive number much less than 1.0 that defines the
           delta value that is used to compute the gradient as a fraction of the
           optimization range for each parameter.
        ss_reduce_frac - float, a positive number less than 1.0 that is
           multiplied by the current step size to reduce the step size when
           required by the optimization search function.
        reduce_maxsteps - int, a positive number that defines the maximum number
           of reductions in the step size that are allowed.
        search_maxsteps - int, a positive number that defines the number of steps
           that are allowed during the search for the optimimum parameter value.
        """
        
        # process keywords
        for p in ('ss_frac','grad_frac','ss_reduce_frac'):
            if p in kwargs:
                x = float(kwargs[p])
                if x <= 0.0 or x >= 1.0:
                    raise ValueError("'%s' must be between 0.0 and 1.0"%p)
                self.__tune[p] = x
        for p in ('reduce_maxsteps','search_maxsteps'):
            if p in kwargs:
                x = int(kwargs[p])
                if x < 1:
                    raise ValueError("'%s' must be greater than 0"%p)
                self.__tune[p] = x
    __init__.__doc__ += config.__doc__
        
    def _geterr(self):
        "Get the current value of the optimization error."
        return self._eval
    error = property(_geterr)
        
    def _iter(self, current_error=None):
        """Perform a single gradient optimization iteration.
        
        current_error is the current value of the "error function"
          if omitted than an initial call to the function is needed
          in order to determine it
        """
        
        if current_error is None:
            # Need to do an initial call to the determine the current
            # value of the error
            current_error = self._cb()
            
        ### loop through the parameters and optimize each one ###
        self._reduce_fail_ct = 0
        for p in self.params:
            try:
                current_error = self._opt_param(p,current_error)
            finally:
                # on all exceptions discard changes to the parameter
                p.optdiscard()
        
        # store the error value
        self._eval = current_error
        
        # check if this iteration failed
        if self._reduce_fail_ct >= len(self.params):
            raise StopOptimization
        
        return current_error
        
    def _opt_param(self, p, ein):
        """Internal method used to optimize a single parameter.
        p is the parameter object
        ein is the current value of the optimization error (a float)
        """
        
        self._log.debug( "%s: value = %.4e" % (p.name,p.v))
        
        # save the original parameter value
        orig = p.v
        
        # choose a step size by taking a fraction of the parameter optimization range
        r = p.optrange
        ss = self.__tune['ss_frac'] * r
        
        # compute the gradient by twiddling the parameter by some fraction of
        # the optimization range
        delta = self.__tune['grad_frac'] * r
        if not p.optadd(delta):
            # unable to add delta to the parameter
            # must be near the top rail
            # subtract delta instead
            delta = -delta
            if not p.optadd(delta):
                # couldn't subtract delta either
                # can't optimize this parameter
                self._log.debug("'%s': gradient calculation failed." % p.name)
                self._reduce_fail_ct += 1
                return ein
        e1 = self._cb()
        if ein == e1:
            self._log.debug("'%s': gradient is 0." % p.name)
            self._reduce_fail_ct += 1
            return ein
        g = ein - e1
        if delta < 0.0: g = -g
        self._log.debug( "%s: gradient = %.4e" % (p.name,g))
        p.optdiscard()
        
        # try to step in the direction that should reduce the error
        # if the error increases then reduce the step size until it decreases
        if g < 0.0: ss = -ss
        for i in range(self.__tune['reduce_maxsteps']):
            self._log.debug( "%s: ss = %.4e" % (p.name,ss))
            if p.optadd(ss):
                e1 = self._cb()
                if e1 < ein:
                    # succeeded in reducing the error
                    break
                p.optdiscard()
            # reduce the step size
            ss *= self.__tune['ss_reduce_frac']
        
        if e1 >= ein:
            # step size reduction loop failed, this is odd since it should not have
            p.optdiscard()
            self._reduce_fail_ct += 1
            self._log.debug("'%s': step size reduction failed." % p.name)
            self._log.debug("'%s': step size was %.5e when the reduction loop exited." % (p.name,ss))
            return ein
            
        # the reduction succeeded, start stepping to find the minimum
        e0 = ein
        e2 = None
        for i in range(self.__tune['search_maxsteps']):
            # take another step in the direction that should minimize the error
            if not p.optadd(ss):
                # could not take another step
                break
            if e2 is not None:
                e0 = e1
                e1 = e2
            e2 = self._cb()
            if e2 > e1:
                # error increased, break out of the loop
                break
            
        # try to find an optimal parameter value
        if e2 is None:
            # we only have a single successful reduction, use that value
            p.optsave()
            eret = e1
        elif e2 > e1:
            # ideal value is bounded between e0 and e2
            # try to fit it using a quadratic fit
            x2 = p.v
            
            xc = _quad_fit(e0,e1,e2)
            if xc >= 0.0 and xc <= 2.0:
                p.optadd((xc-2.0)*ss)
                ec = self._cb()
                if ec <= e1:
                    p.optsave()
                    eret = ec
                else:
                    self._log.debug("'%s': quadratic fit computed a result that worsened the error." % p.name)
                    p.setv(x2-ss)
                    p.optsave()
                    eret = e1
            else:
                self._log.debug("'%s': quadratic fit computed an invalid result." % p.name)
                p.setv(x2-ss)
                p.optsave()
                eret = e1
        else:
            # e2 is less than e1, use the value at e2
            # which happens to be the current value of the parameter
            p.optsave()
            eret = e2
            
        # compute some statistics
        
        
        return eret

class SimultGradientWorker(Worker):
    """
    The SimultGradientWorker is a optimization worker class that optimizes
    a set of parameters by working with them all at once. It uses a composite
    gradient to move along a vector in an N-dimensional problem space
    (where N is equal to the number of parameters being optimized) to find the
    ideal solution.
    
    This type of optimization generally performs a little better than that
    of the GradientWorker in highly non-linear problem spaces or when there are
    wide local minima in the problem space.  This is due to the use of the
    composite search vector and the re-use of previous search vectors in
    adjacent searches.  All of this behavior can be tuned for a given problem
    space.
    
    The _iter() method of this Worker actually performs multiple internal
    iterations with each call, this is tuned with the 'internal_iterations'
    keyword which defaults to 6.  This behavior is so that the reuse of previous
    search vectors can be taken advantage of, since by convention each call to
    _iter() must be considered an independent event (there can be no re-use of
    data across multiple calls to _iter()).
    
    This Worker is not very good at optimizing parameters that have sensitivies
    (gradients) that are more than an order of magnitude smaller than other
    parameters in the problem space.  These less sensitive parameters do not
    tend to move at all when optimized simultaneously with a highly sensitive
    parameter since highly sensisitive parameter(s) will dominate the
    direction of the search vector.
    
    This Worker is significantly slower at finding an ideal solution than the
    GradientWorker when the set of parameters is already very close to the ideal
    solution.  But it will perform better when lots of local minima exist in
    the area surrounding the ideal solution.  This worker is also usually a
    better choice than the GradientWorker when the problem space is highly
    non-linear.
    
    This worker may still have problems in highly non-linear problem spaces and
    in those cases a non-linear worker might be a better choice. A worker that
    is based on Newton's method or a quasi-Newton method would be
    better in a very non-linear problem space (gradient workers are based on
    constrained, linearized versions of these more complex techniques).
    """
    
    def __init__(self, cb, params, **kwargs):
        """
        Arguments:
        cb - a callable object (function) that will return a computed
           optimization error.  The object will be called with no arguments.
           The optimization error that is computed by the object must be tied
           to the values of the parameters that are being optimized, otherwise
           optimization will be impossible.
        params - an iterable (list or tuple) containing OptimizableParam objects
           These are the parameters to optimize.
        """
        # init the parent object
        Worker.__init__(self, cb, params)
        
        # create a log target
        self._log = logging.getLogger('modeling.optimize.SimultGradientWorker')
        
        # no value for optimization error yet
        self._eval = None
        
        # set default values for tunable optimization parameters
        self.__tune = { 'ss_frac':0.1, 'grad_frac':0.002, 'ss_reduce_frac':0.3,
            'reduce_maxsteps':8, 'search_maxsteps':5, 'internal_iterations':6,
            'reuse_frac':0.1, }

        self._cfgdata_prefix = 'gradient_'
        self._cfgdata_vars = ('ss_frac', 'grad_frac', 'ss_reduce_frac', 'reduce_maxsteps', 'search_maxsteps',
            'internal_iterations', 'reuse_frac')
            
        # pass keywords to config
        self.config(**kwargs)
    __init__.__doc__ = __doc__ + __init__.__doc__
    
    def config(self, **kwargs):
        """
        
        Keywords:
        ss_frac - float, a positive number less than 1.0 that defines how big the
           initial step size will be as a fraction of the optimization range
           for each parameter
        grad_frac - float, a positive number much less than 1.0 that defines the
           delta value that is used to compute the gradient as a fraction of the
           optimization range for each parameter.
        ss_reduce_frac - float, a positive number less than 1.0 that is
           multiplied by the current step size to reduce the step size when
           required by the optimization search function.
        reduce_maxsteps - int, a positive number that defines the maximum number
           of reductions in the step size that are allowed.
        search_maxsteps - int, a positive number that defines the number of steps
           that are allowed during the search for the optimimum parameter value.
        internal_iterations - int, a positive number indicating the maximum number
           of internal iterations that will be performed during each iteration of
           the optimization loop; internal interations are needed in order to take
           advantage of gradient re-use from one iteration to the next.
        reuse_frac - float, a positive number less than 1.0 that defines how much
           of the previous gradient vector is used in the calculation of a composite
           vector for the interation; the calculation of the composite gradient
           vector is defined as 'composite = previous*reuse_frac + current'
        """
        # process keywords
        for p in ('ss_frac','grad_frac','ss_reduce_frac','reuse_frac'):
            if p in kwargs:
                x = float(kwargs[p])
                if x <= 0.0 or x >= 1.0:
                    raise ValueError("'%s' must be between 0.0 and 1.0"%p)
                self.__tune[p] = x
        for p in ('reduce_maxsteps','search_maxsteps','internal_iterations'):
            if p in kwargs:
                x = int(kwargs[p])
                if x < 1:
                    raise ValueError("'%s' must be greater than 0"%p)
                self.__tune[p] = x
    __init__.__doc__ += config.__doc__
    
    
    def _geterr(self):
        "Get the current optimization error."
        return self._eval
    error = property(_geterr)
        
        
    def _iter(self, current_error=None):
        """Perform a single gradient optimization iteration.
                
        current_error is the current value of the optimization "error function"
          if omitted than an initial call to the function is needed
          in order to determine it
        """
        
        if current_error is None:
            # Need to do an initial call to the determine the current
            # value of the error
            current_error = self._cb()
            
        ### loop through the parameters and optimize each one ###
        prev = None
        for i in range(self.__tune['internal_iterations']):
            self._log.debug("-- internal iteration # %d --" % (i+1))
            try:
                vect = self._compute_vect(prev,current_error)
                new_error = self._one_iter(vect,current_error)
                prev = vect
            except Exception as e:
                # on all exceptions discard changes to all parameters
                for p in self.params:
                    p.optdiscard()
                self._log.exception("exception in internal iteration")
                raise StopOptimization()
            
            if i > 1 and new_error == current_error:
                break
                
            current_error = new_error
                
            
        
        # store the error value and return it
        self._eval = current_error
        return current_error
        
        
    def _compute_vect(self, last_vect, ein):
        """Compute the search vector.
        last_vect is the previous value of the search vector, either None
           or a list of floats
        ein is the current value of the optimization error (a float)
        """
        
        # compute the gradient for each parameter
        vect = []
        for p in self.params:
            # choose a delta by taking a fraction of the parameter optimization range
            delta = self.__tune['grad_frac'] * p.optrange
            v = p.v
            
            # compute the gradient by twiddling the parameter
            if not p.optadd(delta):
                # unable to add delta to the parameter
                # must be near the top rail
                # subtract delta instead
                delta = -delta
                if not p.optadd(delta):
                    # couldn't subtract delta either
                    # can't optimize this parameter
                    self._log.debug("'%s': gradient calculation failed." % p.name)
                    vect.append(0.0)
                    continue
            e1 = self._cb()
            p.setv(v)
            if ein == e1:
                self._log.debug("'%s': gradient is 0." % p.name)
                vect.append(0.0)
                continue
            vect.append((ein - e1) / delta)
        
        # if last_vect is not none, compute a composite vector by
        # adding a fraction of the previous vector to the current vector
        frac = self.__tune['reuse_frac']
        if last_vect is not None and frac > 0.0:
            assert len(vect) == len(last_vect)
            for i in range(len(vect)):
                vect[i] += frac*last_vect[i]
        
        return vect
        
    def _one_iter(self, vect, ein):
        """Run a single internal iteration.
        vect is the search vector, a list of gradients (floats)
        ein is the current optimization error (a float)
        """
        
        params = self.params
        
        # save the original parameter values
        orig = [p.v for p in params]
        
        # choose a step size by taking a fraction of the optimization range of
        # the parameter with the maximum absolute gradient value
        mx = 0.0
        i = 0
        for j,v in enumerate(vect):
            g = abs(v)
            if g > mx:
                i = j
                mx = g
        
        if mx == 0.0:
            self._log.info("All gradients are zero.")
            return ein
        
        r = params[i].optrange
        ss = self.__tune['ss_frac'] * r / mx
        
        # try to step in the direction that should reduce the error
        # if the error increases then reduce the step size until it decreases
        for i in range(self.__tune['reduce_maxsteps']):
            for j,p in enumerate(params):
                p.optadd(ss*vect[j])
            e1 = self._cb()
            if e1 < ein:
                # succeeded in reducing the error
                break
            
            # did not succeed in reducing the optimization error
            # reduce the step size and try again
            for p in params:
                p.optdiscard()
            ss *= self.__tune['ss_reduce_frac']
        
        if e1 >= ein:
            # step size reduction loop failed, this can happen with the
            # simultaneous gradient method
            for p in params:
                p.optdiscard()
            self._log.debug("Step size reduction failed.")
            self._log.debug("Step size was %.5e when the reduction loop exited." % ss)
            return ein
            
        # the reduction succeeded, start stepping to find the minimum
        e0 = ein
        e2 = None
        for i in range(self.__tune['search_maxsteps']):
            # take another step in the direction that should minimize the error
            for j,p in enumerate(params):
                p.optadd(ss*vect[j])
            if e2 is not None:
                e0 = e1
                e1 = e2
            e2 = self._cb()
            if e2 > e1:
                # error increased, break out of the loop
                break
            
        # try to find an optimal parameter value
        if e2 is None:
            # we only have a single successful reduction, use that value
            for p in params:
                p.optsave()
            eret = e1
        elif e2 > e1:
            # ideal value is bounded between e0 and e2
            # try to fit it using a quadratic fit
            
            # save the current values of the parameters
            psave = [p.v for p in params]
            
            xc = _quad_fit(e0,e1,e2)
            self._log.debug("_quad_fit(%s) = %g"%((e0,e1,e2),xc))
            if xc >= 0.0 and xc <= 2.0:
                # the ideal solution is now bounded between 0 and 2
                # where 2 represents the current value of the parameters
                # and 0 represents the current value minus 2.0*ss*vect
                for p in params:
                    p.optadd((xc-2.0)*ss*vect[j])
                ec = self._cb()
                if ec <= e1:
                    p.optsave()
                    eret = ec
                else:
                    self._log.debug("The quadratic fit computed a result that worsened the error.")
                    for j,p in enumerate(params):
                        p.setv(psave[j]-ss*vect[j])
                        p.optsave()
                    eret = e1
            else:
                self._log.debug("The quadratic fit computed an invalid result.")
                for j,p in enumerate(params):
                    p.setv(psave[j]-ss*vect[j])
                    p.optsave()
                eret = e1
        else:
            # e2 is less than e1, use the value at e2
            # which happens to be the current value of the parameters
            for p in params:
                p.optsave()
            eret = e2
        
        # compute some statistics on the search
        
        
        
        return eret


def _quad_fit(y1, y2, y3):
    """determine the quadratic fit of 3 evenly spaced x values to a
    polynomial of the form y = a*(x-b)^2 + c and then find the
    x value corresponding to the local minima.
    
    The X values are mapped to the values 0, 1, and 2 for easy calculation of
    the quadratic.
    
    The return value should be bounded between 0 and 2.
    """
    return (0.75*y1 - y2 + 0.25*y3) / (0.5*y1 - y2 + 0.5*y3)
    
    
#### register the Worker classes defined in this module
register('gradient',GradientWorker)
register('grad',GradientWorker)
register('simultgradient',SimultGradientWorker)
register('simult_gradient',SimultGradientWorker)
register('simultgrad',SimultGradientWorker)
register('simult_grad',SimultGradientWorker)





    
    