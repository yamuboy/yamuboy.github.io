from __future__ import unicode_literals, absolute_import, division, print_function
import logging
from .worker import Worker
from .param import StopOptimization


class Engine(object):
    """This is the abstract base class for all optimization engines.
    
    
    """
    pass


class BasicEngine(Engine):
    """This is a really basic implementation of an optimization engine. This is
    pretty much just a wrapper around a Worker that keeps track of iterations
    and does some Exception handling.
    
    This engine only uses a single Worker.
    """
    
    
    def __init__(self, **kwargs):
        "initializer"
        
        # set some default values
        self.__worker = None
        self.__numiter = None
        self.__cb = self._dummycb
        self.__curerr = None
        
        # set up a logging target
        self._log = logging.getLogger('modeling.optimize.BasicEngine')
        
        # allow config to set up 
        self.config(**kwargs)
    
    def config(self, **kwargs):
        """
        
        Keywords:
        worker - a Worker-derived object that will be used as the optimization
           worker
        iter - integer, the number of iterations to perform
        itercb - a callable object that will be passed 2 arguments,
           the iteration number (an integer) and a tuple of calculated error
           values, one for each worker (in the case of the BasicEngine this will
           always be a 1-tuple since there is only a single worker).
        """
        if 'worker' in kwargs:
            x = kwargs['worker']
            if not isinstance(x,Worker):
                raise TypeError("'worker' must be an instance of a Worker-derived class.")
            self.__worker = x
            
        if 'iter' in kwargs:
            x = kwargs['iter']
            if x is not None:
                try:
                    self.__numiter = int(x)
                except TypeError:
                    raise TypeError("'iter' must be None or an integer value.")
            else:
                self.__numiter = None
            
        if 'itercb' in kwargs:
            x = kwargs['itercb']
            if not callable(x):
                raise TypeError("'itercb' must be a callable object.")
            self.__cb = x
        
    __init__.__doc__ += config.__doc__
        
        
    def optimize(self, **kwargs):
        """Start the optimization process.
        
        """
        self.config(**kwargs)
        
        # check that the current configuration is valid
        if not self.__worker:
            raise RuntimeError("No worker has been configured.")
        
        # save the current values of all parameters
        # and prepare them all for optimization
        psave = []
        for p in self.__worker.params:
            psave.append(p.v)
            p.optinit()
        
        # put a master exception wrapper around the iteration code
        # to catch any serious exceptions that are raised
        try:
            # compute the initial error
            try:
                self.__curerr = self.__worker._cb()
            except StopOptimization:
                # the very first call has raised an exception to halt optimization
                # call the iteration callback then exit
                self._log.warning("Optimization was halted prior to the first iteration.")
                try:
                    self.__cb(0,(self.__curerr,))
                except StopOptimization:
                    pass
                return
            
            try:
                self.__cb(0,(self.__curerr,))
            except StopOptimization:
                self._log.info("Optimization done.")
                return
                
            if self.__numiter is not None and self.__numiter == 0:
                # return before the first iteration
                self._log.info("Optimization done.")
                return
            
            num = 1
            while True:
                try:
                    # run an iteration of the optimization worker
                    self.__curerr = self.__worker._iter(self.__curerr)
                except StopOptimization:
                    # the worker has raised an exception to stop the loop
                    # call the iteration callback and then quit the loop
                    self._log.debug("Worker caused main loop to exit.")
                    try:
                        self.__cb(num,(self.__curerr,))
                    except StopOptimization:
                        pass
                    break
                
                # call the iteration callback
                try:
                    self.__cb(num,(self.__curerr,))
                except StopOptimization:
                    # iteration callback raised an exception to stop the loop
                    self._log.debug("Iteration callback caused main loop to exit.")
                    break
                
                # check to see if the number of iterations is finished
                if self.__numiter is not None and self.__numiter > 0 and num >= self.__numiter:
                    self._log.debug("Iterations complete.")
                    break
                
                num += 1
                
        except Exception as e:
            # try to roll back changes to parameter values
            # when a serious exception occurs
            for i,p in enumerate(self.__worker.params):
                p.setv(psave[i])
            # re-raise the exception
            self._log.exception(e)
            raise
            
        self._log.info("Optimization done.")
            
    optimize.__doc__ += config.__doc__
        
    def _dummycb(self, i, err):
        """A dummy iteration callback."""
        return
    
    def _geterr(self):
        return (self.__curerr,)
    error = property(_geterr)
    
    