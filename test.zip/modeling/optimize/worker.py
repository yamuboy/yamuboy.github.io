from __future__ import unicode_literals, absolute_import, division, print_function
from .param import OptimizableParam
import logging
from .. import ConfigData, _str_type

class Worker(object):
    """An optimization worker class that defines how to go about optimizing a
    problem.
    
    This is an abstract base class that defines the basic methods that must
    be supported by all Worker classes.
    """
    
    def __init__(self, cb, params):
        """Init the Worker.
        
        cb - a callable object that computes the optimization error. This callable
           is called with no arguments and must be somehow tied to the params
           that are passed (otherwise no optimization will occur).
        params - an iterable of OptimizableParam objects that are to be optimized
        """
        # init logging
        self._log = logging.getLogger('modeling.optimize.Worker')
        
        # check that the callback function is OK
        if not callable(cb):
            raise TypeError("The 'cb' argument must be a callable object.")
        self._cb = cb
        
        try:
            iter(params)
        except TypeError:
            raise TypeError("The 'params' argument must be an iterable.")
        
        # check for a valid set of parameters
        pl = []
        for p in params:
            if not isinstance(p,OptimizableParam):
                self._log.warning("'%s' is not an OptimizableParam instance"%p.name)
            elif not p.optimizable:
                self._log.debug("'%s' is not optimizable"%p.name)
            else:
                pl.append(p)
        
        if not len(pl):
            raise ValueError("no optimizable parameters are defined")
            
        self.__params = pl

        self._cfgdata_prefix = None
        self._cfgdata_vars = []
        
    
    def config(self, **kwargs):
        "configure the worker"
        pass
    
    def config_from_global(self):
        """Configure the worker from data stored in the global ConfigData object
        
        This is a hack to port the legacy configuration to a more namespace-aware
        configuration of the optimization workers.
        
        Each worker that chooses to use this capability must override the
        _cfgdata_prefix and _cfgdata_vars object properties.
        """
        if len(self._cfgdata_vars):
            cfg = ConfigData(search_path=('optimize',))
            kwargs = {}
            for k in self._cfgdata_vars:
                full = k
                if self._cfgdata_prefix:
                    full = self._cfgdata_prefix + k
                
                v = cfg.get(full)
                if v is not None:
                    kwargs[k] = v
            
            self.config(**kwargs)
    
    def _getparams(self):
        return self.__params
    params = property(_getparams)
    
    def _iter(self,current_error=None):
        """Run one iteration of the optimizer.
        
        This method must be implemented in child classes.
        """
        raise NotImplemented()
        
    def __notimpl(self):
        return None
        
    error = property(__notimpl,None,None,"optimization error from the last run of the _iter method")

_registry = dict()
def register(name, ty):
    """register a worker with the registry"""
    if not isinstance(name,_str_type):
        raise TypeError("'name' must be a string")
    if not issubclass(ty,Worker):
        raise TypeError("'ty' must be a type object subclassed from modeling.optimize.Worker")
    
    if name in _registry:
        raise ValueError("'%s' is already registered"%name)
    
    _registry[name] = ty
        
def get_worker(name):
    """get a worker type object by name"""
    return _registry[name]

def registered_workers():
    """get a list of all registered worker names"""
    return _registry.keys()
    
