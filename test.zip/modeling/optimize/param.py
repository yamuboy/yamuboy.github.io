from __future__ import unicode_literals, absolute_import, division, print_function
from ..modelparam import FloatParam

class StopOptimization(StopIteration):
    """A special exception class that can be raised in order to stop the
    main optimization loop.
    """
    pass


class OptimizableParam(FloatParam):
    """This class is the base class that defines an optimizable parameter. It
    can be used as is, or if customization is needed then it can be extended.
    
    It is important that, if extended, the methods defined here continue to
    operate in the same basic manner otherwise the optimization workers might
    get confused and have trouble optimizing problem spaces.
    """
    
    def __init__(self, name, val, optrange=None, **kwargs):
        """
        name is the parameter name, it must be a string
        val is the parameter value, it must be a float or something than can be
           converted to a float (an int or long)
        
        optrange sets the minimum and maximum bound for the optimization range.
        It is a 2-tuple of floats.  The min bound must be less than the max
        bound and the value of the parameter must fall within the bounded range
        in order for optimization to be possible.
        
        See the documentation for FloatParam for more keywords.
        """
        FloatParam.__init__(self, name, val, **kwargs)
        self._optmin = None
        self._optmax = None
        if optrange is not None:
            mn,mx = optrange
            self.set_opt_range(mn,mx)
        
    def optinit(self):
        """Prepare the parameter for optimization."""
        self.__optsave = self.v
        
    def optadd(self, inc, force=False):
        """Add the value inc to the parameter's value unless adding it would
        cause the parameter to go outside of its valid range.
        
        If the force parameter is set to true and the value of inc would cause
        the parameter value to move outside of the range set by min/max, then
        the parameter will be forced to the min/max rail. The parameter will
        never be allowed to go outside of the range set by the min/max when
        using this method.
        
        Return Value:
        True is returned if the inc value could be added to the parameter value,
        False is returned if it could not.  When False is returned it means that
        the parameter value was not modified.  When the force parameter is True
        then this function will always return true.
        """
        v = self.v + inc
        if force:
            if v > self._optmax:
                self.setv(self._optmax)
            elif v < self._optmin:
                self.setv(self._optmin)
            else:
                self.setv(v)
            return True
        else:
            if v > self._optmax or v < self._optmin:
                return False
            self.setv(v)
            return True
        
    def optsub(self, inc, force=False):
        """See the documentation for optadd()."""
        self.optadd(-inc,force)
        
    def optdiscard(self):
        """Discard changes made to the parameter."""
        self.setv(self.__optsave)
    
    def optsave(self):
        """Save changes made during optimization."""
        self.__optsave = self.v
        
    def can_optimize(self):
        """Determine if the parameter is optimizable.  This checks that
        _optmin is less than _optmax and that the parameter value is bounded
        by _optmin and _optmax.
        
        Returns True if the conditions are met, False if not.
        """
        if self._optmin is not None and self._optmax is not None \
            and self._optmin < self._optmax \
            and self.v >= self._optmin and self.v <= self._optmax:
            return True
        return False
    optimizable = property(can_optimize)
    
    def set_opt_range(self, minv=None, maxv=None):
        """Set the min and max optimization limits."""
        mn, mx = self._optmin, self._optmax
        if minv is not None:
            mn = float(minv)
        if maxv is not None:
            mx = float(maxv)
        
        if mn is not None and mx is not None and mx < mn:
            raise ValueError("'%s': Inconsistent limits. Max is less than min."%self.name)
        
        self._optmin, self._optmax = mn, mx
    set_opt_limits = set_opt_range
    
    def _get_optrange(self):
        if self._optmax is None or self._optmin is None:
            return None
        return self._optmax - self._optmin
    optrange = property(_get_optrange)
    
    def _get_optlimits(self):
        return self._optmin,self._optmax
    optlimits = property(_get_optlimits)
    
