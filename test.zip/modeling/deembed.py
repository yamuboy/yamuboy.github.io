from __future__ import unicode_literals, absolute_import, division, print_function
import optparse
import sys, os.path
from .spar_reader import TouchstoneReadAndDeembed

try:
    inpf = raw_input
except NameError:
    inpf = input

def deembedding_cl_tool(default_mode='deembed'):
    """Command-line de-embedding utility
    
    
    
    """
    
    if default_mode not in ('deembed','embed'):
        raise ValueError("invalid 'default_mode'")
    
    # parse the command line
    p = optparse.OptionParser(usage="%prog [options] s2p_file [s2p_file ...]")
    p.add_option('-d','--deembed',action='store_true',dest='deembed',help='deembed fixtures from S2P data files')
    p.add_option('-e','--embed',action='store_true',dest='embed',help='embed fixtures onto S2P data files')
    p.add_option('-1','--fxa','--fixture1',dest='fxa',metavar='FILE',default='',help='use FILE as the port 1 fixture data (S2P data file)')
    p.add_option('-2','--fxb','--fixture2',dest='fxb',metavar='FILE',default='',help='use FILE as the port 2 fixture data (S2P data file)')
    p.add_option('--swap1',action='store_true',dest='swap1',default=False,help='swap the ports of the data used for fixture 1')
    p.add_option('--swap2',action='store_true',dest='swap2',default=False,help='swap the ports of the data used for fixture 2')
    p.add_option('-x','--ext','--extension',dest='ext',help='set the file extension for output files to EXT')
    p.add_option('-p','--pat','--pattern',dest='pattern',help='use the string PATTERN as a template for generating the output file names')
    p.add_option('-q','--quiet',action='store_false',dest='verbose',default=True,help='don\'t print status information to the terminal')
    p.add_option('-i','--interactive',action='store_true',dest='interactive',help='prompt for deembedding fixtures')
    
    opts,filelist = p.parse_args()
    
    if not len(filelist):
        p.print_usage()
        sys.exit(0)
    
    mode = default_mode
    if opts.deembed:
        if opts.embed:
            sys.stderr.write("Error: '--deembed' and '--embed' options are mutually exclusive.\n")
            sys.exit(1)
        mode = 'deembed'
    elif opts.embed:
        mode = 'embed'
    
    if opts.ext and opts.pattern:
        sys.stderr.write("Error: '--extension' and '--pattern' options are mutually exclusive.\n")
        sys.exit(1)
    
    fxa_name = opts.fxa
    fxb_name = opts.fxb
    
    if opts.interactive:
        # prompt for fixture file names
        r = inpf("Port 1 fixture file? [%s] "%fxa_name).strip()
        if r:
            fxa_name = r
        
        r = inpf("Port 2 fixture file? [%s] "%fxb_name).strip()
        if r:
            fxb_name = r
            
        if not opts.ext and not opts.pattern:
            r = inpf("New extension for output files? [.dm2] ").strip()
            if r:
                opts.ext = r
        
    if not fxa_name and not fxb_name:
        sys.stderr.write("Error: no fixture files specified. Nothing to do.\n")
        sys.exit(1)
    
    if not opts.ext and not opts.pattern:
        # set a default output extension of '.dm2'
        opts.ext = '.dm2'
    
    dmb = True
    if mode == 'embed':
        dmb = False
   
    # set up the de-embedding parameters
    kw = {
        'auto_cache':False,
        'auto_deembed':True,
        'deembedding_fixture1':fxa_name,
        'deembedding_fixture2':fxb_name,
        'swap_fixture1':opts.swap1,
        'swap_fixture2':opts.swap2,
        'invert_fixture1':dmb,
        'invert_fixture2':dmb, 
        }
        
    # create the Touchstone read and deembed object
    try:
        tsr = TouchstoneReadAndDeembed(**kw)
    except Exception as e:
        sys.stderr.write("Error: failed to set up de-embedding: {}\n".format(e))
        sys.exit(2)
    
    # on Windows, where there is no useful shell, expand all files in the filelist
    # using glob
    if sys.platform in ('winnt','win32','win64',):
        import glob
        fl2 = []
        for fn in filelist:
            fl2.extend(glob.glob(fn))
        filelist = fl2
    
    # for each input S2P file, read it with the deembedding tool
    # and then write it back out again
    for fn in filelist:
        if opts.verbose:
            sys.stdout.write(fn+" ...\n")
            
        # generate the output file name
        if opts.ext:
            outfn = os.path.splitext(fn)[0] + opts.ext
        else:
            try:
                b, e = os.path.splitext(fn)
                repl = {'fullname':fn, 'name':os.path.basename(fn), 'trunk':b, 'ext':e, 'base':os.path.basename(b)}
                outfn = opts.pattern%repl
            except Exception as e:
                sys.stderr.write("Warning: %s: failed to generate output file name. Error: %s\n"%(fn,e))
                continue                
        
        if outfn == fn:
            sys.stderr.write("Warning: %s: output file name is the same as input file name. Skipping.\n"%fn)
            continue
            
        # read and deembed the S2P file
        try:
            data = tsr.read(fn)
        except Exception as e:
            sys.stderr.write("Warning: %s: read and deembed failed. Error: %s\n"%(fn,e))
            continue
        
        # write the output file
        try:
            data.write(outfn)
        except Exception as e:
            sys.stderr.write("Warning: %s: write failed. Error: %s\n"%(outfn,e))
            continue
    

if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    deembedding_cl_tool()
    