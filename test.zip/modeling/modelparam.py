from __future__ import unicode_literals, absolute_import, division, print_function
from . import _str_type

class ModelParam(object):
    """Base class for model parameters."""
    
    def __init__(self, name):
        "This base initializer sets the parameter name."
        self.name = name
        
        
    def _getname(self):
        return self.__name
    def _setname(self,name):
        if not isinstance(name,_str_type):
            raise TypeError("'name' must be a string.")
        # trim whitespace from the name and check it
        n = name.strip()
        if not len(n):
            raise ValueError("'name' must have non-zero length.")
        self.__name = n
    name = property(_getname,_setname)
    
    def setv(self, v):
        """Set the value of the parameter.
        
        This should be overridden by derived classes.
        """
        self.__value = v
        
    def _getval(self):
        """Get the value of the parameter.
        
        This should be overridden by derived classes.
        """
        return None
    value = property(_getval,setv)
    val = value
    v = value


class FloatParam(ModelParam):
    """A model parameter that holds floating point data."""
    
    def __init__(self, name, value, **kwargs):
        """A floating-point model parameter.
        Keywords:
        limits - a 2-tuple of (min,max) absolute limits for the parameter. To not
          use one of the limits, set its value to None.
          E.g. (None,1.5) set the max limit to 1.5 with no min limit.
        """
        ModelParam.__init__(self,name)
        
        # set limits if they are defined
        self.__minl = None
        self.__maxl = None
        if 'limits' in kwargs:
            limits = kwargs['limits']
            try:
                minl,maxl = limits
            except (TypeError,AttributeError):
                raise TypeError("'limits' keyword must be a 2-tuple.")
            self.set_limits(minl,maxl)
        
        self.setv(value)
        
        
    def setv(self, v):
        """Set the value of the parameter."""
        v = float(v)
        self.check_limits(v)
        self.__value = v
        
    def _getval(self):
        """Get the value of the parameter."""
        return self.__value
    value = property(_getval,setv)
    val = value
    v = value
    
    def set_limits(self, minl=None, maxl=None):
        """Set the absolute limits for the parameter. Attempting to set the
        value of the parameter outside of these limits will result in a ValueError
        exception being raised.  If the limit value is None then a limit is not
        set.
        """
        if minl is None:
            self.__minl = None
        else:
            self.__minl = float(minl)
        if maxl is None:
            self.__maxl = None
        else:
            self.__maxl = float(maxl)
        # make sure than everything is OK
        self.check_limits()
        
    def check_limits(self, val=None):
        """Check that the value 'val' is within the absolute limits defined
        for the parameter.
        If val is not set then the current value of the parameter is checked.
        """
        if val is None: val = self.__value
        if self.__minl is not None and val < self.__minl:
            raise ValueError("'%s': value is less than the absolute minimum."%self.__name)
        elif self.__maxl is not None and val > self.__maxl:
            raise ValueError("'%s': value is greater than the absolute minimum."%self.__name)
        
