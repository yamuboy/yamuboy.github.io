from __future__ import unicode_literals, absolute_import, division, print_function
import sys, os
import math, cmath
import numpy as np
from datetime import datetime
from network_params import Touchstone, ParamSet, NetworkParamsError
import logging
from functools import cmp_to_key
if not hasattr(__builtins__,'cmp'):
    # python3 hack
    cmp = lambda a, b: (a > b)-(a < b)  

# fix missing cmath.phase function
if not hasattr(cmath,'phase'):
    cmath.phase = lambda x: math.atan2(x.imag,x.real)
    
try:
    inpf = raw_input
except NameError:
    inpf = input

def trl_cl():
    """command line wrapper for the compute_fixtures() function below"""
    
    kwargs = {}

    def _read_s2p( prompt, blank_ok=False ):
        "helper to read S2P data files"
        while True:
            try:
                fname = inpf(prompt).strip()
                if blank_ok and fname == '':    
                    return None
                return Touchstone(fname)
            except KeyboardInterrupt:
                raise
            except Exception as e:
                sys.stderr.write("error reading file: %s\n"%e)
                
    
    #### read in thru, reflect, and delay file data ####
    
    thru = _read_s2p("Thru data file name? ")
    reflect = _read_s2p("Reflect data file name? ")
    
    delay_files = []
    while True:
        d = _read_s2p("Delay%d data file name? "%(len(delay_files)+1),blank_ok=True)
        if d is not None:
            delay_files.append(d)
        else:
            if not len(delay_files):
                sys.stderr.write("at least 1 delay data file is required\n")
            else:
                break
    
    #### read in frequency list ####
    flist = None
    while True:
        r = inpf("Frequency list in GHz? (start stop step)\nLeave blank to use the thru file freq. list: ").strip()
        if r == '':
            flist = thru.flist
        else:
            try:
                d = r.split()
                if len(d) != 3:
                    raise ValueError("must be 3 values")
                flist = np.arange(float(d[0])*1.0e9,(float(d[1])+0.001)*1.0e9,float(d[2])*1.0e9).tolist()
            except Exception as e:
                sys.stderr.write("entry error: %s\n"%e)
                continue
        
        if not len(flist):
            sys.stderr.write("frequency list is empty\n")
            continue
                    
        ### TODO: check the freq list against all data files
        fmin, fmax = flist[0], flist[-1]
        
        # flist is OK
        break
            
    #### read in reflect type ####
    reflpr = 'Inductance of short in pH [0.0]? '
    while True:
        r = inpf("Reflect standard type (short/open) [short]? ").strip().lower()
        if r == '':
            break
        elif r == 'short'[:len(r)]:
            break
        elif r == 'open'[:len(r)]:
            reflpr = 'Capacitance of open in pF [0.0]? '
            kwargs['refl_type'] = 'open'
            break
        else:
            sys.stderr.write('invalid entry\n')
    
    #### read in reflect parasitic value ####
    while True:
        r = inpf(reflpr).strip()
        if r == '':
            break
        
        try:
            kwargs['refl_ind_or_cap'] = float(r)*1.0e-12
            break
        except ValueError:
            sys.stderr.write('invalid entry\n')
            
    #### run the fixture computation ####    
    fx1, fx2 = compute_fixtures(flist,thru,reflect,delay_files,**kwargs)
    
    #### prompt for output file names ####
    fn1 = inpf("Fixture 1 output file name? ").strip()
    fn2 = inpf("Fixture 2 output file name? ").strip()
    
    #### write output files ####
    fx1.write(fn1)
    fx2.write(fn2)
    
    sys.stdout.write("\nDone.\n\n")

def compute_fixtures( flist, thru, refl, delay_lines, refl_type='short', refl_ind_or_cap=0.0, z0=50.0, strict=False, allow_averaging=True ):
    """compute input and output calibration fixtures from TRL line measurement data
    
    This function uses a complex algorithm to derive the input and output 'calibration fixtures' that are
    present on either side of a TRL thru line. For this method to work with reasonable accuracy there
    are several things that must be true about the system being measured.
      - The reflect standards must be reciprocal (the same or nearly identical reflect standard must be
        used on both port 1 and port 2 of the calibration).
      - The 'calibration fixtures' must be reciprocal (no isolators, active devices, or other structures
        for which S[1,2] != S[2,1])
      - The frequency list must have small enough frequency spacing so that the insertion phase shift
        through the 'calibration fixture' on each side is less than 180 degrees between adjacent
        frequency points. This requirement is due to the need to calibrate the phase velocity of
        the fixture so that proper phase correction can be applied at the end due to ambiguity in
        the calculated phase of S[1,2] and S[2,1] in the algorithm.
      - No resonances should be present in the calibration fixtures.
    
    Parameters:
    ----------------------------------------
    
    flist - list/tuple of floats, frequencies (in Hz) at which to compute the
       calibration fixtures
       
    thru - network_params.ParamSet object, the measured data for the thru structure
    
    refl - network_params.ParamSet object, the measured data for the reflect structures
    
    delay_lines - list/tuple of network_params.ParamSet objects, the measured data for the
       TRL delay lines
       
    Keywords:
    ----------------------------------------
    
    refl_type - string, either 'short' or 'open' indicting the type of reflect standard used
    
    refl_ind_or_cap - float, the parasitic inductance (for a short) or capacitance (for an open)
       of the reflect standard in absolute units (H or F)
    
    z0 - float, the Z0 of the measurement system
    
    strict - boolean, all warnings become errors
    
    allow_averaging - boolean, allow more than one delay line to contribute to the solution for a given
       frequency point. Multiple results are averaged together. If this is false, then the data from the
       longest delay line that is valid for the frequency will be used and other delay lines that are
       valid will be ignored.
    """
    
    log = logging.getLogger('modeling.compute_fixtures')
    
    flist = list(flist[:])
    flist.sort()
    
    if len(flist) < 3:
        raise ValueError("at least 3 points are required in the frequency list")
    
    if refl_type not in ('open','short'):
        raise ValueError("'refl_type' must be either 'open' or 'short'")
    
    if not isinstance(thru,ParamSet):
        raise TypeError("'thru' must be an instance of 'network_params.ParamSet'")
    if not isinstance(refl,ParamSet):
        raise TypeError("'refl' must be an instance of 'network_params.ParamSet'")
    
    if not isinstance(delay_lines,(list,tuple)):
        raise TypeError("'delay_lines' must be a list/tuple")
        
    for d in delay_lines:
        if not isinstance(d,ParamSet):
            raise TypeError("'delay_lines' must be a list/tuple of 'network_params.ParamSet' objects")
        
    # convert network parameters to correct types
    refl.convert('s')
    thru.convert('t')
    for d in delay_lines:
        d.convert('t')
        
    # compute fmin and fmax data for each delay line
    # and verify that the delay lines will cover the requested
    # frequency list
    fmin, fmax = flist[0], flist[-1]
    delay_data = []
    for delay in delay_lines:
        dat = {'data':delay}
        dat['fmin'], dat['fmax'] = _compute_min_and_max_freq(flist,thru,delay)
        
        if dat['fmin'] is None:
            log.warning("delay data file '%s' does not cover any portion of the frequency list"%delay.filename)
            if strict:
                raise ValueError("delay data file '%s' does not cover any portion of the frequency list"%delay.filename)
            continue
        
        delay_data.append(dat)
    
    # sort the lines from longest to shortest
    def sortfunc(a,b):
        x = cmp(a['fmin'],b['fmin'])
        if x == 0:
            return cmp(a['fmax'],b['fmax'])
        return x
    delay_data.sort(key=cmp_to_key(sortfunc))
        
    # check the longest line of the frequency list to see if there is coverage of the low end
    # of the frequency list
    if delay_data[0]['fmin'] > fmin:
        # longest line does not cover the bottom of the frequency range
        d = abs(_compute_phase_delay(fmin,thru,delay_data[0]['data']))*180.0/math.pi
        if strict:
            tgt = log.error
        else:
            tgt = log.warning
        tgt("the longest delay line ('%s') does not cover the bottom of the frequency range"%delay_data[0]['data'].filename)
        tgt(" the insertion phase difference between the thru and delay line at the minimum frequency of %g MHz is %g degrees"%(fmin*1.0e-6,round(d,1)))
        tgt(" the minimum recommended insertion phase difference for algorithm accuracy is 20 degrees")
        if strict:
            raise ValueError("no delay lines cover the minimum frequency of the band")
        else:
            log.warning(" the minimum frequency of the longest line will be adjusted to cover the frequency band")
            log.warning(" *** this will result in a loss of accuracy ***")
            log.warning(" to turn this warning into an error, set the 'strict' keyword to True")
            
        delay_data[0]['fmin'] = fmin
    
    # check that there are no coverage holes in the frequency band
    not_covered = []
    for f in flist:
        n = 0
        for ddat in delay_data:
            if f >= ddat['fmin'] and f <= ddat['fmax']:
                n += 1
        
        if not n:
            not_covered.append(f)
    
    if len(not_covered):
        log.error("frequencies not covered by the delay lines: %s"%repr(not_covered))
        raise ValueError("%d frequencies are not covered by the delay line data"%len(not_covered))
    
    # create the return data objects
    fx1 = Touchstone()
    fx2 = Touchstone()
    
    refl_units = 'pH'
    if refl_type == 'open':
        refl_units = 'pF'
    header = """! Calculated fixtures using TRL line input data
!
! date stamp:   %s
! working dir:  %s
! thru data:    %s
! reflect data: %s
! reflect type: %s
! reflect para: %g %s
"""%(datetime.now().strftime('%Y/%m/%d %H:%I:%S'),os.getcwd(),thru.filename,refl.filename,refl_type,refl_ind_or_cap*1.0e12,refl_units)
    for i,ddat in enumerate(delay_data):
        header += '! delay%d data:  %s (fmin: %g MHz, fmax: %g MHz)\n'%(i+1,ddat['data'].filename,ddat['fmin']*1.0e-6,ddat['fmax']*1.0e-6)
    header += '!\n'
    
    fx1.header = header
    fx2.header = header
    
    for f in flist:
        mt = thru.extract(f,rawfmt=True)
        mr = refl.extract(f,rawfmt=True)
        
        # for each delay line that covers the frequency
        # extract delay data, compute the fixture and average it
        # with other data points
        ti = np.zeros_like(mt)
        to = np.zeros_like(mt)
        n = 0
        
        for ddat in delay_data:
            if n > 0 and not allow_averaging:
                break
                
            if f >= ddat['fmin'] and f <= ddat['fmax']:
                md = ddat['data'].extract(f,rawfmt=True)
                try:
                    mi, mo = _compute_fxa_fxb(mt,md,mr,refl_type,refl_ind_or_cap,z0,f)
                except Exception as e:
                    log.warning("failure during computation for delay '%s' at frequency %g MHz"%(ddat['data'].filename,f*1.0e-6))
                    if strict:
                        raise
                    continue
                
                # prepare to compute averaging
                # ~180 phase shift is possible
                # so need to check but only if there has already been a calculation at this frequency
                if n:
                    if abs(cmath.phase(ti[0,1]/mi[0,1])) > 0.5*math.pi:
                        mi[0,1] *= -1.
                        mi[1,0] *= -1.
                    
                    if abs(cmath.phase(to[0,1]/mo[0,1])) > 0.5*math.pi:
                        mo[0,1] *= -1.
                        mo[1,0] *= -1.

                ti = ti + mi
                to = to + mo
                n += 1
        
        # this should have been checked ahead of time, so this should always be OK
        assert n > 0

        # compute averaging
        if n > 1:
            ti = ti / complex(n)
            to = to / complex(n)

        # insert the data into the computed fixture data objects
        fx1.insert(f,ti)
        fx2.insert(f,to)
    
    # correct the phase of the fixtures
    el1 = _correct_phase(fx1)
    el2 = _correct_phase(fx2)
    log.info("fixture 1 free space electrical length (approx.) => %g cm"%round(el1,3))
    log.info("fixture 2 free space electrical length (approx.) => %g cm"%round(el2,3))
    
    return fx1, fx2


def _compute_fxa_fxb( tt, td, reflect, refl_type, refl_val, z0, freq ):
    "inner compute function for fixture data for a single frequency point"
    fxa = np.zeros_like(tt)
    fxb = np.zeros_like(tt)
    
    # calculate td * tt(inv)
    tdt = np.dot(td,tt.I)

    # calculate parameters
    v1 = tdt[1,1] - tdt[0,0]
    v2 = -v1
    v1 = cmath.sqrt(v1*v1 + 4.0*tdt[0,1]*tdt[1,0])
    s1 = s2 = 0.5 / tdt[1,0]
    s1 *= v2 + v1
    s2 *= v2 - v1

    s1m = abs(s1)
    s2m = abs(s2)
    if s1m < s2m:
        t12a_t22a = s1
        t21a_t11a = 1.0/s2
    else:
        t12a_t22a = s2
        t21a_t11a = 1.0/s1

    t21b_t22b = (tt[1,0]-tt[0,0]*t21a_t11a) / (tt[1,1]-tt[0,1]*t21a_t11a)
    t12b_t11b = (tt[0,1]-tt[1,1]*t12a_t22a) / (tt[0,0]-tt[1,0]*t12a_t22a)

    v1 = reflect[0,0] - t12a_t22a
    v2 = 1.0 - reflect[0,0]*t21a_t11a
    t11a_t22a = cmath.sqrt((v1*(1.0 + reflect[1,1]*t12b_t11b)*(tt[0,0] - tt[1,0]*t12a_t22a)) / (v2*(reflect[1,1] + t21b_t22b)*(tt[1,1] - tt[0,1]*t21a_t11a)))
    
    # correct for phase (because of sqrt(), pi radian phase shift is possible)
    # start by calculating the approximate reflection coeff of the reflect termination
    if refl_type == 'open':
        refl_y = complex(0.0,2.0*math.pi*freq*refl_val)
        refl_gamma = (1. - refl_y*z0) / (1. + refl_y*z0)
    else:
        refl_z = complex(0.0,2.0*math.pi*freq*refl_val)
        refl_gamma = (refl_z - z0) / (refl_z + z0)
        
    # the calculation here compares the t11a_t22a value calculated above with a value calculated
    # via the equation: (reflect(0,0) - t21a_t22a) / (refl_gamma * (1 - reflect(0,0)*t21a_t11a))
    # the quotient of the 2 values is taken such that the phases are subtracted
    # if the phase differs by more than +/- pi/2 radians, then the sign of t11a_t22a is flipped
    # creating a pi radian phase shift
    x = abs(cmath.phase(refl_gamma*t11a_t22a*v2/v1))
    if x > 0.5*math.pi:
        t11a_t22a = -t11a_t22a
        
    t11b_t22b = (tt[0,0]-tt[1,0]*t12a_t22a)/(t11a_t22a*(tt[1,1]-tt[0,1]*t21a_t11a))
        
    ### calculate and load the input error box
    fxa[0,0] = t12a_t22a
    fxa[1,1] = -t11a_t22a*t21a_t11a
    # fxa[0,1] = cmath.sqrt(t11a_t22a*(1.0-t12a_t22a*t21a_t11a))
    fxa[0,1] = cmath.sqrt(t11a_t22a+fxa[0,0]*fxa[1,1])
    fxa[1,0] = fxa[0,1]

    ### calculate and load the output error box
    fxb[0,0] = t12b_t11b*t11b_t22b
    fxb[1,1] = -t21b_t22b
    # fxb[0,1] = cmath.sqrt( (tt[0,0]-tt[1,0]*t21a_t11a*t11a_t22a)/(tt[1,1]*t11a_t22a-tt[0,1]*t12a_t22a) + fxb[0,0]*fxb[1,1] )
    fxb[0,1] = cmath.sqrt(t11b_t22b+fxb[0,0]*fxb[1,1])
    fxb[1,0] = fxb[0,1]

    return fxa, fxb


def _compute_phase_delay( freq, thru, delay ):
    "compute the phase delay in radians between the thru and delay line at a particular frequency"
    # calculate phase(1/(td*tt(inv))[1,1])
    return cmath.phase(1.0/np.dot(delay.extract(freq,rawfmt=True),thru.extract(freq,rawfmt=True).I)[1,1])
    

def _compute_min_and_max_freq( flist, thru, delay ):
    """Compute the minimum and maximum frequency of a delay line"""
    
    fmin, fmax = None, None
    last = None

    for f in flist:
        try:
            ph = _compute_phase_delay(f,thru,delay)
        except NetworkParamsError:
            if fmin is not None:
                fmax = last
                return fmin, fmax
            else:
                continue

        if fmin is None:
            if ph > 0.0 or ph < -math.pi*8.0/9.0:
                # this delay data is useless
                # the line is too long for the minimum requested frequency
                return None, None
            elif ph <= -math.pi/9.0:
                # minimum frequency (at least 20 degree phase difference) found
                fmin = last = f
        else:
            # min frequency found, searching for the maximum frequency
            if ph > 0.0 or ph < -math.pi*8.0/9.0:
                # this frequnecy is beyond the maximum (phase difference is beyond 160 degrees)
                # use the last good frequency
                fmax = last
                break
            else:
                # this frequency still satisfies the (20 <= phase difference <= 160)
                # condition, so keep searching
                last = f
    
    if fmax is None:
        fmax = last
    
    return fmin, fmax    
    
def _correct_phase( data ):
    "internal function to correct the thru phase of the computed fixtures"
    j = complex(0.0,1.0)
    vel = []
    
    last, lastf = None, None
    for d in data:
        v = cmath.phase(d.data[0,1])        
        if last is not None:
            if last >= v:
                diff = v - last
            else:
                diff = v - last - 2.0*math.pi
            vel.append(diff/(d.freq-lastf))
        
        last = v
        lastf = d.freq
    
    # sort the phase velocities
    vel.sort()

    # take the median value
    ave_phase = vel[len(vel)//2]
    elength_cm = abs(ave_phase)*3.0e10/(2.0*math.pi)

    #### correct the phase
    for d in data:
        # calculate expected and actual phase
        # modify both so that they fall into the
        # range of [0, 2*pi) radians
        expect = math.fmod(ave_phase*d.freq,2.0*math.pi)
        if expect < 0.0:
            expect += 2.0*math.pi
        actual = cmath.phase(d.data[0,1])
        if actual < 0.0:
            actual += 2.0*math.pi
        # error between the expected and actual
        err = abs(actual-expect)

        if err > 0.25*math.pi and err < 1.75*math.pi:
            # error is greater than pi/4 radians
            # phase needs to be corrected
            if err > 0.75*math.pi and err < 1.25*math.pi:
                # correct by 180 degrees
                d.data[0,1] *= -1.0
                d.data[1,0] *= -1.0
            elif err < math.pi:
                # phases are within pi/2 radians of each other,
                # determine which way to go by whether
                # the expected or actual value is greater
                if expect > actual:
                    # correct by +pi/2 radians
                    d.data[0,1] *= j
                    d.data[1,0] *= j
                else:
                    # correct by -pi/2 radians
                    d.data[0,1] *= -j
                    d.data[1,0] *= -j
            else:
                # err >= pi
                # phases are on opposite ends of the range [0,2*pi) radians
                if expect > actual:
                    # correct by -pi/2 radians
                    d.data[0,1] *= -j
                    d.data[1,0] *= -j
                else:
                    # correct by +pi/2 radians
                    d.data[0,1] *= j
                    d.data[1,0] *= j

    return elength_cm
    
    
if __name__ == "__main__":
    trl_cl()
