"""
Configuration data storage
Author: Jay Barrett

"""
from __future__ import unicode_literals, absolute_import, division, print_function

import logging
import re
try:
    import threading as _thread
except ImportError:
    import dummy_threading as _thread
from io import StringIO

import os.path
from . import _str_type


# create a module-level thread lock
_write_lock = _thread.RLock()

class ConfigData(object):
    """
    This is a vehicle for loading configuration data from one or more files and
    maintaining it across all of the parts of a model extraction.
    
    This is implemented as a borg-pattern class in which all object data is
    stored in a single structure in memory and shared among all instances of
    the object.
    
    This class can be sub-classed to provide isolation between various different
    'sets' of configuration data, in which case a search path is specified and
    used to search for variables.
    
    """
    # variables not allowed to be changed
    __locked_vars = frozenset(['default.__version__',])
    
    __shared_data = dict()
    __var_order = dict()
    
    # regular expressions used for various tasks
    __var_re = re.compile(r'(?P<ns>\w+\.)?(?P<var>\w+)$')
    __section_re = re.compile(r'\[([a-zA-Z0-9_]+)\]')
    
    class _varwrapper(object):
        "internal class for variable storage"
        
        def __init__(self, name, vartype, callback, help):
            "initializer"
            if not isinstance(name,_str_type):
                raise TypeError("'name' must be a string")
            if vartype is not None and not callable(vartype):
                raise TypeError("'vartype' must be None or a callable object")
            if callback is not None and not callable(callback):
                raise TypeError("'callback' must be None or a callable object")
            if help is not None and not isinstance(help,_str_type):
                raise TypeError("'help' must be a string")
            
            self.__v = None
            self.__default_v = None
            self.__name = name
            self.__vt = vartype
            self.__cb = callback
            self.__help = help
        
        @property
        def value(self):
            "variable value"
            return self.__v
        
        @property
        def default_value(self):
            "default variable value (value assigned at creation)"
            return self.__default_v
        
        @property
        def name(self):
            "variable name"
            return self.__name
        
        def set(self, value, default=False):
            """set the value of the variable
            if the 'default' keyword is True, also update the default value
            """
            
            v = value
            if value is not None and callable(self.__vt):
                v = self.__vt(value)
            
            if callable(self.__cb):
                v2 = self.__cb(self.__name,v)
                if v2 is not None and callable(self.__vt):
                    v2 = self.__vt(v2)
                v = v2
            
            self.__v = v
            if default:
                self.__default_v = v
        
        def __str__(self):
            "make a pretty version of this"
            return '{}  =>  {}'.format(self.__name,repr(self.__v))
        
        @property
        def help(self):
            "help/documentation text"
            return self.__help
    
    def __init__(self, search_path=None, disable_default=False, default_ns=None):
        "initializer"
        self._log = logging.getLogger('modeling.ConfigData')
        self.__search = ('default',)
        self.__default_ns = 'default'
            
        if search_path:
            if isinstance(search_path,_str_type):
                search_path = [search_path]
            else:
                search_path = list(search_path)
            
            if 'default' not in search_path and not disable_default:
                search_path.append('default')
            
            self.__search = tuple(search_path)
            self.__default_ns = search_path[0]
        
        if default_ns:
            if not isinstance(default_ns,_str_type):
                raise TypeError("'default_ns' must be a string")
            self.__default_ns = default_ns
        
        
    def add(self, varname, default_value=None, vartype=None, namespace=None, callback=None, help=None):
        """Add a configuration variable.
        
        varname is required and must be a string, it must be a valid Python
          identifier (start with a letter and consist of only alphanumeric
          characters and underscores) and must not be a Python reserved word
        
        default_value is the default value of the variable, if this is not None
          and the vartype argument is specified then this default_value must be
          able to be coerced by using the vartype otherwise a TypeError will be
          raised, also if this is not None and the callback argument is specified
          then the callback will be called
        
        vartype is a type object or other callable that can be used to coerce
          variable values to a specific type, this is used when a variable is
          stored
        
        namespace is a string that overrides the default namespace in which the
          variable will be stored
        
        callback is a callable object that performs value validation, the callback
          will be called with 2 arguments, the variable name and value, and the
          vartype callable (if specified) will be called on the value prior to
          running the callback, the callback should raise a TypeError or ValueError
          (whichever is appropriate) when a validation error occurs, the callback
          must return the value of the variable and the vartype callable will be
          called on this return as well
        
        help is a string that is used to generate help/documentation for the variable
        
        """
        
        if not isinstance(varname,_str_type):
            raise TypeError("'varname' must be a string")
        
        # parse the variable name
        m = self.__var_re.match(varname)
        if not m:
            raise KeyError("'%s' is not a valid variable name"%varname)
        g = m.groupdict()
        vname = g['var']
        vns = g['ns']            
        
        ns = self.__default_ns
        if vns is not None:
            ns = vns[:-1]
            
        if namespace:
            if not isinstance(namespace,_str_type):
                raise TypeError("'namespace' must be a string")
            elif vns is not None:
                raise ValueError("namespace can be specified either in the variable name or as a keyword - not both")
            ns = namespace
        
        sd = type(self).__shared_data
        vo = type(self).__var_order
        
        # see if the variable is already defined
        if ns in sd and vname in sd[ns]:
            logging.getLogger('modeling.ConfigData').warning("add(): '%s' is already an existing variable name in namespace '%s'"%(vname,ns))
            return
        
        # create the variable container and initialize its value
        v = self._varwrapper(vname,vartype,callback,help)
        if default_value is not None:
            v.set(default_value,True)       
        
        _write_lock.acquire()
        try:
            # store the variable
            if ns not in sd:
                sd[ns] = dict()
                vo[ns] = []
            sd[ns][vname] = v
            vo[ns].append(vname)
        finally:
            _write_lock.release()
    
    def get(self, name, default=None):
        "dictionary-like get() method"
        try:
            return self[name]
        except KeyError:
            pass
        return default
    
    def __getitem__(self, name):
        "get the value of a variable"
        return self._var_search(name)[0].value
        
    def __setitem__(self, name, value):
        "set the value of a variable"
        try:
            _write_lock.acquire()
            try:
                v, ns = self._var_search(name)
            except KeyError:
                self.add(name,value)
                return
                
            full = ns+'.'+v.name
            if full in self.__locked_vars:
                raise KeyError("'%s' is locked"%full)
            v.set(value)
        finally:
            _write_lock.release()
    
    #def __delitem__(self, name):
    #    "delete an item"
    #    v, ns = self._var_search(name)
    #    full = ns+'.'+v.name
    #    if full in self.__locked_vars:
    #        raise KeyError("'%s' is locked"%full)
    #    
    
    def ns_as_dict(self, ns):
        """retreive a shallow copy of all variables in the given namespace
        returned as a dictionary
        """
        sd = type(self).__shared_data
        if ns not in sd:
            raise KeyError(ns)
        
        ret = dict()
        _write_lock.acquire()
        try:
            for k in sd[ns]:
                ret[k] = sd[ns][k].value
        finally:
            _write_lock.release()
        
        return ret
    
    def _var_search(self, name):
        "helper function for searching the namespaces for a variable"
        if not isinstance(name,_str_type):
            raise KeyError("keys must be strings")
        
        m = self.__var_re.match(name)
        if not m:
            raise KeyError("invalid identifier '%s'"%name)
        g = m.groupdict()
        n = g['var']
        sd = type(self).__shared_data
        if g['ns']:
            # only look in the specified namespace for the variable
            ns = g['ns'][:-1]
            #self._log.debug("searching for '%s' in namespace '%s'"%(n,ns))
            if ns not in sd or n not in sd[ns]:
                raise KeyError(name)
            return sd[ns][n], ns
        else:
            # search the namespace search list for the variable
            for ns in self.__search:
                #self._log.debug("searching for '%s' in namespace '%s'"%(n,ns))
                if ns in sd and n in sd[ns]:
                    return sd[ns][n], ns
        
        # not found, raise a KeyError
        raise KeyError(name)
                
        
    def read_file(self, fname, default_ns='default'):
        "read and parse a configuration data file"
        ac = False
        if isinstance(fname,_str_type):
            ac = True
            fp = open(fname,'r')
        else:
            fp = fname
            fname = '<unknown>'
        
        self._log.debug("reading file '%s'"%fname)
        
        data = fp.readlines()
        if ac:
            fp.close()
        
        # start parsing data
        namespace = default_ns
        coll = []
        for lineno,line in enumerate(data):
            if line.lstrip().startswith('['):
                m = self.__section_re.match(line)
                if m:
                    # this is the start of a new namespace
                    newns = m.group(1)
                    self._log.debug("encountered namespace header '%s' on line %d"%(newns,lineno))
                    if newns != namespace:
                        # process the data collected for the previous section
                        if coll:
                            try:
                                self._log.debug("assigning variables defined in namespace '%s'"%namespace)
                                self._add_namespace_vars(namespace,''.join(coll))
                            except Exception as e:
                                # must have been a syntax error in the namespace data
                                self._log.error("'%s'[%s]: %s: %s"%(fname,namespace,type(e).__name__,e))
                        coll = []
                    namespace = newns
                else:
                    # this is a bad namespace definition
                    self._log.error("'%s':(%d) ignoring badly formed namespace"%(fname,lineno+1))
            else:
                # collect the data to process all at once
                coll.append(line)
            
        # add any leftover data to the current namespace
        if coll:
            try:
                self._log.debug("assigning variables defined in namespace '%s'"%namespace)
                self._add_namespace_vars(namespace,''.join(coll))
            except Exception as e:
                # must have been a syntax error in the section
                self._log.error("'%s'[%s]: %s: %s"%(fname,namespace,type(e).__name__,e))
            
    def write_file(self, fname):
        """write a file with all of the defined variables."""
        
        def myrepr( v ):
            "create a file representation of the value"
            if isinstance(v,_str_type):
                return repr(v).strip('"')
            elif isinstance(v,complex):
                return '(%g%+gj)'%(v.real,v.imag)
            elif isinstance(v,float):
                return '%g'%v
            else:
                return repr(v)
                
        sd = type(self).__shared_data
        vo = type(self).__var_order
        namespaces = list(sd.keys())
        if 'default' in namespaces:
            del namespaces[namespaces.index('default')]
        namespaces.sort()
        namespaces.insert(0,'default')
        
        from textwrap import TextWrapper
        twrap = TextWrapper(initial_indent='# ', subsequent_indent='# ')
        
        fp = StringIO()
        for ns in namespaces:
            fp.write("########################################################################\n")
            fp.write("["+ns+"]\n\n")
            if ns not in sd:
                continue
            
            _write_lock.acquire()
            try:
                keys = list(sd[ns].keys())
                order = vo[ns]
                for k in order[:]:
                    if k in keys:
                        del keys[keys.index(k)]
                    else:
                        del order[order.index(k)]
                if len(keys):
                    keys.sort()
                    order.extend(keys)                
                
                for k in order:
                    full = ns+'.'+k
                    if full in self.__locked_vars:
                        continue
                    
                    # build the variable configuration
                    v = sd[ns][k]
                    txt = v.help
                    if not txt:
                        txt = '<no documentation>'
                    defstr = '#default: %s\n'%myrepr(v.default_value)
                    valstr = '%s = %s\n'%(k,myrepr(v.value))
                    
                    # massage the help text
                    for t in txt.splitlines(False):
                        fp.write(twrap.fill(t) + '\n')
                    fp.write(defstr)
                    if valstr:
                        fp.write(valstr)
                    fp.write('\n')
            finally:
                _write_lock.release()
                
        # write the config data to the real file        
        fpout = open(fname,'w')
        try:
            fpout.write(fp.getvalue())        
        finally:
            fp.close()
            fpout.close()
        
            
    def _add_namespace_vars(self, namespace, data):
        "internal function for adding variables from a parsed namespace section"
        sd = type(self).__shared_data        
        if namespace not in sd:
            self._log.info("ignoring undefined namespace [%s]"%namespace)
            return
                        
        # process the data collected for the section
        vd = dict()
        exec(compile(data,'[{}]'.format(namespace),'exec'),globals(),vd)
                        
        # add variables to the defined variables
        _write_lock.acquire()
        try:
            sdd = sd[namespace]
            for k in vd:
                if k not in sdd:
                    self._log.warning("in namespace [%s]: ignoring assignment of undefined variable '%s'"%(namespace,k))
                    continue
                
                try:
                    sdd[k].set(vd[k])
                except Exception as e:
                    self._log.warning("'%s.%s': %s: %s"%(namespace,k,type(e).__name__,e))                                
        finally:
            _write_lock.release()
            
    def __str__(self):
        "display the contents of the configuration object"
        sd = type(self).__shared_data
        nslist = list(sd.keys())
        if self.__default_ns in nslist:
            del nslist[nslist.index(self.__default_ns)]
        nslist.sort()
        nslist.insert(0,self.__default_ns)
        
        s = "==================== ConfigData ====================\n* default namespace = '%s'\n* search order      = %s\n\n"%(self.__default_ns,self.__search)
        for ns in nslist:
            s += '[%s]\n----------------------------------------------------\n'%ns
            vlist = list(sd[ns].keys())
            vlist.sort()
            r = []
            for name in vlist:
                r.append('{}'.format(sd[ns][name]))
            s +=  '\n'.join(r) + '\n\n'
        return s
            

# instantiate the initial configuration object and load default configuration
# variables
__cfg = ConfigData()
from . import _default_config

def load_config(fname, auto_search=True, search_levels=1, default_ns=None):
    "convenience function for loading configuration data"
    global __cfg
    
    kw = {}
    if default_ns:
        kw['default_ns'] = default_ns
    
    if os.path.isabs(fname) or fname.find('/') > -1 or fname.find('\\') > -1:
        # can't search since this is an absolute path or a relative path
        # with directory information
        __cfg.read_file(fname,**kw)
        absfn = os.path.abspath(fname)
    else:
        # can search since this is a simple file name
        lvl = 0
        fn = fname
        absfn = os.path.abspath(fn)
        found = False
        while True:
            if os.path.isfile(absfn):
                found = True
                break
            
            if search_levels < 0 or lvl < search_levels:
                fn = os.path.join('..',fn)
                newfn = os.path.abspath(fn)
                if len(newfn) == len(absfn):
                    # no reduction in path length, must be at the root level
                    break
                absfn = newfn
            else:
                break
            
            lvl += 1
        
        if found:
            __cfg.read_file(absfn,**kw)
        else:
            raise IOError("file not found: '%s'"%fname)
    
    return __cfg, absfn
    
    
