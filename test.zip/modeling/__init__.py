from __future__ import unicode_literals, absolute_import, division, print_function

# set up a null logging handler for default setups
import logging as _logging
if hasattr(_logging,'NullHandler'):
    _h = _logging.NullHandler()
else:
    class _NullHandler(_logging.Handler):    
        def emit(self, record):
            pass
    _h = _NullHandler()
_logging.getLogger('modeling').addHandler(_h)

# python version compatibility 
try:
    _number_types = (int,long,float)
except NameError:
    _number_types = (int,float)

try:
    _str_type = basestring
except NameError:
    _str_type = str    
    
# make sure that the cmath.phase function is defined
import cmath as _cmath
import math as _math
if not hasattr(_cmath,'phase'):
    _cmath.phase = lambda x: _math.atan2(x.imag,x.real) 

# import some commonly used objects into the top-level package
##from file_cache import FileCache
from .config_data import ConfigData, load_config
from .spar_reader import TouchstoneReadAndDeembed, read_and_deembed_spars

