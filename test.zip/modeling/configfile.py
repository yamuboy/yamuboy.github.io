from __future__ import unicode_literals, absolute_import, division, print_function
import re
import logging
import os
import os.path
from .configtypes import *
from . import _str_type

__all__ = ['ConfigVars','ConfigFile']

class ConfigVars(object):
    """Define variables to be pulled from a configuration file.
    
    **************** DEPRECATED *****************
    **** use ConfigData from modeling.config_data instead!!!! ****
    
    An instance of this class is passed to several methods of the
    ConfigFile class in order to read/write variables to a configuration
    file.
    """
    
    class VarDef(object):
        """Internal class that holds variable definition information."""
        _validname_re = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]*$")
        
        def __init__(self, name, type=CF_DEFAULT, default=None, callback=None, length=None):
            """Create a new object."""
            # error checking
            if self._validname_re.match(name) is None:
                raise ValueError("'name' parameter is invalid.")
            if type not in (CF_STRING,CF_INT,CF_FLOAT,CF_TUPLE,CF_INTTUPLE,CF_FLOATTUPLE):
                raise ValueError("'type' parameter is invalid.")
            if callback is not None and not callable(callback):
                raise TypeError("'callback' parameter is invalid.")
            
            self.__name = name
            self.__type = type
            if default is None:
                # set an appropriate default
                if type in (CF_TUPLE,CF_INTTUPLE,CF_FLOATTUPLE):
                    self.__default = tuple()
                elif type == CF_FLOAT:
                    self.__default = 0.0
                elif type == CF_INT:
                    self.__default = 0
                else:
                    self.__default = ''
            else:
                # use the supplied default value
                self.__default = default
            self.__callback = callback
            
            if length is not None:
                # if length is defined then it must be a 2-tuple of ints
                if not isinstance(length,tuple):
                    raise TypeError("'length' must be a 2-tuple of integers.")
                if len(length) != 2:
                    raise TypeError("'length' must be a 2-tuple of integers.")
                try:
                    l1, l2 = int(length[0]), int(length[1])
                except:
                    raise TypeError("'length' must be a 2-tuple of integers.")
            self.__length = length
        
        @property
        def name(self):
            return self.__name
        
        @property
        def type(self):
            return self.__type
        
        @property
        def default(self):
            return self.__default
        
        @property
        def callback(self):
            return self.__callback
        
        @property
        def length(self):
            return self.__length
        
    def __init__(self):
        """Create the object."""
        self.__vars = []
    
    def add(self,*args,**kwargs):
        """Add a new variable definition."""
        self.__vars.append(self.VarDef(*args,**kwargs))
        
    def __len__(self):
        """Return length of variable list."""
        return len(self.__vars)
        
    def __iter__(self):
        """Iterator."""
        return iter(self.__vars)
        


class ConfigFile(object):
    """Read/write configuration files in a pre-determined way.
    """
    
    def __init__(self):
        """Create a new object."""
        
        # create a logger
        self.__logger = logging.getLogger('ConfigFile')
        
        # initialize internal storage
        self.__rawdata = []
        self.__variables = { 'global':dict() }
        self.__filename = '<unknown>'
    
    def search(self, fname, levels=0, path=None):
        """Search for a configuration file by looking in the current directory
        and a number of parent directories specified by levels or in a list of
        direcories specified by path.
        """
        if path is not None:
            raise NotImplementedError("'path' is not implemented.")
        if path is not None and levels > 0:
            raise ValueError("'levels' and 'path' are mutually exclusive arguments.")
        if not isinstance(fname,_str_type):
            raise ValueError("'fname' must be a string.")
        if not isinstance(levels,int):
            raise ValueError("'levels' must be an integer.")
        
        # search parents as necessary
        cwd = os.getcwd()
        fpath = os.path.join(cwd,fname)
        while not os.path.isfile(fpath) and levels > 0:
            # search parents
            cwd = os.path.dirname(cwd)
            fpath = os.path.join(cwd,fname)            
            
        self.read(fpath)
    
    def read(self, fobj, **kwargs):
        """Read a config file."""
        
        section_re = re.compile(r"^\[(?P<section>[a-zA-Z0-9_-]+)\]$")
        
        # reset internal storage
        self.__filename = '<unknown>'
        self.__rawdata = []
        self.__variables = { 'global':dict() }
        
        autoclose = False
        if isinstance(fobj,_str_type):
            autoclose=True
            self.__filename = fobj
            fobj = open(self.__filename,'r')
        
        # read all of the data from the file
        # config files should not be too big so this is not a huge
        # burden on memory
        if hasattr(fobj,'readlines'):
            all_lines = fobj.readlines()
        else:
            all_lines = []
            for line in fobj:
                all_lines.append(line)
        
        if autoclose:
            fobj.close()
        
        # start parsing the data into the raw data list
        stored = ''
        section = 'global'
        # state 0 is the 'no-state', state 1 is 'comment' and state 2 is 'variable'
        state = 0 
        for i,line in enumerate(all_lines):
            # this loop is a basic state machine that must keep track of
            # what type of data it is processing since the various data types
            # are stored in multi-line blocks
            self.__curline = i+1            
            sline = line.rstrip()
            
            if line.startswith('#') or line.startswith(';'):
                # comment line
                if state == 2:
                    # process the last variable block
                    self._process_variable(stored,section)
                    stored = ''
                state = 1
                stored += sline + '\n'
                
            elif not len(sline):
                # blank line
                if state == 2:
                    # process the last variable block
                    self._process_variable(stored,section)
                    stored = ''
                state = 1
                stored += '\n'
                
            elif line.startswith('['):
                # start of a section block
                if state == 1:
                    # store the last comment block
                    self.__rawdata.append( (1,stored) )
                    stored = ''
                elif state == 2:
                    # process the last variable block
                    self._process_variable(stored,section)
                    stored = ''
                    
                # verify the section syntax
                result = section_re.match(sline)
                if not result:
                    self.__logger.error("'%s':%d: invalid section name. Parsing halted."%(self.__filename,self.__curline))
                    del self.__curline
                    return
                
                # update the section name and create a new storage container
                # as necessary
                section = result.group('section').lower()
                if section not in self.__variables:
                    self.__variables[section] = dict()
                
                self.__rawdata.append( (0,section) )
                state = 0
                
            else:
                # this must be part of a variable block line
                if state == 1:
                    # need to store the comment block
                    self.__rawdata.append( (1,stored) )
                    stored = ''
                state = 2
                stored += sline + '\n'
            
        if state == 1:
            # store the final comment block
            self.__rawdata.append( (state,stored) )
        elif state == 2:
            # store the final variable block
            self._process_variable(stored,section)
        
        del self.__curline
    
    def get_variables(self, vardef, section=None, use_global=True):
        """Get a dictionary of variables by processing them from data stored
        in internal lists.
        """
        
        if not isinstance(vardef,ConfigVars):
            raise TypeError("'vardef' must be and instance of a 'ConfigVars' class.")
        
        # set up the sections variable in a reasonable way
        existing_sections = set(self.__variables.keys())
        sections_clean = []
        if section is not None:
            if isinstance(section,_str_type):
                sl = section.lower()
                if sl in existing_sections:
                    sections_clean.append(sl)
            elif isinstance(section,tuple):
                for s in section:
                    sl = s.lower()
                    if not isinstance(s,_str_type):
                        raise TypeError("'section' must be a string or tuple of strings.")
                    if sl in existing_sections:
                        sections_clean.append(sl)
            else:
                raise TypeError("'section' must be a string or tuple of strings.")
                
        # append the global section to the search list
        if bool(use_global):
            sections_clean.append('global')
        
        # loop through definitions and try to resolve them against the data stored
        # in internal storage
        ret = dict()
        for v in vardef:
            # try to find the variable
            vardata = self._get_var_raw(v.name,sections_clean)
            if vardata is None:
                # variable data not found, use the default supplied
                self.__logger.info("'%s': not found, using default."%v.name)
                ret[v.name] = v.default
            else:
                # resolve the raw value into the specified type
                try:
                    if v.type == CF_FLOAT:
                        val = float(vardata)                        
                    elif v.type == CF_INT:
                        val = int(vardata)                        
                    elif v.type in (CF_TUPLE,CF_INTTUPLE,CF_FLOATTUPLE):
                        # split the data using commas
                        lst = vardata.split(',')
                        val = []
                        for lv in lst:
                            if v.type == CF_INTTUPLE:
                                val.append(int(lv))
                            elif v.type == CF_FLOATTUPLE:
                                val.append(float(lv))
                            else: # string tuple
                                val.append(lv.strip())
                        val = tuple(val)
                    else:
                        # default to raw string
                        val = vardata
                except Exception as e:
                    # error in parsing parameter value, fall back to default
                    self.__logger.warning("'%s': parse error -> '%s'"%(v.name,e))
                    ret[v.name] = v.default
                    continue
                
                # if a callback is set, call it
                if v.callback is not None:
                    try:
                        val = v.callback(v.name,val)
                    except Exception as e:
                        self.__logger.warning("'%s': callback error -> '%s'"%(v.name,e))
                        ret[v.name] = v.default
                        continue
                
                # if the parameter is a tuple and the length is set, check it
                # raise an exception in this case as having an incorrect length
                # is sure to raise havoc further down the road in many cases
                if v.type in (CF_TUPLE,CF_INTTUPLE,CF_FLOATTUPLE) and v.length is not None:
                    lmin, lmax = v.length
                    n = len(val)
                    if lmin > -1 and n < lmin:
                        raise ValueError("'%s': tuple length exceeds minimum allowed."%v.name)
                    elif lmax > -1 and n > lmax:
                        raise ValueError("'%s': tuple length exceeds maximum allowed."%v.name)
                
                # store the value
                ret[v.name] = val

        # return the dictionary of values
        return ret
        
    def _get_var_raw(self, name, sections):
        """Get the raw value of a variable from the internal storage lists."""
        for sect in sections:
            if name in self.__variables[sect]:
                return self.__variables[sect][name]
        return None
            
    def _process_variable(self, data, section):
        """Process 1 or more variables in the data blocka and store them in the
        internal storage lists.
        """
        # parse the variable strings into name/value pairs and store them
        varline_re = re.compile(r"^(?P<varname>[a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(?P<varvalue>.*)$")
        contline_re = re.compile(r"^\s+[^=]+$")
        
        lines = data.split('\n')
        startline = self.__curline - len(lines) + 1
        name,value = None,None
        for i,line in enumerate(lines):
            # determine if this is a primary line or a continuation of a
            # previous line
            result = varline_re.match(line)
            if result:
                if name is not None:
                    # store the previous variable
                    self.__variables[section][name] = value
                    self.__rawdata.append( (2,name) )
                name = result.group('varname')
                value = result.group('varvalue').rstrip()
            elif not len(line.strip()):
                if name is not None:
                    # store the previous variable
                    self.__variables[section][name] = value
                    self.__rawdata.append( (2,name) )
                name,value = None,None
            else:
                # this is not a variable definition line, it must be a continuation
                # line - verify that with a regex
                result = contline_re.match(line)
                if not result:
                    # parse error, invalid line
                    self.__logger.warning("'%s':%d: invalid line (illegal syntax)."%(self.__filename,startline+i))
                    
                if name is None:
                    # parse error, no variable definition line
                    self.__logger.warning("'%s':%d: invalid line (no definition)."%(self.__filename,startline+i))
                    
                # add the value to the previous line, seperating by a newline
                value += '\n' + line.strip()
                
        if name is not None:
            # store the last variable
            self.__variables[section][name] = value
            self.__rawdata.append( (2,name) )
    
    def _debug_print(self):
        """Print data about the internal storage of the class for debugging purposes."""
        print("============= Raw Parser Data ==============")
        for n,v in self.__rawdata:
            if n == 0:
                print("** Section Header: {}".format(v))
            elif n == 1:
                print(" -- Comment --")
                lst = v.split('\n')
                for ln in lst:
                    if len(ln): print("  "+ln)
            elif n == 2:
                print("xx Variable: {}".format(v))
        
        print("============ Variables By Section ===============")
        for sect in self.__variables:
            for k in self.__variables[sect]:
                v = self.__variables[sect][k]
                lst = v.split('\n')
                print("{}.{}: {}".format(sect,k,'  '.join(lst)))
            
if __name__ == '__main__':
    
    def mycb(name, value):
        return value[:-1]
    
    def failcb(name, value):
        raise ValueError('aaaaaahhhhhh')
        
    cf = ConfigFile()
    cf.read('configtest.txt')
    cf._debug_print()
    
    cv = ConfigVars()
    cv.add('varx',CF_FLOAT)
    cv.add('variable2',CF_INTTUPLE, callback=mycb)
    cv.add('variable3',CF_FLOATTUPLE)
    cv.add('varx')
    cv.add('nonexistent')
    cv.add('multiline2',CF_INTTUPLE,callback=failcb)
    
    data = cf.get_variables(cv,section='section1')
    
    print("========= Get Variables ============")
    print(data)
    
    
    
            
        
        
        
        
        
        
        
        
        