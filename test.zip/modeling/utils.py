from __future__ import unicode_literals, absolute_import, division, print_function
import numpy as np
from network_params import Param
import math
from . import _str_type, _number_types

def compute_k_and_mag(data):
    """compute K factor and maximum stable/available gain for a set of
    2-port S-parameter data

    The input data can be either:
      - a sequence of numpy arrays/matrices
      - a sequence of network_params.Param objects
      - a ParamSet object

    The return will be a 2-tuple of the form (K, MAG) where each of the components
    of the 2-tuple is a list of the same length as the input data.
    """

    retsingle = False
    if isinstance(data,Param) or (isinstance(data,np.ndarray) and data.ndim == 2):
        # special case of a single set of data
        # turn this into an iterable
        retsingle = True
        data = (data,)

    try:
        iter(data)
    except:
        raise TypeError("data must be iterable")

    kr, magr = [], []
    for i,d in enumerate(data):
        if isinstance(d,Param):
            if d.nports != 2:
                raise TypeError("network_params.Param at index %d is not 2-port data"%i)
            a = d.data
        elif isinstance(d,np.ndarray):
            if d.ndim != 2 or d.shape != (2,2):
                raise TypeError("numpy.ndarray at index %d is not a 2x2 array"%i)
            a = d
        else:
            raise TypeError("data set at index %d is not a valid network_params.Param or numpy.ndarray object"%i)

        # compute K
        s11m2 = abs(a[0,0])*abs(a[0,0])
        s22m2 = abs(a[1,1])*abs(a[1,1])
        s21s12 = a[0,1]*a[1,0]
        t = a[0,0]*a[1,1] - s21s12
        delm2 = abs(t)*abs(t)

        k = 1.0 - s11m2 - s22m2 + delm2
        t = 2.0*abs(s21s12)
        if t < 1.0e-100:
            t = 1.0e-100
        k = k / t

        # compute MAG/MSG
        t = abs(a[0,1])
        if t < 1.0e-100:
            t = 1.0e-100
        msg = abs(a[1,0]) / t
        if k < 1.0:
            mag = msg
        else:
            if k > 1.0e6:
                # use an approximation to prevent numerical overflow
                mag = (0.5/k)*msg
            else:
                mag = (k - math.sqrt(k*k - 1.0))*msg

        kr.append(k)
        magr.append(mag)
    
    if retsingle:
        return kr[0], magr[0]
    return kr, magr

def y2s_2port_50ohms(data):
    """a quick and dirty utility for converting raw 2-port Y-param data to S-param
    data in a 50 ohm environment

    The input data must be a sequence of numpy arrays/matrices.

    The returned data will be a list of numpy matrices.
    """
    retsingle = False
    if isinstance(data,np.ndarray) and data.ndim == 2:
        # special case of a single set of data
        # turn this into an iterable
        retsingle = True
        data = (data,)
        
    try:
        iter(data)
    except:
        raise TypeError("argument must be iterable")

    zref = complex(50.0)
    ret = []
    for d in data:
        if not isinstance(d,np.ndarray) or d.shape != (2,2):
            raise TypeError("argument must be an iterable of 2x2 numpy arrays")
        x = np.zeros_like(d)
        y12y21zref2 = d[0,1]*d[1,0]*zref*zref
        denom = 1.0 / ((1.0+d[0,0]*zref)*(1.0+d[1,1]*zref) - y12y21zref2)
        x[0,0] = ((1.0-d[0,0]*zref)*(1.0+d[1,1]*zref) + y12y21zref2)*denom
        x[0,1] = -2.0*d[0,1]*zref*denom
        x[1,0] = -2.0*d[1,0]*zref*denom
        x[1,1] = ((1.0+d[0,0]*zref)*(1.0-d[1,1]*zref) + y12y21zref2)*denom
        ret.append(x)
        
    if retsingle:
        return ret[0]
    return ret


def s2y_2port_50ohms(data):
    """a quick and dirty utility for converting raw 2-port S-param data to Y-param
    data in a 50 ohm environment

    The input data must be a sequence of numpy arrays/matrices.

    The returned data will be a sequence of numpy matrices.
    """    
    retsingle = False
    if isinstance(data,np.ndarray) and data.ndim == 2:
        # special case of a single set of data
        # turn this into an iterable
        retsingle = True
        data = (data,)
        
    try:
        iter(data)
    except:
        raise TypeError("must be iterable")

    zref = complex(50.0)
    ret = []
    for d in data:
        if not isinstance(d,np.ndarray) or d.shape != (2,2):
            raise TypeError("argument must be an iterable of 2x2 numpy arrays")
        x = np.zeros_like(d)
        s12s21 = d[0,1]*d[1,0]
        denom = 1.0 / (((1.0+d[0,0])*(1.0+d[1,1]) - s12s21)*zref)
        x[0,0] = ((1.0-d[0,0])*(1.0+d[1,1]) + s12s21)*denom
        x[0,1] = -2.0*d[0,1]*denom
        x[1,0] = -2.0*d[1,0]*denom
        x[1,1] = ((1.0+d[0,0])*(1.0-d[1,1]) + s12s21)*denom
        ret.append(x)
    
    if retsingle:
        return ret[0]
    return ret


def build_freq_list(data, mult=1.0e9):
    """Build a frequency list from configuration data."""
    if not data:
        return None

    if isinstance(data,(_str_type,)+_number_types):
        data = (data,)
    elif not isinstance(data,(list,tuple)):
        raise TypeError("invalid input data type")

    output = []
    for d in data:
        if isinstance(d,_number_types):
            output.append(float(d)*mult)
        elif isinstance(d,_str_type):
            # parse the string to generate a frequency list segment
            glbs = {'__builtins__':__builtins__, 'arange':np.arange, 'range':np.arange}
            try:
                lst = eval(d,glbs)
                if not isinstance(lst,np.ndarray):
                    raise TypeError("evaluation of '%s' did not yield a frequency list segment"%d)
                output.extend( (lst*mult).tolist() )
            except Exception as e:
                logging.getLogger('modeling.build_freq_list').warning('{}'.format(e))
        else:
            logging.getLogger('modeling.build_freq_list').warning("unknown data type '%s' in frequency list"%type(d))

    return output


    
