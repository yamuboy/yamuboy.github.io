from __future__ import unicode_literals, absolute_import, division, print_function
from math import pi
from network_params import ParamSet

def remove_parasitics( indata, params, **kwargs ):
    """Remove the effects of parasitic parameters from a set of FET data.
    
    indata - a ParamSet (or derived object) or a list/tuple of ParamSet objects
       from which parasitics are to be removed
    params - a dictionary of parasitic parameters to remove.  The dictionary keys
       are 'rg', 'rd', 'rs', 'lg', 'ld', 'ls', 'cpg', 'cpd', 'c11', and 'c22'
    
    Returns a copied ParamSet object with parasitics removed or a tuple of copied
       ParamSet objects if the indata argument is a tuple or list.
    """
    
    if isinstance(indata,(tuple,list)) and not kwargs.get('_recursed'):
        # recursively call self
        kwargs['_recursed'] = True
        ret = []
        for dat in indata:
            ret.append(remove_parasitics(dat,params,**kwargs))
        return tuple(ret)
    
    if not isinstance(indata,ParamSet):
        raise TypeError('The first argument must be a ParamSet object.')
        
    # copy input data
    curpt = indata.param_type
    data = indata.copy()
    
    # get parasitic parameter values
    cpg = params.get('cpg',0.0)
    cpd = params.get('cpd',0.0)
    c11 = params.get('c11',0.0)
    c22 = params.get('c22',0.0)
    rg = params.get('rg',0.0)
    rd = params.get('rd',0.0)
    rs = params.get('rs',0.0)
    lg = params.get('lg',0.0)
    ld = params.get('ld',0.0)
    ls = params.get('ls',0.0)
    
    # remove cpg and cpd
    if cpg or cpd:
        data.convert('y')
        for d in data:
            w = 2.0*pi*d.freq
            d.data[0,0] -= complex(0., w*cpg)
            d.data[1,1] -= complex(0., w*cpd)
    # remove lg, ld, ls, and rs
    data.convert('z')
    for d in data:
        w = 2.0*pi*d.freq
        zcom = complex(rs, w*ls)
        d.data[0,0] -= complex(0., w*lg) + zcom
        d.data[1,1] -= complex(0., w*ld) + zcom
        d.data[0,1] -= zcom
        d.data[1,0] -= zcom
    # remove c11 and c22
    if c11 or c22:
        data.convert('y')
        for d in data:
            w = 2.0*pi*d.freq
            d.data[0,0] -= complex(0., w*c11)
            d.data[1,1] -= complex(0., w*c22)
    # remove rg and rd
    data.convert('z')
    for d in data:
        d.data[0,0] -= rg
        d.data[1,1] -= rd
    # convert to the format that it was in originally and return
    data.convert(curpt)
    return data
    
