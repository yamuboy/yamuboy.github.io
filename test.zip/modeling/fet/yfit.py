from __future__ import unicode_literals, absolute_import, division, print_function
import numpy as np
from math import pi
from network_params import param_convert, BiasedTouchstone, ParamSet
from ..utils import y2s_2port_50ohms
import cmath


def yfit( data, **kwargs ):
    """Compute the Y-fit of 1 or more sets of measured FET data.
    
    data - a BiasedTouchstone object or a list/tuple of BiasedTouchstone objects
       representing measured FET data that has already been deembedded and has
       already had the parasitics removed.
    
    Parasitics that should already be removed are:
       rg, rd, rs, lg, ld, ls, cpg, cpd, c11, and c22
    
    Returns either a dictionary of Y-fit parameters, or a list of dictionaries of
      Y-fit parameters for the case when a list/tuple is passed in.  The dictionary
      will contain the keys 'cgs', 'cgd', 'cds', 'gm', 'gds', 'ri', 'rgd', 'tau'
      'tau2', 'ggs', and 'ggd'
    
    """
    if isinstance(data,(list,tuple)):
        ret = []
        for d in data:
            ret.append( yfit(d,**kwargs) )
        return ret
        
    if not isinstance(data,ParamSet):
        raise TypeError("The data argument must be a 'network_params.ParamSet` object")
    
    # run the extraction
    cgs,cgd,cds,gm,gds = _extract_c_gm_gds(data,**kwargs)
    ri,tau,rgd,tau2 = _extract_ri_tau(data,cgs,cds,**kwargs)
    parms = {'cgs':cgs, 'cgd':cgd, 'cds':cds, 'gm':gm, 'gds':gds, 'ri':ri,
             'tau':tau, 'rgd':rgd, 'tau2':tau2 }
    if kwargs.get('yfit_enable_ggsggd',True):
        ggs,ggd = _extract_ggs_ggd(data,parms,**kwargs)
        parms['ggs'] = ggs
        parms['ggd'] = ggd
    else:
        parms['ggs'] = 0.0
        parms['ggd'] = 0.0        
    
    return parms
    
def _extract_c_gm_gds( data, **kwargs ):
    """Internal function for extraction of Cgs/Cgd/Cds/Gm/Gds.
    
    Returns a 5-tuple of (cgs,cgd,cds,gm,gds).
    """
    
    cmin = kwargs.get('yfit_min_cfreq_ghz',0.0)*1e9
    cmax = kwargs.get('yfit_max_cfreq_ghz',100.0)*1e9
    gmin = kwargs.get('yfit_min_gmfreq_ghz',0.0)*1e9
    gmax = kwargs.get('yfit_max_gmfreq_ghz',100.0)*1e9
    
    # verify that the data is in Y-params
    data.convert('y')
    
    ## extraction of Cgs/Cgd/Cds ##
    cgs,cgd,cds = 0.,0.,0.
    n = 0
    for d in data:
        if d.freq >= cmin and d.freq <= cmax:
            w = 2.0*pi*d.freq
            cgs += -1. / ( w * (1. / (d.data[0,0]+d.data[0,1])).imag )
            cgd -= d.data[0,1].imag / w
            cds += (d.data[1,1]+d.data[0,1]).imag / w
            n += 1
    
    if not n:
        raise ExtractionError('No data points were found that meet the Cgs/Cgd/Cds extraction frequency criteria.')
    
    den = 1.0 / n
    cgs *= den
    cgd *= den
    cds *= den
    
    ## extraction of Gm/Gds ##
    gm,gds = 0.,0.
    n = 0
    for d in data:
        if d.freq >= gmin and d.freq <= gmax:
            gm += abs( (d.data[1,0]-d.data[0,1]) / (d.data[0,0]+d.data[0,1]) * complex(0., 2.0*pi*d.freq*cgs) )
            gds += (d.data[1,1]+d.data[0,1]).real
            n += 1
    
    if not n:
        raise ExtractionError('No data points were found that meet the Gm/Gds extraction frequency criteria.')
    
    den = 1.0 / n
    gm *= den
    gds *= den
    
    return cgs,cgd,cds,gm,gds
    
def _extract_ri_tau( data, cgs, cds, **kwargs ):
    """Internal function to extract ri and tau from the data.
    
    Returns a 4-tuple of (ri,tau,rgd,tau2).
    """
    
    fmin = kwargs.get('yfit_min_taufreq_ghz',0.0)*1e9
    fmax = kwargs.get('yfit_max_taufreq_ghz',100.0)*1e9
    
    # verify that the data is in Y-params
    data.convert('y')
    
    ## extraction of Ri/Tau/Rgd/Tau2 ##
    ri,rgd,tau,tau2 = 0.,0.,0.,0.
    n = 0
    for d in data:
        if d.freq >= fmin and d.freq <= fmax:
            w = 2.0*pi*d.freq
            ri += (1. / (d.data[0,0]+d.data[0,1]) ).real
            rgd += -(1. / d.data[0,1]).real
            tau += -cmath.phase((d.data[1,0]-d.data[0,1])/(d.data[0,0]+d.data[0,1])*complex(0.0,w*cgs)) / w
            tau2 += -cmath.phase(d.data[1,1] + d.data[0,1] - complex(0.0,w*cds)) / w
            n += 1
            
    if not n:
        raise ExtractionError('No data points were found that meet the Ri/Tau/Rgd/Tau2 extraction frequency criteria.')
    
    den = 1.0 / n
    ri *= den
    tau *= den
    rgd *= den
    tau2 *= den
    
    return ri,tau,rgd,tau2
    
def _extract_ggs_ggd( data, parms, **kwargs ):
    """Internal function to extract ggs and ggd from the data.
    
    Returns a 2-tuple of (ggs,ggd).
    """
    
    fmin = kwargs.get('yfit_min_ggsfreq_ghz',0.0)*1e9
    fmax = kwargs.get('yfit_max_ggsfreq_ghz',10.0)*1e9
    
    # verify that the data is in Y-params
    data.convert('y')
    
    ## extraction of Ri/Tau/Rgd/Tau2 ##
    ggd = 0.
    ggsp = data.copy_truncated()
    n = 0
    for d in data:
        if d.freq >= fmin and d.freq <= fmax:
            ggd -= d.data[0,1].real
            ggsp.insert(d)
            n += 1
            
    if not n:
        raise ExtractionError('No data points were found that meet the Ggs/Ggd extraction frequency criteria.')
    
    ggd /= n
    parms['ggd'] = ggd
    if hasattr(data,'v1') and hasattr(data,'i1') and data.v1 > 0.0 and data.i1 > 0.0:
        ggs = _ggs_s11_fit( ggsp, parms, **kwargs )
    else:
        ggs = 0.0
    
    return ggs,ggd
    
    
def _ggs_s11_fit( data, parms, **kwargs ):
    """Internal function for fitting of S11 data."""
    
    # convert data to S-params
    data.convert('s')
    
    ggs,last = 0.,0.
    inc = 1.0e-6
    for i in range(1000):
        err = _ggs_s11_error(data, parms, ggs)
        if err < 0. or (i and err > last):  ##need modify....
            ggs -= inc
            break
        ggs += inc
        last = err
    ##add this:
    if ggs < 0.0:
        ggs = 0.0
    return ggs

def _ggs_s11_error( data, parms, ggs ):
    """Internal function for calculation of S11 error that relates to Ggs."""
    
    # model parameters 
    ggd = parms.get("ggd",0.0)
    cgd = parms.get("cgd",0.0)
    cgs = parms.get("cgs",0.0)
    cds = parms.get("cds",0.0)
    ri = parms.get("ri",0.0)
    tau = parms.get("tau",0.0)
    tau2 = parms.get("tau2",0.0)
    gm = parms.get("gm",0.0)
    gds = parms.get("gds",0.0)
    
    # compute S11 error from meas to model
    zref = complex(50.)
    err = 0.
    y = np.mat(np.zeros([2,2], dtype=complex))
    for d in data:
        w = 2.0*pi*d.freq
        y[0,1] = complex(-ggd, -w*cgd)
        y[0,0] = 1. / (ri + 1. / complex(ggs,w*cgs)) - y[0,1]
        y[1,1] = gds*cmath.exp(complex(0.,-w*tau2)) + complex(0.,w*cds) - y[0,1]
        y[1,0] = gm*cmath.exp(complex(0.,-w*tau)) * (y[0,0]+y[0,1]) / complex(ggs,w*cgs) + y[0,1]
        s = y2s_2port_50ohms(y)
        smod = abs(s[0,0])
        smeas = abs(d.data[0,0])
        
        if smod < smeas:
            return -1
        err += smod-smeas
        
    return err

