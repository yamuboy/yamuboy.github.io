from __future__ import unicode_literals, absolute_import, division, print_function
from .. import splines, _number_types, _str_type
import bisect
import math
import re
import logging

_log = logging.getLogger('modeling.fet.dscrreader')


_default_values = { 'rg':1.0e-4, 'rs':1.0e-4, 'rd':1.0e-4, 'ri':1.0e-4, 'cgs':0.0,
    'cgd':0.0, 'cds':0.0, 'cpg':0.0, 'cpd':0.0, 'ls':1.0e-18, 'lg':1.0e-18,
    'ld':1.0e-18, 'ggs':0.0, 'ggd':0.0, 'gm':0.0, 'tau':0.0, 'gds':0.0,
    'tau2':0.0, 'c11':0.0, 'c22':0.0, 'vv':0.0, 'ii':0.0 }


class DSCRModel(object):
    """This class is designed to handle DSCR data that is read using the
    read_dscr_file() function defined below.
    
    This class and the read_dscr_file() function that creates instances of
    this class are designed for use with the modeling.fet.dscr2mdif module for
    converting .dscr files to generic MDIF format.
    """
    
    __summary_keys = ('has_noise','ugw','ngf','vpo','filename','device','wafer','temp',
        'vbr1','vbr2','idss','imax','vmax','vpo3','vpo1p5','vpo1ma','ron')
            
    def __init__(self,*args,**kwwargs):
        self.__data = []
        self.__vds_values = []
        self.__idxmap = []
        self.__summary = {}
        for k in self.__summary_keys:
            self.__summary[k] = None
    
    def check(self):
        """Run a check to make sure that this model is valid."""
        if self['vpo'] is None or self['ngf'] is None or self['ugw'] is None:
            raise ValueError('Model is not valid.')
    
    def __nonzero__(self):
        """Return true if at least one point exists."""
        return bool(self.__idxmap)
    
    def __len__(self):
        """Return a count of the data points in the model."""
        return len(self.__idxmap)
    
    def get_vgs_values(self,vds):
        """Returns a tuple of vgs values for a given vds."""
        i = self._find_vds(vds)
        if i < 0: return []
        ret = []
        for d in self.__data[i]:
            ret.append(d['vgs'])
        return ret
        
    def get_ids_values(self,vds):
        """Returns a copy of ids values for a given vds."""
        i = self._find_vds(vds)
        if i < 0: return []
        ret = []
        for d in self.__data[i]:
            ret.append(d['ids'])
        return ret
        
    def get_vds_values(self):
        """Returns a copy of the vds values for the model."""
        return self.__vds_values[:]
    vds_values = property(get_vds_values)
    
    def get_data(self, vds, vgs=None, ids=None, **kwargs):
        """Get a set of model data for a given vds/vgs or vds/ids (mA/mm)
        combination.
        
        Only one of vgs or ids can be set.
        
        """
        if vgs is None and ids is None:
            raise ValueError("One of the parameters 'vgs' or 'ids' must be set.")
        elif vgs is not None and ids is not None:
            raise ValueError("Only one of the parameters 'vgs' or 'ids' can be set.")
        
        if vgs is not None:
            return self._get_data_by_vgs(vds,vgs,**kwargs)
        else:
            return self._get_data_by_ids(vds,ids,**kwargs)

    def get_rawdata_block(self, vds):
        """Get a block of raw model data for a given vds.
        """
        try:
            i = self.__vds_values.index(vds)
        except Exception:
            return []
        
        ret = []
        for d in self.__data[i]:
            ret.append(d.copy())
        return ret
    
    @property
    def raw_data(self):
        "the full raw data array with all bias data appended into one big list"
        ret = []
        for d in self.__data:
            ret.extend(d)
        return ret
            
    def get_index(self, i):
        """Get a set of data by index"""
        j,k = self.__idxmap[i]
        return self.__data[j][k]
        
    def copy(self):
        """Return a straight copy of this object."""
        ret = DSCRModel()
        if self.__summary:
            ret.__summary = self.__summary.copy()
        ret._copy_data(self.__vds_values,self.__data)
        return ret
        
    def scalecopy(self, ugw=None, ngf=None):
        """Return a scaled copy of this object."""
        ret = self.copy()
        ret.scale(ugw=ugw,ngf=ngf)
        return ret
    
    def scale(self, ugw=None, ngf=None):
        """Scale the internal model data to match the passed ugw/ngf."""
        ugwsf = 1.0
        ngfsf = 1.0
        
        if not self.__summary:
            raise ValueError("DSCR summary parameters are not set.")
            
        if ugw is not None:
            if not isinstance(ugw,_number_types):
                raise TypeError("'ugw' must be a number.")
            elif ugw < 1.0:
                raise ValueError("'ugw' must be >= 1")
            ugwsf = ugw / self.__summary['ugw']
            
        if ngf is not None:
            if not isinstance(ngf,_number_types):
                raise TypeError("'ngf' must be a number.")
            elif ngf < 1.0:
                raise ValueError("'ngf' must be >= 1")
            elif math.fmod(ngf,1.0) > 0.00001:
                raise ValueError("'ngf' must be a whole number")
            ngfsf = ngf / self.__summary['ngf']
            
        if ugwsf == 1.0 and ngfsf == 1.0:
            # nothing to do
            return
        
        dirp = ('ids','igs','cgs','cgd','cds','cpg','cpd','ggs','ggd','gm','gds','c11','c22')
        invp = ('rs','rd','ri')
        sf = ugwsf*ngfsf
        isf = 1.0 / sf
        for vddata in self.__data:
            for d in vddata:
                # direct scaling parameters
                for p in dirp: d[p] *= sf
                # inverse scaling parameters
                for p in invp: d[p] *= isf
                # special parameters
                d['rg'] *= ugwsf / ngfsf
                d['ld'] /= ngfsf
                d['lg'] /= ngfsf
        
        # set new summary parameters
        self.__summary['last_ugw'] = self.__summary['ugw']
        self.__summary['last_ngf'] = self.__summary['ngf']
        self.__summary['ugw'] *= ugwsf
        self.__summary['ngf'] *= ngfsf
        
        
    def _get_data_by_vgs(self,vds,vgs,**kwargs):
        """Get a set of model data for a given vds/vgs combination."""
        # find the bounding indicies for vds (nearest below and above)
        # this will return the same index for both if there is an exact match
        i,j = self._find_vds_bounds(vds)
        
        # create and solve the spline for vgs for the first vds index
        params1 = self._spline_interp(i, vgs, 'vgs')
        
        # if the second vds index is not the same as the first, create and
        # solve the spline for vgs at the second vds index
        if i != j:
            params2 = self._spline_interp(j, vgs, 'vgs')
            # for each parameter, do a linear interpolation between the 2
            # vds values
            ret = {}
            vdsi = self.__vds_values[i]
            vdsj = self.__vds_values[j]
            f = (vds - vdsi)/(vdsj - vdsi)
            for k in params1.keys():
                ret[k] = params1[k] + f * (params2[k]-params1[k])
            return ret
        else:
            # exact match in vds value, return the interpolated data directly
            return params1
        
    def _get_data_by_ids(self,vds,ids,**kwargs):
        """Get a set of model data for a given vds/ids (ids in mA/mm) combination."""
        # find the bounding indicies for vds (nearest below and above)
        # this will return the same index for both if there is an exact match
        i,j = self._find_vds_bounds(vds)
        
        # create and solve the spline for ids for the first vds index
        params1 = self._spline_interp(i, ids, 'ids')
        
        # if the second vds index is not the same as the first, create and
        # solve the spline for vgs at the second vds index
        if i != j:
            params2 = self._spline_interp(j, ids, 'ids')
            # for each parameter, do a linear interpolation between the 2
            # vds values
            ret = {}
            vdsi = self.__vds_values[i]
            vdsj = self.__vds_values[j]
            f = (vds - vdsi)/(vdsj - vdsi)
            for k in params1.keys():
                ret[k] = params1[k] + f * (params2[k]-params1[k])
            return ret
        else:
            # exact match in vds value, return the interpolated data directly
            return params1
        
    def _find_vds_bounds(self, vds):
        """Find the bounding indicies for the given vds value."""
        vals = self.get_vds_values()
        i = bisect.bisect_left(vals,vds)
        if i == 0 and vds != vals[0]:
            raise ValueError('vds extrapolation error (low-side).')
        elif i == len(vals):
            raise ValueError('vds extrapolation error (high-side).')
        
        if vds == vals[i]:
            return i, i
        else:
            return i, i+1
    
    def _spline_interp(self, vds_idx, val, param):
        """Spline interpolation of parameters within a given vds value."""
        dset = self.__data[vds_idx]
        # create the "X" values of the fit
        x = []
        for d in dset:
            x.append(d[param])
        # clean out non-monotonic values, this is an issue with Ids
        # values since they are measured and can be non-monotonic at
        # small values
        ignore = []
        for i in reversed(range(len(x)-1)):
            if x[i] >= x[i+1]:
                ignore.append(i)
                del x[i]
        # check for issues
        if val < min(x)-1.0e-13:
            raise ValueError('%s extrapolation error (low-side).'%param)
        elif val > max(x)+1.0e-13:
            raise ValueError('%s extrapolation error (high-side).'%param)
        
        ret = {}
        for p in dset[0].keys():
            if p == param:
                ret[p] = val
            else:
                y = []
                for i,d in enumerate(dset):
                    if i not in ignore: y.append(d[p])
                assert len(x) == len(y)
                spl = splines.natural_cubic_spline(x,y)
                ret[p] = splines.cubic_spline_solve(spl, val)
        return ret
        
    def add_data(self, data):
        """Add a set of data to the model, used when initializing the model
        with data read from a file."""
        
        # get parameters from the model dataset
        ds = {}
        vds = None
        missing = []
        keys = ('vds','ids','mamm','vgs','igs','rg','rs','rd','ri','cgs','cgd','cds','cpg',
            'cpd','ls','lg','ld','ggs','ggd','gm','tau','gds','tau2','c11','c22','vv','ii')
        for k in keys:
            if k == 'vds':
                if k in data:
                    vds = data[k]
                    ds[k] = data[k]
                else:
                    missing.append(k)                
            elif k in _default_values:
                ds[k] = data.get(k,_default_values[k])            
            else:
                if k in data:
                    ds[k] = data[k]                
                else:
                    missing.append(k)
                                
        if missing:
            raise KeyError("Model data set is missing required parameters: %s"%(', '.join(missing)))
        
        i = self._find_vds(vds)
        if i < 0:
            self.__vds_values.append(vds)
            self.__data.append([])
            i = self._find_vds(vds)
        assert i > -1
        j = len(self.__data[i])
        self.__data[i].append(ds)
        self.__idxmap.append( (i,j) )
    
    def _copy_data(self,vds_vals,data):
        """Function used to copy new data into the object."""
        
        # verify consistency
        if len(vds_vals) != len(data):
            raise ValueError('Mismatch in list lengths.')
        self.__vds_values = vds_vals[:]
        self.__data = []
        for i,d in enumerate(data):
            self.__data.append([])
            for dd in d:
                self.__data[i].append( dd.copy() )
    
    def _find_vds(self,vds):
        """Find the index for Vds that matches the one stored internally
        This function uses a tolerance to check since it deals with floating
        point numbers and there can be round-off issues.
        """
        for i,v in enumerate(self.__vds_values):
            if abs(vds-v) < 0.0001:
                return i
        return -1
    
    @property
    def vpo(self):
        if self.__summary is None: return None
        return self.__summary['vpo']
    
    @property
    def ugw(self):
        if self.__summary is None: return None
        return self.__summary['ugw']
    
    @property
    def ngf(self):
        if self.__summary is None: return None
        return self.__summary['ngf']
    
    @property
    def has_noise(self):
        if self.__summary is None: return False
        return bool(self.__summary['has_noise'])
        
    def _get_summary(self):
        return self.__summary.copy()
    def _set_summary(self,sumdata):
        if not isinstance(sumdata,dict):
            raise TypeError('Summary data must be a dictionary.')
        # fill in missing keys with None
        sc = {}
        for k in self.__summary_keys:
            sc[k] = sumdata.get(k,None)
        self.__summary = sc
    summary = property(_get_summary,_set_summary,None,"model summary information")
    
    def __getitem__(self,name):
        """Dictionary style lookup."""
        return self.__summary[name]
    
    def __setitem__(self,name,value):
        """Dictionary style assignment."""
        if name not in self.__summary_keys:
            raise KeyError("invalid parameter '%s'"%name)
        self.__summary[name] = value
        
    def __str__(self):
        """Create a friendly printout of information contained in the model."""
        s = "DSCRModel object:\n"
        s += "---------------------------------------------------------\n"
        s += "Summary:\n"
        if self.__summary is not None:
            for k in self.__summary:
                s += "   %-20s : %s\n" % (k,self.__summary[k])
        s += "Number of Points: %d\n" % len(self)
        s += "Vds values: %s\n" % self.__vds_values
        return s
        
    def pprint(self):
        print(self)
        
    
def read_dscr_file( fname, use_vpo1ma=False ):
    """Read a DSCR file and generate 1 or more DSCRModel objects.
    
    fname - string, the full or relative path to a single DSCR model file, or
       a file-like object that has a readline method that returns lines
       of data.
       
    This function and the associated DSCRModel class are designed for use
    with the modeling.fet.dscr2mdif module for converting .dscr files to
    generic MDIF format.
    
    Returns a 2-tuple of the form (list(DSCRModel),header).
    """
    
    closefile = False
    if isinstance(fname,_str_type):
        closefile = True
        f = open(fname,'r')
    else:
        f = fname
        fname = '<unknown>'
    
    logstr = "read_dscr_file('%s'): "%fname
    
    try:
        # read header lines until the first non-empty line that does not start with
        # a '!' character is reached
        header = []
        line = f.readline()
        while line:
            if not line.startswith('!'):
                if len(line.strip()):
                    break
            else:
                header.append(line)
            line = f.readline()
    except Exception:
        if closefile:
            f.close()
        raise
    
    # get device data
    devdata = _parse_header_table(header,logstr)
            
    try:
        #### start reading data ####
        # DSCR files have 29 or 31 columns of data (31 if noise parameters are present)
        # existance of multiple models in one file is detected by a reset of the
        # Vds data column
        current_model = DSCRModel()
        models_list = [current_model]
        idx = 0
        act = -1
        last_vds = None
        while line:
            if line.startswith('!') or line.startswith('%'):
                line = f.readline()
                continue
                
            try:
                da = [float(x) for x in line.split()]
            except Exception:
                line = f.readline()                
                continue
                
            n = len(da)
            if n == 29 or n == 31:
                # this is a data line
                ugw = da[2]
                ngf = int(da[3])
                vds = da[4]
                
                if last_vds is not None and vds < last_vds:
                    # this is a new model
                    current_model = DSCRModel()
                    models_list.append(current_model)
                    idx += 1
                last_vds = vds
                
                if idx != act:
                    # this is the first data point for the current_model
                    # store the summary data for this model if it is present
                    # from the device header
                    if idx < len(devdata):
                        s = devdata[idx]
                        if use_vpo1ma:
                            s['vpo'] = s['vpo1ma']
                        else:
                            s['vpo'] = s['vpo3']
                    else:
                        s = {}
                        _log.warning(logstr+"no header summary data for model #%d"%(idx+1))
                        
                    s['ugw'] = ugw
                    s['ngf'] = ngf
                    s['has_noise'] = bool(n==31)
                    s['filename'] = fname
                    current_model.summary = s                    
                    act = idx
                
                # add this data point to the model
                m = { 'vds':vds, 'ids':da[5], 'mamm':da[6], 'vgs':da[7], 'igs':da[8], 'rg':da[9],
                    'rs':da[10], 'rd':da[11], 'ri':da[12], 'cgs':da[13], 'cgd':da[14],
                    'cds':da[15], 'cpg':da[16], 'cpd':da[17], 'ls':da[18], 'lg':da[19],
                    'ld':da[20], 'ggs':da[21], 'ggd':da[22], 'gm':da[23], 'tau':da[24],
                    'gds':da[25], 'tau2':da[26], 'c11':da[27], 'c22':da[28] }
                if n == 31:
                    m['vv'] = da[29]
                    m['ii'] = da[30]
                current_model.add_data(m)
                
            line = f.readline()
    finally:
        if closefile:
            f.close()
    
    return models_list, header
    
def _parse_header_table(header, logstr):
    "parse the device data stored in the header"

    devdata = []
    newstyle = False
    scaledc = True
    tabstart = -1
    
    # figure out whether there is a model table in the header
    for i,line in enumerate(header):
        if line.startswith('!Model'):
            tabstart = i
            break
    
    if tabstart < 0 or tabstart >= len(header)-2:
        # no header information is present
        _log.warning(logstr+"no header data present")
        return devdata
        
    # determine if it is a new-style or old-style header
    if header[tabstart].find('Periphery') > -1:
        _log.debug(logstr+"detected new style header")
        newstyle=True
        if header[tabstart+1].find('(mA/mm)') > -1:
            scaledc = False 
    else:
        _log.debug(logstr+"detected old style header")
    
    # read all of the header table data
    re_tdata = re.compile(r'\!\d+\s+')
    for line in header[tabstart+2:]:
        if not re_tdata.match(line):
            continue
        
        try:
            # this is a potentially valid data line
            if newstyle:
                # new style header
                d = [float(x) for x in line[38:].split()]
                dcp = d[4:]
                if len(dcp) < 7:
                    continue
                device = line[7:11].strip()
                mask = line[12:20].strip()
                wafer = mask + line[21:37].strip()
                temp = d[0]
                if len(dcp) > 7:
                    vpo1ma = dcp[7]
                else:
                    vpo1ma = dcp[3]
                if len(dcp) > 8:
                    ron = dcp[8]
                else:
                    ron = 0.0
                
                sf = 1.0
                if scaledc:
                    # need to scale stuff to mA/mm
                    sf = 1.0e6 / (d[2]*d[3])
                devdata.append( { 'device':device, 'wafer':wafer, 'temp':temp,
                    'vbr1':dcp[0], 'vbr2':dcp[1], 'idss':(sf*dcp[2]), 'imax':(sf*dcp[4]), 'vmax':dcp[6],
                    'vpo3':dcp[3], 'vpo1p5':dcp[5], 'vpo1ma':vpo1ma, 'ron':(ron/sf) } )
            
            else:
                # old style header
                d = line.split()
                if len(d) in (11,12):
                    dcp = [float(x) for x in d[-7:]]
                    if len(d) == 12:
                        wafer = d[2]+d[3]
                        temp = float(d[4])
                    else:
                        wafer = d[2]
                        temp = float(d[3])
                    
                    # Vpo(1mA/mm) is set equal to Vpo(3v), Ron is set to 0.0
                    devdata.append( { 'device':d[1], 'wafer':wafer, 'temp':temp,
                        'vbr1':dcp[0], 'vbr2':dcp[1], 'idss':dcp[2], 'imax':dcp[4], 'vmax':dcp[6],
                        'vpo3':dcp[3], 'vpo1p5':dcp[5], 'vpo1ma':dcp[3], 'ron':0.0 } )
        except Exception as e:
            _log.debug(logstr+"header read failed with error -> %s"%e)
            pass
    
    return devdata
        
