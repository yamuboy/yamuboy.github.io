from __future__ import unicode_literals, absolute_import, division, print_function

from .ivdata import FETDataSet
from .. import _str_type

class FET_SS_Data(FETDataSet):
    """This class is designed to handle small-signal model data for use by
    model extraction routines.
    
    """
    class IntrinsicFET(object):
        """Internal storage of model parameters."""
        
        def __init__(self, **kwargs):
            """
            
            """
            self.__parms = { 'cgs':0.0, 'cgd':0.0, 'cds':0.0, 'ri':0.0, 'rgd':0.0,
                'ggs':0.0, 'ggd':0.0, 'gm':0.0, 'gds':0.0, 'tau':0.0, 'tau2':0.0,
                'vgs':0.0, 'vds':0.0, 'igs':0.0, 'ids':0.0, 'vv':0.0, 'ii':0.0 }
            
            for k in kwargs:
                if k in self.__parms:
                    self.__parms[k] = float(kwargs[k])
        
        def __getattr__(self, name):
            if name in self.__parms:
                return self.__parms[name]
            raise AttributeError("'%s' is not a valid parameter."%name)
            
        def __str__(self):
            """Stringify the data for prettier printing."""
            s = "{ Vgs: %12.4e, Vds: %12.4e, Igs: %12.4e, Ids: %12.4e\n" % \
                (self.__parms['vgs'],self.__parms['vds'],self.__parms['igs'],self.__parms['ids'])
            s += "  Cgs: %12.4e, Cgd: %12.4e, Cds: %12.4e,  Ri: %12.4e\n" % \
                (self.__parms['cgs'],self.__parms['cgd'],self.__parms['cds'],self.__parms['ri'])
            s += "  Rgd: %12.4e, Ggs: %12.4e, Ggd: %12.4e,  Gm: %12.4e\n" % \
                (self.__parms['rgd'],self.__parms['ggs'],self.__parms['ggd'],self.__parms['gm'])
            s += "  Tau: %12.4e, Gds: %12.4e,  vv: %12.4e,  ii: %12.4e\n" % \
                (self.__parms['tau'],self.__parms['gds'],self.__parms['vv'],self.__parms['ii'])
            s += "  Tau2: %12.4e }" % self.__parms['tau2']
            return s
    
    
    def __init__(self,**kwargs):
        """
        
        Keywords:
        
        data - a list of IntrinsicFET objects that are to be used to initialize
          the bias-dependent model data
        
        fixed - a dictionary of fixed parameter values that are to be used to
          initialize the fixed value model data
        
        fname - if this keyword is present, then it will be passed to the
          read() method.  The 'data' and 'fixed' keywords will be ignored.
        
        """        
        # initialize fixed parameters
        self._initfixed()
        # call the parent class
        FETDataSet.__init__(self, **kwargs)
        
        if 'fixed' in kwargs:
            # update the fixed model params using the passed data
            self.set_fixed(**kwargs['fixed'])
    
    def _initfixed(self):
        """Init fixed parameter values."""
        self.__fixed = { 'cpg':0.0, 'cpd':0.0, 'c11':0.0, 'c22':0.0, 'rg':1.0e-4,
            'rd':1.0e-4, 'rs':1.0e-4, 'lg':1.0e-18, 'ld':1.0e-18, 'ls':1.0e-18,
            'ngf':1.0, 'ugw':1.0 }

    def clear(self):
        """Clear all data."""
        FETDataSet.clear(self)
        self._initfixed()
        
    def read(self, fname, **kwargs):
        """Read data from a .dscr file into this object.
        
        The class only stores the actual model data, not any header information
        or other non model data infomation.
        
        fname - a string denoting the .dscr file file or a file-like object that
           implements the readline() method
        
        """
        def _floats_from_string(line):
            ret = []
            try:
                for v in line.split():
                    ret.append( float(v) )
            except:
                pass
            return ret
        
        # reset the stored data
        self.clear()
        
        closefile=False
        if isinstance(fname,_str_type):
            closefile=True
            f = open(fname,'r')
        else:
            # assume fname is a file-like object
            f = fname
        
        #### start reading data ####
        # DSCR files have 29 or 31 columns of data (31 if noise parameters are present)
        # existance of multiple models in one file is detected by a reset of the
        # Vds data column, for this class the existance of more than one model
        # in a .dscr file is considered an error
        try:
            last_vds = None
            first=True
            line = f.readline()
            while line:
                if line.startswith('!') or line.startswith('%'):
                    line = f.readline()
                    continue
                da = _floats_from_string(line)
                n = len(da)
                if n == 29 or n == 31:
                    # this is a data line
                    vds = da[4]
                    if last_vds is not None and vds < last_vds:
                        # this is a new model, which is an error as this class
                        # is only designed to work with single-model .dscr
                        # files
                        raise RuntimeError("The file contains more than 1 model.")
                    last_vds = vds
                    
                    if first:
                        # store fixed parameters when the first data line is
                        # encountered
                        first=False
                        fixed = { 'rg':da[9], 'rd':da[11], 'rs':da[10],
                            'lg':da[19]*1.e-12, 'ld':da[20]*1.e-12, 'ls':da[18]*1.e-12,
                            'c11':da[27]*1.e-12, 'c22':da[28]*1.e-12, 'cpg':da[16]*1.e-12,
                            'cpd':da[17]*1.e-12, 'ugw':da[2], 'ngf':da[3] }
                        self.set_fixed( **fixed )
                    
                    data = { 'vds':da[4], 'vgs':da[7], 'ids':da[5]*1.e-3,
                    'igs':da[8]*1.e-3, 'ri':da[12], 'cgs':da[13]*1.e-12,
                    'cgd':da[14]*1.e-12, 'cds':da[15]*1.e-12, 'ggs':da[21]*1.e-3,
                    'ggd':da[22]*1.e-3, 'gm':da[23]*1.e-3, 'gds':da[25]*1.e-3,
                    'tau':da[24]*1.e-12, 'tau2':da[26]*1.e-12}
                    if da[8] > 0:
                        data['vdsi'] = da[4]-da[5]*1e-3*da[11]-(da[5]+da[8])*1e-3*da[10]
                        data['vgsi'] = da[7]-da[8]*1e-3*da[9]-(da[5]+da[8])*1e-3*da[10]
                    else:
                        data['vdsi'] = da[4]-da[5]*1e-3*da[10]-(da[5]-da[8])*1e-3*da[11]
                        data['vgsi'] = da[7]-da[8]*1e-3*da[9]-da[5]*1e-3*da[10]
                    if n == 31:
                        data['vv'] = da[29]
                        data['ii'] = da[30]
                    
                    # push the data into the data set
                    self.append(self.IntrinsicFET(**data))
                    
                line = f.readline()
        finally:
            if closefile: f.close()
        
    def set_fixed(self, **kwargs):
        """Set values of fixed parameters."""
        for k in kwargs:
            if k in self.__fixed:
                self.__fixed[k] = float(kwargs[k])
    
    def __getattr__(self,name):
        if name in self.__fixed:
            return self.__fixed[name]
        raise AttributeError(name)

