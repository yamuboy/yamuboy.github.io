from __future__ import unicode_literals, absolute_import, division, print_function
from .dscrreader import read_dscr_file, DSCRModel
from datetime import datetime
import numpy as np
from .. import _str_type

def dscr_models_to_mdif( model_list, header=None, outname='composite.mdf', indexby='vgs',
        blockname='FETMODEL', **kwargs ):
    """Take a sequence of DSCRModel objects and turn them into a composite
    generic MDIF file that is indexed by pinch-off, Vds, and Vgs or Ids.
    
    models is a sequence of file names (strings) or DSCRModel objects
    
    Keywords:
    header is a string or list/tuple of strings to write at the top of the
      output file, if this is not specified then a generic header will be written
    outname is the name of the output file
    indexby is the name of the parameter to use as the innermost independent
      variable - only 'vgs' and 'ids' are valid values
    blockname is the name of the data block in the MDIF file
    directory is a string denoting the directory from which to read the models
      in the case when model_list is a sequence of strings
    
    """
    # parameter order, indexed by vgs as the inner independent variable
    param_list_vgs = ('vgs','ids','igs','rg','rd','rs','ri',
        #'cgs','cgd','cds','gm','tau','gds','tau2','lg','ld','ls','ggs','ggd',
        'cgs','cgd','cds','gm','tau','gds','tau2','ggs','ggd',
        'c11','c22','cpg','cpd','vv','ii')
        
    # parameter order, indexed by ids as the inner independent variable
    param_list_ids = ('ids','vgs','igs','rg','rd','rs','ri',
        #'cgs','cgd','cds','gm','tau','gds','tau2','lg','ld','ls','ggs','ggd',
        'cgs','cgd','cds','gm','tau','gds','tau2','ggs','ggd',
        'c11','c22','cpg','cpd','vv','ii')
    
    # error checking
    if not model_list:
        raise ValueError("The 'model_list' parameter is empty.")
    elif isinstance(model_list,_str_type):
        raise TypeError("The 'model_list' parameter must be a sequence.")
    try:
        iter(model_list)
    except:
        raise TypeError("The 'model_list' parameter must be a sequence.")
    if indexby not in ('vgs','ids'):
        raise ValueError("The 'indexby' parameter is invalid.")
    
    models = []
    if not isinstance(model_list[0],DSCRModel):
        # load models and scale them
        mlist = _load_dscr_models(model_list,**kwargs)
        for m in mlist:
            models.append( m.scalecopy(ugw=100.0, ngf=10.0) )
    else:
        # or just scale them
        for m in model_list:
            models.append( m.scalecopy(ugw=100.0, ngf=10.0) )
    
    n_models = len(models)
    m0 = models[0]
    # coerce m0 model temperature as necessary
    if abs(m0['temp']-27.0) < 0.001:
        m0['temp'] = 25.0
    
    # verify that the models all jive
    # all of the models must match in the following ways:
    #  - temperatures are the same
    #  - the has_noise flag is the same
    for i in range(1,n_models):
        if bool(m0.has_noise) != bool(models[i].has_noise):
            raise ValueError("Model with index %d does not match model 0 (noise)." % i)
        # coerce temperatures of 27 C to 25 C
        if abs(models[i]['temp']-27.0) < 0.001:
            models[i]['temp'] = 25.0
        if abs(m0['temp']-models[i]['temp']) > 0.001:
            raise ValueError("Model with index %d does not match model 0 (temperature)." % i)
    
    # use the Vds values from the m0 model
    vds_list = m0.vds_values
    for i in range(1,n_models):
        # remove Vds values that are not present in other models
        vdl = models[i].vds_values
        for j,v in enumerate(vds_list[:]):
            found=False
            for v2 in vdl:
                if abs(v-v2) < 0.001:
                    found=True
                    break
            if not found:
                del vds_list[j]
        
    # remove Vds = 0 for models indexed by Ids
    if indexby == 'ids':
        for j,v in enumerate(vds_list[:]):
            if abs(v) < 0.001:
                del vds_list[j]
                break
            
    if not len(vds_list):
        raise ValueError("No common Vds values could be determined.")
        
    # create an inner list of independent values for Vgs or Ids for each Vds
    inner_list = []
    for i,vds in enumerate(vds_list):
        if indexby == 'ids':
            inner_list.append( _find_common_ids_values(models, vds) )
        else:
            inner_list.append( _find_common_vgs_values(models, vds) )
    
    # sort the models by increasing pinch-off
    if n_models > 1:
        for i in range(0,n_models-1):
            for j in range(i+1,n_models):
                if models[j].vpo < models[i].vpo:
                    m = models[j]
                    models[j] = models[i]
                    models[i] = m
    
    ### begin creating the generic MDIF file ###
    f = open(outname, 'w')
    try:
        # write the header
        if header:
            if isinstance(header,_str_type):
                f.write(header)
                # make sure the header ends in a '\n'
                if header[-1:] != '\n': f.write('\n')
            else:
                # assume that the header is a list/tuple of strings
                for line in header:
                    f.write(line)
                    # make sure each line ends in a '\n'
                    if line[-1:] != '\n': f.write('\n')
            f.write('!\n')
        else:
            # write a generic header
            f.write('!\n! Summary Created: %s\n!\n' % datetime.now().strftime('%Y/%m/%d %H:%M:%S') )
        
        # add extra header lines with information about each model
        f.write('! ---------------- Model Table -------------------\n')
        f.write('!    Vpo     Idss     Imax     Vbr1     Vbr2    Vpo3V   Vpo1.5V  Vpo1mA      Ron        Wafer      Size   Loc.   Orig. DSCR Name\n')
        #        ! xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxxxxxx xxxxxxxxx xxxxx  xxxxx...
        for m in models:
            dsize = '%dx%.1f' % (m['last_ngf'],m['last_ugw'])
            f.write("! %8.3f %8.1f %8.1f %8.2f %8.2f %8.3f %8.3f %8.3f %8.3f %12s %9s %5s  %s\n" %
                (m['vpo'],m['idss'],m['imax'],m['vbr1'],m['vbr2'],m['vpo3'],m['vpo1p5'],m['vpo1ma'],m['ron'],m['wafer'],dsize,m['device'],m['filename']) )
        f.write("!\n")
        
        #
        # add information about the composite model
        has_noise = -1
        if bool(m0.has_noise): has_noise = 1
        f.write('! Device scaling and use information.\n')
        f.write('BEGIN FILEINFO\n')
        f.write('% index(0) Ngf(0) Ugw(1) Temp(1) Noise(0)\n')
        f.write('     1     %2d    %5.1f   %4.1f   %d\n'%(10,100.0,m0['temp'],has_noise) )
        f.write('END\n')
        
        # for each model in the list
        for m in models:
            if n_models > 1:
                f.write("!\n! ####################### Start of Model for Vpo = %.3f #######################\n" % m.vpo)
            # compute each of the bias point models and write them
            for i,vds in enumerate(vds_list):
                # write the outer independent variables
                f.write("!\n")
                if n_models > 1:
                    f.write("VAR Vpo(1) = %.3f\n" % m.vpo)
                f.write("VAR Vds(1) = %.2f\n" % vds)
                # write the block
                f.write("BEGIN %s\n" % blockname)
                # write the MDIF data header
                if indexby == 'ids':
                    _write_mdif_header(f,param_list_ids)
                else:
                    _write_mdif_header(f,param_list_vgs)
                
                # compute and write the model parameters for each bias
                # within this Vds
                for vg_id in inner_list[i]:
                    if indexby == 'ids':
                        d = m.get_data(vds, ids=vg_id)
                        _write_model_data(f,d,param_list_ids)
                    else:
                        d = m.get_data(vds, vgs=vg_id)
                        _write_model_data(f,d,param_list_vgs)
                f.write("END\n")
    finally:
        f.close()
    
def _load_dscr_models( fnames, directory=None, **kwargs ):
    """Load a set of DSCRModel objects be reading 1 or more .dscr files.
    
    fnames is a sequence of file names (strings) to read
    
    Returns a tuple of DSCRModel objects.
    """
    models = []
    for fn in fnames:
        # load each file
        m,header = read_dscr_file(fn)
        models.extend(m)
    
    return tuple(models)
    
def _write_mdif_header( f, plist ):
    """Write the MDIF header line for a model block."""
    f.write('%    ')
    for p in plist:
        # create the parameter string in Title Case and add the MDIF parameter
        # type specifier for real-valued parameters (1)
        f.write(' %10s   ' % (p.title()+'(1)') )
    f.write('\n')
        
def _write_model_data( f, m, plist ):
    """Write a single set of model data."""
    f.write('     ')
    for p in plist:
        f.write(' %13.4e' % m[p])
    f.write('\n')

def _find_common_ids_values( models, vds ):
    """Find a set of Ids values to use when writing model data."""
    
    # determine a common min and max Ids
    mn = 1.9
    mx = 100000.0
    for i,m in enumerate(models):
        idl = m.get_ids_values(vds)
        if not len(idl):
            raise ValueError('Model %d: No Ids values for Vds=%.2f'%(i,vds))
        mn1 = min(idl)
        mx1 = max(idl)
        if mn1 > mn: mn = mn1
        if mx1 < mx: mx = mx1
    
    # create a list of Ids values using the min and max as boundaries
    # the default small step size is 5.0 and the large step size is 30.0
    id_list = []
    small = 5.0
    large = 30.0
    
    # start value
    val = math.ceil(mn)
    last = math.floor(mx)
    i = 0
    while val < last and val < (large - 0.5*small):
        id_list.append(val)
        if i > 1:
            val += 2.0*small
        else:
            val += small
        i += 1
    val = large
    while val < last:
        id_list.append(val)
        val += large
    
    # add a final point if the previous point is more than 20% of the large step
    # away from the max value from the 
    if (val-large) < (last-0.2*large):
        id_list.append(last)
    
    if not len(id_list):
        raise ValueError('Unable to find a common set of Ids values.')
    
    return tuple(id_list)
    
    
def _find_common_vgs_values( models, vds ):
    """Find a set of Vgs values to use when writing model data."""
    
    # determine a common min and max Vgs and a step size
    mn = -100000.0
    mx = 100000.0
    st = 100000.0
    mpo = 1000.0
    
    for i,m in enumerate(models):
        vgl = m.get_vgs_values(vds)
        if not len(vgl):
            raise ValueError('Model %d: No Vgs values for Vds=%.2f'%(i,vds))
        mn1 = min(vgl)
        mx1 = max(vgl)
        if mn1 > mn: mn = mn1
        if mx1 < mx: mx = mx1
        
        # find the step size
        if len(vgl) > 1:
            st1 = abs(vgl[-1]-vgl[-2])
        if st1 < st: st = st1
        
        # find the minimum pinch-off
        if m.vpo < mpo: mpo = m.vpo
        
    if abs(vds) < 0.001:
        # special case for Vds=0
        val = mx
        vg_list = []
        while val > mpo - 2.1*st and val >= mn:
            vg_list.append(val)
            val -= st
        while val >= mn:
            vg_list.append(val)
            val -= 3.0*st
        vg_list.sort()
        
    else:
        vg_list = np.arange(mn,mx+0.001,st)
        
    return tuple(vg_list)

