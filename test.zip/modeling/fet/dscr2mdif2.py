from __future__ import unicode_literals, absolute_import, division, print_function
from .dscrreader import read_dscr_file, DSCRModel
from ..splines import natural_cubic_spline, cubic_spline_solve
from datetime import datetime
import numpy as np
import logging
import math
from io import StringIO
from .. import _str_type
from functools import cmp_to_key
if not hasattr(__builtins__,'cmp'):
    # python3 hack
    cmp = lambda a, b: (a > b)-(a < b)  

# parameter order, indexed by vgs as the inner independent variable
PARAM_LIST_VGS = ('vgs','mamm','ids','igs','ri','cgs','cgd','cds','gm','tau','gds','tau2','ggs','ggd','vv','ii')

# parameter order, indexed by ids(mA/mm) as the inner independent variable
PARAM_LIST_IDS = ('mamm','vgs','ids','igs','ri','cgs','cgd','cds','gm','tau','gds','tau2','ggs','ggd','vv','ii')

_log = logging.getLogger('modeling.dscr2mdif')

def dscr_models_to_mdif( model_list, outname='composite.mdf', header=None, 
        infoblockname='MODELINFO', vgsblockname='VGSDATA', idsblockname='IDSDATA',
        alignvds=False, multitemp=False, mixednoise=False, vgsblocks=True,
        idsblocks=True, common_header=None, ids_mamm_max_step=20.0,
        ids_mamm_threshold=1.0 ):
    """Take a sequence of DSCRModel objects and turn them into a composite
    generic MDIF file that is indexed by model index, Vds, and Vgs or Ids.
    
    models is a sequence of file names (strings) or DSCRModel objects
    
    Keywords:
    outname - the name of the output file
    header - a string or list/tuple of strings to write at the top of the
       output file, if this is not specified then a generic header will be written
    infoblockname - the name of the model info data block in the MDIF file
    vgsblockname - the name of the data blocks in the MDIF file that are
       indexed by Vgs value
    idsblockname - the name of the data blocks in the MDIF file that are
       indexed by Ids (in mA/mm) value
    alignvds - force all of the data blocks in the file to have aligned
       Vds values
    multitemp - allow multiple temperatures, this will change the sorting
       algorithm of the models and will group common temperatures together
       and sort them in ascending temperature order
    mixednoise - allow models that have noise data to be mixed in with those
       that do not have noise data
    vgsblocks - write Vgs data blocks
    idsblocks - write Ids data blocks
    common_header - a string or list/tuple of strings to write at the top of the
       output file, before any other header data is written
    """
    def _vpo_sort(a,b):
        """sort a list of the models by increasing pinch-off"""
        return cmp(a['vpo'],b['vpo'])

    # error checking
    if not isinstance(model_list,(list,tuple)):
        raise TypeError("'model_list' parameter must be a list or tuple")
    elif not len(model_list):
        raise ValueError("'model_list' parameter is empty")
                    
    models = []
    for i,m in enumerate(model_list):
        if isinstance(m,DSCRModel):
            models.append(m)
        elif isinstance(m,_str_type):
            # load models and scale them
            models.extend(_load_dscr_models([m]))
        else:
            raise TypeError("'model_list' value at index %d is not a DSCRModel object or a filename"%i)
        
    n_models = len(models)
    if not n_models:
        raise ValueError("no models are available for processing")
    
    # adjust temperatures (set those at 27C to 25C)
    for m in models:
        if abs(m['temp']-27.0) < 0.001:
            m['temp'] = 25.0    
    
    if multitemp:
        ##### multi temperature mode #####
        
        # split the models up by temperature
        tempsort = {}
        for m in models:
            t = m['temp']
            if t not in tempsort:
                tempsort[t] = []
            tempsort[t].append(m)
        
        # sort each group by increasing pinch-off
        for grp in tempsort.values():
            grp.sort(key=cmp_to_key(_vpo_sort))
        
        # sort the groups by increasing temperature
        m2 = []
        tl = tempsort.keys()
        tl.sort()
        for t in tl:
            m2.extend(tempsort[t])
        models = m2

        # use the first model as the comparison reference
        m0 = models[0]    
        for i in range(1,n_models):
            # check the "noise" status of the model
            if not mixednoise and (bool(m0.has_noise) != bool(models[i].has_noise)):
                raise ValueError("model noise states do not match and 'mixednoise' mode is disabled")
                
    else:
        ##### single temperature mode #####
        
        # sort by increasing pinch-off
        models.sort(key=cmp_to_key(_vpo_sort))
    
        # use the first model as the comparison reference
        m0 = models[0]    
        for i in range(1,n_models):
            # check the temp
            if abs(m0['temp']-models[i]['temp']) > 0.001:
                raise ValueError("model temperatures do not match and 'multitemp' mode is disabled")
            # check the "noise" status of the model
            if not mixednoise and (bool(m0.has_noise) != bool(models[i].has_noise)):
                raise ValueError("model temperatures do not match and 'mixednoise' mode is disabled")

    vds_list = None
    if alignvds:
        # start with the Vds values from the first model and
        # then remove Vds values not present in other models 
        vds_list = models[0].vds_values
        for i in range(1,n_models):
            toremove = []
            for j,v in enumerate(vds_list):
                found=False
                for v2 in models[i].vds_values:
                    if abs(v-v2) < 0.001:
                        found=True
                        break
                if not found:
                    toremove.append(j)
            if toremove:
                for j in reversed(toremove):
                    del vds_list[j]
            
    # create StringIO objects to hold the vgs and ids block data
    # this is so that errors generated there do not result in partial
    # data file writes
    sumf = StringIO()
    vgsf = StringIO()
    idsf = StringIO()
    
    ##### generate header and modelinfo data ####
    
    # write the common header if it exists
    if common_header:
        if isinstance(common_header,_str_type):
            sumf.write(common_header)
            # make sure the header ends in a '\n'
            if common_header[-1:] != '\n':
                sumf.write('\n')
        else:
            # assume that the header is a list/tuple of strings
            for line in common_header:
                sumf.write(line)
                # make sure each line ends in a '\n'
                if line[-1:] != '\n':
                    sumf.write('\n')
    
    # write the header
    if header:
        if isinstance(header,_str_type):
            sumf.write(header)
            # make sure the header ends in a '\n'
            if header[-1:] != '\n':
                sumf.write('\n')
        else:
            # assume that the header is a list/tuple of strings
            for line in header:
                sumf.write(line)
                # make sure each line ends in a '\n'
                if line[-1:] != '\n':
                    sumf.write('\n')
        sumf.write('!\n')
    else:
        # write a generic header
        sumf.write('!\n! Summary Created: %s\n!\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    
    # add extra header lines with information about each model
    sumf.write('! ---------------- Model Table -------------------\n!\n')
    sumf.write('! No.    Size     Vpo     Idss     Imax     Vbr1     Vbr2     Vpo3V   Vpo1.5V  Vpo1mA     Ron        Wafer    Loc.   Orig. DSCR Name\n')
    #        ! xx xxxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxxxxxx xxxxx  xxxxx...
    for i,m in enumerate(models):
        dsize = '%dx%g' % (m['ngf'],m['ugw'])
        sumf.write("! %2d %9s %8.3f %8.1f %8.1f %8.2f %8.2f %8.3f %8.3f %8.3f %8.3f %12s %5s  %s\n" %
            ((i+1),dsize,m['vpo'],m['idss'],m['imax'],m['vbr1'],m['vbr2'],m['vpo3'],m['vpo1p5'],m['vpo1ma'],m['ron'],m['wafer'],m['device'],m['filename']) )
    sumf.write("!\n")
    
    #
    # add information about the composite model
    sumf.write('! ++++++++ Device scaling and use information ++++++++\n!\n')
    sumf.write('BEGIN %s\n'%infoblockname)
    plist = ('rg','rd','rs','lg','ld','ls','c11','c22')
    sumf.write('% index(0) Ngf(0) Ugw(1) Temp(1) Noise(0)')
    for p in plist:
        sumf.write(' %10s   '%(p.title()+'(1)'))
    sumf.write('\n')
    for i,m in enumerate(models):
        has_noise = 0
        if m.has_noise:
            has_noise = 1
        parms = m.get_index(0)
        sumf.write('   %2d     %2d    %5.1f   %4.1f   %d'%(i+1,m['ngf'],m['ugw'],m['temp'],has_noise))
        for p in plist:
            sumf.write(' %13.4e'%parms[p])            
        sumf.write('\n')
    sumf.write('END\n')

    ##### generate Vgs and Ids model blocks #####

    for i,m in enumerate(models):
        if vgsblocks:
            _generate_model_blocks(vgsf,m,i+1,'vgs',vgsblockname,vds_list,ids_mamm_max_step,ids_mamm_threshold)
        if idsblocks:
            _generate_model_blocks(idsf,m,i+1,'ids',idsblockname,vds_list,ids_mamm_max_step,ids_mamm_threshold)
        
    ##### write the data out to the real data file #####
    
    fpout = open(outname,'w')
    try:
        # write header info
        fpout.write(sumf.getvalue())
        sumf.close()
        # write the model blocks indexed by Vgs
        fpout.write(vgsf.getvalue())
        vgsf.close()
        # write the model blocks indexed by Ids
        fpout.write(idsf.getvalue())
        idsf.close()
    
    finally:
        fpout.close()

    
def _generate_model_blocks(f, model, modelnum, indexby, blockname, vds_list, ids_mamm_max_step, ids_mamm_threshold ):
    """subroutine to generate blocks"""
    
    if vds_list is not None:
        # copy vds_list
        vds_list = vds_list[:]
    else:
        vds_list = model.vds_values
    
    if indexby == 'ids':
        plist = PARAM_LIST_IDS
        # remove Vds = 0 for models indexed by Ids
        for j,v in enumerate(vds_list[:]):
            if abs(v) < 0.005:
                del vds_list[j]
                break
    else:
        plist = PARAM_LIST_VGS
                
    # write the data blocks    
    f.write("!\n! ####################### Start of Model %d (indexed by %s) #######################\n"%(modelnum,indexby.title()))
    # compute each of the bias point models and write them
    for i,vds in enumerate(vds_list):
        # write the outer independent variables
        f.write("!\n")
        f.write("VAR Modindex(0) = %d\n"%modelnum)
        f.write("VAR Vds(1) = %.2f\n"%vds)
        # write the block
        f.write("BEGIN %s\n" % blockname)
        # write the MDIF data header
        _write_mdif_header(f,plist)
        
        # get raw values from the model
        rawdata = model.get_rawdata_block(vds)
        if not rawdata:
            _log.debug("_generate_model_blocks(): model #%d: no raw data for vds = %g"%vds) 
            continue
        
        idata = _interpolate_data(rawdata,indexby,ids_mamm_max_step,ids_mamm_threshold)
            
        if not idata:
            _log.debug("_generate_model_blocks(): model #%d: no data for vds = %g (after interpolation)"%vds) 
        else:
            for d in idata:
                _write_model_data(f,d,plist)
            
        f.write("END\n")

        
def _generate_extra_vgs_values( low, high, max_mamm_step ):
    "generate extra vgs steps"
    v1 = low['vgs']
    v2 = high['vgs']
    i1 = low['mamm']
    i2 = high['mamm']
    
    if i2 - i1 > max_mamm_step:
        n = int(math.ceil((i2-i1)/max_mamm_step))
        if n < 2:
            ret = [v2]
        else:
            ret = []
            step = (v2-v1)/float(n)
            for j in range(1,n):
                ret.append(v1+j*step)
            ret.append(v2)            
    else:
        ret = [v2]
    
    return ret

def _interpolate_data( rawdata, indexby, ids_mamm_max_step=20.0, ids_mamm_threshold=1.0 ):
    "interpolate the models to a new vgs_step"
    if len(rawdata) < 3:
        return rawdata
        
    # verify that the raw data is sorted by increasing Vgs
    _vgs_sort_func = lambda a, b: cmp(a['vgs'],b['vgs'])
    rawdata.sort(key=cmp_to_key(_vgs_sort_func))
        
    if indexby == 'ids':
        # if the indexby mode is 'ids', trim out values that are
        # less than zero or not monotonic so we can generate proper vgs values
        tlst = []
        lastids = -10000000.0
        for k,d in enumerate(rawdata):
            if d['ids'] < 0.0 or d['ids'] < lastids:
                tlst.append(k)
            else:
                lastids = d['ids']
        if tlst:
            for k in reversed(tlst):
                del rawdata[k]
        
    if abs(rawdata[0]['vds']) < 0.01:
        # no interpolation for Vds == 0
        vgs_list = [x['vgs'] for x in rawdata]
    else:
        # generate extra Vgs values to fill in large gaps in the Ids(mA/mm) data
        i = 0
        vgs_list = []
        while i < len(rawdata) and rawdata[i]['mamm'] <= ids_mamm_threshold:
            # add values below pinch off
            vgs_list.append(rawdata[i]['vgs'])
            i += 1
        
        while i < len(rawdata):
            # create extra vgs points
            if i > 0:
                vgs_list.extend(_generate_extra_vgs_values(rawdata[i-1],rawdata[i],ids_mamm_max_step))                
            i += 1
        
    # create the output dataset
    out = []
    for vgs in vgs_list:
        out.append( {'vgs':vgs} )
    parms = rawdata[0].keys()
    del parms[parms.index('vgs')]
    
    # interpolate the data
    vgsin = [x['vgs'] for x in rawdata]
    for p in parms:
        # generate the spline data
        y = [x[p] for x in rawdata]        
        spline = natural_cubic_spline(vgsin,y)
        # compute the parameter values
        for i,vgs in enumerate(vgs_list):
            out[i][p] = cubic_spline_solve(spline,vgs)
    
    # trim negative and decreasing ids values
    # this can happen due to the cubic spline
    if abs(rawdata[0]['vds']) > 0.01:
        tlst = []
        lastids = -10000000.0
        for k,d in enumerate(out):
            if d['ids'] < 0.0 or d['ids'] < lastids:
                tlst.append(k)
            else:
                lastids = d['ids']
        if tlst:
            for k in reversed(tlst):
                del out[k]
    
    return out
    
        
def _load_dscr_models( fnames, directory=None ):
    """Load a set of DSCRModel objects be reading 1 or more .dscr files.
    
    fnames is a sequence of file names (strings) to read
    
    Returns a list of DSCRModel objects.
    """
    models = []
    for fn in fnames:
        # load each file
        m,header = read_dscr_file(fn)
        models.extend(m)
    
    return models
    
def _write_mdif_header( f, plist ):
    """Write the MDIF header line for a model block."""
    f.write('%    ')
    for p in plist:
        # create the parameter string in Title Case and add the MDIF parameter
        # type specifier for real-valued parameters (1)
        f.write(' %10s   ' % (p.title()+'(1)') )
    f.write('\n')
        
def _write_model_data( f, m, plist ):
    """Write a single set of model data."""
    f.write('     ')
    for p in plist:
        f.write(' %13.4e' % m[p])
    f.write('\n')

def _find_common_ids_values( models, vds ):
    """Find a set of Ids values to use when writing model data."""
    
    # determine a common min and max Ids
    mn = 1.9
    mx = 100000.0
    for i,m in enumerate(models):
        idl = m.get_ids_values(vds)
        if not len(idl):
            raise ValueError('Model %d: No Ids values for Vds=%.2f'%(i,vds))
        mn1 = min(idl)
        mx1 = max(idl)
        if mn1 > mn: mn = mn1
        if mx1 < mx: mx = mx1
    
    # create a list of Ids values using the min and max as boundaries
    # the default small step size is 5.0 and the large step size is 30.0
    id_list = []
    small = 5.0
    large = 30.0
    
    # start value
    val = math.ceil(mn)
    last = math.floor(mx)
    i = 0
    while val < last and val < (large - 0.5*small):
        id_list.append(val)
        if i > 1:
            val += 2.0*small
        else:
            val += small
        i += 1
    val = large
    while val < last:
        id_list.append(val)
        val += large
    
    # add a final point if the previous point is more than 20% of the large step
    # away from the max value from the 
    if (val-large) < (last-0.2*large):
        id_list.append(last)
    
    if not len(id_list):
        raise ValueError('Unable to find a common set of Ids values.')
    
    return id_list
    
    
def _find_common_vgs_values( models, vds ):
    """Find a set of Vgs values to use when writing model data."""
    
    # determine a common min and max Vgs and a step size
    mn = -100000.0
    mx = 100000.0
    st = 100000.0
    mpo = 1000.0
    
    for i,m in enumerate(models):
        vgl = m.get_vgs_values(vds)
        if not len(vgl):
            # silently ignore
            continue
        mn1 = min(vgl)
        mx1 = max(vgl)
        if mn1 > mn: mn = mn1
        if mx1 < mx: mx = mx1
        
        # find the step size
        if len(vgl) > 1:
            st1 = abs(vgl[-1]-vgl[-2])
        if st1 < st: st = st1
        
        # find the minimum pinch-off
        if m.vpo < mpo: mpo = m.vpo
        
    if abs(vds) < 0.001:
        # special case for Vds=0
        val = mx
        vg_list = []
        while val > mpo - 2.1*st and val >= mn:
            vg_list.append(val)
            val -= st
        while val >= mn:
            vg_list.append(val)
            val -= 3.0*st
        vg_list.sort()
    else:
        vg_list = np.arange(mn,mx+0.001,st)
        
    return vg_list

