from __future__ import unicode_literals, absolute_import, division, print_function
from ...file_utils import EndFile
from ..ivdata import IVData
from ..parker_model import ParkerModel, CTOK, Q_ELECTRON, BOLTZMANN
from ..ssdata import FET_SS_Data
from ...linefit import linefit_mxb
from ...optimize import BasicEngine, get_worker
import math
import logging



class ParkerExtract(object):
    """Extract Parker large-signal models.
    
    Expected use of this class:
        
        # create extraction object
        xtr = ParkerExtract()
        
        # read data files
        xtr.read_param_file()
        xtr.read_data_files()
        
        # run extractions, loop as necessary
        xtr.extract_dciv()
        xtr.extract_qg()
        # ....
        
        # write files
        xtr.write_param_file()
        xtr.write_model()
        
    """
    def __init__(self, **kwargs):
        """Create the extraction object."""
        # create the model object
        self.model = ParkerModel()
        
        # create a log target
        self._log = logging.getLogger('modeling.fet.extract.ParkerExtract')
        
        # create the config object and read initial parameters
        self.read_config_file(kwargs.get('cfgfile','fetmod.cfg'))
        
        # initialize data storage
        self.__modelfile = None
        self.__ssdata = None
        self.__ivdata = None
        self.__fwddata = None
        self.__vbrdata = None
        self.__initial = False
    
    
        
    
    def write_model(self, fname=None):
        """Write the parker model to a ModelMDIF format file."""
        
        if fname is None:
            fname = self._cfg['output_model_fname']
        
        # create a list of parameters to write
        params = [ ('area',self.model['ugw'].v*self.model['ngf'].v), ]
        
        # add model parameters to the list
        modparams = ('ugw','ngf','tnom','rg','rd','rs','lg','ld','ls',
            'c11','c22','cpg','cpd','is','n','ibd','vbd','ileak','vleak','ri','taug','taud',
            'vbi','beta','vto','p','delta','q','vst','mvst','xi','mxi',
            'lambda','z','lfgam','lfg1','lfg2','hfgam','hfg1','hfg2','hfeta',
            'hfe1','hfe2','cgs','cgd','fc','xc','acgam','cds','tau','tm',
            'vhr','mvhr','vht','etah',
            )
        for name in modparams:
            params.append( (name,self.model[name].v) )
        
        # generate a header
        if self.__fwddata and self.__fwddata.header:
            h = self.__fwddata.header
        h += 'VAR Model(1) = 1\n'
        
        # write the model MDIF data
        write_model_mdif(fname,params,header=h)
        
    
    
    def read_data_files(self):
        """Read measured data and small-signal model data files."""
        ss_fname = self._cfg['ssmodel_fname']
        iv_fname = self._cfg['dciv_fname']
        fwd_fname = self._cfg['fwdiv_fname']
        vbr_fname = self._cfg['vbriv_fname']
        piv_fname = self._cfg['piv_fname']
        if len(ss_fname):
            self.__ssdata = FET_SS_Data(fname=ss_fname)
            self.__ssdata.sort()
        if len(iv_fname):
            self.__ivdata = IVData(fname=iv_fname)
        if len(fwd_fname):
            self.__fwddata = IVData(fname=fwd_fname)
        if len(vbr_fname):
            self.__vbrdata = IVData(fname=vbr_fname)
        if len(piv_fname):
            self.__pivdata = IVData(fname=piv_fname, colorder=('vgs','vds','ids','igs','ignore','ignore'))
              

              
              
              
    def extract_initial(self):
        """Do initial extraction operations that do not generally need to be
        repeated more than once (unless options/switches/files are modified)
        """
        if not self._cfg:
            raise RuntimeError("Config file has not been read.")
        if not self.__ssdata:
            raise RuntimeError("Small-signal data file has not been read.")
        if not self.__fwddata:
            raise RuntimeError("Forward I-V data file has not been read.")
        
        # read values from the header of the fwd I-V data file
        # and use them to set the some values for model parameters
        if self.__fwddata.header is None:
            raise RuntimeError("Forward I-V data file header is invalid.")
        hlines = self.__fwddata.header.split('\n')
        found = False
        for j,ln in enumerate(hlines):
            if ln.startswith('!Vbr (.1'):
                dcdata = hlines[j+1][1:].split()
                vpo = float(dcdata[3])
                vmax = float(dcdata[6])
                self.model['vto'].v = vpo
                self.model['vto'].set_opt_range(vpo-0.1,vpo+0.1) 
                self.model['vbi'].v = vmax
                found = True
            elif ln.startswith('!TEMPERATURE'):
                tnom = float(ln[18:])
                if 24.9 < tnom < 27.1:
                    tnom = 25.0
                self.model['tnom'].v = tnom
        
        if not found:
            self._log.warning("Vpo and Vmax could not be read from Fwd I-V data file.")
                    
        # extract model parameters from the small-signal data
        self.model['ugw'].v = self.__ssdata.ugw
        self.model['ngf'].v = self.__ssdata.ngf
        self.model['rg'].v = self.__ssdata.rg
        self.model['rd'].v = self.__ssdata.rd
        self.model['rs'].v = self.__ssdata.rs
        self.model['lg'].v = self.__ssdata.lg
        self.model['ld'].v = self.__ssdata.ld
        self.model['ls'].v = self.__ssdata.ls
        self.model['c11'].v = self.__ssdata.c11
        self.model['c22'].v = self.__ssdata.c22
        self.model['cpg'].v = self.__ssdata.cpg
        self.model['cpd'].v = self.__ssdata.cpd
        
        # average Ri over the target region
        reg = self._cfg['target_region']
        periph = self.model['ugw'].v*self.model['ngf'].v
        ds = self.__ssdata.filter(vdsrange=reg[0:2], idsrange=(reg[2]*periph*1.e-6,reg[3]*periph*1.e-6))
        if not len(ds):
            raise RuntimeError("Target fit region contains no small-signal data points.") 
        ri = 0.0
        for p in ds:
            ri += p.ri
        self.model['ri'].v = ri / float(len(ds))
        
        # initial extraction done
        self.__initial = True
        
    def extract_ig(self):
        """Extract gate current model parameters."""
        if not self.__initial:
            raise RuntimeError("Initial extraction has not been completed.")
        
        # initialize the model parameters to values that disable both
        # fwd and reverse current
        self.model['is'].v = 0.0
        self.model['n'].v = 1.0
        self.model['ibd'].v = 0.0
        self.model['vbd'].v = 1.0
        self.model['ileak'].v = 0.0
        self.model['vleak'].v = 1.0
        
        # at a minimum, forward diode measurements are needed
        if not self.__fwddata:
            self._log.warning("Diode forward I-V data has not been read yet.")
            return
            
        vgs,igs = [],[]
        for p in self.__fwddata[-6:]:
            igs1 = p.igs + p.ids
            if igs1 > 0:
                vgs.append(p.vgs - p.igs*self.model['rg'].v - igs1*self.model['rs'].v)
                igs.append(math.log(igs1))
        if len(vgs) < 2:
            self._log.error("Not enough points for forward diode fit.")
        else:
            m, b, r2 = linefit_mxb(vgs, igs)
            self.model['is'].v = 0.5*math.exp(b)  
            self.model['n'].v = Q_ELECTRON/(m*BOLTZMANN*(self.model['tnom'].v+CTOK))
            
        if not self.__vbrdata:
            # reverse diode breakdown data is not present
            self._log.warning("Diode breakdown I-V data has not been read yet.")
            return
                        
        vdg,igs = [],[]
        for p in self.__vbrdata:
            if p.igs < 0:
                vdg.append(p.vds-p.vgs)
                igs.append(math.log(-p.igs))
        m,b,r2 = linefit_mxb(vdg[-2:], igs[-2:])
        self.model['ibd'] = math.exp(b)
        self.model['vbd'] = 1.0/m
        
        ##leakage
        """ don't extract leakage
        vbm = max(vdg)
        idx_leak = [i for i, v in enumerate(vdg) if v > 0.25*max(vdg) and v < 0.5*max(vdg)]
        self.vleak = [vdg[i] for i in idx_leak]
        self.ileak = [igs[i] for i in idx_leak]
        m, b, r2 = linefit_mxb(self.vleak, self.ileak)
        self.ileak = math.exp(b)
        self.vleak = 1.0/m
        return self.iss, self.n, self.ibd, self.vbd, self.ileak, self.vleak
        """
    
    def extract_dciv(self):
        """Extract DC-IV model parameters."""
        if not self.__initial:
            raise RuntimeError("Initial extraction has not been completed.")
        if not self.__ivdata:
            raise RuntimeError("I-V data has not been read yet.")
        
        params = ('beta', 'vto', 'p', 'q', 'xi', 'mxi','lambda', 
            'z', 'lfgam', 'lfg1', 'lfg2', 'tm', 'vhr','mvhr', 'vht')
                
        # get some configuration variables
        delta =  self._cfg['delta']
        self.model['delta'].v = delta
        
        # compute internal voltages and isothermal current for the data set
        for p in self.__ivdata:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.model['rg'].v,
                rd=self.model['rd'].v, rs=self.model['rs'].v)
            p.idsiso = p.ids * (1.0 + delta*p.vdsi*p.ids)
        
        # create weighted fitting regions
        self.__optdata = self._get_weighted_regions('dciv_fit_regions',self.__ivdata)
                
        # run the DC I-V optimization
        self._log.info("Starting DC I-V Optimization.")
        worker = get_worker('gradient')( self._dciv_erf, self.model.get_named_params(params) )
        engine = BasicEngine( worker=worker, iter=50, itercb=self.itercb )
        engine.optimize()
        self._log.info("DC I-V Final Error: %g" % engine.error)
        
        # filter and store the temporary subthreshold DC I-V optimization data set
        """ disable for now
        self.__optdata = self.__ivdata.filter(vgsrange=(None,self.model['vto'].v-0.01),
            vdsrange=(0.9,None),idsrange=(1e-6,None))
        # compute internal voltages for the data set
        # for IVPoint in IVData.list( IVPoint, IVPoint ...):
        for p in self.__optdata:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.__ssdata.rg,
                rd=self.__ssdata.rd, rs=self.__ssdata.rs)
        # run the subthreshold optimization
        self._log.info("Starting Subthreshold I-V Optimization.")
        worker = get_worker('gradient')( self._subth_erf, self.model.get_named_params( ('vst','mvst') ) )
        engine = BasicEngine( worker=worker, iter=50, itercb=self.itercb )
        engine.optimize()
        self._log.info("Subthreshold I-V Final Error: %g" % engine.error)
        """
        
        # delete the temporary optimization data set
        del self.__optdata
                
    def extract_gm_gds(self):
        """Extract gm and gds model parameters."""
        if not self.__initial:
            raise RuntimeError("Initial extraction has not been completed.")
        
        # get the default weight for the gds data set, the gm dataset defaults
        # to a weight of 1.0, so this can be used to increase or decrease
        # the weighting of the gds fit relative to gm
        gds_weight = self._cfg['gds_default_weight']
        
        params = ('hfgam','hfg1','hfg2','hfeta','hfe1','hfe2')
        
        # compute internal voltages for the small-signal dataset
        for p in self.__ssdata:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.model['rg'].v,
                rd=self.model['rd'].v, rs=self.model['rs'].v)

        optgm = self._get_weighted_regions('gm_fit_regions',self.__ssdata)
        optgds = self._get_weighted_regions('gds_fit_regions',self.__ssdata,default_weight=gds_weight)
        self.__optdata = _reconcile_regions(optgm,optgds)
                
        # run the optimization
        self._log.info("Starting RF gm/gds Optimization.")
        worker = get_worker('gradient')( self._gmgds_erf, self.model.get_named_params(params) )
        engine = BasicEngine( worker=worker, iter=100, itercb=self.itercb )
        engine.optimize()
        self._log.info("RF gm/gds Final Error: %g" % engine.error)
        
        # delete temporary data
        del self.__optdata
        
    def extract_qg(self):
        """Extract gm and gds model parameters."""
        if not self.__initial:
            raise RuntimeError("Initial extraction has not been completed.")
        
        # get the default weight for the cgd data set, the cgs dataset defaults
        # to a weight of 1.0, so this can be used to increase or decrease
        # the weighting of the cgd fit relative to cgs
        cgd_weight = self._cfg['cgd_default_weight']
        
        params = ('acgam','cgs','cgd','xc','fc',)
        
        # compute internal voltages for the small-signal dataset
        for p in self.__ssdata:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.model['rg'].v,
                rd=self.model['rd'].v, rs=self.model['rs'].v)
            
        optcgs = self._get_weighted_regions('cgs_fit_regions',self.__ssdata)
        optcgd = self._get_weighted_regions('cgd_fit_regions',self.__ssdata,default_weight=cgd_weight)
        self.__optdata = _reconcile_regions(optcgs,optcgd)
        
        # run the optimization
        self._log.info("Starting Gate Charge Optimization.")
        worker = get_worker('gradient')(self._charge_erf,self.model.get_named_params(params))
        engine = BasicEngine(worker=worker, iter=100, itercb=self.itercb)
        engine.optimize()
        self._log.info("Gate Charge Final Error: %g"%engine.error)
        
        # delete temporary data
        del self.__optdata        
        
        ### extract tau and cds, this should be done as part of the gate
        ### charge extraction since changes in gate charge parameters affect this...
        reg = self._cfg['target_region']
        periph = self.model['ugw'].v*self.model['ngf'].v
        ds = self.__ssdata.filter(vdsrange=reg[0:2], idsrange=(reg[2]*periph*1.e-6,reg[3]*periph*1.e-6))
        if not len(ds):
            raise RuntimeError("Target fit region contains no small-signal data points.") 
        cds, tau = 0.0, 0.0
        for p in ds:
            cgs, cgd, dqgs_vgd, dqgd_vgs = self.model.compute_qg(p.vgsi, p.vdsi)
            _, gm, gds = self.model.compute_ids(p.vgsi, p.vdsi)
            cds += p.cds
            tau += p.tau
        n = 1.0 / float(len(ds))
        self.model['cds'].v = cds * n
        self.model['tau'].v = tau * n
        
    def _dciv_erf(self):
        """Callback to compute dciv error during optimization"""
        e = 0.0
        for w,region in self.__optdata:
            for p in region:
                ids, _, _= self.model.compute_ids(p.vgsi, p.vdsi)
                e += w * (p.idsiso-ids) * (p.idsiso-ids)
        return e
   
    def _subth_erf(self):                                     
        """Callback to compute subthreshold dciv error during optimization"""
        e = 0.0
        i = 0
        for p in self.__optdata:
            ids, _, _= self.model.compute_ids(p.vgsi, p.vdsi)
            e += 1e6*(p.ids-ids)*(p.ids-ids)
            i += 1
        return e/i
   
    def _charge_erf(self):
        """Callback to compute cgs, cgd error during optimization"""
        e1 = 0.0
        e2 = 0.0
        for wcgs,wcgd,region in self.__optdata:
            for p in region:
                cgs, cgd, dqgs_vgd, dqgd_vgs = self.model.compute_qg(p.vgsi, p.vdsi)
                e1 += wcgs * (p.cgs-(cgs+dqgd_vgs)) * (p.cgs-(cgs+dqgd_vgs))
                e2 += wcgd * (p.cgd-(cgd+dqgs_vgd)) * (p.cgd-(cgd+dqgs_vgd))
        return e1+e2
    
    def _gmgds_erf(self):
        """Callback to compute gm, gds error during optimization"""        
        e1 = 0.0
        e2 = 0.0
        for wgm,wgds,region in self.__optdata:
            for p in region:
                _, gm, gds = self.model.compute_ids(p.vgsi, p.vdsi)
                e1 += wgm * (p.gm-gm) * (p.gm-gm)
                e2 += wgds * (p.gds-gds) * (p.gds-gds)
        return e1+e2
        
    def _get_weighted_regions(self, cfgvar, dataset, default_weight=1.0):
        """Get a list of 2-tuples defining regions of measured data to weight
        differently than the rest.
        """
        regions = self._cfg[cfgvar]
        if len(regions):
            # create a ConfigVars object to read the data for the
            # dciv fitting regions
            cv = ConfigVars()
            for r in regions:
                # each region must be a 5-tuple of floats
                cv.add(r, CF_FLOATTUPLE, length=(5,5))
            
            # read the region data from the config file
            reg = self.__cfgfile.get_variables(cv,section='parker')
            
            # create the dataset subsets
            periph = self.model['ugw'].v*self.model['ngf'].v
            retdata = []
            remain = dataset
            for r in regions:
                if len(reg[r]):
                    # a valid region existed in the config file
                    w = reg[r][0]
                    vds = reg[r][1:3]
                    ids = (reg[r][3]*periph*1.e-6,reg[r][4]*periph*1.e-6)
                    # segregate the data into the target region and the rest
                    d, remain = remain.segregate(vdsrange=vds, idsrange=ids)
                    # if the target region contains data, and it has a
                    # positive optimization weight, add it to the
                    # optimization data set
                    if w > 0.0 and len(d):
                        retdata.append( (w,d) )
            # add the rest of the data to the optimization data set with
            # the default weight
            if len(remain):
                retdata.append( (default_weight,remain) )
                
        else:
            # in absense of regions, return the whole dataset with equal weighting 
            retdata = ( (default_weight, dataset), )
        
        return retdata


    def itercb(self, n, error):
        """Callback function that prints optimization error..."""
        self._log.info("%-5d: %s" % (n,error))
        if n % 5 == 0:
            print("%-5d: %g" % (n, error[0]))
    
    
    
    
    
    
    
    
    
def _reconcile_regions(regions1,regions2):
    """Reconcile 2 sets of fitting regions into a single set of the form:
    list( (w1,w2,dataset1), (w1,w2,dataset2), ...)
    """
    def _find_point(p):
        "Find the region in which point p exists in regions2"
        for i,reg in enumerate(regions2):
            _, dset2 = reg
            if p in dset2:
                return i
        return -1
    
    retdata = []
    for w1,dset1 in regions1:
        reg2sets = {}
        # find all of the points from this dataset in the regions2 set
        for p1 in dset1:
            i = _find_point(p1)
            if i in reg2sets:
                reg2sets[i].append(p1)
            else:
                reg2sets[i] = [p1]
        # now generate new regions
        if len(reg2sets) == 1:
            # special case, no need to generate new sets
            i = reg2sets.keys()[0]
            if i == -1: w2 = 0.0
            else: w2 = regions2[i][0]
            retdata.append( (w1,w2,dset1) )
        else:
            # need to split the old data set into more than 1 new set
            for i in reg2sets.keys():
                if i == -1: w2 = 0.0
                else: w2 = regions2[i][0] 
                retdata.append( (w1,w2,reg2sets[i]) )    
                
    return retdata
    

def get_intrinsic_voltages(data, rg=0.0, rd=0.0, rs=0.0):
    """Compute the internal voltages vgsi and vdsi."""
    if data.igs >= 0.0:
        vdsi = data.vds - data.ids*rd - (data.ids+data.igs)*rs
        vgsi = data.vgs - data.igs*rg - (data.ids+data.igs)*rs
    else:
        vdsi = data.vds - (data.ids-data.igs)*rd - data.ids*rs
        vgsi = data.vgs - data.igs*rg - data.ids*rs
    return vgsi, vdsi
    
    

def apply_port_res_and_iso(vds, vgs, ids, igs, rd, rg, rs):
    if igs > 0:
        vdsi = vds - ids*rd - (ids+igs)*rs
        vgsi = vgs - igs*rg - (ids+igs)*rs
    else:
        vdsi = vds - (ids-igs)*rd - ids*rs
        vgsi = vgs - igs*rg - ids*rs
    return vdsi, vgsi
    
