from __future__ import unicode_literals, absolute_import, division, print_function
from ..switch_model import SwitchModelV2, CTOK, Q_ELECTRON, BOLTZMANN
from ...linefit import linefit_mxb
from ...configfile import ConfigVars, ConfigFile
from ...configtypes import *
from ...optimize import BasicEngine, get_worker
import math
import logging
from io import StringIO
from ... import _str_type

def write_model_mdif( fname, parms, blockname='BDTA', modelnum=1, modelnumvar='Modelnum', header=None, per_line=5 ):
    """write model data in ModelMDIF format"""

    # create a memory buffer for writing the model to
    buffer = StringIO()

    #write the header
    if header:
        buffer.write(buffer)
        if header[-1:] != '\n':
            buffer.write('\n')

    # write the model number variable and start of the block
    buffer.write('%s = %d\nBEGIN %s\n'%(modelnumvar,modelnum,blockname))

    # write the parameters
    lc = 0
    vbuf = '%'
    pbuf = ' '
    for name,val in parms:
        if per_line > 0 and lc >= per_line:
            # insert newlines after 'per_line' parameters have been written
            buffer.write(vbuf+'\n')
            buffer.write(pbuf+'\n')
            vbuf = '%'
            pbuf = ' '
            lc = 0

        vbuf += '%14s'%name
        pbuf += '%+14.4e'%val
        lc += 1

    if lc > 0:
        # add incomplete line data
        buffer.write(vbuf+'\n')
        buffer.write(pbuf+'\n')

    buffer.write('END\n')

    # open the ouptut file
    ac = False
    if isinstance(fname,_str_type):
        ac = True
        fp = open(fname,'w')
    elif hasattr(fname,'write'):
        fp = fname
        ac = False
        fname = '<unknown>'
    else:
        raise TypeError("'fname' must be a string or a file-like object")

    fp.write(buffer.getvalue())
    fp.close()
    buffer.close()



class SwitchExtract(object):
    """Extract FET switch large-signal models.

    """
    def __init__(self, **kwargs):
        """Create the extraction object."""
        # create the model object
        self._model = SwitchModelV2()
        self._initial_done = False

        # create a log target
        self._log = logging.getLogger('modeling.fet.SwitchExtract')

        # create the configuration variable object
        self._cfg = FET_Model_Config()



    def clear(self):
        "clear the stored model from memory"
        self._model = SwitchModelV2()
        self._initial_done = False


    def extract_initial(self):
        """perform initial extraction operations that do not generally need to be
        repeated more than once (unless options/switches/files are modified)
        """
        para = dict()
        pfile = self._cfg['parasitics_file']
        try:
            with open(pfile,'r') as fp:
                exec(compile(fp.read(),pfile,'exec'),globals(),para)
        except Exception as e:
            self._log.warn("could not read parasitics file '{}' -> {}".format(pfile,e))

        # read the parasitics file and configure parasitics
        try:

            if self._cfg['r_data_source'].lower() == 'coldfet':
                self._model['rg'].v = para.get('rg',0.0001)
                self._model['rs'].v = para.get('rs',0.0001)
                self._model['rd'].v = para.get('rd',0.0001)
            else:
                self._model['rg'].v = self._cfg['rg_fixed']
                self._model['rs'].v = self._cfg['rs_fixed']
                self._model['rd'].v = self._cfg['rd_fixed']

            if self._cfg['l_data_source'].lower() == 'coldfet':
                self._model['lg'].v = para.get('lg',1.0e-18)
                self._model['ls'].v = para.get('ls',1.0e-18)
                self._model['ld'].v = para.get('ld',1.0e-18)
            else:
                self._model['lg'].v = self._cfg['lg_fixed']
                self._model['ls'].v = self._cfg['ls_fixed']
                self._model['ld'].v = self._cfg['ld_fixed']

        except Exception as e:
            self._log.error("Parasitics extraction error: %s"%e)
            return False

        # read in the temperature, unit gate width, and number of gate fingers
        fp = open(xxx,'r')
        try:
            for line in fp:
                if not line.startswith('!'):
                    break

                if line.startswith('!TEMPERATURE'):
                    t = float(line.split()[-1])
                    if 24.9 < t < 27.1:
                        t = 25.0
                    self._model['tnom'].v = t
                elif line.startswith('!UNIT GATE WIDTH'):
                    self._model['ugw'].v = float(line.split()[-1])
                elif line.startswith('!NUMBER OF GATE'):
                    self._model['ngf'].v = int(line.split()[-1])

        finally:
            fp.close()


        # initial extraction done
        self._initial_done = True

    def extract_ig(self):
        """Extract gate current model parameters."""
        if not self._initial_done:
            raise RuntimeError("initial extraction has not been completed")

        self._model['is'].v = 0.0
        self._model['n'].v = 1.0
        self._model['ibd'].v = 0.0
        self._model['vbd'].v = 1.0
        self._model['ileak'].v = 0.0
        self._model['vleak'].v = 1.0

        #### extract forward diode parameters ####
        
        
        
        

        vgs,igs = [],[]
        for p in self.__fwddata[-6:]:
            vgs.append(p.vgs - p.igs*self.model['rg'].v - (p.igs+p.ids)*self.model['rs'].v)
            igs.append(math.log(p.igs))
        if len(vgs) < 2:
            self._log.error("Not enough points for forward diode fit.")
        else:
            m, b, r2 = linefit_mxb(vgs, igs)
            self.model['is'].v = 0.5*math.exp(b)
            self.model['n'].v = Q_ELECTRON/(m*BOLTZMANN*(self.model['tnom'].v+CTOK))

        #### extract breakdown parameters ####
        
        
        

        vdg,igs = [],[]
        for p in self.__vbrdata:
            if p.igs < 0:
                vdg.append(p.vds-p.vgs)
                igs.append(math.log(-p.igs))
        m,b,r2 = linefit_mxb(vdg[-2:], igs[-2:])
        self.model['ibd'].v = math.exp(b)
        self.model['vbd'].v = 1.0/m

        #### extract leakage parameters ####

        vdg_low_lim = 0.25*(vdg[-1])
        vdg_high_lim = 0.5*(vdg[-1])
        vdg, igs = [],[]
        for p in self.__vbrdata:
            v = p.vds-p.vgs
            if p.igs <0 and v < vdg_high_lim and v > vdg_low_lim:
                vdg.append(p.vds-p.vgs)
                igs.append(math.log(-p.igs))
        m,b,r2 = linefit_mxb(vdg, igs)
        self.model['ileak'].v = math.exp(b)
        self.model['vleak'].v = 1.0/m

    def extract_cg(self):
        """Extract gate capacitance model parameters."""
        if not self._initial_done:
            raise RuntimeError("initial extraction has not been completed")

        params = ('ct0','ct1','ct2','ce0','ce1','ce2',)

        self.model.get_named_params(params)

        # compute internal voltages for the small-signal dataset
        for p in self.__ssdata:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.model['rg'].v,
                rd=self.model['rd'].v, rs=self.model['rs'].v)

        use_c = self._cfg['c_for_gate_cap']
        if use_c == "'cgs'":
            self.model['cgg0'].v = self.__ssdata[0].cgs
        elif use_c == "'cgd'":
            self.model['cgg0'].v = self.__ssdata[0].cgd
        else:
            self.model['cgg0'].v = 0.5 * (self.__ssdata[0].cgs + self.__ssdata[0].cgd)

        self.__optdata = self._get_weighted_regions('cgate_fit_regions', self.__ssdata)
        # run the optimization
        self._log.info("Starting the Gate Capacitance Optimization.")
        worker = get_worker('gradient')( self._cgs_erf, self.model.get_named_params(params) )
        engine = BasicEngine( worker=worker, iter=500, itercb=self.itercb)
        engine.optimize()
        self._log.info("Gate Cap Final Error: %g" %engine.error)
        del self.__optdata

    def extract_gds(self):
        if not self.__initial:
            raise RuntimeError("Initial extraction has not been completed.")

        params = ("ids0", "ids1", "ids2", "ids3", "ids4",)

        kneevgs = 0
        for p in self.__ivdata:
            if p.vgs > kneevgs and p.vgs < 0.91:
                kneevgs = p.vgs

        optgds = self.__ivdata.filter(vdsrange=(0.1,0.1))
        optknee = self.__ivdata.filter(vgsrange=(p.vgs,p.vgs))

        for p in optknee:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.model['rg'].v,
                rd=self.model['rd'].v, rs=self.model['rs'].v)
        for p in optgds:
            p.vgsi, p.vdsi = get_intrinsic_voltages(p, rg=self.model['rg'].v,
                rd=self.model['rd'].v, rs=self.model['rs'].v)
            p.gds = p.ids/p.vdsi

        self.__optdata = (optknee, optgds)

        # run the optimization
        self._log.info("Starting the Conductance Optimization.")
        worker = get_worker('gradient')( self._gds_erf, self.model.get_named_params(params) )
        engine = BasicEngine( worker=worker, iter=500, itercb=self.itercb)
        engine.optimize()
        self._log.info("Conductance Final Error: %g" %engine.error)
        del self.__optdata



    def write_model(self, fname=None):
        """Write the switch model to a ModelMDIF format file."""
        if not fname:
            fname = 'switch.mdf'

        # generate a header


        # create a list of model parameters to write
        modparams = ('ugw','ngf','is','n','ibd','vbd','ileak','vleak',
            'rg','rd','rs','lg','ld','ls','cds','cgg0','ct0', 'ct1','ct2',
            'ce0', 'ce1', 'ce2', 'ids0', 'ids1', 'ids2', 'ids3', 'ids4',
            )
        params = [ ('area',self.model['ugw'].v*self.model['ngf'].v), ]
        for name in modparams:
            params.append( (name,self.model[name].v) )

        # write the model file
        write_model_mdif(fname,params,header=header)




    def _gds_erf(self):
        """Callback to compute ids, gds error during optimization"""
        e1 = 0.0
        e2 = 0.0
        for p in self.__optdata[0]:
            ids, _ = self.model.compute_ids(p.vgsi, p.vgsi-p.vdsi)
            e1 += (p.ids - ids) * (p.ids - ids) / (p.ids * p.ids)
        for p in self.__optdata[1]:
            _ , gds = self.model.compute_ids(p.vgsi, p.vgsi-p.vdsi)
            e2 += (p.gds - gds) * (p.gds - gds) / (p.gds * p.gds)
        e = 1000 * (e1 + e2)
        return e

    def _cgs_erf(self):
        """Callback to compute cgs error during optimization"""
        e = 0.0
        use_c = self._cfg['c_for_gate_cap']
        for w, region in self.__optdata:
            for p in region:
                cgs = self.model.compute_cgs(p.vgsi)
                if use_c == 'cgd':
                    err = (p.cgd-cgs) / p.cgd
                if use_c == 'cgs':
                    err = (p.cgs-cgs) / p.cgs
                else:
                    err = (p.cgs - 0.5 * (p.cgs+p.cgd)) /(0.5 * (p.cgs + p.cgd))
                e += w*err*err
        return e

    def _get_weighted_regions(self, cfgvar, dataset, default_weight=1.0):
        """Get a list of 2-tuples defining regions of measured data to weight
        differently than the rest.
        """
        regions = self._cfg[cfgvar]
        if len(regions):
            # create a ConfigVars object to read the data for the
            # dciv fitting regions
            cv = ConfigVars()
            for r in regions:
                # each region must be a 5-tuple of floats
                # length = (minlength, maxlength)
                cv.add(r, CF_FLOATTUPLE, length=(5,5))

            # read the region data from the config file
            reg = self.__cfgfile.get_variables(cv,section='switch')

            # create the dataset subsets
            retdata = []
            remain = dataset
            for r in regions:
                if len(reg[r]):
                    # a valid region existed in the config file
                    w = reg[r][0]
                    vds = reg[r][1:3]
                    vgs = reg[r][3:]
                    # segregate the data into the target region and the rest
                    d, remain = remain.segregate(vdsrange=vds, vgsrange=vgs)
                    # if the target region contains data, and it has a
                    # positive optimization weight, add it to the
                    # optimization data set
                    if w > 0.0 and len(d):
                        retdata.append( (w,d) )
            # add the rest of the data to the optimization data set with
            # the default weight
            if len(remain):
                retdata.append( (default_weight,remain) )

        else:
            # in absense of regions, return the whole dataset with equal weighting
            retdata = ( (default_weight, dataset), )

        return retdata

    def itercb(self, n, error):
        """Callback function that prints optimization error..."""
        self._log.info("%-5d: %s" % (n,error))
        if n % 2 == 0:
            print("%-5d: %g" % (n, error[0]))



def get_intrinsic_voltages(data,rg=0.0, rd=0.0, rs=0.0):
    """Compute the internal voltages vgsi and vdsi."""
    if data.igs >= 0.0:
        vdsi = data.vds - data.ids*rd - (data.ids+data.igs)*rs
        vgsi = data.vgs - data.igs*rg - (data.ids+data.igs)*rs
    else:
        vdsi = data.vds - (data.ids-data.igs)*rd - data.ids*rs
        vgsi = data.vgs - data.igs*rg - data.ids*rs
    return vgsi, vdsi


