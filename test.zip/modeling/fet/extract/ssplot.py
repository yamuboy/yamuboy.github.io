"""




"""
from __future__ import unicode_literals, absolute_import, division, print_function
from ..ssmodel import FET_SS_Model
from ..config import FET_Model_Config
from ...spar_reader import TouchstoneReadAndDeembed
from ...utils import *
from ...file_utils import *
from .. import load_ss_model
from network_params import Touchstone, BiasedTouchstone
from . import fet_model_params
import math, cmath
import logging
import numpy as np
import os, os.path, shutil
import glob

import matplotlib
from matplotlib.figure import Figure
#from matplotlib.lines import Line2D

import maplot.smithplot
from maplot import NoMorePages

_log = logging.getLogger('modeling.fet.ssplot')
        
def plot_interactive(files=None, old_style=False):
    """set up for interactive plotting
    
    returns the plot figure object and the plot pager as a 2-tuple
    """
    cfg = FET_Model_Config()

    if files is None:
        if old_style:
            raise ValueError("'files' must be specified when run with 'old_style' = True")
        
        # new style uses the configuration data setup
        files = cfg['sparam_files']
    
    kw = {}
    if old_style:
        kw['old_style'] = True
    else:
        # configure the S2P data reader for new style
        tskw = {}
        for k in ('deembedding_fixture1','deembedding_fixture2','invert_fixture1',
            'invert_fixture2','swap_fixture1','swap_fixture2','cache_extension'):
            tskw[k] = cfg[k]
        reader = TouchstoneReadAndDeembed(touchstone_reader=BiasedTouchstone,**tskw)
        reader.flist = build_freq_list(cfg['extract_freq_list_ghz'])
        kw['s2p_reader'] = reader.read
            
    # generate a list of real data files (expand wildcards, etc)
    _log.info("generating file list ...")
    real_files = expand_file_list(files)
    
    # create the plot data set
    plotdata = []
    ext = cfg['model_extension']
    if old_style:
        ext = '.end'
        
    for fn in real_files:
        modelname = os.path.splitext(fn)[0]+ext
        if os.path.isfile(fn):
            if os.path.isfile(modelname):
                plotdata.append( {'sfile':fn } )            
            else:
                _log.warning("'%s': file not found"%modelname)
        else:
            _log.warning("'%s': file not found"%fn)
    
    # create the plot figure and pager
    _log.info("creating plot figure ...")
    fig = SSFigure2()
    pager = SSPlotPager(plotdata,**kw)
    
    return fig, pager

plot_generator = plot_interactive
    
class SSFigure(Figure):
    """`matplotlib.Figure`-derived class that draws measured vs. modeled
    results for a FET small-signal fit.
    
    """
    
    def __init__(self, *args, **kwargs):
        "initializer"
        super(SSFigure,self).__init__(*args,**kwargs)    
    
    def plot_meas_vs_mod(self, s2pdata, model):
        "generate the plots given a set of s2p data and a FET_SS_Model object"
        
        # clear the figure
        self.clf()
        
        if not isinstance(s2pdata,Touchstone):
            raise TypeError("'s2pdata' must be an instance of `network_params.Touchstone`")
            
        if not isinstance(model,FET_SS_Model):
            raise TypeError("'model' must be an instance of `modeling.fet.FET_SS_Model`")
        
        # generate the plot data
        flist = s2pdata.flist
        sp = y2s_2port_50ohms(model.compute_y(flist,True))
        s11m, s11a = [], []
        s21m, s21a = [], []
        s12m, s12a = [], []
        s22m, s22a = [], []
        s11mm, s11am = [], []
        s21mm, s21am = [], []
        s12mm, s12am = [], []
        s22mm, s22am = [], []
        for i,d in enumerate(s2pdata):
            # measured
            s11m.append(abs(d.data[0,0]))
            s11a.append(cmath.phase(d.data[0,0])*180.0/math.pi)
            s12m.append(abs(d.data[0,1]))
            s12a.append(cmath.phase(d.data[0,1])*180.0/math.pi)
            s21m.append(abs(d.data[1,0]))
            s21a.append(cmath.phase(d.data[1,0])*180.0/math.pi)
            s22m.append(abs(d.data[1,1]))
            s22a.append(cmath.phase(d.data[1,1])*180.0/math.pi)
            # model
            s11mm.append(abs(sp[i][0,0]))
            s11am.append(cmath.phase(sp[i][0,0])*180.0/math.pi)
            s12mm.append(abs(sp[i][0,1]))
            s12am.append(cmath.phase(sp[i][0,1])*180.0/math.pi)
            s21mm.append(abs(sp[i][1,0]))
            s21am.append(cmath.phase(sp[i][1,0])*180.0/math.pi)
            s22mm.append(abs(sp[i][1,1]))
            s22am.append(cmath.phase(sp[i][1,1])*180.0/math.pi)
        
        # create the plots
        p_s11m = self.add_subplot(2,2,1)
        p_s12m = self.add_subplot(2,2,2)
        p_s21m = self.add_subplot(2,2,3)
        p_s22m = self.add_subplot(2,2,4)
        
        if hasattr(p_s11m,'tick_params'):
            p_s11m.tick_params(labelsize='x-small')
            p_s12m.tick_params(labelsize='x-small')
            p_s21m.tick_params(labelsize='x-small')
            p_s22m.tick_params(labelsize='x-small')
        p_s11m.set_title('S(1,1)',fontsize='small')
        p_s12m.set_title('S(1,2)',fontsize='small')
        p_s21m.set_title('S(2,1)',fontsize='small')
        p_s22m.set_title('S(2,2)',fontsize='small')
        
        # adjust subplots
        self.subplots_adjust(left=0.07,right=0.93,top=0.9,bottom=0.1,wspace=0.25,hspace=0.3)
        
        p_s11a = p_s11m.twinx()
        p_s12a = p_s12m.twinx()
        p_s21a = p_s21m.twinx()
        p_s22a = p_s22m.twinx()

        if hasattr(p_s11m,'tick_params'):
            p_s11a.tick_params(labelsize='x-small')
            p_s12a.tick_params(labelsize='x-small')
            p_s21a.tick_params(labelsize='x-small')
            p_s22a.tick_params(labelsize='x-small')
                
        fmt_measm = 'r.'
        fmt_modm = 'r-'
        fmt_measa = 'b.'
        fmt_moda = 'b-'
                
        # add the data to the plots
        flist_ghz = np.array(flist)*1.0e-9
        p_s11m.plot(flist_ghz,s11m,fmt_measm,flist_ghz,s11mm,fmt_modm,antialiased=False)
        p_s12m.plot(flist_ghz,s12m,fmt_measm,flist_ghz,s12mm,fmt_modm,antialiased=False)
        p_s21m.plot(flist_ghz,s21m,fmt_measm,flist_ghz,s21mm,fmt_modm,antialiased=False)
        p_s22m.plot(flist_ghz,s22m,fmt_measm,flist_ghz,s22mm,fmt_modm,antialiased=False)
        p_s11a.plot(flist_ghz,s11a,fmt_measa,flist_ghz,s11am,fmt_moda,antialiased=False)
        p_s12a.plot(flist_ghz,s12a,fmt_measa,flist_ghz,s12am,fmt_moda,antialiased=False)
        p_s21a.plot(flist_ghz,s21a,fmt_measa,flist_ghz,s21am,fmt_moda,antialiased=False)
        p_s22a.plot(flist_ghz,s22a,fmt_measa,flist_ghz,s22am,fmt_moda,antialiased=False)
        
        # add the bias information if available
        try:
            biasstr = 'Vds = %g ; Vgs = %g ; Ids = %g ; Igs = %g'%(s2pdata.v2,s2pdata.v1,s2pdata.i2,s2pdata.i1)
            self.text(0.5,0.97,biasstr,fontsize='x-small',horizontalalignment='center',verticalalignment='top')
        except Exception:
            pass
        
        self.text(0.02,0.02,os.path.realpath(os.path.abspath(s2pdata.filename)),fontsize='xx-small')
        self.text(0.5,0.5,'magnitude = red(left), phase = blue(right) | measured = dots, modeled = solid',
            fontsize='xx-small',horizontalalignment='center',verticalalignment='center')

            
class SSFigure2(Figure):
    """`matplotlib.Figure`-derived class that draws measured vs. modeled
    results for a FET small-signal fit.
    
    *** updated version to improve the speed of plotting ***
    
    """
    # initially start in Smith chart mode
    smith = True
    
    def __init__(self, *args, **kwargs):
        "initializer"
        super(SSFigure2,self).__init__(*args,**kwargs)
        self.init_plots()
    
    def init_plots(self):
        "initialize plots"
        # clear figure
        self.clf()
        
        # create the plots
        if self.smith:
            self.p_s11m = self.add_subplot(2,2,1, projection='smith')  #axes_scale=1.0)
            self.p_s22m = self.add_subplot(2,2,2, projection='smith')  #axes_scale=1.0)
        else:
            self.p_s11m = self.add_subplot(2,2,1)
            self.p_s22m = self.add_subplot(2,2,2)
        
        self.p_s12m = self.add_subplot(2,2,4)
        self.p_s21m = self.add_subplot(2,2,3)
        
        
        # adjust tick text size and add titles
        if hasattr(self.p_s11m,'tick_params'):
            self.p_s11m.tick_params(labelsize='x-small')
            self.p_s12m.tick_params(labelsize='x-small')
            self.p_s21m.tick_params(labelsize='x-small')
            self.p_s22m.tick_params(labelsize='x-small')
        self.p_s11m.set_title('S(1,1)',fontsize='small')
        self.p_s12m.set_title('S(1,2)',fontsize='small')
        self.p_s21m.set_title('S(2,1)',fontsize='small')
        self.p_s22m.set_title('S(2,2)',fontsize='small')
        
        # adjust subplots
        self.subplots_adjust(left=0.07,right=0.93,top=0.9,bottom=0.1,wspace=0.25,hspace=0.3)
        
        # create the right-Y axis for phase
        if not self.smith:
            self.p_s11a = self.p_s11m.twinx()
            self.p_s22a = self.p_s22m.twinx()
        self.p_s12a = self.p_s12m.twinx()
        self.p_s21a = self.p_s21m.twinx()
        

        # adjust tick text size for the right axis
        if hasattr(self.p_s11m,'tick_params'):
            if not self.smith:
                self.p_s11a.tick_params(labelsize='x-small')
                self.p_s22a.tick_params(labelsize='x-small')
            self.p_s12a.tick_params(labelsize='x-small')
            self.p_s21a.tick_params(labelsize='x-small')
            
        
        # set the hold flag for all plots so that cla() is not automatically
        # called on the plots when new data is added, this is for speed improvement
        # to prevent matplotlib from doing a bunch of cleanup that is not required
        self.p_s11m.hold(True)
        self.p_s12m.hold(True)
        self.p_s21m.hold(True)
        self.p_s22m.hold(True)
        self.p_s12a.hold(True)
        self.p_s21a.hold(True)
        if not self.smith:
            self.p_s11a.hold(True)
            self.p_s22a.hold(True)
    
    def plot_meas_vs_mod(self, s2pdata, model):
        "generate the plots given a set of s2p data and a FET_SS_Model object"
        
        # formats for lines
        fmt_measm = 'r-'
        fmt_modm = 'b-'
        fmt_measa = 'r--'
        fmt_moda = 'b--'
        
        if not isinstance(s2pdata,Touchstone):
            raise TypeError("'s2pdata' must be an instance of `network_params.Touchstone`")
            
        if not isinstance(model,FET_SS_Model):
            raise TypeError("'model' must be an instance of `modeling.fet.FET_SS_Model`")
            
        # clear existing plot line data from the plots and text from the figure
        self.p_s11m.lines = []
        self.p_s12m.lines = []
        self.p_s21m.lines = []
        self.p_s22m.lines = []
        self.p_s12a.lines = []
        self.p_s21a.lines = []
        self.p_s11m.ignore_existing_data_limits = True
        self.p_s12m.ignore_existing_data_limits = True
        self.p_s21m.ignore_existing_data_limits = True
        self.p_s22m.ignore_existing_data_limits = True
        self.p_s12a.ignore_existing_data_limits = True
        self.p_s21a.ignore_existing_data_limits = True
        
        if not self.smith:
            self.p_s11a.lines = []
            self.p_s22a.lines = []
            self.p_s11a.ignore_existing_data_limits = True
            self.p_s22a.ignore_existing_data_limits = True
        
        self.texts = []
        
        # generate the plot data
        flist = s2pdata.flist
        sp = y2s_2port_50ohms(model.compute_y(flist,True))
        s11m, s11a = [], []
        s21m, s21a = [], []
        s12m, s12a = [], []
        s22m, s22a = [], []
        s11mm, s11am = [], []
        s21mm, s21am = [], []
        s12mm, s12am = [], []
        s22mm, s22am = [], []
        for i,d in enumerate(s2pdata):
            # measured
            s11m.append(abs(d.data[0,0]))
            s11a.append(cmath.phase(d.data[0,0])*180.0/math.pi)
            s12m.append(abs(d.data[0,1]))
            s12a.append(cmath.phase(d.data[0,1])*180.0/math.pi)
            s21m.append(abs(d.data[1,0]))
            s21a.append(cmath.phase(d.data[1,0])*180.0/math.pi)
            s22m.append(abs(d.data[1,1]))
            s22a.append(cmath.phase(d.data[1,1])*180.0/math.pi)
            # model
            s11mm.append(abs(sp[i][0,0]))
            s11am.append(cmath.phase(sp[i][0,0])*180.0/math.pi)
            s12mm.append(abs(sp[i][0,1]))
            s12am.append(cmath.phase(sp[i][0,1])*180.0/math.pi)
            s21mm.append(abs(sp[i][1,0]))
            s21am.append(cmath.phase(sp[i][1,0])*180.0/math.pi)
            s22mm.append(abs(sp[i][1,1]))
            s22am.append(cmath.phase(sp[i][1,1])*180.0/math.pi)
        
        # add the data to the plots
        flist_ghz = np.array(flist)*1.0e-9
        if self.smith:
            self.p_s11m.plot(np.array([cmath.rect(d[0], d[1]/180.0*math.pi) for d in zip(s11m,s11a)]), marker='', zorder=3, color='#FF0000', no_transform='True')
            self.p_s22m.plot(np.array([cmath.rect(d[0], d[1]/180.0*math.pi) for d in zip(s22m,s22a)]), marker='', zorder=3, color='#FF0000', no_transform='True')
            self.p_s11m.plot(np.array([cmath.rect(d[0], d[1]/180.0*math.pi) for d in zip(s11mm,s11am)]), marker='', zorder=4, color='#0000FF', no_transform='True')
            self.p_s22m.plot(np.array([cmath.rect(d[0], d[1]/180.0*math.pi) for d in zip(s22mm,s22am)]), marker='', zorder=4, color='#0000FF', no_transform='True')
        else:
            self.p_s11m.plot(flist_ghz,s11m,fmt_measm,flist_ghz,s11mm,fmt_modm,antialiased=False)
            self.p_s22m.plot(flist_ghz,s22m,fmt_measm,flist_ghz,s22mm,fmt_modm,antialiased=False)
            self.p_s11a.plot(flist_ghz,s11a,fmt_measa,flist_ghz,s11am,fmt_moda,antialiased=False)
            self.p_s22a.plot(flist_ghz,s22a,fmt_measa,flist_ghz,s22am,fmt_moda,antialiased=False)
            
        self.p_s12m.plot(flist_ghz,s12m,fmt_measm,flist_ghz,s12mm,fmt_modm,antialiased=False)
        self.p_s21m.plot(flist_ghz,s21m,fmt_measm,flist_ghz,s21mm,fmt_modm,antialiased=False)
        self.p_s12a.plot(flist_ghz,s12a,fmt_measa,flist_ghz,s12am,fmt_moda,antialiased=False)
        self.p_s21a.plot(flist_ghz,s21a,fmt_measa,flist_ghz,s21am,fmt_moda,antialiased=False)
        
        # add the bias information if available
        try:
            biasstr = 'Vds = %g ; Vgs = %g ; Ids = %g ; Igs = %g'%(s2pdata.v2,s2pdata.v1,s2pdata.i2,s2pdata.i1)
            self.text(0.5,0.97,biasstr,fontsize='x-small',horizontalalignment='center',verticalalignment='top')
        except Exception:
            pass
        
        # add other text to the figure
        self.text(0.02,0.02,os.path.realpath(os.path.abspath(s2pdata.filename)),fontsize='xx-small')
        self.text(0.5,0.5,'magnitude = solid,left | phase = dashed,right       measured = red | model = blue',
                fontsize='xx-small',horizontalalignment='center',verticalalignment='center')            
            
def _default_s2p_reader( fname ):
    "default reader of S2P data files" 
    return BiasedTouchstone(fname)

class SSPlotPager(object):
    "pager for FET small-signal model plotting"
        
    def __init__(self, data, s2p_reader=_default_s2p_reader, old_style=False):
        """initialize the pager
        
        data is a list of dictionary objects, each dict must contain the keys
        'sfile' - the filename of the S2P data file
        and optionally can contain the keys
        's2pd' - a `network_parameters.Touchstone` (or derived type) object containing S2P data
        'model' - a `modeling.fet.FET_SS_Model` (or derived type) object containing the FET model
        
        s2p_reader is a callable object (function) that reads S2P data, it will be passed a single
          argument, the filename of the file to read, and must return a `network_parameters.Touchstone`
          (or derived type) object. This has no effect if the 's2pd' keys of the dictionaries in the
          data array are already populated.
        old_style is a flag indicating that the pager should use the old style of reading model files
          (.end file format) rather than the new style. This has no effect if the 'model' keys of the 
          dictionaries in the data array are already populated.
        """
        
        if not isinstance(data,(list,tuple)):
            raise TypeError("'data' must be a list/tuple")        
        elif not len(data):
            raise ValueError("'data' is empty")
            
        for i,d in enumerate(data):
            if not isinstance(d,dict):
                raise TypeError("in 'data', element at position %d is not a dictionary"%i)
            if 'sfile' not in d:
                raise KeyError("in 'data', element at position %d is missing key 'sfile'"%i)
        
        if not callable(s2p_reader):
            raise TypeError("'s2p_reader' must be a callable object")        
        
        self.__data = list(data[:])
        self.__s2pr = s2p_reader
        self.__old = bool(old_style)
        self.__i = 0
    
    def _draw_figure(self, figure, idx):
        "draw the figure from the data array at index 'idx'"
        d = self.__data[idx]
        if 's2pd' in d and isinstance(d['s2pd'],Touchstone):
            s2pd = d['s2pd']            
        else:
            try:
                s2pd = self.__s2pr(d['sfile'])
                if not isinstance(s2pd,Touchstone):
                    raise TypeError("'s2p_reader' returned an object of the wrong type")
                d['s2pd'] = s2pd
            except Exception as e:
                # generate dummy s2p data
                _log.warning("failed to read S2P data from file '%s': %s"%(d['sfile'],e))
                s2pd = Touchstone()
        
        if len(s2pd) > 0 and s2pd.nports != 2:
            _log.warning("'%s' does not contain s2p data"%d['sfile'])
            s2pd = Touchstone() 
        
        if 'model' in d and isinstance(d['model'],FET_SS_Model):
            model = d['model']
        else:
            try:
                model = load_ss_model(d['sfile'],old_style=self.__old)
                d['model'] = model
            except Exception as e:
                # generate dummy model data
                _log.warning("failed to read model data for '%s' => %s"%(d['sfile'],e))
                model = FET_SS_Model()
        
        figure.plot_meas_vs_mod(s2pd,model)

    def toggle_smith(self, figure):
        "toggle between smith and rect displays for S11 and S22"
        
        if figure.smith:
            figure.smith = False
        else:
            figure.smith = True
        
        figure.init_plots()
        self._draw_figure(figure, self.__i)
        
        if figure.smith:
            return "S11 and S22 now in Smith chart form"
        else:
            return "S11 and S22 now in rectangular chart form"
        
    def init_pages(self, figure):
        "initialize the first page"
        self.__i = 0
        self._draw_figure(figure,self.__i)
        return "page: 1 of %d"%len(self.__data)
        
    def next_page(self, figure):
        "go to the next page"
        i = self.__i + 1
        if i >= len(self.__data):
            raise NoMorePages()
        self._draw_figure(figure,i)
        self.__i = i
        return "page: %d of %d"%(self.__i+1,len(self.__data))
    
    def prev_page(self, figure):
        "go to the previous page"
        i = self.__i - 1
        if i < 0:
            raise NoMorePages()
        self._draw_figure(figure,i)
        self.__i = i
        return "page: %d of %d"%(self.__i+1,len(self.__data))
    
    def delete_model(self, figure):
        """key binding callback to remove the current data from the plot dataset
        and re-write the data file names to mark them as bad
        """
        d = self.__data[self.__i]
        success = []
        failed = []
        # rename files
        pat = os.path.splitext(d['sfile'])[0] + '.*'
        for fname in glob.glob(pat):
            try:
                newfn = fname + '-d'
                if os.path.exists(newfn):
                    # need to delete
                    os.unlink(newfn)
                shutil.move(fname,newfn)
                success.append("'%s'"%(os.path.basename(fname)))
            except Exception as e:
                failed.append("'"+os.path.basename(fname)+"'")
                _log.warning("failed to rename file '%s' => "%(fname,e))
                                
        del self.__data[self.__i]
        if self.__i >= len(self.__data) and self.__i > 0:
            self.__i -= 1
        
        # recreate and redraw the figure
        self._draw_figure(figure,self.__i)
        figure.canvas.draw()
        
        # return status text to display
        if len(failed):
            txt = "rename failed: " + (', '.join(failed))   
        else:
            txt = "renamed: " + (' ; '.join(success))
        return txt
        
    delete_page = delete_model

