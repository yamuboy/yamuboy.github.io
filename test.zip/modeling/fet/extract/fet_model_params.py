"""
This module defines the common parameters needed by FET model extraction routines.

Custom parameters can be added within the modules for specific extraction code, but extraction
parameters that might be useful to reuse in multiple extraction routines should be defined here.

"""
from __future__ import unicode_literals, absolute_import, division, print_function
from ..config import FET_Model_Config, LSFET_Model_Config
from ... import optimize

try:
    ustr = unicode
except NameError:
    ustr = str

def _check_opt_regions(name, val):
    "callback function for checking the SS optimization region data" 
    
    if val is None:
        return None
    
    if not isinstance(val,(list,tuple)):
        raise TypeError("must be a list or tuple")
        
    for i,data in enumerate(val):
        if not isinstance(data,(list,tuple)) or len(data) != 4:
            raise ValueError("invalid data at index %d (must be a 4-tuple)"%i)

        w,fmin,fmax,wghts = data

        # check that the first three values in each 4-tuple are numbers
        try:
            float(w)
        except:
            raise ValueError("invalid data at index %d - first member of 4-tuple must be a number (weight value)"%i)
        try:
            float(fmin)
        except:
            raise ValueError("invalid data at index %d - second member of 4-tuple must be a number (min frequency in GHz)"%i)
        try:
            float(fmax)
        except:
            raise ValueError("invalid data at index %d - third member of 4-tuple must be a number (max frequency in GHz)"%i)
        
        # check the weights dictionary
        if wghts is not None:
            if not isinstance(wghts,dict):
                raise ValueError("invalid data at index %d - fourth member of 4-tuple must be a dictionary (parameter weights)"%i)
            
    # everything checks OK, return the data structure unmodified
    return val


### set up the global model configuration and initialize it to default values ###
_cv = FET_Model_Config()

# data file information
_cv.add('ss_model_file','ss.dscr',help="the name of the model file to write when a model summary is requested")
_cv.add('parasitics_file','parasitics.xtr',help="the file holding parasitic information for the FET")
_cv.add('sparam_files',['s???[mp]*.dmb'],list,help="a list of files and/or filename patterns that are to be used for small-signal modeling")
_cv.add('model_extension','.model',ustr,help="extension to use for model files")

# FET fixed parasitics
_cv.add('r_data_source','fixed',help="the source for parasitic resistance values: 'fixed' or 'coldfet'")
_cv.add('rg_fixed',1.0e-6,float,help="fixed value for Rg")
_cv.add('rd_fixed',1.0e-6,float,help="fixed value for Rd")
_cv.add('rs_fixed',1.0e-6,float,help="fixed value for Rs")
_cv.add('l_data_source','fixed',help="the source for parasitic inductance values: 'fixed' or 'coldfet'")
_cv.add('lg_fixed',1.0e-18,float,help="fixed value for Lg")
_cv.add('ld_fixed',1.0e-18,float,help="fixed value for Ld")
_cv.add('ls_fixed',1.0e-18,float,help="fixed value for Ls")

# real-time deembedding of data
_cv.add('deembedding_fixture1',help="a Touchstone file to use for deembedding of S-parameter data (port 1)")
_cv.add('invert_fixture1',True,bool,help="a flag indicating that port 1 deembedding data needs to be inverted")
_cv.add('swap_fixture1',False,bool,help="a flag indicating that port 1 deembedding data needs to be swapped/flipped (ports in the wrong order)")
_cv.add('deembedding_fixture2',help="a Touchstone file to use for deembedding of S-parameter data (port 2)")
_cv.add('invert_fixture2',True,bool,help="a flag indicating that port 2 deembedding data needs to be inverted")
_cv.add('swap_fixture2',False,bool,help="a flag indicating that port 2 deembedding data needs to be swapped/flipped (ports in the wrong order)")
_cv.add('cache_extension','.dm2',ustr,help="the extension to use for caching deembedded data")

# coldfet extraction parameters
_cv.add('coldfet_files',['s???c*.dmb'],list,help="a list of files and/or filename patterns that are to be used for cold-FET extraction")
_cv.add('coldfet_cfringe_file',help="the name of a file to be used for calculation of fringing capacitances")
_cv.add('coldfet_rfreq_ghz',2.0,float,help="the frequency to use for cold-FET resistance extraction in GHz")
_cv.add('coldfet_min_lfreq_ghz',10.0,float,help="the min frequency to use for cold-FET inductance extraction in GHz")
_cv.add('coldfet_max_lfreq_ghz',100.0,float,help="the max frequency to use for cold-FET inductance extraction in GHz")
_cv.add('coldfet_min_cfreq_ghz',0.0,float,help="the min frequency to use for cold-FET capacitance extraction in GHz")
_cv.add('coldfet_max_cfreq_ghz',10.0,float,help="the max frequency to use for cold-FET capacitance extraction in GHz")

# yfit parameters
_cv.add('yfit_min_cfreq_ghz',0.0,float,help="the min frequency to use for Y-fit capacitance extraction in GHz")
_cv.add('yfit_max_cfreq_ghz',10.0,float,help="the max frequency to use for Y-fit capacitance extraction in GHz")
_cv.add('yfit_min_gmfreq_ghz',0.0,float,help="the min frequency to use for Y-fit Gm/Gds extraction in GHz")
_cv.add('yfit_max_gmfreq_ghz',10.0,float,help="the max frequency to use for Y-fit Gm/Gds extraction in GHz")
_cv.add('yfit_min_taufreq_ghz',10.0,float,help="the min frequency to use for Y-fit Tau extraction in GHz")
_cv.add('yfit_max_taufreq_ghz',100.0,float,help="the max frequency to use for Y-fit Tau extraction in GHz")
_cv.add('yfit_min_ggsfreq_ghz',0.0,float,help="the min frequency to use for Y-fit Ggs/Ggd extraction in GHz")
_cv.add('yfit_max_ggsfreq_ghz',3.0,float,help="the max frequency to use for Y-fit Ggs/Ggd extraction in GHz")
_cv.add('yfit_enable_tau2',False,bool,help="enable the extraction of model parameter Tau2")
_cv.add('yfit_enable_rgd',False,bool,help="enable the extraction of model parameter Rgd")
_cv.add('yfit_enable_ggsggd',True,bool,help="enable the extraction of model parameters Ggs and Ggd")

# small-signal optimization parameters
_cv.add('ss_opt_percent_error',False,bool,help="use percent error (rather than absolute error) when calculating the optimization error function")
_cv.add('ss_opt_linear_error',True,bool,help="use linear error (rather than least-squared error) when calculating the optimization error function")
_cv.add('optimize_parasitics',False,bool,help="optimize parasitic parameter values")
_cv.add('ss_opt_default_worker','simult_gradient',ustr,help="default optimization worker (when one is not specified)")

# frequency lists for extraction/optimization
_cv.add('extract_freq_list_ghz',None,tuple,help="a list of frequencies used for the extraction process")
_cv.add('ss_optimize_regions',None,tuple,callback=_check_opt_regions,help="""specification of optimization regions
this is a list/tuple of 4-tuples, each 4-tuple consists of:
  (weight, fmin_ghz, fmax_ghz, param_weights), where:
     weight - float, relative weighting of the region
     fmin_ghz - float, region minimum frequency in GHz
     fmax_ghz - float, region maximum frequency in GHz
     param_weights - dict, parameter weights where the keys 
       are the parameter names (strings) and the values are
       the parameter weights (floats)
       valid parameter names: 's11', 's12', 's21', 's22', 
          'y11', 'y12', 'y21', 'y22', 'k', 'mag'
       parameters not specified are assigned a weight of
          0.0 and are not considered during optimization""")

# noise model fitting
_cv.add('noise_files',['*.nfig'],list,help="measured noise files")
_cv.add('noise_fxa',None,ustr,help="noise input fixture file (s2p)")
_cv.add('noise_fxb',None,ustr,help="noise output fixture file (s2p)")
_cv.add('noise_src_s1p',None,ustr,help="s1p file of the noise source (off state)")
_cv.add('noise_sparam_extension','.dm2',ustr,help="extension of DUT s-param files to read and use for noise modeling")
_cv.add('noise_output_extension','.rpc',ustr,help="extension for output files from the noise extraction")
_cv.add('noise_min_ids_mamm',5.0,float,help="minimum Ids current for the DUT in mA/mm to attempt to extract a noise model")
_cv.add('noise_min_nfigure',0.2,float,help="minimum noise figure (in dB) allowed before the measured data point is thrown away")
_cv.add('noise_max_nfigure',18.0,float,help="maximum noise figure (in dB) allowed before the measured data point is thrown away")
_cv.add('noise_max_gamma',0.85,float,help="maximum input gamma allowed before the measured data point is thrown away")
_cv.add('noise_max_gain_error',1.2,float,help="maximum gain error allowed (in dB) before the measured data point is thrown away")
_cv.add('noise_min_npoints',8,int,help="minimum number of 'good' measured data points that are required in order to attempt to generate a noise model")
          
          
####
####   large signal model parameters
####
          
_cv2 = LSFET_Model_Config() 
   
_cv2.add('dciv_fname','sdc.iv',ustr,help="filename of the DC I-V data file")
_cv2.add('fwdiv_fname','sfwd.iv',ustr,help="filename of the forward I-V data file")
_cv2.add('vbriv_fname','svbr.iv',ustr,help="filename of the breakdown I-V data file")
_cv2.add('pulsediv_fname',None,ustr,help="filename of the pulsed I-V data file")
_cv2.add('ss_summary_fname','ss.summary',ustr,help="filename of the small-signal summary data file")
_cv2.add('target_region',(3.0,5.0,-1.0,-0.5),tuple,help="definition of the target region for model optimization")

"""
        cv.add('dciv_fit_regions', CF_TUPLE)
        cv.add('gm_fit_regions', CF_TUPLE)
        cv.add('gds_fit_regions', CF_TUPLE)
        cv.add('cgs_fit_regions', CF_TUPLE)
        cv.add('cgd_fit_regions', CF_TUPLE)
        cv.add('cgd_fit_regions', CF_TUPLE)
"""          
          