"""







"""
from __future__ import unicode_literals, absolute_import, division, print_function
from .. import FET_Model_Config, FET_SS_Model, yfit, coldfet, remove_parasitics, read_ss_model, write_ss_model
from ...optimize import *
from ... import TouchstoneReadAndDeembed
from ...utils import *
from ...file_utils import *
from ...noise import noise_parameters, noise_figure_cy, deembed_nf_and_gain
import network_params
from network_params import ParamSet, Param, BiasedTouchstone, Touchstone
from . import fet_model_params
import math, cmath
import logging
import numpy as np
from io import StringIO

### variables for internal use ###
_default_parasitics = dict(rg=1.0e-6, rd=1.0e-6, rs=1.0e-6, lg=1.0e-18,
    ld=1.0e-18, ls=1.0e-18, c11=0.0, c22=0.0, cpg=0.0, cpd=0.0)

_parasitic_params = ('rg','rd','rs','lg','ld','ls','cpg','cpd','c11','c22')
_parasitic_params_no_rl = ('c11','c22','cpg','cpd')
_internal_params = ('cgs','cgd','cds','ri','rgd','gm','gds','tau','tau2','ggs','ggd')
_optimizer_names = ('s11','s12','s21','s22','y11','y12','y21','y22','k','mag')

class SSExtract(object):
    """FET small-signal extraction."""

    def __init__(self, **kwargs):
        """Create the extraction object."""
        # create a log target
        self._log = logging.getLogger('modeling.fet.SSExtract')

        # create a configuration object
        self._cfg = FET_Model_Config()

        # init parasitics
        self.__parasitics = _default_parasitics.copy()
        # try to read parasitics
        self.read_parasitics()

        # create a cache-backed read and deembed class
        # for touchstone data files
        self.__tsreader = TouchstoneReadAndDeembed(touchstone_reader=kwargs.pop('touchstone_reader',BiasedTouchstone))

        # set up the frequency list for extraction
        self.__flist = None

        # run the configure method for the first time
        self.configure()

    def configure(self):
        "(Re-)configure internally cached settings when configuration variables are updated"

        # update the calculation of the extraction frequency list
        self.__flist = build_freq_list(self._cfg['extract_freq_list_ghz'])

        ### update the configuration of the touchstone reader ###
        kwargs = {}
        for k in ('deembedding_fixture1','deembedding_fixture2','invert_fixture1',
            'invert_fixture2','swap_fixture1','swap_fixture2','cache_extension'):
            kwargs[k] = self._cfg[k]
        self.__tsreader.config(**kwargs)
        self.__tsreader.flist = self.__flist

    def read_parasitics(self):
        """(re-)read the parasitics data file."""
        fname = self._cfg['parasitics_file']
        paraf = dict()
        
        try:
            with open(fname,'r') as fp:
                exec(compile(fp.read(),fname,'exec'),globals(),paraf)
        except IOError:
            self._log.warning("parasitics file '%s' not found"%fname)
        except Exception as e:
            self._log.exception("error reading parasitics")

        para = dict()
        for p in _parasitic_params:
            para[p] = paraf.get(p,_default_parasitics[p])

        if self._cfg['r_data_source'].lower() == 'coldfet':
            self.__parasitics['rg'] = para['rg']
            self.__parasitics['rs'] = para['rs']
            self.__parasitics['rd'] = para['rd']
        else:
            self.__parasitics['rg'] = self._cfg['rg_fixed']
            self.__parasitics['rs'] = self._cfg['rs_fixed']
            self.__parasitics['rd'] = self._cfg['rd_fixed']

        if self._cfg['l_data_source'].lower() == 'coldfet':
            self.__parasitics['lg'] = para['lg']
            self.__parasitics['ls'] = para['ls']
            self.__parasitics['ld'] = para['ld']
        else:
            self.__parasitics['lg'] = self._cfg['lg_fixed']
            self.__parasitics['ls'] = self._cfg['ls_fixed']
            self.__parasitics['ld'] = self._cfg['ld_fixed']
            
        for p in _parasitic_params_no_rl:
            self.__parasitics[p] = para[p]
            
    def clear(self):
        """Clear model data and cache data stored in memory."""
        self.__tsreader.purge()

    def coldfet(self, lr_files=None, c_file=None):
        """Run a coldfet extraction on a set of files."""
        # copy existing parasitics
        para = self.__parasitics.copy()

        # read coldfet files and deembed them if so configured
        try:
            if lr_files is None:
                lr_files = self._cfg['coldfet_files']
            real_lr_files = self._read_sp_files(lr_files)
        except:
            self._log.exception("coldfet(): failure during file read/deembed.")
            return

        real_c_file = None
        try:
            if c_file is None:
                c_file = self._cfg['coldfet_cfringe_file']
            if c_file:
                # read and deembed the cfringe file
                t = self._read_sp_files([c_file])
                if len(t):
                    real_c_file = t[0]
        except:
            self._log.warning("coldfet(): %s: unable to read file - extraction of fringing capacitance disabled"%c_file)

        # create a set of keywords to pass to coldfet()
        kw = dict()
        for p in ('coldfet_rfreq_ghz', 'coldfet_min_lfreq_ghz',
            'coldfet_max_lfreq_ghz', 'coldfet_min_cfreq_ghz', 'coldfet_max_cfreq_ghz',):
            kw[p] = self._cfg[p]

        try:
            # run the coldfet extraction
            cfdata = coldfet(lr_files=real_lr_files,c_file=real_c_file,**kw)
        except:
            self._log.exception("coldfet(): extraction failed")
            return

        para.update(cfdata)

        # write a parasitics data file
        f = open(self._cfg['parasitics_file'],'w')
        f.write("# This file is generated automatically by coldfet extraction.\n#\n")
        f.write("# ***** IMPORTANT NOTES: *****\n")
        f.write("# The values of rg, rs, and rd found here are only used\n")
        f.write("# by the model extraction engine if the configuration\n")
        f.write("# parameter 'r_data_source' is set to 'coldfet'\n#\n")
        f.write("# The values of lg, ls, and ld found here are only used\n")
        f.write("# by the model extraction engine if the configuration\n")
        f.write("# parameter 'l_data_source' is set to 'coldfet'\n#\n")
        for p in _parasitic_params:
            f.write("%s = %g\n"%(p,para[p]))
        f.close()

        # re-read parasitics
        self.read_parasitics()

    def yfit(self, files=None):
        """Run a y-fit extraction on a set of files."""
        if files is None:
            files = self._cfg['sparam_files']
        # read in data files
        real_files = expand_file_list(files)

        # run the yfit on each file and store the result in the model
        for fn in real_files:
            model_name = os.path.splitext(fn)[0]+self._cfg['model_extension']

            # get the S-param data
            self._log.info("yfit(): on '%s'"%fn)
            data = self.__tsreader.read(fn)

            # create a new model and set the parasitics
            model = FET_SS_Model()
            model.update(self.__parasitics)

            # remove the parasitics from the data
            # run the y-fit and update the model
            try:
                self._yfit(data,model)
            except Exception as e:
                self._log.exception("yfit(): %s: failed"%fn)
                continue

            # write the updated model data to the output file
            write_ss_model(model_name,model)

    def optimize(self, files=None, worker=None):
        """Run an optimization on a set of files."""
        if files is None:
            files = self._cfg['sparam_files']
        # read in data files
        real_files = expand_file_list(files)

        # run the optimization on each model
        for fn in real_files:
            model_name = os.path.splitext(fn)[0]+self._cfg['model_extension']

            # make sure the model exists (a y-fit has been run)
            if not os.path.isfile(model_name):
                self._log.error("optimize(): %s: optimization not possible, no model data exists."%fn)
                continue

            # read the S-param data and model data
            self._log.info("optimize(): on '%s'"%fn)
            data = self.__tsreader.read(fn)
            model = read_ss_model(model_name)

            # run the optimization
            try:
                self._optimize(data,model,worker)
            except Exception as e:
                self._log.exception("optimize(): %s: failed."%fn)
                continue

            # write the updated model data
            write_ss_model(model_name,model)

    def yfit_and_optimize(self, files=None, worker=None):
        """Sequentially run a y-fit and optimization on a set of files."""
        if files is None:
            files = self._cfg['sparam_files']
        # read in data files
        real_files = expand_file_list(files)

        # run the yfit and then optimization on each model
        for fn in real_files:
            model_name = os.path.splitext(fn)[0]+self._cfg['model_extension']

            # get the S-param data
            self._log.info("yfit_and_optimize(): on '%s'"%fn)
            data = self.__tsreader.read(fn)

            # create a new model and set the parasitics
            model = FET_SS_Model()
            model.update(self.__parasitics)

            # remove the parasitics from the data
            # run the y-fit and update the model
            try:
                self._yfit(data,model)
            except Exception as e:
                self._log.exception("yfit_and_optimize(): %s: failed Y-fit."%fn)
                continue

            # run the optimization
            try:
                self._optimize(data,model,worker)
            except Exception as e:
                self._log.exception("yfit_and_optimize(): %s: failed optimization."%fn)
                continue

            # write the updated model data
            write_ss_model(model_name,model)
    
    def noise(self, files=None):
        "noise model extraction"
        if files is None:
            files = self._cfg['noise_files']
        # read in data files
        real_files = expand_file_list(files)
        
        # read in the noise fixtures
        fxaf = self._cfg['noise_fxa']
        fxbf = self._cfg['noise_fxb']
        srcf = self._cfg['noise_src_s1p']
        if not fxaf or not fxbf:    
            raise ValueError("parameters 'noise_fxa' and 'noise_fxb' must be specified")

        fxa = Touchstone(fxaf)
        fxb = Touchstone(fxbf)
        if fxa.nports != 2:
            raise ValueError("'noise_fxa' file '%s' does not contain s2p data"%fxaf)
        if fxb.nports != 2:
            raise ValueError("'noise_fxb' file '%s' does not contain s2p data"%fxbf)            
        
        fxa.convert('s')
        fxb.convert('s')
        nsrc = None
        if srcf:
            nsrc = Touchstone(srcf)
            if nsrc.nports != 1:
                raise ValueError("'noise_src_s1p' file '%s' does not contain s1p data"%srcf)
            nsrc.convert('s')
        
        # run the noise extraction on each file
        for fn in real_files:
            self._log.info("noise(): starting extraction on '%s'"%fn)
            
            # get file names
            base = os.path.splitext(fn)[0]
            spar_name = base+self._cfg['noise_sparam_extension']
            model_name = base+self._cfg['model_extension']

            # read the FET S-param data
            try:
                spars = Touchstone(spar_name)
            except Exception as e:
                self._log.error("noise(): unable to read S-parameter file '%s'"%spar_name)
                continue
            
            # read the model
            try:
                model = read_ss_model(model_name)
            except Exception as e:
                self._log.error("noise(): unable to read model '%s'"%model_name)
                continue
            
            # read the measured noise data
            flistm, nfmeas, gmeas = [], [], []
            head = []
            hd = False
            try:
                fp = open(fn,'r')
                try:
                    for line in fp:
                        if line.startswith('!'):
                            if not hd and not line.find('Freq (Hz)') > 0:
                                head.append(line.rstrip())
                                
                            continue
                        
                        try:
                            d = [float(x) for x in line.split()]
                            hd = True
                        except Exception:
                            continue
                        
                        if len(d) == 3:
                            if d[2] > 50.0:
                                # bad measurement point
                                continue
                            flistm.append(d[0])
                            gmeas.append(d[1])
                            nfmeas.append(d[2])
                finally:
                    fp.close()
            
            except Exception as e:
                self._log.error("noise(): '%s': unable to read noise data file => %s"%(fn,e))
                continue
            
            # read stuff from the noise file header
            tcelcius, ugw, ngf = None, None, None
            vgs, vds, igs, ids = 0.0, 0.0, 0.0, 0.0
            try:
                for line in head:
                    if line.startswith('!TEMPERATURE'):
                        tcelcius = float(line.split()[-1])
                    elif line.startswith('!BIAS:'):
                        # read bias info
                        try:
                            d = line.split()
                            vds, ids = float(d[3]), float(d[7])
                            vgs, igs = float(d[11]), float(d[15])
                        except:
                            pass
                    elif line.startswith('!UNIT GATE WIDTH'):
                        ugw = float(line.split()[-1])                
                    elif line.startswith('!NUMBER OF GATE'):
                        ngf = int(line.split()[-1])
            except Exception as e:  
                self._log.error("noise(): '%s': error reading header => %s"%(fn,e))
                continue
            
            if tcelcius is None:
                tcelcius = 25.0
                self._log.warning("noise(): '%s': could not read measurement temperature from header"%fn)
            
            # don't bother to model bias points with Ids less than 5 mA/mm
            # could parameterize this, but for now hard coding is OK
            if ngf and ugw:
                min_ids = (ugw*ngf*0.001)*(self._cfg['noise_min_ids_mamm']*0.001)
                if ids < min_ids:
                    self._log.warning("noise(): '%s': Ids less than threshold - skipping"%fn)
                    continue
                            
            # force room temperature to be 25C
            # and compute absolute temperature
            if 24.9 < tcelcius < 27.1:
                tcelcius = 25.0
            tkelvin = tcelcius + 273.15
            
            # deembed the noise figure and gain using the fixtures and DUT S-parameters
            nfdmbt, gdmbt, gammast = deembed_nf_and_gain(flistm,nfmeas,gmeas,spars,fxa,fxb,gamma=nsrc,kelvin=tkelvin)
            
            # trim out bad data
            flist, nfdmb, gdmb, gammas = [], [], [], []
            for i,f in enumerate(flistm):
                if nfdmbt[i] < self._cfg['noise_min_nfigure'] or nfdmbt[i] > self._cfg['noise_max_nfigure']:
                    # lossy device, bad deembedding, or invalid noise figure measurement
                    continue
                if abs(gammast[i]) > self._cfg['noise_max_gamma']:
                    # high reflection points tend to have accuracy issues
                    continue
                
                # compute available gain of the DUT and compare it to the gain measured during noise figure
                # if the difference is too large then skip this point as well
                gdev = network_params.ga(spars.extract(f).data,gammast[i])
                if gdev < 1.0e-3:
                    continue
                gdevdb = 10.0*math.log10(gdev)
                if abs(gdevdb-gdmbt[i]) > self._cfg['noise_max_gain_error']:
                    continue
                
                flist.append(f)
                nfdmb.append(nfdmbt[i])
                gdmb.append(gdmbt[i])
                gammas.append(gammast[i])
            
            if len(flist) < self._cfg['noise_min_npoints']:
                self._log.warning("noise(): '%s': not enough good data for model extraction"%fn)
                continue
            
            # pass the data off to the subroutine that runs the extraction
            try:
                self._noise(model,flist,nfdmb,gammas,tkelvin)
            except Exception as e:
                self._log.error("noise(): '%s': error in extraction => "%(fn,e))
                continue
            
            # write the updated model data
            write_ss_model(model_name,model)
            
            # write the noise extraction output file
            # do it to a memory-based file first so that we can check for
            # errors due to oscillating data files
            fp = StringIO()
            fp.write('\n'.join(head)+'\n')
            # measured vs. modeled errors
            fp.write('!\n!Measured vs. Modeled:\n! Freq   NF_meas NF_mod Error\n! (GHz)   (dB)   (dB)   (dB)\n')
            for i,f in enumerate(flist):
                ys = (1.0-gammas[i]) / (50.0*(1.0+gammas[i]))
                try:
                    yp, cy = model.compute_y_and_n(f,two_port=True,kelvin=tkelvin)
                    n = 10.0*math.log10(noise_figure_cy(yp,cy,ys=ys))
                    fp.write('!%7.3f%7.3f%7.3f%7.3f\n'%(f*1.0e-9,nfdmb[i],n,nfdmb[i]-n))
                except Exception:
                    pass
            
            # noise parameters vs. frequency
            fp.write('!\n')
            fp.write('!Freq    Fmin    Gamma_Opt     Rn    Vds       Ids       Vgs       Igs           Noise_Params         Gain\n')
            fp.write('!(GHz)   (dB)   Mag    Ang   (Ohms)  (V)       (A)       (V)       (A)      <vv*>/4kT0   <ii*>/4kT0   (dB)\n')
            ##       'xxxxxxx xxxxxx xxxxx xxxxxxx xxxxxx xxxxxx xxxxxxxxxxx xxxxxxx xxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxxx xxxxxx\n'
            f = 0.5
            vv = model['vv'].v
            ii = model['ii'].v
            while f < 50.1:
                try:
                    yp, cy = model.compute_y_and_n(f*1.0e9,two_port=True,kelvin=tkelvin)
                    fmin, rn, yopt = noise_parameters(yp,cy)
                    gopt = network_params.refly(yopt)
                    sp = y2s_2port_50ohms(yp)
                    g = 10.0*math.log10(network_params.ga(sp,gopt))
                    mag = abs(gopt)
                    ang = (180.0/math.pi)*cmath.phase(gopt)
                    fp.write('%7.3f %6.3f %5.3f %7.2f %6.3f %6.3f %11.4e %7.3f %11.4e %12.5e %12.5e %6.3f\n'%(f,10.0*math.log10(fmin),mag,ang,rn,
                        vds,ids,vgs,igs,vv,ii,g))
                except Exception:
                    pass
                f += 0.5
            
            data = fp.getvalue()
            fp.close()
            
            # write the actual file
            fp = open(base+self._cfg['noise_output_extension'],'w')
            fp.write(data)
            fp.close()
            

    def _noise(self, model, flist, nf, gammas, tkelvin):
        "noise model extraction inner routine"
        
        ys = []
        for g in gammas:
            ys.append((1.0-g) / (50.0*(1.0+g)))
        
        # set up the optimization data structures
        self.__opt_noise_data = model, flist, nf, ys, tkelvin 
        self.__opt_err = None
        self.__opt_ierr = None
        
        # set starting values and optimization ranges for vv and ii
        if model['vv'].v == 0.0 and model['ii'].v == 0.0:
            model['vv'].v = 4.0
            model['vv'].set_opt_range(0.01,15.0)
            model['ii'].v = 0.1
            model['ii'].set_opt_range(0.005,2.0)
        
        # create the optimization worker
        wobj = get_worker('gradient')(self._noise_opt_cb,model.get_params(['vv','ii']))
        
        # configure the worker
        wobj.config_from_global()

        # create the engine
        engine = BasicEngine(worker=wobj,iter=20,itercb=self._opt_iter_cb)

        # run the optimizer
        engine.optimize()
        
        if self.__opt_err is not None and self.__opt_ierr is not None:
            self._log.debug("optimization initial error = %s   final error = %s"%(self.__opt_ierr,self.__opt_err))
        
        # cleanup
        del self.__opt_noise_data
        del self.__opt_err
        del self.__opt_ierr

    def _remove_parasitics(self, data):
        "remove parasitics from a set of data - for debugging purposes"
        return remove_parasitics(data,self.__parasitics)        
            
    def _yfit(self, data, model=None):
        """internal yfit implementation that works with a data set in which
        parasitics have been removed
        """
        # generate a set of keywords to pass to yfit
        pnames = ('yfit_min_cfreq_ghz','yfit_max_cfreq_ghz','yfit_min_gmfreq_ghz',
            'yfit_max_gmfreq_ghz','yfit_min_taufreq_ghz','yfit_max_taufreq_ghz',
            'yfit_min_ggsfreq_ghz','yfit_max_ggsfreq_ghz','yfit_enable_ggsggd')
        kw = dict()
        for p in pnames:
            kw[p] = self._cfg[p]

        # run the y-fit
        vals = yfit(remove_parasitics(data,self.__parasitics),**kw)
        
        # turn off model parameters that are not enabled
        if not self._cfg['yfit_enable_tau2']:
            vals['tau2'] = 0.0
        if not self._cfg['yfit_enable_rgd']:
            vals['rgd'] = 0.0
        if not self._cfg['yfit_enable_ggsggd']:
            vals['ggs'] = 0.0
            vals['ggd'] = 0.0
        
        # massage any values that come out negative
        for k in vals:
            v = vals[k]
            if k == 'ri' and v < 1.0e-6:
                vals[k] = 1.0e-6
                self._log.debug("_yfit(): modifying small/negative value of 'ri' to 1.0e-6")
            elif v < 0.0:
                vals[k] = 0.0
                self._log.debug("_yfit(): modifying negative value of '%s' to 0.0"%k)

        # if the model was passed, update it with the Y-fit values
        if model:
            model.update(vals)
            self._set_opt_ranges(model)

    def _optimize(self, data, model, worker):
        """internal implementation of optimization"""

        # set up the optimization data structures
        self.__opt_regions = []
        self.__opt_model = model
        self.__opt_err = None
        self.__opt_ierr = None
        self.__opt_parms = self._cfg['ss_opt_percent_error'], self._cfg['ss_opt_linear_error']
        
        # extract s-param data from the dataset
        sdata = data.extract_and_convert(None,'s',rawfmt=True)
        flist = data.flist
        
        # break the optimization into regions based on configured criteria
        #  this data is then used to build the optimization data
        for regwght,fmin,fmax,wgts in self._create_opt_regions(data):
            # find any data that exists between the specified fmin and fmax of the region
            flr, sr = [], []
            for i,f in enumerate(flist):
                if f >= fmin and f <= fmax:
                    flr.append(f)
                    sr.append(sdata[i])
            
            if len(flr):
                yr = s2y_2port_50ohms(sr)
                k,mag = compute_k_and_mag(sr)            
                self.__opt_regions.append( (regwght,flr,wgts,sr,yr,k,mag) )
            else:
                self._log.info("_optimize(): region defined with [%g <= freq <= %g] resulted in no data for optimization"%(fmin,fmax))
        
        if not self.__opt_regions:
            raise RuntimeError("_optimize(): configuration resulted in no data for optimization")        

        ##### data sets are now ready to optimize, configure the optimization #####

        # determine the set of parameter names and get a list of those
        # parameter objects from the model
        pnames = list(_internal_params)
        if self._cfg['optimize_parasitics']:
            pnames.extend(_parasitic_params)

        # create the optimization worker
        if not worker:
            worker = self._cfg['ss_opt_default_worker']
        wobj = get_worker(worker)(self._opt_cb,model.get_params(pnames))
        
        # configure the worker
        wobj.config_from_global()

        # create the engine
        engine = BasicEngine(worker=wobj,iter=20,itercb=self._opt_iter_cb)

        # run the optimizer
        engine.optimize()
        
        if self.__opt_err is not None and self.__opt_ierr is not None:
            self._log.debug("optimization initial error = %s   final error = %s"%(self.__opt_ierr,self.__opt_err))
        
        # cleanup
        del self.__opt_regions
        del self.__opt_model
        del self.__opt_err
        del self.__opt_ierr
        del self.__opt_parms

    def _read_sp_files(self, files):
        """Read and deembed S-parameter files.
        Returns a list of BiasedTouchstone datasets.
        """
        flist = expand_file_list(files)
        if not len(flist):
            self._log.warning("_read_sp_files(): no files to read.")
            return []

        ret = []
        for fn in flist:
            ret.append(self.__tsreader.read(fn))

        return ret

    def _set_opt_ranges(self, model):
        "set up optimization ranges for model parameters"

        # set all parasitic parameters to have zero range
        for p in _parasitic_params:
            op = model[p]
            op.set_opt_range(op.v,op.v)
        
        # set capacitances to have 10% optimization range
        op = model['cgs']
        op.set_opt_range(op.v*0.9,op.v*1.1)  
        op = model['cgd']
        op.set_opt_range(op.v*0.9,op.v*1.1)  
        op = model['cds']
        op.set_opt_range(op.v*0.9,op.v*1.1)          
        
        # set gm and gds to 20% optimization range
        op = model['gm']
        op.set_opt_range(op.v*0.8,op.v*1.2)  
        op = model['gds']
        op.set_opt_range(op.v*0.8,op.v*1.2)  
        
        # set tau and tau2 to 10% optimization ranges
        op = model['tau']
        if op.v < 1.0e-13:
            op.set_opt_range(0.0,1.0e-12)
        else:
            op.set_opt_range(op.v*0.9,op.v*1.1)
        op = model['tau2']
        if op.v == 0.0:
            op.set_opt_range(0.0,0.0)  
        elif op.v < 1.0e-13:
            op.set_opt_range(1.0,1.0e-12)
        else:
            op.set_opt_range(op.v*0.9,op.v*1.1)
        
        # set ggs and gds to 50% optimization ranges
        op = model['ggs']
        op.set_opt_range(op.v*0.5,op.v*1.5)
        op = model['ggd']
        op.set_opt_range(op.v*0.5,op.v*1.5)
        
        # set up ri's range
        op = model['ri']
        if op.v < 1.0e-2:
            op.set_opt_range(1.0e-6,1.0)
        elif op.v < 0.1:
            op.set_opt_range(1.0e-4,1.0)
        elif op.v < 1.0:
            op.set_opt_range(1.0e-2,3.0)
        else:
            op.set_opt_range(op.v*0.2,op.v*3.0)
        
        # set up rgd's range
        op = model['rgd']
        if op.v == 0.0:
            op.set_opt_range(0.0,0.0)
        elif op.v < 0.1:
            op.set_opt_range(1.0e-4,1.0)
        elif op.v < 1.0:
            op.set_opt_range(1.0e-2,3.0)
        else:
            op.set_opt_range(op.v*0.2,op.v*3.0)

    def _create_opt_regions(self, data):
        "create a set of optimization ranges and weights"
        default_wgts = {'s11':1.0, 's12':1.0, 's21':1.0, 's22':1.0}

        region_cfg = self._cfg['ss_optimize_regions']
        if not region_cfg:
            return [(1.0, data.fmin, data.fmax, default_wgts),]
        
        output = []
        for i,data in enumerate(region_cfg):
            w,fmin,fmax,wghts = data
            w = abs(float(w))
            fmin = float(fmin)*1.0e9
            fmax = float(fmax)*1.0e9
            
            if not wghts:
                wout = default_wgts
            else:
                # trim out invalid weight values
                wout = {}
                for k in wghts:
                    if k in _optimizer_names:
                        try:
                            v = abs(float(wghts[k]))
                        except:
                            continue
                        wout[k] = v

                if not wout:
                    self._log.warning("_create_opt_regions(): 'ss_optimize_regions' index %d had no valid parameter weighting values -> falling back to defaults")
                    wout = default_wgts

            output.append( (w,fmin,fmax,wout) )

        if not output:
            self._log.warning("_create_opt_regions(): evaluation of 'ss_optimize_regions' configuration variable yielded no regions -> falling back to defaults")
            return [(1.0, data.fmin, data.fmax, default_wgts),]

        return output

    def _opt_cb(self):
        """Optimization callback."""
        et = 0.0
        pct_mode, L1_mode = self.__opt_parms

        # iterate over all defined optimization regions
        for regwght,flist,wgts,smeas,ymeas,kmeas,magmeas in self.__opt_regions:
            err = [0.0 for e in _optimizer_names]
            
            # compute Y-params
            yp = self.__opt_model.compute_y(flist,True)
            # convert to S-params
            sp = y2s_2port_50ohms(yp)
            # if k or mag weights are non-zero then compute them
            if 'k' in wgts or 'mag' in wgts:
                k,mag = compute_k_and_mag(sp)

            # compute error values
            for i in range(len(flist)):
                for j,e in enumerate(_optimizer_names):
                    if e in wgts:
                        norm = 1.0
                        # only compute if the weighting value is defined
                        if e == 's11':
                            ev = abs(sp[i][0,0] - smeas[i][0,0])
                            if pct_mode:
                                norm = abs(smeas[i][0,0])
                        elif e == 's12':
                            ev = abs(sp[i][0,1] - smeas[i][0,1])
                            if pct_mode:
                                norm = abs(smeas[i][0,1])
                        elif e == 's21':
                            ev = abs(sp[i][1,0] - smeas[i][1,0])
                            if pct_mode:
                                norm = abs(smeas[i][1,0])
                        elif e == 's22':
                            ev = abs(sp[i][1,1] - smeas[i][1,1])
                            if pct_mode:
                                norm = abs(smeas[i][1,1])
                        elif e == 'y11':
                            ev = abs(yp[i][0,0] - ymeas[i][0,0])
                            if pct_mode:
                                norm = abs(ymeas[i][0,0])
                        elif e == 'y12':
                            ev = abs(yp[i][0,1] - ymeas[i][0,1])
                            if pct_mode:
                                norm = abs(ymeas[i][0,1])
                        elif e == 'y21':
                            ev = abs(yp[i][1,0] - ymeas[i][1,0])
                            if pct_mode:
                                norm = abs(ymeas[i][1,0])
                        elif e == 'y22':
                            ev = abs(yp[i][1,1] - ymeas[i][1,1])
                            if pct_mode:
                                norm = abs(ymeas[i][1,1])
                        elif e == 'k':
                            ev = abs(k[i] - kmeas[i])
                            if pct_mode:
                                norm = abs(kmeas[i])
                        elif e == 'mag':
                            ev = abs(mag[i] - magmeas[i])
                            if pct_mode:
                                norm = abs(magmeas[i])

                        # make sure the normalizer is not too small to cause numerical problems
                        if norm < 1.0e-50:
                            norm = 1.0e-50

                        # add the error to the composite for the parameter
                        if L1_mode:
                            err[j] += ev / norm
                        else:
                            err[j] += (ev*ev) / norm

            # compute the total weighted error for this region
            er = 0.0
            for j,e in enumerate(_optimizer_names):
                if e in wgts:
                    er += err[j]*wgts[e]
            et += regwght * (er / float(len(flist)))

        return et

    def _noise_opt_cb(self):
        "noise optimization callback"
        
        model, flist, nf, ys, tk = self.__opt_noise_data
        e = 0.0
        
        for i,f in enumerate(flist):
            
            yp, cy = model.compute_y_and_n(f,two_port=True,kelvin=tk)
            n = 10.0*math.log10(noise_figure_cy(yp,cy,ys=ys[i]))
            x = abs(n-nf[i])
            e += x*x
        
        return e

    def _opt_iter_cb(self, n, v):
        if self.__opt_err is not None:
            if v[0] >= self.__opt_err:
                self._log.debug("optimization stopped on iteration %d"%n)
                raise StopOptimization
        else:
            self.__opt_ierr = v[0]
        self.__opt_err = v[0]
        
        
