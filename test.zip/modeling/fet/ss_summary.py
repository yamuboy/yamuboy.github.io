from __future__ import unicode_literals, absolute_import, division, print_function
from .dscrreader import DSCRModel
from .dscr2mdif2 import dscr_models_to_mdif
from . import load_ss_model
from .. import load_config, _str_type
from datetime import datetime
import logging
import sys, os, os.path, re
from fnmatch import fnmatch
from optparse import OptionParser
from functools import cmp_to_key
if not hasattr(__builtins__,'cmp'):
    # python3 hack
    cmp = lambda a, b: (a > b)-(a < b)  

_log = logging.getLogger('modeling.ss_summary')

_scale_factors = { 'lg':1.0e12, 'ls':1.0e12, 'ld':1.0e12,
    'cgs':1.0e12, 'cgd':1.0e12, 'cds':1.0e12, 'cpg':1.0e12,
    'cpd':1.0e12, 'c11':1.0e12, 'c22':1.0e12,
    'tau':1.0e12, 'tau2':1.0e12,
    'gm':1.0e3, 'gds':1.0e3, 'ggd':1.0e3, 'ggs':1.0e3 }

def load_fet_ss_model_data( dir_list=[], s2p_pattern='*.dmb', old_style=False, include_noise=True, quiet=False, model_extension=None ):
    """load small-signal model data from 1 or more modeled directories"""
    
    if not isinstance(dir_list,(tuple,list)):
        raise TypeError("'dir_list' must be a list or tuple")
    
    if not len(dir_list):
        dir_list = ['.']
    
    loadss_kw = {}
    if old_style:
        loadss_kw['old_style'] = True
    if model_extension:
        loadss_kw['extension'] = model_extension
    
    model_list = []
    for i,dirname in enumerate(dir_list):
        if not isinstance(dirname,_str_type):
            _log.warning("load_fet_ss_model_data(): non-string data at index %d of 'dir_list'"%i)
            continue
        absdir = os.path.realpath(dirname)
        if not os.path.isdir(absdir):
            _log.warning("load_fet_ss_model_data(): '%s' is not a directory"%dirname)
            continue
        
        # get a list of S-parameter files in the directory
        flist = []
        for fn in os.listdir(absdir):
            if fnmatch(fn,s2p_pattern) and os.path.isfile(os.path.join(absdir,fn)):
                flist.append(fn)
        flist.sort()
        
        if not len(flist):
            _log.warning("load_fet_ss_model_data(): no files match patten '%s' in '%s'"%(s2p_pattern,dirname))
            continue
        
        # read the first S-param data file to get header information
        # and stuff like NGF, UGW, and DC measured parameters
        try:
            header_data, header_lines = _read_header_info(os.path.join(absdir,flist[0]))
            periph = header_data['ugw']*header_data['ngf']
        except Exception as e:
            _log.warning("load_fet_ss_model_data(): error loading header data in path '%s'"%dirname)
            continue
        
        # add some additional data to the header data
        # hard code to use Vpo @ 3 volts as the vpo metric
        header_data['vpo'] = header_data['vpo3']
        header_data['filename'] = absdir
        
        # check for the presense of noise model files
        has_noise = False
        if include_noise:
            for fn in flist:
                base, ext = os.path.splitext(fn)
                if old_style:
                    nn = os.path.join(absdir,'n'+base[1:]+'.rpc')
                else:
                    nn = os.path.join(absdir,base+'.rpc')
                
                if os.path.isfile(nn):
                    has_noise = True
                    break
                    
        header_data['has_noise'] = has_noise
        
        # create the DSCRModel object 
        model = DSCRModel()
        
        # read model files
        for fn in flist:
            base, ext = os.path.splitext(fn)
            absfn = os.path.join(absdir,fn)
            shortfn = os.path.normpath(os.path.join(dirname,fn))
            if old_style:
                nn = os.path.join(absdir,'n'+base[1:]+'.rpc')
            else:
                nn = os.path.join(absdir,base+'.rpc')
            
            try:
                ssm = load_ss_model(absfn,**loadss_kw)
            except Exception as e:
                if not quiet:
                    _log.warning("load_fet_ss_model_data(): '%s': no model data"%shortfn)
                continue
                
            if has_noise and not os.path.isfile(nn):
                if not quiet:
                    _log.warning("load_fet_ss_model_data(): '%s': no noise data"%shortfn)
                continue
            
            try:
                dset = {}
                # read the bias information
                dset['vds'], dset['ids'], dset['vgs'], dset['igs'] = _read_bias_info(absfn)
                # compute ids in mamm
                dset['mamm'] = dset['ids']*1000.0 / periph
                
                # read the noise model file
                if has_noise:
                    dset['vv'], dset['ii'] = _read_noise_model_params(nn)
                
                # scale the small-signal parameters to the units that are expected
                # by the DSCRModel object and add them to the set
                for p in ssm.params.values():
                    dset[p.name] = p.value*_scale_factors.get(p.name,1.0)
                    
                # add the data to the DSCRModel object
                model.add_data(dset)
            except Exception as e:
                if not quiet:
                    _log.warning("load_fet_ss_model_data(): '%s': error loading data %s => "%(shortfn,e))
        
        if not len(model):
            _log.warning("load_fet_ss_model_data(): in path '%s': no model data read"%dirname)
            continue
        
        # append the model to the list and add summary data from the file header
        model_list.append( (model,header_lines) )
        model.summary = header_data        
                
    # model list has now been read
    return model_list
    
def _read_header_info(fname):
    "read header info from an s2p data file"
    
    # read the file
    header_lines = []
    fp = open(fname,'r')
    for line in fp:
        if not line.startswith('!'):
            break
        header_lines.append(line)
    fp.close()
    
    def _header_field( s ):
        "get header field data"
        j = s.find(':')
        if j < 0:
            return ''
        return s[j+1:].strip()
    
    # populate the data set with header info
    d = {
        'device':'',
        'wafer':'',
        'ugw':1.0,
        'ngf':1.0,
        'temp':25.0,
        'vbr1':-99.0,
        'vbr2':-99.0,
        'idss':0.0,
        'imax':0.0,
        'vpo1p5':0.0,
        'vpo3':0.0,
        'vmax':0.0,
        'vpo1ma':0.0,
        'ron':0.0,
    }
    dcidx = -1
    for i,line in enumerate(header_lines):
        if line.startswith('!DEVICE NAME'):
            d['device'] = _header_field(line)
        elif line.startswith('!WAFER NUMBER'):
            d['wafer'] = _header_field(line)
        elif line.startswith('!UNIT GATE WIDTH'):
            d['ugw'] = float(_header_field(line))
        elif line.startswith('!NUMBER OF GATE'):
            d['ngf'] = float(_header_field(line))
        elif line.startswith('!TEMPERATURE'):
            d['temp'] = float(_header_field(line))
            if abs(d['temp']-27.0) < 0.1:
                # coerce 27C to 25C for consistency with other stuff
                d['temp'] = 25.0
        elif line.startswith('!Vbr (.1mA)'):
            dcidx = i+1
        
    if dcidx < 0 or dcidx >= len(header_lines):
        _log.warning("_read_header_info(): could not read DC parameters")
    else:        
        try:
            sf = 1.0e6/(d['ugw']*d['ngf'])
            y = [float(x) for x in header_lines[dcidx][1:].split()]
            if len(y) < 8:
                raise ValueError("missing parameters")
            
            d['vbr1'] = y[0]
            d['vbr2'] = y[1]
            d['idss'] = y[2]*sf
            d['vpo3'] = y[3]
            d['imax'] = y[4]*sf
            d['vpo1p5'] = y[5]
            d['vmax'] = y[6]
            d['vpo1ma'] = y[7]
            if len(y) > 8:
                d['ron'] = y[8]*(1000.0/sf)
            else:
                d['ron'] = 0.0
        except Exception as e:
            _log.warning("_read_header_info(): could not parse DC parameters => %s"%e)
    
    return d, header_lines
        
def _read_bias_info(fname):
    "read noise model parameters from a .rpc file"
    vds, ids, vgs, igs = None, None, None, None
    pat = re.compile('^[!#]*')
    fp = open(fname,'r')
    for line in fp:
        #if not line.startswith('!'):
        if not re.match(pat, line):
            break
        
        if line.startswith('!BIAS:'):
            d = line.split()
            vds = float(d[3])
            ids = float(d[7])*1000.0
            vgs = float(d[11])
            igs = float(d[15])*1000.0
            break
         
    fp.close()
    
    if vds is None:
        _log.warning("'%s': could not read bias information"%fname) 
        vds, ids, vgs, igs = 0.0, 0.0, 0.0, 0.0
    
    return vds, ids, vgs, igs
    
    
def _read_noise_model_params(fname):
    "read noise model parameters from a .rpc file"
    vv, ii = None, None
    fp = open(fname,'r')
    for line in fp:
        if line.startswith('!'):
            continue
        
        d = line.split()
        if len(d) == 12:
            vv = float(d[9])
            ii = float(d[10])
            break
    fp.close()
    
    if vv is None:
        raise ValueError("'%s': could not read noise model parameters"%fname) 
    
    return vv, ii
    
    
    
    
#### DSCR file header blocks ####
_dscr_h1 = """!
!Model Dev           Lot              Temp  Periphery UGW   NGF Vbr (.1mA)  Vbr (1mA)   Idss (3V)   Vpo (3V)   Imax (1.5V)  Vpo (1.5V) Vmax (1.5V) Vpo (1mA/mm)    R-on
!                                     (C)     (um)    (um)         (V)        (V)        (mA/mm)      (V)        (mA/mm)       (V)         (V)         (V)       (ohm*mm)  
"""
_dscr_h2 = """!    
! FET MODEL DSCR PROGRAM VERSION 3.00 %s
!
BEGIN DSCRDATA
%% index   Periphery      ugw         ngf         Vds         Ids        mA_mm        Vgs         Igs         Rg          Rs          Rd          Ri          Cgs         Cdg         Cds         C1          C2          Ls          Lg          Ld          Ggs         Gdg         Gm          T1          Gds         T2          C11         C22%s
"""
    
def write_dscr_file( model_list, outname='linfet.dscr', header=None ):
    """write a DSCR data file"""
    
    def vpo_sort_func(a,b):
        "sort DSCRModel objects by increasing Vpo"
        return cmp(a['vpo'],b['vpo'])
        
    def vgs_sort_func(a,b):
        "sort by ascending vgs"
        return cmp(a['vgs'],b['vgs'])
    
    if not len(model_list):
        raise ValueError("'model_list' is empty")
        
    # copy the model list so it can be sorted
    models = model_list[:]
    models.sort(key=cmp_to_key(vpo_sort_func))

    # make sure that all models are consistent w.r.t. noise
    has_noise = bool(models[0]['has_noise'])
    if len(models) > 1:
        for m in models[1:]:
            if bool(m['has_noise']) != has_noise:
                has_noise = False
                _log.warning("write_dscr_file(): consistency check problem for noise/no-noise -> noise data WILL NOT be added")
                break
    
    # write the header
    fp = open(outname,'w')
    
    if header:
        if isinstance(header,(list,tuple)):
            for line in header:
                line = '{}'.format(line)
                fp.write(line)
                if line[-1:] != '\n':
                    fp.write('\n')
        elif isinstance(header,_str_type):
            fp.write(header)
            if header[-1:] != '\n':
                fp.write('\n')
        else:
            raise TypeError("'header' must be a string or list of strings")
    
    fp.write(_dscr_h1)
    for i,d in enumerate(models):
        periph = d['ugw']*d['ngf']
        dcdata = []
        for p in ('vbr1','vbr2','idss','vpo3','imax','vpo1p5','vmax','vpo1ma','ron'):
            dcdata.append('%+.4e'%d[p])
        fp.write('!%-5d %-13s %-16s %-6.1f %-6.1f %-7.1f %-2d %s\n'%(i+1,d['device'],d['wafer'],d['temp'],periph,d['ugw'],d['ngf'],' '.join(dcdata)))
    noise_headers = ''
    if has_noise:
        noise_headers = '          vv          ii'
    fp.write(_dscr_h2%(datetime.now().strftime('%Y/%m/%d %H:%M:%S'),noise_headers))
    
    # write the model data
    n = 1
    for i,d in enumerate(models):
        periph = d['ugw']*d['ngf']

        fp.write('!DEV_NUM: %d\n'%(i+1))
        
        vdsvals = d.vds_values
        vdsvals.sort()
        for vds in vdsvals:
            # sort data by ascending vgs
            d2 = d.get_rawdata_block(vds)
            d2.sort(key=cmp_to_key(vgs_sort_func))
            
            for modp in d2:
                # write each line
                p = { 'vds':vds, 'periph':periph*0.001, 'ugw':d['ugw'], 'ngf':d['ngf'] }
                p.update(modp)
                pset = []
                for k in ('periph','ugw','ngf','vds','ids','mamm','vgs','igs','rg','rs','rd','ri','cgs','cgd','cds','cpg',
                    'cpd','ls','lg','ld','ggs','ggd','gm','tau','gds','tau2','c11','c22'):
                    pset.append('%+.4e'%p[k])
                if has_noise:
                    pset.append('%+.4e'%p['vv'])
                    pset.append('%+.4e'%p['ii'])
                
                fp.write('%5d    %s\n'%(n,' '.join(pset)))                
                n += 1
           
    fp.write('END DSCRDATA\n')
    fp.close()

def single_device_ss_summary( model, outname='ss.summary' ):
    "write a summary that can be easily read by a large-signal model extraction"
    params = ('ugw','ngf','temp','vbr1','vbr2','idss','imax','vmax','vpo3','vpo1p5','vpo1ma','ron')
    extrinsics = ('rg','rd','rs','lg','ld','ls','cpg','cpd','c11','c22')
    columns = ('vds','vgs','ids','igs','cgs','cgd','cds','gm','tau','ri','gds','tau2','ggs','ggd')
    
    def _sort_func(a, b):
        x = cmp(a['vgs'],b['vgs'])
        if x == 0:
            return cmp(a['vds'],b['vds'])
        else:
            return x
    
    fp = open(outname,'w')
    fp.write('# Path: %s\n'%os.getcwd())
    fp.write('# Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    fp.write('#\n')
    fp.write('# Note: idss and imax are in mA/mm, ron is in ohm*mm\n')
    fp.write('[parameters]\n')
    for p in params:
        fp.write('%s = %g\n'%(p,model[p]))
    fp.write('#\n')
    
    # write extrinsic (fixed) parameters
    fp.write('[extrinsic]\n')
    d0 = model.get_index(0)
    for p in extrinsics:
        fp.write('%s = %g\n'%(p,d0[p]))
    fp.write('#\n')

    # write intrinsic parameters
    data = model.raw_data
    data.sort(key=cmp_to_key(_sort_func))
    
    fp.write('[intrinsic]\n')
    fp.write('#%s\n'%('\t'.join(columns)))
    for d in data:
        x = []
        for p in columns:
            x.append('%+.4e'%d[p])
        fp.write('%s\n'%('\t'.join(x)))
        
    fp.close()    
    
    
def generate_summary( dir_list=[], s2p_pattern='*.dmb', old_style=False, include_noise=True, base_name='linfet' ):
    """generate a small-signal data summary for 1 or more directories"""
    
    # read model data
    model_list = load_fet_ss_model_data(dir_list,s2p_pattern,old_style,include_noise)    
    if not len(model_list):
        raise ValueError("generate_summary(): no models could be read")
    
    
    models = []
    headers = []
    for m,h in model_list:
        models.append(m)
        headers.append(h)
    
    dscrname = base_name+'.dscr'
    mdfname = base_name+'.mdf'
    
    # use data from the first 
    common_header = []
    hfields = ('!PROCESS NAME','!DEVICE NAME','!GATE LENGTH','!GATE TO GATE','!SOURCE-DRAIN')
    for line in headers[0]:
        for f in hfields:
            if line.startswith(f):    
                common_header.append(line)
    
    # write a DSCR summary file
    write_dscr_file(models,dscrname,common_header)
        
    # write a MDF summary file for new-style models
    dscr_models_to_mdif(models,mdfname,common_header=common_header)
    
    # for a single directory summary, create a model summary that is appropriate for large-signal modeling
    if len(dir_list) < 2 and len(model_list) == 1:
        m = models[0]
        if m['has_noise']:
            # regenerate the summary with noise disabled
            m = load_fet_ss_model_data(dir_list,s2p_pattern,old_style,include_noise=False,quiet=True)[0][0]
        
        single_device_ss_summary(m,'ss.summary')
            
def ss_summary_cl():
    "entry point for command-line parsing"
    
    # parse command-line options
    parser = OptionParser(usage='%prog [options] [directory1] [directory2] ...')
    parser.add_option('-x', '--end-files', dest='oldstyle', action="store_true", help='Summarize models stored in *.end files')
    parser.add_option('-z', '--disable-noise', dest='nonoise', action="store_true", help='Do not generate files with noise')
    parser.add_option('-b', '--basename', dest='base', help='Set the base name used to generate output files to BASE')
    parser.add_option('-e', '--ext', '--extension', dest='ext', help='Set the extension of FET s-parameter data files to EXT')
    parser.add_option('-p', '--pat', '--pattern', dest='pattern', help='Set the shell pattern of FET s-parameter data files to PATTERN')
    parser.add_option('-m', '--model-ext', '--model-extension', dest='modext', help='Set the extension of model files to MODEXT')
    parser.add_option('-c', '--config-file', dest='config', help='Read the FET model config file named CONFIG')
    parser.add_option('--debug', dest='debug', action="store_true", help='turn on debugging mode')
    
    options,dirs = parser.parse_args()
    
    if options.ext and options.pattern:
        sys.stderr.write("Error: only one of '--extension' and '--pattern' may be specified at the same time.\n\n")
        sys.exit(1)
        
    kwargs = {}
    config_name = 'fetmod.cfg'
    if options.oldstyle:
        kwargs['old_style'] = True
    if options.nonoise:
        kwargs['include_noise'] = False
    if options.base:
        kwargs['base_name'] = options.base
    if options.config:
        config_name = options.config
    if options.modext:
        kwargs['model_extension'] = options.modext
                
    if options.ext:
        ext = options.ext
        if ext[:1] != '.':
            ext = '.'+ext
        kwargs['s2p_pattern'] = '*'+ext
    elif options.pattern:
        kwargs['s2p_pattern'] = options.pattern
    
    # set up logging
    if options.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO,format="%(levelname)s: %(message)s")
    
    if not options.oldstyle:
        # if not running in old-style, try to read the FET model configuration file
        try:
            cfg, p = load_config(config_name)
            logging.info("loaded config file '%s'"%p)
        except Exception:
            logging.warning("no config file read")
        
    # run the summary tool
    generate_summary(dirs,**kwargs)    
    
if __name__ == '__main__':
    main()

