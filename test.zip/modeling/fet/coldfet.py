from __future__ import unicode_literals, absolute_import, division, print_function
import math
from ..linefit import linefit_mxb
from ..errors import ExtractionError
from ..file_utils import read_and_deembed_spars
from .. import _str_type


def coldfet( lr_files, c_file=None, **kwargs ):
    """Perform coldfet extraction on a set of measured data files.
    
    lr_files - a list or tuple of filenames (strings) or BiasedTouchstone objects
       that are the measured cold-FET data files at Vds=0 and Igs>0.  These files
       are used to extract the parasitic L's and R's.
       If it is a list/tuple of filenames, then those files will be read
       and deembedded using the read_and_deembed_spars() function from
       the modeling.file_utils module. Keywords passed to this function will
       be passed along when the files are read.  At least 2 items must be present
       in the list/tuple so that extraploation to infinte current can be performed.
    
    c_file - a file name string or a ParamSet-like object that is a measured
       cold-FET data file at Vds=0 and Vgs<<Vpo.  This file is used to extract
       the parasitic C's.  If this parameter is not supplied, then the parasitic
       C's will be set to 0 in the returned dictionary.
       
    Returns a dictionary containing extracted values for lg, ld, ls, rd, rs, c11, and c22.
    """
    
    if not isinstance(lr_files,(tuple,list)):
        raise TypeError("Argument 'lr_files' must be a list or tuple type.")
    if len(lr_files) < 2:
        raise ValueError("At least 2 data files must be specified for 'lr_files'")
        
    if isinstance(lr_files[0],_str_type):
        # need to load the lr files
        lr_files = read_and_deembed_spars(lr_files, **kwargs)
    
    # compute all L/R values, then use infinite forward current extrapolation
    # to get the final values
    lr_ext = []
    for p in lr_files:
        d = compute_coldfet_lr(p, **kwargs)
        lr_ext.append( (p.i1,d) )
    ret = _lr_extrapolate(lr_ext)
    
    c1,c2 = 0.0,0.0
    if c_file is not None:
        if isinstance(c_file,_str_type):
            # need to load c_file
            c_file = read_and_deembed_spars( (c_file,), **kwargs)
        c1,c2 = compute_coldfet_c(c_file, **kwargs)
    
    ret['c11'] = c1
    ret['c22'] = c2
    
    return ret
    
def compute_coldfet_lr( params, **kwargs ):
    """Compute inductance and resistance parasitics from a single set of coldfet data.
    
    params - a ParamSet-like object containing measured network parameters. This data
       should be measured at Vds=0 and Igs>0.
    
    Returns a dictionary of extracted values of lg, ld, ls, rd, and rs.
    """
    
    # get parameters from keywords
    rfreq = kwargs.get('coldfet_rfreq_ghz', 2.0)*1.0e9
    minf = kwargs.get('coldfet_min_lfreq_ghz', 5.0)*1.0e9
    maxf = kwargs.get('coldfet_max_lfreq_ghz', 100.0)*1.0e9
    
    # copy the params object and confirm that it is in Z parameters
    params2 = params.copy()
    params2.convert('z')
    
    # iterate over the object and compute the coldfet inductance
    n = 0
    lg = 0.0
    ld = 0.0
    ls = 0.0
    for p in params2:
        if p.freq >= minf and p.freq <= maxf:
            w = 2.0*math.pi*p.freq
            z = p.data
            zcom = 0.5*(z[0,1]+z[1,0])
            lg += (z[0,0] - zcom).imag / w
            ld += (z[1,1] - zcom).imag / w
            ls += zcom.imag / w
            n += 1
            
    if not n:
        raise ExtractionError('No data points were found that meet the inductance extraction frequency criteria.')
    
    d = 1.0 / n
    lg *= d
    ld *= d
    ls *= d
    
    # extract Z-params and compute the resistance
    try:
        z = params2.extract(rfreq).data
    except:
        raise ExtractionError('Could not extract data for resistance extraction at %.2f GHz.'%(rfreq*1.0e-9))
    zcom = 0.5*(z[0,1]+z[1,0])
    rd = (z[1,1] - zcom).real
    rg = (z[0,0] - zcom).real
    rs = zcom.real
    
    # create the return data dictionary
    ret = {'lg':lg, 'ld':ld, 'ls':ls, 'rd':rd, 'rs':rs, 'rg':rg}
    return ret
    

def compute_coldfet_c( params, **kwargs ):
    """Compute capacitive parasitics from a single set of coldfet data.
    
    params - a ParamSet-like object containing measured network parameters. This data
       should be measured at Vds=0 and Vgs<<Vpo.
       
    Returns a 2-tuple of extracted values for (c11,c22)
    """
    
    minf = kwargs.get('coldfet_min_cfreq_ghz', 0.01)*1.0e9
    maxf = kwargs.get('coldfet_max_cfreq_ghz', 100.0)*1.0e9
    
    # copy the params object and confirm that it is in Y parameters
    params2 = params.copy()
    params2.convert('y')
    
    # iterate over the object and compute the coldfet capacitance
    n = 0
    c1 = 0.0
    c2 = 0.0
    for p in params2:
        if p.freq >= minf and p.freq <= maxf:
            w = 2.0*math.pi*p.freq
            y = p.data
            ycom = 0.5*(y[0,1]+y[1,0])
            c1 += (y[0,0] + ycom).imag / w
            c2 += (y[1,1] + ycom).imag / w
            n += 1
            
    if not n:
        raise ExtractionError('No data points were found that meet the capacitance extraction frequency criteria.')
    
    d = 1.0 / n
    c1 *= d
    c2 *= d
    
    return (c1,c2)
    
    
def _lr_extrapolate(lr_ext):
    """Internal function to extrapolate L's and R's to infinite current."""
    plist = ('lg','ld','ls','rd','rs','rg')
    ret = {}
    
    # loop through each parameter
    for p in plist:
        x = []
        y = []
        for ig,parms in lr_ext:
            x.append(1.0 / ig)
            y.append(parms[p])
        
        # extrapolate to infinite gate current
        m,b,r2 = linefit_mxb(x,y)
        ret[p] = b
            
    return ret
