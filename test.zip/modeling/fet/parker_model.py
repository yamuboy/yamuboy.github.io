from __future__ import unicode_literals, absolute_import, division, print_function

from ..model import Model
from ..modelparam import FloatParam
from ..optimize.param import OptimizableParam
import math

# define constants
CTOK = 273.15
BOLTZMANN = 1.380066e-23
Q_ELECTRON = 1.60218e-19

class ParkerModel(Model):
    """Create a representation of the Parker LS model."""
    
    def __init__(self,**kwargs):
        """Create a new object."""
        # model parameters
        p = (
            FloatParam('ugw',1.0),
            FloatParam('ngf',1.0),
            FloatParam('tnom',25.0),
            FloatParam('vbi', 1.0),
            FloatParam('delta', 0.2),
            FloatParam('is',0.0),
            FloatParam('n',1.0),
            FloatParam('ibd',0.0),
            FloatParam('vbd',1.0),
            FloatParam('ileak',0.0),
            FloatParam('vleak',1.0),
            FloatParam('taug',1.0e-6),
            FloatParam('taud',1.0e-5),
            FloatParam('rg',1.0e-4),
            FloatParam('rd',1.0e-4),
            FloatParam('rs',1.0e-4),
            FloatParam('lg',1.0e-18),
            FloatParam('ld',1.0e-18),
            FloatParam('ls',1.0e-18),
            FloatParam('c11',0.0),
            FloatParam('c22',0.0),
            FloatParam('cpg',0.0),
            FloatParam('cpd',0.0),
            FloatParam('ri',1.0e-4),
            FloatParam('cds', 5.0e-14),
            FloatParam('tau', 3.0e-12), 
            OptimizableParam('beta', 0.5, optrange=(0.005,1.0)),
            OptimizableParam('vto',  -1.0, optrange=(-1.5,-0.5)),
            OptimizableParam('p', 2.2, optrange=(2.1,3.5)),
            OptimizableParam('q', 1.5, optrange=(1.1,2.0)),
            OptimizableParam('vst', 0.05, optrange=(0.02,0.3)),
            OptimizableParam('mvst', 0.0, optrange=(0.0,0.2)),
            OptimizableParam('xi', 0.1, optrange=(0.0,2.0)),
            OptimizableParam('mxi', 0.0, optrange=(0.0,0.05)),
            OptimizableParam('lambda', 0.0, optrange=(0.0,0.5)),
            OptimizableParam('z', 4.0, optrange=(0.2,4.0)),
            OptimizableParam('lfgam', 0.0, optrange=(0.0,0.5)),
            OptimizableParam('lfg1', 0.0, optrange=(0.0,0.5)),
            OptimizableParam('lfg2', 0.0, optrange=(0.0,0.5)),
            OptimizableParam('hfgam', 0.05, optrange=(-1.0,1.0)),
            OptimizableParam('hfg1', 0.0, optrange=(-1.0,1.0)),
            OptimizableParam('hfg2', 0.0, optrange=(-1.0,1.0)),
            OptimizableParam('hfeta', 0.0, optrange=(-1.0,1.0)),
            OptimizableParam('hfe1', 0.0, optrange=(-1.0,1.0)),
            OptimizableParam('hfe2', 0.0, optrange=(-1.0,1.0)),
            OptimizableParam('cgs', 3.0e-13, optrange=(1.0e-15,5.0e-12)),
            OptimizableParam('cgd', 5.0e-14, optrange=(1.0e-16,5.0e-13)),
            OptimizableParam('fc', 0.5, optrange= (0.3,0.95)),            
            OptimizableParam('xc', 0.0, optrange=(0.0,0.99)),
            OptimizableParam('acgam', 0.05, optrange=(0.0,1.0)),
            OptimizableParam('tm', 0.0, optrange=(0.0,0.0)),
            OptimizableParam('vhr', 0.1, optrange=(0.001,0.5)),
            OptimizableParam('mvhr', 0.0, optrange=(0.0,0.0)),
            OptimizableParam('vht', 0.0, optrange=(0.0,0.0)),
            OptimizableParam('etah', 0.0, optrange=(0.0,0.0)),
            )
        
        # init the parent, this model has 3 external nodes
        Model.__init__(self,params=p)
                
    ######################################################################################################################    
    def compute_ids(self, vgs, vds, compute_delta=False, vgs_a=None, vds_a=None, ids_a=None):
        """Compute drain current, gm and gds."""
        
        if vgs_a is None or vds_a is None:
            # average values of Vgs and Vds:
            # if not specified, set them to instantaneous values
            # which is correct for DC I-V
            Vgs_a = vgs
            Vds_a = vds
        else:
            Vgs_a = vgs_a
            Vds_a = vds_a
        
        # compute Vgd_a as Vgs_a - Vds_a
        Vgd_a = Vgs_a - Vds_a
        
        # HEMT extensions to the classic P-S MESFET model
        VHT = self['vht'].v
        sigma = self['vhr'].v * (1.0 + self['mvhr'].v*Vds_a)
        vgsh = self['tm'].v * sigma * math.log(math.exp((vgs-VHT)/sigma) + 1.0)
        dvgsh_vgs = self['tm'].v / (math.exp((vgs-VHT)/sigma) + 1.0) * math.exp((vgs-VHT)/sigma)
        dvgsh_vds = 0.0
        Vgsh_a = vgsh
        
        lfg = self['lfgam'].v - self['lfg1'].v*Vgs_a + self['lfg2'].v*Vgd_a
        hfg = self['hfgam'].v - self['hfg1'].v*Vgs_a + self['hfg2'].v*Vgd_a
        hfn = self['hfeta'].v - self['hfe1'].v*Vgd_a + self['hfe2'].v*Vgs_a
        
        # vgst and its derivatives are modified by the HEMT extensions (vgsh and ETAH)
        
        ETAH = self['etah'].v
        vgst = vgs - self['vto'].v - lfg*Vgd_a - hfg*(vgs - vds - Vgd_a) - hfn*(vgs - Vgs_a) - vgsh + ETAH*(vgsh - Vgsh_a)
        dvgst_vgs = 1.0 - hfg - hfn - dvgsh_vgs + ETAH*dvgsh_vgs
        dvgst_vds = hfg - dvgsh_vds + ETAH*dvgsh_vds
        
        # the rest of this is the classic P-S MESFET Model
        
        vst = self['vst'].v*(1.0 + self['mvst'].v*vds)
        dvst_vds = self['vst'].v * self['mvst'].v
        
        if vgst > 30.0*vst: 
            vgt = vgst
            dvgt_vgs = dvgst_vgs
            dvgt_vds = dvgst_vds
        elif  vgst < -30.0*vst:
            vgt = 0.0
            dvgt_vgs = dvgt_vds = 0.0
        else:
            c1 = math.exp(vgst/vst) + 1.0
            c2 = c1 - 1.0
            vgt = vst * math.log(c1)
            dvgt_vgs = 1. / c1 * c2 * dvgst_vgs
            dvgt_vds = vst / c1 * c2 * (dvgst_vds * vst - vgst * dvst_vds) / (vst*vst) + math.log(c1) * dvst_vds
        
        XI = self['xi'].v
        MXI = self['xi'].v
        vbi_minus_vto=self['vbi'].v - self['vto'].v
        c1 = vgt * (1.0 + MXI) + XI*vbi_minus_vto
        c2 = vgt*vgt*MXI + vgt*XI*vbi_minus_vto
        c3 = (c1 * (2.0*vgt*MXI + XI*vbi_minus_vto) - c2 * (1.0 + MXI)) / (c1*c1)
        vsat = c2 / c1
        dvsat_vgs = dvgt_vgs * c3
        dvsat_vds = dvgt_vds * c3
        
        P = self['p'].v
        Q = self['q'].v
        PoQ = P/Q
        PmQ = P-Q
        c1 = PoQ * safe_pow(vgt/vbi_minus_vto, PmQ)
        c2 = PoQ * safe_pow(vgt/vbi_minus_vto, PmQ-1.0)
        vdp = vds * c1
        dvdp_vgs = vds * PmQ * c2 * dvgt_vgs / vbi_minus_vto
        dvdp_vds = vds * PmQ * c2 * dvgt_vds / vbi_minus_vto + c1
        
        Z = self['z'].v
        c1 = math.sqrt(1.0 + Z)
        c2 = Z * vsat*vsat
        c3 = math.sqrt ((vdp * c1 + vsat)*(vdp * c1 + vsat) + c2)
        c4 = math.sqrt ((vdp * c1 - vsat)*(vdp * c1 - vsat) + c2)
        vdt = 0.5 * (c3 - c4)
        dvdt_vgs = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vgs * c1 + dvsat_vgs) + 2.0 * Z * vsat * dvsat_vgs) \
            - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vgs * c1 - dvsat_vgs) + 2.0 * Z * vsat * dvsat_vgs))
        dvdt_vds = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vds * c1 + dvsat_vds) + 2.0 * Z * vsat * dvsat_vds) \
            - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vds * c1 - dvsat_vds) + 2.0 * Z * vsat * dvsat_vds))
        
        c0 = self['beta'].v
        c1 = 1.0 + self['lambda'].v*vds
        c2 = Q * safe_pow(vgt, Q-1.0)
        if vgt > vdt:
            c3 = Q * safe_pow(vgt-vdt, Q-1.0)
            c4 = safe_pow(vgt, Q) - safe_pow(vgt-vdt, Q)
        else: 
            c3 = 0
            c4 = safe_pow(vgt, Q)
        
        if compute_delta:
            if ids_a is None:
                # adding delta to the mix turns the solution into a quadratic
                # equation since:
                # Ids = idsc / (1 + delta * Vds_a * Ids)
                #   where:
                #      idsc = c0 * c1 * c4
                #
                # Rearranged:
                #   Ids^2 * Vds_a * delta + Ids - idsc = 0
                # So:
                #   a = Vds_a * delta
                #   b = 1
                #   c = -idsc
                idsc = c0 * c1 * c4
                qa = Vds_a * self['delta'].v
                q1 = -1.0 / (2.0*qa)
                q2 = math.sqrt(1.0 + 4.0*qa*idsc)
                s1 = q1 + q2
                s2 = q1 - q2
                if s1 > 0.0 and s1 < idsc:
                    Ids = q1
                else:
                    Ids = q2
            else:
                Ids = c0 * c1 * c4 / (1.0 + self['delta'].v*Vds_a*ids_a)
            
            Gm = c0 * c1 * c5 * (c2*dvgt_vgs - c3*(dvgt_vgs-dvdt_vgs))
            Gds = c0 * c5 * (c1 * (c2*dvgt_vds - c3*(dvgt_vds-dvdt_vds)) + c4 * self['lambda'].v)
        else:
            Ids = c0 * c1 * c4
            Gm = c0 * c1 * (c2*dvgt_vgs - c3*(dvgt_vgs-dvdt_vgs))
            Gds = c0 * (c1 * (c2*dvgt_vds - c3*(dvgt_vds-dvdt_vds)) + c4 * self['lambda'].v)
        
        return Ids, Gm, Gds
                
        
    ##################################################################################################################   
    ##################################################################################################################     
   
    def compute_qg(self, vgs, vds):
        """Compute the gate capacitances that result from gate charge."""
        alpha = self['xi'].v / (self['xi'].v + 1.0) * 0.5*(self['vbi'].v-self['vto'].v)

        vgd=vgs-vds
        ACGAM = self['acgam'].v
        c1 = math.sqrt((vgs-vgd)*(vgs-vgd) + alpha*alpha)
        Veff1 = 0.5 * (vgs + vgd + c1) + ACGAM*(vgs-vgd)
        dVeff1_vgs = 0.5 * (1.0 + (vgs-vgd)/c1) + ACGAM
        dVeff1_vgd = 0.5 * (1.0 - (vgs-vgd)/c1) - ACGAM
        
        Veff2 = 0.5 * (vgs + vgd - c1) + ACGAM*(vgs-vgd)
        dVeff2_vgs = dVeff1_vgd + 2.0*ACGAM
        dVeff2_vgd = dVeff1_vgs - 2.0*ACGAM
        
        VTO = self['vto'].v
        XC = self['xc'].v
        c1 = 0.5*(1.0 - XC)
        c2 = math.sqrt((Veff1-VTO)*(Veff1-VTO) + (0.2/(1.0 - XC))*(0.2/(1.0 - XC)))
        Vnew = Veff1*XC + c1*(Veff1 + VTO + c2)
        dVnew_vgs = dVeff1_vgs*XC + c1*(dVeff1_vgs * (1.0 + (Veff1-VTO)/c2))
        dVnew_vgd = dVeff1_vgd*XC + c1*(dVeff1_vgd * (1.0 + (Veff1-VTO)/c2))
        
        VBI = self['vbi'].v
        FC = self['fc'].v
        CGS = self['cgs'].v
        CGD = self['cgd'].v
        if Vnew > FC*VBI:
            c1 = 1.0 / 4.0*math.pow(1.0-FC, 1.5)
            c2 = 1.0 / math.sqrt(1.0-FC)
            c3 = (Vnew/VBI - FC)
            Qgs = CGS * VBI * ( 2.0*(1.0 - math.sqrt(1.0 - FC)) + c3*c3*c1 + c3*c2 )
            dQgs_vgs = CGS * VBI * ( 2.0*c3*dVnew_vgs*c1/VBI  + dVnew_vgs*c2/VBI )
            dQgs_vgd = CGS * VBI * ( 2.0*c3*dVnew_vgd*c1/VBI + dVnew_vgd*c2/VBI )
        else:
            c1 = math.sqrt(1.0 - Vnew/VBI)
            Qgs = 2.0 * CGS * VBI * (1.0 - c1)
            dQgs_vgs =  CGS * dVnew_vgs / c1
            dQgs_vgd =  CGS * dVnew_vgd / c1
            
        Qgd = CGD * Veff2
        dQgd_vgs =  CGD * dVeff2_vgs
        dQgd_vgd =  CGD * dVeff2_vgd
        
        cgs = dQgs_vgs
        cgd = dQgd_vgd
        dqgs_vgd = dQgs_vgd
        dqgd_vgs = dQgd_vgs
        
        return cgs, cgd, dqgs_vgd, dqgd_vgs
    
    def compute_ig(self, vg):
        """Compute the (single-sided) gate current for a given gate voltage."""
        igf = self['is'].v * (math.exp(vg*Q_ELECTRON/(self['n'].v*BOLTZMANN*(CTOK+self['tnom'].v))) - 1.0)
        igr = self['ibd'].v * (1.0 - math.exp(-vg/(self['vbd'].v)))
        igl = self['ileak'].v * (1.0 - math.exp(-vg/(self['vleak'].v)))
        return igf + igr + igl
    
def safe_pow(x, y):
    """pow() function that protects against NaN errors."""
    if  x == 0. and y < 0. : 
        return 1.e100
    elif x == 0.: 
        return 0.
    return math.pow(x, y)

        