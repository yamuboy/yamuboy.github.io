from __future__ import unicode_literals, absolute_import, division, print_function

from ..model import Model, FloatParam
from ..optimize import OptimizableParam
import math

# define constants
CTOK = 273.15
BOLTZMANN = 1.380066e-23
Q_ELECTRON = 1.60218e-19
VT0 = BOLTZMANN*CTOK/Q_ELECTRON

class SwitchModelV2(Model):
    """Switch model (version 2)."""
    
    def __init__(self,**kwargs):
        """Create a new object."""
        # model parameters
        p = (
            FloatParam('ugw',1.0),
            FloatParam('ngf',1.0),
            FloatParam('tnom',25.0),
            FloatParam('is',0.0),
            FloatParam('n',1.0),
            FloatParam('ibd',0.0),
            FloatParam('vbd',1.0),
            FloatParam('ileak',0.0),
            FloatParam('vleak',1.0),
            FloatParam('rg',1.0e-4),
            FloatParam('rd',1.0e-4),
            FloatParam('rs',1.0e-4),
            FloatParam('lg',1.0e-18),
            FloatParam('ld',1.0e-18),
            FloatParam('ls',1.0e-18),
            FloatParam('cds', 0.0),
			FloatParam('cgg0', 0.0),
            OptimizableParam('ct0', 0.1, optrange=(0.0,0.5)),
			OptimizableParam('ct1', 30, optrange=(1.0,30.0)),
			OptimizableParam('ct2', -1, optrange=(-1.2,-0.8)),
			OptimizableParam('ce0', 0.3, optrange=(0.1,1.0)),
			OptimizableParam('ce1', 1.0, optrange=(0.1,3.0)),
			OptimizableParam('ce2', -0.08, optrange=(-1,0.9)),
			OptimizableParam('ids0', 0.2, optrange=(0.01,1.0)),
			OptimizableParam('ids1', 15.0, optrange=(1.0,30.0)),
			OptimizableParam('ids2', 0.0, optrange=(-2.0,1.0)),
			OptimizableParam('ids3', 0.2, optrange=(0.0,1.0)),
			OptimizableParam('ids4', 3.0, optrange=(0.0,10.0)),
            )
        
        # init the parent
        Model.__init__(self,params=p)
                
    def compute_ids_gds(self, vgs, vds):
        "compute the ids and gds"
        vgd = vgs - vds
        arg1 = self['ids1'].v*(vgs - self['ids2'].v \
            - math.sqrt((vgs-self['ids2'].v)*(vgs-self['ids2'].v) \
            + self['ids3'].v*self['ids3'].v))
        arg2 = self['ids1'].v*(vgd - self['ids2'].v \
            - math.sqrt((vgd-self['ids2'].v)*(vgd-self['ids2'].v) \
            + self['ids3'].v*self['ids3'].v))
        gds1 = self['ids0'].v*math.exp(arg1)
        gds2 = self['ids0'].v*math.exp(arg2)

        ids = (gds1*(1.0 + math.tanh(self['ids4'].v*(vgs-vgd))) \
            - gds2*(1.0 + math.tanh(self['ids4'].v*(vgd-vgs))))/(2.0*self['ids4'].v)

        gds = self['ids0'].v*gds2*(1.0 - (vgd-self['ids2'].v)/math.sqrt((vgd-self['ids2'].v)*(vgd-self['ids2'].v) \
            + self['ids3'].v*self['ids3'].v)) * (1.0 + math.tanh(self['ids4'].v*(vgd-vgs)))/(2.0*self['ids4'].v) \
            + 0.5*gds1*(1.0 - math.tanh(self['ids4'].v*(vgs-vgd))*math.tanh(self['ids4'].v*(vgs-vgd))) \
            + 0.5*gds2*(1.0 - math.tanh(self['ids4'].v*(vgd-vgs))*math.tanh(self['ids4'].v*(vgd-vgs)))
        return ids, gds
           
    def compute_cgx(self, vx):
        "compute Cg (for either G-D or G-S)"
        return (self['ct0'].v*0.5*(math.tanh(self['ct1'].v*(vx - self['ct2'].v)) \
            + 1.0) + self['ce0'].v*math.exp(self['ce1'].v*self['ce1'].v \
            *(vx - self['ce2'].v)))*1.0e-12 + self['cgg0'].v
        
    def compute_ig(self, vg):
        "compute single-sided gate current for a given gate (G-S or G-D) voltage"
        igf = self['is'].v * (math.exp(vg*Q_ELECTRON/(self['n'].v*BOLTZMANN*(CTOK+self['tnom'].v))) - 1.0)
        igr = self['ibd'].v * (1.0 - math.exp(-vg/(self['vbd'].v)))
        igl = self['ileak'].v * (1.0 - math.exp(-vg/(self['vleak'].v)))
        return igf + igr + igl
    
    