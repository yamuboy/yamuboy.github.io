from __future__ import unicode_literals, absolute_import, division, print_function
from .. import _str_type

class FETDataSet(object):
    """Base class for data sets of FET parameters.  Classes derived from this
    must implement a storage type that has properties named 'vgs', 'vds', 'igs',
    and 'ids'.
    """
    
    def __init__(self, fname=None, data=None, **kwargs):
        """
        fname - the filename of a file to read I-V data from.  This will be
          passed straight to the read() method.  In addition, any keywords that
          are accepted by read() can be specified here when the 'fname' keyword
          is specified.
        
        data - a list of data objects used to initialize the dataset with.
          This is ignored if 'fname' is present.
          
        """
        # initialize data storage
        self.__data = []
        
        if fname is not None:
            self.read(fname, **kwargs)
        elif data is not None:
            # data was passed in as a keyword, use that data to init the
            # object
            self.__data.extend(data)
        
    def read(self, *args, **kwargs):
        """Read a data file, must be implemented in derived classes."""
        raise NotImplemented
        
    def filter(self, vgsrange=None, igsrange=None, vdsrange=None, idsrange=None):
        """Return a new object with a data set that has been filtered
        according to the keywords.
        
        vgsrange - a 2-tuple of (min,max) values for allowed Vgs, either value
          can be None indicating that their is no min or max
        vdsrange - a 2-tuple of (min,max) values for allowed Vds, either value
          can be None indicating that their is no min or max
        idsrange - a 2-tuple of (min,max) values for allowed Ids, either value
          can be None indicating that their is no min or max
        igsrange - a 2-tuple of (min,max) values for allowed Igs, either value
          can be None indicating that their is no min or max
        
        """
        filtlist = { 'vgsrange':vgsrange, 'vdsrange':vdsrange,
            'igsrange':igsrange, 'idsrange':idsrange }
        d = self.__class__()
        for p in self.__data:
            ok=True
            for k in filtlist:
                v = filelist[k]
                if v is not None:
                    kw = { k:v }
                    if self._filterout(p, **kw):
                        ok=False
                        break
            if ok:
                d.append(p)
        
        # create and return a new object with the filtered data set
        return d
    
    def segregate(self, vgsrange=None, igsrange=None, vdsrange=None, idsrange=None):
        """Return a tuple of 2 new objects, each containing part of the data set,
        segregating it according to the keywords.
        
        The first data set is the "filterin" data set that matches the filter
        parameters and the second in the "filterout" data set with the
        remaining points.
                
        Keywords:
        
        vgsrange - a 2-tuple of (min,max) values for allowed Vgs, either value
          can be None indicating that their is no min or max
        vdsrange - a 2-tuple of (min,max) values for allowed Vds, either value
          can be None indicating that their is no min or max
        idsrange - a 2-tuple of (min,max) values for allowed Ids, either value
          can be None indicating that their is no min or max
        igsrange - a 2-tuple of (min,max) values for allowed Igs, either value
          can be None indicating that their is no min or max
        
        """
        filtlist = { 'vgsrange':vgsrange, 'vdsrange':vdsrange,
            'igsrange':igsrange, 'idsrange':idsrange }
        din = self.__class__()
        dout = self.__class__()
        for p in self.__data:
            ok=True
            for k in filtlist:
                v = filtlist[k]
                if v is not None:
                    kw = { k: v }
                    if self._filterout(p, **kw):
                        ok=False
                        break
            if ok:
                din.append(p)
            else:
                dout.append(p)
        
        # create and return a new object with the filtered data set
        return din, dout
    
    def sort(self, sortby='vgs'):
        """Sort the data set, valid sorting values are 'vgs' and 'vds'."""
                
        # verify the sort order
        if sortby not in ('vgs','vds'):
            raise ValueError('Invalid sort order')
        
        # sort the data
        ds = self.__data
        for i in range(len(ds)):
            j = i+1
            while j < len(ds):
                if sortby == 'vgs':
                    if ds[i].vgs > ds[j].vgs:
                        # swap the data points
                        t = ds[i]
                        ds[i] = ds[j]
                        ds[j] = t
                    elif ds[i].vgs == ds[j].vgs:
                        # sort by vds as well
                        if ds[i].vds > ds[j].vds:
                            # swap the data points
                            t = ds[i]
                            ds[i] = ds[j]
                            ds[j] = t
                else:
                    if ds[i].vds > ds[j].vds:
                        # swap the data points
                        t = ds[i]
                        ds[i] = ds[j]
                        ds[j] = t
                    elif ds[i].vds == ds[j].vds:
                        # sort by vds as well
                        if ds[i].vgs > ds[j].vgs:
                            # swap the data points
                            t = ds[i]
                            ds[i] = ds[j]
                            ds[j] = t
                j += 1

        self.__data = ds
                    
    def clear(self):
        """Clear all data."""
        del self.__data
        self.__data = []
    
    def append(self, data):
        """Append a new point onto the set."""
        self.__data.append(data)
        
    def extend(self, data):
        """Extend the data set with a list of new points."""
        self.__data.extend(data)
    
    def _filterout(self, point, **kwargs):
        """Internal function used to compute a single filter.
        
        This function returns True when a point should be filtered out of the
        data set based on the filter range passed as the keyword arguemnt.
        """
        if len(kwargs) != 1:
            raise TypeError("Exactly 1 keyword argument must be present.")
        k = kwargs.keys()[0]
        v = kwargs[k]
        if not isinstance(v,tuple) or len(v) != 2:
            raise TypeError("Keyword '%s' must be a 2-tuple" % k)
        mn, mx = v
        parm = getattr(point,k[:3])
        filt = False
        if mn is not None:
            mn = float(mn)
            if parm < mn:
                filt = True
        if mx is not None:
            mx = float(mx)
            if parm > mx:
                filt = True
        return filt
        
    def __str__(self):
        s = "%s:\n[\n" % type(self).__name__
        for p in self.__data:
            s += " %s,\n" % p
        s += "]\n"
        return s
    
    def __nonzero__(self):
        return bool(len(self.__data))
    
    def __len__(self):
        return len(self.__data)
    
    def __iter__(self):
        return iter(self.__data)
    
    def __getitem__(self, key):
        return self.__data[key]
        
    def __delitem__(self, key):
        del self.__data[key]


class IVData(FETDataSet):
    """This class reads I-V data from data files and performs manipulations
    on it such as filter data.  It acts like a list, so many list-like
    behaviors are defined on it.
    
    By default it is configured to read the style of data file generated by
    MCT, but it can read other formats as well by passing keywords to the
    read() method.
    
    Examples:
        
        # read I-V data from a file named 'file.iv'
        iv = IVData(fname='file.iv')
        
        # create a new data set by filtering out values of Vds greater than 5.0
        iv2 = iv.filter( vdsrange=(None,5.0001) )
        
        # iterate over the data set and print the Vgs and Ids values
        for point in iv2:
            print point.vgs, point.ids
        
        # create a data set from the last 3 points of the original data set
        iv3 = iv[-3:]
    
    """
    class IVPoint(object):
        """Internal class used for data storage."""
        def __init__(self, vds=0.0, vgs=0.0, ids=0.0, igs=0.0):
            self.__vgs = float(vgs)
            self.__vds = float(vds)
            self.__igs = float(igs)
            self.__ids = float(ids)
        
        @property
        def vgs(self):
            return self.__vgs
            
        @property
        def vds(self):
            return self.__vds
            
        @property
        def igs(self):
            return self.__igs
            
        @property
        def ids(self):
            return self.__ids
            
        def __str__(self):
            """Stringify the data point as a dictionary."""
            return "{ Vgs: %6.3f, Vds: %5.2f, Igs: %12.4e, Ids: %12.4e }" %(self.__vgs,self.__vds,self.__igs,self.__ids)
        
        def __getitem__(self, key):
            """Get data items as dictionary keys."""
            if key == 'vgs':
                return self.__vgs
            elif key == 'vds':
                return self.__vds
            elif key == 'igs':
                return self.__igs
            elif key == 'ids':
                return self.__ids
            else:
                raise KeyError(key)
    
    def __init__(self, **kwargs):
        """
        Keywords:
        
        fname - the filename of a file to read I-V data from.  This will be
          passed straight to the read() method.  In addition, any keywords that
          are accepted by read() can be specified here when the 'fname' keyword
          is specified.
        
        data - a list of IVPoint objects used to initialize the I-V dataset.
          This is ignored if the 'fname' keyword is present.
          
        """
        self.__header = None
        FETDataSet.__init__(self,**kwargs)
    __init__.__doc__ = FETDataSet.__init__.__doc__
        
    def clear(self):
        """Clear all data."""
        FETDataSet.clear(self)
        self.__header = None
    
    def read(self, fname, **kwargs):
        """Read an I-V data set from a file.
        
        This function expects that the data in the file will be contained
        in 4 columns.  The default column order is ('vds','ids','vgs','igs')
        though this can be changed with keywords.  Any line in the file that
        has more or less than 4 numbers on the line or contains any non-numeric
        data will be silently ignored.
        
        fname - a file name (or full path to a data file) that is to be read.
          This can also be any iterable object that returns strings.
        
        Keywords:
        colorder - a tuple defining the column order. It must contain the 4
          strings 'vds', 'vgs', 'ids', and 'igs'.  The order of the strings in
          this tuple is the the order in which the values will be read from the
          data file.  The tuple can also include 1 or more 'ignore' strings to
          indicate columns to ignore in the file. The length of this tuple must
          exactly match the number of columns in the data file otherwise all
          lines of the data file will be ignored.
        
        
        """
        colorder = ('vds','ids','vgs','igs')
        datacols = colorder[:]
        if 'colorder' in kwargs:
            # make sure the colorder keyword is valid
            co = kwargs['colorder']
            if not isinstance(co,tuple) or len(co) < 4:
                raise TypeError("'colorder' keyword must be a tuple of length >= 4.")
            for c in colorder:
                if not c in co:
                    raise ValueError("'colorder' keyword is missing the value '%s'"%c)
            for c in co:
                if not c in colorder and c != 'ignore':
                    raise ValueError("'colorder' keyword has an invalid value '%s'"%c)
            # everything checks out with the 'colorder' keyword
            colorder = co
        
        # clear existing data
        self.clear()
        
        # try to open and read the data file
        autoclose=False
        if isinstance(fname,_str_type):
            # fname is a string denoting the file name
            # try to open the file
            f = open(fname,'r')
            autoclose=True
        else:
            # assume that fname is an iterable object
            f = fname
        
        ncol = len(colorder)
        header = ''
        hdone = False
        try:
            for line in f:
                # shove header data into the header variable
                if not hdone:
                    if line.startswith('!') or line.startswith('#') or line.startswith('/'):
                        header += line
                        continue
                
                lary = line.split()
                if len(lary) != ncol:
                    continue
                try:
                    kw = {}
                    for i,c in enumerate(colorder):
                        if c in datacols:
                            kw[c] = float(lary[i])
                except ValueError:
                    # ignore lines that raise a ValueError
                    # (this indicates non numeric data is present on the line)
                    continue
                
                # OK, found a line with 4 valid data values,
                #  append it to the data set
                self.append(self.IVPoint(**kw))
                # header is done at this point
                hdone = True
        finally:
            if autoclose: f.close()
        
        # save the header data
        if len(header):
            self.__header = header
                
    @property
    def header(self):
        "file header"
        return self.__header
    

