from ..config_data import ConfigData

class FET_Model_Config(ConfigData):
    """Hold configuration data specific to FET models."""
    
    def __init__(self):
        "initializer"
        ConfigData.__init__(self, search_path=('fet','default',))
        
        
class LSFET_Model_Config(ConfigData):
    """Hold configuration data specific to large-signal FET models."""
    
    def __init__(self):
        "initializer"
        ConfigData.__init__(self, search_path=('lsfet','fet','default',))
        
        
