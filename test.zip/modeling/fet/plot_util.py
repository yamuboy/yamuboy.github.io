from __future__ import unicode_literals, absolute_import, division, print_function
import os
import sys
import math
import matplotlib.pyplot as plt
#from .extract.parker import ParkerModelPlotData

class Plot_Util(object):
    
    """create plot,x & y meas and model data
       xlab, ylab for x,y axis label,
       ylegend=list(), labels for lines, 
       title for png title
       pngname for output file name
       log True/False
    """
    def __init__(self, x, y_meas, y_mod, x2=None, y2_meas=None, y2_mod=None,\
        xlab = None, ylab = None, ylegend = None, ytext = None, y2lab=None,
        y2legend=None, y2text=None, pngname=None, title=None, log=False):
        self.x = x
        self.y_meas = y_meas
        self.y_mod = y_mod
        self.x2 = x2
        self.y2_meas = y2_meas
        self.y2_mod = y2_mod
        self.xlab = xlab
        self.ylab = ylab
        self.y2lab = y2lab
        self.ylegend = ylegend
        self.y2legend = y2legend
        self.ytext = ytext
        self.y2text = y2text
        self.pngname = pngname
        self.title = title
        self.log = log

    def run(self):
        plt.title(self.title)
        ymin = 0;
        ymax = 0;
        fig = plt.figure()
        if type(self.x) is dict:
            ymin= list()
            ymax = list()
            for i, d in enumerate(self.ytext):
                ax = plt.subplot(111)
                ax.plot(self.x[d], self.y_meas[d], 'r<-')
                ax.plot(self.x[d], self.y_mod[d], 'bo-')
                ax.text(self.x[d][-1], self.y_meas[d][-1], d, fontsize=12,rotation=0 )
                ymin.append(min(min(self.y_meas[d]),min(self.y_mod[d])))
                ymax.append(max(max(self.y_meas[d]),max(self.y_mod[d])))
            ax.set_ylim(min(ymin)*0.9, max(ymax)*1.1)

        else:
            if len(self.x) != len(self.y_meas) or len(self.x) != len(self.y_mod) :
                raise ValueError("the x y must have same dimensions\n")
            ax = plt.subplot(111)
            L1 = ax.plot(self.x, self.y_meas, 'r^-')
            L2 = ax.plot(self.x, self.y_mod, 'bo-')
            if self.ylegend:
                ax.legend([L1,L2],self.ylegend, loc="best")
            else:
                ax.legend([L1,L2],["Meas", "Model"], loc="best")
            if self.ytext:
                ax.text(self.x[-1], self.y_mod[-1], self.ytext, fontsize=12,rotation=30 )       
            ax.set_ylim(min(min(self.y_meas),min(self.y_mod))*0.9, 
                max(max(self.y_meas),max(self.y_mod))*1.1)
        
        if self.log:
            ax.set_yscale('log')
        ax.set_xlabel(self.xlab)
        ax.set_ylabel(self.ylab)
        ax.set_title(self.title)
        print("\n %s is generated " %(self.pngname))
        if self.x2:
            if len(self.x2) != len(self.y2_meas) or len(self.x2) != len(self.y2_mod) :
                raise ValueError("the x2 y2 must have same dimensions\n")
            ax2 = ax.twinx()
            L3=ax2.plot(self.x2, self.y2_meas, 'mv-')
            L4=ax2.plot(self.x2, self.y2_mod, 'gs-')
            if self.y2legend:
                ax2.legend([L3,L4],[self.y2legend[0],self.y2legend[1]], loc='best')
            if self.y2text:
                ax2.text(self.x[-3], self.y_mod[-3], self.y2text, fontsize=12,rotation=30 )   
            ax2.set_ylim(min(min(self.y2_meas),min(self.y2_mod))*0.9, 
                max(max(self.y2_meas),max(self.y2_mod))*1.1)
            ax2.set_ylabel(self.y2lab, rotation=-90)
        plt.savefig(self.pngname)


# class ParkerPlot(object):
    # def __init__(self, mdf, tvds, tvgs):
        # self.data=ParkerModelPlotData(mdf="parker.mdf", tvds=tvds, tvgs=tvgs)
    
    # def plot_all(self):
        # self.data.run_diode()
        # self.data.skip_diode()
        # self.plot_vbr()
        # self.plot_fwd()
        # self.plot_idvd()
        # self.plot_idvg()
        # self.plot_subth()
        # self.plot_gmgds_constvds()
        # self.plot_gmgds_constvgs()
        # self.plot_cap_constvds()
        # self.plot_cap_constvgs()
        
    # def plot_only_diode(self):
        # self.data.run_diode()
        # self.plot_vbr()
        # self.plot_fwd()
        
    # def plot_only_dc(self):
        # self.data.skip_diode()
        # self.plot_idvd()
        # self.plot_idvg()
        # self.plot_gmgds_constvds()
        # self.plot_gmgds_constvgs()
        
    # def plot_only_charge(self):
        # self.data.skip_diode()
        # self.plot_cap_constvds()

    
    # def plot_vbr(self):
        # """plot breakdown"""
        # vbr = Plot_Util( x=self.data.x['vbr'],y_meas=self.data.y['vbr'], y_mod=self.data.y2['vbr'],
            # xlab="Vdg(V)", ylab="Idg(mA/mm)", pngname='breakdown.png', 
            # title="Breakdown Characteristic", log=True)
        # vbr.run()
    
    # def plot_fwd(self):
        # """plot forward diode"""
        # fwd = Plot_Util( x=self.data.x['fwd'],y_meas=self.data.y['fwd'], y_mod=self.data.y2['fwd'],
            # xlab="Vgs(V)", ylab="Igs(mA/mm)", pngname='forward.png', 
            # title="Diode Characteristic", log=True)
        # fwd.run()
    
    # def plot_idvd(self):
        # """plot idvd"""
        # idvd = Plot_Util( x=self.data.x['idvd'],y_meas=self.data.y['idvd'], y_mod=self.data.y2['idvd'],
            # xlab="Vds(V)", ylab="Ids(mA)", ytext=self.data.y_lab['idvd'], pngname='idvd.png', 
            # title="DC OutPut Characteristics", log=False)
        # idvd.run()
    
    # def plot_idvg(self):
        # """plot idvg"""
        # idvg = Plot_Util( x=self.data.x['idvg'],y_meas=self.data.y['idvg'], y_mod=self.data.y2['idvg'],
            # xlab="Vgs(V)", ylab="Ids(mA)", ytext=self.data.y_lab['idvg'], pngname='idvg.png', 
            # title="DC Transfer Characteristics", log=False)
        # idvg.run()
    
    # def plot_subth(self):
        # """plot subthreshold"""
        # subth = Plot_Util( x=self.data.x['sub'],y_meas=self.data.y['sub'], y_mod=self.data.y2['sub'],
            # xlab="Vgs(V)", ylab="Ids(mA)", ytext=self.data.y_lab['sub'], pngname='sub.png', 
            # title="Subthreshold Current", log=True)
        # subth.run()
    
    # def plot_gmgds_constvds(self):
        # """plot gmgds at constant vds"""
        # gmgds = Plot_Util( x=self.data.x['gm_cvds'],y_meas=self.data.y['gm_cvds'], y_mod=self.data.y2['gm_cvds'],
            # x2=self.data.x['gds_cvds'],y2_meas=self.data.y['gds_cvds'], y2_mod=self.data.y2['gds_cvds'],
            # xlab="Vgs(V)", ylab="Gm(mS)",ylegend=['Gm_meas','Gm_mod'], ytext=self.data.y_lab['gm_cvds'], y2lab="Gds(mS)",
            # y2legend=['Gds_meas','Gds_mod'], y2text=self.data.y_lab['gds_cvds'],pngname='gmgds_cvds.png', title="Gm/Gds@constant Vds", log=False)
        # gmgds.run()
    
    # def plot_gmgds_constvgs(self):
        # """plot gmgds at constant vgs"""
        # gmgds2 = Plot_Util( x=self.data.x['gm_cvgs'],y_meas=self.data.y['gm_cvgs'], y_mod=self.data.y2['gm_cvgs'],
            # x2=self.data.x['gds_cvgs'],y2_meas=self.data.y['gds_cvgs'], y2_mod=self.data.y2['gds_cvgs'],
            # xlab="Vds(V)", ylab="Gm(mS)", ylegend=['Gm_meas','Gm_mod'], ytext=self.data.y_lab['gm_cvgs'], y2lab="Gds(mS)",
            # y2legend=['Gds_meas','Gds_mod'], y2text=self.data.y_lab['gds_cvgs'], pngname='gmgds_cvgs.png', title="Gm/Gds@constant Vgs", log=False)
        # gmgds2.run()
    
    # def plot_cap_constvds(self):
        # """plot cgs cgd at constant vds"""
        # cap = Plot_Util( x=self.data.x['cgs_cvds'],y_meas=self.data.y['cgs_cvds'], y_mod=self.data.y2['cgs_cvds'],
            # x2=self.data.x['cgd_cvds'],y2_meas=self.data.y['cgd_cvds'], y2_mod=self.data.y2['cgd_cvds'],
            # xlab="Vgs(V)", ylab="Cgs(pF)", ylegend=['Cgs_meas','Cgs_mod'], ytext=self.data.y_lab['cgs_cvds'], 
            # y2lab="Cgd(pF)",y2legend=['Cgd_meas','Cgd_mod'],y2text=self.data.y_lab['cgd_cvds'],  
            # pngname='cap_cvds.png', title="Cgs/Cgd@constant Vds",log=False)
        # cap.run()
    
    # def plot_cap_constvgs(self):
        # """plot cgs cgd at constant vgs"""
        # cap2 = Plot_Util( x=self.data.x['cgs_cvgs'],y_meas=self.data.y['cgs_cvgs'], y_mod=self.data.y2['cgs_cvgs'],
            # x2=self.data.x['cgd_cvgs'],y2_meas=self.data.y['cgd_cvgs'], y2_mod=self.data.y2['cgd_cvgs'],
            # xlab="Vds(V)", ylab="Cgs(pF)", ylegend=['Cgs_meas','Cgs_mod'], ytext=self.data.y_lab['cgs_cvgs'], 
            # y2lab="Cgd(pF)", y2legend=['Cgd_meas','Cgd_mod'], y2text=self.data.y_lab['cgd_cvgs'], 
            # pngname='cap_cvgs.png', title="Cgs/Cgd@constant Vgs", log=False)
        # cap2.run()
    
        
