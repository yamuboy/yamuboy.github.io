"""
Single-finger EM deembedding code for batch-mode deembedding


"""
from __future__ import unicode_literals, absolute_import, division, print_function
import os, sys
import numpy as np
import logging

from network_params import ParamSet, Touchstone

def sf_deembed( meas_p, em_p, num_fingers=2, common_gate=False, pin_order=('g','d','s'),
        cg_pin_order=('d','s'), output_ptype='s' ):
    """single-finger EM deembedding routine
    
    The output of this deembedding will be the instrinsic 2-port network parameters of the
    single finger model in common source configuration.  The default output network parameter
    type is 's', though any valid network parameter type can be selected.  At this time all
    network parameter type conversions assume 50 ohm reference impedance.
    
    NOTE: the output network parameters will ALWAYS be in common source, independent of the
    setting of the 'common_gate' parameter.
    
    Required parameters:
    --------------------------------------------------------
    meas_p
        `network_params.ParamSet` object containing 2-port measured S-parameters to deembed 
    
    em_p
        `network_params.ParamSet` object containing network parameters of the EM deembedding
        network.  The number of ports that must be present in this data set depends on the
        setting of the 'num_fingers' and 'common_gate' parameters.  In normal mode the
        number of ports must be num_fingers*3+2, and in common gate mode the number of ports
        must be num_fingers*2+2.  See below in the "EM network parameter port ordering"
        section for information about what the port ordering must be.  Port order is impacted
        by the 'pin_order' parameter (or 'cg_pin_order' when common gate mode is enabled).    
        
    Keywords:
    --------------------------------------------------------
    num_fingers
        (int) number of internal fingers in the extraction, the required port count of the EM
        deembedding parameters is dependent on this parameter [default: 2]
    
    common_gate
        (bool) when True use "common gate" mode for the deembedding, this sets the number of
        internal ports per finger to be equal to 2.  When False the number of internal ports
        per finger is 3 [default: False]
    
    pin_order
        (3-tuple) order of the internal ports for each finger in the EM deembedding matrix,
        when deembedding in normal mode, must contain the 3 values 'g', 'd', and 's'
        [default: ('g','d','s')]
        
    cg_pin_order
        (2-tuple) order of the internal ports for each finger in the EM deembedding matrix,
        when deembedding in common gate mode, must contain the 2 values 'd' and 's'
        [default: ('d','s')]
    
    output_ptype
        (string) the output network parameter type [default: 's']

    EM network parameter port ordering:
    --------------------------------------------------------
    Normal Mode
        1       gate-side measurement reference plane
        2       drain-side measurement reference plane
        3,4,5   gate, drain, and source of first triple of internal ports,
                    order is defined by `pin_order`
        6,7,8   (optional) gate, drain, and source of second port triple ...
        ...
    
    Common Gate
        1       gate-side measurement reference plane
        2       drain-side measurement reference plane
        3,4     drain and source of first pair of internal ports,
                    order is defined by `cg_pin_order`
        5,6     (optional) drain and source of second port pair ...
        ...

    """
    
    if not isinstance(meas_p,ParamSet):
        raise ValueError("'meas_p' is not a `network_params.ParamSet` object")
    elif meas_p.nports != 2:
        raise ValueError("'meas_p' is not a 2-port data set")
        
    if not isinstance(em_p,ParamSet):
        raise ValueError("'em_p' is not a `network_params.ParamSet` object")
        
    # make sure num_fingers is an integer
    num_fingers = int(num_fingers)
    if num_fingers < 1:
        raise ValueError("'num_fingers' must be an integer > 0")
        
    # compute port counts
    n_int_ports = 3
    if common_gate:
        n_int_ports = 2
        if not isinstance(cg_pin_order,tuple) or len(cg_pin_order) != 2:
            raise TypeError("'cg_pin_order' must be a 2-tuple")
        if 'd' not in cg_pin_order:
            raise ValueError("'cg_pin_order' is missing the value 'd'")        
        if 's' not in cg_pin_order:
            raise ValueError("'cg_pin_order' is missing the value 's'")        
            
    else:
        if not isinstance(pin_order,tuple) or len(pin_order) != 3:
            raise TypeError("'pin_order' must be a 3-tuple")
        if 'g' not in pin_order:
            raise ValueError("'pin_order' is missing the value 'g'")        
        if 'd' not in pin_order:
            raise ValueError("'pin_order' is missing the value 'd'")        
        if 's' not in pin_order:
            raise ValueError("'pin_order' is missing the value 's'")
            
    em_size = num_fingers*n_int_ports + 2
    
    if em_p.nports != em_size:
        raise ValueError("'em_p' must be a %d-port data set (num_fingers*%d+2), actual size = %d"%(em_size,n_int_ports,em_p.nports))
    
    # convert measured and EM data into Y-parameters
    meas_p.convert('y')
    em_p.convert('y')
    
    # get a logging target for warnings
    logger = logging.getLogger('modeling.single_finger')
    
    # start the math
    out = meas_p.copy_truncated()
    for m in meas_p:
        
        # extract data from the EM dataset
        try:
            emd = em_p.extract(m.freq).data
        except Exception:
            logger.warning("EM deembedding data set is missing frequency %g GHz (skipping)"%(m.freq*1.0e-9))
            continue

        if common_gate:
            mi = m.data
            A = np.matrix(emd[:2,:2])
            B = np.matrix(emd[:2,2:])
            C = np.matrix(emd[2:,:2])
            D = np.matrix(emd[2:,2:])
            
        else:
            # the indefinite matrix calculations below are necessary to preserve
            # the data set, attempting to do the deembedding without a 3-port
            # measurement matrix results in lost data unless the matrix is converted
            # to indefinite form before doing the deembedding math
            
            # convert the measurement data set into an indefinite matrix
            mi = np.zeros((3,3),dtype=complex)
            mi[1:,1:] = m.data
            s00 = complex(0.0)
            for i in (1,2):
                sr = complex(0.0)
                sc = complex(0.0)
                for j in (1,2):
                    sr += mi[i,j]
                    sc += mi[j,i]
                mi[0,i] = -sc
                mi[i,0] = -sr
                s00 += sr
            mi[0,0] = s00
                    
            # convert the EM data set into an indefinite matrix
            ei = np.zeros((em_size+1,em_size+1),dtype=complex)
            ei[1:,1:] = emd
            s00 = complex(0.0)
            for i in range(1,em_size+1):
                sr = complex(0.0)
                sc = complex(0.0)
                for j in range(1,em_size+1):
                    sr += ei[i,j]
                    sc += ei[j,i]
                ei[0,i] = -sc
                ei[i,0] = -sr
                s00 += sr
            ei[0,0] = s00
                
            # partition the EM data and convert to the speciality `numpy.matrix` type for matrix math operations
            A = np.matrix(ei[:3,:3])
            B = np.matrix(ei[:3,3:])
            C = np.matrix(ei[3:,:3])
            D = np.matrix(ei[3:,3:])
                    
        # debug:
        # print("shape(A) = %s, shape(B) = %s, shape(C) = %s, shape(D) = %s"%(A.shape,B.shape,C.shape,D.shape))
        
        # compute deembedding
        E = (A-mi).I
        T = C*E*B-D
        
        # average the result matrix over the sub-matrices that make up the fingers
        if num_fingers > 1:
            TA = np.zeros((n_int_ports,n_int_ports),dtype=complex)
            for x in range(num_fingers):
                for y in range(num_fingers):
                    for i in range(n_int_ports):
                        for j in range(n_int_ports):
                            TA[i,j] += T[x*n_int_ports+i,y*n_int_ports+j]
            TA = TA / float(num_fingers)
        else:
            TA = T
        
        # convert common gate solution to common source
        # OR
        # convert the indefinite 3-port matrix to 2-port common source
        if common_gate:
            # convert common gate to common source
            md = cg_pin_order.index('d')
            ms = cg_pin_order.index('s')
            R = np.array([[TA[ms,ms]+TA[md,ms]+TA[ms,md]+TA[md,md],-TA[ms,md]-TA[md,md]],[-TA[md,ms]-TA[md,md],TA[md,md]]])
        else:
            # take the indefite matrix and drop the source
            mg = pin_order.index('g')
            md = pin_order.index('d')
            R = np.array([[TA[mg,mg],TA[mg,md]],[TA[md,mg],TA[md,md]]])
        
        # store the results
        out.insert(m.freq,R)
    
    # convert the output parameters to the desired output type
    if output_ptype.lower() != 'y':
        out.convert(output_ptype)
        
    return out
        
def sf_deembed_cl(dont_setup_logging=False):
    "command-line interface for sf_deembed routine"
    from optparse import OptionParser
    from modeling.file_utils import expand_file_list    
    
    # basic logging setup
    if not dont_setup_logging:
        logging.basicConfig()
    
    # set up the command line option parser
    parser = OptionParser(usage="%prog [option] em_file meas_file [meas_file ...]")
    parser.add_option('--cg','--common-gate',action='store_true',dest='cg', default=False,help='run common-gate mode deembedding [default: False]')
    parser.add_option('--fingers',type='int',dest='nf',help="the number of fingers in the deembedding network [default: 2]")
    parser.add_option('--out-type',dest='ty',help="the output parameter type [default: 's']")
    parser.add_option('--order',dest='po',help="pin order in the EM deembedding matrix [default: 'gds'/'ds' (normal/common gate)]")
    parser.add_option('-e','--ext',dest='ext',default='.dmx',help="extension for output files [default: '.dmx']")
        
    # run the parser
    opts, files = parser.parse_args()
    
    if len(files) < 2:
        parser.print_usage()
        sys.exit(1)
    
    # read the deembedding data
    em_data = Touchstone(files[0])
    
    # generate a list of files (this handles the lack of a standard shell glob on Windows)
    flist = expand_file_list(files[1:])
    
    # set up deembedding keywords
    kw = {}
    if opts.nf:
        kw['num_fingers'] = opts.nf
    if opts.ty:
        kw['output_ptype'] = opts.ty
    if opts.cg:
        kw['common_gate'] = True
    if opts.po:
        s = opts.po
        if opts.cg:
            if s not in ('ds','sd'):
                raise ValueError("invalid value for '--order' -> must be 'ds' or 'sd' for common gate mode")
            kw['cg_pin_order'] = tuple([x for x in s])
        else:            
            if s not in ('gds','gsd','dgs','dsg','sgd','sdg'):
                raise ValueError("invalid value for '--order' -> must be one of 'gds', 'gsd', 'dgs', 'dsg', 'sgd', or 'sdg'")
            kw['pin_order'] = tuple([x for x in s])
    
    ext = opts.ext
    if not ext.startswith('.'):
        ext = '.'+ext
        
    # run the deembedding loop for the list of files
    for f in flist:    
        try:
            meas = Touchstone(f)
        except Exception as e:
            sys.stderr.write("Error: could not read '%s' -> %s\n"%(f,e))
            continue
            
        outfname = os.path.splitext(f)[0] + ext
        if outfname == f:
            sys.stderr.write("Error: output file name is the same as input file name (won't overwrite)\n")
            continue
    
        # compute deembedding and write data
        out = sf_deembed(meas,em_data,**kw)
        out.write(outfname)
                