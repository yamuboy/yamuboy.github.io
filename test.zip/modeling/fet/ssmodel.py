from __future__ import unicode_literals, absolute_import, division, print_function
from ..model import LinearModel
from ..optimize import OptimizableParam
from ..ymatrix import reduce as yreduce, reduce_w_cy
import numpy as np
import cmath

class FET_SS_Model(LinearModel):
    """The full small signal model of a FET.
    
    The compute_y() method does the bulk of the work here.
    
    In order to get 2-port S-params from this model:
    
        from modeling.fet.ssmodel import FET_SS_Model
        from network_params import param_convert
        
        # create a model instance
        m = FET_SS_Model()
        
        ##  ...set model param values (not shown)
        
        # compute Y-params (at 1 GHz)
        yp = m.compute_y( 1.0e9 )
        
        # use nodes 0 and 1 in the S-param computation, node 2 is the source
        #  which is presumably grounded so it can be ignored
        # the resulting 2x2 matrix is the S-params of the FET model
        s = param_convert('y', 's', yp[0:2,0:2], 50.0)
        
    The above process could also be done using a tuple of frequencies to the
    compute_y() method, and could be simplified by specifying True as the second
    optional argument to compute_y, which tells the model to only return a 2-port
    matrix.
        # yp will be a 2-tuple (1 GHz and 2 GHz) of 2x2 Y-matrices
        yp = m.compute_y( (1.0e9,2.0e9), True )
    """
    
    def __init__(self,**kwargs):
        # model parameters
        params = (
            OptimizableParam('rg',1.0e-3),
            OptimizableParam('rd',1.0e-3),
            OptimizableParam('rs',1.0e-3),
            OptimizableParam('lg',1.0e-18),
            OptimizableParam('ld',1.0e-18),
            OptimizableParam('ls',1.0e-18),
            OptimizableParam('cpg',0.0),
            OptimizableParam('cpd',0.0),
            OptimizableParam('c11',0.0),
            OptimizableParam('c22',0.0),
            OptimizableParam('cgs',0.8e-12),
            OptimizableParam('cgd',0.05e-12),
            OptimizableParam('cds',0.08e-12),
            OptimizableParam('ri',1.0e-3),
            OptimizableParam('rgd',0.0),
            OptimizableParam('gm',50.0e-3),
            OptimizableParam('gds',0.1e-3),
            OptimizableParam('tau',2.0e-12),
            OptimizableParam('tau2',0.0),
            OptimizableParam('ggs',0.0),
            OptimizableParam('ggd',0.0),
            OptimizableParam('vv',0.0),
            OptimizableParam('ii',0.0),
            )
        
        # init the parent, this model has 3 external nodes
        LinearModel.__init__(self,3,params=params)
    __init__.__doc__ = __doc__
        
    def compute_y(self, freq, two_port=False):
        """Compute Y-parameters
        
        'freq' is either a float or a sequence of floats.
        
        If 'two_port' is True, then only a 2x2 matrix will be returned
        consisting of the gate and drain nodes (0 and 1, resp.)
        
        Returns either a numpy matrix or a list of numpy matrices, the
        size will be either 2x2 or 3x3 depending on the state of the 
        'two_port' parameter
        
        index 0 is the gate
        index 1 is the drain
        index 2 is the source
        """
        retlist = True
        ret = []
        if not np.iterable(freq):
            freq = [freq]
            retlist = False
        
        for f in freq:
            y = yreduce(self._load_y(f),[0,1,2])
            if two_port:
                ret.append(y[0:2,0:2])
            else:
                ret.append(y)
        
        if retlist:
            return ret
        else:
            return ret[0]
        
    def compute_n(self, freq, two_port=False, kelvin=290.0):
        """Compute the noise correlation matrix
        
        'freq' is either a float or a sequence of floats.
        
        If 'two_port' is True, then only a 2x2 matrix will be returned
        consisting of the gate and drain nodes (0 and 1, resp.)
        
        'kelvin' is the temperature to use for computation of the noise
        power of passive elements in degrees Kelvin
        
        Returns either a numpy matrix or a list of numpy matrices, the
        size will be either 2x2 or 3x3 depending on the state of the 
        'two_port' parameter
        
        index 0 is the gate
        index 1 is the drain
        index 2 is the source
        """
        retlist = True
        ret = []
        if not np.iterable(freq):
            freq = [freq]
            retlist = False
        
        for f in freq:
            y, cy = reduce_w_cy(self._load_y(f),self._load_cy(f,kelvin),[0,1,2])
            if two_port:
                ret.append(cy[0:2,0:2])
            else:
                ret.append(cy)
        
        if retlist:
            return ret
        else:
            return ret[0]

    def compute_y_and_n(self, freq, two_port=False, kelvin=290.0):
        """Compute the Y-matrix and noise correlation matrix simultaneously
        
        This is a more efficient call then calling both compute_y() and compute_n()
        to get the Y-matrix and noise correlation matrix, since computing the noise
        correlation matrix requires computation of the Y-matrix anyway.
        
        'freq' is either a float or a sequence of floats.
        
        If 'two_port' is True, then only a 2x2 matrix will be returned
        consisting of the gate and drain nodes (0 and 1, resp.)
        
        'kelvin' is the temperature to use for computation of the noise
        power of passive elements in degrees Kelvin
        
        Returns either a single 2-tuple of numpy matrices or a list of 2-tuples
        of numpy matrices, the size of the matrices will be either 2x2 or 3x3
        depending on the state of the 'two_port' parameter. The 2-tuple consists
        of (y_matrix, noise_corr_matrix).
        
        index 0 is the gate
        index 1 is the drain
        index 2 is the source
        """
        retlist = True
        ret = []
        if not np.iterable(freq):
            freq = [freq]
            retlist = False
        
        for f in freq:
            y, cy = reduce_w_cy(self._load_y(f),self._load_cy(f,kelvin),[0,1,2])
            if two_port:
                ret.append( (y[0:2,0:2],cy[0:2,0:2]) )
            else:
                ret.append( (y,cy) )
        
        if retlist:
            return ret
        else:
            return ret[0]

            
    def _load_y(self, f):
        "load the Y-matrix for the model at one frequency"
        
        def addy( mat, y, n, m ):
            'add a standard branch component to the Y-matrix'
            mat[n,n] += y
            mat[m,m] += y
            mat[n,m] -= y
            mat[m,n] -= y
            
        MATSZ = 9
        w = 2.0*np.pi*f
        yp = np.zeros((MATSZ,MATSZ), dtype=complex)
        
        """
        ===== Node numbers =====
        0   Gate port
        1   Drain port
        2   Source port
        3   Node between Lg, C11, and Rg
        4   Node between Ld, C22, and Rd
        5   Internal Gate Node
        6   Internal Drain Node
        7   Internal Source Node
        8   Node between Cgs and Ri
        """
        # add normal branch components
        addy(yp, 1.0/self['rg'].v, 3, 5)
        addy(yp, 1.0/self['rd'].v, 4, 6)
        addy(yp, complex(0.,-1.0/(w*self['lg'].v)), 0, 3)
        addy(yp, complex(0.,-1.0/(w*self['ld'].v)), 1, 4)
        addy(yp, complex(self['ggs'].v,w*self['cgs'].v), 5, 8)
        rgd = self['rgd'].v
        if rgd > 0.0:
            x1 = complex(self['ggd'].v,w*self['cgd'].v)
            addy(yp, x1/(1.0+rgd*x1), 5, 6)
        else:
            addy(yp, complex(self['ggd'].v,w*self['cgd'].v), 5, 6)
        addy(yp, self['gds'].v*cmath.exp(complex(0.,-w*self['tau2'].v)) + complex(0.,w*self['cds'].v), 6, 7)
        addy(yp, 1.0/self['ri'].v, 7, 8)
        addy(yp, complex(0.,w*self['c11'].v), 2, 3)
        addy(yp, complex(0.,w*self['c22'].v), 2, 4)
        rs,ls = self['rs'].v,self['ls'].v
        den = 1. / (rs*rs + w*w*ls*ls)
        addy(yp, complex(rs*den,-w*ls*den), 2, 7)
        
        # add components that only connect to one place (other end grounded)
        yp[0,0] += complex(0.,w*self['cpg'].v)
        yp[1,1] += complex(0.,w*self['cpd'].v)
        
        # add Gm and Tau
        gm_tau = self['gm'].v * cmath.exp( complex(0., -w*self['tau'].v) )
        yp[6,5] += gm_tau
        yp[6,8] -= gm_tau
        yp[7,5] -= gm_tau
        yp[7,8] += gm_tau
        
        return yp
        
    def _load_cy(self, f, kelvin):
        "load the noise correlation matrix for the model at one frequency"
        
        def addy( mat, y, n, m ):
            'add a standard branch component to the Y-matrix'
            mat[n,n] += y
            mat[m,m] += y
            mat[n,m] -= y
            mat[m,n] -= y
            
        MATSZ = 9
        w = 2.0*np.pi*f
        cy = np.zeros((MATSZ,MATSZ), dtype=complex)
        tscal = kelvin / 290.0       
        
        """
        ===== Node numbers =====
        0   Gate port
        1   Drain port
        2   Source port
        3   Node between Lg, C11, and Rg
        4   Node between Ld, C22, and Rd
        5   Internal Gate Node
        6   Internal Drain Node
        7   Internal Source Node
        8   Node between Cgs and Ri
        """
        # add normal branch components
        addy(cy, tscal/self['rg'].v, 3, 5)
        addy(cy, tscal/self['rd'].v, 4, 6)
        addy(cy, tscal*self['ggs'].v, 5, 8)
        rgd = self['rgd'].v
        if rgd > 0.0:
            x1 = complex(self['ggd'].v,w*self['cgd'].v)
            addy(cy, tscal*(x1/(1.0+rgd*x1)).real, 5, 6)
        else:
            addy(cy, tscal*self['ggd'].v, 5, 6)
        rs,ls = self['rs'].v,self['ls'].v
        den = 1. / (rs*rs + w*w*ls*ls)
        addy(cy, tscal*rs*den, 2, 7)
        
        # add intrinsic active noise sources
        ri = self['ri'].v
        addy(cy,self['vv'].v/(ri*ri), 7, 8)
        addy(cy,self['ii'].v, 6, 7)
                
        return cy
        
        
