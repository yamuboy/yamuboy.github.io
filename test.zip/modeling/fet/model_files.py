from __future__ import unicode_literals, absolute_import, division, print_function
from modeling.optimize import OptimizableParam
from modeling.fet import FET_SS_Model, FET_Model_Config
import modeling.fet.extract.fet_model_params
import os.path
import logging
from .. import _str_type, _number_types

_log = logging.getLogger('modeling.fet.model_files')

def read_ss_model(fname):
    "read model data from a file"
    try:
        data = {}
        with open(fname,'r') as fp:
            exec(compile(fp.read(),fname,'exec'),globals(),data)
    except Exception as e:
        raise ValueError("read_ss_model('{}'): {}".format(fname,e))
    
    optvals = {}
    pvals = {}
    for k in data:
        v = data[k]
        if isinstance(v,tuple):
            if len(v) != 3:
                raise ValueError("read_ss_model('%s'): invalid value for parameter '%s'"%(fname,k))
            pvals[k] = v[1]
            optvals[k] = v[0],v[2]
        elif isinstance(v,_number_types):
            pvals[k] = v
        else:
            raise ValueError("read_ss_model('%s'): invalid value for parameter '%s'"%(fname,k))
        
    model = FET_SS_Model()
    model.update(pvals)
    for k in optvals:
        try:
            op = model[k]
            if isinstance(op,OptimizableParam):
                op.set_opt_range(*optvals[k])
        except KeyError:
            pass        
    
    return model

def write_ss_model(fname, model):
    "write model data to a file"
    if not isinstance(fname,_str_type):
        raise TypeError("'fname' must be a string")        
    
    if not isinstance(model,FET_SS_Model):
        raise TypeError("'model' must be an instance of FET_SS_Model")
    
    parms = model.get_params(as_dict=True)
    names = list(parms.keys())
    names.sort()
    
    fp = open(fname,'w')
    fp.write('#---+++FET model data+++---\n#--VERSION: 1\n#\n#Format: name = min, nominal, max\n')
    for n in names:
        if isinstance(parms[n],OptimizableParam):
            optmin, optmax = parms[n].optlimits
            if optmin is None:
                optmin = parms[n].value
            if optmax is None:
                optmax = parms[n].value
                
            fp.write('%-4s = %+12.4e, %+12.4e, %+12.4e\n'%(n,optmin,parms[n].value,optmax))                
        else:
            fp.write('%-4s = %+12.4e, %+12.4e, %+12.4e\n'%(n,parms[n].value,parms[n].value,parms[n].value))
    fp.close()

def read_old_ss_model(fname):
    "read an old-style SS model (from a .end file)"
    pmap = { 'CDG':'cgd', 'GDG':'ggd', 'C1':'cpg', 'C2':'cpd',
        'B1':'lg', 'B2':'ld', 'TAU1':'tau' }
        
    fp = open(fname,'r')
    pvals = {}
    optvals = {}
    try:
        for line in fp:
            try:
                d = line.strip().split()
                if len(d) != 5:
                    continue
                
                vals = [float(x) for x in d[:4]]
                name = d[4]
            except Exception:
                continue
            
            if name in pmap:
                pname = pmap[name]
            else:
                pname = name.lower()
                
            pvals[pname] = vals[1]
            optvals[pname] = (vals[0],vals[2])
    
    finally:
        fp.close()
        
    model = FET_SS_Model()
    model.update(pvals)
    for k in optvals:
        try:
            op = model[k]
            if isinstance(op,OptimizableParam):
                op.set_opt_range(*optvals[k])
        except KeyError:
            pass
            
    return model
    
def write_old_ss_model(fname, model):
    "write an old-style SS model (to a .end file)"
    if not isinstance(fname,_str_type):
        raise TypeError("'fname' must be string-like")        
    
    if not isinstance(model,FET_SS_Model):
        raise TypeError("'model' must be an instance of FET_SS_Model")
    
    pnames = ('rg','rd','rs','ri','cgs','cgd','cds','cpg','cpd','ls','lg',
        'ld','ggs','ggd','gm','tau','gds','tau2','c11','c22')
    pmap = {'rg':'RG', 'rd':'RD', 'rs':'RS', 'ri':'RI', 'cgs':'CGS', 'cgd':'CDG',
        'cds':'CDS', 'cpg':'C1', 'cpd':'C2', 'ls':'LS', 'lg':'B1', 'ld':'B2',
        'ggs':'GGS', 'ggd':'GDG', 'gm':'GM', 'tau':'TAU1', 'gds':'GDS', 'tau2':'TAU2',
        'c11':'C11', 'c22':'C22'}
    
    parms = model.get_params(as_dict=True)    
    fp = open(fname,'w')
    for n in pnames:
        if isinstance(parms[n],OptimizableParam):
            optmin, optmax = parms[n].optlimits
            fp.write("%+.4e %+.4e %+.4e %+.4e %s\n"%(optmin,parms[n].value,optmax,0.0,pmap[n]))
        else:
            fp.write("%+.4e %+.4e %+.4e %+.4e %s\n"%(parms[n].value,parms[n].value,parms[n].value,0.0,pmap[n]))            
    fp.close()
    
def load_ss_model(fname, old_style=False, extension=None):
    "small wrappoer to provide some logic around loading small signal model files"

    base, ext = os.path.splitext(fname)
    if old_style:
        if extension:
            modname = base+extension
        else:
            modname = base+'.end'
        _log.debug("load_ss_model(): reading old-style model with name '%s'"%modname)
        r = read_old_ss_model(modname)
    else:
        if extension:
            modname = base+extension
        else:
            modname = base+FET_Model_Config()['model_extension']
        _log.debug("load_ss_model(): reading model with name '%s'"%modname)
        r = read_ss_model(modname)
    return r
    
        
    
    

    
