from __future__ import unicode_literals, absolute_import, division, print_function
import math
from network_params import BiasedTouchstone, ParamSet
from ..model import Model
from ..modelparam import FloatParam
from ..optimize import OptimizableParam, BasicEngine, get_worker
import logging

def compute_cap(files, rb=1.e-6, rc=1.e-6, re=1.e-6, lb=1.e-18, lc=1.e-18, le=1.e-18, **kwargs):
    """Extract junction capacitance from S-parameters."""
    
    fmin = kwargs.get('cj_fmin',0.0)
    fmax = kwargs.get('cj_fmax',100.0)
    ret = []
    for fname in files:
        
#        try:
        if isinstance(fname,BiasedTouchstone):
            # already a touchstone data object
            f = fname
        else:
            # read the file using the touchstone class
            f = BiasedTouchstone(fname)
        
        # get bias information and correct it for port resistances
        vbe = f.v1 - (rb+re)*f.i1 - re*f.i2
        vce = f.v2 - (rc+re)*f.i2 - re*f.i1            
        
        # extract a set of data to use
        ds = ParamSet(f.data_between(fmin*1.0e9, fmax*1.0e9), ptype=f.param_type)
        if not len(ds):
            raise ValueError("%s: contains no points meeting frequency criteria."%f.filename)
        
        
        
        # remove parasitics
        ds.convert('z')
        for p in ds:
            w = 2.0*math.pi*p.freq
            zcom = re + w*le*1j
            p[0,0] -= rb + w*lb*1j + zcom
            p[0,1] -= zcom
            p[1,0] -= zcom
            p[1,1] -= rc + w*lc*1j + zcom
            
        # extract capacitances
        ds.convert('y')
        cbe = 0.0
        cbc = 0.0
        cc = 0.0
        n = 0
        for p in ds:
            w = 2.0*math.pi*p.freq                
            # base-collector capacitance comes from the average of Y12 and Y21
            cbc1 = -(0.5*(p[0,1]+p[1,0])).imag / w
            cbc += cbc1
            # base-emitter capacitance comes from Y11 with cbc removed 
            cbe += p[0,0].imag / w - cbc1
            # collector capacitance to ground
            cc += p[1,1].imag / w - cbc1
            n += 1
        cbe /= float(n)
        cbc /= float(n)
        cc /= float(n)
        
        # store data
        data = dict()
        data['vbe'] = vbe
        data['vce'] = vce
        data['cbc'] = cbc
        data['cbe'] = cbe
        data['cc'] = cc
        data['filename'] = f.filename
        ret.append(data)
#        except Exception, e:
#            logging.error("%s"%e) 
    
    return ret
    
class VBICJunctionCap(Model):
    """Representation of the VBIC model junction capacitance."""
    
    def __init__(self,**kwargs):
        """Create a new object."""
        # model parameters
        p = (
            OptimizableParam('cj', 1.0e-13, optrange=(1.0e-18,1.0e-10)),
            OptimizableParam('p', 1.1, optrange=(0.5,2.2)),
            OptimizableParam('m', 0.33, optrange=(0.1,0.55)),
            FloatParam('fc', 0.9),
            FloatParam('aj', -0.5),
            )
        
        # init the parent, this model has 3 external nodes
        Model.__init__(self,params=p)
    
    def compute_cj(self, vj):
        """Compute the junction capacitance.
        
        not using the 'aj' parameter in the calculations since I can't find
        an equation that spells out how it is integrated
        """
        if vj < self['fc'].v*self['p'].v:
            return self['cj'].v / pow(1.0-(vj/self['p'].v),self['m'].v)
        else:
            return self['cj'].v / pow(1.0-self['fc'].v,1.0+self['m'].v) * (1.0-self['fc'].v*(1.0+self['m'].v)+self['m'].v*vj/self['p'].v)
        

class VBICCapExtract(object):
    """Simple class to help with extraction of VBIC junction capacitance models."""
    
    def __init__(self):
        """Create the object."""
        self.model = VBICJunctionCap()
        self.raw_data = None
        self.cap_data = None
        self.extract_data = None
        self.ccave = 0.0
    
    def extract(self, files, mode, **kwargs):
        """Extract the junction capacitance parameters."""
        
        if mode not in ('cbc','cbe',):
            raise ValueError("'mode' must be 'cbc' or 'cbe'")
            
        # extract the capacitance
        self.raw_data = compute_cap(files, **kwargs)
        
        # create a data set for optimization
        if mode == 'cbe':
            vj_max = kwargs.get('cbe_vmax',100.0)
        else:
            vj_max = kwargs.get('cbc_vmax',100.0)
        self.extract_data = []
        self.cap_data = []
        ccave = 0.0
        n = 0
        for d in self.raw_data:
            if mode == 'cbc':
                cj = d['cbc']
                vj = d['vbe'] - d['vce']
            else: # mode == 'cbe'
                cj = d['cbe']
                vj = d['vbe']
            self.cap_data.append( (vj,cj) )
            if vj <= vj_max:
                ccave += d['cc']
                n += 1
                self.extract_data.append( (vj,cj) )
        
        # average value of collector capacitance
        self.ccave = ccave / float(n)
        
        # find a value for CJ(0)
        cj0 = None
        dist = 100000.0
        for vj,cj in self.extract_data:
            if cj0 is None or abs(vj) < dist:
                cj0 = cj
                dist = abs(vj)
        
        # set up the optimization of CJ
        self.model['cj'].v = cj0
        self.model['cj'].set_opt_range(cj0*0.97, cj0*1.03)     
        
        # set up and run the optimization
        wcls = get_worker('gradient')
        worker = wcls(self._erf,self.model.get_named_params(('cj','p','m')))
        engine = BasicEngine( worker=worker, iter=100, itercb=self.itercb )
        engine.optimize()     
        
    def _erf(self):
        """Optimization error function callback."""
        e = 0.0
        for vj,cj in self.extract_data:
            cjm = self.model.compute_cj(vj)
            diff = cj - cjm
            e += diff*diff
        return e
        
    def itercb(self, n, e):
        """Optimization iteration callback."""
        print("%-5d: %g"%(n, e[0]))
        