from __future__ import unicode_literals, absolute_import, division, print_function

import glob
import os.path
import logging

from .spar_reader import TouchstoneReadAndDeembed, read_and_deembed_spars
from .end_file import EndFile
from . import _str_type, _number_types

def expand_file_list(files):
    """Generate a list of real files (that really exist on the disk)
    from a pattern, list of patterns, or a simple list of file names.
    """
    # expand the file list by expanding wildcards
    # also prepend working directory information to
    # the file names
    if isinstance(files,_str_type):
        files = (files,)

    if not isinstance(files,(list,tuple)):
        raise TypeError("argument must be a list/tuple")

    expanded = []

    # expand the each file in the list
    for fn in files:
        if not isinstance(fn,_str_type):
            raise TypeError("argument must be a list/tuple of string instances")
            
        if fn.find('*')>-1 or fn.find('?')>-1 or fn.find('[')>-1:
            res = glob.glob(fn)
            if not len(res):
                logging.getLogger('modeling.file_utils').warning("expand_file_list(): expansion of '%s' resulted in 0 files"%fn)
                continue
            expanded.extend(res)
        else:
            if not os.path.isfile(fn):
                logging.getLogger('modeling.file_utils').warning("expand_file_list(): file '%s' does not exist"%fn)
                continue
            expanded.append(fn)

    expanded.sort()
    return expanded

    
def write_model_mdif(outname, params, header=None, params_per_line=5):
    "write a model-MDIF file"
    try:
        iter(params)
    except Exception:
        raise TypeError("'params' must be iterable")
    
    for p in params:
        if not isinstance(p,(list,tuple)) or not len(p) == 2:
            raise TypeError("'params' must be be an iterable of 2-tuples")
        if not isinstance(p[0],_str_type):
            raise TypeError("parameter names must be string objects")
        if not isinstance(p[1],_number_types):
            raise TypeError("parameter values must be numbers")
    
    autoclose = True
    if isinstance(outname,_str_type):
        fp = open(outname,'w')
    elif hasattr(outname,'write'):
        autoclose = False
        fp = outname
    else:
        raise TypeError("'outname' must be a filename or file-like object")
    
    try:
        if header:
            if not isinstance(header,_str_type):
                raise TypeError("'header' must be a string object")
            fp.write(header)
            if header[-1:] != '\n':
                fp.write('\n')
        
        fp.write("BEGIN BDTA\n")
        # write fixed parameters
        newline_at = int(params_per_line)-1
        s1 = "%    "
        s2 = "     "
        for i,p in enumerate(params):
            s1 += "%-14s"%p[0]
            s2 += "%-14.4e"%float(p[1])
            if i >= newline_at:
                fp.write("%s\n%s\n"%(s1,s2))
                s1 = "%    "
                s2 = "     "
                newline_at += int(params_per_line)
        
        if len(s2.strip()) > 0:
            # write leftover parameters on the last line
            fp.write("%s\n%s\n"%(s1,s2))
        
        fp.write("END\n")
    
    finally:
        if autoclose:
            fp.close()
        
    
        
        
        
    
    
    
    