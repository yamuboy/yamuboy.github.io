from __future__ import unicode_literals, absolute_import, division, print_function

class ExtractionError(Exception):
    pass