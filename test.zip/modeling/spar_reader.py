from __future__ import unicode_literals, absolute_import, division, print_function
import os, os.path, logging
from network_params import Param, ParamSet, Touchstone, DeembeddingUtil
import numpy as np

from . import _str_type

### default module options ###
CACHE_ENABLED = True
DEEMBEDDING_ENABLED = True
##############################

class TouchstoneReadAndDeembed(object):
    """
    This class encapsulates the S-parameter file reading and de-embedding code
    so that efficient caching can be employed
    """

    def __init__(self, **kwargs):
        """initializer
        
        """
        self.__flist = None
        self.__dmb = None
        self.__tsreader = Touchstone
        self.__cache_extension = '.dmb-cache'
        self.__enable_cache = CACHE_ENABLED
        self.__auto_deembed = DEEMBEDDING_ENABLED
        
        self._log = logging.getLogger('modeling.TouchstoneReadAndDeembed')
        
        if kwargs:
            self.config(**kwargs)

    def config(self, **kwargs):
        """Keyword-based configuration:
        -------------------------------------------------------
        
        freq_list   
                (list/tuple of floats) a list of frequencies (in Hz) to use
                for the frequency list of returned data objects.
        
        working_directory
                (string) NO LONGER VALID.
        
        touchstone_reader
        reader
                (type object) a type object that will be instanciated in
                order to read touchstone data files.  This should be a type derived from
                the <network_params.Touchstone> type
        
        deembedding_fixture1
        dmb1
                (string or network_params.ParamSet object) either the
                filename of the port 1 deembedding fixture or a ParamSet object of the
                network parameters of the fixture
        
        invert_fixture1
        inv1
                (boolean) invert the port 1 fixture matrix when
                applying deembedding to the network [default: True]
        
        swap_fixture1
        swap1
                (boolean) transpose the port 1 fixture matrix when
                applying deembedding to the network [default: False]
        
        deembedding_fixture2
        dmb2
                (string or network_params.ParamSet object) either the
                filename of the port 2 deembedding fixture or a ParamSet object of the
                network parameters of the fixture
        
        invert_fixture2
        inv2
                (boolean) invert the port 2 fixture matrix when
                applying deembedding to the network [default: True]
        
        swap_fixture2
        swap2
                (boolean) transpose the port 2 fixture matrix when
                applying deembedding to the network [default: False]
        
        auto_deembed
                (boolean) enable automatic deembedding [default: True]
        
        auto_cache
                (boolean) enable automatic file-based caching of deembedded
                data, data is stored in paralell to the original file with a different
                extension, specified by the 'cache_extension' parameter [default: True]
        
        cache_extension
                (string) extension to use for caching [default: `.dmb-cache`]
                
        """
        
        if 'working_dir' in kwargs: 
            raise ValueError("'working_dir' keyword argument is no longer supported")
        
        if 'freq_list' in kwargs:
            self.flist = kwargs.pop('freq_list')
        
        if 'touchstone_reader' in kwargs:
            self.reader = kwargs.pop('touchstone_reader')
        elif 'reader' in kwargs:
            self.reader = kwargs.pop('reader')
        
        if 'auto_deembed' in kwargs:
            self.__auto_deembed = bool(kwargs.pop('auto_deembed'))

        if 'auto_cache' in kwargs:
            self.__enable_cache = bool(kwargs.pop('auto_cache'))
        
        if 'cache_extension' in kwargs:
            ext = kwargs.pop('cache_extension')
            valid_ext_chars = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$+@~_-')
            if not isinstance(ext,_str_type):
                raise TypeError("`cache_extension` must be a string")
            if len(ext):
                if ext[:1] != '.':
                    ext = '.'+ext
                
                for c in ext[1:]:
                    if c not in valid_ext_chars:
                        raise ValueError("'cache_extension' contains invalid characters")
                
                self.__cache_extension = ext
            else:
                self.__cache_extension = ''
        
        # de-embedding parameters
        dmb = {}
        dmb['fname1'] = kwargs.pop('deembedding_fixture1',kwargs.pop('dmb1',None))
        dmb['invert1'] = kwargs.pop('invert_fixture1',kwargs.pop('inv1',True))
        dmb['swap1'] = kwargs.pop('swap_fixture1',kwargs.pop('swap1',False))
        dmb['fname2'] = kwargs.pop('deembedding_fixture2',kwargs.pop('dmb2',None))
        dmb['invert2'] = kwargs.pop('invert_fixture2',kwargs.pop('inv2',True))
        dmb['swap2'] = kwargs.pop('swap_fixture2',kwargs.pop('swap2',False))
        
        if len(kwargs):
            raise ValueError("invalid keywords: "+(', '.join(kwargs.keys())))
        
        # configure de-embedding
        if dmb['fname1'] or dmb['fname2']:
            self.set_deembedding(**dmb)
        else:
            self.clear_deembedding()
        
    __init__.__doc__ += config.__doc__

    def _getflist(self):
        if self.__flist:
            return self.__flist[:]
        return []
    def _setflist(self, v):
        if not v:
            self.__flist = None
        else:
            try:
                self.__flist = [float(f) for f in v]
            except:
                raise TypeError("must be an iterable of floats")
        
        if self.__dmb:
            # update the frequency list of the de-embedding
            self.__dmb.flist = self.__flist
    flist = property(_getflist,_setflist,None,"frequency list to extract from data")
         
    def _getreader(self):
        return self.__tsreader
    def _setreader(self, v):
        if not issubclass(v,Touchstone):
            raise TypeError("must be derived from 'network_params.Touchstone'")
        self.__tsreader = v
    reader = property(_getreader,_setreader,None,"touchstone file reader class")

    def set_deembedding(self, **kwargs):
        # if we have a defined frequency list, then add it to the keywords
        if self.__flist:
            kwargs['flist'] = self.flist
        # create the de-embedding object
        self.__dmb = DeembeddingUtil(**kwargs)
    set_deembedding.__doc__ = DeembeddingUtil.__init__.__doc__
    set_dmb = set_deembedding
    
    def clear_deembedding(self):
        "clear the deembedding configuration"
        self.__dmb = None
    clear_dmb = clear_deembedding
                        
    def read(self, fname, auto_deembed=None, use_cache=None, return_name=False):
        """Read a file and perform de-embedding.
        
        """
        fname_is_string = isinstance(fname,_str_type)
        
        if auto_deembed is not None:
            auto_deembed = bool(auto_deembed)
        else:
            auto_deembed = self.__auto_deembed
            
        if use_cache is not None:
            use_cache = bool(use_cache)
        else:
            use_cache = self.__enable_cache
        
        # check to see if a cached version of the file is available
        if fname_is_string and use_cache:
            try:
                cached, cache_fname = self._get_from_cache(fname)
                if cached:
                    self._log.debug("cache hit on '%s'"%fname)
                    if return_name:
                        return cached, cache_fname
                    else:
                        return cached
            except Exception as e:
                self._log.debug("cache read error for '%s' => %s"%(fname,e))
            self._log.debug("cache miss on '%s'"%fname)
        
        #### read the data file ####
        
        data = self.__tsreader(fname)
        
        #### frequency list extraction ####
        
        if self.__flist:
            data = data.copy_with_flist(self.__flist)
        
        if not auto_deembed or not self.__dmb:
            # no auto deembedding, just return the data
            if return_name:
                return data, data.filename
            else:
                return data
        
        # check to see if this is a cache file
        # if it is then do not re-processes de-embedding on it
        h = data.header.split('\n')
        if len(h) >= 1 and h[0].startswith('!$$$$>'):
            self._log.warning(data.filename+": this is a deembedding cache file - you probably shouldn't be reading it directly")
            if return_name:
                return data, data.filename
            else:
                return data
        
        #### deembedding ####
        
        data = self.__dmb.deembed(data)
        if use_cache and fname_is_string:
            # cache the de-embedded data, only do this if
            # caching is enabled and the 'fname' parameter
            # passed into this method was a string representing
            # a filename (there are too many wildcards in play
            # if the filename was not a string)
            cache_name = self._store_in_cache(fname,data)
            
        if return_name:
            if cache_name:
                return data, cache_name
            else:
                return data, data.filename                
        else:
            return data
    
    def _store_in_cache(self, fname, data):
        "store deembeded data for easier retrieval later"
        if not self.__cache_extension:
            return None
        cache_name = os.path.splitext(fname)[0] + self.__cache_extension
        if cache_name == fname:
            self._log.debug("unable to cache '%s' - cache name is the same as file name"%fname)
            return None
        
        # check that the input data is not cache data
        header = data.header.split('\n')
        iscache = True
        if len(header) >= 1 and header[0].startswith('!$$$$>'):
            self._log.debug("unable to cache '%s' - data comes from a cache file"%fname)
            return None
        
        # copy the data to cache writer so that the header can be modified
        # and modify the header to add the deembedding data
        ts = Touchstone(copy_from=data)
        dmbheader = '!$$$$> '+self.__dmb.fingerprint+'\n'
        ts.header = dmbheader + ts.header
        
        if os.path.exists(cache_name):
            if not os.path.isfile(cache_name) or os.path.islink(cache_name):
                self._log.debug("unable to cache '%s' - cache name target '%s' conflicts with a non-regular file"%(fname,cache_name))
                return None
            
            # check that the cache file is actually a cache file before overwriting it
            fp = open(cache_name,'r')
            line = fp.readline()
            fp.close()
            if not line.startswith('!$$$$>'):
                self._log.debug("unable to cache '%s' - cache file would overwrite another file"%fname)
                return None
            
            # overwrite the current cache file
            ts.write(cache_name)
        else:
            # cache file does not exist, write it
            ts.write(cache_name)
        
        return cache_name
    
    def _get_from_cache(self, fname):
        "attempt to retrive a file from the cache"
        if not self.__cache_extension or not self.__dmb:
            # can't cache if the extension is not set and there is no
            # point in reading a cache file if de-embedding is disabled
            return None, None
                
        cache_name = os.path.splitext(fname)[0] + self.__cache_extension
        
        # check that the original file exists
        if not os.path.isfile(fname):
            return None, None
        mt_f = int(os.stat(fname).st_mtime)
        
        try:
            tsdata = self.__tsreader(cache_name)
        except IOError:
            return None, None
        except Exception as e:
            self._log.debug("cache read failed for '%s' => %s"%(cache_name,e))
            return None, None
        
        # check that the mtime of the cache file is newer than the original file
        mt_c = int(os.stat(cache_name).st_mtime)
        if mt_c < mt_f:
            return None, None      
        
        # make sure that the data that was read was actually generated
        # by the caching process, and read the deembedding fingerprint
        header = tsdata.header.split('\n')
        if len(header) < 1:
            return None, None
        h0 = header[0]
        if not h0.startswith('!$$$$>'):
            return None, None
        pr = h0.split()[1]
            
        # this is a valid cache file
        # check its deembedding fingerprint against the current settings
        # and check that it has a frequency list that jives with current settings
        if pr.strip() == self.__dmb.fingerprint and self._flists_match(tsdata.flist,self.__flist):
            # everything checks out, remove the cache header lines
            # and return the cached data
            tsdata.header = '\n'.join(header[1:])
            return tsdata, cache_name
        else:    
            # remove the existing cache file and return
            self._log.debug("cache data stale for '%s'"%fname)
            os.unlink(cache_name)
            return None, None
            
    def purge(self):
        "purge cached data files (NOT IMPLEMENTED)"
        pass
    
    @staticmethod
    def _flists_match( fl1, fl2 ):
        "check if two frequency lists are the same"
        if not fl1:
            if not fl2:
                return True
            return False    
        elif not fl2:
            if not fl1:
                return True
            return False
        elif len(fl1) != len(fl2):
            return False
            
        # everything matches to this point, check the 2 lists point-by-point
        for i in range(len(fl1)):
            if abs(fl1[i]-fl2[i]) > 0.01:
                return False    
        return True
        
def read_and_deembed_spars( filenames, **kwargs ):
    """The utility function reads Touchstone-format S-parameter files, optionally
    performs frequency interpolation/reduction on them, and optionally deembeds
    (or embeds) fixtures.
    
    Returns a list of Touchstone-like objects that have been deembedded and otherwise
    modified as specified by keyword arguments.
    
    """
    if isinstance(filenames,_str_type+(ParamSet,)):
        filenames = (filenames,)
    
    if not isinstance(filenames,(list,tuple)):
        raise TypeError("The first argument must be a list or tuple type.")
        
    if not len(filenames):
        return []
    
    trad = TouchstoneReadAndDeembed(**kwargs)
    ret = []
    for f in filenames:
        ret.append( trad.read(f) )
    
    return ret
read_and_deembed_spars.__doc__ += TouchstoneReadAndDeembed.config.__doc__


def set_default_caching( flag ):
    """set the default caching mode to on (True) or off (False)
    
    NOTE: this will only apply to objects created AFTER this parameter
    is set.  All existing objects will retain their current caching
    settings.  Also, keywords passed to module objects at creation time
    or during subsequent configuration can override this default setting.
    """
    global CACHE_ENABLED
    CACHE_ENABLED = bool(flag)

def set_default_deembedding( flag ):
    """set the default deembedding mode to on (True) or off (False)
    
    NOTE: this will only apply to objects created AFTER this parameter
    is set.  All existing objects will retain their current deembedding
    settings.  Also, keywords passed to module objects at creation time
    or during subsequent configuration can override this default setting.
    """
    global DEEMBEDDING_ENABLED
    DEEMBEDDING_ENABLED = bool(flag)
    