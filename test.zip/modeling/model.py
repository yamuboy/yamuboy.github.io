from __future__ import unicode_literals, absolute_import, division, print_function
from .modelparam import *
from .optimize import OptimizableParam
import logging
try:
    from collections import OrderedDict
except ImportError:
    from ordereddict import OrderedDict
from . import _str_type

class Model(object):
    """The Model class is the base class for all models. It defines the basic
    behaviors of defining and accessing model parameters.
    """
    
    def __init__(self,params=None):
        'Initialize the model.'
        self.__params = OrderedDict()
        if params is not None:
            self._add_params(params)
    
    def _get_parms(self):
        'Return a shallow copy of the parameter dictionary'
        return self.__params.copy()
    def _set_parms(self,parms):
        'Set new values for the model parameters.'
        if not isinstance(parms,dict):
            raise TypeError('expecting a dictionary')
        for k in parms:
            if not k in self.__params:
                raise ValueError("The model has no parameter named '%s'" % k)
            self.__params[k].setv(parms[k])
    params = property(_get_parms,_set_parms,None,"get/set model parameter values")
    
    def update(self, parms):
        "Update the model parameters using the values stored in 'parms'"
        if not isinstance(parms,dict):
            raise TypeError("expected a dictionary argument")
        log = None
        for k in parms:
            if k in self.__params:
                self.__params[k].value = parms[k]
            else:
                if not log: log = logging.getLogger('modeling.Model')
                log.warning("update(): '%s' is not a valid model parameter name"%k)
    
    def _add_params(self, parm):
        """Add one/several new parameter(s) to the model.  This is normally done
        during initialization of the model.
        
        parm is either a ModelParam-derived object or a sequence of ModelParam-
           derived objects.
        """
        try:
            iter(parm)
        except TypeError:
            # parm is not iterable, make it iterable
            parm = (parm,)
        
        # add model parameters to the model
        for p in parm:
            if not isinstance(p,ModelParam):
                raise TypeError("All parameters must be derived from ModelParam")
            if p.name in self.__params:
                raise ValueError("A parameter named '%s' already exists."%p.name)
            self.__params[p.name] = p
    
    def get_params(self, names=None, as_dict=False, only_optimizable=False):
        """Get a list of model parameter objects.
        
        If 'names' (a list/tuple of model parameter names) is specified then
          the result will be filtered to include only the parameters that match
          those in 'names'.
        
        If 'as_dict' is set to True then a dictionary will be returned rather
          than a list.
          
        If 'only_optimizable' is set to True then only parameters that are
          derived from the 'OptimizableParam' type and whose 'optimizable'
          property evaluates to True will be selected.
        """
        log = None
        plst = []
        if isinstance(names,_str_type):
            names = (names,)        
            
        if not names:
            plst = self.__params.values()
        else:
            for n in names:
                if n not in self.__params:
                    if not log: log = logging.getLogger('modeling.Model')
                    log.warning("get_params(): '%s' is not a valid model parameter name"%n)
                    continue
                plst.append(self.__params[n])
        
        if only_optimizable:
            ret = []
            for p in plst:
                if isinstance(p,OptimizableParam) and p.optimizable:
                    ret.append(p)
        else:
            ret = plst
            
        
        if as_dict:
            retd = {}
            for p in ret:
                retd[p.name] = p
            return retd
        
        return ret
    get_named_params = get_params
    
    def get_optimizable_params(self, **kwargs):
        """Get a list of parameters of the model that are optimizable."""
        kwargs['only_optimizable'] = True
        self.get_params(**kwargs)
    
    def __getitem__(self,key):
        """Dictionary-style lookup of model parameters."""
        return self.__params[key]
        
    def __setitem__(self,key,value):
        """Dictionary-style modification of model parameters.
        
        Only model parameters that already exist can be modified in this manner.
        To create new model parameters, the _add_param() method must be used.
        """
        if key not in self.__params:
            raise KeyError("'"+key+"'")
        self.__params[key].setv(value)
        return self.__params[key]
    
    def __iter__(self):
        """Make model objects iterable over their parameter set."""
        return iter(self.__params)
    
    def iter_params(self):
        "iterate ModelParam objects"
        return self.__params.itervalues()
    
    @property
    def param_names(self):
        "return a list of parameter names"
        return self.__params.keys()
        
    
    
class LinearModel(Model):
    """The LinearModel class defines a linear model.  Linear models must be able
    to compute Y-parameters for themselves.
    """
    
    def __init__(self,ext_nodes,params=None):
        """Initialize the model.
        
        ext_nodes is the number of external nodes for the model, an integer
          value greater than 0.
        """
        Model.__init__(self,params)
        n = int(ext_nodes)
        if n < 1:
            raise ValueError("'ext_nodes' must be a positive integer")
        self.__numnodes = n
    
    @property
    def num_nodes(self):
        "the number of external nodes"
        return self.__numnodes
    
    
    def compute_y(self, freq):
        """Compute the Y-parameters of the model.
        freq is the frequency in Hz (a float or a tuple of floats
        
        Returns:
        an NxN numpy array, where N is equal to the number of nodes, or returns
        a list/tuple of arrays in the case where the input freq argument is a tuple.
        """
        raise NotImplementedError
        
        
        
        
