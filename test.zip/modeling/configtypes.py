from __future__ import unicode_literals, absolute_import, division, print_function
"""
Types used by the old-style configuration class ConfigVars

"""
# configuration file data types
CF_DEFAULT = 'string'
CF_STRING = 'string'
CF_FLOAT = 'float'
CF_INT = 'int'
CF_TUPLE = 'tuple'
CF_INTTUPLE = 'inttuple'
CF_FLOATTUPLE = 'floattuple'
