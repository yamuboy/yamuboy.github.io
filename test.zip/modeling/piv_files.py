from __future__ import unicode_literals, absolute_import, division, print_function
import bisect
from copy import deepcopy

class PIV_Datafile(object):
    """reads a pulsed I-V data file and allows re-sorting
    and manipulating of the data
    """
    
    def __init__(self, fname=None):
        "initializer"
        
        if fname:
            self.read_file(fname)
        else:
            self._initvars()
        
        
    def read_file(self, fname):
        "read the file"
        self._initvars()
        self.__filename = fname
        fp = open(fname,'rt',encoding='utf-8')
        try:
            hdone = False
            head = ''
            dat = []
            block = None
            for line in fp:
                if line.startswith('!'):
                    if not hdone:
                        head += line
                elif not line.strip():
                    block = None
                    pass
                else:
                    try:
                        d = list(map(float,line.split()))                        
                        if len(d) != 6:
                            raise ValueError("line must have 6 float values")
                        if block is None:
                            block = []
                            dat.append(block)                            
                        block.append({'vg':d[0],'vd':d[1],'vg_m':d[2],'vd_m':d[3],'id_r':d[4],'id_c':d[5]})
                    except Exception:
                        pass
        
        finally:
            fp.close()
        
        self.__header = head
        self.__data = dat
        
    def _initvars(self):
        "initialize class variables"
        self.__header = ''
        self.__filename = ''
        self.__data = []
        
    def write_file(self, fname):
        "write a containing the pulsed I-V data"
        fp = open(fname,'w')
        fp.write(self.__header)
        for block in self.__data:
            fp.write('\n')
            for b in block:
                fp.write('%g\t%g\t%g\t%g\t%g\t%g\n'%(b['vg'],b['vd'],b['vg_m'],b['vd_m'],b['id_r'],b['id_c']))
        fp.close()
        
    def write_mdif(self, fname):
        "write a generic MDIF containing the pulsed I-V data"
        head = self.__header.split('\n')
        hstop = None
        for i,line in enumerate(head):
            if line.startswith('!-------------'):
                hstop = i
                break
        if hstop:
            header = '\n'.join(head[:hstop])
        else:
            header = '\n'.join(head)
            
        
        fp = open(fname,'w')
        fp.write(header)
        for block in self.__data:
            fp.write('!\nVAR vg(1) = %g\n'%block[0]['vg'])
            fp.write('BEGIN PIVDATA\n')
            fp.write('%\tVd(1)\tVg_meas(1)\tVd_meas(1)\tId_raw(1)\tId_corr(1)\n')
            for b in block:
                fp.write('\t%g\t%g\t%g\t%g\t%g\n'%(b['vd'],b['vg_m'],b['vd_m'],b['id_r'],b['id_c']))            
            fp.write('END\n')
        fp.close()
    
    def clean_data(self, min_gds=-1.0e-3, id_threshold=20.0e-3, vg_threshold=-100.0, vd_threshold=-100.0,
        max_linear_gds=6.0e-3, vd_max=6.0):
        "generate a new object with cleaned data"
        
        # calculate the median gds
        gds_list = []
        for b in self.__data:
            for i in range(1,len(b)):
                gds = (b[i]['id_c'] - b[i-1]['id_c']) / (b[i]['vd_m'] - b[i-1]['vd_m'])
                if gds >= 0.0 and gds <= max_linear_gds:
                    gds_list.append(gds)
        gds_list.sort()
        gds_med = gds_list[len(gds_list)//2]
        
        out = []
        for b1 in self.__data:
            # copy out data to be trimmed
            b = b1[:]
            n = len(b)
            
            # compute gds
            gds = []
            for i in range(1,n):
                gds.append((b[i]['id_c'] - b[i-1]['id_c']) / (b[i]['vd_m'] - b[i-1]['vd_m']))
            gds.insert(0,gds[0])
            
            # find the end of the knee
            knee_end = 1
            for i in range(n):
                if gds[i] < max_linear_gds:
                    knee_end = i
                    break
            
            # find the first value at/beyond the end of the "unstable" region
            unst_end = n-1
            for i in range(n):
                if b[i]['vd'] >= vd_max:
                    unst_end = i
                    break
            
            # first trim by gds values less than min_gds or result in
            # large gds increases beyond the knee
            totrim = []
            for i,g in enumerate(gds):
                if b[i]['vg'] >= vg_threshold and b[i]['vd'] >= vd_threshold and i > knee_end and i < unst_end and b[i]['id_c'] >= id_threshold:
                    if g < min_gds:
                        totrim.append(i)
                        continue
                    
                    # calculate expected ids for this point
                    idexpect = b[knee_end]['id_c'] + b[i]['vd_m']*(b[unst_end]['id_c'] - b[knee_end]['id_c'])/(b[unst_end]['vd_m'] - b[knee_end]['vd_m'])
                    if b[i]['id_c'] < 0.95*idexpect:                    
                        totrim.append(i)
                        
            for j in reversed(totrim):
                del b[j]
        
            out.append(b)
        
        # create and return a copy of this object with the auto-trimmed data
        ret = PIV_Datafile()
        ret.__filename = self.__filename
        ret.__header = self.__header
        ret.__data = out
        
        return ret
    
    def extend_data(self, vd_list=None, vg_max=1.8, gds_linear=1.0e-2, vg_sat=1.3):
        "extend data to make it square for easy import into ADS"
        
        # create a set of vds values if one is not specified
        if not vd_list:
            vd_list = [b['vd'] for b in self.__data[0]]
        
        dat = []
        
        # first pass is to interpolate all curves to a common set of Vds values
        # this will still leave gaps in the data at the high vd values where
        # the power limit has been applied to the test
        for block in self.__data:
            b = []
            dat.append(b)
            for v in vd_list:
                x = self._interp_vds(block,v)
                if not x:
                    break
                b.append(x)
                        
        # second pass is to extend all of the data at the high end
        # of the vd values where the power limit has truncated data
        # during the PIV test
        for i,block in enumerate(dat):
            while len(block) < len(dat[0]):
                block.append(self._extrap_vds(dat,i,len(block)))
        
        # third pass is to extend the gate voltage up beyond vg_max
        gstep = dat[-1][0]['vg'] - dat[-2][0]['vg']
        n = len(dat[0])
        while dat[-1][0]['vg'] < vg_max:
            vg = dat[-1][0]['vg'] + gstep
            i = len(dat)
            b = []
            dat.append(b)
            for j in range(n):
                b.append(self._extrap_vgs(dat,i,j,vg,gds_linear,vg_sat))
        
        ret = PIV_Datafile()
        ret.__filename = self.__filename
        ret.__header = self.__header
        ret.__data = dat
        
        return ret
        
    def copy(self):
        "create a copy"
        r = PIV_Datafile()
        r.__filename = self.__filename
        r.__header = self.__header
        r.__data = deepcopy(self.__data)
        return r
        
    def _interp_vds(self, block, vd):
        "interpolate values at vd for each curve of the I-V data"
        tol = 0.00001
        if vd < block[0]['vd']-tol:
            raise ValueError("cannot extrapolate to Vds = %g"%vd)
            
        for i,b in enumerate(block):
            if abs(vd - b['vd']) <= tol:
                return b
            elif i > 0 and vd <= b['vd'] and vd >= block[i-1]['vd']:
                f = (vd - block[i-1]['vd']) / (b['vd'] - block[i-1]['vd'])
                p = {
                    'vg':block[i-1]['vg'] + f*(b['vg']-block[i-1]['vg']),
                    'vd':vd,
                    'vg_m':block[i-1]['vg_m'] + f*(b['vg_m']-block[i-1]['vg_m']),
                    'vd_m':block[i-1]['vd_m'] + f*(b['vd_m']-block[i-1]['vd_m']),
                    'id_r':block[i-1]['id_r'] + f*(b['id_r']-block[i-1]['id_r']),
                    'id_c':block[i-1]['id_c'] + f*(b['id_c']-block[i-1]['id_c']),
                }
                return p
        
        # calculation requires extrapolation         
        return None
            
        
    def _extrap_vds(self, data, vgidx, vdidx):
        "extrapolate curves in the vds direction by using adjacent gm calculations"
        
        if vdidx < 2:
            raise ValueError("cannot extrapolate any curve with less than 2 points")
        
        gmidx = vgidx
        if vgidx < 1:
            gmidx = 1
        
        # compute the 2 adjacent gm values and average them
        gm1 = (data[gmidx][vdidx-2]['id_c'] - data[gmidx-1][vdidx-2]['id_c']) / (data[gmidx][vdidx-2]['vg_m'] - data[gmidx-1][vdidx-2]['vg_m'])
        gm2 = (data[gmidx][vdidx-1]['id_c'] - data[gmidx-1][vdidx-1]['id_c']) / (data[gmidx][vdidx-1]['vg_m'] - data[gmidx-1][vdidx-1]['vg_m'])
        gm = 0.5*(gm1+gm2)
        
        # average the measured vg
        vg_m = 0.5*(data[vgidx][vdidx-2]['vg_m']+data[vgidx][vdidx-1]['vg_m'])
        # create the baselines for id_r and id_c
        if vgidx < 1:
            vd_m = data[0][vdidx]['vd_m']
            vg_diff = 0.0
            id_r = data[0][vdidx-1]['id_r']
            id_c = data[0][vdidx-1]['id_c']
        else:
            vd_m = data[vgidx-1][vdidx]['vd_m']
            vg_diff = vg_m - data[vgidx-1][vdidx]['vg_m']
            id_r = data[vgidx-1][vdidx]['id_r']
            id_c = data[vgidx-1][vdidx]['id_c']
        
        # compute the data point and append it to the curve
        p = {
            'vg':data[vgidx][vdidx-1]['vg'],
            'vd':data[0][vdidx]['vd'],
            'vg_m':vg_m,
            'vd_m':vd_m,
            # compute the id currents using the gm calculated above
            'id_r':id_r+gm*vg_diff,
            'id_c':id_c+gm*vg_diff,
        }
        return p

    def _extrap_vgs(self, data, vgidx, vdidx, vg, gds_linear, vg_sat):
        "extrapolate vgs beyond the measured values"
        if vgidx < 3:
            raise ValueError("cannot extrapolate with less than 3 curves")
        
        # compute gds
        gdsidx = vdidx
        if vdidx < 1:
            gdsidx = 1
        gds = (data[vgidx-1][gdsidx]['id_c']-data[vgidx-1][gdsidx-1]['id_c']) / (data[vgidx-1][gdsidx]['vd_m']-data[vgidx-1][gdsidx-1]['vd_m'])
        
        if gds < gds_linear and vg < vg_sat:
            # compute gm at the prior 2 curves of the I-V plot
            gm1 = (data[vgidx-2][vdidx]['id_c']-data[vgidx-3][vdidx]['id_c']) / (data[vgidx-2][vdidx]['vg_m']-data[vgidx-3][vdidx]['vg_m'])
            gm2 = (data[vgidx-1][vdidx]['id_c']-data[vgidx-2][vdidx]['id_c']) / (data[vgidx-1][vdidx]['vg_m']-data[vgidx-2][vdidx]['vg_m'])
            smaller_gm = min([gm1,gm2])
            
            # calculate gm slope and extrapolate
            #m = (gm2 - gm1) / (data[vgidx-1][vdidx]['vg_m'] - data[vgidx-2][vdidx]['vg_m'])
            #gm = m*vg
            gm = smaller_gm*0.5
            if gm < 0.0:
                gm = 0.0
        else:
            gm = 0.0
        
        # calculate the data point
        vgdiff = vg - data[vgidx-1][vdidx]['vg']
        p = {
            'vg':vg,
            'vd':data[0][vdidx]['vd'],
            'vg_m':vg,
            'vd_m':data[vgidx-1][vdidx]['vd_m'],
            # compute the id currents using the gm calculated above
            'id_r':data[vgidx-1][vdidx]['id_r']+gm*vgdiff,
            'id_c':data[vgidx-1][vdidx]['id_c']+gm*vgdiff,
        }
        return p
        
    @property
    def _rawdata(self):
        "returns the raw data list - can be modified on the fly"
        return self.__data
    
    @property
    def filename(self):
        "PIV filename"
        return self.__filename
    
    @property
    def header(self):
        "PIV file header"
        return self.__header
        
    
        
        