from __future__ import unicode_literals, absolute_import, division, print_function
"""
default configuration variable specification

"""

def __conf():
    "function to prevent namespace clutter"
    from .config_data import ConfigData
    c = ConfigData()
    
    # add a bunch of default configuration variables
    c.add('__version__', '0.1')
    return c
    
    
    
__c = __conf()