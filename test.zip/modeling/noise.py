from __future__ import unicode_literals, absolute_import, division, print_function
import numpy as np
import math
import network_params

def noise_parameters( y, cy ):
    """compute noise parameters from the Y-matrix and
    admittance form of the noise correlation matrix
    
    y - a numpy.ndarray object of shape 2x2
    cy - admittance form of the noise correlation matrix, a
        numpy.ndarray object of shape 2x2. Must be normalized by
        4*k*T0.
    
    Returns a 3-tuple of (Fmin, Rn, Yopt)
    
    This function can raise math DomainError exceptions if the cy matrix
    contains non-sensical data.
    """
    if not isinstance(y,np.ndarray) or y.shape != (2,2):
        raise TypeError("'y' must be a 2x2 `numpy.ndarray`")
    if not isinstance(cy,np.ndarray) or cy.shape != (2,2):
        raise TypeError("'cy' must be a 2x2 `numpy.ndarray`")
        
    ### Equations/methodology come from "Noise in Linear and Nonlinear Circuits"
    ###  by Stephen Maas, sections 5.2.3 and 5.2.4
    ###
    ### These calculations use Y and Cy directly to compute the noise parameters
    ### without first converting to the chain form of the noise correlation
    ### matrix which saves some steps in the calculation  
    
    # compute Rn
    y21m = abs(y[1,0])
    Rn = cy[1,1].real / (y21m*y21m)
    
    # compute Fmin
    ycor = y[0,0] - (cy[0,1]/cy[1,1])*y[1,0]
    f1 = abs(y[0,0] - ycor)
    gn = cy[0,0].real - f1*f1*Rn
    gcor = ycor.real    
    gsopt = math.sqrt(gn/Rn + gcor*gcor)
    Fmin = 1.0 + 2.0*Rn*(gcor + gsopt)
    
    # compute Yopt
    Yopt = complex(gsopt,-ycor.imag)
    
    return Fmin, Rn, Yopt
    
def noise_parameters_ct( ct, Z0=50.0 ):
    """compute noise parameters from the T-parameter form of
    the noise wave correlation matrix
    
    ct is the noise wave correlation matrix in T-parameter form,
       a 2x2 numpy.ndarray object.  It must be normalized by
       4*k*T0.
    
    Keywords:
    Z0 - system normalizing impedance, MUST be a real value (not complex)
    
    Returns a 3-tuple of (Fmin, Rn, Gamma_opt)
    
    This function can raise math DomainError exceptions if the ct matrix
    contains non-sensical data.
    """
    Ta = ct[0,0].real
    Tb = ct[1,1].real
    Tcm = abs(ct[1,0])
    x = (Ta + Tb)/(2.0*Tcm)
    Gopt = (x - math.sqrt(x*x-1.0))*cmath.exp(complex(0.0,cmath.phase(ct[0,1])))
    Goptm = abs(Gopt)
    Gopta = cmath.phase(Gopt)
    Rn = Z0*Tcm/Goptm*(1.0 + 2.0*Goptm*math.cos(Gopta) + Goptm*Goptm)
    x = Ta+Tb
    Fmin = 1.0 + 2.0*(Ta-Tb) + 2.0*math.sqrt(x*x-4.0*Tcm*Tcm)
    
    return Fmin, Rn, Gopt
    
    
def noise_parameters_cs( cs, Z0=50.0 ):
    """compute noise parameters from the S-parameter form of
    the noise wave correlation matrix
    
    cs is the noise wave correlation matrix in S-parameter form,
       a 2x2 numpy.ndarray object.  It must be normalized by
       4*k*T0.
    
    Keywords:
    Z0 - system normalizing impedance, MUST be a real value (not complex)
    
    Returns a 3-tuple of (Fmin, Rn, Gamma_opt)
    
    This function can raise math DomainError exceptions if the ct matrix
    contains non-sensical data.
    """
    
    raise NotImplementedError
    
    
def noise_figure_cy( y, cy, ys=complex(0.02) ):
    """compute noise figure from the Y-matrix, noise correlation matrix,
    and source admittance
    
    y - Y matrix, a numpy.ndarray object of shape 2x2
    cy - admittance form of the noise correlation matrix, a
        numpy.ndarray object of shape 2x2. Must be normalized by
        4*k*T0.
    ys - (complex) source admittance, default is 0.02 [50 ohm impedance]
    
    returns noise figure in linear units (noise factor)
    """
    if not isinstance(y,np.ndarray) or y.shape != (2,2):
        raise TypeError("'y' must be a 2x2 `numpy.ndarray`")
    if not isinstance(cy,np.ndarray) or cy.shape != (2,2):
        raise TypeError("'cy' must be a 2x2 `numpy.ndarray`")    
    
    ### Equations/methodology come from "Noise in Linear and Nonlinear Circuits"
    ###  by Stephen Maas, sections 5.2.3 and 5.2.4
    ###
    
    # make sure that source admittance is complex
    ysc = complex(ys)
        
    # compute the noise figure
    y21m = abs(y[1,0])
    Rn = cy[1,1].real / (y21m*y21m)
    
    ycor = y[0,0] - (cy[0,1]/cy[1,1])*y[1,0]
    f1 = abs(y[0,0] - ycor)
    gn = cy[0,0].real - f1*f1*Rn
    
    f2 = abs(ysc + ycor)
    F = 1.0 + (1.0/ysc.real)*(gn + Rn*f2*f2)
    
    return F
    
    
    
    
def deembed_nf_and_gain(flist, nfmeas, gmeas, duts, fxa, fxb, gamma=None, kelvin=290.0):
    """deembed measured noise figure and gain to the DUT terminals
    
    flist - tuple/list of frequencies in Hz
    nfmeas - tuple/list of measured noise figure in dB
    gmeas - tuple/list of measured gain in dB
    duts - a `network_params.ParamSet` object of 2-port DUT S-parameters
    fxa - a `network_params.ParamSet` object of the 2-port input fixture
    fxb - a `network_params.ParamSet` object of the 2-port output fixture
    
    Keywords
    -----------------------
    gamma - a `network_params.ParamSet` object of the 1-port input gamma
    kelvin - temperature in Kelvin to use for calculation of noise
        for the passive input and output fixtures
    
    """
    
    if not isinstance(flist,(tuple,list)):
        raise TypeError("'flist' must be a list/tuple object")
    if not isinstance(nfmeas,(tuple,list)):
        raise TypeError("'nfmeas' must be a list/tuple object")
    if not isinstance(gmeas,(tuple,list)):
        raise TypeError("'gmeas' must be a list/tuple object")
        
    if len(flist) != len(nfmeas) or len(nfmeas) != len(gmeas):
        raise ValueError("'flist', 'nfmeas', and 'gmeas' must be the same length")
    
    if fxa:
        if not isinstance(fxa,network_params.ParamSet):
            raise TypeError("'fxa' must be a `network_params.ParamSet` object")
    if fxb:
        if not isinstance(fxb,network_params.ParamSet):
            raise TypeError("'fxb' must be a `network_params.ParamSet` object")
    if gamma:
        if not isinstance(gamma,network_params.ParamSet):
            raise TypeError("'gamma' must be a `network_params.ParamSet` object")
    
    tscal = kelvin/290.0
    ideal = np.matrix([[0.0,complex(1.0)],[complex(1.0),0.0]])
    
    nf, gain, gout = [], [], []
    for i,f in enumerate(flist):
        # get the fixture, DUT, and source S-param data
        if fxa:
            s1 = fxa.extract(f).data
        else:
            s1 = ideal
        s2 = duts.extract(f).data
        if fxb:
            s3 = fxb.extract(f).data
        else:
            s3 = ideal
        if gamma:
            gin = gamma.extract(f).data[0,0]
        else:
            gin = 0.0
        
        # compute gains and reflection coefficients
        gain1 = network_params.ga(s1,gin)
        gm1 = network_params.cascade_refl(s1,gin,True)
        gain2 = network_params.ga(s2,gm1)
        gm2 = network_params.cascade_refl(s2,gm1,True)
        gain3 = network_params.ga(s3,gm2)
        gdmb = gain1*gain3
        if gdmb < 1.0e-3:
            gdmb = 1.0e-3

        # compute noise factors
        f1 = (1.0/gain1 - 1.0)*tscal + 1.0;
        f3 = (1.0/gain3 - 1.0)*tscal + 1.0;
        ftot = 10.0**(nfmeas[i]*0.1)
        # deembed noise
        nfact = 1.0 + gain1*(ftot - f1 - (f3-1.0)/(gain1*gain2))
        if nfact < 1.0e-3:
            nfact = 1.0e-3
        
        gout.append(gm1)
        nf.append(10.0*math.log10(nfact))
        gain.append(gmeas[i]-10.0*math.log10(gdmb))
        
    return nf, gain, gout
    
        
    
