from __future__ import unicode_literals, absolute_import, division, print_function
from .modelparam import ModelParam, FloatParam
from .optimize.param import OptimizableParam
from . import _str_type

class EndFile(object):
    """
    This class deals with reading and writing .end files that have been used
    for a long time with many revisions of modeling software.
    """
    
    def __init__(self, **kwargs):
        """Create a new object that handles .end files.
        
        Keywords:
        fname - if present, then it will be passed along as the 'fname' argument
          to the read() method.  This is a shortcut to create an EndFile
          object and read a .end file in a single step.
        
        """
        # init object properties
        self.__order = []
        self.__data = dict()
        
        # pass keywords to the config method
        self.config(**kwargs)
        
        # if the 'fname' keyword is given, try to read the file
        if 'fname' in kwargs:
            self.read(kwargs['fname'])
        
        
    def config(self, **kwargs):
        """Config Keywords:
        ...
        
        Advanced Use Keywords:
        paramnames - a list of parameter names that is used to set the parameters
          that will be written to the .end file.  Specifying this keyword will
          OVERWRITE ALL STORED INFORMATION about parameters.
          This is normally only used when a .end file needs to be
          written without first reading a .end file.  All parameters are
          initialized to the value of 0.0 with min and max values of 0.0.
          The order of the parameters will be taken from the order of them in
          the paramnames list.
        write_case - force the case of the parameter names that are to be written
          to the .end file.  Valid values here are 'upper', 'lower', and 'title'
        
        """
        # process the paramnames keyword first, since other keywords may affect
        # parameter names stored in the object
        if 'paramnames' in kwargs:
            # erase all stored information
            self.__data = dict()
            self.__order = []
            # push new parameters
            for p in kwargs['paramnames']:
                if not isinstance(p,_str_type):
                    raise TypeError("'paramnames' must be an iterable of strings.")
                pl = p.lower()
                if pl in self.__data:
                    raise ValueError("'%s' exists more than once in 'paramnames'"%p)
                self.__data[pl] = (p,0.0,0.0,0.0)
                self.__order.append(pl)
                
        if 'write_case' in kwargs:
            wc = kwargs['write_case']
            if not wc in ('upper','lower','title'):
                raise ValueError("Invalid value for 'write_case'")
            for pl in self.__data.keys():
                if wc == 'upper': pc = pl.upper()
                elif wc == 'lower': pc = pl
                elif wc == 'title': pc = pl.title()
                # see if the specified case matches what is currently stored
                if self.__data[pl][0] != pc:
                    # need to change the stored parameter case
                    # since it is tuple and can't be modified
                    # it must be recreated
                    dat = [pc]
                    dat.extend(self.__data[pl][1:])
                    self.__data[pl] = tuple(dat)
        
    def read(self, fname, **kwargs):
        """Read a .end file
        
        fname is either a string specifying the filename to open and read
          the .end file data from, or it can be any iterable object that 
          returns strings (lines of data from the "file").
          
        """
        if len(kwargs):
            self.config(**kwargs)
        
        autoclose=False
        if isinstance(fname,_str_type):
            f = open(fname, 'r')
            autoclose=True
        else:
            # assume that this is an already opened iterable object
            f = fname
        
        # erase stored parameter data
        self.__order = []
        self.__data = dict()
        # read in the data from the file
        try:
            for line in f:
                data = line.split()
                if len(data) == 5:
                    try:
                        mn = float(data[0])
                        val = float(data[1])
                        mx = float(data[2])
                        name = data[4]
                    except ValueError:
                        continue
                    
                    pl = name.lower()
                    if pl in self.__data:
                        raise ValueError("'%s' appears more than once in the file."%name)
                    self.__order.append(pl)
                    self.__data[pl] = (name,mn,val,mx)
        finally:
            if autoclose: f.close()
    read.__doc__ += config.__doc__
        
    def write(self, fname, **kwargs):
        """Write a .end file
        
        fname is either a string specifying the filename to open and write
          the .end file data to, or it can be any file-like object that has
          a method named write() which takes a string parameter.
        
        """
        if len(kwargs):
            self.config(**kwargs)
        
        autoclose=False
        if isinstance(fname,_str_type):
            f = open(fname,'w')
            autoclose=True
        else:
            # assume that this is an already opened file-like object
            f = fname
        
        try:
            for pl in self.__order:
                p = self.__data[pl]
                f.write("%13.4e%13.4e%13.4e%13.4e %s\n"%(p[1],p[2],p[3],0.0,p[0]))
        finally:
            if autoclose: f.close()
    write.__doc__ += config.__doc__
        
    def update_model(self, model, **kwargs):
        """Update a model using the values of parameters stored in this object.
        
        The parameters are iterated over, and those than can be mapped to
        .end file parameters stored here are updated. Mappings are always
        computed by comparing the lowercase model parameter name to the
        lowercase .end file parameter name, except when a 'map' is specified
        (see the documentation on the 'map' keyword below).
        
        The model parameters that map to .end file parameters must be either
        FloatParam or OptimizableParam objects.
        
        Keywords:
        map - a mapping object that performs parameter name translation between
          the model parameter names and the .end file parameter names.  This can
          be one of two possible object types:
           - it can be a dictionary in which the keys are the names of the model
           parameters (in lower case) and the values are the names of the .end
           file parameters
           - it can be a callable object that will be called with a single
           parameter, the model parameter name (in lower case), and must return
           the .end file parameter name
        
        """
        m = kwargs.get('map',None)
        
        for mpn in model.params.keys():
            p = model[mpn]
            mpnl = p.name.lower()
            
            if m:
                # perform parameter name mapping
                if callable(m):
                    # the mapping is a callable object
                    epnl = m(mpnl).lower()
                else:
                    # assume the mapping is a dictionary
                    if mpnl in m:
                        epnl = m[mpnl].lower()
                    else:
                        epnl = mpnl
            else:
                # direct mapping
                epnl = mpnl
            
            # see if a match exists
            if epnl in self.__data:
                d = self.__data[epnl]
                # verify that the model parameter type is valid
                if not isinstance(p,FloatParam):
                    raise TypeError("'%s' is not a floating-point model parameter."%p.name)
                
                # update the model parameter
                p.setv(d[2])
                if isinstance(p,OptimizableParam):
                    p.set_opt_range(d[1],d[3])
        
    def update(self, params, **kwargs):
        """Update the values of the parameters stored in this object.
        
        params is some sort of iterable containing FloatParam or OptimizableParam
        objects.
        
        This is normally called just prior to writing a .end file.
        
        The params are iterated over, and those than can be mapped to
        .end file parameters stored here are updated. Mappings are always
        computed by comparing the lowercase name porperty of the param to the
        lowercase .end file parameter name, except when a 'map' is specified
        (see the documentation on the 'map' keyword below).
        
        The only params that will be considered are FloatParam or
        OptimizableParam objects since they are the only types that can be
        stored in the .end file format.  If the model has a parameter that
        is not one of these types that maps to a .end file parameter, then an
        exception will be raised as this is assumed to be a major problem.
        
        If a parameter is a FloatParam or an OptimizableParam in which
        the optimization limits have not been set then the min and max that are
        updated here are set to be equal to the parameter value.
        
        Keywords:
        map - a mapping object that performs parameter name translation between
          the param names and the .end file parameter names.  This can
          be one of two possible object types:
           - it can be a dictionary in which the keys are the names of the
           params (in lower case) and the values are the names of the .end
           file parameters (in lower case)
           - it can be a callable object that will be called with a single
           parameter, the param's name (in lower case), and must return
           the .end file parameter name (in lower case)
        """
        m = kwargs.get('map',None)
        
        for mp in params:
            if not isinstance(mp,ModelParam):
                # params must be a dictionary
                p = params[mp]
            else:
                p = mp
            mpnl = p.name.lower()
            
            if m:
                # perform parameter name mapping
                if callable(m):
                    # the mapping is a callable object
                    epnl = m(mpnl).lower()
                else:
                    # assume the mapping is a dictionary
                    if mpnl in m:
                        epnl = m[mpnl].lower()
                    else:
                        epnl = mpnl
            else:
                # direct mapping
                epnl = mpnl
            
            # see if a match exists
            if epnl in self.__data:
                d = self.__data[epnl]
                # verify that the model parameter type is valid
                if not isinstance(p,FloatParam):
                    raise TypeError("'%s' is not a floating-point parameter."%p.name)
                
                # update the internally stored data
                val = p.v
                if isinstance(p,OptimizableParam):
                    mn,mx = p.optlimits
                else:
                    mn,mx = val,val
                d = [self.__data[epnl][0]]
                d.extend( [mn,val,mx] )
                self.__data[epnl] = tuple(d)


