from __future__ import unicode_literals, absolute_import, division, print_function
import random, time, os, os.path
try:
    import threading as _thread
except ImportError:
    import dummy_threading as _thread

from . import _number_types, _str_type
    
class _CacheData:
    "simple object to hold cache data"
    
    def __init__(self, data=None, expires=None):
        "initializer"
        self.data = data
        self.hits = 1
        if isinstance(expires,_number_types):
            self.tstamp = float(expires)
        else:
            self.tstamp = None
    
    @property
    def expired(self):
        if not isinstance(self.tstamp,_number_types):
            return False
        elif self.tstamp < time.time():
            return True
        return False
    
class CacheBackend(object):
    """
    A backend implementation for a cache.
    
    """
    
    def __init__(self, prefix=None):
        "initializer"
        if prefix is not None:
            if not isinstance(prefix,_str_type):
                raise TypeError("'prefix' must be a string")
            self._prefix = prefix
        else:
            self._prefix = ''
        self._write_lock = _thread.RLock()
    
    def get(self, key, disable_prefix=False):
        "get a cache key, raises KeyError for keys that don't exist"
        if hasattr(self,'_get') and callable(self._get):
            if disable_prefix:
                v = self._get(key)
            else:
                v = self._get(self._prefix+key)
            v.hits += 1
            return v.data
        else:
            raise NotImplementedError
    
    def set(self, key, value, expires, overwrite, disable_prefix=False):
        "set a cache key, raises KeyError for existing keys when overwrite is set to False"
        if hasattr(self,'_set') and callable(self._set):
            if not overwrite and self.check(key):
                raise KeyError("'{}' exists and cannot be overwritten".format(key))
            self._write_lock.acquire()
            try:
                # lock the cache during write operations
                if disable_prefix:
                    self._set(key,_CacheData(value,expires))
                else:
                    self._set(self._prefix+key,_CacheData(value,expires))
            finally:
                self._write_lock.release()
        else:
            raise NotImplementedError
        
    def delete(self, key, disable_prefix=False):
        "delete a cache key, raises KeyError for keys that don't exist"
        if hasattr(self,'_delete') and callable(self._delete):
            self._write_lock.acquire()
            try:
                # lock the cache during delete operations
                if disable_prefix:
                    self._delete(key)
                else:
                    self._delete(self._prefix+key)
            finally:
                self._write_lock.release()                
        else:
            raise NotImplementedError
        
    def purge(self, scope='expired', prefix=None):
        "purge the cache"
        if scope not in ('all','expired','prefix'):
            raise ValueError("invalid 'scope'")
            
        if scope == 'all':
            if hasattr(self,'purge_all') and callable(self.purge_all):
                # backend defines a purge_all method
                self.purge_all()
            else:
                # manual purge of all keys
                for k in self.keys():
                    try:
                        self.delete(k,disable_prefix=True)
                    except KeyError:
                        pass
        elif scope == 'expired':
            if hasattr(self,'purge_expired') and callable(self.purge_expired):
                # backend defines a purge_expired method
                self.purge_expired()
            else:
                # manual purge of expired keys
                for k in self.keys():
                    try:
                        v = self.get(k,disable_prefix=True)
                        if v.expired:
                            self.delete(k,disable_prefix=True)
                    except KeyError:
                        pass
        elif scope == 'prefix':
            if not isinstance(prefix,_str_type):
                raise ValueError("invalid 'prefix' specified")
            if hasattr(self,'purge_prefix') and callable(self.purge_prefix):
                # backend defines a purge_expired method
                self.purge_prefix(prefix)
            else:
                # manual purge of keys with the specified prefix
                for k in self.keys():
                    try:
                        if k.startswith(prefix):
                            self.delete(k,disable_prefix=True)
                    except KeyError:
                        pass
            
    def check(self, key):
        "check for the presence of a key"
        try:
            v = self.get(key)
            if v.expired:
                self.delete(key)
                return False
            return True        
        except KeyError:
            pass
        return False
        
    def keys(self):
        "return an iterator of the raw cache keys"
        raise NotImplementedError
        
class MemoryCacheBackend(CacheBackend):
    """
    Memory-backed cache engine.
    
    
    """
    __common_cache = dict()

    def __init__(self, **kwargs):
        "initializer"
        # use the cache dictionary from the common cache
        # this way all objects share the same cache
        self.__cache = self.__common_cache
        
        # call the parent initializer
        super(MemoryCacheBackend,self).__init__(**kwargs)
        
    def purge_all(self):
        "purge all cached data"
        self._write_lock.acquire()
        try:
            self.__cache.clear()
        finally:
            self._write_lock.release()
    
    def purge_expired(self):
        "purge expired cached data"
        now = time.time()
        self._write_lock.acquire()
        try:
            todel = []
            for k in self.__cache:
                v = self.__cache[k]
                if v.tstamp < now:
                    todel.append(k)
            for k in todel:
                del self.__cache[k]
        finally:
            self._write_lock.release()

    def purge_prefix(self, prefix):
        "purge all data with a given prefix from the cache"
        self._write_lock.acquire()
        try:
            todel = []
            for k in self.__cache:
                if k.startswith(prefix):
                    todel.append(k)
            for k in todel:
                del self.__cache[k]        
        finally:
            self._write_lock.release()
      
    def _get(self, key):
        "get a raw key value (prefix has already been prepended)"
        try:
            return self.__cache[key]
        except Exception:
            raise KeyError(key)
    
    def _set(self, key, cachedata):
        "set a raw key value (prefix has already been prepended)"
        try:
            self.__cache[key] = cachedata
        except Exception:
            raise KeyError(key)
        
    def _delete(self, key):
        "delete a raw key value (prefix has already been prepended)"
        try:
            del self.__cache[key]
        except Exception:
            raise KeyError(key)        
        
    def keys(self): 
        "return an iterator of the raw cache keys"
        return iter(self.__cache)

        
class Cache(object):
    """A generic caching engine for storing data."""
    
    def __init__(self, prefix=None, backend=MemoryCacheBackend):
        "initializer"
        if not issubclass(backend,CacheBackend):
            raise TypeError("'backend' must be a subclass of 'CacheBackend'")
        self.__backend = backend(prefix=prefix)
        
    def get(self, key):
        "get a cached object given a key"
        try:
            return self.__backend.get(key)
        except KeyError:
            return None
        
    def set(self, key, value, expires=None, overwrite=True):
        """set a key/value pair in the cache
        
        expires is the number of seconds in the future that the object should expire
           and no longer be valid in the cache (defaults to None = no expiry of data)
        overwrite is a flag indicting whether existing keys in the cache should be
           overwritten (defaults to True)
        """
        # compute the absolute expires parameter
        abs_expires = None
        if isinstance(expires,(int,float)):
            abs_expires = int(time.time()+expires)
        self.__backend.set(key,value,abs_expires,overwrite)
            
    def delete(self, key):
        "delete the key if it exists"
        try:
            self.__backend.delete(key)
        except Exception:
            pass
        
    def purge(self):
        "purge all items from the cache"
        self.__backend.purge('all')
        
    def purge_expired(self):
        "purge expired items from the cache"
        self.__backend.purge('expired')

    def purge_prefix(self, prefix):
        "purge cache items by prefix"
        self.__backend.purge('prefix',prefix)
        
    def __getitem__(self, key):
        "dictionary-style property access"
        return self.__backend.get(key)
        
    def __setitem__(self, key, value):
        "dictionary-style property access"
        self.set(key,value)
    
    def __delitem__(self, key):
        "dictionary-style property access"
        self.__backend.delete(key)
        
    
    
class FileCache(Cache):
    """
    A cache for data files.
    
    For the get/set/delete methods, a file path is provided instead of a cache key.
    This path must point to a real file on the disk. The modified timestamp of the
    file will be examined whenever get() is called and compared against the modified
    timestamp that was cached during the set() method.  If the file has changed, then
    the key will be deleted and None will be returned, an indication that the cached
    data is no longer valid and must be regenerated.
    """
        
    def __init__(self, **kwargs):
        "initialize"
        if 'prefix' not in kwargs:
            kwargs['prefix'] = 'filecache_'
        super(FileCache,self).__init__(**kwargs)
    
    def get(self, fpath):
        "get file data from the cache"
        # get the absolute path name of the file
        k = self._getabsfpath(fpath)
        # verify existance of the file on disk
        try:
            st = os.stat(k)
        except IOError:
            # file not found, delete cached copy (if it exists)
            super(FileCache,self).delete(k)
            return None
        
        # get the cached copy (if it exists)
        try:
            ts, data = super(FileCache,self).get(k)
        except Exception:
            # not in the cache
            return None
            
        if ts >= int(st.st_mtime):
            return data
        else:
            # data is expired
            super(FileCache,self).delete(k)            
            return None

    def set(self, fpath, data, expires=None, overwrite=True):
        """set a key/value pair in the cache
        
        expires is the number of seconds in the future that the object should expire
           and no longer be valid in the cache (defaults to None = no expiry of data)
        overwrite is a flag indicting whether existing keys in the cache should be
           overwritten (defaults to True)
        """
        # get the absolute path name of the file
        k = self._getabsfpath(fpath)
        # get the modified timestamp of the file
        try:
            st = os.stat(k)
        except IOError:
            # file not found, fail silently
            return
        
        # store the data in the cache
        super(FileCache,self).set(k,(int(st.st_mtime),data),expires,overwrite)
            
    def delete(self, fpath):
        "delete the key if it exists"
        super(FileCache,self).delete(self._getabsfpath(fpath))
        
    def _getabsfpath(self, fpath):
        "convert a filename to a non-aliased absolute file name"
        return os.path.abspath(os.path.realpath(fpath))
        
    def __getitem__(self, key):
        "dictionary-style property access"
        return self.get(key)
        
    def __setitem__(self, key, value):
        "dictionary-style property access"
        self.set(key,value)
    
    def __delitem__(self, key):
        "dictionary-style property access"
        self.delete(key)
        