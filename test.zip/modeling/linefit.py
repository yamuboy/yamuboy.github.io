from __future__ import unicode_literals, absolute_import, division, print_function

def linefit_mxb( x, y ):
    """Compute the slope and intercept of the linear fit of a set of x and y data."""
    
    try:
        iter(x)
        iter(y)
    except:
        raise TypeError('The inputs must be iterable containers.')
    
    n = len(x)
    if n < 2:
        raise ValueError('The input data must have a length >= 2.')
    elif n != len(y):
        raise ValueError('The inputs must have the same length.')
    
    xsum, ysum = 0., 0.
    xxsum, yysum, xysum = 0., 0., 0.
    for i in range(n):
        xsum  += x[i]
        ysum  += y[i]
        xxsum += x[i]*x[i]
        yysum += y[i]*y[i]
        xysum += x[i]*y[i]
        
    m  = (xysum*n - xsum*ysum) / (xxsum*n - xsum*xsum)
    ymean = ysum / n
    b  = ymean - m * xsum / n
    
    # compute R^2
    err = 0.
    tot = 0.
    for i in range(n):
        t = m*x[i] + b - y[i]
        err += t * t
        t = y[i] - ymean
        tot += t * t
    r2 = 1. - err/tot
    
    return m, b, r2
