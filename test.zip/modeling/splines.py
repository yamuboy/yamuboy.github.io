from __future__ import unicode_literals, absolute_import, division, print_function
import numpy as np
import bisect

def natural_cubic_spline(x,y):
    """Compute the coefficients of the natural cubic spline of x and y. A
    natural cubic spline is one such that the second derivative of the spline
    at the points x[0] and x[-1] is equal to 0.
    
    - x and y should be iterable containers of values (list, tuple)
    - x must be an increasing function such that:
        x[i-1] < x[i] < x[i+1]
    - x and y must be the same length
    - the length of x and y must be greater than 2
    
    This algorithm is based on the one found here:
    http://en.wikipedia.org/wiki/Spline_%28mathematics%29
    with some modifications.  The primary changes are that the a[i] terms
    are replaced by y[i] since a[i] == y[i], and the computational efficiency
    of this algorithm is somewhat improved over the basic procedure found
    on Wikipedia.
    
    The computed cubic spline consists of a piecewise series of len(x)-1
    cubic functions where each function f[i] covers the interval from 
    x[i] to x[i+1].  The function f[i] is defined as follows:
    
    f[i] = a[i] + b[i]*xv[i] + c[i]*xv[i]*xv[i] + d[i]*xv[i]*xv[i]*xv[i]
      where: xv[i] = x - x[i]
      and a[i], b[i], c[i], and d[i] are the computed spline coefficients
        for the interval
    """
    # check the input sequences
    if isinstance(x,np.ndarray):
        if x.ndim > 1:
            raise TypeError("splines are only supported for single-dimentional data")
    
    if isinstance(y,np.ndarray):
        if y.ndim > 1:
            raise TypeError("splines are only supported for single-dimentional data")
    
    n = len(x)
    if n < 3:
        raise ValueError("the length of the input sequences must be greater than 2")
    elif n != len(y):
        raise ValueError("the input sequences must have the same length")
    
    nm1 =  n-1
    
    # compute the intervals, h, between the knots
    h = np.zeros(nm1)
    for i in range(nm1):
        h[i] = x[i+1] - x[i]
        if h[i] <= 0.0:
            raise ValueError("the x coordinate input sequence must be continually increasing")
    
    # compute intermediate values used in the calculation of the 'c' coefficients
    u = np.zeros(nm1)
    z = np.zeros(nm1)
    for i in range(1,nm1):
        alphai = 3.0/h[i]*(y[i+1]-y[i]) - 3.0/h[i-1]*(y[i]-y[i-1])
        li = 2.0*(x[i+1]-x[i-1]) - h[i-1]*u[i-1]
        u[i] = h[i]/li
        z[i] = (alphai - h[i-1]*z[i-1])/li
    
    # compute the 'c' coefficients
    c = np.zeros(n)
    for i in reversed(range(nm1)):
        c[i] = z[i] - u[i]*c[i+1]
    
    # compute the 'b' and 'd' coefficients and fill in the coefficients list
    coeffs = []
    for i in range(nm1):
        b = (y[i+1]-y[i])/h[i] - h[i]*(c[i+1]+2.0*c[i])/3.0
        d = (c[i+1]-c[i])/(3.0*h[i])
        coeffs.append( (b,c[i],d) ) 
    
    # return the original x and y arrays plus the computed spline coefficients
    # as a tuple of lists, the y values are used for the 'a' coefficients in
    # the spline since y[i] == a[i]
    return x,y,coeffs
    
def cubic_spline_solve( spline, x0 ):
    """Solve a computed cubic spline at a particular x value."""
    if not isinstance(spline,tuple) or len(spline) != 3:
        raise TypeError("'spline' input should be a 3-tuple")
    
    eps = 1.0e-13
    x, y, coeffs = spline
    i =  bisect.bisect_left(x,x0)
    if i == 0:
        if x0 < (x[0] - eps):
            raise ValueError("Spline low-side extrapolation error.")
        return y[0]
    elif i == len(x):
        # check for numerical precision errors
        if x0 > (x[-1] + eps):
            raise ValueError("Spline high-side extrapolation error.")
        return y[-1]
    
    if x0 == x[i]:
        # exact match case, no need to compute spline
        return y[i]
    
    # compute the spline, because of the use of the bisect function the
    # i index is set 1 higher than the value we need, so use i-1
    im1 = i-1
    xv = x0 - x[im1]
    b, c, d = coeffs[im1]
    return y[im1] + b*xv + c*xv*xv + d*xv*xv*xv
    
