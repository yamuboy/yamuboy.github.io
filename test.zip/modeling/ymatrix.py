from __future__ import unicode_literals, absolute_import, division, print_function
import numpy as np

# reduce the Y-matrix of a circuit definition that includes internal nodes
def reduce(y, ext_nodes):
    """Reduce the Y-mtrix to remove all internal nodes
    
    y - the Y-parameter matrix, an NxN numpy.ndarray object of complex numbers
    ext_nodes - a list/tuple of external node indices
    """
    
    if not isinstance(y,np.ndarray):
        raise TypeError("Y-matrix must be a numpy.ndarray object")
    elif y.ndim != 2 or y.shape[0] != y.shape[1]:
        raise TypeError("Y-matrix must be a 2-dimensional square array")
        
    if not isinstance(ext_nodes,(tuple,list)) or not len(ext_nodes):
        raise TypeError("'ext_nodes' must be a non-empty list of external nodes")
    
    # create a copy of the original object
    a = y.copy()
    
    # create a set of nodes to reduce
    N = a.shape[0]
    rows = list(range(N))
    for n in ext_nodes:
        if n not in rows:
            raise ValueError("'ext_nodes' node number '%s' is not valid"%n)
        del rows[rows.index(n)]
    rset = set(rows)
    cset = set(rows)
    
    ##### start the reduction loop #####
    while len(rset):
        # find the largest value in the Y-matrix in the entries that have not been reduced yet
        # this is need in order to implement full pivoting for the best numerical performance
        # of the reduction algorithm
        largest = 1.0e-15
        rt, ct = -1, -1
        for i in rset:
            for j in cset:
                x = abs(a[i,j])
                if x > largest:
                    rt, ct = i, j
                    largest = x
        
        if rt < 0:
            raise ValueError("matrix is singular")
        
        # perform the reduction by eliminating the row/col of the largest entry
        #
        # reduction of the partitioned matrix Y is according to the equations:
        #       [ A | B ]
        #   Y = [---|---]    size: NxN
        #       [ C | D ]
        #
        #   Y(reduced) = A - B*(D^-1)*C     size: (N-1)x(N-1)
        #
        #     where the size of A is (N-1)x(N-1), B is (N-1)x1, C is 1x(N-1), and D is 1x1
        #
        den = 1.0 / a[rt,ct]
        for i in rset.union(ext_nodes):
            if i == rt:
                continue
            sf = a[i,ct]*den
            for j in cset.union(ext_nodes):
                if j == ct:
                    continue
                a[i,j] -= a[rt,j]*sf
        
        # remove the reduced row and column from their respective sets
        rset.remove(rt)
        cset.remove(ct)
    
    # create and return the reduced matrix
    return a[ext_nodes,][:,ext_nodes]

    
# simultaneous reduction of the Y-matrix and noice correlation matrix (admittance form)
# of a circuit definition that includes internal nodes
def reduce_w_cy(y, cy, ext_nodes):
    """Reduce the Y-matrix to remove all internal nodes and simultaneously
    reduce the corresponding noise correlatation matrix
    
    y - the Y-parameter matrix, an NxN numpy.ndarray of complex numbers
    cy - the noise correlation matrix, an NxN numpy.ndarray of complex numbers
    ext_nodes - a list/tuple of external node indices
    """
    
    if not isinstance(y,np.ndarray):
        raise TypeError("Y-matrix must be a numpy.ndarray object")
    elif y.ndim != 2 or y.shape[0] != y.shape[1]:
        raise TypeError("Y-matrix must be a 2-dimensional square array")
        
    if not isinstance(cy,np.ndarray):
        raise TypeError("noise correlation matrix must be a numpy.ndarray object")
    elif cy.ndim != 2 or cy.shape[0] != cy.shape[1] or cy.shape[0] != y.shape[0]:
        raise TypeError("noise correlation matrix must be the same size as the Y-matrix")
        
    if not isinstance(ext_nodes,(tuple,list)) or not len(ext_nodes):
        raise TypeError("'ext_nodes' must be a non-empty list of external nodes")
    
    # create a copies of the original objects
    a = y.copy()
    b = cy.copy()
    
    # create a set of nodes to reduce
    N = a.shape[0]
    rows = list(range(N))
    for n in ext_nodes:
        if n not in rows:
            raise ValueError("'ext_nodes' node number '%s' is not valid"%n)
        del rows[rows.index(n)]
    rset = set(rows)
    cset = set(rows)
    
    ##### start the reduction loop #####
    while len(rset):
        # find the largest value in the Y-matrix in the entries that have not been reduced yet
        # this is need in order to implement full pivoting for the best numerical performance
        # of the reduction algorithm
        largest = 1.0e-15
        rt, ct = -1, -1
        for i in rset:
            for j in cset:
                x = abs(a[i,j])
                if x > largest:
                    rt, ct = i, j
                    largest = x
        
        if rt < 0:
            raise ValueError("matrix is singular")
        
        # perform the reduction by eliminating the row/col of the largest entry
        #
        # reduction of the partitioned matrix Y is according to the equations:
        #       [ A | B ]
        #   Y = [---|---]    size: NxN
        #       [ C | D ]
        #
        #   Y(reduced) = A - B*(D^-1)*C     size: (N-1)x(N-1)
        #
        #     where the size of A is (N-1)x(N-1), B is (N-1)x1, C is 1x(N-1), and D is 1x1
        #
        # reduction of the partitioned noise correlation matrix is according to:
        #
        #        [ CA | CB ]
        #   Cy = [----|----]    size: NxN
        #        [ CC | CD ]
        #
        #   Cy(reduced) = CA - B*(D^-1)*CC - CB*H[B*(D^-1)] + B*(D^-1)*CD*H[B*(D^-1)]
        #           size: (N-1)x(N-1)
        #
        #     where CA, CB, CC, and CD have the same sizes as their counterparts in
        #     the Y matrix and the `H[...]` notation is designating the Hermetian 
        #     (conjugate transpose) operator
        #
        den = 1.0 / a[rt,ct]
        for i in rset.union(ext_nodes):
            if i == rt:
                continue
            sf = a[i,ct]*den
            for j in cset.union(ext_nodes):
                if j != ct:
                    a[i,j] -= a[rt,j]*sf
                if j != rt:
                    sf2 = a[j,ct].conj()*den.conj()
                    b[i,j] += -b[rt,j]*sf - b[i,rt]*sf2 + b[rt,rt]*sf*sf2
        
        # remove the reduced row and column from their respective sets
        rset.remove(rt)
        cset.remove(ct)
    
    # create and return the reduced matrices
    return a[ext_nodes,][:,ext_nodes], b[ext_nodes,][:,ext_nodes]

    
    
    
    
    
    