"""Simple GPIB interface library based on the "traditional" interface
to the National Instruments IEEE 488.2 library.

This module contains the higher level device/board interface
classes.  These are what most code would use to interface with
GPIB devices and boards.

TODO: add some more capability to the Board class to be able to
handle cases where the board is being used as a talker/listener
rather than a system controller.

Author: Jay Barrett
"""
from __future__ import division, print_function, unicode_literals, absolute_import
from .library import GpibLib
from .constants import *
import time

DEFAULT_EOSMODE = ord(b'\n')
DEFAULT_MAX_BYTES = 262144    

class GpibBase(object):
    "base class for GPIB Board and Device objects"
    
    def __init__(self, board_index, **kwargs):
        "initializer"        
        # open the library
        self.lib = GpibLib()
        # make sure board_index is an integer
        board_index = int(board_index)
        if board_index < 0:
            raise ValueError("'board_index' must be >= 0")
        
        # open the device descriptor and store the
        # EOS character
        self._ud = self._create_ud(board_index,**kwargs)
        self._eoschar = bytes(bytearray([self.get_config(CONFIG.EOSchar)]))
    
    def _create_ud(self, board_index, **kwargs):
        "create the unit descriptor (must be defined in sub classes)"
        raise NotImplementedError
        
    def get_config(self, cfgid):
        "get GPIB software configuration parameters"
        if cfgid not in VALID_CONFIG_IDS:
            raise ValueError("invalid configuration parameter ID")
        return self.lib.ibask(self._ud,cfgid)
    
    def set_config(self, cfgid, value):
        "set GPIB software configuration parameters"
        if cfgid not in VALID_CONFIG_IDS:
            raise ValueError("invalid configuration parameter ID")
        value = int(value)
        self.lib.ibconfig(self._ud,cfgid,value)
    
    def local(self):
        "tell the board/device to go to local"
        self.lib.ibloc(self._ud)

    def write_raw(self, cmd):
        "write raw data"
        self.lib.ibwrt(self._ud,cmd)
        
    def write(self, cmd, encoding='utf-8'):
        "write data, appending the eos character if needed"
        if self._eoschar != b'\x00' and cmd[-1:] != self._eoschar:
            self.write_raw(cmd.encode(encoding)+self._eoschar)
        else:
            self.write_raw(cmd.encode(encoding))            
    
    def read_raw(self, max_bytes=DEFAULT_MAX_BYTES):
        "read raw data"
        return self.lib.ibrd(self._ud,max_bytes)
    
    def read(self, max_bytes=DEFAULT_MAX_BYTES):
        "read data, stripping the eos character"
        r = self.read_raw(max_bytes)
        if self._eoschar != b'\x00' and r[-1:] == self._eoschar:
            return r[:-1]
        else:
            return r
    
    def query(self, cmd, delay_ms=0, max_read_bytes=DEFAULT_MAX_BYTES):
        "combine a write and read"
        self.write(cmd)
        if delay_ms > 0:
            now = time.time()
            target = now + delay_ms*0.001
            while now < target:
                delta = target - now
                if delta < 0.001:
                    break
                time.sleep(delta)
                now = time.time()
        return self.read(max_read_bytes)
    ask = query
    
    def set_eoi(self, flag):
        "enable/disable EOI on last byte"
        self.lib.ibeot(self._ud,bool(flag))
        
    def set_eos(self, v):
        "set the EOS byte and mode"
        self.lib.ibeos(self._ud,int(v)&EOSMASK)
        self._eoschar = bytes(bytearray([self.get_config(CONFIG.EOSchar)]))
    
    def reset(self):
        "reset the interface parameters"
        self.lib.ibonl(self._ud,1)
        self._eoschar = bytes(bytearray([self.get_config(CONFIG.EOSchar)]))
        
    @property
    def ud(self):
        "unit descriptor"
        return self._ud
        
    @property
    def timeout(self):
        "device timeout, one of the Txxx constants (an integer 0-17)"
        return self.lib.ibask(self._ud,CONFIG.TMO)
    
    @timeout.setter
    def timeout(self, v):
        v = int(v)
        if v < 0 or v > 17:
            raise ValueError("invalid timeout - must be an integer in the range 0-17")
        self.lib.ibtmo(self._ud,v)

    @property
    def eoschar(self):
        "end-of-string (EOS) character"
        return self._eoschar
        
        
class Board(GpibBase):
    "GPIB interface board"
    
    def __init__(self, board_index, timeout=T10s, send_eoi=True, eosmode=0):
        "initializer"
        super(Board,self).__init__(board_index,timo=timeout,eoi=send_eoi,eos=eosmode)
    
    def _create_ud(self, board_index, **kwargs):
        "create the unit descriptor"
        # open the board using ibfind
        ud = self.lib.ibfind('gpib{0}'.format(board_index))
        # set timeout, EOI, and EOS mode if they are in
        # the keywords
        if 'timo' in kwargs:
            v = int(kwargs.pop('timo'))
            if v < 0 or v > 17:
                raise ValueError("'timo' must be an integer in the range 0-17".format(NO_SAD,ALL_SAD))
            self.lib.ibtmo(ud,v)
        if 'eoi' in kwargs:
            self.lib.ibeot(ud,bool(kwargs.pop('eoi')))
        if 'eos' in kwargs:
            v = int(kwargs.pop('eos')) & EOSMASK
            self.lib.ibeos(ud,v)
        
        if len(kwargs):
            raise ValueError("invalid keyword arguments: {0}".format(', '.join(kwargs)))
        
        return ud
        
    def clear(self):
        "send an interface clear"
        self.lib.ibsic(self._ud)        
        
    def command(self, data):
        "send a binary string of command bytes to the interface board"
        if not isinstance(data,bytes):
            raise TypeError("data must be a `bytes` object")
        self.lib.ibcmd(self._ud,data) 
        
    def check_listener(self, pad, sad=NO_SAD):
        "check for a listener at the specified address"
        return bool(self.lib.ibln(self._ud,pad,sad))
    
    def find_listeners(self, scan_sad=False):
        "find listeners on the bus"
        # get board primary address
        board_pad = self.get_config(CONFIG.PAD)
        listeners = []
        for pad in range(31):
            if pad == board_pad:
                # skip the primary address belonging to the board
                continue
            
            if self.check_listener(pad):
                listeners.append( (pad,NO_SAD) )
            
            if scan_sad:
                ls = []
                for sad in range(96,127):
                    if self.check_listener(pad,sad):
                        ls.append( (pad,sad) )
                
                if len(ls) == 31:
                    # all secondary address were listening
                    listeners.append( (pad,ALL_SAD) )
                else:
                    listeners.extend(ls)
        
        return listeners
    
    @property
    def control_lines(self):
        "get the state of the GPIB control lines"
        return self.lib.iblines(self._ud)
    
class Device(GpibBase):
    "GPIB device"
    
    def __init__(self, board_index, pad, sad=NO_SAD, timeout=T10s, send_eoi=True, eosmode=DEFAULT_EOSMODE):
        "initializer"
        super(Device,self).__init__(board_index,pad=pad,sad=sad,timo=timeout,eoi=send_eoi,eos=eosmode)
             
    def _create_ud(self, board_index, **kwargs):
        "create the unit descriptor"
        # open the device using ibdev
        if 'pad' not in kwargs:
            raise ValueError("'pad' must be specified for Device initialization")
        pad = int(kwargs.pop('pad'))
        sad = int(kwargs.pop('sad',NO_SAD))
        timo = int(kwargs.pop('timo',T10s))
        eoi = bool(kwargs.pop('eoi',True))
        eos = int(kwargs.pop('eos',DEFAULT_EOSMODE)) & EOSMASK
        
        if pad < 0 or pad > 30:
            raise ValueError("'pad' must be an integer 0-30")
        if sad != NO_SAD and sad != ALL_SAD and (sad < 96 or sad > 126):
            raise ValueError("'sad' must be integer {}, {}, or in range 96-126".format(NO_SAD,ALL_SAD))
        if timo < 0 or timo > 17:
            raise ValueError("'timo' must be an integer in the range 0-17".format(NO_SAD,ALL_SAD))
        
        if len(kwargs):
            raise ValueError("invalid keyword arguments: {0}".format(', '.join(kwargs)))
            
        return self.lib.ibdev(board_index,pad,sad,timo,eoi,eos)
             
    def clear(self):
        "clear the device"
        self.lib.ibclr(self._ud)

    def trigger(self):
        "send a bus trigger to the device"
        self.lib.ibtrg(self._ud)    
    
    @property
    def status_byte(self):
        "serial poll the device to get its status byte"
        return self.lib.ibrsp(self._ud)
    
        


