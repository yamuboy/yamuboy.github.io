"""Simple GPIB interface library based on the "traditional" interface
to the National Instruments IEEE 488.2 library.

This module contains the wrapper code around the NI library using ctypes
and includes some error handling and such to make it more `Pythonic`.

Author: Jay Barrett
"""
from __future__ import division, print_function, unicode_literals, absolute_import
from ctypes import *
from ctypes.util import find_library
from .constants import *

class GpibError(Exception):
    "general GPIB error"
    def __init__(self, iberr, msg=None, errno=None):
        "initializer"
        m = error_description(iberr)
        if msg:
            m += ' -> '+msg
        super(GpibError,self).__init__(m)
        self.iberr = iberr
        self.errno = errno
       
class TimeoutError(GpibError):
    "error for communication timeouts"
    pass

class AsyncInProgress(GpibError):
    "asynchronous operation in progress"
    def __init__(self, msg=None):
        super(AsyncInProgress,self).__init__(EOIP,msg=msg)
 
class AsyncReadBuffer(object):
    "class to handle asynchronous reads (ibrda)"
    
    def __init__(self, ud, bufsize):
        "initializer"
        self._ud = ud
        self._ready = False
        self._buf = create_string_buffer(bufsize)
        self._lib = GpibLib()
        self._readbytes = -1
    
    @property
    def value(self):
        "buffer value"
        self.wait_for_ready()
        if self._readbytes < 0:
            raise RuntimeError("bug! bytes read is less than 0")
        return self._buf.value[:self._readbytes]
    
    def wait_for_ready(self):
        "wait for the buffer to be ready"
        if not self._ready:
            stat = self._lib.ibwait(self._ud,CMPL|TIMO)
            if stat & TIMO:
                raise TimeoutError(self._lib.iberr)
            self._ready = True
            self._readbytes = self._lib.ibcntl
    
    def check_if_ready(self):
        "check if the I/O is complete"
        if not self._ready:
            stat = self._lib.ibwait(self._ud,0)
            if stat & CMPL:
                self._ready = True
                self._readbytes = self._lib.ibcntl
            elif stat & TIMO:
                raise TimeoutError(self._lib.iberr)
        return self._ready

class GpibLib(object):
    """NI IEEE 488.2 GPIB library interface
    
    this uses a Borg-pattern initialization such that
    only one copy of the ctypes DLL wrapper is created and
    it is shared between all objects that need to use
    the NI IEEE 488.2 library
    """
    
    # shared state for Borg initialization
    __shared_state = dict()
    
    def __init__(self):
        "initializer"
        # Borg initialization
        self.__dict__ = self.__shared_state
        
        if not hasattr(self,'_library'):
            # first creation, must load the library
            # first try loading the library directly
            # this uses the default ctypes method for
            # loading the library on the platform
            for sl in ['libgpib.so','gpib-32.dll']:
                try:
                    self._library = cdll.LoadLibrary(sl)
                    break
                except OSError:
                    pass
            
            if not hasattr(self,'_library'):
                # direct load failed, try to use find_library
                # to locate the library
                for sl in ['gpib','gpib-32.dll']:
                    path = find_library(sl)
                    if path is not None:
                        try:
                            self._library = cdll.LoadLibrary(path)
                            break
                        except OSError:
                            pass
            
            if not hasattr(self,'_library'):
                raise OSError("could not load NI IEEE 488.2 GPIB library")
            
            # special items used for asynchronous I/O
            self._async_buffer = None
            self._async_io = False

    def _check(self, st):
        """check the command return status and raise
        exceptions as appropriate
        """
        if st & TIMO:
            raise TimeoutError(self.iberr)
        elif st & ERR:
            if self.iberr in (EDVR,EFSO):
                raise GpibError(self.iberr,errno=self.ibcntl)
            else:
                raise GpibError(self.iberr)
        
    def _sync(self, ud, wait=False):
        "re-sync the library if an asynchronous operation was underway"
        if self._async_io:
            if isinstance(self._async_buffer,AsyncReadBuffer):
                # let the read buffer handle synchronization
                if wait:
                    self._async_buffer.wait_for_ready()                
                else:
                    if not self._async_buffer.check_if_ready():
                        raise AsyncInProgress()
                # async I/O is done
                self._async_io = False            
                self._async_buffer = None
            else:
                # sync manually
                if wait:
                    st = self._library.ibwait(ud,CMPL|TIMO)
                else:
                    st = self._library.ibwait(ud,0)
                
                if st & TIMO:
                    raise TimeoutError(self.iberr)
                
                if st & CMPL:
                    # async I/O is done
                    self._async_io = False            
                    self._async_buffer = None
                else:
                    raise AsyncInProgress()
        
    def ibask(self, ud, option):
        "get software configuration parameters"
        # extern int ibask( int ud, int option, int *value );
        self._sync(ud)
        v = c_int()
        self._check(self._library.ibask(c_int(ud),c_int(option),byref(v)))
        return v.value
        
    def ibbna(self, ud, board_name):
        "device-level only: change the interface for a device"
        # extern int ibbna( int ud, char *board_name );
        self._sync(ud)
        self._check(self._library.ibbna(c_int(ud),bytes(board_name)))
        
    def ibcac(self, ud, sync_flag):
        "board-level only: become active controller"
        # extern int ibcac( int ud, int synchronous );
        self._sync(ud)
        v = c_int(1) if sync_flag else c_int(0)
        self._check(self._library.ibcac(c_int(ud),v))
    
    def ibclr(self, ud):
        "device-level only: send a device clear command"
        # extern int ibclr( int ud );
        self._sync(ud)
        self._check(self._library.ibclr(c_int(ud)))
    
    def ibcmd(self, ud, cmd):
        "board-level only: send commands on the bus"
        # extern int ibcmd( int ud, const void *cmd, long cnt );
        self._sync(ud)
        self._check(self._library.ibcmd(c_int(ud),bytes(cmd),c_long(len(cmd))))
        
    def ibcmda(self, ud, cmd):
        "board-level only: send commands asynchronously"
        # extern int ibcmda( int ud, const void *cmd, long cnt );
        self._sync(ud)
        buf = create_string_buffer(cmd)
        # save the buffer so it doesn't get garbage collected
        self._async_buffer = buf
        self._check(self._library.ibcmda(c_int(ud),buf,c_long(len(cmd))))
        self._async_io = True
        
    def ibconfig(self, ud, option, value):  
        "change software configuration parameters"
        # extern int ibconfig( int ud, int option, int value );
        self._sync(ud)
        self._check(self._library.ibconfig(c_int(ud),c_int(option),c_int(value)))
    
    def ibdev(self, board, pad, sad, timo, send_eoi, eos):
        "device-level only: get a device descriptor for a device"
        # extern int ibdev( int board_index, int pad, int sad, int timo, int send_eoi, int eosmode );
        if board < 0:
            raise ValueError("'{}' is not a valid board index".format(board))                        
        if pad < 0 or pad > 30:
            raise ValueError("'{}' is not a valid primary address".format(pad))            
        if sad not in (NO_SAD,ALL_SAD) and (sad < 96 or sad > 126):
            raise ValueError("'{}' is not a valid secondary address".format(sad))
        if timo < 0 or timo > 17:
            raise ValueError("'{}' is not a valid timeout specifier".format(timo))            
        eoi = c_int(1) if send_eoi else c_int(0)
        ud = self._library.ibdev(c_int(board),c_int(pad),c_int(sad),c_int(timo),eoi,c_int(eos&EOSMASK))
        if ud < 0:
            raise GpibError(self.iberr,"ibdev() could not generate a device descriptor for board={}, pad={}, sad={}".format(board,pad,sad))
        return ud
        
    def ibdma(self, ud, flag):
        "(deprecated) enable/disable DMA transfers"
        # extern int ibdma( int ud, int v );
        self._sync(ud)
        v = c_int(1) if flag else c_int(0)
        self._check(self._library.ibdma(c_int(ud),v))
    
    def ibeos(self, ud, v):
        "configure the EOS character and mode"
        # extern int ibeos( int ud, int v );
        self._sync(ud)
        self._check(self._library.ibeos(c_int(ud),c_int(v&EOSMASK)))
        
    def ibeot(self, ud, flag):
        "enable/disable assertion of EOI at the end of writes"
        # extern int ibeot( int ud, int v );
        self._sync(ud)
        v = c_int(1) if flag else c_int(0)
        self._check(self._library.ibeot(c_int(ud),v))              
    
    def ibfind(self, dev):
        "get the device descriptor for a board/device configured by name"
        # extern int ibfind( const char *dev );
        ud = self._library.ibfind(bytes(dev))
        if ud < 0:
            raise GpibError(self.iberr,"ibfind() could not find a board or device named '{}'".format(dev))
        return ud
        
    def ibgts(self, ud, handshake_flag):
        "board-level only: go to standby - release bus control"
        # extern int ibgts(int ud, int shadow_handshake);
        self._sync(ud)
        v = c_int(1) if handshake_flag else c_int(0)
        self._check(self._library.ibgts(c_int(ud),v))  
        
    def ibist(self, ud, flag):
        "board-level only: set/clear individual status bit for parallel polls"
        # extern int ibist( int ud, int ist );
        self._sync(ud)
        v = c_int(1) if flag else c_int(0)
        self._check(self._library.ibgts(c_int(ud),v))  
    
    def iblines(self, ud):
        "board-level only: get GPIB control line status"
        # extern int iblines( int ud, short *line_status );
        self._sync(ud)
        v = c_short()
        self._check(self._library.iblines(c_int(ud),byref(v)))
        return v.value

    def ibln(self, ud, pad, sad=NO_SAD):
        "check for listeners"
        # extern int ibln( int ud, int pad, int sad, short *found_listener );
        self._sync(ud)
        v = c_short()
        self._check(self._library.ibln(c_int(ud),c_int(pad),c_int(sad),byref(v)))
        return v.value

    def ibloc(self, ud):
        "go to local mode"
        # extern int ibloc( int ud );
        self._sync(ud)
        self._check(self._library.ibloc(c_int(ud)))
        
    def ibonl(self, ud, flag):
        "place the board/device online/offline"
        # extern int ibonl( int ud, int onl );
        v = c_int(1) if flag else c_int(0)
        self._check(self._library.ibonl(c_int(ud),v))
        
    def ibpad(self, ud, v):
        "set primary address"
        # extern int ibpad( int ud, int v );
        self._sync(ud)
        if v < 0 or v > 30:
            raise ValueError("'{0}' is not a valid primary address".format(v))
        self._check(self._library.ibpad(c_int(ud),c_int(v)))
        
    def ibpct(self, ud):
        "device-level only: pass control to another device"
        # extern int ibpct( int ud );
        self._sync(ud)
        self._check(self._library.ibpct(c_int(ud)))
        
    def ibppc(self, ud, v):
        "configure parallel polling"
        # extern int ibppc( int ud, int v );
        self._sync(ud)
        if v != 0 and (v < 96 or v > 126):
            raise ValueError("'{0}' is not a valid parallel poll configuration".format(v))            
        self._check(self._library.ibppc(c_int(ud),c_int(v&0xff)))
    
    def ibrd(self, ud, max_len):
        "read data"
        # extern int ibrd( int ud, void *buf, long count );
        self._sync(ud)
        buf = create_string_buffer(max_len)
        self._check(self._library.ibrd(c_int(ud),buf,c_long(max_len)))
        return buf.value[:self.ibcntl]
        
    def ibrda(self, ud, max_len):
        "read data asynchronously"
        # extern int ibrda( int ud, void *buf, long count );
        self._sync(ud)
        buf = AsyncReadBuffer(ud,max_len)
        # save the buffer so it doesn't get garbage collected
        self._async_buffer = buf
        self._check(self._library.ibrda(c_int(ud),buf,c_long(max_len)))
        self._async_io = True
        return buf

    def ibrpp(self, ud):
        "conduct a parallel poll and return the result"
        # extern int ibrpp( int ud, char *ppr );
        self._sync(ud)
        v = c_byte()
        self._check(self._library.ibrpp(c_int(ud),byref(v)))
        return v.value
        
    def ibrsc(self, ud, flag):
        "board-level only: request/release control"
        # extern int ibrsc( int ud, int v );
        self._sync(ud)
        v = c_int(1) if flag else c_int(0)
        self._check(self._library.ibrsc(c_int(ud),v))

    def ibrsp(self, ud):
        "conduct a serial poll and return the result"
        # extern int ibrsp( int ud, char *spr );
        self._sync(ud)
        v = c_byte()
        self._check(self._library.ibrsp(c_int(ud),byref(v)))
        return v.value

    def ibrsv(self, ud, v):
        "board-level only: request service from the controller"
        # extern int ibrsv( int ud, int v );
        self._sync(ud)
        self._check(self._library.ibrsv(c_int(ud),c_int(v)))

    def ibsad(self, ud, v):
        "set secondary address"
        # extern int ibsad( int ud, int v );
        self._sync(ud)
        if v not in (NO_SAD,ALL_SAD) and (v < 96 or v > 126):
            raise ValueError("'{0}' is not a valid secondary address".format(v))
        self._check(self._library.ibsad(c_int(ud),c_int(v)))

    def ibsic(self, ud):
        "board-level only: assert the interface clear line"
        # extern int ibsic( int ud );
        self._sync(ud)
        self._check(self._library.ibsic(c_int(ud)))

    def ibsre(self, ud, flag):
        "board-level only: set/clear the remote enable (REN) line"
        # extern int ibsre( int ud, int v );
        self._sync(ud)
        v = c_int(1) if flag else c_int(0)
        self._check(self._library.ibsre(c_int(ud),v))

    def ibstop(self, ud):
        "abort asynchronous operation"
        # extern int ibstop( int ud );
        self._check(self._library.ibstop(c_int(ud)))

    def ibtmo(self, ud, v):
        "change the I/O timeout"
        # extern int ibtmo( int ud, int v );
        self._sync(ud)
        if v < 0 or v > 17:
            raise ValueError("invalid timeout value")
        self._check(self._library.ibtmo(c_int(ud),c_int(v)))

    def ibtrg(self, ud):
        "device level only: send a bus trigger to the device"
        # extern int ibtrg( int ud );
        self._sync(ud)
        self._check(self._library.ibtrg(c_int(ud)))

    def ibwait(self, ud, mask):
        "wait for an event"
        # extern int ibwait( int ud, int mask );
        self._check(self._library.ibwait(c_int(ud),c_int(mask&0xffff)))

    def ibwrt(self, ud, cmd):
        "write command data"
        # extern int ibwrt( int ud, const void *buf, long count );
        self._sync(ud)
        self._check(self._library.ibwrt(c_int(ud),bytes(cmd),c_long(len(cmd))))
        
    def ibwrta(self, ud, cmd):
        "write data asynchronously"
        # extern int ibwrta( int ud, const void *buf, long count );
        self._sync(ud)
        buf = create_string_buffer(cmd)
        # save the buffer so it doesn't get garbage collected
        self._async_buffer = buf
        self._check(self._library.ibwrta(c_int(ud),buf,c_long(len(cmd))))
        self._async_io = True
            
    @property
    def ibsta(self):
        "library function call status"
        if hasattr(self._library,'ThreadIbsta'):
            return self._library.ThreadIbsta()
        else:
            return c_int.in_dll(self._library,'ibsta').value
    
    @property
    def iberr(self):
        "library function call error number"
        if hasattr(self._library,'ThreadIberr'):
            return self._library.ThreadIberr()
        else:
            return c_int.in_dll(self._library,'iberr').value
            
    @property
    def ibcntl(self):
        "byte transfer count"
        if hasattr(self._library,'ThreadIbcntl'):
            f = self._library.ThreadIbcntl
            f.restype = c_long
            return f()
        else:
            return c_long.in_dll(self._library,'ibcntl').value
    ibcnt = ibcntl

            
    