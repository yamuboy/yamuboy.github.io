"""Simple GPIB interface library based on the "traditional" interface
to the National Instruments IEEE 488.2 library.

Author: Jay Barrett
"""
from __future__ import division, print_function, unicode_literals, absolute_import
from .constants import *
from .library import GpibLib, GpibError, TimeoutError, AsyncInProgress
from .devices import Board, Device