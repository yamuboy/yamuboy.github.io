"""Simple GPIB interface library based on the "traditional" interface
to the National Instruments IEEE 488.2 library.

This module constants used by the NI library.

Author: Jay Barrett
"""
from __future__ import division, print_function, unicode_literals, absolute_import

# special secondary addresses 
NO_SAD = 0
ALL_SAD = -1
    
# EOS mode bits (high byte of EOS word)
REOS = 0x0400
XEOS = 0x0800
BIN = 0x1000
EOSMASK = REOS | XEOS | BIN | 0xff

# ibsta bit definitions
DCAS = 0x0001
DTAS = 0x0002
LACS = 0x0004
TACS = 0x0008
ATN = 0x0010
CIC = 0x0020
REM = 0x0040
LOK = 0x0080
CMPL = 0x0100
EVENT = 0x0200
SPOLL = 0x0400
RQS = 0x0800
SRQI = 0x1000
END = 0x2000
TIMO = 0x4000
ERR = 0x8000

# error codes
EDVR = 0
ECIC = 1
ENOL = 2
EADR = 3
EARG = 4
ESAC = 5
EABO = 6
ENEB = 7
EDMA = 8
EOIP = 10
ECAP = 11
EFSO = 12
EBUS = 14
ESTB = 15
ESRQ = 16
ETAB = 20
    
_error_descriptions = {
    EDVR: "Failed system call.",
    ECIC: "Interface board is not controller-in-charge.",
    ENOL: "No listeners currently addressed.",
    EADR: "Interface board failed to address itself during I/O operations.",
    EARG: "Invalid function arguemnt(s).",
    ESAC: "Interface board is not system controller.",
    EABO: "I/O operation aborted.",
    ENEB: "Interface board does not exist or is not configured properly.",
    EDMA: "DMA error (deprecated).",
    EOIP: "Asynchronous I/O in progress.",
    ECAP: "No capability for requested operation.",
    EFSO: "File system error.",
    EBUS: "Bus write timed out.",
    ESTB: "One or more serial poll status bytes have been dropped.",
    ESRQ: "Service request line is stuck on.",
    ETAB: "Table problem.",
}

def error_description( e ):
    "get the description for an error message"
    if e in _error_descriptions:
        return _error_descriptions[e]
    return "Unknown error."

# timeout constants
TNONE = 0
T10us = 1
T30us = 2
T100us = 3
T300us = 4
T1ms = 5
T3ms = 6
T10ms = 7
T30ms = 8
T100ms = 9
T300ms = 10
T1s = 11
T3s = 12
T10s = 13
T30s = 14
T100s = 15
T300s = 16
T1000s = 17
    
# configuration parameter IDs
# used by ibask and ibconfig
_config_params = { 'PAD': 0x1, 'SAD': 0x2, 'TMO': 0x3,
    'EOT': 0x4, 'PPC': 0x5, 'READDR': 0x6, 'AUTOPOLL': 0x7,
    'CICPROT': 0x8, 'IRQ': 0x9, 'SC': 0xa, 'SRE': 0xb,
    'EOSrd': 0xc, 'EOSwrt': 0xd, 'EOScmp': 0xe, 'EOSchar': 0xf,
    'PP2': 0x10, 'TIMING': 0x11, 'DMA': 0x12, 'ReadAdjust': 0x13,
    'WriteAdjust': 0x14, 'EventQueue': 0x15, 'SPollBit': 0x16,
    'SendLLO': 0x17, 'SPollTime': 0x18, 'PPollTime': 0x19,
    'EndBitIsNormal': 0x1a, 'UnAddr': 0x1b, 'HSCableLength': 0x1f,
    'Ist': 0x20, 'Rsv': 0x20, 'BNA': 0x200,
    }

# create an enumeration of configuration parameter IDs
# that can be used like CONFIG.PAD and CONFIG.SPollBit
if 'unicode' in __builtins__:
    _enum_name = b'Enum' # Python2
else:
    _enum_name = 'Enum' # Python3
CONFIG = type(_enum_name,(),_config_params)

# valid config ID values
VALID_CONFIG_IDS = set(_config_params.values())

