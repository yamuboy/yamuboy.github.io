﻿from __future__ import print_function

import re
import os
import sys

width_re = r'\#define .+_width (\d+)\n'
length_re = r'\#define .+_height (\d+)\n'
name_re = r'.+ (.+)_bits.+\n'

class Pattern(object):
    """
    Class that encapsulates a fill pattern

    Members:
    _width - width of the pattern (int)
    _height - height of the pattern (int)
    _name - name of the pattern (str)

    _lines - list of list of booleans, where n is the width of the line

    """
    def __init__(self, filename=None):
        self._width = 16
        self._height = 16
        self._name = u'No Fill'
        self._lines =   [
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                           [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                        ]

        if filename is not None:
            self.read_ADS_pattern(filename)

    def print_pattern(self):
        "Prints the pattern to console"
        for line in self._lines:
            for bit in line:
                if bit:
                    print(u'\u2588', end="")
                else:
                    print(' ', end="")
            print()

    def print_pattern_awr_lpf(self, stream=sys.stdout):
        """
        Prints pattern to the specified stream in AWR LPF format
        """
        #   Sample AWR LPF pattern format
        #
        #   ( display forward_slash (
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #   ) )

        print('( display {} ('.format(self._name), file=stream)

        for line in self._lines:
            print("  (", end=' ', file=stream)

            for bit in line:
                if bit:
                    print("1", end=' ', file=stream)
                else:
                    print("0", end=' ', file=stream)

            print(")", file=stream)

        print(") )", file=stream)

    def print_pattern_klayout_lyp(self, stream=sys.stdout, index=0):
        """
        Prints pattern to the specified stream in KLayout .lyp format
        """
        #   Sample KLayout pattern format
        #   <custom-dither-pattern>
        #    <pattern>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***.....***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>********************************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*.*..**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**......**..*...**......**...</line>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***...*.***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>***************.****************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*....**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**...*..**......**......**...</line>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***.....***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>********************************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*....**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**......**......**......**...</line>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***.....***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>********************************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*....**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**......**......**......**...</line>
        #    </pattern>
        #    <order>1</order>
        #    <name/>
        #   </custom-dither-pattern>

        print(' <custom-dither-pattern>', file=stream)
        print('  <pattern>', file=stream)
        
        # KLayout uses 32x32, so must repeat patterns smaller than 32x32 accordingly
        j = 0
        while(j < 32):
            for line in self._lines:
                i = 0
                print('   <line>', end='', file=stream)
                
                while(i < 32):
                    for bit in line:
                        if bit:
                            print("*", end='', file=stream)
                        else:
                            print(".", end='', file=stream)
                        i += 1

                print('</line>', file=stream)

                j += 1

        print('  </pattern>', file=stream)
        print('  <order>' + str(index) + '</order>', file=stream)
        print('  <name>' + self.name + '</name>', file=stream)
        print(' </custom-dither-pattern>', file=stream)

    def print_pattern_ads(self, stream=sys.stdout):
        """
        Prints pattern to the specified stream in ADS format
        """
        #   Sample ADS pattern format
        #
        #   #define pat1_width 16
        #   #define pat1_height 16
        #   static unsigned char pat1_bits[] = {
        #      0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa,
        #      0x7f, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa,
        #      0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa};

        print('#define ' + self._name + '_width ' + str(self.width), file=stream)
        print('#define ' + self._name + '_height ' + str(self.height), file=stream)
        print('static unsigned char ' + self._name + '_bits[] = {', end = '', file=stream)

        idx = 0
        for line in self._lines:
            segments = [line[x:x + 8] for x in xrange(0, len(line), 8)]

            for segment in segments:
                bits = 0
                for bit in reversed(range(0, 8)):
                    if segment[bit]:
                        bits += 1 << (bit)

                if idx == 0:
                    print('\n   0x{:02x}'.format(bits), end='', file=stream)
                elif not idx%12 and not idx == 0:
                    print(',\n   0x{:02x}'.format(bits), end='', file=stream)
                else:
                    print(', 0x{:02x}'.format(bits), end='', file=stream)

                idx += 1

        print('};', file=stream)

    def read_ADS_pattern(self, filename):
        """
        Reads an ADS pattern file

        Arguments:

        filename - path to the "*.pattern" file
        
        """

        #   A sample ADS pattern file looks as follows:
        #
        #   #define pat1_width 16
        #   #define pat1_height 16
        #   static unsigned char pat1_bits[] = {
        #      0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa,
        #      0x7f, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa,
        #      0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa};
        #
        #   Extract width of pattern from line 0
        #   Extract height of pattern from line 1
        #   Extract name of pattern from filename
        #   Extract pattern lines from lines 3:

        fp = open(filename)
        lines = fp.readlines()

        # get pattern width, height, and name
        self._width = int(re.match(width_re, lines[0]).group(1))
        self._height = int(re.match(length_re, lines[1]).group(1))
        self._name = os.path.basename(filename).split('.')[-2]

        # parse pattern lines
        
        # combine all 8-bit segments into one string
        all_segments = "".join(lines[3:]).replace('\n', '')[:-2]

        # parse all 8-bit segments into list of bytes
        segments = [int(x.strip()[2:4], 16) for x in re.split(r',', all_segments)]

        # determine how many consecutive bytes make up one line
        segs_per_line = len(segments) / self._width

        patlines = [ ]

        # store lines
        # index over number of lines
        for i in range(0, len(segments), segs_per_line):
            
            line = [ ]

            # index over number of bytes in a line
            for j in range (0, segs_per_line):

                # index over bits in a byte
                for k in range (0, 8):

                    bit = ((segments[i + j] >> k) & 1) == 1
                    line.append(bit)

            patlines.append(line)

        self._lines = patlines
    
    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    @property
    def name(self):
        return self._name

    @property
    def lines(self):
        return self._lines
        
