﻿import wx
import os
import re
import sys
import cPickle
import colorsys
import traceback

from enum import Enum

import wx.lib.colourchooser as CCD
from wx.lib.scrolledpanel import ScrolledPanel
from wx.lib.splitter import MultiSplitterWindow

import wx.lib.inspection

from .utils import *
from .layer import Layer
from .pattern import Pattern
from .bufferedcanvas import BufferedCanvas

_debug = False

_no_fill_text = 'No Fill'
_no_outline_text = 'No Outline'

etEVT_LAYER = wx.NewEventType()
etEVT_PATTERN = wx.NewEventType()
etEVT_INFO = wx.NewEventType()
EVT_LAYER = wx.PyEventBinder(etEVT_LAYER, 1)
EVT_PATTERN = wx.PyEventBinder(etEVT_PATTERN, 1)
EVT_INFO = wx.PyEventBinder(etEVT_INFO, 1)

class LayerEventType(Enum):
    INSERT  = 0,
    REMOVE  = 1,
    DISPLAY = 2,
    MOVE    = 3,
    SELECT  = 4,

class LayerEvent(wx.PyCommandEvent):
    """
    Custom event sent when a user interacts with the layer list

    Arguments:

    eventType - LayerEventType that describes the event
    eventValue - Specific information for the event

    For an INSERT event, the eventValue is a 2-tuple of form (String, Integer). The string is the name of the layer, and the integer represents
        the index where the new layer should be inserted. If the value is -1, then the layer should be appended to the end of the layer list
    For a REMOVE event, the eventValue is a list of Integers that represents the indices of the layers to be removed
    For a DISPLAY event, the eventValue is a list of Integers that represents the indices of layers to be displayed
    For a MOVE event, the eventValue is a list of Integers that represent the new indices of each layer.
        e.g. a list of [0, 2, 3, 1, 4] means an original layer list of ['Layer 1', 'Layer 2'...] would look like ['Layer 1', 'Layer 3', 'Layer 4', 'Layer 2' ...]
    For a SELECT event, eventValue is a list of Integers that represent the selected indices from the layer list
    """
    def __init__(self, evtType, id, eventType, eventValue):
        wx.PyCommandEvent.__init__(self, evtType, id)
        self._eventType = eventType
        self._eventValue = eventValue

    @property
    def eventType(self):
        return self._eventType

    @property
    def eventValue(self):
        return self._eventValue

class PatternEvent(wx.PyCommandEvent):
    """
    Custom event sent when a pattern is added to the info display but isn't already in the main pattern list
    This can occur if a user opens a layer configuration that contains a layer without loading all of the patterns used in that configuration

    Arguments:

    pattern - the Pattern object to be added
    """
    def __init__(self, evtType, id, pattern):
        wx.PyCommandEvent.__init__(self, evtType, id)
        self._pattern = pattern

    @property
    def pattern(self):
        return self._pattern

class InfoEvent(wx.PyCommandEvent):
    "Event used to trigger updates from user-input data to the internal list of layers"
    def __init__(self, evtType, id):
        wx.PyCommandEvent.__init__(self, evtType, id)

class LCTControlPanel(wx.Panel):
    def __init__(self, *args, **kwargs):
        super(LCTControlPanel, self).__init__(*args, **kwargs)
        self.initUI()

    def initUI(self, *args, **kwargs):
        self._ADSbutton = wx.Button(self, label='Write ADS configuration')
        self._AWRbutton = wx.Button(self, label='Write AWR LPF File')
        self._KLayoutbutton = wx.Button(self, label='Write KLayout .lyp File')

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self._ADSbutton, 0, flag=wx.SizerFlags(0).Expand().GetFlags())
        sizer.AddSpacer(10)
        sizer.Add(self._AWRbutton, 0, flag=wx.SizerFlags(0).Expand().GetFlags())
        sizer.AddSpacer(10)
        sizer.Add(self._KLayoutbutton, 0, flag=wx.SizerFlags(0).Expand().GetFlags())

        self.Bind(wx.EVT_BUTTON, self.OnADSButton, self._ADSbutton)
        self.Bind(wx.EVT_BUTTON, self.OnAWRButton, self._AWRbutton)
        self.Bind(wx.EVT_BUTTON, self.OnKLayoutButton, self._KLayoutbutton)

        self.SetSizerAndFit(sizer)
        self.Layout()

    def OnADSButton(self, evt):
        evt.SetString('SaveADSConf')
        evt.Skip()

    def OnAWRButton(self, evt):
        evt.SetString('SaveAWRLPF')
        evt.Skip()

    def OnKLayoutButton(self, evt):
        evt.SetString('SaveKLayoutLYP')
        evt.Skip()

class LCTCanvas(BufferedCanvas):
    _bitmap = None

    def __init__(self, *args, **kwargs):
        super(LCTCanvas, self).__init__(*args, **kwargs)
        self._bitmap = wx.EmptyBitmap(self.GetSize().x, self.GetSize().y)

    def draw(self, dc):
        if self._bitmap is not None:
            dc.Clear()
            dc.DrawBitmap(self._bitmap, 0, 0)
                
    def update_bitmap(self, bitmap):
        if bitmap is not None:
            self._bitmap = bitmap

class LCTDispPanel(wx.Panel):
    """
    Panel that contains one black and one white canvas on which to draw a pattern
    """
    
    _canvas_size = 256
    _box_size = 128
    _data = None

    def __init__(self, *args, **kwargs):
        super(LCTDispPanel, self).__init__(*args, **kwargs)
        self.initData()
        self.initUI()

    def initData(self, num=1, pattern=None, color=wx.Colour(128, 128, 128)):
        # create local patterns
        self._patterns = [pattern]*num

        # create blank canvases
        self._colors = [color]*num
        self._masks = [wx.BitmapFromImage(wx.EmptyImage(8, 8))]*num
        
        black = wx.EmptyImage(self._canvas_size, self._canvas_size)
        white = wx.EmptyImage(self._canvas_size, self._canvas_size)
        white.Replace(0, 0, 0, 255, 255, 255)

        self._black = wx.BitmapFromImage(black)
        self._white = wx.BitmapFromImage(white)

    def initUI(self, *args, **kwargs):
        self._black_label = wx.StaticText(self, wx.ID_ANY, 'Black Background (ADS)')
        self._white_label = wx.StaticText(self, wx.ID_ANY, 'White Background (AWR)')
        self._black_canvas = LCTCanvas(self, size=(self._canvas_size, self._canvas_size))
        self._white_canvas = LCTCanvas(self, size=(self._canvas_size, self._canvas_size))

        self._black_canvas.update_bitmap(self._black)
        self._white_canvas.update_bitmap(self._white)

        sizer = wx.GridBagSizer(5, 5)

        sizer.AddStretchSpacer((0, 0))
        sizer.AddGrowableCol(0)

        sizer.Add(self._black_label,  pos=(0, 1), flag=wx.SizerFlags(0).Align(wx.ALIGN_CENTER_HORIZONTAL).GetFlags())
        sizer.Add(self._black_canvas, pos=(1, 1), flag=wx.SizerFlags(0).Align(wx.ALIGN_CENTER_HORIZONTAL).GetFlags())

        sizer.AddStretchSpacer((0, 2))
        sizer.AddGrowableCol(2)

        sizer.Add(self._white_label,  pos=(0, 3), flag=wx.SizerFlags(0).Align(wx.ALIGN_CENTER_HORIZONTAL).GetFlags())
        sizer.Add(self._white_canvas, pos=(1, 3), flag=wx.SizerFlags(0).Align(wx.ALIGN_CENTER_HORIZONTAL).GetFlags())

        sizer.AddStretchSpacer((0, 4))
        sizer.AddGrowableCol(4)

        self.SetSizer(sizer)
        sizer.Fit(self)
        self.Layout()

    def clearBitmap(self, bitmap, color, trans=False):
        dc = wx.MemoryDC(bitmap)
        dc.BeginDrawing()
        if trans:
            dc.SetBackground(wx.Brush(color, style=wx.BRUSHSTYLE_TRANSPARENT))
        else:
            dc.SetBackground(wx.Brush(color))
        dc.Clear()
        dc.EndDrawing()
        dc.Destroy()

    def updateData(self, data):
        """
        Update the pattern, style, color and scale data stored in the display window.
        Assumes correct format is passed in to data!

        data - 4-tuple of form ([Pattern], [LineStyle], [wx.Colour], [float])
        """

        self._data = data
        self._masks = []
        self.createMasks()
        self.drawPattern()

    def createMasks(self):
        """
        Creates a wx.Bitmap for each pattern stored in the window
        If data is None, creates a blank mask
        """
        if self._data:
            patterns = self._data[0]
            colors = self._data[2]

            # get max width/height of all patterns
            width = 0
            height = 0
            for pattern in patterns:
                if pattern is None:
                    continue
                width = max(width, pattern.width)
                height = max(height, pattern.height)

            # initialize images           
            dc = wx.MemoryDC()

            # draw all patterns
            for (pattern, color) in zip(patterns, colors):

                if pattern is not None:

                    width = pattern.width
                    height = pattern.height
                    lines = pattern.lines

                    mask = wx.BitmapFromImage(wx.EmptyImage(width, height))

                    bgcolor = 'BLACK'
                    if color == wx.Colour(0, 0, 0):
                        bgcolor = 'WHITE'

                    self.clearBitmap(mask, bgcolor)

                    dc.SelectObject(mask)
                    dc.BeginDrawing()

                    if bgcolor == 'WHITE':
                        dc.SetPen(wx.Pen('BLACK'))
                    else:
                        dc.SetPen(wx.Pen(color))

                    x = 0
                    y = 0

                    for line in lines:
                        for bit in line:
                            if bit:
                                dc.DrawPoint(x, y)
                            x += 1

                        y += 1
                        x = 0

                    dc.EndDrawing()
                    dc.SelectObject(wx.NullBitmap)

                    if bgcolor == 'WHITE':
                        mask.SetMaskColour(wx.Colour(255, 255, 255))
                    else:
                        mask.SetMaskColour(wx.Colour(0, 0, 0))

                    self._masks.append(mask)

                else:
                    mask = wx.BitmapFromImage(wx.EmptyImage(8, 8))
                    self.clearBitmap(mask, 'BLACK')
                    mask.SetMaskColour(wx.Colour(0, 0, 0))
                    self._masks.append(mask)

            dc.Destroy()

        else:
            self._masks = [wx.BitmapFromImage(wx.EmptyImage(8, 8))]
            self.clearBitmap(self._masks[0], 'BLACK')
            self._masks[0].SetMaskColour(wx.Colour(255, 255, 255))

    def drawPattern(self):
        """
        Draws the stored pattern stack
        """

        x0 = self._canvas_size / 2
        y0 = self._canvas_size / 2

        self.clearBitmap(self._black, 'BLACK')
        self.clearBitmap(self._white, 'WHITE')

        dc = wx.MemoryDC()

        for canvas in [self._black ,self._white]:
            if self._data:
                dc.SelectObject(canvas)
                dc.BeginDrawing()
                patterns = list(reversed(self._data[0]))    # draw in reverse order to ensure correct layering
                styles = self._data[1]
                colors = self._data[2]
                scales = self._data[3]

                idx = 0
                for (pattern, style, color, scale) in zip(reversed(self._masks), reversed(styles), reversed(colors), reversed(scales)):

                    brush = wx.Brush('BLACK', style=wx.BRUSHSTYLE_TRANSPARENT)
                    dc.SetBrush(brush)

                    if color == wx.Colour(0, 0, 0) and canvas is self._black:
                        dc.SetLogicalFunction(wx.SET)
                    elif color == wx.Colour(255, 255, 255) and canvas is self._white:
                        dc.SetLogicalFunction(wx.CLEAR)
                    else:
                        dc.SetLogicalFunction(wx.COPY)

                    pen = wx.Pen(color, style=get_wx_penstyle(style))
                    dc.SetPen(pen)

                    dc.DrawRectangle(x0 - 0.5*self._box_size*scale, y0 - 0.5*self._box_size*scale, self._box_size*scale, self._box_size*scale)

                    if patterns[idx] is not None:

                        width = pattern.Width
                        height = pattern.Height
                        dc.SetClippingRegion(x0 - 0.5*self._box_size*scale, y0 - 0.5*self._box_size*scale, self._box_size*scale, self._box_size*scale)
                        for i in range(0, self._canvas_size / width):
                            for j in range(0, self._canvas_size / height):
                                dc.Blit(x0 - 0.5*self._canvas_size + width*i, y0 - 0.5*self._canvas_size + height*j, width, height, wx.MemoryDC(pattern), 0, 0, useMask=True)
                        dc.DestroyClippingRegion()

                    idx += 1 

                dc.EndDrawing()

        dc.Destroy()

        self.Layout()

class LCTInfoPanel(wx.Panel):
    """
    Panel that contains controls with which to edit layer properties
    """

    _patternNames = []

    def __init__(self, *args, **kwargs):
        super(LCTInfoPanel, self).__init__(*args, **kwargs)
        self.initUI()

    def initUI(self, *args, **kwargs):
        self._nameLabel     = wx.StaticText(self, label="Name")
        self._gdsLabel      = wx.StaticText(self, label="GDS Layer # (0-255)")
        self._scaleLabel    = wx.StaticText(self, label="Draw Scale")
        self._patternLabel  = wx.StaticText(self, label="Pattern")
        self._styleLabel    = wx.StaticText(self, label="Border Line Style")
        self._bindingLabel  = wx.StaticText(self, label="Layer Bindings")

        self._nameBox       = wx.TextCtrl(self, size=(10, 25))
        self._gdsBox        = wx.TextCtrl(self, size=(30, 25))
        self._scaleBox      = wx.TextCtrl(self, size=(30, 25))
        self._patternDrop   = wx.ComboBox(self, size=(400, 25), value=_no_fill_text, choices=[_no_fill_text])
        self._styleDrop     = wx.ComboBox(self, size=(400, 25), value=_no_outline_text, choices=[_no_outline_text] + [x.name for x in LineStyle])
        self._visibleCB     = wx.CheckBox(self, label="Visible by Default?", style=wx.CHK_3STATE)
        self._cloakCB       = wx.CheckBox(self, label="Cloaked by Default? (AWR Only)", style=wx.CHK_3STATE)

        self._bindingLB     = wx.ListBox(self, style=wx.LB_EXTENDED)

        self._controls = [self._nameBox, self._gdsBox, self._scaleBox, self._patternDrop, self._styleDrop, self._visibleCB, self._cloakCB, self._bindingLB]
        self.disableAllControls()

        leftSizer = wx.BoxSizer(wx.VERTICAL)
        leftSizer.Add(self._nameLabel   , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.Add(self._nameBox     , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).Expand().GetFlags())
        leftSizer.AddSpacer(5)
        leftSizer.Add(self._gdsLabel    , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.Add(self._gdsBox      , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.AddSpacer(5)
        leftSizer.Add(self._scaleLabel    , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.Add(self._scaleBox      , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.AddSpacer(5)
        leftSizer.Add(self._patternLabel, 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.Add(self._patternDrop , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.AddSpacer(5)
        leftSizer.Add(self._styleLabel  , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.Add(self._styleDrop   , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.AddSpacer(5)
        leftSizer.Add(self._visibleCB   , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())
        leftSizer.Add(self._cloakCB     , 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL, 10).GetFlags())

        rightSizer = wx.BoxSizer(wx.VERTICAL)
        rightSizer.Add(self._bindingLabel, 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL,10).Expand().GetFlags())
        rightSizer.Add(self._bindingLB, 1, flag=wx.SizerFlags(0).Align(wx.RIGHT).Border(wx.ALL,10).Expand().GetFlags())

        sizer = wx.BoxSizer(wx.HORIZONTAL)
        sizer.Add(leftSizer, 0, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL,10).Expand().GetFlags())
        sizer.AddSpacer(10)
        sizer.Add(rightSizer, 1, flag=wx.SizerFlags(0).Align(wx.LEFT).Border(wx.ALL,10).Expand().GetFlags())

        self._data_events = [wx.EVT_TEXT, wx.EVT_COMBOBOX, wx.EVT_CHECKBOX, wx.EVT_LISTBOX]

        for event in self._data_events:
            self.Bind(event, self.processEvent)

        self._displayValid = False

        self.SetSizerAndFit(sizer)
        self.Layout()

    def processEvent(self, evt):
        # if the display has finished updating from a selection event
        if self._displayValid:
            event = InfoEvent(etEVT_INFO, self.GetId())
            self.GetEventHandler().ProcessEvent(event)

    def disableAllControls(self):
        for control in self._controls:
            control.Enable(False)

    def enableAllControls(self):
        for control in self._controls:
            control.Enable(True)

    def clearInfo(self):
        self._nameBox.Value = ''
        self._gdsBox.Value = ''
        self._patternDrop.Select(0)
        self._styleDrop.Select(0)
        self._visibleCB.Value = False
        self._cloakCB.Value = False
        self.disableAllControls()

    def updatePatterns(self, patterns=None):
        if patterns is None:
            self._patternDrop.Clear()
            self._patternNames = []
            self._patternDrop.Append(_no_fill_text)
            self._patternNames.append(_no_fill_text)

        else:
            for pattern in patterns:
                if pattern.name not in self._patternNames:
                    self._patternNames.append(pattern.name)
                    string = str(self._patternDrop.Count - 1) + ': ' + pattern.name
                    self._patternDrop.Append(string)

    def updateInfo(self, data):
        layers = data[0]
        scales = data[1]
        self._displayValid = False

        # displaying info for only one layer
        if len(layers) == 1:
            layer = layers[0]
            scale = scales[0]
            self._nameBox.Value = layer.name
            self._gdsBox.Value = str(layer.gds)
            self._scaleBox.Value = str(scale)

            # add the pattern to the main list if it isn't already
            if layer.pattern is not None:
                if layer.pattern.name not in self._patternNames:
                    event = LayerEvent(etEVT_PATTERN, self.GetId(), layer.pattern)
                    self.GetEventHandler().ProcessEvent(event)

                # at this point, the pattern should exist in the drop down
                # offset index of pattern in name list by +1 since the drop-down also has an entry for pattern = None at index 0
                self._patternDrop.Select(self._patternNames.index(layer.pattern.name))
            else:
                self._patternDrop.Value = _no_fill_text

            if layer.style is not None:
                self._styleDrop.Select(layer.style.value + 1)
            else:
                self._styleDrop.Value = _no_outline_text

            self._visibleCB.Value = layer.visible
            self._cloakCB.Value = layer.cloak

            for binding in layer.binding:
                self._bindingLB.Select(self._bindingLB.FindString(binding.name))

            self.enableAllControls()

        # displaying info for multiple layers
        else:
            self._nameBox.Value = "Multiple Selections"
            self._nameBox.Enable(False)
            self._gdsBox.Value = "***"
            self._gdsBox.Enable(False)

            self._bindingLB.DeselectAll()

            # determine if layers have the same scale or not
            scale = scales[0]
            sameScale = True
            for s in scales[1:]:
                if not s == scale:
                    sameScale = False

            # show mutual scaling factor, or display '***' if differing
            if sameScale:
                self._scaleBox.Value = str(scale)
            else:
                self._scaleBox.Value = '***'

            # determine if layers are all of the same pattern or not
            pattern = layers[0].pattern
            samePattern = True
            for layer in layers[1:]:
                if not pattern == layer.pattern:
                    samePattern = False

            # show mutual pattern or leave blank if different between selection
            if samePattern and pattern is not None:

                # add the pattern to the main list if it isn't already
                if layer.pattern is not None:
                    if layer.pattern.name not in self._patternDrop.Items:
                        event = LayerEvent(etEVT_PATTERN, self.GetId(), layer.pattern)
                        self.GetEventHandler().ProcessEvent(event)

                self._patternDrop.Select(self._patternNames.index(pattern.name))

            elif not samePattern:
                self._patternDrop.Value = ""

            # determine if layers are all of the same style or not
            style = layers[0].style
            sameStyle = True
            for layer in layers[1:]:
                if not style == layer.style:
                    sameStyle = False

            # show mutual style or leave blank if different between selection
            if sameStyle and style is not None:
                self._styleDrop.Select(style.value)
            else:
                self._styleDrop.Value = ""

            # determine if layers are all of the same default visibility or not
            visible = layers[0].visible
            sameVis = True
            for layer in layers[1:]:
                if not visible == layer.visible:
                    sameVis = False
            # show mutual default visibility or leave undetermined if different between selection
            if sameVis:
                self._visibleCB.Value = visible
            else:
                self._visibleCB.Set3StateValue(wx.CHK_UNDETERMINED)

            # determine if layers are all of the same default cloaking or not
            cloak = layers[0].cloak
            sameClk = True
            for layer in layers[1:]:
                if not cloak == layer.cloak:
                    sameClk = False

            # show mutual default cloaking or leave undetermined if different between selection
            if sameClk:
                self._cloakCB.Value = cloak
            else:
                self._cloakCB.Set3StateValue(wx.CHK_UNDETERMINED)

        self._displayValid = True

    def updateBindingLayers(self, layers):
        self._bindingLB.Clear()

        for layer in layers:
            self._bindingLB.Append(layer.name)

    @property
    def LayerName(self):
        return self._nameBox.Value

    @property
    def LayerGDS(self):
        value = self._gdsBox.Value
        if not value == '':
            return int(self._gdsBox.Value)
        else:
            return 0

    @property
    def LayerScale(self):
        value = self._scaleBox.Value
        if value == '***':
            return None
        if not value == '':
            return float(self._scaleBox.Value)
        else:
            return 1.0

    @property 
    def LayerPattern(self):
        value = self._patternDrop.Value 
        if value == _no_fill_text:
            return None
        else:
            match = re.match(r'\d+: (.+)', self._patternDrop.Value)
            if match:
                if match.group(1):
                    return match.group(1)
            else:
                return ''

    @property
    def LayerStyle(self):
        value = self._styleDrop.Value
        if value == _no_outline_text:
            return None
        else:
            try:
                return LineStyle[self._styleDrop.Value]
            except:
                return ''

    @property
    def LayerVisible(self):
        return self._visibleCB.Value

    @property
    def LayerCloak(self):
        return self._cloakCB.Value
    
    @property
    def LayerBindings(self):
        return self._bindingLB.Selections

class LCTLayerListPanel(wx.Panel):
    """
    Panel that contains a listbox of all layers in this configuration
    """
    def __init__(self, *args, **kwargs):
        super(LCTLayerListPanel, self).__init__(*args, **kwargs)
        self.initUI()

    def initData(self, layers):
        self._listbox.Clear()

        for layer in layers:
            str = '[ ] ' + layer.name
            self._listbox.Append(str)

    def initUI(self, *args, **kwargs):
        self._label = wx.StaticText(self, label="Layer List")

        self._listbox = wx.ListBox(self, size=(200, 600), style=wx.LB_EXTENDED)
        
        self._addButton = wx.Button(self, size=(30, 30), label="+")
        self._removeButton = wx.Button(self, size=(30, 30), label="-")
        self._upButton = wx.Button(self, size=(30, 30), label=u'\u2191')
        self._topButton = wx.Button(self, size=(30, 30), label=u'\u21c8')
        self._downButton = wx.Button(self, size=(30, 30), label=u'\u2193')
        self._botButton = wx.Button(self, size=(30, 30), label=u'\u21ca')

        mainSizer = wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add(self._label       , flag=wx.SizerFlags(1).Expand().Border(wx.ALL, 50).GetFlags())
        mainSizer.Add(self._listbox     , flag=wx.SizerFlags(1).Expand().Border(wx.ALL, 50).GetFlags())

        buttonSizer = wx.BoxSizer(wx.HORIZONTAL)
        buttonSizer.AddStretchSpacer()
        buttonSizer.Add(self._addButton   , flag=wx.SizerFlags(0).Align(wx.CENTER).GetFlags())
        buttonSizer.Add(self._removeButton, flag=wx.SizerFlags(0).Align(wx.CENTER).GetFlags())
        buttonSizer.Add(self._topButton   , flag=wx.SizerFlags(0).Align(wx.CENTER).GetFlags())
        buttonSizer.Add(self._upButton    , flag=wx.SizerFlags(0).Align(wx.CENTER).GetFlags())
        buttonSizer.Add(self._downButton  , flag=wx.SizerFlags(0).Align(wx.CENTER).GetFlags())
        buttonSizer.Add(self._botButton   , flag=wx.SizerFlags(0).Align(wx.CENTER).GetFlags())
        buttonSizer.AddStretchSpacer()

        mainSizer.Add(buttonSizer, flag=wx.SizerFlags(0).Align(wx.Center).Expand().GetFlags())

        self.SetSizerAndFit(mainSizer)
        self.Layout()

        self.CreateContextMenus()

        self.Bind(wx.EVT_LISTBOX, self.processSelect)
        self.Bind(wx.EVT_LISTBOX_DCLICK, self.TogglePreviewLayers)

        self.Bind(wx.EVT_CONTEXT_MENU, self.ShowPopupMenu)

        self.Bind(wx.EVT_BUTTON, self.InsertLayerAbove, self._addButton)
        self.Bind(wx.EVT_BUTTON, self.RemoveLayers, self._removeButton)
        self.Bind(wx.EVT_BUTTON, self.MoveLayerToTop, self._topButton)
        self.Bind(wx.EVT_BUTTON, self.MoveLayerUp, self._upButton)
        self.Bind(wx.EVT_BUTTON, self.MoveLayerDown, self._downButton)
        self.Bind(wx.EVT_BUTTON, self.MoveLayerToBot, self._botButton)

    def processSelect(self, evt=None):
        if self._listbox.Selections:
            event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.SELECT, self._listbox.Selections)
        else:
            event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.SELECT, None)

        self.GetEventHandler().ProcessEvent(event)

    def processDisplay(self):
        indices = []
        for idx, item in enumerate(self._listbox.Items):
            if item[0:3] == '[*]':
                indices.append(idx)

        event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.DISPLAY, indices)
        self.GetEventHandler().ProcessEvent(event)

    def CreateContextMenus(self):
        # Create menu used for when no layers are selected
        self._empty_menu = wx.Menu()
        self._empty_menu_add_layer_item = self._empty_menu.Append(wx.ID_ANY, 'Add Layer')

        self.Bind(wx.EVT_MENU, self.AddLayerToEnd, self._empty_menu_add_layer_item)

        # Create menu used for when a single layer is selected
        self._single_sel_menu = wx.Menu()
        self._single_sel_menu_add_layer_to_top_item = self._single_sel_menu.Append(wx.ID_ANY, 'Add New Layer to Top')
        self._single_sel_menu_insert_layer_above_item = self._single_sel_menu.Append(wx.ID_ANY, 'Insert New Layer Above')
        self._single_sel_menu_insert_layer_below_item = self._single_sel_menu.Append(wx.ID_ANY, 'Insert New Layer Below')
        self._single_sel_menu_add_layer_to_bot_item = self._single_sel_menu.Append(wx.ID_ANY, 'Add New Layer to Bottom')
        self._single_sel_menu.AppendSeparator()
        self._single_sel_menu_remove_layer_item = self._single_sel_menu.Append(wx.ID_ANY, 'Remove Layer')
        self._single_sel_menu.AppendSeparator()
        self._single_sel_menu_move_layer_top_item = self._single_sel_menu.Append(wx.ID_ANY, 'Move Layer to Top')
        self._single_sel_menu_move_layer_up_item = self._single_sel_menu.Append(wx.ID_ANY, 'Move Layer Up')
        self._single_sel_menu_move_layer_down_item = self._single_sel_menu.Append(wx.ID_ANY, 'Move Layer Down')
        self._single_sel_menu_move_layer_bot_item = self._single_sel_menu.Append(wx.ID_ANY, 'Move Layer to Bottom')
        self._single_sel_menu.AppendSeparator()
        self._single_sel_menu_preview_layer_item = self._single_sel_menu.Append(wx.ID_ANY, 'Toggle Layer Preview')

        self.Bind(wx.EVT_MENU, self.AddLayerToBeginning, self._single_sel_menu_add_layer_to_top_item)
        self.Bind(wx.EVT_MENU, self.InsertLayerAbove, self._single_sel_menu_insert_layer_above_item)
        self.Bind(wx.EVT_MENU, self.InsertLayerBelow, self._single_sel_menu_insert_layer_below_item)
        self.Bind(wx.EVT_MENU, self.AddLayerToEnd, self._single_sel_menu_add_layer_to_bot_item)

        self.Bind(wx.EVT_MENU, self.RemoveLayers, self._single_sel_menu_remove_layer_item)

        self.Bind(wx.EVT_MENU, self.MoveLayerToTop, self._single_sel_menu_move_layer_top_item)
        self.Bind(wx.EVT_MENU, self.MoveLayerUp, self._single_sel_menu_move_layer_up_item)
        self.Bind(wx.EVT_MENU, self.MoveLayerDown, self._single_sel_menu_move_layer_down_item)
        self.Bind(wx.EVT_MENU, self.MoveLayerToBot, self._single_sel_menu_move_layer_bot_item)
        
        self.Bind(wx.EVT_MENU, self.TogglePreviewLayers, self._single_sel_menu_preview_layer_item)

        # Create menu used for when multiple layers are selected
        self._multi_sel_menu = wx.Menu()
        self._multi_sel_menu_add_layer_to_top_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Add New Layer to Top')
        self._multi_sel_menu_insert_layer_above_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Insert New Layer Above')
        self._multi_sel_menu_insert_layer_below_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Insert New Layer Below')
        self._multi_sel_menu_add_layer_to_bot_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Add New Layer to Bottom')
        self._multi_sel_menu.AppendSeparator()
        self._multi_sel_menu_remove_layers_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Remove Layers')
        self._multi_sel_menu.AppendSeparator()
        self._multi_sel_menu_move_layers_top_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Move Layers to Top')
        self._multi_sel_menu_move_layers_up_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Move Layers Up')
        self._multi_sel_menu_move_layers_down_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Move Layers Down')
        self._multi_sel_menu_move_layers_bot_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Move Layers to Bottom')
        self._multi_sel_menu.AppendSeparator()
        self._multi_sel_menu_toggle_preview_layers_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Toggle Layer Preview')
        self._multi_sel_menu_enable_preview_layers_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Enable Layer Preview')
        self._multi_sel_menu_disable_preview_layers_item = self._multi_sel_menu.Append(wx.ID_ANY, 'Disable Layer Preview')

        self.Bind(wx.EVT_MENU, self.AddLayerToBeginning, self._multi_sel_menu_add_layer_to_top_item)
        self.Bind(wx.EVT_MENU, self.InsertLayerAbove, self._multi_sel_menu_insert_layer_above_item)
        self.Bind(wx.EVT_MENU, self.InsertLayerBelow, self._multi_sel_menu_insert_layer_below_item)
        self.Bind(wx.EVT_MENU, self.AddLayerToEnd, self._multi_sel_menu_add_layer_to_bot_item)

        self.Bind(wx.EVT_MENU, self.RemoveLayers, self._multi_sel_menu_remove_layers_item)

        self.Bind(wx.EVT_MENU, self.MoveLayerToTop, self._multi_sel_menu_move_layers_top_item)
        self.Bind(wx.EVT_MENU, self.MoveLayerUp, self._multi_sel_menu_move_layers_up_item)
        self.Bind(wx.EVT_MENU, self.MoveLayerDown, self._multi_sel_menu_move_layers_down_item)
        self.Bind(wx.EVT_MENU, self.MoveLayerToBot, self._multi_sel_menu_move_layers_bot_item)
        
        self.Bind(wx.EVT_MENU, self.TogglePreviewLayers, self._multi_sel_menu_toggle_preview_layers_item)
        self.Bind(wx.EVT_MENU, self.EnablePreviewLayers, self._multi_sel_menu_enable_preview_layers_item)
        self.Bind(wx.EVT_MENU, self.DisablePreviewLayers, self._multi_sel_menu_disable_preview_layers_item)

    def ShowPopupMenu(self, evt):
        pos = self.ScreenToClient(wx.GetMousePosition())

        if not len(self._listbox.Selections):
            self.PopupMenu(self._empty_menu, pos)
        elif len(self._listbox.Selections) == 1:
            self.PopupMenu(self._single_sel_menu, pos)
        else:
            self.PopupMenu(self._multi_sel_menu, pos)

    def GetNextLayerNumber(self):
        name = 'Layer '
        number = 1
        string = name + str(number)

        # ensure no duplicates
        # strip first 4 characters of listbox item to get actual layer name
        while string in [x[4:] for x in self._listbox.Items]:
            number += 1
            string = name + str(number)

        return number

    def ChangeLayerName(self, idx, name):
        display = self._listbox.Items[idx][:4]
        self._listbox.Delete(idx)
        self._listbox.Insert(display + name, idx)

    def ProcessLayerMove(self, indices):
        event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.MOVE, indices)
        self.GetEventHandler().ProcessEvent(event)

    def AddLayerToBeginning(self, evt):
        name = 'Layer ' + str(self.GetNextLayerNumber())
        self._listbox.Insert('[ ] ' + name, 0)
        event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.INSERT, (name, 0))
        self.GetEventHandler().ProcessEvent(event)

    def InsertLayerAbove(self, evt):
        if not self._listbox.Count or not self._listbox.Selections:
            self.AddLayerToEnd(None)

        elif self._listbox.Selections:
            idx = self._listbox.Selections[0]
            name = 'Layer ' + str(self.GetNextLayerNumber())
            self._listbox.Insert('[ ] ' + name, idx)
            event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.INSERT, (name, idx))
            self.GetEventHandler().ProcessEvent(event)

    def InsertLayerBelow(self, evt):
        if self._listbox.Selections:
            idx = self._listbox.Selections[-1]
            if idx == self._listbox.Count - 1:
                self.AddLayerToEnd(None)
            else:
                name = 'Layer ' + str(self.GetNextLayerNumber())
                self._listbox.Insert('[ ] ' + name, idx + 1)
                event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.INSERT, (name, idx + 1))
                self.GetEventHandler().ProcessEvent(event)

    def AddLayerToEnd(self, evt):
        name = 'Layer ' + str(self.GetNextLayerNumber())
        self._listbox.Append('[ ] ' + name)
        event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.INSERT, (name, -1))
        self.GetEventHandler().ProcessEvent(event)

    def RemoveLayers(self, evt):
        if self._listbox.Count:
            if self._listbox.Selections:
                selections = [x for x in self._listbox.Selections]
                selIdx = max(self._listbox.Selections[0] - 1, 0)

                for idx in reversed(self._listbox.Selections):
                    self._listbox.Delete(idx)

                if self._listbox.Count:
                    self._listbox.Select(selIdx)

                event = LayerEvent(etEVT_LAYER, self.GetId(), LayerEventType.REMOVE, eventValue=selections)
                self.GetEventHandler().ProcessEvent(event)

                self.processSelect(None)

    def MoveLayerToTop(self, evt):
        indices = None

        if self._listbox.Selections:
            # for a single selection
            if len(self._listbox.Selections) == 1:
                idx = self._listbox.Selections[0]
                if idx is not 0:
                    prevItems = [x for x in self._listbox.Items[0:idx]]
                    prevIndices = range(0,idx)
                    curItem = [self._listbox.Items[idx]]
                    nextItems = [x for x in self._listbox.Items[idx+1:]]
                    nextIndices = range(idx+1, self._listbox.Count)
                    self._listbox.SetItems(curItem + prevItems + nextItems)
                    self._listbox.Select(0)
                    indices = [idx] + prevIndices + nextIndices

            # for multiple selections
            else:
                list = [ ]
                indices = [ ]
                original_list = [x for x in range(0, self._listbox.Count)]
                selections = [x for x in self._listbox.Selections]

                for i in selections:
                    list.append(self._listbox.Items[i])
                    indices.append(i)
                    original_list.remove(i)

                for i in original_list:
                    list.append(self._listbox.Items[i])
                    indices.append(i)

                self._listbox.SetItems(list)

                for i in range(0, len(selections)):
                    self._listbox.Select(i)

            if indices is None:
                indices = range(0, self._listbox.Count)
            
            self.ProcessLayerMove(indices)
            self.processSelect()

    def MoveLayerUp(self, evt):
        indices = None

        if self._listbox.Selections:

            # for a single selection
            if len(self._listbox.Selections) == 1:
                idx = self._listbox.Selections[0]
                if idx is not 0:
                    prevItems = [x for x in self._listbox.Items[0:idx-1]]
                    prevIndices = range(0, idx-1)
                    prevItem = [self._listbox.Items[idx - 1]]
                    curItem = [self._listbox.Items[idx]]
                    nextItems = [x for x in self._listbox.Items[idx+1:]]
                    nextIndices = range(idx+1, self._listbox.Count)
                    self._listbox.SetItems(prevItems + curItem + prevItem + nextItems)
                    self._listbox.SetSelection(idx - 1)
                    indices = prevIndices + [idx] + [idx-1] + nextIndices

            # for multiple selections
            else:
                if self._listbox.Selections[0] is not 0:
                    list = [ ]
                    indices = [ ]
                    original_list = [x for x in range(0, self._listbox.Count)]
                    selections_moved = [x - 1 for x in self._listbox.Selections]

                    for i in range(0, self._listbox.Count):
                        if i in selections_moved:
                            list.append(self._listbox.Items[i + 1])
                            indices.append(i + 1)
                            original_list.remove(i + 1)
                        else:
                            list.append(self._listbox.Items[original_list[0]])
                            indices.append(original_list[0])
                            original_list.pop(0)

                    self._listbox.SetItems(list)
                    for i in selections_moved:
                        self._listbox.SetSelection(i)

            if indices is None:
                indices = range(0, self._listbox.Count)
            self.ProcessLayerMove(indices)
            self.processSelect()

    def MoveLayerDown(self, evt):
        indices = None

        if self._listbox.Selections:

            # for a single selection
            if len(self._listbox.Selections) == 1:
                idx = self._listbox.Selections[0]
                if idx is not (self._listbox.Count - 1):
                    prevItems = [x for x in self._listbox.Items[0:idx]]
                    prevIndices = range(0, idx)
                    curItem = [self._listbox.Items[idx]]
                    nextItem = [self._listbox.Items[idx + 1]]
                    nextItems = [x for x in self._listbox.Items[idx+2:]]
                    nextIndices = range(idx+2, self._listbox.Count)
                    self._listbox.SetItems(prevItems + nextItem + curItem + nextItems)
                    self._listbox.SetSelection(idx + 1)
                    indices = prevIndices + [idx+1] + [idx] + nextIndices

            # for multiple selections
            else:
                if self._listbox.Selections[-1] is not self._listbox.Count - 1:
                    list = [ ]
                    indices = [ ]
                    original_list = [x for x in range(0, self._listbox.Count)]
                    selections_moved = [x + 1 for x in self._listbox.Selections]

                    for i in reversed(range(0, self._listbox.Count)):
                        if i in selections_moved:
                            list.insert(0, self._listbox.Items[i - 1])
                            indices.insert(0, i - 1)
                            original_list.pop(i - 1)
                        else:
                            list.insert(0, self._listbox.Items[original_list[-1]])
                            indices.insert(0, original_list[-1])
                            original_list.pop()


                    self._listbox.SetItems(list)
                    
                    for i in selections_moved:
                        self._listbox.Select(i)
            
            if indices is None:
                indices = range(0, self._listbox.Count)

            self.ProcessLayerMove(indices)
            self.processSelect()

    def MoveLayerToBot(self, evt):
        indices = None

        if self._listbox.Selections:

            # for a single selection
            if len(self._listbox.Selections) == 1:
                idx = self._listbox.Selections[0]
                if idx is not 0:
                    prevItems = [x for x in self._listbox.Items[0:idx]]
                    prevIndices = range(0, idx)
                    curItem = [self._listbox.Items[idx]]
                    nextItems = [x for x in self._listbox.Items[idx+1:]]
                    nextIndices = range(idx+1, self._listbox.Count)
                    self._listbox.SetItems(prevItems + nextItems + curItem)
                    self._listbox.SetSelection(self._listbox.Count - 1)
                    indices = prevIndices + nextIndices + [idx]

            # for multiple selections
            else:
                list = [ ]
                indices = [ ]
                original_list = [x for x in range(0, self._listbox.Count)]
                selections = [x for x in self._listbox.Selections]

                for i in selections:
                    list.append(self._listbox.Items[i])
                    indices.append(i)
                    original_list.remove(i)

                for i in reversed(original_list):
                    list.insert(0, self._listbox.Items[i])
                    indices.insert(0, i)

                self._listbox.SetItems(list)

                for i in range(0, len(selections)):
                    self._listbox.Select(self._listbox.Count - 1 - i)

            if indices is None:
                indices = range(0, self._listbox.Count)

            self.ProcessLayerMove(indices)
            self.processSelect()

    def TogglePreviewLayers(self, evt):
        if self._listbox.Selections:
            list = [x for x in self._listbox.Items]
            selections = [x for x in self._listbox.Selections]
            for i in selections:
                name = self._listbox.Items[i][3:]
                if list[i][0:3] == '[ ]':
                    list[i] = '[*]' + name
                elif list[i][0:3] == '[*]':
                    list[i] = '[ ]' + name

            self._listbox.SetItems(list)
            for i in selections:
                self._listbox.Select(i)

            self.processDisplay()

    def EnablePreviewLayers(self, evt):
        if self._listbox.Selections:
            list = [x for x in self._listbox.Items]
            selections = [x for x in self._listbox.Selections]
            for i in selections:
                list[i] = '[*]' + self._listbox.Items[i][3:]

            self._listbox.SetItems(list)
            for i in selections:
                self._listbox.Select(i)

            self.processDisplay()

    def DisablePreviewLayers(self, evt):
        if self._listbox.Selections:
            list = [x for x in self._listbox.Items]
            selections = [x for x in self._listbox.Selections]
            for i in selections:
                list[i] = '[ ]' + self._listbox.Items[i][3:]

            self._listbox.SetItems(list)
            for i in selections:
                self._listbox.Select(i)

            self.processDisplay()

class LCTChooser(CCD.PyColorChooser):
    """
    Color Chooser panel that sends an event whenever its color is changed
    """

    def __init__(self, *args, **kwargs):
        super(LCTChooser, self).__init__(*args, **kwargs)
        self._valid = True

        self.Bind(wx.EVT_TEXT, self.UpdateFromText)

    def UpdateEntries(self, colour):
        self._valid = False
        super(LCTChooser, self).UpdateEntries(colour)
        event = wx.PyCommandEvent(wx.EVT_COLOURPICKER_CHANGED.typeId, self.GetId())
        wx.PostEvent(self.GetEventHandler(), event)
        self._valid = True

    def UpdateFromText(self, evt):

        if self._valid:
            if not self.rentry.Value == '' and not self.gentry.Value == '' and not self.bentry.Value == '' \
            and not self.hentry.Value == '' and not self.sentry.Value == '' and not self.ventry.Value == '':

                self._valid = False

                try:
                    if evt.GetEventObject() in [self.rentry, self.gentry, self.bentry]:
                        r = max(0, min(int(float(self.rentry.Value)), 255))
                        g = max(0, min(int(float(self.gentry.Value)), 255))
                        b = max(0, min(int(float(self.bentry.Value)), 255))

                    elif evt.GetEventObject() in [self.hentry, self.sentry, self.ventry]:
                        r, g, b = colorsys.hsv_to_rgb(  max(0.0, min(float(self.hentry.Value), 255.0)), \
                                                        max(0.0, min(float(self.sentry.Value), 255.0)), \
                                                        max(0.0, min(float(self.ventry.Value), 255.0)))

                except ValueError:
                    r, g, b = 0, 0, 0

                self.SetValue(wx.Colour(r, g, b))

class LCTFrame(wx.Frame):
    
    def __init__(self, *args, **kwargs):
        patfile = kwargs.pop('pattern_file', None)
        super(LCTFrame, self).__init__(*args, **kwargs)
        self.initData(patfile)
        self.InitUI()
    
    def initData(self, patfile = None):
        self._selection = None
        self._display = None
        self._layerList = [ ]
        self._scaleList = [ ]

        if patfile is not None:
            fp = open(patfile, 'rb')
            self._patternList = cPickle.load(fp)
            fp.close()
        else:
            self._patternList = [ None ]
        
    def InitUI(self):
        
        menubar = wx.MenuBar()
        
        fileMenu = wx.Menu()
        
        self._omi = wx.MenuItem(fileMenu, wx.ID_OPEN, '&Load Layer Configuration\tCtrl+O')
        self._smi = wx.MenuItem(fileMenu, wx.ID_SAVE, '&Save Layer Configuration\tCtrl+S')
        self._imi = wx.MenuItem(fileMenu, wx.ID_NONE, '&Import ADS Layer Pattern File(s)\tCtrl+I')
        self._qmi = wx.MenuItem(fileMenu, wx.ID_EXIT, '&Quit\tCtrl+W')
        fileMenu.AppendItem(self._omi)
        fileMenu.AppendItem(self._smi)
        fileMenu.AppendItem(self._imi)
        fileMenu.AppendItem(self._qmi)

        self._smi.Enable(False)
        
        menubar.Append(fileMenu, '&File')
        self.SetMenuBar(menubar)
        
        self.SetSize(wx.Size(1000,800))
        self.SetTitle('Layer Configuration Tool')
        
        # splitter windows for basic panel layout
        self.splitter = MultiSplitterWindow(self)

        # set up left-side panel
        self.leftPanel = wx.Panel(self.splitter)
        self.layerPanel = LCTLayerListPanel(self.leftPanel, style=wx.RAISED_BORDER)
        self.controlPanel = LCTControlPanel(self.leftPanel, size=(250, 200), style=wx.RAISED_BORDER)

        leftSizer = wx.BoxSizer(wx.VERTICAL)
        leftSizer.Add(self.layerPanel, flag=wx.SizerFlags(1).Expand().GetFlags())
        leftSizer.Add(self.controlPanel, flag=wx.SizerFlags(1).Expand().GetFlags())
        self.leftPanel.SetSizerAndFit(leftSizer)
        self.leftPanel.Layout()

        # set up right panel
        self.rightPanel = wx.Panel(self.splitter)
        self.infoPanel = LCTInfoPanel(self.rightPanel, style=wx.BORDER_RAISED)
        self.colorPanel = LCTChooser(self.rightPanel, wx.ID_ANY)
        self.dispPanel = LCTDispPanel(self.rightPanel, style=wx.RAISED_BORDER)

        rightSizer = wx.BoxSizer(wx.VERTICAL)
        rightSizer.Add(self.infoPanel, 1, flag=wx.SizerFlags(0).Expand().GetFlags())
        rightSizer.Add(self.colorPanel, 0, flag=wx.SizerFlags(0).Expand().GetFlags())
        rightSizer.AddSpacer(50)
        rightSizer.Add(self.dispPanel, 0, flag=wx.SizerFlags(0).Expand().GetFlags())
        rightSizer.SetSizeHints(self.rightPanel)
        self.rightPanel.SetSizerAndFit(rightSizer)
        self.rightPanel.Layout()

        self.splitter.AppendWindow(self.leftPanel)
        self.splitter.AppendWindow(self.rightPanel)

        self.splitter.SetSashPosition(0, self.splitter.GetWindow(0).MinSize[0])
        
        self.Bind(wx.EVT_MENU, self.OnOpenConfig, self._omi)
        self.Bind(wx.EVT_MENU, self.OnSaveConfig, self._smi)
        self.Bind(wx.EVT_MENU, self.OnImportADSPatFile, self._imi)
        self.Bind(wx.EVT_MENU, self.OnQuit, self._qmi)
        self.Bind(wx.EVT_SIZE, self.OnResize)
        self.Bind(wx.EVT_COLOURPICKER_CHANGED, self.OnColorChange)

        self.Bind(wx.EVT_BUTTON, self.ProcessButtonEvent)

        self.Bind(EVT_LAYER, self.processLayerList)
        
        self.Bind(EVT_INFO, self.UpdateInfo)
        
        self.SetClientSize(self.splitter.GetEffectiveMinSize())

        if _debug:
            wx.lib.inspection.InspectionTool().Show()

        self.infoPanel.updatePatterns(self._patternList)
        self.Show(True)
        
    def OnResize(self, e):
        e.Skip()
        
    def OnQuit(self, e):
        self.Close()

    def ProcessButtonEvent(self, evt):
        if evt.GetString() == 'SaveADSConf':
            self.SaveADSConf()
        elif evt.GetString() == 'SaveAWRLPF':
            self.SaveAWRLPF()
        elif evt.GetString() == 'SaveKLayoutLYP':
            self.SaveKLayoutLYP()

    def OnColorChange(self, evt):
        if self._selection:
            for i in self._selection:
                self._layerList[i].color = self.colorPanel.GetValue().GetRGB()

        self.UpdateDisplay()

    def OnImportADSPatFile(self, evt):
        "callback for when the 'Import ADS Pattern Files' control is triggered"
        kw = {'style':wx.FD_MULTIPLE | wx.FD_OPEN,'wildcard':"ADS Pattern Files (*.pattern)|*.pattern"}
        dlg = wx.FileDialog(self,'Import ADS Pattern File(s)',**kw)

        if dlg.ShowModal() == wx.ID_OK:
            filepaths = dlg.GetPaths()
            for path in filepaths:
                pat = Pattern(path)
                self._patternList.append(pat)
                self.infoPanel.updatePatterns([pat])

        dlg.Destroy()

    def SaveADSConf(self):
        "callback for saving the current configuration to a file"
        kw = {'style':wx.FD_SAVE,'wildcard':"ADS Layer Configuration File (*.lay)|*.lay"}
        dlg = wx.FileDialog(self,'Save ADS Layer Configuration',**kw)

        if dlg.ShowModal() == wx.ID_OK:
            filepath = dlg.GetPath()

            # reverse ADS layer list to ensure correct order
            write_ads_config(filepath, list(reversed(self._layerList)), self._patternList)
        dlg.Destroy()

    def SaveAWRLPF(self):
        "callback for saving the current configuration to a file"
        kw = {'style':wx.FD_SAVE,'wildcard':"AWR Layer Configuration File (*.lpf)|*.lpf"}
        dlg = wx.FileDialog(self,'Save AWR Layer Configuration',**kw)

        if dlg.ShowModal() == wx.ID_OK:
            filepath = dlg.GetPath()
            write_awr_lpf(filepath, self._layerList)
        dlg.Destroy()

    def SaveKLayoutLYP(self):
        "callback for saving the current configuration to a file"
        kw = {'style':wx.FD_SAVE,'wildcard':"KLayout Layer Preferences File (*.lyp)|*.lyp"}
        dlg = wx.FileDialog(self,'Save KLayout Layer Preferences',**kw)

        if dlg.ShowModal() == wx.ID_OK:
            filepath = dlg.GetPath()
            write_klayout_layer_prefs_file(filepath, self._layerList)
        dlg.Destroy()

    def OnSaveConfig(self, evt):
        "callback for saving the current configuration to a file"
        kw = {'style':wx.FD_SAVE,'wildcard':"Layer Configuration Files (*.layercfg)|*.layercfg"}
        dlg = wx.FileDialog(self,'Save Layer Configuration',**kw)

        if dlg.ShowModal() == wx.ID_OK:
            filepath = dlg.GetPath()
            file = open(filepath, 'wb')
            data = (self._layerList, self._scaleList, self._patternList)
            cPickle.dump(data, file)
            file.close()
        dlg.Destroy()

    def OnOpenConfig(self, evt):
        "callback for loading a configuration from a file"
        kw = {'style':wx.FD_OPEN,'wildcard':"Layer Configuration Files (*.layercfg)|*.layercfg"}
        dlg = wx.FileDialog(self,'Open Layer Configuration',**kw)

        if dlg.ShowModal() == wx.ID_OK:
            filepath = dlg.GetPath()
            file = open(filepath, 'rb')
            data = cPickle.load(file)
            file.close()
            self.LoadConfiguration(data)
        dlg.Destroy()

    def LoadConfiguration(self, data):
        """
        Loads a layer configuration from the input data

        The single argument 'data' should be a 3-tuple containing a list of the layers, the scales, and patterns ([Layer], [float], [Pattern])

        The length of the layer list and the scale list should be identical.
        """

        self.initData()

        layers = data[0]
        scales = data[1]
        patterns = data[2]

        if not len(layers) == len(scales):
            raise ValueError('Invalid data loaded, skipping load')
            return

        self.infoPanel.clearInfo()
        self.dispPanel.updateData(None)
        self.infoPanel.updatePatterns(None)

        del self._layerList
        del self._scaleList
        del self._patternList

        self._layerList = layers
        self._scaleList = scales
        self._patternList = patterns

        self.layerPanel.initData(layers)
        self.infoPanel.updatePatterns(patterns)
        self._smi.Enable(True)
        
    def AddPattern(self, pattern):
        if isinstance(pattern, Pattern):
            if pattern not in self._patternList:
                self._patternList.append(pattern)

    def selectLayers(self):
        if self._selection == None:
            self.infoPanel.clearInfo()
            self.colorPanel.SetValue(wx.Colour(0, 0, 0))
        else:
            self.infoPanel.updateBindingLayers(self._layerList)
            self.infoPanel.updateInfo(([self._layerList[i] for i in self._selection], [self._scaleList[i] for i in self._selection]))
            if len(self._selection) == 1:
                layer = self._layerList[self._selection[0]]
                self.colorPanel.SetValue(wx.Colour(layer.red, layer.green, layer.blue))

    def processLayerList(self, evt):
        # add layer to list
        if evt.eventType == LayerEventType.INSERT:
            layer = Layer(name=evt.eventValue[0])
            if evt.eventValue[1] == -1:
                self._layerList.append(layer)
            else:
                self._layerList.insert(evt.eventValue[1], layer)
            
            self._scaleList.append(1)

            if not self._smi.IsEnabled():
                self._smi.Enable(True)

        # remove layer(s) from list
        elif evt.eventType == LayerEventType.REMOVE:
            for idx in reversed(evt.eventValue):
                self._layerList.pop(idx)
                self._scaleList.pop(idx)

            if not self._layerList:
                self._smi.Enable(False)
        
        # update layer order in list
        elif evt.eventType == LayerEventType.MOVE:
            indices = evt.eventValue
            new_layer_list = [ ]
            new_scale_list = [ ]

            for i in indices:
                new_layer_list.append(self._layerList[i])
                new_scale_list.append(self._scaleList[i])

            del self._layerList
            del self._scaleList

            self._layerList = new_layer_list
            self._scaleList = new_scale_list

        # update layer display pane
        elif evt.eventType == LayerEventType.DISPLAY:
            self._display = evt.eventValue
            self.UpdateDisplay()

        # update selected layers based on selection in list
        elif evt.eventType == LayerEventType.SELECT:
            self._selection = evt.eventValue
            self.selectLayers()

    def UpdateInfo(self, evt):
        # process info updates from information panel
        info = self.infoPanel

        if self._selection:
            # single layer selected
            if len(self._selection) == 1:
                self._layerList[self._selection[0]].name = info.LayerName
                self._layerList[self._selection[0]].gds = info.LayerGDS

                if info.LayerPattern == _no_fill_text:
                    self._layerList[self._selection[0]].pattern = None
                elif not info.LayerPattern == '':
                    pattern_names = [x.name for x in self._patternList]
                    if info.LayerPattern in pattern_names:
                        patternIdx = pattern_names.index(info.LayerPattern)
                        self._layerList[self._selection[0]].pattern = self._patternList[patternIdx]

                if info.LayerStyle == _no_outline_text:
                    self._layerList[self._selection[0]].style = None
                elif not info.LayerStyle == '':
                    self._layerList[self._selection[0]].style = info.LayerStyle

                self._layerList[self._selection[0]].visible = info.LayerVisible
                self._layerList[self._selection[0]].cloak = info.LayerCloak

                self._layerList[self._selection[0]].binding = [self._layerList[x] for x in info.LayerBindings]

                if info.LayerScale is not None:
                    self._scaleList[self._selection[0]] = info.LayerScale

                self.layerPanel.ChangeLayerName(self._selection[0], info.LayerName)

            # multiple layers selected
            else:
                for i in self._selection:

                    if info.LayerPattern == _no_fill_text:
                        self._layerList[i].pattern = None
                    elif not info.LayerPattern == '':
                        pattern_names = [x.name for x in self._patternList]
                        if info.LayerPattern in pattern_names:
                            patternIdx = pattern_names.index(info.LayerPattern)
                            self._layerList[i].pattern = self._patternList[patternIdx]
                    
                    if info.LayerStyle == _no_outline_text:
                        self._layerList[i].style = None
                    elif not info.LayerStyle == '':
                        self._layerList[i].style = info.LayerStyle

                    if not info.LayerVisible == wx.CHK_UNDETERMINED:
                        self._layerList[i].visible = info.LayerVisible

                    if not info.LayerCloak == wx.CHK_UNDETERMINED:
                        self._layerList[i].cloak = info.LayerCloak

                    self._layerList[i].binding = [self._layerList[x] for x in info.LayerBindings]

                    if info.LayerScale is not None:
                        self._scaleList[i] = info.LayerScale

        self.UpdateDisplay()

    def UpdateDisplay(self):
        if self._display is not None:
            patterns = [ ]
            styles = [ ]
            colors = [ ]
            scales = [ ]

            for i in self._display:
                patterns.append(self._layerList[i].pattern)
                styles.append(self._layerList[i].style)
                colors.append(wx.Colour(self._layerList[i].red, self._layerList[i].green, self._layerList[i].blue))
                scales.append(self._scaleList[i])

            if patterns and styles and colors and scales:
                data = (patterns, styles, colors, scales)
            else:
                data = None
        else:
            data = None
        
        self.dispPanel.updateData(data)