﻿import wx
import os
from layer_config_tool.gui import LCTFrame

ex = wx.App()

# try loading default patterns from layer_config_tool library
<<<<<<< .mine
patfile = "C:\\Users\\ma099737\\modeling\\pylib\\layer_config_tool\\default_patterns.pkl"
if os.path.exists(os.getenv('PYTHONPATH') + '/layer_config_tool/default_patterns.pkl'):
    patfile = os.getenv('PYTHONPATH') + '/layer_config_tool/default_patterns.pkl'
=======
patfile = os.path.join(os.path.dirname(__file__),'default_patterns.pkl')
if not os.path.exists(patfile):
    patfile = None
>>>>>>> .r2287

#names = [ ]
#paths = [ ]
#if len(sys.argv) > 1:
#    for arg in sys.argv[1:]:
#        if os.path.isfile(arg):
#            paths.append(arg)
#            names.append(os.path.basename(arg))
frame = LCTFrame(None, pattern_file=patfile)
frame.Show()
ex.MainLoop()