﻿import sys
import types
from layer_config_tool.pattern import Pattern
from .utils import LineStyle

class Layer(object):
    """
    General object that stores all the necessary information to define a layer in both ADS and AWR

    Keywords:

    name - String defining the name of the layer
    gds - Integer defining the GDS layer number of the layer
    color - either a hex string, an Integer representing a packed RGB value, or a 3-tuple of ints representing (Red, Green, Blue)
    pattern - Pattern type that stores the layer's fill pattern (see layer_config_tool.pattern.Pattern). Set to "None" for no fill
    style - LineStyle enum that defines the bounding line style of the layer. Set to None for no outline (ADS only, AWR will revert to solid)
    visible - Boolean representing whether or not the layer is visible by default
    cloak - Boolean representing whether or not the layer is hidden from the users's view by default (AWR only, ADS always shows all layers)
    binding - List of Layers
    """

    def __init__(self, *args, **kwargs):
        "initializer"
        nam = kwargs.pop('name', "")
        num = kwargs.pop('gds', 0)
        col = kwargs.pop('color', (0, 0, 0))
        pat = kwargs.pop('pattern', Pattern())
        ls = kwargs.pop('style', None)
        vis = kwargs.pop('visible', True)
        clk = kwargs.pop('cloak', False)
        bind = kwargs.pop('binding', [])

        # check kwargs
        if not isinstance(nam, types.StringTypes):
            raise TypeError('\'name\' must be a string')

        if not isinstance(num, int):
            raise TypeError('\'gds\' must be an integer between 0-255')
        elif not 0 <= num <= 255:
            raise TypeError('\'gds\' must be an integer between 0-255')

        if not isinstance(col, (types.StringTypes, int, tuple)):
            raise TypeError('\'color\' must be hex string, an Integer representing a packed RGB value, or a 3-tuple of ints representing (Red, Green, Blue)')
        elif isinstance(col, types.StringTypes) and not int(col.lstrip('#'), 16):
            raise TypeError('Invalid color hex string')
        elif isinstance(col, tuple) and not all(isinstance(x, int) for x in col):
            raise TypeError('Invalid color RGB tuple')

        if pat is not None and not isinstance(pat, Pattern):
            raise TypeError('\'pattern\' must be of type layer_config_tool.pattern.Pattern')

        if ls is not None and not (isinstance(ls, LineStyle) or isinstance(ls, int)):
            raise TypeError('\'style\' must be a LineStyle or an int')

        if not isinstance(vis, bool): 
            raise TypeError('\'visible\' must be a boolean')

        if not isinstance(clk, bool):
            raise TypeError('\'cloak\' must be a boolean')

        if not isinstance(bind, list):
            raise TypeError('\'binding\' must be a list of Layers')
        elif isinstance(bind, list):
            if not all(isinstance(x, Layer) for x in bind):
                raise TypeError('\'binding\' must be a list of Layers')

        # update properties
        self._name = nam
        self._gds = num

        if isinstance(col, types.StringTypes):
            self._color = int(col.lstrip('#'), 16)
        elif isinstance(col, tuple):
            self._color = int("".join(map(chr, col)).encode('hex'), 16)
        elif isinstance(col, int):
            self._color = col

        self._pattern = pat
        self._style = ls
        self._visible = vis
        self._cloak = clk
        self._binding = bind

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, str):
        if not isinstance(str, types.StringTypes):
            raise TypeError('\'name\' must be a string')
        self._name = str

    @property
    def gds(self):
        return self._gds

    @gds.setter
    def gds(self, num):
        if not isinstance(num, int):
            raise TypeError('\'gds\' must be an integer between 0-255')
        elif not 0 <= num <= 255:
            raise TypeError('\'gds\' must be an integer between 0-255')
        self._gds = num

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, col):
        if not isinstance(col, (types.StringTypes, int, tuple)):
            raise TypeError('\'color\' must be hex string, an Integer representing a packed RGB value, or a 3-tuple of ints representing (Red, Green, Blue)')
        elif isinstance(col, types.StringTypes) and not int(col.lstrip('#'), 16):
            raise TypeError('Invalid color hex string')
        elif isinstance(col, tuple) and not all(isinstance(x, int) for x in col):
            raise TypeError('Invalid color RGB tuple')

        if isinstance(col, types.StringTypes):
            self._color = int(col.lstrip('#'), 16)
        elif isinstance(col, tuple):
            self._color = int("".join(map(chr, col)).encode('hex'), 16)
        elif isinstance(col, int):
            self._color = col

    @property
    def red(self):
        return self._color & 0x0000FF

    @property
    def green(self):
        return (self._color & 0x00FF00) >> 8

    @property
    def blue(self):
        return (self._color & 0xFF0000) >> 16

    @property
    def pattern(self):
        return self._pattern

    @pattern.setter
    def pattern(self, pat):
        if pat is not None:
            if not isinstance(pat, Pattern):
                raise TypeError('\'pattern\' must be of type layer_config_tool.pattern.Pattern')
            self._pattern = pat
        else:
            self._pattern = None

    @property
    def style(self):
        return self._style

    @style.setter
    def style(self, ls):
        if ls:
            if not (isinstance(ls, LineStyle) or isinstance(ls, int)):
                raise TypeError('\'style\' must be a LineStyle or an int')
            if isinstance(ls, LineStyle):
                self._style = ls
            else:
                self._style = LineStyle(ls)
        else:
            self._style = None

    @property
    def visible(self):
        return self._visible

    @visible.setter
    def visible(self, vis):
        if not isinstance(vis, bool):
            raise TypeError('\'visible\' must be a boolean')
        self._visible = vis

    @property
    def cloak(self):
        return self._cloak

    @cloak.setter
    def cloak(self, clk):
        if not isinstance(clk, bool):
            raise TypeError('\'cloak\' must be a boolean')
        self._cloak = clk

    @property
    def binding(self):
        return self._binding
    
    @binding.setter
    def binding(self, bind):
        if not isinstance(bind, list):
            raise TypeError('\'binding\' must be a list of Layers')
        elif isinstance(bind, list):
            if not all(isinstance(x, Layer) for x in bind):
                raise TypeError('\'binding\' must be a list of Layers')
        del self._binding
        self._binding = bind
