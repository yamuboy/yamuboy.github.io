﻿from __future__ import print_function

import os
import wx

from .pattern import Pattern

try:
    from enum import Enum
except ImportError as e:
    if e.message.split()[-1] == 'enum':
        print('Missing module enum. Download the \'enum34\' package.')
        raise SystemExit

# based off of AWR dash-style indicies since they are more restrictive
class LineStyle(Enum):
    Solid       = 0
    Dashed      = 1
    Dotted      = 2
    DashDot     = 3
    #DashDotDot  = 4    #this seems to just draw a solid line in AWRv12, so ignoring it...

def get_wx_penstyle(style=LineStyle.Solid):
    _pen_style_map = [
                        wx.PENSTYLE_SOLID,
                        wx.PENSTYLE_SHORT_DASH,
                        wx.PENSTYLE_DOT,
                        wx.PENSTYLE_DOT_DASH
                    ]
    if style is None:
        return wx.PENSTYLE_TRANSPARENT
    elif isinstance(style, LineStyle):
        return _pen_style_map[style.value]
    elif isinstance(style, int):
        return _pen_style_map[(style)%4]
    else:
        raise ValueError

def get_ads_linestyle(style=LineStyle.Solid):
    "Returns the numerical index of the ADS linestyle that corresponds to the given LineStyle/int"
    _ads_linestyle_map =    [
                                0,  # ADS solid linestyle
                                5,  # ADS long dash linestyle used for "Dashed"
                                3,  # ADS short dash linestyle used for "Dot"
                                4   # ADS short dash dot linestyle used for "DashDot"
                            ]   
    
    if isinstance(style, LineStyle):
        return _ads_linestyle_map[style.value]
    elif isinstance(style, int):
        return _ads_linestyle_map[(style)%4]
    else:
        raise ValueError 

def get_awr_linestyle(style=LineStyle.Solid):
    "Returns the numerical index of the AWR linestyle that corresponds to the given LineStyle/int"
    _awr_linestyle_map =    [
                                0,  # AWR solid linestyle
                                1,  # AWR dashed linestyle
                                2,  # AWR dot linestyle
                                3   # AWR dash dot linestyle
                            ]   
    
    if isinstance(style, LineStyle):
        return _awr_linestyle_map[style.value]
    elif isinstance(style, int):
        return _awr_linestyle_map[(style)%4]
    else:
        raise ValueError 

def get_red_from_color(color):
    """
    Returns the red component of a packed 24-bit color integer
    """
    return color & 0x0000FF

def get_green_from_color(color):
    """
    Returns the green component of a packed 24-bit color integer
    """
    return (color & 0x00FF00) >> 8

def get_blue_from_color(color):
    """
    Returns the blue component of a packed 24-bit color integer
    """
    return (color & 0xFF0000) >> 16

def convert_BGR_to_RGB(color):
    """Converts a 24-bit packed BGR integer into a 24-bit packed RGB integer"""
    red = get_red_from_color(color)
    green = get_green_from_color(color)
    blue = get_blue_from_color(color)

    return (red << 16) + (green<<8) + blue

def convert_RGB_to_hex(color):
    """Returns the hex code string of a 24-bit packed RGB integer"""
    red = (color >> 16) & 0xFF
    green = (color >> 8) & 0xFF
    blue = color & 0xFF

    return '%02x%02x%02x'%(red, green, blue)

def stackup_color_to_rgb(color):
    """Returns (hatch style index, blue, green, red)"""
    hatch = (color>>24)&(255)
    blue = (color>>16)&(255)
    green = (color>>8)&(255)
    red = color&(255)
    return (hatch, blue, green, red)
    
def stackup_rgb_to_color(hatch, blue, green, red):
    """Returns decimal combination of hatch style index and RGB color"""
    return (hatch<<24) + (blue<<16) + (green<<8) + red
    
def lpf_color_to_rgb(color):
    """Returns (blue, green, red)"""
    return stackup_color_to_rgb(color)[1:]
    
def lpf_rgb_to_color(blue, green, red):
    """Returns decimal combination of RGB color"""
    return (blue<<16) + (green<<8) + red

def write_awr_lpf(filepath, layers):
    """
    Writes a complete AWR file to the given filepath with the given list of Layer objects
    """

    # store all unqiue patterns from layer stack
    patterns = []
    for layer in layers:
        if not layer.pattern in patterns and layer.pattern is not None:
            patterns.append(layer.pattern)

    with open(filepath, 'w') as fp:

        print("$PROCESS_SETUP_BEGIN\n", file=fp)

        # write default units
        units = {}
        write_awr_lpf_default_units(fp, **units)

        print('', file=fp)

        # write database units
        write_awr_lpf_database_units(fp)

        print('', file=fp)

        # write misc lines (unused)
        print(  '    !--- Register drawing utility function used for drawing airbridges ------',    file=fp)
        print(  '    $BRIDGE_DRAW_BEGIN AWR_MMIC $BRIDGE_DRAW_END\n',                               file=fp)
        print(  '    !--- Register cell to be used by default for route vias  ------',              file=fp)
        print(  '    $ROUTE_VIA_CELL_BEGIN MMICROUTEVIA $ROUTE_VIA_CELL_END\n',                     file=fp)
        print(  '    !--- DRC Rule deck (path relative to lpf file) ------',                        file=fp)
        print(  '    $DRC_RULES_FILE_BEGIN "" $DRC_RULES_FILE_END\n',                               file=fp)
        print(  '    !--- DRC engine: AWR, CALIBRE, ASSURA, CIRANOVA, or POLYTEDA ------',          file=fp)
        print(  '    $DRC_ENGINE_BEGIN "AWR" $DRC_ENGINE_END\n',                                    file=fp)

        # write connectivity rules
        write_awr_connectivity_rules(fp, layers)

        print('', file=fp)

        # write default values
        print(  '    !--- Default font used for layout ------',                                         file=fp)
        print(  '    $DEFAULT_FONT_BEGIN "Arial"     20000    0    0     $DEFAULT_FONT_END\n',          file=fp)
        print(  '    $PROPERTY_VALUES_BEGIN',                                                           file=fp)
        print(  '    $PROPERTY_VALUES_END\n',                                                           file=fp)
        print(  '    $DEFAULT_VALUES_BEGIN',                                                            file=fp)
        print(  '        W        20      u',                                                           file=fp)
        print(  '        L        40      u',                                                           file=fp)
        print(  '        H        50      u',                                                           file=fp)
        print(  '        T        2       u',                                                           file=fp)
        print(  '        Er       11.6',                                                                file=fp)
        print(  '        Rho      1',                                                                   file=fp)
        print(  '        Tand     0',                                                                   file=fp)
        print(  '        C        1       p',                                                           file=fp)
        print(  '        Li       1       n',                                                           file=fp)
        print(  '        Rad      20      u',                                                           file=fp)
        print(  '        M        0.6',                                                                 file=fp)
        print(  '        Cs       5       u',                                                           file=fp)
        print(  '        Extn     200     u',                                                           file=fp)
        print(  '    $DEFAULT_VALUES_END',                                                              file=fp)

        print('\n$PROCESS_SETUP_END\n', file=fp)

        # write layer setup heading
        print('!-------------- Drawing Layer Setup Defined Below ------------------------------',               file=fp)
        print('!-----  Color Format    -    (Blue << 16) + (Green << 8) + Red (all 8-bit colors, i.e. 0-255)',  file=fp)
        print('!-----', file=fp)
        print('!-----  Hatch Styles    -   00 = No Fill',                                                                                                                                                       file=fp)
        print('!-----                      01 = Solid Fill             02 = Small Dots               03 = Dense Small Dots         04 = Sparse Large Dots                        05 = Checkers',                file=fp)
        print('!-----                      06 = Sparse Small Dots      07 = Solid Squares            08 = Dense Backslashes        09 = Dense Forwardslashes                     10 = Dense Horizontal Lines',  file=fp)
        print('!-----                      11 = Thick Horizontal Lines 12 = Dense Vertical Lines     13 = Thick Vertical Lines     14 = Thin Horizontal Lines                    15 = Thin Vertical Lines',     file=fp)
        print('!-----                      16 = Sparse Large Dots      17 = Brick                    18 = Hollow Squares           19 = Diamonds (alternating dense/sparse rows) 20 = Sparse Forwardslashes',   file=fp)
        print('!-----                      21 = Sparse Backslashes     22 = Sparse Horizontal Lines  23 = Sparse Vertical Lines    24 = Grid                                     25 = Crosshatch',              file=fp)
        print('!-----', file=fp)
        print('!-----  Line Styles     -   0 (Solid)    1 (Dash)           2 (Dot)           3 (Dash Dot)               4 (Dash Dot Dot)',      file=fp)
        print('!-----                      =====        == == == ==        =  =  =  =        ==  =  ==  =  ==  =        ==  =  =  ==  =  =\n',    file=fp)

        print('$LAYER_SETUP_BEGIN\n', file=fp)

        # write draw layers section
        write_awr_layer_setup(fp, layers, patterns)

        print('\n$LAYERS_CONFIG_BEGIN\n', file=fp)

        # write default layer config
        vis_list = []
        clk_list = []
        for i in range(0, len(layers)):
            if layers[i].name[0:3] == 'EM_':
                vis_list.append(False)
            else:
                vis_list.append(True)

            if layers[i].name[0:3] == 'EM_':
                clk_list.append(True)
            else:
                clk_list.append(False)

        write_awr_layer_config(fp, 'Default', layers, patterns, vis_list, clk_list)

        print('', file=fp)

        # write EM layer config
        vis_list = []
        clk_list = []
        for i in range(0, len(layers)):
            if layers[i].name[0:3] == 'EM_':
                vis_list.append(True)
            else:
                vis_list.append(False)

            if layers[i].name[0:3] == 'EM_':
                clk_list.append(False)
            else:
                clk_list.append(True)
        write_awr_layer_config(fp, 'EM', layers, patterns, vis_list, clk_list)

        print('', file=fp)

        print('', file=fp)

        print('\n$LAYERS_CONFIG_END\n', file=fp)

        # write model layers
        write_awr_model_layer(fp, layers)

        print('', file=fp)

        # write EM mapping skeleton
        write_awr_em_mapping(fp, layers)

        print('', file=fp)

        # write GDS file export mapping
        write_awr_file_mapping(fp, layers)

        print('', file=fp)

        # write miscellanous portions
        print('$DRILL_TABLE_BEGIN', file=fp)
        print('!drill_name drill_number drill_diameter', file=fp)
        print('', file=fp)
        print('$DRILL_TABLE_END', file=fp)

        print('', file=fp)

        write_awr_stipple_patterns(fp, patterns)

        print('', file=fp)

        print('$LAYER_SETUP_END', file=fp)
        print('', file=fp)
        print('$ROUTER_SETUP_BEGIN', file=fp)
        print('', file=fp)
        print('$LAYERS_BEGIN', file=fp)
        print('!--------------------------------- Layer Entry Descriptions -----------------------------------------------------------', file=fp)
        print('! layer_name <layer_type> <layer_dir> min_width min_spacing route_grid route_grid_offset', file=fp)
        print('! <layer_type> = other, nwell, pwell, ndiff, pdiff, nimplant, pimplant, poly, cut, metal, non_contact_metal', file=fp)
        print('!                diffusion, recognition', file=fp)
        print('! <layer_dir> = none, horiz, vert', file=fp)
        print('!----------------------------------------------------------------------------------------------------------------------', file=fp)
        print('$LAYERS_END', file=fp)
        print('', file=fp)
        print('$CONNECT_LAYERS_BEGIN', file=fp)
        print('!--------------------------------- Connect layer -----------------------------------------------------------', file=fp)
        print('! <connect_type> <layer>', file=fp)
        print('! <connect_type> = UNKNOWN CAP_TOP_PLATE CAP_BOTTOM_PLATE SPIRAL_EXIT SPIRAL_TURN RESISTOR RESISTOR_2 RESISTOR_3', file=fp)
        print('!                 VIA_TOP VIA_BOTTOM DISABLED CAP_TOP_PLATE_2 CAP_BOTTOM_PLATE_2 CAP_TOP_PLATE_3 CAP_BOTTOM_PLATE_3 DEVICE', file=fp)
        print('!                 DEVICE_2 DEVICE_3', file=fp)
        print('!-----------------------------------------------------------------------------------------------------------', file=fp)
        print('$CONNECT_LAYERS_END', file=fp)
        print('', file=fp)
        print('$ROUTER_SETUP_END', file=fp)
        print('', file=fp)
        print('', file=fp)
        print('!------------- EM Simulation Setup Defined Below ----------------------------', file=fp)
        print('', file=fp)
        print('$EM_SETUP_BEGIN', file=fp)
        print('    $DEFAULT_EM_ENCLOSURE_BEGIN', file=fp)
        print('    !-----XDIM-----YDIM-----NX-----NY-----', file=fp)
        print('    !      (m)      (m)', file=fp)
        print('          0.001    0.001    1000   1000', file=fp)
        print('    $DEFAULT_EM_ENCLOSURE_END', file=fp)
        print('', file=fp)
        print('    $DEFAULT_EM_LAYERS_BEGIN', file=fp)
        print('    !    Hatch Patterns ------(0)  |||||(1)  \\\\\(2)  /////(3)  +++++(4)  xxxxx(5)', file=fp)
        print('    !', file=fp)
        print('    !-T---------Er-----Tand-----Sigma-----Scale-----CondHatch-----ViaHatch-----', file=fp)
        print('    !(m)                        (S/m)                 (0-5)         (0-5)', file=fp)
        print('      0.0001    1      0        0         1         5             1', file=fp)
        print('      2.56e-006 1      0        0         1         4             2', file=fp)
        print('      1e-007    6.9    0.001    0         1         3             3', file=fp)
        print('      5e-008    6.9    0.001    0         1         2             4', file=fp)
        print('      0.0001    12.9   0.001    0         1         1             5', file=fp)
        print('    $DEFAULT_EM_LAYERS_END', file=fp)
        print('', file=fp)
        print('    $EM_CONDUCTORS_BEGIN', file=fp)
        print('        $ELECTRICAL_SPEC_BEGIN', file=fp)
        print('        !-----Name-------rDC-------rHF-------+jX-------Red------Green-----Blue------', file=fp)
        print('        !              (ohm/sq)  (ohm/sq)  (ohm/sq)  <0-255>   <0-255>   <0-255>', file=fp)
        print('        $ELECTRICAL_SPEC_END', file=fp)
        print('', file=fp)
        print('    $EM_CONDUCTORS_END', file=fp)
        print('$EM_SETUP_END', file=fp)

def write_awr_lpf_default_units(fp, **kwargs):
    """
    Write default units section of AWR LPF file. Defaults are marked with an asterisk

    Arguments:

    fp - valid file handle

    Keywords:

    len - SI prefix in ['f', 'p', 'n', 'u'*, 'm', 'c', 'none', 'k']
    freq - SI prefix in ['none', 'k', 'M', 'G'*, 'T']
    cap - SI prefix in ['f', 'p'*, 'n', 'u', 'm', 'none']
    ind - SI prefix in ['f', 'p', 'n'*, 'u', 'm', 'none', 'k', 'M', 'G', 'T']
    res - SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*, 'k', 'M', 'G', 'T']
    cond - SI prefix in [SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*]
    temp - Unit in ['DegC'*, 'DegK', 'DegF']
    ang - Unit in ['Deg'*, 'Rad']
    time - SI prefix in ['f', 'p', 'n'*, 'u', 'm', 'none', 'k', 'M', 'G', 'T']
    volt - SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*, 'k', 'M', 'G', 'T']
    cur - SI prefix in ['f', 'p', 'n', 'u', 'm'*, 'none', 'k', 'M', 'G', 'T']
    pwr - SI prefix in ['f', 'p', 'n', 'u', 'm'*, 'none', 'k', 'M', 'G', 'T']
    """

    len = kwargs.pop('len', 'u')
    freq = kwargs.pop('freq', 'G')
    cap = kwargs.pop('cap', 'p')
    ind = kwargs.pop('ind', 'n')
    res = kwargs.pop('res', 'none')
    cond = kwargs.pop('cond','none')
    temp = kwargs.pop('temp', 'DegC')
    ang = kwargs.pop('ang', 'Deg')
    time = kwargs.pop('time', 'n')
    volt = kwargs.pop('volt', 'none')
    cur = kwargs.pop('cur', 'm')
    pwr = kwargs.pop('pwr', 'm')

    print('    $DEFAULT_UNITS_BEGIN', file=fp)
    print('        LEN  ' + len     , file=fp)
    print('        FREQ ' + freq    , file=fp)
    print('        CAP  ' + cap     , file=fp)
    print('        IND  ' + ind     , file=fp)
    print('        RES  ' + res     , file=fp)
    print('        COND ' + cond    , file=fp)
    print('        TEMP ' + temp    , file=fp)
    print('        ANG  ' + ang     , file=fp)
    print('        TIME ' + time    , file=fp)
    print('        VOLT ' + volt    , file=fp)
    print('        CUR  ' + cur     , file=fp)
    print('        PWR  ' + pwr     , file=fp)
    print('    $DEFAULT_UNITS_END  ', file=fp)

def write_awr_lpf_database_units(fp, draw_res=0.001, grid_spacing=0.01):
    """
    Write database units section of AWR LPF file. Arguments are in microns

    Arguments:
    fp - valid file handle
    draw_res - float representing database drawing resolution, in microns
    grid_spacing - float representing 1x grid spacing, in microns
    """
    print('    $DBASE_UNIT_BEGIN', file=fp)
    print('        DRAW_RESOLUTION ' + str(draw_res).ljust(8) + 'u', file=fp)
    print('        GRID_SPACING    ' + str(grid_spacing).ljust(8) + 'u', file=fp)
    print('    $DBASE_UNIT_END', file=fp)

def write_awr_connectivity_rules(fp, layers):
    """
    Write connectivity rules section of AWR LPF file.

    Arguments:

    fp - valid handle to file
    layers - list of Layer objects
    """

    local_layers = [x for x in layers]

    print('    !--- Used by Connectivity tracer ------', file=fp)
    print('    $CONNECT_RULES_BEGIN ', file=fp)

    # connections is a dict with each layer as a key, and a list of Layers that is connected to by each key
    connections = {}
    connect_all = [ ]
    for layer in local_layers:
        # if length of layer binding is equal to total number of layers, assume a "Connect_All" rule is to be written
        if len(layer.binding) == len(local_layers):
            print('        Connect_All "' + layer.name + '"', file=fp)
            connect_all.append(layer)

            # remove this layer from other layer's connect rules, if it exists
            for other_layer in local_layers:
                if layer in other_layer.binding:
                    other_layer.binding.remove(layer)

        else:
            connections[layer.name] = [x for x in layer.binding]

    for key, val in connections.iteritems():
        # no rule written for layers with no bindings
        if val:
            for layer in val:
                # write connect rule
                print('        Connect "' + key + '" To "' + layer.name + '"', file=fp)

                # remove this layer from other layer's connect rules, if it exists
                if key in [x.name for x in layer.binding]:
                    for i in range(0,len(connections[layer.name])):
                        if connections[layer.name][i].name == key:
                            connections[layer.name].pop(i)
                            break

    print('    $CONNECT_RULES_END', file=fp)

def write_awr_layer_setup(fp, layers, patterns, vis_list=None, clk_list=None):
    """
    Writes the Draw_Layers section of an AWR LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    patterns - list of unique Pattern objects that are used in the list of Layers
    """

    print('$DRAW_LAYERS_BEGIN\n', file=fp)
    print('!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------', file=fp)
    print('! '                          , end='', file=fp)
    print('Layer_Name'        , end='', file=fp)
    print('Line_Color'      .ljust(12)  , end='', file=fp)
    print('Fill_Color'      .ljust(12)  , end='', file=fp)
    print('Line_Style'      .ljust(12)  , end='', file=fp)
    print('Hatch_Style'     .ljust(12)  , end='', file=fp)
    print('Visible'         .ljust(8)   , end='', file=fp)
    print('Hatch_Visible'   .ljust(14)  , end='', file=fp)
    print('Frozen'          .ljust(8)   , end='', file=fp)
    print('3D_Thickness'    .ljust(14)  , end='', file=fp)
    print('3D_Z_Pos'        .ljust(10)  , end='', file=fp)
    print('Texture'         .ljust(8)   , end='', file=fp)
    print('Trans_Fill'      .ljust(12)  , end='', file=fp)
    print('Translucent'     .ljust(12)  , end='', file=fp)
    print('Texture_Scale'   .ljust(14)  , end='', file=fp)
    print('File_Layer'      .ljust(12)  , end='', file=fp)
    print('Options'         .ljust(8)   , end='', file=fp)
    print('Cloak'           .ljust(6)   , end='', file=fp)
    print('Hatch_Name'        , end='', file=fp)
    print('\n!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------', file=fp)

    print('"Error"'.ljust(27)+'255'.ljust(12)+'255'.ljust(12)+'0'.ljust(12)+'16'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'0'.ljust(6),file=fp)
    print('"RatsNest"'.ljust(27)+'255'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'0'.ljust(6),file=fp)
    print('"EMSymbols"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'0'.ljust(6),file=fp)
    print('"Default"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'0'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"SubcircuitAnnotation"'.ljust(27)+'4259648'.ljust(12)+'4259648'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"Annotation"'.ljust(27)+'16776960'.ljust(12)+'16776960'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"DrillHoles"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"ErrorHighlight"'.ljust(27)+'1113872'.ljust(12)+'1113872'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"Highlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"Selection"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"DimensionLines"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"SubSelection"'.ljust(27)+'4210943'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('"DynamicHighlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'2'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6),file=fp)
    print('', file=fp)

    for layer in layers:
        name = '"' + layer.name + '"'
        
        # force pure white to draw as black instead
        if layer.color == wx.Colour(255, 255, 255).GetRGB():
            color = str(lpf_rgb_to_color(0, 0, 0))
        else:
            color = str(lpf_rgb_to_color(layer.blue, layer.green, layer.red))
        
        if layer.style is not None:
            style = str(get_awr_linestyle(layer.style))
        else:
            style = '0'

        if layer.pattern is not None:
            fill_index = str(patterns.index(layer.pattern) + 26) # indices for custom-defined patterns starts at 26
            hatch_visible = '1'
            hatch_name = '"' + layer.pattern.name + '"'
        else:
            fill_index = '0'
            hatch_visible = '0'
            hatch_name = ''

        if layer.visible:
            vis = '1'
        else:
            vis = '0'

        if layer.cloak:
            clk = '1'
        else:
            clk = '0'

        print(name                      .ljust(27)  , end='', file=fp)
        print(color                     .ljust(12)  , end='', file=fp)
        print(color                     .ljust(12)  , end='', file=fp)
        print(style                     .ljust(12)  , end='', file=fp)
        print(fill_index                .ljust(12)  , end='', file=fp)
        print(vis                       .ljust(8)   , end='', file=fp)
        print(hatch_visible             .ljust(14)  , end='', file=fp)
        print('0'                       .ljust(8)   , end='', file=fp)
        print('0'                       .ljust(14)  , end='', file=fp)
        print('0'                       .ljust(10)  , end='', file=fp)
        print('""'                      .ljust(8)   , end='', file=fp)
        print('0'                       .ljust(12)  , end='', file=fp)
        print('0.5'                     .ljust(12)  , end='', file=fp)
        print('0'                       .ljust(14)  , end='', file=fp)
        print('"Obsolete"'              .ljust(12)  , end='', file=fp)
        print('0'                       .ljust(8)   , end='', file=fp)
        print(clk                       .ljust(6)   , end='', file=fp)
        print(hatch_name                  , end='', file=fp)
        print('', file=fp)

    print('\n$DRAW_LAYERS_END', file=fp)

def write_awr_layer_config(fp, config_name, layers, patterns, vis_list, clk_list):
    """
    Writes a layer config section of an AWR LPF file

    Arguments:

    fp - valid handle to file to be written to
    config_name - a string with the name of the configuration
    layers - list of Layer objects
    patterns - list of unique Pattern objects that are used in the list of Layers
    vis_list - list of Booleans that determines whether the corresponding layer should be visible in this configuration
    clk_list - list of Booleans that determines whether the corresponding layer should be cloaked in this configuration

    layers, vis_list, and clk_list must be the same length!
    """

    if not len(layers) == len(vis_list) or not len(layers) == len(clk_list):
        raise ValueError('layers, vis_list, and clk_list must be the same length!')

    print('$CONFIG_NAME    "' + config_name + '"', file=fp)

    print('! '                      , end='', file=fp)
    print('Layer_Name'    , end='', file=fp)
    print('Line_Color'.ljust(12)    , end='', file=fp)
    print('Fill_Color'.ljust(12)    , end='', file=fp)
    print('Line_Style'.ljust(12)    , end='', file=fp)
    print('Hatch_Style'.ljust(12)   , end='', file=fp)
    print('Visible'.ljust(8)        , end='', file=fp)
    print('Hatch_Visible'.ljust(14) , end='', file=fp)
    print('Frozen'.ljust(8)         , end='', file=fp)
    print('Trans_Fill'.ljust(12)    , end='', file=fp)
    print('Translucent'.ljust(12)   , end='', file=fp)
    print('Cloak'.ljust(6)          , end='', file=fp)
    print('3D_Thickness'.ljust(14)  , end='', file=fp)
    print('3D_Z_Pos'.ljust(10)      , end='', file=fp)
    print('', file=fp)

    print('"Error"'.ljust(27)+'255'.ljust(12)+'255'.ljust(12)+'0'.ljust(12)+'16'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"RatsNest"'.ljust(27)+'255'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"EMSymbols"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"Default"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'0'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"SubcircuitAnnotation"'.ljust(27)+'4259648'.ljust(12)+'4259648'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"Annotation"'.ljust(27)+'16776960'.ljust(12)+'16776960'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"DrillHoles"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"ErrorHighlight"'.ljust(27)+'1113872'.ljust(12)+'1113872'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"Highlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"Selection"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"DimensionLines"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"SubSelection"'.ljust(27)+'4210943'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('"DynamicHighlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'2'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10),file=fp)
    print('', file=fp)

    for (layer, visible, cloak) in zip(layers, vis_list, clk_list):
        name = '"' + layer.name + '"'

        # force pure white to draw as black instead
        if layer.color == wx.Colour(255, 255, 255).GetRGB():
            color = str(lpf_rgb_to_color(0, 0, 0))
        else:
            color = str(lpf_rgb_to_color(layer.blue, layer.green, layer.red))
        
        if layer.style is not None:
            style = str(get_awr_linestyle(layer.style))
        else:
            style = '0'

        if layer.pattern is not None:
            fill_index = str(patterns.index(layer.pattern) + 26) # indices for custom-defined patterns starts at 26
            hatch_visible = '1'
            hatch_name = '"' + layer.pattern.name + '"'
        else:
            fill_index = '0'
            hatch_visible = '0'
            hatch_name = ''

        if visible:
            vis = '1'
        else:
            vis = '0'

        if cloak:
            clk = '1'
        else:
            clk = '0'

        print(name                      .ljust(27)  , end='', file=fp)
        print(color                     .ljust(12)  , end='', file=fp)
        print(color                     .ljust(12)  , end='', file=fp)
        print(style                     .ljust(12)  , end='', file=fp)
        print(fill_index                .ljust(12)  , end='', file=fp)
        print(vis                       .ljust(8)   , end='', file=fp)
        print(hatch_visible             .ljust(14)  , end='', file=fp)
        print('0'                       .ljust(8)   , end='', file=fp)
        print('0'                       .ljust(12)  , end='', file=fp)
        print('0.5'                     .ljust(12)  , end='', file=fp)
        print(clk                       .ljust(6)   , end='', file=fp)
        print('0'                       .ljust(14)  , end='', file=fp)
        print('0'                       .ljust(10)  , end='', file=fp)
        print('', file=fp)

def write_awr_model_layer(fp, layers):
    """
    Writes the model layers section of the LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    """

    print('$MODEL_LAYER_BEGIN\n', file=fp)
    print('$MAP_NAME'.ljust(30) + '"GDS Map"', file=fp)

    # print model layer -> model layer
    for layer in layers:
        string = '"' + layer.name + '"'
        print(string.ljust(30) + string, file=fp)

    print('', file=fp)

    # print GDS number -> model layer
    for layer in layers:
        string1 = '"' + str(layer.gds) + '_0"'
        string2 = '"' + layer.name + '"'
        print(string1.ljust(30) + string2, file=fp)

    print('', file=fp)
    print('"Default"                     "Default"'               , file=fp)
    print('"EMSymbols"                   "EMSymbols"'             , file=fp)
    print('"RatsNest"                    "RatsNest"'              , file=fp)
    print('"Error"                       "Error"'                 , file=fp)
    print('"SubcircuitAnnotation"        "SubcircuitAnnotation"'  , file=fp)
    print('"Annotation"                  "Annotation"'            , file=fp)
    print('"DrillHoles"                  "DrillHoles"'            , file=fp)
    print('"ErrorHighlight"              "ErrorHighlight"'        , file=fp)
    print('"Highlight"                   "Highlight"'             , file=fp)
    print('"Selection"                   "Selection"'             , file=fp)
    print('"DimensionLines"              "DimensionLines"'        , file=fp)
    print('"SubSelection"                "SubSelection"'          , file=fp)
    print('"DynamicHighlight"            "DynamicHighlight"'      , file=fp)
    print('$MODEL_LAYER_END',   file=fp)

def write_awr_em_mapping(fp, layers):
    """
    Writes the EM mapping section of the LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    """

    print('$EM_MAPPING_BEGIN', file=fp)
    print('$EM_MAP    "AXIEM_SPP_Full" !name', file=fp)
    print('!layer_name                   em_layer    is_via  material            via_extent', file=fp)

    for layer in layers:
        string = '"' + layer.name + '"'
        print(string.ljust(30) + '0           0       ""                  1'                            , file=fp)

    print('')
    print('"Default"'                     .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"EMSymbols"'                   .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"RatsNest"'                    .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"Error"'                       .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"SubcircuitAnnotation"'        .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"Annotation"'                  .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"DrillHoles"'                  .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"ErrorHighlight"'              .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"Highlight"'                   .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"Selection"'                   .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"DimensionLines"'              .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"SubSelection"'                .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('"DynamicHighlight"'            .ljust(30) + '0           0       ""                  1'  , file=fp)
    print('$EM_MAPPING_END',   file=fp)

def write_awr_file_mapping(fp, layers):
    """
    Writes the GDS export mapping section of the LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    """

    print('$FILE_MAPPING_BEGIN', file=fp)
    print('$FILE_MAP    "GDSII" 0', file=fp)
    print('!layer_name                   file_layer  skip', file=fp)

    for layer in layers:
        string1 = '"' + layer.name + '"'
        string2 = '"' + str(layer.gds) + '"'

        # skip EM layer export
        if layer.name[0:3] == 'EM_':
            string3 = '1'
        else:
            string3 = '0'

        print(string1.ljust(30) + string2.ljust(12) + string3, file=fp)

    print('')
    print('"Default"'                     .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"EMSymbols"'                   .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"RatsNest"'                    .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"Error"'                       .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"SubcircuitAnnotation"'        .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"Annotation"'                  .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"DrillHoles"'                  .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"ErrorHighlight"'              .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"Highlight"'                   .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"Selection"'                   .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"DimensionLines"'              .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"SubSelection"'                .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('"DynamicHighlight"'            .ljust(30) + '""'.ljust(12) + '1', file=fp)
    print('', file=fp)
    print('$FILE_MAPPING_END',   file=fp)

def write_awr_stipple_patterns(fp, patterns):
    """
    Writes the custom stipple pattern section of the AWR LPF file

    Arguments:

    fp - valid handle to file to be written to
    patterns - list of Pattern objects
    """
    print('$LAYER_FILL_PATTERN_BEGIN', file=fp)
    print('', file=fp)

    # custom stipple patterns start at index 26 after built-in AWR stipple patterns
    idx = 26 
    for pattern in patterns:
        print('! ' + str(idx), file=fp)
        pattern.print_pattern_awr_lpf(fp)
        print('', file=fp)
        idx += 1

    print('$LAYER_FILL_PATTERN_END', file=fp)

def write_ads_config(filepath, layers, allpatterns=None):
    """
    Writes an ADS layout.lay file, with corresponding color and fill index files. The index files append "_colors" and "_fills" to the base filename
    of the given filepath.
    """

    # store all unique patterns from layer stack
    if allpatterns is not None:
        patterns = allpatterns
    else:
        patterns = []
        for layer in layers:
            if not layer.pattern in patterns and layer.pattern is not None:
                patterns.append(layer.pattern)

    # store all unique colors from layer stack
    colors = []
    for layer in layers:
        if not layer.color in colors:
            colors.append(layer.color)

    # determine default visibility (hide EM layers, show layout layers)
    vis_list = []
    for i in range(0, len(layers)):
        if layers[i].name[0:3] == 'EM_':
            vis_list.append(False)
        else:
            vis_list.append(True)

    kitName = os.path.splitext(os.path.basename(filepath))[0]
    rootDir = os.path.dirname(filepath)

    # create cfg, pattern, and tech directories
    if not os.path.exists(rootDir + '/cfg'):
        os.mkdir(rootDir + '/cfg')

    if not os.path.exists(rootDir + '/cfg/fill_patterns'):
        os.mkdir(rootDir + '/cfg/fill_patterns')

    if not os.path.exists(rootDir + '/tech'):
        os.mkdir(rootDir + '/tech')

    # write color index file
    with open(rootDir + '/cfg/hpeecolor.cfg', 'w') as fp:
        
        # convert color list into RGB 3-tuples
        col = []
        for color in colors:
            col.append((get_red_from_color(color), get_green_from_color(color), get_blue_from_color(color)))

        # ensure black and white are in list
        if (0, 0, 0) not in col:
            col.append((0, 0, 0))
        if (255, 255, 255) not in col:
            col.append((255, 255, 255))

        write_ads_color_file(fp, col)

    # write pattern index file
    with open(rootDir + '/cfg/hpeefill.cfg', 'w') as fp:
        write_ads_pattern_index_file(fp, patterns)

    # write all pattern files
    for pattern in patterns:
        with open(rootDir + '/cfg/fill_patterns/' + pattern.name + '.pattern', 'w') as fp:
            pattern.print_pattern_ads(fp)

    # write .lay file
    with open(rootDir + '/layout.lay', 'w') as fp:
        write_ads_layout_lay(fp, layers, colors, patterns, vis_list)

    # write library.tech file
    with open(rootDir + '/tech/library.tech', 'w') as fp:
        write_ads_library_tech_file(fp, layers, patterns, vis_list)

    # write display.tech file
    with open(rootDir + '/tech/display.tech', 'w') as fp:
        write_ads_display_tech_file(fp, layers)

    # write technology creation ael file
    with open(rootDir + '/tech/create_technology.ael', 'w') as fp:
        write_ads_create_tech_ael(fp, kitName, layers)

    with open(rootDir + '/tech/LayerMap.map', 'w') as fp:
        write_ads_layer_map_file(fp, layers)

def write_ads_layout_lay(fp, layers, colors, patterns, vis_list):
    """
    Writes an ADS layout.lay file for a given list of layers, colors, patterns, visibilities

    Arguments:

    fp - valid handle to output file to write
    layers - list of Layer objects
    colors - list of integers representing unique 24-bit packed RGB colors used in layer list
    patterns - list of Patterns representing unique patterns used in layer list
    vis_list - list of layers that are visible by default
    """

    # print header
    print('CurrentLayer number = 0', file=fp)

    # print default layer configuration
    print('default'                 .ljust(18)  , end='', file=fp)
    print('number = 0'              .ljust(15)  , end='', file=fp)
    print('stream = 0'              .ljust(15)  , end='', file=fp)
    print('iges = 0'                .ljust(15)  , end='', file=fp)
    print('color = 59'              .ljust(12)  , end='', file=fp)
    print('fill = 0'                .ljust(12)  , end='', file=fp)
    print('line = 0'                .ljust(9)   , end='', file=fp)
    print(', ', end='', file=fp)
    print('0 ', end='', file=fp)    # plot mode
    print('0 ', end='', file=fp)    # protect flag
    print('1, ', end='', file=fp)   # visible flag
    print('""', end=', ', file=fp)
    print('type = 1, dxf = "default"'.ljust(26), end='', file=fp)
    print('trans = 0', file=fp)

    for (layer, visible) in zip(layers, vis_list):
        name = layer.name
        numStr = 'number = ' + str(layer.gds)
        streamStr = 'stream = ' + str(layer.gds)
        igesStr = 'iges = ' + str(layer.gds)

        # force pure black to draw as white instead
        if layer.color == wx.Colour(0, 0, 0).GetRGB():
            color = wx.Colour(255, 255, 255).GetRGB()
        else:
            color = layer.color

        colorIdx = str(colors.index(color))
        
        if layer.style is not None:
            style = str(get_ads_linestyle(layer.style))
        else:
            style = '0'

        if layer.pattern is not None:
            fill_index = str(patterns.index(layer.pattern))
        else:
            fill_index = '0'

        if visible:
            vis = '1'
        else:
            vis = '0'

        print(name                      .ljust(18)  , end='', file=fp)
        print(numStr                    .ljust(15)  , end='', file=fp)
        print(streamStr                 .ljust(15)  , end='', file=fp)
        print(igesStr                   .ljust(15)  , end='', file=fp)
        print(('color = ' + colorIdx)   .ljust(12)  , end='', file=fp)
        print(('fill = ' + fill_index)  .ljust(12)  , end='', file=fp)
        print(('line = ' + style)       .ljust(9)  , end='', file=fp)
        print(', ', end='', file=fp)

        # determine and write plot mode
        if not layer.style is None and not layer.pattern is None:
            print('2 ', end='', file=fp)
        elif layer.style is None:
            print('1 ', end='', file=fp)
        elif layer.pattern is None:
            print('0 ', end='', file=fp)

        print('0 ', end='', file=fp)        # protect flag
        print(vis + ', ', end='', file=fp)  # visible flag

        bindStr = '"' + layer.name.lower()

        # don't print a binding for a layer that is bound to every layer in the stack
        # this is used to determine a "Connect_All" rule in the AWR configuration, which has no analog in ADS
        if not len(layer.binding) == len(layers):
            for bind in layer.binding:
                bindStr = bindStr + ' ' + bind.name.lower()

        bindStr = bindStr + '"'

        print(bindStr.ljust(50), end=', ', file=fp)
        print('type = 1, dxf = ', end='', file=fp)

        dxfStr = '"' + layer.name.lower() + '"'

        print(dxfStr.ljust(26), end='', file=fp)
        print('trans = 0', file=fp)

def write_ads_color_file(fp, colors):
    """
    Writes an ADS color index file (a. la. hpeecolor.cfg)

    Arguments:

    fp - valid handle to file to be written to
    colors - list of RGB tuples (red, green, blue)
    """
    print('# red'.ljust(8), end='', file=fp)
    print('green'.ljust(6), end='', file=fp)
    print('blue'.ljust(6), end='', file=fp)
    print(': ', end='', file=fp)
    print('name'.ljust(12), end='', file=fp)
    print(': ', end='', file=fp)
    print('index', end='', file=fp)

    print('', file=fp)

    idx = 0
    for (red, green, blue) in colors:
        redStr = str(red).ljust(6)
        grnStr = str(green).ljust(6)
        bluStr = str(blue).ljust(6)
        nameStr = ('Color ' + str(idx)).ljust(12)
        idxStr = str(idx)

        print('  ' + redStr + grnStr + bluStr + ': ' + nameStr + ': ' + idxStr, file=fp)
        idx += 1

    print('', file=fp)

def write_ads_pattern_index_file(fp, patterns):
    """
    Writes an ADS fill index file (a. la. hpeefill.cfg)

    Arguments:

    fp - valid handle to file to be written to
    patterns - list of Pattern objects
    """

    # default HPGL/2 plotter string, should be unused
    # 2 - solid unidirectional fill, 0 - 0 point spacing, 45 - 45deg angle
    HPGL2Str = '2 0 45'

    for pattern in patterns:
        string = '/de/fill_patterns/' + pattern.name + '.pattern'
        print(string.ljust(75) + ': ' + HPGL2Str, file=fp)

def write_ads_library_tech_file(fp, layers, patterns, vis_list):
    """
    Writes an ADS library.tech file for a given list of layers, patterns, visibilities

    Arguments:

    fp - valid handle to output file to write
    layers - list of Layer objects
    patterns - list of all Patterns in which the individual layers' patterns are indexed
    vis_list - list of layers that are visible by default
    """

    # print header
    print('<!DOCTYPE Technology>', file=fp)
    print('<Lpp_List>', file=fp)
    
    # print default layer configuration
    print('\t<LPP purpose="drawing"'    , end='', file=fp)
    print('visible="1"'                 .ljust(12), end='', file=fp)
    print('rgb="16777215"'              .ljust(15), end='', file=fp)
    print('line="0"'                    .ljust(9),  end='', file=fp)
    print('protect="0"'                 .ljust(12), end='', file=fp)
    print('alpha="255"'                 .ljust(12), end='', file=fp)
    print('fill="0"'                    .ljust(10), end='', file=fp)
    print('layer="default"'             , end='', file=fp)
    print('mode="0"/>'                  .ljust(10), file=fp)

    for (layer, visible) in zip(layers, vis_list):
        
        # determine layer visibility string
        if visible:
            visString = 'visible="1"'
        else:
            visString = 'visible="0"'

        # determine layer color string

        # force pure black to draw as white instead
        if layer.color == wx.Colour(0, 0, 0).GetRGB():
            color = wx.Colour(255, 255, 255).GetRGB()
        else:
            color = convert_BGR_to_RGB(layer.color)

        colorString = 'rgb="' + str(color) + '"'
        
        # determine layer linestyle string
        if layer.style is not None:
            styleString = 'line="' + str(get_ads_linestyle(layer.style)) + '"'
        else:
            styleString = 'line="0"'

        # determine layer pattern string
        if layer.pattern is not None:
            fillString = 'fill="' + str(patterns.index(layer.pattern)) + '"'
        else:
            fillString = 'fill="0"'

        # determine layer name string
        nameString = 'layer="' + layer.name + '"'

        # determine plot mode
        if not layer.style is None and not layer.pattern is None:
            modeString = 'mode="2"/>'
        elif layer.style is None:
            modeString = 'mode="1"/>'
        elif layer.pattern is None:
            modeString = 'mode="0"/>'

        # print layer configuration
        print('\t<LPP purpose="drawing"'    , end='', file=fp)
        print(visString                     .ljust(12), end='', file=fp)
        print(colorString                   .ljust(15), end='', file=fp)
        print(styleString                   .ljust(9),  end='', file=fp)
        print('protect="0"'                 .ljust(12), end='', file=fp)
        print('alpha="255"'                 .ljust(12), end='', file=fp)
        print(fillString                    .ljust(10), end='', file=fp)
        print(nameString                    , end='', file=fp)
        print(modeString                    .ljust(10), file=fp)

    # print footer
    print('</Lpp_List>', file=fp)

def write_ads_display_tech_file(fp, layers):
    """
    Writes an ADS display.tech file for a given list of layers

    Arguments:

    fp - valid handle to output file to write
    layers - list of Layer objects
    """

    # print file header and default layer
    print('<!DOCTYPE Display>', file=fp)
    print('<Display>', file=fp)
    print('\t<Lpp_Display_Order order="0">', file=fp)
    print('\t\t<LPP name="default:drawing"/>', file=fp)

    # print process layers
    for layer in layers:
        print('\t\t<LPP name="' + layer.name + ':drawing"/>', file=fp)

    # print extra layers
    print('\t\t<LPP name="silkscreen:drawing"/>', file=fp)
    print('\t\t<LPP name="silkscreen2:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_rects:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_text:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_street:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_err1:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_err2:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_err3:drawing"/>', file=fp)
    print('\t\t<LPP name="DRC_err4:drawing"/>', file=fp)

    # print footer
    print('\t</Lpp_Display_Order>', file=fp)
    print('\t<Current_Lpp name="default:drawing"/>', file=fp)
    print('</Display>', file=fp)

def write_ads_create_tech_ael(fp, prefix, layers):
    """
    Writes an ael script that will create a technology for the process

    Arguments:

    fp - valid handle to the output file to write
    prefix - name of the kit (prefix used for kit name in Python preprocessor, e.g. "MACOM_GSI40_")
    layers - list of Layer objects
    """

    kitNameStr = prefix + '_DK_NAME'

    # write header
    print('fputs(stderr, strcat("Creating ", ' + kitNameStr + ', " technology..."));\n', file=fp)
    print('tech_create_technology(' + kitNameStr + ');', file=fp)
    print('tech_open_technology(' + kitNameStr + ', "w");', file=fp)

    # write units, resolution, include ads_schematic_layers
    print('tech_set_layout_units(' + kitNameStr + ', "micron");', file=fp)
    print('tech_set_layout_resolution(' + kitNameStr + ', 1000);', file=fp)
    print('tech_set_libraries_used_by_technology(' + kitNameStr + ', list("ads_schematic_layers"));\n', file=fp)

    # write layer configuration
    for layer in layers:

        layerNameStr = '"' + layer.name + '"'
        
        if layer.gds in range(200, 256):
            layerNumStr = str(layer.gds + 56)   # for any layer that is GDS between 200-255, shift it up by 256 to avoid conflicts with ADS layers
        else:
            layerNumStr = str(layer.gds)

        layerGDSStr = str(layer.gds)

        bindStr = '"' + layer.name.lower()

        # don't print a binding for a layer that is bound to every layer in the stack
        # this is used to determine a "Connect_All" rule in the AWR configuration, which has no analog in ADS
        if not len(layer.binding) == len(layers):
            for bind in layer.binding:
                bindStr = bindStr + ' ' + bind.name.lower()

        bindStr = bindStr + '"'

        # create physical layer
        print('tech_create_physical_layer('.ljust(27), end='', file=fp)
        print(kitNameStr    , end=', ', file=fp)            # kit name
        print(layerNameStr  , end=', ', file=fp)  # layer name
        print(layerNumStr   .ljust(4), end=', ', file=fp)   # layer number
        print(layerGDSStr   .ljust(4), end=', ',  file=fp)  # mask number
        print('PROCESS_ROLE_CONDUCTOR);', file=fp)          # process role

        # set layer binding
        print('tech_set_layer_binding('.ljust(27), end='', file=fp)
        print(kitNameStr    , end=', ', file=fp)            # kit name
        print(layerNameStr  , end=', ', file=fp)  # layer name
        print(bindStr.ljust(50), end='', file=fp)           # layer binding
        print(');\n', file=fp)


    print('tech_save_technology(' + kitNameStr + ');', file=fp)

def write_ads_layer_map_file(fp, layers):
    """
    Writes an ADS layer map file for GDS export

    Arguments:
    fp - valid handle to the output file to write
    layers - list of Layer objects
    """

    print('# Layer' + 'Purpose'.ljust(8) + 'GDSLayer'.ljust(9) + 'GDSPurpose', file=fp)
    print('default' + 'drawing'.ljust(8) + '0'.ljust(9) + '0', file=fp)

    for layer in layers:
        print(layer.name + 'drawing'.ljust(8) + str(layer.gds).ljust(9) + '0', file=fp)

def write_klayout_layer_prefs_file(filepath, layers):
    """
    Writes a KLayout layer preference file

    Arguments:
    filepath - path to write the configuration to
    layers - list of Layer objects
    """

    patterns = []
    for layer in layers:
        if not layer.pattern in patterns and layer.pattern is not None:
            patterns.append(layer.pattern)

    with open(filepath, 'wb') as fp:
        # print xml header
        print('<?xml version="1.0" encoding="utf-8"?>', file=fp)
        print('<layer-properties-tabs>', file=fp)
        print(' <layer-properties>', file=fp)

        # determine default visibility (hide EM layers, show layout layers)
        vis_list = []
        for i in range(0, len(layers)):
            if layers[i].name[0:3] == 'EM_':
                vis_list.append(False)
            else:
                vis_list.append(True)

        # print layer preferences
        for (layer, visible) in zip(layers, vis_list):
        
            # determine layer visibility string
            if visible:
                visString = 'true'
            else:
                visString = 'false'

            # determine layer color string

            # force pure white to draw as black instead
            if layer.color == wx.Colour(255, 255, 255).GetRGB():
                color = wx.Colour(0, 0, 0).GetRGB()
            else:
                color = convert_BGR_to_RGB(layer.color)

            colorString = '#' + convert_RGB_to_hex(color)
        
            # determine layer linestyle string
            if layer.style is not None:
                styleString = '1'       # no dashed lines, use a 1px line for everything
            else:
                styleString = '0'       # if no outline, set to 0px

            # determine layer pattern string
            if layer.pattern is not None:
                fillString = 'C' + str(patterns.index(layer.pattern))
            else:
                fillString = 'I1'   # 'I1' is a no-fill

            # determine layer name string
            nameString = 'layer="' + layer.name + '"'

            print('  <properties>', file=fp)
            print('   <frame-color>' + colorString + '</frame-color>', file=fp)
            print('   <fill-color>' + colorString + '</fill-color>', file=fp)
            print('   <frame-brightness>' + '0' + '</frame-brightness>', file=fp)
            print('   <fill-brightness>' + '0' + '</fill-brightness>', file=fp)
            print('   <dither-pattern>' + fillString + '</dither-pattern>', file=fp)
            print('   <valid>' + 'true' + '</valid>', file=fp)
            print('   <visible>' + visString + '</visible>', file=fp)
            print('   <transparent>' + 'true' + '</transparent>', file=fp)
            print('   <width>' + styleString + '</width>', file=fp)
            print('   <marked>' + 'false' + '</marked>', file=fp)
            print('   <animation>' + '0' + '</animation>', file=fp)
            print('   <name>' + layer.name + '</name>', file=fp)
            print('   <source>' + (str(layer.gds) + '/0@1') + '</source>', file=fp)
            print('  </properties>', file=fp)

        print(' <name/>', file=fp)

        idx = 1

        # custom stipple patterns start at index 1 in the pattern section
        for pattern in patterns:
            pattern.print_pattern_klayout_lyp(fp, idx)
            idx += 1

        print(' </layer-properties>', file=fp)
        print('</layer-properties-tabs>', file=fp)