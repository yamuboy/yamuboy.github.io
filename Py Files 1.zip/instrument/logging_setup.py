import logging
#
# define a default logging target for the library
#
class NullHandler(logging.Handler):
    def emit(self, record):
        pass

# point the top-level library log target at the null handler
_h = NullHandler()
logging.getLogger('instrument').addHandler(_h)
