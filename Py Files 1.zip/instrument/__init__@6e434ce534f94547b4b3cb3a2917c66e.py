# initialize the logger
from .logger import logger

# import some stuff that needs to be imported early
from .utils import timed_wait, timed_wait_ms

# import some core modules
from .base import InstrumentManager, register, create, driver, GenericInstrument
from .errors import *

# import the instrument families before any drivers are imported
# otherwise a recursive import will occur and an error will be raised
from . import family

# import the drivers to cause them to register themselves
from . import drivers as _drivers

# create some shortcuts/aliases
manager = InstrumentManager

# import pyvisa constants
import pyvisa.constants as visa_constants
