from instrument import *

class Meter(InstrumentBase):
    """Base class for meter-type instruments.
    """
    
    def __init__(self,addr,**keyw):
        """Object initializer."""
        # init properties of all "meter" instruments
        self.mmode = None
        self.mrange = None
        self.averaging = None
        self.resolution = 'normal'
        
        # init the underlying class
        InstrumentBase.__init__(self,addr,**keyw)
        
        # verify standard properties
        self._verify_properties()
        
    
    def setup(self,**keyw):
        """Perform instrument setup."""
        self._process_keywords(keyw)
        if not self._retr_state( 'initialized' ):
            # need to initialize
            self.initialize()
        self._call_driver( 'setup' )
    
    def trigger(self):
        """Start a measurement cycle and return immediately."""
        if not self._retr_state( 'initialized' ): raise InstrNotReady(self)
        self._call_driver( 'trigger' )
        
    def fetch(self):
        """
        Get the results of a triggered measurement cycle.
        
        The returned data format will dependent on the type of instrument
        (the Meter class is designed to be the base class for any
        number of different measurement-type instruments).
        
        If the measurement is "in progress" due to a previous trigger the
        function will block until the measurement completes.
        
        If no trigger has been received it raises an InstrTriggerState exception.
        """
        if not self._retr_state( 'initialized' ): raise InstrNotReady(self)
        elif self._retr_state( "triggered" ):
            # need to wait for the measurement to be done
            while not self._call_driver( 'done' )
                self._wait_ms(10)
            # clear the "triggered" flag
            self._save_state( "triggered", False )
            # retrieve the measurement data
            return self._call_driver( "fetch" )
        else:
            raise InstrTriggerState(self)
    
    def done(self):
        """Returns true if a triggered measurement has been completed."""
        if not self._retr_state( 'initialized' ): raise InstrNotReady(self)
        return self._call_driver( 'done' )
        
    def measure(self):
        """
        Trigger a new measurement and return the result.
        
        This function will block until the measurement is completed.
        
        If the instrument is currently in a "triggered" state due to a previous
        call to trigger() with no intervening call to fetch(), an InstrTriggerState
        exception will be raised.
        
        This function is identical to calling trigger() then fetch() back to back.
        """
        if self._retr_state( "triggered" ):
            raise InstrTriggerState(self)
        self.trigger()
        return self.fetch()
        
    def _verify_properties(self):
        """A hook for verifying properties that may have been set
        by keyword arguments.
        
        The purpose is to ensure that certain properties that must be
        of certain types, like int/float/string/None, or that must take on certain
        values are valid.
        
        Invalid properties should raise an InstrPropertyError exception.
        """
        pass


