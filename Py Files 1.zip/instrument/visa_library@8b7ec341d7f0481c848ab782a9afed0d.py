import logging

## define flags for values_format pyVisa field ##
VF_ASCII = 0
VF_SINGLE = 1
VF_DOUBLE = 3
VF_LITTLEENDIAN = 0
VF_BIGENDIAN = 4

def get_visa():
    """Get the pyVISA module.  This is handled differently than a standard import
    because it is nice to be able to conditionally include VISA for debugging
    purposes on machines that do not have NI VISA installed.
    """
    #### TODO: determine if the VISA library needs to be loaded from a non-standard
    #          location
    #
    
    import visa
    return visa
    
class VisaDebugger(object):
    """Log debug messages for VISA calls."""
    
    def __init__(self, vi):
        self.__visa = vi
        self.__log = logging.getLogger('instrument.VisaDebugger')
        
    def read(self):
        r = self.__visa.read()
        self._debugmsg('read()',r)
        return r        
    
    def write(self, msg):
        self._debugmsg('write(%s)'%repr(msg))
        self.__visa.write(msg)    
    
    def ask(self, msg,*args):
        r = self.__visa.ask(msg,*args)
        self._debugmsg('ask(%s)'%repr(msg),r)
        return r    
    
    def read_values(self,*args):
        r = self.__visa.read_values(*args)
        self._debugmsg('read_values()',r)
        return r        
        
    def ask_for_values(self, msg, *args):
        r = self.__visa.ask_for_values(msg,*args)
        self._debugmsg('ask_for_values(%s)'%repr(msg),r)
        return r        
        
    def read_raw(self):
        r = self.__visa.read_raw()
        self._debugmsg('read_raw()',r)
        return r
    
    def clear(self):
        self._debugmsg('CLEAR')
        self.__visa.clear()        
        
    def trigger(self):
        self._debugmsg('TRIGGER')
        self.__visa.trigger()
    
    def close(self):
        self._debugmsg('close()')
        self.__visa.close()
    
    def _getstb(self):
        st = self.__visa.stb
        self._debugmsg('STB = %d (%x)'%(st,st))
        return st
    stb = property(_getstb)
        
    def _getrsc(self):
        return self.__visa.resource_name
    resource_name = property(_getrsc)
    
    def __getattr__(self, key):
        self._debugmsg("unlogged access to '%s'"%key)
        return getattr(self.__visa,key)
        
    def _debugmsg(self, cmd, ret=None):
        self.__log.debug('%-20s: %s'%(self.resource_name,cmd))
        if ret is not None:
            r = repr(ret)
            if len(r) > 255:
                r = r[:251] + "...'"
            self.__log.debug("   Response: %s"%r)
    
    def _getvi(self):
        return self.__visa


