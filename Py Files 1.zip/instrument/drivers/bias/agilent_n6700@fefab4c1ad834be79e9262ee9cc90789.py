from instrument.family.bias import BiasInstrument, VOLTAGE, CURRENT
from instrument import timed_wait_ms, register

class Agilent_N6700_Driver(BiasInstrument):

    drvname = 'Keysight N670x'
    regex = r'n?670[04]?'
    
    def __init__(self, *args, **kwargs):
        """Create the driver object."""
        # define capabilities and call the parent initializer
        kwargs['capabilities'] = ('source_v','source_i',
            'measure_v','measure_i')
        super(Agilent_N6700_Driver,self).__init__(*args,**kwargs)
        
        if self.chan == 0:
            self.chan = 1
        
        # automatically run instrument initialization
        self.init()
        
    def init(self):
        nch = int(self.vi.ask("SYST:CHAN:COUN?").strip('+'))
        #Configure legal channels
        #self._config_legal_channels([x for x in range(1,nch+1)])
        # set up the channel configuration dictionaries
        p = self._get_params(self.chan)
        p['state'] = 0
        p['mode'] = VOLTAGE
        p['vset'] = 0.0
        p['iset'] = 0.0
        # Get the module type
        self.type = self.vi.ask(":SYST:CHAN:MOD? (@%d)"%self.chan).strip('\n')
        
        if self.type == 'N6784A':
            # Set the default mode to source voltage
            if p['mode'] == VOLTAGE:
                p['mode'] = 'VOLT'
                self.vi.write("OUTP %d,(@%d); FUNC %s,(@%d);VOLT %d,(@%d)"%(p['state'],self.chan,p['mode'],self.chan,p['vset'],self.chan))
            else:
                p['mode'] = 'CURR'
                self.vi.write("OUTP %d,(@%d); FUNC %s,(@%d);CURR %d,(@%d)"%(p['state'],self.chan,p['mode'],self.chan,p['vset'],self.chan))
        else:
            self.vi.write("OUTP %d,(@%d); VOLT %d,(@%d)"%(p['state'],self.chan,p['vset'],self.chan))
        
    def _close(self):
        self.vi.write("OUTP 0,(@%d)"%self.chan)
        self._get_params()['state'] = 0
        
    def config(self, chan=None, **kwargs):
        self._vicheck()
        
        ch = self._get_channel(chan = chan)
        p = self._get_params(ch)
        mode = p['mode']
                
        rlkw = ('vlimit','ilimit','vrange','irange','vmrange','imrange')
        for k in rlkw:
            if k in kwargs:
                v = kwargs.pop(k)
                if v is None:
                    p[k] = v
                else:
                    try:
                        p[k] = abs(float(v))
                    except ValueError:
                        raise ValueError(k)
        
        # store changes in the vset/iset values
                
        vset, iset = False, False
        if 'vset' in kwargs:
            p['vset'] = float(kwargs.pop('vset'))
            vset = True
        if 'iset' in kwargs:
            p['iset'] = float(kwargs.pop('iset'))
            iset = True
            
        mode_changed = False
        if 'mode' in kwargs and mode != kwargs['mode']:
            # need to change the operating mode
            mode = kwargs.pop('mode')
            if mode not in ('v','i',VOLTAGE,CURRENT):
                raise ValueError("Invalid 'mode'.")                
            if self.type == 'N6784A':
                if mode in ('v',VOLTAGE):
                    self.vi.write('FUNC VOLT,(@%d)'%(ch))
                else:
                    self.vi.write('FUNC CURR,(@%d)'%(ch))
                    
            self.vi.write("OUTP 0,(@%d)"%ch)
            timed_wait_ms(50)
            p['mode'] = mode
            p['state'] = 0   
                       
            mode_changed = True
            
        # set the source
		
        v,i,vrng,irng = self._n6700_src_compl(p,ch)
        
		# This is a comment
        if p.get('vrange') is not None:
            vrng = p.get('vrange')
            
        if p.get('irange') is not None:
            irng = p.get('irange')

        if (mode == VOLTAGE or mode =='v') and (mode_changed or vset):
            if self.type == 'N6784A':
                # Set the current limits
                self.vi.write(':CURR:LIM:COUP 1,(@%d)'%(ch))
                if 'ilimit' in p:
                    self.vi.write(':CURR:LIM %f,(@%d)'%(p['ilimit'],ch))
                self.vi.write(':SENS:CURR:RANG %f,(@%d)'%(irng,ch))
                self.vi.write(':VOLT:RANG %f,(@%d)'%(vrng,ch))
                self.vi.write('SOUR:VOLT %f,(@%d)'%(p['vset'],ch))
            else:
                self.vi.write("CURR:RANG %f,(@%d)"%(irng,ch))
                if 'ilimit' in p:
                    self.vi.write("CURR %f,(@%d)"%(p['ilimit'],ch))
                self.vi.write("VOLT:RANG %f,(@%d)"%(vrng,ch))
                self.vi.write("SOUR:VOLT %f,(@%d)"%(p['vset'],ch))
                
        elif (mode == CURRENT or mode =='i') and (mode_changed or iset):
            if self.type == 'N6784A':
                self.vi.write(':VOLT:LIM:COUP 1,(@%d)'%(ch))
                if p['vlimit'] is not None:
                    self.vi.write(':VOLT:LIM %f,(@%d)'%(p['vlimit'],ch))
                else:
                    self.vi.write(':VOLT:LIM %f,(@%d)'%(v,ch))
                self.vi.write(':SENS:VOLT:RANG %f,(@%d)'%(vrng,ch))
                self.vi.write(':CURR:RANG %f,(@%d)'%(irng,ch))
                self.vi.write('SOUR:CURR %f,(@%d)'%(p['iset'],ch))
            else:
                self.vi.write("VOLT:RANG %f,(@%d)"%(vrng,ch))
                if p['vlimit'] is not None:
                    self.vi.write("VOLT %f,(@%d)"%(v,ch))
                self.vi.write("CURR:RANG %f,(@%d)"%(irng,ch))
                self.vi.write("SOUR:CURR %f,(@%d)"%(p['iset'],ch))
                
        if 'state' in kwargs:
            s = bool(kwargs.pop('state'))
            if s and not p['state']:
                self.vi.write('OUTP 1,(@%d)'%ch)
                p['state'] = 1
            elif not s and p['state']:
                self.vi.write('OUTP 0,(@%d)'%ch)
                p['state'] = 0
                
        # pass additional keyword arguments on to pyVISA
        if len(kwargs):
            self.configure_vi(**kwargs)
            
            
    def get_current_limit(self,chan = None):
        ch = self._get_channel(chan = chan)
        print "Measured Gate Limit %f"%float(self.vi.ask('CURR:LIM? (@%d)'%ch))
        
    def initiate(self,chan=None):
        """Initiate a measurement."""
        self._vicheck()
        if self._use_srqs:
            # don't know what to do here
            pass
        # instrument measures continuously
        # no need to do anything
        
    def get_source(self):
        # Returns the sourced voltage or current
        ch = self._get_channel(chan = chan)
        p = self._get_params(ch)
        if p['mode'] == CURRENT or p['mode'] == 'i':
            return p['iset']
        else:
            return p['vset']            
        
    def ask_if_done(self,chan=None):
        """Check to see if a pending measurement is done."""
        # this instrument has no capacity for trigger, so it
        # is always ready to measure
        return True
        
    def ask_if_limiting(self,chan=None):
        self._vicheck()
        ch = self._get_channel(chan=chan)
        p = self._get_params(ch)
        vm = float(self.vi.ask(':MEAS:VOLT? (@%d)'%ch))         
        im = float(self.vi.ask(':MEAS:CURR? (@%d)'%ch)) 
        
        if p['mode'] == CURRENT or p['mode'] == 'i':
            ret = vm
            if abs(vm - p['vlimit']) < 0.08 and abs(im - p['iset']) > 0.003:
                return True                
        else:
            ret = im
            if abs(im - p['ilimit']) < 0.003 and abs(vm - p['vset']) > 0.08:
                return True
               
        
    def fetch(self,chan=None):
        """Retrieve a measurement from the instrument."""
        self._vicheck()
        ch = self._get_channel(chan=chan)
        p = self._get_params(ch)
        # read voltage and current
        vm = float(self.vi.ask(':MEAS:VOLT? (@%d)'%ch))         
        im = float(self.vi.ask(':MEAS:CURR? (@%d)'%ch)) 
        if p['mode'] == CURRENT or p['mode'] == 'i':
            ret = vm
            if abs(vm - p['vlimit']) < 0.08 and abs(im - p['iset']) > 0.003:
                p['limiting'] = True                
        else:
            ret = im
            if abs(im - p['ilimit']) < 0.003 and abs(vm - p['vset']) > 0.08:
                p['limiting'] = True
                               
        return ret
        
                
    def _n6700_src_compl(self,params,chan):
        # For current mode, make sure the current being set is valid 
        # Also make sure that the compliance is valid
        if params['mode'] == CURRENT or params['mode'] == 'i':
            i = params.get('iset',0.0)
            v = params.get('vlimit')
            
            if self.type == 'N6784A':
                if i > 3.0:
                    i = 3.0
                elif i < -3.0:
                    i = -3.0
                if abs(i) <= 1.0:
                    if v > 6.0:
                        v = 6.0
                elif v > 20.0:
                    v = 20.0
            
            if self.type == 'N6762A':
                if abs(i) > 3.0:
                    i = 3.0
                if v > 50.0:
                    v = 50.0
                    
            if self.type == 'N6736B':
                if abs(i) > 0.5:
                    i = 0.5
                if v > 100.0:
                    v = 100.0
            
            if self.type == 'N6746B':
                if i > 1.0:
                    i = 1.0
                if v > 100.0:
                    v = 100.0
        # Set correct compliance and source if in voltage source mode            
        else:
            v = params.get('vset',0.0)
            i = params.get('ilimit')
            if self.type == 'N6784A':
                if v > 20.0:
                    v = 20.0
                elif v < -20.0:
                    v = -20.0
                if abs(v) <= 6.0:
                    if i > 3.0:
                        i = 3.0
                elif i > 1.0:
                    i = 1.0
            
            if self.type == 'N6762A':
                if abs(v) > 50.0:
                    v = 50.0
                if i > 3.0:
                    i = 3.0
                    
            if self.type == 'N6736B':
                if abs(v) > 100.0:
                    v = 100.0
                if i > 0.5:
                    i = 0.5
            
            if self.type == 'N6746B':
                if abs(v) > 100.0:
                    v = 100.0
                if i > 1.0:
                    i = 1.0
                    
                    
        return self._get_ranges(v,i,params)
        
    def _get_ranges(self,v,i,params):
        if params['mode'] == VOLTAGE or params['mode'] == 'v':
            vrange = params.get('vrange')
            irange = params.get('irange')
            if self.type == 'N6784A':
                if v > 6.0:
                    vrange = 20.0
                else:
                    vrange = 6.0
                if i > 1.0:
                    irange = 3.0
                elif i > 0.1:
                    irange = 1.0
                elif i > 0.01:
                    irange = 0.1
                else:
                    irange = 0.01
                    
            if self.type == 'N6762A':
                
                if v > 5.0:
                    vrange = 50.0
                else:
                    vrange = 5.0
                if i > 0.1:
                    irange = 3.0
                else:
                    irange = 0.1
                    
            if self.type == 'N6736B':
                
                vrange = 100.0
                irange = 0.5
            if self.type == 'N6746B':
                vrange = 100.0
                irange = 1.0
                
        if params['mode'] == CURRENT or params['mode'] == 'i':
            vrange = params.get('vrange')
            irange = params.get('irange')
            if self.type == 'N6784A':
                if i > 1.0:
                    irange = 3.0
                elif i > 0.1:
                    irange = 1.0
                elif i > 0.01:
                    irange = 0.1
                else:
                    irange = 0.01
                if v > 6.0:
                    vrange = 20.0
                else:
                    vrange = 6.0
                    
            if self.type == 'N6762A':
                if i > 0.1:
                    irange = 3.0
                else:
                    irange = 0.1
                if v > 5.0:
                    vrange = 50.0
                else:
                    vrange = 5.0
                    
            if self.type == 'N6736B':
                vrange = 100.0
                irange = 0.5
                
            if self.type == 'N6746B':
                vrange = 100.0
                irange = 1.0
                
               
        return v,i,vrange,irange
       
register(Agilent_N6700_Driver)
            
        
                
                
                
                
                
        
            
        
                    
        
            