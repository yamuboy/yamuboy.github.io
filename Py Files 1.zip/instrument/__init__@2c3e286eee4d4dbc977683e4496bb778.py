# setup module logging
import logging_setup as _logging_setup

# import some stuff that needs to be imported early
from utils import timed_wait, timed_wait_ms

# import some core modules
from base import InstrumentManager, register, create, driver
from errors import *

# import the instrument families before any drivers are imported
# otherwise a recursive import will occur and an error will be raised
import family

# import the drivers to cause them to register themselves
import drivers as _drivers

# create some shortcuts/aliases
manager = InstrumentManager
