# setup module logging
import logging as _l

logger = _l.getLogger('instrument')
# point the top-level library log target at the null handler
logger.addHandler(_l.NullHandler())

