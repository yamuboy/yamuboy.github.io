import wx
from pivgui.gui import PIV_Main

# create app and main window and run
app = wx.App(redirect=False)
main = PIV_Main(None,debug=False)
app.MainLoop()
