"""
CATV Matrix Test stand GUI
Main application window





"""
import wx
from wx.lib.newevent import NewEvent
    
import os, os.path, sys, logging
from datetime import datetime

from wxtestgui import Param, TestParameters, EditTestParamsDialog, InstrumentConfigDialog, ApplicationPreferences
from wxtestgui.worker import Worker, EVT_WORKER_MESSAGE, EVT_WORKER_EXITING

from .params import TEST_PARAMS
from .instruments import INSTR_LIST
from macomplot import get_canvas_by_name, PlotlibFrame

from . import test_worker
from . import executive

logger = logging.getLogger('piv.gui')

# data for the About dialog
about_info = wx.AboutDialogInfo()
about_info.SetCopyright('MACOM (2016)')
about_info.SetDescription('Pulsed I-V application for operating the\nFocus pulsed I-V system.')
about_info.SetName('Pulsed I-V (Focus)')
about_info.SetVersion('0.1')
about_info.SetDevelopers(['Modeling Team',])

# which entry points to use (for easy debugging)
IV_SWEEP_FUNCTION = executive.iv_sweep_main
MANUAL_MODE_FUNCTION = executive.manual_mode_main

def box_panel( parent, label ):
    "convenience function to create a StaticBox+StaticBoxSizer inside a Panel"
    panel = wx.Panel(parent)
    sz = wx.BoxSizer(wx.VERTICAL)
    bsz = wx.StaticBoxSizer(wx.StaticBox(panel,label=label),wx.VERTICAL)
    sz.Add(bsz,1,wx.EXPAND|wx.ALL,3)
    panel.SetSizer(sz)
    return panel, bsz

def show_error_dialog( msg, title='Error' ):
    "convenience function for showing an error dialog"
    dlg = wx.MessageDialog(None,msg,title,wx.OK|wx.ICON_ERROR)
    dlg.ShowModal()
    dlg.Destroy()

def position_dialog(parent, dialog, xoffset=100, yoffset=100):
    "position a dialog at an offset from it's parent"
    x, y = parent.GetPositionTuple()
    dialog.SetPosition( (x+xoffset,y+yoffset) )

# logging event and event ID
LoggingEvent, EVT_LOG_RECORD = NewEvent()    
    
class GuiLoggingHandler(logging.Handler):
    "handler that passes log messages to a UI window"
    
    def __init__(self, wxobj=None):
        "initializer"
        super(GuiLoggingHandler,self).__init__()
        self._wxobj = wxobj
        self.formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s','%H:%M:%S')
    
    def emit(self, record):
        "handle a logging record"
        if isinstance(self._wxobj,wx.Window):
            m = self.format(record)
            wx.PostEvent(self._wxobj,LoggingEvent(message=m,levelno=record.levelno))
    
    def flush(self):
        "does nothing"
        pass
        
        
        
    
    
class PIV_Main(wx.Frame):
    """Main frame for the pulsed I-V application"""
    
    def __init__(self, *args, **kwargs):
        "initializer"
        loglvl = logging.INFO
        if kwargs.pop('debug',False):
            loglvl = logging.DEBUG
        if kwargs.pop('demo',False):
            global IV_SWEEP_FUNCTION
            global MANUAL_MODE_FUNCTION
            IV_SWEEP_FUNCTION = test_worker.main
            MANUAL_MODE_FUNCTION = test_worker.manual
        
        super(PIV_Main,self).__init__(*args,**kwargs)
        
        # store the test configuration parameters
        self.params = TestParameters(TEST_PARAMS)

        # store the greyed out text color for later
        self.GRAYTEXT = wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT)
        self.INFOTEXT = wx.Colour(0,0,200)
        
        # set up some varialbes
        self._current_setup = None
        self.working_path = os.getcwd()
        self._unsaved_params = False
        self._worker_thread = None
        self._plot_iv_window = None
        self._plot_spar_window = None
        self._last_iv_file = None       
        self._last_spar_file = None       
                
        # init the window
        self.InitUI()
                
        # create some dialogs
        self._parms_dlg = EditTestParamsDialog(self.params.get_dialog_list(),parent=self)
        self._instr_dlg = InstrumentConfigDialog(INSTR_LIST,parent=self)
        self._manual_dlg = PIV_ManualMode(parent=self)
        
        # create logging styles
        self._logstyle_debug = wx.TextAttr('#b0b0b0')
        self._logstyle_error = wx.TextAttr('#dd0000')
        self._logstyle_warning = wx.TextAttr('#ff6600')
        
        # set up logging
        root = logging.getLogger()
        root.addHandler(GuiLoggingHandler(self))
        root.setLevel(loglvl)
        self.Bind(EVT_LOG_RECORD,self.OnHandleLogMsg)
        ## for debugging
        ##root.addHandler(logging.StreamHandler())
        
        # load preferences
        prefs_file = os.path.expanduser('~/.pivgui')
        self.prefs = ApplicationPreferences(prefs_file)
        try:
            self.prefs.load()
            logger.debug("loaded preferences from '%s'"%prefs_file)
        except Exception as e:
            logger.warning("error loading preferences file '%s' -> %s"%(prefs_file,e))
        
        # initialize instrument configuration
        idata = self.prefs.get('instruments',{})
        for instr in INSTR_LIST:
            if instr.name in idata:
                i = idata[instr.name]
                if not instr.static:
                    instr.driver_name = i['drv']
                instr.resource = i['rsc']
                instr.chan = i['chan']
                instr.parms = i['parms']        

        # set the focus
        self.controls['edit_params'].SetFocus()
        
        # bind worker thread events
        self.Bind(EVT_WORKER_MESSAGE,self.OnWorkerMessage)
        self.Bind(EVT_WORKER_EXITING,self.OnWorkerExit)        
        
        # bind close events
        self.Bind(wx.EVT_CLOSE,self.OnCloseWindow)
                
        # set up the main window size and position
        self.SetSize( self.prefs.get('mainwin_size',(600,400)) )
        self.SetPosition( self.prefs.get('mainwin_position',(100,100)) )

        # set the title
        self.SetTitle('Pulsed I-V')
        
        # try to load the last setup
        fname = self.prefs.get('last_setup',None)
        if fname:
            self._load_setup(fname)
        
        # show the window
        if self.prefs.get('mainwin_maximized',False):
            self.ShowFullScreen(True)
        else:
            self.Show(True)
        logger.info('Ready.')

        self._parms_dlg.CenterOnParent()
        self._instr_dlg.CenterOnParent()
        self._manual_dlg.CenterOnParent()
        
        
    def InitUI(self):
        "initialize the UI"
        
        # store the controls that are created
        # and menu items that need to be disabled during auto testing
        self.controls = {}
        self.controls_to_disable = []
        
        
        #### create a menu bar ####
        
        menubar = wx.MenuBar()
        filemenu = wx.Menu()
        file1 = filemenu.Append(wx.ID_OPEN, '&Open Setup ...\tCtrl-O', 'Open setup configuration')
        self._save_ctrl = filemenu.Append(wx.ID_SAVE, '&Save Setup\tCtrl-S', 'Save setup configuration')
        file2 = filemenu.Append(wx.ID_SAVEAS, 'Save Setup &As ...', 'Save setup configuration as')
        filemenu.AppendSeparator()
        file3 = filemenu.Append(wx.ID_EXIT, '&Quit\tCtrl-Q', 'Quit application')
        self.Bind(wx.EVT_MENU,self.OnLoadSetup,file1)
        self.Bind(wx.EVT_MENU,self.OnSaveSetup,self._save_ctrl)
        self.Bind(wx.EVT_MENU,self.OnSaveSetupAs,file2)
        self.Bind(wx.EVT_MENU,self.OnQuit,file3)
        menubar.Append(filemenu, '&File')
        self._save_ctrl.Enable(False)
        
        setupmenu = wx.Menu()
        setup1 = setupmenu.Append(wx.ID_ANY, 'Instruments ...\tCtrl-I', 'Setup instruments')
        setup2 = setupmenu.Append(wx.ID_ANY, 'Parameters ...\tCtrl-P', 'Set configuration parameters')
        self.Bind(wx.EVT_MENU,self.OnSetupInstr,setup1)
        self.Bind(wx.EVT_MENU,self.OnEditParams,setup2)
        menubar.Append(setupmenu, '&Setup')
                
        helpmenu = wx.Menu()
        help1 = helpmenu.Append(wx.ID_ANY, 'About ...\tF1', 'Program information')
        self.Bind(wx.EVT_MENU,self.OnAbout,help1)
        menubar.Append(helpmenu, '&Help')
        
        self.SetMenuBar(menubar)
        self.controls_to_disable.extend( [file1,file3,setup1,setup2] )
                
        #### create the body area of the window ####
        
        # main panel, needed in order to get consistency on all platforms
        mainpanel = wx.Panel(self)
        mainsz = wx.BoxSizer(wx.VERTICAL)
        mainpanel.SetSizer(mainsz)
        
        # sizer for the configuation and run panels
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        mainsz.Add(hsz,0,wx.ALL|wx.EXPAND,5)
        
        ## configuration box ##
        
        cfgpan, cfgsz = box_panel(mainpanel,'Configuration')
        self.controls['edit_params'] = wx.Button(cfgpan,wx.ID_ANY,"Test Params")
        self.Bind(wx.EVT_BUTTON,self.OnEditParams,self.controls['edit_params'])
        self.controls['meas_sparams'] = wx.CheckBox(cfgpan,wx.ID_ANY,"Measure S-Params")
        self.controls['meas_gmgds'] = wx.CheckBox(cfgpan,wx.ID_ANY,"Measure gm+gds")
        
        self.controls_to_disable.extend( [self.controls['edit_params'],self.controls['meas_sparams'],self.controls['meas_gmgds']] )
        
        cfgsz.Add(self.controls['edit_params'])
        cfgsz.Add((-1,10))
        cfgsz.Add(self.controls['meas_sparams'])
        cfgsz.Add((-1,3))
        cfgsz.Add(self.controls['meas_gmgds'])
        cfgsz.Add((-1,5))
        hsz.Add(cfgpan,0,wx.RIGHT|wx.EXPAND,2)
        
        
        ## test run box ##
        
        runpan, runsz = box_panel(mainpanel,'Run')
        self.controls['run_manual'] = wx.Button(runpan,wx.ID_ANY,"Manual")
        self.Bind(wx.EVT_BUTTON,self.OnRunManual,self.controls['run_manual'])
        self.controls['run_sweep'] = wx.Button(runpan,wx.ID_ANY,"I-V Curves")
        self.Bind(wx.EVT_BUTTON,self.OnRunSweep,self.controls['run_sweep'])
        self.controls['pause'] = wx.Button(runpan,wx.ID_ANY,"Pause")
        self.Bind(wx.EVT_BUTTON,self.OnPauseTest,self.controls['pause'])
        self.controls['abort'] = wx.Button(runpan,wx.ID_ANY,"Abort")
        self.Bind(wx.EVT_BUTTON,self.OnAbort,self.controls['abort'])
        self.controls['abort'].Enable(False)
        self.controls['abort'].SetForegroundColour('#ff0000')
        self.controls['pause'].Enable(False)
        self.controls['pause'].SetForegroundColour('#ff6600')

        self.controls_to_disable.extend( [self.controls['run_manual'],self.controls['run_sweep']] )
        
        runsz.Add(self.controls['run_manual'],5,wx.TOP|wx.LEFT|wx.RIGHT)
        runsz.Add((-1,25))
        runsz.Add(self.controls['run_sweep'],5,wx.LEFT|wx.RIGHT)
        runsz.Add((-1,5))
        runsz.Add(self.controls['pause'],5,wx.LEFT|wx.RIGHT)
        runsz.Add((-1,5))
        runsz.Add(self.controls['abort'],5,wx.LEFT|wx.RIGHT)
        runsz.Add((-1,5))
        hsz.Add(runpan,0,wx.RIGHT|wx.EXPAND,2)

        ## plot box ##
        
        plotpan, plotsz = box_panel(mainpanel,'Plot')
        self.controls['plot_iv'] = wx.Button(plotpan,wx.ID_ANY,"I-V Plot")
        self.Bind(wx.EVT_BUTTON,self.OnPlotIV,self.controls['plot_iv'])
        self.controls['plot_spars'] = wx.Button(plotpan,wx.ID_ANY,"Spar Plot")
        self.Bind(wx.EVT_BUTTON,self.OnPlotSpars,self.controls['plot_spars'])
        
        plotsz.Add(self.controls['plot_iv'])
        plotsz.Add((-1,10))
        plotsz.Add(self.controls['plot_spars'])
        plotsz.Add((-1,5))
        hsz.Add(plotpan,0,wx.RIGHT|wx.EXPAND,2)
        
        ## log panel ##
        
        mainsz.Add((-1,5))
        mainsz.Add(wx.StaticText(mainpanel,-1,'Log Window'),0,wx.ALL,5)
        self.log_window = wx.TextCtrl(mainpanel,style=wx.TE_READONLY|wx.TE_MULTILINE|wx.HSCROLL|wx.TE_RICH2)
        mainsz.Add(self.log_window,1,wx.LEFT|wx.RIGHT|wx.EXPAND,5)
        mainsz.Add((-1,5))
                        
    def OnAbout(self, event):
        "show the program information dialog"
        wx.AboutBox(about_info)        
    
    def OnLoadSetup(self, event):
        "load a setup file"
        # check if the current setup has been saved
        if self._unsaved_params:
            dlg = wx.MessageDialog(self,'The current test setup is unsaved.\nAre you sure you want to load a new one?','Confirm',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
            position_dialog(self,dlg)
            if dlg.ShowModal() != wx.ID_YES:
                dlg.Destroy()
                return
            dlg.Destroy()
        
        dir = ''
        if self._current_setup:
            dir = os.path.split(self._current_setup)[0]
        kw = {'style':wx.FD_OPEN,'wildcard':"Setup Files (*.stp)|*.stp"}
        if dir and os.path.isdir(dir):
            kw['defaultDir'] = dir
        dlg = wx.FileDialog(self,'Load Setup',**kw)
        position_dialog(self,dlg)
        if dlg.ShowModal() == wx.ID_OK:
            self._load_setup(dlg.GetPath())
        dlg.Destroy()
    
    def _load_setup(self, fname):
        "load a setup"
        try:
            self.params.load(fname)
            self._unsaved_params = False
            self._current_setup = fname
            logger.info("loaded setup file '%s'"%fname)
            self._save_ctrl.Enable(True)
        except Exception as e:
            logger.error("could not load setup file '%s' -> %s"%(fname,e))
            show_error_dialog('\n'.join([unicode(x) for x in e.allerrs]),'Errors during load')
        
    def OnSaveSetup(self, event):
        "save a setup using the current name"
        if not self._current_setup:
            logger.error("cannot save setup - use Save Setup As instead")
        else:
            self._save_setup(self._current_setup)
        
    def OnSaveSetupAs(self, event):
        "save the current setup"
        dir = ''
        if self._current_setup:
            dir = os.path.split(self._current_setup)[0]
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT,'wildcard':"Setup Files (*.stp)|*.stp"}
        if dir and os.path.isdir(dir):
            kw['defaultDir'] = dir
            
        dlg = wx.FileDialog(self,'Save Setup',**kw)
        position_dialog(self,dlg)
        if dlg.ShowModal() == wx.ID_OK:
            self._save_setup(dlg.GetPath())
        dlg.Destroy()
    
    def _save_setup(self, fname):
        "save a setup file"
        self.params.save(fname)            
        self._unsaved_params = False
        self._current_setup = fname
        logger.info("saved setup file '%s'"%fname)
        self._save_ctrl.Enable(True)
                
    def OnSetupInstr(self, event):
        "open the instrument setup dialog"
        self._instr_dlg.ShowModal()
        
    def OnEditParams(self, event):
        "open the options configuration dialog"
        if self._parms_dlg.ShowModal() == wx.ID_OK:
            self._unsaved_params = True
            
    def OnHandleLogMsg(self, event):
        "handle log messages"
        lvl = event.levelno
        sty = None
        if lvl in (logging.ERROR,logging.CRITICAL):
            sty = self._logstyle_error
        elif lvl == logging.WARNING:
            sty = self._logstyle_warning
        elif lvl == logging.DEBUG:
            sty = self._logstyle_debug
        
        n = self.log_window.GetLastPosition()
        self.log_window.AppendText(event.message.strip()+'\n')
        n2 = self.log_window.GetLastPosition()
        
        if sty:
            self.log_window.SetStyle(n,n2,sty)
        
        self.log_window.ShowPosition(n2)        
    
    def OnRunSweep(self, event):
        "start the automatic test routine"
        instr = [i.copy() for i in INSTR_LIST]
        parms = self.params.get_param_dict()
        
        # get the state of the measure S-params and measure gm+gds checkboxes
        parms['measure_spars'] = self.controls['meas_sparams'].GetValue()
        parms['measure_gmgds'] = self.controls['meas_gmgds'].GetValue()
        
        # prompt for a filename for the data to be saved to
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT|wx.FD_CHANGE_DIR,
            'wildcard':"PIV Files (*.piv)|*.piv",
            }            
        dlg = wx.FileDialog(self,'Save PIV data to',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            dlg.Destroy()
        else:
            dlg.Destroy()
            return
        
        arglist = [instr,parms,fname]
        
        # check if an S-param file will be overwritten
        if parms['measure_spars']:
            spar_fname = os.path.splitext(fname)[0]+'.psp'
            arglist.append(spar_fname)
            if os.path.isfile(spar_fname):
                dlg = wx.MessageDialog(self,"Continuing will overwrite the following S-parameter data file:\n'%s'\n\nAre you sure you want to continue?"%spar_fname,'Confirm Overwrite',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_WARNING)
                if dlg.ShowModal() != wx.ID_YES:
                    dlg.Destroy()
                    return
                dlg.Destroy()
            self._last_spar_file = spar_fname       

        self._last_iv_file = fname       
    
        # start the worker thread
        self._sweep_running(True)
        self._worker_thread = Worker(self,target=IV_SWEEP_FUNCTION,args=arglist)
        self._worker_thread.start()
        
    def OnPauseTest(self, event):
        "pause or resume an I-V sweep"
        if not self._worker_thread:
            logger.warn('cannot pause/resume -> no test is running')
            return
            
        lab = self.controls['pause'].GetLabel()
        if lab == 'Pause':
            logger.info('sending pause signal ...')
            self._worker_thread.comm.send_to_worker('pause')        
            self.controls['pause'].SetLabel('Resume')
        else:
            logger.info('sending resume signal ...')
            self._worker_thread.comm.send_to_worker('resume')        
            self.controls['pause'].SetLabel('Pause')
        
    def OnAbort(self, event):
        "abort auto testing"
        if not self._worker_thread:
            logger.warn('cannot abort -> no test is running')
            return
        logger.info('sending abort signal ...')
        self._worker_thread.comm.send_to_worker('abort')        
        
    def OnRunManual(self, event):
        "manual mode"
        self._manual_dlg.ShowModal()
    
    def OnWorkerMessage(self, event):
        "handle messages from the worker"
        mtype = event.msgtype
        data = event.payload
        
        if mtype == 'ivfile':
            if self._plot_iv_window and not self._plot_iv_window.IsBeingDeleted():
                self._plot_iv_window.set_plot_file(data)
        elif mtype == 'sparfile':
            if self._plot_spar_window and not self._plot_spar_window.IsBeingDeleted():
                self._plot_spar_window.set_plot_file(data)
        else:
            logger.debug('received an unhandled message from the worker: '+mtype)
        
    def OnWorkerExit(self, event):
        "handle when the worker thread exits"
        self._sweep_running(False)
        self.controls['run_sweep'].SetFocus()
        if event.exitstatus:
            logger.error('I-V sweep error -> '+event.message)
            show_error_dialog('Error during test.\n'+event.message)
        else:
            logger.info('Test complete.')
        
        self._worker_thread.join()
        self._worker_thread = None
        
    def OnPlotIV(self, event):
        "open/raise the IV plot window"
        w = None
        if self._plot_iv_window:
            w = self._plot_iv_window
            if not w.IsBeingDeleted():
                if w.IsIconized():
                    w.Iconize(False)
                w.Show(True)
                w.Raise()
            else:
                self._plot_iv_window = None
                w = None
                
        if not w:
            # window did not exist or was invalid, need to re-create
            c = get_canvas_by_name('pulsediv')
            w = PlotlibFrame(None,canvas_class=c)
            w.SetTitle('Plot: Pulsed I-V')
            self._plot_iv_window = w
        
        # point the most recent/current data file at the window
        w.set_plot_file(self._last_iv_file)
        
    def OnPlotSpars(self, event):
        "open/raise the S-parm plot window"
        w = None
        if self._plot_spar_window:
            w = self._plot_spar_window
            if not w.IsBeingDeleted():
                if w.IsIconized():
                    w.Iconize(False)
                w.Show(True)
                w.Raise()
            else:
                self._plot_spar_window = None
                w = None
                
        if not w:
            # window did not exist or was invalid, need to re-create
            c = get_canvas_by_name('ssparams')
            w = PlotlibFrame(None,canvas_class=c)
            w.SetTitle('Plot: Pulsed S-Parameters')
            self._plot_spar_window = w
        
        # point the most recent/current data file at the window
        w.set_plot_file(self._last_spar_file)
        
    def _sweep_running(self, flag):
        "disable/enable UI elements when a I-V sweep is running"
        st = not bool(flag)

        for ctrl in self.controls_to_disable:
            ctrl.Enable(st)
        
        # set the abort and pause buttons
        self.controls['abort'].Enable(flag)
        self.controls['pause'].Enable(flag)
        self.controls['pause'].SetLabel('Pause')
        
    def OnQuit(self, event):
        "callback for a quit action"
        self.Close()
        
    def OnCloseWindow(self, event):
        "event callback for closing the window"
        if self._worker_thread:
            # test in running, cannot exit
            show_error_dialog('Cannot exit while a test is running.\nPlease abort the current test first.')
            event.Veto()
            return
        
        if self._unsaved_params:
            dlg = wx.MessageDialog(self,'The current test setup is unsaved.\nAre you sure you want to quit?','Confirm',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION|wx.CENTRE)
            position_dialog(self,dlg)
            if dlg.ShowModal() != wx.ID_YES:
                event.Veto()
                return
            
        # update the current main window size and position in preferences
        self.prefs['mainwin_maximized'] = self.IsMaximized()
        if not self.prefs['mainwin_maximized']:
            self.prefs['mainwin_size'] = self.GetSizeTuple()
            self.prefs['mainwin_position'] = self.GetPositionTuple()
        
        # save the current setup in preferences
        if self._current_setup:
            self.prefs['last_setup'] = self._current_setup
        else:
            self.prefs['last_setup'] = None
        
        # update instrument settings in the preferences
        data = {}
        for instr in INSTR_LIST:
            data[instr.name] = {'drv':instr.driver_name, 'rsc':instr.resource, 'chan':instr.chan, 'parms':instr.parms}
        self.prefs['instruments'] = data

        # save application preferences
        try:
            self.prefs.save()
        except Exception as e:
            logger.warning("save of preferences file '%s' failed -> %s"%(self.prefs.get_default_filename,e))
            pass
        
        # destroy the plot windows if they exist
        if self._plot_iv_window and not self._plot_iv_window.IsBeingDeleted():
            self._plot_iv_window.Destroy()
        if self._plot_spar_window and not self._plot_spar_window.IsBeingDeleted():
            self._plot_spar_window.Destroy()
           
        # destroy the main window
        self.Destroy()
        
        
        
class PIV_ManualMode(wx.Dialog):

    def __init__(self,*args,**kwargs):
        "initializer"
        super(PIV_ManualMode,self).__init__(*args,**kwargs)
        
        self._piv_enabled = False
        self._worker = None
        self.state = ''
        self.timout_timer = wx.Timer(self)
        
        parent = self.GetParent()
        if not parent or not isinstance(parent,PIV_Main):
            raise ValueError("the parent of `PIV_ManualMode` must by `PIV_Main`")
        self.params = parent.params
        
        # init the UI
        self.InitUI()
        
        # bind close
        self.Bind(wx.EVT_CLOSE,self.OnCloseDialog)
        
        # bind show events
        self.Bind(wx.EVT_SHOW,self.OnShowDialog)        
        
        # bind events from the worker thread
        self.Bind(EVT_WORKER_MESSAGE,self.OnWorkerMessage)
        self.Bind(EVT_WORKER_EXITING,self.OnWorkerExit)
        
        # bind timer events
        self.Bind(wx.EVT_TIMER,self.OnTimeout)
        
        # create a dialog to put up whenever the UI needs
        # to wait for the worker to do something
        self.wait_dialog = WaitForWorker(parent=self)
        
    def InitUI(self):
        "initialize the UI"
        self.controls = {}
                
        # q-point
        
        qpan, qsz = box_panel(self,'Q-Point')
        fgsz = wx.FlexGridSizer(rows=0,cols=2,hgap=8,vgap=6)
        qsz.Add(fgsz,1,wx.EXPAND|wx.ALL,5)
        
        fgsz.Add(wx.StaticText(qpan,-1,'Vg-q'))
        self.controls['vgq'] = wx.TextCtrl(qpan,size=(40,-1))
        self.controls['vgq'].SetValue('%g'%self.params['gate_q'].value)
        fgsz.Add(self.controls['vgq'])
        fgsz.Add(wx.StaticText(qpan,-1,'Vd-q'))
        self.controls['vdq'] = wx.TextCtrl(qpan,size=(40,-1))
        self.controls['vdq'].SetValue('%g'%self.params['drain_q'].value)
        fgsz.Add(self.controls['vdq'])
        
        # pulse voltages
        
        ppan, psz = box_panel(self,'Pulse')
        fgsz = wx.FlexGridSizer(rows=0,cols=2,hgap=8,vgap=6)
        psz.Add(fgsz,1,wx.EXPAND|wx.ALL,5)
        
        fgsz.Add(wx.StaticText(ppan,-1,'Vg'))
        self.controls['vg'] = wx.TextCtrl(ppan,size=(40,-1))
        self.controls['vg'].SetValue('0')
        fgsz.Add(self.controls['vg'])
        fgsz.Add(wx.StaticText(ppan,-1,'Vd'))
        self.controls['vd'] = wx.TextCtrl(ppan,size=(40,-1))
        self.controls['vd'].SetValue('0')
        fgsz.Add(self.controls['vd'])
        
        # pulser controls

        cpan, csz = box_panel(self,'Control Panel')
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        csz.Add(hsz,1,wx.EXPAND|wx.ALL,5)
        
        self.controls['toggle'] = wx.Button(cpan,wx.ID_ANY,"Enable")
        self.Bind(wx.EVT_BUTTON,self.OnToggleState,self.controls['toggle'])
        self.controls['update'] = wx.Button(cpan,wx.ID_ANY,"Update")
        self.Bind(wx.EVT_BUTTON,self.OnUpdate,self.controls['update'])
        self.controls['measure'] = wx.Button(cpan,wx.ID_ANY,"Measure")
        self.Bind(wx.EVT_BUTTON,self.OnMeasure,self.controls['measure'])
        
        hsz.Add(self.controls['toggle'],0,wx.LEFT|wx.RIGHT,8)
        hsz.Add(self.controls['update'],0,wx.LEFT|wx.RIGHT,8)
        hsz.Add(self.controls['measure'],0,wx.LEFT|wx.RIGHT,8)
        self.controls['update'].Enable(False)
        csz.Add((1,1))
        
        # add the various panels to the main dialog panel
        sz = wx.BoxSizer(wx.VERTICAL)
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        hsz.Add(qpan,1,wx.EXPAND|wx.RIGHT,4)
        hsz.Add(ppan,1,wx.EXPAND)
        sz.Add(hsz,0,wx.EXPAND|wx.LEFT|wx.RIGHT,8)
        sz.Add((-1,3))
        sz.Add(cpan,0,wx.EXPAND|wx.LEFT|wx.RIGHT,8)
        sz.Add((-1,8))
        
        # add a seperator
        sep = wx.StaticLine(self)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        self.exit_button = wx.Button(self,wx.ID_CLOSE,'&Quit')
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(self.exit_button)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the Exit button
        self.Bind(wx.EVT_BUTTON,self.OnExit,id=wx.ID_CLOSE)
        
        self.SetSizer(sz)
        
        self.Fit()
        self.SetTitle("Manual Mode")
    
    def OnShowDialog(self, event):
        "handler for when the dialog is shown/hidden"
        if event.GetShow():
            self.state = 'initializing'
            
            # disable all controls
            for c in self.controls.values():
                c.Enable(False)
            self.exit_button.Enable(False)
            
            # set initial state
            self._piv_enabled = False
            self.controls['toggle'].SetLabel('Enable')

            instr = [i.copy() for i in INSTR_LIST]
            parms = self.params.get_param_dict()
            arglist = [instr,parms]
            
            # create the worker thread, passing in appropriate data
            self._worker = Worker(self,target=MANUAL_MODE_FUNCTION,args=arglist)
            #self._worker = Worker(self,target=executive.manual_mode_main,args=arglist)
            self._worker.start()
            
            # start a timer to wait for the thread to be ready
            self.timout_timer.Start(10000,wx.TIMER_ONE_SHOT)
            
            """
            # pop up the wait dialog
            self.wait_dialog.set_text_string('initializing ...')
            parent = self.GetParent()
            pw, ph = parent.GetSizeTuple()
            px, py = parent.GetPositionTuple()
            w, h = self.wait_dialog.GetSizeTuple()
            self.wait_dialog.SetPosition( (px+int(0.5*(pw-w)),py+int(0.5*(ph-h))) )
            self.wait_dialog.ShowModal()
            """
        
    def OnToggleState(self, event):
        "toggle the pulser state"
        self.state = 'toggling'
        if self._piv_enabled:
            self.controls['toggle'].SetLabel('Enable')
            self.controls['update'].Enable(False)
            self._piv_enabled = False
            self._worker.comm.send_to_worker('disable')
            msg = 'disabling pulser ...'
        else:
            try:
                parms = {
                    'vg':float(self.controls['vg'].GetValue()),
                    'vd':float(self.controls['vd'].GetValue()),
                    'vgq':float(self.controls['vgq'].GetValue()),
                    'vdq':float(self.controls['vdq'].GetValue()),
                    }
            except Exception:
                show_error_dialog('Invalid voltage.')
                return
        
            self.controls['toggle'].SetLabel('Disable')
            self.controls['update'].Enable(True)
            self._piv_enabled = True
            self._worker.comm.send_to_worker('enable',parms)
            msg = 'enabling pulser ...'
            
        # set a timer to ensure we don't get locked up
        self.timout_timer.Start(10000,wx.TIMER_ONE_SHOT)
        
        # pop up a working dialog
        self.wait_dialog.set_text_string(msg)
        self.wait_dialog.CenterOnParent()
        self.wait_dialog.ShowModal()
    
    def OnUpdate(self, event):
        "update the pulser voltages"
        try:
            parms = {
                'vg':float(self.controls['vg'].GetValue()),
                'vd':float(self.controls['vd'].GetValue()),
                'vgq':float(self.controls['vgq'].GetValue()),
                'vdq':float(self.controls['vdq'].GetValue()),
                }
        except Exception:
            show_error_dialog('Invalid voltage.')
            return
        self._worker.comm.send_to_worker('enable',parms)
        
        # set a timer to ensure we don't get locked up
        self.timout_timer.Start(10000,wx.TIMER_ONE_SHOT)
        
        # pop up a working dialog
        self.wait_dialog.set_text_string('updating pulser voltages ...')
        self.wait_dialog.CenterOnParent()
        self.wait_dialog.ShowModal()
        
    def OnMeasure(self, event):
        "trigger a measurement"
        self.state = 'measuring'
        self._worker.comm.send_to_worker('measure')
        
        # set a timer to ensure we don't get locked up
        self.timout_timer.Start(6000,wx.TIMER_ONE_SHOT)
        
        # pop up a working dialog        
        self.wait_dialog.set_text_string('measuring ...')
        self.wait_dialog.CenterOnParent()
        self.wait_dialog.ShowModal()
        
    def OnWorkerMessage(self, event):
        "handler for messages from the worker"
        msg = event.msgtype
        data = event.payload
        
        if self.timout_timer.IsRunning():
            self.timout_timer.Stop()
        if self.wait_dialog.IsModal():
            self.wait_dialog.EndModal(wx.ID_OK)
        
        if msg == 'ready':
            # enable all controls
            for c in self.controls.values():
                c.Enable(True)
            self.controls['update'].Enable(False)
            self.exit_button.Enable(True)
        elif msg == 'ack':
            pass
        elif msg == 'measured':
            keys = data.keys()
            keys.sort()
            d = []
            for k in keys:
                if data[k] is not None:
                    d.append('%s = %g'%(k.title(),data[k]))
            dlg = wx.MessageDialog(self,'\n'.join(d),'Measured Data',wx.OK|wx.ICON_INFORMATION)
            dlg.ShowModal()
            dlg.Destroy()        
        
    def OnWorkerExit(self, event):
        "handler for when the worker thread exits"
        self._worker.join()
        self._worker = None
        if self.timout_timer.IsRunning():
            self.timout_timer.Stop()
        if self.wait_dialog.IsModal():
            self.wait_dialog.EndModal(wx.ID_OK)
        if event.exitstatus:
            logger.error('manual mode exited abnormally -> '+event.message)
            show_error_dialog('manual mode exited abnormally -> '+event.message,'Error')
         
        self.Close()
        
    def OnTimeout(self, event):
        "handle timeouts in commands"       
        logger.error('timeout occurred while waiting for a response -> operation = `%s`'%self.state)
        if self.wait_dialog.IsModal():
            self.wait_dialog.EndModal(wx.ID_OK)
        show_error_dialog('Timeout while waiting for operation: %s'%self.state,'Timeout Error')
        self.exit_button.Enable(True)

    
    def OnExit(self, event):
        "stuff to do when the exit button is pressed"
        for c in self.controls.values():
            c.Enable(False)
        self.exit_button.Enable(False)
        if self._worker:
            # send a 'quit' message to the worker
            self._worker.comm.send_to_worker('quit')
        
    def OnCloseDialog(self, event):
        "dialog close handler"
        if self._worker:
            # don't allow the dialog to be closed
            # while the worker thread is still alive
            event.Veto()
        else:
            event.Skip()
                    
            
class WaitForWorker(wx.Dialog):
    "dialog that is designed to be shown modal to wait for the worker to do something"
    
    def __init__(self, *args, **kwargs):
        "initializer"
        
        kwargs['style'] = 0
        super(WaitForWorker,self).__init__(*args,**kwargs)
        
        # create the basic UI
        self._sizer = wx.BoxSizer(wx.VERTICAL)        
        self._sizer.Add(wx.StaticText(self,-1,'waiting ...'),0,wx.ALL,20)
        
        self.SetSizer(self._sizer)
        self.Fit()
    
    def set_text_string(self, msg):
        "change the text string"
        
        self._sizer.Clear(True)
        self._sizer.Add(wx.StaticText(self,-1,msg),0,wx.ALL,20)
        self.Fit()
