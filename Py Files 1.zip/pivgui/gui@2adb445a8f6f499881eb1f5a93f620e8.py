"""
CATV Matrix Test stand GUI
Main application window





"""
import wx
from wx.lib.newevent import NewEvent
    
import os, os.path, sys, logging
from datetime import datetime

from wxtestgui import Param, TestParameters, EditTestParamsDialog, InstrumentConfigDialog, ApplicationPreferences

from .params import TEST_PARAMS
from .instruments import INSTR_LIST

# data for the About dialog
about_info = wx.AboutDialogInfo()
about_info.SetCopyright('MACOM (2016)')
about_info.SetDescription('Pulsed I-V application for operating the\nFocus pulsed I-V system.')
about_info.SetName('Pulsed I-V (Focus)')
about_info.SetVersion('0.1')
about_info.SetDevelopers(['Modeling Team',])

# storage for the test executive thread    
_test_executive_thread = None

def box_panel( parent, label ):
    "convenience function to create a StaticBox+StaticBoxSizer inside a Panel"
    panel = wx.Panel(parent)
    sz = wx.BoxSizer(wx.VERTICAL)
    bsz = wx.StaticBoxSizer(wx.StaticBox(panel,label=label),wx.VERTICAL)
    sz.Add(bsz,1,wx.EXPAND|wx.ALL,3)
    panel.SetSizer(sz)
    return panel, bsz

def show_error_dialog( msg, title='Error' ):
    "convenience function for showing an error dialog"
    dlg = wx.MessageDialog(None,msg,title,wx.OK|wx.ICON_ERROR)
    dlg.ShowModal()
    dlg.Destroy()

def position_dialog(parent, dialog, xoffset=100, yoffset=100):
    "position a dialog at an offset from it's parent"
    x, y = parent.GetPositionTuple()
    dialog.SetPosition( (x+xoffset,y+yoffset) )

# logging event and event ID
LoggingEvent, EVT_LOG_RECORD = NewEvent()    
    
class GuiLoggingHandler(logging.Handler):
    "handler that passes log messages to a UI window"
    
    def __init__(self, wxobj=None):
        "initializer"
        super(GuiLoggingHandler,self).__init__()
        self._wxobj = wxobj
        self.formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s','%H:%M:%S')
    
    def emit(self, record):
        "handle a logging record"
        if isinstance(self._wxobj,wx.Window):
            m = self.format(record)
            wx.PostEvent(self._wxobj,LoggingEvent(message=m,levelno=record.levelno))
    
    def flush(self):
        "does nothing"
        pass
        
        
        
    
    
class PIV_Main(wx.Frame):
    """Main frame for the pulsed I-V application"""
    
    def __init__(self, *args, **kwargs):
        "initializer"
        loglvl = logging.INFO
        if kwargs.pop('debug',True):
            loglvl = logging.DEBUG
        
        super(PIV_Main,self).__init__(*args,**kwargs)
        
        # store a pointer to the preferences
        # these are automatically loaded from disk when
        # this class is instantiated
        self.prefs = ApplicationPreferences(os.path.expanduser('~/.pivgui'))
        
        # store the test configuration parameters
        self.params = TestParameters(TEST_PARAMS)

        # store the greyed out text color for later
        self.GRAYTEXT = wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT)
        self.INFOTEXT = wx.Colour(0,0,200)
        
        # set up some varialbes
        self._last_setup = None
        self.working_path = os.getcwd()
        self._unsaved_params = False
                
        # initialize instrument configuration
        """
        self.instruments = {}
        for instr in INSTR_LIST:
            self.instruments[instr.name] = instr
        if 'instrument_setup' in self.prefs:
            for nm, data in self.prefs['instrument_setup'].iteritems():
                if nm in self.instruments and len(data) == 4:
                    instr = self.instruments[nm]
                    instr.driver_name = data[0]
                    instr.resource = data[1]
                    instr.chan = data[2]
                    instr.parms = data[3]
        """

        # init the window
        self.InitUI()
        
        # create logging styles
        self._logstyle_debug = wx.TextAttr('#b0b0b0')
        self._logstyle_error = wx.TextAttr('#cc0000')
        self._logstyle_warning = wx.TextAttr('#ff6600')
        
        # set up logging
        root = logging.getLogger()
        root.addHandler(GuiLoggingHandler(self))
        root.setLevel(loglvl)
        self._log = logging.getLogger('piv.gui')
        self.Bind(EVT_LOG_RECORD,self.OnHandleLogMsg)

        # set the focus on the file header field
        self.controls['edit_params'].SetFocus()
        
        # bind close events
        self.Bind(wx.EVT_CLOSE,self.OnCloseWindow)
        
        """
        # start the test executive thread
        if demo_mode:
            from .tst import TestExecutive
        else:
            from .test_executive import TestExecutive
    
        global _test_executive_thread
        _test_executive_thread = TestExecutive()
        _test_executive_thread.daemon = True
        _test_executive_thread.start()
        """
        
        # set up the main window size and position
        self.SetSize( self.prefs.get('mainwin_size',(600,400)) )
        self.SetPosition( self.prefs.get('mainwin_position',(100,100)) )

        # set the title
        self.SetTitle('Pulsed I-V')
        
        # show the window
        if self.prefs.get('mainwin_maximized',False):
            self.ShowFullScreen(True)
        else:
            self.Show(True)
        self._log.info('Ready.')
            
        
    def InitUI(self):
        "initialize the UI"
        
        # store the controls that are created
        # and menu items that need to be disabled during auto testing
        self.controls = {}
        self.menu_items_to_disable = []
        
        
        #### create a menu bar ####
        
        menubar = wx.MenuBar()
        filemenu = wx.Menu()
        file1 = filemenu.Append(wx.ID_OPEN, 'Open Setup ...\tCtrl-O', 'Open setup config')
        file2 = filemenu.Append(wx.ID_SAVE, 'Save Setup ...\tCtrl-S', 'Save setup config')
        filemenu.AppendSeparator()
        file3 = filemenu.Append(wx.ID_EXIT, 'Quit\tCtrl-Q', 'Quit application')
        self.Bind(wx.EVT_MENU,self.OnLoadSetup,file1)
        self.Bind(wx.EVT_MENU,self.OnSaveSetup,file2)
        self.Bind(wx.EVT_MENU,self.OnQuit,file3)
        menubar.Append(filemenu, '&File')
        
        setupmenu = wx.Menu()
        setup1 = setupmenu.Append(wx.ID_ANY, 'Instruments ...\tCtrl-I', 'Setup instruments')
        setup2 = setupmenu.Append(wx.ID_ANY, 'Parameters ...\tCtrl-P', 'Set configuration parameters')
        self.Bind(wx.EVT_MENU,self.OnSetupInstr,setup1)
        self.Bind(wx.EVT_MENU,self.OnEditParams,setup2)
        menubar.Append(setupmenu, '&Setup')
                
        helpmenu = wx.Menu()
        help1 = helpmenu.Append(wx.ID_ANY, 'About ...\tF1', 'Program information')
        self.Bind(wx.EVT_MENU,self.OnAbout,help1)
        menubar.Append(helpmenu, '&Help')
        
        self.SetMenuBar(menubar)
        self.menu_items_to_disable.extend( [file1,file3,setup1,setup2] )
                
        #### create the body area of the window ####
        
        # main panel, needed in order to get consistency on all platforms
        mainpanel = wx.Panel(self)
        mainsz = wx.BoxSizer(wx.VERTICAL)
        mainpanel.SetSizer(mainsz)
        
        # sizer for the configuation and run panels
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        mainsz.Add(hsz,0,wx.ALL|wx.EXPAND,5)
        
        ## configuration box ##
        
        cfgpan, cfgsz = box_panel(mainpanel,'Configuration')
        self.controls['edit_params'] = wx.Button(cfgpan,wx.ID_ANY,"Test Params")
        self.Bind(wx.EVT_BUTTON,self.OnEditParams,self.controls['edit_params'])
        self.controls['meas_sparams'] = wx.CheckBox(cfgpan,wx.ID_ANY,"Measure S-Params")
        self.controls['meas_gmgds'] = wx.CheckBox(cfgpan,wx.ID_ANY,"Measure gm+gds")
        
        cfgsz.Add(self.controls['edit_params'])
        cfgsz.Add((-1,10))
        cfgsz.Add(self.controls['meas_sparams'])
        cfgsz.Add((-1,3))
        cfgsz.Add(self.controls['meas_gmgds'])
        cfgsz.Add((-1,5))
        hsz.Add(cfgpan,0,wx.RIGHT|wx.EXPAND,5)
        
        ## test run box ##
        
        runpan, runsz = box_panel(mainpanel,'Run')
        self.controls['run_manual'] = wx.Button(runpan,wx.ID_ANY,"Manual")
        self.Bind(wx.EVT_BUTTON,self.OnRunManual,self.controls['run_manual'])
        self.controls['run_sweep'] = wx.Button(runpan,wx.ID_ANY,"Run Sweep")
        self.Bind(wx.EVT_BUTTON,self.OnRunSweep,self.controls['run_sweep'])
        self.controls['abort'] = wx.Button(runpan,wx.ID_ANY,"Abort")
        self.Bind(wx.EVT_BUTTON,self.OnAbort,self.controls['abort'])
        self.controls['abort'].Enable(False)
        
        runsz.Add(self.controls['run_manual'],5,wx.TOP|wx.LEFT|wx.RIGHT)
        runsz.Add((-1,15))
        runsz.Add(self.controls['run_sweep'],5,wx.LEFT|wx.RIGHT)
        runsz.Add((-1,5))
        runsz.Add(self.controls['abort'],5,wx.LEFT|wx.RIGHT)
        runsz.Add((-1,5))
        hsz.Add(runpan,0,wx.RIGHT|wx.EXPAND,5)

        ## log panel ##
        
        self.log_window = wx.TextCtrl(mainpanel,style=wx.TE_READONLY|wx.TE_MULTILINE|wx.HSCROLL|wx.TE_RICH2)
        mainsz.Add(self.log_window,1,wx.ALL|wx.EXPAND,5)
                        
    def OnAbout(self, e):
        "show the program information dialog"
        wx.AboutBox(about_info)        
    
    def OnLoadSetup(self, e):
        "load a setup file"
        # check if the current setup has been saved
        if self._unsaved_params:
            dlg = wx.MessageDialog(None,'The current test setup is unsaved.\nAre you sure you want to load a new one?','Confirm',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
            position_dialog(self,dlg)
            if dlg.ShowModal() != wx.ID_YES:
                return
        
        dir = ''
        if self._last_setup:
            dir = os.path.split(self._last_setup)[0]
        kw = {'style':wx.FD_OPEN,'wildcard':"Setup Files (*.stp)|*.stp"}
        if dir and os.path.isdir(dir):
            kw['defaultDir'] = dir
        else:
            kw['defaultDir'] = self.working_path
        dlg = wx.FileDialog(None,'Load Setup',**kw)
        position_dialog(self,dlg)
        if dlg.ShowModal() == wx.ID_OK:
            try:
                fname = dlg.GetPath()
                self.params.load(fname)
                self._last_setup = fname                
                self._unsaved_params = False
                self._log.info('loaded setup file: '+fname)
            except Exception as e:
                show_error_dialog('\n'.join([unicode(x) for x in e.allerrs]),'Errors during load')
                                        
    def OnSaveSetup(self, e):
        "save the current setup"
        dir, fname = '', ''
        if self._last_setup:
            dir, fname = os.path.split(self._last_setup)
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT,'wildcard':"Setup Files (*.stp)|*.stp"}
        if dir and os.path.isdir(dir):
            kw['defaultDir'] = dir
            kw['defaultFile'] = fname
        else:
            kw['defaultDir'] = self.working_path
            
        dlg = wx.FileDialog(None,'Save Setup',**kw)
        position_dialog(self,dlg)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            self.params.save(fname)            
            self._last_setup = fname
            self._unsaved_params = False
            self._log.info('saved setup file: '+fname)
                
    def OnSetupInstr(self, event):
        "open the instrument setup dialog"
        dlg = InstrumentConfigDialog(INSTR_LIST,parent=None)
        position_dialog(self,dlg)
        if dlg.ShowModal() == wx.ID_OK:
            # save instrument setup in preferences
            """
            data = {}
            for instr in self.instruments.values():
                data[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)
            self.prefs['instrument_setup'] = data
            """
        
    def OnEditParams(self, event):
        "open the options configuration dialog"
        dlg = EditTestParamsDialog(self.params.get_dialog_list(),None,style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        position_dialog(self,dlg)
        if dlg.ShowModal() == wx.ID_OK:
            self._unsaved_params = True
            
    def OnHandleLogMsg(self, event):
        "handle log messages"
        lvl = event.levelno
        sty = None
        if lvl in (logging.ERROR,logging.CRITICAL):
            sty = self._logstyle_error
        elif lvl == logging.WARNING:
            sty = self._logstyle_warning
        elif lvl == logging.DEBUG:
            sty = self._logstyle_debug
        
        n = self.log_window.GetLastPosition()
        self.log_window.AppendText(event.message.strip()+'\n')
        n2 = self.log_window.GetLastPosition()
        
        if sty:
            self.log_window.SetStyle(n,n2,sty)
        
        self.log_window.ShowPosition(n2)        
    
    def OnRunSweep(self, event):
        "start the automatic test routine"
        self._log.debug('debug message')
        self._log.warning('warning message')
        self._log.info('info message')
        self._log.error('error message')
        pass
    
    def OnAbort(self, event):
        "abort auto testing"
        self._log.info('sending abort signal ...')
        
    def OnRunManual(self, event):
        "manual mode"
        pass
    
    """
    def send_command(self, command, data=None, timeout=None):
        "send a command to the TE, with an optional timeout"
        c = Command(self,command,data)
        send_command_to_te(c)
        if isinstance(timeout,float) and timeout > 0.2:
            self.command_timer.watch(self,c,timeout)
    """
            
    def OnQuit(self, event):
        "callback for a quit action"
        self.Close()
        
    def OnCloseWindow(self, event):
        "event callback for closing the window"
        if self._unsaved_params:
            dlg = wx.MessageDialog(None,'The current test setup is unsaved.\nAre you sure you want to quit?','Confirm',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION|wx.CENTRE)
            position_dialog(self,dlg)
            if dlg.ShowModal() != wx.ID_YES:
                event.Veto()
                return
            
        # tell the test executive to exit
        ###self.send_command('quit')
    
        # update the current main window size and position in preferences
        self.prefs['mainwin_maximized'] = self.IsMaximized()
        if not self.prefs['mainwin_maximized']:
            self.prefs['mainwin_size'] = self.GetSizeTuple()
            self.prefs['mainwin_position'] = self.GetPositionTuple()
    
        # save application preferences and exit
        try:
            self.prefs.save()
        except Exception:
            pass
            
        # join the test executive thread and exit
        #_test_executive_thread.join()
        
        # destroy the window
        self.Destroy()
        
