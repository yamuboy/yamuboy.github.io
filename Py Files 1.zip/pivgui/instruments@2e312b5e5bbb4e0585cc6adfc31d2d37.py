from wxtestgui import Instr

INSTR_LIST = [
    Instr('pulser',static=True,driver=''),
    Instr('vd_lo',family='bias'),
    Instr('vd_hi',family='bias'),
]