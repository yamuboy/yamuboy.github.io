# import wxPython
import wx

# import stuff that is needed from matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg
import numpy as np

import os, os.path, sys, logging

logger = logging.getLogger('pivgui.ivplot')

def get_style(i):
    "get the line style associated with the index"
    colors = ['#ff0000','#800000','#ff8080','#ffff00','#808000','#008000','#00ff00','#008080','#30ffff',
        '#0000ff','#800080','#ff80ff','#b0b0b0','#606060','#000000']
    styles = ['-','--','-.',':']
    
    nc = len(colors)
    ns = len(styles)
    
    ci = i%nc
    si = (i//nc)%ns
    
    return styles[si], colors[ci]
    
def read_piv_data_file(fname):
    "read pulsed I-V data"
    v = 0
    fp = open(fname,'rU')
    line = fp.readline()
    if line.startswith('!$$version'):
        # this is a newer style file
        v = int(line.split()[-1])
        
    data = []
    try:
        last_vd = -10000000.0
        vdl, idl = [], []
        label = None
        for line in fp:
            try:
                vals = [float(x) for x in line.split()]
                
                if len(vals) > 5:
                    if v:
                        vdset = vals[2]
                        vd = vals[4]
                        id = vals[5]*1000.0
                        vg = vals[1]
                    else:
                        # old file version
                        vdset = vals[1]
                        vd = vals[3]
                        id = vals[5]*1000.0
                        vg = vals[0]
                    
                    if vdset < last_vd and len(vdl) > 0:
                        data.append( (vdl,idl,label) )
                        vdl, idl = [], []
                        label = None
                    last_vd = vdset
                    
                    vdl.append(vd)
                    idl.append(id)
                    if label is None:
                        label = 'Vg = %.3f'%vg
            
            except Exception:
                pass

        if len(vdl) > 0:
            data.append( (vdl,idl,label) )
            
    finally:
        fp.close()
        
    return data
    
    
class PIVPlotFigure(Figure):
    "Plot figure for plotting PIV data"
    
    def __init__(self,*args,**kwargs):
        "initializer"
        # strip keywords specific to this figure
        
        # init parent
        super(PIVPlotFigure,self).__init__(*args,**kwargs)
        
        # create the plot axes
        self.iv_axes = self.add_axes([0.1,0.1,0.8,0.8])        
        
    def plot_iv_data(self, data):
        "plot the I-V data on the axes"
        
        # check argument
        if not isinstance(data,list):
            raise TypeError("'data' must be a list")                
        
        linewidth = 2
        showlegend = True
        
        # reset the plot
        self.reset_plot()
        
        # draw the I-V curves
        plotargs = []
        for i,dset in enumerate(data):
            try:
                if not isinstance(dset,(list,tuple)):
                    raise TypeError("'data' element %d: not a tuple/list"%i)
                elif len(dset) not in (2,3):
                    raise TypeError("'data' element %d: not a 2-element or 3-element tuple/list"%i)
                    
                x = dset[0]
                y = dset[1]
                if len(dset) == 3:
                    label = dset[2]
                else:
                    label = 'Series %d'%(i+1)
                
                if not np.iterable(x):
                    raise ValueError("'data' element %d: X data is not an iterable"%i)            
                elif not np.iterable(y):
                    raise ValueError("'data' element %d: Y data is not an iterable"%i)
                elif len(x) != len(y):
                    raise ValueError("'data' element %d: X and Y data are not the same length"%i)
                elif not isinstance(label,basestring):
                    raise TypeError("'data' element %d: label is not a string value"%i)
                
                # generate keywords and plot
                kw = {'lw':linewidth, 'label':label}
                kw['ls'], kw['c'] = get_style(i)
                self.iv_axes.plot(x,y,**kw)
            except Exception, e:
                import traceback
                traceback.print_exc()
        
        # generate the legend
        if showlegend:
            self.iv_axes.legend(loc ='upper right',fontsize='x-small')
    
    def reset_plot(self):
        "reset the plot"
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        self.iv_axes.cla()
        self.iv_axes.hold(True)
        self.iv_axes.grid(True)
        
        # set the axis labels
        self.iv_axes.set_xlabel('Vds (V)')
        self.iv_axes.set_ylabel('Ids (mA)')
        self.iv_axes.set_title('Pulsed I-V')
        
        
class PIVPlotPanel(wx.Panel):
    """Plot panel for displaying plots
    
    """
    def __init__( self, *args, **kwargs ):
        "initializer"
        
        # set the last update time for the plot
        self._lastupdate = None
        self._plotfile = None

        # initialize Panel
        if 'style' not in kwargs:
            kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE
        else:
            kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE
        super(PIVPlotPanel,self).__init__(*args,**kwargs)
        self.parent = self.GetParent()
        
        # initialize matplotlib stuff
        self.figure = PIVPlotFigure()
        canvas = FigureCanvasWxAgg(self,-1,self.figure)
        canvas.SetFocus()

        # set up sizing
        self._SetSize()
        self._resizeflag = False

        # bind idle and size events
        self.Bind(wx.EVT_IDLE, self._onIdle)
        self.Bind(wx.EVT_SIZE, self._onSize)
        
        # do an initial plot update
        self._check_replot(None)
        
        # start a timer to check for plot data file updates
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self._check_replot, self.timer)
        self.timer.Start(1000)
    
    def set_plot_file(self, fname):
        "set the plot up for static plotting"
        if fname is not None and not isinstance(fname,basestring):
            raise TypeError("'fname' must be a string")
        self._plotfile = fname
        self.figure.reset_plot()
        self._lastupdate = None
        self._check_replot(None)
        
    set_file = set_plot_file
    
    def _onSize( self, event ):
        "event method for resize"
        self._resizeflag = True

    def _onIdle( self, evt ):
        "event method for idle events"
        if self._resizeflag:
            self._resizeflag = False
            self._SetSize()
        
    def _SetSize( self ):
        "resize the figure image" 
        pixels = tuple(self.parent.GetClientSize())
        self.SetSize(pixels)
        self.figure.canvas.SetSize(pixels)
        self.figure.set_size_inches( float( pixels[0] )/self.figure.get_dpi(),
                                     float( pixels[1] )/self.figure.get_dpi() )
            
    def _check_replot( self, event ):
        "check if there is any new data to plot"
        if self._plotfile:
            try:
                sz = os.stat(self._plotfile).st_size
            except Exception:
                return
                        
            if self._lastupdate is None or self._lastupdate != sz:
                # plot needs to be updated
                # read the PIV plot file
                self._lastupdate = sz
                self.update_plot()
    
    def update_plot(self):
        "update the plot window"
        try:
            data = read_piv_data_file(self._plotfile)
        except Exception as e:
            logger.error("unable to read I-V data file '%s' -> %s"%(self._plotfile,e))
            self.parent.error_msg('unable to update plot')
            return
        
        # plot the data
        if len(data):
            try:
                self.figure.plot_iv_data(data)
                self.figure.canvas.draw()
            except Exception as e:
                logger.error("plot_iv_data() failed -> %s"%e)
                self.parent.error_msg('unable to update plot')
                
class PIVPlotFrame(wx.Frame):
    """Main frame for holding the WxPIVPlotPanel"""    
    
    def __init__( self, *args, **kwargs ):
        "initializer"
    
        title = kwargs.pop('title','Pulsed I-V Plot 0.2')
        
        # init the parent
        super(PIVPlotFrame,self).__init__(*args,**kwargs)       
        self.SetTitle(title)
        
        # create a status bar
        self.statusbar = self.CreateStatusBar()
        
        # create a menu bar
        menubar = wx.MenuBar()

        filemenu = wx.Menu()
        omi = wx.MenuItem(filemenu, wx.ID_ANY, '&Open PIV File\tCtrl+O')
        filemenu.AppendItem(omi)
        smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
        filemenu.AppendItem(smi)
        filemenu.AppendSeparator()
        qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(qmi)

        self.Bind(wx.EVT_MENU,self.OnOpenFile,omi)
        self.Bind(wx.EVT_MENU,self.OnSaveFigure,smi)
        self.Bind(wx.EVT_MENU,self.OnQuit,qmi)

        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)
        
        # create the panel that holds the matplotlib Figure
        self.panel = PIVPlotPanel(self)
        
        # draw the canvas for the first time
        self.panel.figure.canvas.draw()
        
        # show this Window
        dw, dh = wx.DisplaySize()
        if float(dw)/float(dh) >= 1.25:
            # use height as the bounding dimension
            h = int(0.8*dh)
            w = int(h*1.33)
        else:
            # use width as the bounding dimension
            w = int(dw*0.8)
            h = int(0.75*w)
        self.SetSize( (w,h) )
        self.Centre()
        self.Show(True)
                    
    def OnQuit(self, event):
        "capture quit commands"
        self.Close()
    
    def OnOpenFile(self, event):
        "set the plot utility to open a static file"
        dlg = wx.FileDialog(self, "Open file", "", "", "All files (*.*)|*.*", wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            self.panel.set_plot_file(dlg.GetPath())
        dlg.Destroy()
        
    def OnSaveFigure(self, event):
        """Menu entry callback to save the current figure."""
        filetypes, exts, filter_index = self.panel.figure.canvas._get_imagesave_wildcards()
        default_file = "image." + self.panel.figure.canvas.get_default_filetype()
        dlg = wx.FileDialog(self, "Save to file", "", default_file,
                            filetypes,
                            wx.SAVE|wx.OVERWRITE_PROMPT)
        dlg.SetFilterIndex(filter_index)
        if dlg.ShowModal() == wx.ID_OK:
            fname  = dlg.GetPath()
            format = exts[dlg.GetFilterIndex()]
            basename, ext = os.path.splitext(fname)
            if ext.startswith('.'):
                ext = ext[1:]
            if ext in ('svg', 'pdf', 'ps', 'eps', 'png') and format != ext:
                #looks like they forgot to set the image type drop
                #down, going with the extension.
                #warnings.warn('extension %s did not match the selected image type %s; going with %s'%(ext, format, ext), stacklevel=0)
                format = ext
                
            try:
                self.panel.figure.canvas.print_figure(fname,format=format)
                self.status_msg("Saved file '%s'"%fname)
            except Exception as e:
                self.error_msg(str(e))
        dlg.Destroy()
    
    def set_file(self, fname):
        "set the file to use for plotting"
        self.panel.set_plot_file(fname)
        
    def status_msg(self, msg):
        "print a status message to the status bar"
        self.statusbar.SetStatusText(msg)
    error_msg = status_msg
                
        
