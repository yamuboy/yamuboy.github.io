
from wxtestgui.worker import send_to_ui, get_next_message, NoMessages
import logging
from time import sleep
import random


def main(*args, **kwargs):
    "test out using a worker thread and handling communication with a Window"
    print(args[0])
    print(args[1])
    print(args[2])
    
    _log = logging.getLogger('pivgui.worker')
    
    # send some log messages and then exit with either normal status or an exception
    
    _log.info('started worker')
    sleep(1.2)
    
    _log.warning('something abnormal happended')
    sleep(0.7)
    
    try:
        send_to_ui('bonk',3)
        raise ValueError('wrong number dummy')
    except Exception as e:
        _log.exception('uh oh')
    
    while True:
        # wait for an abort signal (this call blocks)
        msg = get_next_message()
        _log.debug('got a message with type: '+msg.msgtype)
        if msg.msgtype == 'abort':
            break
    
    # this should be a 50/50 chance of exiting with an exception
    if random.randint(0,1):
        raise TypeError('whoops')

        
def manual(*args, **kwargs):
    "manual mode test function"
    
    # initialzing delay
    sleep(1.5)
    
    # this should be a 50/50 chance of exiting with an exception
    if random.randint(0,1):
        raise TypeError('types are types')
    
    sleep(0.2)
    send_to_ui('ready')
    
    enabled = False
    while True:
        # main loop
        msg = get_next_message()
        ty = msg.msgtype
        
        if ty == 'quit':
            sleep(1.1)
            break
        elif ty == 'enable':
            if enabled:
                sleep(2.2)
            else:
                sleep(4.3)
            enabled = True
            send_to_ui('ack')
        elif ty == 'disable':
            sleep(2.2)
            enabled = False
            send_to_ui('ack')
        elif ty == 'measure':
            sleep(1.7)
            send_to_ui('measured',{'vg':0.1,'vgq':-0.3,'vd':0.4,'vdq':5.02,'id':0.0234,'idq':0.0433})
    
    
