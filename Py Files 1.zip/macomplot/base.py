﻿from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
                        
import os, os.path, sys, traceback, re
from collections import OrderedDict

import wx
from wx.lib.scrolledpanel import ScrolledPanel

from matplotlib.figure import Figure as mpl_figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as mpl_figure_canvas

from . import PlotOption, AxisScale, PlotFile
from .artprovider import initialize_art_provider
from .dialogs import ScalingDialog, OptionsDialog, AddCanvasDialog

###############################################################################
# canvas type registry
###############################################################################

_canvas_types_by_label = {}
_canvas_types_by_name = {}

def register_canvas(cls, label):
    "register a canvas so that it can be selected when creating a new plot"    
    if not issubclass(cls,PlotlibCanvasBase):
        raise TypeError('the first argument to register_canvas must be a type object subclassed from `PlotlibCanvasBase`')
    
    if label and not label.startswith('_'):
        if label in _canvas_types_by_label:
            raise ValueError("canvas type with label '%s' is already registered"%label)
        _canvas_types_by_label[label] = cls
    
    if cls.pl_name in _canvas_types_by_name:
        raise ValueError("canvas type with name '%s' is already registered"%cls.pl_name)
        
    _canvas_types_by_name[cls.pl_name] = cls
    
def get_canvas_by_label(label):
    "get a canvas type by label"
    return _canvas_types_by_label[label]

def get_canvas_by_name(name):
    "get a canvas type by name"
    return _canvas_types_by_name[name]

def get_all_canvas_types():
    "returns a copy of the canvas types by label dictionary"
    return _canvas_types_by_label.copy()
    

###############################################################################
# base plot canvas that defines interactions with the plot panel
###############################################################################
        
class PlotlibCanvasBase(mpl_figure_canvas):
    """Base class for all canvases defined by the plotlib
    
    defines the standard interface methods and sets up some
    interfaces with the plotting frame
    """
    
    pl_name = '_base_'
    pl_multi_file = False
    pl_plot_file = None
    
    def __init__(self, parent, **kwargs):
        "initializer"
        figure_class = kwargs.pop('figure_class',mpl_figure)
        figure_kwargs = kwargs.pop('figure_kwargs',{})
        if not issubclass(figure_class,mpl_figure):
            raise TypeError('figure_class must be a subclass of `PlotlibFigure`')
        if not isinstance(figure_kwargs,dict):
            raise TypeError('figure_kwargs must be a dictionary')
        
        figure = figure_class(**figure_kwargs)
        mpl_figure_canvas.__init__(self,parent,wx.ID_ANY,figure)
        self._wxparent = parent
        
        if len(kwargs):
            raise ValueError("unsupported keywords: "%(', '.join(kwargs.keys())))
                
    def set_plot_file(self, fname, label=None):
        """set the plot file"""
        if fname is None:
            self.pl_plot_file = None
        else:
            self.pl_plot_file = PlotFile(fname,label)
        self.check_plot_files(True)
            
    def add_plot_file(self, fname, label=None):
        "add another plot file to the list"
        self.set_plot_file(fname,label)    
        
    def clear_plot_files(self):
        "clear the plot data"
        self.set_plot_file(None)    
    
    def get_plot_scale_data(self):
        """get the scale data for all axes that are considered
        "independently" scalable
                
        The format for this data is a list containing AxisScale
        instances.
        
        By default this returns None, which disables any scaling
        of the plots in the figure
        """
        return None
        
    def set_plot_scale_data(self, scale_data):
        """set the plot scales
        
        The argument is the same list with the same AxisScale
        instances that were received from get_plot_scale_data() with
        updated values that were entered into the UI dialog.
        
        Because this scale_data list is the same object that was
        received from get_plot_scale_data(), it is possible for the
        canvas to not have to do anything with this received data.
        """
        pass
        
    def get_plot_options(self):
        """get plot options
        
        This should be a dictionary-like object of PlotOption objects
        a collections.OrderedDict is recommended so that the order of
        the options in the UI is deterministic. The keys are the option
        'name'.
        """
        return None
    
    def set_plot_options(self, options):
        """set plot options
        
        This will be a dictionary where the keys are the same as those
        that were received from get_plot_options() and the values will
        be Python objects of the appropriate type (int, float, string, etc)
        """
        pass
        
    def _populate_toolbar(self, toolbar):
        """add custom tools to the panel's toolbar
        
        toolbar is an instance of wx.ToolBar and tools
        should be added using one of the wx.ToolBar methods
        
        To connect events using Bind, you should connect them
        to the parent wx window which is stored in
        self._wxparent (or you can get via self.GetParent())
        """
        pass
    
    def check_plot_files(self, force=False):
        """called to tell the canvas to check for changes in
        plot files - this is triggered by a timer event
        in the PlotPanel that contains the canvas if live
        plotting mode is enabled it should return True if
        any of the plot files were updated
        """
        if self.pl_plot_file:
            try:
                if force or self.pl_plot_file.check_for_update():
                    self.pl_plot_file.data = self.read_plot_file(self.pl_plot_file.fname)
                    self._plot_files_updated()
                    return True
            except Exception as e:
                # do something here
                self.pl_plot_file.data = None
                self._push_error_msg(self.pl_plot_file.fname+' -> '+str(e))
        
        return False
            
    def read_plot_file(self, fname):
        ""
        # must be overriden in the dervived canvas to return
        # a dataset to be stored (that will be used to generate
        # the plots in the figure)
        return None
        
    def _plot_files_updated(self):
        "trigger to indicate that the plot files have been updated"
        # this default implementation can be overridden in derived classes
        # to potentially update controls or do other things in addition
        # to re-drawing the plot figure
        self.redraw_plot_figure()
    
    def redraw_plot_figure(self):
        """force a redraw of the plot figure
        
        usually call after a new data file is added or an existing file
        is updated when plotting in live mode
        """
        # should be overriden in the derived canvas
        pass
    
    def change_figure(self, figure_class, **kwargs):
        """change out the figure with a new one
        
        keywords are passed to the figure_class initializer
        """
        if not issubclass(figure_class,PlotlibFigure):
            raise TypeError('figure_class must be a subclass of `PlotlibFigure`')
        figure = figure_class(**kwargs)
        oldfigure = self.figure
        figure.set_canvas(self)
        self.figure = figure
        oldfigure.clf()
        oldfigure.set_canvas(None)
        oldfigure._plotlib_is_valid = False
        
    def _push_error_msg(self, msg):
        "push error message to the frame"
        if hasattr(self._wxparent,'trigger_error_message'):
            self._wxparent.trigger_error_message(msg)
        
###############################################################################
# multi-file canvas
###############################################################################

class MultiFileCanvas(PlotlibCanvasBase):
    """Canvas for multi-file plots
    """
    
    pl_name = '_multi_'
    pl_multi_file = True
    pl_plot_file_list = []
    pl_max_files = -1

    def __init__(self, parent, **kwargs):
        "initializer"
        PlotlibCanvasBase.__init__(self,parent,**kwargs)
    
    def set_plot_file(self, fname, label=None):
        "set the plot file for a multiplot canvas"
        if fname is None:
            self.pl_plot_file_list = []
        else:
            self.pl_plot_file_list = [PlotFile(fname,label)]  
        self.check_plot_files(True)
    
    def add_plot_file(self, fname, label=None):
        "add another plot file to the list"
        n = len(self.pl_plot_file_list)
        if self.pl_max_files > 0 and n >= self.pl_max_files:
            raise ValueError('maximum number of files reached')
        
        self.pl_plot_file_list.append(PlotFile(fname,label))
        self.check_plot_files(True)
        
    def clear_plot_files(self):
        "clear the plot file list"
        self.pl_plot_file_list = []
        self._plot_files_updated()
    
    def check_plot_files(self, force=False):
        """called to tell the canvas to check for changes in
        plot files - this is triggered by a timer event
        in the PlotPanel that contains the canvas if live
        plotting mode is enabled it should return True if
        any of the plot files were updated
        """
        flag = False
        for p in self.pl_plot_file_list:
            try:
                if force or p.check_for_update():
                    # plot file was updated
                    p.data = self.read_plot_file(p.fname)
                    flag = True
            except Exception as e:
                p.data = None
                flag = True
                self._push_error_msg(p.fname+' -> '+str(e))
                
        if flag:
            self._plot_files_updated()
            
        # returning True will cause the canvas to be redrawn
        return flag


        
###############################################################################    
# Panel Class
###############################################################################

class PlotlibPanel(wx.Panel):
    "Plot panel with controls to set the plot file and scaling"
    
    def __init__( self, *args, **kwargs ):
        "initializer"
        canvas_class = kwargs.pop('canvas_class',PlotlibCanvasBase)
        canvas_kwargs = kwargs.pop('canvas_kwargs',{})
        self._show_close_button = kwargs.pop('close_button',False)
        if not issubclass(canvas_class,PlotlibCanvasBase):
            raise TypeError('canvas_class must be a subclass of `PlotlibCanvasBase`')
        if not isinstance(canvas_kwargs,dict):
            raise TypeError('canvas_kwargs must be a dictionary')
        
        # everything else in kwargs gets passed to the wx.Panel initializer
        super(PlotlibPanel,self).__init__(*args,**kwargs)
        
        # register the panel with the top-level frame
        tl = self.GetTopLevelParent()
        if hasattr(tl,'register_plot_panel'):
            tl.register_plot_panel(self)
        
        # variables tracked here
        self._live_update = True
        
        # create the canvas, if canvas_class was passed via the kwargs
        # then that will be used otherwise the default PlotlibCanvasBase
        # class will be used, the canvas will be passed keywords from the
        # canvas_kwargs keyword when it is created
        self.plotcanvas = canvas_class(self,**canvas_kwargs)        
        
        # create a toolbar
        self.toolbar = wx.ToolBar(self)
        self.toolbar.SetBackgroundColour('#9494b8')
        self._populate_toolbar()
        
        # set up the main panel layout
        self.panelsz = wx.BoxSizer(wx.VERTICAL)
        self.panelsz.Add(self.toolbar,0,wx.EXPAND)
        self.panelsz.Add(self.plotcanvas,1,wx.EXPAND)
        self.SetSizer(self.panelsz)
        
        # create dialogs
        self._scale_dlg = ScalingDialog(self)
        self._option_dlg = OptionsDialog(self)
        
        
        # set the minimum size for a plot panel
        # note that this setting only affects auto layout
        self.SetMinSize((500,500))
        
    def _populate_toolbar(self):
        "populate the toolbar with tool icons"
        
        art = wx.ArtProvider
        open_file = self.toolbar.AddLabelTool(wx.ID_ANY,'',art.GetBitmap(wx.ART_FILE_OPEN,wx.ART_TOOLBAR),shortHelp='open a new file')
        scales = self.toolbar.AddLabelTool(wx.ID_ANY,'',art.GetBitmap('plot_scales',wx.ART_TOOLBAR),shortHelp='adjust plot scales')
        options = self.toolbar.AddLabelTool(wx.ID_ANY,'',art.GetBitmap('plot_options',wx.ART_TOOLBAR),shortHelp='set plot options')
        live = self.toolbar.AddCheckLabelTool(wx.ID_ANY,'',art.GetBitmap('livemode_on',wx.ART_TOOLBAR),shortHelp='toggle live updates')
        saveimg = self.toolbar.AddLabelTool(wx.ID_ANY,'',art.GetBitmap(wx.ART_FILE_SAVE,wx.ART_TOOLBAR),shortHelp='save plot as image')
        self.toolbar.AddSeparator()
                
        self.toolbar.ToggleTool(live.GetId(),self._live_update)
        self.Bind(wx.EVT_TOOL,self.OnAddPlotFile,open_file)
        self.Bind(wx.EVT_TOOL,self.OnAdjustScales,scales)
        self.Bind(wx.EVT_TOOL,self.OnChangeOptions,options)
        self.Bind(wx.EVT_TOOL,self.OnChangeLive,live)
        self.Bind(wx.EVT_TOOL,self.OnSaveImage,saveimg)
        
        # allow the canvas to add tools to the toolbar
        self.plotcanvas._populate_toolbar(self.toolbar)
        
        # add the close button
        if self._show_close_button:
            self.toolbar.AddStretchableSpace()        
            close = self.toolbar.AddLabelTool(wx.ID_ANY,'',art.GetBitmap(wx.ART_CROSS_MARK,wx.ART_TOOLBAR),shortHelp='close the plot window')
            self.Bind(wx.EVT_TOOL,self.OnClosePanel,close)
        
        # realize the toolbar
        self.toolbar.Realize()

    def change_plot_canvas(self, canvas_class, **kwargs):
        "change the plot figure to a new one"
        if not issubclass(canvas_class,PlotlibCanvasBase):
            raise TypeError('canvas_class must be a subclass of `PlotlibCanvasBase`')
        
        # create the new canvas
        oldcanvas = self.plotcanvas
        self.plotcanvas = canvas_class(self,**kwargs)
        
        # change out the canvas in the main panel sizer and delete the old one
        self.panelsz.Replace(oldcanvas,self.plotcanvas)
        oldcanvas.Destroy()
        
        # update toolbar
        self.toolbar.ClearTools()
        self._populate_toolbar()
        
        # force the sizer to update child window postitions
        self.FitInside()
        
        # draw the new canvas
        self.plotcanvas.draw()
        
    def set_plot_file(self, fname, label=None):
        """set the plot data file
        
        for plots that support multiple files, this will
        clear all other files so that the passed file is
        the only active file in the plot
        """
        if fname is not None and not isinstance(fname,basestring):
            raise TypeError("plot file name must be a string")
        # hand the new file to the plot canvas for it to handle
        try:
            self.plotcanvas.set_plot_file(fname,label)
            self.plotcanvas.draw_idle()
        except Exception as e:
            self.trigger_error_message(fname+' -> %s'%e)
            
    def add_plot_file(self, fname, label=None):
        """add a new plot file to the plot 
        
        this will act exactly like set_plot_file() for plots
        that do not support multiple files
        """
        if fname is not None and not isinstance(fname,basestring):
            raise TypeError("plot file name must be a string")
        try:
            self.plotcanvas.add_plot_file(fname,label)
            self.plotcanvas.draw_idle()
        except Exception as e:
            self.trigger_error_message(fname+' -> %s'%e)
        
    def reset(self):
        "reset the canvas, clearing all data"
        self.plotcanvas.clear_plot_files()
        self.plotcanvas.draw_idle()
        
    def OnAddPlotFile(self, event):
        "callback for when the 'add file' control is triggered"
        kw = {'style':wx.FD_OPEN|wx.FD_MULTIPLE,'wildcard':"All Files (*.*)|*.*"}
        dlg = wx.FileDialog(self,'Add Plot File',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            filepaths = dlg.GetPaths()
            if len(filepaths) > 1:
                self.set_plot_file(filepaths[0])
                for path in filepaths[1:]:
                    self.add_plot_file(path)
            else:
                self.add_plot_file(dlg.GetPath())
        dlg.Destroy()
        
    def OnClosePanel(self, event):
        "close the panel by destroying it"
        # unregister the panel with the top-level frame
        tl = self.GetTopLevelParent()
        if hasattr(tl,'unregister_plot_panel'):
            tl.unregister_plot_panel(self)
        # remove the panel from its sizer
        sz = self.GetContainingSizer()
        if sz:
            sz.Remove(self)
        # get the parent
        parent = self.GetParent()
        # destroy the panel
        self.Destroy()
        # refit the plot panels of the parent
        if hasattr(parent,'refit_plot_panels'):
            parent.refit_plot_panels()
        
    def OnAdjustScales(self, event):
        "callback for when the 'scales' control is triggered"
        scale_data = self.plotcanvas.get_plot_scale_data()
        if not scale_data:
            self.trigger_error_message('scaling cannot be changed for this plot canvas')
            return
        
        self._scale_dlg.SetupUI(scale_data)
        self._scale_dlg.CenterOnParent()
        if self._scale_dlg.ShowModal() == wx.ID_OK:
            self.plotcanvas.set_plot_scale_data(scale_data)
            self.plotcanvas.draw_idle()
    
    def OnChangeOptions(self, event):
        "change plot options"
        option_data = self.plotcanvas.get_plot_options()
        if not option_data:
            self.trigger_error_message('this plot canvas has no options')
            return
            
        self._option_dlg.SetupUI(option_data)
        self._option_dlg.CenterOnParent()
        if self._option_dlg.ShowModal() == wx.ID_OK:
            self.plotcanvas.set_plot_options(option_data)
            self.plotcanvas.draw_idle()
        
    def OnSaveImage(self, event):
        "save the plot canvas as an image"
        filetypes, exts, filter_index = self.plotcanvas._get_imagesave_wildcards()
        default_file = "plot." + self.plotcanvas.get_default_filetype()
        dlg = wx.FileDialog(self,"Save image",defaultFile=default_file,
            wildcard=filetypes,style=wx.SAVE|wx.OVERWRITE_PROMPT)
        dlg.SetFilterIndex(filter_index)
        if dlg.ShowModal() == wx.ID_OK:
            fpath  = dlg.GetPath()
            format = exts[dlg.GetFilterIndex()]
            ext = os.path.splitext(fpath)[1]
            if ext.startswith('.'):
                ext = ext[1:]
            if ext in exts and format != ext:
                format = ext
                
            try:
                self.plotcanvas.print_figure(fpath,format=format)
                self.status_msg("Saved image file: %s"%fpath)
            except Exception as e:
                self.trigger_error_message(str(e))
    
        dlg.Destroy()
        
    def OnChangeLive(self, event):
        "change live mode status"
        self._live_update = event.Checked()
        
    def check_plot_files(self):
        "check plot files for updates"
        if self._live_update:
            # call the canvas to tell it to update its plots
            # if the files have changed, this method should
            # return True if any changes have been detected
            # and the canvas will be redrawn
            if self.plotcanvas.check_plot_files():
                self.plotcanvas.draw_idle()
    
    def status_msg(self, msg):
        "propagate a status message to the top level"
        tl = self.GetTopLevelParent()
        if hasattr(tl,'status_msg'):
            tl.status_msg(msg)
    
    def trigger_error_message(self, msg):
        "send an error message to the top level"
        tl = self.GetTopLevelParent()
        if hasattr(tl,'show_error'):
            tl.show_error(msg)
    
###############################################################################    
# multiple plot panel window
###############################################################################

class PlotlibMultiPanel(ScrolledPanel):
    "a container that holds multiple PlotlibPanel objects"
    MAX_PANELS = 6
    
    def __init__(self, parent, canvas_class=PlotlibCanvasBase, canvas_kwargs={}, **kwargs):
        "initializer"
        
        # init the parent class
        ScrolledPanel.__init__(self,parent,**kwargs)
        
        # create a grid sizer for the sub-panels
        self._gridsizer = wx.GridSizer(cols=2,vgap=5,hgap=5)
        
        # set the main panel layout
        #sz = wx.BoxSizer(wx.VERTICAL)
        #sz.Add(self._gridsizer,1,wx.EXPAND)
        
        # add the first plot panel 
        panel = self.add_plot_panel(canvas_class,**canvas_kwargs)
        
        # initialize the scrolling behavior
        self.SetSizer(self._gridsizer)
        self.SetupScrolling()
                
    def add_plot_panel(self, canvas_class=PlotlibCanvasBase, **kwargs):
        "add a plot panel to the multiplot display"
        n = len(self._gridsizer.GetChildren())
        if n >= self.MAX_PANELS:
            raise ValueError('cannot add a new plot panel - maximum has been reached')
        
        # create the panel and add it to the sizer
        panel = PlotlibPanel(self,canvas_class=canvas_class,canvas_kwargs=kwargs,close_button=True)
        self._gridsizer.Add(panel,1,wx.EXPAND)
        
        # adjust the sizer layout as necessary
        self.refit_plot_panels()
            
    def refit_plot_panels(self):
        "check the layout of the sizer and update as necessary"
        n = len(self._gridsizer.GetChildren())
        c = self._gridsizer.GetCols()
        if n == 1:
            cols = 1
        elif n < 5:
            cols = 2
        else:
            cols = 3
        if c != cols:
            self._gridsizer.SetCols(cols)
        self._gridsizer.Layout()
    
    def set_plot_file(self, fname):
        "proxy this along to all the panels"
        for item in self._gridsizer.GetChildren():
            w = item.GetWindow()
            if isinstance(w,PlotlibPanel):
                w.set_plot_file(fname)
        
###############################################################################    
# Top-level frame classes
###############################################################################

class PlotlibFrame(wx.Frame):
    "Frame that contains the Plot Panel"
    
    def __init__(self, *args, **kwargs):
        "initializer"
    
        self._plot_panels = set()
    
        title = kwargs.pop('title','Plot')
        multiplot = kwargs.pop('multiplot',False)
        canvas_class = kwargs.pop('canvas_class',PlotlibCanvasBase)
        canvas_kwargs = kwargs.pop('canvas_kwargs',{})
        
        # init parent
        wx.Frame.__init__(self,*args,**kwargs)
        
        # initial our custom art provider
        # this can be called more than once as it will only
        # actually do the initialization the first time
        # it has to be done inside of a wx window since
        # it will fail if the wx.App() object has not
        # been created yet
        initialize_art_provider()
        
        # set title
        self.SetTitle(title)
        
        # create a status bar
        self.statusbar = self.CreateStatusBar()
        
        # create a menu bar
        menubar = wx.MenuBar()
        
        filemenu = wx.Menu()
        if multiplot:
            addNewPlot_menu = wx.MenuItem(filemenu, wx.ID_ANY, 'Add &New Plot\tCtrl+N')
            filemenu.AppendItem(addNewPlot_menu)
            self.Bind(wx.EVT_MENU, self.OnAddNewPlot, addNewPlot_menu)
            filemenu.AppendSeparator()
        quit = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(quit)
        self.Bind(wx.EVT_MENU,self.OnQuit,quit)
        
        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)
        
        # create an interval timer that creates a timer event every 1000 milliseconds
        self.interval_timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER,self.OnInterval,self.interval_timer)
        self.interval_timer.Start(1000)        
        
        # create a timer that is used to reset the status bar background color
        self._timer1 = wx.Timer(self)
        self.Bind(wx.EVT_TIMER,self.OnTimer1,self._timer1)
        
        # create the panel that holds plot canvases
        panelkw = {'canvas_class':canvas_class,'canvas_kwargs':canvas_kwargs}
        if multiplot:
            self.panel = PlotlibMultiPanel(self,**panelkw)
        else:
            self.panel = PlotlibPanel(self,**panelkw)
        
        # capture destroy events so that the main frame can be closed
        # if the panel beneath it is destroyed
        self.Bind(wx.EVT_WINDOW_DESTROY,self.OnDestroyChild,self.panel)
        
        self._add_canvas_dlg = AddCanvasDialog(self)
        
        # set the initial window size
        dw, dh = wx.DisplaySize()
        if float(dw)/float(dh) >= 1.25:
            # use height as the bounding dimension
            h = int(0.8*dh)
            w = int(h*1.33)
        else:
            # use width as the bounding dimension
            w = int(dw*0.8)
            h = int(0.75*w)
        self.SetSize( (w,h) )
        
        # center and show the window
        self.Centre()
        self.Show(True)
    
    def OnQuit(self, event):
        "capture quit commands"
        self.Close()
    
    def OnAddNewPlot(self, event):
        "add a new canvas to a multiplot panel"
        # pop up a dialog with a plot panel selector
        self._add_canvas_dlg.CenterOnParent()
        if self._add_canvas_dlg.ShowModal() == wx.ID_OK:
            if self._add_canvas_dlg.selected_canvas:
                self.add_plot_panel(canvas_class=self._add_canvas_dlg.selected_canvas)
            else:
                self.show_error('invalid canvas selected')
    
    def OnDestroyChild(self, event):
        "child panel was destroyed"
        if not self.IsBeingDeleted():
            self.Close()
        
    def set_plot_file(self, fname):
        "set the plot file name - this is proxied on to the plot panel"
        self.panel.set_plot_file(fname)
    
    def add_plot_panel(self, *args, **kwargs):
        "add a plot panel to a mutilpanel plot"
        if not isinstance(self.panel,PlotlibMultiPanel):
            self.show_error('new plot canvases cannot be added to single plot windows')
            return
            
        self.panel.add_plot_panel(*args,**kwargs)        
    
    def OnTimer1(self, event):
        "set the status bar background to normal color"
        self.statusbar.SetBackgroundColour(None)
        self.statusbar.SetStatusText('')
        self.statusbar.Refresh()
    
    def register_plot_panel(self, w):
        "register a plot panel so that live update events can be propagated"
        id = w.GetId()
        if id not in self._plot_panels:
            self._plot_panels.add(id)
        
    def unregister_plot_panel(self, w):
        "unregister a plot panel - done when the panel is about to be destroyed"
        id = w.GetId()
        if id in self._plot_panels:
            self._plot_panels.remove(id)
    
    def OnInterval(self, event):
        "propagate the interval timer to plot panels"
        for id in self._plot_panels:
            w = self.FindWindowById(id)
            if w.IsBeingDeleted():
                self._plot_panels.remove(id)            
            else:
                w.check_plot_files()
    
    def status_msg(self, msg):
        "print a status message to the status bar"
        self.statusbar.SetStatusText(msg)
        self.statusbar.SetBackgroundColour(None)
        self.statusbar.Refresh()
        self._timer1.Start(4000,True)
    
    def show_error(self, msg):
        "print an error message to the status bar"
        self.status_msg(msg)
        self.statusbar.SetBackgroundColour('#dd0000')
        self.statusbar.Refresh()
        self._timer1.Start(4000,True)
        
###############################################################################
# dummy figure 
###############################################################################

class DummyFigure(mpl_figure):
    "dummy figure for testing"
    
    def __init__(self, *args, **kwargs):
        "initializer, passes all parameters to the matplotlib.Figure initializer"
        mpl_figure.__init__(self,*args,**kwargs)    
        self.text(0.5,0.5,'This is a dummy figure.',va='center',ha='center')
        
