from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
                        
from network_params import Param, Touchstone
import math

def read_sparam_data_simple( fname ):
    """read 1-port or 2-port S-parameter data from a file
    
    this is a very watered down version of the Touchstone reading
    functionality found in the network_params.Touchstone class,
    but it has the advantage of having less overhead (for speed)
    and it can read multi-bias S-parameter data sets in a single
    shot to simplify reading in data from multi-bias S-parameter
    data files for plotting
    
    returns a 2-tuple consisting of
       - a list of Touchstone objects
       - the file header as a string
    
    """
    default_format = '# HZ S MA R 50'
    
    # open the file
    ac = True
    if hasattr(fname,'readline') and hasattr(fname.readline,'__call__'):
        # this is a file-like object
        fp = fname
        ac = False
        fname = '<stream>'
        if hasattr(fp,'filename'):
            fname = fp.filename
    else:
        fp = open(fname,'rU')
    
    datasets = []
    
    try:
        line = fp.readline()
        h = []
        d = []
        fmt = default_format
        fmtinfo = _get_format_info(fmt)
        hd = False
        nports = 0
        
        while line != '':
            ln = line.strip()
            if ln.startswith('!'):
                if d:
                    # already read data, this comment marks the start
                    # of a new S-paramter data block
                    t = Touchstone()
                    t.format = fmt
                    t.header = ('\n'.join(h)) + '\n'
                    t.insert(d)
                    datasets.append(t)
                    # reset variables
                    h = [ln]
                    d = []
                    fmt = default_format
                    fmtinfo = _get_format_info(fmt)
                    hd = False
                else:
                    if not hd: h.append(ln)
            elif ln.startswith('#'):
                fmt = ln.upper()
                fmtinfo = _get_format_info(fmt)
                hd = True
            elif ln == '':
                pass
            else:
                # try to read S-parameter data from the line
                try:
                    x = map(float,ln.split())
                    hd = True
                    if len(x) == 3:
                        if not nports:
                            nports = 1                        
                        elif nports != 1:
                            # inconsistent data
                            raise ValueError
                        d.append(_convert_to_param(x,fmtinfo))
                    elif len(x) == 9:
                        if not nports:
                            nports = 2
                        elif nports != 2:
                            # inconsistent data
                            raise ValueError
                    else:
                        raise ValueError
                    d.append(_convert_to_param(x,fmtinfo))
                except Exception:
                    pass
        
            line = fp.readline()
        
        # add the last data read to the dataset
        if d:
            t = Touchstone()
            t.format = fmt
            t.header = ('\n'.join(h)) + '\n'
            t.insert(d)
            datasets.append(t)
        
    finally:
        if ac: fp.close()
    
    # fix the headers for multi-part S-parameter files
    fileheader = ''
    if len(datasets) > 1:
        # the first Touchstone object is going to have a much longer
        # header than the rest since it gets the whole header at the
        # top of the file
        
        # to fix this, assume that the header should be the same length
        # as the second dataset and strip the rest off
        hlst = datasets[0].header.rstrip().split('\n')
        n = len(datasets[1].header.rstrip().split('\n'))
        if len(hlst) > n:
            fileheader = ('\n'.join(hlst[:-n]))+'\n'
            datasets[0].header = ('\n'.join(hlst[-n:]))+'\n'
    
    return datasets, fileheader

_deg2rad = math.pi / 180.0
def _ma_to_complex(m, a):
    "convert mag/angle format to a complex number"
    return complex(m*math.cos(a*_deg2rad),m*math.sin(a*_deg2rad))
    
def _db_to_complex(db, a):
    "convert dB/angle format to a complex number"
    m = 10.0^(0.05*db)
    return complex(m*math.cos(a*_deg2rad),m*math.sin(a*_deg2rad))
    
_conv_func_map = {0:_ma_to_complex, 1:complex, 2:_db_to_complex}    
def _convert_to_param(data, fmtinfo):
    "convert data to a Param object"
    freq = data[0]*fmtinfo[0]
    conv = _conv_func_map[fmtinfo[1]]
    
    if len(data) == 3:
        p = [conv(data[1],data[2])]
    else:  # len(data) == 9
        p = [conv(data[1],data[2]),conv(data[5],data[6]),conv(data[3],data[4]),conv(data[7],data[8])]
    
    return Param(freq,p)

def _get_format_info(fmt):
    """get the format info necessary to convert the S-parameter data
    into real/imag format with proper frequency scaling
    """
    fsc = 1.0
    if 'HZ' in fmt:
        fsc = 1.0
    elif 'KHZ' in fmt:
        fsc = 1.0e-3
    elif 'MHZ' in fmt:
        fsc = 1.0e-6   
    elif 'GHZ' in fmt:
        fsc = 1.0e-9       
    elif 'THZ' in fmt:
        fsc = 1.0e-12 
    
    p = 0
    if 'MA' in fmt:
        p = 0
    elif 'RI' in fmt:
        p = 1
    elif 'DB' in fmt:
        p = 2
        
    return (fsc,p)
        
    
def yfit_simple( data ):
    """calculate a basic Y-fit of the incoming data
    
    data can be either a Param object or a list/tuple
    of Param objects.  It must be Y-parameter data, so
    conversion from S or anything else must have already
    been done
    
    returns a dictionary or list of dictionaries containing
    the calculated model parameters 
    """
    
    if isinstance(data,Param):
        return _yfit_inner(data)
    else:
        return [_yfit_inner(x) for x in data]
    
    
def _yfit_inner( data ):
    "inner Y-fit extraction function"
    if not isinstance(data,Param) or data.nports != 2:
        raise TypeError("data must be a 2-port `network_params.Param` object")
    
    wi = 0.5 / (math.pi*data.freq)
    d = data.data
    
    return {'cgs':wi*(d[0,0]+d[0,1]).imag,
        'cgd':-wi*d[0,1].imag,
        'cds':wi*(d[1,1]+d[0,1]).imag,
        'gm':d[1,0].real,
        'gds':d[1,1].real,
        # H21 = Y21/Y11, ft = mag(H21)*freq
        'ft':abs(d[1,0]/d[0,0])*data.freq,
        }
    
def s2y_simple( data, zref=complex(50.0) ):
    "convert S-parameters to Y-parameters"
    if isinstance(data,Param):
        return _s2y_inner(data,zref)
    else:
        return [_s2y_inner(x,zref) for x in data]

        
def _s2y_inner( data, zref ):
    "inner S to Y function"
    if not isinstance(data,Param) or data.nports != 2:
        raise TypeError("data must be a 2-port `network_params.Param` object")
        
    d = data.data
    s12s21 = d[0,1]*d[1,0]
    denom = 1.0 / (((1.0+d[0,0])*(1.0+d[1,1]) - s12s21)*zref)
    y11 = ((1.0-d[0,0])*(1.0+d[1,1]) + s12s21)*denom
    y12 = -2.0*d[0,1]*denom
    y21 = -2.0*d[1,0]*denom
    y22 = ((1.0+d[0,0])*(1.0-d[1,1]) + s12s21)*denom
    
    return Param(data.freq,[y11,y12,y21,y22])
    
    
    
    
    
    
    
    