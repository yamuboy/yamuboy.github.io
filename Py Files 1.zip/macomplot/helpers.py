import os, os.path

###############################################################################
# plot option 
###############################################################################

class PlotOption(object):
    """An option for plotting that can be modified in the UI"""
    _valid_types = ('string','bool','int','float','choice')
    
    def __init__(self, ty, label, value=None, **kwargs):
        """Initializer
        
        Keywords are:
        
        
        """
        if ty not in self._valid_types:
            raise ValueError('invalid option type, valid values are: %s'%(', '.join(self._valid_types)))
        if not isinstance(label,basestring):
            raise TypeError("'label' must be a string")
        
        self._ty = ty
        self._minv = kwargs.pop('minv',None)
        self._maxv = kwargs.pop('maxv',None)
        self._label = label
        self._idx = -1
        self._validator = kwargs.pop('validator',None)
        if self._validator is not None:
            if not hasattr(self._validator,'__call__'):
                return TypeError("'validator' is not callable")
        self._choices = []
        if ty == 'choice':
            self._choices = kwargs.pop('choices',[])
            if not self._choices:
                raise ValueError("'choices' is a required keyword for 'choice' options")
        self._v = self._coerce(value)        
            
        
    def _coerce(self, v):
        "coerce the input variable to a valid value for the option type"
        if self._ty == 'string':
            if v is None:
                return unicode('')
            return unicode(v)            
        elif self._ty == 'int':
            if v is None:
                return 0
            return int(v) 
        elif self._ty == 'float':
            if v is None:
                return 0.0
            return float(v) 
        elif self._ty == 'bool':
            return bool(v)
        elif self._ty == 'choice':
            if v is None:
                self._idx = 0
                return self._choices[0]
            self._idx = self._choices.index(v)
            return v
        else:
            # eeeeks, someone messed with internal variables
            raise ValueError('internal type setting is invalid')
    
    def _get_value(self):
        if self._ty == 'choice':
            return self._choices[self._idx]
        else:    
            return self._v
    
    def _set_value(self, value):
        value = self._coerce(value)
        if self._validator:
            self._v = self._coerce(self._validator(value))
        elif self._ty in ('float','int') and (self._minv is not None or self._maxv is not None):
            if self._minv is not None and value < self._minv:
                raise ValueError('exceeded mimimum value')             
            if self._maxv is not None and value > self._maxv:
                raise ValueError('exceeded maximum value')
            self._v = value
        else:
            self._v = value
    
    value = property(_get_value,_set_value,None,'option value')
    
    @property
    def type(self):
        "option type"
        return self._ty
    
    @property
    def label(self):
        "option label"
        return self._label
    
    def _get_selected(self):
        return self._idx
        
    def _set_selected(self,i):
        if i < 0 or i >= len(self._choices):
            raise ValueError('invalid index')
        self._idx = i
        self._v = self._choices[i]

    selected = property(_get_selected,_set_selected,None,"selected index - only valid for 'choice' options")

        
###############################################################################
# scaling option
###############################################################################

class AxisScale:
    "scaling data for an axis"
    label = 'axis'
    min = None
    max = None
    autoscale = True
    logscale = False

    # flags to tell the UI what scale options to present the 
    allow_manual = True
    allow_log = False
    
    def __init__(self, **kwargs):
        "initializer"
        for k in kwargs:
            if not hasattr(self,k):
                raise ValueError("invalid keyword '%s'"%k)
            setattr(self,k,kwargs[k])

     
###############################################################################
# plot file data storage and metadata
###############################################################################
        
class PlotFile(object):
    "storage for plot file data"
    
    def __init__(self, fname, label=None):
        "initializer"
        self.fname = fname
        if label:
            self.label = label
        self.data = None
        
        if self.fname:
            st = os.stat(self.fname)
            self._mtime = int(st.st_mtime)
            self._size = st.st_size
        else:
            self._mtime = 0
            self._size = 0
    
    def _getfname(self):
        return self._fname
        
    def _setfname(self, fname):
        if fname is not None and not isinstance(fname,basestring):
            raise TypeError('fname must be a string')
        self._fname = fname
        if fname:
            self.label = os.path.split(fname)[1]
    
    fname = property(_getfname, _setfname, None, "filename")
    
    def _getlabel(self):
        return self._label
        
    def _setlabel(self, label):
        if label is not None and not isinstance(label,basestring):
            raise TypeError('label must be a string')
        self._label = label
    
    label = property(_getlabel, _setlabel, None, "filename")
    
    def check_for_update(self):
        "check to see if the file was updated, returns True if it has been"
        if self.fname:
            st = os.stat(self.fname)
            mtime = int(st.st_mtime)
            sz = st.st_size
            if mtime > self._mtime or sz != self._size:
                self._mtime = mtime
                self._size = sz
                return True
            return False        
        else:
            return False

