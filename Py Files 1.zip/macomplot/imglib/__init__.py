

def get_path():
    "get the path to this folder"
    import os.path
    return os.path.split(__file__)[0]