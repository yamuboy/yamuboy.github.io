from wx import ArtProvider, Bitmap, NullBitmap
from os.path import join as _join

# import python image objects
from .imglib import get_path

# create a mapping from artid strings to python objects
# that store the image data
_p = get_path()
_art_mapping = {
    'plot_scales':_join(_p,'graph.png'),
    'livemode_off':_join(_p,'lightbulb.png'),
    'livemode_on':_join(_p,'lightbulb_lit.png'),
    'plot_options':_join(_p,'tools.png'),
}

class PlotlibArtProvider(ArtProvider):
    "art provider to provide bitmaps for the plotlib"
    
    def __init__(self):
        "initializer"
        ArtProvider.__init__(self)
    
    def CreateBitmap(self, artid, client, size):
        "return bitmaps for recognized id strings"
        # this method completely ignores the client and size arguments
        # since all bitmaps that are managed only come in a single size
        
        if artid in _art_mapping:
            return Bitmap(_art_mapping[artid])
        
        # no match
        return NullBitmap

_provider_is_initialized = False
def initialize_art_provider():
    "initialize the art provider"
    global _provider_is_initialized
    if not _provider_is_initialized:
        ArtProvider.Push(PlotlibArtProvider())
        _provider_is_initialized = True
    
