﻿from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
                        
from collections import OrderedDict
from .. import PlotlibCanvasBase, MultiFileCanvas, PlotOption, AxisScale, register_canvas
from ..styles import LineStyleGenerator
from datetime import datetime, timedelta
from matplotlib import dates, ticker

import os.path
import re

class _dcstressbase:
    "DC Stress base class with common methods"

    def _init_common(self):
        "common initialization"
        # create the plot axes
        self.priax = self.figure.add_axes([0.1,0.6,0.8,0.3])
        self.secax = self.figure.add_axes([0.1,0.1,0.8,0.3])

        self._options = OrderedDict(
            [
                ('title',PlotOption('string','Title','DC Stress')),
                ('show_legend',PlotOption('bool','Show Legend',True)),
                ('linewidth',PlotOption('int','Line Width',1,minv=1)),
            ]
        )
        
        self._scaledata = [
            AxisScale(label='Time', allow_log=True),
            AxisScale(label='Id', allow_log=True),
            AxisScale(label='|Ig|', allow_log=True)
        ]
        
        self.redraw_plot_figure()
            
    def abs_to_elapsed(self, timeList):
        "process times into elapsed time (in seconds)"
        tl = []
        for t in timeList:
            td = datetime.strptime(t, '%Y/%m/%d %H:%M:%S') - datetime.strptime(timeList[0], '%Y/%m/%d %H:%M:%S')
            tl.append(td.days * 1440 + td.seconds // 60)
        return tl

    def read_plot_file(self, fname):
        "read data from file"
    
        # Sample lines  from .dat file below
        # Timestamp Igate   Idrain
        # 2015/07/13 11:25:52   -4.11959e-07    0.0603194
        # date <space> time <tab> ig <tab> id
    
        fp = open(fname,'r')
        try:
            lines = fp.readlines()
            time, igate, idrain = [], [], []
            for line in lines:
                if line == lines[0]:
                    if line == "Timestamp\tIgate\tIdrain\n":
                        continue
                    else:
                        raise ValueError("Invalid DC Stress in-situ data file!")
                        return
            
                try:
                    tokens = re.split('\t', line)
                    time.append(tokens[0])                  #get timestamp (without date)
                    igate.append(abs(float(tokens[1]))*1e6) #get gate current
                    idrain.append(float(tokens[2])*1e3)     #get drain current
                
                except Exception:
                    pass
            
        finally:
            fp.close()

        times = self.abs_to_elapsed(time)
        data = (times, igate, idrain)
        return data
        
    def get_plot_options(self):
        """get plot options
        
        This should be a dictionary of PlotOption objects
        """
        return self._options
    
    def set_plot_options(self, options):
        """set plot options
        
        This will be a dictionary of values
        """
        self.redraw_plot_figure()
        
    def get_plot_scale_data(self):
        "get scale data"
        x = self._scaledata[0]
        y1 = self._scaledata[1]
        y2 = self._scaledata[2]
        x.min, x.max = self.priax.get_xbound()
        y1.min, y1.max = self.priax.get_ybound()
        y2.min, y2.max = self.secax.get_ybound()
        
        return self._scaledata

    def set_plot_scale_data(self, scale_data):
        "set scale data"
        self.redraw_plot_figure()

class DCStressCanvas(_dcstressbase,PlotlibCanvasBase):
    "Plot figure for plotting in-situ DC Stress data"
    
    pl_name = 'dcstress'
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(DCStressCanvas,self).__init__(parent,**kwargs)
        
        self._init_common()
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax1 = self.priax
        ax2 = self.secax
        
        # clear the axes
        # can be called more than once
        ax1.cla()
        ax2.cla()

        # enable grid on both axes
        ax1.grid(True)
        ax2.grid(True)
        
        # set the axis labels and title
        ax1.set_xlabel('Time')
        ax1.set_ylabel('Id (mA)')
        ax2.set_ylabel(u'|Ig| (\u00b5A)')   #\u00b5 is micro sign
        ax1.set_title(self._options['title'].value)
        
        if not self.pl_plot_file or not self.pl_plot_file.data:
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        y1scale = self._scaledata[1]
        y2scale = self._scaledata[2]
        
        if xscale.autoscale:
            ax1.autoscale(True,axis='x')
            ax2.autoscale(True,axis='x')
        else:
            ax1.autoscale(False,axis='x')
            ax2.autoscale(False,axis='x')
            ax1.set_xbound(xscale.min,xscale.max)
            ax2.set_xbound(xscale.min,xscale.max)
        
        if y1scale.autoscale:
            ax1.autoscale(True,axis='y')
        else:
            ax1.autoscale(False,axis='y')
            ax1.set_ybound(y1scale.min,y1scale.max)

        if y2scale.autoscale:
            ax2.autoscale(True,axis='y')
        else:
            ax2.autoscale(False,axis='y')
            ax2.set_ybound(y2scale.min,y2scale.max)
        
        if xscale.logscale:
            ax1.set_xscale('log')
            ax2.set_xscale('log')
        else:
            ax1.set_xscale('linear')
            ax2.set_xscale('linear')

        if y1scale.logscale:
            ax1.set_yscale('log')
        else:
            ax1.set_yscale('linear')

        if y2scale.logscale:
            ax2.set_yscale('log')
        else:
            ax2.set_yscale('linear')

        data = self.pl_plot_file.data
        linewidth = self._options['linewidth'].value
        do_legend = self._options['show_legend'].value
        
        # draw the curves
        g = LineStyleGenerator()
        t = data[0]
        ig = data[1]
        id = data[2]

        # set/rotate x-axis labels
        ax1.set_xticklabels(t, rotation='30')
        ax2.set_xticklabels(t, rotation='30')
        
        # set x-axes to plot time elapsed based on timeTicks formatter
        def timeTicks(x, pos):
            d = timedelta(seconds=x)
            return str(d)
        
        timeformatter = ticker.FuncFormatter(timeTicks)
        ax1.get_xaxis().set_major_formatter(timeformatter)
        ax2.get_xaxis().set_major_formatter(timeformatter)

        # generate keywords and plot
        kw = {'lw':linewidth}
        kw['c'], kw['ls'] = g.next_style()
        ax1.plot(t,id,**kw)
        ax2.plot(t,ig,**kw)
        
        # generate the legend
        if do_legend:
            ax1.legend(loc='upper right',fontsize='x-small')

class DCStressMultiFile(_dcstressbase,MultiFileCanvas):
    "canvas for multi-file DC Stress in-situ comparisons"
    
    pl_name = 'dcstress_multi'
    pl_max_files = 32
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(DCStressMultiFile,self).__init__(parent,**kwargs)
        
        self._init_common()
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax1 = self.priax
        ax2 = self.secax
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax1.cla()
        ax2.cla()
        ax1.hold(True)
        ax2.hold(True)

        # enable grid on both axes
        ax1.grid(True)
        ax2.grid(True)
        
        # set the axis labels and title
        ax1.set_xlabel('Time')
        ax1.set_ylabel('Id (mA)')
        ax2.set_ylabel(u'|Ig| (\u00b5A)')   #\u00b5 is micro sign
        ax1.set_title(self._options['title'].value)
        
        if not len(self.pl_plot_file_list):
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        y1scale = self._scaledata[1]
        y2scale = self._scaledata[2]
        
        if xscale.autoscale:
            ax1.autoscale(True,axis='x')
            ax2.autoscale(True,axis='x')
        else:
            ax1.autoscale(False,axis='x')
            ax2.autoscale(False,axis='x')
            ax1.set_xbound(xscale.min,xscale.max)
            ax2.set_xbound(xscale.min,xscale.max)
        
        if y1scale.autoscale:
            ax1.autoscale(True,axis='y')
        else:
            ax1.autoscale(False,axis='y')
            ax1.set_ybound(y1scale.min,y1scale.max)

        if y2scale.autoscale:
            ax2.autoscale(True,axis='y')
        else:
            ax2.autoscale(False,axis='y')
            ax2.set_ybound(y2scale.min,y2scale.max)

        if xscale.logscale:
            ax1.set_xscale('log')
            ax2.set_xscale('log')
        else:
            ax1.set_xscale('linear')
            ax2.set_xscale('linear')

        if y1scale.logscale:
            ax1.set_yscale('log')
        else:
            ax1.set_yscale('linear')

        if y2scale.logscale:
            ax2.set_yscale('log')
        else:
            ax2.set_yscale('linear')

        linewidth = self._options['linewidth'].value
        
        g = LineStyleGenerator()
        lines, labels = [], []
        for file in self.pl_plot_file_list:
            data = file.data
            label = file.fname
            if not data:
                continue
            
            labels.append(os.path.abspath(label))
            
            # draw the data
            t = data[0]
            ig = data[1]
            id = data[2]

            # generate keywords and plot
            kw = {'lw':linewidth, 'label':os.path.abspath(label)}
            kw['c'], kw['ls'] = g.next_style()
            handle = ax1.plot(t,id,**kw)[0]
            ax2.plot(t,ig,**kw)

            lines.append(handle)
            
        # generate the legend
        if self._options['show_legend'].value:
            self.figure.legend(lines,labels,loc='upper right',fontsize='x-small')
        
# register the canvas so that it can be used when adding new canvases        
register_canvas(DCStressCanvas,'DC Stress')
register_canvas(DCStressMultiFile,'DC Stress (multi-file)')

