﻿from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
                        
from collections import OrderedDict
from .. import PlotlibCanvasBase, MultiFileCanvas, PlotOption, AxisScale, register_canvas
from ..styles import LineStyleGenerator

import os.path
import re

class _lagbase:
    "lag base class with common methods"

    def _init_common(self):
        "common initialization"
        # create the plot axes
        self.priax = self.figure.add_axes([0.1,0.1,0.8,0.8])
        self.secax = self.priax.twinx()

        self._options = OrderedDict(
            [
                ('title',PlotOption('string','Title','Lag')),
                ('show_legend',PlotOption('bool','Show Legend',True)),
                ('linewidth',PlotOption('int','Line Width',2,minv=1)),
            ]
        )
        
        self._scaledata = [
            AxisScale(label='X', allow_log=True),
            AxisScale(label='Y1', allow_log=True),
            AxisScale(label='Y2', allow_log=True)
        ]
        
        self.redraw_plot_figure()
            
    def read_plot_file(self, fname):

        # Sample lines from .dat file below
        # ! GaN Drain Lag Test
        # !
        # ! Test Date/Time: 2016/05/20 13:06:29
        # !
        # ! Settings:
        # !    drainlag_Vd_ss = 50.0
        # !    drainlag_Vd_pulse = 10.0
        # !    drainlag_Vg_q = -2.0
        # !    drainlag_pulse_width = 10
        # !    drainlag_pulse_period = 10
        # !    target_Ids_drainlag = 0.01
        # 
        # ! t (s)	Vg (V)	Vd (V)	Id (A)
        # +9.999993E+00	-1.849925E+00	+4.999990E+01	+1.269860E-02	
        # +1.000002E+01	-1.849990E+00	+5.000000E+01	+1.269450E-02
        fp = open(fname,'r')
        time, vgate, vdrain, idrain = [], [], [], []
        valid = False
        try:
            # assume file has header
            lines = fp.readlines()
            for line in lines:
                # skip file header
                if line in lines[0:12]:
                    continue

                # skip table header, mark file as valid
                elif (line == "! t (s)\tVg (V)\tVd (V)\tId (A)\n" or line == "\n" or
                    line == "! t (s)\tVg (V)\tVd (V)\tId (A)\r\n" or line == "\r\n"):
                    valid = True
                    continue

                # break reading 
                elif not valid:
                    raise ValueError("Invalid GaN Lag data file!")
                    return
                
                # parse data
                try:
                    tokens = re.split('\t', line)
                    time.append(float(tokens[0]))   # get timestamp
                    vgate.append(float(tokens[1]))  # get gate voltage
                    vdrain.append(float(tokens[2])) # get drain voltage
                    idrain.append(float(tokens[3])) # get drain current
                except Exception:
                    raise
        
        finally:
            fp.close()

        data = (time, vgate, vdrain, idrain)
        return data
        
    def get_plot_options(self):
        """get plot options
        
        This should be a dictionary of PlotOption objects
        """
        return self._options
    
    def set_plot_options(self, options):
        """set plot options
        
        This will be a dictionary of values
        """
        self.redraw_plot_figure()
        
    def get_plot_scale_data(self):
        "get scale data"
        x = self._scaledata[0]
        y1 = self._scaledata[1]
        y2 = self._scaledata[2]
        x.min, x.max = self.priax.get_xbound()
        y1.min, y1.max = self.priax.get_ybound()
        y2.min, y2.max = self.secax.get_ybound()
        
        return self._scaledata

    def set_plot_scale_data(self, scale_data):
        "set scale data"
        self.redraw_plot_figure()

class LagCanvas(_lagbase,PlotlibCanvasBase):
    "Plot figure for plotting lag data"
    
    pl_name = 'lag'
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(LagCanvas,self).__init__(parent,**kwargs)
        
        self._init_common()
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax1 = self.priax
        ax2 = self.secax
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax1.cla()
        ax2.cla()

        ax1.hold(True)
        ax2.hold(True)
        ax1.grid(True)
        
        # set the axis labels and title
        ax1.set_xlabel('Time (s)')
        ax1.set_ylabel('Ids (A)')
        ax2.set_ylabel('Voltage (V)')
        ax1.set_title(self._options['title'].value)
        
        if not self.pl_plot_file or not self.pl_plot_file.data:
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        y1scale = self._scaledata[1]
        y2scale = self._scaledata[2]
        
        if xscale.autoscale:
            ax1.autoscale(True,axis='x')
            ax2.autoscale(True,axis='x')
        else:
            ax1.autoscale(False,axis='x')
            ax2.autoscale(False,axis='x')
            ax1.set_xbound(xscale.min,xscale.max)
            ax2.set_xbound(xscale.min,xscale.max)
        
        if y1scale.autoscale:
            ax1.autoscale(True,axis='y')
        else:
            ax1.autoscale(False,axis='y')
            ax1.set_ybound(y1scale.min,y1scale.max)

        if y2scale.autoscale:
            ax2.autoscale(True,axis='y')
        else:
            ax2.autoscale(False,axis='y')
            ax2.set_ybound(y2scale.min,y2scale.max)
        
        if xscale.logscale:
            ax1.set_xscale('log')
            ax2.set_xscale('log')
        else:
            ax1.set_xscale('linear')
            ax2.set_xscale('linear')

        if y1scale.logscale:
            ax1.set_yscale('log')
        else:
            ax1.set_yscale('linear')

        if y2scale.logscale:
            ax2.set_yscale('log')
        else:
            ax2.set_yscale('linear')

        data = self.pl_plot_file.data
        linewidth = self._options['linewidth'].value
        do_legend = self._options['show_legend'].value
        
        # draw the curves
        g = LineStyleGenerator()
        x = data[0]
        vg = data[1]
        vd = data[2]
        ids = data[3]

        # generate keywords and plot
        kw = {'lw':linewidth}
        kw['c'], kw['ls'] = g.next_style()
        ax1.plot(x,ids,**kw)
        kw['c'], kw['ls'] = g.next_style()
        ax2.plot(x,vg,**kw)
        kw['c'], kw['ls'] = g.next_style()
        ax2.plot(x,vd,**kw)
        
        # generate the legend
        if do_legend:
            ax.legend(loc='upper right',fontsize='x-small')

class LagMultiFile(_lagbase,MultiFileCanvas):
    "canvas for multi-file lag comparisons"
    
    pl_name = 'lag_multi'
    pl_max_files = 32
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(LagMultiFile,self).__init__(parent,**kwargs)
        
        self._init_common()
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax1 = self.priax
        ax2 = self.secax
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax1.cla()
        ax2.cla()
        ax1.hold(True)
        ax2.hold(True)
        ax1.grid(True)
        
        # set the axis labels and title
        ax1.set_xlabel('Time (s)')
        ax1.set_ylabel('Ids (A)')
        ax2.set_ylabel('Voltage (V)')
        ax1.set_title(self._options['title'].value)
        
        if not len(self.pl_plot_file_list):
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        y1scale = self._scaledata[1]
        y2scale = self._scaledata[2]
        
        if xscale.autoscale:
            ax1.autoscale(True,axis='x')
            ax2.autoscale(True,axis='x')
        else:
            ax1.autoscale(False,axis='x')
            ax2.autoscale(False,axis='x')
            ax1.set_xbound(xscale.min,xscale.max)
            ax2.set_xbound(xscale.min,xscale.max)
        
        if y1scale.autoscale:
            ax1.autoscale(True,axis='y')
        else:
            ax1.autoscale(False,axis='y')
            ax1.set_ybound(y1scale.min,y1scale.max)

        if y2scale.autoscale:
            ax2.autoscale(True,axis='y')
        else:
            ax2.autoscale(False,axis='y')
            ax2.set_ybound(y2scale.min,y2scale.max)

        if xscale.logscale:
            ax1.set_xscale('log')
            ax2.set_xscale('log')
        else:
            ax1.set_xscale('linear')
            ax2.set_xscale('linear')

        if y1scale.logscale:
            ax1.set_yscale('log')
        else:
            ax1.set_yscale('linear')

        if y2scale.logscale:
            ax2.set_yscale('log')
        else:
            ax2.set_yscale('linear')

        linewidth = self._options['linewidth'].value
        
        g = LineStyleGenerator()
        lines, labels = [], []
        for file in self.pl_plot_file_list:
            data = file.data
            label = file.fname
            if not data:
                continue
            
            labels.append(os.path.basename(label))
            
            # draw the data
            x = data[0]
            vg = data[1]
            vd = data[2]
            ids = data[3]

            # generate keywords and plot
            kw = {'lw':linewidth, 'label':os.path.basename(label)}
            kw['c'], kw['ls'] = g.next_style()
            handle = ax1.plot(x,ids,**kw)[0]

            kw['ls'] = g._ltypes[1]
            ax2.plot(x,vg,**kw)

            kw['ls'] = g._ltypes[2]
            ax2.plot(x,vd,**kw)

            lines.append(handle)
            
        # generate the legend
        if self._options['show_legend'].value:
            self.figure.legend(lines,labels,loc='upper right',fontsize='x-small')
        
# register the canvas so that it can be used when adding new canvases        
register_canvas(LagCanvas,'Lag')
register_canvas(LagMultiFile,'Lag (multi-file)')

