from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
                        
import wx
from collections import OrderedDict
from .. import PlotlibCanvasBase, PlotOption, AxisScale, register_canvas
from ..styles import LineStyleGenerator
from ..utils import yfit_simple, read_sparam_data_simple, s2y_simple

class _ssbase:
    "base methods for small-signal plots"
    
    def _init_common(self):
        "common initializer code"
        # create the plot axes
        self.figure.add_axes([0.1,0.1,0.8,0.8])
        
        self._param_index = 0

        self._options = OrderedDict( [('title',PlotOption('string','Title','SS Parameters')),
            ('show_legend',PlotOption('bool','Show Legend',True)),
            ('linewidth',PlotOption('int','Line Width',2,minv=1)),
            ('extract_freq',PlotOption('float','Extract Freq GHz',2,minv=0.01)),
            ]
        )
        
        self._scaledata = [AxisScale(label='X')] + [AxisScale(label=x) for x in self._ylabel_strings]
        
        self.redraw_plot_figure()
        
    def read_plot_file(self, fname):
        "read a pulsed I-V data file"
        # read the S-parameter data from the file
        dsets, header = read_sparam_data_simple(fname)
        
        # get the version of the pulsed S-parameter data file
        v = 0
        h = header.split('\n')
        if len(h) and h[0].startswith('!$$version'):
            v = int(h[0].split()[-1])
        
        # extract small signal parameters
        freq = self._options['extract_freq'].value*1.0e9
        data = []
        for d in dsets:
            try:
                # get the Y-fit data
                parms = yfit_simple(s2y_simple(d.extract(freq)))
                
                # read the vg, vd, and id values from the header
                vg, vd, id, vdm = None, None, None, None
                for line in d.header.split('\n'):
                    if line.startswith('!BIAS:'):
                        x = line.split()
                        vg = float(x[11])
                        vd = float(x[3])
                        vdm = float(x[3])
                        id = float(x[7])
                        break
                    elif line.startswith('!PULSE:'):
                        x = line.split()
                        if v > 1:
                            vg = float(x[1])
                            vd = float(x[2])
                            vdm = float(x[4])
                            id = float(x[5])
                        else:
                            vg = float(x[1])
                            vd = float(x[2])
                            vdm = float(x[4])
                            id = float(x[6])
                        break
                
                if vg is None:
                    # bias header not found
                    raise ValueError
                
                parms['vd'] = vd
                parms['vdm'] = vdm
                parms['vg'] = vg
                parms['id'] = id
                data.append(parms)
            except Exception:
                pass
                
        return data
        
    def get_plot_options(self):
        """get plot options
        
        This should be a dictionary of PlotOption objects
        """
        return self._options
    
    def set_plot_options(self, options):
        """set plot options
        
        This will be a dictionary of values
        """
        self.redraw_plot_figure()
        
    def get_plot_scale_data(self):
        "get scale data"
        x = self._scaledata[0]
        y = self._scaledata[self._param_index+1]
        x.min, x.max = self.figure.axes[0].get_xbound()
        y.min, y.max = self.figure.axes[0].get_ybound()
        
        return self._scaledata

    def set_plot_scale_data(self, scale_data):
        "set scale data"
        self.redraw_plot_figure()
        
    def _populate_toolbar(self, tb):
        "add custom tools to the toolbar"
        ch = wx.Choice(tb,choices=self._ylabel_strings)
        ch.SetSelection(self._param_index)
        t = tb.AddControl(ch)
        self._wxparent.Bind(wx.EVT_CHOICE,self.OnChangePlotType,ch)
        
    def OnChangePlotType(self, event):
        "update the plot selection"
        self._param_index = event.GetSelection()
        self.redraw_plot_figure()
        self.draw()
    
class SSParamsCanvas(_ssbase,PlotlibCanvasBase):
    "Plot figure for plotting PIV data"
    
    pl_name = 'ssparams'
    
    _ylabel_strings = ['Cgs (pF)','Cgd (pF)','Gm (mS)','Gds (mS)','Cds (pF)','Ids (mA)','ft (GHz)']
    _parameter_scaling = [1.0e12,1.0e12,1.0e3,1.0e3,1.0e12,1.0e3,1.0e-9]
    _parameter_names = ['cgs','cgd','gm','gds','cds','id','ft']
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(SSParamsCanvas,self).__init__(parent,**kwargs)
        
        self._init_common()        
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax = self.figure.axes[0]
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax.cla()
        ax.hold(True)
        ax.grid(True)
        
        # set the axis labels and title
        ax.set_xlabel('Vds (V)')
        ax.set_ylabel(self._ylabel_strings[self._param_index])
        ax.set_title(self._options['title'].value)
        
        if not self.pl_plot_file or not self.pl_plot_file.data:
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        yscale = self._scaledata[self._param_index+1]
        
        if xscale.autoscale:
            ax.autoscale(True,axis='x')
        else:
            ax.autoscale(False,axis='x')
            ax.set_xbound(xscale.min,xscale.max)
        
        if yscale.autoscale:
            ax.autoscale(True,axis='y')
        else:
            ax.autoscale(False,axis='y')
            ax.set_ybound(yscale.min,yscale.max)
        
        data = self.pl_plot_file.data
        linewidth = self._options['linewidth'].value
                
        # draw the curves
        g = LineStyleGenerator()
        p = self._parameter_names[self._param_index]
        sf = self._parameter_scaling[self._param_index]
        x, y = [], []
        last_vd = -100000000.0
        label = None
        for i,dset in enumerate(data):
            if dset['vd'] < last_vd:
                # this is a new curve, plot the data
                if len(x) > 1:
                    kw = {'lw':linewidth, 'label':label}
                    kw['c'], kw['ls'] = g.next_style()
                    ax.plot(x,y,**kw)
                x, y = [], []
                label = None
            
            last_vd = dset['vd']
            x.append(dset['vdm'])
            y.append(dset[p]*sf)
            if label is None:
                label = 'Vg = %.3f'%dset['vg']
        
        # plot the last set
        if len(x) > 1:
            kw = {'lw':linewidth, 'label':label}
            kw['c'], kw['ls'] = g.next_style()
            ax.plot(x,y,**kw)
        
        # generate the legend
        if self._options['show_legend'].value:
            ax.legend(loc='upper right',fontsize='x-small')
    
class SSVsIdCanvas(_ssbase,PlotlibCanvasBase):
    "Plot figure for plotting PIV data"
    
    pl_name = 'ssvsid'
    
    _ylabel_strings = ['Cgs (pF)','Cgd (pF)','Gm (mS)','Gds (mS)','Cds (pF)','ft (GHz)']
    _parameter_scaling = [1.0e12,1.0e12,1.0e3,1.0e3,1.0e12,1.0e-9]
    _parameter_names = ['cgs','cgd','gm','gds','cds','ft']
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(SSVsIdCanvas,self).__init__(parent,**kwargs)
        
        self._init_common()
        self._scaledata[0].allow_log = True
                
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax = self.figure.axes[0]
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax.cla()
        ax.hold(True)
        ax.grid(True)
        
        # set the axis labels and title
        ax.set_xlabel('Ids (mA)')
        ax.set_ylabel(self._ylabel_strings[self._param_index])
        ax.set_title(self._options['title'].value)
        
        if not self.pl_plot_file or not self.pl_plot_file.data:
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        yscale = self._scaledata[self._param_index+1]
        
        if xscale.autoscale:
            ax.autoscale(True,axis='x')
        else:
            ax.autoscale(False,axis='x')
            ax.set_xbound(xscale.min,xscale.max)
        
        if xscale.logscale:
            ax.set_xscale('log')
        
        if yscale.autoscale:
            ax.autoscale(True,axis='y')
        else:
            ax.autoscale(False,axis='y')
            ax.set_ybound(yscale.min,yscale.max)
        
        data = self.pl_plot_file.data
        linewidth = self._options['linewidth'].value
        
        # re-arrange the data
        d2 = {}
        for dset in data:
            vd = dset['vd']
            if vd not in d2:
                d2[vd] = []
            d2[vd].append(dset)
        
        sortf = lambda a, b: cmp(a['vg'],b['vg'])
        for vd in d2:
            d2[vd].sort(sortf)
        
        vdlist = list(d2)
        vdlist.sort()
        
        # draw the curves
        g = LineStyleGenerator()
        p = self._parameter_names[self._param_index]
        sf = self._parameter_scaling[self._param_index]
        for vd in vdlist:
            label = 'Vd = %g'%vd
            kw = {'lw':linewidth, 'label':label}
            kw['c'], kw['ls'] = g.next_style()
            x, y = [], []
            for dset in d2[vd]:
                x.append(dset['id']*1.0e3)
                y.append(dset[p]*sf)
            ax.plot(x,y,**kw)
        
        # generate the legend
        if self._options['show_legend'].value:
            ax.legend(loc='upper right',fontsize='x-small')
        
# register the canvas so that it can be used when adding new canvases        
register_canvas(SSParamsCanvas,'Small Sig. Params')
register_canvas(SSVsIdCanvas,'Small Sig. vs. Ids')
