# import canvases so that they can be registerd
def _load_canvases():
    import os, os.path
    d = os.path.split(__file__)[0]
    for f in os.listdir(d):
        fn, ext = os.path.splitext(f)
        if ext.lower() == '.py' and not fn.startswith('_'):
            __import__('macomplot.canvases.'+fn)
    
_load_canvases()