from __future__ import (absolute_import, division, print_function,
                        unicode_literals)
                        
from collections import OrderedDict
from .. import PlotlibCanvasBase, MultiFileCanvas, PlotOption, AxisScale, register_canvas
from ..styles import LineStyleGenerator

import os.path


class _pivbase:
    "pulsed I-V base class with common methods"

    def _init_common(self):
        "common initialization"
        # create the plot axes
        self.figure.add_axes([0.1,0.1,0.8,0.8])

        self._options = OrderedDict( [('title',PlotOption('string','Title','Pulsed I-V')),
            ('show_legend',PlotOption('bool','Show Legend',True)),
            ('linewidth',PlotOption('int','Line Width',2,minv=1)),
            ]
        )
        
        self._scaledata = [
            AxisScale(label='X'),
            AxisScale(label='Y'),
        ]
        
        self.redraw_plot_figure()
            
    def read_plot_file(self, fname):
        "read a pulsed I-V data file"
        v = 0
        fp = open(fname,'rU')
        line = fp.readline()
        if line.startswith('!$$version'):
            # this is a newer style file
            v = int(line.split()[-1])
            
        data = []
        try:
            last_vd = -10000000.0
            vdl, idl = [], []
            label = None
            for line in fp:
                try:
                    vals = [float(x) for x in line.split()]
                    
                    if len(vals) > 5:
                        if v:
                            vdset = vals[2]
                            vd = vals[4]
                            id = vals[5]*1000.0
                            vg = vals[1]
                        else:
                            # old file version
                            vdset = vals[1]
                            vd = vals[3]
                            id = vals[5]*1000.0
                            vg = vals[0]
                        
                        if vdset < last_vd and len(vdl) > 0:
                            data.append( (vdl,idl,label) )
                            vdl, idl = [], []
                            label = None
                        last_vd = vdset
                        
                        vdl.append(vd)
                        idl.append(id)
                        if label is None:
                            label = 'Vg = %.3f'%vg
                
                except Exception:
                    pass

            if len(vdl) > 0:
                data.append( (vdl,idl,label) )
                
        finally:
            fp.close()
            
        return data
        
    def get_plot_options(self):
        """get plot options
        
        This should be a dictionary of PlotOption objects
        """
        return self._options
    
    def set_plot_options(self, options):
        """set plot options
        
        This will be a dictionary of values
        """
        self.redraw_plot_figure()
        
    def get_plot_scale_data(self):
        "get scale data"
        x = self._scaledata[0]
        y = self._scaledata[1]
        x.min, x.max = self.figure.axes[0].get_xbound()
        y.min, y.max = self.figure.axes[0].get_ybound()
        
        return self._scaledata

    def set_plot_scale_data(self, scale_data):
        "set scale data"
        self.redraw_plot_figure()
        

class PIVPlotCanvas(_pivbase,PlotlibCanvasBase):
    "Plot figure for plotting PIV data"
    
    pl_name = 'pulsediv'
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(PIVPlotCanvas,self).__init__(parent,**kwargs)
        
        self._init_common()
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax = self.figure.axes[0]
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax.cla()
        ax.hold(True)
        ax.grid(True)
        
        # set the axis labels and title
        ax.set_xlabel('Vds (V)')
        ax.set_ylabel('Ids (mA)')
        ax.set_title(self._options['title'].value)
        
        if not self.pl_plot_file or not self.pl_plot_file.data:
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        yscale = self._scaledata[1]
        
        if xscale.autoscale:
            ax.autoscale(True,axis='x')
        else:
            ax.autoscale(False,axis='x')
            ax.set_xbound(xscale.min,xscale.max)
        
        if yscale.autoscale:
            ax.autoscale(True,axis='y')
        else:
            ax.autoscale(False,axis='y')
            ax.set_ybound(yscale.min,yscale.max)
        
        data = self.pl_plot_file.data
        linewidth = self._options['linewidth'].value
        do_legend = self._options['show_legend'].value
        
        # draw the I-V curves
        g = LineStyleGenerator()
        for i,dset in enumerate(data):
            x = dset[0]
            y = dset[1]
            label = dset[2]
                
            # generate keywords and plot
            kw = {'lw':linewidth, 'label':label}
            kw['c'], kw['ls'] = g.next_style()
            ax.plot(x,y,**kw)
            # annotate each curve at the end point
            if x[-1] > 2.9:
                ax.text(x[-1]-0.5,y[-1]+2.0,label,color=kw['c'],fontsize='x-small',horizontalalignment='right')
        
        # generate the legend
        if do_legend:
            ax.legend(loc='upper right',fontsize='x-small')
            
_multicolors = ('#ff0000','#0000ff','#00ff00','#00ffff','#ff00ff',
    '#b45f04','#585858','#868a08','#088a85')

class PIVMultiFile(_pivbase,MultiFileCanvas):
    "canvas for multi-file pulsed I-V comparisons"
    
    pl_name = 'pulsediv_multi'
    pl_max_files = 8
    
    def __init__(self, parent, **kwargs):
        "initializer"        
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(PIVMultiFile,self).__init__(parent,**kwargs)
        
        self._init_common()
        
    def redraw_plot_figure(self):
        "redraw the plot figure"        
        ax = self.figure.axes[0]
        
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        ax.cla()
        ax.hold(True)
        ax.grid(True)
        
        # set the axis labels and title
        ax.set_xlabel('Vds (V)')
        ax.set_ylabel('Ids (mA)')
        ax.set_title(self._options['title'].value)
        
        if not len(self.pl_plot_file_list):
            # nothing to draw on the axes
            return 
        
        # set scaling parameters
        xscale = self._scaledata[0]
        yscale = self._scaledata[1]
        
        if xscale.autoscale:
            ax.autoscale(True,axis='x')
        else:
            ax.autoscale(False,axis='x')
            ax.set_xbound(xscale.min,xscale.max)
        
        if yscale.autoscale:
            ax.autoscale(True,axis='y')
        else:
            ax.autoscale(False,axis='y')
            ax.set_ybound(yscale.min,yscale.max)
        
        linewidth = self._options['linewidth'].value
        
        i = 0
        lines, labels = [], []
        for file in self.pl_plot_file_list:
            data = file.data
            if not data:
                continue
            
            labels.append(os.path.basename(file.fname))
            
            # draw the I-V curves
            for j,dset in enumerate(data):
                x = dset[0]
                y = dset[1]
                # label = dset[2]
                    
                # generate keywords and plot
                kw = {'lw':linewidth, 'c': _multicolors[i], 'ls':'-'}
                x = ax.plot(x,y,**kw)[0]
                if j == 0:
                    lines.append(x)
            
            i += 1
            
        # generate the legend
        #if self._options['show_legend'].value:
        #    ax.legend(loc='upper right',fontsize='x-small')
        if self._options['show_legend'].value:
            self.figure.legend(lines,labels,loc='upper right',fontsize='x-small')
    
        
# register the canvas so that it can be used when adding new canvases        
register_canvas(PIVPlotCanvas,'Pulsed I-V')
register_canvas(PIVMultiFile,'Pulsed I-V (multi-file)')

