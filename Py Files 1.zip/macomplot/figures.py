from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import numpy as np
from numpy import cos, sin, log10, pi, matrix, absolute, angle
from matplotlib import dates, ticker
from matplotlib.dates import date2num

from datetime import datetime, timedelta
from collections import OrderedDict

from network_params import Touchstone, Param, ParamSet
from modeling.fet import yfit

from .styles import *

class SingleRectPlot(Figure):
    "Rectangular Plot Figure with one Y-axis"
    
    def __init__(self, *args, **kwargs):
        super(SingleRectPlot, self).__init__(*args, **kwargs)
        self.add_axes([0.075, 0.075, 0.85, 0.85])
        self.resetPlot()
        
    def plotData(self, xdata, ydata, label="Series", linestyle=_styleLUT(LineStyle.Solid), linecolor=_colorLUT(LineColor.LtRed), **kwargs):
        """
        xdata, ydata - list of doubles
        label - string
        linestyle - string (usually determined from LUT)
        linecolor - string (usually determined from LUT)
        
        Plot given y data vs the given x data on the graph. Doesn't clear
        the graph before plotting, so multiple calls to this function will
        lead to multiple plots on the same axes
        """
        # generate keywords and plot
        kw = { }
        kw['lw'] = 1
        kw['ls'] = linestyle
        kw['c'] = linecolor
        kw['label'] = label
        for key, val in kwargs:
            kw[key] = val

        self.axes[0].plot(xdata, ydata, **kw)

    def scatterData(self, xdata, ydata, markercolor=_colorLUT(LineColor.Black), markerstyle=_markerLUT(MarkerType.x), **kwargs):
        self.axes[0].scatter(xdata, ydata, c=markercolor, marker=markerstyle, **kwargs)
    
    def plotContour(self, xvals, yvals, zvals, numContours=5, linewidth=1, label="Series", linecolor=_colorLUT(LineColor.Black), **kwargs):
        contour = self.axes[0].contour(xvals, yvals, zvals, numContours, linewidths=linewidth, colors=linecolor, **kwargs)
        self.axes[0].clabel(contour, fontsize='smaller', fmt='%.1f', inline=1)
        
    def annotate(self, string, xcoord, ycoord, **kwargs):
        ann = self.axes[0].annotate(string, (xcoord, ycoord), **kwargs)
        return ann

    def showLegend(self, show):
        """
        show - boolean

        Show or hide the legend
        """
        # generate the legend
        if show:
            self.axes[0].legend(loc ='upper right',fontsize='x-small')
        else:
            self.axes[0].legend_ = None
            
    def resetPlot(self):
        """
        Clear the axes of any plots
        """
        self.axes[0].cla()
        self.axes[0].hold(True)
        self.axes[0].grid(True, linestyle=_styleLUT(LineStyle.Dot), color=_colorLUT(LineColor.Black))
    
    def getAxisLimits(self):
        """
        Returns three 2-tuples: xlimits, y1limits, y2limits
        
        y2limits is (0.0, 1.0), since this graph type only has one y-axis
        """    
        xmin, xmax = self.axes[0].get_xlim()
        y1min, y1max = self.axes[0].get_ylim()

        return [(xmin, xmax), (y1min, y1max), (0.0, 1.0)]

    def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min=None, y2max=None):
        """
        xmin, xmax, y1min, y1max - double
        y2min, y2max - unused

        Set axis limits accordingly. Since this is a single plot,
        y2min and y2max aren't used. They are kept in the function
        signature in order to be consistent with other potential
        figure types.
        """
        self.axes[0].set_xlim([xmin, xmax])
        self.axes[0].set_ylim([y1min, y1max])

    def setAxisScaling(self, xscale, y1scale, y2scale):
        """
        xscale, y1scale, y2scale - string or None

        Set axis scaling accordingly. Valid inputs are 'linear', 'log', or None
        Since this is a single plot, y2scale isn't used. It is kept in the
        function signature in order to be consistent with other potential
        figure types.
        """
        if xscale is not None:
            self.axes[0].set_xscale(xscale)
        if y1scale is not None:
            self.axes[0].set_yscale(y1scale)
                
    def setXLabel(self, label):
        """
        label - string

        Sets the x-axis label accordingly
        """
        self.axes[0].set_xlabel(label)
        
    def setYLabel(self, label):
        """
        label - string

        Sets the y-axis label accordingly
        """
        self.axes[0].set_ylabel(label)
    
    def setTitle(self, title):
        """
        title - string

        Sets the plot title accordingly
        """
        self.axes[0].set_title(title)

class DoubleRectPlot(Figure):
    "Rectangular Plot Figure with two Y-axes"
    
    def __init__(self, *args, **kwargs):
        super(DoubleRectPlot, self).__init__(*args, **kwargs)
        self.priax = self.add_axes([0.075, 0.075, 0.85, 0.85])
        self.secax = self.priax.twinx()
        self.resetPlot()
        
    def plotData(self, xdata, ydata1, ydata2, ydata1lab="Series 1", ydata2lab="Series 2"):
        """
        xdata, ydata, ydata2 - list of doubles
        ydata1lab, ydata2lab - string
        
        Plot given y data vs the given x data on the graph. Doesn't clear
        the graph before plotting, so multiple calls to this function will
        lead to multiple plots on the same axes. Automatically colors ydata1
        trace red, and ydata2 trace blue.
        """
        self.priax.plot(xdata, ydata1, label=ydata1lab, ls='-', c='#ff0000')
        self.secax.plot(xdata, ydata2, label=ydata2lab, ls='--', c='#0000ff')
    
    def plotPrimary(self, xdata, ydata, ylabel, style=_styleLUT(LineStyle.Solid), color=_colorLUT(LineColor.LtRed)):
        """
        xdata, ydata - list of doubles
        ylabel - string
        
        Plot given y data vs the given x data on the graph's primary axis.
        Doesn't clear the graph before plotting, so multiple calls to this function
        will lead to multiple plots on the same axes.
        """
        self.priax.plot(xdata, ydata, label = ylabel, ls=style, c=color)
    
    def plotSecondary(self, xdata, ydata, ylabel, style=_styleLUT(LineStyle.Dashed), color=_colorLUT(LineColor.LtBlue)):
        """
        xdata, ydata - list of doubles
        ylabel - string
        
        Plot given y data vs the given x data on the graph's secondary axis.
        Doesn't clear the graph before plotting, so multiple calls to this function
        will lead to multiple plots on the same axes.
        """
        self.secax.plot(xdata, ydata, label = ylabel, ls=style, c=color)

    def scatterDataPrimary(self, xdata, ydata, markercolor=_colorLUT(LineColor.Black), markerstyle=_markerLUT(MarkerType.x)):
        self.priax.scatter(xdata, ydata, c=markercolor, marker=markerstyle)

    def scatterDataSecondary(self, xdata, ydata, markercolor=_colorLUT(LineColor.Black), markerstyle=_markerLUT(MarkerType.x)):
        self.secax.scatter(xdata, ydata, c=markercolor, marker=markerstyle)

    def annotatePri(self, string, xcoord, ycoord, **kwargs):
        ann = self.priax.annotate(string, (xcoord, ycoord), **kwargs)
        return ann

    def annotateSec(self, string, xcoord, ycoord, **kwargs):
        ann = self.secax.annotate(string, (xcoord, ycoord), **kwargs)
        return ann

    def showLegend(self, show):
        """
        show - boolean

        Show or hide the legend
        """
        # generate the legend
        if show:
            self.priax.legend(loc ='upper left',fontsize='x-small')
            self.secax.legend(loc ='upper right',fontsize='x-small')
        else:
            self.priax.legend_ = None
            self.secax.legend_ = None
    
    def resetPlot(self):
        """
        Clear the axes of any plots
        """
        self.priax.cla()
        self.priax.grid(True, linestyle=_styleLUT(LineStyle.Dot), color=_colorLUT(LineColor.Black))
        self.secax.cla()
        self.secax.grid(True, linestyle=_styleLUT(LineStyle.Dot), color=_colorLUT(LineColor.Black))
    
    def getAxisLimits(self):
        """
        Returns three 2-tuples: xlimits, y1limits, y2limits
        """    
        xmin, xmax = self.priax.get_xlim()
        y1min, y1max = self.priax.get_ylim()
        y2min, y2max = self.secax.get_ylim()

        return [(xmin, xmax), (y1min, y1max), (y2min, y2max)]

    def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min, y2max):
        """
        xmin, xmax, y1min, y1max, y2min, y2max - double

        Set axis limits accordingly.
        """
        self.priax.set_xlim([xmin, xmax])
        self.priax.set_ylim([y1min, y1max])
        self.secax.set_ylim([y2min, y2max])
    
    def setAxisScaling(self, xscale, y1scale, y2scale = None):
        """
        xscale, y1scale, y2scale - string

        Set axis scaling accordingly. Valid inputs are 'linear', 'log', and None.
        """
        
        if xscale is not None:
            self.priax.set_xscale(xscale)
        if y1scale is not None:
            self.priax.set_yscale(y1scale)
        if y2scale is not None:
            self.secax.set_yscale(y2scale)
    
    def setXLabel(self, label):
        """
        label - string

        Sets the x-axis label accordingly
        """
        self.priax.set_xlabel(label)
    
    def setY1Label(self, label):
        """
        label - string

        Sets the first y-axis label accordingly
        """
        self.priax.set_ylabel(label)
    
    def setY2Label(self, label):
        """
        label - string

        Sets the second y-axis label accordingly
        """
        self.secax.set_ylabel(label)
    
    def setTitle(self, title):
        """
        title - string

        Sets the plot title accordingly
        """
        self.priax.set_title(title)

class DCMonitorPlot(Figure):
    "Figure for plotting DC Monitor data"
    
    def __init__(self,*args,**kwargs):
        "initializer"
        # strip keywords specific to this figure
        
        # init parent
        super(DCMonitorPlot,self).__init__(*args,**kwargs)
        self.add_axes([0.075, 0.075, 0.85, 0.85])
    
    def plotData(self, times, data, terminal):
        "plot the data on the axes"
        
        # check argument
        if not isinstance(data, list):
            raise TypeError("'data' must be a list")
        
        # reset the plot
        self.resetPlot(terminal)
        
        # set/rotate x-axis labels
        self.axes[0].set_xticklabels(times, rotation='30')
    
        # set x-axes to plot time elapsed based on timeTicks formatter
        def timeTicks(x, pos):
            d = timedelta(seconds=x)
            return str(d)
        
        timeformatter = ticker.FuncFormatter(timeTicks)
        self.axes[0].get_xaxis().set_major_formatter(timeformatter)
        
        # plot data
        self.axes[0].plot(times, data)
        
        # set graphs to use scientific notation on y-axis
        self.axes[0].ticklabel_format(style='sci', scilimits=(0,0), axis='y')
    
    def resetPlot(self, terminal):
        "reset the plot"
        # clear the axes
        self.axes[0].cla()
        self.axes[0].grid(True)
        
        # set the axis labels
        self.axes[0].set_xlabel('Time (D:HH:MM elapsed)')
        if terminal == "Gate":
            self.axes[0].set_ylabel('Ig (A)')
            self.axes[0].set_title('Igate vs Time')
        else:
            self.axes[0].set_ylabel('Id (A)')
            self.axes[0].set_title('Idrain vs Time')
    
    def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min=None, y2max=None):
        self.axes[0].set_xlim([xmin, xmax])
        self.axes[0].set_ylim([y1min, y1max])
    
    def showLegend(self, show):
        # generate the legend
        if show:
            self.axes[0].legend(loc ='upper right',fontsize='x-small')
        else:
            self.axes[0].legend_ = None

class SmithPlot(Figure):
    "Smith Chart Plot Figure"
    
    def __init__(self, *args, **kwargs):
        super(SmithPlot, self).__init__(*args, **kwargs)
        #self.set_tight_layout(True)
        self.add_subplot(1, 1, 1, projection="smith", axes_scale=1.0)
    
    def plotLine(self, data_normalized_complex, label="Series", linestyle=LineStyle.Solid, linecolor=LineColor.LtRed):
        # generate keywords and plot
        kw = { }
        kw['lw'] = 2
        kw['ls'] = _styleLUT(linestyle)
        kw['c'] = _colorLUT(linecolor)
        kw['label'] = label
        kw['marker'] = None
        self.axes[0].plot(data_normalized_complex, **kw)
    
    def scatterData(self, xdata, ydata, markercolor=_colorLUT(LineColor.Black), markerstyle=_markerLUT(MarkerType.x), **kwargs):
        self.axes[0].scatter(xdata, ydata, c=markercolor, marker=markerstyle, **kwargs)
    
    def plotContour(self, xvals, yvals, zvals, numContours=5, linewidth=1, label="Series", linecolor=_colorLUT(LineColor.Black), **kwargs):
        contour = self.axes[0].contour(xvals, yvals, zvals, numContours, linewidths=linewidth, colors=linecolor, **kwargs)
        self.axes[0].clabel(contour, fontsize='smaller', fmt='%.1f', inline=1)

    def annotate(self, string, xcoord, ycoord, **kwargs):
        ann = self.axes[0].annotate(string, (xcoord, ycoord), **kwargs)
        return ann

    def showLegend(self, show):
        # generate the legend
        if show:
            self.axes[0].legend(loc ='upper right',fontsize='x-small')
        else:
            self.axes[0].legend_ = None
    
    def resetPlot(self):
        self.axes[0].cla()
        self.axes[0].grid(True)
    
    def setTitle(self, title):
        self.axes[0].set_title(title)
