from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from enum import Enum

class ComplexType(Enum):
    MagAngle = 0
    RealImag = 1

class LineStyle(Enum): # use in conjunction with global _styleLUT function
    Solid     = 0
    Dashed     = 1
    DashDot = 2
    Dot     = 3

class LineColor(Enum):
    LtRed       = 0     #ff0000
    DkRed       = 1     #800000
    LtGreen     = 2     #00ff00
    DkGreen     = 3     #008000
    LtBlue      = 4     #0000ff
    DkBlue      = 5     #000080
    Orange      = 6     #ff8000
    Lime        = 7     #80ff00
    Yellow      = 8     #ffff00
    Magenta     = 9     #ff0080
    DkPurple    = 10    #8000ff
    Purple      = 11    #ff00ff
    Aqua        = 12    #00ff80
    SkyBlue     = 13    #0080ff
    Cyan        = 14    #00ffff
    Black       = 15    #000000

class MarkerType(Enum):
    point           = 0
    pixel           = 1
    circle          = 2
    triangle_down   = 3
    triangle_up     = 4
    triangle_left   = 5
    triangle_right  = 6
    tri_down        = 7
    tri_up          = 8
    tri_left        = 9
    tri_right       = 10
    octagon         = 11
    square          = 12
    pentagon        = 13
    star            = 14
    hexagon1        = 15
    hexagon2        = 16
    plus            = 17
    x               = 18
    diamond         = 19
    thin_diamond    = 20
    vline           = 21
    hline           = 22
    tickleft        = 23
    tickright       = 24
    tickup          = 25
    tickdown        = 26
    caretleft       = 27
    caretright      = 28
    caretup         = 29
    caretdown       = 30
    none            = 31

class SParLUT(Enum):
    S11 = 0
    S12 = 1
    S21 = 2
    S22 = 3

class RectAxis(Enum):
    x = 0
    y1 = 1
    y2 = 2

def _styleLUT(style=LineStyle.Solid):
    "get the line style associated with the index"
    # 16 colors, 4 line styles
    styles = ['-','--','-.',':']
    
    if isinstance(style, LineStyle):    
        return styles[style.value]
    elif isinstance(style, int):
        return styles[(style//16)%4]
    else:
        raise ValueError

def _colorLUT(color=LineColor.LtRed):
    "get the line color associated with the index"
    # 16 colors
    colors = ['#ff0000', '#800000', '#00ff00', '#008000', '#0000ff', '#000080', '#ff8000', '#80ff00', '#ffff00', '#ff0080', '#8000ff', '#ff00ff', '#00ff80', '#0080ff', '#00ffff', '#000000']
    
    if isinstance(color, LineColor):    
        return colors[color.value]
    elif isinstance(color, int):
        return colors[color%16]
    else:
        raise ValueError

def _markerLUT(marker=MarkerType.x):
    "get the marker style associated with the index"
    # 32 marker styles in matplotlib (including none)
    markers = [  '.', ',', 'o', 'v', '^', '<', '>',
                '1', '2', '3', '4', '8', 's', 'p',
                '*', 'h', 'H', '+', 'x', 'D', 'd',
                '|', '_', 'TICKLEFT', 'TICKRIGHT',
                'TICKUP', 'TICKDOWN', 'CARETLEFT',
                'CARETRIGHT', 'CARETUP', 'CARETDOWN',
                '']

    if isinstance(marker, MarkerType):
        return markers[marker.value]
    elif isinstance(marker, int):
        return colors[marker%32]
    else:
        raise ValueError

class LineStyleGenerator(object):
    "generate line styles for a plot"
    _colors = ('#ff0000', '#800000', '#00ff00', '#008000', '#0000ff', '#000080',
        '#ff8000', '#80ff00', '#ffff00', '#ff0080', '#8000ff', '#ff00ff',
        '#00ff80', '#0080ff', '#00ffff', '#000000')
    _ltypes = ('-','--','-.',':')

    def __init__(self):
        self._i = 0
        self._nc = len(self._colors)
        self._nl = len(self._ltypes)
        self._max = self._nl*self._nc
        
    def next_style(self):
        "get the next style"
        i = self._i
        if i >= self._max:
            raise ValueError('out of styles')
        color = self._colors[i%self._nc]
        linetype = self._ltypes[i//self._nc]
        self._i += 1
        return color, linetype
    
    
    
    
    
    
    
    
    
    
    
