from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

# import matplotlib and the smithplot projection
import matplotlib
from . import smithplot

from .helpers import PlotOption, AxisScale, PlotFile
from .base import (PlotlibFrame, PlotlibPanel, PlotlibMultiPanel, PlotlibCanvasBase,
    MultiFileCanvas, register_canvas, get_canvas_by_label, get_canvas_by_name, get_all_canvas_types)
    
# import all canvases to allow them to be registered
from . import canvases

