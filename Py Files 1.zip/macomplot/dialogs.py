from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import wx
from .helpers import PlotOption, AxisScale

class AddCanvasDialog(wx.Dialog):
    """dialog that prompts for the canvas to add to a multiplot window"""
    
    def __init__(self, parent, *args, **kwargs):
        "initializer"
        
        # init parent
        wx.Dialog.__init__(self,parent,*args,**kwargs)
        
        self.SetTitle("Select Canvas Type")
        
        # get possible canvas types
        from . import get_all_canvas_types
        self.canvasdict = get_all_canvas_types()
        labels = self.canvasdict.keys()
        labels.sort()
        
        self.canvas_list = labels
        self.selected_canvas = None
        
        # dialog layout sizer
        mainsz = wx.BoxSizer(wx.VERTICAL)
        
        # create the controls
        
        mainsz.Add((300,10))
        mainsz.Add(wx.StaticText(self,wx.ID_ANY,'Select a plot canvas type\nfor the new plot.'),0,wx.ALL|wx.ALIGN_CENTER,5)
        mainsz.Add((-1,10))
        
        self.choicebox = wx.Choice(self,choices=self.canvas_list)
        mainsz.Add(self.choicebox,0,wx.LEFT|wx.RIGHT|wx.ALIGN_CENTER,10)

        # add a seperator
        mainsz.Add((-1,8))
        mainsz.Add(wx.StaticLine(self),0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        # add the dialog buttons
        ok = wx.Button(self,wx.ID_OK)
        cancel = wx.Button(self,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        mainsz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        self.SetSizer(mainsz)
        self.Fit()
        self.Layout()
                
    def OnOK(self, event):
        "callback for when the OK button is pressed"
        try:
            i = self.choicebox.GetSelection()
            if i >= 0:
                self.selected_canvas = self.canvasdict[self.canvas_list[i]]
        except Exception:
            self.selected_canvas = None
        
        # allow the event to propagate so that the
        # dialog is closed using the default handler
        event.Skip()

class ScalingDialog(wx.Dialog):
    """Dialog that allows the user to adjust axis scaling parameters
    
    
    """
    
    def __init__(self, parent, *args, **kwargs):
        "initializer"
        
        # init parent
        wx.Dialog.__init__(self,parent,*args,**kwargs)
        
        self.SetTitle("Set Scaling")
        
        # create the initial framwork for the dialog
        self._scdata = []
        self._ctrlsz = wx.BoxSizer(wx.VERTICAL)
        
        # dialog layout sizer
        mainsz = wx.BoxSizer(wx.VERTICAL)
        mainsz.Add(self._ctrlsz,0,wx.EXPAND|wx.ALL,5)

        # add a seperator
        mainsz.Add((-1,8))
        mainsz.Add(wx.StaticLine(self),0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        # add the dialog buttons
        ok = wx.Button(self,wx.ID_OK)
        cancel = wx.Button(self,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        mainsz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        self.SetSizer(mainsz)
        self.Fit()
        self.Layout()
        
    def SetupUI(self, scale_data):
        "setup the UI - this must be done before showing the dialog"
        # clear any existing UI, deleting all windows
        self._ctrlsz.Clear(True)
        self._ctrl_list = []
        self._scdata = scale_data
        
        if not isinstance(scale_data,(list,tuple)):
            raise TypeError('scale_data must be a list/tuple')
        
            
        for sc in scale_data:
            if not isinstance(sc,AxisScale):
                raise TypeError('scale_data must be a list/tuple of `AxisScale` objects')
            
            # create a static box panel to hold the axis scaling information
            pan = wx.Panel(self)
            _sz = wx.BoxSizer(wx.VERTICAL)
            box = wx.StaticBoxSizer(wx.StaticBox(pan,label=sc.label),wx.VERTICAL)
            _sz.Add(box,1,wx.EXPAND|wx.ALL,3)
            pan.SetSizer(_sz)
                        
            # add controls as necessary
            c = {}
            hsz = wx.BoxSizer(wx.HORIZONTAL)
            c['auto'] = wx.CheckBox(pan,wx.ID_ANY,'Autoscale')
            c['log'] = wx.CheckBox(pan,wx.ID_ANY,'Logarithmic')
            hsz.Add(c['auto'],0,wx.LEFT|wx.RIGHT,5)
            hsz.Add((20,-1))
            hsz.Add(c['log'],0,wx.LEFT|wx.RIGHT,5)
            
            box.Add((-1,10))
            box.Add(hsz,0,wx.EXPAND)
            
            hsz = wx.BoxSizer(wx.HORIZONTAL)
            c['min'] = wx.TextCtrl(pan,wx.ID_ANY,size=(50,-1))
            c['max'] = wx.TextCtrl(pan,wx.ID_ANY,size=(50,-1))
            hsz.Add(wx.StaticText(pan,wx.ID_ANY,'Axis Limits:'),0,wx.LEFT,5)
            hsz.Add((10,-1))
            hsz.Add(wx.StaticText(pan,wx.ID_ANY,'Min'))
            hsz.Add(c['min'],0,wx.LEFT,5)
            hsz.Add((20,-1))
            hsz.Add(wx.StaticText(pan,wx.ID_ANY,'Max'))
            hsz.Add(c['max'],0,wx.LEFT|wx.RIGHT,5)
        
            box.Add((-1,4))
            box.Add(hsz,0,wx.EXPAND)
            box.Add((-1,4))
            
            # set values
            c['auto'].SetValue(bool(sc.autoscale))
            c['log'].SetValue(bool(sc.logscale))
            if sc.min is not None:
                c['min'].SetValue('%g'%sc.min)
            if sc.max is not None:
                c['min'].SetValue('%g'%sc.min)
            
            # disable/enable controls
            if not sc.allow_manual:
                c['auto'].Enable(False)
            if not sc.allow_log:
                c['log'].Enable(False)
            if bool(sc.autoscale):
                c['min'].Enable(False)
                c['max'].Enable(False)
                
            # store the controls
            self._ctrl_list.append(c)
            
            # bind changes to the autoscale button
            self.Bind(wx.EVT_CHECKBOX,self.OnAutoChange,c['auto'])
            
            # add the box to the main sizer
            self._ctrlsz.Add(pan,0,wx.EXPAND|wx.TOP|wx.BOTTOM,3)
        
        self.Fit()
        self.Layout()
            
    def OnAutoChange(self, event):
        "enable/disable the min/max scale boxes depending on the autoscale state"
        wid = event.GetId()
        for c in self._ctrl_list:
            if c['auto'].GetId() == wid:
                if event.Checked():
                    c['min'].Enable(False)
                    c['max'].Enable(False)
                else:
                    c['min'].Enable(True)
                    c['max'].Enable(True)
                break
        
    def OnOK(self, event):
        "callback for when the OK button is pressed"
        which = ''
        try:
            for i in range(len(self._scdata)):
                sc = self._scdata[i]
                c = self._ctrl_list[i]
                which = sc.label
                if sc.allow_manual:
                    sc.autoscale = bool(c['auto'].GetValue())
                    vmin = c['min'].GetValue().strip()
                    vmax = c['max'].GetValue().strip()
                    if vmin:
                        sc.min = float(vmin)                    
                    if vmax:
                        sc.max = float(vmax)
                if sc.allow_log:
                    sc.logscale = bool(c['log'].GetValue())
        except Exception as e:
            dlg = wx.MessageDialog(self,"while processing axis '%s': %s"%(which,e),'Error',wx.ICON_ERROR|wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # allow the event to propagate so that the
        # dialog is closed using the default handler
        event.Skip()
    
    
    
    
class OptionsDialog(wx.Dialog):
    """Dialog that allows the user to set plot options
    
    """
    
    def __init__(self, parent, *args, **kwargs):
        "initializer"
        
        # init parent
        wx.Dialog.__init__(self,parent,*args,**kwargs)
        
        self.SetTitle("Plot Options")
        
        # create the initial framwork for the dialog
        self._ctrlsz = wx.FlexGridSizer(cols=2,hgap=15,vgap=4)
        
        # dialog layout sizer
        mainsz = wx.BoxSizer(wx.VERTICAL)
        mainsz.Add(self._ctrlsz,0,wx.EXPAND|wx.ALL,5)

        # add a seperator
        mainsz.Add((-1,8))
        mainsz.Add(wx.StaticLine(self),0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        # add the dialog buttons
        ok = wx.Button(self,wx.ID_OK)
        cancel = wx.Button(self,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        mainsz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        self.SetSizer(mainsz)
        self.Fit()
        self.Layout()
        
    def SetupUI(self, option_data):
        "setup the UI - this must be done before showing the dialog"        
        # clear any existing UI, deleting all windows
        self._ctrlsz.Clear(True)
        self._ctrl_list = []
        
        if not isinstance(option_data,dict):
            raise TypeError('option_data must be a dictionary-like object')
        
        for k in option_data:
            opt = option_data[k]
            ty = opt.type
            c = {'name':k, 'type':ty, 'opt':opt, 'ischoice':False}
            
            # create the control
            if ty == 'string':
                c['ctrl'] = wx.TextCtrl(self,wx.ID_ANY,size=(120,-1))
                c['ctrl'].SetValue(opt.value)
            elif ty in ('int','float'):
                c['ctrl'] = wx.TextCtrl(self,wx.ID_ANY,size=(30,-1))
                if ty == 'int':
                    c['ctrl'].SetValue('%d'%opt.value)
                else:
                    c['ctrl'].SetValue('%g'%opt.value)                    
            elif ty == 'bool':
                c['ctrl'] = wx.CheckBox(self)
                c['ctrl'].SetValue(opt.value)                    
            elif ty == 'select':
                c['ischoice'] = True
                c['ctrl'] = wx.Choice(self,choices=opt._choices)
                c['ctrl'].SetSelection(opt.selected)
            else:
                raise ValueError("cannot handle plot option type '%s'"%ty)
            
            # add to the sizer
            self._ctrlsz.Add(wx.StaticText(self,wx.ID_ANY,opt.label))
            self._ctrlsz.Add(c['ctrl'])
            
            self._ctrl_list.append(c)
        
        self.Fit()
        self.Layout()
        
    def OnOK(self, event):
        "callback for when the OK button is pressed"
        which = ''
        try:
            for c in self._ctrl_list:
                which = c['name']
                opt = c['opt']
                if c['ischoice']:
                    opt.selected = c['ctrl'].GetSelection()
                else:
                    opt.value = c['ctrl'].GetValue()
        except Exception as e:
            dlg = wx.MessageDialog(self,"while processing option '%s': %s"%(which,e),'Error',wx.ICON_ERROR|wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # allow the event to propagate so that the
        # dialog is closed using the default handler
        event.Skip()
