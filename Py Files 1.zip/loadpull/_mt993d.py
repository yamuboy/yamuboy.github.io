"""
Interface to the Maury ATS DLL that is provided by the MT993D package

"""
from __future__ import division, print_function, unicode_literals, absolute_import
from ctypes import *

class MauryError(Exception):
    "exception object raised by DLL errors"
    pass

class TunerInfo:
    """tuner information
    
    returned by the add_tuner() and get_tuner_params() functions
    """
    number = -1
    num_motors = 0
    max_range = (0,0,0)
    z0_posn = None
    f_min = 0.0
    f_max = 0.0
    f_cross = 0.0
    
# open the Maury MT993D DLL on first access (lazy initialization)
__dllhandle = None
def _mt993dll():
    "open/return the handle to the ctypes DLL wrapper" 
    global __dllhandle
    if __dllhandle is None:
        __dllhandle = WinDLL('MLibTuners.dll')
    return __dllhandle

# constants used by the module
_MAX_HARM = 10
_MAX_FREQ = 51
_ERR_BUF_LEN = 200    
    
########################################################################################
##             Functions exported from the MT993D DLL library                         ##
########################################################################################

def get_tuner_driver_version():
    """Get the version of the DLL.
    
    Returns the DLL version string.
    """
    ## void __stdcall get_tuner_driver_version(char version_string[]);
    s = create_string_buffer(100)
    _mt993dll().get_tuner_driver_version(s)
    return s.value.decode('ascii')

def get_model_lists(driver):
    """Get the supported controller and tuner models.
    driver - string, the name of the controller driver
    
    Returns a 2-tuple of strings, the first is the supported controllers and the
      second is the supported tuners.
    """
    ## short __stdcall get_model_lists(char FileName[],
    ##     char controller_model_string[],	char tuner_model_string[],
    ##     char error_string[]);
    func = _mt993dll().get_model_lists
    func.restype = c_short
    ctrs = create_string_buffer(500)
    tuners = create_string_buffer(500)
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(driver,ctrs,tuners,err):
        raise MauryError(err.value.decode('ascii'))
    return ctrs.value.decode('ascii'),tuners.value.decode('ascii')

def add_gpib_board(model, timeout, address, delay_ms, driver):
    """Add a GPIB board definition.
    model - string, the board model
    timeout - integer, the GPIB timeout parameter 0 to 17 (see NI GPIB docs for details)
    address - integer, the GPIB address
    delay_ms - integer, a millisecond delay that is elapsed after performing tuner operations
    driver - string, the name of the GPIB board driver
    """
    ## short __stdcall add_gpib_board(char model[], int timeout,
    ##     int address, long delay_ms, char driver[], char error_string[]);
    func = _mt993dll().add_gpib_board
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(model,timeout,address,delay_ms,driver,err):
        raise MauryError(err.value.decode('ascii'))

def add_tuner(number, model, serial_num, ctrl_num, ctrl_port):
    """Add/configure a tuner.
    number - integer, 0 to 7 denotes the tuner number to configure
    model - string, the tuner model
    serial_num - integer, the tuner serial number
    ctrl_num - integer, the configured controller number that the tuner connects to
    ctrl_port - integer, the port number that the tuner connects to on the controller
    
    Returns a TunerInfo object.
    """
    ## short __stdcall add_tuner(short tuner_number, char model[],
    ##     short serial_number, short ctlr_num, short ctlr_port, short *no_of_motors,
    ##     long max_range[], double *fmin, double *fmax, double *fcrossover,
    ##     char error_string[]);
    func = _mt993dll().add_tuner
    func.restype = c_short
    num_motors = c_short()
    max_range = (c_long*3)()
    f_min = c_double()
    f_max = c_double()
    f_cross = c_double()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),model,c_short(serial_num),c_short(ctrl_num),c_short(ctrl_port),byref(num_motors),max_range,byref(f_min),byref(f_max),byref(f_cross),err):
        raise MauryError(err.value.decode('ascii'))
        
    info = TunerInfo()
    info.number = number
    info.num_motors = num_motors.value
    info.max_range = (max_range[0],max_range[1],max_range[2])
    info.f_min = f_min.value
    info.f_max = f_max.value
    info.f_cross = f_cross.value
    
    return info
    
def delete_tuner(number):
    """Delete a configured tuner.
    number - integer, 0 to 7 denoting the configured tuner number to delete
    """
    ## short __stdcall delete_tuner(short tuner_number);
    ## short __stdcall delete_tuner_ex(short tuner_number,
    ##     char error_string[]);
    func = _mt993dll().delete_tuner_ex
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number), err):
        raise MauryError(err.value.decode('ascii'))

def add_controller(number, driver, model, timeout, address, delay_ms, serial_num):
    """Add/configure a tuner controller.
    number - integer, 0 to 7 denotes the controller number to configure
    driver - string, the name of the driver
    model - string, the controller model number string
    timeout - integer, the GPIB timeout parameter 0 to 17 (see NI GPIB docs for details)
    address - integer, the GPIB address
    delay_ms - integer, a millisecond delay that is elapsed after performing tuner operations
    serial_num - integer, the controller serial number for USB tuner controllers
    """
    ## short __stdcall add_controller(short controller_number,
    ##     char driver[], char model[], int timeout, int address, long delay_ms,
    ##     short serial_number, char error_string[]);
    func = _mt993dll().add_controller
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),driver,model,timeout,address,delay_ms,c_short(serial_num),err):
        raise MauryError(err.value.decode('ascii'))

def delete_controller(number):
    """Delete a configured tuner controller.
    number - integer, 0 to 7 denoting the configured controller to delete
    """
    ## short __stdcall delete_controller(short controller_number);
    ## short __stdcall delete_controller_ex(short controller_number,
    ##     char error_string[]);
    func = _mt993dll().delete_controller_ex
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),err):
        raise MauryError(err.value.decode('ascii'))
    
def get_tuner_params(number):
    """Get the tuner information.
    number - integer, 0 to 7 denotes the configured tuner number
    
    Reteurns a TunerInfo object.
    """    
    ## short __stdcall get_tuner_params(short tuner_number,
    ##     short *num_motors,long max_range[],long z0_posn[],double *freq_min,
    ##     double *freq_max,double *freq_crossover,char error_string[]);
    func = _mt993dll().get_tuner_params
    func.restype = c_short
    num_motors = c_short()
    max_range = (c_long*3)()
    z0 = (c_long*3)()
    f_min = c_double()
    f_max = c_double()
    f_cross = c_double()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),byref(num_motors), max_range, z0, byref(f_min), byref(f_max), byref(f_cross), err):
        raise MauryError(err.value.decode('ascii'))
    
    info = TunerInfo()
    info.number = number
    info.num_motors = num_motors.value
    info.max_range = (max_range[0],max_range[1],max_range[2])
    info.z0_posn = (z0[0],z0[1],z0[2])
    info.f_min = f_min.value
    info.f_max = f_max.value
    info.f_cross = f_cross.value
    
    return info

########################################################################################
##             Tuner Control Functions                                                ##
########################################################################################

def check_tuner_controllers(gpib_board_addr=0):
    """Check that all configured controllers can be found.
    gpib_board_address - integer, number of the GPIB board that tuner controllers are
       connected to
    """
    ## short __stdcall isthere_tuner_controllers(
    ##     int gpib_board_address,char error_string[]);
    func = _mt993dll().isthere_tuner_controllers
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(gpib_board_addr,err):
        raise MauryError(err.value.decode('ascii'))
    
def get_tuner_init_status(number):
    """Get the initialization status of a tuner.
    number - integer, 0 to 7 denoting the tuner number as configured
    
    Returns an integer (don't know what it means).
    """
    ## short __stdcall get_tuner_init_status(short tuner_number,
    ##     short *status,char error_string[]);
    func = _mt993dll().get_tuner_init_status
    func.restype = c_short
    status = c_short()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),byref(status),err):
        raise MauryError(err.value.decode('ascii'))
    return status.value
    
def init_tuners():
    """Initialize all configured tuners.
    """
    ## short __stdcall init_tuners(char error_string[]);
    func = _mt993dll().init_tuners
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(err):
        raise MauryError(err.value.decode('ascii'))
    
def move_tuner(number,carr,p1,p2):
    """Move a tuner to the specified position.
    number - integer, 0 to 7 denoting the tuner number as configured
    carr - integer, desired carraige position
    p1 - integer, desired probe 1 position
    p2 - integer, desired probe 2 position
    """
    ## short __stdcall move_tuner(short tuner_number,
    ##     long carr,long p1,long p2, char error_string[]);
    func = _mt993dll().move_tuner
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),carr,p1,p2,err):
        raise MauryError(err.value.decode('ascii'))
    
def move_tuners(positions):
    """Move all of the configured tuners to the specified positions.
    positions - an integer-keyed dictionary, where each value is a 3-tuple
       the dictionary keys are 0 through 7 denoting the tuner number as configured
       and the 3-tuples are integers denoting the desired (carriage,probe1,probe2)
       positions.  Each configured tuner number must have an entry.
    """
    ## short __stdcall move_tuners(long carr[], long p1[], long p2[],
    ##     char error_string[]);
    func = _mt993dll().move_tuners
    func.restype = c_short
    carr = (c_long*8)()
    p1 = (c_long*8)()
    p2 = (c_long*8)()
    err = create_string_buffer(_ERR_BUF_LEN)
    for i in range(8):
        if i in positions:
            if len(positions[i]) != 3:
                raise ValueError("expected a 3-tuple for tuner number %d" % i)
            carr[i] = positions[i][0]
            p1[i] = positions[i][1]
            p2[i] = positions[i][2]
    if func(carr,p1,p2,err):
        raise MauryError(err.value.decode('ascii'))

def get_tuner_position(number):
    """Get the tuner position.
    number - integer, 0 to 7 denoting the tuner number as configured
    """
    ## short __stdcall get_tuner_position(short tuner_number,
    ##     long *carr, long *p1, long *p2, char error_string[]);
    func = _mt993dll().get_tuner_position
    func.restype = c_short
    carr = c_long()
    p1 = c_long()
    p2 = c_long()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number), byref(carr), byref(p1), byref(p2), err):
        raise MauryError(err.value.decode('ascii'))
    return carr.value,p1.value,p2.value

########################################################################################
##             Tuner Data File Functions                                              ##
########################################################################################

def read_tuner_data_file(number, fname, tuner_model):
    """Read a tuner data file into memory.
    
    number - integer, 0 to 7 denotes the configured tuner number
    fname - string, the name (with path information, if needed) of the tuner data file
    tuner_model - string, the tuner model
    """
    ## short __stdcall read_tuner_data_file(short tuner_number,
    ## 	char fname[], char tuner_model[], char error_string[]);
    func = _mt993dll().read_tuner_data_file
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)             
    if func(c_short(number), fname, tuner_model, err):
        raise MauryError(err.value.decode('ascii'))
    
def free_tuner_data(number):
    """Free tuner data file memory.
    
    number - integer, 0 to 7 denotes the configured tuner number
    """
    ## short __stdcall free_tuner_data(short tuner_number);
    ## short __stdcall free_tuner_data_ex(short tuner_number,
    ##     char error_string[]);
    func = _mt993dll().free_tuner_data_ex
    func.restype = c_short
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number), err):
        raise MauryError(err.value.decode('ascii'))
    
def get_tuner_freqs(number):
    """Get the frequencies for the tuner.
    
    number - integer, 0 to 7 denotes the configured tuner number
    
    Returns a tuple of frequency values.
    """
    ## short __stdcall get_tuner_freqs(short tuner_number,
    ##     short *numfreq,	double freqs[], char error_string[]);
    func = _mt993dll().get_tuner_freqs
    func.restype = c_short
    num_f = c_short()
    freqs = (c_double*_MAX_FREQ)()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),byref(num_f),freqs,err):
        raise MauryError(err.value.decode('ascii'))
    result = []
    for i in range(num_f.value):
        result.append(freqs[i])
    return tuple(result)
    
def get_tuner_harmonics(number, freq):
    """Get the number of harmonics for a given frequency for the tuner.
    
    number - integer, 0 to 7 denotes the configured tuner number
    freq - float, the frequency of interest in GHz
    
    Returns an integer representing the number of harmonics.
    """                                        
    ## short __stdcall get_tuner_harmonics(short tuner_number,
    ##     double freq, short *num_harmonics, char error_string[]);
    func = _mt993dll().get_tuner_harmonics
    func.restype = c_short
    nharm = c_short()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),c_double(freq),byref(nharm),err):
        raise MauryError(err.value.decode('ascii'))
    return nharm.value
    
def is_tuner_position_interpolated(number, freq, carr, p1, p2):
    """Determine whether a given tuner position is interpolated.
    
    number - integer, 0 to 7 denotes the configured tuner number
    freq - float, the frequency in GHz
    carr - integer, tuner carraige motor position
    p1 - integer, tuner probe 1 moter position
    p2 - integer, tuner probe 2 motor position
    
    Returns true if the position is interpolated.
    """
    ## short __stdcall get_tuner_position_mode(short tuner_number,
    ##     double freq,long carr,long p1,long p2,short *interp_mode,
    ##     char error_string[]);
    func = _mt993dll().get_tuner_position_mode
    func.restype = c_short
    mode = c_short()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),c_double(freq),c_long(carr),c_long(p1),c_long(p2),byref(mode),err):
        raise MauryError(err.value.decode('ascii'))
    return bool(mode)
    
def get_tuner_position_spars(number, freq, interpolate=False):
    """Not sure what this does...no documentation and prototype is weak...
    """
    ## short __stdcall get_tuner_position_spara(short tuner_number,
    ##     double freq,short interp_mode,long *carr,long *p1,long *p2,
    ##     double s11_x[],double s11_y[],double s21_x[], double s21_y[],
    ##     double s12_x[], double s12_y[],double s22_x[], double s22_y[],
    ##     char error_string[]);
    raise NotImplementedError
    
def get_tuner_position_num(number, freq):
    """Get the number of characterized positions for a given tuner and frequency.
    
    number - integer, 0 to 7 denotes the configured tuner number
    freq - float, the frequency in GHz
    
    Returns an integer representing the number of positions.
    """
    ## short __stdcall get_tuner_position_num(short tuner_number,
    ##     double freq,short *num_positions,char error_string[]);
    func = _mt993dll().get_tuner_position_num
    func.restype = c_short
    num = c_short()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),c_double(freq),byref(num),err):
        raise MauryError(err.value.decode('ascii'))
    return num.value
    
def get_tuner_position_list(number, freq):
    """Get all of the characterized positions for the tuner at a frequency.
    
    number - integer, 0 to 7 denotes the configured tuner number
    freq - float, the frequency in GHz
    
    Returns a list of integer 3-tuples representing (carraige,probe1,probe2)
      motor positions for each characterized point.
    """
    ## short __stdcall get_tuner_position_list(short tuner_number,
    ##     double freq,long carr[],long p1[],long p2[],char error_string[]);
    func = _mt993dll().get_tuner_position_list
    func.restype = c_short
    num = get_tuner_position_num(number,freq)
    carr = (c_long*num)()
    p1 = (c_long*num)()
    p2 = (c_long*num)()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),c_double(freq),carr,p1,p2,err):
        raise MauryError(err.value.decode('ascii'))
    result = []
    for i in range(num):
        result.append( (carr[i],p1[i],p2[i]) )
    return result
    
def get_tuner_refl_posn(number, freq, term, target, interpolate=False):
    """Get the tuner position to achieve a given reflection coefficient.
    
    number - integer, 0 to 7 denotes the configured tuner number
    freq - float, the frequency in GHz
    term - complex, the termination reflection coefficient
    target - complex, the target reflection coefficient
    interpolate - boolean, if True interpolate the tuner data set to
       get the target position (requires a hardware key)
       
    Returns an integer 3-tuple of the tuner motor positions.
    """
    ## short __stdcall get_tuner_refl_posn(short tuner_number,
    ##     short interp_mode, double freq, double gamma_termination_x,
    ##     double gamma_termination_y,	double gamma_target_x, double gamma_target_y,
    ##     long *carr, long *p1, long *p2,	char error_string[]);
    func = _mt993dll().get_tuner_refl_posn
    func.restype = c_short
    interp = c_short(0)
    if interpolate: interp.value = 1
    term_x = c_double(term.real)
    term_y = c_double(term.imag)
    target_x = c_double(target.real)
    target_y = c_double(target.imag)
    carr = c_long()
    p1 = c_long()
    p2 = c_long()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),interp,c_double(freq),term_x,term_y,target_x,target_y,byref(carr),byref(p1),byref(p2),err):
        raise MauryError(err.value.decode('ascii'))
    return carr.value,p1.value,p2.value
    
def get_tuner_refl_data(number, freq, term, target, interpolate=False):
    """Get the tuner position and resulting S-parameters for a given target
    reflection coefficient.
    
    number - integer, 0 to 7 denotes the configured tuner number
    freq - float, the frequency in GHz
    term - complex, the termination reflection coefficient
    target - complex, the target reflection coefficient
    interpolate - boolean, if True interpolate the tuner data set to
       get the target position (requires a hardware key)
       
    Returns a 4-tuple.  The first 3 elements are the tuner motor positions and
    the fourth is a list of 2x2 complex-valued numpy matrices representing
    the S-params for each of the available harmonics.
    """
    ## short __stdcall get_tuner_refl_data(short tuner_number,
    ##     short interp_mode,double freq,double gamma_termination_x,
    ##     double gamma_termination_y,double gamma_target_x,double gamma_target_y,
    ##     long *carr,long *p1,long *p2,double s11_x[], double s11_y[],
    ##     double s21_x[], double s21_y[],double s12_x[], double s12_y[],
    ##     double s22_x[], double s22_y[],char error_string[]);
    func = _mt993dll().get_tuner_refl_data
    func.restype = c_short
    interp = c_short(0)
    if interpolate: interp.value = 1
    term_x = c_double(term.real)
    term_y = c_double(term.imag)
    target_x = c_double(target.real)
    target_y = c_double(target.imag)
    carr = c_long()
    p1 = c_long()
    p2 = c_long()
    s11_x = (c_double*_MAX_HARM)()
    s11_y = (c_double*_MAX_HARM)()
    s21_x = (c_double*_MAX_HARM)()
    s21_y = (c_double*_MAX_HARM)()
    s12_x = (c_double*_MAX_HARM)()
    s12_y = (c_double*_MAX_HARM)()
    s22_x = (c_double*_MAX_HARM)()
    s22_y = (c_double*_MAX_HARM)()
    err = create_string_buffer(_ERR_BUF_LEN)
    if func(c_short(number),interp,c_double(freq),term_x,term_y,target_x,target_y,byref(carr),byref(p1),byref(p2),s11_x,s11_y,s21_x,s21_y,s12_x,s12_y,s22_x,s22_y,err):
        raise MauryError(err.value.decode('ascii'))
    spars = []
    for i in range(get_tuner_harmonics(number,freq)):
        spars.append( [[complex(s11_x[i],s11_y[i]),complex(s12_x[i],s12_y[i])],[complex(s21_x[i],s21_y[i]),complex(s22_x[i],s22_y[i])]] )
    return carr.value,p1.value,p2.value,spars

########################################################################################
##             Deembedding Functions                                                  ##
########################################################################################

def read_spar_file(fname):
    """Not going to implement this since the network_params.Touchstone class
    is much better at reading S-params.
    """
    ## short __stdcall read_spara_file(const char fname[],
    ##     short *spara_valid,short *numfreq,double freq[],
    ##     double s11_x[], double s11_y[], double s21_x[], double s21_y[],
    ##     double s12_x[], double s12_y[], double s22_x[], double s22_y[],
    ##     char error_string[]);
    raise NotImplementedError
    
def set_tuner_deembed_dut(number,spars):
    """'Deembed' a set of S-parameter on the DUT side of the tuner.  The
    terminology here is dumb, since this function actually embeds the
    S-parameters onto the tuner.
    
    number - integer, 0 to 7 denotes the configured tuner number
    spars - need to decide what type of object to support...
    """
    ## short __stdcall set_tuner_deembed_dut(short tuner_number, 
    ##     short numfreq, double freq[], double s11_x[], double s11_y[], 
    ##     double s21_x[], double s21_y[], double s12_x[], double s12_y[], 
    ##     double s22_x[], double s22_y[], char error_string[]);
    raise NotImplementedError
    
def set_tuner_deembed_back(number,spars):
    """'Deembed' a set of S-parameter on the non-DUT side of the tuner.   The
    terminology here is dumb, since this function actually embeds the
    S-parameters onto the tuner.
    
    number - integer, 0 to 7 denotes the configured tuner number
    spars - need to decide what type of object to support...
    """
    ## short __stdcall set_tuner_deembed_back(short tuner_number, 
    ##     short numfreq, double freq[], double s11_x[], double s11_y[], 
    ##     double s21_x[], double s21_y[], double s12_x[], double s12_y[], 
    ##     double s22_x[], double s22_y[], char error_string[]);
    raise NotImplementedError
    
def clear_tuner_deembed_dut(number):
    """Clear deembedding on the DUT side of the tuner.
    
    number - integer, 0 to 7 denotes the configured tuner number
    """
    ## short __stdcall clear_tuner_deembed_dut(short tuner_number,
    ##     char error_string[]);
    raise NotImplementedError
    
def clear_tuner_deembed_back(number):
    """Clear deembedding on the non-DUT side of the tuner.
    
    number - integer, 0 to 7 denotes the configured tuner number
    """
    ## short __stdcall clear_tuner_deembed_back(short tuner_number,
    ##     char error_string[]);
    raise NotImplementedError


########################################################################################
##             Test                                                                   ##
########################################################################################

if __name__ == '__main__':
    print('Version: {}'.format(get_tuner_driver_version()))
    ctrl,tun = get_model_lists('Tun1020c.exe')
    print('Controller Models: {}'.format(ctrl))
    print('Tuner Models: {}'.format(tun))
    
