﻿from __future__ import division, print_function, unicode_literals, absolute_import
import datetime
import time
import warnings
import re
import cmath
import operator as _operator

from cmath import pi
from cmath import phase
from cmath import rect as MAtoComplex

_focus_column_translation_map = {
    # maps a lowercase column name specified by the user on the
    # command line to the case-corrected Focus column name
    'pin':'PinWaves[dBm]',
    'pin_dbm':'PinWaves[dBm]',
    'pin_avail':'PinWaves[dBm]',
    'pin_avail_dbm':'PinWaves[dBm]',
    'pin_deliv':'PinDelWaves[dBm]',
    'pin_deliv_dbm':'PinDelWaves[dBm]',
    'pout':'PoutWaves[dBm]',
    'pout_dbm':'PoutWaves[dBm]',
    'gain':'GainWavesTrd[dB]',
    'gt':'GainWavesTrd[dB]',
    'gt_db':'GainWavesTrd[dB]',
    'gp':'GainWavesPwr[dB]',
    'gp_db':'GainWavesPwr[dB]',
    'iout':'I2[mA]',
    'iout_ma':'I2[mA]',
    'iin':'I1[uA]',
    'vout':'V2[V]',
    'vin':'V1[V]',
    'eff':'PAEffWaves[%]',
    'eff_%':'PAEffWaves[%]',
    'gamma_src1':'|GSWaves@F0|',
    'gamma_src2':'|GSWaves@F1|',
    'gamma_src3':'|GSWaves@F2|',
    'gamma_ld1':'|GLWaves@F0|',
    'gamma_ld2':'|GLWaves@F1|',
    'gamma_ld3':'|GLWaves@F2|',
    #'refl':'refl_coef',
    #'refldb':'refl_db',
    #'c':'c_dbm',
    #'ip3':'ip3_dbm',
    #'ip5':'ip5_dbm',
    #'i3':'i3_dbm',
    #'i5':'i5_dbm',
    #'i7':'i7_dbm',
}

_focus_column_reverse_translation_map = {
    # maps a lowercase column name specified by the user on the
    # command line to the case-corrected Focus column name
    'PinWaves[dBm]':'pin_avail_dbm',
    'PinDelWaves[dBm]':'pin_deliv_dbm',
    'PoutWaves[dBm]':'pout_dbm',
    'GainWavesTrd[dB]':'gt_db',
    'GainWavesPwr[dB]':'gp_db',
    'I2[mA]':'iout_ma',
    'I1[uA]':'iin',
    'V2[V]':'vout',
    'V1[V]':'vin',
    'PAEffWaves[%]':'eff_%',
    #'refl':'refl_coef',
    #'refldb':'refl_db',
    #'c':'c_dbm',
    #'ip3':'ip3_dbm',
    #'ip5':'ip5_dbm',
    #'i3':'i3_dbm',
    #'i5':'i5_dbm',
    #'i7':'i7_dbm',
}       

#_const_column_names = frozenset(["vq_in_v", "vq_out_v", "iq_in_ma", "iq_out_ma", "freq"])
_gamma_re_match = re.compile(r'\|G(S|L)Waves@F(\d+)?\|')
_phi_re_match = re.compile(r'Phi(S|L)Waves@F(\d+)?\[deg\]')
_focus_LPwave_date_format_24h = '%A, %B %d, %Y   Time: %H:%M:%S'
_focus_LPwave_date_format_12h = '%A, %B %d, %Y   Time: %H:%M:%S %p'
_focus_Satwave_date_format_24h = '%A, %B %d, %Y %H:%M:%S'
_focus_Satwave_date_format_12h = '%A, %B %d, %Y %H:%M:%S %p'

class ParserError(Exception):
    def __init__(self,msg,filename=None,lineno=None):
        """Parameters:
           msg - the error message string
           filename - the name of the file in which the error occurred.
           lineno - the line number of which the error occurred.
        """
        super(ParserError,self).__init__(msg)
        self.filename = filename
        self.lineno = lineno

            
def focus_lpwave_parser( filename ):
    "Parser for Focus load pull data files"
    fp = _filewrapper(filename)
    
    line = fp.readline()
    if line.startswith("! Power Sweep Load Pull"):
        return FocusLpcwaveFile(fp, "loadpull")
    elif line.startswith("! Power Sweep Source Pull"):
        return FocusLpcwaveFile(fp, "sourcepull")
    elif line.startswith("! File"):
        return FocusSatwaveFile(fp)
    else:
        raise ParserError("unknown or unsupported file type",filename,1)
        
        
class _filewrapper(object):
    "wrapper for a file that keeps track of line number readline() calls"
    
    def __init__(self, filename, initial_lineno=0):
        "initializer"
        self._lineno = initial_lineno
        if hasattr(filename,'readline') and hasattr(filename.readline,'__call__'):
            self._f = filename
            self._filename = '<object>'
            self._ac = False
        else:
            self._f = open(filename, "r")
            self._filename = filename
            self._ac = True
        
    def readline(self):
        "read a line from the file"
        if not self._f:
            raise ValueError("file is closed")
        line = self._f.readline()
        if line != '':
            self._lineno += 1
        return line
    
    def close(self):
        "close the file"
        if self._f and self._ac:
            self._f.close()
        self._f = None    
    
    @property
    def line_number(self):
        "current line number in the file"
        return self._lineno
    
    @property
    def filename(self):
        "name of the file"
        return self._filename
        
    def __del__(self):
        "deletion method"
        self.close()
            
            
class FocusDataBlock(object):
    "data block for a Focus data file"
    EQUALITY_TOLERANCE = 1.0e-6
    
    def __init__(self, columns, num_src_harmonics, num_ld_harmonics):
        "initialize and create the column set"
        col_order = []
        const_cols = []
        swp_data = {}
        for c in columns:
            if c == 'valid':
                continue
            elif _gamma_re_match.match(c) or _phi_re_match.match(c):
                continue

            swp_data[c] = []
            col_order.append(c)
    
        self._swp_data = swp_data
        self._gammas = [None]
        self._gammal = [None]
        self._col_order = col_order
    
    def add_data(self, block):
        "add a new 'line' of data to the block"
        need_cols = self._swp_data.keys()
        for k in block:
            if k == 'valid':
                continue
            v = block[k]
            gamma_m = _gamma_re_match.match(k)
            phi_m = _phi_re_match.match(k)
            if gamma_m or phi_m:
                pass
                #del need_cols[need_cols.index(k)]
                #if None in self._gammas or None in self._gammal:
                #    # only compute gammas the first time
                #    which, harm = m.group(1), int(m.group(2))
                #    if which == 'S':
                #        self._gammas[harm-1] = v
                #    else:
                #        self._gammal[harm-1] = v
            else:
                if k in self._swp_data:
                    self._swp_data[k].append(v)
                    del need_cols[need_cols.index(k)]
                #else:
                #    if k not in self._const_data:
                #        self._const_data[k] = v
        
        if need_cols:
            raise ValueError("missing data for columns: "+(', '.join(need_cols)))
    
    def extract(self, value, parameter='pin_dbm', operator='eq', interpolate=True, compression_wrt_peak=False, pin_adjust=None):
        """extract 1 or more values from the dataset
        
        returns a dictionary in the case of single selection, or a list in the case
        of multiple selection, or None for extraction conditions that cannot be met
        
        Parameters:
        -------------------------------
        
        value         float or list of floats, the value or values at which to extract the data
                        the units of this parameter are dependent on which `parameter` is used
        
        Keywords:
        -------------------------------
        
        parameter     string, the name of the parameter that is used to extract the data, this can
                        be almost any Maury data column name as well as the 'virtual' columns:
                          comp_gt  - compression level in dB using Gt as the gain metric
                          comp_gp  - compression level in dB using Cp as the gain metric 
        
        operator      string, the condition to extract values at, one of:
                          eq      - equal, extract at the specified value, will interpolate (if possible and enabled)
                          gt      - greater than, extract all values greater than the specified value
                          ge      - greater than or equal, extract all values greater or equal to than the specified value
                          lt      - less than, extract all values less than the specified value
                          le      - less than or equal, extract all values less than or equal to the specified value
                          ne      - not equal, extract all values not equal to the specified value
                        *NOTE*: only 'eq' will interpolate and only 'eq' will accept a list of values
        
        interpolate   bool, enable interpolation (default = True, only-supported when condition='eq')
        
        compression_wrt_peak
                      bool, compute compression with respect to the peak gain (default = False)
        
        pin_adjust    float, adjust the input power by an amount after extraction of the specified condition, this is
                        mostly useful to extract data at an input power backoff from some compression level 
                        *NOTE*: this ONLY works when using the 'eq' operator
        """
        if not self._swp_data[_focus_column_translation_map['pin_avail_dbm']]:
            raise ValueError("dataset is empty")
        
        if operator not in ('eq','lt','le','gt','ge','ne'):
            raise ValueError("invalid `operator`, must be one of 'eq', 'lt', 'le', 'gt', or 'ge'")
        
        if isinstance(value,list):
            try:
                value = map(float,value)
            except Exception:
                raise ValueError("`value` must be a float or list of floats")
            
            if operator != 'eq':
                raise ValueError("a list of floats is only supported for `value` when `operator` = 'eq'")                
        else:
            if value in ('min','max'):
                if operator != 'eq':
                    raise ValueError("`value` can only be 'min' or 'max' when `operator` = 'eq'")                                
            else:
                try:
                    value = float(value)
                except Exception:
                    raise ValueError("`value` must be a float or list of floats")
        
        if pin_adjust is not None:
            if operator != 'eq':
                raise ValueError("the `pin_adjust` parameter is only allowed when `operator` = 'eq'")                
                
            try:
                pin_adjust = float(pin_adjust)
                if abs(pin_adjust) < 0.0001:
                    pin_adjust = None
            except Exception:
                raise ValueError("invalid value for pin_adjust, must be a float")
        
        if parameter in ('comp_gt','comp_gp'):
            try:
                if parameter == 'comp_gp':
                    gaincol = self._swp_data[_focus_column_translation_map['gp_db']]                
                else:
                    gaincol = self._swp_data[_focus_column_translation_map['gt_db']]
            except Exception:
                raise ValueError("the necessary gain column for computing `%s` is not available in the dataset"%parameter)
            indep = _compute_compression(gaincol,compression_wrt_peak)
        else:
            try:
                indep = self._swp_data[_focus_column_translation_map[parameter]]
            except Exception:
                raise ValueError("the specified `parameter` is not a valid column name or not available in the dataset")
                
        if operator == 'eq':
            if isinstance(value,list):
                return [self._extract_eq(v,indep,interpolate,pin_adjust) for v in value]
            else:
                return self._extract_eq(value,indep,interpolate,pin_adjust)
        else:
            return self._extract_other(value,indep,operator)        
        
    def _extract_eq(self, value, indep, interpolate, pin_adjust=None):
        "internal function for extracting at a value equal to the one specified"
        if value in ('min','max'):
            # handle the min or max case
            if value == 'min':
                i = indep.index(min(indep))
            else:
                i = indep.index(max(indep))
            
            if pin_adjust:
                new_pin = self._swp_data[_focus_column_translation_map['pin_avail_dbm']][i] + pin_adjust
                return self._extract_eq(new_pin,self._swp_data[_focus_column_translation_map['pin_avail_dbm']],interpolate)                    
            else:
                return self._build_data(i)
        
        if interpolate:
            # find where the interpolation puts us, the returned value is
            # either an integer for an exact match or a float
            i = _interp_index(value,indep,self.EQUALITY_TOLERANCE)
            if i is None:
                return None
            elif isinstance(i,int):
                # exact match case
                if pin_adjust:
                    new_pin = self._swp_data[_focus_column_translation_map['pin_avail_dbm']][i] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data[_focus_column_translation_map['pin_avail_dbm']],interpolate)                    
                else:
                    return self._build_data(i)
            else:
                # create an interpolated data set
                ii = int(i)
                delta = i-ii
                
                # start with the integer-index data set 
                d = self._build_data(ii)
                
                # interpolate the sweep parameter values
                for k in self._swp_data.keys():
                    if k in ['gamma_src', 'gamma_ld']:
                        continue
                    lwr = self._swp_data[k][ii]
                    upr = self._swp_data[k][ii+1]
                    d[k] = lwr + (upr-lwr)*delta
                
                if pin_adjust:
                    new_pin = d[_focus_column_translation_map['pin_avail_dbm']] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data[_focus_column_translation_map['pin_avail_dbm']],interpolate)
                else:    
                    return d
        else:
            for i,a in enumerate(indep):
                if abs(value-a) < self.EQUALITY_TOLERANCE:
                    if pin_adjust:
                        new_pin = self._swp_data[_focus_column_translation_map['pin_avail_dbm']][i] + pin_adjust
                        return self._extract_eq(new_pin,self._swp_data[_focus_column_translation_map['pin_avail_dbm']],interpolate)
                    else:
                        return self._build_data(i)
            return None
        
    def _extract_other(self, value, indep, op):
        "internal function for extracting at values other than equal"
        func = getattr(_operator,op)
        ret = []
        for i,a in enumerate(indep):
            if func(a,value):
                ret.append(self._build_data(i))
        return ret
    
    def _build_data(self, idx):
        "build the dataset for the specified index"
        data = self._swp_data.copy()
        ret = { }
        for k in data:
            v = data[k]
            if k in _focus_column_reverse_translation_map.keys() and v:
                ret[_focus_column_reverse_translation_map[k]] = v[idx]
        
        ret['gamma_src'] = self._gammas[:]
        ret['gamma_ld'] = self._gammal[:]
        return ret
    
    @property
    def gamma_src(self):
        "source gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammas[:]
    
    @gamma_src.setter
    def gamma_src(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammas = v[:]
    
    @property
    def gamma_ld(self):
        "load gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammal[:]
        
    @gamma_ld.setter
    def gamma_ld(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammal = v[:]
    
    @property
    def num_harmonics(self):
        "number of measured harmonics (for source/load gamma)"
        return len(self._gammas), len(self._gammal)

    @property
    def num_src_harmonics(self):
        "number of measured harmonics (for source gamma)"
        return len(self._gammas)

    @property
    def num_ld_harmonics(self):
        "number of measured harmonics (for load gamma)"
        return len(self._gammal)
    
    @property
    def column_order(self):
        return self._col_order[:]
    
    @property
    def swept_columns(self):
        keys = [ ]
        for k in _focus_column_translation_map:
            if _focus_column_translation_map[k] in self._swp_data.keys():
                keys.append(k)
        return keys
        
    @property
    def const_columns(self):
        return self._const_data.keys()
    
    def __nonzero__(self):
        "boolean test"
        return bool(self._swp_data)
    
    def __len__(self):
        "length of the data block"
        return len(self._swpdata)

    def __getitem__(self, col):
        "get data by column name, will either return a single data point for constant columns or a list of the sweep"
        if col in _focus_column_translation_map.keys():
            parameter = _focus_column_translation_map[col]
        else:
            parameter = col
        gamma_m = _gamma_re_match.match(parameter)
        if gamma_m:
            # got a match to a GSWaves or GLWaves parameter
            which,harm = gamma_m.group(1,2)
            if harm:
                n = int(harm)
                try:
                    if which == 'S':
                        return self._gammas[n]                
                    else:
                        return self._gammal[n]                
                except Exception:
                    raise KeyError(parameter+' is not available in the dataset')
            else:
                if which == 'S':
                    return self._gammas[:]                
                else:
                    return self._gammal[:]
        elif parameter in self._swp_data:
            return self._swp_data[parameter][:]
        else:
            raise KeyError(parameter+' is not available in the dataset')
    
class FocusFileBase(object):
    "base class for Focus data files"
    
    def __init__(self, filename, initial_lineno=0):
        "base class initializer"
        self._data = []
        self._freqlist = []
        self._testdate = datetime.datetime.fromtimestamp(0)
        self._header_map = {}
        
        if isinstance(filename, _filewrapper):
            self._file = filename            
        else:
            self._file = _filewrapper(filename,initial_lineno)
        self._filename = self._file.filename
                
    def _readline(self):
        "read a line from the current file"
        return self._file.readline()
    
    def _parser_cleanup(self):
        "cleanup at the end of parsing"
        if self._file:
            self._file.close()
            self._file = None
    
    def map_header_to_file(self, col):
        "map a column back to the name it has in a Maury data file"
        if col in self._header_map:
            return self._header_map[col]
        else:
            return col
    
    @property
    def _fileinfo(self):
        "return the fileinfo for the file currently being parsed"
        return self._file.filename,self._file.line_number
    
    @property
    def filename(self):
        "the name of the file that was parsed"
        return self._filename 
    
    @property
    def flat_data(self):
        "full data array with no indexes"
        return self._data

    @property
    def test_date(self):
        "test date"
        return self._testdate
       
    @property
    def frequency(self):
        "frequency of the measured data"
        n = len(self._freqlist)
        if n == 1:
            return self._freqlist[0]
        elif n > 1:
            return self._freqlist[:]        
        else:
            return None        
        
    def __iter__(self):
        "iterator to allow iteration"
        return self._data
    
    def __len__(self):
        "number of data blocks in the ATS data file"
        return len(self._data)
    
    def __nonzero__(self):
        return bool(self._data)
    
    def __getitem__(self,key):
        "needs to be implemented in subclasses"
        raise NotImplementedError
            
class FocusLpcwaveFile(FocusFileBase):
    "Focus Source/Load-Pull Power Sweep File"
    
    _type = "loadpull"
    _harm = None

    def __init__(self, filename, type="loadpull", initial_lineno=0):
        "initializer"
        super(FocusLpcwaveFile,self).__init__(filename,initial_lineno)
        self._type = type

        try:
            try:
                # read load-pull header
                harmonic = 0
                gammas_list = [ ]
                gammal_list = [ ]
                var_list = []
                freq_list = []
                header_map = {}

                # hardcoded variable list to conform to maury_ats_parser data structures
                if not self._type in ["loadpull", "sourcepull"]:
                    raise NotImplementedError("Filetype not implemented yet!")
                var_list.append('Pin_avail')

                line = self._readline()

                while line:
                    line = line.strip()
                    # date/time
                    if line.startswith('! Date'):
                        # handle 12-hour time format
                        if line[-2:] == "AM" or line[-2:] == "PM":
                            self._testdate = datetime.datetime(*(time.strptime(line[9:],_focus_LPwave_date_format_12h)[0:6]))
                        # handle 24-hour time format
                        else:
                            self._testdate = datetime.datetime(*(time.strptime(line[9:],_focus_LPwave_date_format_24h)[0:6]))

                    # frequency (only handles single-frequency sweeps)
                    elif line.startswith('! Frequency'):
                        number = float(line.split()[-2:][0])
                            
                        multstring = line.split()[-2:][1]
                        if multstring == 'GHz':
                            mult = 1.0
                        elif multstring == 'MHz':
                            mult = 1.0E-3

                        freq_list.append(number*mult)

                    # number of harmonics
                    elif line.startswith('! Source Frequencies'):
                        src_harm_strings = [x for x in re.finditer(r'F(\d+): ((\d+)(\.\d+)?) (\w+)', line[22:])]
                        for h, f in zip([x.group(1) for x in src_harm_strings], [y.group(2) for y in src_harm_strings]):
                            if float(f) == freq_list[0] and self._type == "sourcepull":
                                var_list.append("F%d Source Gamma"%(int(h)+1))
                                harmonic = int(h)
                        self._numgs = len(src_harm_strings)

                    elif line.startswith('! Load Frequencies'):
                        ld_harm_strings = [x for x in re.finditer(r'F(\d+): ((\d+)(\.\d+)?) (\w+)', line[20:])]
                        for h, f in zip([x.group(1) for x in ld_harm_strings], [y.group(2) for y in ld_harm_strings]):
                            if float(f) == freq_list[0] and self._type == "loadpull":
                                var_list.append("F%d Load Gamma"%(int(h)+1))
                                harmonic = int(h)
                        self._numgl = len(ld_harm_strings)

                    # source impedances for loadpull
                    elif line.startswith('! Source Impedances (Polar)'):
                        coeff_strings = [x for x in re.finditer(r'F(\d+): \d+\.\d+, (-)?\d+\.\d+\(deg\)', line[27:])]
                        for string in coeff_strings:
                            harm = float(string.group(0).split(' ')[0][1:-1])
                            mag = float(string.group(0).split(' ')[1][:-1])
                            ang = float(string.group(0).split(' ')[2][:-5])
                            gamma_exact = MAtoComplex(mag, ang)
                            gamma_approx = round(gamma_exact.real, 5) + round(gamma_exact.imag, 5)*1j
                            gammas_list.append(gamma_approx)

                    # load impedances for sourcepull
                    elif line.startswith('! Load Impedances (Polar)'):
                        coeff_strings = [x for x in re.finditer(r'F(\d+): \d+\.\d+, (-)?\d+\.\d+\(deg\)', line[27:])]
                        for string in coeff_strings:
                            harm = float(string.group(0).split(' ')[0][1:-1])
                            mag = float(string.group(0).split(' ')[1][:-1])
                            ang = float(string.group(0).split(' ')[2][:-5])
                            gamma_exact = MAtoComplex(mag, ang)
                            gamma_approx = round(gamma_exact.real, 5) + round(gamma_exact.imag, 5)*1j
                            gammal_list.append(gamma_approx)

                    # end of header -- breaks loop with column headers stored into "line"
                    elif line.startswith('Point'):
                        break

                    # read next line
                    line = self._readline()

                # get column names
                data_headers = line.strip().split()[3:]
                for header in data_headers:
                    header_map[header] = header
                
                # move to next line    
                line = self._readline()

                # process file data
                while line:
                    # when at first line of a data block process it
                    if line.startswith('#'):
                        # get point gamma value
                        point = line
                        mag = float(point.split()[2])
                        ang = float(point.split()[3])*pi/180.0
                        
                        # exact value from conversion too long for combobox
                        # so round to 5 decimal places
                        gamma_exact = MAtoComplex(mag, ang) 
                        gamma_approx = round(gamma_exact.real,5) + round(gamma_exact.imag,5)*1j

                        # create block of swept data
                        data, line = self._read_block(data_headers, line)
                        self._data.append(data)

                        # store source/load gamma to block
                        # only stores the harmonic that is swept, other two are "None"
                        if self._type == "loadpull":
                            self._data[-1]._swp_data['gamma_src'] = gammas_list
                            self._data[-1]._gammas = gammas_list
                            templist = [None] * self._numgl
                            templist[harmonic] = gamma_approx
                            self._data[-1]._swp_data['gamma_ld'] = templist
                            self._data[-1]._gammal = templist
                        elif self._type == "sourcepull":
                            self._data[-1]._swp_data['gamma_ld'] = gammal_list
                            self._data[-1]._gammal = gammal_list
                            templist = [None] * self._numgs
                            templist[harmonic] = gamma_approx
                            self._data[-1]._swp_data['gamma_src'] = templist
                            self._data[-1]._gammas = templist

                    # otherwise move to next line
                    else:
                        line = self._readline()

                # set the object variables
                self._vars = var_list
                self._freqlist = freq_list
                self._header_map = header_map
                self._harm = harmonic
            
            except ParserError:
                raise                
            except Exception as e:
                # modify the exception and re-raise
                
                raise
        finally:
            self._parser_cleanup()
    
    def _read_block(self, headers, line):
        """
        Read a block of Focus Power Sweep Source/Load-pull Measurement Data from a .lpcwave file.
        Assumes function called when self._readline() will return the first data-row of the block
        
        line - starting line of block (of form "# <point number> <mag> <ang>\r\n")
        """
        # create the data block
        ret = FocusDataBlock(headers, self._numgs, self._numgl)

        # move to first row of data in block
        line = self._readline()

        # add all lines of data from this block, stop when next block reached
        while line and not line.startswith('#'):

            row = line.split()
            
            i = 0
            data = {}
            # generate data row
            for header in headers:
                # avoid parsing "N/A" as a float, change it to 0.0 instead
                if row[i] == "N/A":
                    data[header] = 0.0
                else:
                    data[header] = float(row[i])
                i += 1
            # add data row to block
            ret.add_data(data)

            # move to next line
            line = self._readline()

        # done reading block, return the data set
        return ret, line
    
    def __getitem(self, key):
        """customized indexing method
        
        
        
        """
        raise NotImplementedError

class FocusSatwaveFile(FocusFileBase):
    "Focus Power Sweep File"

    def __init__(self, filename, initial_lineno=0):
        "initializer"
        super(FocusSatwaveFile,self).__init__(filename,initial_lineno)

        try:
            try:
                # read load-pull header
                harmonic = 0
                gammas_list = [ ]
                gammal_list = [ ]
                var_list = []
                freq_list = []
                header_map = {}

                var_list.append('Pin_avail')

                line = self._readline()

                while line:
                    line = line.strip()
                    # date/time
                    if line.startswith('! Date'):
                        # handle 12-hour time format
                        if line[-2:] == "AM" or line[-2:] == "PM":
                            self._testdate = datetime.datetime(*(time.strptime(line[8:],_focus_Satwave_date_format_12h)[0:6]))
                        # handle 24-hour time format
                        else:
                            self._testdate = datetime.datetime(*(time.strptime(line[8:],_focus_Satwave_date_format_24h)[0:6]))

                    # frequency (only handles single-frequency sweeps)
                    elif line.startswith('! Frequency'):
                        number = float(line.split()[-2:][0])
                            
                        multstring = line.split()[-2:][1]
                        if multstring == 'GHz':
                            mult = 1.0
                        elif multstring == 'MHz':
                            mult = 1.0E-3

                        freq_list.append(number*mult)

                    # number of harmonics
                    elif line.startswith('! Source Frequencies'):
                        src_harm_strings = [x for x in re.finditer(r'F(\d+): ((\d+)(\.\d+)?) (\w+)', line[22:])]
                        for h, f in zip([x.group(1) for x in src_harm_strings], [y.group(2) for y in src_harm_strings]):
                            if float(f) == freq_list[0]:
                                var_list.append("F%d Source Gamma"%(int(h)+1))
                                harmonic = int(h)
                        self._numgs = len(src_harm_strings)

                    elif line.startswith('! Load Frequencies'):
                        ld_harm_strings = [x for x in re.finditer(r'F(\d+): ((\d+)(\.\d+)?) (\w+)', line[20:])]
                        for h, f in zip([x.group(1) for x in ld_harm_strings], [y.group(2) for y in ld_harm_strings]):
                            if float(f) == freq_list[0]:
                                var_list.append("F%d Load Gamma"%(int(h)+1))
                                harmonic = int(h)
                        self._numgl = len(ld_harm_strings)

                    # source impedances for loadpull
                    elif line.startswith('! Source Impedances (Polar)'):
                        coeff_strings = [x for x in re.finditer(r'F(\d+): \d+\.\d+<(-)?\d+\.\d+\(deg\)', line[27:])]
                        for string in coeff_strings:
                            harm = float(re.split("\s|<",string.group(0))[0][1:-1])
                            mag = float(re.split("\s|<",string.group(0))[1])
                            ang = float(re.split("\s|<",string.group(0))[2][:-5])
                            gamma_exact = MAtoComplex(mag, ang)
                            gamma_approx = round(gamma_exact.real, 5) + round(gamma_exact.imag, 5)*1j
                            gammas_list.append(gamma_approx)

                    # load impedances for sourcepull
                    elif line.startswith('! Load Impedances (Polar)'):
                        coeff_strings = [x for x in re.finditer(r'F(\d+): \d+\.\d+<(-)?\d+\.\d+\(deg\)', line[27:])]
                        for string in coeff_strings:
                            harm = float(re.split("\s|<",string.group(0))[0][1:-1])
                            mag = float(re.split("\s|<",string.group(0))[1])
                            ang = float(re.split("\s|<",string.group(0))[2][:-5])
                            gamma_exact = MAtoComplex(mag, ang)
                            gamma_approx = round(gamma_exact.real, 5) + round(gamma_exact.imag, 5)*1j
                            gammal_list.append(gamma_approx)

                    # end of header -- breaks loop with column headers stored into "line"
                    elif line.startswith('! --'):
                        line = self._readline()
                        break

                    # read next line
                    line = self._readline()

                # get column names
                data_headers = line.strip().split()[2:]
                for header in data_headers:
                    header_map[header] = header
                
                # move to first line in sweep
                line = self._readline()
                line = self._readline()

                # create block of swept data
                data, line = self._read_block(data_headers, line)
                self._data.append(data)
                self._data[-1]._gammas = gammas_list
                self._data[-1]._gammal = gammal_list

                # set the object variables
                self._vars = var_list
                self._freqlist = freq_list
                self._header_map = header_map
            
            except ParserError:
                raise                
            except Exception as e:
                # modify the exception and re-raise
                
                raise
        finally:
            self._parser_cleanup()
    
    def _read_block(self, headers, line):
        """
        Read a block of Focus Power Sweep Source/Load-pull Measurement Data from a .lpcwave file.
        Assumes function called when self._readline() will return the first data-row of the block
        
        line - starting line of block
        """
        # create the data block
        ret = FocusDataBlock(headers, self._numgs, self._numgl)

        # add all lines of data from this block, stop when next block reached
        while line:

            row = line.split()
            
            i = 0
            data = {}
            # generate data row
            for header in headers:
                # avoid parsing "N/A" as a float, change it to 0.0 instead
                if row[i] == "N/A":
                    data[header] = 0.0
                else:
                    data[header] = float(row[i])
                i += 1
            # add data row to block
            ret.add_data(data)

            # move to next line
            line = self._readline()

        # done reading block, return the data set
        return ret, line
    
    def __getitem(self, key):
        """customized indexing method
        
        
        
        """
        raise NotImplementedError

def _compute_compression(gaincol, compression_wrt_peak):
    "compute compression of a gain column, returns a list of the same length"
    # find the peak value
    pi = 0
    mx = gaincol[0]
    for j,v in enumerate(gaincol):
        if v > mx:
            pi = j
            mx = v
    
    ret = []
    if compression_wrt_peak:
        for i,g in enumerate(gaincol):
            if i < pi:
                ret.append(0.0)
            else:
                ret.append(mx-g)
    else:
        d = gaincol[0]
        for i,g in enumerate(gaincol):
            ret.append(d-g)
        
    return ret
        
def _interp_index( value, data, tolerance ):
    "compute the interpolation index, a floating point index"
    n = len(data)
    # check to see if the value falls into the range specified by adjacent points in the data array
    # or matches a point in the array exactly
    for i,vp1 in enumerate(data[1:]):
        v = data[i]
        if abs(value-v) <= tolerance:
            return i
        if abs(value-vp1) <= tolerance:
            return i+1
        
        if abs(vp1-v) <= tolerance:
            continue
            
        if (value > v and value < vp1) or (value < v and value > vp1):
            # interpolation 
            return float(i) + (value-v)/(vp1-v)        
    
    # no interpolation possible
    return None
