import datetime
import time
import warnings
import re
import operator as _operator

_maury_column_translation_map = {
    # maps a lowercase column name specified by the user on the
    # command line to the case-corrected Maury column name
    'pin':'pin_avail_dbm',
    'pin_dbm':'pin_avail_dbm',
    'pin_avail':'pin_avail_dbm',
    'pin_deliv':'pin_deliv_dbm',
    'pout':'pout_dbm',
    'gain':'gt_db',
    'gt':'gt_db',
    'gp':'gp_db',
    'iout':'iout_ma',
    'iin':'iin_ma',
    'vout':'vout_v',
    'vin':'vin_v',
    'eff':'eff_%',
    'refl':'refl_coef',
    'refldb':'refl_db',
    'c':'c_dbm',
    'ip3':'ip3_dbm',
    'ip5':'ip5_dbm',
    'i3':'i3_dbm',
    'i5':'i5_dbm',
    'i7':'i7_dbm',
}       
    
_const_column_names = frozenset(["vq_in_v", "vq_out_v", "iq_in_ma", "iq_out_ma", "freq"])
_gamma_re_match = re.compile(r'gamma_(src|ld)(\d+)?')
_maury_date_format = '%a %b %d %H:%M:%S %Y'

class ParserError(Exception):
    def __init__(self,msg,filename=None,lineno=None):
        """Parameters:
           msg - the error message string
           filename - the name of the file in which the error occurred.
           lineno - the line number of which the error occurred.
        """
        super(ParserError,self).__init__(msg)
        self.filename = filename
        self.lineno = lineno

            
def maury_ats_parser( filename ):
    "Parser for Maury ATS load pull data files"
    fp = _filewrapper(filename)
    
    line = fp.readline()
    if line.startswith("! Power sweep plan"):
        return MaurySplFile(fp)
    elif line.startswith("! Swept power data"):
        return MaurySwpFile(fp)
    else:
        raise ParserError("unknown or unsupported file type",filename,1)
        
        
class _filewrapper(object):
    "wrapper for a file that keeps track of line number readline() calls"
    
    def __init__(self, filename, initial_lineno=0):
        "initializer"
        self._lineno = initial_lineno
        if hasattr(filename,'readline') and hasattr(filename.readline,'__call__'):
            self._f = filename
            self._filename = '<object>'
            self._ac = False
        else:
            self._f = open(filename, "r")
            self._filename = filename
            self._ac = True
        
    def readline(self):
        "read a line from the file"
        if not self._f:
            raise ValueError("file is closed")
        line = self._f.readline()
        if line != '':
            self._lineno += 1
        return line
    
    def close(self):
        "close the file"
        if self._f and self._ac:
            self._f.close()
        self._f = None    
    
    @property
    def line_number(self):
        "current line number in the file"
        return self._lineno
    
    @property
    def filename(self):
        "name of the file"
        return self._filename
        
    def __del__(self):
        "deletion method"
        self.close()
            
            
class MauryDataBlock(object):
    "data block for a Maury data file"
    EQUALITY_TOLERANCE = 1.0e-6
    
    def __init__(self, columns):
        "initialize and create the column set"
        col_order = []
        const_cols = []
        swp_data = {}
        for c in columns:
            if c == 'valid':
                continue
            elif c.startswith('gamma_'):
                continue
            
            if c not in _const_column_names:
                swp_data[c] = []
            col_order.append(c)
    
        self._const_data = {}
        self._swp_data = swp_data
        self._gammas = []
        self._gammal = []
        self._col_order = col_order
    
    def add_data(self, block):
        "add a new 'line' of data to the block"
        need_cols = self._swp_data.keys()
        gs, gl = [None]*10, [None]*10
        for k,v in block.iteritems():
            if k == 'valid':
                continue
            
            m = _gamma_re_match.match(k)
            if m:
                if not self._gammas:
                    # only compute gammas the first time 
                    which,harm = m.group(1,2)
                    if harm:
                        n = int(harm)-1
                    else:
                        n = 0
                    
                    if which == 'src':
                        gs[n] = v
                    else:
                        gl[n] = v
            else:
                if k in self._swp_data:
                    self._swp_data[k].append(v)
                    del need_cols[need_cols.index(k)]
                else:
                    if k not in self._const_data:
                        self._const_data[k] = v
        
        if gs[0] and gl[0]:
            for i in range(10):
                if gs[i] and gl[i]:
                    self._gammas.append(gs[i])
                    self._gammal.append(gl[i])
                else:
                    break
        
        if need_cols:
            raise ValueError("missing data for columns: "+(', '.join(need_cols)))
    
    def extract(self, value, parameter='pin_dbm', operator='eq', interpolate=True, compression_wrt_peak=False, pin_adjust=None):
        """extract 1 or more values from the dataset
        
        returns a dictionary in the case of single selection, or a list in the case
        of multiple selection, or None for extraction conditions that cannot be met
        
        Parameters:
        -------------------------------
        
        value         float or list of floats, the value or values at which to extract the data
                        the units of this parameter are dependent on which `parameter` is used
        
        Keywords:
        -------------------------------
        
        parameter     string, the name of the parameter that is used to extract the data, this can
                        be almost any Maury data column name as well as the 'virtual' columns:
                          comp_gt  - compression level in dB using Gt as the gain metric
                          comp_gp  - compression level in dB using Cp as the gain metric 
        
        operator      string, the condition to extract values at, one of:
                          eq      - equal, extract at the specified value, will interpolate (if possible and enabled)
                          gt      - greater than, extract all values greater than the specified value
                          ge      - greater than or equal, extract all values greater or equal to than the specified value
                          lt      - less than, extract all values less than the specified value
                          le      - less than or equal, extract all values less than or equal to the specified value
                          ne      - not equal, extract all values not equal to the specified value
                        *NOTE*: only 'eq' will interpolate and only 'eq' will accept a list of values
        
        interpolate   bool, enable interpolation (default = True, only-supported when condition='eq')
        
        compression_wrt_peak
                      bool, compute compression with respect to the peak gain (default = False)
        
        pin_adjust    float, adjust the input power by an amount after extraction of the specified condition, this is
                        mostly useful to extract data at an input power backoff from some compression level 
                        *NOTE*: this ONLY works when using the 'eq' operator
        """
        if not self._swp_data['pin_avail_dbm']:
            raise ValueError("dataset is empty")
        
        if operator not in ('eq','lt','le','gt','ge','ne'):
            raise ValueError("invalid `operator`, must be one of 'eq', 'lt', 'le', 'gt', or 'ge'")
        
        if isinstance(value,list):
            try:
                value = map(float,value)
            except Exception:
                raise ValueError("`value` must be a float or list of floats")
            
            if operator != 'eq':
                raise ValueError("a list of floats is only supported for `value` when `operator` = 'eq'")                
        else:
            if value in ('min','max'):
                if operator != 'eq':
                    raise ValueError("`value` can only be 'min' or 'max' when `operator` = 'eq'")                                
            else:
                try:
                    value = float(value)
                except Exception:
                    raise ValueError("`value` must be a float or list of floats")
        
        if pin_adjust is not None:
            if operator != 'eq':
                raise ValueError("the `pin_adjust` parameter is only allowed when `operator` = 'eq'")                
                
            try:
                pin_adjust = float(pin_adjust)
                if abs(pin_adjust) < 0.0001:
                    pin_adjust = None
            except Exception:
                raise ValueError("invalid value for pin_adjust, must be a float")
        
        if parameter in ('comp_gt','comp_gp'):
            try:
                if parameter == 'comp_gp':
                    gaincol = self._swp_data['gp_db']                
                else:
                    gaincol = self._swp_data['gt_db']
            except Exception:
                raise ValueError("the necessary gain column for computing `%s` is not available in the dataset"%parameter)
            indep = _compute_compression(gaincol,compression_wrt_peak)
        else:
            try:
                indep = self._swp_data[_translate_maury_column(parameter)]
            except Exception:
                raise ValueError("the specified `parameter` is not a valid column name or not available in the dataset")
                
        if operator == 'eq':
            if isinstance(value,list):
                return [self._extract_eq(v,indep,interpolate,pin_adjust) for v in value]
            else:
                return self._extract_eq(value,indep,interpolate,pin_adjust)
        else:
            return self._extract_other(value,indep,operator)        
        
    def _extract_eq(self, value, indep, interpolate, pin_adjust=None):
        "internal function for extracting at a value equal to the one specified"
        if value in ('min','max'):
            # handle the min or max case
            if value == 'min':
                i = indep.index(min(indep))
            else:
                i = indep.index(max(indep))
            
            if pin_adjust:
                new_pin = self._swp_data['pin_avail_dbm'][i] + pin_adjust
                return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)                    
            else:
                return self._build_data(i)
        
        if interpolate:
            # find where the interpolation puts us, the returned value is
            # either an integer for an exact match or a float
            i = _interp_index(value,indep,self.EQUALITY_TOLERANCE)
            if i is None:
                return None
            elif isinstance(i,int):
                # exact match case
                if pin_adjust:
                    new_pin = self._swp_data['pin_avail_dbm'][i] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)                    
                else:
                    return self._build_data(i)
            else:
                # create an interpolated data set
                ii = int(i)
                delta = i-ii
                
                # start with the integer-index data set 
                d = self._build_data(ii)
                
                # interpolate the sweep parameter values
                for k in self._swp_data.keys():
                    lwr = self._swp_data[k][ii]
                    upr = self._swp_data[k][ii+1]
                    d[k] = lwr + (upr-lwr)*delta
                
                if pin_adjust:
                    new_pin = d['pin_avail_dbm'] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)
                else:    
                    return d
        else:
            for i,a in enumerate(indep):
                if abs(value-a) < self.EQUALITY_TOLERANCE:
                    if pin_adjust:
                        new_pin = self._swp_data['pin_avail_dbm'][i] + pin_adjust
                        return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)
                    else:
                        return self._build_data(i)
            return None
        
    def _extract_other(self, value, indep, op):
        "internal function for extracting at values other than equal"
        func = getattr(_operator,op)
        ret = []
        for i,a in enumerate(indep):
            if func(a,value):
                ret.append(self._build_data(i))
        return ret
    
    def _build_data(self, idx):
        "build the dataset for the specified index"
        ret = self._const_data.copy()
        ret['gamma_src'] = self._gammas[:]
        ret['gamma_ld'] = self._gammal[:]
        for k,v in self._swp_data.iteritems():
            ret[k] = v[idx]
        return ret
    
    @property
    def gamma_src(self):
        "source gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammas[:]
    
    @gamma_src.setter
    def gamma_src(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammas = v[:]
    
    @property
    def gamma_ld(self):
        "load gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammal[:]
        
    @gamma_ld.setter
    def gamma_ld(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammal = v[:]
    
    @property
    def num_harmonics(self):
        "number of measured harmonics (for source/load gamma)"
        return len(self._gammas)
    
    @property
    def column_order(self):
        return self._col_order[:]
    
    @property
    def swept_columns(self):
        return self._swp_data.keys()
        
    @property
    def const_columns(self):
        return self._const_data.keys()
    
    def __nonzero__(self):
        "boolean test"
        return bool(self._swp_data)
    
    def __len__(self):
        "length of the data block"
        return len(self._swpdata)

    def __getitem__(self, col):
        "get data by column name, will either return a single data point for constant columns or a list of the sweep"
        m = _gamma_re_match.match(col)
        if m:
            # got a match to a gamma_src or gamma_ld column
            which,harm = m.group(1,2)
            if harm:
                n = int(harm)
                try:
                    if which == 'src':
                        return self._gammas[n]                
                    else:
                        return self._gammal[n]                
                except Exception:
                    raise KeyError(col+' is not available in the dataset')
            else:
                if which == 'src':
                    return self._gammas[:]                
                else:
                    return self._gammal[:]
        elif m in self._const_data:
            return self._const_data[col]
        elif m in self._swp_data:
            return self._swp_data[col][:]
        else:
            raise KeyError(col+' is not available in the dataset')
    

    
    
class MauryFileBase(object):
    "base class for Maury data files"
    
    def __init__(self, filename, initial_lineno=0):
        "base class initializer"
        self._data = []
        self._freqlist = []
        self._testdate = datetime.datetime.fromtimestamp(0)
        self._header_map = {}
        
        if isinstance(filename, _filewrapper):
            self._file = filename            
        else:
            self._file = _filewrapper(filename,initial_lineno)
        self._filename = self._file.filename
                
    def _readline(self):
        "read a line from the current file"
        return self._file.readline()
    
    def _parser_cleanup(self):
        "cleanup at the end of parsing"
        if self._file:
            self._file.close()
            self._file = None
    
    def map_header_to_file(self, col):
        "map a column back to the name it has in a Maury data file"
        if col in self._header_map:
            return self._header_map[col]
        else:
            return col
    
    @property
    def _fileinfo(self):
        "return the fileinfo for the file currently being parsed"
        return self._file.filename,self._file.line_number
    
    @property
    def filename(self):
        "the name of the file that was parsed"
        return self._filename 
    
    @property
    def flat_data(self):
        "full data array with no indexes"
        return self._data

    @property
    def test_date(self):
        "test date"
        return self._testdate
       
    @property
    def frequency(self):
        "frequency of the measured data"
        n = len(self._freqlist)
        if n == 1:
            return self._freqlist[0]
        elif n > 1:
            return self._freqlist[:]        
        else:
            return None        
        
    def __iter__(self):
        "iterator to allow iteration"
        return self._data
    
    def __len__(self):
        "number of data blocks in the ATS data file"
        return len(self._data)
    
    def __nonzero__(self):
        return bool(self._data)
    
    def __getitem__(self,key):
        "needs to be implemented in subclasses"
        raise NotImplementedError
        
        
class MaurySplFile(MauryFileBase):
    "Maury Sweep Plan File parser"
    
    def __init__(self, filename, initial_lineno=0):
        "initializer"
        super(MaurySplFile,self).__init__(filename,initial_lineno)
        try:
            try:
                # read header
                numf = 0
                numv = 0
                var_list = []
                freq_list = []
                ind_list = []
                header_map = {}
                line = self._readline()
                while line:
                    if line.startswith('Number of Freq'):
                        numf = int(line.split()[-1])
                    elif line.startswith('Number of Var'):
                        numv = int(line.split()[-1])
                    elif line.startswith('VAR='):
                        m = re.match(r'VAR=<([^<>]*)>,\s*Units=<([^<>]*)>',line,re.I)
                        if m:
                            v, u = m.group(1,2)
                            var_list.append(v)
                    elif line.startswith('! Date'):
                        self._testdate = datetime.datetime(*(time.strptime(line[12:].strip(),_maury_date_format)[0:6]))
                    elif line.startswith("! Freq"):
                        if not numf:
                            raise ParserError("'Number of Frequencies' is invalid or not found",*self._fileinfo)
                        try:
                            for i in range(numf):
                                d = self._readline().split()
                                freq_list.append( float(d[0]) )
                                ind = [int(d[j+1]) for j in range(numv)]
                                ind_list.append(ind)
                        except Exception as e:
                            raise ParserError("error reading variable count information -> "+str(e),*self._fileinfo)                            
                        break
                    line = self._readline()
                    
                # check the variable data
                
                if numv != len(var_list):
                    raise ParserError("mismatch between 'Number of Variables' and VAR headers",*self._fileinfo)
                elif var_list[-1] != 'Pin_avail':
                    raise ParserError("the innermost VAR must be 'Pin_avail' (otherwise data blocks make no sense)",*self._fileinfo)
                elif numv < 2:
                    raise ParserError("can't read a file where 'Number of Variables' is less than 2",*self._fileinfo)
                    
                if numf != len(freq_list):
                    raise ParserError(self._fileinfo+": mismatch between 'Number of Frequencies' and per-frequency variable counts")
                
                # start reading data
                data = []
                for findex in range(numf):
                    # wait for the frequency block header
                    while not line.startswith('Freq'):
                        line = self._readline()
                        if line == '':
                            raise ParserError("hit EOF before hitting the 'Freq = ' block header",*self._fileinfo)
                    current_freq = float(line.split()[-2])
                    
                    # sanity check of frequency
                    if abs(current_freq - freq_list[findex]) > 0.0001:
                        raise ParserError("frequency mismatch -> %g != %g"%(current_freq,freq_list[findex]),*self._fileinfo)
                    
                    # read the other block headers
                    harm_line = self._readline()
                    data_headers = self._readline().split()
                    data_headers_lwr = [x.lower() for x in data_headers]
                    
                    # add header translations to the dictionary
                    for i,ho in enumerate(data_headers):
                        hl = data_headers_lwr[i]
                        if hl != ho and hl not in header_map:
                            header_map[hl] = ho
                    
                    # read all data blocks for this frequency
                    total_blocks = 1
                    ind = ind_list[findex]
                    for i in range(numv-1):
                        total_blocks *= ind[i]
                    for i in range(total_blocks):
                        self._data.append(self._read_block(data_headers_lwr,ind[-1]))
                                
                # set the object variables
                self._vars = var_list
                self._indexing = ind_list
                self._freqlist = freq_list
                self._header_map = header_map
            
            except ParserError:
                raise                
            except Exception as e:
                # modify the exception and re-raise
                
                raise
        finally:
            self._parser_cleanup()
    
    def _read_block(self, headers, blocklen):
        """Read a block of Maury ATS sweep plan (version 4) data.
        
        headers - list of headers from the main block header
        blocklen - the length of the data block.
        """
        # create the data block
        ret = MauryDataBlock(headers)
        
        # read the data lines
        for i in range(blocklen):
            line = self._readline()
            if line == '':
                raise ParserError("unexpected EOF",*self._fileinfo)
            d = line.split()
            dl = len(d)
            if not dl:
                raise ParserError("unexpected blank line",*self._fileinfo)
                
            if d[0] == '0':
                # valid flag is 0
                continue
            
            # parse data line
            j = 0
            data = {}
            for h in headers:
                m = _gamma_re_match.match(h)
                if m:
                    data[h] = complex(float(d[j]),float(d[j+1]))
                    j += 2
                else:
                    data[h] = float(d[j])
                    j += 1
            
            # add data to the block
            ret.add_data(data)

        # done reading block, return the data set
        return ret
    
    def __getitem(self, key):
        """customized indexing method
        
        
        
        """
        raise NotImplementedError
        
        
class MaurySwpFile(MauryFileBase):
    "Maury Swept Power File parser"
    
    def __init__(self, filename, initial_lineno=0):
        "initializer"
        super(MaurySwpFile,self).__init__(filename,initial_lineno)
        try:
            try:
                # read header
                nswp = 0
                line = self._readline()
                while line:
                    if line.startswith("Frequency"):
                        self._freqlist = [float(line.split()[-2])]
                    elif line.startswith('! Date'):
                        self._testdate = datetime.datetime(*(time.strptime(line[12:].strip(),_maury_date_format)[0:6]))
                    elif line.startswith('Number of sweeps'):
                        nswp = int(line.split()[-1])
                        break
                    line = self._readline()
                
                # start reading the data sets
                if not nswp:
                    raise ParserError("missing 'Number of sweeps' header",*self._fileinfo)
                
                for swpidx in range(nswp):
                    # wait for the Gamma_dut line
                    while not line.startswith('Gamma_dut'):
                        line = self._readline()
                        if line == '':
                            raise ParserError("hit EOF before hitting the 'Gamma_dut' block header",*self._fileinfo)
                    
                    # parse the Gamma_dut line
                    gs, gl = [], []
                    gline = line.split()[1:]
                    for suf in ("","_2nd","_3rd","_4th","_5th","_6th","_7th","_8th","_9th","_10th"):
                        try:
                            si = gline.index('Source'+suf)
                            li = gline.index('Load'+suf)
                            gs.append( complex(float(gline[si+2].lstrip('(')), float(gline[si+3].rstrip(')'))) )
                            gl.append( complex(float(gline[li+2].lstrip('(')), float(gline[li+3].rstrip(')'))) )
                        except Exception:
                            break
                    
                    if not gs:
                        raise ParserError("could not parse 'Gamma_dut' line",*self._fileinfo)
                    
                    # read the number of power points measured
                    numpwr = int(self._readline().split()[-1])
                    
                    # read the block headers
                    headers = self._readline()[1:].split()
                    headers_lwr = [x.lower() for x in headers]
                    numheaders = len(headers)
                    
                    # add header translations to the dictionary
                    for i,ho in enumerate(headers):
                        hl = headers_lwr[i]
                        if hl != ho and hl not in self._header_map:
                            self._header_map[hl] = ho
                    
                    # create the data block
                    block = MauryDataBlock(headers_lwr)
                    block.gamma_src = gs
                    block.gamma_ld = gl
                    
                    # read all the data lines
                    for i in range(numpwr):
                        d = map(float,self._readline().split())
                        if len(d) != numheaders:
                            raise ParserError("number of data columns does not match number of headers",*self._fileinfo)                            
                        dd = dict(zip(headers_lwr,d))
                        block.add_data(dd)
                    
                    # add the block to the data set
                    self._data.append(block)
            
            except ParserError:
                raise                
            except Exception as e:
                # modify the exception and re-raise
                
                raise
        finally:
            self._parser_cleanup()
        
    def __getitem(self, key):
        """customized indexing method
        
        
        
        """
        raise NotImplementedError
        
        
def _compute_compression(gaincol, compression_wrt_peak):
    "compute compression of a gain column, returns a list of the same length"
    # find the peak value
    pi = 0
    mx = gaincol[0]
    for j,v in enumerate(gaincol):
        if v > mx:
            pi = j
            mx = v
    
    ret = []
    if compression_wrt_peak:
        for i,g in enumerate(gaincol):
            if i < pi:
                ret.append(0.0)
            else:
                ret.append(mx-g)
    else:
        d = gaincol[0]
        for i,g in enumerate(gaincol):
            ret.append(d-g)
        
    return ret
        
def _interp_index( value, data, tolerance ):
    "compute the interpolation index, a floating point index"
    n = len(data)
    # check to see if the value falls into the range specified by adjacent points in the data array
    # or matches a point in the array exactly
    for i,vp1 in enumerate(data[1:]):
        v = data[i]
        if abs(value-v) <= tolerance:
            return i
        if abs(value-vp1) <= tolerance:
            return i+1
        
        if abs(vp1-v) <= tolerance:
            continue
            
        if (value > v and value < vp1) or (value < v and value > vp1):
            # interpolation 
            return float(i) + (value-v)/(vp1-v)        
    
    # no interpolation possible
    return None
        
def _translate_maury_column( col ):
    "translate column names from shorthand versions"
    col = col.lower()
    if col in _maury_column_translation_map:
        return _maury_column_translation_map[col]
    else:
        return col
        
        
        