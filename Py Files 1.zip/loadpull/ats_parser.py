from __future__ import division, print_function, unicode_literals, absolute_import

import cmath
import datetime
import math
import time, warnings, re
import operator as _operator
import os

_maury_column_translation_map = {
    # maps a lowercase column name specified by the user on the
    # command line to the lowercase Maury column name
    'pin':'pin_avail_dbm',
    'pin_dbm':'pin_avail_dbm',
    'pin_avail':'pin_avail_dbm',
    'pin_deliv':'pin_deliv_dbm',
    'pout':'pout_dbm',
    'gain':'gt_db',
    'gt':'gt_db',
    'gp':'gp_db',
    'iout':'iout_ma',
    'iin':'iin_ma',
    'vout':'vout_v',
    'vin':'vin_v',
    'eff':'eff_%',
    'refl':'refl_coef',
    'refldb':'refl_db',
    'c':'c_dbm',
    'ip3':'ip3_dbm',
    'ip5':'ip5_dbm',
    'i3':'i3_dbm',
    'i5':'i5_dbm',
    'i7':'i7_dbm',
}

_maury_column_to_display_map = {
    'pin_avail_dbm' : 'Available Input Power [dBm]',
    'pin_avail_w'   : 'Available Input Power [W]',
    'pin_deliv_dbm' : 'Delivered Input Power [dBm]',
    'pin_deliv_w'   : 'Delivered Input Power [W]',
    'pout_dbm'      : 'Output Power [dBm]',
    'pout_w'        : 'Output Power [W]',
    'gt_db'         : 'Transducer Gain [dB]',
    'gp_db'         : 'Power Gain [dB]',
    'iout_ma'       : 'Drain Current [mA]',
    'iin_ma'        : 'Gate Current [mA]',
    'vout_v'        : 'Drain Voltage [V]',
    'vin_v'         : 'Gate Voltage [V]',
    'pae_%'         : 'Power Added Efficiency [%]',
    'eff_%'         : 'Efficiency [%]',
    'deff_%'        : 'Drain Efficiency [%]',
    'refl_coef'     : 'Reflection Coefficient',
    'gt(s)'         : 'Small-signal Transducer Gain [dB]',
    'delta_gt'      : 'Transducer Gain Compression [dB]',
    'pdc_w'         : 'DC Power Consumption [W]',

}

_display_to_maury_column_map = {
    'Available Input Power [dBm]'       : 'pin_avail_dbm',
    'Available Input Power [W]'         : 'pin_avail_w',
    'Delivered Input Power [dBm]'       : 'pin_deliv_dbm',
    'Delivered Input Power [W]'         : 'pin_deliv_w',
    'Output Power [dBm]'                : 'pout_dbm',
    'Output Power [W]'                  : 'pout_w',
    'Transducer Gain [dB]'              : 'gt_db',
    'Power Gain [dB]'                   : 'gp_db',
    'Drain Current [mA]'                : 'iout_ma',
    'Gate Current [mA]'                 : 'iin_ma',
    'Drain Voltage [V]'                 : 'vout_v',
    'Gate Voltage [V]'                  : 'vin_v',
    'Power Added Efficiency [%]'        : 'pae_%',
    'Efficiency [%]'                    : 'eff_%',
    'Drain Efficiency [%]'              : 'deff_%',
    'Reflection Coefficient'            : 'refl_coef',
    'Small-signal Transducer Gain [dB]' : 'gt(s)',
    'Transducer Gain Compression [dB]'  : 'delta_gt',
    'DC Power Consumption [W]'          : 'pdc_w',
}

_const_column_names = frozenset(["vq_in_v", "vq_out_v", "iq_in_ma", "iq_out_ma", "freq"])
_gamma_re_match = re.compile(r'gamma_(src|ld)(\d+)?')
_maury_date_format = '%a %b %d %H:%M:%S %Y'
_ivcad_date_format = '%Y/%m/%d %H:%M:%S'

class ParserError(Exception):
    def __init__(self,msg,filename=None,lineno=None):
        """Parameters:
           msg - the error message string
           filename - the name of the file in which the error occurred.
           lineno - the line number of which the error occurred.
        """
        super(ParserError,self).__init__(msg)
        self.filename = filename
        self.lineno = lineno


def maury_ats_parser(filename):
    "Parser for Maury ATS load pull data files"
    fp = _filewrapper(filename)

    if os.path.splitext(filename)[1] == '.cst':
        return IVCADFile(fp)
    else:
        line = fp.readline()
        if line.startswith("! Power sweep plan"):
            return MaurySplFile(fp)
        elif line.startswith("! Swept power data"):
            return MaurySwpFile(fp)
        else:
            raise ParserError("unknown or unsupported file type",filename,1)


class _filewrapper(object):
    "wrapper for a file that keeps track of line number readline() calls"

    def __init__(self, filename, initial_lineno=0):
        "initializer"
        self._lineno = initial_lineno
        if hasattr(filename,'readline') and hasattr(filename.readline,'__call__'):
            self._f = filename
            if hasattr(filename,'name'):
                self._filename = filename.name
            else:
                self._filename = '<object>'
            self._ac = False
        else:
            self._f = open(filename, "r")
            self._filename = filename
            self._ac = True

    def readline(self):
        "read a line from the file"
        if not self._f:
            raise ValueError("file is closed")
        line = self._f.readline()
        if line != '':
            self._lineno += 1
        return line

    def close(self):
        "close the file"
        if self._f and self._ac:
            self._f.close()
        self._f = None

    @property
    def line_number(self):
        "current line number in the file"
        return self._lineno

    @property
    def filename(self):
        "name of the file"
        return self._filename

    def __del__(self):
        "deletion method"
        self.close()

class MauryLpDataBlock(object):

    "data block for maury lp data file"
    def __init__(self, columns, num_src_harmonics, num_ld_harmonics):

        col_order = []
        const_cols = []
        swp_data = {}
        self._const_data = {}
        for c in columns:
            swp_data[c] = []
        col_order.append(c)

        self._swp_data = swp_data
        self._gammas = [None]*num_src_harmonics
        self._gammal = [None]*num_ld_harmonics

    def add_data(self, block):

        need_cols = self._swp_data.keys()
        for k,v in block.iteritems():
            if k in self._swp_data:
                self._swp_data[k].append(v)
                del need_cols[need_cols.index(k)]
            else:
                if k not in self._const_data:
                    self._const_data[k] = v

    @property
    def gamma_src(self):
        "source gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammas[:]

    @gamma_src.setter
    def gamma_src(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammas = v[:]

    @property
    def gamma_ld(self):
        "load gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammal[:]

    @gamma_ld.setter
    def gamma_ld(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammal = v[:]

    @property
    def num_harmonics(self):
        "number of measured harmonics (for source/load gamma)"
        return len(self._gammas), len(self._gammal)

    @property
    def num_src_harmonics(self):
        "number of measured harmonics (for source gamma)"
        return len(self._gammas)

    @property
    def num_ld_harmonics(self):
        "number of measured harmonics (for load gamma)"
        return len(self._gammal)

    @property
    def column_order(self):
        return self._col_order[:]

    @property
    def column_names(self):
        return self._col_order[:]

    @property
    def swept_columns(self):
        return list(self._swp_data.keys())

    @property
    def const_columns(self):
        return list(self._const_data.keys())

    def __nonzero__(self):
        "boolean test"
        return bool(self._swp_data)

    def __len__(self):
        "length of the data block"
        return len(self._swp_data.values()[0])
    
    
    

class MauryDataBlock(object):
    "data block for a Maury data file"
    EQUALITY_TOLERANCE = 1.0e-6

    def __init__(self, columns, gamma_s, gamma_l):
        "initialize and create the column set"
        col_order = []
        const_cols = []
        swp_data = {}
        for c in columns:
            if c == 'valid':
                continue
            elif c.startswith('gamma_'):
                continue

            if c not in _const_column_names:
                swp_data[c] = []
            col_order.append(c)

        self._const_data = {}
        self._swp_data = swp_data
        self._gammas = gamma_s
        self._gammal = gamma_l
        self._col_order = col_order

    def add_data(self, block):
        "add a new 'line' of data to the block"
        need_cols = list(self._swp_data.keys())
        for k in block:
            if k == 'valid':
                continue
            v = block[k]

            m = _gamma_re_match.match(k)
            if m:
                if None in self._gammas or None in self._gammal:
                    # only compute gammas the first time
                    which, harm = m.group(1), int(m.group(2))
                    if which == 'src':
                        self._gammas[harm-1] = v
                    else:
                        self._gammal[harm-1] = v
            else:
                if k in self._swp_data:
                    self._swp_data[k].append(v)
                    del need_cols[need_cols.index(k)]
                else:
                    if k not in self._const_data:
                        self._const_data[k] = v

        if need_cols:
            raise ValueError("missing data for columns: "+(', '.join(need_cols)))

    def extract(self, value, parameter='pin_dbm', operator='eq', interpolate=True, compression_wrt_peak=False, pin_adjust=None):
        """extract 1 or more values from the dataset

        returns a dictionary in the case of single selection, or a list in the case
        of multiple selection, or None for extraction conditions that cannot be met

        Parameters:
        -------------------------------

        value         float or list of floats, the value or values at which to extract the data
                        the units of this parameter are dependent on which `parameter` is used

        Keywords:
        -------------------------------

        parameter     string, the name of the parameter that is used to extract the data, this can
                        be almost any Maury data column name as well as the 'virtual' columns:
                          comp_gt  - compression level in dB using Gt as the gain metric
                          comp_gp  - compression level in dB using Cp as the gain metric

        operator      string, the condition to extract values at, one of:
                          eq      - equal, extract at the specified value, will interpolate (if possible and enabled)
                          gt      - greater than, extract all values greater than the specified value
                          ge      - greater than or equal, extract all values greater or equal to than the specified value
                          lt      - less than, extract all values less than the specified value
                          le      - less than or equal, extract all values less than or equal to the specified value
                          ne      - not equal, extract all values not equal to the specified value
                        *NOTE*: only 'eq' will interpolate and only 'eq' will accept a list of values

        interpolate   bool, enable interpolation (default = True, only-supported when condition='eq')

        compression_wrt_peak
                      bool, compute compression with respect to the peak gain (default = False)

        pin_adjust    float, adjust the input power by an amount after extraction of the specified condition, this is
                        mostly useful to extract data at an input power backoff from some compression level
                        *NOTE*: this ONLY works when using the 'eq' operator
        """
        if not self._swp_data['pin_avail_dbm']:
            raise ValueError("dataset is empty")

        if operator not in ('eq','lt','le','gt','ge','ne'):
            raise ValueError("invalid `operator`, must be one of 'eq', 'lt', 'le', 'gt', or 'ge'")

        if isinstance(value,list):
            try:
                value = map(float,value)
            except Exception:
                raise ValueError("`value` must be a float or list of floats")

            if operator != 'eq':
                raise ValueError("a list of floats is only supported for `value` when `operator` = 'eq'")
        else:
            if value in ('min','max'):
                if operator != 'eq':
                    raise ValueError("`value` can only be 'min' or 'max' when `operator` = 'eq'")
            else:
                try:
                    value = float(value)
                except Exception:
                    raise ValueError("`value` must be a float or list of floats")

        if pin_adjust is not None:
            if operator != 'eq':
                raise ValueError("the `pin_adjust` parameter is only allowed when `operator` = 'eq'")

            try:
                pin_adjust = float(pin_adjust)
                if abs(pin_adjust) < 0.0001:
                    pin_adjust = None
            except Exception:
                raise ValueError("invalid value for pin_adjust, must be a float")

        if parameter in ('comp_gt','comp_gp'):
            try:
                if parameter == 'comp_gp':
                    gaincol = self._swp_data['gp_db']
                else:
                    gaincol = self._swp_data['gt_db']
            except Exception:
                raise ValueError("the necessary gain column for computing `%s` is not available in the dataset"%parameter)
            indep = _compute_compression(gaincol,compression_wrt_peak)
        else:
            try:
                indep = self._swp_data[_translate_maury_column(parameter)]
            except Exception:
                raise ValueError("the specified `parameter` is not a valid column name or not available in the dataset")

        if operator == 'eq':
            if isinstance(value,list):
                return [self._extract_eq(v,indep,interpolate,pin_adjust) for v in value]
            else:
                return self._extract_eq(value,indep,interpolate,pin_adjust)
        else:
            return self._extract_other(value,indep,operator)

    def _extract_eq(self, value, indep, interpolate, pin_adjust=None):
        "internal function for extracting at a value equal to the one specified"
        if value in ('min','max'):
            # handle the min or max case
            if value == 'min':
                i = indep.index(min(indep))
            else:
                i = indep.index(max(indep))

            if pin_adjust:
                new_pin = self._swp_data['pin_avail_dbm'][i] + pin_adjust
                return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)
            else:
                return self._build_data(i)

        if interpolate:
            # find where the interpolation puts us, the returned value is
            # either an integer for an exact match or a float
            i = _interp_index(value,indep,self.EQUALITY_TOLERANCE)
            if i is None:
                return None
            elif isinstance(i,int):
                # exact match case
                if pin_adjust:
                    new_pin = self._swp_data['pin_avail_dbm'][i] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)
                else:
                    return self._build_data(i)
            else:
                # create an interpolated data set
                ii = int(i)
                delta = i-ii

                # start with the integer-index data set
                d = self._build_data(ii)

                # interpolate the sweep parameter values
                for k in self._swp_data.keys():
                    lwr = self._swp_data[k][ii]
                    upr = self._swp_data[k][ii+1]
                    d[k] = lwr + (upr-lwr)*delta

                if pin_adjust:
                    new_pin = d['pin_avail_dbm'] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)
                else:
                    return d
        else:
            for i,a in enumerate(indep):
                if abs(value-a) < self.EQUALITY_TOLERANCE:
                    if pin_adjust:
                        new_pin = self._swp_data['pin_avail_dbm'][i] + pin_adjust
                        return self._extract_eq(new_pin,self._swp_data['pin_avail_dbm'],interpolate)
                    else:
                        return self._build_data(i)
            return None

    def _extract_other(self, value, indep, op):
        "internal function for extracting at values other than equal"
        func = getattr(_operator,op)
        ret = []
        for i,a in enumerate(indep):
            if func(a,value):
                ret.append(self._build_data(i))
        return ret

    def _build_data(self, idx):
        "build the dataset for the specified index"
        ret = self._const_data.copy()
        ret['gamma_src'] = self._gammas[:]
        ret['gamma_ld'] = self._gammal[:]
        for k in self._swp_data:
            ret[k] = self._swp_data[k][idx]
        return ret

    @property
    def gamma_src(self):
        "source gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammas[:]

    @gamma_src.setter
    def gamma_src(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammas = v[:]

    @property
    def gamma_ld(self):
        "load gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammal[:]

    @gamma_ld.setter
    def gamma_ld(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammal = v[:]

    @property
    def num_harmonics(self):
        "number of measured harmonics (for source/load gamma)"
        return len(self._gammas), len(self._gammal)

    @property
    def num_src_harmonics(self):
        "number of measured harmonics (for source gamma)"
        return len(self._gammas)

    @property
    def num_ld_harmonics(self):
        "number of measured harmonics (for load gamma)"
        return len(self._gammal)

    @property
    def column_order(self):
        return self._col_order[:]

    @property
    def column_names(self):
        return self._col_order[:]

    @property
    def swept_columns(self):
        return list(self._swp_data.keys())

    @property
    def const_columns(self):
        return list(self._const_data.keys())

    def __nonzero__(self):
        "boolean test"
        return bool(self._swp_data)

    def __len__(self):
        "length of the data block"
        return len(self._swp_data.values()[0])

    def __getitem__(self, col):
        "get data by column name, will either return a single data point for constant columns or a list of the sweep"
        m = _gamma_re_match.match(col)
        if m:
            # got a match to a gamma_src or gamma_ld column
            which,harm = m.group(1,2)
            if harm:
                n = int(harm)
                try:
                    if which == 'src':
                        return self._gammas[n]
                    else:
                        return self._gammal[n]
                except Exception:
                    raise KeyError(col+' is not available in the dataset')
            else:
                if which == 'src':
                    return self._gammas[:]
                else:
                    return self._gammal[:]
        elif col in self._const_data:
            return self._const_data[col]
        elif col in self._swp_data:
            return self._swp_data[col][:]
        else:
            raise KeyError(col+' is not available in the dataset')


class MauryFileBase(object):
    "base class for Maury data files"

    def __init__(self, filename, initial_lineno=0):
        "base class initializer"
        self._data = []
        self._freqlist = []
        self._testdate = datetime.datetime.fromtimestamp(100000)
        self._header_map = {}

        if isinstance(filename, _filewrapper):
            self._file = filename
        else:
            self._file = _filewrapper(filename,initial_lineno)
        self._filename = self._file.filename

    def _readline(self):
        "read a line from the current file"
        return self._file.readline()

    def _parser_cleanup(self):
        "cleanup at the end of parsing"
        if self._file:
            self._file.close()
            self._file = None

    def map_header_to_file(self, col):
        "map a column back to the name it has in a Maury data file"
        if col in self._header_map:
            return self._header_map[col]
        else:
            return col

    @property
    def _fileinfo(self):
        "return the fileinfo for the file currently being parsed"
        return self._file.filename,self._file.line_number

    @property
    def filename(self):
        "the name of the file that was parsed"
        return self._filename

    @property
    def flat_data(self):
        "full data array with no indexes"
        return self._data

    @property
    def test_date(self):
        "test date"
        return self._testdate

    @property
    def frequency(self):
        "frequency of the measured data"
        n = len(self._freqlist)
        if n == 1:
            return self._freqlist[0]
        elif n > 1:
            return self._freqlist[:]
        else:
            return None

    def __iter__(self):
        "iterator to allow iteration"
        return iter(self._data)

    def __len__(self):
        "number of data blocks in the ATS data file"
        return len(self._data)

    def __nonzero__(self):
        return bool(self._data)

    def __bool_(self):
        return bool(self._data)

    def __getitem__(self,key):
        "item indexing"
        return self._data[key]
        
    def __str__(self):
        "string representation"
        return '{}:\n  Freq: {}\n  Test Date: {}\n  Block Count: {}'.format(type(self).__name__,self.freqeuncy,self.test_data,len(self))


class MaurySplFile(MauryFileBase):
    "Maury Sweep Plan File parser"

    _type = "loadpull"

    def __init__(self, filename, initial_lineno=0):
        "initializer"
        super(MaurySplFile,self).__init__(filename,initial_lineno)
        try:
            try:
                # read header
                numf = 0
                numv = 0
                numgs = 0
                numgl = 0
                var_list = []
                freq_list = []
                ind_list = []
                header_map = {}
                line = self._readline()
                while line:
                    if line.startswith('Number of Freq'):
                        numf = int(line.split()[-1])
                    elif line.startswith('Number of Var'):
                        numv = int(line.split()[-1])
                    elif line.startswith('VAR='):
                        m = re.match(r'VAR=<([^<>]*)>,\s*Units=<([^<>]*)>',line,re.I)
                        if m:
                            v, u = m.group(1,2)
                            var_list.append(v)
                            # determine whether file is load/source pull, and which harmonic
                            if not v.find("Load") == -1:
                                self._type = "loadpull"
                                if not v.find("1") == -1:
                                    self._harm = 0
                                elif not v.find("2") == -1:
                                    self._harm = 1
                                elif not v.find("3") == -1:
                                    self._harm = 2
                            elif not v.find("Source") == -1:
                                self._type = "sourcepull"
                                if not v.find("1") == -1:
                                    self._harm = 0
                                elif not v.find("2") == -1:
                                    self._harm = 1
                                elif not v.find("3") == -1:
                                    self._harm = 2
                    elif line.startswith('! Date'):
                        self._testdate = datetime.datetime(*(time.strptime(line[12:].strip(),_maury_date_format)[0:6]))
                    elif line.startswith("! Freq"):
                        if not numf:
                            raise ParserError("'Number of Frequencies' is invalid or not found",*self._fileinfo)
                        try:
                            for i in range(numf):
                                d = self._readline().split()
                                freq_list.append( float(d[0]) )
                                ind = [int(d[j+1]) for j in range(numv)]
                                ind_list.append(ind)
                        except Exception as e:
                            raise ParserError("error reading variable count information -> {}".format(e),*self._fileinfo)
                        break
                    line = self._readline()

                # check the variable data

                if numv != len(var_list):
                    raise ParserError("mismatch between 'Number of Variables' and VAR headers",*self._fileinfo)
                elif var_list[-1] != 'Pin_avail':
                    raise ParserError("the innermost VAR must be 'Pin_avail' (otherwise data blocks make no sense)",*self._fileinfo)
                elif numv < 2:
                    raise ParserError("can't read a file where 'Number of Variables' is less than 2",*self._fileinfo)

                if numf != len(freq_list):
                    raise ParserError(self._fileinfo+": mismatch between 'Number of Frequencies' and per-frequency variable counts")

                # start reading data
                data = []
                for findex in range(numf):
                    # wait for the frequency block header
                    while not line.startswith('Freq'):
                        line = self._readline()
                        if line == '':
                            raise ParserError("hit EOF before hitting the 'Freq = ' block header",*self._fileinfo)
                    current_freq = float(line.split()[-2])

                    # sanity check of frequency
                    if abs(current_freq - freq_list[findex]) > 0.0001:
                        raise ParserError("frequency mismatch -> %g != %g"%(current_freq,freq_list[findex]),*self._fileinfo)

                    # read the other block headers
                    harm_line = self._readline()
                    data_headers = self._readline().split()
                    data_headers_lwr = [x.lower() for x in data_headers]

					# store number of source and load harmonics
                    self._numgs = int(re.search(r"(num_src_harmonics = )(\d+)", harm_line).group(2))
                    self._numgl = int(re.search(r"(num_ld_harmonics = )(\d+)", harm_line).group(2))

                    # add header translations to the dictionary
                    for i,ho in enumerate(data_headers):
                        hl = data_headers_lwr[i]
                        if hl != ho and hl not in header_map:
                            header_map[hl] = ho

                    # read all data blocks for this frequency
                    total_blocks = 1
                    ind = ind_list[findex]
                    for i in range(numv-1):
                        total_blocks *= ind[i]
                    for i in range(total_blocks):
                        self._data.append(self._read_block(data_headers_lwr,ind[-1]))

                # set the object variables
                self._vars = var_list
                self._indexing = ind_list
                self._freqlist = freq_list
                self._header_map = header_map

            except ParserError:
                raise
            except Exception as e:
                # modify the exception and re-raise

                raise
        finally:
            self._parser_cleanup()

    def _read_block(self, headers, blocklen):
        """Read a block of Maury ATS sweep plan (version 4) data.

        headers - list of headers from the main block header
        blocklen - the length of the data block.
        """
        # create the data block
        ret = MauryDataBlock(headers, self._numgs, self._numgl)

        # read the data lines
        for i in range(blocklen):
            line = self._readline()
            if line == '':
                raise ParserError("unexpected EOF",*self._fileinfo)
            d = line.split()
            dl = len(d)
            if not dl:
                raise ParserError("unexpected blank line",*self._fileinfo)

            if d[0] == '0':
                # valid flag is 0
                continue

            # parse data line
            j = 0
            data = {}
            for h in headers:
                m = _gamma_re_match.match(h)
                if m:
                    data[h] = complex(float(d[j]),float(d[j+1]))
                    j += 2
                else:
                    data[h] = float(d[j])
                    j += 1

            # add data to the block
            ret.add_data(data)

        # done reading block, return the data set
        return ret


class MaurySwpFile(MauryFileBase):
    "Maury Swept Power File parser"

    def __init__(self, filename, initial_lineno=0):
        "initializer"
        super(MaurySwpFile,self).__init__(filename,initial_lineno)
        try:
            try:
                # read header
                nswp = 0
                line = self._readline()
                while line:
                    if line.startswith("Frequency"):
                        self._freqlist = [float(line.split()[-2])]
                    elif line.startswith('! Date'):
                        self._testdate = datetime.datetime(*(time.strptime(line[12:].strip(),_maury_date_format)[0:6]))
                    elif line.startswith('Number of sweeps'):
                        nswp = int(line.split()[-1])
                        break
                    line = self._readline()

                # start reading the data sets
                if not nswp:
                    raise ParserError("missing 'Number of sweeps' header",*self._fileinfo)

                for swpidx in range(nswp):
                    # wait for the Gamma_dut line
                    while not line.startswith('Gamma_dut'):
                        line = self._readline()
                        if line == '':
                            raise ParserError("hit EOF before hitting the 'Gamma_dut' block header",*self._fileinfo)

                    # parse the Gamma_dut line
                    gs, gl = [], []
                    gline = line.split()[1:]
                    for suf in ("","_2nd","_3rd","_4th","_5th","_6th","_7th","_8th","_9th","_10th"):
                        try:
                            si = gline.index('Source'+suf)
                            li = gline.index('Load'+suf)
                            gs.append( complex(float(gline[si+2].lstrip('(')), float(gline[si+3].rstrip(')'))) )
                            gl.append( complex(float(gline[li+2].lstrip('(')), float(gline[li+3].rstrip(')'))) )
                        except Exception:
                            break

                    if not gs:
                        raise ParserError("could not parse 'Gamma_dut' line",*self._fileinfo)

                    # read the number of power points measured
                    numpwr = int(self._readline().split()[-1])

                    # read the block headers
                    headers = self._readline()[1:].split()
                    headers_lwr = [x.lower() for x in headers]
                    numheaders = len(headers)

                    # add header translations to the dictionary
                    for i,ho in enumerate(headers):
                        hl = headers_lwr[i]
                        if hl != ho and hl not in self._header_map:
                            self._header_map[hl] = ho

                    # create the data block
                    block = MauryDataBlock(headers_lwr,len(gs),len(gl))
                    block.gamma_src = gs
                    block.gamma_ld = gl

                    # read all the data lines
                    for i in range(numpwr):
                        d = list(map(float,self._readline().split()))
                        if len(d) != numheaders:
                            raise ParserError("number of data columns does not match number of headers",*self._fileinfo)
                        dd = dict(zip(headers_lwr,d))
                        block.add_data(dd)

                    # add the block to the data set
                    self._data.append(block)

            except ParserError:
                raise
            except Exception as e:
                # modify the exception and re-raise

                raise
        finally:
            self._parser_cleanup()


_re_block_begin = re.compile(r'#MEASUREMENT TYPE:\s*(?P<type>.+)')
_re_date = re.compile(r'#DATE:\s*(?P<test_time>.+)')
_re_freq = re.compile(r'#FUNDAMENTAL FREQUENCY:\s*(?P<num>\d+(\.\d+)?)\s*(?P<unit>\w)?Hz')
_re_gammasource = re.compile(r'#GAMMASOURCE:\s*(?P<f0_mag>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<f0_ang>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<f1_mag>[+|-]?\d+\.?\d+?E[+|-]\d+)?\s*(?P<f1_ang>[+|-]?\d+\.?\d+?E[+|-]\d+)?\s*(?P<f2_mag>[+|-]?\d+\.?\d+?E[+|-]\d+)?\s*(?P<f2_ang>[+|-]?\d+\.?\d+?E[+|-]\d+)?')
_re_gammaload = re.compile(r'#GAMMALOAD:\s*(?P<f0_mag>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<f0_ang>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<f1_mag>[+|-]?\d+\.?\d+?E[+|-]\d+)?\s*(?P<f1_ang>[+|-]?\d+\.?\d+?E[+|-]\d+)?\s*(?P<f2_mag>[+|-]?\d+\.?\d+?E[+|-]\d+)?\s*(?P<f2_ang>[+|-]?\d+\.?\d+?E[+|-]\d+)?')
_re_num_harmonics = re.compile(r'#HARMONICS:\s*(?P<harmonics>\d+)')
_re_quiescent_point = re.compile(r'#QUIESCENT\s*(BIAS)?\s*POINT:\s*(Vin)?\s*(?P<Vin>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(Iin)?\s*(?P<Iin>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(Vout)?\s*(?P<Vout>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(Iout)?\s*(?P<Iout>[+|-]?\d+\.?\d+?E[+|-]\d+)')
_re_pulse_point = re.compile(r'#(QUIESCENT\s)?PULSE\s*POINT:\s*(Vin)?\s*(?P<Vin>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(Iin)?\s*(?P<Iin>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(Vout)?\s*(?P<Vout>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(Iout)?\s*(?P<Iout>[+|-]?\d+\.?\d+?E[+|-]\d+)')
_re_header = re.compile(r'#Frequency\(Hz\)\s*(?:V1|Vin)\(V\)\s*(?:I1|Iin)\(A\)\s*(?:V2|Vout)\(V\)\s*(?:I2|Iout)\(A\)\s*Re\[a1\]\s*Im\[a1\]\s*Re\[b1\]\s*Im\[b1\]\s*Re\[a2\]\s*Im\[a2\]\s*Re\[b2\]\s*Im\[b2\]')
_re_data_row = re.compile(r'(?P<freq>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<V1>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<I1>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<V2>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<I2>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<a1re>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<a1im>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<b1re>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<b1im>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<a2re>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<a2im>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<b2re>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*(?P<b2im>[+|-]?\d+\.?\d+?E[+|-]\d+)\s*')
_re_block_end = re.compile(r'#END')

_si_to_float = {
    'y': 1e-24,  # yocto
    'z': 1e-21,  # zepto
    'a': 1e-18,  # atto
    'f': 1e-15,  # femto
    'p': 1e-12,  # pico
    'n': 1e-9,   # nano
    'u': 1e-6,   # micro
    'm': 1e-3,   # mili
    'c': 1e-2,   # centi
    'd': 1e-1,   # deci
    'k': 1e3,    # kilo
    'M': 1e6,    # mega
    'G': 1e9,    # giga
    'T': 1e12,   # tera
    'P': 1e15,   # peta
    'E': 1e18,   # exa
    'Z': 1e21,   # zetta
    'Y': 1e24,   # yotta
}

def safe_log10(value):
    "Returns log10 of the input number, or a very small number for a non-positive input value"
    if value <= 0.0:
        return math.log10(1e-308)
    else:
        return math.log10(value)

class IVCADDataBlock(object):
    "Data block for a Maury IVCAD file"
    EQUALITY_TOLERANCE = 1.0e-6

    def __init__(self, block_type, frequency, harmonics, src_gammas, ld_gammas):
        """
        Initialize the data block.

        Arguments:
            frequency - float representing the fundamental frequency, in Hz
            harmonics - integer reperesenting the number of harmonics measured
            src_gammas - list of complex numbers indicating the source reflection coefficients
            ld_gammas - list of complex numbers indicating the load reflection coefficients
        """
        self._type = block_type
        self._freq = frequency
        self._harmonics = harmonics
        self._gammas = [None]*(harmonics + 1)
        self._gammal = [None]*(harmonics + 1)

        for idx, g in enumerate(src_gammas):
            self._gammas[idx] = g

        for idx, g in enumerate(ld_gammas):
            self._gammal[idx] = g

        self._swp_data = []
        for idx in range(harmonics + 1):
            self._swp_data.append(
                {
                    'vin_v': [],
                    'vout_v': [],
                    'iin_ma': [],
                    'iout_ma': [],
                    'a1': [],
                    'b1': [],
                    'a2': [],
                    'b2': [],
                    'pdc_w': [],
                    'pout_w': [],
                    'pout_dbm': [],
                    'pin_deliv_w': [],
                    'pin_deliv_dbm': [],
                    'pin_avail_w': [],
                    'pin_avail_dbm': [],
                    'gp_db': [],
                    'gt_db': [],
                    'pae_%': [],
                    'eff_%': [],
                    'deff_%': []
                }
            )

    def add_data(self, line):
        """
        Parses a line of text from an IVCAD data section and inserts the data into the block.
        """
        m = _re_data_row.match(line)
        if m:
            try:
                freq = float(m.group('freq'))
                V1 = float(m.group('V1'))
                V2 = float(m.group('V2'))
                I1 = float(m.group('I1'))
                I2 = float(m.group('I2'))
                a1 = complex(float(m.group('a1re')), float(m.group('a1im')))
                b1 = complex(float(m.group('b1re')), float(m.group('b1im')))
                a2 = complex(float(m.group('a2re')), float(m.group('a2im')))
                b2 = complex(float(m.group('b2re')), float(m.group('b2im')))

                f_idx = int(freq/self._freq) - 1
                gamma_in = b1/a1
                gamma_load = a2/b2
                z_in = 50.0*((1 + gamma_in)/(1 - gamma_in))
                z_src = 50.0*((1 + self._gammas[f_idx])/(1 - self._gammas[f_idx])) if self._gammas[f_idx] else complex(50.0,0.0)
                pdc_w = V2*I2
                pout_w = 0.5*(abs(b2)*abs(b2)-abs(a2)*abs(a2))
                pout_dbm = 10.0*safe_log10(pout_w*1000.0)
                pin_del_w = 0.5*abs(a1)*abs(a1)*(1-(abs(gamma_in)*abs(gamma_in)))
                pin_del_dbm = 10.0*safe_log10(pin_del_w*1000.0)
                pin_avail_w = pin_del_w/(1 - abs((z_in - z_src.conjugate())/(z_in + z_src.conjugate())))
                pin_avail_dbm = 10.0*safe_log10(pin_avail_w*1000.0)
                gp_db = 10.0*safe_log10(pout_w/pin_del_w)
                gt_db = 10.0*safe_log10(pout_w/pin_avail_w)
                pae_pct = 100.0*((pout_w - pin_del_w)/pdc_w)
                eff_pct = 100.0*((pout_w - pin_avail_w)/pdc_w)
                deff_pct = 100.0*(pout_w/pdc_w)

            except:
                raise ValueError('Unable to parse line "{}" into IVCAD data format'.format(line))

            self._swp_data[f_idx]['vin_v'].append(V1)
            self._swp_data[f_idx]['vout_v'].append(V2)
            self._swp_data[f_idx]['iin_ma'].append(I1*1e3)
            self._swp_data[f_idx]['iout_ma'].append(I2*1e3)
            self._swp_data[f_idx]['a1'].append(a1)
            self._swp_data[f_idx]['b1'].append(b1)
            self._swp_data[f_idx]['a2'].append(a2)
            self._swp_data[f_idx]['b2'].append(b2)

            self._swp_data[f_idx]['pdc_w'].append(pdc_w)
            self._swp_data[f_idx]['pout_w'].append(pout_w)
            self._swp_data[f_idx]['pout_dbm'].append(pout_dbm)
            self._swp_data[f_idx]['pin_deliv_w'].append(pin_del_w)
            self._swp_data[f_idx]['pin_deliv_dbm'].append(pin_del_dbm)
            self._swp_data[f_idx]['pin_avail_w'].append(pin_avail_w)
            self._swp_data[f_idx]['pin_avail_dbm'].append(pin_avail_dbm)
            self._swp_data[f_idx]['gp_db'].append(gp_db)
            self._swp_data[f_idx]['gt_db'].append(gt_db)
            self._swp_data[f_idx]['pae_%'].append(pae_pct)
            self._swp_data[f_idx]['eff_%'].append(eff_pct)
            self._swp_data[f_idx]['deff_%'].append(deff_pct)

    def extract(self, value, harmonic=0, parameter='pin_avail_dbm', operator='eq', interpolate=True, compression_wrt_peak=False, pin_adjust=None):
        """extract 1 or more values from the dataset

        returns a dictionary in the case of single selection, or a list in the case
        of multiple selection, or None for extraction conditions that cannot be met

        Parameters:
        -------------------------------

        value         float or list of floats, the value or values at which to extract the data
                        the units of this parameter are dependent on which `parameter` is used

        Keywords:
        -------------------------------

        harmonic    int, which harmonic to extract the data from (defaults to the fundamental)

        parameter   string, the name of the parameter that is used to extract the data, this can
                        be almost any Maury data column name as well as the 'virtual' columns:
                          comp_gt  - compression level in dB using Gt as the gain metric
                          comp_gp  - compression level in dB using Cp as the gain metric

        operator      string, the condition to extract values at, one of:
                          eq      - equal, extract at the specified value, will interpolate (if possible and enabled)
                          gt      - greater than, extract all values greater than the specified value
                          ge      - greater than or equal, extract all values greater or equal to than the specified value
                          lt      - less than, extract all values less than the specified value
                          le      - less than or equal, extract all values less than or equal to the specified value
                          ne      - not equal, extract all values not equal to the specified value
                        *NOTE*: only 'eq' will interpolate and only 'eq' will accept a list of values

        interpolate   bool, enable interpolation (default = True, only-supported when condition='eq')

        compression_wrt_peak
                      bool, compute compression with respect to the peak gain (default = False)

        pin_adjust    float, adjust the input power by an amount after extraction of the specified condition, this is
                        mostly useful to extract data at an input power backoff from some compression level
                        *NOTE*: this ONLY works when using the 'eq' operator
        """
        if not self._swp_data[harmonic][parameter]:
            raise ValueError("dataset is empty")

        if operator not in ('eq','lt','le','gt','ge','ne'):
            raise ValueError("invalid `operator`, must be one of 'eq', 'lt', 'le', 'gt', or 'ge'")

        if isinstance(value,list):
            try:
                value = map(float,value)
            except Exception:
                raise ValueError("`value` must be a float or list of floats")

            if operator != 'eq':
                raise ValueError("a list of floats is only supported for `value` when `operator` = 'eq'")
        else:
            if value in ('min','max'):
                if operator != 'eq':
                    raise ValueError("`value` can only be 'min' or 'max' when `operator` = 'eq'")
            else:
                try:
                    value = float(value)
                except Exception:
                    raise ValueError("`value` must be a float or list of floats")

        if pin_adjust is not None:
            if operator != 'eq':
                raise ValueError("the `pin_adjust` parameter is only allowed when `operator` = 'eq'")

            try:
                pin_adjust = float(pin_adjust)
                if abs(pin_adjust) < 0.0001:
                    pin_adjust = None
            except Exception:
                raise ValueError("invalid value for pin_adjust, must be a float")

        if parameter in ('comp_gt','comp_gp'):
            try:
                if parameter == 'comp_gp':
                    gaincol = self._swp_data[harmonic]['gp_db']
                else:
                    gaincol = self._swp_data[harmonic]['gt_db']
            except Exception:
                raise ValueError("the necessary gain column for computing `%s` is not available in the dataset"%parameter)
            indep = _compute_compression(gaincol,compression_wrt_peak)
        else:
            try:
                indep = self._swp_data[harmonic][_translate_maury_column(parameter)]
            except Exception:
                raise ValueError("the specified `parameter` is not a valid column name or not available in the dataset")

        if operator == 'eq':
            if isinstance(value,list):
                return [self._extract_eq(harmonic, v,indep,interpolate,pin_adjust) for v in value]
            else:
                return self._extract_eq(harmonic, value,indep,interpolate,pin_adjust)
        else:
            return self._extract_other(harmonic, value,indep,operator)

    def _extract_eq(self, harmonic, value, indep, interpolate, pin_adjust=None):
        "internal function for extracting at a value equal to the one specified"
        if value in ('min','max'):
            # handle the min or max case
            if value == 'min':
                i = indep.index(min(indep))
            else:
                i = indep.index(max(indep))

            if pin_adjust:
                new_pin = self._swp_data[harmonic]['pin_avail_dbm'][i] + pin_adjust
                return self._extract_eq(harmonic, new_pin,self._swp_data['pin_avail_dbm'],interpolate)
            else:
                return self._build_data(i, harmonic=harmonic)

        if interpolate:
            # find where the interpolation puts us, the returned value is
            # either an integer for an exact match or a float
            i = _interp_index(value,indep,self.EQUALITY_TOLERANCE)
            if i is None:
                return None
            elif isinstance(i,int):
                # exact match case
                if pin_adjust:
                    new_pin = self._swp_data[harmonic]['pin_avail_dbm'][i] + pin_adjust
                    return self._extract_eq(harmonic, new_pin,self._swp_data[harmonic]['pin_avail_dbm'],interpolate)
                else:
                    return self._build_data(i, harmonic=harmonic)
            else:
                # create an interpolated data set
                ii = int(i)
                delta = i-ii

                # start with the integer-index data set
                d = self._build_data(ii, harmonic=harmonic)

                # interpolate the sweep parameter values
                for k in self._swp_data[harmonic].keys():
                    lwr = self._swp_data[harmonic][k][ii]
                    upr = self._swp_data[harmonic][k][ii+1]
                    d[k] = lwr + (upr-lwr)*delta

                if pin_adjust:
                    new_pin = d['pin_avail_dbm'] + pin_adjust
                    return self._extract_eq(new_pin,self._swp_data[harmonic]['pin_avail_dbm'],interpolate)
                else:
                    return d
        else:
            for i,a in enumerate(indep):
                if abs(value-a) < self.EQUALITY_TOLERANCE:
                    if pin_adjust:
                        new_pin = self._swp_data[harmonic]['pin_avail_dbm'][i] + pin_adjust
                        return self._extract_eq(new_pin,self._swp_data[harmonic]['pin_avail_dbm'],interpolate)
                    else:
                        return self._build_data(i, harmonic=harmonic)
            return None

    def _extract_other(self, harmonic, value, indep, op):
        "internal function for extracting at values other than equal"
        func = getattr(_operator,op)
        ret = []
        for i,a in enumerate(indep):
            if func(a,value):
                ret.append(self._build_data(i, harmonic=harmonic))
        return ret

    def _build_data(self, idx, harmonic=0):
        "build the dataset for the specified index"
        ret = {}
        # ret = self._const_data.copy()
        # ret['gamma_src'] = self._gammas[:]
        # ret['gamma_ld'] = self._gammal[:]
        for k in self._swp_data[harmonic]:
            ret[k] = self._swp_data[harmonic][k][idx]
        return ret

    @property
    def gamma_src(self):
        "source gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammas[:]

    @gamma_src.setter
    def gamma_src(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammas = v[:]

    @property
    def gamma_ld(self):
        "load gamma, returns a list of fundamental, second harm, third, etc"
        return self._gammal[:]

    @gamma_ld.setter
    def gamma_ld(self, v):
        if not isinstance(v,list):
            raise ValueError("gamma values must be a list")
        self._gammal = v[:]

    @property
    def num_harmonics(self):
        "number of measured harmonics"
        return self._harmonics

    @property
    def num_src_harmonics(self):
        "number of set source reflection coefficient harmonics"
        return len(self._gammas)

    @property
    def num_ld_harmonics(self):
        "number of set load reflection coefficient harmonics"
        return len(self._gammal)

    @property
    def swept_columns(self):
        return list(self._swp_data[0].keys())

    def __nonzero__(self):
        "boolean test"
        return bool(self._swp_data)

    def __len__(self):
        "length of the data block"
        return len(self._swp_data[0].values()[0])

    def __getitem__(self, col):
        "get data by column name, return all of the sweep data for the given column in an n-tuple, where n is the number of harmonics"
        if col in self._swp_data[0]:
            return tuple([self._swp_data[x][col][:] for x in range(len(self._swp_data))])
        else:
            raise KeyError(col+' is not available in the dataset')


class IVCADFile(MauryFileBase):
    "Maury IVCAD file parser"

    def __init__(self, filename, initial_lineno=0):
        "initializer"
        super(IVCADFile,self).__init__(filename,initial_lineno)
        try:
            line = self._readline()
            block_type = None
            freq = None
            harmonics = None
            gamma_source = []
            gamma_load = []
            data_block = None

            while line:
                # parse and store test time/date
                if _re_date.match(line):
                    self._testdate = datetime.datetime.strptime(_re_date.match(line).group('test_time'), '%Y/%m/%d %H:%M:%S')

                # use data_block as a flag to indicate that current lines reside inside of a data block header
                elif _re_block_begin.match(line):
                    block_type = _re_block_begin.match(line).group('type')
                    data_block = True

                # extract fundamental frequency of block
                elif data_block and _re_freq.match(line):
                    num = _re_freq.match(line).group('num')
                    unit = _re_freq.match(line).group('unit')
                    freq = float(num)*(_si_to_float[unit] if unit else 1.0)

                # extract number of harmonics measured in first block and use it to generate file's frequency list
                elif data_block and _re_num_harmonics.match(line):
                    if not freq:
                        raise ParserError('Hit number of harmonics before fundamental frequency', *self._fileinfo)
                    harmonics = int(_re_num_harmonics.match(line).group('harmonics'))
                    if not self._freqlist:
                        self._freqlist = [freq*(x+1) for x in range(harmonics + 1)]

                # extract source reflection coefficients
                elif data_block and _re_gammasource.match(line):
                    match = _re_gammasource.match(line)

                    for idx in range(3):
                        mag = match.group('f{}_mag'.format(idx))
                        ang = match.group('f{}_ang'.format(idx))
                        if mag and ang:
                            gamma_source.append(cmath.rect(float(mag), math.radians(float(ang))))

                # extract load reflection coefficients
                elif data_block and _re_gammaload.match(line):
                    match = _re_gammaload.match(line)

                    for idx in range(3):
                        mag = match.group('f{}_mag'.format(idx))
                        ang = match.group('f{}_ang'.format(idx))
                        if mag and ang:
                            gamma_load.append(cmath.rect(float(mag), math.radians(float(ang))))

                # create data block when header is reached and clear temporary header bindings
                elif data_block and _re_header.match(line):
                    if not all([gamma_source, gamma_load, freq, harmonics]):
                        raise ParserError('Hit start of data block before collecting required header information', *self._fileinfo)

                    data_block = IVCADDataBlock(block_type, freq, harmonics, gamma_source, gamma_load)
                    freq = None
                    harmonics = None
                    gamma_source = []
                    gamma_load = []

                # add data row to data block
                elif data_block and _re_data_row.match(line):
                    data_block.add_data(line)

                # add this data block to the data list and re-initialize data_block binding
                elif data_block and _re_block_end.match(line):
                    self._data.append(data_block)
                    data_block = None

                line = self._readline()

        except Exception as e:
            raise

        finally:
            self._parser_cleanup()

def _compute_compression(gaincol, compression_wrt_peak):
    "compute compression of a gain column, returns a list of the same length"
    # find the peak value
    pi = 0
    mx = gaincol[0]
    for j,v in enumerate(gaincol):
        if v > mx:
            pi = j
            mx = v

    ret = []
    if compression_wrt_peak:
        for i,g in enumerate(gaincol):
            if i < pi:
                ret.append(0.0)
            else:
                ret.append(mx-g)
    else:
        d = gaincol[0]
        for i,g in enumerate(gaincol):
            ret.append(d-g)

    return ret

def _interp_index( value, data, tolerance ):
    "compute the interpolation index, a floating point index"
    n = len(data)
    # check to see if the value falls into the range specified by adjacent points in the data array
    # or matches a point in the array exactly
    for i,vp1 in enumerate(data[1:]):
        v = data[i]
        if abs(value-v) <= tolerance:
            return i
        if abs(value-vp1) <= tolerance:
            return i+1

        if abs(vp1-v) <= tolerance:
            continue

        if (value > v and value < vp1) or (value < v and value > vp1):
            # interpolation
            return float(i) + (value-v)/(vp1-v)

    # no interpolation possible
    return None

def _translate_maury_column( col ):
    "translate column names from shorthand versions"
    col = col.lower()
    if col in _maury_column_translation_map:
        return _maury_column_translation_map[col]
    else:
        return col


