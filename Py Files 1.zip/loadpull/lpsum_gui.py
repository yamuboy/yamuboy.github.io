from __future__ import division, print_function, unicode_literals, absolute_import
try:
    # python2
    import Tkinter as tk
    import tkFileDialog
    import tkMessageBox
except ImportError:
    # python3
    import tkinter as tk
    from tkinter import filedialog as tkFileDialog
    from tkinter import messagebox as tkMessageBox
    
try:
    # python2
    from ConfigParser import RawConfigParser
except ImportError:
    # python3
    from configparser import RawConfigParser
    
    
from .gui_backend import lpsum_backend

import os
import os.path
import imp

def _load_styles():
    """Try to load a set of summary styles from a file in the user's $HOME."""
    home = os.path.expanduser('~')
    name = 'lpsum_styles'
    fp, pathname, desc = imp.find_module(name, [home])
    if fp is None:
        raise ImportError(name)
        
    try:
        return imp.load_module(name, fp, pathname, desc)
    finally:
        fp.close()
            
class LoadpullSumMain(tk.Frame):
    """Load pull summary main application window."""
    
    def __init__(self,parent,**kwargs):
        """Initializer."""
        # add some padding to the inside of the main window
        #  and init the parent object
        kwargs['padx'] = 6
        kwargs['pady'] = 10
        tk.Frame.__init__(self,parent,**kwargs)
        
        # name of the config file section
        self.__cfgsection = 'Main'
        
        # define some variables to store stuff in
        self.process = tk.StringVar()
        self.wafer = tk.StringVar()
        self.device = tk.StringVar()
        self.devicesize = tk.DoubleVar()
        self.site = tk.StringVar()
        self.testplan = tk.StringVar()
        self.testrev = tk.StringVar()
        self.working_dir = os.getcwd()
        
        try:
            stymod = _load_styles()
            self.summary_styles = stymod.SUMMARY_STYLES
            stykeys = stymod.SUMMARY_STYLES.keys()
            stykeys.sort()
            styles = tuple(stykeys)
            self.process.set(styles[0])
        except ImportError:
            print("Error finding styles module.")
            styles = None
            
        
        # try to read the last configuration from the config file
        # and set more sensible values for the variables
        self._readconfig()
        
        # outer label frame that contains the setup options
        fs = tk.LabelFrame(self, text='Setup')
        fs.grid(sticky=tk.N+tk.S+tk.W+tk.E,ipady=8,ipadx=12)
        n = 0
        
        # process/style selection list
        if styles is not None:
            tk.Label(fs, text='Process/Style:').grid(row=n,sticky=tk.W,padx=6,pady=3)
            tk.OptionMenu(fs,self.process,*styles).grid(row=n,column=1,sticky=tk.W)
            n += 1
        
        # wafer entry box
        tk.Label(fs, text='Wafer:').grid(row=n,sticky=tk.W,padx=6,pady=3)
        tk.Entry(fs,textvariable=self.wafer,width=16).grid(row=n,column=1,sticky=tk.W)
        n += 1
        
        # device entry box
        tk.Label(fs, text='Device Name:').grid(row=n,sticky=tk.W,padx=6,pady=3)
        tk.Entry(fs,textvariable=self.device,width=18).grid(row=n,column=1,sticky=tk.W)
        n += 1
        
        tk.Label(fs, text='Device Size (um):').grid(row=n,sticky=tk.W,padx=6,pady=3)
        tk.Entry(fs,textvariable=self.devicesize,width=7).grid(row=n,column=1,sticky=tk.W)
        n += 1        
        
        # site entry box
        """ # do this as a sub dialog
        tk.Label(fs, text='Site Name:').grid(row=n,sticky=tk.W,padx=6,pady=3)
        tk.Entry(fs,textvariable=self.site,width=6).grid(row=n,column=1,sticky=tk.W)
        n += 1
        """
        
        # test plan name
        tk.Label(fs, text='Test Plan:').grid(row=n,sticky=tk.W,padx=6,pady=3)
        tk.Entry(fs,textvariable=self.testplan,width=20).grid(row=n,column=1,sticky=tk.W)
        n += 1
        
        # test plan revision
        tk.Label(fs, text='Test Plan Rev:').grid(row=n,sticky=tk.W,padx=6,pady=3)
        tk.Entry(fs,textvariable=self.testrev,width=3).grid(row=n,column=1,sticky=tk.W)
        n += 1
        
        # create the "Summarize..." button
        b1 = tk.Button(self, text='Summarize file...', command=self.run_summary, width=16).grid(pady=15,sticky=tk.N+tk.S)
        
        # create the status message area
        self.msg_text = tk.StringVar(value='Ready.')
        tk.Label(self, textvariable=self.msg_text, anchor=tk.W, relief=tk.GROOVE, width=60).grid(padx=2,sticky=tk.N+tk.S+tk.E+tk.W)
        
        # handle delete window events
        self.winfo_toplevel().protocol("WM_DELETE_WINDOW",self.quit)
        
        if styles is None:
            # disable the summarize button and display an error in the status area
            b1.config(state=tk.DISABLED)
            self.msg_text.set('Error: no styles module found.') 
        
    def run_summary(self,event=None):
        """Run the summary."""
        
        # start by querying for a filename
        kwargs = { 'parent': self, 'title': 'Select a Maury data file', 
            'initialdir': self.working_dir }
        kwargs['filetypes'] = [('Maury sweep plan files','*.spl'),('All files','*.*')]
        fname = tkFileDialog.askopenfilename(**kwargs)
        
        if not len(fname):
            self.msg_text.set('Action cancelled.')
            return
        
        # a filename was selected
        # create the confirm dialog and wait
        # for it to be handled by the user
        self.confirm = False
        dialog = LoadPullSumDialog(self,fname,self.site.get())
        self.wait_window(dialog)
        
        if not self.confirm:
            # cancelled
            self.msg_text.set('Action cancelled.')
            return
        
        # if the confirmation is OK, run the summary
        try:
            # save the working directory
            p, fn = os.path.split(fname)
            self.working_dir = p
            
            # get the configuration information for this "process/style"
            suminfo = self.summary_styles[self.process.get()]
            
            # create the configuration dictionary to pass to the backend
            kw = {}
            kw['csvfilename'] = suminfo[0]
            kw['params'] = suminfo[1]
            kw['condition'] = suminfo[2]
            kw['filename'] = fname
            kw['wafer'] = self.wafer.get()
            kw['device'] = self.device.get()
            kw['devicesize'] = self.devicesize.get()
            kw['site'] = self.site.get()
            kw['testplan'] = self.testplan.get()
            kw['testplanrev'] = self.testrev.get()
            
            ##### call the backend function #####
            lpsum_backend(**kw)
            
            # update the status message
            self.msg_text.set("Summarized '%s'"%fn)
        except Exception:
            import traceback
            emsg = traceback.format_exc()
            # pop up an error dialog
            self.msg_text.set('An error occurred.')
            tkMessageBox.showerror('Error', emsg, parent=self)
    
    def quit(self,event=None):
        """Quit the program."""
        self._saveconfig()
        self.winfo_toplevel().destroy()
        
    def _readconfig(self):
        """Read configuration data."""
        # try to open a config style stored in $HOME
        cfgfile = os.path.expanduser('~/.lpsum')
        try:
            f = open(cfgfile,'r')
            p = RawConfigParser()
            p.readfp(f)
            f.close()
            main = self.__cfgsection
            self.working_dir = p.get(main,'WorkingDir')
            self.process.set( p.get(main,'Process') )
            self.wafer.set( p.get(main,'Wafer') )
            self.device.set( p.get(main,'Device') )
            self.devicesize.set( float(p.get(main,'Devicesize')) )
            self.site.set( p.get(main,'Site') )
            self.testplan.set( p.get(main,'Testplan') )
            self.testrev.set( p.get(main,'TPrev') )
        except Exception:
            print("read failed.")
        
    def _saveconfig(self):
        """Save configuration data."""
        # try to open a config style stored in $HOME
        cfgfile = os.path.expanduser('~/.lpsum')
        try:
            f = open(cfgfile,'w')
            p = RawConfigParser()
            main = self.__cfgsection
            p.add_section(main)
            p.set(main,'WorkingDir',self.working_dir)
            p.set(main,'Process',self.process.get())
            p.set(main,'Wafer',self.wafer.get())
            p.set(main,'Device',self.device.get())
            p.set(main,'Devicesize',self.devicesize.get())
            p.set(main,'Site',self.site.get())
            p.set(main,'Testplan',self.testplan.get())
            p.set(main,'TPrev',self.testrev.get())
            p.write(f)
            f.close()
        except Exception:
            print("save failed.")

class LoadPullSumDialog(tk.Toplevel):
    """Popup dialog that confirms the summary action."""
    def __init__(self,parent,fname,site):
        """Create the dialog."""
        
        # init the base class
        tk.Toplevel.__init__(self,parent)
        
        # hook this dialog to the parent window
        self.transient(parent)
        
        # set the parent in an easy-to-access property
        self.parent = parent
        
        # set the title
        self.title('Confirm action...')
        
        # create the confirmation text
        _, base = os.path.split(fname)
        s = 'Process/Style: %s\nWafer: %s\nDevice: %s\nSite: %s\n' % (
            parent.process.get(),parent.wafer.get(),parent.device.get(),parent.site.get() )
        s += 'Test Plan: %s\nTP Rev: %s\nFile: %s' % (
            parent.testplan.get(),parent.testrev.get(),base )
        
        tk.Label(self,text=s,anchor=tk.W,justify=tk.LEFT).grid(sticky=tk.N+tk.S+tk.W+tk.E,padx=5,pady=8)
        
        self.site = tk.StringVar()
        self.site.set(site)
        
        # 
        # create a site entry box
        fs = tk.LabelFrame(self, text='Enter')
        fs.grid(sticky=tk.N+tk.S+tk.W+tk.E,padx=5)
        
        tk.Label(fs,text='Site Name:').grid(row=0,sticky=tk.W,padx=6,pady=3)
        entry = tk.Entry(fs,textvariable=self.site,width=6).grid(row=0,column=1,sticky=tk.W,padx=6,pady=3)        
        
        #
        # create buttons
        #
        fr = tk.Frame(self)
        fr.grid(sticky=tk.N+tk.S+tk.W+tk.E,pady=8)
        tk.Button(fr,text='OK (F8)',width=10,command=self.ok).grid(row=0,sticky=tk.N+tk.S+tk.W+tk.E,padx=10)
        tk.Button(fr,text='Cancel',width=10,command=self.cancel).grid(row=0,column=1,sticky=tk.N+tk.S+tk.W+tk.E,padx=10)
        
        # grab mouse and keyboard events and the focus
        self.grab_set()
        self.focus_set()
        
        # bind the escape key to cancel
        # and F8 key to confirm
        self.bind('<Escape>',self.cancel)
        self.bind('<F8>',self.ok)
        
        # handle delete window events
        self.protocol("WM_DELETE_WINDOW",self.cancel)
        
        # set the initial position
        self.geometry("+%d+%d" % (parent.winfo_rootx()+30,parent.winfo_rooty()+30))        
        
    def ok(self,event=None):
        self.parent.confirm = True
        self.parent.site.set(self.site.get())
        self.cancel()
        
    def cancel(self,event=None):
        self.destroy()
        
        
if __name__ == '__main__':
    raise RuntimeError("This module should not be run directly.")
    
    