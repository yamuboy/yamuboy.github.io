# classic singleton
# 
class singleton(object):
    def __new__(self):
        if not hasattr(self, 'instance'):
            self.instance = super(singleton, self).__new__(self)
        return self.instance

# borg pattern - objects share the same state
class borg(object):

    _shared_dict = {}
    def __new__(self, *args, **kwargs):
        obj = super(borg, self).__new__(self, *args, **kwargs)
        obj.__dict__ = self._shared_dict
        return obj

def sorted_linear_search( l_to_search, item):
    l_to_search.sort()
    loop_counter = 0
    for i in range(len(l_to_search)):
        if item == l_to_search[i]:
            return True
        elif item < l_to_search[i]:
            loop_counter += 1

    print loop_counter    
    return False

def generate_sample( list_len ):
    import random
    return random.sample( range(list_len), 100)

if __name__ == "__main__":
    l = generate_sample( 100 )
    print sorted_linear_search(l, 5)
    

        

