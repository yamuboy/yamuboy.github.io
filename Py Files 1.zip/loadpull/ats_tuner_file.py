from __future__ import division, print_function, unicode_literals, absolute_import
from network_params import Param, ParamSet, param_convert, DeembeddingUtil
import numpy as np

try:
    _str_type = basestring
except NameError:
    _str_type = str

__all__ = ['TunerDataPoint','TunerFile']

class TunerDataPoint(object):
    """Class for holding and manipulating individual tuner data points."""
    
    def __init__(self, posn, spars):
        """Initializer
        posn - a 3-tuple of integers representing the tuner motor positions
        spars - a sequence of 1 or more 2x2 complex-valued NumPy array
           representing the S-parameters of the tuner at the given position.
           The first element of the sequence is the fundamental harmonic with
           the optional additional entry representing the higher order harmonics.
        """
        if len(posn) != 3:
            raise ValueError("expected a 3-tuple for argument 1")
        if not np.iterable(spars):
            raise TypeError("expected a sequence for argument 2")
        if not len(spars):
            raise ValueError("at least 1 set of S-params must be supplied in argument 2")
        
        # verify and copy the S-param data
        sp = []
        for s in spars:
            if not isinstance(s,np.ndarray):
                raise TypeError("argument 2 must be a sequence containing only NumPy arrays.")
            if s.ndim != 2 or s.shape[0] != 2 or s.shape[1] != 2:
                raise ValueError("argument 2 must be a 2x2 NumPy array-like object.")
            
            sp.append( np.matrix(s,copy=True) )
        
        self.__position = tuple(posn)
        self.__spars = tuple(sp)
        
    @property
    def position(self):
        """Get the 3-tuple of the tuner motor locations for this tuner
        position."""
        return self.__position
    
    @property
    def spars(self):
        """Get a tuple consisting of 2x2 matricies of the S-parameters at the
        fundamental frequency and harmonics (if they exist) of this
        tuner position."""
        return self.__spars
    
    @property
    def num_harmonics(self):
        """Get the number of harmonics."""
        return len(self.__spars)
        
    def refl(self, term=None, swapped=False):
        """Compute the reflection coefficient for the tuner given the termination
        gamma.
        
        term - a complex number representing the reflection coefficient of the
          termination
        swapped - boolean, use the tuner in a "swapped" manner with the termination
          on port 1 and the returned reflection coefficient as the port 2 value.
          Normally the termination is placed on port 2 and the port 1 reflection
          coefficient is returned.
        
        Returns a complex number representing the tuner's reflection coefficient.
        """
        s = self.__spars[0]
        if swapped:
            if term is None:
                return s[1,1]
            else:
                return s[1,1] + s[1,0]*s[0,1]*term / (1.0 - s[0,0]*term)
        else:
            if term is None:
                return s[0,0]
            else:
                return s[0,0] + s[1,0]*s[0,1]*term / (1.0 - s[1,1]*term)
        
    def refl_all(self, term=None, swapped=False):
        """Compute the reflection coefficient at all harmonics for the tuner
        given the termination gamma.
        
        term - a sequence of complex numbers representing the reflection
          coefficient of the termination at each harmonic.
        swapped - boolean, use the tuner in a "swapped" manner with the termination
          on port 1 and the returned reflection coefficient as the port 2 value.
          Normally the termination is placed on port 2 and the port 1 reflection
          coefficient is returned.
        
        Returns a list of complex numbers representing the tuner's reflection
          coefficient at all harmonics.
        """
        if term is None:
            result = []
            for s in self.__spars:
                if swapped:
                    result.append(s[1,1])
                else:
                    result.append(s[0,0])
            return result
        else:
            if len(term) != len(self.__spars):
                raise ValueError("the 'term' argument must have %d values" % len(self.__spars))
            result = []
            for i,s in enumerate(self.__spars):
                if swapped:
                    result.append( s[1,1] + s[1,0]*s[0,1]*term[i] / (1.0 - s[0,0]*term[i]) )
                else:
                    result.append( s[0,0] + s[1,0]*s[0,1]*term[i] / (1.0 - s[1,1]*term[i]) )
            return result
        
    def _deembed(self, dmb, f_fund):
        """De-embed (or embed) the stored data
        
        dmb    - a `network_params.DeembedingUtil` object that has been configured
                   with fixtures to de-embed (or embed)
        
        f_fund - float, the frequency of the fundamental harmonic (in Hz) if the stored data represents
                   more than one harmonic then these additional frequncies will be synthesised
                   internally (this object does not store this information as it
                   is stored in the `TunerFile`)
                
        Returns a new `TunerDataPoint` object in which has been processed
          through the de-embedding. 
        """
        if not isinstance(dmb,DeembeddingUtil):
            raise TypeError("argument 1 must be an instance of `network_params.DeembeddingUtil`")
        elif not isinstance(f_fund,float):
            raise ValueError("argument 2 must be a float")
        
        if len(self.__spars) > 1:
            flist = [(x+1)*f_fund for x in range(len(self.__spars))]
            return TunerDataPoint( self.__position, [x[1] for x in dmb.deembed_raw(map(tuple,flist,self.__spars))] )
        else:
            return TunerDataPoint( self.__position, dmb.deembed_raw( (f_fund,self.__spars[0]) )[1] )
    
    def distance(self, refl, term=None, swapped=False):
        """Compute the vector distance between this tuner position and the
        desired reflection coeffiecient.
        
        refl - a complex number representing the desired reflection coefficient
        term - (optional) complex number representing the termination impedance
           of the tuner.  If not specified, then it is assumed to be complex(0.0)
        swapped - boolean, if true then the port 2 reflection coefficient is
           used instead of port 1.
        
        Returns a floating point "distance".
        """
        return abs(self.refl(term,swapped) - refl)


class TunerFile(object):
    """Objects of this class read, store, and manipulate data from Maury ATS tuner data files."""
    
    def __init__(self, fname=None):
        """Initializer."""
        self.filename = '<object>'
        self.__flist = None
        self.__data = None
        
        if fname is not None:
            self.read_file(fname)
        
    def read_file(self,fname):
        """Read a Maury ATS tuner data file.
        
        fname - string or file object, either the filename (possibly with path
           information) of the file to read, or an already opened file-like
           object.
        """
        
        if isinstance(fname,_str_type):
            autoclose=True
            f = open(fname,'r')
            self.filename = fname
        else:
            autoclose=False
            if hasattr(fname,'name'):
                self.filename = fname.name
            else:
                self.filename = '<object>'
            f = fname
        
        # reset internal data sets
        self.__flist = []
        self.__data = []
        
        # read the tuner file
        findex = -1
        nharm = 0
        try:
            line = f.readline()
            while line:
                if line.startswith("Freq"):
                    # found a set of tuner data for a new frequency
                    freq = float(line.split()[1])
                    findex += 1
                    self.__data.append([])
                    self.__flist.append(freq*1.0e9)
                    nharm = 0
                    line = f.readline()
                    
                elif line.startswith("Position"):
                    if findex < 0:
                        raise MauryError("invalid tuner file format detected.")
                    # read in a set of position data
                    p = line.split()[1:4]
                    posn = (int(p[0]),int(p[1]),int(p[2].rstrip(',')))
                    dat = []
                    line = f.readline()
                    if not nharm:
                        # don't know how many harmonics there are
                        # need to figure it out
                        while line:
                            if line.startswith("Position"): break
                            # read the data set from the line
                            dat.append( self._get_pos_data(line) )
                            line = f.readline()
                        # set the number of harmonics for future position datasets
                        nharm = len(dat)
                    else:
                        # number of harmonics is known
                        for i in range(nharm):
                            dat.append( self._get_pos_data(line) )
                            line = f.readline()
                    # insert this position dataset into the master data list
                    dataset = TunerDataPoint(posn,dat)
                    self.__data[findex].append(dataset)
                    
                else:
                    # this is a line that we don't care about
                    line = f.readline()
        finally:
            if autoclose: f.close()
    
        
    def num_points(self, freq=None):
        """Get the number of tuner points in the dataset.
        
        freq - float, frequency to select in GHz (only useful for
           multi-frequency tuner files.
        """
        if self.__flist is None: return 0
        return len(self.__data[self._select_freq(freq)])
        
    def num_harmonics(self, freq=None):
        """Get the number of harmonics in the dataset.
        
        freq - float, frequency to select in GHz (only useful for
           multi-frequency tuner files.
        """
        if self.__flist is None: return 0
        return self.__data[self._select_freq(freq)][0].num_harmonics
    
    @property
    def num_freqs(self):
        """Get the number of freqencies in the dataset."""
        if self.__flist is None: return 0
        return len(self.__flist)
        
    @property
    def freqs(self):
        """Get the frequencies of the tuner file."""
        if self.__flist is None: return []
        return self.__flist[:]
        
    def find_nearest_position(self, refl, freq=None, term=None, swapped=False, **kwargs):
        """Find the nearest absolute tuner position
        
        refl - complex, the desired reflection coefficient
        freq - float, the frequency in GHz, only useful for multi-frequency tuner files
        term - complex, terminating impedance for the tuner
        swapped - boolean, get the port 2 reflection coefficient instead of port 1
        
        Keywords:
        
        TBD...
        
        Returns a TunerDataPoint object.
        """
        if self.__flist is None:
            raise ValueError("there is no data in the object.")
            
        # select the dataset to use
        data = self.__data[self._select_freq(freq)]
        # find the closest tuner data point
        dist = 1000.0
        i = -1
        for j,tp in enumerate(data):
            d = tp.distance(refl,term,swapped)
            if d < dist:
                i = j
                dist = d
        return data[i]
    
    def deembed(self, port1_spars=None, port2_spars=None, swap_p1=False, swap_p2=False, deembed=True):
        """De-embed/embed S-parameters onto the tuner data.
        
        port1_spars - a `network_params.ParamSet` object, the path to a Touchstone data file,
           or an open file-like object - this contains S-parameters to embed/de-embed to/from
           port 1 of the tuner.  If None, then no de-embedding is done
           on port 1.  See `network_params.DeembeddingUtil for details.
        port2_spars - a `network_params.ParamSet` object, the path to a Touchstone data file,
           or an open file-like object - this contains S-parameters to embed/de-embed to/from
           port 2 of the tuner.  If None, then no de-embedding is done
           on port 2.  See `network_params.DeembeddingUtil for details.
        swap_p1 - boolean, if True then swap the port order for the port1_spars
           before de-embedding (default = False).
        swap_p2 - boolean, if True then swap the port order for the port2_spars
           before de-embedding (default = False).
        deembed - boolean, if True then automatically calculate the matrix inverse
           of the port 1 and 2 de-embedding data (default = True)
           
        The port1_spars and port2_spars data must cover all of the frequencies and harmonics
        that are part of the TunerFile dataset - it will be interpolated as necessary to match
        the frequencies that are present.
        
        The "standard" port order is as shown below:
        
                ----------        ---------        ----------
             1 |  Port 1  | 2  1 |         | 2  1 |  Port 2  | 2
           ----| S-params |------|  Tuner  |------| S-params |----
               |          |      |         |      |          |
                ----------        ---------        ----------
        
        Port 1 and port 2 S-params can be swapped by using the swap_p1 and swap_p2 arguments if
        the port order of the data does not match the diagram above.
        
        Returns a new TunerFile object with the de-embedding applied.
        """
        if not self.__flist:
            raise ValueError("there is no data stored")
            
        # create the de-embedding utility
        dmb = DeembeddingUtil(fname1=port1_spars,fname2=port2_spars,swap1=swap_p1,swap2=swap_p2,
            invert1=deembed,invert2=deembed)
            
        freqs = self.__flist
        newdata = []
        for i,dset in enumerate(self.__data):
            fdata = []
            for d in dset:
                fdata.append( d._deembed(dmb,freqs[i]) )
            newdata.append(fdata)
        
        ret = TunerFile()
        ret._set_data(freqs,newdata)
        return ret
        
    def embed(self, port1_spars=None, port2_spars=None, swap_p1=False, swap_p2=False, deembed=None):
        return self.deembed(port1_spars=port1_spars,port2_spars=port2_spars,swap_p1=swap_p1,
            swap_p2=swap_p2,deembed=False)
    embed.__doc__ = deembed.__doc__
        
    def _set_data(self, flist, data):
        """This is used internally to apply data to a TunerFile object after
        embedding/deembedding.
        """
        if len(flist) != len(data):
            raise ValueError("Mismatch in size of arguments.")
        self.__flist = flist
        self.__data = data
    
    def _get_pos_data(self, line):
        """Get the S-parameter data from a line in a tuner file."""
        d = map(float,line.split())
        if len(d) != 8:
            raise ValueError("Invalid line format. Expected 8 floating point values.")
        # convert to a complex numpy matrix and correct the order
        return np.matrix( [[complex(d[0],d[1]),complex(d[4],d[5])],[complex(d[2],d[3]),complex(d[6],d[7])]] )
    
    def _select_freq(self, freq=None):
        """Select the frequency index to use.  Useful for multi-frequency
        tuner data files.
        
        Returns an integer index.
        """
        if not freq or len(self.__flist) == 1:
            return 0
        
        for i,f in enumerate(self.__flist):
            if abs(freq - f) < 0.001:
                return i
        
        raise ValueError("the specified frequency is not available.")
    
    def iter_pos(self, freq=None):
        """Return an iterator that iterates over the tuner positions for the
        specified frequency.
        
        freq - float, the frequency in GHz. If not supplied then the first
           frequency in the dataset will be used.
        
        Returns an iterator to the data for the given frequency. Each iteration
        will return a TunerFile.TunerDataPoint object.
        """
        if not len(self.__freq):
            raise ValueError("no data exists.")
        return iter(self.__data[self._select_freq(freq)])
        
    def iter_freq(self):
        """Iterate over the frequency list of the data set.
        
        Each iteration returns a frequency value in GHz.
        """
        return iter(self.__freq)
        
        

