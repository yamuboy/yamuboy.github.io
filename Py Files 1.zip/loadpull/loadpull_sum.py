from __future__ import division, print_function, unicode_literals, absolute_import
from maplot.batch_setup import *
from maplot.figures.loadpull_plot import LoadPullFigure
from .ats_summary import maury_ats_summary
from optparse import OptionParser, OptionValueError
import traceback
import sys

def summarize( filename, do_print=False, do_rect=False, do_contour=False, **kwargs ):
    """Main loadpull summary extry point.
    
    Arguments:
    filename - an iterable container of file names/paths
    
    Keywords:
    do_print - a boolean indicating if a data summary should be printed to the
       terminal. The default is False.
    
    do_rect - a boolean indicating if rectangular plotting is to be done. The
       default is False.
    
    do_contour - a boolean indicating if contour plotting is to be done. The
       default is False.
    
    minimize - a boolean indicating that the summary should minimize the
       specified parameter (useful for reflection coeff). The default is False.
    
    y1axis - a list of data columns to plot on the y1 axis of rectangular
       plots.  The default is None.
    
    y2axis - a list of data columns to plot on the y2 axis of rectangular
       plots. The default is None.
    
    zaxis - a list of data columns to plot on the contour plot z-axis. The
       default is ['Pout_dBm'].
    
    linewidth - the line width for plots. The default is 1.
    
    grid_density - the density of the grid in both X and Y directions for
       contour plots.  This should be an integer indicating the number of
       divisions that the x/y grid should be broken into. The default
       value is 30.
    
    ncontours - The number of contours to draw for contour plots. The default
       value is 10.
       
    file_pattern - a pattern string that will be used to create the output
       file.  This must contain an appropriate pattern if multiple files are
       to be plotted, otherwise each plot fle will overwrite the previous one.
       The default pattern is '%(path)%(base)-%(ext)'.
    
    textsum - a sequence of columns for which to generate a textual summary
       by the side of the plot for rectangular plots. The default is None.
    
    output - the type of image file for the output of plot files ('png', 'bmp',
       'jpg', etc). The default is 'png'.
    """
    
    if not do_print and not do_rect and not do_contour:
        raise RuntimeError("Nothing to do.")
        
    # get the summary conditions
    col,cond,val = 'Pout_dBm','comp_gt',1.0
    if 'condition' in kwargs:
        if len(kwargs['condition']) != 3:
            raise ValueError("The 'condition' keyword must be a 3-tuple.")
        col,cond,val = kwargs['condition']
    minimize = kwargs.get('minimize',False)
    
    # create the summary object
    summary = maury_ats_summary(filename=filename, column=col, condition=cond,
        value=val, minimize=minimize)
    
    # if the summary is to be printed, print it to stdout
    if do_print:
        summary.print_summary()
        
    if do_rect or do_contour:
        # create a load pull figure
        figure = create_figure(FigureClass=LoadPullFigure)
        
        if do_rect:
            # adjust keywords to include parameters for creating the data file name
            kwargs['filename_extra'] = '_rect'
            figure.rect_plot(summary,**kwargs)
            
        if do_contour:
            # adjust keywords to include parameters for creating the data file name
            kwargs['filename_extra'] = '_contour'
            figure.contour_plot(summary,**kwargs)
        


def parse_cl( args=None ):
    """Parse the command line, if args is not set then it defaults to
    sys.argv.
    """
    if args is None:
        args = sys.argv[1:]
    
    # parse command line args
    options, extra = _op.parse_args(args)
    
    # set some implied options
    if options.y1axis is not None or options.y2axis is not None:
        setattr(options, 'do_rect', True)
    if options.zaxis is not None:
        setattr(options, 'do_contour', True)
    
    ret = dict()
    for k in options.__dict__:
        v = options.__dict__[k]
        if v is not None:
            ret[k] = v
    
    return ret, extra
    
def print_help():
    """Print the command-line help."""
    _op.print_help()

def print_usage():
    """Print the command-line usage message."""
    _op.print_usage()

def _main():
    """Implicit main routine if the module is invoked directly."""
    opts, files = parse_cl()
    
    if not len(files):
        _op.print_usage()
        sys.exit(1)
    
    for f in files:
        if f.startswith('-'):
            print("Error: unexpected option '%s'." % f)
            print('')
            _op.print_help()
            sys.exit(1)
        
    for f in files:
        try:
            summarize(f,**opts)
        except Exception as msg:
            print("Error: %s: %s" % (f,msg))
            traceback.print_exc()


def _collist_arg_cb( option, opt_str, value, parser ):
    """Parse an arg into a list of columns."""
    if not value:
        raise OptionValueError("Optoin '%s' requires a value." % opt_str)
    lst = value.split(',')
    if not len(lst):
        raise OptionValueError("Parse error for option '%s'." % opt_str)
    
    lst2 = []
    for c in lst:
        c1 = c.strip()
        if not len(c1): continue
        lst2.append(c1)
    
    # error checking done, set the option value
    setattr(parser.values,option.dest,lst2)
    
def _condition_arg_cb( option, opt_str, value, parser ):
    """Parse the condition arg.
    
    The form is 'column,condition,value' or just 'cond'.  If the level argument
    is not supplied then it takes on the default value for the given
    condition.
    """
    col,cond,val = None,None,None
    valid_conditions = ('at','comp_gt','comp_gp','at_pin','at_pout','min','max')
    
    if not value:
        raise OptionValueError("Option '%s' requires a value." % opt_str)
    
    lst = value.split(',')
    if not len(lst):
        raise OptionValueError("Parse error for option '%s'." % opt_str)
    
    if lst[0].strip() in valid_conditions:
        # no column name was given, default to Pout_dBm
        col = 'Pout_dBm'
        cond = lst[0].strip()
        if len(lst) > 1:
            try:
                val = float(lst[1].strip())
            except ValueError:
                raise OptionValueError("Invalid 'value' parameter for option '%s'."%opt_str)
            
        if len(lst) > 2:
            raise OptionValueError("Too many parameters for option '%s'." % opt_str)
        
    else:
        # first list value must be a column name
        col = lst[0].strip().lower()
        
        if len(lst) > 1:
            cond = lst[1].strip().lower()
            if cond not in valid_conditions:
                raise OptionValueError("Invalid 'condition' parameter for option '%s'."%opt_str)
            
        if len(lst) > 2:
            try:
                val = float(lst[2].strip())
            except ValueError:
                raise OptionValueError("Invalid 'value' parameter for option '%s'."%opt_str)
            
        if len(lst) > 3:
            raise OptionValueError("Too many parameters for option '%s'." % opt_str)
    
    if cond is None:
        cond = 'comp_gt'
        val = 1.0
    
    # store the values
    setattr(parser.values,option.dest,(col,cond,val,))


# create a command line parser
_op = OptionParser( usage="Usage: %prog [options] file1 [file2 ...]" )
_op.add_option( "-v", "--verbose", action="store_true", dest="do_print",
    help="Print summary data to the terminal." )
_op.add_option( "-r", "--rect", "--sweep", action="store_true", dest="do_rect",
    help="Create a rectangular (power sweep) data plot." )
_op.add_option( "-c", "--contour", action="store_true", dest="do_contour",
    help="Create a contour data plot." )
_op.add_option( "--xaxis", dest="xaxis", type="string",
    help="The column name to use for the X-axis of rectangular plots, default = 'Pin_avail_dBm'" )
_op.add_option( "--y1axis", action="callback", dest="y1axis", type="string",
    callback=_collist_arg_cb,
    help="A comma-separated list of 1 or more column names to plot on the Y1-axis of rectangular plots." )
_op.add_option( "--y2axis", action="callback", dest="y2axis", type="string",
    callback=_collist_arg_cb,
    help="A comma-separated list of 1 or more column names to plot on the Y2-axis of rectangular plots." )
_op.add_option( "--zaxis", action="callback", dest="zaxis", type="string",
    callback=_collist_arg_cb,
    help="A comma-separated list of 1 or more column names to plot on the Z-axis of contour plots." )

_op.add_option( "--cond", type="string", action="callback", dest="condition",
    callback=_condition_arg_cb, help="The condition used to process the summary. This \
is a comma-seperated string of 'column,condition,value', where 'column' is a data\
column name or alias, 'condition' is one of ['comp_gt', 'comp_gp', 'at_pin', 'at_pout', \
'at', 'min', or 'max'], and 'value' is a value to be applied to the condition and \
is ignored for conditions that do not need a value." )

_op.add_option( "--min", action="store_true", dest="minimize",
    help="Minimize the 'column' summary parameter instead of maximizing it." )

_op.add_option( "--pattern", type="string", dest="file_pattern",
    help="A pattern string to use when generating file names. The pattern is \
a string that contains replacement string patterns such as '%(path)s' that are \
replaced with an appropriate substitution when file names are generated for \
plots." )
_op.add_option( "-o", "--output", type="string", dest="output",
    help="Output image type for plots (i.e. 'png', 'jpg', 'bmp', etc)." )
_op.add_option( "--lw", type="float", dest="linewidth",
    help="Line width for plots." )

_op.add_option( "--txtsum", action="callback", dest="textsum", type="string",
    callback=_collist_arg_cb,
    help="A comma-separated list of 1 or more column names to print a text \
summary of on rectangular plots." )

_op.add_option( "--density", type="int", dest="grid_density",
    help="Grid density for contour plots, larger number => more dense grid." )
_op.add_option( "--levels", type="int", dest="ncontours",
    help="The number of contour levels for contour plots." )
    
if __name__ == '__main__':
    # run the main routine if invoked directly
    _main()


