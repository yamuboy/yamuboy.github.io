from .ats_parser import MauryFileBase, _maury_date_format


def extract_lp_file( fname, dataset, extract_condition ):
    """Extract data from a Maury data set (MaurySplFile or MaurySwpFile)
    at a certain condition and then write a Maury load pull data file
    
    fname                string or open file-like object
    dataset              MaurySplFile or MaurySwpFile object
    extract_condition    dict, passed on as kwargs to the MauryDataBlock.extract() method
                           the dictionary MUST at a minimum contain the 'value' keyword
                           and can also contain any other parameters accepted by the
                           above-named function method
    """
    # validate the extract_condition dictionary
    if 'value' not in extract_condition:
        raise KeyError("`extract_condition` must contain a key for 'value'")
    if 'operator' in extract_condition and extract_condition['operator'] != 'eq':
        raise ValueError("only 'eq' is supported for `extract_condition['operator']`")

    # check the dataset
    freq = dataset.frequency
    if isinstance(freq,list):
        raise ValueError("this function can only support datasets with a single frequency")
    
    first_block = dataset.flat_data[0]
    column_order = first_block.column_order
    if 'freq' in column_order:
        del column_order[column_order.index('freq')]
    gamma_src = first_block.gamma_src
    
    # first do the extraction
    if not isinstance(dataset,MauryFileBase):
        raise TypeError('dataset must be a `MauryFileBase`-derived object')
    data = []
    for d in dataset.flat_data:
        x = d.extract(**extract_condition)
        if x:
            for col in column_order:
                if col not in x:
                    raise ValueError("heterogeous data set, columns are not consistent")
            data.append(x)
    
    if not len(data):
        raise ValueError("dataset extraction step resulted in no usable data")
    
    if hasattr(fname,'write') and hasattr(fname.write,'__call__'):
        fp = fname
        ac = False
    else:
        fp = open(fname,'w')
        ac = True
    
    try:
        fp.write('! Load Pull Data file\n')
        fp.write('! \n')
        fp.write('! Date/time %s \n'%dataset.test_date.strftime(_maury_date_format))   # Wed Apr 07 13:58:33 2010 
        fp.write('Frequency %8.4f GHz\n'%freq)
        fp.write('number of positions: %3d\n'%len(data))
        fp.write('number of harmonics: %3d\n'%len(gamma_src))
        # write static source gamma
        fp.write('Static Gamma_dut:')
        suffix = ("","_2nd","_3rd","_4th","_5th","_6th","_7th","_8th","_9th","_10th")
        for i,gs in enumerate(gamma_src):
            fp.write(' Source%s = (%.5f %.5f)'%(suffix[i],gs.real,gs.imag))
        fp.write('\n')
        # write the headers
        fp.write('!')
        for h in column_order:
            fp.write(' '+dataset.map_header_to_file(h))
        fp.write('\n')
        # write the blocks
        for block in data:
            # gamma line
            fp.write('Gamma_dut:')
            for gl in block['gamma_ld']:
                fp.write('   %.5f   %.5f'%(gl.real,gl.imag))
            fp.write(' \n')
            # data line
            fp.write('  ')
            for h in column_order:
                fp.write(' %9.5f'%block[h])
            fp.write('\n')
    finally:
        if ac:
            fp.close()
            
            