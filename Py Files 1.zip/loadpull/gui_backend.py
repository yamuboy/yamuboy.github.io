from __future__ import division, print_function, unicode_literals, absolute_import
from .ats_summary import maury_ats_summary
from .ats_parser import maury_ats_parser
import math
import os
import os.path
import csv
import cmath
import numpy as np

# mA/mm gate current for Psat
_psat_ig_mamm = 1.0
_psat0p1_ig_mamm = 0.1

# what to return for a blank column value
BLANK_COL = '-'

def lpsum_backend(**kwargs):
    """Load pull summary workhorse function."""
    
    # read the file
    ats_file = maury_ats_parser(kwargs['filename'])
    
    # for each condition listed in the condition list
    # run the summary worker
    for cond_name,cond_def in kwargs['condition']:
        _summary_worker(cond_name,cond_def,ats_file,**kwargs)
        
    
def _summary_worker(cond_name,cond,ats_file,**kwargs):
    """Worker function for the summary."""

    # ordered list of parameters to include in the summary 
    param_keys = ['wafer','device','site','testplan','testplanrev','devicesize'] 
    param_keys.extend(kwargs['params'])
    # add the filename at the end since it is a long field
    param_keys.append('filename')
    
    # dictionary mapping of parameter names to "pretty" column header names
    # parameters not appearing here will instead by printed in title case
    param_header_map = { 'testplan':'Test Plan', 'testplanrev':'TP Rev',
        'devicesize':'Size', 'testdate':'Test Date',
        'pout':'Po', 'pae':'PAE', 'deff':'DE',
        'sumcond':'Sum. Cond.', 'freq':'Frequency', 'mag_gs':'Mag(Gs)',
        'phase_gs':'Phase(Gs)', 'real_gs':'Real(Gs)', 'imag_gs':'Imag(Gs)',
        'mag_gl':'Mag(Gl)', 'phase_gl':'Phase(Gl)', 'real_gl':'Real(Gl)',
        'imag_gl':'Imag(Gl)', 'refldb':'Refl',
    }
    
    # dictionary mapping parameter names to units
    param_units_map = { 'devicesize':'um', 'pout':'mW/mm',
        'pae':'%', 'deff':'%', 'vdd':'V', 'vgg':'V',
        'vdq':'V', 'vgq':'V', 'idd':'mA', 'idq':'mA', 'igg':'mA', 'igq':'mA',
        'gt':'dB', 'gp':'dB', 'freq':'GHz', 'refldb':'dB',
    }
    
    # dictionary mapping parameter names to Maury data file names
    fixed_meas_map = { 'vdq':'Vq_out_v', 'vgq':'Vq_in_v', 'idq':'Iq_out_mA',
        'igq':'Iq_in_mA', 'vdd':'Vout_v', 'idd':'Iout_mA', 'vgg':'Vin_v',
        'igg':'Iin_mA', 'gt':'Gt_dB', 'gp':'Gp_dB', 'refl':'Refl_coef',
        'refldb':'Refl_dB',
    }
    
    # tuple defining valid representations of the source and load gammas
    gamma_keys = ('mag_gs','phase_gs','real_gs','imag_gs','mag_gl','phase_gl',
        'real_gl','imag_gl',)
            
    # parse and summarize the file
    args = [ats_file]
    args.extend( cond.split(',') )
    summary = maury_ats_summary(*args)
    
    # best block index
    bestidx = summary.best_index
    
    # separate summary objects for various conditions
    sum1db = None
    sum3db = None
    sumsat = None
    sumsat0p1 = None
    
    # compute the psat current
    psat_ma = _psat_ig_mamm * kwargs['devicesize'] * 0.001
    psat0p1_ma = _psat0p1_ig_mamm * kwargs['devicesize'] * 0.001
        
    # generate the data to be used by the summary
    sum_params = dict()
    for key in param_keys:
        if key in kwargs:
            # for these keys, get a value from the incoming keywords
            if key in ('wafer','device','site'):
                # to prevent Excel from treating numeric site numbers and
                # wafer numbers as numbers (Excel displays them all wacky)
                # force them to be strings
                sum_params[key] = '"'+kwargs[key]+'"'
            else:
                sum_params[key] = kwargs[key]
        elif key in fixed_meas_map.keys():
            # for these keys, access fixed values of the loadpull summary data
            try:
                sum_params[key] = summary.best_block[fixed_meas_map[key]]
            except KeyError:
                sum_params[key] = BLANK_COL
        elif key in gamma_keys:
            # these are manipulation of the fundamental source and load gammas
            g = key[-2:]
            if g == 'gs':
                data = summary.best_block['gamma_src'][0]
            else:
                data = summary.best_block['gamma_ld'][0]
            if key.startswith('real'):
                sum_params[key] = data.real
            elif key.startswith('imag'):
                sum_params[key] = data.imag
            elif key.startswith('mag'):
                sum_params[key] = abs(data)
            elif key.startswith('phase'):
                sum_params[key] = math.degrees(math.atan2(data.imag,data.real))
        elif key == 'freq':
            sum_params[key] = summary.data.frequency
        elif key == 'sumcond':
            sum_params[key] = cond_name
        elif key == 'testdate':
            try:
                sum_params[key] = summary.data.testdate.strftime('%m/%d/%Y')
            except:
                sum_params[key] = BLANK_COL
        elif key.find(',') > 0:
            # compute a variety of special summary conditions
            parm,cond = key.split(',')
            minimize = False
            if cond == '1db':
                if sum1db is None:
                    sum1db = maury_ats_summary(filename=ats_file,column='Pout_dBm',condition='comp_gt',value=1.0)
                sumdata = sum1db.summary[bestidx]
            elif cond == '3db':
                if sum3db is None:
                    sum3db = maury_ats_summary(filename=ats_file,column='Pout_dBm',condition='comp_gt',value=3.0)
                sumdata = sum3db.summary[bestidx]
            elif cond == 'sat':
                if sumsat is None:
                    sumsat = maury_ats_summary(filename=ats_file,column='Iin_mA',condition='at',value=psat_ma)
                sumdata = sumsat.summary[bestidx]
            elif cond == 'sat0p1':
                if sumsat0p1 is None:
                    sumsat0p1 = maury_ats_summary(filename=ats_file,column='Iin_mA',condition='at',value=psat0p1_ma)
                sumdata = sumsat0p1.summary[bestidx]
            elif cond == 'max':
                sumdata = summary.data[bestidx]
            elif cond == 'min':
                sumdata = summary.data[bestidx]
                minimize = True
            else:
                print("Warning: '%s' is not a valid condition." % cond)
                sum_params[key] = BLANK_COL
                continue
            
            d = _compute_special(sumdata,parm,kwargs['devicesize'])
            if d == BLANK_COL or isinstance(d,float):
                sum_params[key] = d
            else:
                # must be a list
                if minimize:
                    sum_params[key] = min(d)
                else:
                    sum_params[key] = max(d)
        else:
            print("Warning: '%s' is not a valid column descriptor." % key)
            sum_params[key] = BLANK_COL
                            
    csvfile_exist=False
    csvfname = os.path.expandvars(os.path.expanduser(kwargs['csvfilename']))
    if not os.path.isfile(csvfname):
        # csv summary file does not exist, need to add header information to it
        fp = open(csvfname,'wb')
        csvf = csv.writer(fp)
        
        # create the header names row
        d = []
        for key in param_keys:
            if key.find(',') > 0:
                k1, cond = key.split(',')
                extra = cond
            else:
                k1 = key
                extra = ''
                
            if k1 in param_header_map:
                h = param_header_map[k1]
            else:
                h = k1.title()
            
            if len(extra):
                h += '-' + extra
            
            # see if units exist
            if k1 in param_units_map:
                h += '(%s)' % param_units_map[k1]
            
            d.append(h)
                
        csvf.writerow(d)
                
    else:
        # file exists, append to the existing file
        fp = open(csvfname,'ab')
        csvf = csv.writer(fp)
    
    # create the data row
    d = []
    for key in param_keys:
        d.append(sum_params[key])
    csvf.writerow(d)
    fp.close()

def _compute_special(sumobj, param, periphum):
    """Compute a "special" parameter that is not directly copied from the
    original summary object.
    """
    
    parm_map = { 'pae':'Eff_%', 'iout':'Iout_mA', 'iin':'Iin_mA',
        'gt':'Gt_dB', 'gp':'Gp_dB',     
    }
    
    if sumobj is None:
        return BLANK_COL
    
    # get the column
    col = param
    if param in parm_map:
        col = parm_map[param]
    
    # check if the data is stored in lists, in which case a list will
    # be returned
    lstmode = False
    try:
        iter(sumobj['Pout_dBm'])
        lstmode = True
    except:
        pass
    
    try:
        if param in parm_map:
            col = parm_map[param]
            return sumobj[col]
        elif param == 'pout':
            # convert pout to mW/mm
            if lstmode:
                return np.pow(10.0,np.array(sumobj['Pout_dBm'])*0.1)*1000.0 / periphum
            else:
                return math.pow(10.0,sumobj['Pout_dBm']*0.1)*1000.0 / periphum
        elif param == 'deff':
            # compute drain efficiency
            if lstmode:
                return 100.0 * np.pow(10.0,0.1*np.array(sumobj['Pout_dBm'])) / (np.array(sumobj['Vout_v'])*np.array(sumobj['Iout_mA']))
            else:                
                return 100.0 * math.pow(10.0,0.1*sumobj['Pout_dBm']) / (sumobj['Vout_v']*sumobj['Iout_mA'])
        else:
            print("Warning: '%s' param is not valid." % param)
            return BLANK_COL
    except Exception as e:
        print("Warning: '%s' for param '%s'" % (e,param))
        return BLANK_COL

if __name__ == '__main__':
    # trap attempts to run this module directly
    raise RuntimeError("This module is not designed to be invoked directly.")

