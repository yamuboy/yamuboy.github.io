import numpy as np
from network_params import ParamSet, param_convert
import six

__all__ = ['TunerDataPoint','TunerFile']

class TunerDataPoint(object):
    """Class for holding and manipulating individual tuner data points."""
    
    def __init__(self,posn,spars):
        """Initializer
        posn - a 3-tuple of integers representing the tuner motor positions
        spars - a sequence of 1 or more 2x2 complex-valued NumPy array
           representing the S-parameters of the tuner at the given position.
           The first element of the sequence is the fundamental harmonic with
           the optional additional entry representing the higher order harmonics.
        """
        if len(posn) != 3:
            raise ValueError("expected a 3-tuple for argument 1")
        if not np.iterable(spars):
            raise TypeError("expected a sequence for argument 2")
        if not len(spars):
            raise ValueError("at least 1 set of S-params must be supplied in argument 2")
        
        # verify and copy the S-param data
        sp = []
        for s in spars:
            if not isinstance(s,np.ndarray):
                raise TypeError("argument 2 must be a sequence containing only NumPy arrays.")
            if s.ndim != 2 or s.shape[0] != 2 or s.shape[1] != 2:
                raise ValueError("argument 2 must be a 2x2 NumPy array-like object.")
            
            sp.append( np.matrix(s,copy=True) )
        
        self.__position = tuple(posn)
        self.__spars = tuple(sp)
        
    @property
    def position(self):
        """Get the 3-tuple of the tuner motor locations for this tuner
        position."""
        return self.__position
    
    @property
    def spars(self):
        """Get a tuple consisting of 2x2 matricies of the S-parameters at the
        fundamental frequency and harmonics (if they exist) of this
        tuner position."""
        return self.__spars
    
    @property
    def num_harmonics(self):
        """Get the number of harmonics."""
        return len(self.__spars)
        
    def refl(self, term=None, swapped=False):
        """Compute the reflection coefficient for the tuner given the termination
        gamma.
        
        term - a complex number representing the reflection coefficient of the
          termination
        swapped - boolean, use the tuner in a "swapped" manner with the termination
          on port 1 and the returned reflection coefficient as the port 2 value.
          Normally the termination is placed on port 2 and the port 1 reflection
          coefficient is returned.
        
        Returns a complex number representing the tuner's reflection coefficient.
        """
        s = self.__spars[0]
        if swapped:
            if term is None:
                return s[1,1]
            else:
                return s[1,1] + s[1,0]*s[0,1]*term / (1.0 - s[0,0]*term)
        else:
            if term is None:
                return s[0,0]
            else:
                return s[0,0] + s[1,0]*s[0,1]*term / (1.0 - s[1,1]*term)
        
    def refl_all(self, term=None, swapped=False):
        """Compute the reflection coefficient at all harmonics for the tuner
        given the termination gamma.
        
        term - a sequence of complex numbers representing the reflection
          coefficient of the termination at each harmonic.
        swapped - boolean, use the tuner in a "swapped" manner with the termination
          on port 1 and the returned reflection coefficient as the port 2 value.
          Normally the termination is placed on port 2 and the port 1 reflection
          coefficient is returned.
        
        Returns a list of complex numbers representing the tuner's reflection
          coefficient at all harmonics.
        """
        if term is None:
            result = []
            for s in self.__spars:
                if swapped:
                    result.append(s[1,1])
                else:
                    result.append(s[0,0])
            return result
        else:
            if len(term) != len(self.__spars):
                raise ValueError("the 'term' argument must have %d values" % len(self.__spars))
            result = []
            for i,s in enumerate(self.__spars):
                if swapped:
                    result.append( s[1,1] + s[1,0]*s[0,1]*term[i] / (1.0 - s[0,0]*term[i]) )
                else:
                    result.append( s[0,0] + s[1,0]*s[0,1]*term[i] / (1.0 - s[1,1]*term[i]) )
            return result
        
    def _embed_t(self, p1_tpars=None, p2_tpars=None):
        """Embed T-parameters onto the tuner ports and return the result as
        a new object.
        
        Note that de-embedding can be applied by inverting the T-param
        matrices prior to passing them to the function.
        
        p1_spars - a sequence of 2x2 complex numpy matrices, representing the
           T-parameters to embed onto port 1 of the tuner data.  The length
           of the sequence must exactly match the length of the stored tuner
           S-parameters.
        p2_spars - a sequence of 2x2 complex numpy matrices, representing the
           T-parameters to embed onto port 2 of the tuner data.
        
        Port order:
        
                ----------        ---------        ----------
             1 |  Port 1  | 2  1 |         | 2  1 |  Port 2  | 2
           ----| T-params |------|  Tuner  |------| T-params |----
               |          |      |         |      |          |
                ----------        ---------        ----------
        
        Returns a new object in which the specified embedding is applied.
        """
        # compute the tuner T-params
        t_tuner = self._s2t(self.__spars)
        
        t_result = []
        if p1_tpars is not None:
            if len(p1_tpars) != len(self.spars):
                raise ValueError("the 'p1_tpars' argument has the wrong length")
            for i,tt in enumerate(t_tuner):
                t_result.append( p1_tpars[i] * tt )
        else:
            t_result = t_tuner
            
        if p2_tpars is not None:
            if len(p2_tpars) != len(self.spars):
                raise ValueError("the 'p2_tpars' argument has the wrong length")
            for i,tt in enumerate(t_tuner):
                t_result.append( tt * p2_tpars[i] )
        
        # create and return the new object
        return TunerDataPoint( self.__position, self._t2s(t_result) )
    
    def distance(self, refl, term=None, swapped=False):
        """Compute the vector distance between this tuner position and the
        desired reflection coeffiecient.
        
        refl - a complex number representing the desired reflection coefficient
        term - (optional) complex number representing the termination impedance
           of the tuner.  If not specified, then it is assumed to be complex(0.0)
        swapped - boolean, if true then the port 2 reflection coefficient is
           used instead of port 1.
        
        Returns a floating point "distance".
        """
        return abs(self.refl(term,swapped) - refl)
    
    def _s2t(self, inp):
        """Convert S-parameters to T-parameters."""
        if np.iterable(inp):
            ret = []
            for p in inp:
                d = 1.0/p[1,0]
                ret.append( np.matrix([[p[0,1]-p[0,0]*p[1,1]*d, p[0,0]*d], [-p[1,1]*d, d]]) )
            return ret
        else:
            p = inp
            d = 1.0/p[1,0]
            return np.matrix([[p[0,1]-p[0,0]*p[1,1]*d, p[0,0]*d], [-p[1,1]*d, d]])
        
    def _t2s(self, inp):
        """Convert T-parameters to S-parameters."""
        if np.iterable(inp):
            ret = []
            for p  in inp:
                d = 1.0/p[1,1]
                ret.append( np.matrix([[p[0,1]*d, p[0,0]-p[0,1]*p[1,0]*d], [d, -p[1,0]*d]]) )
            return ret
        else:
            p = inp
            d = 1.0/p[1,1]
            return np.matrix([[p[0,1]*d, p[0,0]-p[0,1]*p[1,0]*d], [d, -p[1,0]*d]])
            




class TunerFile(object):
    """Objects of this class read, store, and manipulate data from Maury ATS tuner data files."""
    
    def __init__(self, fname=None):
        """Initializer."""
        self.filename = '<unknown>'
        self.__flist = None
        self.__data = None
        
        if fname is not None:
            self.read_file(fname)
        
    def read_file(self,fname):
        """Read a Maury ATS tuner data file.
        
        fname - string or file object, either the filename (possibly with path
           information) of the file to read, or an already opened file-like
           object.
        """
        
        if isinstance(fname,six.string_types):
            autoclose=True
            f = open(fname,'r')
            self.filename = fname
        else:
            autoclose=False
            self.filename = '<unknown>'
            f = fname
        
        # reset internal data sets
        self.__flist = []
        self.__data = []
        
        # read the tuner file
        findex = -1
        nharm = 0
        try:
            line = f.readline()
            while line:
                if line.startswith("Freq"):
                    # found a set of tuner data for a new frequency
                    freq = float(line.split()[1])
                    findex += 1
                    self.__data.append( [] )
                    self.__flist.append(freq*1.0e9)
                    nharm = 0
                    line = f.readline()
                    
                elif line.startswith("Position"):
                    if findex < 0:
                        raise MauryError("invalid tuner file format detected.")
                    # read in a set of position data
                    p = line.split()[1:4]
                    posn = (int(p[0]),int(p[1]),int(p[2].rstrip(',')))
                    dat = []
                    line = f.readline()
                    if not nharm:
                        # don't know how many harmonics there are
                        # need to figure it out
                        while line:
                            if line.startswith("Position"): break
                            # read the data set from the line
                            dat.append( self._get_pos_data(line) )
                            line = f.readline()
                        # set the number of harmonics for future position datasets
                        nharm = len(dat)
                    else:
                        # number of harmonics is known
                        for i in range(nharm):
                            dat.append( self._get_pos_data(line) )
                            line = f.readline()
                    # insert this position dataset into the master data list
                    dataset = TunerDataPoint(posn,dat)
                    self.__data[findex].append(dataset)
                    
                else:
                    # this is a line that we don't care about
                    line = f.readline()
        finally:
            if autoclose: f.close()
    
        
    def num_points(self, freq=None):
        """Get the number of tuner points in the dataset.
        
        freq - float, frequency to select in GHz (only useful for
           multi-frequency tuner files.
        """
        if self.__flist is None: return 0
        return len(self.__data[self._select_freq(freq)])
        
    def num_harmonics(self, freq=None):
        """Get the number of harmonics in the dataset.
        
        freq - float, frequency to select in GHz (only useful for
           multi-frequency tuner files.
        """
        if self.__flist is None: return 0
        return self.__data[self._select_freq(freq)][0].num_harmonics
    
    @property
    def num_freqs(self):
        """Get the number of freqencies in the dataset."""
        if self.__flist is None: return 0
        return len(self.__flist)
        
    @property
    def freqs(self):
        """Get the frequencies of the tuner file."""
        if self.__flist is None: return []
        return self.__flist[:]
        
    def find_nearest_position(self, refl, freq=None, term=None, swapped=False, **kwargs):
        """Find the nearest absolute tuner position
        
        refl - complex, the desired reflection coefficient
        freq - float, the frequency in GHz, only useful for multi-frequency tuner files
        term - complex, terminating impedance for the tuner
        swapped - boolean, get the port 2 reflection coefficient instead of port 1
        
        Keywords:
        
        TBD...
        
        Returns a TunerDataPoint object.
        """
        if self.__flist is None:
            raise ValueError("there is no data in the object.")
            
        # select the dataset to use
        data = self.__data[self._select_freq(freq)]
        # find the closest tuner data point
        dist = 1000.0
        i = -1
        for j,tp in enumerate(data):
            d = tp.distance(refl,term,swapped)
            if d < dist:
                i = j
                dist = d
        return data[i]
    
    def embed(self, port1_spars=None, port2_spars=None, swap_p1=False, swap_p2=False):
        """Return a new object in which the s-params are embedded onto the tuner
        ports.
        
        port1_spars - a network_params.ParamSet object containing S-parameters to
           embed onto port 1 of the tuner.  If None, then no embedding is done
           on port 1.
        port2_spars - a network_params.ParamSet object containing S-parameters to
           embed onto port 2 of the tuner.  If None, then no embedding is done
           on port 2.
        swap_p1 - boolean, if true then swap the port order for the port1_spars
           before embedding.
        swap_p2 - boolean, if true then swap the port order for the port2_spars
           before embedding.
           
        The S-parameter ParamSet objects must contain enough data to cover all of
        the frequencies and harmonics that are part of the TunerFile dataset.  The
        S-param data will be interpolated as necessary to match the frequencies
        of the TunerFile dataset.
        
        The "standard" port order is as shown below:
        
                ----------        ---------        ----------
             1 |  Port 1  | 2  1 |         | 2  1 |  Port 2  | 2
           ----| S-params |------|  Tuner  |------| S-params |----
               |          |      |         |      |          |
                ----------        ---------        ----------
        
        Port 1 and port 2 S-params can be swapped by using the swap_p1 and
        swap_p2 arguments.
        
        Return a new TunerFile object with the embedding applied.
        """
        if self.__flist is None:
            raise ValueError("there is no data in the object.")
            
        freqs = self.__flist
        newdata = []
        for i,dset in enumerate(self.__data):
            # create embedding data for this frequency
            p1_t,p2_t = None,None
            if port1_spars is not None:
                p1_t = self._extract_t(port1_spars,freqs[i],swap_p1)
            if port2_spars is not None:
                p2_t = self._extract_t(port2_spars,freqs[i],swap_p2)
            # embed the data
            fdata = []
            for d in dset:
                fdata.append( d._embed_t(p1_t,p2_t) )
            newdata.append(fdata)
        
        ret = TunerFile()
        ret._set_data(freqs,newdata)
        return ret
        
    def deembed(self, port1_spars=None, port2_spars=None, swap_p1=False, swap_p2=False):
        """Return a new object in which the s-params are deembedded from the tuner
        ports.
        
        port1_spars - a network_params.ParamSet object containing S-parameters to
           deembed from port 1 of the tuner.  If None, then no deembedding is done
           on port 1.
        port2_spars - a network_params.ParamSet object containing S-parameters to
           deembed from port 2 of the tuner.  If None, then no deembedding is done
           on port 2.
        swap_p1 - boolean, if true then swap the port order for the port1_spars
           before deembedding.
        swap_p2 - boolean, if true then swap the port order for the port2_spars
           before deembedding.
           
        The S-parameter ParamSet objects must contain enough data to cover all of
        the frequencies and harmonics that are part of the TunerFile dataset.  The
        S-param data will be interpolated as necessary to match the frequencies
        of the TunerFile dataset.
        
        The "standard" port order is as shown below:
        
                ----------        ---------        ----------
             1 |  Port 1  | 2  1 |         | 2  1 |  Port 2  | 2
           ----| S-params |------|  Tuner  |------| S-params |----
               |          |      |         |      |          |
                ----------        ---------        ----------
        
        Port 1 and port 2 S-params can be swapped by using the swap_p1 and
        swap_p2 arguments.
        
        Returns a new TunerFile object with the deembedding applied.
        """
        if self.__flist is None:
            raise ValueError("there is no data in the object.")
            
        freqs = self.__flist
        newdata = []
        for i,dset in enumerate(self.__data):
            # create deembedding data for this frequency
            p1_t,p2_t = None,None
            if port1_spars is not None:
                p1_t = self._extract_t(port1_spars,freqs[i],swap_p1,invert=True)
            if port2_spars is not None:
                p2_t = self._extract_t(port2_spars,freqs[i],swap_p2,invert=True)
            # deembed the data
            fdata = []
            for d in dset:
                fdata.append( d._embed_t(p1_t,p2_t) )
            newdata.append(fdata)
        
        ret = TunerFile()
        ret._set_data(freqs,newdata)
        return ret
        
    def _set_data(self, flist, data):
        """This is used internally to apply data to a TunerFile object after
        embedding/deembedding.
        """
        if len(flist) != len(data):
            raise ValueError("Mismatch in size of arguments.")
        self.__flist = flist[:]
        self.__data = data[:]
    
    def _extract_t(self, spars, freq, swap=False, invert=False):
        """Extract T-parameters from the passed S-paremeter ParamSet object.
        
        spars - network_params.ParamSet object containing S-parameters
        freq - double, the frequency in GHz for which to generate the T-param
          data.  This must be one of the frequencies of this TunerFile object.
        swap - boolean, if true swap the port order
        invert - boolean, if true invert the resultant T-param matrices prior
          to returning them.  This is useful for deembedding.
        
        Returns a tuple of T-param matrices of the right length to match the
        harmonics of the given TunerFile frequency.
        """
        if not isinstance(spars,ParamSet):
            raise TypeError("expected a network_params.ParamSet object for argument 1")
        # generate a list of harmonics
        nharm = self.num_harmonics(freq)
        fund = freq*1.0e9
        fl = [fund]
        for j in range(2,nharm+1):
            fl.append(fund*j)
        # extract the S-params from the ParamSet
        sp = spars.extract(fl)
        # convert to T
        tp = param_convert('s','t',sp)
        # pull the data component from the Param objects and insert it into
        # a list, swapping and inverting if requested
        ret = []
        for t in tp:
            td = t.data
            if swap:
                td = td.T
            if invert:
                td = td.I
            ret.append(td)
        return tuple(ret)
        
    def _get_pos_data(self, line):
        """Get the S-parameter data from a line in a tuner file."""
        d = map(float,line.split())
        if len(d) != 8:
            raise ValueError("Invalid line format. Expected 8 floating point values.")
        # convert to a complex numpy matrix and correct the order
        return np.matrix( [[complex(d[0],d[1]),complex(d[4],d[5])],[complex(d[2],d[3]),complex(d[6],d[7])]] )
    
    def _select_freq(self, freq=None):
        """Select the frequency index to use.  Useful for multi-frequency
        tuner data files.
        
        Returns an integer index.
        """
        if not freq or len(self.__flist) == 1:
            return 0
        
        for i,f in enumerate(self.__flist):
            if abs(freq - f) < 0.001:
                return i
        
        raise ValueError("the specified frequency is not available.")
    
    def iter_pos(self,freq=None):
        """Return an iterator that iterates over the tuner positions for the
        specified frequency.
        
        freq - float, the frequency in GHz. If not supplied then the first
           frequency in the dataset will be used.
        
        Returns an iterator to the data for the given frequency. Each iteration
        will return a TunerFile.TunerDataPoint object.
        """
        if not len(self.__freq):
            raise ValueError("no data exists.")
        return iter(self.__data[self._select_freq(freq)])
        
    def iter_freq(self):
        """Iterate over the frequency list of the data set.
        
        Each iteration returns a frequency value in GHz.
        """
        return iter(self.__freq)
        
        

