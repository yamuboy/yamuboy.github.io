from loadpull.ats_parser import MauryFileBase, MauryLpDataBlock
import datetime
import time, warnings, re

_maury_date_format = '%a %b %d %H:%M:%S %Y'


class NewLpFile( MauryFileBase ):

    def __init__(self, filename, initial_lineno = 0):

        super( NewLpFile, self).__init__(filename, initial_lineno)
        try:
            while True:
                line = self._readline()
                if line.startswith('Frequency'):
                    freq = float(re.findall("\d+\.\d+",line)[0])
                elif line.startswith('number of positions'):
                    num_positions = int(line.split()[-1])
                elif line.startswith('! Date'):
                    self._testdate = datetime.datetime(*(time.strptime(line[12:].strip(),_maury_date_format)[0:6])) 
                elif line.startswith('number of harmonics'):
                    num_harmonics = line.split()[-1]
                elif line.startswith('Static'):
                    static_gammas = re.findall(static_gamma_ex, line)
                    src1 = self._convert_gammas(static_gammas[0])
                    src2 = self._convert_gammas(static_gammas[1])
                    src3 = self._convert_gammas(static_gammas[3])
                elif 'Pin_avail_dBm' in line:
                    data_headers = line.split()[1:]
                    data_headers_lwr = [x.lower() for x in data_headers]                            
                    # add header translations to the dictionary
                    for i,ho in enumerate(data_headers):
                        hl = data_headers_lwr[i]
                        if hl != ho and hl not in header_map:
                            header_map[hl] = ho
                elif line.startswith('Gamma_dut'):
                    ld1, ld2, ld3 = self._convert_gammas_2(line)
                    self._numgl = [ld1, ld2, ld3]
                    blocklen = 1
                else:
                    if len(line.split()) == len(data_headers):
                        self._data.append(self._read_block(data_headers_lwr))
        except ParserError:
            raise
        finally:
            self._parser_cleanup()
            

    def _convert_gammas(self, to_conv):

        t = to_conv.split()
        return complex(float(t[0]),float(t[1]))

    def _convert_gammas_2(self, to_conv):

        t = to_conv.split()[1:]
        ld1 = complex( float(t[0]), float(t[1]) )
        ld2 = complex( float(t[2]), float(t[3]) )
        ld3 = complex( float(t[4]), float(t[5]) )
        return ld1, ld2, ld3  
        
class ParserError(Exception):
    def __init__(self,msg,filename=None,lineno=None):
        """Parameters:
           msg - the error message string
           filename - the name of the file in which the error occurred.
           lineno - the line number of which the error occurred.
        """
        super(ParserError,self).__init__(msg)
        self.filename = filename
        self.lineno = lineno

class MauryLpFile( MauryFileBase ):

    def __init__(self, filename, initial_lineno = 0):

        super(MauryLpFile, self).__init__(filename, initial_lineno)
        
        try:
            header_map = {}
            freq = 0
            # Regex to get the static source gammas
            static_gamma_ex = '(?<=\\().*?(?=\\))'
            f = open(self.filename, 'r')
            #line = self._readline() 
            for line in f:
                if line.startswith('Frequency'):
                    freq = float(re.findall("\d+\.\d+",line)[0])
                elif line.startswith('number of positions'):
                    num_positions = int(line.split()[-1])
                elif line.startswith('! Date'):
                    self._testdate = datetime.datetime(*(time.strptime(line[12:].strip(),_maury_date_format)[0:6])) 
                elif line.startswith('number of harmonics'):
                    num_harmonics = line.split()[-1]
                elif line.startswith('Static'):
                    static_gammas = re.findall(static_gamma_ex, line)
                    src1 = self._convert_gammas(static_gammas[0])
                    src2 = self._convert_gammas(static_gammas[1])
                    src3 = self._convert_gammas(static_gammas[3])
                    self._numgs = [src1, src2, src3 ]
                elif 'Pin_avail_dBm' in line:
                    data_headers = line.split()[1:]
                    data_headers_lwr = [x.lower() for x in data_headers]                            
                    # add header translations to the dictionary
                    for i,ho in enumerate(data_headers):
                        hl = data_headers_lwr[i]
                        if hl != ho and hl not in header_map:
                            header_map[hl] = ho
                elif line.startswith('Gamma_dut'):
                    ld1, ld2, ld3 = self._convert_gammas_2(line)
                    self._numgl = [ld1, ld2, ld3]
                    blocklen = 1
                else:
                    if len(line.split()) == 12:
                        self._data.append(self._read_block(data_headers_lwr))                
        except ParserError:
            raise
        finally:
            self._parser_cleanup()
                
            
    def _convert_gammas(self, to_conv):

        t = to_conv.split()
        return complex(float(t[0]),float(t[1]))

    def _convert_gammas_2(self, to_conv):

        t = to_conv.split()[1:]
        ld1 = complex( float(t[0]), float(t[1]) )
        ld2 = complex( float(t[2]), float(t[3]) )
        ld3 = complex( float(t[4]), float(t[5]) )
        return ld1, ld2, ld3  

    def _read_block(self, headers):
        """Read a block of Maury ATS sweep plan (version 4) data.

        headers - list of headers from the main block header
        blocklen - the length of the data block.
        """
        # create the data block
        self._numgs = 3
        self._numgl = 3
        ret = MauryLpDataBlock(headers, self._numgs, self._numgl)

        # read the data lines
        line = self._readline()
        
        if line == '':
            raise ParserError("unexpected EOF",*self._fileinfo)
        d = line.split()
        dl = len(d)
        if not dl:
            raise ParserError("unexpected blank line",*self._fileinfo)

        if d[0] == '0':
            # valid flag is 0
            pass

        # parse data line
        j = 0
        data = {}
        print headers
        for h in headers:
            data[h] = float(d[j])
            j += 1

        # add data to the block
        ret.add_data(data)

        # done reading block, return the data set
        return ret 
    
if __name__ == "__main__":
    a = MauryLpFile('25cLoadPull.lp')
    print dir(a)
    #test1('25cLoadPull.lp')
    


