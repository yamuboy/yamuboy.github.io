import sys
import math
from loadpull.ats_parser import maury_ats_parser

#  ---------------------------------------------------------------------------------
#         Maury Data summary tool
#  ---------------------------------------------------------------------------------

_default_analyzer_parms = {
    'max_compression_db':3.5,
    'eff_backoff':3.0,
    'gain_backoff':0.0,
    'power_backoff':0.6,
    'eff_mult':2.0,
    'gain_mult':4.0,
    'power_mult':2.0,
    'eff_trans':1.0,
    'gain_trans':0.7,
    'power_trans':1.5,
    'use_gp':False,
}

class LoadpullAnalyzer(object):
    """Analyze loadpull data on a device and try to find the best set of
    impedances based on trade-offs between power, gain, and efficiency.
    
    There are a set of tuning parameters that can be used to modify the
    algorithm that is used by the analyzer, but the basic algorithm is as
    follows:
    - Analyze each load pull data block and find the best efficiency value
      where the device is less than `max_compression_db` into compression
      (as measured from linear gain) - the best efficiency and associated
      gain at that point are then used in subsequent calculations as
      $effpeak and $gaineff
    - Analyze each load pull data block and find the best power value where
      the device is less than `max_compression_db` into compression (as
      measured from linear gain) - the power level at this point is then
      used in subsequent calculations as $pwrpeak
    - a backoff of $effpeak, $gaineff, and $pwrpeak is calculated by using
      the configurable parameters `eff_backoff`, `gain_backoff`, and
      `power_backoff` - these backoff values are used as the target values
      for computing metrics for the load pull blocks
    - metrics are calculated by using the target values as center points
      to a non-linear weighting function for each of the 3 parameters (power,
      gain, and efficiency)
    """
    
    def __init__(self, filename=None, **kwargs):
        """Initializer
           
        """
        
        self.__atsfile = None
        self.__parms = _default_analyzer_parms.copy()
        self.__bestblock = None
        self.__blockdata = None
        
        if len(kwargs) or filename is not None:
            # deal with configuration parameters
            if filename is not None:
                kwargs['filename'] = filename
            self.config(**kwargs)
        
    def clear(self):
        """Delete file data and clear the summary but leave parameters intact."""
        self.__atsfile = None
        self.__bestblock = None
        self.__blockdata = None
        
    def config(self, **kwargs):
        """Configure the parameters of the analyzer engine
        
        Keywords
        ==================================================================
        filename - name of the file to read, can also be a file-like object
                   or an instance of `maury_ats_parser`
        auto_analyze - boolean, flag to automatically re-analyze the ATS data
                       defaults to True when `filename` is specified and
                       False otherwise
        max_compression_db - float, maximum compression in dB as measured
                             from linear gain
        eff_backoff - float, backoff in precent from peak efficiency, used
                      in computation of loadpull block metrics
        
        
        
        
        
        
        
        """
        
        # reset the state so that the summary is not listed as complete
        self.__bestblock = None
        self.__blockdata = None
        
        # check configuration keywords
        for k in ('max_compression_db', 'eff_backoff', 'gain_backoff', 'power_backoff',
            'eff_mult', 'gain_mult', 'power_mult', 'eff_trans', 'gain_trans', 'power_trans',):
            if k in kwargs:
                try:
                    v = float(kwargs.pop(v))
                    if v < 0.0:
                        raise ValueError("less than 0")
                    self.__parms[k] = v
                except Exception, e:
                    raise ValueError("'%s' must be a floating-point value >= 0.0"%k)
        
        if 'use_gp' in kwargs:
            self.__parms['use_gp'] = bool(kwargs.pop('use_gp'))
        
        auto = None
        if 'auto_analyze' in kwargs:
            auto = bool(kwargs.pop('auto_analyze'))
        
        if 'filename' in kwargs:
            self.__atsfile = None
            fname = kwargs.pop('filename')
            if isinstance(fname,maury_ats_parser):
                self.__atsfile = fname            
            else:
                self.__atsfile = maury_ats_parser(fname)
            
            # if auto-analyze is not specified, then default to True
            # in cases when the filename keyword is supplied 
            if auto is None:
                auto = True
        
        # check for left-over keywords
        if len(kwargs):
            raise ValueError("unrecognized keywords: "+(', '.join(["'"+str(k)+"'" for k in kwargs.keys()])))
        
        # run the analysis
        if auto:
            self.analyze()
    
    def analyze(self, **kwargs):
        """Analyze the load pull data set
        
        Find the best data block based on the current set of algorithm criteria
        """
        if len(kwargs):
            # configure prior to analyze
            kwargs['auto_analyze'] = False
            self.config(**kwargs)
        
        self.__bestblock = None
        self.__blockdata = None
        
        if self.__atsfile is None:
            raise ValueError("no file has been read")
        elif not len(self.__atsfile):
            raise ValueError("'%s' - no data" % self.__atsfile.filename)
        
        gain_field_name = 'Gt_dB'
        if self.__parms['use_gp']:
            gain_field_name = 'Gp_dB'
        
        # check for the availability of fields
        d = self.__atsfile[0]
        missing = []
        for fn in ('Pout_dBm','Eff_%',gain_field_name):
            if fn not in d:
                missing.append(fn)
        if missing:
            raise ValueError("missing field(s): "+(', '.join(["'"+str(k)+"'" for k in missing])))            
        
        # special case for single-sweep data
        if len(self.__atsfile) == 1:
            self.__bestblock = 0
            self.__blockdata = [None]
            return
        
        ### Pass 1: find the best efficiency and power points ###
        effp = -10000.0
        pwrp = -10000.0
        gainp = -10000.0
        effi = None
        pwri = None
        for i, d in enumerate(self.__atsfile):
            p, g, e = self._analyze_block(d,gain_field_name)
            if pwri is None or p > pwrp:
                pwri = i
                pwrp = p
            if effi is None or e > effp:
                effi = i
                effp = e
                gainp = g
        
        ### Compute the target values for power, gain, and efficiency ###
        pwrt = pwrp - self.__parms['power_backoff']
        gaint = gainp - self.__parms['gain_backoff']
        efft = effp - self.__parms['eff_backoff']
        
        #print "power target: %.2f"%pwrt
        #print "gain target: %.2f"%gaint
        #print "eff target: %.1f"%efft
        
        ### Pass 2: compute metrics for each block ###
        self.__blockdata = []
        for i, d in enumerate(self.__atsfile):
            metric = self._compute_block_metric(d,gain_field_name,pwrt,gaint,efft)
            metric['index'] = i
            self.__blockdata.append(metric)
        
        ### find the best metric and store that ###
        metrics = self.__blockdata[:]
        sortf = lambda a, b: cmp(a['metric'],b['metric'])
        metrics.sort(sortf)
        self.__bestblock = metrics[-1]['index']
        
    def _analyze_block(self, block, gaincol):
        "find the best efficiency (and gain at that efficiency) and power for a given block"
        maxcomp = self.__parms['max_compression_db']
        gain0 = block[gaincol][0]
        pwrp = -10000.0
        gainp = -10000.0
        effp = -10000.0
        for i in range(len(block['Pout_dBm'])):
            comp = gain0 - block[gaincol][i]
            if comp > maxcomp:
                break
            
            if block['Pout_dBm'][i] > pwrp:
                pwrp = block['Pout_dBm'][i]
            if block['Eff_%'][i] > effp:
                effp = block['Eff_%'][i]
                gainp = block[gaincol][i]
        
        return pwrp, gainp, effp
    
    def _compute_block_metric(self, block, gaincol, pwrt, gaint, efft):
        "compute the metric for the block"
        best = None
        n = None
        for i in range(len(block['Pout_dBm'])):
            x = block['Pout_dBm'][i] - pwrt
            pm = self.__parms['power_mult']*abs(x)*math.tanh(self.__parms['power_trans']*x)
            x = block[gaincol][i] - gaint
            gm = self.__parms['gain_mult']*abs(x)*math.tanh(self.__parms['gain_trans']*x)
            x = block['Eff_%'][i] - efft
            em = self.__parms['eff_mult']*abs(x)*math.tanh(self.__parms['eff_trans']*x)
            total = pm + gm + em
            if i == 0 or total > best:
                best = total
                n = i
        
        return {'metric':best, 'pout':block['Pout_dBm'][n], 'gain':block[gaincol][n], 'eff':block['Eff_%'][n]}
            
    def __str__(self):
        """Stringify the data for pretty printing."""
        def _print_gamma( g ):
            m = abs(g[0])
            a = math.atan2(g[0].imag,g[0].real) * 180. / math.pi
            mastr = "(%5.3f <%6.1f)" % (m, a)
            s = "%-20s %-20s" % (g[0],mastr)
            return s
            
        s = "=======================================================\nFile: %s\nFreq: %.3f GHz\n" % (self.__atsfile.filename,self.__atsfile.frequency)
        if self.__bestblock is not None:
            s += "Best data block:\n  Index: %d\n" % self.__bestblock
            metric = self.__blockdata[self.__bestblock]
            data = self.__atsfile[self.__bestblock]
            s += "  Pout  = %.2f\n"%metric['pout']
            s += "  Gain  = %.1f\n"%metric['gain']
            s += "  Eff   = %.2f\n"%metric['eff']            
            s += "  Gamma:\n"
            s += "    %-11s = %s\n"%("gamma_src",_print_gamma(data["gamma_src"])) 
            s += "    %-11s = %s\n"%("gamma_ld",_print_gamma(data["gamma_ld"]))
        return s
    
    
    @property    
    def filename(self):
        if not self.__atsfile:
            return None
        return self.__atsfile.filename
    
    @property
    def atsdata(self):
        return self.__atsfile
    
    @property
    def best_data(self):
        if not self.__atsfile or self.__bestblock is None:
            return None
        return self.__atsfile[self.__bestblock]
    
    @property
    def best_index(self):
        return self.__bestblock
    
    @property
    def get_metrics(self):
        if not self.__blockdata:
            return None
        return self.__blockdata[:]
    
    
    
