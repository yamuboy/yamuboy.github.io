from __future__ import division, print_function, unicode_literals, absolute_import
from . import _mt993d
import weakref

_controllers = weakref.WeakValueDictionary()
_tuners = weakref.WeakValueDictionary()

class ConsistencyError(_mt993d.MauryError):
    "raise an error related to parameter consistency"
    pass
    
class OutOfSpace(_mt993d.MauryError):
    "raise an error when too many tuners or controllers are defined"
    pass


def init_tuners():
    "initialize all defined tuners"
    _mt993d.init_tuners()
    
    
class Controller(object):
    "define a tuner controller"
    
    def __init__(self, driver, model, timeout=13, address=-1, delay_ms=0, serial=-1):
        """initializer
        
        driver    string, ATS driver name, i.e. "Tun1020c.exe"
        model     string, controller model string, i.e. "MT1020C"
                    a list of model strings that are supported by a given driver
                    can be retrieved using _mt993d.get_model_lists()
        
        Keywords:
        -------------------------------
        timeout   int, GPIB timeout, this is a value from 0-17 that represents
                    represents an approximate GPIB communication timeout
                    for more information see the NI GPIB documentation
        address   int, GPIB address of the controller
        delay_ms  int, delay in milliseconds before sending commands to the
                    controller
        serial    int, the controller serial number, required if the controller
                    is USB type
        """
        self._mytuners = []
        
        # get the next available controller number
        idx = list(range(8))
        for k in _controllers.keys():
            if k in idx:
                del idx[idx.index(k)]
        if not len(idx):
            raise OutOfSpace("no more storage space for controllers - only 8 are allowed")
        self._index = idx[0]
        
        # create the controller, this can raise a MauryError exception
        _mt993d.add_controller(self._index,driver,model,timeout,address,delay_ms,serial)
        
        # store this controller
        _controllers[self._index] = self
    
    def add_tuner(self, model, serial, port=1):
        """add a new tuner definition to this controller
        
        model     string, tuner model string, i.e. "MT982B01"
        serial    int, tuner serial number
        
        Keywords:
        -------------------------------
        port      int, the controller port number that the tuner is
                    connected to (either 1 or 2 for most controllers) 
        """
        return Tuner(self,model,serial,port)
        
    def check(self):
        "check that the controller is present and defined properly"
        if self._index < 0:
            raise ConsistencyError("this controller has an invalid index")
        _mt993d.check_tuner_controllers(self._index)
        return True
 
    def _register_tuner(self, tuner):
        """register a tuner with this controller
        
        this is called during construction of a Tuner object and should not
        be used by any other code
        """
        self._mytuners.append(tuner)
        
    def _unregister_tuner(self, tuner):
        """un-register a tuner with this controller
        
        this is called during deletion of a Tuner object and should not
        be used by any other code
        """
        if tuner in self._mytuners:
            del self._mytuners[self._mytuners.index(tuner)]
        
    def __del__(self):
        "special behavior during a delete"
        if self._index > -1:
            _mt993d.delete_controller(self._index)            
        self._index = -1
            
    @property
    def index(self):
        "get the controller index"
        return self._index

class NullController(Controller):
    "special class for controller-less tuners"
    
    def __init__(self, *args, **kwargs):
        "do nothing initializer"
        self._index = -1
        self._mytuners = []
        
    def check(self):
        "check the controller (always true)"
        return True
        
class Tuner(object):
    "define a tuner"
    
    def __init__(self, controller, model, serial, port=1):
        """initializer
        
        controller  Controller object, the controller to which this
                      tuner is connected
        model       string, tuner model string, i.e. "MT982B01"
        serial      int, tuner serial number
        
        Keywords:
        -------------------------------
        port        int, the controller port number that the tuner is
                      connected to (either 1 or 2 for most controllers) 
        
        """
        if controller is None:
            controller = NullController()
        else:
            if not isinstance(controller,Controller):
                raise TypeError("`controller` must be an instance of `ats_tuner_control.Controller`")
        
        # get the next available tuner number
        idx = list(range(8))
        for k in _tuners.keys():
            if k in idx:
                del idx[idx.index(k)]
        if not len(idx):
            raise OutOfSpace("no more storage space for tuners - only 8 are allowed")
        self._index = idx[0]
        
        # create the tuner, this can throw a MauryError exception
        _mt993d.add_tuner(self._index,model,serial,controller.index,port)
        
        # register the tuner
        controller._register_tuner(self)
        _tuners[self._index] = self
    
    @property
    def info(self):
        "get the tuner information, returns a mt993d.TunerInfo object"
        if self._index < 0:
            raise ConsistencyError("this tuner has an invalid index")
        return _mt993d.get_tuner_params(self._index)
            
    @property
    def initialized(self):
        "check if this tuner is initialized"
        if self._index < 0:
            raise ConsistencyError("this tuner has an invalid index")
        return bool(_mt993d.get_tuner_init_status(self._index))
        
    def move(self, c, p1, p2):
        "move the tuner to the specified (carriage, probe1, probe2) position"
        if self._index < 0:
            raise ConsistencyError("this tuner has an invalid index")
        _mt993d.move_tuner(self._index,c,p1,p2)
    
    @property
    def position(self):
        "get the tuner's current position as a 3-tuple (carriage, probe1, probe2)"
        return _mt993d.get_tuner_position(self._index)
    
    def __del__(self):
        "special behavior during a delete"
        if self._index > -1:
            _mt993d.delete_tuner(self._index)            
        self._index = -1
    
    @property
    def index(self):
        "get the controller index"
        return self._index
        
        
        
    