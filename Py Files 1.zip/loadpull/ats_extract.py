from __future__ import division, print_function, unicode_literals, absolute_import

import sys

from .ats_parser import MauryFileBase, _maury_date_format, IVCADFile


def extract_lp_file( fname, dataset, extract_condition ):
    """Extract data from a Maury data set (MaurySplFile or MaurySwpFile)
    at a certain condition and then write a Maury load pull data file

    fname                string or open file-like object
    dataset              MaurySplFile or MaurySwpFile object
    extract_condition    dict, passed on as kwargs to the MauryDataBlock.extract() method
                           the dictionary MUST at a minimum contain the 'value' keyword
                           and can also contain any other parameters accepted by the
                           above-named function method
    """
    # validate the extract_condition dictionary
    if 'value' not in extract_condition:
        raise KeyError("`extract_condition` must contain a key for 'value'")
    if 'operator' in extract_condition and extract_condition['operator'] != 'eq':
        raise ValueError("only 'eq' is supported for `extract_condition['operator']`")

    # check the dataset
    freq = dataset.frequency
    if isinstance(freq,list):
        raise ValueError("this function can only support datasets with a single frequency")

    first_block = dataset.flat_data[0]
    column_order = first_block.column_order
    if 'freq' in column_order:
        del column_order[column_order.index('freq')]
    gamma_src = first_block.gamma_src

    # first do the extraction
    if not isinstance(dataset,MauryFileBase):
        raise TypeError('dataset must be a `MauryFileBase`-derived object')
    data = []
    for d in dataset.flat_data:
        x = d.extract(**extract_condition)
        if x:
            for col in column_order:
                if col not in x:
                    raise ValueError("heterogeous data set, columns are not consistent")
            data.append(x)

    if not len(data):
        raise ValueError("dataset extraction step resulted in no usable data")

    if hasattr(fname,'write') and hasattr(fname.write,'__call__'):
        fp = fname
        ac = False
    else:
        fp = open(fname,'w')
        ac = True

    try:
        fp.write('! Load Pull Data file\n')
        fp.write('! \n')
        fp.write('! Date/time %s \n'%dataset.test_date.strftime(_maury_date_format))   # Wed Apr 07 13:58:33 2010
        fp.write('Frequency %8.4f GHz\n'%freq)
        fp.write('number of positions: %3d\n'%len(data))
        fp.write('number of harmonics: %3d\n'%len(gamma_src))
        # write static source gamma
        fp.write('Static Gamma_dut:')
        suffix = ("","_2nd","_3rd","_4th","_5th","_6th","_7th","_8th","_9th","_10th")
        for i,gs in enumerate(gamma_src):
            fp.write(' Source%s = (%.5f %.5f)'%(suffix[i],gs.real,gs.imag))
        fp.write('\n')
        # write the headers
        fp.write('!')
        for h in column_order:
            fp.write(' '+dataset.map_header_to_file(h))
        fp.write('\n')
        # write the blocks
        for block in data:
            # gamma line
            fp.write('Gamma_dut:')
            for gl in block['gamma_ld']:
                fp.write('   %.5f   %.5f'%(gl.real,gl.imag))
            fp.write(' \n')
            # data line
            fp.write('  ')
            for h in column_order:
                fp.write(' %9.5f'%block[h])
            fp.write('\n')
    finally:
        if ac:
            fp.close()

def extract_lp_mdf_file( fname, dataset, extract_condition ):
    """Extract data from a Maury data set (MaurySplFile or MaurySwpFile)
    at a certain condition and then write a loadpull file in MDF format

    fname                string or open file-like object
    dataset              MaurySplFile or MaurySwpFile object
    extract_condition    dict, passed on as kwargs to the MauryDataBlock.extract() method
                           the dictionary MUST at a minimum contain the 'value' keyword
                           and can also contain any other parameters accepted by the
                           above-named function method
    """
    # validate the extract_condition dictionary
    if 'value' not in extract_condition:
        raise KeyError("`extract_condition` must contain a key for 'value'")
    if 'operator' in extract_condition and extract_condition['operator'] != 'eq':
        raise ValueError("only 'eq' is supported for `extract_condition['operator']`")

    # check the dataset
    freq = dataset.frequency
    if isinstance(freq,list):
        raise ValueError("this function can only support datasets with a single frequency")

    first_block = dataset.flat_data[0]
    column_order = first_block.column_order
    if 'freq' in column_order:
        del column_order[column_order.index('freq')]

    # generate the MDF header
    mdfcols = ['dummyindex(int)']
    for i in range(len(first_block.gamma_src)):
        mdfcols.append('gamma_src%d(complex)'%(i+1))
    for i in range(len(first_block.gamma_ld)):
        mdfcols.append('gamma_ld%d(complex)'%(i+1))
    for col in column_order:
        cname = dataset.map_header_to_file(col)
        if cname == 'Eff_%':
            cname = 'Eff'
        mdfcols.append(cname+'(real)')

    mdfheader = '%\t'+('\t'.join(mdfcols))+'\n'

    # first do the extraction
    if not isinstance(dataset,MauryFileBase):
        raise TypeError('dataset must be a `MauryFileBase`-derived object')
    data = []
    for d in dataset.flat_data:
        x = d.extract(**extract_condition)
        if x:
            for col in column_order:
                if col not in x:
                    raise ValueError("heterogeous data set, columns are not consistent")
            data.append(x)

    if not len(data):
        raise ValueError("dataset extraction step resulted in no usable data")

    if hasattr(fname,'write') and hasattr(fname.write,'__call__'):
        fp = fname
        ac = False
    else:
        fp = open(fname,'w')
        ac = True

    try:
        fp.write('! Load Pull Data file\n')
        fp.write('! \n')
        fp.write('! Date/time %s \n'%dataset.test_date.strftime(_maury_date_format))   # Wed Apr 07 13:58:33 2010
        fp.write('! Frequency %8.4f GHz\n'%freq)
        fp.write('! number of positions: %3d\n'%len(data))
        fp.write('! number of source harmonics: %3d\n'%len(first_block.gamma_src))
        fp.write('! number of load harmonics: %3d\n'%len(first_block.gamma_ld))
        fp.write('!\n')
        fp.write('BEGIN loadpull\n')
        fp.write(mdfheader)

        # write the blocks
        for idx,block in enumerate(data):
            outdata = ['%d'%(idx+1)]
            for gs in block['gamma_src']:
                outdata.append('%g'%gs.real)
                outdata.append('%g'%gs.imag)
            for gl in block['gamma_ld']:
                outdata.append('%g'%gl.real)
                outdata.append('%g'%gl.imag)
            for col in column_order:
                outdata.append('%g'%block[col])

            fp.write('\t'.join(outdata)+'\n')

        fp.write('END\n')
    finally:
        if ac:
            fp.close()

def convert_IVCAD_to_mdf(dataset, out_stream=sys.stdout):
    """
    Convert an IVCAD sweep plan file into an MDIF. Assumes a power-sweep plan that potentially sweeps source/load gammas.
    """
    frequencies = dataset._freqlist
    swept_variables = []

    # determine if either of the gammas are swept
    if len(set([tuple(x._gammas) for x in dataset])) > 1:
        swept_variables.append('Source Impedance')

    if len(set([tuple(x._gammal) for x in dataset])) > 1:
        swept_variables.append('Load Impedance')

    swept_variables.append('Input Power')

    print('!IVCAD Sweep Data, converted to MDIF', file=out_stream)
    print('!Original File: {}'.format(dataset.filename), file=out_stream)
    print('!Original Test Time: {}'.format(dataset.test_date), file=out_stream)
    print('!Swept Variables: ', end='', file=out_stream)
    varlist = ''
    for var in swept_variables:
        varlist += '{}, '.format(var)

    print(varlist.rstrip(', '), end='\n\n', file=out_stream)

    for block_idx, block in enumerate(dataset):

        cols = block.swept_columns
        swp_data = [[block._build_data(x, fidx) for x in range(len(block))] for fidx in range(block._harmonics + 1)]

        for fidx, freq in enumerate(frequencies):

            print('VAR IDX(int) = {}'.format(block_idx), file=out_stream)
            print('VAR FREQ(real) = {}'.format(freq), file=out_stream)

            print('BEGIN RAW_ABDATA\n', end='', file=out_stream)

            # print header for this block
            print('%swp_idx(int) '.ljust(26), end='', file=out_stream)
            for column in cols:
                if column in ['a1', 'b1', 'a2', 'b2']:
                    print('{}_real(real)'.format(column).ljust(25), end='', file=out_stream)
                    print('{}_imag(real)'.format(column).ljust(25), end='', file=out_stream)
                else:
                    print('{}(real)'.format(column.replace('%','pct')).ljust(25), end='', file=out_stream)
            print('\n', end='', file=out_stream)

            for row_idx, row in enumerate(zip(*swp_data)):
                print(' {}'.format(row_idx).ljust(26), end='', file=out_stream)
                for col in cols:
                    if col in ['a1', 'b1', 'a2', 'b2']:
                        print('{:<+16e}'.format(row[fidx][col].real).ljust(25), end='', file=out_stream)
                        print('{:<+16e}'.format(row[fidx][col].imag).ljust(25), end='', file=out_stream)
                    else:
                        print('{:<+16e}'.format(row[fidx][col]).ljust(25), end='', file=out_stream)
                print(file=out_stream)

            # end block
            print('END\n\n', end='', file=out_stream)


def convert_IVCAD_to_spl(dataset, out_stream=sys.stdout):
    """
    Convert an IVCAD sweep plan file into a similar ATS .spl file. Assumes a power-sweep plan that potentially sweeps source/load gammas.
    """
    frequencies = dataset._freqlist
    swept_variables = []

    # determine if either of the gammas are swept
    if len(set([tuple(x._gammas) for x in dataset])) > 1:
        swept_variables.append('Source Impedance')

    if len(set([tuple(x._gammal) for x in dataset])) > 1:
        swept_variables.append('Load Impedance')

    swept_variables.append('Input Power')

    print('!IVCAD Sweep Data, converted to Maury ATS .spl format', file=out_stream)
    print('!Original File: {}'.format(dataset.filename), file=out_stream)
    print('!Original Test Time: {}'.format(dataset.test_date), file=out_stream)
    print('!Swept Variables: ', end='', file=out_stream)
    varlist = ''
    for var in swept_variables:
        varlist += '{}, '.format(var)

    print(varlist.rstrip(','), file=out_stream)

    for block_idx, block in enumerate(dataset):

        cols = block.swept_columns
        swp_data = [[block._build_data(x, fidx) for x in range(len(block))] for fidx in range(block._harmonics + 1)]

        for fidx, freq in enumerate(frequencies):

            print('VAR IDX(int) = {}'.format(block_idx), file=out_stream)
            print('VAR FREQ(real) = {}'.format(freq), file=out_stream)

            print('BEGIN RAW_ABDATA\n', end='', file=out_stream)

            # print header for this block
            print('%swp_idx(int) '.ljust(26), end='', file=out_stream)
            for column in cols:
                if column in ['a1', 'b1', 'a2', 'b2']:
                    print('{}_real(real)'.format(column).ljust(25), end='', file=out_stream)
                    print('{}_imag(real)'.format(column).ljust(25), end='', file=out_stream)
                else:
                    print('{}(real)'.format(column.replace('%','pct')).ljust(25), end='', file=out_stream)
            print('\n', end='', file=out_stream)

            for row_idx, row in enumerate(zip(*swp_data)):
                print(' {}'.format(row_idx).ljust(26), end='', file=out_stream)
                for col in cols:
                    if col in ['a1', 'b1', 'a2', 'b2']:
                        print('{:<+16e}'.format(row[fidx][col].real).ljust(25), end='', file=out_stream)
                        print('{:<+16e}'.format(row[fidx][col].imag).ljust(25), end='', file=out_stream)
                    else:
                        print('{:<+16e}'.format(row[fidx][col]).ljust(25), end='', file=out_stream)
                print(file=out_stream)

            # end block
            print('END\n\n', end='', file=out_stream)




if __name__ == '__main__':
    df = IVCADFile('H:\\Documents\\Temp\\AMCAD_1.cst')
    convert_IVCAD_to_mdf(df, None)