import wx
import numpy as np
import os, re

from matplotlib.figure import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg
from matplotlib.lines import Line2D

from maplot import NoMorePages
from maplot.wxgui import WxPlotFrame

_use_drag_drop = False
# do some test here to check for drag and drop capability
# that works correctly and set the above flag to True to
# enable it



class DataBlock:
    "basic storage of a data block"
    
    def __init__(self, section):
        self.section = section
        self.vgs = []
        self.vds = []
        self.igs = []
        self.ids = []
    
    @property
    def empty(self):
        if not self.vgs:
            return True
        return False
    
    

class DownpointData(object):
    "store downpoint data in a convenient class"
    
    __section_patterns = [
        ('dciv',re.compile(r'\!\s*\**\s*dc\s+i-v',re.I)),
        ('transfer',re.compile(r'\!\s*\**\s*transfer\s+i-v',re.I)),
        ('leakage',re.compile(r'\!\s*\**\s*leakage\s+i-v',re.I)),
        ('fwdiv',re.compile(r'\!\s*\**\s*forward\s+i-v',re.I)),    
    ]
    
    __header = u''
    __filename = u''
    __datasets = {}
    
    def __init__(self, fname=None):
        "initializer"
        if fname:
            self.read_file(fname)
        
    def read_file(self, fname):
        "read a data file"
        self.__header = u''
        self.__datasets = {}
        
        if hasattr(fname,'readline') and hasattr(fname.readline,'__call__'):
            ac = False
            fp = fname
            if hasattr(fp,'name'):
                self.__filename = fp.name
            else:
                self.__filename = '<object>'
        else:
            ac = True
            fp = open(fname)
            self.__filename = fname
        
        headlines = []
        header_done = False
        block = None
        current_secname = None
        try:
            for line in fp:
                if line.startswith('!'):
                    # header or section delimiter lines
                    secname = self._section_match(line)
                    if secname:
                        header_done = True
                        current_secname = secname
                    
                    if header_done:
                        headlines.append(line)
                    
                else:
                    # data lines
                    if not header_done:
                        header_done = True
                    
                    try:
                        d = [float(x) for x in line.split()]
                        if len(d) != 4:
                            raise ValueError()
                        
                        if not block:
                            block = DataBlock(current_secname)
                            if current_secname not in self.__datasets:
                                self.__datasets[current_secname] = []
                            self.__datasets[current_secname].append(block)
                        block.vgs.append(d[2])
                        block.vds.append(d[0])
                        block.igs.append(d[3])
                        block.ids.append(d[1])
                    except Exception:
                        if block and not block.empty:
                            block = None
            
        finally:
            if ac:
                fp.close()
        
        self.__header = u''.join(headlines)
    
    def _section_match(self, line):
        "see if the line matches a section heading pattern"
        for sec,pat in self.__section_patterns:
            m = pat.match(line)
            if m:
                return sec
        return None    
    
    def __getitem__(self, key):
        return self.__datasets[key][:]
    
    @property
    def header(self):
        "header data from the file"
        return self.__header
    
    @property
    def filename(self):
        "name of the data file"
        return self.__filename

colorlist = ('#ff0000','#0000ff','#00ff00','#ff00ff')

class DownpointPlotFigure(Figure):
    "figure class for plotting downpoint data"
    
    __plotdata = [
        {'dset':'fwdiv', 'xp':'vgs', 'yp':'igs', 'logy':True, 'yscale':1000.0,
            'xlabel':'Vgs (V)', 'ylabel':'Igs (mA)', 'title':'Forward I-V Curve' },
        {'dset':'dciv', 'xp':'vds', 'yp':'ids', 'logy':False, 'yscale':1000.0,
            'xlabel':'Vds (V)', 'ylabel':'Ids (mA)', 'title':'DC I-V Curve' },
        {'dset':'transfer', 'xp':'vgs', 'yp':'ids', 'logy':False, 'yscale':1000.0,
            'xlabel':'Vgs (V)', 'ylabel':'Ids (mA)', 'title':'Transfer Curve' },
        {'dset':'leakage', 'xp':'vds', 'yp':'igs', 'logy':True, 'yscale':1000.0,
            'xlabel':'Vds (V)', 'ylabel':'Igs (mA)', 'title':'Gate Leakage Curve' },
        ]
            
    def __init__(self, *args, **kwargs):
        "initialize"
        super(DownpointPlotFigure,self).__init__(*args,**kwargs)
        self.__i = 0
        self.__data = []
        
    def add_data(self, d):
        "add data to the plot figure"
        if not isinstance(d,DownpointData):
            raise TypeError("argument must be an instance of `DownpointData`")
        
        if len(self.__data) >= 4:
            raise ValueError("cannot add more data sets (limit = 4)")
        
        self.__data.append(d)
        self._plot()
    
    def clear_data(self):
        "clear all data"
        self.__data = []
        self._plot()

    def init_pages(self, figure):
        "draw the first page"
        self._plot()

    def next_page(self, figure):
        "draw the next page"
        i = self.__i + 1
        if i > 3:
            raise NoMorePages()
        self.__i = i
        self._plot()
        
    def prev_page(self, figure):
        "draw the previous page"
        i = self.__i - 1
        if i < 0:
            raise NoMorePages()
        self.__i = i
        self._plot()
        
    def _plot(self):
        "draw the plot"
        
        p = self.__plotdata[self.__i]
        linewidth = 2

        # clear the figure and re-generate the axes
        # add the data
        self.clf()
        ax = self.add_axes([0.1,0.1,0.8,0.7])
        
        lines, labels = [], []
        for i,d in enumerate(self.__data):
            for bl in d[p['dset']]:
                x = np.array(getattr(bl,p['xp']))
                y = np.array(getattr(bl,p['yp']))*p['yscale']
                if p['logy']:
                    y = np.abs(y)+1.0e-12
                    ax.semilogy(x,y,color=colorlist[i],lw=linewidth,label=d.filename)
                else:
                    ax.plot(x,y,color=colorlist[i],lw=linewidth,label=d.filename)
            lines.append(Line2D((0,0),(0,0),lw=linewidth,c=colorlist[i]))
            labels.append(d.filename)
                
        # add labels
        ax.set_xlabel(p['xlabel'])
        ax.set_ylabel(p['ylabel'])
        ax.set_title(p['title'])
        ax.grid(True)
        
        # add the figure legend
        if len(lines):
            self.legend(lines,labels,loc='upper left')

class DownpointPlotMain(WxPlotFrame):
    "extention of the base plot frame with an updated menu bar"
    
    def __init__(self, *args, **kwargs):
        "initializer"
        
        # init parent
        super(DownpointPlotMain,self).__init__(*args,**kwargs)
        
        # redefine the menubar
        menubar = wx.MenuBar()

        filemenu = wx.Menu()
        
        addmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Add File\tCtrl+A')
        filemenu.AppendItem(addmi)
        clrmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Clear Files\tCtrl+D')
        filemenu.AppendItem(clrmi)
        filemenu.AppendSeparator()
        smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
        filemenu.AppendItem(smi)
        filemenu.AppendSeparator()
        qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(qmi)

        self.Bind(wx.EVT_MENU,self.save_figure,smi)
        self.Bind(wx.EVT_MENU,self.OnQuit,qmi)
        self.Bind(wx.EVT_MENU,self.add_dataset,addmi)
        self.Bind(wx.EVT_MENU,self.clear_datasets,clrmi)

        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)
        
        self.SetSize((800,600))
    
    if _use_drag_drop:
        def add_dataset(self, e):
            "add a dataset using a file browser"
            self._datasetdialog = FileDropDialog(parent=self)
            self._datasetdialog.Show()
            self._datasetdialog.Bind(wx.EVT_CLOSE, self.OnAddDatasetClosed)

        def OnAddDatasetClosed(self, e):
            "called when the dataset drag and drop dialog is closed"
            files = self._datasetdialog.dt.files
            self._datasetdialog.Destroy()
            if files:
                loaded, failed = 0, 0
                for fname in files:
                    try:
                        dset = DownpointData(fname)
                        self.panel.figure.add_data(dset)        
                        loaded += 1
                    except Exception, e:
                        failed += 1
                
                msg = 'loaded %d file(s)'%loaded
                if failed:
                    msg += '; %d files failed'%failed
                self.status_msg(msg)
                self.panel.figure.canvas.draw()
            else:
                self.status_msg('')
                return
            
    else:
        def add_dataset(self, e):
            "add a dataset using a file browser"
            kw = {'style':wx.FD_OPEN,
                'wildcard':"All Files (*.*)|*.*",
                'defaultDir':os.getcwd(),
                }
            dlg = wx.FileDialog(None,'Add Downpoint Data',**kw)
            if dlg.ShowModal() == wx.ID_OK:
            
                fname = dlg.GetPath()
                try:
                    dset = DownpointData(fname)
                except Exception, e:
                    self.error_msg('failed to read file: '+str(e))
                    return 
                
                self.status_msg('loaded: '+fname)
                self.panel.figure.add_data(dset)        
                self.panel.figure.canvas.draw()
            else:
                self.status_msg('')
                return
        
    def clear_datasets(self, e):
        "clear datasets"
        self.panel.figure.clear_data()
        self.panel.figure.canvas.draw()
        
if _use_drag_drop:
    class MyTextDropTarget(wx.TextDropTarget):
        file_names = []

        def __init__(self, object, wd=None):
            super(MyTextDropTarget,self).__init__(self)
            self.object = object
            if not wd:
                wd = os.getcwd()
            self.path = wd
                
        def OnDropText(self, x, y, data):
            self.object.InsertStringItem(0, data)
            self.file_names.append(os.path.join(self.path,data))

        def set_cwd(self,path):
            self.path = path

        @property
        def files(self):
            return self.file_names[:]

    # GenericDirCtrl won't run on Linux, need to create something that extends on TreeCtrl

    class FileDropDialog(wx.Frame):
        def __init__(self, parent=None):
            wx.Frame.__init__(self,parent = parent, title = "Drag and Drop", size = (700,700))

            main_splitter = wx.SplitterWindow(self)
            h_splitter = wx.SplitterWindow(main_splitter)
     
            menubar = wx.MenuBar()

            file_menu = wx.Menu()
            file1 = file_menu.Append(wx.ID_ANY, "Add Datasets...")
            file_menu.AppendSeparator()
            file2 = file_menu.Append(wx.ID_ANY, "Close...")

            self.Bind(wx.EVT_MENU,self.OnAddDatasets,file1)
            self.Bind(wx.EVT_MENU,self.OnClose,file2)

            menubar.Append(file_menu, "File")
            self.SetMenuBar(menubar)

            
            self.dir = wx.GenericDirCtrl(main_splitter, -1, dir=os.getcwd(), style=wx.DIRCTRL_DIR_ONLY, size = (300,500))
            
            self.lc1 = wx.ListCtrl(h_splitter, -1, style=wx.LC_LIST, size = (100,100))
            self.lc2 = wx.ListCtrl(h_splitter, -1, style=wx.LC_LIST, size = (100,100))
            self.dt = MyTextDropTarget(self.lc2)
            self.lc2.SetDropTarget(self.dt)
            wx.EVT_LIST_BEGIN_DRAG(self, self.lc1.GetId(), self.OnDragInit)
            tree = self.dir.GetTreeCtrl()

            h_splitter.SplitHorizontally(self.lc1, self.lc2)
            main_splitter.SplitVertically(self.dir, h_splitter)

            main_sizer = wx.BoxSizer(wx.VERTICAL)
            main_sizer.Add(main_splitter,1, wx.EXPAND)

            wx.EVT_TREE_SEL_CHANGED(self, tree.GetId(), self.OnSelect)
            self.OnSelect(0)
            self.SetSizer(main_sizer)

        def OnSelect(self, event):
            list = os.listdir(self.dir.GetPath())
            self.dt.set_cwd(self.dir.GetPath())
            self.lc1.ClearAll()
            #self.lc2.ClearAll()
            for i in range(len(list)):
                if list[i][0] != '.':
                    self.lc1.InsertStringItem(0, list[i])

        def OnDragInit(self, event):
            self.dt.set_cwd(self.dir.GetPath())
            text = self.lc1.GetItemText(event.GetIndex())
            tdo = wx.PyTextDataObject(text)
            tds = wx.DropSource(self.lc1)
            tds.SetData(tdo)
            tds.DoDragDrop(True)

        def OnAddDatasets(self, event):
            a = self.dt.return_filenames()
            for i in a:
                if type(i) is unicode:
                    datasets.append(i.encode('ascii','ignore'))
                else:
                    datasets.append(i)
            self.Close()

        def OnClose(self, event):
            self.Close()
            
if __name__ == "__main__":
    app = wx.App(redirect=False) 
    frame_1 = DownpointPlotMain(Figure(),None) 
    app.SetTopWindow(frame_1) 
    frame_1.Show() 
    app.MainLoop()       


