# import stuff that is needed from matplotlib
from matplotlib.axes import Axes
import numpy as np

__all__ = ['IVCurveAxes']


class IVCurveAxes(Axes):
    
    def __init__(self, show_legend=False, trace_labels=False, *args, **kwargs):
        """Initializer."""
        
        self._showlegend = show_legend
        self._tracelabels = trace_labels
                
        # initialize the Axes base class
        Axes.__init__(self,*args,**kwargs)
        
        # initialize some stuff
        self._setup_ivaxes()
    
    def _setup_ivaxes(self):
        "setup the axes on creation or after a 'clear'"
        # set the X and Y axis scaling
        self.set_xlim(xmin=0.0,auto=True)
        self.set_ylim(ymin=0.0,auto=True)
    
    def plot(self, *args, **kwargs):
        """Override the plot method to create an I-V curve plot.
        
        Positional arguments can come in groups of 2 or 3 (mixed is OK),
        where the first 2 arguments are the x and y values, and the optional
        third argument is the trace label, which must be a string type
        
        Additional keywords are passed on to the matplotlib.Axes.plot() method         
        
        Returns:
        a list of matplotlib.line.Line2D objects representing the traces of the
        I-V curve
        """
        nargs = len(args)
        if nargs < 2:
            raise ValueError("at least 2 positional arguments must be specified")
        
        # validate trace data
        i = 0
        traces = []
        while i < nargs:
            
            try:
                x = args[i]
                y = args[i+1]            
                if len(x) != len(y):
                    raise ValueError("lengths must match")
                if not np.isnumber(x[0]):
                    raise TypeError("x-values must be numbers")
                if not np.isnumber(y[0]):
                    raise TypeError("y-values must be numbers")
            
            except Exception, e:
                # modify the exception and re-raise it
                
                
                
                raise e
                
            lab = None
            if i+2 < nargs:
                lab = args[i+2]
            
            d = {'x':x, 'y':y}
            if isinstance(lab,basestring):
                d['label'] = lab
                i += 3
            else:
                i += 2
                
            traces.append(d)
            
            
        for t in traces:
            kw = kwargs.copy()
            
            if self._showlegend and 'label' in t:
                kw['label'] = t['label']
                
            # plot the trace
            line_list.append(Axes.plot(self,t['x'],t['y'],**kw))
            
            if self._tracelabels and 'label' in t:
                self.annotate(s=t['label'],xy=())
            
        
        # return the line list
        return line_list
        
    def cla(self):
        """Override the clear method so that the Axes can be reconfigured
        properly after it is cleared.
        """
        # call the underlying clear method
        Axes.cla(self)
        # re-run the setup method
        self._setup_ivaxes()
    clear = cla
    
        
        