

from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Arc
from matplotlib.axes import Axes
from matplotlib.ticker import NullLocator, NullFormatter


class SmithChart(Axes):
    
    def __init__(self, fig, rect, **kwargs):
        """initializer for Smith chart styled plot
        
        """
        super(SmithChart,self).__init__(fig,rect,**kwargs)
        self._setup_smith()
    __init__.__doc__ = Axes.__init__.__doc__
        
    def cla(self):
        super(SmithChart,self).cla()
        # reset things that need to be set
        self._setup_smith_chart()
    cla.__doc__ = Axes.cla.__doc__
    clear = cla
    
    def _setup_smith(self):
        """Internal method to set up the Smith axes."""
        
        super(SmithChart,self).set_autoscale_on(False)
        super(SmithChart,self).set_frame_on(False)
        super(SmithChart,self).set_xlim(-1.0,1.0)
        super(SmithChart,self).set_ylim(-1.0,1.0)
        super(SmithChart,self).grid(False)
        
        
        self.add_patch( Circle((0.0,0.0), 1.0) )
        self.add_patch( Circle((0.5,0.0), 0.5) )
        self.add_patch( Arc((1.0,1.0), 2.0, 2.0, theta1=180.0, theta2=270.0, fill=False) )
        self.add_patch( Arc((1.0,-1.0), 2.0, 2.0, theta1=90.0, theta2=180.0, fill=False) )
        self.add_line( Line2D((-1.0,0.0),(1.0,0.0),color='k',lw=1) )
            
        # turn off all ticks/annotations
        self.xaxis.set_minor_locator(NullLocator())
        self.xaxis.set_major_locator(NullLocator())
        self.xaxis.set_major_formatter(NullFormatter())
        self.yaxis.set_minor_locator(NullLocator())
        self.yaxis.set_major_locator(NullLocator())
        self.yaxis.set_major_formatter(NullFormatter())
    
    def set_xlim(self, **kwargs):
        "override this method so it can't be called"
        return -1.0, 1.0
        
    def set_ylim(self, **kwargs):
        "override this method so it can't be called"
        return -1.0, 1.0
        
    def grid(self, *args, **kwargs):
        "override this method so it can't be called"
        pass
        
    
        
        
        

        
        