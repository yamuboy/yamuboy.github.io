import matplotlib
from matplotlib.figure import Figure
from matplotlib.backend_bases import FigureCanvasBase

class NoMorePages(Exception):
    """exception that should be raised by the next_page()
    and prev_page() methods of a Pager when there are
    no more pages to draw
    """
    pass


class Pager:
    """A pager class that handles changing between pages
    in an interactive plot window session
    
    This class is mostly just a guideline, the same methods
    can be implemented in any class.
    """
    
    def init_pages(self, figure):
        """Pager callback for initializing the pages
        and drawing the first page
        
        figure is the `matplotlib.figure.Figure` instance
        """
        pass
        
    def next_page(self, figure):
        """Pager callback for drawing the next page
        
        figure is the `matplotlib.figure.Figure` instance
        """
        raise NoMorePages()
    
    def prev_page(self, figure):
        """Pager callback for drawing the previous page
        
        figure is the `matplotlib.figure.Figure` instance
        """    
        raise NoMorePages()
    
def plot_gui(figure, pager=None):
    """create a plot GUI using either WxWindows or Tkinter
    depending on which is available
    """
    use_wx = True
    try:
        import wx
        from maplot.wxgui import WxPlotFrame as frame
    except ImportError:
        use_wx = False
        try:
            from maplot.tkgui import TkPlotRoot as frame
        except ImportError:
            raise ImportError("neither 'wxPython' nor 'Tkinter' could be imported - no GUI available")
        
    if use_wx:
        # wx
        app = wx.PySimpleApp()
        root = frame(figure,pager=pager,parent=None,id=wx.ID_ANY,size=(800,600))
        root.Show()
        app.MainLoop()
    else:
        # Tkinter
        root = frame(figure,pager=pager)
        root.mainloop()

def plot_report(figure, pager=None, fname=None, mode=None, **kwargs):
    """generate plots in 'report' format where the plots are written to 1 or more data files"""
    import subprocess
    import os.path
    try:
        from cStringIO import StringIO
    except ImportError:
        from StringIO import StringIO
    
    def _check_psmerge():
        "check that we can call psmerge"
        try:
            subprocess.Popen(['psmerge','--help'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).communicate()
        except OSError:
            raise RuntimeError("unable to run 'psmerge' - this is needed to generate multi-page postscript files")

    def _check_ps2pdf():
        "check that we can call ps2pdf"
        try:
            subprocess.Popen(['ps2pdf','--help'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).communicate()
        except OSError:
            raise RuntimeError("unable to run 'ps2pdf' - this is needed to generate PDF files in older versions of matplotlib")
    
    # check the figure
    if not isinstance(figure,Figure):
        raise TypeError("'figure' must be a `matplotlib.figure.Figure`-derived object")
    
    # set the report mode
    if mode is None:
        if fname:
            # pick out the mode based on the file extension
            ext = os.path.splitext(fname)[1].lstrip('.').lower()
            if ext:
                plotmode = ext
            else:
                plotmode = 'pdf'
        else:
            # default to PDF
            plotmode = 'pdf'
    else:
        plotmode = str(mode).lower().strip('"\'.')
    
    if fname:
        fbase = os.path.splitext(fname)[0]
    else:    
        fname = 'report'
        fbase = fname
    
    
    # verify the pager setup 
    if pager:
        # verify that the has a prev_page and next_page method
        if not hasattr(pager,'prev_page') or not callable(pager.prev_page):
            raise TypeError("The 'pager' must have a callable prev_page method.")
        elif not hasattr(pager,'next_page') or not callable(pager.next_page):
            raise TypeError("The 'pager' must have a callable next_page method.")
        elif not hasattr(pager,'init_pages') or not callable(pager.init_pages):
            raise TypeError("The 'pager' must have a callable init_pages method.")
        
    # initialize the figure
    if pager:
        pager.init_pages(figure)
    elif hasattr(figure,'init_pages') and callable(figure.init_pages):
        figure.init_pages(figure)
    
    # set up the next_page callback
    cb = None
    if pager:
        cb = pager.next_page
    elif hasattr(figure,'next_page') and callable(figure.next_page):
        cb = figure.next_page        
        
    # init the report backend
    savekw = kwargs
    savekw['format'] = plotmode
    pdfpage = None
    ps2pdfmode = False
    psdata = []
    if plotmode in ('bmp','png'):
        # generate a files for each plot using the agg backend
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        canvas = FigureCanvasAgg(figure)
    elif plotmode == 'pdf':
        # generate a single PDF with all data
        try:
            from matplotlib.backends.backend_pdf import FigureCanvasPdf, PdfPages
            canvas = FigureCanvasPdf(figure)
            pdfpage = PdfPages(fbase+'.pdf')
        except ImportError:
            # matplotlib version is too old to support this
            # generate multiple postscript files instead and 
            # convert them to a pdf report
            from matplotlib.backends.backend_ps import FigureCanvasPS
            canvas = FigureCanvasPS(figure)
            savekw['format'] = 'ps'
            ps2pdfmode = True
            _check_psmerge()
            _check_ps2pdf()            
            
    elif plotmode == 'ps':
        # generate a single postscript file with all data
        # this has to be hacked using multiple ps files that
        # are then merged using psmerge
        from matplotlib.backends.backend_ps import FigureCanvasPS
        canvas = FigureCanvasPS(figure)
        _check_psmerge()
        
    else:
        raise ValueError("invalid 'mode' - supported values are 'pdf', 'ps', 'png', and 'bmp'")
    
    # loop through plot pages and generate the report
    inc = 1
    while True:
    
        # determine the save file name
        if plotmode in ('bmp','png'):
            # simple image backend
            savefname = fbase+('%0.4d.'%inc)+plotmode
        elif plotmode == 'ps' or ps2pdfmode:
            # postscript backend (composite file)
            # page data will be stored in a StringIO
            # object and that will be used as an input to psmerge later
            savefname = StringIO()
            psdata.append(savefname)
        elif plotmode == 'pdf':
            # pdf backend (composite file)
            # no need to generate a new file name, just point the
            # file name argument at the PdfPages object
            savefname = pdfpage

        # save the figure
        figure.savefig(savefname,**savekw)
        
        if not cb:
            # only 1 page
            break
        
        # move to the next page until there are no more         
        try:
            cb(figure)        
        except NoMorePages:
            break
            
        inc += 1

    if plotmode == 'ps' or ps2pdfmode:
        # need to merge all of the individual ps files into one composite file
        psname = fbase+'.ps'
        
        # run psmerge
        fp = open(psname,'wb')
        proc = subprocess.Popen(['psmerge'],stdin=subprocess.PIPE,stdout=fp,stderr=subprocess.STDOUT)
        for d in psdata:
            try:
                proc.stdin.write(d.getvalue())
                d.close()
            except IOError, e:
                if e.errno != errno.EPIPE:
                    raise
        proc.stdin.close()
        fp.close()
    elif plotmode == 'pdf':
        # close PDF file
        pdfpage.close()
                
    if ps2pdfmode:
        # convert the postscript report to a pdf report
        import time
        time.sleep(1.0)
        pdfname = fbase+'.pdf'
        subprocess.Popen(['ps2pdf',psname,pdfname]).communicate()

def get_figure_canvas_class( backend ):
    """Get the figure canvas type object for the given matplotlib backend"""
    
    # import the backend module
    modname = 'matplotlib.backends.backend_'+backend.lower()
    m = __import__(modname,globals(),locals(),[modname])
    # try to find a figure canvas that follows the naming convention
    # FigureCanvasXXX, where XXX is the Title case of the backend name
    fcname = 'FigureCanvas'+backend.title()
    if hasattr(m,fcname):
        return getattr(m,fcname)
    
    # default naming did not work, scan the list of exports of the module
    # and search for a type that is derived from FigureCanvasBase but is
    # not the FigureCanvasBase type
    for attr in dir(m):
        try:
            fc = getattr(m,attr)
            if issubclass(fc,FigureCanvasBase) and fc != FigureCanvasBase:
                return fc
        except TypeError:
            pass
            
    # that didn't work, raise an error
    raise ValueError("could not locate the FigureCanvas for backend module '%s'"%backend) 

def create_ni_figure(**kwargs):
    """Create a new Figure object for use in non-interactive plotting
    
    Keywords used by this function
    
    FigureClass - a type object that is used to instatiate the new figure, if
       not specified then this defaults to `matplotlib.figure.Figure`
    
    backend - a string indicating which backend to use, currently this can
       be one of: 'agg' (the default), 'ps', 'pdf', or 'svg'
    
    This function passes all additional keywords on to Figure.__init__(),
    whose help text is copied below:
    
    """
    
    fc = kwargs.pop('FigureClass',Figure)
    if not issubclass(fc,Figure):   
        raise TypeError("'FigureClass' must be a sub-type of `matplotlib.figure.Figure`")
    
    backend = kwargs.pop('backend','agg')
    if backend not in ('pdf','agg','ps','svg'):
        raise ValueError("invalid backend for non-interactive plotting")
    
    cc = get_figure_canvas_class(backend)
    
    # create the figure
    fig = fc(**kwargs)
    # create the canvas
    canvas = cc(fig)
    
    # return the figure, a reference to the canvas is stored automatically
    # in the fig.canvas attribute so there is no need to return the canvas
    # object
    return fig
    
create_ni_figure.__doc__ += Figure.__init__.__doc__
 
        
        


    