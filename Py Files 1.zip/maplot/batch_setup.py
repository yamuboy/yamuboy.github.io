
from maplot import create_ni_figure as create_figure