#
#  A Tk-centric GUI for interactive display of plots
#

from maplot import NoMorePages

# import stuff that is needed from matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  #, NavigationToolbar2TkAgg
import sys, traceback

# tkinter stuff
import Tkinter as tk

# translation table for keys that might be supplied via key_bindings
KEY_TRANSLATION_TABLE = {
    '<RETURN>':'<Return>',
    #### todo: add more
}
        
class TkPlotRoot(tk.Tk):
    """A Tk-based plot GUI that will act as the root window."""
    
    def __init__(self, figure, **kwargs):
        """Initializer.
        
        figure - a `matplotlib.figure.Figure` (or derived class) instance
        
        Keywords:
        ----------------------------------------------
        
        pager - a pager object, this can be a subclass of maplot.Pager, or any object
           that has the methods init_pages(), prev_page(), and next_page().  The figure object
           can also be its own pager if it defines theses methods (this behavior is automatic
           and does not require this keyword to be set)
           
        initcb - a function (or other callable) object that will be called to initialize
           the pages, but only if the 'pager' keyword is not set.
        
        title - a string to use for the window title
        
        """
        
        # verify arguments
        if not isinstance(figure,Figure):
            raise TypeError("'figure' must be a `matplotlib.figure.Figure` (or derived type) object")
            
        # pull keywords that are used by the Tk base class
        kw2 = {}
        for k in ('screenName','baseName','className','useTk','sync','use'):
            if k in kwargs:
                kw2[k] = kwargs.pop(k)
        
        # init the base class 
        tk.Tk.__init__(self,**kw2)
        
        # save the matplotlib figure for later
        self.figure = figure
        
        # get keywords
        self._initcb = kwargs.get('initcb')
        title = kwargs.get('title','TkPlot 0.1')
        self.pager = kwargs.get('pager')
        
        # verify the pager setup 
        if self.pager:
            # verify that the has a prev_page and next_page method
            if not hasattr(self.pager,'prev_page') or not callable(self.pager.prev_page):
                raise TypeError("The 'pager' must have a callable prev_page method.")
            elif not hasattr(self.pager,'next_page') or not callable(self.pager.next_page):
                raise TypeError("The 'pager' must have a callable next_page method.")
            elif not hasattr(self.pager,'init_pages') or not callable(self.pager.init_pages):
                raise TypeError("The 'pager' must have a callable init_pages method.")
            elif not hasattr(self.pager, 'toggle_smith') or not callable(self.pager.toggle_smith):
                raise TypeError("The 'pager' must have a callable toggle_smith method.")
            
        #### set up the window ####                

        # set the window title
        self.title(title)
            
        # create the canvas where matplotlib will draw
        canvas = FigureCanvasTkAgg(figure,master=self)
        #canvas.show()
        canvas.get_tk_widget().pack(side=tk.TOP,fill=tk.BOTH,expand=1)
        
        self.statmsg = tk.StringVar()
        self.statusbar = tk.Label(self,textvariable=self.statmsg,anchor=tk.W,relief=tk.GROOVE)
        self.statusbar.pack(side=tk.BOTTOM,fill=tk.X,ipadx=5,ipady=3)
        
        # this enables a toolbar below
        #self.toolbar = NavigationToolbar2TkAgg(canvas,self)
        #self.toolbar.update()
        
        # create a menu bar
        menubar = tk.Menu(self)
        
        # create a pulldown menu, and add it to the menu bar
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Toggle Smith/Rect S11 & S22", command=self.toggle_smith)
        filemenu.add_command(label="Save As Image...", command=self.save_figure)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=filemenu)
        
        # display the menu
        self.config(menu=menubar)
        
        # bind some keys
        self.bind('<Return>', self.next_page)
        self.bind('<Right>', self.next_page)
        self.bind('<Down>', self.next_page)
        self.bind('<space>', self.next_page)
        self.bind('n', self.next_page)
        self.bind('<Left>', self.prev_page)
        self.bind('<Up>', self.prev_page)
        self.bind('p', self.prev_page)
        self.bind('q', self.quit)
        self.bind('x', self.quit)
        self.bind('s', self.save_figure)
        self.bind('r', self.toggle_smith)

        # connect key bindings defined as part of the pager or figure (when there is no pager)
        self.__bindings = {}
        b = None
        if self.pager:
            if hasattr(self.pager,'key_bindings'):
                b = self.pager.key_bindings
        else:
            if hasattr(figure,'key_bindings'):
                b = figure.key_bindings
        
        if b is not None:
            # check the format of the key bindings data
            if not isinstance(b,(list,tuple)):
                raise TypeError("'key_bindings' must be a list/tuple object")
            for x in b:
                if not isinstance(x,tuple) or len(x) != 2:
                    raise TypeError("'key_bindings' must contain 2-tuples")
                if not isinstance(x[0],str):
                    raise ValueError("in 'key_bindings', the first element of each 2-tuple must be a string")                
                if not callable(x[1]):
                    raise ValueError("in 'key_bindings', the second element of each 2-tuple must be a callable object")
            
            # add key bindings to the array
            for k,f in b:
                if len(k) == 1:
                    key = k.lower()
                else:
                    try:
                        key = KEY_TRANSLATION_TABLE[k.upper()]
                    except Exception:
                        sys.stderr.write("WARNING: key binding for '%s' could not be translated\n"%k)
                        continue
                        
                self.__bindings[key] = f
                
            self.bind(key,self._run_key_binding)
        
        # draw the canvas for the first time
        self.init_pages()
    
    def _run_key_binding(self,event=None):
        "run external key bindings"
        if event is None:
            sys.stderr.write("ERROR: _run_key_bindings(): event is None\n")
            return
        
        if event.char in self.__bindings:
            try:
                r = self.__bindings[event.char](self.figure)
                if isinstance(r,str):
                    self.status_msg(r)
                else:
                    self.status_msg('key binding callback executed')
            except Exception, e:
                self.error_msg("callback failed: %s"%e)
                sys.stderr.write(traceback.format_exc()+'\n')
        else:
            sys.stderr.write("WARNING: could not match binding for keyboard event '%s'\n"%event.char)
    
    def save_figure(self,event=None):
        """Menu entry callback to save the current figure."""
        from tkFileDialog import asksaveasfilename
        filetypes = self.figure.canvas.get_supported_filetypes().copy()
        default_filetype = self.figure.canvas.get_default_filetype()

        # Tk doesn't provide a way to choose a default filetype,
        # so we just have to put it first
        default_filetype_name = filetypes[default_filetype]
        del filetypes[default_filetype]

        sorted_filetypes = filetypes.items()
        sorted_filetypes.sort()
        sorted_filetypes.insert(0, (default_filetype, default_filetype_name))

        tk_filetypes = [(name, '*.%s'%ext) for (ext, name) in sorted_filetypes]

        # adding a default extension seems to break the
        # asksaveasfilename dialog when you choose various save types
        # from the dropdown.  Passing in the empty string seems to
        # work - JDH
        #defaultextension = self.canvas.get_default_filetype()
        defaultextension = ''
        fname = asksaveasfilename(
            master=self,
            title='Save the figure',
            filetypes = tk_filetypes,
            defaultextension = defaultextension
            )

        if fname == "" or fname == ():
            return
        else:
            try:
                # This method will handle the delegation to the correct type
                self.figure.canvas.print_figure(fname)
                self.status_msg("Plot window saved as '%s'"%fname)
            except Exception, e:
                self.error_msg("Error saving file: "+str(e))
            
                
    def quit(self,event=None):
        """Menu entry callback to exit."""
        self.destroy()
        
    def init_pages(self):
        "do the initial page draw"
        if self.pager:
            cb = self.pager.init_pages
        elif self._initcb:
            cb = self._initcb
        elif hasattr(self.figure,'init_pages') and callable(self.figure.init_pages):
            cb = self.figure.init_pages
        else:
            self.figure.canvas.draw()
            return
            
        try:
            txt = cb(self.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except Exception, e:
            self.error_msg('Cannot initialize the first page.')
            return
        
        self.figure.canvas.draw()

    def toggle_smith(self):
        """Toggle between Smith and Rectangular plots"""
        if self.pager:
            pager = self.pager
        elif hasattr(self.panel.figure, 'toggle_smith') and callable(self.panel.figure.toggle_smith):
            pager = self.panel.figure
        else:
            self.error_msg('Unable to change chart type.')
            return
        
        try:
            txt = pager.toggle_smith(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except Exception, e:
            self.error_msg('Unable to change chart type.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
        
        self.panel.figure.canvas.draw()
        
    def prev_page(self, event=None):
        """Go to the previous plot page."""
        if self.pager:
            pager = self.pager
        elif hasattr(self.figure,'prev_page') and callable(self.figure.prev_page):
            pager = self.figure
        else:
            self.error_msg('Cannot go to the previous page.')
            return
            
        try:
            txt = pager.prev_page(self.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except NoMorePages:
            self.status_msg('Already at the first page.')
            return
        except Exception, e:
            self.error_msg('Cannot go to the previous page.')
            return
        
        self.figure.canvas.draw()
        
    def next_page(self, event=None):
        """Go to the next plot page."""
        if self.pager:
            pager = self.pager
        elif hasattr(self.figure,'next_page') and callable(self.figure.next_page):
            pager = self.figure
        else:
            self.error_msg('Cannot go to the next page.')
            return
            
        try:
            txt = pager.next_page(self.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except NoMorePages:
            self.status_msg('Already at the last page.')
            return
        except Exception, e:
            self.error_msg('Cannot go to the next page.')
            return
            
        self.figure.canvas.draw()

            
    def status_msg(self, msg):
        "print a status message to the status bar"
        self.statusbar.config(fg='black')
        self.statmsg.set(msg)
        
    def error_msg(self, msg):
        "print an error message to the status bar"
        self.statusbar.config(fg='red')
        self.statmsg.set(msg)
    
