


class Pager(object):
    """This is a very basic pager class that can be used as an interface
    to a multi-page plot Figure.  The class works by calling the callback
    function/class that is passed to the initializer whenever a page change is
    requested.
    
    It is not necessary to use an explicit pager object, the pager methods can
    simply be added to the Figure-like class that defines the plot window and
    then that object can be passed to the PlotDialog/PlotRoot c-tor as both the
    fig and pager arguments.  This design can actually significantly simplify the
    implementation as all of the page "control" can be kept in one place inside
    of the Figure-like object.
    """
    
    
    def __init__(self, callback, num_pages=-1, **kwargs):
        """
        callback is a function/class/method that implements the page change
          operation.  The callback will be passed a single integer argument
          representing the page number.
        num_pages is an integer defining the number of pages (optional).
        """
        
        if not callable(callback):
            raise TypeError("'callback' argument is not callable")
        
        self.__callback = callback
        self.__i = 0
        self.__numpages = num_pages
        
    def goto_page(self,page):
        """Go to the specified zero-indexed page number."""
        if not isinstance(page,int):
            raise TypeError('The argument must be an integer type.')
        if page < 0 or (self.__numpages > 0 and page >= self.__numpages):
            raise IndexError('Invalid page number.')
        
        # try to go to the page
        if page != self.__i:
            self.__callback(page)
            self.__i = page
    
    def prev_page(self):
        """Go to the previous page."""
        if self.__i <= 0:
            raise StopIteration
        self.__callback(self.__i-1)
        self.__i -= 1
        
    def next_page(self):
        """Go to the next page."""
        if self.__numpages > 0 and self.__i+1 >= self.__numpages:
            raise StopIteration
        self.__callback(self.__i+1)
        self.__i += 1
        
        
