import math
import os.path
import re
import matplotlib.mlab as mlab
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
#import matplotlib.cm as cm
import numpy as np
from loadpull.ats_summary import maury_ats_summary, translate_col

# only export these functions/variables
__all__ = ['LoadPullFigure']

class LoadPullFigure(Figure):
    """matplotlib Figure class for displaying summarized load pull data
    from a maury_ats_summary object.
    
    Rectangular and contour plots can be created.
    """
    
    # keep track of the current plot mode
    plot_mode = None
    
    # map of column names to labels
    _label_map = { 'Pout_dBm':'Pout (dBm)', 'Gt_dB':'Gt (dB)', 'Gp_dB':'Gp (dB)',
        'Iout_mA':'Iout (mA)', 'Iin_mA':'Iin (mA)', 'Eff_%':'Eff (%)',
        'Refl_coef':'Refl Coeff', 'Refl_dB':'Refl Coeff (dB)', 'C_dBm':'Carrier (dBm)',
        'C_2nd':'2nd Harmonic (dBm)', 'C_3rd':'3rd Harmonic (dBm)', 'IP3_dBm':'IP3 (dBm)',
        'IP5_dBm':'IP5 (dBm)', 'I3_dBm':'IM3 (dBm)', 'I5_dBm':'IM5 (dBm)',
        'I7_dBm':'IM7 (dBm)', 'Pin_avail_dBm':'Pin (dBm)', 'Pin_deliv_dBm':'Pdeliv (dBm)',
        }
    
    # column name abbreviations
    _column_abb = {'Pout_dBm':'Po', 'Eff_%':'Eff', 'Gt_dB':'Gt', 'Gp_dB':'Gp',
        'Iout_ma':'Iout', 'Iin_ma':'Iin', 'Refl_dB':'RdB', 'Refl_coef':'R',
        'C_dBm':'C', 'C_2nd':'C2', 'C_3rd':'C3', 'IP3_dBm':'IP3',
        'IP5_dBm':'IP5', 'I3_dBm':'IM3', 'I5_dBm':'IM5', 'I7_dBm':'IM7',
        'Pin_avail_dBm':'Pi', 'Pin_deliv_dBm':'Pdel' }
    
    def __init__(self, **kwargs):
        """Create the figure."""
        Figure.__init__(self, **kwargs)
    
    def _get_label(self, col):
        """Get a 'pretty' representation of a column name for displaying a label."""
        if col in self._label_map:
            return self._label_map[col]
        ct = translate_col(col)
        if ct in self._label_map:
            return self._label_map[ct]
        return col.title()
        
    def _generate_dep_label(self, cols):
        """Generate a label for a dependent data axis that may have more than
        one column present."""
        s = ''
        for c in cols:
            if s: s += ' / '
            s += self._get_label(c)
        return s
    
    def _create_summary_block(self, summary, **kwargs):
        """Create a textual summary block to place beside a plot.
        """
        
        txt = ''
        if self.plot_mode == 'contour':
            # create a summary block with the max (or min)
            # values of the Z-axis parameters at the contouring
            # level
            zcols = _translate_column_list( kwargs.get('zaxis'), ('Pout_dBm',) )
            for c in zcols:
                # create a data set of the data for this column
                z = []
                for d in summary.summary:
                    if d is not None:
                        z.append(d[c])
                
                # create the summary text for this column
                col = translate_col(c)
                if col in ('Refl_dB','Refl_coef'):
                    val = _format_col_data(col,min(z))
                    mnmx = '-min: '
                else:
                    val = _format_col_data(col,max(z))
                    mnmx = '-max: '
                
                # get an abbreviation for the column name
                if col in self._column_abb:
                    colabb = self._column_abb[col]
                else:
                    colabb = c.title()
                    
                txt += colabb + mnmx + ("%s\n" % val)
                
        elif kwargs.get('textsum') is not None:
            domnmx = bool(kwargs.get('textsum_minmax',False))
            
            if summary.best_index < 0 or not summary.best_block:
                # not possible to create a data summary
                return
                
            # rectangular mode, where textsum is set
            if not np.iterable(kwargs['textsum']):
                tsum = (kwargs['textsum'],)
            else:
                tsum = kwargs['textsum']
            
            sumabb = '@cond: '
            # see if we are in compression mode
            # if so then a -XdB summary will be printed
            # otherwise if will be an @cond
            sumcol,cond,val = summary.condition
            if cond in ('comp_gt','comp_gp'):
                if abs(round(val,1)-val) < 0.01:
                    sumabb = "-%.0fdB: " % round(val,1)
                else:
                    sumabb = "-%.1fdB: " % round(val,1)
            
            for c in tsum:
                col = translate_col(c)
                if col not in summary.best_block:
                    # column does not exist in data set
                    continue
                
                # get an abbreviation for the column
                if col in self._column_abb:
                    colabb = self._column_abb[col]
                else:
                    colabb = c.title()
                    
                # create the @condition summary line
                txt += colabb + sumabb + _format_col_data(col,summary.best_block[col]) + "\n"
                
                # create the max (or min, depends on param)
                if domnmx:
                    mxmn = '-max: '
                    findmin = False
                    if col in ('Refl_dB','Refl_coef'):
                        mxmn = '-min: '
                        findmin = True
                    if findmin:
                        val = _format_col_data(col,min(summary.data[summary.best_index][col]))
                    else:
                        val = _format_col_data(col,max(summary.data[summary.best_index][col]))
                    txt += colabb + mxmn + val + "\n"
                
        if len(txt):
            self.text(0.8, 0.2, txt)

    
    def _build_common_labels(self, summary, **kwargs):
        """Create plot labels."""
        
        # create a text summary of the data
        self._create_summary_block(summary,**kwargs)
        
        # create a text summary of the operating point
        oppt = ''
        if 'Vq_out_v' in summary.best_block:
            oppt += 'Vdq: %.1f V\n' % summary.best_block['Vq_out_v']
        elif 'Vout_v' in summary.best_block:
            oppt += 'Vd: %.1f V\n' % summary.best_block['Vout_v'][0]
            
        if 'Vq_in_v' in summary.best_block:
            oppt += 'Vgq: %.1f V\n' % summary.best_block['Vq_in_v']
        elif 'Vin_v' in summary.best_block:
            oppt += 'Vg: %.1f V\n' % summary.best_block['Vin_v'][0]
            
        if 'Iq_out_mA' in summary.best_block:
            oppt += 'Idq: %.1f mA\n' % summary.best_block['Iq_out_mA']
        elif 'Iout_mA' in summary.best_block:
            oppt += 'Id[0]: %.1f mA\n' % summary.best_block['Iout_mA'][0]
        
        if oppt:
            self.text(0.8, 0.5, oppt)
    
    def save_figure(self, filename, **kwargs):
        "save a plot figure"
        self.savefig(self._generate_fname(filename,**kwargs))
    
    def rect_plot(self, summary, **kwargs):
        """Create a rectangular plot of load pull data.
        
        Arguments:
        summary - a maury_ats_summary object that holds the data
        
        Keywords:
        cond_str - a string representation of the summary condition
        y1axis - a string or sequence of strings representing column names of
           data columns to plot on the left Y axis
        y2axis - a string or sequence of strings representing column names of
           data columns to plot on the right Y axis
        output - one of the output file formats supported by the matplotlib
           package, e.g. 'png', 'jpg', 'bmp', etc.
        file_pattern - pattern used to generate the output file name
        linewidth - line width for the plot traces (default=1)
        block_index - force plotting of a specific block of data
        """
        # clear the figure
        self._axes = None
        self._axes2 = None
        self.clf()
        
        # set the plot mode to rectangular plotting
        self.plot_mode = 'rect'
        
        block_num = kwargs.get('block_index',None)
        forced_block = True
        if block_num is None:
            if summary.best_index < 0:
                # uh-oh, need to guess at a block to use, pick block 0
                block_num = 0
            else:
                forced_block = False
                block_num = summary.best_index
        
        # get a pointer to the selected block is valid
        try:
            dp = summary.data[block_num]
        except (KeyError,IndexError):
            raise IndexError("The specified block '%s' does not exist."%block_num)
        
        # get the x-axis data column, default to Pin_avail_dBm
        xcol = translate_col(kwargs.get('xaxis','Pin_avail_dBm'))
        if xcol not in dp:
            raise RuntimeError("X-axis data column '%s' does not appear in the data set."%xcol)
        
        # get lists of columns to plot on the y1/y2 axes
        y1cols = _translate_column_list(kwargs.get('y1axis'))
        y2cols = _translate_column_list(kwargs.get('y2axis'))
        
        # check columns
        if y1cols is None and y2cols is None:
            raise RuntimeError("Nothing to plot: 'y1axis' or 'y2axis' keyword must contain at least 1 column name.")
        
        # create the plot axis, and turn on the grid
        rect = [0.1,0.1,0.6,0.6]
        self._axes = self.add_axes(rect)
        self._axes.grid(True)
        
        # set axis labels
        self._axes.set_xlabel(self._get_label(xcol))
        
        if y1cols:
            self._axes.set_ylabel(self._generate_dep_label(y1cols))
            if y2cols:
                # set up the twin y2-axis to be on the right and label it
                self._axes2 = self._axes.twinx()
                self._axes2.set_ylabel(self._generate_dep_label(y2cols))
        else:
            # y2-axis is the only axis, copy the ax1 variable for convenience
            # and move the Y axis to the right side of the axes
            self._axes2 = self._axes
            self._axes = None
            self._axes2.get_yaxis().set_label_position('right')
            
        # set the trace line width
        linewidth = int(kwargs.get('linewidth',1))
        
        # add traces to the plot
        # the line style is incremented using the variable
        # i as an argument to the line_style() function
        # lines and labels are saved for use later in generating
        # a legend
        lines = []
        labels = []
        i = 0
        xdata = dp[xcol]
        if y1cols is not None:
            for col in y1cols:
                if col not in dp:
                    continue
                y = dp[col]
                if len(xdata) != len(y):
                    raise ValueError("len(data['%s']) != len(data['%s'])"%(xcol,col))
                l = self._axes.plot(xdata, y, _line_style(i), lw=linewidth)
                lines.extend(l)
                labels.append(self._get_label(col))
                i += 1
            
        if y2cols is not None:
            for col in y2cols:
                if col not in dp:
                    continue
                y = dp[col]
                if len(xdata) != len(y):
                    raise ValueError("len(data['%s']) != len(data['%s'])"%(xcol,col))
                l = self._axes2.plot(xdata, y, _line_style(i), lw=linewidth)
                lines.extend(l)
                labels.append(self._get_label(col))
                i += 1
                
        # add a legend
        self.legend(lines, labels, 'upper right')
        
        # create the summary condition string
        cond_str = _condition_string(summary, True)
        
        # add the header
        path,fname_base = _file_name_and_path(summary.filename)
        head = ''
        head += "Path: %s\n" % path
        head += "File: %s\n" % fname_base
        head += "Frequency: %s GHz\n" % summary.data.frequency
        if len(summary.data) > 1:
            if not forced_block:
                head += "Summary metric: %s\n" % cond_str
            head += "Sweep number (starting at 1): %d\n" % (block_num+1)
        head += "Gamma_src: %s  /  %s\n" % (dp["gamma_src"][0], _ma_cplx_str(dp["gamma_src"][0]))
        head += "Gamma_ld: %s  /  %s" % (dp["gamma_ld"][0], _ma_cplx_str(dp["gamma_ld"][0]))
        self.text(0.05, 0.75, head)
        
        # add common labels
        self._build_common_labels(summary, **kwargs)
        
        # save the figure
        self.save_figure(summary.filename, **kwargs)
    
    def contour_plot(self, summary, contour_smith=False, **kwargs):
        """Create a rectangular plot of load pull data.
        
        Arguments:
        summary - a maury_ats_summary object that holds the data
        cond_str - a string that represents the summary condition
        
        Keywords:
        zaxis - a string or sequence of strings representing column names of
           data columns to plot
        output - one of the output file formats supported by the matplotlib
           package, e.g. 'png', 'jpg', 'bmp', etc.
        file_pattern - pattern used to generate the output file name
        linewidth - line width for the plot traces (default=1)
        """
        # clear the figure
        self._axes = None
        self._axes2 = None
        self.clf()
        
        # set the plot mode to contour plotting
        self.plot_mode = 'contour'
    
        # set values for plot parameters
        grid_density = int(kwargs.get('grid_density',30))
        ncontours = int(kwargs.get('ncontours',10))
        linewidth = int(kwargs.get('linewidth',1))
        draw_smith = bool(kwargs.get('smith_axes', False))
        
        zcols = _translate_column_list(kwargs.get('zaxis'), ('Pout_dBm',))
        
        if not zcols:
            raise RuntimeError("There are no data columns to plot.")
        elif len(zcols) > 3:
            raise RuntimeError("A maximum of 3 data columns can be plotted on a contour plot.")
        
        # loop through summary blocks to create x,y data arrays
        x = []
        y = []
        for d in summary.summary:
            if d is not None:
                x.append( d['gamma_ld'][0].real )
                y.append( d['gamma_ld'][0].imag )
        
        if len(x) < 6:
            raise RuntimeError("At least 6 data points are required for contour plots.")
        
        #p.xlim(min(x)-0.05,max(x)+0.05)
        #p.ylim(min(y)-0.05,max(y)+0.05)
        
        # create the x/y grid
        xi = np.linspace(min(x)-0.01,max(x)+0.01,grid_density)
        yi = np.linspace(min(y)-0.01,max(y)+0.01,grid_density)
        
        # create the plot axes
        rect = [0.1,0.1,0.6,0.6]
        if contour_smith:
            from maplot.axes.smith import SmithChartAxes
            self._axes = SmithChartAxes(self,rect)
            self.add_axes(self._axes)
        else:
            self._axes = self.add_axes(rect)
            # turn on the grid
            self._axes.grid(True)
        
        # for each Z data column
        i = 0
        lines = []
        labels = []
        for col in zcols:
            if col not in summary.summary[0]:
                # column does not exist in data set
                continue
            
            # create the data array
            z = []
            maxv = None
            maxi = -1
            j = 0
            for d in summary.summary:
                if d is not None:
                    z.append(d[col])
                    if maxv is None or d[col] > maxv:
                        maxv = d[col]
                        maxi = j
                    j += 1
            
            # z and x should be the same length
            if len(z) != len(x):
                raise RuntimeError("Data size mismatch: code error...")
            
            # grid the Z data
            zi = mlab.griddata(x,y,z,xi,yi)
            
            # create the contour plot
            color = _line_color(i)
            lvls = _contour_levels(z, ncontours)
            cs = self._axes.contour(xi,yi,zi,lvls,linewidth=linewidth,colors=color)
            # cs = ax.contour(xi,yi,zi,ncontours,cmap=cm.jet)
            
            # add contour labels
            self._axes.clabel(cs,fontsize=8)
            
            # save the line and label for creating the legend later
            # need to generate a Line2D to use since the contour data
            # set is not usable as an object to pass to the legend
            lines.append(Line2D((0,0),(0,0),lw=linewidth,c=color,ls='-'))
            labels.append(self._get_label(col))
            
            # highlight the peak point
            if maxi > -1:
                self._axes.scatter([x[maxi]],[y[maxi]],marker='o',color=color,s=18,zorder=10)
            
            i += 1
        
        # create point markers for the x,y coordinates of the data points
        self._axes.scatter(x,y,marker='o',color='k',s=6)
        
        # create x and y labels
        self._axes.set_xlabel("real{Gamma}")
        self._axes.set_ylabel("imag{Gamma}")
        
        # create a legend
        self.legend(lines, labels, 'upper right')
        
        # create the condition string
        cond_str = _condition_string(summary)
        
        # add header text
        path,fname_base = _file_name_and_path(summary.filename)
        head = ''
        head += "Path: %s\n" % path
        head += "File: %s\n" % fname_base
        head += "Frequency: %s GHz\n" % summary.data.frequency
        head += "Contour condition: %s\n" % cond_str
        self.text(0.05, 0.8, head)
        
        # add common labels
        self._build_common_labels(summary, **kwargs)
        
        # save the figure
        self.save_figure(summary.filename, **kwargs)
    
    def _generate_fname(self, filename, **kwargs):
        """Generate a file name for plot output."""
        
        # determine the pattern to use
        pattern = kwargs.get('file_pattern', '%(pathbase)s-%(ext)s%(extra)s')
        if pattern.find('%(newext)s') < 0:
            pattern += '%(newext)s'
        
        # create a dictionary of replacement strings
        repl_dict = dict()
        repl_dict['path'],repl_dict['name'] = os.path.split(filename)
        repl_dict['base'],repl_dict['ext'] = os.path.splitext(repl_dict['name'])
        repl_dict['pathbase'], _ = os.path.splitext(filename)
        repl_dict['mode'] = self.plot_mode
        if len(repl_dict['ext']):
            # remove the leading period from the extension
            repl_dict['ext'] = repl_dict['ext'][1:]
        repl_dict['extra'] = kwargs.get('filename_extra','')
        
        # add the extension for the output type
        repl_dict['newext'] = kwargs.get('output','.png').lower()
        if repl_dict['newext'][0] != '.':
            repl_dict['newext'] = '.' + repl_dict['newext']
        
        # apply the replacements to the pattern string and return the result
        return pattern % repl_dict

### regular expression to match the path part of a file name ###
_path_re = re.compile(r"""^(?:\.{0,2}[/\\]|[A-Za-z]:[/\\])?(?:[^\x00-\x1f\x7f"*/\\:<>?|]*[/\\])*""")
_last_3_path = re.compile(r"""(?:[/\\]+[^\x00-\x1f\x7f"*/\\:<>?|]*){0,3}$""")
_last_2_path = re.compile(r"""(?:[/\\]+[^\x00-\x1f\x7f"*/\\:<>?|]*){0,2}$""")
_last_1_path = re.compile(r"""(?:[/\\]+[^\x00-\x1f\x7f"*/\\:<>?|]*){0,1}$""")
_abs_path_re = re.compile(r"""^(?:[/\\]+|[A-Za-z]:[/\\]+)""")

def _file_name_and_path( fname, max_len=40 ):
    """Determine the file name of the data file and the
    path on the file system.
    """
    path,base = os.path.split(fname)
    if path:
        if _abs_path_re.match(path) is None:
            # the path is relative, append it to the current working directory
            path = os.path.join(os.getcwd(),path)
        # simplify the path
        path = os.path.normpath(path)
    else:
        # the path piece is empty so use the working directory
        path = os.getcwd()
    
    if len(path) < max_len:
        # path is short enough, use the full path
        return path, base
    
    # extract the last 1, 2, or 3 path components
    # depending on the length of the resultant path
    path_end = _last_3_path.search(path).group(0)
    if len(path_end) < max_len:
        return ('...'+path_end,base)
    path_end = _last_2_path.search(path).group(0)
    if len(path_end) < max_len:
        return ('...'+path_end,base)
    path_end = _last_1_path.search(path).group(0)
    return ('...'+path_end,base)

def _dbm_to_watts( x ):
    "Convert dBm to Watts."
    return math.pow(10., x*0.1) * 0.001

def _ma_cplx_str( x ):
    "Format a complex number in mag/angle for display."
    return "(%.3f<%.1f)" % (abs(x),math.degrees(math.atan2(x.imag,x.real))) 

def _line_style( i ):
    """Select a line color and style from a list of line styles."""
    colors = ['r','g','b','c','k','m']
    styles = ['-','--',':','o','D']
    cindex = i % len(colors)
    sindex = int(i / len(colors)) % len(styles)
    return colors[cindex] + styles[sindex]

def _line_color( i ):
    "Select a line color based on an arbitrary index value."
    colors = ['r','g','b','c','k','m']
    cindex = i % len(colors)
    return colors[cindex]

def _iterable(seq):
    "Determine if the input object is an iterable type."
    try:
        iter(seq)
    except TypeError:
        return False
    return True
    
def _translate_column_list(cols, defaults=None):
    """Translate a list of column nicknames to actual column names."""
    if not cols:
        return defaults
    
    if isinstance(cols,str):
        return (translate_col(cols),)
    else:
        cl = []
        for c in cols:
            cl.append(translate_col(c))
        return tuple(cl)
    
def _format_col_data( col, data ):
    """Format data in a print-friendly manner."""
    if col in ('Pout_dBm',):
        # display Pout in watts
        return "%.3f" % round(_dbm_to_watts(data),4)
    elif col in ('Iin_mA','Refl_coef'):
        # round certain columns diffently
        return "%.3f" % round(data,4)
    else:
        return "%.1f" % round(data,2)

def _contour_levels( z, nlevels ):
    """Determine a good set of contour levels."""
    mn = min(z)
    mx = max(z)
    d = mx - mn
    
    def scale_range( val ):
        sf = 1.0
        while val >= 1.0:
            sf *= 0.1
            val *= 0.1
        while val < 0.1:
            sf *= 10.0
            val *= 10.0
        return val,sf
    
    stp = d / nlevels
    sstp,sf = scale_range(stp)
    if sstp < 0.15: nsstp = 0.1
    elif sstp < 0.3: nsstp = 0.2
    elif sstp < 0.45: nsstp = 0.4
    elif sstp < 0.7: nsstp = 0.5
    else: nsstp = 0.8
    
    nstp = nsstp / sf
    
    # find a good starting level
    start = math.ceil( mn * sf * 10.0 ) / (sf * 10.0)
    
    # create contour levels
    x = start
    last_x = start
    V = []
    while x < mx:
        V.append(x)
        last_x = x
        x += nstp
    
    # add one extra contour at the max end if needed
    x = last_x + 0.2*nstp
    if mx - x > 0.2*nstp:
        while mx - x > 0.2*nstp:
            last_x = x
            x += 0.2*nstp
        V.append(last_x)
    
    return V

def _condition_string(summary, rect_mode=False):
    """Create the summary condition string."""
    col,cond,val  = summary.condition
    mnmxstr = 'Max'
    if summary.minimize:
        mnmxstr = 'Min'
    
    s = ''
    if cond == 'at':
        s = "%s == %.3f" % (col,val)
    elif cond == 'at_pin':
        if rect_mode:
            s = "%s '%s' @ " % (mnmxstr,col)
        s += "Pin(dBm) == %.2f" % val
    elif cond == 'at_pout':
        if rect_mode:
            s = "%s '%s' @ " % (mnmxstr,col)
        s += "Pout(dBm) == %.2f" % val
    elif cond.startswith('comp'):
        if rect_mode:
            s = "%s '%s' @ " % (mnmxstr,col)
        gtgp = 'Gt'
        if cond == 'comp_gp': gtgp = 'Gp'
        s += "%.2f dB Comp. (%s)" % (val,gtgp)
    elif cond in ('min','max'):
        s = "%s{%s}" % (cond.title(),col)
    return s

if __name__ == '__main__':
    # trap attempts to run this module directly
    raise RuntimeError("This module should not be invoked directly.")


