#!/usr/bin/env python

# import stuff that is needed from matplotlib
from matplotlib.figure import Figure
from matplotlib.axes import _process_plot_format

from network_params import ParamSet
import numpy as np

_quad_style_keywords = ('mag_ls','mag_color','mag_marker','mag_lw',
    'phase_ls','phase_color','phase_marker','phase_lw')

def _get_styles( **kwargs ):
    """Retrieve style keywords from keyword args."""
    ret = {}
    for kw in _quad_style_keywords:
        if kw in kwargs:
            ret[kw] = kwargs[kw]
    return ret
    
def _get_mag_kwargs( **kwargs ):
    
    for kw in _quad_style_keywords:
        if kw in kwargs:
            if kw.startswith('mag'):
                if kw == 'mag_ls':
                    kwargs['linestyle'] = kwargs['mag_ls']
                elif kw == 'mag_color':
                    kwargs['color'] = kwargs['mag_color']
                elif kw == 'mag_marker':
                    kwargs['marker'] = kwargs['mag_marker']
                elif kw == 'mag_lw':
                    kwargs['linewidth'] = kwargs['mag_lw']
                
            del kwargs[kw]
    
    return kwargs

def _get_phase_kwargs( **kwargs ):
    
    for kw in _quad_style_keywords:
        if kw in kwargs:
            if kw.startswith('phase'):
                if kw == 'phase_ls':
                    kwargs['linestyle'] = kwargs['phase_ls']
                elif kw == 'phase_color':
                    kwargs['color'] = kwargs['phase_color']
                elif kw == 'phase_marker':
                    kwargs['marker'] = kwargs['phase_marker']
                elif kw == 'phase_lw':
                    kwargs['linewidth'] = kwargs['phase_lw']
                
            del kwargs[kw]
    
    return kwargs

import time

class SparamQuadFigure(Figure):
    
    def __init__(self,linear_mode=True,show_phase=True,**kwargs):
        
        # initialize the Figure base class
        Figure.__init__(self,**kwargs)
        
        self.__show_phase = bool(show_phase)
        self.__lin_mode = bool(linear_mode)
        
        # default styles when nothing is specified
        self.__defstyles = {'mag_ls':'-', 'phase_ls':'--', 'mag_color':'red',
            'phase_color':'blue', 'mag_marker':'', 'phase_marker':'',
            'mag_lw':1, 'phase_lw':1 }
        kwstyles = _get_styles(**kwargs)
        if kwstyles:
            # merge the styles specified by keywords into the default values
            self.__defstyles.update(kwstyles)
        
        # build and set up the Axes
        self.__build_axes()
        self.__setup_axes()
        
        self._adjust_plotwin()
        
        
    def _adjust_plotwin(self, event=None):
        'Adjust the positions of subplots to account for figure size.'
        # adjust subplots
        w = self.get_figwidth()
        h = self.get_figheight()
        xmargin = 1.0
        y1margin = 1.0
        y2margin = 2.0
        xcen = 1.5
        ycen = 0.75
        w1 = 1.0 / w
        h1 = 1.0 / h
        wspace = 2.0*xcen / (w - 2.0*xmargin - xcen)
        hspace = 2.0*ycen / (h - y1margin - y2margin - ycen)
        self.subplots_adjust( left=xmargin*w1, right=1.0-xmargin*w1, bottom=y1margin*h1, top=1.0-y2margin*h1, hspace=hspace, wspace=wspace )
        
    def __build_axes(self):
        """Build the axes."""
        # create the subplot axes
        self.mag_axes = [None for i in range(4)]
        self.phase_axes = [None for i in range(4)]
        for i in range(4):
            # mag axes
            self.mag_axes[i] = self.add_subplot(220+i+1)
            # if enabled, create the phase axes
            if self.__show_phase:
                self.phase_axes[i] = self.mag_axes[i].twinx()
    
    def __setup_axes(self):
        """Perform axes setup operations."""
        mag_labels = ('mag(S11)','mag(S12)','mag(S21)','mag(S22)')
        db_labels = ('dB(S11)','dB(S12)','dB(S21)','dB(S22)')
        phase_labels = ('phase(S11)','phase(S12)','phase(S21)','phase(S22)')
        
        if self.__lin_mode: lab = mag_labels
        else: lab = db_labels
        
        for i in range(4):
            self.mag_axes[i].grid(True)
            self.mag_axes[i].set_xlabel('GHz')
            self.mag_axes[i].set_ylabel(lab[i])
            if self.__show_phase:
                self.phase_axes[i].set_ylabel(phase_labels[i])
                # set tick and label locations, since these get lost on clear
                self.phase_axes[i].yaxis.set_label_position('right')
                self.phase_axes[i].yaxis.set_ticks_position('right')
    
    def plot(self,paramset,*args,**kwargs):
        """Clear the axes and then add a new set of S-parameters to the quad plot.
        
        The first argument is a ParamSet-like object containing S-parameters
        (or Y or Z or T ...).
        The optional 2nd positional argument is the magnitude axis composite line style.
        The optional 2nd positional argument is the phase axis composite line style.
        
        Line styles can be more thoroughly defined by using the mag_[ls|marker|color|lw]
        and phase_[ls|marker|color|lw] keywords.
        """
        
        # clear the axes before adding new S-params
        self.clear_all_axes()
        
        # then add the new S-params
        self.addplot(paramset,*args,**kwargs)
        
        
    def addplot(self,paramset,*args,**kwargs):
        """
        Add a new set of S-parameters to the quad plot.
        Existing traces will not be cleared so that more than one set of
        S-parameters can be displayed on the axes.
        """
        
        # verify the arguments
        if not isinstance(paramset,ParamSet):
            raise TypeError('The first argument must be a ParamSet-like object.')
        
        # create keywords to be passed to magnitude and phase axes
        styles = self.__defstyles.copy()
        styles.update(kwargs)
        magkw = _get_mag_kwargs( **styles )
        phakw = _get_phase_kwargs( **styles )
        
        if len(args) > 2:
            raise ValueError('Too many positional arguments were passed.')
        elif len(args) > 1:
            ls = _process_plot_format(args[0])
            if len(ls) == 3:
                magkw['linestyle'],magkw['marker'],magkw['color'] = ls
            else:
                magkw['linestyle'],magkw['color'] = ls
            ls = _process_plot_format(args[1])
            if len(ls) == 3:
                phakw['linestyle'],phakw['marker'],phakw['color'] = ls
            else:
                phakw['linestyle'],phakw['color'] = ls
        elif len(args) > 0:
            ls = _process_plot_format(args[0])
            if len(ls) == 3:
                magkw['linestyle'],magkw['marker'],magkw['color'] = ls
            else:
                magkw['linestyle'],magkw['color'] = ls
        
        # add the new set of S-params to each axes
        for i in range(2):
            for j in range(2):
                self._plot_sparams_axes(2*i+j,paramset.flist*1.0e-9,paramset.param(i,j),magkw,phakw)
        
    def clear_all_axes(self):
        """Clear all S-parameter data from the axes."""
        for i in range(4):
            self.mag_axes[i].cla()
            if self.phase_axes[i]:
                self.phase_axes[i].cla()
        self.__setup_axes()
    
    def clear(self):
        """Clear the figure."""
        for i in range(4):
            mag_axes[i]= None
            phase_axes[i]= None
        Figure.clear(self)
    
    def _plot_sparams_axes(self,i,freq,spars,mag_kwargs,phase_kwargs):
        """Plot the S-parameters of an individual axes."""
        
        # compute and plot the dB/mag
        mag = np.absolute(spars)
        if not self.__lin_mode:
            mag = 20.0 * np.log10(mag)
        self.mag_axes[i].plot(freq,mag,**mag_kwargs)
        
        # compute the phase axis if it is shown
        if self.__show_phase:
            phase = np.arctan2(spars.imag,spars.real) * 180.0 / np.pi
            self.phase_axes[i].plot(freq,phase,**phase_kwargs)
        
