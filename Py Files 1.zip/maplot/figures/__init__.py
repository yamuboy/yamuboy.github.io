
from matplotlib.figure import Figure




class TestFigure(Figure):
    """Test figure for testing the GUI interface"""
    
    def __init__(self,**kwargs):
        
        # init the parent class
        Figure.__init__(self,**kwargs)
            
    def _draw_page(self,i):
        from maplot import NoMorePages
        import numpy as np
        
        if i<0 or i>2:
            # out of range
            raise NoMorePages()
        
        self.clear()
        ax = self.add_axes( [0.1,0.1,0.8,0.8] )
        
        if i == 0:
            x = np.arange(0.0,10.1,0.025)
            y = np.sin(x)
            ax.plot(x,y,'r-')
        elif i == 1:
            x = np.arange(0.0,5.1,0.02)
            y = x*x
            ax.plot(x,y,'m-.')
        elif i == 2:
            x = np.arange(-3.2,2.15,0.01)
            y = np.tanh(x)
            ax.plot(x,y,'b-')
    
    def prev_page(self, figure):
        self._draw_page(self.__i-1)
        self.__i -= 1
        
    def next_page(self, figure):
        self._draw_page(self.__i+1)
        self.__i += 1
        
    def init_pages(self, figure):
        self.__i = 0
        self._draw_page(0)
        
