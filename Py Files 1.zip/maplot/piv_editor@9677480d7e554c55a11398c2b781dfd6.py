"""
wx GUI for editing pulsed I-V data

This can be used via a simple front end consisting of:
----------------------------------------------------------------------------

import wx
from maplot.piv_editor import PivEditorFrame

app = wx.App(redirect=False)
root = PivEditorFrame(size=(800,600))
root.Show()
app.SetTopWindow(root)
app.MainLoop()

"""
from __future__ import unicode_literals, absolute_import, division, print_function
import os, os.path, sys, traceback, six

# import wxPython
import wx

# import stuff that is needed from matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg
import numpy as np

from modeling.piv_files import PIV_Datafile

def _show_error_dialog(msg,title='Error'):
    dlg = wx.MessageDialog(None,msg,title,wx.OK|wx.CENTRE|wx.ICON_ERROR)
    dlg.ShowModal()
    dlg.Destroy()
    
_filter_info_text = """Filtering is done by examining the Gds of each I-V curve to look for discontinuities.
The 'Min Ids', 'Min Vgs', and 'Min/Max Vds' parameters define the region within which
filtering will be applied to the data.  The 'Minimum Allowed Gds' parameter sets the
minimum value that will be considered "normal" when computing point-to-point Gds values
along each I-V curve.  The 'Maximum Saturated Gds' parameter sets the maximum value of
Gds that is considered normal in the saturation region of the I-V plane and is also
used in detection of the knee voltage for each curve.  Abnormal points (those for which
Gds is not within specified limits) will be trimmed from the dataset."""


class FilterParmsDialog(wx.Dialog):
    "dialog for entering filter values for the auto filter function"
    def __init__(self, parms, **kwargs):
        "initializer"
        super(FilterParmsDialog,self).__init__(**kwargs)
                
        self._parms = parms
        sz = wx.BoxSizer(wx.VERTICAL)
        
        # slap in some info text
        infopan = wx.Panel(self,style=wx.SIMPLE_BORDER)
        sz2 = wx.BoxSizer(wx.VERTICAL)
        sz2.Add(wx.StaticText(infopan,wx.ID_ANY,_filter_info_text),0,wx.EXPAND|wx.ALL,5)
        infopan.SetSizer(sz2)
        sz.Add(infopan,0,wx.EXPAND|wx.ALL,5)
                
        self._ctrl = {}
        
        #### add some user input fields ####
        fgsz = wx.FlexGridSizer(cols=2,hgap=10,vgap=6)
        
        # minimum allowed Gds 
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Minimum Allowed Gds (mS)"))
        self._ctrl['min_gds'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['min_gds'].SetValue('%g'%(parms['min_gds']*1000.0))
        fgsz.Add(self._ctrl['min_gds'])
        # maximum linear Gds 
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Maximum Saturated Gds (mS)"))
        self._ctrl['max_linear_gds'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['max_linear_gds'].SetValue('%g'%(parms['max_linear_gds']*1000.0))
        fgsz.Add(self._ctrl['max_linear_gds'])
        # Ids threshold
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Min Ids for filter region (mA)"))
        self._ctrl['id_threshold'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['id_threshold'].SetValue('%g'%(parms['id_threshold']*1000.0))
        fgsz.Add(self._ctrl['id_threshold'])
        # Vgs threshold
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Min Vgs for filter region (V)"))
        self._ctrl['vg_threshold'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['vg_threshold'].SetValue('%g'%parms['vg_threshold'])
        fgsz.Add(self._ctrl['vg_threshold'])
        # Vds threshold
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Min Vds for filter region (V)"))
        self._ctrl['vd_threshold'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['vd_threshold'].SetValue('%g'%parms['vd_threshold'])
        fgsz.Add(self._ctrl['vd_threshold'])
        # Vds max
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Max Vds for filter region (V)"))
        self._ctrl['vd_max'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['vd_max'].SetValue('%g'%parms['vd_max'])
        fgsz.Add(self._ctrl['vd_max'])
        
        sz.Add(fgsz,0,wx.EXPAND|wx.ALL,8)
        
        # add a seperator
        sz.Add(wx.StaticLine(self),0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(self,wx.ID_OK,"Filter")
        cancel = wx.Button(self,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        self.Bind(wx.EVT_BUTTON,self.OnFilter,ok)
        
        self.SetSizer(sz)
        
        self.Fit()
        self.SetTitle("Auto-Filter Data")
        self.Centre()
        
    def OnFilter(self, event=None):
        "callback for clicking the filter button"
        scaling = {'min_gds':0.001, 'max_linear_gds':0.001, 'id_threshold':0.001}
        # read the data from the controls
        errs = []
        for n,c in six.iteritems(self._ctrl):
            sf = 1.0
            if n in scaling:
                sf = scaling[n]
            try:
                self._parms[n] = sf*float(c.GetValue())
            except Exception:
                errs.append('could not convert value for parameter `%s` to float'%n)
        
        if errs:
            _show_error_dialog('\n'.join(errs))
            return
    
        if self.IsModal():
            self.EndModal(wx.ID_OK)
        else:
            self.Destroy()


_extrap_info_text = """Extrapolation of the dataset will interpolate and extend the Vds data of
each curve to a common set of values.  It will then extrapolate Vgs values up 
to the 'Vgs Maximum' specified below.  The gm of the I-V data set will be 
forced to 0 beyond 'Vgs Saturation'.  The 'Saturated Gds' parameter sets the
maximum Gds value that is considered to be in the saturation region of the
I-V data set and is used in detection of the knee to prevent the extrapolation
from blowing up at low Vds values."""


class ExtrapParmsDialog(wx.Dialog):
    "dialog for entering filter values for the auto filter function"
    def __init__(self, parms, **kwargs):
        "initializer"
        super(ExtrapParmsDialog,self).__init__(**kwargs)
                
        self._parms = parms
        sz = wx.BoxSizer(wx.VERTICAL)
        
        # slap in some info text
        infopan = wx.Panel(self,style=wx.SIMPLE_BORDER)
        sz2 = wx.BoxSizer(wx.VERTICAL)
        sz2.Add(wx.StaticText(infopan,wx.ID_ANY,_extrap_info_text),0,wx.EXPAND|wx.ALL,5)
        infopan.SetSizer(sz2)
        sz.Add(infopan,0,wx.EXPAND|wx.ALL,5)
                
        self._ctrl = {}
        
        #### add some user input fields ####
        fgsz = wx.FlexGridSizer(cols=2,hgap=10,vgap=6)
        
        # Vgs saturation value
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Vgs Saturation (V)"))
        self._ctrl['vg_sat'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['vg_sat'].SetValue('%g'%parms['vg_sat'])
        fgsz.Add(self._ctrl['vg_sat'])
        # Vgs maximum
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Vgs Maximum (V)"))
        self._ctrl['vg_max'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['vg_max'].SetValue('%g'%parms['vg_max'])
        fgsz.Add(self._ctrl['vg_max'])
        # linear-to-saturated Gds region cutover  
        fgsz.Add(wx.StaticText(self,wx.ID_ANY,"Saturated Gds (mS)"))
        self._ctrl['gds_linear'] = wx.TextCtrl(self,size=(50,-1))
        self._ctrl['gds_linear'].SetValue('%g'%(parms['gds_linear']*1000.0))
        fgsz.Add(self._ctrl['gds_linear'])
        
        sz.Add(fgsz,0,wx.EXPAND|wx.ALL,8)
        
        # add a seperator
        sz.Add(wx.StaticLine(self),0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(self,wx.ID_OK,"Extrapolate")
        cancel = wx.Button(self,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        self.Bind(wx.EVT_BUTTON,self.OnExtrapolate,ok)
        
        self.SetSizer(sz)
        
        self.Fit()
        self.SetTitle("Extrapolate Data")
        self.Centre()
        
    def OnExtrapolate(self, event=None):
        "callback for clicking the filter button"
        scaling = {'gds_linear':0.001}
        # read the data from the controls
        errs = []
        for n,c in six.iteritems(self._ctrl):
            sf = 1.0
            if n in scaling:
                sf = scaling[n]
            try:
                self._parms[n] = sf*float(c.GetValue())
            except Exception:
                errs.append('could not convert value for parameter `%s` to float'%n)
        
        if errs:
            _show_error_dialog('\n'.join(errs))
            return
    
        if self.IsModal():
            self.EndModal(wx.ID_OK)
        else:
            self.Destroy()
    
            
class PlotPanel(wx.Panel):
    """Plot panel for displaying plots
    
    """
    def __init__( self, parent, **kwargs ):
        "initializer"
        
        # initialize Panel
        if 'id' not in kwargs.keys():
            kwargs['id'] = wx.ID_ANY
        if 'style' not in kwargs.keys():
            kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS
        else:
            kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS 
        super(PlotPanel,self).__init__(parent,**kwargs)
        self.parent = parent
        
        # initialize matplotlib stuff
        self.figure = Figure()
        canvas = FigureCanvasWxAgg(self,-1,self.figure)
        canvas.SetFocus()
        self.axes = self.figure.add_axes([0.1,0.1,0.8,0.8])
        #self.SetColor(color)

        self._SetSize()
        self._resizeflag = False

        self.Bind(wx.EVT_IDLE, self._onIdle)
        self.Bind(wx.EVT_SIZE, self._onSize)
                        
    def _onSize( self, event ):
        "event method for resize"
        self._resizeflag = True

    def _onIdle( self, evt ):
        "event method for idle events"
        if self._resizeflag:
            self._resizeflag = False
            self._SetSize()
        
    def _SetSize( self ):
        "resize the figure image" 
        pixels = tuple(self.parent.GetClientSize())
        self.SetSize(pixels)
        self.figure.canvas.SetSize(pixels)
        self.figure.set_size_inches( float( pixels[0] )/self.figure.get_dpi(),
                                     float( pixels[1] )/self.figure.get_dpi() )
            
    def _SetColor( self, rgbtuple=None ):
        "Set figure and canvas colours to be the same."
        if rgbtuple is None:
            rgbtuple = wx.SystemSettings.GetColour( wx.SYS_COLOUR_BTNFACE ).Get()
        clr = [c/255. for c in rgbtuple]
        self.figure.set_facecolor( clr )
        self.figure.set_edgecolor( clr )
        self.canvas.SetBackgroundColour( wx.Colour( *rgbtuple ) )
        
    def redraw(self):
        "update the plot window"
        self.figure.canvas.draw()
        
                
class PivEditorFrame(wx.Frame):
    """Main frame for holding the WxPIVPlotPanel"""    
    
    def __init__( self, parent=None, *args, **kwargs ):
        "initializer"
    
        title = kwargs.pop('title','PIV Plot 0.1')
        
        #if 'style' not in kwargs:
        #    kwargs['style'] = wx.DEFAULT_FRAME_STYLE | wx.WANTS_CHARS
        #else:
        #    kwargs['style'] |= wx.WANTS_CHARS

        # init the parent
        super(PivEditorFrame,self).__init__(parent,*args,**kwargs)
        
        # create some variables for data storage
        self.pivfile = None
        self.pivplot1 = None
        self.pivplot2 = None
        self._lines = []
        self._filt_parms = dict(min_gds=-0.5e-3, id_threshold=40.0e-3, vg_threshold=-10.0, vd_threshold=0.0,
            max_linear_gds=5.0e-3, vd_max=6.0)
        self._extrap_parms = dict(vg_max=1.8, gds_linear=1.0e-2, vg_sat=1.3)
        self._undo_stack = []
        
        self.SetTitle(title)
        
        # create a status bar
        self.statusbar = self.CreateStatusBar()
        
        # create a menu bar
        menubar = wx.MenuBar()

        filemenu = wx.Menu()
        omi = wx.MenuItem(filemenu, wx.ID_ANY, '&Open PIV File\tCtrl+O')
        filemenu.AppendItem(omi)
        smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save PIV File\tCtrl+S')
        filemenu.AppendItem(smi)
        filemenu.AppendSeparator()
        simi = wx.MenuItem(filemenu, wx.ID_ANY, 'Save &Image\tCtrl+I')
        filemenu.AppendItem(simi)
        filemenu.AppendSeparator()
        qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(qmi)

        self.Bind(wx.EVT_MENU,self.open_pivfile,omi)
        self.Bind(wx.EVT_MENU,self.save_pivfile,smi)
        self.Bind(wx.EVT_MENU,self.save_figure,simi)
        self.Bind(wx.EVT_MENU,self.OnQuit,qmi)

        menubar.Append(filemenu, '&File')
        
        editmenu = wx.Menu()
        self.w_undo = wx.MenuItem(editmenu, wx.ID_ANY, '&Undo\tCtrl+Z')
        editmenu.AppendItem(self.w_undo)
        self.w_undo.Enable(False)
        editmenu.AppendSeparator()
        filtmi = wx.MenuItem(editmenu, wx.ID_ANY, 'Auto &Filter Data\tCtrl+F')
        editmenu.AppendItem(filtmi)
        self.w_manual_removal = wx.MenuItem(editmenu, wx.ID_ANY, 'Enable &Manual Point Removal\tCtrl+M', kind=wx.ITEM_CHECK)
        editmenu.AppendItem(self.w_manual_removal)
        xtrmi = wx.MenuItem(editmenu, wx.ID_ANY, 'E&xtrapolate Data\tCtrl+P')
        editmenu.AppendItem(xtrmi)

        self.Bind(wx.EVT_MENU,self.OnUndo,self.w_undo)
        self.Bind(wx.EVT_MENU,self.filter_data,filtmi)
        self.Bind(wx.EVT_MENU,self.extrapolate,xtrmi)
        
        menubar.Append(editmenu, '&Edit')
        
        self.SetMenuBar(menubar)
        
        # create the panel that holds the matplotlib Figure
        self.plotpanel = PlotPanel(self)
        
        # connect picker events on the canvas
        self.plotpanel.figure.canvas.mpl_connect('pick_event',self._pickercb)
        
        # draw the canvas for the first time
        self.plotpanel.figure.canvas.draw()
        
        # show this Window
        self.Centre()
        self.Show(True)
                    
    def OnQuit(self, e=None):
        "capture quit commands"
        self.Close()
    
    def open_pivfile(self, e=None):
        "set the plot utility to open a static file"
        self.pivfile = None
        self.pivplot1 = None
        self.pivplot2 = None
        self._lines = []
        dlg = wx.FileDialog(self, "Open file", "", "", "All files (*.*)|*.*", wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            fname = os.path.join(dlg.GetDirectory(),dlg.GetFilename())
            try:
                self.pivfile = PIV_Datafile(fname)
                self.pivplot1 = self.pivfile
            except Exception as e:
                self.status_msg(str(e),True)
            
            self._recreate_plot()
        
    def save_pivfile(self, e=None):
        "save a copy of the PIV data file"
        if not self.pivplot1:
            self.status_msg("a file must be opened first",True)
            return
            
        default_file = os.path.splitext(os.path.basename(self.pivfile.filename))[0] + '_mod' 
        dlg = wx.FileDialog(self, "Save to file", "", "",
                            "PIV format (*.piv)|*.piv|Generic MDIF format (*.mdf)|*.mdf",
                            wx.SAVE|wx.OVERWRITE_PROMPT)
        #dlg.SetFilterIndex(0)
        if dlg.ShowModal() == wx.ID_OK:
            dirname  = dlg.GetDirectory()
            filename = dlg.GetFilename()
            format = dlg.GetFilterIndex()
            basename = os.path.splitext(filename)[0]
            if basename == filename:
                # auto append an extension
                if format == 0:
                    ext = '.piv'
                else:
                    ext = '.mdf'
                filename += ext
                
            try:
                fname = os.path.join(dirname,filename)
                if format == 0:
                    self.pivplot1.write_file(fname)
                else:
                    self.pivplot1.write_mdif(fname)
                self.status_msg("Saved file '%s'"%filename)
            except Exception as e:
                self.status_msg(str(e),True)
    
    def save_figure(self,e=None):
        """Menu entry callback to save the current figure."""
        filetypes, exts, filter_index = self.panel.figure.canvas._get_imagesave_wildcards()
        default_file = "image." + self.panel.figure.canvas.get_default_filetype()
        dlg = wx.FileDialog(self, "Save to file", "", default_file,
                            filetypes,
                            wx.SAVE|wx.OVERWRITE_PROMPT)
        dlg.SetFilterIndex(filter_index)
        if dlg.ShowModal() == wx.ID_OK:
            dirname  = dlg.GetDirectory()
            filename = dlg.GetFilename()
            format = exts[dlg.GetFilterIndex()]
            basename, ext = os.path.splitext(filename)
            if ext.startswith('.'):
                ext = ext[1:]
            if ext in ('svg', 'pdf', 'ps', 'eps', 'png') and format!=ext:
                #looks like they forgot to set the image type drop
                #down, going with the extension.
                #warnings.warn('extension %s did not match the selected image type %s; going with %s'%(ext, format, ext), stacklevel=0)
                format = ext
                
            try:
                fname = os.path.join(dirname,filename)
                self.panel.figure.canvas.print_figure(fname,format=format)
                self.status_msg("Saved file '%s'"%fname)
            except Exception as e:
                self.status_msg(str(e),True)
    
    def filter_data(self, e=None):
        "auto-filter the PIV data"
        if not self.pivplot1:
            self.status_msg("a file must be opened first",True)
            return
            
        dlg = FilterParmsDialog(parent=None,parms=self._filt_parms)
        if dlg.ShowModal() != wx.ID_OK:
            dlg.Destroy()
            return
        dlg.Destroy()
        
        try:
            self.pivplot2 = self.pivplot1.clean_data(**self._filt_parms)
        except Exception as e:
            self.status_msg('An error occurred: '+str(e))
            _show_error_dialog('Error: '+str(e))
            return
        self._recreate_plot()
        
        # ask if the data should be kept
        dlg = wx.MessageDialog(None,'Do you want to keep the filtered data set?','Keep Data',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            self._save_undo_data()
            self.pivplot1 = self.pivplot2
            self.pivplot2 = None
        else:
            self.pivplot2 = None
        self._recreate_plot()

    def extrapolate(self, e=None):
        "extrapolate data"
        if not self.pivplot1:
            self.status_msg("a file must be opened first",True)
            return
            
        dlg = ExtrapParmsDialog(parent=None,parms=self._extrap_parms)
        if dlg.ShowModal() != wx.ID_OK:
            dlg.Destroy()
            return
        dlg.Destroy()
        
        try:        
            self.pivplot2 = self.pivplot1.extend_data(**self._extrap_parms)
        except Exception as e:
            self.status_msg('An error occurred: '+str(e))
            _show_error_dialog('Error: '+str(e))
            return
        self._recreate_plot()
        
        # ask if the data should be kept
        dlg = wx.MessageDialog(None,'Do you want to keep the extrapolated data set?','Keep Data',wx.YES_NO|wx.NO_DEFAULT|wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            self._save_undo_data()
            self.pivplot1 = self.pivplot2
            self.pivplot2 = None
        else:
            self.pivplot2 = None
        self._recreate_plot()
        
        
    def _recreate_plot(self):
        "re-create the matplotlib plot figure"
        self.plotpanel.axes.cla()
        self._lines = []
        
        # set the axis labels
        self.plotpanel.axes.set_xlabel('Vds (V)')
        self.plotpanel.axes.set_ylabel('Ids (mA)')
        self.plotpanel.axes.set_title('Pulsed I-V')
        
        if not self.pivplot1:
            self.plotpanel.redraw()
            return


        self.plotpanel.axes.hold(True)
        self.plotpanel.axes.grid(True)
            
        # set some styles as variables to make them easier to use
        plot1kw = {'linestyle':'--', 'linewidth':2, 'color':'#ff0000',
            'marker':'d', 'markeredgecolor':'#ff0000',
            'markerfacecolor':'#ff0000',
            'picker':True, 'pickradius':5.0}
        plot2kw = {'linestyle':'-', 'linewidth':2, 'color':'#0000ff',}
        
        # draw the original pulsed I-V data
        for block in self.pivplot1._rawdata:
            # plot Vd measured vs. Id corrected
            x = [a['vd_m'] for a in block]
            y = [a['id_c'] for a in block]
            self._lines.extend(self.plotpanel.axes.plot(x,y,**plot1kw))
            
        # if there is filtered/extrapolated data, draw that is a different color
        if self.pivplot2:
            for block in self.pivplot2._rawdata:
                # plot Vd measured vs. Id corrected
                x = [a['vd_m'] for a in block]
                y = [a['id_c'] for a in block]
                self.plotpanel.axes.plot(x,y,**plot2kw)
        
        # redraw the plot
        self.plotpanel.redraw()
            
    def _pickercb(self, event):
        "called when picker events are bubbled up from the matplotlib plot"
        if not self.w_manual_removal.IsChecked():
            return
        
        line = event.artist
        try:
            # find the line that generated the event
            i = self._lines.index(line)
            # figure out which point(s) in the line generated the event
            ind = list(event.ind)
            if len(ind) == 1:
                # try to remove the point in question
                n = ind[0]
                dset = self.pivplot1._rawdata[i]
                x, y = dset[n]['vd_m'], dset[n]['id_c']
                if abs(x-event.mouseevent.xdata) < 0.4:
                    self._save_undo_data()
                    del dset[n]
                    self._recreate_plot()
                
        except Exception as e:
            pass
    
    def _save_undo_data(self):
        "save undo data"
        if len(self._undo_stack) >= 10:
            # keep 10 undo operations
            del self._undo_stack[0]
        self._undo_stack.append(self.pivplot1.copy())
        self.w_undo.Enable()
        
    def _clear_undo_data(self):
        "clear undo stack"
        self._undo_stack = []
        self.w_undo.Enable(False)
    
    def OnUndo(self, e=None):
        "handler for an undo operation"
        if not len(self._undo_stack):
            self.status_msg('undo stack is empty',True)
            return
        
        self.pivplot1 = self._undo_stack[-1]
        del self._undo_stack[-1]
        if not len(self._undo_stack):
            # disable undo control
            self.w_undo.Enable(False)
        
        # redraw the plot
        self._recreate_plot()
    
    def status_msg(self, msg, error=False):
        "print a status message to the status bar"
        if error:
            self.statusbar.SetForegroundColour('red')
        else:
            self.statusbar.SetForegroundColour('black')
        self.statusbar.SetStatusText(msg)
        