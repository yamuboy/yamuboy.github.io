#
#  A Tk-centric GUI for interactive display of plots
#

from maplot import NoMorePages

# import wxPython
import wx

# import stuff that is needed from matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg

import os.path
import sys, traceback

# translation table for keys that might be supplied via key_bindings
KEY_TRANSLATION_TABLE = {
    '<RETURN>':wx.WXK_RETURN,
    '<F1>':wx.WXK_F1,
    '<F2>':wx.WXK_F2,
    '<F3>':wx.WXK_F3,
    '<F4>':wx.WXK_F4,
    '<F5>':wx.WXK_F5,
    '<F6>':wx.WXK_F6,
    '<F7>':wx.WXK_F7,
    '<F8>':wx.WXK_F8,
    '<F9>':wx.WXK_F9,
    '<F10>':wx.WXK_F10,
    '<F11>':wx.WXK_F11,
    '<F12>':wx.WXK_F12,
    #### todo: add more
}

class WxPlotPanel(wx.Panel):
    """Plot panel for displaying plots
    
    """
    def __init__( self, figure, parent, dpi=None, **kwargs ):
        "initializer"

        # initialize Panel
        if 'id' not in kwargs.keys():
            kwargs['id'] = wx.ID_ANY
        if 'style' not in kwargs.keys():
            kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS
        else:
            kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS 
        super(WxPlotPanel,self).__init__(parent,**kwargs)
        self.parent = parent
        
        # initialize matplotlib stuff
        self.figure = figure
        canvas = FigureCanvasWxAgg(self,-1,self.figure)
        canvas.SetFocus()
        #self.SetColor(color)

        self._SetSize()

        self._resizeflag = False

        self.Bind(wx.EVT_IDLE, self._onIdle)
        self.Bind(wx.EVT_SIZE, self._onSize)

        
    def _onSize( self, event ):
        self._resizeflag = True

    def _onIdle( self, evt ):
        if self._resizeflag:
            self._resizeflag = False
            self._SetSize()

    def _SetSize( self ):
        pixels = tuple(self.parent.GetClientSize())
        self.SetSize(pixels)
        self.figure.canvas.SetSize(pixels)
        self.figure.set_size_inches( float( pixels[0] )/self.figure.get_dpi(),
                                     float( pixels[1] )/self.figure.get_dpi() )
            
    """
    def SetColor( self, rgbtuple=None ):
        "Set figure and canvas colours to be the same."
        if rgbtuple is None:
            rgbtuple = wx.SystemSettings.GetColour( wx.SYS_COLOUR_BTNFACE ).Get()
        clr = [c/255. for c in rgbtuple]
        self.figure.set_facecolor( clr )
        self.figure.set_edgecolor( clr )
        self.canvas.SetBackgroundColour( wx.Colour( *rgbtuple ) )
    """

        
                
class WxPlotFrame(wx.Frame):
    """Main frame for holding the WxPlotPanel"""
    
    
    def __init__( self, figure, parent=None, *args, **kwargs ):
        "initializer"
    
        self._initcb = kwargs.pop('initcb',None)
        title = kwargs.pop('title','WxPlot 0.1')
        self.pager = kwargs.pop('pager',None)
        
        #if 'style' not in kwargs:
        #    kwargs['style'] = wx.DEFAULT_FRAME_STYLE | wx.WANTS_CHARS
        #else:
        #    kwargs['style'] |= wx.WANTS_CHARS

        # init the parent
        super(WxPlotFrame,self).__init__(parent,*args,**kwargs)
        
        self.SetTitle(title)
        
        # create a status bar
        self.statusbar = self.CreateStatusBar()
        
        # create a menu bar
        menubar = wx.MenuBar()

        filemenu = wx.Menu()
        smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
        filemenu.AppendItem(smi)
        filemenu.AppendSeparator()
        qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(qmi)

        self.Bind(wx.EVT_MENU,self.save_figure,smi)
        self.Bind(wx.EVT_MENU,self.OnQuit,qmi)

        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)
        
        # create the panel that holds the matplotlib Figure
        self.panel = WxPlotPanel(figure,self)

        # verify the pager setup 
        if self.pager:
            # verify that the has a prev_page and next_page method
            if not hasattr(self.pager,'prev_page') or not callable(self.pager.prev_page):
                raise TypeError("The 'pager' must have a callable prev_page method.")
            elif not hasattr(self.pager,'next_page') or not callable(self.pager.next_page):
                raise TypeError("The 'pager' must have a callable next_page method.")
            elif not hasattr(self.pager,'init_pages') or not callable(self.pager.init_pages):
                raise TypeError("The 'pager' must have a callable init_pages method.")
        
        
        # draw the canvas for the first time
        self.init_pages()
        
        # show this Window
        #self.SetSize((350, 250))
        self.Centre()
        self.Show(True)
        
        # connect KeyDown events
        self._connect_keydown(self)
        
        # connect navigation events
        self.Bind(wx.EVT_NAVIGATION_KEY,self.OnNavEvent)
        self.panel.Bind(wx.EVT_NAVIGATION_KEY,self.OnNavEvent)
        
        # connect figure/pager specific events
        self.__bindings = {}
        b = None
        if self.pager:
            if hasattr(self.pager,'key_bindings'):
                b = self.pager.key_bindings
        else:
            if hasattr(figure,'key_bindings'):
                b = figure.key_bindings
        
        if b is not None:
            # check the format of the key bindings data
            if not isinstance(b,(list,tuple)):
                raise TypeError("'key_bindings' must be a list/tuple object")
            for x in b:
                if not isinstance(x,tuple) or len(x) != 2:
                    raise TypeError("'key_bindings' must contain 2-tuples")
                if not isinstance(x[0],str):
                    raise ValueError("in 'key_bindings', the first element of each 2-tuple must be a string")                
                if not callable(x[1]):
                    raise ValueError("in 'key_bindings', the second element of each 2-tuple must be a callable object")
            
            # add key bindings to the array
            for k,f in b:
                if len(k) == 1:
                    key = ord(k.upper())
                else:
                    try:
                        key = KEY_TRANSLATION_TABLE[k.upper()]
                    except Exception:
                        sys.stderr.write("WARNING: key binding for '%s' could not be translated\n"%k)
                        continue
                
                self.__bindings[key] = f
        
    def _connect_keydown(self, w):
        "bind the key down event for all widgets"
        w.Bind(wx.EVT_KEY_DOWN,self.OnKeyEvent)
        # recursively call children
        for w2 in w.GetChildren():
            self._connect_keydown(w2)
        
    def OnKeyEvent(self, e):
        "capture key press events"
        code = e.GetKeyCode()
        if code in (ord('P'),wx.WXK_LEFT,wx.WXK_UP):
            self.prev_page()        
        elif code in (ord('N'),wx.WXK_SPACE,wx.WXK_RIGHT,wx.WXK_DOWN):
            self.next_page()        
        elif code in (ord('Q'),ord('X')):
            self.OnQuit()
        elif code == ord('S'):
            self.save_figure()
        elif code in self.__bindings:
            # call all callback functions for the key binding
            try:
                r = self.__bindings[code](self.panel.figure)
                if isinstance(r,str):
                    self.status_msg(r)
                else:
                    self.status_msg('key binding callback executed')
            except Exception, e:
                self.error_msg("callback failed: %s"%e)
                sys.stderr.write(traceback.format_exc()+'\n')
    
    def OnNavEvent(self, e):
        "capture navigation events"
        if e.IsFromTab():
            e.Skip()
        else:
            if e.GetDirection():
                self.next_page()
            else:
                self.prev_page()
            
    def OnQuit(self, e=None):
        "capture quit commands"
        self.Close()
    
    def init_pages(self):
        "do the initial page draw"
        if self.pager:
            cb = self.pager.init_pages
        elif self._initcb:
            cb = self._initcb
        elif hasattr(self.panel.figure,'init_pages') and callable(self.panel.figure.init_pages):
            cb = self.panel.figure.init_pages
        else:
            self.panel.figure.canvas.draw()
            return
            
        try:
            txt = cb(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except Exception, e:
            self.error_msg('Cannot initialize the first page.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
        
        self.panel.figure.canvas.draw()

    def prev_page(self):
        """Go to the previous plot page."""
        if self.pager:
            pager = self.pager
        elif hasattr(self.panel.figure,'prev_page') and callable(self.panel.figure.prev_page):
            pager = self.panel.figure
        else:
            self.error_msg('Cannot go to the previous page.')
            return
            
        try:
            txt = pager.prev_page(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except NoMorePages:
            self.status_msg('Already at the first page.')
            return
        except Exception, e:
            self.error_msg('Cannot go to the previous page.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
        
        self.panel.figure.canvas.draw()
        
    def next_page(self):
        """Go to the next plot page."""
        if self.pager:
            pager = self.pager
        elif hasattr(self.panel.figure,'next_page') and callable(self.panel.figure.next_page):
            pager = self.panel.figure
        else:
            self.error_msg('Cannot go to the next page.')
            return
            
        try:
            txt = pager.next_page(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except NoMorePages:
            self.status_msg('Already at the last page.')
            return
        except Exception, e:
            self.error_msg('Cannot go to the next page.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
            
        self.panel.figure.canvas.draw()
    
    
    def save_figure(self,e=None):
        """Menu entry callback to save the current figure."""
        filetypes, exts, filter_index = self.panel.figure.canvas._get_imagesave_wildcards()
        default_file = "image." + self.panel.figure.canvas.get_default_filetype()
        dlg = wx.FileDialog(self, "Save to file", "", default_file,
                            filetypes,
                            wx.SAVE|wx.OVERWRITE_PROMPT)
        dlg.SetFilterIndex(filter_index)
        if dlg.ShowModal() == wx.ID_OK:
            dirname  = dlg.GetDirectory()
            filename = dlg.GetFilename()
            format = exts[dlg.GetFilterIndex()]
            basename, ext = os.path.splitext(filename)
            if ext.startswith('.'):
                ext = ext[1:]
            if ext in ('svg', 'pdf', 'ps', 'eps', 'png') and format!=ext:
                #looks like they forgot to set the image type drop
                #down, going with the extension.
                #warnings.warn('extension %s did not match the selected image type %s; going with %s'%(ext, format, ext), stacklevel=0)
                format = ext
                
            try:
                fname = os.path.join(dirname,filename)
                self.panel.figure.canvas.print_figure(fname,format=format)
                self.status_msg("Saved file '%s'"%fname)
            except Exception, e:
                self.error_msg(str(e))
        
    def status_msg(self, msg):
        "print a status message to the status bar"
        self.statusbar.SetForegroundColour('black')
        self.statusbar.SetStatusText(msg)
        
    def error_msg(self, msg):
        "print an error message to the status bar"
        self.statusbar.SetForegroundColour('red')
        self.statusbar.SetStatusText(msg)
                
        
