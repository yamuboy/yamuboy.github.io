# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version Feb  9 2019)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

from .DBCanvas import DBCanvas
import wx
import wx.xrc

###########################################################################
## Class ControlPanel
###########################################################################

class ControlPanel ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		controlSizer = wx.GridBagSizer( 0, 0 )
		controlSizer.SetFlexibleDirection( wx.BOTH )
		controlSizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )


		controlSizer.Add( ( 0, 0 ), wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 6 ), wx.EXPAND, 5 )

		self.standnum_label = wx.StaticText( self, wx.ID_ANY, u"Test Stand ID", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.standnum_label.Wrap( -1 )

		controlSizer.Add( self.standnum_label, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.standnum_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_READONLY )
		controlSizer.Add( self.standnum_text, wx.GBPosition( 1, 1 ), wx.GBSpan( 1, 5 ), wx.ALL|wx.EXPAND, 5 )

		self.foundry_label = wx.StaticText( self, wx.ID_ANY, u"Foundry", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.foundry_label.Wrap( -1 )

		controlSizer.Add( self.foundry_label, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		foundry_comboChoices = []
		self.foundry_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), foundry_comboChoices, wx.CB_READONLY|wx.CB_SORT )
		controlSizer.Add( self.foundry_combo, wx.GBPosition( 2, 1 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 5 )

		self.process_label = wx.StaticText( self, wx.ID_ANY, u"Process", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.process_label.Wrap( -1 )

		controlSizer.Add( self.process_label, wx.GBPosition( 3, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		process_comboChoices = []
		self.process_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, process_comboChoices, wx.CB_READONLY|wx.CB_SORT|wx.TE_PROCESS_ENTER )
		controlSizer.Add( self.process_combo, wx.GBPosition( 3, 1 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 5 )

		self.mask_label = wx.StaticText( self, wx.ID_ANY, u"Mask ID", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.mask_label.Wrap( -1 )

		controlSizer.Add( self.mask_label, wx.GBPosition( 4, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		mask_comboChoices = []
		self.mask_combo = wx.ComboBox( self, wx.ID_ANY, u"2141", wx.DefaultPosition, wx.DefaultSize, mask_comboChoices, wx.CB_READONLY|wx.CB_SORT )
		self.mask_combo.SetSelection( 1 )
		controlSizer.Add( self.mask_combo, wx.GBPosition( 4, 1 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 5 )

		self.dp_temp_label = wx.StaticText( self, wx.ID_ANY, u"DP Temp [°C]", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.dp_temp_label.Wrap( -1 )

		controlSizer.Add( self.dp_temp_label, wx.GBPosition( 5, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.dp_temp_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		self.dp_temp_text.SetMaxLength( 3 )
		controlSizer.Add( self.dp_temp_text, wx.GBPosition( 5, 1 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 5 )

		self.stress_temp_label = wx.StaticText( self, wx.ID_ANY, u"Stress Temp [°C]", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.stress_temp_label.Wrap( -1 )

		controlSizer.Add( self.stress_temp_label, wx.GBPosition( 6, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.stress_temp_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		self.stress_temp_text.SetMaxLength( 3 )
		controlSizer.Add( self.stress_temp_text, wx.GBPosition( 6, 1 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 5 )

		self.lot_label = wx.StaticText( self, wx.ID_ANY, u"Lot #", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lot_label.Wrap( -1 )

		controlSizer.Add( self.lot_label, wx.GBPosition( 2, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.lot_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		self.lot_text.SetMaxLength( 10 )
		controlSizer.Add( self.lot_text, wx.GBPosition( 2, 3 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self.wafernum_label = wx.StaticText( self, wx.ID_ANY, u"Wafer #", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.wafernum_label.Wrap( -1 )

		controlSizer.Add( self.wafernum_label, wx.GBPosition( 3, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.wafernum_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		self.wafernum_text.SetMaxLength( 2 )
		controlSizer.Add( self.wafernum_text, wx.GBPosition( 3, 3 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self.scribe_label = wx.StaticText( self, wx.ID_ANY, u"Scribe Mark", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.scribe_label.Wrap( -1 )

		controlSizer.Add( self.scribe_label, wx.GBPosition( 4, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.scribe_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		controlSizer.Add( self.scribe_text, wx.GBPosition( 4, 3 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self.periphery_label = wx.StaticText( self, wx.ID_ANY, u"NGF x\nUGW [µm]", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.periphery_label.Wrap( -1 )

		controlSizer.Add( self.periphery_label, wx.GBPosition( 5, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.fingernum_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 65,-1 ), wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		self.fingernum_text.SetMaxLength( 2 )
		controlSizer.Add( self.fingernum_text, wx.GBPosition( 5, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALL, 5 )

		self.x_label = wx.StaticText( self, wx.ID_ANY, u"x", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.x_label.Wrap( -1 )

		controlSizer.Add( self.x_label, wx.GBPosition( 5, 4 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALL, 1 )

		self.fingerwidth_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		self.fingerwidth_text.SetMaxLength( 3 )
		controlSizer.Add( self.fingerwidth_text, wx.GBPosition( 5, 5 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALL, 5 )

		self.device_label = wx.StaticText( self, wx.ID_ANY, u"Device", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.device_label.Wrap( -1 )

		controlSizer.Add( self.device_label, wx.GBPosition( 6, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.device_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER|wx.TE_RIGHT )
		controlSizer.Add( self.device_text, wx.GBPosition( 6, 3 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self.experimental_cbox = wx.CheckBox( self, wx.ID_ANY, u"Experimental", wx.DefaultPosition, wx.DefaultSize, 0 )
		controlSizer.Add( self.experimental_cbox, wx.GBPosition( 7, 1 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER|wx.ALL, 1 )

		self.multisite_cbox = wx.CheckBox( self, wx.ID_ANY, u"Multi-site", wx.DefaultPosition, wx.DefaultSize, 0 )
		controlSizer.Add( self.multisite_cbox, wx.GBPosition( 7, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER|wx.ALL, 1 )

		self.param_button = wx.Button( self, wx.ID_ANY, u"Test Parameters", wx.DefaultPosition, wx.DefaultSize, 0 )
		controlSizer.Add( self.param_button, wx.GBPosition( 8, 0 ), wx.GBSpan( 1, 6 ), wx.ALL|wx.EXPAND, 1 )

		self.stress_button = wx.Button( self, wx.ID_ANY, u"Begin Stress Test", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.stress_button.SetForegroundColour( wx.Colour( 255, 0, 0 ) )

		controlSizer.Add( self.stress_button, wx.GBPosition( 9, 0 ), wx.GBSpan( 1, 2 ), wx.ALL|wx.EXPAND, 1 )

		self.downpoint_button = wx.Button( self, wx.ID_ANY, u"Begin Downpoint Test", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.downpoint_button.SetForegroundColour( wx.Colour( 0, 128, 255 ) )

		controlSizer.Add( self.downpoint_button, wx.GBPosition( 9, 2 ), wx.GBSpan( 1, 4 ), wx.ALL|wx.EXPAND, 1 )


		controlSizer.Add( ( 0, 0 ), wx.GBPosition( 10, 0 ), wx.GBSpan( 1, 6 ), wx.EXPAND, 0 )


		controlSizer.AddGrowableCol( 1 )
		controlSizer.AddGrowableRow( 0 )
		controlSizer.AddGrowableRow( 10 )

		self.SetSizer( controlSizer )
		self.Layout()
		controlSizer.Fit( self )

		# Connect Events
		self.foundry_combo.Bind( wx.EVT_COMBOBOX, self.onFoundry )
		self.process_combo.Bind( wx.EVT_COMBOBOX, self.onProcess )
		self.mask_combo.Bind( wx.EVT_COMBOBOX, self.onMaskID )
		self.dp_temp_text.Bind( wx.EVT_TEXT, self.onModify )
		self.dp_temp_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.stress_temp_text.Bind( wx.EVT_TEXT, self.onModify )
		self.stress_temp_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.lot_text.Bind( wx.EVT_TEXT, self.onModify )
		self.lot_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.wafernum_text.Bind( wx.EVT_TEXT, self.onModify )
		self.wafernum_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.scribe_text.Bind( wx.EVT_TEXT, self.onModify )
		self.scribe_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.fingernum_text.Bind( wx.EVT_TEXT, self.onModify )
		self.fingernum_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.fingerwidth_text.Bind( wx.EVT_TEXT, self.onModify )
		self.fingerwidth_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.device_text.Bind( wx.EVT_TEXT, self.onModify )
		self.device_text.Bind( wx.EVT_TEXT_ENTER, self.onModify )
		self.experimental_cbox.Bind( wx.EVT_CHECKBOX, self.onModify )
		self.multisite_cbox.Bind( wx.EVT_CHECKBOX, self.onModify )
		self.param_button.Bind( wx.EVT_BUTTON, self.onParamButton )
		self.stress_button.Bind( wx.EVT_BUTTON, self.onStressButton )
		self.downpoint_button.Bind( wx.EVT_BUTTON, self.onDownpointButton )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onFoundry( self, event ):
		event.Skip()

	def onProcess( self, event ):
		event.Skip()

	def onMaskID( self, event ):
		event.Skip()

	def onModify( self, event ):
		event.Skip()


















	def onParamButton( self, event ):
		event.Skip()

	def onStressButton( self, event ):
		event.Skip()

	def onDownpointButton( self, event ):
		event.Skip()


###########################################################################
## Class LogPanel
###########################################################################

class LogPanel ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		logSizer = wx.GridSizer( 0, 1, 0, 0 )

		self.log_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_LEFT|wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_RICH2 )
		self.log_text.SetMinSize( wx.Size( 600,-1 ) )

		logSizer.Add( self.log_text, 0, wx.ALL|wx.EXPAND, 1 )


		self.SetSizer( logSizer )
		self.Layout()
		logSizer.Fit( self )

	def __del__( self ):
		pass


###########################################################################
## Class MapPanel
###########################################################################

class MapPanel ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		mapSizer = wx.GridBagSizer( 0, 0 )
		mapSizer.SetFlexibleDirection( wx.VERTICAL )
		mapSizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )


		mapSizer.Add( ( 0, 0 ), wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 0 )

		self.canvas_panel = DBCanvas( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self.canvas_panel.SetMinSize( wx.Size( 600,600 ) )

		mapSizer.Add( self.canvas_panel, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.SHAPED, 0 )


		mapSizer.Add( ( 0, 0 ), wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 0 )


		mapSizer.AddGrowableCol( 0 )
		mapSizer.AddGrowableRow( 0 )
		mapSizer.AddGrowableRow( 2 )

		self.SetSizer( mapSizer )
		self.Layout()
		mapSizer.Fit( self )

		# Connect Events
		self.canvas_panel.Bind( wx.EVT_LEFT_UP, self.onLClick )
		self.canvas_panel.Bind( wx.EVT_RIGHT_UP, self.onRClick )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onLClick( self, event ):
		event.Skip()

	def onRClick( self, event ):
		event.Skip()


###########################################################################
## Class PlotPanel
###########################################################################

class PlotPanel ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		plotSizer = wx.BoxSizer( wx.VERTICAL )

		self.plotNotebook = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.downpointPanel = wx.Panel( self.plotNotebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		downpointSizer = wx.GridBagSizer( 0, 0 )
		downpointSizer.SetFlexibleDirection( wx.BOTH )
		downpointSizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )


		downpointSizer.AddGrowableCol( 0 )
		downpointSizer.AddGrowableRow( 0 )

		self.downpointPanel.SetSizer( downpointSizer )
		self.downpointPanel.Layout()
		downpointSizer.Fit( self.downpointPanel )
		self.plotNotebook.AddPage( self.downpointPanel, u"Downpoint (Live)", False )
		self.stressPanel = wx.Panel( self.plotNotebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		stressSizer = wx.GridBagSizer( 0, 0 )
		stressSizer.SetFlexibleDirection( wx.BOTH )
		stressSizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )


		stressSizer.AddGrowableCol( 0 )
		stressSizer.AddGrowableRow( 0 )

		self.stressPanel.SetSizer( stressSizer )
		self.stressPanel.Layout()
		stressSizer.Fit( self.stressPanel )
		self.plotNotebook.AddPage( self.stressPanel, u"Stress (Live)", False )

		plotSizer.Add( self.plotNotebook, 1, wx.EXPAND |wx.ALL, 5 )


		self.SetSizer( plotSizer )
		self.Layout()
		plotSizer.Fit( self )

	def __del__( self ):
		pass


###########################################################################
## Class TestControlDialog
###########################################################################

class TestControlDialog ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.STAY_ON_TOP )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		stressCtrlSizer = wx.StaticBoxSizer( wx.StaticBox( self, wx.ID_ANY, u"Test Control" ), wx.VERTICAL )

		stCtlSizer = wx.GridBagSizer( 0, 0 )
		stCtlSizer.SetFlexibleDirection( wx.BOTH )
		stCtlSizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )


		stCtlSizer.Add( ( 0, 0 ), wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 5 ), wx.EXPAND, 0 )

		self.pauseA_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Pause A", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.pauseA_button.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, wx.EmptyString ) )
		self.pauseA_button.SetForegroundColour( wx.Colour( 255, 128, 0 ) )

		stCtlSizer.Add( self.pauseA_button, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.pauseB_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Pause B", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.pauseB_button.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, wx.EmptyString ) )
		self.pauseB_button.SetForegroundColour( wx.Colour( 255, 128, 0 ) )

		stCtlSizer.Add( self.pauseB_button, wx.GBPosition( 1, 1 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.pauseC_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Pause C", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.pauseC_button.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, wx.EmptyString ) )
		self.pauseC_button.SetForegroundColour( wx.Colour( 255, 128, 0 ) )

		stCtlSizer.Add( self.pauseC_button, wx.GBPosition( 1, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.pauseD_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Pause D", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.pauseD_button.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, wx.EmptyString ) )
		self.pauseD_button.SetForegroundColour( wx.Colour( 255, 128, 0 ) )

		stCtlSizer.Add( self.pauseD_button, wx.GBPosition( 1, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.pause_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Pause Test", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.pause_button.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, wx.EmptyString ) )
		self.pause_button.SetForegroundColour( wx.Colour( 255, 128, 0 ) )

		stCtlSizer.Add( self.pause_button, wx.GBPosition( 1, 4 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.abortA_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Abort A", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.abortA_button.SetForegroundColour( wx.Colour( 255, 0, 0 ) )

		stCtlSizer.Add( self.abortA_button, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.abortB_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Abort B", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.abortB_button.SetForegroundColour( wx.Colour( 255, 0, 0 ) )

		stCtlSizer.Add( self.abortB_button, wx.GBPosition( 2, 1 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.abortC_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Abort C", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.abortC_button.SetForegroundColour( wx.Colour( 255, 0, 0 ) )

		stCtlSizer.Add( self.abortC_button, wx.GBPosition( 2, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.abortD_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Abort D", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.abortD_button.SetForegroundColour( wx.Colour( 255, 0, 0 ) )

		stCtlSizer.Add( self.abortD_button, wx.GBPosition( 2, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 1 )

		self.abort_button = wx.Button( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Abort Test", wx.DefaultPosition, wx.Size( 90,-1 ), 0 )
		self.abort_button.SetForegroundColour( wx.Colour( 255, 0, 0 ) )

		stCtlSizer.Add( self.abort_button, wx.GBPosition( 2, 4 ), wx.GBSpan( 1, 1 ), wx.ALIGN_RIGHT|wx.ALL, 1 )

		self.sites_title_label = wx.StaticText( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Site(s) Under Test:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.sites_title_label.Wrap( -1 )

		self.sites_title_label.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD, False, wx.EmptyString ) )

		stCtlSizer.Add( self.sites_title_label, wx.GBPosition( 3, 0 ), wx.GBSpan( 1, 5 ), wx.ALL, 1 )

		self.sites_label = wx.StaticText( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"A: (x, y), B: (x, y), C: (x, y), D: (x, y)", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_HORIZONTAL )
		self.sites_label.Wrap( -1 )

		stCtlSizer.Add( self.sites_label, wx.GBPosition( 4, 0 ), wx.GBSpan( 1, 5 ), wx.ALL|wx.EXPAND, 5 )

		self.detail_title_label = wx.StaticText( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Detailed Status:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.detail_title_label.Wrap( -1 )

		self.detail_title_label.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD, False, wx.EmptyString ) )

		stCtlSizer.Add( self.detail_title_label, wx.GBPosition( 5, 0 ), wx.GBSpan( 1, 1 ), wx.ALL, 1 )

		self.detail_label = wx.StaticText( stressCtrlSizer.GetStaticBox(), wx.ID_ANY, u"Site       | Vg [V]  | Ig [mA]  | Vd [V]  | Id [mA]  | Elapsed  | Remaining\nA (xx, yy) | -12.123 | -123.123 | -12.123 | -123.123 | 00:00:00 | 00:00:00\nB (xx, yy) | -12.123 | -123.123 | -12.123 | -123.123 | 00:00:00 | 00:00:00\nC (xx, yy) | -12.123 | -123.123 | -12.123 | -123.123 | 00:00:00 | 00:00:00\nD (xx, yy) | -12.123 | -123.123 | -12.123 | -123.123 | 00:00:00 | 00:00:00", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self.detail_label.Wrap( -1 )

		self.detail_label.SetFont( wx.Font( wx.NORMAL_FONT.GetPointSize(), wx.FONTFAMILY_MODERN, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, wx.EmptyString ) )

		stCtlSizer.Add( self.detail_label, wx.GBPosition( 6, 0 ), wx.GBSpan( 1, 5 ), wx.ALIGN_CENTER_VERTICAL|wx.ALL, 1 )


		stCtlSizer.Add( ( 0, 0 ), wx.GBPosition( 7, 0 ), wx.GBSpan( 1, 5 ), wx.EXPAND, 0 )


		stCtlSizer.AddGrowableCol( 1 )
		stCtlSizer.AddGrowableRow( 0 )
		stCtlSizer.AddGrowableRow( 7 )

		stressCtrlSizer.Add( stCtlSizer, 1, wx.ALIGN_CENTER|wx.EXPAND, 1 )


		self.SetSizer( stressCtrlSizer )
		self.Layout()
		stressCtrlSizer.Fit( self )

		self.Centre( wx.BOTH )

		# Connect Events
		self.pauseA_button.Bind( wx.EVT_BUTTON, self.onPauseResume )
		self.pauseB_button.Bind( wx.EVT_BUTTON, self.onPauseResume )
		self.pauseC_button.Bind( wx.EVT_BUTTON, self.onPauseResume )
		self.pauseD_button.Bind( wx.EVT_BUTTON, self.onPauseResume )
		self.pause_button.Bind( wx.EVT_BUTTON, self.onPauseResume )
		self.abortA_button.Bind( wx.EVT_BUTTON, self.onAbort )
		self.abortB_button.Bind( wx.EVT_BUTTON, self.onAbort )
		self.abortC_button.Bind( wx.EVT_BUTTON, self.onAbort )
		self.abortD_button.Bind( wx.EVT_BUTTON, self.onAbort )
		self.abort_button.Bind( wx.EVT_BUTTON, self.onAbort )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onPauseResume( self, event ):
		event.Skip()





	def onAbort( self, event ):
		event.Skip()






