import csv

from macomplot.canvases.dcstress import DCStressCanvas

class HammerGUIStressPlotCanvas(DCStressCanvas):

    def __init__(self, parent, **kwargs):
        "initializer"
        super(HammerGUIStressPlotCanvas, self).__init__(parent, **kwargs)

        self.file_filter = 'Hammer Stress Files (*.hammerst)|*.hammerst|{0}'.format(self.file_filter)

        self.redraw_plot_figure()

    # override read plot file to handle new format of HammerGUI in-situ files
    def read_plot_file(self, fname, extra_data={}):
        "read data from file"

        # Sample lines from .csv from hammer file below
        # !,"Rapid DC Stress Test"
        # !,"Test Date:",2018/02/12 17:56:03
        #
        # !,"Test Configuration"
        # !,"foundry","MACOM","Foundry"
        # (... ... ...)
        # !,"stress_target_id_tolerance_dec_ma","2","Target Ids Tolerance [mA decimal places]"
        #
        # !,"Data (stress)"
        # "Timestamp","Igate","Idrain","Site (x, y)","4","3"
        # "2018/02/12 17:56:05","0.0119687576813","0.0171210216274"
        # "2018/02/12 17:56:07","0.0198365778495","0.0241879493974"
        # (... ... ...)

        rows = []
        with open(fname, 'rb') as fp:
            try:
                reader = csv.reader(fp)

                # load file contents into memory
                for row in reader:
                    rows.append(row)

            except Exception as e:
                raise RuntimeError('Error reading file {}'.format(fname))

        time, igate, idrain = [], [], []
        site = None
        data = False

        for row in rows:

            # skip empty rows
            if not row:
                continue

            # skip commented lines
            if row[0] == '!':
                continue

            # found header, set data flag and get site name
            elif row[0] == 'Timestamp':
                data = True

                site = '{:2d}, {:2d}'.format(int(row[4]), int(row[5]))

                continue

            # collecting data
            elif data:
                time.append(row[0])                     # get timestamp as string formatted as '%Y/%m/%d %H:%M:%S'
                igate.append(abs(float(row[1]))*1e6)    # get gate current and convert to uA
                idrain.append(float(row[2])*1e3)        # get drain current and convert to mA

            # ignore any other rows
            else:
                pass

        times = self.abs_to_elapsed(time)
        data = (times, igate, idrain)

        # generate a new data dictionary for newly-created files
        if not extra_data:

            # generate a new style for the current file
            self.style_gen.next_style()

            pfile_data = {}
            pfile_data['data'] = data
            pfile_data['enabled'] = True
            pfile_data['width'] = 1.0
            pfile_data['color'] = self.style_gen.current_color
            pfile_data['ltype'] = self.style_gen.current_linetype
            pfile_data['marker'] = self.style_gen.current_marker
            pfile_data['name'] = site

        else:
            if not extra_data['name']:
                extra_data['name'] = site
            extra_data['data'] = data
            pfile_data = extra_data

        return pfile_data

    def redraw_plot_figure(self):
        super(HammerGUIStressPlotCanvas, self).redraw_plot_figure()
        self.draw_idle()
