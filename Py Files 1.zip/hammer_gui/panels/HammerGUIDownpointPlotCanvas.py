from macomplot import PlotlibCanvasBase
from matplotlib import lines

import csv
import macomplot.styles as styles
import os.path
import re

_pre_color = styles.LineColor.LtBlue
_post_color = styles.LineColor.LtRed
_comp_color = styles.LineColor.DkPurple
_marker_style = styles.MarkerType.circle
_pre_x_val = 0.0
_post_x_val = 1.0
_droop_x_val = 2.375
_imax_title = '$I_{MAX}$'
_imax_droop_title = '$I_{MAX}$ and Droop'
_dvg_title = 'Pinch-off Shift'

class HammerGUIDownpointPlotCanvas(PlotlibCanvasBase):

    def __init__(self, parent, **kwargs):
        "initializer"
        # init parent, use the default matplotlib.Figure class
        if 'figure_kwargs' not in kwargs:
            kwargs['figure_kwargs'] = {}
        kwargs['figure_kwargs']['facecolor'] = 'white'
        super(HammerGUIDownpointPlotCanvas,self).__init__(parent,**kwargs)

        # create the plot axes
        self.ax_diode = self.figure.add_axes([0.1, 0.6, 0.225, 0.35])
        self.ax_txfr = self.figure.add_axes([0.3875, 0.6, 0.225, 0.35])
        self.ax_leak = self.figure.add_axes([0.675, 0.6, 0.225, 0.35])
        self.ax_dvg = self.figure.add_axes([0.1, 0.1, 0.225, 0.35])
        self.ax_ron = self.figure.add_axes([0.3875, 0.1, 0.225, 0.35])
        self.ax_imax = self.figure.add_axes([0.675, 0.1, 0.225, 0.35])
        self.ax_droop = self.ax_imax.twinx()

        color1 = styles._colorLUT(_pre_color)
        color2 = styles._colorLUT(_post_color)
        ltype = styles._ltypeLUT(styles.LineType.Solid)
        marker = styles._markerLUT(_marker_style)
        line1 = lines.Line2D([0.0, 1.0], [0.0, 0.0], linewidth=1.0, linestyle=ltype, color=color1, marker=marker)
        line2 = lines.Line2D([0.0, 1.0], [0.0, 0.0], linewidth=1.0, linestyle=ltype, color=color2, marker=marker)
        self.legend = self.figure.legend([line1, line2], ['Pre', 'Post'], ncol=2, loc='upper right')
        self.legend.draggable(True)

        self._initialize_axes()

        self.file_filter = 'Hammer Downpoint Files (*.hammerdp)|*.hammerdp|{0}'.format(self.file_filter)

        self.redraw_plot_figure()

    def _initialize_axes(self):
        all_axes = [self.ax_diode, self.ax_txfr, self.ax_leak, self.ax_dvg, self.ax_ron, self.ax_imax, self.ax_droop]

        # clear the axes
        for ax in all_axes:
            ax.cla()
            ax.autoscale(False, axis='both')

        # set up diode graph
        self.ax_diode.set_title('Diode Curve')
        self.ax_diode.set_yscale('log')
        self.ax_diode.set_xlim(left=0.0, right=2.0)
        self.ax_diode.set_ylim(bottom=1e-4, top=1.0)
        self.ax_diode.set_xlabel('Forward Diode Voltage [V]')
        self.ax_diode.set_ylabel('Gate Current [mA/mm]')
        self.ax_diode.grid(b=False, which='minor', axis='x')
        self.ax_diode.grid(b=True, which='major', axis='x')
        self.ax_diode.grid(b=True, which='both', axis='y')

        # set up transfer graph
        self.ax_txfr.set_title('Transver Curve')
        self.ax_txfr.set_xlim(left=-2.0, right=0.0)
        self.ax_txfr.set_ylim(bottom=0.0, top=400.0)
        self.ax_txfr.set_xlabel('Gate Voltage [V]')
        self.ax_txfr.set_ylabel('Drain Current [mA/mm]')
        self.ax_txfr.grid(b=False, which='minor', axis='x')
        self.ax_txfr.grid(b=True, which='major', axis='x')
        self.ax_txfr.grid(b=True, which='both', axis='y')

        # set up leakage graph
        self.ax_leak.set_title('Leakage Currents')
        self.ax_leak.set_yscale('log')
        self.ax_leak.set_xlim(left=-0.5, right=5.5)
        self.ax_leak.set_ylim(bottom=1e-4, top=10.0)
        self.ax_leak.set_ylabel('Leakage Currents [mA/mm]')
        self.ax_leak.set_xticks([-0.5, 1.5, 3.5, 5.5])
        self.ax_leak.set_xticks([0.5, 2.5, 4.5], minor=True)
        self.ax_leak.set_xticklabels(['$I_D$', '$|I_G|$', '$|I_S|$'], minor=True)
        self.ax_leak.tick_params(axis='x', which='major', labelbottom='off', bottom='off')
        self.ax_leak.tick_params(axis='x', which='minor', labelbottom='on', bottom='on')
        self.ax_leak.grid(b=False, which='minor', axis='x')
        self.ax_leak.grid(b=True, which='major', axis='x')
        self.ax_leak.grid(b=True, which='both', axis='y')

        # set up imax/droop graph
        self.ax_imax.set_title(_imax_droop_title)
        self.ax_imax.set_xlim(left=-0.5, right=3)
        self.ax_imax.set_ylim(bottom=200.0, top=1000.0)
        self.ax_imax.set_ylabel('Drain Current [mA/mm]')
        self.ax_imax.set_xticks([-0.5, 1.75, 3])
        self.ax_imax.set_xticks([_droop_x_val], minor=True)
        self.ax_imax.set_xticklabels(['Droop ($\\frac{Post}{Pre}$)'], minor=True)
        self.ax_imax.tick_params(axis='x', which='minor', labelbottom='on', bottom='off')
        self.ax_imax.tick_params(axis='x', which='major', labelbottom='off', bottom='off')
        self.ax_imax.grid(b=False, which='minor', axis='x')
        self.ax_imax.grid(b=True, which='major', axis='x')
        self.ax_imax.grid(b=True, which='both', axis='y')

        self.ax_droop.set_ylim(bottom=80.0, top=120.0)
        self.ax_droop.set_ylabel('Delta $I_{MAX}$ [%]')

        # set up ron graph
        self.ax_ron.set_title('On Resistance')
        self.ax_ron.set_xlim(left=-0.5, right=1.5)
        self.ax_ron.set_ylim(bottom=3.0, top=8.0)
        self.ax_ron.set_ylabel(u'$R_{on}$ [$\Omega$-mm]')
        self.ax_ron.set_xticks([0.5])
        self.ax_ron.set_xticks([_pre_x_val, _post_x_val], minor=True)
        self.ax_ron.tick_params(axis='x', which='both', labelbottom='off', bottom='off')
        self.ax_ron.grid(b=False, which='both', axis='x')
        self.ax_ron.grid(b=True, which='both', axis='y')

        # set up pinch-off shift graph
        self.ax_dvg.set_title(_dvg_title)
        self.ax_dvg.set_xlim(left=-0.5, right=0.5)
        self.ax_dvg.set_ylim(bottom=0.0, top=400.0)
        self.ax_dvg.set_xlabel('Gate Voltage Delta (Post - Pre) [V]')
        self.ax_dvg.set_ylabel('Drain Current [mA/mm]')
        self.ax_dvg.grid(b=False, which='minor', axis='x')
        self.ax_dvg.grid(b=True, which='major', axis='x')
        self.ax_dvg.grid(b=True, which='both', axis='y')

    def read_plot_file(self, fname, extra_data={}):
        "read data from file"

        # Sample lines  from .dat file below
        # !,"Rapid DC Stress Test"
        # !,"Test Date:",2018/02/14 18:10:06
        #
        # !,"Test Configuration"
        # !,"foundry","MACOM","Foundry"
        # (... ... ...)
        # !,"stress_target_id_tolerance_dec_ma","2","Target Ids Tolerance [mA decimal places]"
        #
        # !,"Data (downpoint0)"
        # "Site (x, y)","3","3"
        # "dvg0","0.000677022522315"
        # "dig0","6e-07"
        # "dvg1","0.000726299808531"
        # "dig1","6e-06"
        # "dvg2","0.000336020479371"
        # "dig2","6e-05"
        # "imax","1.04933903219"
        # "ron","952.980847297"
        # "tvg0","-3.00625"
        # "tid0","0.317874842957"
        # "tvg1","-3.03125"
        # "tid1","0.107595475801"
        # "tvg2","-3.05625"
        # "tid2","0.558723640946"
        # "leakig","1.10891024743"
        # "leakid","0.560920012861"
        # "leakis","1.66983026029"

        # reinitialize all axes when a new file is added
        self._initialize_axes()

        rows = []
        with open(fname, 'rb') as fp:
            try:
                reader = csv.reader(fp)

                # load file contents into memory
                for row in reader:
                    rows.append(row)

            except Exception as e:
                raise RuntimeError('Error reading file {}'.format(fname))

        data_dict = {}

        site = None
        level = None
        data = False

        for row in rows:

            # skip empty rows
            if not row:
                continue

            # get test level from header
            elif 'downpoint0' in row[1]:
                level = 0

            elif 'downpoint1' in row[1]:
                level = 1

            # skip all other commented lines
            elif row[0] == '!':
                continue

            # found header, set data flag and get site name
            elif row[0] == 'Site (x, y)':
                data = True

                site = '{:2d}, {:2d}'.format(int(row[1]), int(row[2]))

                continue

            # collecting data
            elif data:
                data_dict[row[0]] = float(row[1])

            # ignore any other rows
            else:
                pass

        # generate a new data dictionary for newly-created files
        if data:
            if not extra_data:
                pfile_data = {}
                pfile_data['data'] = data_dict
                pfile_data['enabled'] = True
                pfile_data['level'] = level
                pfile_data['name'] = site

            else:
                if not extra_data['name']:
                    extra_data['name'] = site
                extra_data['data'] = data_dict
                pfile_data = extra_data
        else:
            pfile_data = {}

        return pfile_data

    def get_plot_options(self):
        """get plot options

        This should be a dictionary of PlotOption objects
        """
        return self._options

    def set_plot_options(self, options):
        """set plot options

        This will be a dictionary of values
        """
        self.redraw_plot_figure()

    def get_plot_scale_data(self):
        "get scale data"
        return self._scaledata

    def set_plot_scale_data(self, scale_data):
        "set scale data"
        self.redraw_plot_figure()

    def get_trace_list_data(self):
        """
        Generate data used to populate the modify traces dialog

        Returns a list of dictionaries that contain the following keys:
            'enabled'   - bool indicating whether the trace is plotted or not
            'name'      - string indicating the name of the data trace (defaults to the filename and an additional identifier if needed)
            'path'      - string indicating the absolute path of the source file
            'width'     - float indicating the width of the trace
            'color'     - LineColor enum indicating the color of the trace
            'ltype'     - LineType enum indicating the line type of the trace
            'marker'    - MarkerType enum indicating the marker type of the trace
        """
        pfiles_data = []

        for pfile in self.plot_files:
            d = pfile.data if isinstance(pfile.data, dict) else {}
            d['path'] = pfile.fpath

            pfiles_data.append(d)

        return pfiles_data

    def set_trace_list_data(self, trace_data):
        """
        Update trace data based on user input in the modify traces dialog

        See 'get_trace_list_data()' for a description of the format for 'trace_data'
        """

        new_list = [ ]
        new_paths = [x['path'] for x in trace_data]

        for pfile in self.plot_files:
            if pfile.data is None:
                continue

            # only add files that still exist in the new trace data to the new list
            if pfile.data['path'] in new_paths:

                idx = new_paths.index(pfile.data['path'])

                pfile.data['enabled'] = trace_data[idx]['enabled']
                pfile.data['name'] = trace_data[idx]['name']

                new_list.append(pfile)

        self.plot_files = new_list
        self.redraw_plot_figure()

    def redraw_plot_figure(self):
        "redraw the plot figure"

        ax_diode = self.ax_diode
        ax_txfr = self.ax_txfr
        ax_leak = self.ax_leak
        ax_dvg = self.ax_dvg
        ax_ron = self.ax_ron
        ax_imax = self.ax_imax
        ax_droop = self.ax_droop

        if not len(self.plot_files):
            # nothing to draw on the axes
            return

        # organize data into dictionary keyed by site names
        # each value is a 2-tuple where the 0th entry is the pre-dp, and 1st entry is a post_dp
        # assumes at most only one pre- and one post-dp submitted per site
        # keep track of if a comparison between post/pre is possible, if not then disable comparison graphs
        sites = {}
        pre_data = False
        post_data = False
        for pfile in self.plot_files:

            # skip files with no data
            if not pfile.data:
                continue

            name = pfile.data['name']
            level = pfile.data['level']

            # if current site doesn't already exist, create list
            if name not in sites:
                sites[name] = [None, None]

            # set pre-/post- data flags
            if level and not post_data:
                post_data = True
            elif not level and not pre_data:
                pre_data = True

            # add data to site
            sites[name][level] = pfile.data['data']

        # disable comparison graphs if only one type of data
        if not (pre_data and post_data):
            self.ax_droop.axis('off')
            self.ax_imax.set_title(_imax_title)

            self.ax_dvg.axis('off')
            self.ax_dvg.set_title('')
        else:
            self.ax_droop.axis('on')
            self.ax_imax.set_title(_imax_droop_title)
            self.ax_dvg.axis('on')
            self.ax_dvg.set_title(_dvg_title)

        # iterate over sites and add lines/points to plots

        kw = {  
                'lw'        : 1,
                'marker'    : styles._markerLUT(_marker_style),
                'linestyle' : styles._ltypeLUT(styles.LineType.Solid),                
            }
        for site_name, site_data in sites.iteritems():
            pre_data, post_data = site_data[0], site_data[1]

            if pre_data:
                diode_pre_x = [pre_data['dvg0'], pre_data['dvg1'], pre_data['dvg2']]
                diode_pre_y =[pre_data['dig0'], pre_data['dig1'], pre_data['dig2']]
                txfr_pre_x = [pre_data['tvg0'], pre_data['tvg1'], pre_data['tvg2']]
                txfr_pre_y = [pre_data['tid0'], pre_data['tid1'], pre_data['tid2']]
                imax_pre = pre_data['imax']
                ron_pre = pre_data['ron']
                leakid_pre = pre_data['leakid']
                leakig_pre = pre_data['leakig']
                leakis_pre = pre_data['leakis']

                kw.update({'color': styles._colorLUT(_pre_color), 'label': '{} Pre'.format(site_name)})
                self.ax_diode.add_line(lines.Line2D(diode_pre_x, diode_pre_y, **kw))
                self.ax_txfr.add_line(lines.Line2D(txfr_pre_x, txfr_pre_y, **kw))
                self.ax_imax.scatter([_pre_x_val], [imax_pre], **kw)
                self.ax_ron.scatter([_pre_x_val], [ron_pre], **kw)
                self.ax_leak.scatter([_pre_x_val], [leakid_pre], **kw)
                self.ax_leak.scatter([_pre_x_val + 2.0], [leakig_pre], **kw)
                self.ax_leak.scatter([_pre_x_val + 4.0], [leakis_pre], **kw)
            
            if post_data:
                diode_post_x = [post_data['dvg0'], post_data['dvg1'], post_data['dvg2']]
                diode_post_y = [post_data['dig0'], post_data['dig1'], post_data['dig2']]
                txfr_post_x = [post_data['tvg0'], post_data['tvg1'], post_data['tvg2']]
                txfr_post_y = [post_data['tid0'], post_data['tid1'], post_data['tid2']]
                imax_post = post_data['imax']
                ron_post = post_data['ron']
                leakid_post = post_data['leakid']
                leakig_post = post_data['leakig']
                leakis_post = post_data['leakis']

                kw.update({'color': styles._colorLUT(_post_color), 'label': '{} Post'.format(site_name)})
                self.ax_diode.add_line(lines.Line2D(diode_post_x, diode_post_y, **kw))
                self.ax_txfr.add_line(lines.Line2D(txfr_post_x, txfr_post_y, **kw))
                self.ax_imax.scatter([_post_x_val], [imax_post], **kw)
                self.ax_ron.scatter([_post_x_val], [ron_post], **kw)
                self.ax_leak.scatter([_post_x_val], [leakid_post], **kw)
                self.ax_leak.scatter([_post_x_val + 2.0], [leakig_post], **kw)
                self.ax_leak.scatter([_post_x_val + 4.0], [leakis_post], **kw)

            if pre_data and post_data:
                droop = imax_post/imax_pre*100
                dvg_x = [x2 - x1 for x1, x2 in zip(txfr_pre_x, txfr_post_x)]
                dvg_y = txfr_post_y

                kw.update({'color': styles._colorLUT(_comp_color), 'label': '{} Delta'.format(site_name)})
                self.ax_droop.scatter([_droop_x_val], [droop], **kw)
                self.ax_dvg.scatter(dvg_x, dvg_y, **kw)

        self.draw_idle()