from __future__ import print_function

import os
import re
import sys
import traceback
import math

from gdsiitools import Library, Text, Boundary
from mautils import cli_utils

_re_mask_id = re.compile(r'(\d\d\d\d).+\.gds')
_re_dimension = re.compile(r'[^\d]*(\d+)\s*by\s*(\d+)[^\d]*')

def wafermap_from_gds(gds_fname):
    "gets wafermap information for MACOM fab GDS files"

    # get mask id from filename
    fname = os.path.basename(gds_fname)
    mask_id = _re_mask_id.search(fname).group(1)

    # open GDS file
    lib = Library.load(gds_fname)

    # find map1 structure
    map1 = lib.get_structure_by_name('{}map1'.format(mask_id))

    # get dimensions
    xdim, ydim = _dimension_from_lib(map1)

    # get list of full reticles
    ret_list = _reticles_from_lib(map1)

    _print_info(fname, mask_id, xdim, ydim, ret_list)

    # prompt to check if x/y need to be swapped
    _prompt_str = 'Do X/Y coordinates need to be swapped? (GDS file may have flat on bottom) [yN]: '
    result = raw_input(_prompt_str)

    while result.strip().upper() not in ['', 'N']:
        print('Flipping X/Y coordinates')
        xdim, ydim = ydim, xdim
        ret_list = zip(*ret_list)
        _print_info(fname, mask_id, xdim, ydim, ret_list)
        result = raw_input(_prompt_str)

    # prompt to check if any reticles need to be toggled
    _prompt_str = 'Enter any reticles (in form "X Y") that need to be toggled, or just press Enter to continue: '
    result = raw_input(_prompt_str)

    while result.strip() != '':
        toggle_site = re.match('^.*(\d+)\s+(\d+).*$', result.strip())
        if toggle_site:
            x = int(toggle_site.group(1)) - 1
            y = int(toggle_site.group(2)) - 1
            if x in range(len(ret_list)) and y in range(len(ret_list[0])):
                ret_list[x][y] = not ret_list[x][y]
            else:
                print('Invalid entry ({:2d}, {:2d})'.format(x + 1, y + 1))
        else:
            print('Invalid entry ({:2d}, {:2d})'.format(x + 1, y + 1))
        _print_info(fname, mask_id, xdim, ydim, ret_list)
        result = raw_input(_prompt_str)

    _prompt_str = 'Enter the coefficient of expansion for the X direction in um/degC [0.0]: '
    result = raw_input(_prompt_str)
    try:
        alpha_x = float(result)
    except:
        print('Unable to parse value, setting it to 0.0 and continuing!')
        alpha_x = 0.0

    _prompt_str = 'Enter the coefficient of expansion for the Y direction in um/degC [0.0]: '
    result = raw_input(_prompt_str)
    try:
        alpha_y = float(result)
    except:
        print('Unable to parse value, setting it to 0.0 and continuing!')
        alpha_y = 0.0

    _write_to_map(mask_id, xdim, ydim, alpha_x, alpha_y, ret_list)
    _upload_to_db(mask_id, xdim, ydim, alpha_x, alpha_y, ret_list)

def _print_info(fname, mask_id, xdim, ydim, ret_list):
    print('File: {}'.format(fname))
    print('Mask: {}'.format(mask_id))
    print('X: {}'.format(xdim))
    print('Y: {}'.format(ydim))

    flat_ret_list = [col for row in ret_list for col in row]
    print('Reticles: {}\n'.format(len(filter(lambda x: x, flat_ret_list))))

    # iterate over transpose of ret_list to allow for printing in the correct order
    for i, col in enumerate(zip(*ret_list)):
        for j, row in enumerate(col):
            if row:
                print('({:2d}, {:2d}) '.format(j + 1, i + 1), end='')
            else:
                print('(XXXXXX) ', end='')
        print('\n\t')
    print()

def _dimension_from_lib(map_struct):

    # get all text elements
    text_elems = filter(lambda x: isinstance(x, Text), map_struct.elements)

    strings = [x.string for x in text_elems]
    dim_string = filter(lambda x: _re_dimension.match(x), strings)[0]

    # map1 has flat on left, so in GDS file, written as 'Y by X'
    xdim = int(_re_dimension.match(dim_string).group(2))
    ydim = int(_re_dimension.match(dim_string).group(1))

    return xdim, ydim

def _reticles_from_lib(map_struct):
    """
    Returns a 2D list of strings indicating full reticles on the wafer,
    where the i axis is parallel to the wafer flat, the j axis is normal to it, and the
    (0, 0) coordinate is top left when flat is facing down.
    Assumes the GDS file is oriented such that the flat is on the left, i.e. GDS x axis is
    normal to the flat and the GDS y axis is parallel to the flat.
    """
    ret_list = []

    # find the circular wafer drawing(s) (above a certain number of xy points is the heuristic)
    wafer_elems = filter(lambda x: len(x.xy) > 5, map_struct.elements)

    # if multiple circular elements, sort the list by the elements with the smallest diameter
    if len(wafer_elems) > 1:
        _element_xcoords = lambda el: [xy[0] for xy in el.xy]
        _element_ycoords = lambda el: [xy[1] for xy in el.xy]
        _circle_diameter = lambda el: max(max(_element_ycoords(el)) - min(_element_ycoords(el)), max(_element_xcoords(el)) - min(_element_xcoords(el)))
        wafer_elems.sort(key=_circle_diameter)

    # pull the smallest circle from the sorted list and get its radius
    radius = _circle_diameter(wafer_elems[0])/2

    # filter rectangular objects where at least one of their coordinates fall inside of the smallest circle
    _reticle_filter = lambda x: isinstance(x, Boundary) and \
                                len(x.xy) < 6 and \
                                any([_xy_to_polar(*xy)[0] < radius for xy in x.xy])

    # get all elements on layer 0
    all_reticles = filter(_reticle_filter, map_struct.elements)

    # create unique sorted list of right-most x coordinates for each reticle
    max_x_coords = [max(xy[0] for xy in ret.xy) for ret in all_reticles]
    max_x_coords = list(set(max_x_coords))
    max_x_coords.sort()

    # top-most y coordinate for each reticle
    max_y_coords = [max(xy[1] for xy in ret.xy) for ret in all_reticles]
    max_y_coords = list(set(max_y_coords))
    max_y_coords.sort()

    # full reticles have all of their xy coordinates inside of the smallest circle
    _full_reticle_filter = lambda ret: all([rad < radius for rad in [_xy_to_polar(*xy)[0] for xy in ret.xy]])

    full_list = [True if _full_reticle_filter(ret) else False for ret in all_reticles]
    x_idx_list = [max_x_coords.index(coord) for coord in [max(xy[0] for xy in ret.xy) for ret in all_reticles]]
    y_idx_list = [max_y_coords.index(coord) for coord in [max(xy[1] for xy in ret.xy) for ret in all_reticles]]

    ret_list = [[False]*len(max_x_coords) for x in max_y_coords]

    for full, x, y in zip(full_list, x_idx_list, y_idx_list):
        if full:
            ret_list[y][x] = True

    return ret_list

def _write_to_map(mask_name, xdim, ydim, alpha_x, alpha_y, ret_list):
    result = raw_input('Write map to .map file? [Yn]: ')
    if result.strip().upper() in ['Y', '']:

        # try to change to default HammerGUI offline mask directory
        from HammerDataMgr import _default_map_dir
        if os.path.isdir(_default_map_dir):
            os.chdir(_default_map_dir)

        print('Current Directory: {}'.format(os.getcwd()))
        def_out_path = os.path.join(os.getcwd(), '{}.map'.format(mask_name))
        out_path = cli_utils.prompt_output_file(msg='Enter destination path [{}]: '.format(def_out_path), optional=True, default=def_out_path)

        # if no entry, use default output path
        if out_path is not None:

            print("Writing map file to '{}'".format(out_path))

            if not os.path.isdir(os.path.dirname(out_path)):
                os.makedirs(os.path.dirname(out_path))

            with open(os.path.abspath(out_path), 'w') as fp:
                print('xindex: {}'.format(xdim), file=fp)
                print('yindex: {}'.format(ydim), file=fp)
                print('xalpha: {}'.format(alpha_x), file=fp)
                print('yalpha: {}'.format(alpha_y), file=fp)
                print(file=fp)
                print('majorflat: N', file=fp)
                print(file=fp)
                print('[sites]', file=fp)
                print(file=fp)

                for i, col in enumerate(ret_list):
                    for j, row in enumerate(col):
                        if row:
                            print('{} {}'.format(i + 1, j + 1), file=fp)
                    print(file=fp)

                print("Successfully wrote map file to '{}'".format(out_path))
        else:
            print("Skipping .map file output")

def _upload_to_db(mask_name, xdim, ydim, alpha_x, alpha_y, ret_list):
    result = raw_input('Upload to Hammer test database? [Yn]: ')
    if result.strip().upper() in ['Y', '']:
        from HammerDataMgr import HammerDataMgr, _dbconnect, _db_table_foundry, _db_table_process, _db_table_mask, _db_table_site
        mgr = HammerDataMgr(None)

        try: 
            db = _dbconnect()
            cur = db.cursor()

            # find 'MACOM' id in database table
            result = mgr._select_from_table(_db_table_foundry, ['id'], {'foundry': 'MACOM'}, cur)
            foundry_id = cur.fetchall()[0]['id']

            # get all 'MACOM' processes
            result = mgr._select_from_table(_db_table_process, ['id', 'process'], {'foundry_id': foundry_id}, cur)
            rows = cur.fetchall()

            processes = {}
            for row in rows:
                processes[str(row['id'])] = row['process']

            result = ''
            while result.strip() not in processes:

                print()
                for proc_id, proc_name in processes.iteritems():
                    print('\t{} - {}'.format(proc_id, proc_name))
                print()

                result = raw_input('Select mask process: ')
                if result.strip() not in processes:
                    print('Invalid selection!')

            process_id = long(result.strip())

            # check if this mask already exists in database
            result = mgr._select_from_table(_db_table_mask, ['process_id', 'name'], {'process_id': process_id, 'name': mask_name}, cur)

            # mask already in database
            if result:
                print('Mask {} for process {} already exists in database, skipping upload'.format(mask_name, processes[str(process_id)]))

            # mask doesn't exist, just add it
            else:
                col_val_pairs = {
                    'process_id': process_id,
                    'name': mask_name,
                    'xidx': xdim, 
                    'yidx': ydim,
                    'xalpha': alpha_x,
                    'yalpha': alpha_y,
                }
                result = mgr._insert_into_table(_db_table_mask, col_val_pairs.keys(), [tuple(col_val_pairs.values())], cur)
                mask_id = cur.lastrowid

                # update site table
                for i, row in enumerate(ret_list):
                    for j, col in enumerate(row):
                        if col:
                            mgr._insert_into_table(_db_table_site, ['mask_id', 'x', 'y'], [(mask_id, i + 1, j + 1)], cur)

        except Exception as e:
            traceback.print_exc()
            print('Error during upload, skipping upload!')

        finally:
            print('Upload of mask {} complete!'.format(mask_name))
            cur.close()
            db.close()

    else:
        print('Skipping upload!')

def _xy_to_polar(x, y):
    r = math.hypot(x, y)
    theta = math.degrees(math.atan2(y, x))
    return r, theta

if __name__ == '__main__':

    fpaths = [os.path.abspath(x) for x in sys.argv[1:]]

    if not fpaths:
        print('Please pass in GDS files to create a wafer map from as an argument')

    else:
        for path in fpaths:
            try:
                wafermap_from_gds(path)
            except Exception as e:
                traceback.print_exc()
                print('Failed getting reticle information from file {}'.format(path))
                continue

    raw_input("Finished extracting information for all supplied files. Press Enter to close.")
