import logging
import os
import re
import threading
import time

from datetime import datetime
from datetime import timedelta
from instrument.utils import timed_wait_ms
from pyvisa import VisaIOError
from pyvisa.constants import VI_ERROR_TMO
from wxtestgui.instr import Instr
from wxtestgui.worker import Worker, send_to_ui, get_next_message, NoMessages, Message

class SignalMessage(Exception):
    def __init__(self, msg=None, data=None):
        super(SignalMessage, self).__init__()
        self.message = msg
        self.data = data

def downpoint_single_site(cfg, site, sgate, sdrain, out_file=None):
    """
    Run downpoint test at single site, optionally outputting data to given file as test runs.
    Writes test data to site dictionary under the 'test_out' key.

    Arguments:
        site        - site dictionary from wafer map object
        sgate       - open handle to gate side supply instrument
        sdrain      - open handle to drain-side supply instrument

    Keywords:
        out_file    - open handle to file to write incremental data to. If not specified, nothing is written during test
    """

    site_x, site_y, site_data = site

    _logmsg_info('Running downpoint test for site ({:d}, {:d})'.format(site_x, site_y))

    fwd_data = None
    iv_data = None
    txfr_data = None
    leakage_data = None

    while True:
        try:
            _check_message_queue(False)
            fwd_data = fwd_points(cfg, site, sgate, sdrain)
            _check_message_queue(False)
            iv_data = imax_ron(cfg, site, sgate, sdrain)
            _check_message_queue(False)
            txfr_data = txfr_points(cfg, site, sgate, sdrain)
            _check_message_queue(False)
            leakage_data = leakage_point(cfg, site, sgate, sdrain)
            _check_message_queue(False)
            _status_update(site_data, {'status': 'Complete'})
            break

        except SignalMessage as signal:
        
            data = signal.data if signal.data is not None else ''

            if signal.message == 'abort':
                _status_update(site_data, {'status': 'Aborted'})
                _logmsg_info('({:2d}, {:2d}): Test Aborted'.format(site_x, site_y))
                send_to_ui('aborted', data)

                # shut off supplies
                sdrain.config(state=0)
                timed_wait_ms(500)
                sgate.config(state=0)
                return

        finally:
            _status_update(site_data, {'vg': None, 'ig': None, 'vd': None, 'id': None})

    # gather data for columns
    periph_mm = cfg.get('ngf').value*cfg.get('ugw').value*0.001
    a_to_ma = 1.0e3

    diode_vg = fwd_data[0]
    diode_ig_norm = [x*a_to_ma/periph_mm for x in fwd_data[1]]

    imax_norm = iv_data[0]*a_to_ma/periph_mm
    ron_norm = iv_data[1]*periph_mm

    txfr_vg = txfr_data[0]
    txfr_id_norm = [x*a_to_ma/periph_mm for x in txfr_data[1]]

    leakage_id_norm = leakage_data[0]*a_to_ma/periph_mm
    leakage_ig_norm = abs(leakage_data[1]*a_to_ma/periph_mm)
    leakage_is_norm = abs(leakage_data[2]*a_to_ma/periph_mm)

    if out_file:
        out_file.write('"Site (x, y)","{:d}","{:d}"\n'.format(site_x, site_y))

        for idx, (dvg, dig) in enumerate(zip(diode_vg, diode_ig_norm)):
            out_file.write('"dvg{0:d}","{1:e}"\n"dig{0:d}","{2:e}"\n'.format(idx, dvg, dig))

        out_file.write('"imax","{:e}"\n'.format(imax_norm))
        out_file.write('"ron","{:e}"\n'.format(ron_norm))

        for idx, (tvg, tid) in enumerate(zip(txfr_vg, txfr_id_norm)):
            out_file.write('"tvg{0:d}","{1:e}"\n"tid{0:d}","{2:e}"\n'.format(idx, tvg, tid))

        out_file.write('"leakid","{:e}"\n'.format(leakage_id_norm))
        out_file.write('"leakig","{:e}"\n'.format(leakage_ig_norm))
        out_file.write('"leakis","{:e}"\n'.format(leakage_is_norm))
        out_file.flush()

    # update site data dictionary with complete output data set
    site_data['test_out'] = {'fwd': fwd_data, 'iv': iv_data, 'txfr': txfr_data, 'leakage': leakage_data}

def find_target_Ids(targetIds, tol, initial_vg, vg_step, vg_step_factor, vg_max, vg_min, site, sgate, sdrain):
    "finds a specified current by adjusting Vgs, assumes limits and drain voltage already set"

    # take measurements to get up-to-date measurements before checking for compliance in while loop
    sgate.measure()
    timed_wait_ms(50)
    sdrain.measure()
    timed_wait_ms(50)

    currentVg = initial_vg
    stepSize = vg_step
    targetIds_rounded = round(targetIds*1000,tol)
    increasing = True

    # measure Ids
    currentId = sdrain.measure()
    currentId_rounded = round(currentId*1000,tol)
    timed_wait_ms(50)

    failed = False

    while currentId_rounded != targetIds_rounded:
        # check for messages
        _check_message_queue(False)

        _status_update(site[2], {'status': 'Targeting Id', 'vg': currentVg, 'id': currentId*1e3})

        # if in compliance, throw exception
        if sgate.ask_if_limiting() or sdrain.ask_if_limiting():
            _logmsg_warn('({:2d}, {:2d}) DUT in compliance, aborting current find routine!'.format(site[0], site[1]))
            failed = True
            return currentVg

        if currentId_rounded == targetIds_rounded:
            break

        # if smaller than desired and less than max allowed Vg, step up
        elif (currentId_rounded < targetIds_rounded) and (vg_min <= currentVg <= vg_max):
            if not increasing:
                increasing = True
                stepSize = stepSize*vg_step_factor
                # limit step size to 10uV
                if stepSize < 1e-5:
                    stepSize = 1e-5
            currentVg = currentVg + stepSize

        # if larger than desired, step down
        elif (currentId_rounded > targetIds_rounded) and (vg_min <= currentVg <= vg_max):
            if increasing:
                increasing = False
                stepSize = stepSize*vg_step_factor
                # limit step size to 10uV
                if stepSize < 1e-5:
                    stepSize = 1e-5
            currentVg = currentVg - stepSize

        elif currentVg > vg_max or currentVg < vg_min:
            _logmsg_warn("({:2d}, {:2d}) Reached min/max allowed Vg, continuing test with current corresponding to Vg = {:.5f} V".format(site[0], site[1], currentVg))
            failed = True
            break

        # set next Vg and wait to settle
        sgate.config(vset=currentVg)
        timed_wait_ms(100)

        # measure Ids
        currentId = sdrain.measure()
        currentId_rounded = round(currentId*1000,tol)
        _status_update(site[2], {'id': currentId*1e3})

    if not failed:
        _logmsg_info("({:2d}, {:2d}) Found target current Id = {:e} mA with Vg = {:.5f} V".format(site[0], site[1], currentId*1.0e3,currentVg))

    return currentVg

def fwd_points(cfg, site, sgate, sdrain):
    "capture the forward I-V curve of the device"

    site_x, site_y, site_data = site

    _logmsg_info('({:2d}, {:2d}) Capturing forward diode curve points'.format(site_x, site_y))
    _status_update(site_data, {'status': 'Diode Test'})

    periph = cfg.get('ugw').value*cfg.get('ngf').value
    vgmax = cfg.get('vg_max').value
    igmax = cfg.get('fwd_ig_max_mamm').value*periph*1.0e-6
    idlim = igmax*4.0
    vds = cfg.get('fwd_vd').value
    target_ig_list = [cfg.get('fwd_ig_uamm{}'.format(x)).value*periph*1.0e-9 for x in range(3)]
    meas_delay = cfg.get('fwd_meas_delay_ms').value

    vg = []
    ig = []

    # turn on sources
    sdrain.config(mode='V',vset=vds,state=1,ilimit=idlim,resolution='high',remote=False)
    timed_wait_ms(50)
    sgate.config(mode='I',iset=0.0,state=1,vlimit=vgmax,resolution='high',remote=False)

    # set the initial SMU range
    current_range = target_ig_list[0]*100.0
    sgate.config(irange=current_range)

    for idx, igs in enumerate(target_ig_list):
        # check for range changes
        if igs > current_range:
            current_range *= 100.0
            sgate.config(irange=current_range)

        # set gate current, wait for settle
        sgate.config(iset=igs)
        timed_wait_ms(cfg.get('fwd_meas_delay_ms').value)

        # take measurement
        vgs = sgate.measure()
        ids = sdrain.measure()
        vg.append(vgs)
        ig.append(igs)
        _status_update(site_data, {'vg': vgs, 'ig': igs*1e3, 'vd': vds, 'id': ids*1e3})

    # turn off sources
    sgate.set_state(0)
    timed_wait_ms(50)
    sdrain.set_state(0)

    _status_update(site_data, {'vg': None, 'ig': None, 'vd': None, 'id': None})

    return (vg, ig)

def imax_ron(cfg, site, sgate, sdrain):
    """Capture a set of I-V data from the device."""

    site_x, site_y, site_data = site

    _logmsg_info('({:2d}, {:2d}) Capturing Imax and Ron'.format(site_x, site_y))
    _status_update(site_data, {'status': 'Imax/Ron Test'})

    periph = cfg.get('ugw').value*cfg.get('ngf').value
    iglim = cfg.get('idss_ig_max_mamm').value*periph*1.0e-6
    idlim = cfg.get('idss_id_max_mamm').value*periph*1.0e-6

    # set the initial gate and drain current limits
    sgate.config(mode='V',ilimit=iglim,resolution='medium',remote=False)
    sdrain.config(mode='V',ilimit=idlim,resolution='medium',remote=False)

    # measure imax
    vgs = cfg.get('idss_vg').value
    vds = cfg.get('idss_vd').value
    sgate.config(vset=vgs, state=1)
    timed_wait_ms(50)
    sdrain.config(vset=vds, state=1)
    timed_wait_ms(cfg.get('iv_meas_delay_ms').value)
    igs = sgate.measure()
    imax = sdrain.measure()

    _status_update(site_data, {'vg': vgs, 'ig': igs*1e3, 'vd': vds, 'id': imax*1e3})

    # turn off drain source
    sdrain.config(state=0)

    idlim = cfg.get('ron_id_max_mamm').value*periph*1.0e-6
    sdrain.config(ilimit=idlim)

    # measure ron
    vgs = cfg.get('ron_vg').value
    vds = cfg.get('ron_vd').value
    sgate.config(vset=vgs)
    timed_wait_ms(50)
    sdrain.config(vset=vds, state=1)
    timed_wait_ms(cfg.get('iv_meas_delay_ms').value)
    igs = sgate.measure()
    ids = sdrain.measure()
    ron = vds / ids
    _status_update(site_data, {'vg': vgs, 'ig': igs*1e3, 'vd': vds, 'id': ids*1e3})

    # turn off sources
    sdrain.set_state(0)
    timed_wait_ms(50)
    sgate.set_state(0)

    _status_update(site_data, {'vg': None, 'ig': None, 'vd': None, 'id': None})

    return (imax, ron)

def leakage_point(cfg, site, sgate, sdrain):
    "measure the leakage curve"

    site_x, site_y, site_data = site

    _logmsg_info('({:2d}, {:2d}) Capturing leakage points'.format(site_x, site_y))
    _status_update(site_data, {'status': 'Leakage Test'})

    periph = cfg.get('ugw').value*cfg.get('ngf').value
    iglim = cfg.get('leakage_ig_max_mamm').value*periph*1.0e-6
    idlim = cfg.get('leakage_id_max_mamm').value*periph*1.0e-6
    vgate = cfg.get('leakage_vg').value
    vdrain = cfg.get('leakage_vd').value

    # set sources and wait for settling
    sgate.config(mode='V',vset=vgate,state=1,ilimit=iglim,resolution='high',remote=False)
    timed_wait_ms(50)
    sdrain.config(mode='V',vset=vdrain,state=1,ilimit=idlim,resolution='high',remote=False)
    timed_wait_ms(cfg.get('leakage_meas_delay_ms').value)

    # take measurement
    igs = sgate.measure()
    ids = sdrain.measure()
    _status_update(site_data, {'vg': vgate, 'ig': igs*1e3, 'vd': vdrain, 'id': ids*1e3})

    # turn off sources
    sdrain.set_state(0)
    timed_wait_ms(50)
    sgate.set_state(0)

    _status_update(site_data, {'vg': None, 'ig': None, 'vd': None, 'id': None})

    return (ids, igs, -(ids + igs))

def run_test(test_type, wmap, out_dir, cfg, inst_list):
    """
    Handler to run the indicated test over the given wafer map, stepped sequentially. Assumes prober is already in contact at the upper-left
    most site selected for the given test (as indicated in the UI)

    Arguments:
        test_type   - string indicating test type ('downpoint0' for pre-test, 'downpoint1' for post-test, or 'stress')
        wmap        - WaferMap object containing the sites to be tested as well as the mask information
        base_dir    - string containing the absolute path to write output data to (directories are created according to config)
        cfg         - TestParameters object with all test parameters
        inst_list   - list of Instr objects necessary for test
    """

    multisite = cfg['multisite'].value
    inst_names = [x.name for x in inst_list]
    this_thread = threading.currentThread()

    # try to open instruments
    try:
        _logmsg_debug('Trying to open instruments [{}]'.format(', '.join(inst_names)))

        insts = {}
        for inst in inst_list:
            insts[inst.name] = inst.open_instrument()

    # close instruments if initialization failed
    except Exception as e:
        _logmsg_error(e.message)
        _logmsg_error("Unable to open instrument '{}'".format(inst.name))
        for inst in insts.itervalues():
            if inst:
                inst.close()
        send_to_ui('testdata', None)
        return

    if not multisite:
        prober = insts['prober']
    else:
        prober = None
        threads = [ ]

    gates = [insts[x] for x in filter(lambda x: re.search('vg[a-d]', x), inst_names)]
    drains = [insts[x] for x in filter(lambda x: re.search('vd[a-d]', x), inst_names)]

    _logmsg_debug('Successfully opened all instruments')

    if not os.path.isdir(out_dir):
        _logmsg_debug("Creating output directory '{}'".format(out_dir))
        os.makedirs(out_dir)

    # send message to clear plot
    send_to_ui('clear_dpplot' if 'downpoint' in test_type else 'clear_stplot')

    # run tests
    # compile list of sites to be run and update their status
    site_list = [ ]
    for idx, site in enumerate(wmap):

        site_x, site_y, data = site
        status_dict = {'status': 'Pending', 'vg': None, 'ig': None, 'vd': None, 'id': None, 't' : None, 'tr': None}

        if 'downpoint' in test_type and data.get('downpoint', False):
            _status_update(data, status_dict)
            site_list.append(site)

        elif 'stress' == test_type and data.get('stress', False):
            _status_update(data, status_dict)
            site_list.append(site)

    # iterate over sites
    for idx, site in enumerate(site_list):
        site_x, site_y, site_data = site

        # move prober for iterative test
        if not multisite:

            _logmsg_debug('Moving prober to site ({:2d}, {:2d})'.format(site_x, site_y))

            # move to next site
            if idx > 0:
                # calculate temperature delta for stress test
                tdelta = cfg.get('stress_temp').value - cfg.get('downpoint_temp').value if test_type == 'stress' else 0.0

                # get indices of previous site and current site in wafer map
                prev_idx = wmap.get_site_index(site_list[idx - 1][0], site_list[idx - 1][1])
                cur_idx = wmap.get_site_index(site[0], site[1])

                # calculate delta x/y between previous and current site
                deltaX, deltaY = wmap.compute_pos(cur_idx, startidx=prev_idx, tdelta=tdelta)

                # move prober
                curX, curY = prober.get_position()
                prober.set_position_synch(curX + deltaX, curY + deltaY)

        # initialize in-situ file basename
        out_name = '{:02d}{:02d}_{}'.format(site[0], site[1], test_type)
        ext = 'hammerdp' if 'downpoint' in test_type else 'hammerst'

        _prev_file_regex = lambda x: re.match('{:02d}{:02d}_{}_?(\d+)?\.{}'.format(site_x, site_y, test_type, ext), x)

        # check for all previously created files for this test
        prev_files = filter(_prev_file_regex, os.listdir(out_dir))

        # if there were more than one previously created files
        if len(prev_files) > 1:

            # remove first previously_created file from list to avoid exception in finding largest index
            prev_files.remove('{:02d}{:02d}_{}.{}'.format(site_x, site_y, test_type, ext))

            _prev_idx_regex = lambda x: int(re.search('{:02d}{:02d}_{}_(\d+)\.{}'.format(site_x, site_y, test_type, ext), x).group(1))
            prev_idx_list = [_prev_idx_regex(x) for x in prev_files]
            prev_idx_list.sort()
            max_idx = prev_idx_list[-1]

            # check for how many previously created files were made (all of format <site>_<test_type>_<index>.{}
            # extract index from filename

            # if more than one file, increment the largest index and use that for new filename
            out_name += '_{:d}'.format(max_idx + 1)

        # if only one previously created file, use '1' as the new filename index
        elif prev_files:
            out_name += '_1'

        out_name += '.{}'.format(ext)
        out_path = os.path.join(out_dir, out_name)

        # create worker threads for multi-site test
        if multisite:
            args = [test_type, out_path, cfg, site, gates[idx], drains[idx]]
            threads.append(Worker(this_thread.comm._w, target=initiate_test, args=args))

        elif not multisite:
            send_to_ui('plot_monitor', True)
            initiate_test(test_type, out_path, cfg, site, gates[0], drains[0])

    # start all worker threads and wait for their completion if multisite
    if multisite:

        # start worker threads
        for thread in threads:
            thread.start()

        send_to_ui('plot_monitor', True)

        active_threads = any([x.isAlive() for x in threads])
        while active_threads:
            try:
                _check_message_queue()
                active_threads = any([x.isAlive() for x in threads])

            # handle any user messages by setting flags and re-starting main loop
            except SignalMessage as signal:
                msg = signal.message
                site = signal.data

                idx = None
                if site is not None:
                    idx = 'ABCD'.index(site)

                # messaging a single site
                if idx is not None:
                    threads[idx].comm.send_to_worker(signal.message, site)

                # pausing all sites
                else:
                    for t in threads:
                        t.comm.send_to_worker(signal.message)

                continue

    # move back to initial prober position if not multisite
    elif not multisite:

        # only move if more than one site
        if idx > 0:
            
            # calculate temperature delta for stress test
            tdelta = cfg.get('stress_temp').value - cfg.get('downpoint_temp').value if test_type == 'stress' else 0.0

            # get indices of previous site and current site in wafer map
            prev_idx = wmap.get_site_index(site_list[-1][0], site_list[-1][1])
            cur_idx = wmap.get_site_index(site_list[0][0], site_list[0][1])

            # calculate delta x/y between previous and current site
            deltaX, deltaY = wmap.compute_pos(cur_idx, startidx=prev_idx, tdelta=tdelta)

            # move prober
            curX, curY = prober.get_position()
            prober.set_position_synch(curX + deltaX, curY + deltaY)

    # close instruments
    for inst in insts.itervalues():
        if inst is not None:
            inst.close()

    _logmsg_info('Test complete!')

    # send complete test data up to main thread for processing/storage into database
    send_to_ui('testdata', (cfg.get_param_dict(), datetime.now(), test_type))

def initiate_test(test_type, out_path, cfg, site, sgate, sdrain):

    # determine test function
    if 'downpoint' in test_type:
        test_func = downpoint_single_site
    elif 'stress' == test_type:
        test_func = stress_single_site

    # open output file
    with open(out_path, 'w') as out_file:

        _logmsg_debug("Writing in-situ output to '{}'".format(out_path))

        # for stress or pre-downpoint, add only this file to plot panel
        if test_type in ['stress', 'downpoint0']:
            send_to_ui('dpplot' if 'downpoint' in test_type else 'stplot', out_path)

        # for post-dp, send this file and try sending the corresponding pre-downpoint file
        elif test_type == 'downpoint1':
            send_to_ui('dpplot', out_path)
            pre_dp_path = out_path.replace('downpoint1', 'downpoint0')
            if os.path.isfile(pre_dp_path):
                send_to_ui('dpplot', pre_dp_path)
            else:
                _logmsg_warn("Couldn't find corresponding pre-downpoint file '{}'. Plot will only show current test results".format(pre_dp_path))        

        # write file header
        out_file.write(generate_header(cfg, test_type))
        out_file.flush()

        # call test subroutine
        test_data = test_func(cfg, site, sgate, sdrain, out_file)

def stress_single_site(cfg, site, sgate, sdrain, out_file=None):
    """
    Run stress test at single site, optionally outputting data to given file as test runs.
    Writes test data to site dictionary under the 'test_out' key.

    Arguments:
        site        - site dictionary from wafer map object
        sgate       - open handle to gate side supply instrument
        sdrain      - open handle to drain-side supply instrument

    Keywords:
        out_file    - open handle to file to write incremental data to. If not specified, nothing is written during test
    """

    site_x, site_y, site_data = site
    
    _logmsg_info('Running stress test for site ({:d}, {:d})'.format(site_x, site_y))

    periph      = cfg.get('ngf').value*cfg.get('ugw').value
    igcomp      = cfg.get('stress_ig_max_mamm').value*periph*1.0e-6*2.0
    idlim       = cfg.get('stress_id_max_mamm').value*periph*1.0e-6
    vdrain      = cfg.get('stress_vd').value
    target_id   = cfg.get('stress_target_id_mamm').value*periph*1.0e-6
    vgate       = cfg.get('initial_vg').value
    vg_step     = cfg.get('vg_step').value
    vg_max      = cfg.get('vg_max').value
    vg_min      = cfg.get('vg_min').value
    step_factor = cfg.get('step_factor').value
    tol         = cfg.get('stress_target_id_tolerance_dec_ma').value
    poll        = cfg.get('stress_poll_interval_msec').value
    interval    = cfg.get('stress_meas_interval_sec').value
    duration    = cfg.get('stress_meas_duration_sec').value

    # initialize data lists
    time_list = []
    ig_list = []
    id_list = []

    # turn on sources
    sgate.config(mode='V', vset=vgate, state=1, ilimit=igcomp, resolution='high', remote=False)
    timed_wait_ms(50)
    sdrain.config(mode='V', vset=vdrain, state=1, ilimit=idlim, resolution='high', remote=False)

    # increase timeouts
    sgate.timeout = 10000
    sdrain.timeout = 10000

    # adjust vg to desired current
    try:
        vgate = find_target_Ids(target_id, tol, vgate, vg_step, step_factor, vg_max, vg_min, site, sgate, sdrain)

    except SignalMessage as signal:

        data = signal.data if signal.data is not None else ''

        if signal.message == 'abort':
            _status_update(site_data, {'status': 'Aborted'})
            _logmsg_info('({:2d}, {:2d}): Test Aborted'.format(site_x, site_y))
            send_to_ui('aborted', data)

            # shut off supplies
            sdrain.config(state=0)
            timed_wait_ms(500)
            sgate.config(state=0)
            return

    # begin stress
    start_time = datetime.now()
    next_time = start_time
    end_time = start_time + timedelta(seconds=duration)
    poll_time = start_time + timedelta(milliseconds=poll)
    current_time = start_time

    _logmsg_info('({:2d}, {:2d}) Start Time: {}'.format(site[0], site[1], start_time.strftime('%Y/%m/%d %H:%M:%S')))
    _logmsg_info('({:2d}, {:2d}) End Time: {}'.format(site[0], site[1], end_time.strftime('%Y/%m/%d %H:%M:%S')))

    if out_file:
        out_file.write('"Timestamp","Igate","Idrain","Site (x, y)","{:d}","{:d}"\n'.format(site[0], site[1]))
        out_file.flush()

    # initialize flags
    # use None to signal unset pause/resume/abort flags, and use a string (site name or number) to set flag
    pause = None
    resume = None
    abort = None
    failed = False
    pollGate = True

    # take t0 measurements
    igs = sgate.measure()
    ids = sdrain.measure()

    status_dict = {
        'status': 'Running',
        'vg': vgate,
        'ig': igs*1e3,
        'vd': vdrain,
        'id': ids*1e3,
        't' : current_time - start_time,
        'tr': end_time - current_time
    }

    _status_update(site_data, status_dict)

    # main test loop
    while True:
        try:
            # update current time
            current_time = datetime.now()

            # check for messages
            _check_message_queue(False)

            # if abort flag is set, break out of test loop and notify UI that test was aborted
            if abort is not None:
                _status_update(site_data, {'status': 'Aborted'})
                _logmsg_info('({:2d}, {:2d}): Test Aborted'.format(site_x, site_y))
                send_to_ui('aborted', abort)
                break

            # if pause flag is set, then shut off sources and remain in this loop until it is un-set
            if pause is not None:

                # turn off sources
                _logmsg_debug('({:2d}, {:2d}) Disabling sources'.format(site_x, site_y))
                sdrain.config(state=0)
                timed_wait_ms(500)
                sgate.config(state=0)

                # record time of pause
                pause_start_time = datetime.now()

                # notify UI that test is paused
                _logmsg_info('({:2d}, {:2d}): Test paused at time {}'.format(site_x, site_y, pause_start_time.strftime('%Y/%m/%d %H:%M:%S')))
                _status_update(site_data, {'status': 'Paused', 'vg': None, 'ig': None, 'vd': None, 'id': None})
                send_to_ui('paused', pause)

                # repeat loop, sleeping thread for 50ms between checks of pause flag
                while pause is not None:
                    time.sleep(50e-3)

                    # check for messages while paused
                    _check_message_queue()

                    # if abort signal sent while paused, break out of pause loop
                    if abort is not None:
                        send_to_ui('aborted', abort)
                        break

                continue

            # if resume flag is set, turn sources back on and continue main test loop
            if resume is not None:
                # if test is to be continued, capture length of pause and add it to duration
                pause_end_time = datetime.now()
                pause_time = pause_end_time - pause_start_time
                next_time = next_time + pause_time
                poll_time = poll_time + pause_time
                end_time = end_time + pause_time

                # turn sources back on
                _logmsg_debug('({:2d}, {:2d}) Enabling sources'.format(site_x, site_y))
                sgate.config(state=1)
                timed_wait_ms(500)
                sdrain.config(state=1)
                timed_wait_ms(500)

                # notify UI that test has resumed
                _logmsg_info('({:2d}, {:2d}): Paused for {} seconds. Resuming test. New end time: {}'.format(site_x, site_y, pause_time.seconds, end_time.strftime('%Y/%m/%d %H:%M:%S')))
                _status_update(site_data, {'status': 'Running', 'vg': vgate, 'vd': vdrain})
                send_to_ui('resumed', resume)

                # unset flag
                resume = None

            # if it's not time to poll yet, sleep for a while, then continue the loop
            if current_time < poll_time:
                td = poll_time - current_time
                sleep_interval = td.seconds + td.microseconds*1.0e-6
                if sleep_interval >= 0.001:
                    time.sleep(sleep_interval)
                    continue

            # update current time and next poll time
            current_time = datetime.now()
            poll_time = current_time + timedelta(milliseconds=poll)
            _status_update(site_data, {'t': current_time - start_time, 'tr': end_time - current_time})

            # measure only one source at each poll, but don't log until interval is exceeded
            pollGate = not pollGate

            # poll sources and check for compliance
            if pollGate:
                igs = sgate.measure()
                _status_update(site_data, {'ig': igs*1.0e3})

                if sgate.ask_if_limiting():
                    _logmsg_warn('Device ({}, {}) reached gate compliance, ending test!'.format(site[0], site[1]))
                    failed = True
                    _status_update(site_data, {'status': 'Failed'})
            else:
                ids = sdrain.measure()
                _status_update(site_data, {'id': ids*1.0e3})
                if sdrain.ask_if_limiting():
                    _logmsg_warn('Device ({}, {}) reached drain compliance, ending test!'.format(site[0], site[1]))
                    failed = True
                    _status_update(site_data, {'status': 'Failed'})

            # record measurements if at a measurement interval
            if next_time == start_time or current_time >= next_time or failed:

                # update next measurement interval
                next_time = current_time + timedelta(seconds=interval)

                # write in-situ data to file
                if out_file:
                    out_file.write('"{}","{}","{}"\n'.format(current_time.strftime('%Y/%m/%d %H:%M:%S'),igs,ids))
                    out_file.flush()

                # update lists
                time_list.append((current_time - start_time).seconds)
                ig_list.append(igs)
                id_list.append(ids)

                # if at end of test
                if current_time >= end_time or failed:
                    # mark site as completed
                    _status_update(site_data, {'status': 'Complete'})
                    break

        # ignore timeouts
        except VisaIOError as ex:
            if ex.error_code == VI_ERROR_TMO:
                pass
            else:
                raise

        # handle any user messages by setting flags and re-starting main loop
        except SignalMessage as signal:

            # store the signal's data in this thread's flag if it exists, otherwise store ''
            msg = signal.message
            data = signal.data if signal.data is not None else ''

            if msg == 'pause':
                if pause is None:
                    pause = data

            elif msg == 'resume':
                if pause is not None and resume is None:
                    resume = data
                    pause = None

            elif msg == 'abort':
                abort = data

            continue

    # shut off supplies
    sdrain.config(state=0)
    timed_wait_ms(500)
    sgate.config(state=0)

    # clear in-situ monitoring parameters from test data dictionary
    status_dict = {'vg': None, 'ig': None, 'vd': None, 'id': None, 'tr': None}
    _status_update(site_data, status_dict)

    # update site data dictionary with complete output data set
    site_data['test_out'] = {'time': time_list, 'ig': ig_list, 'id': id_list, 'vg': vgate, 'vd':vdrain}

def txfr_points(cfg, site, sgate, sdrain):
    "measure the transfer curve"

    site_x, site_y, site_data = site

    _logmsg_info('({:2d}, {:2d}) Capturing transfer curve points'.format(site_x, site_y))
    _status_update(site_data, {'status': 'Transfer Test'})

    periph = cfg.get('ugw').value*cfg.get('ngf').value
    iglim = cfg.get('txfr_ig_max_mamm').value*periph*1.0e-6
    idlim = cfg.get('txfr_id_max_mamm').value*periph*1.0e-6
    vdrain = cfg.get('txfr_vd').value
    vgs = cfg.get('initial_vg').value
    vg_step = cfg.get('vg_step').value
    vg_min = cfg.get('vg_min').value
    vg_max = cfg.get('vg_max').value
    step_factor = cfg.get('step_factor').value
    tol = cfg.get('txfr_target_id_tolerance_dec_ma').value
    target_id_list = [cfg.get('txfr_target_id_mamm{}'.format(x)).value*periph*1.0e-6 for x in range(3)]
    power_limit = cfg.get('txfr_power_limit_wmm').value*periph*1.0e-3
    idlimp = power_limit / vdrain
    if idlimp < idlim:
        idlim = idlimp

    vg = []
    id = []

    sgate.config(mode='V',vset=vgs,state=1,ilimit=iglim,resolution='high',remote=False)
    timed_wait_ms(50)
    sdrain.config(mode='V',vset=vdrain,state=1,ilimit=idlim,resolution='high',remote=False)

    for idx, ids in enumerate(target_id_list):
        # find current and settle
        vgs = find_target_Ids(ids, tol, vgs, vg_step, step_factor, vg_max, vg_min, site, sgate, sdrain)
        timed_wait_ms(cfg.get('txfr_meas_delay_ms').value)

        # take measurement
        igs = sgate.measure()
        ids = sdrain.measure()
        vg.append(vgs)
        id.append(ids)
        _status_update(site_data, {'vg': vgs, 'ig': igs*1.0e3, 'vd': vdrain, 'id': ids*1.0e3})

        # step vg down by one step for next point
        vgs -= vg_step

    # disable sources
    sdrain.set_state(0)
    timed_wait_ms(50)
    sgate.set_state(0)

    _status_update(site_data, {'vg': None, 'ig': None, 'vd': None, 'id': None})

    return (vg, id)

def generate_header(cfg, test_type):
    out_str = ''
    out_str += '!,"Rapid DC Stress Test"\n'
    out_str += '!,"Test Date:",{}\n\n'.format(datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    out_str += '!,"Test Configuration"\n'

    for parm in cfg:
        out_str += '!,"{}","{}","{}"\n'.format(parm, cfg.get(parm).value, cfg.get(parm).label)

    out_str += '\n'
    out_str += '!,"Data ({})"\n'.format(test_type)
    return out_str

def _check_message_queue(block=False):
    try:
        msg = get_next_message(block)

        if any([x in msg.msgtype for x in ['abort', 'pause', 'resume']]):
            raise SignalMessage(msg.msgtype, msg.data)
        else:
            return msg
    except NoMessages:
        return None

def _logmsg_debug(msg):
    "Convenience method to send a debug-level message to the UI"
    send_to_ui('log', {'level': logging.DEBUG, 'msg': msg})

def _logmsg_error(msg):
    "Convenience method to send an errer-level message to the UI"
    send_to_ui('log', {'level': logging.ERROR, 'msg': msg})

def _logmsg_info(msg):
    "Convenience method to send an info-level message to the UI"
    send_to_ui('log', {'level': logging.INFO, 'msg': msg})

def _logmsg_warn(msg):
    "Convenience method to send a warning-level message to the UI"
    send_to_ui('log', {'level': logging.WARNING, 'msg': msg})

def _status_update(site_data, new_data):
    "Convenience method to update the site data in the data manager and signal the UI to update"
    if site_data.get('testdata', None):
        site_data['testdata'].update(new_data)
    else:
        site_data['testdata'] = new_data
    send_to_ui('status')
