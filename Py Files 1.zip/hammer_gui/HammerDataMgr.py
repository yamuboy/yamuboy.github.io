from __future__ import unicode_literals, absolute_import, division, print_function

try:
    import cPickle as pkl
except ImportError:
    import pickle as pkl
    
import itertools
import logging
try:
    import MySQLdb
    from MySQLdb.cursors import DictCursor as DictCursor
except ImportError:
    MySQLdb = None
    DictCursor = None
    
import os
import socket

from collections import OrderedDict
from testsoft.wafermap import WaferMap
from wx.lib.pubsub import pub
from wxtestgui import TestParameters, app_prefs
from wxtestgui.worker import Worker

from .executive import run_test
from .instruments import INSTR_LIST
from .params import TEST_PARAMS

_logger = logging.getLogger('hammer.datamgr')

_default_prefs_file = os.path.abspath(os.path.expanduser(os.path.join('~', '.hammergui', 'prefs')))
_default_map_dir = os.path.abspath(os.path.expanduser(os.path.join('~', '.hammergui', 'masks')))

_dbhost = 'blade'
_dbuser = 'fetdata'
_dbpass = 'Mark2002'
_dbname = 'gan_hammer'
_dbconnect = lambda: MySQLdb.connect(host=_dbhost, user=_dbuser, passwd=_dbpass, db=_dbname, connect_timeout=60, cursorclass=DictCursor)
_db_init_error_msg = "Unable to initialize from database '{}' on host '{}'. Reverting to offline mode.".format(_dbname, _dbhost)

_db_table_foundry = 'foundry'
_db_table_downpoint = 'downpoint'
_db_table_mask = 'mask'
_db_table_process = 'process'
_db_table_site = 'site'
_db_table_stress = 'stress'
_db_table_waferinfo = 'waferinfo'

class HammerDataMgr(object):

    def __init__(self, frame=None, *args, **kwargs):
        """
        Initialize the data manager

        Keywords:
            offline - boolean indicating whether to use database or local storage for configuration/data
            standID - string indicating the identifier string for the test stand
        """
        self.parent = frame

        self._available_maps = OrderedDict()
        self._available_foundries = []
        self._available_processes = []
        self._modified = False
        self._offline = kwargs.pop('offline', False)
        if self.parent is not None:
            self._prefs = ApplicationPreferences(_default_prefs_file)
        self._setup_file = None
        self._work_dir = None
        self._worker_thread = None

        self.initialize_data()
        self._broadcast_update()

    def initialize_data(self):
        "Initialize the data manager"

        # test parameters
        self._testpars = TestParameters(TEST_PARAMS)

        # try to initialize online
        if not self._offline:
            self._init_online()

        # if online initialization failed, initialize offline
        if self._offline:
            self._init_offline()

        # load preferences
        if self.parent:
            self.load_prefs()

        # populate test stand
        self._testpars['stand']._set_value(socket.gethostname())

        self._broadcast_update()

    def change_foundry(self, foundry_name):
        if foundry_name in self.AvailableFoundries:
            # change selected foundry
            self.TestPars['foundry']._set_value(foundry_name)

            # reload available processes
            self.reload_available_processes()

            # clear lot/wafer/scribe mark to ensure re-entry
            self.TestPars['lot']._set_value('')
            self.TestPars['wafer']._set_value('')
            self.TestPars['scribe']._set_value('')

            self._broadcast_update()

    def change_map(self, map_name):
        if map_name in self.AvailableWaferMapNames:
            # change selected mask
            self.TestPars['mask']._set_value(map_name)

            # clear lot/wafer/scribe mark to ensure re-entry
            self.TestPars['lot']._set_value('')
            self.TestPars['wafer']._set_value('')
            self.TestPars['scribe']._set_value('')

            self._broadcast_update()

    def change_process(self, process_name):
        self.TestPars['process']._set_value(process_name)

        # force a non-standard process name to be experimental
        if process_name not in self.AvailableProcesses:
            self.TestPars['experiment']._set_value(True)

        self.reload_available_masks()
        self._broadcast_update()

    def initiate_test(self, test_type):
        "Spawn a worker thread to run the given test type. Valid arguments are 'downpoint0', 'downpoint1', and 'stress'"

        # notify the UI frame that the test has started
        self.parent.onWorkerEnter(test_type=test_type)

        # ensure a working directory has been set
        if not self._work_dir or not os.path.isdir(self._work_dir):
            self.parent.onSetWorkDir()

        # generate output directory
        foundry_str = self.TestPars['foundry'].value.upper()
        process_str = self.TestPars['process'].value.upper()
        mask_str = self.TestPars['mask'].value.upper()
        lot_str = self.TestPars['lot'].value.replace('.', 'p')
        wafer_str = self.TestPars['wafer'].value
        scribe_str = self.TestPars['scribe'].value.upper()
        ngf_str = str(self.TestPars['ngf'].value)
        ugw_str = '{:g}'.format(self.TestPars['ugw'].value).replace('.', 'p')
        device_str = self.TestPars['device'].value.upper()

        self._out_dir = os.path.join( self._work_dir,
                                foundry_str,
                                process_str,
                                '{}_{}_w{}_{}'.format(mask_str, lot_str, wafer_str, scribe_str),
                                '{}x{}um_{}'.format(ngf_str, ugw_str, device_str)
        )

        args =  [test_type, self.CurrentMap, self._out_dir, self.TestPars]

        # for multisite test, pass in only source instruments according to number of selected test sites
        if self.TestPars.get('multisite').value:
            num_sites = len(self.StressSites) if test_type == 'stress' else len(self.DownpointSites)
            args.append(INSTR_LIST[1:num_sites*2 + 1])

        # for iterative-stepping test, pass in prober and first 2 source instruments
        else:
            args.append(INSTR_LIST[:3])

        # spawn thread
        self._worker_thread = Worker(self.parent, target=run_test, args=args)
        self._worker_thread.start()

    def change_mode(self, offline=None):
        "Change from online/offline mode. Call with no argument to toggle from current mode, or send in true/false to set mode explicitly"
        if offline is None:
            offline = not self._offline

        if offline:
            self._init_offline()
        else:
            self._init_online()

        self._broadcast_update()

    def load_prefs(self):

        # load preferences
        if os.path.isfile(self._prefs.get_default_filename()):
            try:
                self._prefs.load()
                _logger.info("loaded preferences from '{}'".format(_default_prefs_file))
            except Exception as e:
                _logger.warning("error loading preferences file '{}' -> %{}".format(_default_prefs_file,e))
        else:
            dirname = os.path.dirname(self._prefs.get_default_filename())
            if not os.path.isdir(dirname):
                os.makedirs()
            self._prefs.save()

        # load last setup file
        self._setup_file = self._prefs.get('last_setup_file')
        if self._setup_file:
            self._testpars.load(self._setup_file)

        self._work_dir = self._prefs.get('work_dir')

        # load window settings
        self.parent.Maximize(self._prefs.get('mainwin_maximized', False))
        if not self.parent.IsMaximized():
            if self._prefs.get('mainwin_size'):
                self.parent.SetSize(self._prefs.get('mainwin_size'))
            if self._prefs.get('mainwin_position'):
                self.parent.SetPosition(self._prefs.get('mainwin_position'))

        # load instrument settings
        idata = self._prefs.get('instruments', {})
        for instr in INSTR_LIST:
            if instr.name in idata:
                i = idata[instr.name]
                if not instr.static:
                    instr.driver_name = i['drv']
                instr.resource = i['rsc']
                instr.chan = i['chan']
                instr.parms = i['parms']

        # load front-panel test parameters
        self._testpars['mask']._set_value(self._prefs.get('current_mask', self._testpars['mask'].value))
        self._testpars['lot']._set_value(self._prefs.get('current_lot', self._testpars['lot'].value))
        self._testpars['wafer']._set_value(self._prefs.get('current_wafer', self._testpars['wafer'].value))
        self._testpars['scribe']._set_value(self._prefs.get('current_scribe', self._testpars['scribe'].value))
        self._testpars['process']._set_value(self._prefs.get('current_process', self._testpars['process'].value))
        self._testpars['ngf']._set_value(int(self._prefs.get('current_ngf', self._testpars['ngf'].value)))
        self._testpars['ugw']._set_value(float(self._prefs.get('current_ugw', self._testpars['ugw'].value)))
        self._testpars['device']._set_value(self._prefs.get('current_device', self._testpars['device'].value))
        self._testpars['multisite']._set_value(self._prefs.get('current_multisite', self._testpars['multisite'].value))

        # load selected sites
        if self._testpars['mask'].value in self._available_maps:
            dp_sites = self._prefs.get('dp_sites', [])
            st_sites = self._prefs.get('st_sites', [])
            wmap = self._available_maps[self._testpars['mask'].value]

            for site in dp_sites:
                if site in wmap:
                    idx = wmap.get_site_index(site[0], site[1])
                    wmap.update_site_data(idx, {'downpoint': True})

            for site in st_sites:
                if site in wmap:
                    idx = wmap.get_site_index(site[0], site[1])
                    wmap.update_site_data(idx, {'stress': True})

    def load_setup(self, fname):
        "Loads the setup from the given filename. Assumes the given filename is an absolute filepath."

        self._testpars.load(fname)

        # update the current setup filepath
        if not fname == self._setup_file:
            self._setup_file = fname

        self.Modified = False

        _logger.info('Loaded setup from file: {}'.format(fname))

    def message_worker(self, msg, data=None):
        "send a message to the worker thread"
        if self._worker_thread:
            self._worker_thread.comm.send_to_worker(msg, data)

    def process_test_data(self, test_data, online=True):
        """
        Processes test data and stores it locally in an easy-to-recover pkl file, and also to a database if possible

        Arguments:
            test_data   - time and test type as returned by the main test thread (3-tuple: (config, datetime, string))

        Keywords:
            online      - boolean indicating whether to try uploading data to the database, if in online mode
        """
        # extract data from tuple argument
        config, time, test_type = test_data

        time_str = time.strftime('%Y%m%d_%H%M')
        out_fname = '{}_{}.pkl'.format(test_type, time_str)
        out_path = os.path.join(self._out_dir, out_fname)

        # create output directory if necessary (shouldn't be, since test-worker should create it during in-situ data)
        if not os.path.isdir(self._out_dir):
            os.makedirs(self._out_dir)

        # remove in-situ test data from site data dictionaries
        if 'downpoint' in test_type:
            sites = self.DownpointSites
        elif 'stress' == test_type:
            sites = self.StressSites

        out_data = [ ]
        for site_x, site_y, site_data in sites:
            sdata = site_data.pop('test_out', None)
            site_data.pop('testdata', None)
            if sdata:
                out_data.append((site_x, site_y, sdata))

        # write test data out to file for easy recovery
        with open(out_path, 'wb') as fp:
            pkl.dump((config, out_data), fp)

        # upload all data to database if online
        if not self.Offline:

            try:
                # connect to database
                db = _dbconnect()
                cur = db.cursor()

                # get foundry id
                result = self._select_from_table(_db_table_foundry, ['id'], {'foundry': config['foundry']}, cur)

                # if foundry wasn't found in database, skip upload
                if not result:
                    raise UserWarning("Foundry '{}' not found in database, skipping upload to database".format(config['foundry']))
                else:
                    foundry_id = cur.fetchall()[0]['id']

                # get process id
                result = self._select_from_table(_db_table_process, ['id'], {'foundry_id': foundry_id, 'process': config['process']}, cur)

                # if process wasn't found in database, skip upload
                if not result:
                    raise UserWarning("Process '{}' not found in database, skipping upload to database".format(config['process']))
                else:
                    process_id = cur.fetchall()[0]['id']

                # get mask id
                result = self._select_from_table(_db_table_mask, ['id'], {'process_id': process_id, 'name': config['mask']}, cur)

                # if mask wasn't found in database, skip upload
                if not result:
                    raise UserWarning('Mask not found in database, skipping upload to database')
                else:
                    mask_id = cur.fetchall()[0]['id']

                # get current wafer/device ID
                col_val_pairs = {
                        'foundry_id': foundry_id,
                        'process_id': process_id,
                        'mask_id'   : mask_id,
                        'lot'       : config['lot'],
                        'wafer'     : config['wafer'],
                        'scribe'    : config['scribe'],
                        'ngf'       : config['ngf'],
                        'ugw'       : config['ugw'],
                        'device'    : config['device'],
                        'experiment': config['experiment'],
                }
                result = self._select_from_table(_db_table_waferinfo, ['id'], col_val_pairs, cur)
                # create entry for wafer/device if it isn't in the database yet
                if not result:
                    wafer_str = '{}_L{}_W{}_{}'.format(config['mask'], config['lot'], config['wafer'], config['scribe'])
                    device_str = '{:d}x{:g}um_{}'.format(config['ngf'], config['ugw'], config['device'])
                    _logger.info('Device type {} for wafer {} not found in database, creating new entry for it'.format(device_str, wafer_str))

                    result = self._insert_into_table(_db_table_waferinfo, col_val_pairs.keys(), [tuple(col_val_pairs.values())], cur)

                    # failed to create entry, abort upload
                    if result != 1:
                        raise RuntimeError("Unable to create entry '{}:{}' in database, aborting data upload".format(wafer_str, device_str))

                    # inserted entry successfully, get entry id from cursor
                    else:
                        waferinfo_id = cur.lastrowid

                # already have entry for device on this wafer
                else:
                    waferinfo_id = cur.fetchall()[0]['id']

                # iterate over site data
                for site_x, site_y, data in out_data:

                    # get site_id for this site
                    col_val_pairs = {
                        'waferinfo_id' : waferinfo_id,
                        'x'            : site_x,
                        'y'            : site_y,
                    }
                    result = self._select_from_table(_db_table_site, ['id'], col_val_pairs, cur)

                    # site hasn't been tested at this wafer, create an entry for it
                    if not result:
                        wafer_str = '{}_L{}_W{}_{}'.format(config['mask'], config['lot'], config['wafer'], config['scribe'])
                        site_str = '({:2d}, {:2d})'.format(site_x, site_y)
                        _logger.info('Site {} for wafer {} not found in database, creating new entry for it'.format(site_str, wafer_str))

                        result = self._insert_into_table(_db_table_site, col_val_pairs.keys(), [tuple(col_val_pairs.values())], cur)

                        # failed to create entry, abort upload
                        if result != 1:
                            raise RuntimeError("Unable to create entry '({:2d}, {:2d})' in database, aborting data upload".format(site_x, site_y))

                        # inserted entry successfully, get entry id from cursor
                        else:
                            site_id = cur.lastrowid

                    # already have entry for this site
                    else:
                        site_id = cur.fetchall()[0]['id']

                    periph_mm = config['ngf']*config['ugw']*0.001
                    amps_to_ma = 1000.0
                    col_val_pairs = {
                        'site_id'  : site_id,
                        'time'     : time,
                    }

                    # create entry in downpoint table
                    if 'downpoint' in test_type:
                        table = _db_table_downpoint

                        col_val_pairs.update({
                            # get test level from last character of test type, 0=pre, 1=post
                            'level'    : int(test_type[-1]),
                            'dvg1'     : data['fwd'][0][0],
                            'dvg10'    : data['fwd'][0][1],
                            'dvg100'   : data['fwd'][0][2],
                            'imax'     : data['iv'][0]*amps_to_ma/periph_mm,
                            'ron'      : data['iv'][1]*periph_mm,
                            'tvg100'   : data['txfr'][0][0],
                            'tvg200'   : data['txfr'][0][1],
                            'tvg300'   : data['txfr'][0][2],
                            'leakid'   : data['leakage'][0]*amps_to_ma/periph_mm,
                            'leakig'   : data['leakage'][1]*amps_to_ma/periph_mm,
                            'leakis'   : data['leakage'][2]*amps_to_ma/periph_mm,
                        })

                        cols = col_val_pairs.keys()
                        vals = [tuple(col_val_pairs.values())]

                    # create entry in stress table
                    elif 'stress' == test_type:
                        table = _db_table_stress

                        num_total_points = len(data['time'])

                        # crude method to decimate total test data to a more managable number
                        if num_total_points > 15:
                            indices =   range(num_total_points/10) + \
                                        range(num_total_points/10, num_total_points/2, num_total_points/10) + \
                                        range(num_total_points/2, num_total_points, num_total_points/5) + \
                                        [(num_total_points - 1)]
                        else:
                            indices = range(num_total_points)

                        # populate output data arrays
                        elapsed_times = []
                        gate_currents = []
                        drain_currents = []
                        for idx in indices:
                            elapsed_times.append(data['time'][idx])
                            gate_currents.append(data['ig'][idx]*amps_to_ma/periph_mm)
                            drain_currents.append(data['id'][idx]*amps_to_ma/periph_mm)

                        vals = [ ]
                        for (t, g, d) in zip(elapsed_times, gate_currents, drain_currents):
                            new_dict = col_val_pairs.copy()
                            new_dict.update({
                                    'elapsed'   : t,
                                    'ig'        : g,
                                    'id'        : d,
                            })
                            vals.append(new_dict)

                        cols = vals[0].keys()
                        vals = [tuple(x.values()) for x in vals]

                    # insert result into appropriate table
                    result = self._insert_into_table(table, cols, vals, cur)

                    if result != len(vals):
                        raise RuntimeError('Error inserting data into database, aborting upload')
                    else:
                        _logger.info('Successfully uploaded data from site ({:2d}, {:2d}) to database'.format(site_x, site_y))

                _logger.info('Successfully uploaded all test data to database')

            except Exception as e:

                if isinstance(e, MySQLdb.OperationalError):
                    _logger.warning(_db_init_error_msg)
                    self._offline = True

                elif isinstance(e, UserWarning):
                    _logger.warning(e.message)

                else:
                    _logger.error(e.message)

            finally:
                cur.close()
                db.close()

        # clear output directory
        self._out_dir = None

        # signal parent that test has completed
        self.parent.onTestComplete()

    def save_prefs(self):

        # save the current setup file
        self._prefs['last_setup_file'] = self._setup_file

        self._prefs['work_dir'] = self._work_dir

        # update the current main window size and position in preferences
        self._prefs['mainwin_maximized'] = self.parent.IsMaximized()
        if not self._prefs['mainwin_maximized']:
            self._prefs['mainwin_size'] = tuple(self.parent.GetSize())
            self._prefs['mainwin_position'] = tuple(self.parent.GetPosition())

        # update instrument settings in the preferences
        data = {}
        for instr in INSTR_LIST:
            data[instr.name] = {'drv':instr.driver_name, 'rsc':instr.resource, 'chan':instr.chan, 'parms':instr.parms}
        self._prefs['instruments'] = data

        # store currently selected front-panel parameters
        self._prefs['current_mask'] = self._testpars['mask'].value
        self._prefs['current_lot'] = self._testpars['lot'].value
        self._prefs['current_wafer'] = self._testpars['wafer'].value
        self._prefs['current_scribe'] = self._testpars['scribe'].value
        self._prefs['current_process'] = self._testpars['process'].value
        self._prefs['current_ngf'] = self._testpars['ngf'].value
        self._prefs['current_ugw'] = self._testpars['ugw'].value
        self._prefs['current_device'] = self._testpars['device'].value
        self._prefs['current_multisite'] = self._testpars['multisite'].value

        # store currently selected sites
        if self.CurrentMap:

            dp_sites = []
            st_sites = []

            for site_x, site_y, site_data in self.CurrentMap:
                if site_data.get('downpoint', False):
                    dp_sites.append((site_x, site_y))
                if site_data.get('stress', False):
                    st_sites.append((site_x, site_y))

            self._prefs['dp_sites'] = dp_sites
            self._prefs['st_sites'] = st_sites

        # save application preferences
        try:
            self._prefs.save()
        except Exception as e:
            raise

    def save_setup(self, fname=None):
        """
        Save the setup to the given filename, or to the current setup file if no filename is given.
        Assumes the given filename is an absolute filepath.
        """
        out_name = self._setup_file if fname is None else fname

        try:
            self._testpars.save(out_name)

            # update the current setup filepath
            if not out_name == self._setup_file:
                self._setup_file = out_name

            self.Modified = False
        except:
            _logger.error("Unable to save setup to file '{}'. Try 'Save As' instead.".format(out_name))

        _logger.info('Saved setup to file: {}'.format(out_name))

    def toggle_site_select(self, x, y, sel_type):
        """
        Toggle selection of site at location (x, y) with respect to downpoint or stress test. Returns True if selection is valid,
        and False if no change was made (e.g. a 5th site was selected for a multi-site test, which can only do 4 sites at once)

        Arguments:
            - x         - integer indicating the x-index of site in map
            - y         - integer indicating the y-index of site in map
            - sel_type  - string indicating type of selection ('downpoint' or 'stress')
        """

        ret = False

        wmap = self.CurrentMap
        if wmap is not None:
            if sel_type == 'downpoint':
                sites = self.DownpointSites
            elif sel_type == 'stress':
                sites = self.StressSites

            if (x, y) in wmap:
                idx = wmap.get_site_index(x, y)
                data = wmap.get_site_data(idx)

                if not (self.TestPars['multisite'].value and len(sites) >= 4 and not data[sel_type]):
                    wmap.update_site_data(idx, {sel_type: not data[sel_type]})
                    ret = True

                self._broadcast_update()

        return ret

    def _broadcast_update(self):
        "Send a pubsub message that data has been updated"
        pub.sendMessage('hammer.data.update')

    def _check_multisite(self):
        "Remove any extraneous selected sites if multi site mode is enabled"
        wmap = self.CurrentMap

        if wmap and self.TestPars.get('multisite').value:
            dp_sites = self.DownpointSites[4:]
            st_sites = self.StressSites[4:]

            for site_x, site_y, data in dp_sites:
                idx = wmap.get_site_index(site_x, site_y)
                wmap.update_site_data(idx, {'downpoint': False})

            for site_x, site_y, data in st_sites:
                idx = wmap.get_site_index(site_x, site_y)
                wmap.update_site_data(idx, {'stress': False})

    def _init_offline(self):

        self._available_maps = {}

        # load available wafer maps
        if os.path.isdir(_default_map_dir):

            # check and load all .map files in directory
            for fname in filter(lambda x: os.path.splitext(x)[1] == '.map', os.listdir(_default_map_dir)):
                try:
                    # open map temporarily to extract sites, then create new map to ensure correct ordering (left to right, top to bottom)
                    temp_map = WaferMap(os.path.join(_default_map_dir, fname))
                    site_list = list(temp_map.sites)
                    site_list.sort()

                    # initialize wafer map with downpoint/stress booleans for each site if necessary
                    wmap = WaferMap()
                    wmap.set_mf(temp_map.major_flat)
                    wmap.set_xindex(temp_map.x_index)
                    wmap.set_yindex(temp_map.y_index)
                    wmap.set_xalpha(temp_map.x_alpha)
                    wmap.set_yalpha(temp_map.y_alpha)
                    for site_x, site_y, site_data in site_list:
                        site_data.update({'downpoint': False, 'stress': False})
                        wmap.add_site(site_x, site_y, site_data)

                    # add map to available dictionary
                    self._available_maps[os.path.splitext(os.path.basename(fname))[0]] = wmap

                except:
                    continue

        self._offline = True
        _logger.debug("Successfully initialized from localhost")

    def _init_online(self):
    
        if not MySQLdb:
            self._offline = True
            _logger.warning("`MySQLdb` package is not available - using offline mode.")
            return
            
        try:
            # initialize database connection and cursor
            db = _dbconnect()
            cur = db.cursor()

            # load available foundries sorted ascending
            cur.execute("SELECT foundry FROM {} ORDER BY foundry ASC".format(_db_table_foundry))
            foundry_list = cur.fetchall()

            # create list of foundries and select the first one
            self._available_foundries = [x['foundry'] for x in foundry_list]
            if self._available_foundries[0]:
                self.TestPars['foundry']._set_value(self._available_foundries[0])

            # reload process and mask lists (mask list handled by process list)
            self.reload_available_processes(cur)

            self._offline = False
            _logger.debug("Successfully initialized from database '{}' on host '{}'".format(_dbname, _dbhost))

        except Exception as e:
            if isinstance(e, MySQLdb.OperationalError):
                _logger.warning(_db_init_error_msg)
                self._offline = True
            else:
                _logger.error(e.message)

        finally:
            # close database connection
            cur.close()
            db.close()

    def _select_from_table(self, table, columns=[], values={}, cursor=None, distinct=False):
        """
        Get all of the requested columns for rows with data matching the given criteria in table.
        If no values given, excludes the WHERE clause and returns everything from the table.
        If no columns given, returns all columns in the table.
        Pass in an open cursor on the database to use an already existing connection.
        Use the SELECT DISTINCT clause if indicated, otherwise use regular SELECT.
        Returns the result of the cursor.execute() function (number of rows selected).

        Arguments:
            table       - string containing the name of the table in the dictionary
        Keywords:
            columns     - list of strings indicating the columns in the database table to return
            values      - dictionary with keys corresponding to column names in the table, and values to match
            cursor      - open cursor from an already existing database connection
            distinct    - boolean indicating whether to use SELECT DISTINCT or not
        """

        sel_str = ', '.join(columns)
        distinct_str = ' DISTINCT' if distinct else ''
        match_str = (' WHERE ' + ' AND '.join(['{}=%s'.format(x) for x in values])) if values else ''
        command = "SELECT{} {} FROM {}{}".format(distinct_str, sel_str, table, match_str)

        if cursor is None:
            db = _dbconnect()
            cur = db.cursor()
        else:
            cur = cursor

        result = cur.execute(command, values.values())

        if cursor is None:
            cur.close()
            db.close()

        return result

    def _insert_into_table(self, table, columns, values, cursor=None):
        """
        Inserts rows in the given table with the given values into the given columns.
        Pass in an open cursor on the database to use an already existing connection.
        Returns the result of the cursor.execute() function (number of rows inserted).

        Arguments:
            table   - string containing the name of the table in the dictionary
        Keywords:
            columns - list of strings containing the column names to insert into
            values  - list of n-tuples with the values to add, in the same order of the columns list, where n is the number of rows
            cursor  - open cursor from an already existing database connection
        """
        col_str = ', '.join(columns)
        row_val_str = '({})'.format(', '.join(['%s']*len(values[0])))
        rows_val_str = ','.join([row_val_str]*len(values))
        values_flat = list(itertools.chain.from_iterable(values))
        command = "INSERT INTO {} ({}) VALUES {}".format(table, col_str, rows_val_str)

        if cursor is None:
            db = _dbconnect()
            cur = db.cursor()
        else:
            cur = cursor

        result = cur.execute(command, values_flat)

        if cursor is None:
            cur.close()
            db.close()

        return result

    def reload_available_processes(self, cursor=None):
        "Reload processes given currently selected foundry. Pass in an open cursor on the database to use an already existing connection"
        try:
            # create cursor if necessary
            if cursor is not None:
                cur = cursor
            else:
                db = _dbconnect()
                cur = db.cursor()

            # load available processes sorted ascending
            if self.CurrentFoundry:
                cur.execute("SELECT process FROM {0} JOIN {1} ON {1}_id={1}.id WHERE foundry='{2}' ORDER BY process ASC".format(_db_table_process, _db_table_foundry, self.CurrentFoundry))
                process_list = cur.fetchall()
            else:
                process_list = []

            self._available_processes = [x['process'] for x in process_list]
            if self._available_processes[0]:
                self.TestPars['process']._set_value(self._available_processes[0])

            # reload masks after changing process
            self.reload_available_masks(cur)

        except Exception as e:
            if isinstance(e, MySQLdb.OperationalError):
                _logger.warning(_db_init_error_msg)
                self._offline = True
            else:
                _logger.error(e.message)

        finally:
            # close cursors created in this function
            if not cursor:
                # close database connection
                cur.close()
                db.close()

    def reload_available_masks(self, cursor=None):
        "Reload masks given currently selected process. Pass in an open cursor on the database to use an already existing connection"
        try:
            # create cursor if necessary
            if cursor is not None:
                cur = cursor
            else:
                db = _dbconnect()
                cur = db.cursor()

            map_cols = ['xidx', 'yidx', 'xalpha', 'yalpha', 'name']

            # if selected process is not standard, pull all maps from database
            if self.CurrentProcess not in self.AvailableProcesses:
                cur.execute("SELECT {0} FROM {1} ORDER BY name ASC".format(', '.join(map_cols), _db_table_mask))

            # query available wafer maps based on selected process
            elif self.CurrentProcess:
                cur.execute("SELECT {0} FROM {1} JOIN {2} ON {2}_id={2}.id WHERE process='{3}' ORDER BY name ASC".format(', '.join(map_cols), _db_table_mask, _db_table_process, self.CurrentProcess))

            maplist = cur.fetchall()

            # create and store WaferMap objects in local dictionary with data from database
            self._available_maps = OrderedDict()

            for m in maplist:
                wmap = WaferMap()
                wmap.set_mf('N')
                wmap.set_xindex(m['xidx'])
                wmap.set_yindex(m['yidx'])
                wmap.set_xalpha(m['xalpha'])
                wmap.set_yalpha(m['yalpha'])

                # query sorted site list for this map
                cur.execute("SELECT x, y FROM {0} JOIN {1} ON {1}_id={1}.id WHERE {1}.name='{2}' AND {3}_id IS NULL ORDER BY x ASC, y ASC".format(_db_table_site, _db_table_mask, m['name'], _db_table_waferinfo))
                sitelist = cur.fetchall()

                for s in sitelist:
                    wmap.add_site(s['x'], s['y'], {'downpoint': False, 'stress': False})

                self._available_maps[m['name']] = wmap

            self.TestPars['mask']._set_value(self.AvailableWaferMapNames[0])

        except Exception as e:
            if isinstance(e, MySQLdb.OperationalError):
                _logger.warning(_db_init_error_msg)
                self._offline = True
            else:
                _logger.error(e.message)

        finally:
            # close cursors created in this function
            if not cursor:
                # close database connection
                cur.close()
                db.close()

    @property
    def AvailableFoundries(self):
        return self._available_foundries

    @property
    def AvailableProcesses(self):
        return self._available_processes

    @property
    def AvailableWaferMapNames(self):
        return self._available_maps.keys()

    @property
    def CurrentFoundry(self):
        "Return the currently selected foundry based on the 'foundry' parameter value. Returns None if the specified foundry isn't available"
        selected_foundry = self.TestPars['foundry'].value
        if selected_foundry in self._available_foundries:
            return selected_foundry
        else:
            return None

    @property
    def CurrentProcess(self):
        "Return the currently selected process based on the 'process' parameter value."
        selected_process = self.TestPars['process'].value
        return selected_process

    @property
    def CurrentMap(self):
        "Return the currently selected wafer map based on the 'mask' parameter value. Returns None if the specified map isn't available"
        selected_map = self.TestPars['mask'].value
        if selected_map in self.AvailableWaferMapNames:
            return self._available_maps[selected_map]
        else:
            return None

    @property
    def CurrentMapName(self):
        "Return the currently selected wafer map name based on the 'mask' parameter value."
        return self._testpars['mask'].value

    @property
    def CurrentWorkingDirectory(self):
        return self._work_dir

    @CurrentWorkingDirectory.setter
    def CurrentWorkingDirectory(self, dir_path):
        if os.path.isdir(os.path.abspath(dir_path)):
            self._work_dir = os.path.abspath(dir_path)
        else:
            self._work_dir = None

    @property
    def DownpointSites(self):
        "Return a list of 2-tuples indicating which sites are currently selected for downpoint testing"
        sites = []

        if self.CurrentMap is not None:
            for site in self.CurrentMap:
                site_x, site_y, data = site
                if data.get('downpoint', False):
                    sites.append(site)

        return sites

    @property
    def Instruments(self):
        return INSTR_LIST

    @property
    def Modified(self):
        return self._modified

    @Modified.setter
    def Modified(self, mod):
        if isinstance(mod, bool):
            self._check_multisite()
            self._modified = mod
            self._broadcast_update()

    @property
    def Offline(self):
        return self._offline

    @property
    def ReadyForDownpointTest(self):
        if self.DownpointSites:
            return True
        else:
            return False

    @property
    def ReadyForStressTest(self):
        if self.StressSites:
            return True
        else:
            return False

    @property
    def StressSites(self):
        "Return a list of 2-tuples indicating which sites are currently selected for stress testing"
        sites = []

        if self.CurrentMap is not None:
            for site in self.CurrentMap:
                site_x, site_y, data = site
                if data.get('stress', False):
                    sites.append(site)

        return sites

    @property
    def TestPars(self):
        return self._testpars
