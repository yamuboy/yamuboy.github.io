from __future__ import print_function

import cPickle
import datetime
import os
import re
import sys

from hammer_gui.HammerDataMgr import HammerDataMgr, _dbconnect, _db_table_downpoint, _db_table_stress, _db_table_site, _db_table_waferinfo, _db_table_mask, _db_table_process, _db_table_foundry
from difflib import SequenceMatcher
from mautils import cli_utils

_test_types = ['downpoint0', 'downpoint1', 'stress']
_re_init_dp = re.compile(r'.+initial.+dp')
_re_post_dp = re.compile(r'.+post.+dp')
_re_stress = re.compile(r'^(?!\d{4}).+?stress')
_re_wafer = re.compile(r'(?P<mask>\d{4})(?P<lot>.+)_w?(?P<wafer>\d+)_(?P<scribe>.+)')
_re_periph = re.compile(r'.+?(?P<ngf>\d)x(?P<ugw>\d+)(?:um)?.+')
_re_device_re = re.compile(r'(?:.+?hammer[/\\]*(.+?)[/\\]*pkl.+)')
_general_str_valid = lambda x: re.match(r'^[a-zA-Z0-9_]+', x) is not None

_datamgr = HammerDataMgr(None)

def prompt_file_from_list(test_type, file_list):
    out_file = ''
    if file_list:
        if len(file_list) > 1:

            for idx, fname in enumerate(file_list):

                print('{}: {}'.format(idx, fname))
            
            while True:

                r = raw_input('Choose {} file: '.format(test_type)).strip()

                try:
                    print()
                    out_file = file_list[int(r)]
                    break

                except:
                    print('Invalid selection')

        else:
            out_file = file_list[0]
    return out_file

def prompt_test_type(fname):
    print('Filename: {}'.format(fname))
    for idx, test in enumerate(_test_types):
        print('\t{} - {}'.format(idx, test))

    while True:
        r = raw_input('Choose test type: ').strip()
        try:
            test_type = _test_types[int(r)]
            return test_type
        except KeyboardInterrupt:
            print('Exiting program')
            raise SystemExit
        except:
            print('Invalid selection')

def prompt_periphery(fname):
    print('Filename: {}'.format(fname))
    
    while True:
        r = raw_input('Enter ngf: ').strip()
        try:
            ngf = int(r)
            break
        except KeyboardInterrupt:
            print('Exiting program')
            raise SystemExit
        except:
            print('Invalid entry')

    while True:
        r = raw_input('Enter ugw: ').strip()
        try:
            ugw = float(r)
            break
        except KeyboardInterrupt:
            print('Exiting program')
            raise SystemExit
        except:
            print('Invalid entry')

    return (ngf, ugw)

def prompt_info(info, fname=None):
    if fname:
        print('Filename: {}'.format(fname))
    
    while True:
        r = raw_input('Enter {} name: '.format(info)).strip()
        try:
            if _general_str_valid(r):
                return r
            else:
                raise ValueError

        except KeyboardInterrupt:
            print('Exiting program')
            raise SystemExit

        except:
            print('Invalid entry')

def wafer_info_from_abspath(path):
    for s in os.path.abspath(path).split(os.sep):
        m = _re_wafer.match(s)

        if m:
            try:
                mask = m.group('mask')
                lot = str(float(m.group('lot').replace('p', '.')))
                wafer = int(m.group('wafer'))
                scribe = m.group('scribe')
                return {'mask': mask, 'lot': lot, 'wafer': wafer, 'scribe': scribe}
            except Exception as e:
                pass
        else:
            continue

        return None

def upload_to_db(data, test_type, info):

    db = None
    cur = None

    try:
        db = _dbconnect()
        cur = db.cursor()

        test_table = _db_table_stress if test_type == 'stress' else _db_table_downpoint
        test_columns =  ['{}.{}'.format(_db_table_stress, x) for x in ['time', 'elapsed', 'ig', 'id']] if test_type == 'stress' else \
                        ['{}.{}'.format(_db_table_downpoint, x) for x in ['time', 'level', 'dvg1', 'dvg10', 'dvg100', 'imax', 'ron', 'tvg100', 'tvg200', 'tvg300', 'leakig', 'leakid', 'leakis']]

        wafer_str = '{}_L{}_W{}_{}'.format(info['mask'], info['lot'], info['wafer'], info['scribe'])
        device_str = '{:d}x{:g}um_{}'.format(info['ngf'], info['ugw'], info['device'])

        # get foundry id
        result = _datamgr._select_from_table(_db_table_foundry, ['id'], {'foundry': info['foundry']}, cur)

        # if foundry wasn't found in database, skip upload
        if not result:
            print("Foundry '{}' not found in database, skipping upload to database".format(info['foundry']))
            return
        else:
            foundry_id = cur.fetchall()[0]['id']

        # get process id
        result = _datamgr._select_from_table(_db_table_process, ['id'], {'foundry_id': foundry_id, 'process': info['process']}, cur)

        # if process wasn't found in database, skip upload
        if not result:
            print("Process '{}' not found in database, skipping upload to database".format(info['process']))
            return
        else:
            process_id = cur.fetchall()[0]['id']

        # get mask id
        result = _datamgr._select_from_table(_db_table_mask, ['id'], {'process_id': process_id, 'name': info['mask']}, cur)

        # if mask wasn't found in database, skip upload
        if not result:
            print("Mask '{}' not found in database, skipping upload to database".format(info['mask']))
            return
        else:
            mask_id = cur.fetchall()[0]['id']

        # get current wafer/device ID
        col_val_pairs = {
                'foundry_id': foundry_id,
                'process_id': process_id,
                'mask_id'   : mask_id,
                'lot'       : info['lot'],
                'wafer'     : info['wafer'],
                'scribe'    : info['scribe'],
                'ngf'       : info['ngf'],
                'ugw'       : info['ugw'],
                'device'    : info['device'],
                'experiment': cli_utils.prompt_yes_no('Is this an experimental wafer?', default=False),
        }
        result = _datamgr._select_from_table(_db_table_waferinfo, ['id'], col_val_pairs, cur)

        # create entry for wafer/device if it isn't in the database yet
        if not result:
            print('Device type {} for wafer {} not found in database, creating new entry for it'.format(device_str, wafer_str))

            result = _datamgr._insert_into_table(_db_table_waferinfo, col_val_pairs.keys(), [tuple(col_val_pairs.values())], cur)

            # failed to create entry, abort upload
            if result != 1:
                raise RuntimeError("Unable to create entry '{}:{}' in database, aborting data upload".format(wafer_str, device_str))

            # inserted entry successfully, get entry id from cursor
            else:
                waferinfo_id = cur.lastrowid

        # already have entry for device on this wafer
        else:
            waferinfo_id = cur.fetchall()[0]['id']

        # iterate over site data
        for site, data in data.iteritems():
            site_x = int(site[:2])
            site_y = int(site[2:])
            site_str = '({:2d}, {:2d})'.format(site_x, site_y)

            # check if this test data for this site is already in database
            table = test_table
            table += ' JOIN {} ON {}.{}_id = {}.id'.format(_db_table_site, test_table, _db_table_site, _db_table_site)
            table += ' JOIN {} ON {}.{}_id = {}.id'.format(_db_table_waferinfo, _db_table_site, _db_table_waferinfo, _db_table_waferinfo)
            table += ' JOIN {} ON {}.{}_id = {}.id'.format(_db_table_mask, _db_table_waferinfo, _db_table_mask, _db_table_mask)
            table += ' JOIN {} ON {}.{}_id = {}.id'.format(_db_table_process, _db_table_mask, _db_table_process, _db_table_process)
            table += ' JOIN {} ON {}.{}_id = {}.id'.format(_db_table_foundry, _db_table_process, _db_table_foundry, _db_table_foundry)

            values = {
                        'foundry'   : info['foundry'],
                        'process'   : info['process'],
                        'name'      : info['mask'],
                        'lot'       : info['lot'],
                        'wafer'     : info['wafer'],
                        'scribe'    : info['scribe'],
                        'ngf'       : info['ngf'],
                        'ugw'       : info['ugw'],
                        'device'    : info['device'],
                        'x'         : site_x,
                        'y'         : site_y,
            }

            if 'downpoint' in test_type:
                values['level'] = int(test_type[-1])
            
            result = _datamgr._select_from_table(table, test_columns, values, cur)
            rows = cur.fetchall()

            if not result:
                # get site_id for this site
                col_val_pairs = {
                    'waferinfo_id' : waferinfo_id,
                    'x'            : site_x,
                    'y'            : site_y,
                }

                # site hasn't been tested at this wafer, create an entry for it
                result = _datamgr._select_from_table(_db_table_site, ['id'], col_val_pairs, cur)

                if not result:
                    print('Site {} for wafer {} not found in database, creating new entry for it'.format(site_str, wafer_str))
                    result = _datamgr._insert_into_table(_db_table_site, col_val_pairs.keys(), [tuple(col_val_pairs.values())], cur)

                    # failed to create entry, abort upload
                    if result != 1:
                        raise RuntimeError("Unable to create entry '({:2d}, {:2d})' in database, aborting data upload".format(site_x, site_y))

                    # inserted entry successfully, get entry id from cursor
                    else:
                        site_id = cur.lastrowid

                else:
                    site_id = cur.fetchall()[0]['id']

            # already have entry for this site
            else:
                print('{} data already exists for {} at site {}, skipping upload\n'.format(test_type, wafer_str, site_str))
                continue

            periph_mm = info['ngf']*info['ugw']*0.001
            amps_to_ma = 1000.0
            col_val_pairs = {
                'site_id'  : site_id,
                'time'     : info['time'],
            }

            # create entry in downpoint table
            if 'downpoint' in test_type:
                table = _db_table_downpoint

                col_val_pairs.update({
                    # get test level from last character of test type, 0=pre, 1=post
                    'level'    : int(test_type[-1]),
                    'dvg1'     : data[1]['fwd'][0][0],
                    'dvg10'    : data[1]['fwd'][0][1],
                    'dvg100'   : data[1]['fwd'][0][2],
                    'imax'     : data[1]['iv'][0]*amps_to_ma/periph_mm,
                    'ron'      : data[1]['iv'][1]*periph_mm,
                    'tvg100'   : data[1]['txfr'][0][0],
                    'tvg200'   : data[1]['txfr'][0][1],
                    'tvg300'   : data[1]['txfr'][0][2],
                    'leakid'   : data[1]['leakage'][0]*amps_to_ma/periph_mm,
                    'leakig'   : data[1]['leakage'][1]*amps_to_ma/periph_mm,
                    'leakis'   : data[1]['leakage'][2]*amps_to_ma/periph_mm,
                })

                cols = col_val_pairs.keys()
                vals = [tuple(col_val_pairs.values())]

            # create entry in stress table
            elif 'stress' == test_type:
                table = _db_table_stress

                num_total_points = len(data[1]['time'])

                # crude method to decimate total test data to a more managable number
                if num_total_points > 15:
                    indices =   range(num_total_points/10) + \
                                range(num_total_points/10, num_total_points/2, num_total_points/10) + \
                                range(num_total_points/2, num_total_points, num_total_points/5) + \
                                [(num_total_points - 1)]
                else:
                    indices = range(num_total_points)

                # populate output data arrays
                elapsed_times = []
                gate_currents = []
                drain_currents = []
                for idx in indices:
                    elapsed_times.append(data[1]['time'][idx])
                    gate_currents.append(data[1]['ig'][idx]*amps_to_ma/periph_mm)
                    drain_currents.append(data[1]['id'][idx]*amps_to_ma/periph_mm)

                vals = [ ]
                for (t, g, d) in zip(elapsed_times, gate_currents, drain_currents):
                    new_dict = col_val_pairs.copy()
                    new_dict.update({
                            'elapsed'   : t,
                            'ig'        : g,
                            'id'        : d,
                    })
                    vals.append(new_dict)

                cols = vals[0].keys()
                vals = [tuple(x.values()) for x in vals]

            # insert result into appropriate table
            result = _datamgr._insert_into_table(table, cols, vals, cur)

            if result != len(vals):
                raise RuntimeError('Error inserting data into database, aborting upload')
            else:
                print('Successfully uploaded {} data from {} at site {} to database'.format(test_type, wafer_str, site_str))

    except Exception as e:
        raise

    finally:
        if cur:
            cur.close()
        if db:
            db.close()

if __name__ == '__main__':

    info = {}
    paths = None

    if len(sys.argv) > 1:
        paths = sys.argv[1:]
    
    if not paths:
        raise SystemExit

    info['foundry'] = prompt_info('foundry')
    info['process'] = prompt_info('process')

    for path in paths:
        path_gen = os.walk(path)

        for cur_pos in path_gen:

            if not all(x in cur_pos[0] for x in ['hammer', 'pkl']):
                continue

            dirpath = cur_pos[0]

            files = os.listdir(dirpath)

            for datafile in filter(lambda x: 'pkl' in x, files):
                test_type = _test_types[0] if _re_init_dp.match(datafile) else \
                            _test_types[1] if _re_post_dp.match(datafile) else \
                            _test_types[2] if _re_stress.match(datafile) else \
                            None
                
                if test_type:

                    filepath = os.path.join(dirpath, datafile)
                    info.update(wafer_info_from_abspath(filepath))

                    periph_match = _re_periph.match(filepath)
                    if periph_match:
                        info['ngf'], info['ugw'] = int(periph_match.group('ngf')), float(periph_match.group('ugw'))
                    else:
                        info['ngf'], info['ugw'] = prompt_periphery(datafile)

                    info['device'] = prompt_info('device', datafile)
                    info['time'] = datetime.datetime.fromtimestamp(os.path.getctime(filepath))

                    with open(filepath, 'rb') as fp:
                        data = cPickle.load(fp)

                    # prompt for sites if multisite stress file (which erroneously is formatted as (cfg, [data0, data1, data2]))
                    new_data = None
                    if not isinstance(data, dict) and isinstance(data, tuple):
                        new_data = {}
                        for idx, site_data in enumerate(data[1]):
                            site_name = prompt_info('site {:d}'.format(idx), datafile)
                            new_data[site_name] = (data[0], data[1][idx])
                    if new_data:
                        data = new_data

                    print()
                    print('Path: {}'.format(filepath))
                    print('File: {}'.format(os.path.basename(filepath)))
                    print('Test Type: {}'.format(test_type))
                    print('Sites: {}'.format(', '.join(data.keys())))
                    for key, val in info.iteritems():
                        print('{}: {}'.format(key, val))
                    print()

                    if cli_utils.prompt_yes_no('Upload to database?', False):
                        upload_to_db(data, test_type, info)
                        print()

    raw_input('Press enter to quit.')

