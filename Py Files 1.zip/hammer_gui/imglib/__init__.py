# import build first, this will build the image library if necessary
import build

# import the image library, this should be built upon import of build
import img
from build import initialize_art_provider
