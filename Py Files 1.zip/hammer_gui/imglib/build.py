import os

from wx import ArtProvider, NullBitmap
from wxutils.image_lib import scan_and_write

_libdir = os.path.dirname(os.path.abspath(__file__))
_libfile = os.path.join(_libdir, 'img.py')

# create image library if necessary
if not os.path.isfile(_libfile):
    scan_and_write(_libdir, libname=_libfile)

class ImageLibArtProvider(ArtProvider):
    "art provider to provide bitmaps for the wx application"

    def __init__(self):
        "initializer"
        super(ImageLibArtProvider, self).__init__()

    def CreateBitmap(self, artid, client, size):
        "return bitmaps for recognized id strings"
        # this method completely ignores the client and size arguments
        # since all bitmaps that are managed only come in a single size
        from img import get_bitmap, ImageNotAvailable
        
        try:
            return get_bitmap(artid)
        except ImageNotAvailable:
            pass

        # no match
        return NullBitmap

_provider_is_initialized = False
def initialize_art_provider():
    "initialize the art provider"
    global _provider_is_initialized


    # initialize art provider
    if not _provider_is_initialized:
        ArtProvider.Push(ImageLibArtProvider())
        _provider_is_initialized = True

