#!/usr/bin/env python2
import wx

from hammer_gui.HammerGUIFrame import HammerGUIFrame

# create app and main window and run
ex = wx.App()
frame = HammerGUIFrame(None, debug=False)
frame.Show()
ex.SetTopWindow(frame)
ex.MainLoop()
