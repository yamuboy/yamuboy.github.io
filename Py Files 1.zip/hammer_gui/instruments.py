from wxtestgui import Instr

INSTR_LIST = [
    Instr('prober',family='prober',label='Prober'),
    Instr('vga',family='bias',label='Gate Supply A'),
    Instr('vda',family='bias',label='Drain Supply A'),
    Instr('vgb',family='bias',label='Gate Supply B'),
    Instr('vdb',family='bias',label='Drain Supply B'),
    Instr('vgc',family='bias',label='Gate Supply C'),
    Instr('vdc',family='bias',label='Drain Supply C'),
    Instr('vgd',family='bias',label='Gate Supply D'),
    Instr('vdd',family='bias',label='Drain Supply D'),
]