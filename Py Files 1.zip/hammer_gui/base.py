# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version Feb  9 2019)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

from .panels.HammerGUIMapPanel import HammerGUIMapPanel
from .panels.HammerGUIControlPanel import HammerGUIControlPanel
from .panels.HammerGUIPlotPanel import HammerGUIPlotPanel
from .panels.HammerGUILogPanel import HammerGUILogPanel
import wx
import wx.xrc

###########################################################################
## Class Frame
###########################################################################

class Frame ( wx.Frame ):

	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Rapid DC Stress Test (Hammer)", pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )

		self.SetSizeHints( wx.Size( -1,-1 ), wx.DefaultSize )

		self.menu_bar = wx.MenuBar( 0 )
		self.menu_file = wx.Menu()
		self.menu_file_open = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Open Setup..."+ u"\t" + u"Ctrl+O", u"Open a previously saved configuration", wx.ITEM_NORMAL )
		self.menu_file_open.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self.menu_file.Append( self.menu_file_open )

		self.menu_file_save = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Save Setup..."+ u"\t" + u"Ctrl+S", u"Save current configuration to default location", wx.ITEM_NORMAL )
		self.menu_file_save.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_SAVE, wx.ART_MENU ) )
		self.menu_file.Append( self.menu_file_save )

		self.menu_file_saveas = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Save Setup As..."+ u"\t" + u"Ctrl+Shift+S", u"Save current configuration to specified location", wx.ITEM_NORMAL )
		self.menu_file_saveas.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_SAVE_AS, wx.ART_MENU ) )
		self.menu_file.Append( self.menu_file_saveas )

		self.menu_file.AppendSeparator()

		self.menu_file_instruments = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Configure Instruments..."+ u"\t" + u"Ctrl+I", u"Open instrument configuration dialog", wx.ITEM_NORMAL )
		self.menu_file_instruments.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_REMOVABLE, wx.ART_MENU ) )
		self.menu_file.Append( self.menu_file_instruments )

		self.menu_file_workdir = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Set Working Directory..."+ u"\t" + u"Ctrl+D", wx.EmptyString, wx.ITEM_NORMAL )
		self.menu_file_workdir.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_NEW_DIR, wx.ART_MENU ) )
		self.menu_file.Append( self.menu_file_workdir )

		self.menu_file_offline = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Offline Mode", u"Run in offline mode (configuration and data stored locally)", wx.ITEM_CHECK )
		self.menu_file.Append( self.menu_file_offline )

		self.menu_file.AppendSeparator()

		self.menu_file_quit = wx.MenuItem( self.menu_file, wx.ID_ANY, u"Quit..."+ u"\t" + u"Alt+F4", u"Close program", wx.ITEM_NORMAL )
		self.menu_file_quit.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_QUIT, wx.ART_MENU ) )
		self.menu_file.Append( self.menu_file_quit )

		self.menu_bar.Append( self.menu_file, u"File" )

		self.menu_help = wx.Menu()
		self.menu_help_about = wx.MenuItem( self.menu_help, wx.ID_ANY, u"About"+ u"\t" + u"F1", u"About this program", wx.ITEM_NORMAL )
		self.menu_help_about.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_HELP, wx.ART_MENU ) )
		self.menu_help.Append( self.menu_help_about )

		self.menu_bar.Append( self.menu_help, u"Help" )

		self.SetMenuBar( self.menu_bar )

		self.status_bar = self.CreateStatusBar( 1, wx.STB_SIZEGRIP, wx.ID_ANY )
		mainSizer = wx.GridBagSizer( 0, 0 )
		mainSizer.SetFlexibleDirection( wx.BOTH )
		mainSizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )

		self.mapPanel = HammerGUIMapPanel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		mainSizer.Add( self.mapPanel, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND |wx.ALL, 1 )

		self.controlPanel = HammerGUIControlPanel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		mainSizer.Add( self.controlPanel, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND|wx.FIXED_MINSIZE, 1 )

		self.plotPanel = HammerGUIPlotPanel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		mainSizer.Add( self.plotPanel, wx.GBPosition( 0, 1 ), wx.GBSpan( 1, 1 ), wx.EXPAND |wx.ALL, 1 )

		self.logPanel = HammerGUILogPanel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		mainSizer.Add( self.logPanel, wx.GBPosition( 1, 1 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 1 )


		mainSizer.AddGrowableCol( 1 )
		mainSizer.AddGrowableRow( 0 )

		self.SetSizer( mainSizer )
		self.Layout()
		mainSizer.Fit( self )

		self.Centre( wx.BOTH )

		# Connect Events
		self.Bind( wx.EVT_CLOSE, self.onQuit )
		self.Bind( wx.EVT_MENU, self.onOpenSetup, id = self.menu_file_open.GetId() )
		self.Bind( wx.EVT_MENU, self.onSaveSetup, id = self.menu_file_save.GetId() )
		self.Bind( wx.EVT_MENU, self.onSaveSetupAs, id = self.menu_file_saveas.GetId() )
		self.Bind( wx.EVT_MENU, self.onShowInstrumentDialog, id = self.menu_file_instruments.GetId() )
		self.Bind( wx.EVT_MENU, self.onSetWorkDir, id = self.menu_file_workdir.GetId() )
		self.Bind( wx.EVT_MENU, self.onModeChange, id = self.menu_file_offline.GetId() )
		self.Bind( wx.EVT_MENU, self.onQuit, id = self.menu_file_quit.GetId() )
		self.Bind( wx.EVT_MENU, self.showAboutDialog, id = self.menu_help_about.GetId() )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onQuit( self, event ):
		event.Skip()

	def onOpenSetup( self, event ):
		event.Skip()

	def onSaveSetup( self, event ):
		event.Skip()

	def onSaveSetupAs( self, event ):
		event.Skip()

	def onShowInstrumentDialog( self, event ):
		event.Skip()

	def onSetWorkDir( self, event ):
		event.Skip()

	def onModeChange( self, event ):
		event.Skip()


	def showAboutDialog( self, event ):
		event.Skip()


