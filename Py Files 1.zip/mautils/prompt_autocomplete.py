from glob import glob
try:
    import readline
except ImportError as e:
    if e.message.split()[-1] == 'readline':
        print 'Missing module readline. If on Windows, download the \'pyreadline\' package.'
        raise SystemExit

def auto_complete(text, state):
    return (glob(text+'*')+[None])[state]

# setup prompt autocompletion
readline.set_completer_delims(' \t\n;')
readline.parse_and_bind("tab: complete")
readline.set_completer(auto_complete)