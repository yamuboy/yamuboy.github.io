#!/usr/bin/env python

import math
import numpy as np
from datetime import datetime
from network_params import Touchstone

# import TKinter and some utils
from Tkinter import *
import tkFileDialog
import tkMessageBox

#
# define a dialog box that will be used for the fixture configuration
#
class FixtureDialog(Toplevel):
    
    def __init__(self,parent):
        
        # init the base class
        Toplevel.__init__(self,parent,padx=4,pady=6)
        # hook this dialog to the parent window
        self.transient(parent)
        # set the title
        self.title('Fixture Configuration')
        # set the parent in an easy-to-access property
        self.parent = parent
        
        # get the mode from the parent and create the dialog accordingly
        modestr = parent.work_mode.get()
        if modestr.find('1') != -1:
            mode = 1
        else:
            mode = 2
        
        # get the list of available calsets
        try:
            csets = tuple(parent.get_calsets())
        except:
            self.destroy()
            raise
        
        if len(csets) < 2:
            self.destroy()
            raise Exception("At least 2 calsets must be available in the PNA.")
        
        # outer cal set selection
        fr = Frame(self)
        fr.grid(sticky=W+E)
        Label(fr, text='Outer calset (furthest from DUT):').pack(side=LEFT)
        OptionMenu(fr,parent.outer_calset,*csets).pack(side=LEFT,padx=8)
        
        # inner cal set selection
        fr = Frame(self)
        fr.grid(sticky=W+E)
        Label(fr, text='Inner calset (closest to DUT):').pack(side=LEFT)
        OptionMenu(fr,parent.inner_calset,*csets).pack(side=LEFT,padx=8)
        
        #
        # create the fixture filename entry fields
        #
        
        fn = 'Filename:'
        if mode == 2:
            fn = 'Port 1 Filename:'
        
        fr = Frame(self)
        fr.grid(sticky=W+E)
        Label(fr, text=fn).pack(side=LEFT)
        Entry(fr,textvariable=parent.p1_filename,width=25).pack(side=LEFT,padx=6)
        Button(fr,text='Browse...',command=self.f1_filename_browse).pack(side=LEFT)
        
        if mode == 2:
            fr = Frame(self)
            fr.grid(sticky=W+E)
            Label(fr, text='Port 2 filename:').pack(side=LEFT)
            Entry(fr,textvariable=parent.p2_filename,width=25).pack(side=LEFT,padx=6)
            Button(fr,text='Browse...',command=self.f2_filename_browse).pack(side=LEFT)
            
        fr = Frame(self)
        fr.grid(sticky=W+E)
        
        port_options = ('1','2')
        if self.parent.fourport_pna:
            port_options = ('1','2','3','4')
        
        n = 0
        if mode == 2:
            Label(fr, text='Outer Calset Port 1').grid(row=n,sticky=W)
            OptionMenu(fr,self.parent.outer_p1,*port_options).grid(row=n,column=1,sticky=W)
            n += 1
            
            Label(fr, text='Outer Calset Port 2').grid(row=n,sticky=W)
            OptionMenu(fr,self.parent.outer_p2,*port_options).grid(row=n,column=1,sticky=W)
            n += 1
            
            Label(fr, text='Inner Calset Port 1').grid(row=n,sticky=W)
            OptionMenu(fr,self.parent.inner_p1,*port_options).grid(row=n,column=1,sticky=W)
            n += 1
            
            Label(fr, text='Inner Calset Port 2').grid(row=n,sticky=W)
            OptionMenu(fr,self.parent.inner_p2,*port_options).grid(row=n,column=1,sticky=W)
            n += 1            
        else:
            Label(fr, text='Outer Calset Port').grid(row=n,sticky=W)
            OptionMenu(fr,self.parent.outer_p1,*port_options).grid(row=n,column=1,sticky=W)
            n += 1
            
            Label(fr, text='Inner Calset Port').grid(row=n,sticky=W)
            OptionMenu(fr,self.parent.inner_p1,*port_options).grid(row=n,column=1,sticky=W)
            n += 1
        
        #
        # create buttons
        #
        
        fr = Frame(self,pady=20)
        fr.grid(sticky=W+E)
        Button(fr,text='OK',width=12,command=self.run).grid(row=0)
        Button(fr,text='Cancel',width=12,command=self.cancel).grid(row=0,column=1)
        
        # grab mouse and keyboard events and the focus
        self.grab_set()
        self.focus_set()
        
        # bind the escape key to cancel
        self.bind('<Escape>',self.cancel)
        
        # handle delete window events
        self.protocol("WM_DELETE_WINDOW",self.cancel)
        
        # set the initial position
        self.geometry("+%d+%d" % (parent.winfo_rootx()+30,parent.winfo_rooty()+30))
        
    def f1_filename_browse(self):
        """Browse for a SaveAs filename."""
        fname = tkFileDialog.asksaveasfilename(parent=self)
        if fname:
            self.parent.p1_filename.set(fname)        
        
    def f2_filename_browse(self):
        """Browse for a SaveAs filename."""
        fname = tkFileDialog.asksaveasfilename(parent=self)
        if fname:
            self.parent.p2_filename.set(fname)        
    
    def run(self,event=None):
        """Run the fixture de-embed."""
        try:
            self.parent.set_message('Running.')
            self.parent.run()
        except Exception, e:
            import traceback
            emsg = traceback.format_exc()
            # pop up an error dialog
            self.parent.set_message('An error occurred.')
            tkMessageBox.showerror('Error', emsg, parent=self)
            return
            
        self.parent.set_message('Fixture files created successfully.')
        self.destroy()
        
    def cancel(self,event=None):
        """Cancel without doing anything."""
        self.parent.focus_set()
        self.destroy()
        

class MainWindow(Frame):
    """Main application window."""
    
    def __init__(self,parent,**kwargs):
        """Initializer."""
        # set keywords and init the parent object
        kwargs['padx'] = 3
        kwargs['pady'] = 5
        Frame.__init__(self,parent,**kwargs)
        
        # define the maximum port number
        self.MAX_PORT = 2
        # define the channel
        self.chan = 1
        # define data format parameters
        self.freqfmt = 'HZ'
        self.datafmt = 'MA'
        # PNA pyVISA object
        self.pna = None
        
        #
        # create the various parts of the main window
        #
        
        # variables to store stuff from the various interactive widgets
        self.pna_address = StringVar(value="GPIB::16")
        self.outer_calset = StringVar()
        self.inner_calset = StringVar()
        self.work_mode = StringVar()
        self.p1_filename = StringVar()
        self.p2_filename = StringVar()
        self.sv_freqfmt = StringVar()
        self.sv_datafmt = StringVar()
        self.outer_p1 = StringVar()
        self.outer_p2 = StringVar()
        self.inner_p1 = StringVar()
        self.inner_p2 = StringVar()
        
        self.outer_p1.set('1')
        self.outer_p2.set('2')
        self.inner_p1.set('1')
        self.inner_p2.set('2')
        
        self.fourport_pna = False
        
        fs = LabelFrame(self, text='Configuration')
        fs.grid(sticky=N+S+W+E,columnspan=2,ipady=8,ipadx=4)
        n = 0
        
        # create the PNA address field
        Label(fs, text='PNA Address:').grid(row=n,sticky=W)
        Entry(fs,textvariable=self.pna_address,width=16).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the measurement mode selection
        Label(fs, text='Generate fixtures:').grid(row=n,sticky=W)
        options = ("2-Port","1-Port")
        self.work_mode.set(options[0])
        OptionMenu(fs,self.work_mode,*options).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the frequency format selection
        Label(fs, text='Frequency Format:').grid(row=n,sticky=W)
        options = ("Hz","KHz","MHz","GHz")
        self.sv_freqfmt.set(options[0])
        OptionMenu(fs,self.sv_freqfmt,*options).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the data format selection
        Label(fs, text='Data Format:').grid(row=n,sticky=W)
        options = ("MA","RI","DB")
        self.sv_datafmt.set(options[0])
        OptionMenu(fs,self.sv_datafmt,*options).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the buttons
        Button(self, text='Run...', command=self.dialog_popup, width=10).grid(row=n,columnspan=2,pady=15)
        n += 1
        
        # create the status message area
        self.msg_text = StringVar(value='Ready.')
        Label(self, textvariable=self.msg_text, anchor=W, relief=GROOVE).grid(padx=2,columnspan=2,sticky=N+S+E+W)
        
        # bind the enter and escape keys
        #self.bind('<Enter>', self.dialog_popup)
        self.bind('<Escape>', self.quit)
        
    def dialog_popup(self,event=None):
        """Create the fixture dialog."""
        try:
            dialog = FixtureDialog(self)
            self.wait_window(dialog)
        except:
            import traceback
            emsg = traceback.format_exc()
            # pop up an error dialog
            self.set_message('An error occurred.')
            tkMessageBox.showerror('Error', emsg, parent=self)
            return
    
    def quit(self,event=None):
        """Quit the program."""
        self.winfo_toplevel().destroy()
        
    def run(self):
        """Run the deembedding stuff - this is called from the dialog window."""
        
        # get the string mode and set an integer mode to make things easier
        modestr = self.work_mode.get()
        if modestr.find('1') != -1:
            mode = 1
        else:
            mode = 2
        
        # get calsets and filenames
        outer_cset = self.outer_calset.get()
        inner_cset = self.inner_calset.get()
        f1_fname = self.p1_filename.get()
        f2_fname = self.p2_filename.get()
        
        # set up formats
        self.freqfmt = self.sv_freqfmt.get().upper()
        self.datafmt = self.sv_datafmt.get().upper()
        
        # error checking
        if not outer_cset:
            raise Exception('The outer calset must be specified.')
        if not inner_cset:
            raise Exception('The inner calset must be specified.')
        if outer_cset == inner_cset:
            raise Exception('The outer and inner calsets cannot be the same.')
        if not f1_fname:
            if mode == 2:
                raise Exception('The port 1 filename must be specified.')
            else:
                raise Exception('A filename must be specified.')
        if mode == 2 and not f2_fname:
            raise Exception('The port 2 filename must be specified.')
        
        # create a connection to the 8364B
        self._open_pna()
        
        # select and verify the outer cal set
        self.pna.write("SENS%d:CORR:CSET:ACT '%s', 1"%(self.chan,outer_cset) )
        msg = self.pna.ask("SENS%d:CORR:CSET:ACT? name" % self.chan)
        if msg.strip("'\"") != outer_cset:
            raise Exception("Error selecting calset '%s' != '%s'" % (outer_cset,msg))
        
        # read the frequency list
        self.flist = self.pna.ask_for_values( "FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?" % self.chan )
        
        # read the outer cal set coeffs
        op1 = 1
        op2 = 2
        try:
            op1 = int(self.outer_p1.get())
            op2 = int(self.outer_p2.get())
        except Exception:
            pass
        if mode == 2:
            cco1 = self._read_coeffs(op1)
            cco2 = self._read_coeffs(op2)
        elif mode == 1:
            cco1 = self._read_coeffs(op1)
        else:
            raise Exception("Bug! Invalid mode.")
            
        # select and verify the inner cal set
        self.pna.write("SENS%d:CORR:CSET:ACT '%s', 1"%(self.chan,inner_cset) )
        msg = self.pna.ask("SENS%d:CORR:CSET:ACT? name" % self.chan)
        if msg.strip("'\"") != inner_cset:
            raise Exception("Error selecting calset '%s'" % inner_cset)
        
        # verify the frequency lists
        flist2 = self.pna.ask_for_values( "FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?" % self.chan )
        if( len(self.flist) != len(flist2) ): raise Exception("The frequency lists for the cal sets do not match.")
        for i,f in enumerate(self.flist):
            if( f != flist2[i] ): raise Exception("The frequency lists for the cal sets do not match.")
            
        # read the inner cal set coeffs and compute the fixture file(s)
        ip1 = 1
        ip2 = 2
        try:
            ip1 = int(self.inner_p1.get())
            ip2 = int(self.inner_p2.get())
        except Exception:
            pass
        if mode == 2:
            cci1 = self._read_coeffs(ip1)
            cci2 = self._read_coeffs(ip2)
            self._create_fixture_file(f1_fname,cci1,cco1)
            self._create_fixture_file(f2_fname,cci2,cco2)
        elif mode == 1:
            cci1 = self._read_coeffs(ip1)
            self._create_fixture_file(f1_fname,cci1,cco1)
        else:
            raise Exception("Bug! Invalid mode.")
    
    def set_message(self, msg):
        """Set the status area message."""
        self.msg_text.set(msg)
        
    def _read_coeffs(self, port):
        # read cal coeffs
        edir = self.pna.ask_for_values( "FORM:DATA REAL,64;BORD SWAP;:SENS%d:CORR:CSET:DATA? EDIR,%d,%d"%(self.chan,port,port) )
        esrm = self.pna.ask_for_values( "FORM:DATA REAL,64;BORD SWAP;:SENS%d:CORR:CSET:DATA? ESRM,%d,%d"%(self.chan,port,port) )
        erft = self.pna.ask_for_values( "FORM:DATA REAL,64;BORD SWAP;:SENS%d:CORR:CSET:DATA? ERFT,%d,%d"%(self.chan,port,port) )
        # convert real-valued interleaved arrays into arrays of complex numbers
        cedir = []
        cesrm = []
        cerft = []
        for i in range(len(edir)//2):
            cedir.append(complex(edir[2*i],edir[2*i+1]))
            cesrm.append(complex(esrm[2*i],esrm[2*i+1]))
            cerft.append(complex(erft[2*i],erft[2*i+1]))
        return cedir,cesrm,cerft
    
    def _scale_freq(self, frhz):
        """Scale frequency to the correct value for the file."""
        if self.freqfmt == 'KHZ':
            return frhz*1.e-3
        elif self.freqfmt == 'MHZ':
            return frhz*1.e-6
        elif self.freqfmt == 'GHZ':
            return frhz*1.e-9
        else:
            return frhz
    
    def _convert_data(self, param):
        """Convert sparams to the necessary format for storing them in a file."""
        if self.datafmt in ['MA','DB']:
            mag = abs(param)
            ang = math.degrees(math.atan2(param.imag,param.real))
            if self.datafmt == 'DB':
                mag = 20.0*math.log10(mag)
                
            return mag,ang
        else:
            return param.real,param.imag    
    
    def _create_fixture_file(self, fname, inner_coeffs, outer_coeffs):
        """Create a fixture file by doing the computations and writing the S2P file."""
        edir1c,esrm1c,erft1c = inner_coeffs
        edir2c,esrm2c,erft2c = outer_coeffs
        if len(self.flist) != len(edir1c) or len(self.flist) != len(edir2c):
            raise Exception("Size mismatch: len(flist) != len(coeff).")
        # use numpy arrays to make the math quick and efficient
        edir1 = np.array(edir1c)
        esrm1 = np.array(esrm1c)
        erft1 = np.array(erft1c)
        edir2 = np.array(edir2c)
        esrm2 = np.array(esrm2c)
        erft2 = np.array(erft2c)
        # compute fixture
        t1 = edir1 - edir2
        s11 = t1 / (erft2 + esrm2*t1)
        t2 = 1. - esrm2*s11
        s12s21 = erft1/erft2 * t2
        s22 = esrm1 - s12s21*esrm2/t2
        # correct s21/s12
        s12 = correct_phase(self.flist,np.sqrt(s12s21))
        
        # write the file
        ts = Touchstone()
        ts.header = '! Generated by pyFixture v1.0\n! Date: %s\n'%datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ts.format = '# %s S %s R 50'%(self.freqfmt,self.datafmt)
        for i,fr in enumerate(self.flist):
            ts.insert(fr,[s11[i],s12[i],s12[i],s22[i]])        
        ts.write(fname)
    
    def _open_pna(self):
        """Convenience method for opening the PNA."""
        import visa
        if not self.pna:
            rsc_name = self.pna_address.get()
            self.pna = visa.instrument(rsc_name, values_format=visa.double)
    
    def get_calsets(self):
        """Read the available calsets from the PNA."""
        # create a connection to the PNA
        self._open_pna()
        # check if it is a 4-port PNA
        model = self.pna.ask('*IDN?').split(',')[1]
        if model.find('N52') != -1:
            # this isn't technically the correct way to rigorously check
            # but it works for the instruments we deal with
            self.fourport_pna = True          
        # get the calatog of cal sets
        return self.pna.ask("SENS%d:CORR:CSET:CAT? name" % self.chan).strip('"').split(',')
            
def write_debug_mdif(fname, flist, coeffs):
    """Write the cal coeffs to an MDIF file for debugging in ADS."""
    edir,esrm,erft = coeffs
    f = open(fname, "w+")
    f.write("! cal coeffs\n")
    f.write("BEGIN CALDATA\n")
    f.write("% freq(real) edir(complex) esrm(complex) erft(complex)\n")
    for i,fr in enumerate(flist):
        f.write( "%.4e %+.4e %+.4e %+.4e %+.4e %+.4e %+.4e\n" % (fr,edir[i].real,edir[i].imag,esrm[i].real,esrm[i].imag,erft[i].real,erft[i].imag) )
    f.write( "END\n" )
    f.close()

def argdeg(val):
    """Compute the argument (phase) of a complex number in degrees."""
    return math.degrees(math.atan2(val.imag,val.real))

def correct_phase(fl, inp):
    """Correct the phase of the S12/S21 data during fixture computation."""
    j = complex(0.,1.)
    phasel = []
    for i,v in enumerate(inp):
        if( i==0 ): continue
        ph1 = argdeg(inp[i-1])
        ph2 = argdeg(v)
        if( ph1 < 0. ): ph1 += 360.
        if( ph2 < 0. ): ph2 += 360.
        if( ph1 > ph2 ): phasel.append( (ph2 - ph1) / (fl[i]-fl[i-1]) )
        
    n = len(phasel)
    if n < 2:
        print "Warning: phase correction could not be applied."
        return inp
	
    # sort the list of phase velocities and pick the median value
    phasel.sort()
    
    # determine the phase velocity
    # for data sets with more than 4 points pick the median
    # for shorter data sets, do special handling
    if n == 2:
        p = (phasel[0] + phasel[1]) * 0.5
    elif n == 3:
        p = phasel[1]
    elif n == 4:
        p = (phasel[1] + phasel[2]) * 0.5
    else:
        p = phasel[n//2]
        
    # correct the input data
    # this is complicated because of 90 degree phase shifts
    # that can occur
    for i,v in enumerate(inp):
        expect = math.fmod(fl[i]*p,360.)
        actual = argdeg(v)
        if( expect < 0. ): expect += 360.
        if( actual < 0. ): actual += 360.
        err = math.fabs(expect-actual)

        if( err > 45. and err < 315. ):
            # need to correct
            if( err > 135. and err < 225. ):
                # correct by 180
                inp[i] *= -1.
            elif( err <= 135. ):
                # correct by 90, need to figure out which way
                if( expect > actual ): inp[i] *= j
                else: inp[i] *= -j
            else:
                # correct by 90, these cases are the opposite
                # of those above
                if( expect > actual ): inp[i] *= -j
                else: inp[i] *= j
                
    return inp

if __name__ == "__main__":
    raise RuntimeError("This module should not be run directly.")
    
