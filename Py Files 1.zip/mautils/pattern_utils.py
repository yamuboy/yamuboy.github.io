import re
import os

width_re = r'\#define .+_width (\d+)\n'
length_re = r'\#define .+_height (\d+)\n'
name_re = r'.+ (.+)_bits.+\n'

class fill_pattern(object):
    """
    Class that encapsulates a fill pattern

    Members:
    _width - width of the pattern (int)
    _height - height of the pattern (int)
    _name - name of the pattern (str)

    _lines - list of ints, each int represents one line of the pattern in binary

    """
    _width = 16
    _height = 16
    _name = "Pattern"
    _lines = []

    def __init__(self, filename=None):
        self._width = 0
        self._height = 0
        self._name = ""
        self._lines = [ ]

        if filename is not None:
            self.read_ADS_pattern(filename)

    def print_pattern(self):
        "Prints the pattern to console"
        for line in self._lines:
            print ("{0:0%sb}"%self._width).format(line)

    def print_pattern_awr_lpf(self):
        """
        Prints pattern to console in AWR LPF format
        """
        #   Sample AWR LPF pattern format
        #
        #   $LAYER_FILL_PATTERN_BEGIN
        #   ( display forward_slash (
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #   ) )

        print "$LAYER_FILL_PATTERN_BEGIN\n"
        print "( display %s (" % self._name

        for line in self._lines:
            print "  ( " + " ".join(("{0:0%sb}"%self._width).format(line)) + " )"

        print ") )"


    def read_ADS_pattern(self, filename):
        """
        Reads an ADS pattern file

        Arguments:

        filename - path to the "*.pattern" file
        
        """

        #   A sample ADS pattern file looks as follows:
        #
        #   #define pat1_width 16
        #   #define pat1_height 16
        #   static unsigned char pat1_bits[] = {
        #      0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa,
        #      0x7f, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa,
        #      0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa};
        #
        #   Extract width of pattern from line 0
        #   Extract height of pattern from line 1
        #   Extract name of pattern from line 2
        #   Extract pattern lines from lines 3:

        fp = open(filename)
        lines = fp.readlines()

        # get pattern width, height, and name
        self._width = int(re.match(width_re, lines[0]).group(1))
        self._height = int(re.match(length_re, lines[1]).group(1))
        self._name = re.match(name_re, lines[2]).group(1)

        # parse pattern lines
        
        # combine all 8-bit segments into one string
        all_segments = "".join(lines[3:]).replace('\n', '')[:-2]

        # parse all 8-bit segments into list
        segments = [int(x.strip()[2:4], 16) for x in re.split(r',', all_segments)]

        # determine how many consecutive segments make up one line
        segs_per_line = len(segments) / self._width

        # store lines
        for i in range(0, len(segments), segs_per_line):
            line = 0

            for j in range (0, segs_per_line):
                line += segments[i + j] << (segs_per_line - j - 1)*8

            self._lines.append(line)

        
