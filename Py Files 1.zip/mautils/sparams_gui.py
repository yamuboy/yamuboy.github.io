#!/usr/bin/env python

from datetime import datetime
import math

# import TK GUI packages
from Tkinter import *
import tkFileDialog
import tkMessageBox

class MainWindow(Frame):
    """Class for the main window of the GUI."""
    
    def __init__(self,parent):
        """Initialize the main GUI window."""
        Frame.__init__(self,parent)
        
        # variables to store stuff from the various interactive widgets
        self.pna_address = StringVar(value="GPIB::16")
        self.freqfmt = StringVar()
        self.datafmt = StringVar()
        self.measfmt = StringVar()
        self.filename = StringVar(value="output.s2p")
        
        fs = LabelFrame(self, text='Configuration')
        fs.grid(sticky=N+S+W+E,columnspan=2,padx=3,pady=5,ipady=8,ipadx=4)
        n = 0
        
        # create the PNA address field
        Label(fs, text='PNA Address:').grid(row=n,sticky=W)
        Entry(fs,textvariable=self.pna_address,width=16).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the measurement mode selection
        Label(fs, text='Measurement:').grid(row=n,sticky=W)
        options = ("2-port","Port 1 only","Port 2 only")
        self.measfmt.set(options[0])
        OptionMenu(fs,self.measfmt,*options).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the frequency format selection
        Label(fs, text='Frequency Format:').grid(row=n,sticky=W)
        options = ("Hz","KHz","MHz","GHz")
        self.freqfmt.set(options[0])
        OptionMenu(fs,self.freqfmt,*options).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the data format selection
        Label(fs, text='Data Format:').grid(row=n,sticky=W)
        options = ("MA","RI","DB")
        self.datafmt.set(options[0])
        OptionMenu(fs,self.datafmt,*options).grid(row=n,column=1,sticky=W)
        n += 1
        
        # create the filename entry field
        fr = Frame(fs)
        fr.grid(row=n,columnspan=2)
        Label(fr, text='Filename:').pack(side=LEFT)
        Entry(fr,textvariable=self.filename,width=25).pack(side=LEFT,padx=6)
        Button(fr,text='Browse...',command=self.filename_browse).pack(side=LEFT)
        n += 1
        
        # create the buttons
        Button(self, text='Measure', command=self.measure, width=10).grid(row=n,columnspan=2,pady=15)
        n += 1
        
        # create an area for displaying 1-line status messages
        self.msg_text = StringVar(value='Ready.')
        Label(self, textvariable=self.msg_text, anchor=W, relief=GROOVE).grid(padx=2,columnspan=2,sticky=N+S+E+W)
        
    def filename_browse(self):
        """Browse for a SaveAs filename."""
        fname = tkFileDialog.asksaveasfilename(parent=self)
        if fname:
            self.filename.set(fname)
    
    def set_message(self,msg):
        """Set the message area string."""
        self.msg_text.set(msg)
        
    def measure(self):
        """Measure S-params using the PNA."""
        
        
        # get the info from the various selection boxes
        address = self.pna_address.get()
        frfmt = self.freqfmt.get()
        datafmt = self.datafmt.get()
        measfmt = self.measfmt.get()
        if measfmt == "Port 1 only":
            measmode=1
        elif measfmt == "Port 2 only":
            measmode=2
        else:
            measmode=0
        filename = self.filename.get()
        if not filename:
            self.set_message('Error: a filename must be specified.')
            tkMessageBox.showerror('Error', 'A filename must be specified.', parent=self)
            return
        
        # interact with the PNA
        try:
            save_sparams(address, filename, format=datafmt, mode=measmode, freq=frfmt)
        except Exception, e:
            # write the exception to the terminal
            import traceback
            emsg = traceback.format_exc()
            # pop up an error dialog
            self.set_message('Error in last measurement.')
            tkMessageBox.showerror('Error', emsg, parent=self)
            return
        
        self.set_message('S-parameters were captured.')
        
    def quit(self):
        """Exit it out of the GUI."""
        self.winfo_toplevel().destroy()
    

def pna_get_sparams( pna, measmode ):
    """Get S-params from the PNA.
    
    Arguments:
    pna - a pyVISA Instrument object used to communicate with the PNA
    measmode - integer, the measurement mode where:
        0 -> 2-port
        1 -> 1-port, S11
        2 -> 1-port, S22
    """
    chan = 1
    
    # depending on the mode, select the measurments that must exist
    if measmode == 0:
        params = ('S11','S12','S21','S22')
    elif measmode == 1:
        params = ('S11',)
    elif measmode == 2:
        params = ('S22',)
    else:
        raise Exception('Invalid measurement mode.')
    
    # initial setup
    pna.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
    # put sweep in hold
    pna.write('SENS%d:SWE:MODE HOLD' % chan)
    # get the measurement catalog
    catalog = pna.ask('CALC%d:PAR:CAT?' % chan)
    # create measurements as needed
    for p in params:
        measdef = "pysparams_ch%d_%s" % (chan,p)
        if catalog.find(measdef) == -1:
            pna.write("CALC%d:PAR:DEF '%s',%s" % (chan,measdef,p))
    
    # detect averaging state
    avg = int(pna.ask('SENS%d:AVER:STAT?' % chan))
    if avg:
        count = int(pna.ask('SENS%d:AVER:COUN?' % chan))
        # restart averaging
        pna.write('SENS%d:AVER:CLEAR' % chan)
    else:
        count = 1
    
    # set the group count to be equal to the averaging
    pna.write('SENS%d:SWE:GRO:COUN %d' % (chan,count))
    # trigger a measurment group
    pna.write('SENS%d:SWE:MODE GRO;*ESE 1;*OPC' % chan)
    
    # wait for the measurement to finish
    while 1:
        
        esr = int(pna.ask('*ESR?'))
        if esr:
            break
    
    result = []
    # get the frequency list
    r = pna.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?' % chan)
    n = len(r)
    result.append(r)
    
    # get the S-parameters
    for p in params:
        
        pna.write("CALC%d:PAR:SEL 'pysparams_ch%d_%s'" % (chan,chan,p))
        r = pna.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA' % chan)
        # combine the interlaced real/imag pairs into complex numbers
        if len(r) != n*2:
            raise Exception("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (p,n,len(r)))
        r2 = []
        for i in range(n):
            cnum = complex(r[2*i],r[2*i+1])
            r2.append(cnum)
        result.append(r2)
    
    # allow the PNA to enter continous sweep mode
    pna.write('SENS%d:SWE:MODE CONT' % chan)
    
    # return the final result as a tuple
    return tuple(result)

def scale_freq( frhz, fmt ):
    """Scale frequency to the correct value for the file."""
    if fmt == 'KHZ':
        return frhz*1.e-3
    elif fmt == 'MHZ':
        return frhz*1.e-6
    elif fmt == 'GHZ':
        return frhz*1.e-9
    else:
        return frhz

def convert_sparams( param, format ):
    """Convert sparams to the necessary format for string them in a file."""
    if format in ('MA','DB'):
        mag = abs(param)
        ang = math.degrees(math.atan2(param.imag,param.real))
        if format == 'DB':
            mag = 20.0*math.log10(mag)
            
        return mag,ang
    else:
        return param.real,param.imag

def save_sparams( resource, outfile, **kwargs ):
    """Interact with the PNA to fetch and save S-parameters."""
    
    # import pyVISA
    import visa
    
    # get parameters
    mode = 0
    freqfmt = 'HZ'
    datafmt = 'MA'
    if 'mode' in kwargs:
        mode = kwargs['mode']
    if 'freq' in kwargs:
        freqfmt = kwargs['freq'].upper()
    if 'format' in kwargs:
        datafmt = kwargs['format'].upper()
    
    # connect to the PNA
    pna = visa.instrument( resource, values_format=visa.double )
    
    # get the S-parameters
    result = pna_get_sparams( pna, mode )
    
    # write the file
    n = len(result)
    if n not in [2,5]:
        raise Exception('The tuple returned by pna_get_sparams() is not the correct length.')
    
    outf = open(outfile, "w")
    outf.write("! S-Parameters - measured by pySparams\n")
    outf.write("! Date: %s\n" % datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    # write the touchstone header
    outf.write('# %s S %s R 50.0\n!\n' % (freqfmt,datafmt))
    
    # write the data
    if n == 2:
        # 1-port data
        fr,s11 = result
        for i in range(len(fr)):
            data = [scale_freq(fr[i],freqfmt)]
            data.extend( convert_sparams(s11[i],datafmt) )
            outf.write('%.4e\t%.4e\t%.4e\n' % tuple(data))
    else:
        # 2-port data
        fr,s11,s12,s21,s22 = result
        for i in range(len(fr)):
            data = [scale_freq(fr[i],freqfmt)]
            data.extend( convert_sparams(s11[i],datafmt) )
            data.extend( convert_sparams(s21[i],datafmt) )
            data.extend( convert_sparams(s12[i],datafmt) )
            data.extend( convert_sparams(s22[i],datafmt) )
            outf.write('%.4e\t%.4e\t%.4e\t%.4e\t%.4e\t%.4e\t%.4e\t%.4e\t%.4e\n' % tuple(data))
    
    outf.close()
    
if __name__ == "__main__":
    raise RuntimeError("This module should not be run directly.")
    
