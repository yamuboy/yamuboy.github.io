def stackup_color_to_rgb(color):
    """Returns (hatch style index, blue, green, red)"""
    hatch = (color>>24)&(255)
    blue = (color>>16)&(255)
    green = (color>>8)&(255)
    red = color&(255)
    return (hatch, blue, green, red)
    
def stackup_rgb_to_color(hatch, blue, green, red):
    """Returns decimal combination of hatch style index and RGB color"""
    return (hatch<<24) + (blue<<16) + (green<<8) + red
    
def lpf_color_to_rgb(color):
    """Returns (blue, green, red)"""
    return stackup_color_to_rgb(color)[1:]
    
def lpf_rgb_to_color(blue, green, red):
    """Returns decimal combination of RGB color"""
    return (blue<<16) + (green<<8) + red