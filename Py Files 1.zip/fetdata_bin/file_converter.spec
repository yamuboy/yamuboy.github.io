# -*- mode: python -*-
a = Analysis(['file_converter.py'],
             pathex=['C:\\Users\\ma099737\\modeling\\fetdata_bin'],
             hiddenimports=[],
             hookspath=None,
             runtime_hooks=None)
pyz = PYZ(a.pure)
exe = EXE(pyz,
          a.scripts,
          a.binaries,
          a.zipfiles,
          a.datas,
          name='file_converter.exe',
          debug=False,
          strip=None,
          upx=True,
          console=False )
