#!/usr/bin/env python
import visa

def reset(addr):
    k = visa.instrument(addr)
    k.write("J0X")

if __name__ == '__main__':
    a = int(raw_input("GPIB address of keithley to reset: "))
    reset("GPIB::%d"%a)

