#!/usr/bin/env python

import visa
from datetime import datetime
import time
import sys
import optparse

def main( fname, append=False, elapsed_time_hr=0 ):
    """Main entry point."""
    
    # open data file
    fmode = 'w'
    if append:
        fmode = 'a'
    f = open(fname,fmode)
    if fmode == 'w':
        f.write("Timestamp\tIgate\tIdrain\n")
    
    fixed_start = time.time()
    
    try:
        while True:
            try:
                monitor(f,fixed_start)
            except KeyboardInterrupt:
                print
                print "test paused, type q to quit, type c to continue"
                r = get_response( ('q','c',) )
                if r == 'q':
                    break
    
    finally:
        f.close()
    
def get_response( valid_resp ):
    """Get a response, waiting for a valid one."""
    while True:
        try:
            r = raw_input("  > ").strip()
            if r in valid_resp:
                return r
            elif len(r):
                print " ** invalid response **"
        except KeyboardInterrupt:
            pass

def monitor( f, start_time ):
    """
    Monitor the power test.
    
    f is an open file object
    start_time is the start time of the test as a UNIX time stamp, which
      is used to compute the monitoring interval
    """
    # open instruments
    #pm = visa.instrument("GPIB::13")
    gate = visa.instrument("GPIB::21")
    drain = visa.instrument("GPIB::23")

    # set the output format for the keithleys
    gate.write("G4,2,0X")
    drain.write("G4,2,0X")
    time.sleep(0.05)
    #pm.write('AP')
    gate.write("N1H0X")
    drain.write("N1H0X") 

    try:
        
        while True:
            try:
                #pow = pm.read()
                ig = gate.read()
                time.sleep(0.01)
                id = drain.read()
                time.sleep(0.01)
            except:
                continue
            
            # write data
            t = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
            print t, ig, id
            f.write("%s\t%s\t%s\n"%(t,ig,id))
            f.flush()
            
            # get the interval and sleep for that time
            time.sleep(1.0)
            #elapsed = (time.time() - start_time)/60.0
    finally:
        #pm.close()
        drain.write("N0X")
        gate.write("N0X")
        gate.close()
        drain.close()

if __name__ == '__main__':
    ### program entry point

    p = optparse.OptionParser(usage="usage: %prog [options] filename")
    p.add_option('-r', '--restart', metavar="ELAPSED", dest="elapsed", type="float", default=0, help="restart the monitoring program at ELAPSED hours completed, this option also implies the --append option")
    p.add_option('-a', '--append', dest="append", action="store_true", default=False, help="open the data file in append mode")
    opts, args = p.parse_args()

    if len(args) != 1:
        p.print_usage()
        sys.exit(1)
    
    # process arguments
    kw = {}
    if opts.append:
        kw['append'] = True
    if opts.elapsed > 0:
        kw['append'] = True
        kw['elapsed_time_hr'] = opts.elapsed
            
    # run the main program
    main(args[0], **kw)
