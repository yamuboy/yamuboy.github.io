#!/usr/bin/env python
import os, sys, time
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
import instrument

INSTR = {
    #'bias1':['k23x','GPIB::21',{'remote':True,'resolution':'high'}],
    #'bias2':['k23x','GPIB::23',{'remote':True,'resolution':'high'}],
    'bias1':['b2902','GPIB::22',{'chan':1,'remote':True,'resolution':'high'}],
    'bias2':['b2902','GPIB::22',{'chan':2,'remote':True,'resolution':'high'}],
    #'prober':['12k','GPIB::28',{}],
    #'siggen':['SCPISigGen','GPIB::19',{}],
}
# Parameters for the test including FET DC Parameters
# power stress and other parameters such as 
# the wafer and device name and mapfile for stepping across the wafer
TEST_PARAMS = {
    # general parameters
    'periphery_um':400,
    'wafer':'',
    'device':'',
    
    # DC screen parameters
    'min_vgs':-3,
    'max_vgs':1.6,
    'max_igs_mamm':1.0,
    'max_ids_mamm':800.0,
    'ibr_low_mamm':0.01,
    'ibr_high_mamm':0.1,
    'max_vbr':30,
    'vds_idss':3.0,
    'vds_imax':1.5,
    'igs_imax_mamm':1.0,
    'vpo_percent':2.5,
    'vpo_current_mamm':1.0,
    }

def fmt_dc_data(data):
    "format DC data in preparation for writing to a file"
    params = ('vbr_ss_low','vbr_ss_high','idss','vpo','imax','vpo_imax',
        'vmax','vpo_mamm','ron','ig_10v','ig_12v','ig_15v','ig_20v')
    
    vals = []
    for p in params:
        vals.append('%+.4e'%data.get(p,0.0))
    
    return '\t'.join(vals)


def main():
    filename=raw_input("Enter Filename for test data?\n")
    if os.path.exists(filename):
        r=raw_input("%s exists-overwrite?(y/n)"%filename).strip().lower()
        if not r.startswith('y'):
            return
    
    params= TEST_PARAMS   
    gate = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    drain = instrument.create('bias',*(INSTR['bias2'][:2]),**(INSTR['bias2'][2]))

    
    f= open(filename,'w')
    f.write('!DC Screen and Breakdown Test\n')
    f.write('!Test Date: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write('!\n')
    f.write('!DC FET PARAMETERS\n')
    f.write('!Vbr(0.01mA/mm)\tVbr(0.1mA/mm)\tIdss(3V)\tVpo(3V)\tImax(1.5V)\tVpo(1.5V)\tVMax(1.5V)\tVpo(1mA/mm)\tRon(Ohms)\tIg(10V)\tIg(12V)\tIg(15V)\tIg(20V)\n')
    dc_screen(gate,drain,params,f)

def ids_target_search(gate, drain, vds, target, vgstart, vgmin, vgmax, iglimit, idlimit, maxiter=20,
    stepfrac=0.15, successfrac=0.01, failfrac=0.05, stepadj=0.3, minstep=0.002, leaveon=False):
    """this routine targets a drain current for a given set of gate voltage criteria

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    vds - float, drain voltage
    target - float, target Ids current (amps)
    vgstart - float, starting value for Vg
    vgmin - float, minimum Vg limit
    vgmax - float, maximum Vg limit
    iglimit - float, Ig current limit (amps)
    idlimit - float, Id current limit (amps)
    maxiter - int, maximum number of iterations of the targetting loop
    stepfrac - float, fraction of the range (vgmax-vgmin) that is used for the initial step size
    successfrac - float, fraction of the target current that is considered a "success"
    failfrac - float, fraction of the target current that is considered "failure" at the end of
        the targeting loop
    stepadj - float, fraction by which the step size is reduced when the loop overshoots
    minstep - float, minimum Vg step size
    leaveon - bool, leave the gate and drain SMUs on 

    returns: gate voltage value (float)
    """
    if vgstart > vgmax or vgstart < vgmin or vgmin > vgmax:
        raise ValueError("'vgmin' <= 'vgstart' <= 'vgmax': not satisfied")
        
    step = stepfrac*(vgmax-vgmin)
    vg = vgstart

    gate.config(mode='V',vset=vg,ilimit=iglimit,state=1)
    timed_wait_ms(25)
    drain.config(mode='V',vset=vds,ilimit=idlimit,state=1)
    timed_wait_ms(100)
    idm = drain.measure()
    if idm > target:
        step = -step

    try:
        # start the search loop
        count=0
        while count < maxiter:
            if step > 0.0 and vg == vgmax:
                raise ValueError("'vg' is at 'vgmax' (Id_meas = %g, Target = %g)"%(idm,target))
            elif step < 0.0 and vg == vgmin:
                raise ValueError("'vg' is at 'vgmin' (Id_meas = %g, Target = %g)"%(idm,target))

            vg += step
            if vg > vgmax:
                vg = vgmax
            elif vg < vgmin:
                vg = vgmin

            gate.config(vset=vg)
            timed_wait_ms(50)
            idm = drain.measure()

            if abs(idm-target) <= successfrac*target:
                break

            # reduce step and reverse direction for certain conditions
            if (step < 0.0 and idm < target) or (step > 0.0 and idm > target):
                if abs(step) == minstep:
                    # already at min step, just break
                    break
                step *= -stepadj

            # force a minimum step size
            if abs(step) < minstep:
                if step < 0.0:
                    step = -minstep
                else:
                    step = minstep

            count += 1

        if abs(idm-target) > failfrac*target:
            # more than 5% error, raise error
            raise ValueError("current targeting failed (Vg = %g, Id = %g, Target = %g)"%(vg,idm,target))

        if not leaveon:
            timed_wait_ms(20)
            drain.config(state=0)
            timed_wait_ms(50)
            gate.config(state=0)
                
    except ValueError:
        timed_wait_ms(20)
        drain.config(state=0)
        timed_wait_ms(50)
        gate.config(state=0)        
        raise
        
    return vg
      
        

def dc_screen(gate,drain,params,f):
    """FET DC screen measurement

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    params - dict, test parameters

    returns: a dict of measured DUT parameters
    """
    data = {}
        
    periph = params['periphery_um']

    # compliance for breakdown tests
    gate_c = periph*params['ibr_high_mamm']*4.0e-6
    drain_c = params['max_vbr']+params['min_vgs']
    
    #### single-sided breakdown ####

    try:
        print "   Single Sided Breakdown..."    
        gate.config(mode='V',vset=params['min_vgs'],ilimit=gate_c,state=1,resolution='very high')
        timed_wait_ms(25)
        drain.config(mode='I',iset=params['ibr_low_mamm']*1.0e-6*periph,vlimit=drain_c,state=1,resolution='very high')
        timed_wait_ms(1000)
        data['vbr_ss_low'] = params['min_vgs'] - drain.measure()
        
        drain.config(iset=params['ibr_high_mamm']*1e-6*periph)
        timed_wait_ms(1000)
        data['vbr_ss_high'] = params['min_vgs'] - drain.measure()
        
        drain.set_state(0)
        timed_wait_ms(50)
                        
        #### Idss ####

        gate_c = params['max_igs_mamm']*1.0e-6*periph
        drain_c = params['max_ids_mamm']*1.0e-6*periph

        print "   Idss Measurement..."
        gate.config(vset=0.0,ilimit=gate_c)
        timed_wait_ms(25)
        drain.config(mode='V',vset=params['vds_idss'],ilimit=drain_c,state=1)
        timed_wait_ms(100)
        data['idss'] = drain.measure()
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

        #### Imax / Vmax ####

        print "   Imax Measurement..."
        gate.config(mode='I',iset=params['igs_imax_mamm']*1.0e-6*periph,vlimit=params['max_vgs'],state=1)
        timed_wait_ms(25)
        drain.config(vset=params['vds_imax'],state=1)
        timed_wait_ms(100)
        data['vmax'] = gate.measure()
        data['imax'] = drain.measure()
        open_gate = gate.limiting
        shorted_chan = drain.limiting
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

        #### Checks for failed devices ####
        
        if open_gate:
            raise ValueError("gate is open-circuited")
        elif data['vmax'] < 0.5:
            raise ValueError("gate is short-circuited")
        elif data['imax'] < 10.0e-6*periph:
            raise ValueError("channel is open-circuited")
        elif shorted_chan:
            raise ValueError("gate is short-circuited")
        
        #### Vpo measurement at Vds for Idss ####

        print "   Pinchoff Measurement @ Vds for Idss..."    
        
        if data['idss'] < 0.05*data['imax']:
            target_ids = 0.01*params['vpo_percent']*data['imax']
        else:
            target_ids = 0.01*params['vpo_percent']*data['idss']
        
        gate.config(resolution='medium')
        drain.config(resolution='medium')
        data['vpo'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)

        #### Vpo Measurement at Vds for IMax ####

        print "   Pinchoff Measurement for Vds@ Imax..."    
        
        data['vpo_imax'] = ids_target_search(gate,drain,params['vds_imax'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)

        #### Vpo measurement mA/mm ####

        print "   Pinchoff Measurement mA/mm..."
        
        target_ids = params['vpo_current_mamm']*1e-6*periph
        data['vpo_mamm'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
        
        #### Ron Measurement D-FET ####

        print "   Ron Measurement..."
        vset = 0.02
        gate.config(mode='V',vset=0.0,ilimit=gate_c,state=1,resolution='very high')
        timed_wait_ms(25)
        drain.config(mode='V',vset=vset,ilimit=drain_c,state=1,resolution='very high')
        timed_wait_ms(1000)
        data['ron'] = vset/drain.measure()
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)
                
        #### spot leakage current tests ####

        print "   Leakage Current Test..."
        vgs = params['min_vgs']
        gate.config(mode='V',vset=vgs,ilimit=params['ibr_high_mamm']*1e-06*periph,state=1)
        timed_wait_ms(25)
        drain.config(mode='V',vset=0.0,ilimit=params['ibr_high_mamm']*2e-06*periph,state=1)
        timed_wait_ms(25)

        names = ['ig_10v','ig_12v','ig_15v','ig_20v']
        for i,vleak in enumerate([10.0,12.0,15.0,20.0]):
            vds = vleak + vgs
            if vleak <= 1.0*abs(data['vbr_ss_high']):
                drain.config(vset=vds)
                timed_wait_ms(1000)
                data[names[i]] = gate.measure()
                timed_wait_ms(10)
            else:
                data[names[i]] = 0.0

    finally:
        timed_wait_ms(25)
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)
 
    f.write("%s\n"%(fmt_dc_data(data)))
    f.flush()

    
if __name__=="__main__":
    main()
    
    
    
    

    
    
