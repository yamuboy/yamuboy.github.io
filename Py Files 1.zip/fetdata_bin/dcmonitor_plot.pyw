#!/usr/bin/env python2.6

import sys
import os.path
from wx import wx
from testsoft.dcmonitorplotlib import WxDCMonitorPlotFrame

if __name__ == '__main__':
    app = wx.PySimpleApp()
    root = WxDCMonitorPlotFrame(size=(800,600))
    if len(sys.argv) > 1:
        if os.path.isfile(sys.argv[1]):
            path = sys.argv[1]
            filename = os.path.basename(path)
            root.set_live_file_path(path, filename)
            root.live_mode_initial()
            
    root.Show()
    app.MainLoop()
