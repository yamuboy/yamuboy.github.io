#!/usr/bin/env python

import os, sys, traceback, math
import re
from datetime import datetime
import instrument
from instrument import timed_wait_ms

DEFAULT_CONFIGFILE = 'gan_lag.cfg'

def load_config_file(cfg, cfgfname):
    try:
        data = dict()
        execfile(cfgfname,data)
        del data['__builtins__']
        cfg.update(data)
        print "read config options from: '%s'\n"%cfgfname
    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no config file, using default options"
        else:
            raise

def print_config(cfg):
    print "\n"
    # using explicit for loop to keep logical order of variables... must update this list if more variables are added in cfg file
    for k in ('gatelag_Vg_ss', 'gatelag_Vg_pulse', 'gatelag_Vd_q', 'gatelag_pulse_width', 'gatelag_pulse_period',
              'drainlag_Vd_ss', 'drainlag_Vd_pulse', 'drainlag_Vg_q', 'drainlag_pulse_width', 'drainlag_pulse_period',
              'target_Ids', 'Vg_start', 'Vg_step', 'Vg_stop', 'Ig_limit_ua', 'Id_limit_ma', 'output_filter',
              'single_pulse', 'gate_smu', 'drain_smu'):
        print k + ' = ' + str(cfg[k])
    print "\n"
        
def main(cfgfname=DEFAULT_CONFIGFILE,fname=''):
    "entry point"
    print "\n\n***********************************************\n"
    print "***************GaN Lag Tester******************\n"
    print "***********************************************\n\n"

    cfg = _default_config()
    load_config_file(cfg, cfgfname)

    # try to open instruments
    gate = instrument.create('bias',*(cfg['gate_smu'][:2]),**(cfg['gate_smu'][2]))
    drain = instrument.create('bias',*(cfg['drain_smu'][:2]),**(cfg['drain_smu'][2]))
    
    while True:
        print "Menu:\n"
        print "\t t - Run test\n"
        print "\t tg - Run only gate lag test\n"
        print "\t td - Run only drain lag test\n"        
        print "\t g - Set SMU to pulse current gate lag settings\n"
        print "\t d - Set SMU to pulse current drain lag settings\n"
        print "\t r - Reload config file\n"
        print "\t p - Print currently loaded config file\n"
        print "\t q - Quit\n\n"
        r = raw_input("Enter your choice: ")
        
        if r == "t":
            try:
                run(cfg,gate,drain,fname, "both")
            except KeyboardInterrupt:
                disable_sources(gate, drain)
                print "\naborted\n"
            finally:
                disable_sources(gate, drain)
        elif r == "tg":
            try:
                run(cfg,gate,drain,fname, "gate")
            except KeyboardInterrupt:
                disable_sources(gate, drain)
                print "\naborted\n"
            finally:
                disable_sources(gate, drain) 
        elif r == "td":
            try:
                run(cfg,gate,drain,fname, "drain")
            except KeyboardInterrupt:
                disable_sources(gate, drain)
                print "\naborted\n"
            finally:
                disable_sources(gate, drain)    
        elif r == "g":
            try:
                test_gatelag_settings(cfg, cfgfname, gate, drain)
            except KeyboardInterrupt:
                disable_sources(gate, drain)
                print "\naborted\n"
            finally:
                disable_sources(gate, drain) 
                  
        elif r == "d":
            try:
                test_drainlag_settings(cfg, cfgfname, gate, drain)
            except KeyboardInterrupt:
                disable_sources(gate, drain)
                print "\naborted\n"
            finally:
                disable_sources(gate, drain) 
        elif r == "r":
            load_config_file(cfg, cfgfname)
        elif r == "p":
            print_config(cfg)
        elif r == "q":
            gate.close()
            drain.close()
            raise SystemExit
        else:
            print "Invalid Option! Try again\n"
    
def maxv_warning(cfg):
    maxv = max(cfg['gatelag_Vd_q'], cfg['drainlag_Vd_ss'], cfg['drainlag_Vd_pulse'])
    if maxv > 30.0:
        print "WARNING ***********************************************"
        print "WARNING: maximum drain voltage for this test is %g volts"%maxv
        print "WARNING: ensure that the bias tees can handle this voltage"
        print "WARNING ***********************************************"
        print ""
        r = raw_input("press enter to continue or ctrl-C to quit")

def run(cfg,gate,drain,fname, tests):
    "run test"
    
    maxv_warning(cfg)
    
    # ask for a file name
    while not fname:
        fname = raw_input('Base output file name? ').strip()
    if tests == "both" or tests == "gate":
        # gate lag
        run_gatelag(cfg, gate, drain, fname)

    if tests == "both" or tests == "drain":
        # drain lag
        run_drainlag(cfg, gate, drain, fname)
        
    print "\nTests complete!\n"
     
def test_gatelag_settings(cfg, cfgfname, gate, drain):
    try:
        while True:
            maxv_warning(cfg)
    
            xmin = 0
            xmax =  cfg['gatelag_pulse_period']*3.0
            ymin = 0
            ymax = cfg['target_Ids']
                
            config_sources(cfg, gate, drain)
            
            # configure triggers and pulse values
            config_gatelag_trigger(cfg, gate, drain, cfg['gatelag_Vg_pulse'])
            
            enable_sources(gate, drain)
            trigger_idle_wait(gate, drain)
            timed_wait_ms(1000)
            initiate_trigger(gate, drain)

            # set SMU to display graph
#            SMU_display_graph(gate)
            
            r = raw_input("SMU enabled! Wait for enough data to be captured, then press enter!")
            
            abort_trigger(gate, drain)
            disable_sources(gate, drain)
            
            r = raw_input("SMU set to view gate lag pulse waveform.\nPress enter to continue, or press 'r' to reload config file and re-test.")
            
            if r == "r":
                load_config_file(cfg, cfgfname)
            else:
                break
                
    except KeyboardInterrupt:
        print "Exiting!"
    
    finally:
        disable_sources(gate, drain)
        
def test_drainlag_settings(cfg, cfgfname, gate, drain):
    try:
        while True:
            maxv_warning(cfg)
    
            xmin = 0
            xmax =  cfg['drainlag_pulse_period']*3.0
            ymin = 0
            ymax = cfg['target_Ids']
                
            config_sources(cfg, gate, drain)
            
            # configure triggers and pulse values
            config_drainlag_trigger(cfg, gate, drain, cfg['drainlag_Vg_q'])
            
            enable_sources(gate, drain)
            trigger_idle_wait(gate, drain)
            timed_wait_ms(1000)
            initiate_trigger(gate, drain)

            # set SMU to display graph
#            SMU_display_graph(gate)
            
            r = raw_input("SMU enabled! Wait for enough data to be captured, then press enter!")
            
            abort_trigger(gate, drain)
            disable_sources(gate, drain)
            
            r = raw_input("SMU set to view drain lag pulse waveform.\nPress enter to continue, or press 'r' to reload config file and re-test.")
            
            if r == "r":
                load_config_file(cfg, cfgfname)
            else:
                break
                
    except KeyboardInterrupt:
        print "Exiting!"
    
    finally:
        disable_sources(gate, drain)

def SMU_display_graph(gate):
    gate.vi.write(":DISP:ENAB ON")
    timed_wait_ms(50)
    gate.vi.write(":DISP:VIEW GRAP")
    timed_wait_ms(50)
    
def SMU_display_dual(gate):
    gate.vi.write(":DISP:ENAB ON")
    timed_wait_ms(50)
    gate.vi.write(":DISP:VIEW DUAL")
    timed_wait_ms(50)

def write_gatelag(cfg, gdata, ddata, basename, ids):
    
    testparams = re.sub(r'\.', 'p', ('_gatelag_%2.0fmA'%(ids*1000)))
    filename = basename + testparams + '.dat'
    
    print "Writing Gate Lag Test data to %s\n"%filename
    output = open(filename,'w')
    output.write('! GaN Gate Lag Test\n')
    output.write('!\n')
    output.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    output.write('!\n')
    output.write('! Settings:\n')
    for k in ('gatelag_Vg_ss', 'gatelag_Vg_pulse', 'gatelag_Vd_q', 'gatelag_pulse_width', 'gatelag_pulse_period'):
        output.write('!    %s = %s\n'%(k,repr(cfg[k])))
    output.write('!    target_Ids = %s\n\n'%ids)

    output.write('! t (s)\tVg (V)\tVd (V)\tId (A)\n')
    for tg, td in zip(gdata, ddata):
        output.write(''.join(str(s)+'\t' for s in [tg[2], tg[0], td[0], td[1]]) + '\n')

    output.close()

def write_drainlag(cfg, gdata, ddata, basename, ids):

    testparams = re.sub(r'\.', 'p', ('_drainlag_%2.0fmA'%(ids*1000)))
    filename = basename + testparams + '.dat'
    
    print "Writing Drain Lag Test data to %s\n"%filename
    output = open(filename,'w')
    output.write('! GaN Drain Lag Test\n')
    output.write('!\n')
    output.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    output.write('!\n')
    output.write('! Settings:\n')
    for k in ('drainlag_Vd_ss', 'drainlag_Vd_pulse', 'drainlag_Vg_q', 'drainlag_pulse_width', 'drainlag_pulse_period'):
        output.write('!    %s = %s\n'%(k,repr(cfg[k])))
    output.write('!    target_Ids = %s\n\n'%ids)
    
    output.write('! t (s)\tVg (V)\tVd (V)\tId (A)\n')
    for tg, td in zip(gdata, ddata):
        output.write(''.join(str(s)+'\t' for s in [tg[2], tg[0], td[0], td[1]]) + '\n')

    output.close()

def config_sources(cfg, gate, drain):

    # reset SMU
    gate.vi.write("*RST")
        
    # set sources to voltage, with compliance limits and 4-wire mode
    gate.vi.write(":SOUR1:FUNC:MODE VOLT")
    timed_wait_ms(50)
    gate.vi.write(":SENS1:CURR:PROT %e"%(cfg['Ig_limit_ua']*1.0e-6))
    timed_wait_ms(50)
    gate.vi.write(":SENS1:REM ON")
    timed_wait_ms(50)

    drain.vi.write(":SOUR2:FUNC:MODE VOLT")
    timed_wait_ms(50)
    drain.vi.write(":SENS2:CURR:PROT %e"%(cfg['Id_limit_ma']*1.0e-3))
    timed_wait_ms(50)
    drain.vi.write(":SENS2:REM ON")
    timed_wait_ms(50)
    
    # output filters enabled by default, disable if need be
    if not cfg['output_filter']:
        gate.vi.write(":OUTP1:FILT 0")
        timed_wait_ms(50)
        drain.vi.write(":OUTP2:FILT 0")
        timed_wait_ms(50)
        
def config_gatelag_trigger(cfg, gate, drain, targetVg):
    # set trigger parameters
    gate.vi.write(":TRIG1:ALL:COUN %s"%"INF")   # infinite trigger count for gate
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ALL:COUN %s"%"INF")
    timed_wait_ms(50)
    gate.vi.write(":TRIG1:ALL:DEL %e"%0.0)      # trigger delay = 0
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ALL:DEL %e"%0.0)
    timed_wait_ms(50)
    gate.vi.write(":TRIG1:ALL:SOUR %s"%"TIM")   # trigger source = internal timer
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    gate.vi.write(":TRIG1:ACQ:TIM %e"%20.0e-6)  # measure as fast as possible, 20us
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ACQ:TIM %e"%20.0e-6)
    timed_wait_ms(50)                     
    
    # set gate pulse parameters
    if cfg['single_pulse']:
        gate.vi.write(":TRIG1:TRAN:TIM %s"%"MAX")   # pulse period set to maximum for single-pulse mode
        timed_wait_ms(50)
        drain.vi.write(":TRIG2:TRAN:TIM %s"%"MAX")  # pulse period must be same across channels for trigger to work
        timed_wait_ms(50)
        gate.vi.write(":SOUR1:PULS:DEL %s"%"100e-6")  # pulse delay
        timed_wait_ms(50)
        gate.vi.write(":SOUR1:PULS:WIDT %s"%"99e3")  # pulse width set close to maximum (can't set to MAX due to conflict with trigger period)
        timed_wait_ms(50)
    else:
        gate.vi.write(":TRIG1:TRAN:TIM %e"%cfg['gatelag_pulse_period']) # pulse period set as in config
        timed_wait_ms(50)
        drain.vi.write(":TRIG2:TRAN:TIM %e"%cfg['gatelag_pulse_period'])# pulse period must be same across channels for trigger to work
        timed_wait_ms(50)
        gate.vi.write(":SOUR1:PULS:DEL %e"%0.0)                         # pulse delay
        timed_wait_ms(50)
        gate.vi.write(":SOUR1:PULS:WIDT %e"%cfg['gatelag_pulse_width']) # pulse width
        timed_wait_ms(50)
    
    gate.vi.write(":SOUR1:FUNC:SHAP %s"%"PULS")                     # set gate source to pulsed
    timed_wait_ms(50)
    gate.vi.write(":SOUR1:VOLT %e"%cfg['gatelag_Vg_ss'])            # set gate steady-state voltage
    timed_wait_ms(50)
    gate.vi.write(":SOUR1:VOLT:TRIG %e"%targetVg)                   # set gate pulse peak voltage
    timed_wait_ms(50)
    
    drain.vi.write(":SOUR2:FUNC:SHAP %s"%"DC")                      # set drain source to DC
    timed_wait_ms(50)
    drain.vi.write(":SOUR2:VOLT %e"%cfg['gatelag_Vd_q'])            # set drain quiescent voltage
    timed_wait_ms(50)
    drain.vi.write(":SOUR2:VOLT:TRIG %e"%cfg['gatelag_Vd_q'])       # must set both DC and pulse voltages for triggered DC source to work correctly
    timed_wait_ms(50)

def config_drainlag_trigger(cfg, gate, drain, targetVg):
    # set trigger parameters
    gate.vi.write(":TRIG1:ALL:COUN %s"%"INF")   # infinite trigger count for gate
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ALL:COUN %s"%"INF")
    timed_wait_ms(50)
    gate.vi.write(":TRIG1:ALL:DEL %e"%0.0)      # trigger delay = 0
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ALL:DEL %e"%0.0)
    timed_wait_ms(50)
    gate.vi.write(":TRIG1:ALL:SOUR %s"%"TIM")   # trigger source = internal timer
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    gate.vi.write(":TRIG1:ACQ:TIM %e"%20.0e-6)  # measure as fast as possible, 20us
    timed_wait_ms(50)
    drain.vi.write(":TRIG2:ACQ:TIM %e"%20.0e-6)
    timed_wait_ms(50)
    
    
    # set drain pulse parameters
    if cfg['single_pulse']:
        gate.vi.write(":TRIG1:TRAN:TIM %s"%"MAX")   # pulse period set to max for single-pulse mode
        timed_wait_ms(50)
        drain.vi.write(":TRIG2:TRAN:TIM %s"%"MAX")  # pulse period must be same across channels for trigger to work
        timed_wait_ms(50)
        drain.vi.write(":SOUR2:PULS:DEL %s"%"100e-6") # pulse delay
        timed_wait_ms(50)
        drain.vi.write(":SOUR2:PULS:WIDT %s"%"99e3") # pulse width
        timed_wait_ms(50)
    else:
        gate.vi.write(":TRIG1:TRAN:TIM %e"%cfg['drainlag_pulse_period']) # pulse period set as in config
        timed_wait_ms(50)
        drain.vi.write(":TRIG2:TRAN:TIM %e"%cfg['drainlag_pulse_period'])# pulse period must be same across channels for trigger to work
        timed_wait_ms(50)
        drain.vi.write(":SOUR2:PULS:DEL %e"%0.0)                         # pulse delay
        timed_wait_ms(50)
        drain.vi.write(":SOUR2:PULS:WIDT %e"%cfg['drainlag_pulse_width'])# pulse width
        timed_wait_ms(50)
        
    drain.vi.write(":SOUR2:FUNC:SHAP %s"%"PULS")                    # set drain source to pulsed
    timed_wait_ms(50)
    drain.vi.write(":SOUR2:VOLT %e"%cfg['drainlag_Vd_ss'])          # set drain steady-state voltage
    timed_wait_ms(50)
    drain.vi.write(":SOUR2:VOLT:TRIG %e"%cfg['drainlag_Vd_pulse'])  # set drain pulse peak voltage
    timed_wait_ms(50)
    
    gate.vi.write(":SOUR1:FUNC:SHAP %s"%"DC")                       # set gate source to DC
    timed_wait_ms(50)
    gate.vi.write(":SOUR1:VOLT %e"%targetVg)                        # set gate quiescent voltage
    timed_wait_ms(50)
    gate.vi.write(":SOUR1:VOLT:TRIG %e"%targetVg)                   # must set both DC and pulse voltages for triggered DC source to work correctly
    timed_wait_ms(50)

def enable_sources(gate, drain):
    # turn on gate
    gate.vi.write(":OUTP1 ON")
    timed_wait_ms(1000)
    
    # turn on drain
    drain.vi.write(":OUTP2 ON")
    timed_wait_ms(500)

def disable_sources(gate, drain):
    # turn off drain
    drain.vi.write(":OUTP2 OFF")
    timed_wait_ms(1000)

    # turn off gate
    gate.vi.write(":OUTP1 OFF")
    timed_wait_ms(500)

def initiate_trigger(gate, drain):
    # initiate global trigger
    gate.vi.write(":INIT:ALL (@1:2)")
    timed_wait_ms(50)

def trigger_idle_wait(gate, drain):
    # wait for channels to be idle
    gate.vi.ask(":IDLE1:ALL?")
    timed_wait_ms(50)
    drain.vi.ask(":IDLE2:ALL?")
    timed_wait_ms(50)

def abort_trigger(gate, drain):
    # abort trigger
    gate.vi.write(":ABOR:ALL (@1:2)")
    timed_wait_ms(50)

def config_SMU_tb(gate, drain, numBlocks):
    # set data format
    gate.vi.write(":FORM:ELEM:SENS VOLT,CURR,TIME")
    timed_wait_ms(50)
    gate.vi.write(":FORM:SREG BIN")
    timed_wait_ms(50)
    
    # set trace buffer settings and clear
    gate.vi.write(":TRAC1:FEED SENS")
    timed_wait_ms(50)
    gate.vi.write(":TRAC1:POIN %d"%numBlocks)
    timed_wait_ms(50)
    drain.vi.write(":TRAC2:FEED SENS")
    timed_wait_ms(50)
    drain.vi.write(":TRAC2:POIN %d"%numBlocks)
    timed_wait_ms(50)
    gate.vi.write(":TRAC1:FEED:CONT NEV")
    timed_wait_ms(50)
    drain.vi.write(":TRAC2:FEED:CONT NEV")
    timed_wait_ms(50)
    gate.vi.write(":TRAC1:CLE")
    timed_wait_ms(50)
    drain.vi.write(":TRAC2:CLE")
    timed_wait_ms(50)
    gate.vi.write(":TRAC1:FEED:CONT NEXT")
    timed_wait_ms(50)
    drain.vi.write(":TRAC2:FEED:CONT NEXT")
    timed_wait_ms(50)

def run_gatelag(cfg, gate, drain, fname):

    print "\nRunning Gate Lag Test...\n"
    
    for ids in cfg['target_Ids']:
        print "Target Current = %.1fmA"%(ids*1000.0)
        numBlocks = int((cfg['gatelag_pulse_period']/(20.0e-6))*3)   # store only ~3 periods of data    
        if numBlocks > 100000 or cfg['single_pulse']:  # b2902 only can hold 100000 blocks
            numBlocks = 100000
        
        config_sources(cfg, gate, drain)

        # find Vg for target Ids
#        SMU_display_dual(gate)
        targetVg = find_target_Ids_gatelag(cfg, gate, drain, ids)
        
        # configure triggers and pulse values
#        SMU_display_graph(gate)
        config_gatelag_trigger(cfg, gate, drain, targetVg)
        
        # configure trace buffer
        config_SMU_tb(gate, drain, numBlocks)
        
        enable_sources(gate, drain)
        trigger_idle_wait(gate, drain)
        timed_wait_ms(1000)
        initiate_trigger(gate, drain)
        
        # wait for 3 full periods, at least
        timed_wait_ms(cfg['gatelag_pulse_period']*1000*3)
        
        # check to see if SMU has gathered all the data
        bufferfull = False
        while not bufferfull:
            result = int(gate.vi.ask(":STAT:MEAS:COND?")[2:],2)    # string returned from SMU looks like '#Bxxxxxxxxxxxx', need to remove the '#B'
            timed_wait_ms(1000)
            if result&0x0410 == 0x0410: # check for trace buffers to be full
                bufferfull = True

        abort_trigger(gate, drain)
        disable_sources(gate, drain)

        # pull trace data
        print "Acquiring data from SMU..."
        g_data = gate.vi.ask("TRAC1:DATA? 0,%d"%numBlocks) # returned as voltage(1),current(1),time(1),voltage(2),current(2),time(2), etc...
        timed_wait_ms(50)
        d_data = drain.vi.ask("TRAC2:DATA? 0,%d"%numBlocks)
        timed_wait_ms(50)
        
        g = zip(*[iter(g_data.split(','))]*3)
        d = zip(*[iter(d_data.split(','))]*3)
        
        write_gatelag(cfg, g, d, fname, ids)
    
def run_drainlag(cfg, gate, drain, fname):
    
    print "\nRunning Drain Lag Test...\n"
    
    for ids in cfg['target_Ids']:
        print "Target Current = %.1fmA"%(ids*1000.0)
        numBlocks = int((cfg['drainlag_pulse_period']/(20.0e-6))*3)   # store only 3 periods of data    
        if numBlocks > 100000 or cfg['single_pulse']:  # b2902 only can hold 100000 blocks
            numBlocks = 100000
        
        config_sources(cfg, gate, drain)

        # find Vg for target Ids
#        SMU_display_dual(gate)
        targetVg = find_target_Ids_drainlag(cfg, gate, drain, ids)
        
        # configure triggers and pulse values
#        SMU_display_graph(gate)
        config_drainlag_trigger(cfg, gate, drain, targetVg)
        
        # configure trace buffer
        config_SMU_tb(gate, drain, numBlocks)
        
        enable_sources(gate, drain)
        trigger_idle_wait(gate, drain)
        timed_wait_ms(1000)
        initiate_trigger(gate, drain)
        
        # wait for 3 full periods, at least
        timed_wait_ms(cfg['drainlag_pulse_period']*1000*3)
        
        # check to see if SMU has gathered all the data
        bufferfull = False
        while not bufferfull:
            result = int(gate.vi.ask(":STAT:MEAS:COND?")[2:],2)    # string returned from SMU looks like '#Bxxxxxxxxxxxx', need to remove the '#B'
            timed_wait_ms(1000)
            if result&0x0410 == 0x0410: # check for trace buffers to be full
                bufferfull = True
        
        abort_trigger(gate, drain)
        disable_sources(gate, drain)

        # pull trace data
        print "Acquiring data from SMU..."
        g_data = gate.vi.ask("TRAC1:DATA? 0,%d"%numBlocks) # returned as voltage(1),current(1),time(1),voltage(2),current(2),time(2), etc...
        timed_wait_ms(50)
        d_data = drain.vi.ask("TRAC2:DATA? 0,%d"%numBlocks)
        timed_wait_ms(50)
        
        g = zip(*[iter(g_data.split(','))]*3)
        d = zip(*[iter(d_data.split(','))]*3)
        
        write_drainlag(cfg, g, d, fname, ids)
    
def find_target_Ids_gatelag(cfg, gate, drain, targetIds):
    
    currentVg = cfg['Vg_start']
    currentId = 0.0
    currentId_rounded = 0.0

    # set starting values for gate and drain
    gate.vi.write(":SOUR1:VOLT %e"%currentVg)
    timed_wait_ms(50)
    drain.vi.write(":SOUR2:VOLT %e"%cfg['gatelag_Vd_q'])
    timed_wait_ms(50)
    
    enable_sources(gate,drain)

    try:
        stepSize = cfg['Vg_step']
        targetIds_rounded = round(targetIds*1000,1)
        increasing = True
        while currentId_rounded != targetIds_rounded:
            # measure Ids
            currentId = float(drain.vi.ask(":MEAS:CURR? (@2)"))
            currentId_rounded = round(currentId*1000,1)
            timed_wait_ms(50)

            # if in compliance, throw exception
            gatelimit = int(gate.vi.ask(":SENS1:CURR:PROT:TRIP?"))
            timed_wait_ms(50)
            drainlimit = int(drain.vi.ask(":SENS2:CURR:PROT:TRIP?"))
            timed_wait_ms(50)
            if gatelimit or drainlimit:
                print "DUT in compliance, aborting test!"
                raise SystemExit
            
            # if smaller than desired and less than max allowed Vg, step up
            if (currentId_rounded < targetIds_rounded) and (currentVg <= cfg['Vg_stop']):
                if not increasing:
                    increasing = True
                    stepSize = stepSize*0.9
                    # limit step size to 10uV
                    if stepSize < 1e-5:
                        stepSize = 1e-5
                currentVg = currentVg + stepSize
                gate.vi.write(":SOUR1:VOLT %e"%currentVg)
                timed_wait_ms(100)

            # if larger than desired, step down
            elif (currentId_rounded > targetIds_rounded):
                if increasing:
                    increasing = False
                    stepSize = stepSize*0.9
                    # limit step size to 10uV
                    if stepSize < 1e-5:
                        stepSize = 1e-5
                currentVg = currentVg - stepSize
                gate.vi.write(":SOUR1:VOLT %e"%currentVg)
                timed_wait_ms(100)
            elif currentVg >= cfg['Vg_stop']:
                print("Reached maximum allowed Vg, continuing test with current corresponding to Vg = %e V"%currentVg)
                break

    finally:
        print("Found target current Id = %e A with Vg = %e V"%(currentId,currentVg))

        disable_sources(gate, drain)
        
        return currentVg

def find_target_Ids_drainlag(cfg, gate, drain, targetIds):
    
    currentVg = cfg['Vg_start']
    currentId = 0.0
    currentId_rounded = 0.0

    # set starting values for gate and drain
    gate.vi.write(":SOUR1:VOLT %e"%currentVg)
    timed_wait_ms(50)
    drain.vi.write(":SOUR2:VOLT %e"%cfg['drainlag_Vd_pulse'])
    timed_wait_ms(50)
    
    enable_sources(gate, drain)

    try:
        stepSize = cfg['Vg_step']
        targetIds_rounded = round(targetIds*1000,1)
        increasing = True
        while currentId_rounded != targetIds_rounded:
            # measure Ids
            currentId = float(drain.vi.ask(":MEAS:CURR? (@2)"))
            currentId_rounded = round(currentId*1000,1)
            timed_wait_ms(50)

            # if in compliance, throw exception
            gatelimit = int(gate.vi.ask(":SENS1:CURR:PROT:TRIP?"))
            timed_wait_ms(50)
            drainlimit = int(drain.vi.ask(":SENS2:CURR:PROT:TRIP?"))
            timed_wait_ms(50)
            if gatelimit or drainlimit:
                print "DUT in compliance, aborting test!"
                raise SystemExit
            
            # if smaller than desired and less than max allowed Vg, step up
            if (currentId_rounded < targetIds_rounded) and (currentVg <= cfg['Vg_stop']):
                if not increasing:
                    increasing = True
                    stepSize = stepSize*0.9
                    # limit step size to 10uV
                    if stepSize < 1e-5:
                        stepSize = 1e-5
                currentVg = currentVg + stepSize
                gate.vi.write(":SOUR1:VOLT %e"%currentVg)
                timed_wait_ms(100)
            # if larger than desired, step down
            elif (currentId_rounded > targetIds_rounded):
                if increasing:
                    increasing = False
                    stepSize = stepSize*0.9
                    # limit step size to 10uV
                    if stepSize < 1e-5:
                        stepSize = 1e-5
                currentVg = currentVg - stepSize
                gate.vi.write(":SOUR1:VOLT %e"%currentVg)
                timed_wait_ms(100)
            elif currentVg >= cfg['Vg_stop']:
                print("Reached maximum allowed Vg, continuing test with current corresponding to Vg = %e V"%currentVg)
                break

    except KeyboardInterrupt:
        disable_sources(gate, drain)
        print "aborted"
        
    finally:
        print("Found target current Id = %e A with Vg = %e V"%(currentId,currentVg))

        disable_sources(gate, drain)
        
        return currentVg

def _default_config():
    "default configuration"
    
    cfg = {}
    cfg['gatelag_Vg_ss'] = -10.0
    cfg['gatelag_Vg_pulse'] = -2.0
    cfg['gatelag_Vd_q'] = 10.0
    cfg['gatelag_pulse_width'] = 20.0e-3
    cfg['gatelag_pulse_period'] = 40.0e-3
    
    cfg['drainlag_Vd_ss'] = 50.0
    cfg['drainlag_Vd_pulse'] = 10.0
    cfg['drainlag_Vg_q'] = -2.0
    cfg['drainlag_pulse_width'] = 100.0e-3
    cfg['drainlag_pulse_period'] = 200.0e-3
    
    cfg['target_Ids'] = [ 20.0e-3 ]
    cfg['Vg_start'] = -2.0
    cfg['Vg_step'] = 10.0e-3
    cfg['Vg_stop'] = 0.0
    cfg['Ig_limit_ua'] = 100.0
    cfg['Id_limit_ma'] = 100.0
    
    cfg['output_filter'] = False
    cfg['single_pulse'] = True
        
    cfg['gate_smu'] = ('b2902','GPIB::22',{'chan':1})
    cfg['drain_smu'] = ('b2902','GPIB::22',{'chan':2})

    return cfg
    
if __name__ == '__main__':
    import optparse, sys
    p = optparse.OptionParser(usage='USAGE: %prog [-c CONFIGFILE] [OUTFILE]')
    p.add_option('-c','--cfg',metavar='FILE',dest='cfg',help='config file path')
    
    opts, args = p.parse_args()
    kw = {}
    if opts.cfg:
        kw['cfgfname'] = opts.cfg
    
    if len(args) == 1:
        kw['fname'] = args[0]
    elif len(args) > 1:
        p.print_usage()
        sys.exit(1)        
    
    main(**kw)
    

    
    
    
