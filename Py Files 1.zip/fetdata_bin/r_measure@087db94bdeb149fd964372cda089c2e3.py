#!/usr/bin/env python

import visa
import time
import sys
import datetime
from instrument.manager import InstrumentManager
from instrument.utils import timed_wait_ms
import os

def run_test():
    manager= InstrumentManager()
    driver=manager.get_driver('bias','keithley236')
    kth_keywords = {'averaging':32,'integration':'linecycle','sensing':'local'}
    supply= driver('GPIB::21')
    supply.config(**kth_keywords)
    v_sweep=[0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8]
    filename= raw_input('Enter the filename for the test \n')
    if os.path.exists(filename):
        print "Warning: file '%s' exists." % filename
        if raw_input("Overwrite the existing file? (y/N): ").strip().lower()[0] != 'y': 
            print "Exiting."
            return
    f= open(filename,'w')
    f.write('VSet \t IMeasured \n')
    
    try:
       for i in range(len(v_sweep)):
           supply.config(vset= v_sweep[i],ilimit= 0.320, state=1)
           current= supply.measure()
           time.sleep(0.2)
           
           f.write('%f\t %.3e\n'%(v_sweep[i],current))
    except IOError:
           print "Unable to write to the file"
           return
    finally:
           supply.close()
           f.close()

if __name__=="__main__":
    run_test()
          

    
