#!/usr/bin/env python

"""
Custom test program for measuring FET Vgs shift after a soak period under bias
and also capturing the gate diode ideality

J. Barrett
Nov. 15, 2012
"""
import os, sys, time, math, os.path
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
import logging

BOLTZMANN = 1.3806503e-23
QELECTRON = 1.602176565e-19

class WaferMap(object):
    """Structure to hold wafer map information."""
    
    _log = logging.getLogger('WaferMap')
    
    def __init__(self):
        """Initialize."""
        self.__xi = 0
        self.__yi = 0
        self.__mf = 'N'
        self.__sites = []
        
    def read_map(self, fname):
        """Read a wafer map file.
        
        The wafer map file has the following format:
        ---------------------------------
        xindex: XXXXX
        yindex: YYYYY
        majorflat: Z
        
        [sites]
        x1 y1
        x2 y2
        x3 y3
        .
        .
        .
        ---------------------------------
        
        Where:
        XXXXX is the step index for X (positive integer)
        YYYYY is the step index for Y (positive integer)
        Z is either N, S, W, or E for the position of the major flat
        
        Any line with a leading '#' is a comment
        
        """
        f = open(fname,'rU')
        startsites = False
        try:
            for line in f:
                if line.startswith('#'):
                    continue
                
                line = line[:-1]
                if not startsites:
                    if line.startswith('xindex:'):
                        self.set_xindex(int(line[7:]))
                    elif line.startswith('yindex:'):
                        self.set_yindex(int(line[7:]))
                    elif line.startswith('majorflat:'):
                        mf = line[10:].strip()
                        self.set_mf(mf)
                    elif line.startswith('[sites]'):
                        startsites = True
                else:
                    if not len(line):
                        continue
                        
                    try:
                        x,y = tuple(line.split())
                        self.add_site(x,y)
                    except Exception, e:
                        self._log.warning("illegal line '%s' in file '%s'"%(line,fname))
                        continue
                        
        finally:
            f.close()
        
    def set_xindex(self, x):
        """Set the X index."""
        x = int(x)
        if x <= 0:
            raise ValueError("X-index must be greater than 0.")            
        self.__xi = x
        
    def set_yindex(self, y):
        """Set the Y index."""
        y = int(y)
        if y <= 0:
            raise ValueError("Y-index must be greater than 0.")            
        self.__yi = y
        
    def set_mf(self, mf):
        """Set the major flat location."""
        mf = mf.upper()
        if mf not in ('N','S','W','E'):
            raise ValueError("Invalid major flat position '%s'"%mf)
        self.__mf = mf
    
    def add_site(self, x, y):
        """Add a site to the map."""
        x, y = int(x), int(y)
        if x <= 0 or y <= 0:
            raise ValueError("site IDs must be positive integers.")
        self.__sites.append( (x,y) )
    
    def compute_pos(self, idx, startidx=0):
        """Compute the differential position from the starting index."""
        indexing_map = dict(N=(self.__xi,-self.__yi),S=(-self.__xi,self.__yi),
            E=(-self.__yi,-self.__xi), W=(self.__yi,self.__xi))
        column_map = dict(N=(0,1), S=(0,1), E=(1,0), W=(1,0))
        
        start = self.__sites[startidx]
        current = self.__sites[idx]
        cm = column_map[self.__mf]
        im = indexing_map[self.__mf]
        return (current[cm[0]]-start[cm[0]])*im[0], (current[cm[1]]-start[cm[1]])*im[1]
       
    def get_site_name(self, idx):
        """Get the name of the site at the given index."""
        x,y = self.__sites[idx]
        return '%0.2d%0.2d'%(x,y)
       
    def get_site_index(self, x, y):
        """Get the ordinal index of site (x,y)."""
        x, y = int(x), int(y)
        for i,site in enumerate(self.__sites):
            if site[0] == x and site[1] == y:
                return i
        raise ValueError("site '%d,%d' is not in the wafer map"%(x,y))
        
    def __getitem__(self,i):
        return self.__sites[i]
    
    def __len__(self):
        return len(self.__sites)


def main():
    "entry point"
    # init logging
    logging.basicConfig()
    
    filename = raw_input("File name for test data? ")
    if os.path.exists(filename):
        r = raw_input("'%s' exists - overwrite? (y/N)"%filename).strip().lower()
        if not r.startswith('y'):
            return
    
    ### test parameters
    parms = {
        'vg':-8.9,
        'vd':-8.0,
        'iglimit':0.0004,
        'idlimit':0.15,
        'soak':30.0,
        'vgstep':0.005,
        'ighigh':0.004,
        'iglow':0.0004,
        'temp':25.0,
        'mapfile':'sites.map',
    }
    
    # read wafer map
    map1 = WaferMap()
    map1.read_map(parms.get('mapfile','sites.map'))
    
    # load instruments
    mgr = InstrumentManager()
    driver=mgr.get_driver('bias','Keithley236')
    prober = mgr.open_driver('prober','12k','GPIB::28')
    gatesmu = driver('GPIB::21')
    drainsmu = driver('GPIB::23')
    kth_keywords = {'averaging':32,'integration':'linecycle','sensing':'local'}
    gatesmu.config(**kth_keywords)
    drainsmu.config(**kth_keywords) 
    
    # get the autoprober initial position
    start_x, start_y = prober.get_position() 
    
    
    # open the output file
    fp = open(filename,'w')
    fp.write("! Custom DC Soak Test w/ Ideality\n!\n")
    fp.write("! Test Date: %s\n"%datetime.now().strftime("%Y/%m/%d %H:%M:%S"))
    fp.write("!X\tY\tVgs\tVds\tIds(init)\tElapsed\tIds(final)\tVgs(ret)\tIds(ret)\tLastVgs\tLastIds\tIglow\tIghigh\tVglow\tVghigh\tIdeality\n")
        
    # start site loop
    try:
        try:
            for i in range(len(map1)):
                x, y = map1.compute_pos(i)
                if i > 0:
                    # move probe station
                    prober.set_position_synch(start_x+x,start_y+y)
                
                # run the test
                try:
                    run_site(gatesmu,drainsmu,x,y,parms,fp)
                except KeyboardInterrupt:
                    raw_input("site aborted, press Enter to continue (Control-C again to quit)")
        except Exception:
            # clean up instruments and exit
            drainsmu.set_state(0)
            timed_wait_ms(50)
            gatesmu.set_state(0)
            raise
    finally:
        fp.close()

def run_site( gatesmu, drainsmu, x, y, parms,fp):
    "run the test for a given site"
     
    print "====== Site (%d,%d) ======"%(x,y)
    
    # turn on the SMUs and record the initial current
    vg = parms.get('vg',0.0)
    vd = parms.get('vd',2.0)
    iglimit = parms.get('iglimit',0.001)
    idlimit = parms.get('idlimit',0.2)

       
    gatesmu.config(mode='V',vset=vg,ilimit=iglimit,state=1)
    timed_wait_ms(50)
    drainsmu.config(mode='V',vset=vd,ilimit=idlimit,state=1)
    
    # measure the starting current
    timed_wait_ms(100)
    id_initial = drainsmu.measure()
    print "Ids initial:        ", '%.3e'%id_initial
    
    # wait the specified time
    starttime = time.time()
    stoptime = starttime + parms.get('soak',1200)
    
    print "Starting soak at:   ",datetime.fromtimestamp(starttime).strftime("%H:%M:%S")
    print "Soak will finish at:",datetime.fromtimestamp(stoptime).strftime("%H:%M:%S")
    while True:
        cur = time.time()
        if cur >= stoptime:
            break
        time.sleep(1.0)
    elapsed = cur - starttime
    print "Soak done, elapsed: ", str(elapsed)
    
    # measure the ending current
    id_final = drainsmu.measure()
    print "Ids final:          ", '%.3e'%id_final

    gatesmu.set_state(0)
    drainsmu.set_state(0)
    
    # reset the gate voltage to target the the initial
    step = parms.get('vgstep',0.001)
    if id_final > id_initial:
        step = -step
    last_ids = None
    last_vg = None
    tolerance= 0.10
    """while True:
        vg+=step
        gatesmu.config(vset=vg,state=1)
        drainsmu.config(vset=vd, state=1)
        ids= drainsmu.measure()
        if abs(ids-id_initial)<=0.10:
              last_vg= vg
              vg_retarget= vg
              id_retarget= ids
              last_ids= ids
              break
        
        """
    while True:
        vg += step
        gatesmu.config(vset=vg)
        timed_wait_ms(20)
        ids = drainsmu.measure()
        if ids < id_initial:
            # this is the end of the loop
            if last_ids is not None:
                last_vg = vg - step
            vg_retarget = vg
            id_retarget = ids
            break
        last_ids = ids
       
      
    #print "Vg Shift:           ", '%.3f'%(vg_retarget-vg)
    print "Vg Shift:           ", '%.3f'%(last_vg-vg)
    
    # turn off the SMUs
    drainsmu.set_state(0)
    timed_wait_ms(50)
    gatesmu.set_state(0)
    
    # do a simple 2-point ideality measurement
    ighigh = parms.get('ighigh',0.004)
    iglow = parms.get('iglow',0.0004)
    
    # turn on the SMUs for the idealith measurement
    drainsmu.config(mode='V',vset=0.0,ilimit=4*ighigh,state=1)
    timed_wait_ms(50)
    gatesmu.config(mode='I',iset=iglow,vlimit=1.7,state=1,irange=ighigh)
    
    # do the 2-point ideality measurement
    timed_wait_ms(200)
    vlo = gatesmu.measure()
    gatesmu.config(iset=ighigh)
    timed_wait_ms(200)
    vhi = gatesmu.measure()
    
    # turn off SMUs
    gatesmu.set_state(0)
    drainsmu.set_state(0)
    
    # compute the ideality
    T = parms.get('temp',25.0)
    ktq = BOLTZMANN*(T+273.15)/QELECTRON
    n = (vhi-vlo)/(math.log(ighigh)-math.log(iglow))/ktq
    print "Ideality:           ", '%.3f'%n
    
    # write results
    fp.write("%d\t%d\t%.3f\t%.2f\t%.3e\t%.1f\t%.3e\t%.3f\t%.3e\t%.3f\t%.3e\t%.3e\t%.3e\t%.4f\t%.4f\t%.3f\n"% \
        (x, y, vg, vd, id_initial, elapsed, id_final, vg_retarget, id_retarget, last_vg, last_ids, iglow, ighigh, vlo, vhi, n))
    
if __name__ == '__main__':
    main()
    
    
