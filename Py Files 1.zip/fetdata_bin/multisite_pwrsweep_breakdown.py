#!/usr/bin/env python

import visa as vi
import os, sys, time
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
import logging

class rf_source(object):
    def __init__(self,address):
        self.rfsc= vi.instrument(address)
        self.rfsc.write('*CLS')
        self.rfsc.write('OUTP:STAT 0')
    def set_power(self,power):
        self.rfsc.write('POW:AMPL %f'%power)
    def set_state(self,state):
        self.rfsc.write('OUTP:STAT %d'%state)


class WaferMap(object):
    """Structure to hold wafer map information."""
    
    _log = logging.getLogger('WaferMap')
    
    def __init__(self):
        """Initialize."""
        self.__xi = 0
        self.__yi = 0
        self.__mf = 'N'
        self.__sites = []
        
    def read_map(self, fname):
        """Read a wafer map file.
        
        The wafer map file has the following format:
        ---------------------------------
        xindex: XXXXX
        yindex: YYYYY
        majorflat: Z
        
        [sites]
        x1 y1
        x2 y2
        x3 y3
        .
        .
        .
        ---------------------------------
        
        Where:
        XXXXX is the step index for X (positive integer)
        YYYYY is the step index for Y (positive integer)
        Z is either N, S, W, or E for the position of the major flat
        
        Any line with a leading '#' is a comment
        
        """
        f = open(fname,'rU')
        startsites = False
        try:
            for line in f:
                if line.startswith('#'):
                    continue
                
                line = line[:-1]
                if not startsites:
                    if line.startswith('xindex:'):
                        self.set_xindex(int(line[7:]))
                    elif line.startswith('yindex:'):
                        self.set_yindex(int(line[7:]))
                    elif line.startswith('majorflat:'):
                        mf = line[10:].strip()
                        self.set_mf(mf)
                    elif line.startswith('[sites]'):
                        startsites = True
                else:
                    if not len(line):
                        continue
                        
                    try:
                        x,y = tuple(line.split())
                        self.add_site(x,y)
                    except Exception, e:
                        self._log.warning("illegal line '%s' in file '%s'"%(line,fname))
                        continue
                        
        finally:
            f.close()
        
    def set_xindex(self, x):
        """Set the X index."""
        x = int(x)
        if x <= 0:
            raise ValueError("X-index must be greater than 0.")            
        self.__xi = x
        
    def set_yindex(self, y):
        """Set the Y index."""
        y = int(y)
        if y <= 0:
            raise ValueError("Y-index must be greater than 0.")            
        self.__yi = y
        
    def set_mf(self, mf):
        """Set the major flat location."""
        mf = mf.upper()
        if mf not in ('N','S','W','E'):
            raise ValueError("Invalid major flat position '%s'"%mf)
        self.__mf = mf
    
    def add_site(self, x, y):
        """Add a site to the map."""
        x, y = int(x), int(y)
        if x <= 0 or y <= 0:
            raise ValueError("site IDs must be positive integers.")
        self.__sites.append( (x,y) )
    
    def compute_pos(self, idx, startidx=0):
        """Compute the differential position from the starting index."""
        indexing_map = dict(N=(self.__xi,-self.__yi),S=(-self.__xi,self.__yi),
            E=(-self.__yi,-self.__xi), W=(self.__yi,self.__xi))
        column_map = dict(N=(0,1), S=(0,1), E=(1,0), W=(1,0))
        
        start = self.__sites[startidx]
        current = self.__sites[idx]
        cm = column_map[self.__mf]
        im = indexing_map[self.__mf]
        return (current[cm[0]]-start[cm[0]])*im[0], (current[cm[1]]-start[cm[1]])*im[1]
       
    def get_site_name(self, idx):
        """Get the name of the site at the given index."""
        x,y = self.__sites[idx]
        return '%0.2d%0.2d'%(x,y)
       
    def get_site_index(self, x, y):
        """Get the ordinal index of site (x,y)."""
        x, y = int(x), int(y)
        for i,site in enumerate(self.__sites):
            if site[0] == x and site[1] == y:
                return i
        raise ValueError("site '%d,%d' is not in the wafer map"%(x,y))
        
    def __getitem__(self,i):
        return self.__sites[i]
    
    def __len__(self):
        return len(self.__sites)

def main():
    filename=raw_input("Enter Filename for test data?\n")
    if os.path.exists(filename):
        r=raw_input("%s exists-overwrite?(y/n)"%filename).strip().lower()
        if not r.startswith('y'):
            return
    # Parameters for the test including FET DC Parameters and mapfile for stepping across the wafer
    params= {
        'ngf':2,
        'ugw':200,
        'max_vds':8.0,
        'max_power':1.25,
        'min_vgs':-3,
        'max_vgs':1.6,
        'max_igs':1,
        'max_ids':800,
        'ibr_low':0.01,
        'ibr_high':0.1,
        'max_vbr':30,
        'vds_idss':3,
        'vds_imax':1.5,
        'igs_imax':1,
        'vpo_percent':2.5,
        'vpo_current':1,
        'drain_v_power': 11.5,
        'gate_v_power': -0.90,
        'rf_in': -18.3,
        'mapfile':'sites.map',
        'wafer':'181402603_069',
        'device':'2x2001p3a'}
    map1 = WaferMap()
    map1.read_map(params.get('mapfile','sites.map'))
    
    mgr= InstrumentManager()
    driver= mgr.get_driver('bias','Keithley236')
    prober = mgr.open_driver('prober','12k','GPIB::28')
    gate= driver('GPIB::21')
    drain= driver('GPIB::23')
    rf= rf_source('GPIB::19') 
    kth_keywords={'averaging':32,'integration':'linecycle','sensing':'local'}
    gate.config(kth_keywords)
    drain.config(kth_keywords)
    rf.set_state(0)
    rf.set_power(params['rf_in'])
    
    failed_device_list=[]
    start_x, start_y = prober.get_position() 
    
    f= open(filename,'w')
    f.write('!Multisite RF Stress and Breakdown Test\n')
    f.write('!Test Date: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write('!Wafer:%s\n'%params['wafer'])
    f.write('!Device:%s\n'%params['device'])
    f.write('!Min Vgs= -3V\n')
    f.write('! Vgd sweep values= [10V,13V,16V,20V]\n')
    f.write('! Stress Drain Voltage= %f\n'%(params['drain_v_power']))
    f.write('!\n')
    f.write('!DC FET PARAMETERS\n')
    f.write('!x\ty\tpre_Vbr(0.01mA/mm)\tpre_Vbr(0.1mA/mm)\tpre_Idss(3V)\tpre_Vpo(3V)\tpre_Imax(1.5V)\tpre_Vpo(1.5V)\tpre_VMax(1.5V)\tpre_Vpo(1mA/mm)\tpre_Ron(Ohms)\tpre_Ig(10V)\tpre_Ig(13V)\tpre_Ig(16V)\tpre_Ig(20V)\tpost_Vbr(0.01mA/mm)\tpost_Vbr(0.1mA/mm)\tpost_Idss(3V)\tpost_Vpo(3V)\tpost_Imax(1.5V)\tpost_Vpo(1.5V)\tpost_VMax(1.5V)\tpost_Vpo(1mA/mm)\tpost_Ron(Ohms)\tpost_Ig(10V)\tpost_Ig(13V)\tpost_Ig(16V)\tpost_Ig(20V)\n')
    try:
        try:
            for i in range(len(map1)):
                x, y = map1.compute_pos(i)
                site = map1.get_site_name(i)
                if i > 0:
                    # move probe station
                    prober.set_position_synch(start_x+x,start_y+y)
                                
                # run the test
                try:
                    data=dc_screen(gate,drain,params,site)
                    f.write('%d\t%d\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t'%(data['x'],data['y'],data['vbr_ss_low'],data['vbr_ss_high'],data['idss'],data['vpo'],data['imax'],data['vpo_imax'],data['vmax'],data['vpo_mamm'],data['ron'],data['ig_10v'],data['ig_12v'],data['ig_15v'],data['ig_20v']))
                    f.flush()
                    if data['failed_device_flag']==1:
                        power_stress(gate,drain,rf,params)
                        data=dc_screen(gate,drain,params,site)
                        f.write('%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\t%+0.4e\n'%(data['vbr_ss_low'],data['vbr_ss_high'],data['idss'],data['vpo'],data['imax'],data['vpo_imax'],data['vmax'],data['vpo_mamm'],data['ron'],data['ig_10v'],data['ig_12v'],data['ig_15v'],data['ig_20v']))
                        f.flush()
                    else:
                        f.write('\n')
                        print 'Device Failed, Moving on to next device'
                        failed_device_list.append(site)
                except KeyboardInterrupt:
                    raw_input("Site aborted, press Enter to continue (Control-C again to quit)")
        except Exception:
            # clean up instruments and exit
            rf.set_state(0)
            drain.set_state(0)
            timed_wait_ms(50)
            gate.set_state(0)
            raise
    finally:
        f.write('Failed Devices:')
        for i in failed_device_list:
            f.write('(%s),\t'%(i))
        drain.close()
        gate.close()
        f.close()

def current_target(gate,drain,params):
    target= 50e-3
    start= -0.9
    step=0.025
    count=0
    while(True):
        gate.config(mode='V',vset=start, ilimit= 4.0e-3, state=1)
        timed_wait_ms(10)
        drain.config(mode='V',vset=params['drain_v_power'], ilimit= 0.2, state=1)
        timed_wait_ms(50)
        id= float(drain.measure())
        timed_wait_ms(70)
        print id
        if count>=20:
            break
        if abs(id-target)<=0.0025:
            break
        else:
            start= start+step
        count=count+1
    return(start)
        
        
def power_stress(gate,drain,rf,params):
    print "Starting short RF Stress..."
    # Hitting the device with RF to see if we can affect a breakdown shift  
    for i in range(5):
        vg= current_target(gate,drain,params)
        gate.config(mode='V',vset=vg,ilimit=4.0e-3,state=1)
        timed_wait_ms(10)
        drain.config(mode='V',vset=params['drain_v_power'], ilimit=0.2,state=1)
        timed_wait_ms(80)
        rf.set_state(1)
        timed_wait_ms(10000)
        ig= gate.measure()
        timed_wait_ms(50)
        id=drain.measure()
        timed_wait_ms(50)
        print "RF Stress Ig= %s mA, Id= %s mA\n"%(ig,id)
        rf.set_state(0)
        timed_wait_ms(500)
        
    # Short RF Stress Complete
    drain.config(vset= 0.0, state=0)
    gate.config(vset= 0.0, state=0)
    print "RF Stress Completed!"


def dc_screen(gate,drain,params,site):
    print "DC Parameters on Device (%s)\n"%(site)
    # This flag lets us know if the device has failed or not
    data=dict()
    failed_device_flag=1
    tmp= site.split('0')
    if len(tmp)<3:
        x=int(tmp[1][0:1])       
        y=int(tmp[1][1:])
    elif site.split('0')[1]=='':
        x= int(site[0:2])
        y=int(site[2:])
    elif site.split('0')[2]=='':
        x= int(site[0:2].split('0')[1])
        y= int(site[2:])
    else:
        x=int(site.split('0')[1])
        y=int(site.split('0')[2])
    
    data['x']= x
    data['y']= y
    
    # Writing dc parameter headers to the data file
        
    fet_periphery= params['ngf']*params['ugw']
    vgs_start= params['min_vgs']
    # Set compliance for breakdown tests
    ic= fet_periphery*params['ibr_high']*4.0e-6
    vc= params['max_vbr']+params['min_vgs']
    
    # Doing the single sided breakdown
    print "Single Sided Breakdown.."
    
    gate.config(mode='V',vset=vgs_start,ilimit=ic, state=0)
    drain.config(mode='I',iset=params['ibr_low']*1.0e-6*fet_periphery, vlimit=vc,state=0)
    gate.set_state(1)
    timed_wait_ms(10)
    drain.set_state(1)
    timed_wait_ms(1000)
    vbr_reading= float(drain.measure())
    vbr_ss_low= params['min_vgs']-vbr_reading
    data['vbr_ss_low']= vbr_ss_low
    
    drain.config(mode='I',iset=params['ibr_high']*1e-6*fet_periphery,vlimit=vc,state=1)
    timed_wait_ms(1000)
    vbr_reading= float(drain.measure())
    vbr_ss_high= params['min_vgs']-vbr_reading
    data['vbr_ss_high']= vbr_ss_high
    
    drain.set_state(0)
    timed_wait_ms(10)
    gate.set_state(0)
    if vgs_start<(0.8*vbr_ss_high):
        vgs_start=0.8*vbr_ss_high
            
    # Done with Single Sided Breakdown
    
    print "Idss Measurement.."
    
    # Idss Measurement
    gate.config(mode='V',vset=0.0, ilimit=params['max_igs']*1e-6*fet_periphery,state=1)
    drain.config(mode='V',vset=params['vds_idss'], ilimit=params['max_ids']*1e-6*fet_periphery,state=1)
    timed_wait_ms(100)
    idss= float(drain.measure())
    drain.set_state(0)
    gate.set_state(0)
    data['idss']= idss

    print "Imax Measurement.."
    
    # Imax Measurement
    gate.config(mode='I', iset= params['igs_imax']*1.0e-6*fet_periphery, vlimit=params['max_vgs'], state=1)
    timed_wait_ms(100)
    drain.config(mode='V', vset=params['vds_imax'],ilimit=params['max_ids']*1.0e-6*fet_periphery,state=1)
    timed_wait_ms(100)
    vmax = float(gate.measure())
    imax = float(drain.measure())
    data['vmax']= vmax
    data['imax']=imax
    
    drain.set_state(0)
    gate.set_state(0)
    # Doing checks for failed devices. If Device fails, return 0 to main. Since this is a multisite test...
    # ...a list and count of failed devices will be maintained and recorded so that those devices can be skipped while performing the dc stress
    
    if vmax==0:
        print "fet_dc_parameters(): gate is open-circuited.\n"
        failed_device_flag= 0
        failed_device_reason='Gate Open Circuited'
        vmax=0.0
    elif vmax < 0.5:
        print "fet_dc_parameters(): gate is short-circuited.\n"
        failed_devie_flag=0
        failed_device_reason= 'Gate short circuited'
        vmax=0.0
    elif imax < 10.0e-6*fet_periphery:
        print "fet_dc_parameters(): channel is open-circuited.\n"
        failed_device_flag=0
        failed_device_reason= 'Channel open Circuited'
        imax=0.0
    elif imax==0:
        print "fet_dc_parameters(): channel is short-circuited.\n"
        failed_device_flag=0
        failed_device_reason= 'Channel short circuited'
        imax=0.0
    
    # Vpo measurement at Vds for Idss
    print "Pinchoff Measurement @ Vds for Idss..."
    
    gate_c = params['max_igs']*1.0e-6*fet_periphery
    drain_c = params['max_ids']*1.0e-6*fet_periphery
    vgg= vgs_start
    
    if idss<0.05*imax:
        target_ids = 0.01*params['vpo_percent']*imax
    else:
        target_ids = 0.01*params['vpo_percent']*idss
    
    gate.config(mode='V',vset=vgg,ilimit= gate_c, state=1)
    drain.config(mode='V', vset=params['vds_idss'],ilimit=drain_c, state=1)
    timed_wait_ms(100)
    idd= float(drain.measure())
    
    if idd> target_ids:
        drain.set_state(0)
        gate.set_state(0)
        print "Device failed to pinch off"
        failed_device_flag=0
        failed_device_reason= 'Failed to Pinch off'
        
    n=0
    last_vgg= 5.0+vgg
    while abs(idd - target_ids)> 0.001*target_ids:
        step = 0.65*abs(last_vgg - vgg)
        last_vgg = vgg
        if idd < target_ids:
            vgg += step
            if vgg > vmax*0.8:
                vgg = vmax*0.8
        else:
            vgg -= step
            if (vgg < vgs_start):
                vgg = vgs_start
        
        gate.config(mode='V',vset=vgg,ilimit= gate_c, state=1)
        drain.config(mode='V', vset= params['vds_idss'], ilimit=drain_c, state=1)
        timed_wait_ms(100)
        idd= float(drain.measure())
        n=n+1        
        if ((step < 1.0e-3) or (n > 20)):
            break
    
    vpo = vgg
    data['vpo']=vpo
    
    # Vpo Measurement at Vds for IMax
    print "Pinchoff Measurement for Vds@ Imax..."
    
    vgg= vgs_start
    
    if idss<0.05*imax:
        target_ids = 0.01*params['vpo_percent']*imax
    else:
        target_ids = 0.01*params['vpo_percent']*idss
    
    gate.config(mode='V',vset=vgg,ilimit= gate_c, state=1)
    drain.config(mode='V', vset=params['vds_imax'],ilimit=drain_c, state=1)
    timed_wait_ms(100)
    idd= float(drain.measure())
    
    if idd> target_ids:
        drain.set_state(0)
        gate.set_state(0)
        print "Device failed to pinch off\n"
        failed_device_flag=0
        failed_device_reason= 'Failed to Pinch off'
        
    n=0
    last_vgg= 5.0+vgg
    while abs(idd - target_ids)> 0.001*target_ids:
        step = 0.65*abs(last_vgg - vgg)
        last_vgg = vgg
        if idd < target_ids:
            vgg += step
            if vgg > vmax*0.8:
                vgg = vmax*0.8
        else:
            vgg -= step
            if (vgg < vgs_start):
                vgg = vgs_start
        
        gate.config(mode='V',vset=vgg,ilimit= gate_c, state=1)
        drain.config(mode='V', vset= params['vds_imax'], ilimit=drain_c, state=1)
        timed_wait_ms(100)
        idd= float(drain.measure())
        n=n+1
        if ((step < 1.0e-3) or (n > 20)):
            break
    
    vpo_imax = vgg
    data['vpo_imax']= vpo_imax
    
    # Vpo measurement mA/mm
    print "Pinchoff Measurement mA/mm..."
    
    vgg= vgs_start
    target_ids= params['vpo_current']*1e-6*fet_periphery
    
    gate.config(mode='V',vset=vgg,ilimit= gate_c, state=1)
    drain.config(mode='V', vset=params['vds_idss'],ilimit=drain_c, state=1)
    timed_wait_ms(100)
    idd= float(drain.measure())
    
    if idd> target_ids:
        drain.set_state(0)
        gate.set_state(0)
        print "Device failed to pinch off\n"
        failed_device_flag=0
        failed_device_reason= 'Failed to Pinch off'
    
    n=0
    last_vgg= 5.0+vgg
    while abs(idd - target_ids)> 0.001*target_ids:
        step = 0.65*abs(last_vgg - vgg)
        last_vgg = vgg
        if idd < target_ids:
            vgg += step
            if vgg > vmax*0.8:
                vgg = vmax*0.8
        else:
            vgg -= step
            if (vgg < vgs_start):
                vgg = vgs_start
        
        gate.config(mode='V',vset=vgg,ilimit= gate_c, state=1)
        drain.config(mode='V', vset= params['vds_idss'], ilimit=drain_c, state=1)
        timed_wait_ms(100)
        idd= float(drain.measure())
        n=n+1
        if ((step < 1.0e-3) or (n > 20)):
            break
    
    vpo_mamm = vgg
    data['vpo_mamm']= vpo_mamm
    
    # Ron Measurement D-FET
    print "Ron Measurement..."
    gate.config(mode='V',vset=0.0, ilimit=gate_c, state=1)
    drain.config(mode='V', vset=0.02, ilimit=drain_c, state=1)
    timed_wait_ms(1000)
    idd= float(drain.measure())
    ron= 0.02/idd
    data['ron']= ron
    drain.set_state(0)
    gate.set_state(0)
            
    # Doing the three voltage breakdown test
    print "Four Voltage Breakdown Test..."
    drain_v_list=[7.0,9.0,12.0,17.0]
    igs=[]
    for i in drain_v_list:
        gate.config(mode='V',vset=params['min_vgs'],ilimit=params['ibr_high']*4e-06*fet_periphery,state=0)
        drain.config(mode='V',vset=i, ilimit=params['ibr_high']*4e-06*fet_periphery,state=0)
        gate.set_state(1)
        timed_wait_ms(10)
        drain.set_state(1)
        timed_wait_ms(1000)
        igs.append(float(gate.measure()))
        timed_wait_ms(10)
        
    drain.set_state(0)
    gate.set_state(0)

    data['failed_device_flag']= failed_device_flag
    failed_device_reasons=["Failed to Pinch off","Gate Open Circuited","Gate short circuited","Channel open Circuited","Channel short circuited"]

    data['ig_10v']= igs[0]
    data['ig_12v']= igs[1]
    data['ig_15v']= igs[2]
    data['ig_20v']= igs[3]
   
    if failed_device_flag==0:
        if failed_device_reason in failed_device_reasons:
            for key in data:
                data[key]= 0.0
                data['x']=x
                data['y']=y
                data['failed_device_flag']= 0

    return data
    
    
if __name__=="__main__":
    main()
    
    
    
    

    
    
