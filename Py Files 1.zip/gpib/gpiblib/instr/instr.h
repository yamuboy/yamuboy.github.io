/* instrument-specific functions */
#include <instr/instr_calls.h>

#ifndef GPIB_LIB_H
#define GPIB_LIB_H

/* instument type constants */
#define INSTR_NOTYPE      (-1)
#define INSTR_BIAS        (1)
#define INSTR_VNA         (2)
#define INSTR_NFM         (3)
#define INSTR_AUTOPROBER  (4)
#define INSTR_TCONTROL    (5)
#define INSTR_SPECANA     (6)
#define INSTR_SIGGEN      (7)
#define INSTR_PWRMETER    (8)

/* resolution constants */
#define LOW_RES          (1)
#define MEDIUM_RES       (2)
#define HIGH_RES         (3)

/* bias driver constants */
#define SRC_OFF          (0)
#define SRC_VOLTAGE      (1)
#define SRC_CURRENT      (2)
#define AUTO_RANGE       (0.0)
#define MAX_COMPLIANCE   (1.0e12)

/* autoprober driver constants */
#define MOVE_REL_BASE    (1)
#define MOVE_REL_LAST    (2)
#define MOVE_ABSOLUTE    (3)

/* logging levels */
#define GPIB_LOGERR      (1<<0)  /* error logging */
#define GPIB_LOGBUS      (1<<1)  /* bus transaction logging */
#define GPIB_LOGBUSEXT   ((1<<3)|GPIB_LOGBUS)  /* extended bus transaction logging */
#define GPIB_LOGFUNC     (1<<5)  /* function logging (USE WITH CAUTION) */
#define GPIB_LOGTS       (1<<8)  /* add timestamps to all log entries (USE WITH CAUTION) */
#define GPIB_LOGALL      (GPIB_LOGERR|GPIB_LOGBUSEXT|GPIB_LOGFUNC|GPIB_LOGTS)

/* error codes */
#define EGPIB_INVALIDARG         (-100)
#define EGPIB_INVALIDLIBNAME     (-101)
#define EGPIB_LIBLOADFAIL        (-102)
#define EGPIB_LIBSYMMISSING      (-103)
#define EGPIB_CREATEFAILED       (-104)
#define EGPIB_INITFAILED         (-105)
#define EGPIB_CLOSEFAILED        (-106)
#define EGPIB_UDINVALID          (-200)
#define EGPIB_BUSERROR           (-300)
#define EGPIB_INSTRERROR         (-400)
#define EGPIB_WRONGINSTR         (-401)
#define EGPIB_NOTSUPPORTED       (-402)
#define EGPIB_NOTINITIALIZED     (-403)
#define EGPIB_BADDEVICE          (-404)

/* instrument info structure */
struct _gpib_info
   {
   int addr;
   int chan;
   char *timeout;
   char *instr_name;
   char *instr_type;
   char *driver_name;
   char *driver_version;
   char *driver_date;
   char *driver_text;
   };
typedef struct _gpib_info* gpib_info_t;

/***********************************************************************
                          Function Prototypes
 ***********************************************************************/

/* library functions */

extern int gpib_set_loglevel( int lvl );
extern int gpib_set_logfile( char *fname );
extern char* gpib_errmsg( void );
extern char* gpib_stderrmsg( int errnum );

/* functions to initialize and close the gpib board */

extern int gpib_board_open( int idx, int *bd );
extern int gpib_board_close( int bd );

/* generic instrument functions */

extern int gpib_instr_load( gpib_instr_t *inst, char *name, int insttype, char *libname, int bd, int addr,
                            int chan, int tmo, char donotinit );
extern int gpib_instr_unload( gpib_instr_t instr, char donotclose );
extern int gpib_instr_init( gpib_instr_t instr );
extern int gpib_instr_close( gpib_instr_t instr );
extern char* gpib_instr_getname( gpib_instr_t inst );
extern int gpib_instr_gettype( gpib_instr_t inst );
extern int gpib_instr_getinfo( gpib_instr_t inst, gpib_info_t *info );
extern void gpib_instr_freeinfo( gpib_info_t info );

/* other functions */

extern void ms_delay( unsigned ms );

/*******************************************************************************/
/*******************************************************************************/
/* 
      the following section is only included when building the library
      or when building drivers
 */
/*******************************************************************************/
/*******************************************************************************/

#ifdef GPIB_LIB_CREATE 

/* magic cookie definitions */
#define MC_GPIB_INSTR_BIAS          (0x3f5c134a)
#define MC_GPIB_INSTR_VNA           (0x45fe1291)
#define MC_GPIB_INSTR_NFM           (0x0312c31b)
#define MC_GPIB_INSTR_AP            (0xfe6aa1c2)
#define MC_GPIB_INSTR_TC            (0x3d12f503)
#define MC_GPIB_INSTR_SG            (0x8dd4f41c)
#define MC_GPIB_INSTR_PM            (0xca7351ef)
#define MC_GPIB_INSTR_SA            (0x402de82a)

/* instrument flags */
#define INSTRFLAG_INIT              (1<<0)

/* macros to access flags */
#define IS_INITIALIZED(x)     (((instr_general_t*)(x))->flag&INSTRFLAG_INIT)

/* instrument structures - internal representation */

typedef struct 
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (gpib_instr_t x);
   int (*close) (gpib_instr_t x);
   } instr_general_t;

typedef struct _bias_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _bias_def *b);
   int (*close) (struct _bias_def *b);
   /* other members/methods */
   int mode, resolution, triggered;
   double source, compliance;
   int (*set_bias) (struct _bias_def *b, int mode, double src, double comp, int res, double max_range, unsigned delay);
   int (*read_bias) (struct _bias_def *b, double *src, double *meas);
   int (*trigger) (struct _bias_def *b);
   int (*bias_off) (struct _bias_def *b);
   } instr_bias_t;

typedef struct _vna_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _vna_def *vna);
   int (*close) (struct _vna_def *vna);
   /* other members/methods */
   int (*read_freq_list) (struct _vna_def *vna, double *flist, unsigned sz_flist, unsigned *numf);
   int (*read_s_params) (struct _vna_def *vna, instr_complex_t sp[][4], unsigned sz_sp, unsigned *nums);
   int (*read_cal_coeffs) (struct _vna_def *vna, instr_complex_t c[][12], unsigned sz_c, unsigned *numc);
   } instr_vna_t;

typedef struct _nfm_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _nfm_def *nfm);
   int (*close) (struct _nfm_def *nfm);
   /* other members/methods */
   int (*read_noise_sweep) (struct _nfm_def *nfm, double *freq, double *nf, double *gain, unsigned sz_vec, unsigned *num);
   int (*load_enr) (struct _nfm_def *nfm, double *freq, double *enr, unsigned npts);
   } instr_nfm_t;

typedef struct _tcontrol_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _tcontrol_def *tc);
   int (*close) (struct _tcontrol_def *tc);
   /* other members/methods */
   int (*set_temp) (struct _tcontrol_def *tc, double t);
   int (*read_temp) (struct _tcontrol_def *tc, double *t);
   int (*shutdown) (struct _tcontrol_def *tc);
   } instr_tc_t;

typedef struct _autoprober_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _autoprober_def *ap);
   int (*close) (struct _autoprober_def *ap);
   /* other members/methods */
   long x_base, y_base, x_last, y_last;
   int (*move) (struct _autoprober_def *ap, long x, long y, int mode);
   int (*separate) (struct _autoprober_def *ap);
   } instr_ap_t;

typedef struct _specana_def
   {
   /* standard members/methods */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _specana_def *sa);
   int (*close) (struct _specana_def *sa);
   /* other members/methods */

   } instr_sa_t;

typedef struct _siggen_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _siggen_def *sg);
   int (*close) (struct _siggen_def *sg);
   /* other members/methods */
   int is_on;
   int (*turn_on) (struct _siggen_def *sg);
   int (*turn_off) (struct _siggen_def *sg);
   int (*set_power) (struct _siggen_def *sg, double dbm);
   int (*set_freq) (struct _siggen_def *sg, double freq);
   } instr_sg_t;

typedef struct _pwrmeter_def
   {
   /* standard members */
   unsigned long mc;
   void *h_lib, *udata;
   int bidx, addr, chan, tmo, ud, type, flag;
   char *name, *libname;
   char *libver, *libdate, *libtext;
   int (*open) (struct _pwrmeter_def *pm);
   int (*close) (struct _pwrmeter_def *pm);
   /* other members/methods */
   int (*read) (struct _pwrmeter_def *pm, double freq, int res, double *dbm);
   } instr_pm_t;

/* functions to be used by drivers/library only */

extern void* gpib_malloc( size_t sz );
extern int gpib_getud( int *ud, int bidx, int addr, int tmo, int send_eoi, int eos );
extern void gpib_freeud( int ud );
extern int gpib_write( int ud, char *buf );
extern int gpib_read( int ud, char *buf, int sz_buf );
extern int gpib_ask( int ud, char *wbuf, char *rbuf, int sz_rbuf );
extern int gpib_spoll( int ud, char *ret );
extern int gpib_clear( int ud );
extern int gpib_trig( int ud );
extern int gpib_golocal( int ud );
extern int gpib_buserror( void );
extern int gpib_readcount( void );

extern void gpib_seterror( char *id, char *errmsg );
extern void gpiblog_logstr( char type, char* str );

#define gpiblog_func(f)    gpiblog_logstr('F',f)

#endif  /* GPIB_LIB_CREATE */

#endif  /* GPIB_LIB_H */
