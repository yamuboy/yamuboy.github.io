#ifndef GPIBLIB_INSTR_H
#define GPIBLIB_INSTR_H


/* generic GPIB instrument structure -
    instruments are recoginized through
    their magic-cookie structure components
    */
typedef void* gpib_instr_t;

/* complex data structure */
typedef struct {
   double real, imag;
   } instr_complex_t;

extern int gpib_bias_set( gpib_instr_t instr, int mode, double src, double comp, int res, double max_range, unsigned delay );
extern int gpib_bias_trig( gpib_instr_t instr );
extern int gpib_bias_read( gpib_instr_t instr, double *src, double *meas );
extern int gpib_bias_off( gpib_instr_t instr );

extern int gpib_vna_readflist( gpib_instr_t instr, double *flist, unsigned sz_flist, unsigned *numf );
extern int gpib_vna_readsp( gpib_instr_t instr, instr_complex_t sp[][4], unsigned sz_sp, unsigned *nums );
extern int gpib_vna_readcal( gpib_instr_t instr, instr_complex_t c[][12], unsigned sz_c, unsigned *numc );

extern int gpib_nfm_readswp( gpib_instr_t instr, double *freq, double *nf, double *gain, unsigned sz_vec, unsigned *num );
extern int gpib_nfm_loadenr( gpib_instr_t instr, double *freq, double *enr, unsigned npts );

extern int gpib_ap_move( gpib_instr_t instr, long x, long y, int mode );
extern int gpib_ap_separate( gpib_instr_t instr );

extern int gpib_pm_read( gpib_instr_t instr, double freq, int res, double *dbm );

extern int gpib_sg_setfreq( gpib_instr_t instr, double freq );
extern int gpib_sg_setpower( gpib_instr_t instr, double dbm );
extern int gpib_sg_rfon( gpib_instr_t instr );
extern int gpib_sg_rfoff( gpib_instr_t instr );

extern int gpib_tc_settemp( gpib_instr_t instr, double temp );
extern int gpib_tc_readtemp( gpib_instr_t instr, double *temp );
extern int gpib_tc_shutdown( gpib_instr_t instr );

#endif

