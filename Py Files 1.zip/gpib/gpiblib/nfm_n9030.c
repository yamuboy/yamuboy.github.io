#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_nfm( instr_nfm_t *nfm );
static int close_nfm( instr_nfm_t *nfm );
static int read_noise_sweep( instr_nfm_t *nfm, double *freq, double *nf, double *gain, unsigned sz, unsigned *num );
static int load_enr_table( instr_nfm_t *nfm, double *freq, double *enr, unsigned npts );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_nfm_t* nm;

   if( gpib_instr_gettype( inst ) != INSTR_NFM )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   nm = (instr_nfm_t*) inst;

   /* initialize the driver methods */
   nm->open = open_nfm;
   nm->close = close_nfm;
   nm->read_noise_sweep = read_noise_sweep;
   nm->load_enr = load_enr_table;

   /* set the library version and text fields */
   nm->libver = "1.0.0";
   nm->libtext = "Driver for the Agilent N9010A/N9020A/N9030A PXA/CXA/MXA noise figure application.";

   return 0;
   }


/******************************************************************************************/
/******************************************************************************************/

static int open_nfm( instr_nfm_t *nm )
{
    int e;
    char r[256];

    /* create the device descriptor */
    e = gpib_getud(&nm->ud, nm->bidx, nm->addr, nm->tmo, 1, 0);
    if(e)
        return e;
    
    /* make sure this is the correct instrument */
    e = gpib_ask(nm->ud, "*IDN?", r, 256);
    if(e)
        return e;
    if( !strstr(r,"Agilent") || (!strstr(r,"N9010") && !strstr(r,"N9020") && !strstr(r,"N9030")) )
        return EGPIB_WRONGINSTR;
        
    /* make sure that the noise figure measurement is set up + configured */
    e = gpib_ask(nm->ud, ":CONF?", r, 256);
    if(e)
        return e;
    if( strncmp(r,"NFIG",4) ) {
        gpib_seterror(nm->name,"PXA noise figure measurement application is not properly configured.");
        return EGPIB_INSTRERROR;
    }
       
    /* turn off continuous trigger */
    e = gpib_write(nm->ud, ":INIT:CONT OFF");
    if(e)
        return e;

    return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int close_nfm( instr_nfm_t *nfm )
{
    int e;

    /* turn on continuous trigger */
    e = gpib_write(nfm->ud, ":INIT:CONT ON");
    if(e)
        return e;
      
    /* turn on filter alignment */
    e = gpib_write(nfm->ud, ":CAL:AUTO ON");
    if(e)
        return e;    
    
    gpib_golocal( nfm->ud );
    gpib_freeud( nfm->ud );
    nfm->ud = -1;
    return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static unsigned load_return_array( char *data, double *out, unsigned szout )
{
    unsigned n = 0;
    char *p = data;
    double f;
    
    while( *p != '\0' ) {
        if( !sscanf(p,"%lf",&f) )
            break;
        
        if( n >= szout )
            break;
        
        out[n] = f;
        ++n;
        
        while( *p != ',' && *p != '\0' )
            ++p;
        
        if( *p != '\0' )
            // increment past the comma
            ++p;
    }
    return n;
}  

/******************************************************************************************/
/******************************************************************************************/

static int read_noise_sweep( instr_nfm_t *nm, double *freq, double *nf, double *gain, unsigned sz, unsigned *num )
{
    char r[2048];
    int e, st;
    unsigned nfr, nnf, nga;
    
    /* turn off filter alignment */
    e = gpib_write(nm->ud, ":CAL:AUTO OFF");
    if(e)
        return e;    
    
    /* initiate a measurement */
    e = gpib_write(nm->ud, ":INIT:CONT OFF;REST");
    if(e)
        return e;
    
    /* wait for the measurement to complete */
    while( 1 ) {
        ms_delay(100);
        e = gpib_ask(nm->ud, ":STAT:OPER?", r, 2048);
        if(e)
            return e;
        st = atoi(r);
        if( !(st & 8) )
            break;
    }
    
    /* read frequency list */
    e = gpib_ask(nm->ud, ":SENS:NFIG:FREQ:MODE?", r, 2048);
    if(e)
        return e;    
    if( r[0] == 'L' ) {
        // list frequency mode
        e = gpib_ask(nm->ud, ":SENS:NFIG:FREQ:LIST:DATA?", r, 2048);
        if(e)
            return e;    
        nfr = load_return_array(r,freq,sz);
    }
    else if( r[0] == 'F' ) {
        // fixed frequency mode
        e = gpib_ask(nm->ud, ":SENS:NFIG:FREQ:FIX?", r, 2048);
        if(e)
            return e;    
        freq[0] = atof(r);
        nfr = 1;
    }
    else {
        // swept frequency mode
        double start, span, step;
        unsigned i;
        e = gpib_ask(nm->ud, ":SENS:NFIG:FREQ:STAR?", r, 2048);
        if(e)
            return e;    
        start = atof(r);
        e = gpib_ask(nm->ud, ":SENS:NFIG:FREQ:SPAN?", r, 2048);
        if(e)
            return e;    
        span = atof(r);
        e = gpib_ask(nm->ud, ":SENS:NFIG:SWE:POIN?", r, 2048);
        if(e)
            return e;    
        nfr = (unsigned) atoi(r);
        step = span / ((double) (nfr-1));

        for( i=0; i<nfr; ++i ) {
            if( i>=sz ) {
                nfr = sz;
                break;
            }
            freq[i] = start + step*i;
        }
    }

    /* read data */
    e = gpib_ask(nm->ud, ":FORM:DATA ASC;:FETC:NFIG:ARR:CORR:NFIG?", r, 2048);
    if(e)
        return e;
    nnf = load_return_array(r,nf,sz);
    
    e = gpib_ask(nm->ud, ":FORM:DATA ASC;:FETC:NFIG:ARR:CORR:GAIN?", r, 2048);
    if(e)
        return e;    
    nga = load_return_array(r,gain,sz);
    
    if( nfr != nnf || nfr != nga ) {
        gpib_seterror(nm->name,"Frequency list mismatch!");
        return EGPIB_INSTRERROR;
    }    
    *num = nfr;
    
    /* run filter alignments that are pending */
    e = gpib_ask(nm->ud, ":CAL:EXP?", r, 1024);
    if(e)
        return e;    

    return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int load_enr_table( instr_nfm_t *nfm, double *freq, double *enr, unsigned npts )
{
    gpib_seterror(nfm->name,"Remote ENR table loading is not supported by this driver.");
    return EGPIB_NOTSUPPORTED;
}


