#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <instr/instr.h>

enum {
   HP41420A,
   HP41421B,
   HP41422A,
   HP41423A
   };

typedef struct
   {
   struct timeval trig_time;
   unsigned delay;
   } TIMING_INFO;

static int open_bias( instr_bias_t *bias );
static int close_bias( instr_bias_t *bias );
static int set_bias( instr_bias_t *bias, int mode, double src, double compl, int res, double max_range, unsigned delay );
static int bias_off( instr_bias_t *bias );
static int trigger( instr_bias_t *bias );
static int read_bias( instr_bias_t *bias, double *src, double *meas );

static double get_source( int type, int mode, double src );
static double get_compliance( int type, int mode, double src, double compl );
static int get_range( int type, int mode, double val );

/*********************************************************************************/
/*********************************************************************************/
/* this is the only exported routine */

extern int instr_load( gpib_instr_t inst )
   {
   instr_bias_t* bias;

   if( gpib_instr_gettype( inst ) != INSTR_BIAS )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   bias = (instr_bias_t*) inst;

   /* initialize the driver methods */
   bias->open = open_bias;
   bias->close = close_bias;
   bias->set_bias = set_bias;
   bias->read_bias = read_bias;
   bias->trigger = trigger;
   bias->bias_off = bias_off;

   /* set the library version and text fields */
   bias->libver = "1.0.0";
   bias->libtext = "Driver for the HP 4142 configurable SMU chassis.";

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int open_bias( instr_bias_t *bias )
   {
   static char *query = "*IDN?\r\n";
   char buf[200];
   char *ptr1, *ptr2;
   int e, i;

   /* create the device descriptor */
   e = gpib_getud( &bias->ud, bias->bidx, bias->addr, bias->tmo, 1, 0 );
   if( e )
      return e;

   /* clear/reset the instrument */
   e = gpib_clear( bias->ud );
   if( e )
      return e;

   /* query the instrument */
   e = gpib_write( bias->ud, query );
   if( e )
      return e;

   /* check the instrument ID string */
   e = gpib_read( bias->ud, buf, 200 );
   if( e )
      return e;
   if( !strstr(buf, "4142B") )
      {
      gpib_seterror( bias->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
      }

   /* check the channel configuration */

   if( bias->chan < 1 || bias->chan > 8 )
      {
      sprintf( buf, "Channel %d is not valid for this instrument.", bias->chan );
      gpib_seterror( bias->name, buf );
      return EGPIB_INSTRERROR;
      }

   e = gpib_write( bias->ud, "UNT?\r\n" );
   if( e )
      return e;
   e = gpib_read( bias->ud, buf, 200 );
   if( e ) {
      gpib_write( bias->ud, "ERR?\r\n" );
      gpib_read( bias->ud, buf, 200 );
      return e;
   }

   /* parse the configuration string to determine the unit model */
   ptr1 = ptr2 = buf;
   for( i=1; *ptr2; ptr2++ )
      {
      if( *ptr2 == ';' )
         {
         *ptr2 = '\0';
         if( i == bias->chan )
            {
            if( strstr( ptr1, "41420A" ) )
               bias->type = HP41420A;
            else if( strstr( ptr1, "41421B" ) )
               bias->type = HP41421B;
            else if( strstr( ptr1, "41422A" ) )
               bias->type = HP41422A;
            else if( strstr( ptr1, "41423A" ) )
               bias->type = HP41423A;
            else
               {
               bias->type = -1;
               sprintf( buf, "Unit at channel %d is either missing or not recognized.", bias->chan );
               gpib_seterror( bias->name, buf );
               return EGPIB_INSTRERROR;
               }
            break;
            }
         ptr1 = ptr2+1;
         i++;
         }
      }

   /* allocate memory for the TIMING_INFO struct */
   bias->udata = malloc( sizeof(TIMING_INFO) );

   return 0;
   }      

/*********************************************************************************/
/*********************************************************************************/

static int close_bias( instr_bias_t *bias )
   {
   if( bias->mode )
      bias_off( bias );
   
   /* take the device descriptor offline */
   gpib_golocal( bias->ud );
   gpib_freeud( bias->ud );
   bias->ud = -1;

   /* free the timing info structure */
   if( bias->udata )
      free((void *)bias->udata);
   bias->udata = NULL;

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int set_bias( instr_bias_t *bias, int mode, double src, double compl, int res, double max_range, unsigned delay )
   {
   char buf[64];
   char *res_str = "";
   int turn_on = 0;
   int e, range;
   double s, c;

   if( bias->mode != mode )
      {
      /* biasing mode has changed */

      if( !bias->mode )
         /* supply is off, need to turn it on */
         turn_on = 1;
      else if( !mode )
         /* supply is on, need to shut it off */
         return bias_off( bias );
      else
         {
         /* need to switch supply modes (voltage->current or current->voltage)
            shut off the supply first  */
         e = bias_off( bias );
         if( e )
            return e;
         turn_on = 1;
         }
      }

   if( !mode )
      return 0;

   if( bias->resolution != res || turn_on )
      {
      switch (res)
         {
         case LOW_RES:
            res_str = "AV1,0";
            break;
         case MEDIUM_RES:
            res_str = "AV4,0";
            break;
         default:
         case HIGH_RES:
            res_str = "AV-2";
            break;
         }
      }

   range = get_range( bias->type, mode, max_range );
   s = get_source( bias->type, mode, src );
   c = get_compliance( bias->type, mode, src, compl );

   if (delay > 5000)  /* don't allow a delay of g.t. 5 seconds */
      delay = 5000;

   bias->mode = mode;
   bias->source = s;
   bias->compliance = c;
   bias->resolution = res;
   ((TIMING_INFO*)bias->udata)->delay = delay;

   if( turn_on )
      {
      switch( mode )
         {
         case SRC_VOLTAGE:
            sprintf( buf, "CN%d;DV%d,%d,%.4e,%.4e;*OPC?\r\n", bias->chan, bias->chan, range, s, c );
            break;

         case SRC_CURRENT:
            sprintf( buf, "CN%d;DI%d,%d,%.4e,%.4e;*OPC?\r\n", bias->chan, bias->chan, range, s, c );
            break;
         }
      }
   else
      {
      switch( mode )
         {
         case SRC_VOLTAGE:
            sprintf( buf, "DV%d,%d,%.4e,%.4e;*OPC?\r\n", bias->chan, range, s, c );
            break;

         case SRC_CURRENT:
            sprintf( buf, "DI%d,%d,%.4e,%.4e;*OPC?\r\n", bias->chan, range, s, c );
            break;
         }
      }

   e = gpib_write( bias->ud, buf );
   if( e )
      return e;
   e = gpib_read( bias->ud, buf, 64 );
   if( e ) {
      gpib_write( bias->ud, "ERR?\r\n" );
      gpib_read( bias->ud, buf, 200 );
      return e;
   }
   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int bias_off( instr_bias_t *bias )
   {
   char buf[64];
   int e;

   sprintf( buf, "CL%d;DZ%d;*OPC?\r\n", bias->chan, bias->chan );
   e = gpib_write( bias->ud, buf );
   if( e )
      return e;
   e = gpib_read( bias->ud, buf, 64 );
   if( e )
      return e;

   bias->mode = 0;
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int trigger( instr_bias_t *bias )
   {
   if( !bias->mode )
      return 0;

   gettimeofday( &(((TIMING_INFO*)bias->udata)->trig_time), NULL );
   bias->triggered = 1;
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_bias( instr_bias_t *bias, double *src, double *meas )
   {
   char buf[100];
   char stat = 0;
   struct timeval tcurrent;
   long elapsed_ms = 0;
   TIMING_INFO *inf = (TIMING_INFO*) bias->udata;
   int e;

   if( !bias->mode )
      {
      if (src)
         *src = 0.0;
      if (meas)
         *meas = 0.0;
      return 0;
      }
   else if( !bias->triggered )
      {
      e = trigger( bias );
      if( e )
         return e;
      }

   /* reset the trigger flag */
   bias->triggered = 0;

   if( meas )
      {
      /* wait for the measurement delay to expire */
      while( elapsed_ms < (long) inf->delay )
         {
         gettimeofday( &tcurrent, NULL );
         elapsed_ms = (tcurrent.tv_sec - inf->trig_time.tv_sec)*1000 + (tcurrent.tv_usec - inf->trig_time.tv_usec)/1000;
         }

      /* ask the instrument to take the measurement */
      sprintf( buf, "FMT1;MM1,%d;XE\r\n", bias->chan );
      e = gpib_write( bias->ud, buf );
      if( e )
         return e;
      e = gpib_read( bias->ud, buf, 100 );
      if( e ) {
         gpib_write( bias->ud, "ERR?\r\n" );
         gpib_read( bias->ud, buf, 200 );
         return e;
      }

      sscanf( buf, "%c%*c%*c%lf", &stat, meas );
      }

   if( src )
      *src = bias->source;

   if (stat == 'C')
      return 1;
      
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static double get_source( int type, int mode, double src )
   {
   double max_s = 1.0e6;

   if( mode == SRC_VOLTAGE )
      {
      /* for different models */
      switch( type )
         {
         case HP41420A:
            max_s = 200.0;
            break;
         case HP41421B:
            max_s = 100.0;
            break;
         case HP41422A:
            max_s = 10.0;
            break;
         case HP41423A:
            max_s = 1000.0;
            break;
         default:
            max_s = 0.0;
            break;     
         }
      }
   else if( mode == SRC_CURRENT )
      {
      switch( type )
         {
         case HP41420A:
            max_s = 1.0;
            break;
         case HP41421B:
            max_s = 0.1;
            break;
         case HP41422A:
            max_s = 10.0;
            break;
         case HP41423A:
            max_s = 0.01;
            break;
         default:
            max_s = 0.0;
            break;     
         }
      }

   if( fabs( src ) > max_s )
      {
      if( src < 0.0 )
         return -max_s;
      return max_s;
      }
   return src;
   }

/******************************************************************************************/
/******************************************************************************************/

static double get_compliance( int type, int mode, double src, double compl )
   {
   double max_compl;

   src = fabs( src );

   if (mode == SRC_VOLTAGE)
      {
      if (src > 100.0)
         max_compl = 0.05;
      else if (src > 40.0)
         max_compl = 0.125;
      else if (src > 20.0)
         max_compl = 0.35;
      else if (src > 14.0)
         max_compl = 0.7;
      else
         max_compl = 1.0;
      }
   else
      {
      if (src > 0.7)
         max_compl = 14.0;
      else if (src > 0.35)
         max_compl = 20.0;
      else if (src > 0.125)
         max_compl = 40.0;
      else if (src > 0.05)
         max_compl = 100.0;
      else
         max_compl = 200.0;
      }

   if( fabs( compl ) < max_compl )
      return compl;
   else
      {
      if( compl < 0.0 )
         return -max_compl;
      return max_compl;
      }
   }

/******************************************************************************************/
/******************************************************************************************/

static int get_range( int type, int mode, double src )
   {
   int range = 0;

   if( src == AUTO_RANGE )
      return 0;

   src = fabs (src);

   if (mode == SRC_VOLTAGE)
      {
      if (src > 500.0)
         range = 17;
      else if (src > 200.0)
         range = 16;
      else if (src > 100.0)
         range = 15;
      else if (src > 40.0)
         range = 14;
      else if (src > 20.0)
         range = 13;
      else if (src > 2.0)
         range = 12;
      else
         range = 11;
      }
   else if (mode == SRC_CURRENT)
      {
      if (src > 1.0)
         range = 21;
      else if (src > 0.1)
         range = 20;
      else if (src > 1.0e-2)
         range = 19;
      else if (src > 1.0e-3)
         range = 18;
      else if (src > 1.0e-4)
         range = 17;
      else if (src > 1.0e-5)
         range = 16;
      else if (src > 1.0e-6)
         range = 15;
      else if (src > 1.0e-7)
         range = 14;
      else if (src > 1.0e-8)
         range = 13;
      else if (src > 1.0e-9)
         range = 12;
      else
         range = 11;
      }

   return range;
   }

