#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <instr/instr.h>

/* supported keithley SMU types */
enum {
   K236,
   K237,
   K238
   };

static int init_bias( instr_bias_t *b );
static int close_bias( instr_bias_t *b );
static int set_bias( instr_bias_t *b, int mode, double src, double compl, int res, double max_range, unsigned delay );
static int read_bias( instr_bias_t *b, double *src, double *meas );
static int turn_off_bias( instr_bias_t *b );
static int trigger( instr_bias_t *b );

static double get_source (int type, int mode, double src);
static double get_compliance (int type, int mode, double src, double compl);
static int get_range (int type, int mode, double val);

/*********************************************************************************/
/*********************************************************************************/
/* this is the only exported routine */

extern int instr_load( gpib_instr_t inst )
   {
   instr_bias_t* bias;

   if( gpib_instr_gettype( inst ) != INSTR_BIAS )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   bias = (instr_bias_t*) inst;

   /* initialize the driver methods */
   bias->open = init_bias;
   bias->close = close_bias;
   bias->set_bias = set_bias;
   bias->read_bias = read_bias;
   bias->trigger = trigger;
   bias->bias_off = turn_off_bias;

   /* set the library version and text fields */
   bias->libver = "1.0.0";
   bias->libtext = "Driver for the Keithley 236A, 237A, and 238A SMUs.";
   bias->libdate = __DATE__;

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int init_bias( instr_bias_t *bias )
   {
   static char *query = "J0XU0X";
   char buffer[100];
   int e;

   /* create the device descriptor */
   e = gpib_getud( &bias->ud, bias->bidx, bias->addr, bias->tmo, 1, 0 );
   if( e )
      return e;

   /* clear the instrument */
   e = gpib_clear( bias->ud );
   ms_delay(5);
   if( e )
      return e;

   /* initialize and query the instrument */
   e = gpib_write( bias->ud, query );
   ms_delay(5);
   if( e )
      return e;

   /* check the instrument ID string */
   e = gpib_read( bias->ud, buffer, 100 );
   ms_delay(5);
   if( e )
      return e;

   if( strstr(buffer, "238") )
      bias->type = K238;
   else if( strstr(buffer, "237") )
      bias->type = K237;
   else if( strstr(buffer, "236") )
      bias->type = K236;
   else
      {
      bias->type = -1;
      gpib_seterror( bias->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
      }

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int close_bias( instr_bias_t *bias )
   {
   if( bias->mode )
      {
      /* bias is on, need to shut off */
      turn_off_bias( bias );
      }

   /* take the device offline */
   gpib_golocal( bias->ud );
   gpib_freeud( bias->ud );
   bias->ud = -1;

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int set_bias( instr_bias_t *bias, int mode, double src, double compl, int res, double max_range, unsigned delay )
   {
   char buffer[100];
   double s, c;
   char *res_str = "";
   int turn_on = 0;
   int range = 0;
   int crange = 0;
   int m = 0;
   int e;

   if( bias->mode != mode )
      {
      /* biasing mode has changed */

      if( !bias->mode )
         /* supply is off, need to turn it on */
         turn_on = 1;
      else if( !mode )
         /* supply is on, need to shut it off */
         return turn_off_bias( bias );
      else
         {
         /* need to switch supply modes (voltage->current or current->voltage)
             shut off the supply first */
         e = turn_off_bias( bias );
         if( e )
            return e;
         turn_on = 1;
         }
      }

   /* bias mode is off */
   if( !mode )
      return 0;

   /* set the resolution string */
   if( bias->resolution != res || turn_on )
      {
      switch (res)
         {
         case LOW_RES:
            res_str = "P2S0";
            break;
         case MEDIUM_RES:
            res_str = "P3S1";
            break;
         default:
         case HIGH_RES:
            res_str = "P5S2";
            break;
         }
      }


   s = get_source( bias->type, mode, src );
   c = get_compliance( bias->type, mode, src, compl );

   range = get_range( bias->type, mode, s );

   /* don't allow a delay of g.t. 5 seconds */
   if( delay > 5000 )
      delay = 5000;

   if( mode == SRC_CURRENT ) {
      crange = get_range( bias->type, SRC_VOLTAGE, c );
      m = 1;
   }
   else if( mode == SRC_VOLTAGE ) {
      crange = get_range( bias->type, SRC_CURRENT, c );
   }

   /* store new values of instrument parameters */
   bias->mode = mode;
   bias->source = s;
   bias->compliance = c;
   bias->resolution = res;
   bias->triggered = 0;

   if( turn_on )
      {
      /* initialize the triggers, data output format, sensing, and source type */
      sprintf (buffer, "G5,0,0R0XT4,2,0,0F%d,0O1R1XH0X", m);
      e = gpib_write(bias->ud, buffer);
      ms_delay(5);
      if( e )
         return e;
      }

   /* set the resolution (if necessary), source, compliance, range and dc delay
       also, place the SMU in operate mode if it is in standby */
   sprintf( buffer, "%sL%.4e,%dB%.4e,%d,%d%s", res_str, c, crange, s, range, delay, turn_on ? "N1H0X" : "H0X" );
   e = gpib_write(bias->ud, buffer);
   ms_delay(5);
   if( e )
      return e;

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int trigger( instr_bias_t *bias )
   {
   static char *trig = "H0X";
   char stb;
   int e;

   if( !bias->mode )
      return 0;

   /* wait for a "ready for trigger" condition */
   do {
      e = gpib_spoll( bias->ud, &stb );
      ms_delay(5);
      if( e )
         return e;
      else if( stb & 32 )
         {
         gpib_seterror( bias->name, "Keithley-reported error condition." );
         return EGPIB_INSTRERROR;
         }
      }
   while( !(stb & 16) );

   e = gpib_write(bias->ud, trig);
   ms_delay (5);
   if( e )
      return e;

   bias->triggered = 1;
   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int read_bias( instr_bias_t *bias, double *src, double *meas )
   {
   char buffer[100];
   char stat;
   double t1, t2;
   int e;

   if( !bias->mode )
      {
      if(src)
         *src = 0.0;
      if(meas)
         *meas = 0.0;
      return 0;
      }
   else if( !bias->triggered )
      {
      /* need to trigger the smu */
      e = trigger( bias );
      if( e )
         return e;
      }

   /* reset the trigger flag */
   bias->triggered = 0;

   e = gpib_read( bias->ud, buffer, 100 );
   ms_delay (5);
   if( e )
      return e;

   sscanf( buffer, "%c%*c%*c%*c%*c%lf,%*c%*c%*c%*c%*c%lf", &stat, &t1, &t2 );

   if(src)
      *src = t1;
   if(meas)
      *meas = t2;

   /* return a positive number (errors are negative) to indicate that the SMU is
       currently in compliance */
   if( stat == 'O' )
      return 1;

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/

static int turn_off_bias( instr_bias_t *bias )
   {
   static char *turn_off = "R0XT4,0,0,0R1XB0,0,0N0H0X";
   int e;

   if( !bias->mode )
      return 0;

   bias->mode = SRC_OFF;
   e = gpib_write( bias->ud, turn_off );
   ms_delay(5);
   if( e )
      return e;

   return 0;
   }

/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/

static double get_source (int type, int mode, double src)
   {
   double s1 = fabs (src);
   double max_s;
   
   if (type == K238)
      {
      if (mode == SRC_VOLTAGE)
         max_s = 110.0;
      else
         max_s = 1.0;
      }
   else if (type == K237)
      {
      if (mode == SRC_VOLTAGE)
         max_s = 1100.0;
      else
         max_s = 0.1;
      }
   else  // 236
      {
      if (mode == SRC_VOLTAGE)
         max_s = 110.0;
      else
         max_s = 0.1;
      }

   if (s1 > max_s)
      {
      if (src < 0.0)
         return -max_s;
      else
         return max_s;
      }

   return src;
   }

/******************************************************************************************/
/******************************************************************************************/

static double get_compliance (int type, int mode, double src, double compl)
   {
   double max_c;

   src = fabs (src);
   compl = fabs (compl);
   
   if (type == K238)
      {
      if (mode == SRC_VOLTAGE)
         {
         if (src > 15.0)
            max_c = 0.1;
         else
            max_c = 1.0;
         }
      else
         {
         if (src > 0.1)
            max_c = 15.0;
         else
            max_c = 110.0;
         }
      }
   else if (type == K237)
      {
      if (mode == SRC_VOLTAGE)
         max_c = 0.1;
      else
         max_c = 1100.0;
      }
   else  // 236
      {
      if (mode == SRC_VOLTAGE)
         max_c = 0.1;
      else
         max_c = 110.0;
      }

   if (compl <  max_c)
      return compl;

   return max_c;
   }

/******************************************************************************************/
/******************************************************************************************/

static int get_range (int type, int mode, double val)
   {
   int range = 0;

   val = fabs (val);

   if (mode == SRC_VOLTAGE)
      {
      if (type == K238)
         {
         if (val > 15.0)
            range = 3;
         else if (val > 1.5)
            range = 2;
         else
            range = 1;
         }
      else  // 236 and 237
         {
         if ((val > 110.0) && (type == K237))
            range = 4;
         else if (val > 11.0)
            range = 3;
         else if (val > 1.1)
            range = 2;
         else
            range = 1;
         }
      }
   else if (mode == SRC_CURRENT)
      {
      if ((val > 0.1) && (type == K238))
         range = 10;
      else if (val > 1.0e-2)
         range = 9;
      else if (val > 1.0e-3)
         range = 8;
      else if (val > 1.0e-4)
         range = 7;
      else if (val > 1.0e-5)
         range = 6;
      else if (val > 1.0e-6)
         range = 5;
      else if (val > 1.0e-7)
         range = 4;
      else if (val > 1.0e-8)
         range = 3;
      else if (val > 1.0e-9)
         range = 2;
      else
         range = 1;
      }

   return range;
   }

