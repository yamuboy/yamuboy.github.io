#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_nfm( instr_nfm_t *nfm );
static int close_nfm( instr_nfm_t *nfm );
static int read_noise_sweep( instr_nfm_t *nfm, double *freq, double *nf, double *gain, unsigned sz, unsigned *num );
static int load_enr_table( instr_nfm_t *nfm, double *freq, double *enr, unsigned npts );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_nfm_t* nm;

   if( gpib_instr_gettype( inst ) != INSTR_NFM )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   nm = (instr_nfm_t*) inst;

   /* initialize the driver methods */
   nm->open = open_nfm;
   nm->close = close_nfm;
   nm->read_noise_sweep = read_noise_sweep;
   nm->load_enr = load_enr_table;

   /* set the library version and text fields */
   nm->libver = "1.0.0";
   nm->libtext = "Driver for the HP 8970B noise figure meter.";

   return 0;
   }


/******************************************************************************************/
/******************************************************************************************/

static int open_nfm( instr_nfm_t *nm )
   {
   int e;

   /* create the device descriptor */
   e = gpib_getud( &nm->ud, nm->bidx, nm->addr, nm->tmo, 1, 0 );
   if( e )
      return e;

   /* the 8970 is so old that it does not produce an identification string,
        also, issuing a device clear command will preset the instrument
        which is usually not desireable
    */

   /* set the display to insertion gain and noise figure */
   e = gpib_write( nm->ud, "H1" );
   if( e )
      return e;
   
   /* set the meter to measure corrected NF and gain */
   e = gpib_write( nm->ud, "M2" );
   if( e )
      return e;

   /* disable SRQ */
   e = gpib_write( nm->ud, "Q0" );
   if( e )
      return e;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int close_nfm( instr_nfm_t *nfm )
   {
   ms_delay (100);
   gpib_golocal( nfm->ud );
   gpib_freeud( nfm->ud );
   nfm->ud = -1;
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_noise_sweep( instr_nfm_t *nfm, double *freq, double *nf, double *gain, unsigned sz, unsigned *num )
   {
   char st;
   char buf[64];
   double f = 0.0, g, nfig, last;
   int e;

   *num = 0;

   /* set the trigger mode to hold */
   e = gpib_write( nfm->ud, "T1" );
   if( e )
      return e;

   /* enable SRQ on data ready, command error, and instrument error */
   e = gpib_write( nfm->ud, "Q1Q3Q6" );
   if( e )
      return e;

   /* start a single sweep */
   e = gpib_write( nfm->ud, "W2" );
   if( e )
      return e;

   /* trigger the sweep */
   gpib_trig( nfm->ud );

   /* wait a half second */
   ms_delay (500);

   /* start reading in data */
   do {
      last = f;

      if( *num >= sz )
         break;

      /* wait for the status byte to indicate an SRQ */
      while( 1 )
         {
         e = gpib_spoll( nfm->ud, &st );
         if( e )
            return e;

         if( st & 0x40 )
            break;

         ms_delay( 100 );
         }

      /* check the status byte */
      if( st & 0x04 )
         {
         gpib_seterror( nfm->name, "GPIB command error." );
         return EGPIB_INSTRERROR;
         }
      /*
      else if( st & 0x20 )
         {
         gpib_seterror( nfm->name, "Instrument error." );
         return EGPIB_INSTRERROR;
         }
       */

      /* read the measurement */
      e = gpib_read( nfm->ud, buf, 64 );
      if( e )
         return e;
      if( sscanf( buf, "%lf,%lf,%lf", &f, &g, &nfig ) != 3 )
         {
         gpib_seterror( nfm->name, "Read error." );
         return EGPIB_INSTRERROR;
         }

      if( f>last )
         { 
         freq[*num] = f;
         nf[*num] = nfig;
         gain[*num] = g;
         (*num)++;

         gpib_trig( nfm->ud );
         ms_delay( 100 );
         }
      }
   while( f>last );

   ms_delay (100);

   /* disable SRQ */
   e = gpib_write( nfm->ud, "Q0" );
   if( e )
      return e;

   /* set trigger mode to free run */
   e = gpib_write( nfm->ud, "T0" );
   if( e )
      return e;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int load_enr_table( instr_nfm_t *nfm, double *freq, double *enr, unsigned npts )
   {
   char buf[64];
   unsigned i;
   int e;

   /* start the ENR table load procedure */
   e = gpib_write( nfm->ud, "NR" );
   if( e )
      return e;

   /* load the ENR table values */
   for( i=0; i<npts; i++ )
      {
      sprintf( buf, "%.0fEN%.3fEN", freq[i]*1.0e-6, enr[i] );
      e = gpib_write( nfm->ud, buf );
      if( e )
         return e;
      }

   /* finish the ENR table load procedure */
   e = gpib_write( nfm->ud, "FR" );
   if( e )
      return e;

   ms_delay( 100 );
   return 0;
   }

