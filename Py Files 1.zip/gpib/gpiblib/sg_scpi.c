#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_siggen( instr_sg_t *nfm );
static int close_siggen( instr_sg_t *nfm );
static int rf_on( instr_sg_t *sg );
static int rf_off( instr_sg_t *sg );
static int set_power_dbm( instr_sg_t *sg, double dbm );
static int set_frequency( instr_sg_t *sg, double freq );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_sg_t* sg;

   if( gpib_instr_gettype( inst ) != INSTR_SIGGEN )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   sg = (instr_sg_t*) inst;

   /* initialize the driver methods */
   sg->open = open_siggen;
   sg->close = close_siggen;
   sg->set_power = set_power_dbm;
   sg->set_freq = set_frequency;
   sg->turn_on = rf_on;
   sg->turn_off = rf_off;

   /* set the library version and text fields */
   sg->libver = "1.0.0";
   sg->libtext = "Driver for any SCPI-compatible RF signal generator.";

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int open_siggen( instr_sg_t *sg )
   {
   int e;

   /* create the device descriptor */
   e = gpib_getud( &sg->ud, sg->bidx, sg->addr, sg->tmo, 1, 0 );
   if( e )
      return e;

   /* clear the instrument */
   e = gpib_clear( sg->ud );
   if( e )
      return e;

   /* send a reset signal (in case the clear didn't reset the instrument) */
   e = gpib_write( sg->ud, "*RST" );
   if( e )
      return e;

   /* since this driver is a generic SCPI driver, don't bother to check the 
       device identification
    */
   
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int close_siggen( instr_sg_t *sg )
   {
   if( sg->is_on )
      rf_off( sg );

   gpib_golocal( sg->ud );
   gpib_freeud( sg->ud );
   sg->ud = -1;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int rf_on( instr_sg_t *sg )
   {
   int e = gpib_write( sg->ud, ":OUTP:STAT 1" );
   if( e )
      return e;

   sg->is_on = 1;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int rf_off (instr_sg_t *sg)
   {
   int e = gpib_write( sg->ud, ":OUTP:STAT 0" );
   if( e )
      return e;

   sg->is_on = 0;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int set_power_dbm (instr_sg_t *sg, double dbm)
   {
   char buf[100];
   int e;

   sprintf (buf, ":SOUR:POW %.2f DBM", dbm);
   e = gpib_write( sg->ud, buf );
   if( e )
      return e;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int set_frequency (instr_sg_t *sg, double freq)
   {
   char buf[100];
   int e;

   sprintf (buf, ":SOUR:FREQ %.4e HZ", freq);
   e = gpib_write( sg->ud, buf );
   if( e )
      return e;

   return 0;
   }






