#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <instr/instr.h>

static int open_autoprober( instr_ap_t *ap );
static int close_autoprober( instr_ap_t *ap );
static int move_autoprober( instr_ap_t *ap, long x, long y, int move_type );
static int separate( instr_ap_t *ap );

static int ap_wait_done( instr_ap_t *ap );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_ap_t* ap;

   if( gpib_instr_gettype( inst ) != INSTR_AUTOPROBER )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   ap = (instr_ap_t*) inst;

   /* initialize the driver methods */
   ap->open = open_autoprober;
   ap->close = close_autoprober;
   ap->move = move_autoprober;
   ap->separate = separate;

   /* set the library version and text fields */
   ap->libver = "1.0.0";
   ap->libtext = "Driver for the Cascade 10k and 12k probe stations.";

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int open_autoprober( instr_ap_t *ap )
   {
   char buf[200];
   static char *init_state = "$:set:resp off;$:set:err:abor on;$:set:syntax win";
   int e;

   /* create the device descriptor */
   e = gpib_getud( &ap->ud, ap->bidx, ap->addr, ap->tmo, 1, 0 );
   if( e )
      return e;

   /* clear the instrument */
   e = gpib_clear( ap->ud );
   if( e )
      return e;

   /* query the identification string */
   e = gpib_write( ap->ud, "*idn?" );
   if( e )
      return e;
   e = gpib_read( ap->ud, buf, 200 );
   if( e )
      return e;

   if( strstr( buf, "10000" ) )
      ap->type = 1;
   else if( strstr( buf, "Prober" ) )
      /* make a guess b/c the prober software is broken */
      ap->type = 1;
   else if( strstr( buf, "12000" ) )
      ap->type = 2;
   else if( strstr( buf, "<Model #>" ) )
      /* make a guess b/c the prober software is broken */
      ap->type = 2;
   else
      {
      ap->type = -1;
      gpib_seterror( ap->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
      }

   /* set the prober state */
   e = gpib_write( ap->ud, init_state );
   if( e )
      return e;

   /* check for chuck contact position */
   sprintf( buf, ":move:cont? %d", ap->type );
   e = gpib_write( ap->ud, buf );
   if( e )
      return e;
   e = gpib_read( ap->ud, buf, 200 );
   if( e )
      return e;
   if( strncmp( buf, "TRUE", 4 ) )
      {
      sprintf( buf, "Wafer chuck is not in the contact position." );
      gpib_seterror( ap->name, buf );
      return EGPIB_INSTRERROR;
      }

   /* get the starting position */
   sprintf( buf, ":move:abs? %d", ap->type );
   e = gpib_write( ap->ud, buf );
   if( e )
      return e;
   e = gpib_read( ap->ud, buf, 200 );
   if( e )
      return e;

   if( sscanf( buf, "%ld%ld", &ap->x_base, &ap->y_base ) != 2 )
      {
      sprintf( buf, "Unable to read chuck position." );
      gpib_seterror( ap->name, buf );
      return EGPIB_INSTRERROR;
      }

   ap->x_last = ap->x_base;
   ap->y_last = ap->y_base;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int close_autoprober( instr_ap_t *ap )
   {
   gpib_golocal( ap->ud );
   gpib_freeud( ap->ud );
   ap->ud = -1;
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int move_autoprober( instr_ap_t *ap, long x, long y, int move_type )
   {
   long x1, y1;
   char buf[200];
   int e;

   if( ap->type < 1 )
      {
      sprintf( buf, "Invalid type (%d).", ap->type );
      gpib_seterror( ap->name, buf );
      return EGPIB_INSTRERROR;
      }

   switch (move_type)
      {
      case MOVE_ABSOLUTE:
         x1 = x;
         y1 = y;
         break;

      case MOVE_REL_LAST:
         x1 = ap->x_last + x;
         y1 = ap->y_last + y;
         break;

      default:
      case MOVE_REL_BASE:
         x1 = ap->x_base + x;
         y1 = ap->y_base + y;
         break;
      }

   /* clear the status byte */
   e = gpib_write( ap->ud, "*cls" );
   if( e )
      return e;

   /* move the autoprober */
   sprintf( buf, ":move:abs %d %ld %ld UP;*opc", ap->type, x1, y1 );
   e = gpib_write( ap->ud, buf );
   if( e )
      return e;

   /* wait for command completion */
   e = ap_wait_done( ap );
   if( e )
      return e;

   ap->x_last = x1;
   ap->y_last = y1;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int separate( instr_ap_t *ap )
   {
   char buf[200];
   int e;

   if( ap->type < 1 )
      {
      sprintf( buf, "Invalid type (%d).", ap->type );
      gpib_seterror( ap->name, buf );
      return EGPIB_INSTRERROR;
      }

   /* clear the status byte */
   e = gpib_write( ap->ud, "*cls" );
   if( e )
      return e;

   /* send the separate command */
   sprintf( buf, ":move:sep %d;*opc", ap->type );
   e = gpib_write( ap->ud, buf );
   if( e )
      return e;

   /* wait for command completion */
   e = ap_wait_done( ap );
   if( e )
      return e;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int ap_wait_done( instr_ap_t *ap )
   {
   int e;
   char ch;

   while( 1 )
      {
      e = gpib_spoll( ap->ud, &ch );
      if( e )
         return e;

      if( ch & 0x01 )
         {
         gpib_seterror( ap->name, "Autoprober error. Check the error log." );
         return EGPIB_INSTRERROR;
         }
      else if( ch & 0x02 )
         return 0;

      ms_delay( 50 );
      }

   return 0;
   }

