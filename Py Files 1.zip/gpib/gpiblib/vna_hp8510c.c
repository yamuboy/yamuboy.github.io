#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

typedef long BIN32_DATA;

static int open_vna( instr_vna_t *vna );
static int close_vna( instr_vna_t *vna );
static int read_freq_list( instr_vna_t *vna, double *flist, unsigned szList, unsigned *numf );
static int read_s_params (instr_vna_t *vna, instr_complex_t sp[][4], unsigned szSp, unsigned *nums );
static int read_cal_coeffs (instr_vna_t *vna, instr_complex_t c[][12], unsigned szCoeffs, unsigned *numc );

static float convert_bin32( long data, int little );
static int read_block_header( long head, int *little );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_vna_t* vna;

   if( gpib_instr_gettype( inst ) != INSTR_VNA )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   vna = (instr_vna_t*) inst;

   /* initialize the driver methods */
   vna->open = open_vna;
   vna->close = close_vna;
   vna->read_freq_list = read_freq_list;
   vna->read_s_params = read_s_params;
   vna->read_cal_coeffs = read_cal_coeffs;

   /* set the library version and text fields */
   vna->libver = "1.0.0";
   vna->libtext = "Driver for the HP 8510C vector network analyzer.";

   return 0;
   }


/******************************************************************************************/
/******************************************************************************************/

static int open_vna (instr_vna_t *vna )
   {
   int e;
   char buf[100];

   /* create the device descriptor */
   e = gpib_getud( &vna->ud, vna->bidx, vna->addr, vna->tmo, 1, 0 );
   if( e )
      return e;

   /* clear the instrument */
   /* -- VNA doesn't like this for some reason
   e = gpib_clear( vna->ud );
   if( e )
      return e;
   */

   /* initialize the instrument */
   e = gpib_write( vna->ud, "DEBUOFF;BEEPOFF;SRQM 0,0;HOLD;ENTO;" );
   if( e )
      return e;

   /* check the instrument ID string */
   e = gpib_write( vna->ud, "OUTPIDEN;" );
   if( e )
      return e;
   e = gpib_read( vna->ud, buf, 100 );
   if( e )
      return e;

   /* check that the instrument model is valid */
   if( !strstr( buf, "8510C" ) )
      {
      gpib_seterror( vna->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
      }

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int close_vna( instr_vna_t *vna )
   {
   gpib_golocal( vna->ud );
   gpib_freeud( vna->ud );
   vna->ud = -1;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_freq_list( instr_vna_t *vna, double *flist, unsigned szList, unsigned *numf )
   {
   int little;
   int read_length = 4*(szList + 1);
   BIN32_DATA *data;
   unsigned i;
   int e;

   data = (BIN32_DATA *) gpib_malloc( sizeof(BIN32_DATA) * (szList+1) );

   e = gpib_write( vna->ud, "FORM2;OUTPFREL;" );
   if( e )
      {
      free((void*)data);
      return e;
      }
   e = gpib_read( vna->ud, (void*)data, read_length );
   if( e )
      {
      free((void*)data);
      return e;
      }

   *numf = read_block_header( data[0], &little ) / 4;
   if( *numf != (unsigned) (gpib_readcount()-4)/4 )
      {
      free((void*)data);
      gpib_seterror( vna->name, "Block header does not match number of bytes read." );
      return EGPIB_INSTRERROR;
      }

   for( i=0; i<*numf; i++ )
      flist[i] = convert_bin32( data[i+1], little );

   free((void *)data);

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_s_params( instr_vna_t *vna, instr_complex_t sp[][4], unsigned szSp, unsigned *nums )
   {
   char st, *cmd;
   int little;
   int read_length = 8*szSp + 4;
   BIN32_DATA *data;
   unsigned i, j, k;
   int e;

   data = (BIN32_DATA*) gpib_malloc( sizeof(BIN32_DATA) * (2*szSp+1) );
   
   /* clear the status byte and trigger a measurement */
   e = gpib_write( vna->ud, "CLES;WAIT;SING;" );
   if( e )
      {
      free((void*)data);
      return e;
      }

   /* wait for the measurement to complete */
   while( 1 )
      {
      ms_delay( 50 );
      e = gpib_spoll( vna->ud, &st );
      if( e )
         {
         free((void*)data);
         return e;
         }

      if( st & 0x10 )
         break;
      else if( st & 0x20 )
         {
         gpib_seterror( vna->name, "Command syntax error." );
         free((void*)data);
         return EGPIB_INSTRERROR;
         }
      }

   /* read in the data */
   for( k=0; k<4; k++ )
      {
      switch( k )
         {
         default:
         case 0:
            cmd = "S11;WAIT;FORM2;OUTPDATA;";
            break;
         case 1:
            cmd = "S12;WAIT;FORM2;OUTPDATA;";
            break;
         case 2:
            cmd = "S21;WAIT;FORM2;OUTPDATA;";
            break;
         case 3:
            cmd = "S22;WAIT;FORM2;OUTPDATA;";
            break;
         }

      e = gpib_write( vna->ud, cmd );
      if( e )
         {
         free((void*)data);
         return e;
         }
      e = gpib_read( vna->ud, (void*)data, read_length );
      if( e )
         {
         free((void*)data);
         return e;
         }

      if( !k )
         /* determine the length of the [S] parameter vector (only need to do this once) */
         *nums = read_block_header( data[0], &little ) / 8;

      if( *nums != (unsigned) (gpib_readcount()-4)/8 )
         {
         free((void *)data);
         gpib_seterror( vna->name, "Block header does not match number of bytes read." );
         return EGPIB_INSTRERROR;
         }

      for( i=0,j=1; i<*nums; i++,j+=2 )
         {
         /* real part */
         sp[i][k].real = convert_bin32( data[j], little );
         sp[i][k].imag = convert_bin32( data[j+1], little );
         }
      }

   free((void *)data);

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_cal_coeffs( instr_vna_t *vna, instr_complex_t c[][12], unsigned szCoeffs, unsigned *numc )
   {
   char str[4], buf[64];
   int little;
   int read_length = 8*szCoeffs + 4;
   BIN32_DATA *data;
   unsigned i, j, k;
   int e;

   data = (BIN32_DATA*) gpib_malloc( sizeof(BIN32_DATA) * (2*szCoeffs+1) );

   for( k=0; k<12; k++ )
      {
      sprintf( str, "%d", k+101 );
      sprintf( buf, "FORM2;OUTPCALC%c%c;", str[1], str[2]);
      e = gpib_write( vna->ud, buf );
      if( e )
         {
         free((void*)data);
         return e;
         }
      e = gpib_read( vna->ud, (void*)data, read_length );
      if( e )
         {
         free((void*)data);
         return e;
         }

      if( !k )
         /* determine the length of the coefficient parameter vector (only need to do this once) */
         *numc = read_block_header( data[0], &little ) / 8;

      if( *numc != (unsigned) (gpib_readcount()-4)/8 )
         {
         free((void*)data);
         gpib_seterror( vna->name, "Block header does not match number of bytes read." );
         return EGPIB_INSTRERROR;
         }

      for( i=0,j=1; i<*numc; i++,j+=2 )
         {
         /* real part */
         c[i][k].real = convert_bin32( data[j], little );
         c[i][k].imag = convert_bin32( data[j+1], little );
         }
      }

   free((void *)data);

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static float convert_bin32( long data, int little )
   {
   float *f;

   /* convert to little-endian */
   if( little )
      data = ((data&0x000000ff)<<24) | ((data&0x0000ff00)<<8) | ((data&0x00ff0000)>>8) | ((data&0xff000000)>>24);

   f = (float*)&data;
   return *f;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_block_header( long head, int *little )
   {
   unsigned char b0 = (unsigned char) (head&0x000000ff);
   unsigned char b1 = (unsigned char) ((head&0x0000ff00)>>8);
   unsigned char b2 = (unsigned char) ((head&0x00ff0000)>>16);
   unsigned char b3 = (unsigned char) ((head&0xff000000)>>24);

   if( b0 == '#' && b1 == 'A' )
      {
      /* machine stores data in little-endian format */
      *little = 1;
      return ((int) b3) | (((int) b2)<<8);
      }
   else if( b3 == '#' && b2 == 'A' )
      {
      /* machine stores data in big-endian format */
      *little = 0;
      return ((int) b0) | (((int) b1)<<8);
      }
   
   /* invalid block header */
   return 0;
   }


