#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <instr/instr.h>

/* supported models */
enum {
   HP6622A,
   HP6625A,
   HP6626A,
   HP6628A,
   HP6629A
};

typedef struct
{
   struct timeval trig_time;
   unsigned delay;
} TIMING_INFO;

static int init_bias( instr_bias_t *bias );
static int close( instr_bias_t *bias );
static int set_bias( instr_bias_t *b, int mode, double src, double compl, int res, double max_range, unsigned delay );
static int read_bias( instr_bias_t *b, double *src, double *meas );
static int turn_off_bias( instr_bias_t *b );
static int trigger( instr_bias_t *b );

static void get_source_and_compl( int type, int chan, int mode, double src, double compl, double *s, double *c );

static char *lib_version = "1.0.0";
static char *lib_text = "Driver for the HP 6625A, 6626A, 6628A, and 6629A DC supplies.\n \
                        Because these supplies cannot generate negative voltages,\nabsolute values are used to set the voltage and current.";

/*********************************************************************************/
/*********************************************************************************/
/* this is the only exported routine */

extern int instr_load( gpib_instr_t inst )
{
   instr_bias_t* bias;

   if( gpib_instr_gettype( inst ) != INSTR_BIAS )
   {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
   }

   bias = (instr_bias_t*) inst;

   /* initialize the driver methods */
   bias->open = init_bias;
   bias->close = close;
   bias->set_bias = set_bias;
   bias->read_bias = read_bias;
   bias->trigger = trigger;
   bias->bias_off = turn_off_bias;

   /* set the library version and text fields */
   bias->libver = lib_version;
   bias->libtext = lib_text;

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int init_bias( instr_bias_t *bias )
{
   static char *query = "CLR;ID?";
   char buf[100];
   int e, nchans;
   TIMING_INFO *inf;

   /* create the device descriptor */
   e = gpib_getud( &bias->ud, bias->bidx, bias->addr, bias->tmo, 1, 0 );
   if( e )
      return e;

   /* initialize the timing info structure */
   inf = (TIMING_INFO*) gpib_malloc( sizeof(TIMING_INFO) );
   inf->delay = 0;
   bias->udata = (void*) inf;

   /* initialize the driver methods */
   bias->set_bias = set_bias;
   bias->read_bias = read_bias;
   bias->trigger = trigger;
   bias->bias_off = turn_off_bias;
   bias->close = close;

   /* clear the instrument */
   e = gpib_clear( bias->ud );
   if( e )
      return e;

   /* initialize and query the instrument */
   e = gpib_write( bias->ud, query );
   if( e )
      return e;

   /* check the instrument ID string */
   e = gpib_read( bias->ud, buf, 100 );
   if( e )
      return e;

   /* check that the instrument model is valid, and that the channel number
   is valid for the queried instrument */
   if( strstr( buf, "6622A" ) )
   {
      bias->type = HP6622A;
      nchans = 2;
   }
   else if( strstr( buf, "6625A" ) )
   {
      bias->type = HP6625A;
      nchans = 2;
   }
   else if( strstr( buf, "6626A" ) )
   {
      bias->type = HP6626A;
      nchans = 4;
   }
   else if( strstr( buf, "6628A" ) )
   {
      bias->type = HP6628A;
      nchans = 2;
   }
   else if( strstr( buf, "6629A" ) )
   {
      bias->type = HP6629A;
      nchans = 4;
   }
   else
   {
      bias->type = -1;
      gpib_seterror( bias->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
   }

   /* check for a valid channel # */
   if( bias->chan < 1 || bias->chan > nchans )
   {
      sprintf( buf, "Channel %d is not valid for this instrument.", bias->chan );
      gpib_seterror( bias->name, buf );
      return EGPIB_INSTRERROR;
   }

   /* make sure the output is OFF and disable overcurrent protection */
   sprintf( buf, "OUT%d,0;OCP%d,0", bias->chan, bias->chan );
   e = gpib_write( bias->ud, buf );
   if( e )
      return e;

   /* set the display */
   sprintf( buf, "METER%d", bias->chan );
   e = gpib_write( bias->ud, buf );
   if( e )
      return e;

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int close( instr_bias_t *bias )
{
   if( bias->mode )
      /* need to shut off */
      turn_off_bias( bias );

   /* take the device descriptor offline */
   gpib_golocal( bias->ud );
   gpib_freeud( bias->ud );
   bias->ud = -1;

   /* free the timing info structure */
   if( bias->udata )
      free((void*)bias->udata);
   bias->udata = NULL;

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/
// note that the res and max_range parameters are ignored for this driver

static int set_bias( instr_bias_t *bias, int mode, double src, double compl, int res, double max_range, unsigned delay )
{
   char buf[100];
   int turn_on = 0;
   double s, c;
   int e;

   if( bias->mode != mode )
   {
      /* biasing mode has changed */

      if( !bias->mode )
         /* supply is off, need to turn it on */
         turn_on = 1;
      else if( !mode )
         /* supply is on, need to shut it off */
         return turn_off_bias( bias );
   }

   /* bias mode is off */
   if( !mode )
      return 0;

   /* get the corrected values for source and compliance (supply dependent) */
   get_source_and_compl( bias->type, bias->chan, mode, src, compl, &s, &c );

   /* store new values of instrument parameters */
   bias->mode = mode;
   bias->source = s;
   bias->compliance = c;
   bias->resolution = res;
   bias->triggered = 0;
   ((TIMING_INFO*)bias->udata)->delay = delay;

   /* set the source and compliance parameters */
   if( mode == SRC_CURRENT )
   {
      sprintf( buf, "ISET%d,%.4f;VSET%d,%.4f", bias->chan, s, bias->chan, c );
      e = gpib_write( bias->ud, buf );
      if( e )
         return e;
   }
   else /* SRC_VOLTAGE */
   {
      sprintf( buf, "VSET%d,%.4f;ISET%d,%.4f", bias->chan, s, bias->chan, c );
      e = gpib_write( bias->ud, buf );
      if( e )
         return e;
   }

   /* place the SMU in operate mode if it is in standby */
   if( turn_on )
   {
      sprintf( buf, "OUT%d,1", bias->chan );
      e = gpib_write( bias->ud, buf );
      if( e )
         return e;
   }

   /* source settling */
   ms_delay( 200 );

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int trigger( instr_bias_t *bias )
{
   if( !bias->mode )
      return 0;

   gettimeofday( &(((TIMING_INFO*)bias->udata)->trig_time), NULL );
   bias->triggered = 1;

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int read_bias( instr_bias_t *bias, double *src, double *meas )
{
   char buf[100];
   struct timeval tcurrent;
   long elapsed_ms = 0;
   TIMING_INFO *inf = (TIMING_INFO*) bias->udata;
   int e;
   int c = 0;

   if( !bias->mode )
   {
      if (src)
         *src = 0.0;
      if (meas)
         *meas = 0.0;
      return 0;
   }
   else if( !bias->triggered )
   {
      e = trigger( bias );
      if( e )
         return e;
   }

   /* wait for the measurement delay to expire */
   while( elapsed_ms < (long) inf->delay )
   {
      gettimeofday( &tcurrent, NULL );
      elapsed_ms = (tcurrent.tv_sec - inf->trig_time.tv_sec)*1000 + (tcurrent.tv_usec - inf->trig_time.tv_usec)/1000;
   }

   /* reset the trigger flag */
   bias->triggered = 0;

   /* read the output voltage */
   if( (bias->mode == SRC_VOLTAGE && src) || (bias->mode == SRC_CURRENT && meas) )
   {
      sprintf( buf, "VOUT?%d", bias->chan );
      e = gpib_write( bias->ud, buf );
      if( e )
         return e;
      e = gpib_read( bias->ud, buf, 100 );
      if( e )
         return e;

      if( bias->mode == SRC_VOLTAGE )
      {
         *src = atof( buf );
         if( fabs( *src - bias->source ) > 0.1 )
            c++;
      }
      else
      {
         *meas = atof( buf );
         if( fabs( *meas - bias->compliance ) < 0.002 )
            c++;
      }
   }

   /* read the output current */
   if( (bias->mode == SRC_CURRENT && src) || (bias->mode == SRC_VOLTAGE && meas) )
   {
      sprintf( buf, "IOUT?%d", bias->chan );
      e = gpib_write( bias->ud, buf );
      if( e )
         return e;
      e = gpib_read( bias->ud, buf, 100 );
      if( e )
         return e;

      if( bias->mode == SRC_CURRENT )
      {
         *src = atof( buf );
         if( fabs( *src - bias->source ) > 0.002 )
            c++;
      }
      else
      {
         *meas = atof( buf );
         if( fabs( *meas - bias->compliance ) < 0.05 )
            c++;
      }
   }

   return c;
}

/*********************************************************************************/
/*********************************************************************************/

static int turn_off_bias( instr_bias_t *bias )
{
   char buf[32];

   if( !bias->mode )
      return 0;

   bias->mode = SRC_OFF;
   sprintf( buf, "OUT%d,0", bias->chan );
   return gpib_write( bias->ud, buf );
}

/*********************************************************************************/
/*********************************************************************************/

static void get_source_and_compl( int type, int chan, int mode, double src, double compl, double *s, double *c )
{
   double maxc = 0.;

   *s = *c = 0.0;
   src = fabs( src );
   compl = fabs( compl );

   if( mode == SRC_VOLTAGE )
   {
      if( type == HP6622A )
      {
         if( src > 40. )
            *s = 40.;
         else
            *s = src;

         if( src > 20. )
            maxc = 2.;
         else
            maxc = 4.;
      }
      else
      {
         if( src > 50. )
            *s = 50.;
         else
            *s = src;

         switch( type )
         {
         case HP6625A:
            if( chan == 1 )
               maxc = 0.5;
            else
               maxc = 2.;
            break;

         case HP6626A:
            if( chan == 1 || chan == 2 )
               maxc = 0.5;
            else
               maxc = 2.;
            break;

         case HP6628A:
         case HP6629A:
            maxc = 2.;
            break;
         }
      }
   }
   else if( mode == SRC_CURRENT )
   {
      if( type == HP6622A )
      {
         if( src > 4. )
            *s = 4.;
         else
            *s = src;

         if( src > 2. )
            maxc = 20.;
         else
            maxc = 40.;
      }
      else
      {
         maxc = 50.;

         switch( type )
         {
         case HP6625A:
            if( chan == 1 )
            {
               if( src > 0.5 )
                  *s = 0.5;
               else
                  *s = src;
            }
            else
            {
               if( src > 2. )
                  *s = 2.;
               else
                  *s = src;
            }
            break;

         case HP6626A:
            if( chan == 1 || chan == 2 )
            {
               if( src > 0.5 )
                  *s = 0.5;
               else
                  *s = src;
            }
            else
            {
               if( src > 2. )
                  *s = 2.;
               else
                  *s = src;
            }
            break;

         case HP6628A:
         case HP6629A:
            if( src > 2. )
               *s = 2.;
            else
               *s = src;
            break;
         }
      }   
   }

   if( compl > maxc )
      *c = maxc;
   else
      *c = compl;
}
