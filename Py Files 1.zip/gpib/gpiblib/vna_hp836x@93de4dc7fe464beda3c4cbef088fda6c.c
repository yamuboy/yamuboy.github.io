#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_vna( instr_vna_t *vna );
static int close_vna( instr_vna_t *vna );
static int read_freq_list( instr_vna_t *vna, double *flist, unsigned szList, unsigned *numf );
static int read_s_params (instr_vna_t *vna, instr_complex_t sp[][4], unsigned szSp, unsigned *nums );
static int read_cal_coeffs (instr_vna_t *vna, instr_complex_t c[][12], unsigned szCoeffs, unsigned *numc );

static int convert_real32_block( const void* block, int szblock, double* data, int szdata, int* converted );

struct agilent_pna_t
{
   double *flist;
   double *sp;
   void *bbuf;
   int sz_flist;
   int sz_bbuf;
};


/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
{
   instr_vna_t* vna;

   if( gpib_instr_gettype( inst ) != INSTR_VNA )
   {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
   }

   vna = (instr_vna_t*) inst;

   /* initialize the driver methods */
   vna->open = open_vna;
   vna->close = close_vna;
   vna->read_freq_list = read_freq_list;
   vna->read_s_params = read_s_params;
   vna->read_cal_coeffs = read_cal_coeffs;

   /* set the library version and text fields */
   vna->libver = "1.0.0";
   vna->libtext = "Driver for the Agilent PNA-series 836X vector network analyzers.";

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int allocate_local_memory( instr_vna_t *vna, int sz )
{
   if( !vna->udata ) {
      struct agilent_pna_t* pna = malloc( sizeof(struct agilent_pna_t) );
      pna->flist = 0;
      pna->bbuf = 0;
      pna->sp = 0;
      pna->sz_flist = 0;
      pna->sz_bbuf = 0;
      vna->udata = (void*)pna;
   }

   if( sz > 0 ) {
      struct agilent_pna_t* pna = (struct agilent_pna_t*) vna->udata;
      if( pna->flist ) {
         // memory already allocated
         if( pna->sz_flist >= sz ) {
            // allocated space is adequate
            return 0;
         }
         else {
            // allocated space is too small, free existing memory
            if( pna->flist ) free((void*) pna->flist);
            if( pna->bbuf ) free(pna->bbuf);
            if( pna->sp ) free((void*) pna->sp);
            pna->flist = 0;
            pna->bbuf = 0;
            pna->sp = 0;
            pna->sz_flist = 0;
            pna->sz_bbuf = 0;
         }
      }

      // allocate memory for the frequency list, sp buffer, and binary buffer
      pna->sz_flist = sz;
      pna->sz_bbuf = 4 * sz * 2 + 16;
      pna->flist = malloc( sizeof(double) * sz );
      pna->sp = malloc( sizeof(double) * sz * 2 );
      pna->bbuf =  malloc( pna->sz_bbuf );
      if( !pna->flist || !pna->sp || !pna->bbuf ) {
         gpib_seterror( vna->name, "Memory allocation failure. System resources depleted?" );
         return EGPIB_INSTRERROR;
      }
   }
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static void free_local_memory( instr_vna_t *vna )
{
   struct agilent_pna_t* pna = (struct agilent_pna_t*) vna->udata;
   if( pna ) {
      if( pna->flist ) free((void*) pna->flist);
      if( pna->bbuf ) free(pna->bbuf);
      if( pna->sp ) free((void*) pna->sp);
      free(vna->udata);
      vna->udata = 0;
   }
}


/******************************************************************************************/
/******************************************************************************************/

static int open_vna (instr_vna_t *vna )
{
   int i, e;
   char buf[256];
   char buf1[256];
   char buf2[1024];
   const char *meas;
   const char bittest[] = { 0, 0, 0x05, 0x37 };
   int swap_order;

   /* create the device descriptor */
   if( (e = gpib_getud( &vna->ud, vna->bidx, vna->addr, vna->tmo, 1, 0 )) )
      return e;

   /* clear the instrument and check the ID string */
   if( (e = gpib_write( vna->ud, "*CLS;*IDN?" )) )
      return e;
   if( (e = gpib_read( vna->ud, buf, 255 )) )
      return e;
   if( !strstr(buf, "Agilent") || !(strstr(buf, "836") || strstr(buf, "N5245A")) ) {
      gpib_seterror( vna->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
   }

   // determine whether the bit order is normal or swapped
   //  this depends on the "endian-ness" of the machine
   //  for x86 machines the result should be
   //  swapped bit order
   memcpy( (void*)&e, (const void*)bittest, 4 );
   swap_order = (e==0x537)?0:1;

   /* initialize the instrument */
   // set:
   //   - no service request generation
   //   - global triggers
   //   - immediate triggering
   //   - binary 32-bit blocks for data transfer
   //   - correct bit order for transfer
   //   - set the channel mode to HOLD
   if( vna->chan < 1 )
      vna->chan=1;
   sprintf( buf, "*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:FORM:DATA REAL,32;BORD %s;:INIT:CONT 1", swap_order?"SWAP":"NORM" );
   if( (e = gpib_write( vna->ud, buf )) )
      return e;
   sprintf( buf, "SENS%d:SWE:MODE HOLD", vna->chan );
   if( (e = gpib_write( vna->ud, buf )) )
      return e;

   /* check and initialize the measurements */
   sprintf( buf, "CALC%d:PAR:CAT?", vna->chan );
   if( (e = gpib_write( vna->ud, buf )) )
      return e;
   if( (e = gpib_read( vna->ud, buf2, 1023 )) )
      return e;
   buf2[gpib_readcount()] = '\0';
   for( i=0; i<4; ++i ) {
      switch( i ) {
         default:
         case 0:
            meas = "S11"; break;
         case 1:
            meas = "S12"; break;
         case 2:
            meas = "S21"; break;
         case 3:
            meas = "S22"; break;
      }

      sprintf( buf1, "gpiblibdrv_ch%d_%s", vna->chan, meas );
      if( strstr( buf2, buf1 ) ) {
         // delete the existing definition
         sprintf( buf, "CALC%d:PAR:DEL \'%s\'", vna->chan, buf1 );
         if( (e = gpib_write( vna->ud, buf )) )
            return e;
      }
      sprintf( buf, "CALC%d:PAR:DEF \'%s\',%s", vna->chan, buf1, meas );
      if( (e = gpib_write( vna->ud, buf )) )
         return e;
   }

   /* create data storage */
   if( (e = allocate_local_memory(vna,0)) )
      return e;


   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int close_vna( instr_vna_t *vna )
{
   char str[64];

   // set continuous trigger mode
   sprintf( str, "SENS%d:SWE:MODE CONT", vna->chan );
   gpib_write( vna->ud, str );

   // free local memory
   free_local_memory(vna);
   
   // set gpib mode to local and free handle
   gpib_golocal( vna->ud );
   gpib_freeud( vna->ud );
   vna->ud = -1;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_flist_( instr_vna_t *vna )
{
   char buf[64];
   struct agilent_pna_t* pna;
   int e, n;
   // determine the size of the frequency list
   sprintf( buf, "SENS%d:SWE:POIN?", vna->chan );
   if( (e = gpib_write( vna->ud, buf )) )
      return e;
   if( (e = gpib_read( vna->ud, buf, 255 )) )
      return e;
   buf[gpib_readcount()] = '\0';
   // allocate memory for the frequency list and buffer
   if( (e=allocate_local_memory(vna,atoi(buf))) )
      return e;
   pna = (struct agilent_pna_t*) vna->udata;
   // read the frequency list
   sprintf( buf, "SENS%d:X:VAL?", vna->chan );
   if( (e=gpib_write(vna->ud,buf)) || (e=gpib_read(vna->ud,pna->bbuf,pna->sz_bbuf)) || (e=convert_real32_block(pna->bbuf,gpib_readcount(),pna->flist,pna->sz_flist,&n)) ) {
      return e;
   }
   if( n != pna->sz_flist ) {
      gpib_seterror( vna->name, "In read_flist_(): expected frequency list size is not the same as actual." );
      return EGPIB_INSTRERROR;
   }
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_freq_list( instr_vna_t *vna, double *flist, unsigned szList, unsigned *numf )
{
   struct agilent_pna_t* pna = (struct agilent_pna_t*) vna->udata;
   int i, e;

   // initialize numf to 0
   *numf = 0;

   if( !pna || !pna->flist ) {
      if( (e=read_flist_(vna)) )
         return e;
      pna = (struct agilent_pna_t*) vna->udata;
   }

   // copy the frequency list to the return variable
   if( pna->sz_flist > szList ) {
      gpib_seterror( vna->name, "In read_freq_list(): array is not large enough for the frequency list." );
      return EGPIB_INSTRERROR;
   }
   for( i=0; i<pna->sz_flist; ++i ) {
      flist[i] = pna->flist[i];
   }
   *numf = pna->sz_flist;
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_s_params( instr_vna_t *vna, instr_complex_t sp[][4], unsigned szSp, unsigned *nums )
{
   struct agilent_pna_t* pna = (struct agilent_pna_t*) vna->udata;
   char buf[128];
   char *meas;
   int i, j, n, e;
   int avg;

   // initialize nums to 0
   *nums = 0;

   if( !pna || !pna->bbuf ) {
      if( (e=read_flist_(vna)) )
         return e;
      pna = (struct agilent_pna_t*) vna->udata;
   }

   // read averaging state
   sprintf( buf, "SENS%d:AVER:STAT?", vna->chan );
   if( (e = gpib_write( vna->ud, buf )) || (e=gpib_read(vna->ud,buf,127)) )
      return e;
   buf[gpib_readcount()]='\0';
   if( atoi(buf) ) {
      // averaging is turned on
      // read the current averaging number
      sprintf( buf, "SENS%d:AVER:COUN?", vna->chan );
      if( (e = gpib_write( vna->ud, buf )) || (e=gpib_read(vna->ud,buf,127)) )
         return e;
      buf[gpib_readcount()]='\0';
      avg = atoi( buf );
      // restart the averaging
      sprintf( buf, "SENS%d:AVER:CLEAR", vna->chan );
      if( (e = gpib_write( vna->ud, buf )) )
         return e;
   }
   else avg = 1;

   //  set the group count to be equal to the averaging
   sprintf( buf, "SENS%d:SWE:GRO:COUN %d", vna->chan, avg );
   if( (e = gpib_write( vna->ud, buf )) )
      return e;

   // trigger a measurement group
   sprintf( buf, "SENS%d:SWE:MODE GRO;*ESE 1;*OPC", vna->chan );
   if( (e = gpib_write( vna->ud, buf )) )
      return e;

   // wait for the measurement to complete
   //  this is done by checking the 
   //  Event Status Register for the presence of
   //  the OPC bit
   while( 1 )
   {
      ms_delay( 50 );
      e = gpib_write( vna->ud, "*ESR?" );
      if( e )
         return e;
      e = gpib_read( vna->ud, buf, 127 );
      if( e )
         return e;
      buf[gpib_readcount()] = '\0';

      if( atoi(buf) )
         break;
   }

   // loop through the 4 sparameters and read each
   for( i=0; i<4; ++i ) {
      switch( i ) {
          default:
          case 0:
             meas = "S11"; break;
          case 1:
             meas = "S12"; break;
          case 2:
             meas = "S21"; break;
          case 3:
             meas = "S22"; break;
      }

      // set the parameter, query the data, and convert from REAL,32 block format to a double-precision array
      sprintf( buf, "CALC%d:PAR:SEL \'gpiblibdrv_ch%d_%s\'", vna->chan, vna->chan, meas );
      if( (e = gpib_write( vna->ud, buf )) )
         return e;
      sprintf( buf, "CALC%d:DATA? SDATA", vna->chan );
      if( (e=gpib_write(vna->ud,buf)) || (e=gpib_read(vna->ud,pna->bbuf,pna->sz_bbuf)) || (e=convert_real32_block(pna->bbuf,gpib_readcount(),pna->sp,2*pna->sz_flist,&n)) )
         return e;
      // check that the size of the returned data is correct
      if( n != 2*pna->sz_flist ) {
         gpib_seterror( vna->name, "In read_s_params(): returned array size differs from expected size." );
         return EGPIB_INSTRERROR;
      }
      // check that there is enough space for the data
      if( szSp < n/2 ) {
         char str[128];
         sprintf( str, "In read_s_params(): array is not large enough for the data (%d < %d).", szSp, n/2 );
         gpib_seterror( vna->name, str );
         return EGPIB_INSTRERROR;
      }
      // copy the data into the appropriate locations in the return array
      for( j=0; j<n/2; ++j ) {
         sp[j][i].real = pna->sp[2*j];
         sp[j][i].imag = pna->sp[2*j+1];
      }
   }
   // set the number of points read
   *nums = pna->sz_flist;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_cal_coeffs( instr_vna_t *vna, instr_complex_t c[][12], unsigned szCoeffs, unsigned *numc )
{
   gpib_seterror( vna->name, "In read_cal_coeffs(): not implemented yet." );
   return EGPIB_INSTRERROR;
}

/******************************************************************************************/
/******************************************************************************************/

static int convert_real32_block( const void* block, int szblock, double* data, int szdata, int* converted )
{
   const char* ptr = (const char*)block;
   int szbcount;
   int bcount;
   int i,j;
   float d;
   // check that the block is in "definite block format"
   if( *ptr != '#' ) {
      gpib_seterror( "PNA", "In convert_real32_block(): invalid data transfer format. Expected block format." );
      return EGPIB_INSTRERROR;
   }
   // get the size of the block count
   ++ptr;
   szbcount = *ptr - '0';
   // get the number of bytes in the block
   ++ptr;
   bcount = *ptr - '0';
   for( i=1; i<szbcount; ++i ) {
      ++ptr;
      bcount *= 10;
      bcount += *ptr - '0';
   }
   // check that the reported byte coount is consistent with
   //   the size of the block
   if( bcount > szblock - szbcount - 1 ) {
      gpib_seterror( "PNA", "In convert_real32_block(): byte count is not consistent with block size." );
      return EGPIB_INSTRERROR;
   }
   // check that the reported byte count is a multiple of 4
   if( bcount % 4 ) {
      gpib_seterror( "PNA", "In convert_real32_block(): illegal byte count in block (must be a multiple of 4)." );
      return EGPIB_INSTRERROR;
   }
   // convert the data
   ++ptr;
   *converted = 0;
   for( i=0, j=0; i<bcount; i+=4, ++j, ptr+=4 ) {
      if( j == szdata ) {
         gpib_seterror( "PNA", "In convert_real32_block(): storage array is not large enough to hold the converted block." );
         return EGPIB_INSTRERROR;
      }
      memcpy( (void*)&d, (const void*)ptr, 4 );
      data[j] = d;
      ++(*converted);
   }
   return 0;
}

