#include <stdio.h>
#include <string.h>
#include <instr/instr.h>

/****************************************************************************************/

static int err_check_instr( gpib_instr_t instr, char *funcname, int type )
   {
   if( !instr )
      {
      gpib_seterror( funcname, gpib_stderrmsg( EGPIB_INVALIDARG ) );
      return EGPIB_INVALIDARG;
      }
   else if( gpib_instr_gettype( instr ) != type )
      {
      char msg[200];
      sprintf( msg, "%s: %s", gpib_instr_getname( instr ), gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      gpib_seterror( funcname, msg );
      return EGPIB_WRONGINSTR;
      }
   else if( !IS_INITIALIZED(instr) )
      {
      char msg[200];
      sprintf( msg, "%s: %s", gpib_instr_getname( instr ), gpib_stderrmsg( EGPIB_NOTINITIALIZED ) );
      gpib_seterror( funcname, msg );
      return EGPIB_NOTINITIALIZED;
      }

   return 0;
   }

/****************************************************************************************/
/* ---------                         Bias Supply                              ----------*/
/****************************************************************************************/

extern int gpib_bias_set( gpib_instr_t instr, int mode, double src, double comp, int res, double max_range, unsigned delay )
   {
   instr_bias_t *b = (instr_bias_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_bias_set()", INSTR_BIAS );
   if( e )
      return e;
   else if( !b->set_bias )
      {
      gpib_seterror( "gpib_bias_set()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return b->set_bias( b, mode, src, comp, res, max_range, delay );
   }

/****************************************************************************************/

extern int gpib_bias_trig( gpib_instr_t instr )
   {
   instr_bias_t *b = (instr_bias_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_bias_trig()", INSTR_BIAS );
   if( e )
      return e;
   else if( !b->trigger )
      {
      gpib_seterror( "gpib_bias_trig()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return b->trigger( b );
   }

/****************************************************************************************/

extern int gpib_bias_read( gpib_instr_t instr, double *src, double *meas )
   {
   instr_bias_t *b = (instr_bias_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_bias_read()", INSTR_BIAS );
   if( e )
      return e;
   else if( !b->read_bias )
      {
      gpib_seterror( "gpib_bias_read()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return b->read_bias( b, src, meas );
   }

/****************************************************************************************/

extern int gpib_bias_off( gpib_instr_t instr )
   {
   instr_bias_t *b = (instr_bias_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_bias_off()", INSTR_BIAS );
   if( e )
      return e;
   else if( !b->bias_off )
      {
      gpib_seterror( "gpib_bias_off()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return b->bias_off( b );
   }

/****************************************************************************************/
/* ---------                        Network Analyzer                          ----------*/
/****************************************************************************************/

extern int gpib_vna_readflist( gpib_instr_t instr, double *flist, unsigned sz_flist, unsigned *numf )
   {
   instr_vna_t *v = (instr_vna_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_vna_readflist()", INSTR_VNA );
   if( e )
      return e;
   else if( !v->read_freq_list )
      {
      gpib_seterror( "gpib_vna_readflist()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return v->read_freq_list( v, flist, sz_flist, numf );
   }

/****************************************************************************************/

extern int gpib_vna_readsp( gpib_instr_t instr, instr_complex_t sp[][4], unsigned sz_sp, unsigned *nums )
   {
   instr_vna_t *v = (instr_vna_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_vna_readsp()", INSTR_VNA );
   if( e )
      return e;
   else if( !v->read_s_params )
      {
      gpib_seterror( "gpib_vna_readsp()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return v->read_s_params( v, sp, sz_sp, nums );
   }

/****************************************************************************************/

extern int gpib_vna_readcal( gpib_instr_t instr, instr_complex_t c[][12], unsigned sz_c, unsigned *numc )
   {
   instr_vna_t *v = (instr_vna_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_vna_readcal()", INSTR_VNA );
   if( e )
      return e;
   else if( !v->read_cal_coeffs )
      {
      gpib_seterror( "gpib_vna_readcal()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return v->read_cal_coeffs( v, c, sz_c, numc );
   }

/****************************************************************************************/
/* ---------                          Noise Meter                             ----------*/
/****************************************************************************************/

extern int gpib_nfm_readswp( gpib_instr_t instr, double *freq, double *nf, double *gain, unsigned sz_vec, unsigned *num )
   {
   instr_nfm_t *n = (instr_nfm_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_nfm_readswp()", INSTR_NFM );
   if( e )
      return e;
   else if( !n->read_noise_sweep )
      {
      gpib_seterror( "gpib_nfm_readswp()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return n->read_noise_sweep( n, freq, nf, gain, sz_vec, num );
   }

/****************************************************************************************/

extern int gpib_nfm_loadenr( gpib_instr_t instr, double *freq, double *enr, unsigned npts )
   {
   instr_nfm_t *n = (instr_nfm_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_nfm_loadenr()", INSTR_NFM );
   if( e )
      return e;
   else if( !n->load_enr )
      {
      gpib_seterror( "gpib_nfm_loadenr()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return n->load_enr( n, freq, enr, npts );
   }

/****************************************************************************************/
/* ---------                          Autoprober                              ----------*/
/****************************************************************************************/

extern int gpib_ap_move( gpib_instr_t instr, long x, long y, int mode )
   {
   instr_ap_t *a = (instr_ap_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_ap_move()", INSTR_AUTOPROBER );
   if( e )
      return e;
   else if( !a->move )
      {
      gpib_seterror( "gpib_ap_move()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return a->move( a, x, y, mode );
   }

/****************************************************************************************/

extern int gpib_ap_separate( gpib_instr_t instr )
   {
   instr_ap_t *a = (instr_ap_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_ap_separate()", INSTR_AUTOPROBER );
   if( e )
      return e;
   else if( !a->separate )
      {
      gpib_seterror( "gpib_ap_separate()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return a->separate( a );
   }

/****************************************************************************************/
/* ---------                          Power Meter                             ----------*/
/****************************************************************************************/

extern int gpib_pm_read( gpib_instr_t instr, double freq, int res, double *dbm )
   {
   instr_pm_t *p = (instr_pm_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_pm_read()", INSTR_PWRMETER );
   if( e )
      return e;
   else if( !p->read )
      {
      gpib_seterror( "gpib_pm_read()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return p->read( p, freq, res, dbm );
   }

/****************************************************************************************/
/* ---------                         Signal Generator                         ----------*/
/****************************************************************************************/

extern int gpib_sg_setfreq( gpib_instr_t instr, double freq )
   {
   instr_sg_t *s = (instr_sg_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_sg_setfreq()", INSTR_SIGGEN );
   if( e )
      return e;
   else if( !s->set_freq )
      {
      gpib_seterror( "gpib_sg_setfreq()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return s->set_freq( s, freq );
   }

/****************************************************************************************/

extern int gpib_sg_setpower( gpib_instr_t instr, double dbm )
   {
   instr_sg_t *s = (instr_sg_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_sg_setpower()", INSTR_SIGGEN );
   if( e )
      return e;
   else if( !s->set_power )
      {
      gpib_seterror( "gpib_sg_setpower()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return s->set_power( s, dbm );
   }

/****************************************************************************************/

extern int gpib_sg_rfon( gpib_instr_t instr )
   {
   instr_sg_t *s = (instr_sg_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_sg_rfon()", INSTR_SIGGEN );
   if( e )
      return e;
   else if( !s->turn_on )
      {
      gpib_seterror( "gpib_sg_rfon()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return s->turn_on( s );
   }

/****************************************************************************************/

extern int gpib_sg_rfoff( gpib_instr_t instr )
   {
   instr_sg_t *s = (instr_sg_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_sg_rfoff()", INSTR_SIGGEN );
   if( e )
      return e;
   else if( !s->turn_off )
      {
      gpib_seterror( "gpib_sg_rfoff()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return s->turn_off( s );
   }

/****************************************************************************************/
/* ---------                      Temperature Controller                      ----------*/
/****************************************************************************************/

extern int gpib_tc_settemp( gpib_instr_t instr, double temp )
   {
   instr_tc_t *t = (instr_tc_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_tc_settemp()", INSTR_TCONTROL );
   if( e )
      return e;
   else if( !t->set_temp )
      {
      gpib_seterror( "gpib_tc_settemp()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return t->set_temp( t, temp );
   }

/****************************************************************************************/

extern int gpib_tc_readtemp( gpib_instr_t instr, double *temp )
   {
   instr_tc_t *t = (instr_tc_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_tc_readtemp()", INSTR_TCONTROL );
   if( e )
      return e;
   else if( !t->read_temp )
      {
      gpib_seterror( "gpib_tc_readtemp()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return t->read_temp( t, temp );
   }

/****************************************************************************************/

extern int gpib_tc_shutdown( gpib_instr_t instr )
   {
   instr_tc_t *t = (instr_tc_t*) instr;

   /* error checking */
   int e = err_check_instr( instr, "gpib_tc_shutdown()", INSTR_TCONTROL );
   if( e )
      return e;
   else if( !t->shutdown )
      {
      gpib_seterror( "gpib_tc_shutdown()", gpib_stderrmsg( EGPIB_NOTSUPPORTED ) );
      return EGPIB_NOTSUPPORTED;
      }

   return t->shutdown( t );
   }

/****************************************************************************************/
/* ---------                       Spectrum Analyzer                          ----------*/
/****************************************************************************************/




