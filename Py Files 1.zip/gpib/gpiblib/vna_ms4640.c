#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_vna(instr_vna_t *vna);
static int close_vna(instr_vna_t *vna);
static int read_freq_list(instr_vna_t *vna, double *flist, unsigned szList, unsigned *numf);
static int read_s_params(instr_vna_t *vna, instr_complex_t sp[][4], unsigned szSp, unsigned *nums);
static int read_cal_coeffs(instr_vna_t *vna, instr_complex_t c[][12], unsigned szCoeffs, unsigned *numc);
static int convert_real64_block(instr_vna_t* vna, int read_bytes, double* data, int szdata, int* converted);

struct localdata_t
{
   double *flist;
   double *sp;
   void *bbuf;
   int sz_flist;
   int sz_bbuf;
   char *border;
   char measparms[128];
};


/******************************************************************************************/
/******************************************************************************************/

extern int instr_load(gpib_instr_t inst)
{
   instr_vna_t* vna;

   if( gpib_instr_gettype(inst) != INSTR_VNA )
   {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
   }

   vna = (instr_vna_t*) inst;

   /* initialize the driver methods */
   vna->open = open_vna;
   vna->close = close_vna;
   vna->read_freq_list = read_freq_list;
   vna->read_s_params = read_s_params;
   vna->read_cal_coeffs = read_cal_coeffs;

   /* set the library version and text fields */
   vna->libver = "1.0.0";
   vna->libtext = "Driver for the Anritsu MS4640-series vector network analyzers.";

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int allocate_local_memory(instr_vna_t *vna, int sz)
{
   if( !vna->udata ) {
      struct localdata_t* data = malloc( sizeof(struct localdata_t) );
      data->flist = 0;
      data->bbuf = 0;
      data->sp = 0;
      data->sz_flist = 0;
      data->sz_bbuf = 0;
      strcpy(data->measparms,"");
      vna->udata = (void*)data;
   }

   if( sz > 0 ) {
      struct localdata_t* data = (struct localdata_t*) vna->udata;
      if( data->flist ) {
         // memory already allocated
         if( data->sz_flist >= sz ) {
            // allocated space is adequate
            return 0;
         }
         else {
            // allocated space is too small, free existing memory
            if( data->flist ) free((void*) data->flist);
            if( data->bbuf ) free(data->bbuf);
            if( data->sp ) free((void*) data->sp);
            data->flist = 0;
            data->bbuf = 0;
            data->sp = 0;
            data->sz_flist = 0;
            data->sz_bbuf = 0;
         }
      }

      // allocate memory for the frequency list, sp buffer, and binary buffer
      data->sz_flist = sz;
      data->sz_bbuf = 8 * sz * 2 + 32;
      data->flist = malloc( sizeof(double) * sz );
      data->sp = malloc( sizeof(double) * sz * 2 );
      data->bbuf =  malloc( data->sz_bbuf );
      if( !data->flist || !data->sp || !data->bbuf ) {
         gpib_seterror( vna->name, "Memory allocation failure. System resources depleted?" );
         return EGPIB_INSTRERROR;
      }
   }
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static void free_local_memory( instr_vna_t *vna )
{
   struct localdata_t* data = (struct localdata_t*) vna->udata;
   if( data ) {
      if( data->flist ) free((void*) data->flist);
      if( data->bbuf ) free(data->bbuf);
      if( data->sp ) free((void*) data->sp);
      free(vna->udata);
      vna->udata = 0;
   }
}


/******************************************************************************************/
/******************************************************************************************/

static int open_vna (instr_vna_t *vna)
{
   int i, e, mcount;
   char buf[256];
   const char bittest[] = { 0, 0, 0x05, 0x37 };
   struct localdata_t* data;
   int s11p = 0;
   int s12p = 0;
   int s21p = 0;
   int s22p = 0;

   /* create the device descriptor */
   if( (e = gpib_getud( &vna->ud, vna->bidx, vna->addr, vna->tmo, 1, 0 )) )
      return e;

   /* clear the instrument and check the ID string */
   if( (e = gpib_write(vna->ud, "*CLS;*IDN?")) || (e = gpib_read( vna->ud, buf, 255 )) )
      return e;
   if( !strstr(buf, "ANRITSU") || !strstr(buf, "MS464") ) {
      gpib_seterror( vna->name, gpib_stderrmsg(EGPIB_BADDEVICE) );
      return EGPIB_BADDEVICE;
   }

   /* create data storage */
   if( (e = allocate_local_memory(vna,0)) )
      return e;
   data = (struct localdata_t*) vna->udata;
   
   // determine whether the bit order is normal or swapped
   //  this depends on the "endian-ness" of the machine
   //  for x86 machines the result should be
   //  swapped bit order
   memcpy( (void*)&e, (const void*)bittest, 4 );
   data->border = (e==0x537)?"NORM":"SWAP";

   /* initialize the instrument */
   // set:
   //   - no service request generation
   //   - set the channel mode to HOLD
   if( vna->chan < 1 )
      vna->chan=1;
   sprintf(buf, "*SRE 0;:SENS:HOLD:FUNC HOLD");
   if( (e = gpib_write( vna->ud, buf )) )
      return e;

   /* initialize the measurements */
   // find out how many measurements are defined
   sprintf(buf,":CALC%d:PAR:COUN?",vna->chan);
   if( (e = gpib_write( vna->ud, buf )) || (e = gpib_read(vna->ud,buf,255)) )
      return e;

   mcount = atoi(buf);
   if( mcount < 4 ) {
      gpib_seterror( vna->name, "open_vna(): not enough measurements are defined." );
      return EGPIB_INSTRERROR;
   }

   for( i=0; i<mcount; ++i ) {
      sprintf(buf,":CALC%d:PAR%d:DEF?",vna->chan,i+1);
      if( (e = gpib_write( vna->ud, buf )) || (e = gpib_read(vna->ud,buf,255)) )
         return e;

      if( !strncmp(buf,"S11",3) ) s11p = i+1;
      else if( !strncmp(buf,"S21",3) ) s21p = i+1;
      else if( !strncmp(buf,"S22",3) ) s22p = i+1;
      else if( !strncmp(buf,"S12",3) ) s12p = i+1;
   }

   if( !s11p ) {
      gpib_seterror( vna->name, "open_vna(): measurement S11 is not defined." );
      return EGPIB_INSTRERROR;
   }
   else if( !s12p ) {
      gpib_seterror( vna->name, "open_vna(): measurement S12 is not defined." );
      return EGPIB_INSTRERROR;
   }
   else if( !s21p ) {
      gpib_seterror( vna->name, "open_vna(): measurement S21 is not defined." );
      return EGPIB_INSTRERROR;
   }
   else if( !s22p ) {
      gpib_seterror( vna->name, "open_vna(): measurement S22 is not defined." );
      return EGPIB_INSTRERROR;
   }

   sprintf(data->measparms,"%d %d %d %d",s11p,s12p,s21p,s22p); 

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int close_vna(instr_vna_t *vna)
{
   char buf[128];
   int e;
   
   // free local memory
   free_local_memory(vna);

   sprintf(buf, ":SENS:HOLD:FUNC CONT");
   if( (e = gpib_write(vna->ud, buf)) )
      return e;
   
   // set gpib mode to local and free handle
   gpib_golocal(vna->ud);
   gpib_freeud(vna->ud);
   vna->ud = -1;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_flist_(instr_vna_t *vna)
{
   char buf[64];
   struct localdata_t* data = (struct localdata_t*) vna->udata;
   int e, n;
   
   // determine the size of the frequency list
   sprintf(buf, "SENS%d:SWE:POIN?", vna->chan);
   if( (e = gpib_write( vna->ud, buf )) )
      return e;
   if( (e = gpib_read( vna->ud, buf, 255 )) )
      return e;
   buf[gpib_readcount()] = '\0';
   
   // allocate memory for the frequency list and buffer
   if( (e=allocate_local_memory(vna,atoi(buf))) )
      return e;
   
   // read the frequency list
   sprintf(buf, ":FORM:DATA REAL;:FORM:BORD %s;:SENS%d:FREQ:DATA?",data->border,vna->chan);
   if( (e=gpib_write(vna->ud,buf)) || (e=gpib_read(vna->ud,data->bbuf,data->sz_bbuf)) || (e=convert_real64_block(vna,gpib_readcount(),data->flist,data->sz_flist,&n)) ) {
      return e;
   }
   if( n != data->sz_flist ) {
      gpib_seterror( vna->name, "In read_flist_(): expected frequency list size is not the same as actual." );
      return EGPIB_INSTRERROR;
   }
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_freq_list( instr_vna_t *vna, double *flist, unsigned szList, unsigned *numf )
{
   struct localdata_t* data = (struct localdata_t*) vna->udata;
   int i, e;

   // initialize numf to 0
   *numf = 0;

   if( !data->flist ) {
      if( (e=read_flist_(vna)) )
         return e;
   }

   // copy the frequency list to the return variable
   if( data->sz_flist > szList ) {
      gpib_seterror( vna->name, "read_freq_list(): array is not large enough for the frequency list.");
      return EGPIB_INSTRERROR;
   }
   for( i=0; i<data->sz_flist; ++i ) {
      flist[i] = data->flist[i];
   }
   *numf = data->sz_flist;
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_s_params( instr_vna_t *vna, instr_complex_t sp[][4], unsigned szSp, unsigned *nums )
{
   struct localdata_t* data = (struct localdata_t*) vna->udata;
   char buf[128];
   int i, j, n, e;
   int parm[4];

   // initialize nums to 0
   *nums = 0;

   if( !data->flist ) {
      if( (e=read_flist_(vna)) )
         return e;
   }

   // read averaging state
   sprintf(buf, ":SENS%d:AVER:STAT?", vna->chan);
   if( (e = gpib_write( vna->ud, buf )) || (e=gpib_read(vna->ud,buf,127)) )
      return e;
   buf[gpib_readcount()]='\0';
   if( atoi(buf) ) {
      // averaging is turned on
      // read the current averaging number
      sprintf(buf, ":SENS%d:AVER:TYP?", vna->chan);
      if( (e = gpib_write(vna->ud, buf)) || (e=gpib_read(vna->ud,buf,127)) )
         return e;
      buf[gpib_readcount()]='\0';
      
      if( strcmp(buf,"POIN") ) {
         // only point-by-point averaging is allowed
         gpib_seterror(vna->name, "read_s_params(): only point-by-point averaging is allowed.");
         return EGPIB_INSTRERROR;
      }
      
      // restart the averaging
      sprintf(buf, ":SENS%d:AVER:CLE", vna->chan);
      if( (e = gpib_write( vna->ud, buf )) )
         return e;
   }
   
   // trigger a measurement
   sprintf(buf, ":TRIG:SING;*ESE 1;*OPC");
   if( (e = gpib_write( vna->ud, buf )) )
      return e;

   // wait for the measurement to complete
   //  this is done by checking the 
   //  Event Status Register for the presence of
   //  the OPC bit
   while( 1 )
   {
      ms_delay(50);
      if( (e = gpib_write(vna->ud, "*ESR?" )) )
         return e;
      if( (e = gpib_read( vna->ud, buf, 127 )) )
         return e;
      buf[gpib_readcount()] = '\0';

      if( atoi(buf) )
         break;
   }

   sscanf(data->measparms,"%d%d%d%d",&parm[0],&parm[1],&parm[2],&parm[3]); 
   
   // loop through the 4 sparameters and read each
   for( i=0; i<4; ++i ) {
      // set the parameter, query the data, and convert from block format to a double-precision array
      sprintf(buf, ":CALC%d:PAR%d:SEL",vna->chan,parm[i]);
      if( (e = gpib_write(vna->ud, buf)) )
         return e;
     
      sprintf(buf,":FORM:DATA REAL;:FORM:BORD %s;:CALC%d:SEL:DATA:SDAT?",data->border,vna->chan);
      if( (e=gpib_write(vna->ud,buf)) || (e=gpib_read(vna->ud,data->bbuf,data->sz_bbuf)) || (e=convert_real64_block(vna,gpib_readcount(),data->sp,2*data->sz_flist,&n)) )
         return e;
     
      // check that the size of the returned data is correct
      if( n != 2*data->sz_flist ) {
         gpib_seterror( vna->name, "read_s_params(): returned array size differs from expected size." );
         return EGPIB_INSTRERROR;
      }
      
      // check that there is enough space for the data
      if( szSp < n/2 ) {
         char str[128];
         sprintf(str, "read_s_params(): array is not large enough for the data (%d < %d).", szSp, n/2);
         gpib_seterror(vna->name, str);
         return EGPIB_INSTRERROR;
      }
      
      // copy the data into the appropriate locations in the return array
      for( j=0; j<n/2; ++j ) {
         sp[j][i].real = data->sp[2*j];
         sp[j][i].imag = data->sp[2*j+1];
      }
   }
   // set the number of points read
   *nums = data->sz_flist;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int read_cal_coeffs( instr_vna_t *vna, instr_complex_t c[][12], unsigned szCoeffs, unsigned *numc )
{
   gpib_seterror( vna->name, "In read_cal_coeffs(): not implemented yet." );
   return EGPIB_INSTRERROR;
}

/******************************************************************************************/
/******************************************************************************************/

static int convert_real64_block(instr_vna_t *vna, int read_bytes, double* outdata, int szdata, int* converted)
{
   struct localdata_t* data = (struct localdata_t*) vna->udata;
   const char* ptr = (const char*)data->bbuf;
   int szbcount;
   int bcount=0;
   int i,j;
   double d;

   // check that the block is in "definite block format"
   if( *ptr != '#' ) {
      gpib_seterror(vna->name,"convert_real64_block(): invalid data transfer format. Expected block format.");
      return EGPIB_INSTRERROR;
   }
   
   // get the size of the block count
   ++ptr;
   szbcount = *ptr - '0';
   
   // get the number of bytes in the block
   for( i=0; i<szbcount; ++i ) {
      ++ptr;
      bcount *= 10;
      bcount += *ptr - '0';
   }
   
   // check that the reported byte count is consistent with
   //   the size of the block
   if( bcount > read_bytes - szbcount - 1 ) {
      gpib_seterror(vna->name,"convert_real64_block(): byte count is not consistent with block size.");
      return EGPIB_INSTRERROR;
   }
   
   // check that the reported byte count is a multiple of 8
   if( bcount % 8 ) {
      gpib_seterror(vna->name,"convert_real64_block(): illegal byte count in block (must be a multiple of 8).");
      return EGPIB_INSTRERROR;
   }
   
   // convert the data
   ++ptr;
   *converted = 0;
   for( i=0, j=0; i<bcount; i+=8, ++j, ptr+=8 ) {
      if( j == szdata ) {
         gpib_seterror(vna->name,"convert_real64_block(): storage array is not large enough to hold the converted block.");
         return EGPIB_INSTRERROR;
      }
      memcpy((void*)&d, (const void*)ptr, 8);
      outdata[j] = d;
      ++(*converted);
   }
   return 0;
}

