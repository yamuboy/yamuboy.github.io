#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <instr/instr.h>

static int init_bias( instr_bias_t *b );
static int close_bias( instr_bias_t *b );
static int set_bias( instr_bias_t *b, int mode, double src, double compl, int res, double max_range, unsigned delay );
static int read_bias( instr_bias_t *b, double *src, double *meas );
static int turn_off_bias( instr_bias_t *b );
static int trigger( instr_bias_t *b );

static double get_range(int mode, double val);
static double get_compl_range(int mode, double src, double compl);
static double get_adjusted_compl(int mode, double src, double compl);


/*********************************************************************************/
/*********************************************************************************/
/* this is the only exported routine */

extern int instr_load( gpib_instr_t inst )
{
    instr_bias_t* bias;

    if( gpib_instr_gettype(inst) != INSTR_BIAS )
    {
        gpib_seterror(inst, gpib_stderrmsg(EGPIB_WRONGINSTR));
        return EGPIB_WRONGINSTR;
    }

    bias = (instr_bias_t*) inst;

    /* initialize the driver methods */
    bias->open = init_bias;
    bias->close = close_bias;
    bias->set_bias = set_bias;
    bias->read_bias = read_bias;
    bias->trigger = trigger;
    bias->bias_off = turn_off_bias;

    /* set the library version and text fields */
    bias->libver = "1.0.0";
    bias->libtext = "Driver for the Agilent B2902 SMUs.";
    bias->libdate = __DATE__;
    
    /* allocate instrument object local storage */
    bias->udata = NULL;

    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int init_bias( instr_bias_t *bias )
{
    char buffer[1024];
    int e;
    
    if( bias->chan != 1 && bias->chan != 2 ) {
        gpib_seterror(bias->name, "invalid channel");
        return EGPIB_INITFAILED;    
    }    

    /* create the device descriptor */
    e = gpib_getud(&bias->ud, bias->bidx, bias->addr, bias->tmo, 1, 0);
    if(e)
        return e;

    /* clear the instrument */
    e = gpib_clear(bias->ud);
    if(e)
        return e;

    /* initialize and query the instrument */
    e = gpib_write(bias->ud,"*IDN?");
    if(e)
        return e;

    /* check the instrument ID string */
    e = gpib_read(bias->ud, buffer, 100);
    if(e)
        return e;

    if(strstr(buffer,"Agilent") && (strstr(buffer,"B2901") || strstr(buffer,"B2911")))
        bias->type = 1;
    else if(strstr(buffer,"Agilent") && (strstr(buffer,"B2902") || strstr(buffer,"B2912")))
        bias->type = 2;
    else
    {
        bias->type = -1;
        gpib_seterror(bias->name, gpib_stderrmsg(EGPIB_BADDEVICE));
        return EGPIB_BADDEVICE;
    }
    
    if( bias->type == 1 && bias->chan == 2 ) {
        gpib_seterror(bias->name, "B2901/B2911 is a single channel instrument");
        return EGPIB_INITFAILED;    
    }
    
    /* initialize the mode and settings to a known value */
    // set the channel for voltage with 100uA compliance and autoranging
    sprintf(buffer,"OUTP%d:STAT 0",bias->chan);
    e = gpib_write(bias->ud,buffer);
    if(e)
        return e;
    sprintf(buffer,"SOUR%d:FUNC:MODE VOLT;:SOUR%d:VOLT:RANG:AUTO 1;:SENS%d:CURR:PROT 100e-6;:SOUR%d:VOLT 0.0;:SENS%d:REM 1",
        bias->chan,bias->chan,bias->chan,bias->chan,bias->chan);
    e = gpib_write(bias->ud,buffer);
    if(e)
        return e;
    
    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int close_bias( instr_bias_t *bias )
{
    if( bias->mode ) {
        /* bias is on, need to shut off */
        turn_off_bias(bias);
    }

    /* take the device offline */
    gpib_golocal(bias->ud);
    gpib_freeud(bias->ud);
    bias->ud = -1;

    /* free local storage */
    free((void*)bias->udata);
    bias->udata = NULL;
    
    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int set_bias( instr_bias_t *bias, int mode, double src, double compl, int res, double max_range, unsigned delay )
{
    char buffer[256];
    char range_str[128];
    int turn_on = 0;
    int e;
    double integ;
    char *src_param, *meas_param;
    int mmode;
    double srange, mrange, delay_s, cadj;

    if( mode == SRC_CURRENT ) {
        src_param = "CURR";
        meas_param = "VOLT";
        mmode = SRC_VOLTAGE;
    }
    else {
        src_param = "VOLT";
        meas_param = "CURR";    
        mmode = SRC_CURRENT;
    }

    if( bias->mode != mode )
    {
        /* biasing mode has changed */

        if( !mode )
            /* supply is on, need to shut it off */
            return turn_off_bias( bias );
        else
        {
            if( bias->mode ) {
                /* need to switch supply modes (voltage->current or current->voltage)
                shut off the supply first */
                e = turn_off_bias( bias );
                if( e )
                    return e;
            }
            turn_on = 1;
            sprintf(buffer,"SOUR%d:FUNC:MODE %s;:SENS:REM 1",bias->chan,src_param,bias->chan);
            e = gpib_write(bias->ud,buffer);
            if(e)
                return e;
        }
    }

    /* bias mode is off */
    if( !mode )
        return 0;

    /* set the resolution (integration time) */
    if( bias->resolution != res || turn_on )
    {
        if( res == HIGH_RES )
            integ = 16.0;
        else if( res == MEDIUM_RES )
            integ = 8.0;
        else
            integ = 2.0;
        sprintf(buffer,"SENS%d:%s:NPLC:AUTO 0;:SENS%d:%s:NPLC %lf",
            bias->chan,meas_param,bias->chan,meas_param,integ);
        e = gpib_write(bias->ud,buffer);
        if(e)
            return e;
    }

    if( max_range != AUTO_RANGE ) {
        /* for this driver, this range specifies the source range
           - when this is set to fixed range we also force the
             measurement to a fixed range measurement based
             on the compliance value
        */
        srange = get_range(mode,max_range);
        mrange = get_compl_range(mode,src,compl);
        
        sprintf(buffer,"SENS%d:%s:RANG:AUTO 0;:SOUR%d:%s:RANG:AUTO 0",
            bias->chan,meas_param,bias->chan,src_param);
        e = gpib_write(bias->ud,buffer);
        if(e)
            return e;
        
        sprintf(range_str,"SENS%d:%s:RANG %.4e;:SOUR%d:%s:RANG %.4e;",
            bias->chan,meas_param,mrange,bias->chan,src_param,srange);
    }
    else {
        // set auto-range        
        sprintf(buffer,"SENS%d:%s:RANG:AUTO 1;:SOUR%d:%s:RANG:AUTO 1",
            bias->chan,meas_param,bias->chan,src_param);
        e = gpib_write(bias->ud,buffer);
        if(e)
            return e;
            
        strcpy(range_str,"");
    }
   
    /* don't allow a delay of g.t. 5 seconds */
    if( delay > 5000 )
        delay = 5000;
    delay_s = delay*0.001;
    
    /* set up the measurement trigger delay */
    sprintf(buffer,"TRIG%d:ACQ:DEL %lf",bias->chan,delay_s);
    e = gpib_write(bias->ud,buffer);
    if( e )
        return e;
    
    /* get an adjusted compliance value */
    cadj = get_adjusted_compl(mode,src,compl);
    
    /* set the source, compliance, and range (if manual range) */
    sprintf(buffer,"%s:SENS%d:%s:PROT %.5e;:SOUR%d:%s %.5e",
        range_str,bias->chan,meas_param,cadj,bias->chan,src_param,src);
    e = gpib_write(bias->ud,buffer);
    if( e )
        return e;
      
    if( turn_on )
    {
        // turn on bias
        sprintf(buffer,"OUTP%d:STAT 1",bias->chan);
        e = gpib_write(bias->ud,buffer);
        if( e )
            return e;
    }

    /* store new values of instrument parameters */
    bias->mode = mode;
    bias->source = src;
    bias->compliance = cadj;
    bias->resolution = res;
    bias->triggered = 0;

    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int trigger( instr_bias_t *bias )
{
    int e;
    char buffer[32];

    if( !bias->mode )
        return 0;

    sprintf(buffer,"*CLS;:INIT:ACQ (@%d)",bias->chan);
    e = gpib_write(bias->ud,buffer);
    if( e )
        return e;

    bias->triggered = 1;
    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int read_bias( instr_bias_t *bias, double *src, double *meas )
{
    char buffer[64];
    int e;

    if( !bias->mode )
    {
        if(src)
            *src = 0.0;
        if(meas)
            *meas = 0.0;
        return 0;
    }
    else if( !bias->triggered )
    {
        /* need to trigger the smu */
        e = trigger(bias);
        if(e)
            return e;
    }

    /* reset the trigger flag */
    bias->triggered = 0;
    
    /* read SMU */
    if( bias->mode == SRC_CURRENT ) {
        // read the measured voltage
        if( meas ) {
            sprintf(buffer,"FETC:VOLT? (@%d)",bias->chan);
            e = gpib_ask(bias->ud,buffer,buffer,64);
            if( e )
                return e;
            sscanf(buffer,"%lf",meas);
        }
        
        // read the set current
        if( src ) {
            sprintf(buffer,"SOUR%d:CURR?",bias->chan);
            e = gpib_ask(bias->ud,buffer,buffer,64);
            if( e )
                return e;
            sscanf(buffer,"%lf",src);
        }
        
        // check compliance
        sprintf(buffer,"SENS%d:VOLT:PROT:TRIP?",bias->chan);
        e = gpib_ask(bias->ud,buffer,buffer,64);
        if( e )
            return e;
        if( atoi(buffer) )
            // return a positive number to indicate compliance
            return 1;
    }
    else /* SRC_VOLTAGE */ {
        // read the measured voltage
        if( meas ) {
            sprintf(buffer,"FETC:CURR? (@%d)",bias->chan);
            e = gpib_ask(bias->ud,buffer,buffer,64);
            if( e )
                return e;
            sscanf(buffer,"%lf",meas);
        }
        
        // read the set current
        if( src ) {
            sprintf(buffer,"SOUR%d:VOLT?",bias->chan);
            e = gpib_ask(bias->ud,buffer,buffer,64);
            if( e )
                return e;
            sscanf(buffer,"%lf",src);
        }
        
        // check compliance
        sprintf(buffer,"SENS%d:CURR:PROT:TRIP?",bias->chan);
        e = gpib_ask(bias->ud,buffer,buffer,64);
        if( e )
            return e;
        if( atoi(buffer) )
            // return a positive number to indicate compliance
            return 1;
    }
    
    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int turn_off_bias( instr_bias_t *bias )
{
    int e;
    char buffer[32];

    if( !bias->mode )
        return 0;

    bias->mode = SRC_OFF;
    sprintf(buffer,"*CLS;OUTP%d:STAT 0",bias->chan);
    e = gpib_write(bias->ud,buffer);
    if(e)
        return e;

    return 0;
}

/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/
/*********************************************************************************/

static double get_range( int mode, double val )
{
    double range = 0.0;

    val = fabs(val);
    if( mode==SRC_VOLTAGE ) {
        if( val > 21.0 )
            range = 200.0;
        else if( val > 2.1 )
            range = 20.0;
        else if( val > 0.21 )
            range = 2.0;
        else
            range = 0.2;
    }
    else {
        if( val > 1.515 )
            range = 3.0;
        else if( val > 1.05 )
            range = 1.5;
        else if( val > 0.105 )
            range = 1.0;
        else if( val > 10.5e-3 )
            range = 0.1;
        else if( val > 1.05e-3 )
            range = 0.01;
        else if( val > 105e-6 )
            range = 0.001;
        else if( val > 10.5e-6 )
            range = 100e-6;
        else if( val > 1.05e-6 )
            range = 10e-6;
        else if( val > 105e-9 )
            range = 1e-6;
        else
            range = 100e-9;
    }

    return range;
}

static double get_compl_range(int mode, double src, double compl)
{
    double r;
    double s = fabs(src);
    
    if( mode == SRC_VOLTAGE ) {
        r = get_range(SRC_CURRENT,compl);
        if( s > 6.0 && r > 1.5 )
            r = 1.5;
        else if( s > 21.0 && r > 0.1 )
            r = 0.1;
    }
    else {
        r = get_range(SRC_VOLTAGE,compl);
        if( s > 1.515 && r > 20.0 )
            r = 20.0;
    }
    
    return r;
}

static double get_adjusted_compl(int mode, double src, double compl)
{
    double s = fabs(src);
    double c = fabs(compl);
    double mc;
    
    if( mode == SRC_VOLTAGE ) {
        if( s > 21.0 )
            mc = 0.105;
        else if( s > 6.0 )
            mc = 1.515;
        else
            mc = 3.03;
    }
    else {
        if( s > 1.515 )
            mc = 6.0;
        else if( s > 0.105 )
            mc = 21.0;
        else
            mc = 210.0;
    }
    
    if( c > mc )
        c = mc;
    
    return c;
}

