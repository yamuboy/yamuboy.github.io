#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_pm( instr_pm_t *pm );
static int close_pm( instr_pm_t *pm );
static int read_pm( instr_pm_t *pm, double freq, int res, double *dbm );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_pm_t* pm;

   if( gpib_instr_gettype( inst ) != INSTR_PWRMETER )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   pm = (instr_pm_t*) inst;

   /* initialize the driver methods */
   pm->open = open_pm;
   pm->close = close_pm;
   pm->read = read_pm;

   /* set the library version and text fields */
   pm->libver = "1.0.0";
   pm->libtext = "Driver for the Gigatronics 8542 dual-channel power meter.";

   return 0;
   }


/******************************************************************************************/
/******************************************************************************************/

static int open_pm( instr_pm_t *pm )
   {
   char buf[64];
   int e;

   /* create the device descriptor */
   e = gpib_getud( &pm->ud, pm->bidx, pm->addr, pm->tmo, 1, 0 );
   if( e )
      return e;

   /* clear/reset the instrument */
   e = gpib_clear( pm->ud );
   if( e )
      return e;

   /* query the instrument */
   e = gpib_write( pm->ud, "*IDN?" );
   if( e )
      return e;

   /* check the instrument ID string */
   e = gpib_read( pm->ud, buf, 64 );
   if( e )
      return e;

   /* check that the instrument model is valid */
   if( !strstr( buf, "8542" ) )
      {
      gpib_seterror( pm->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
      }

   /* check for a valid channel # */
   if( pm->chan < 1 || pm->chan > 2 )
      {
      sprintf( buf, "Channel %d is not valid for this instrument.", pm->chan );
      gpib_seterror( pm->name, buf );
      return EGPIB_INSTRERROR;
      }

   /* disable SRQ */
   e = gpib_write( pm->ud, "*SRE000*ESE000" );
   if( e )
      return e;

   ms_delay( 100 );
   
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int close_pm( instr_pm_t *pm )
   {
   gpib_golocal( pm->ud );
   gpib_freeud( pm->ud );
   pm->ud = -1;
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/
/* note that res is ignored by this function */

static int read_pm( instr_pm_t *pm, double freq, int res, double *dbm )
   {
   char buf[64];
        char st, *sens;
   int e;

   /* determine the sensor A/B */
   if( pm->chan == 1 )
      sens = "AE";
   else
      sens = "BE";
        
   /* set to dBm units and set the frequency */
   sprintf( buf, "%sLGFR%.3fGZ", sens, freq*1.0e-9 );
   e = gpib_write( pm->ud, buf );
   if( e )
      return e;

        /* clear status */
   e = gpib_write( pm->ud, "CS" );
   if( e )
      return e;

   /* critical delay, allows the meter to process the clear status command */
        ms_delay( 100 );
                        
        /* trigger a full measurement with settling */
   e = gpib_write( pm->ud, "TR2" );
   if( e )
      return e;

   /* wait for measurement completion */
   while( 1 )
      {
      ms_delay( 50 );
      e = gpib_spoll( pm->ud, &st );
      if( e )
         return e;

      if( st & 0x01 )
         break;
      }
                                                
   /* read the power */
   e = gpib_read( pm->ud, buf, 64 );
   if( e ) 
      return e;
   *dbm = atof( buf );

        /* clear status */
   e = gpib_write( pm->ud, "CS" );
   if( e )
      return e;

        /* set to free run */
   e = gpib_write( pm->ud, "TR3" );
   if( e )
      return e;
        
   return 0;
   }




