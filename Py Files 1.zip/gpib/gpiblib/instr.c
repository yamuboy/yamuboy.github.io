#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include <time.h>
#include <sys/time.h>
#include <pthread.h>
#ifdef WIN32
# include <decl-32.h>
#else
# include <ni488.h>
#endif
#include <instr/instr.h>

/* local global variables */
static char* default_logfile_name = "gpiblib.log";
static int global_loglvl = 0;
static char* logfile_name = NULL;

/* variables for implementing thread-safety and thread-local storage for error messages */
#ifdef HAVE_PTHREAD
static pthread_mutex_t logfile_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_key_t errstr_key;
static pthread_once_t errstr_once = PTHREAD_ONCE_INIT;
#else
/* if pthreads are not available, no thread safety */
static char* global_errstr = NULL;
#endif

static int create_instrument( gpib_instr_t *inst, int insttype, char *name, char *libname, void *h_lib,
                              int bidx, int addr, int chan, int tmo );
static void delete_instrument( gpib_instr_t inst );
static void gpib_instr_closelib( gpib_instr_t inst );
static char* gpib_iberrstring( void );
static void gpiblog_ibwrt( int ud, char *str );
static void gpiblog_ibrd( int ud, char *str );
static void gpiblog_ibrsp( int ud, char b );
static void gpiblog_ibclr( int ud );
static void gpiblog_ibtrg( int ud );

/********************************************************************************/
/********************************************************************************/

#ifdef HAVE_PTHREAD

static void delete_errstr( void *str )
   {
   if( str )
      free( str );
   }

static void create_errstr_key( void )
   {
   pthread_key_create( &errstr_key, delete_errstr );
   }

#endif

/********************************************************************************/
/********************************************************************************/

static char* get_thread_errorstr( void )
   {
#ifdef HAVE_PTHREAD
   return (char*) pthread_getspecific( errstr_key );
#else
   return global_errstr;
#endif
   }

/********************************************************************************/
/********************************************************************************/

static void set_thread_errorstr( char *errstr )
   {
#ifdef HAVE_PTHREAD
   char *oldmsg = get_thread_errorstr();
   if( oldmsg )
      /* free old memory */
      free((void*)oldmsg);

   pthread_once( &errstr_once, create_errstr_key );
   if( errstr )
      pthread_setspecific( errstr_key, strdup(errstr) );
   else
      pthread_setspecific( errstr_key, NULL );
#else
   if( global_errstr )
      free((void*)global_errstr);
   if( errstr )
      global_errstr = strdup( errstr );
   else
      global_errstr = NULL;
#endif
   }

/********************************************************************************/
/********************************************************************************/

extern int gpib_set_loglevel( int lvl )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_set_loglevel");

   /* lock the logfile */
#ifdef HAVE_PTHREAD
   pthread_mutex_lock( &logfile_mutex );
#endif

   global_loglvl = lvl;

   /* unlock the logfile */
#ifdef HAVE_PTHREAD
   pthread_mutex_unlock( &logfile_mutex );
#endif

   return 0;
   }

/********************************************************************************/
/********************************************************************************/

extern int gpib_set_logfile( char *fname )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_set_logfile");

   /* lock the logfile */
#ifdef HAVE_PTHREAD
   pthread_mutex_lock( &logfile_mutex );
#endif

   /* free the old logfile name */
   if( logfile_name && logfile_name != default_logfile_name )
      free((void*)logfile_name);

   /* set the new logfile name */
   if( !fname )
      logfile_name = default_logfile_name;
   logfile_name = strdup( fname );

   /* unlock the logfile */
#ifdef HAVE_PTHREAD
   pthread_mutex_unlock( &logfile_mutex );
#endif

   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern char* gpib_errmsg( void )
   {
   char *str;
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_errmsg");

   str = get_thread_errorstr();
   if( str )
      return str;
   return "";
   }

/********************************************************************************/
/********************************************************************************/

extern int gpib_instr_load( gpib_instr_t *inst, char *name, int insttype, char *libname, int bd, int addr, int chan, int tmo, char donotinit )
   {
   int (*load)( void * );
   void *h_lib;
   int e;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_load");

   if( !inst )
      {
      /* dumbass passed a NULL in */
      gpib_seterror( "gpib_instr_load()", "You cannot pass a NULL value to the gpib_inst_t pointer. You are a dumbass." );
      return EGPIB_INVALIDARG;
      }

   /* 
      explicitely set the instrument pointer to NULL in case the user
       ignores an error returned from this function 
    */
   *inst = NULL;

   /* check for function call errors */
   if( !libname || !*libname ) 
      {
      gpib_seterror( "gpib_instr_load()", gpib_stderrmsg( EGPIB_INVALIDLIBNAME ) );
      return EGPIB_INVALIDLIBNAME;
      }

   /* attempt to load the library */
   h_lib = dlopen( libname, RTLD_NOW );
   if( !h_lib )
      {
      char msg[200];
      sprintf( msg, "%s: library load failed.\ndlerror(): %s", libname, dlerror() );
      gpib_seterror( "dlopen()", msg );
      return EGPIB_LIBLOADFAIL;
      }

   /* create and initialize the instrument structure */
   e = create_instrument( inst, insttype, name, libname, h_lib, bd, addr, chan, tmo );
   if( e )
      {
      /* close the library and return the error */
      dlclose( h_lib );
      return e;
      }

   /* resolve the "instr_load" symbol from the library */
   load = (int (*) (void *)) dlsym( h_lib, "instr_load" );
   if( !load )
      {
      char msg[200];
      sprintf( msg, "%s: \'instr_load\' symbol is missing.\ndlerror(): %s", libname, dlerror() );
      gpib_seterror( "dlsym()", msg );
      dlclose( h_lib );
      delete_instrument( *inst );
      *inst = NULL;
      return EGPIB_LIBSYMMISSING;
      }

   /* load the library - normally this should not ever return an error unless the driver
       was incorrectly written */
   e = (*load)( *inst );
   if( e )
      {
      dlclose( h_lib );
      delete_instrument( *inst );
      *inst = NULL;
      return e;
      }

   if( donotinit==0 )
      {
      /* only init the instrument if the donotinit flag is 0 */
      e = gpib_instr_init( *inst );
      if( e )
         {
         dlclose( h_lib );
         delete_instrument( *inst );
         *inst = NULL;
         return e;
         }
      }

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

extern int gpib_instr_unload( gpib_instr_t inst, char donotclose )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_unload");

   if( !inst )
      {
      gpib_seterror( "gpib_instr_unload()", gpib_stderrmsg( EGPIB_INVALIDARG ) );
      return EGPIB_INVALIDARG;
      }

   if( donotclose==0 )
      {
      /* only close the instrument if the donotclose flag is 0 */
      int e = gpib_instr_close( inst );
      if( e )
         {
         gpib_instr_closelib( inst );
         delete_instrument( inst );
         return e;
         }
      }

   gpib_instr_closelib( inst );
   delete_instrument( inst );
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

extern int gpib_instr_init( gpib_instr_t inst )
   {
   instr_general_t *x = (instr_general_t*) inst;
   int e;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_init");

   if( !x || !x->open )
      {
      gpib_seterror( gpib_instr_getname( inst ), gpib_stderrmsg( EGPIB_INITFAILED ) );
      return EGPIB_INITFAILED;
      }
   
   e = x->open( inst );
   if( e )
      return e;

   /* set the initialized flag */
   x->flag |= INSTRFLAG_INIT;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

extern int gpib_instr_close( gpib_instr_t inst )
   {
   instr_general_t *x = (instr_general_t*) inst;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_close");

   if( !x || !x->close )
      {
      gpib_seterror( gpib_instr_getname( inst ), gpib_stderrmsg( EGPIB_CLOSEFAILED ) );
      return EGPIB_CLOSEFAILED;
      }

   /* clear the initialized flag */
   x->flag &= ~INSTRFLAG_INIT;
   
   return x->close( inst );
   }

/******************************************************************************************/
/******************************************************************************************/

static void gpib_instr_closelib( gpib_instr_t inst )
   {
   instr_general_t *x = (instr_general_t*) inst;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_closelib");

   if( !x )
      return;

   if( x->h_lib )
      dlclose( x->h_lib );
   }

/******************************************************************************************/
/******************************************************************************************/

extern int gpib_instr_gettype( gpib_instr_t inst )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_gettype");

   if( !inst )
      return INSTR_NOTYPE;

   switch( *((long*)inst) )
      {
      case MC_GPIB_INSTR_BIAS:
         return INSTR_BIAS;
      case MC_GPIB_INSTR_VNA:
         return INSTR_VNA;
      case MC_GPIB_INSTR_NFM:
         return INSTR_NFM;
      case MC_GPIB_INSTR_AP:
         return INSTR_AUTOPROBER;
      case MC_GPIB_INSTR_TC:
         return INSTR_TCONTROL;
      case MC_GPIB_INSTR_SG:
         return INSTR_SIGGEN;
      case MC_GPIB_INSTR_PM:
         return INSTR_PWRMETER;
      case MC_GPIB_INSTR_SA:
         return INSTR_SPECANA;
      }

   return INSTR_NOTYPE;
   }

/******************************************************************************************/
/******************************************************************************************/

extern char* gpib_instr_getname( gpib_instr_t inst )
   {
   instr_general_t *x = (instr_general_t*) inst;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_instr_getname");

   if( !x )
      return "(InvalidInstr)";
   else if( !x->name || !*x->name )
      return "(UnnamedInstr)";

   return x->name;
   }

/******************************************************************************************/
/******************************************************************************************/

extern int gpib_board_open( int idx, int *bd )
   {
   char str[10];

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_board_open");

   if( !bd || idx < 0 || idx > 3)
      {
      gpib_seterror( "gpib_board_open()", gpib_stderrmsg( EGPIB_INVALIDARG ) );
      return EGPIB_INVALIDARG;
      }

   sprintf( str, "gpib%d", idx );
   *bd = ibfind( str );

   if( *bd < 0 )
      {
      gpib_seterror( "ibfind()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   /* set the remote enable line */
   if( ibsre( *bd, 1 ) & ERR )
      {
      gpib_seterror( "ibsre()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

extern int gpib_board_close( int bd )
   {
   char str[] = {UNT, UNL, 0};

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_board_close");

   if( bd < 0 )
      {
      gpib_seterror( "gpib_board_close()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   /* send untalk and unlisten commands */
   if( ibcmd( bd, str, strlen(str) ) & ERR )
      {
      gpib_seterror( "ibcmd()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   /* release the board descriptor */
   ibonl( bd, 0 );

   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_instr_getinfo( gpib_instr_t inst, gpib_info_t *info )
   {
   instr_general_t *x = (instr_general_t*) inst;
   gpib_info_t t;
   char *tmo_str, *type_str;

   if( !x || !info )
      {
      gpib_seterror( "gpib_instr_getinfo()", gpib_stderrmsg( EGPIB_INVALIDARG ) );
      return EGPIB_INVALIDARG;
      }

   t = (gpib_info_t) gpib_malloc( sizeof(struct _gpib_info) );

   /* set the timeout string */
   switch( x->tmo )
      {
      case 1:
         tmo_str = "10 us"; break;
      case 2:
         tmo_str = "30 us"; break;
      case 3:
         tmo_str = "100 us"; break;
      case 4:
         tmo_str = "300 us"; break;
      case 5:
         tmo_str = "1 ms"; break;
      case 6:
         tmo_str = "3 ms"; break;
      case 7:
         tmo_str = "10 ms"; break;
      case 8:
         tmo_str = "30 ms"; break;
      case 9:
         tmo_str = "100 ms"; break;
      case 10:
         tmo_str = "300 ms"; break;
      case 11:
         tmo_str = "1 s"; break;
      case 12:
         tmo_str = "3 s"; break;
      case 13:
         tmo_str = "10 s"; break;
      case 14:
         tmo_str = "30 s"; break;
      case 15:
         tmo_str = "100 s"; break;
      case 16:
         tmo_str = "300 s"; break;
      case 17:
         tmo_str = "1000 s"; break;
      default:
      case 0:
         tmo_str = "infinite"; break;
      }

   /* set the instrument type string */
   switch( gpib_instr_gettype( inst ) )
      {
      case INSTR_BIAS:
         type_str = "Bias Supply"; break;
      case INSTR_VNA:
         type_str = "Network Analyzer"; break;
      case INSTR_NFM:
         type_str = "Noise Figure Meter"; break;
      case INSTR_AUTOPROBER:
         type_str = "Automatic Probe Station"; break;
      case INSTR_TCONTROL:
         type_str = "Temperature Control Unit"; break;
      case INSTR_SIGGEN:
         type_str = "Signal Generator"; break;
      case INSTR_PWRMETER:
         type_str = "Power Meter"; break;
      case INSTR_SPECANA:
         type_str = "Spectrum Analyzer"; break;
      default:
         type_str = "(unknown)"; break;
      }

   t->addr = x->addr;
   t->chan = x->chan;
   t->timeout = tmo_str;
   t->instr_name = x->name ? strdup( x->name ) : strdup( "(none)" );
   t->instr_type = type_str;
   t->driver_name = strdup( x->libname );
   t->driver_version = x->libver ? strdup( x->libver ) : strdup( "(none)" );
   t->driver_date = x->libdate ? strdup( x->libdate ) : strdup( "(none)" );
   t->driver_text = x->libtext ? strdup( x->libtext ) : strdup( "(none)" );

   *info = t;
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern void gpib_instr_freeinfo( gpib_info_t info )
   {
   if( !info )
      return;
   free((void*)info->instr_name); 
   free((void*)info->driver_name);
   free((void*)info->driver_version);
   free((void*)info->driver_text);
   free((void*)info);
   }

/********************************************************************************************/
/********************************************************************************************/

static int create_instrument( gpib_instr_t *inst, int insttype, char *name, char *libname, void *h_lib,
                              int bidx, int addr, int chan, int tmo )
   {
   instr_general_t *x = NULL;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("create_instrument");

   switch( insttype )
      {
      /* in here allocate memory and init instr-specific fields,
          standard fields will be set later (except for the mc
          field which is set here as well) */

      case INSTR_BIAS:
         {
         instr_bias_t *b = gpib_malloc( sizeof(instr_bias_t) );
         b->mc = MC_GPIB_INSTR_BIAS;
         b->mode = 0;
         b->resolution = 0;
         b->triggered = 0;
         b->source = 0.0;
         b->compliance = 0.0;
         b->set_bias = NULL;
         b->read_bias = NULL;
         b->trigger = NULL;
         b->bias_off = NULL;

         x = (instr_general_t*) b;
         break;
         }

      case INSTR_VNA:
         {
         instr_vna_t *v = gpib_malloc( sizeof(instr_vna_t) );
         v->mc = MC_GPIB_INSTR_VNA;
         v->read_freq_list = NULL;
         v->read_s_params = NULL;
         v->read_cal_coeffs = NULL;

         x = (instr_general_t*) v;
         break;
         }

      case INSTR_NFM:
         {
         instr_nfm_t *n = gpib_malloc( sizeof(instr_nfm_t) );
         n->mc = MC_GPIB_INSTR_NFM;
         n->read_noise_sweep = NULL;
         n->load_enr = NULL;

         x = (instr_general_t*) n;
         break;
         }

      case INSTR_AUTOPROBER:
         {
         instr_ap_t *a = gpib_malloc( sizeof(instr_ap_t) );
         a->mc = MC_GPIB_INSTR_AP;
         a->x_base = 0;
         a->y_base = 0;
         a->x_last = 0;
         a->y_last = 0;
         a->move = NULL;
         a->separate = NULL;

         x = (instr_general_t*) a;
         break;
         }

      case INSTR_TCONTROL:
         {
         instr_tc_t *t = gpib_malloc( sizeof(instr_tc_t) );
         t->mc = MC_GPIB_INSTR_TC;
         t->set_temp = NULL;
         t->read_temp = NULL;
         t->shutdown = NULL;

         x = (instr_general_t*) t;
         break;
         }

      case INSTR_SIGGEN:
         {
         instr_sg_t *g = gpib_malloc( sizeof(instr_sg_t) );
         g->mc = MC_GPIB_INSTR_SG;
         g->is_on = 0;
         g->turn_on = NULL;
         g->turn_off = NULL;
         g->set_power = NULL;
         g->set_freq = NULL;

         x = (instr_general_t*) g;
         break;
         }

      case INSTR_PWRMETER:
         {
         instr_pm_t *p = gpib_malloc( sizeof(instr_pm_t) );
         p->mc = MC_GPIB_INSTR_PM;
         p->read = NULL;

         x = (instr_general_t*) p;
         break;
         }

      case INSTR_SPECANA:
         {
         instr_sa_t *s = gpib_malloc( sizeof(instr_sa_t) );
         s->mc = MC_GPIB_INSTR_SA;

         x = (instr_general_t*) s;
         break;
         }
      }

   if( !x )
      {
      /* unrecognized insttype */
      char msg[200];
      sprintf( msg, "\"%s\": %s", name ? name : "(noname)", gpib_stderrmsg( EGPIB_CREATEFAILED ) );
      gpib_seterror( "create_instrument()", msg );
      return EGPIB_CREATEFAILED;
      }

   /* set standard members (except mc) */
   x->h_lib = h_lib;
   x->udata = NULL;
   x->bidx = bidx;
   x->addr = addr;
   x->chan = chan;
   x->tmo = tmo;
   x->type = 0;
   x->flag = 0;
   x->ud = -1;
   if( name )
      x->name = strdup( name );
   else
      x->name = NULL;
   x->libname = strdup( libname );
   x->libver = NULL;
   x->libdate = NULL;
   x->libtext = NULL;
   x->open = NULL;
   x->close = NULL;
   
   *inst = (gpib_instr_t) x;
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

static void delete_instrument( gpib_instr_t inst )
   {
   instr_general_t *x = (instr_general_t*) inst;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("delete_instrument");

   /* deletes memory associated with the instrument structure */
   if( x->name )
      free((void*)x->name);
   free((void*)x->libname);
   free((void*)x);
   }

/********************************************************************************************/
/********************************************************************************************/

extern void* gpib_malloc( size_t sz )
   {
   void *buf;
   if( sz < 1 )
      sz = 4;

   buf = malloc( sz );
   if( !buf )
      {
      fprintf( stderr, "Error(fatal): memory-allocation failed.\n" );
      exit(-1);
      }

   return buf;
   }

/******************************************************************************************/
/******************************************************************************************/

extern void ms_delay( unsigned ms )
   {
   struct timeval tstart, tcurrent;
   long elapsed_ms = 0;
   
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("ms_delay");

   gettimeofday( &tstart, NULL );
   while( elapsed_ms < (long) ms )
      {
      gettimeofday( &tcurrent, NULL );
      elapsed_ms = (tcurrent.tv_sec - tstart.tv_sec)*1000 + (tcurrent.tv_usec - tstart.tv_usec)/1000;
      }
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_getud( int *ud, int bidx, int addr, int tmo, int send_eoi, int eos )
   {
   int pad = addr & 0xff;
   int sad = addr & 0xff00;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_getud");

   if( tmo < 0 )
      tmo = 0;
   else if( tmo > 17 )
      tmo = 17;

   *ud = ibdev( bidx, pad, sad, tmo, send_eoi, eos );
   if( *ud < 0 )
      {
      gpib_seterror( "gpib_getud()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern void gpib_freeud( int ud )
   {
   if( ud > -1 )
      ibonl( ud, 0 );
   }

/********************************************************************************************/
/********************************************************************************************/

static int get_ibsta( void )
   {
#ifdef HAVE_MTIBLIB
   return ThreadIbsta();
#else
   return ibsta;
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

static int get_iberr( void )
   {
#ifdef HAVE_MTIBLIB
   return ThreadIberr();
#else
   return iberr;
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

static int get_ibcnt( void )
   {
#ifdef HAVE_MTIBLIB
   return ThreadIbcnt();
#else
   return ibcnt;
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_write( int ud, char *buf )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_write");

   if( ud < 0 )
      {
      gpib_seterror( "gpib_write()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   if( ibwrt( ud, buf, strlen(buf) ) & ERR )
      {
      gpib_seterror( "gpib_write()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   if( global_loglvl & GPIB_LOGBUS )
      gpiblog_ibwrt( ud, buf );
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_read( int ud, char *buf, int sz_buf )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_read");

   if( ud < 0 )
      {
      gpib_seterror( "gpib_read()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   if( ibrd( ud, buf, sz_buf-1 ) & ERR )
      {
      gpib_seterror( "gpib_read()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   buf[get_ibcnt()] = '\0';

   if( global_loglvl & GPIB_LOGBUS )
      gpiblog_ibrd( ud, buf );
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_ask( int ud, char *wbuf, char *rbuf, int sz_rbuf )
{
    int e;
    e = gpib_write(ud,wbuf);
    if(e)
        return e;
    return gpib_read(ud,rbuf,sz_rbuf);
}   
   
/********************************************************************************************/
/********************************************************************************************/

extern int gpib_spoll( int ud, char *ret )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_spoll");

   if( ud < 0 )
      {
      gpib_seterror( "gpib_spoll()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   if( ibrsp( ud, ret ) & ERR )
      {
      gpib_seterror( "gpib_spoll()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   if( global_loglvl & GPIB_LOGBUS )
      gpiblog_ibrsp( ud, *ret );
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_clear( int ud )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_clear");

   if( ud < 0 )
      {
      gpib_seterror( "gpib_clear()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   if( ibclr( ud ) & ERR )
      {
      gpib_seterror( "gpib_clear()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   if( global_loglvl & GPIB_LOGBUS )
      gpiblog_ibclr( ud );
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_trig( int ud )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_trig");

   if( ud < 0 )
      {
      gpib_seterror( "gpib_trig()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   if( ibtrg( ud ) & ERR )
      {
      gpib_seterror( "gpib_trig()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   if( global_loglvl & GPIB_LOGBUS )
      gpiblog_ibtrg( ud );
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_golocal( int ud )
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_golocal");

   if( ud < 0 )
      {
      gpib_seterror( "gpib_golocal()", gpib_stderrmsg( EGPIB_UDINVALID ) );
      return EGPIB_UDINVALID;
      }

   if( ibloc( ud ) & ERR )
      {
      gpib_seterror( "gpib_golocal()", gpib_iberrstring() );
      return EGPIB_BUSERROR;
      }

   return 0;
   }
        
/********************************************************************************************/
/********************************************************************************************/

extern int gpib_buserror( void ) 
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_buserror");

   return (get_ibsta() & ERR);
   }

/********************************************************************************************/
/********************************************************************************************/

extern int gpib_readcount( void ) 
   {
   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_readcount");

   return get_ibcnt();
   }

/********************************************************************************************/
/********************************************************************************************/
/*                                    ERROR MESSAGES                                        */
/********************************************************************************************/
/********************************************************************************************/

extern void gpib_seterror( char *id, char *errmsg )
   {
   char *msg;
   long idlen, msglen;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_seterror");

   /* create a message of the form "id: errmsg" */
   if( !id )
      {
      id = "(null)";
      idlen = 6;  
      }
   else
      idlen = strlen( id );

   if( !errmsg )
      {
      errmsg = "(none)";
      msglen = 6;
      }
   else
      msglen = strlen( errmsg );

   /* create the message string */
   msg = (char*) gpib_malloc( sizeof(char) * (idlen+msglen+3) );
   strcpy( msg, id );
   strcat( msg, ": " );
   strcat( msg, errmsg );

   if( global_loglvl & GPIB_LOGERR )
      gpiblog_logstr( 'E', msg );

   set_thread_errorstr( msg );
   }

/******************************************************************************************/
/******************************************************************************************/

static char* gpib_iberrstring( void )
   {
   static struct iberr_list { int code; char* txt; } list[] = {
      {EDVR, "System call failure."},
      {ECIC, "Board is not controller-in-charge."},
      {ENOL, "No listener at address."},
      {EADR, "Board failed to address itself."},
      {EARG, "Invalid function argument."},
      {ESAC, "Board is not system controller."},
      {EABO, "An abort occured during read/write."},
      {ENEB, "Board does not exist, or is not configured."},
      {EDMA, "DMA error."},
      {EOIP, "Asynchronous I/O in progress."},
      {ECAP, "No capability to execute command."},
      {EFSO, "File system failure."},
      {EBUS, "Timeout during command byte write."},
      {ESTB, "Status byte buffer overflow during automatic serial polling."},
      {ESRQ, "Stuck SRQ on bus."},
      {ETAB, "Function specific error."}
      };
   int n_errs = sizeof(list)/sizeof(*list);
   int stat = get_ibsta();
   int err = get_iberr();
   int i;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_iberrstring");
   if( global_loglvl & GPIB_LOGERR )
      {
      char str[150];
      sprintf( str, "BUS ERROR: ibsta=%x iberr=%x", stat, err );
      if( !(stat & TIMO) && ( err==EDVR || err==EFSO ) )
         {
         /* EDVR and EFSO set ibcnt to the system errno corresponding to the error encountered */
         char str1[50];
         sprintf( str1, " errno=%d", get_ibcnt() );
         strcat( str, str1 );
         }
      gpiblog_logstr( 'E', str );
      }

   /* there is no error */
   if( !(stat & ERR) )
      return "";

   /* check for TIMO */
   if( stat & TIMO )
      return "Bus read/write operation timed out.";

   /* check for other errors */
   for( i=0; i<n_errs; i++ )
      {
      if( err == list[i].code )
         return list[i].txt;
      }

   /* unknown error */
   return "Unrecognized error.";
   }

/******************************************************************************************/
/******************************************************************************************/

extern char* gpib_stderrmsg( int errnum )
   {
   static struct gpib_errlist { int code; char *txt; } list[] = {
      {EGPIB_INVALIDARG, "Invalid argument passed to function."},
      {EGPIB_INVALIDLIBNAME, "Library name is invalid."},
      {EGPIB_LIBLOADFAIL, "Library failed to load."},
      {EGPIB_LIBSYMMISSING, "Missing library symbol \"instr_init\"."},
      {EGPIB_CREATEFAILED, "Instrument creation failed."},
      {EGPIB_INITFAILED, "Instrument initialization failed"},
      {EGPIB_CLOSEFAILED, "Instrument close failed."},
      {EGPIB_UDINVALID, "Invalid device descriptor."},
      {EGPIB_BUSERROR, "GPIB bus error."},
      {EGPIB_INSTRERROR, "Instrument error."},
      {EGPIB_WRONGINSTR, "Wrong instrument type."},
      {EGPIB_NOTSUPPORTED, "Instrument library does not support function."},
      {EGPIB_NOTINITIALIZED, "Instrument has not been initialized."},
      {EGPIB_BADDEVICE, "Instrument is not supported by this driver."}

      };
   int n_errs = sizeof(list)/sizeof(*list);
   int i;

   if( global_loglvl & GPIB_LOGFUNC )
      gpiblog_func("gpib_stderrmsg");

   /* check for errors */
   for( i=0; i<n_errs; i++ )
      {
      if( errnum == list[i].code )
         return list[i].txt;
      }

   /* unknown error */
   return "Unrecognized error.";
   }

/********************************************************************************************/
/********************************************************************************************/
/*                                         Logging                                          */ 
/********************************************************************************************/
/********************************************************************************************/

static char* gpiblog_ts(void)
   {
   static char str[24];
   static struct timeval td;
   static struct tm lt;
   char c;
   int i;

   gettimeofday( &td, NULL );
   localtime_r( (time_t*)&td.tv_sec, &lt );

   /* create a string of the form "MM/DD/YYYY HH:MM:SS.xxx" */
   c = (char) lt.tm_mon+1;
   str[0] = '0' + c/10;
   str[1] = '0' + c%10;
   str[2] = '/';
   c = (char) lt.tm_mday;
   str[3] = '0' + c/10;
   str[4] = '0' + c%10;
   str[5] = '/';
   i = (int) lt.tm_year;
   str[6] = (i > 99) ? '2' : '1';
   str[7] = (i > 99) ? '0' + ((char)(i/100)) : '9';
   c = (char) (i%100);
   str[8] = '0' + c/10;
   str[9] = '0' + c%10;
   str[10] = ' ';
   c = (char) lt.tm_hour;
   str[11] = '0' + c/10;
   str[12] = '0' + c%10;
   str[13] = ':';
   c = (char) lt.tm_min;
   str[14] = '0' + c/10;
   str[15] = '0' + c%10;
   str[16] = ':';
   c = (char) lt.tm_sec;
   str[17] = '0' + c/10;
   str[18] = '0' + c%10;
   str[19] = '.';
   i = (int) (td.tv_usec/1000);
   str[20] = '0' + ((char)(i/100));
   c = (char) (i%100);
   str[21] = '0' + c/10;
   str[22] = '0' + c%10;
   str[23] = '\0';

   return str;
   }

/********************************************************************************************/
/********************************************************************************************/

extern void gpiblog_logstr( char type, char* str )
   {
   FILE *file;

   if( !str )
      return;

   /* lock the logfile */
#ifdef HAVE_PTHREAD
   pthread_mutex_lock( &logfile_mutex );
#endif

   if( !logfile_name )
      logfile_name = default_logfile_name;

   file = fopen( logfile_name, "a" );
   if( !file )
      {
      /* unlock the logfile */
#ifdef HAVE_PTHREAD
      pthread_mutex_unlock( &logfile_mutex );
#endif
      return;
      }

   if( global_loglvl & GPIB_LOGTS )
      fprintf( file, "%s\t\t%c\t%s\n", gpiblog_ts(), type, str );
   else
      fprintf( file, "\t%c\t%s\n", type, str );
   fclose( file );

   /* unlock the logfile */
#ifdef HAVE_PTHREAD
   pthread_mutex_unlock( &logfile_mutex );
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

static void gpiblog_ibwrt( int ud, char *str )
   {
   char *ptr = strdup( str );
   char *p2 = ptr + strlen( str ) - 1;
   char *msg;

   /* remove trailing control characters */
   while( (p2 > ptr) && (*p2 < ' ') )
      {
      *p2 = '\0';
      p2--;
      }

   if( global_loglvl & GPIB_LOGBUSEXT )
      {
      msg = (char*) gpib_malloc( sizeof(char) * (strlen( ptr )+35) );
      sprintf( msg, "(0x%x)\tWRITE(%d): %s", get_ibsta(), ud, ptr );
      gpiblog_logstr( 'X', msg );
      free((void*)msg);
      }
   else
      {
      msg = (char*) gpib_malloc( sizeof(char) * (strlen( ptr )+20) );
      sprintf( msg, "WRITE(%d): %s", ud, ptr );
      gpiblog_logstr( 'B', msg );
      free((void*)msg);
      }

   free((void*)ptr);
   }

/********************************************************************************************/
/********************************************************************************************/

static void gpiblog_ibrd( int ud, char *str )
   {
   char *ptr = strdup( str );
   char *p2 = ptr + strlen( str ) - 1;
   char *msg;

   /* remove trailing control characters */
   while( (p2 > ptr) && (*p2 < ' ') )
      {
      *p2 = '\0';
      p2--;
      }

   if( global_loglvl & GPIB_LOGBUSEXT )
      {
      msg = (char*) gpib_malloc( sizeof(char) * (strlen( ptr )+35) );
      sprintf( msg, "(0x%x)\tREAD(%d): %s", get_ibsta(), ud, ptr );
      gpiblog_logstr( 'X', msg );
      free((void*)msg);
      }
   else
      {
      msg = (char*) gpib_malloc( sizeof(char) * (strlen( ptr )+20) );
      sprintf( msg, "READ(%d): %s", ud, ptr );
      gpiblog_logstr( 'B', msg );
      free((void*)msg);
      }

   free((void*)ptr);
   }

/********************************************************************************************/
/********************************************************************************************/

static void gpiblog_ibrsp( int ud, char b )
   {
   char msg[100];
   if( global_loglvl & GPIB_LOGBUSEXT )
      {
      sprintf( msg, "(0x%x)\tSPOLL(%d): %c", get_ibsta(), ud, (short) b );
      gpiblog_logstr( 'X', msg );
      }
   else
      {
      sprintf( msg, "SPOLL(%d): %c", ud, (short) b );
      gpiblog_logstr( 'B', msg );
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static void gpiblog_ibclr( int ud )
   {
   char msg[100];
   if( global_loglvl & GPIB_LOGBUSEXT )
      {
      sprintf( msg, "(0x%x)\tCLEAR(%d)", get_ibsta(), ud );
      gpiblog_logstr( 'X', msg );
      }
   else
      {
      sprintf( msg, "CLEAR(%d)", ud );
      gpiblog_logstr( 'B', msg );
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static void gpiblog_ibtrg( int ud )
   {
   char msg[100];
   if( global_loglvl & GPIB_LOGBUSEXT )
      {
      sprintf( msg, "(0x%x)\tTRIGGER(%d)", get_ibsta(), ud );
      gpiblog_logstr( 'X', msg );
      }
   else
      {
      sprintf( msg, "TRIGGER(%d)", ud );
      gpiblog_logstr( 'B', msg );
      }
   }

