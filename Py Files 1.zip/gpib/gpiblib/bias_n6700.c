#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <instr/instr.h>

/* supported models */
enum {
   N6736,
   N6746,
   N6762,
   N6784,
};

typedef struct
{
   struct timeval trig_time;
   unsigned delay;
} TIMING_INFO;

static int init_bias( instr_bias_t *bias );
static int close( instr_bias_t *bias );
static int set_bias( instr_bias_t *b, int mode, double src, double compl, int res, double max_range, unsigned delay );
static int read_bias( instr_bias_t *b, double *src, double *meas );
static int turn_off_bias( instr_bias_t *b );
static int trigger( instr_bias_t *b );

static void get_source_and_compl( int type, int mode, double src, double compl, double srange, double *s, double *c, double* sr, double* mr );
static void get_ranges( int type, int mode, double s, double c, double srange, double* sr, double* mr );

static char *lib_version = "1.0.0";
static char *lib_text = "Driver for the Agilent N6700-series Modular DC Power Analyzer.";

/*********************************************************************************/
/*********************************************************************************/
/* this is the only exported routine */

extern int instr_load( gpib_instr_t inst )
{
   instr_bias_t* bias;

   if( gpib_instr_gettype( inst ) != INSTR_BIAS )
   {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
   }

   bias = (instr_bias_t*) inst;

   /* initialize the driver methods */
   bias->open = init_bias;
   bias->close = close;
   bias->set_bias = set_bias;
   bias->read_bias = read_bias;
   bias->trigger = trigger;
   bias->bias_off = turn_off_bias;

   /* set the library version and text fields */
   bias->libver = lib_version;
   bias->libtext = lib_text;

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int init_bias( instr_bias_t *bias )
{
    char cmd[128], buf[256];
    int e, nchans;
    TIMING_INFO *inf;

    /* check for a valid channel # */
    if( bias->chan < 1 || bias->chan > 4 )
    {
        sprintf( buf, "Chan %d is invalid.  It must be 1, 2, 3, or 4.", bias->chan );
        gpib_seterror( bias->name, buf );
        return EGPIB_INSTRERROR;
    }    
    
    /* create the device descriptor */
    e = gpib_getud( &bias->ud, bias->bidx, bias->addr, bias->tmo, 1, 0 );
    if( e )
        return e;

    /* initialize the timing info structure */
    inf = (TIMING_INFO*) gpib_malloc( sizeof(TIMING_INFO) );
    inf->delay = 0;
    bias->udata = (void*) inf;

    /* initialize the driver methods */
    bias->set_bias = set_bias;
    bias->read_bias = read_bias;
    bias->trigger = trigger;
    bias->bias_off = turn_off_bias;
    bias->close = close;

    /* clear the instrument */
    e = gpib_clear( bias->ud );
    if( e )
        return e;
    
    /* query the mainframe an validate the model */
    e = gpib_ask( bias->ud, "*IDN?", buf, 255 );
    if( e )
        return e;
    
    if( !strstr(buf,"Agilent") || !strstr(buf,"N670") ) {
        gpib_seterror( bias->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
        return EGPIB_BADDEVICE;
    }
    
    /* make sure that the module is installed */
    e = gpib_ask( bias->ud, ":SYST:CHAN?", buf, 255 );
    if( e )
        return e;
    nchans = atoi(buf);

    if( bias->chan > nchans )
    {
        sprintf(buf, "Module %d is not installed.", bias->chan);
        gpib_seterror(bias->name, buf);
        return EGPIB_INSTRERROR;
    }
    
    /* query the module and get its model number */
    sprintf(cmd, ":SYST:CHAN:MOD? (@%d)", bias->chan);
    e = gpib_ask(bias->ud, cmd, buf, 255);
    if( e )
        return e;
    
    /* make sure the module is supported and store the module */
    if( strstr(buf,"N6736") ) {
        bias->type = N6736;
    }
    else if( strstr(buf,"N6746") ) {
        bias->type = N6746;    
    }
    else if( strstr(buf,"N6762") ) {
        bias->type = N6762;
    }
    else if( strstr(buf,"N6784") ) {
        bias->type = N6784;
    }
    else {
        bias->type = -1;
        gpib_seterror( bias->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
        return EGPIB_BADDEVICE;
    }
   
    /* make sure the output is off */
    sprintf(cmd, "OUTP 0, (@%d)", bias->chan);
    e = gpib_write(bias->ud, cmd);
    if( e )
        return e;
        
    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int close( instr_bias_t *bias )
{
    if( bias->mode )
        /* need to shut off */
        turn_off_bias( bias );

    /* take the device descriptor offline */
    gpib_golocal( bias->ud );
    gpib_freeud( bias->ud );
    bias->ud = -1;

    /* free the timing info structure */
    if( bias->udata )
        free((void*)bias->udata);
    bias->udata = NULL;

    return 0;
}

/*********************************************************************************/
/*********************************************************************************/
// note that the res parameter is ignored for this driver

static int set_bias( instr_bias_t *bias, int mode, double src, double compl, int res, double max_range, unsigned delay )
{
   char buf[256];
   char *sfunc, *mfunc;
   int turn_on = 0;
   double s, c, sr, mr;
   int e;

    if( bias->mode != mode )
    {
        /* biasing mode has changed */
        if( !bias->mode )
            /* supply is off, need to turn it on */
            turn_on = 1;
        else if( !mode )
            /* supply is on, need to shut it off */
            return turn_off_bias(bias);
    }

    /* bias mode is off */
    if( !mode )
        return 0;

    /* get the corrected values for source and compliance (supply dependent) */
    get_source_and_compl( bias->type, mode, src, compl, max_range, &s, &c, &sr, &mr );

    if( mode == SRC_VOLTAGE ) {
        sfunc = "VOLT";
        mfunc = "CURR";
    }
    else {
        sfunc = "CURR";
        mfunc = "VOLT";
    }
    
    /* set the source and compliance parameters */
    if( bias->type == N6784 ) {
        // N6784A has a different command set and different capabilities
        
        if( bias->mode != mode ) {
            // need to shut off supply before changing mode
            e = turn_off_bias(bias);
            if(e)
                return e;
            turn_on = 1;
            
            // set the new source function
            sprintf(buf, "FUNC %s, (@%d)", sfunc, bias->chan);
            e = gpib_write( bias->ud, buf );
            if( e )
                return e;            
        }
        
        // set the source and limit values
        sprintf(buf, ":%s:LIM:COUP 1, (@%d); :%s:LIM %.4e, (@%d); :SENS:%s:RANG %.4e, (@%d); :%s:RANG %.4e, (@%d); :%s %.4e, (@%d)",
            mfunc, bias->chan, mfunc, c, bias->chan, mfunc, mr, bias->chan, sfunc, sr, bias->chan, sfunc, s, bias->chan);
        e = gpib_write( bias->ud, buf );
        if( e )
            return e;
        /* source settling time */
        ms_delay( 30 );        
    }
    else {
        // the rest of the modules are programmed more like power supplies
        sprintf(buf, ":%s:RANG %.4e, (@%d); :%s %.4e, (@%d); :%s:RANG %.4e, (@%d); :%s %.4e, (@%d)",
            mfunc, mr, bias->chan, mfunc, c, bias->chan, sfunc, sr, bias->chan, sfunc, s, bias->chan);
        e = gpib_write( bias->ud, buf );
        if( e )
            return e;
        /* source settling time */
        ms_delay( 30 );
    }
    
    /* store new values of instrument parameters */
    bias->mode = mode;
    bias->source = s;
    bias->compliance = c;
    bias->resolution = res;
    bias->triggered = 0;
    ((TIMING_INFO*)bias->udata)->delay = delay;

    /* place the SMU in operate mode if it is in standby */
    if( turn_on )
    {
        sprintf(buf, "OUTP 1, (@%d)", bias->chan);
        e = gpib_write( bias->ud, buf );
        if( e )
            return e;
        /* turn on time */
        ms_delay( 60 );
    }

    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int trigger( instr_bias_t *bias )
{
    if( !bias->mode )
        return 0;

    gettimeofday( &(((TIMING_INFO*)bias->udata)->trig_time), NULL );
    bias->triggered = 1;

    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int read_bias( instr_bias_t *bias, double *src, double *meas )
{
   char cmd[128], buf[128];
   struct timeval tcurrent;
   long elapsed_ms = 0;
   TIMING_INFO *inf = (TIMING_INFO*) bias->udata;
   int e;
   int c = 0;
   int stat;

    if( !bias->mode )
    {
        if (src)
            *src = 0.0;
        if (meas)
            *meas = 0.0;
        return 0;
    }
    else if( !bias->triggered )
    {
        e = trigger( bias );
        if( e )
            return e;
    }

   /* wait for the measurement delay to expire */
    while( elapsed_ms < (long) inf->delay )
    {
        gettimeofday( &tcurrent, NULL );
        elapsed_ms = (tcurrent.tv_sec - inf->trig_time.tv_sec)*1000 + (tcurrent.tv_usec - inf->trig_time.tv_usec)/1000;
    }

    /* reset the trigger flag */
    bias->triggered = 0;
    
    /* read the operation status register */
    sprintf(cmd, ":STAT:OPER:COND? (@%d)", bias->chan);
    e = gpib_ask(bias->ud, cmd, buf, 127);
    if( e )
        return e;
    stat = atoi(buf);

    /* read the output voltage */
    if( (bias->mode == SRC_VOLTAGE && src) || (bias->mode == SRC_CURRENT && meas) )
    {
        sprintf(cmd, ":MEAS:VOLT? (@%d)", bias->chan);
        e = gpib_ask(bias->ud, cmd, buf, 127);
        if( e )
            return e;
            
        if( bias->mode == SRC_VOLTAGE )
            *src = atof(buf);
        else
            *meas = atof(buf);
    }

    /* read the output current */
    if( (bias->mode == SRC_CURRENT && src) || (bias->mode == SRC_VOLTAGE && meas) )
    {
        sprintf(cmd, ":MEAS:CURR? (@%d)", bias->chan);
        e = gpib_ask(bias->ud, cmd, buf, 127);
        if( e )
            return e;
            
        if( bias->mode == SRC_CURRENT )
            *src = atof(buf);
        else
            *meas = atof(buf);
    }
    
    /* check for "compliance" */
    if( (bias->mode == SRC_CURRENT && (stat&1) ) || (bias->mode == SRC_VOLTAGE && (stat&2) ) )
        c = 1;

    return c;
}

/*********************************************************************************/
/*********************************************************************************/

static int turn_off_bias( instr_bias_t *bias )
{
    char buf[32];
    int e;

    if( !bias->mode )
        return 0;

    bias->mode = SRC_OFF;
    sprintf(buf, "OUTP 0, (@%d)", bias->chan);
    e = gpib_write(bias->ud, buf);
    if( e )
        return e;
    
    // turn off delay
    ms_delay( 50 );
    return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static void get_source_and_compl( int type, int mode, double src, double compl, double srange, double *s, double *c, double* sr, double* mr )
{
    double abssrc = fabs(src);
    compl = fabs(compl);
    *s = src;
    *c = compl;

    if( mode == SRC_VOLTAGE )
    {
        if( type == N6784 )
        {
            if( src > 20. )
                *s = 20.;
            else if( src < -20. )
                *s = -20.;
            
            if( abssrc <= 6. ) {
                if( compl > 3. )
                    *c = 3.;
            }
            else {
                if( compl > 1. )
                    *c = 1.;
            }
        }
        else if( type == N6762 )
        {
            *s = abssrc;
            if( abssrc > 50. )
                *s = 50.;
            if( compl > 3. )
                *c = 3.;
        }
        else if( type == N6736 )
        {
            *s = abssrc;
            if( abssrc > 100. )
                *s = 100.;
            if( compl > 0.5 )
                *c = 0.5;
        }
        else if( type == N6746 )
        {
            *s = abssrc;
            if( abssrc > 100. )
                *s = 100.;
            if( compl > 1. )
                *c = 1.;
        }
    }
    else  // mode == SRC_CURRENT 
    {
        if( type == N6784 )
        {
            if( src > 3. )
                *s = 3.;
            else if( src < -3. )
                *s = -3.;
            
            if( abssrc <= 1. ) {
                if( compl > 6. )
                    *c = 6.;
            }
            else {
                if( compl > 20. )
                    *c = 20.;
            }
        }
        else if( type == N6762 )
        {
            *s = abssrc;
            if( abssrc > 3. )
                *s = 3.;
            if( compl > 50. )
                *c = 50.;
        }
        else if( type == N6736 )
        {
            *s = abssrc;
            if( abssrc > 0.5 )
                *s = 0.5;
            if( compl > 100. )
                *c = 100.;
        }
        else if( type == N6746 )
        {
            *s = abssrc;
            if( abssrc > 1. )
                *s = 1.;
            if( compl > 100. )
                *c = 100.;
        }
    }
    
    get_ranges(type, mode, *s, *c, srange, sr, mr);    
}

/*********************************************************************************/
/*********************************************************************************/

static void get_ranges( int type, int mode, double s, double c, double srange, double* sr, double* mr )
{
    double abssrc = fabs(s);
    if( srange != AUTO_RANGE )
        abssrc = fabs(srange);

    if( mode == SRC_VOLTAGE )
    {
        if( type == N6784 )
        {
            if( abssrc > 6. )
                *sr = 20.;
            else
                *sr = 6.;
            
            if( c > 1. )
                *mr = 3.;
            else if( c > 0.1 )
                *mr = 1.;
            else if( c > 0.01 )
                *mr = 0.1;
            else
                *mr = 0.01;
        }
        else if( type == N6762 )
        {
            if( abssrc > 5. )
                *sr = 50.;
            else
                *sr = 5.;
            
            if( c > 0.1 )
                *mr = 3.;
            else
                *mr = 0.1;
        }
        else if( type == N6736 )
        {
            *sr = 100.;
            *mr = 0.5;
        }
        else if( type == N6746 )
        {
            *sr = 100.;
            *mr = 1.0;
        }
    }
    else  // mode == SRC_CURRENT
    {
        if( type == N6784 )
        {
            if( abssrc > 1. )
                *sr = 3.;
            else if( abssrc > 0.1 )
                *sr = 1.;
            else if( abssrc > 0.01 )
                *sr = 0.1;
            else
                *sr = 0.01;
            
            if( c > 6. )
                *mr = 20.;
            else
                *mr = 6.;
        }
        else if( type == N6762 )
        {
            if( abssrc > 0.1 )
                *sr = 3.;
            else
                *sr = 0.1;
            
            if( c > 5. )
                *mr = 50.;
            else
                *mr = 5.;
        }
        else if( type == N6736 )
        {
            *sr = 100.;
            *mr = 0.5;
        }
        else if( type == N6746 )
        {
            *sr = 100.;
            *mr = 1.0;
        }
    }
}

