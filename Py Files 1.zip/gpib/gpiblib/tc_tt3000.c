#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <instr/instr.h>

static int open_tc( instr_tc_t *tc );
static int close_tc( instr_tc_t *tc );
static int set_temp( instr_tc_t *tc, double temp );
static int read_temp( instr_tc_t *tc, double *temp );
static int shutdown( instr_tc_t *tc );

/******************************************************************************************/
/******************************************************************************************/

extern int instr_load( gpib_instr_t inst )
   {
   instr_tc_t* tc;

   if( gpib_instr_gettype( inst ) != INSTR_TCONTROL )
      {
      gpib_seterror( inst, gpib_stderrmsg( EGPIB_WRONGINSTR ) );
      return EGPIB_WRONGINSTR;
      }

   tc = (instr_tc_t*) inst;

   /* initialize the driver methods */
   tc->open = open_tc;
   tc->close = close_tc;
   tc->set_temp = set_temp;
   tc->read_temp = read_temp;
   tc->shutdown = shutdown;

   /* set the library version and text fields */
   tc->libver = "1.0.0";
   tc->libtext = "Driver for the Temptronic 3000A thermo-chuck controller.";

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int open_tc( instr_tc_t *tc )
   {
   char buf[64];
   int e;

   /* create the device descriptor */
   e = gpib_getud( &tc->ud, tc->bidx, tc->addr, tc->tmo, 1, 0 );
   if( e )
      return e;

   /* clear the instrument */
   e = gpib_clear( tc->ud );
   if( e )
      return e;

   /* check the instrument ID string */
   e = gpib_write( tc->ud, "*IDN?" );
   if( e )
      return e;
   e = gpib_read( tc->ud, buf, 64 );
   if( e )
      return e;

   /* check that the instrument model is valid */
   if( !strstr( buf, "TP03000" ) )
      {
      gpib_seterror( tc->name, gpib_stderrmsg( EGPIB_BADDEVICE ) );
      return EGPIB_BADDEVICE;
      }

   /* set the temp controller to remote mode */
   e = gpib_write( tc->ud, "*RM" );
   if( e )
      return e;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int close_tc( instr_tc_t *tc )
   {
   /* set the temp controller to local mode */
   int e = gpib_write( tc->ud, "*GL" );
   if( e )
      return e;

   gpib_freeud( tc->ud );
   tc->ud = -1;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int set_temp( instr_tc_t *tc, double temp )
   {
   char buf[64];
   int e;

   /* set the temperature */
   sprintf( buf, "SETP %+.1f", temp );
   e = gpib_write( tc->ud, buf );
   if( e )
      return e;

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int read_temp( instr_tc_t *tc, double *temp )
   {
   char buf[64];
   int e;

   /* read the current temperature */
   e = gpib_write( tc->ud, "TEMP?" );
   if( e )
      return e;
   e = gpib_read( tc->ud, buf, 64 );
   if( e )
      return e;
   *temp = atof( buf );

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int shutdown( instr_tc_t *tc )
   {
   return gpib_write( tc->ud, "POWR 0" );
   }


