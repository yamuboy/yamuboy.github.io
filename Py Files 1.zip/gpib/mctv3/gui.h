#include <Xm/Xm.h>
#include <Xm/DialogS.h>
#include <Xm/BulletinB.h>
#include <Xm/LabelG.h>
#include <Xm/PushB.h>
#include <Xm/Text.h>
#include <Xm/Frame.h>
#include <Xm/Form.h>
#include <Xm/RowColumn.h>
#include <Xm/SeparatoG.h>
#include <Xm/MenuShell.h>
#include <Xm/ToggleB.h>
#include <Xm/PanedW.h>
#include "common.h"

#ifndef MCT_GUI_DEF
#define MCT_GUI_DEF

// parameter types
#define TYPE_STRING       1
#define TYPE_REAL         2
#define TYPE_INT          3
#define TYPE_UNSIGNED     4
#define TYPE_BOOL         5

typedef struct
{
   Widget shell, bulletin, pane;
} MCT_DIALOG;

typedef struct
{
   char *txt;
   void (*cb) ();
   void *data;
   Widget w;
} ACTION_AREA_ITEMS;

typedef struct
{
   char *name;
   int type;
   void *data;
} SAVE_LOAD_VALUES;

typedef struct
{
   Widget parent;
   Widget entry;
   char *path;
   char *pattern;
   int dir_flag;
   void (*cb) ();
   void *cb_data;
} BROWSE_INFO;

typedef struct
{
   Widget parent;
   Widget entry;
} EDIT_TEXT_FILE;

/***** Function Prototypes *****/

/* from gui_run_gpib.c */
extern void start_gpib_thread( Widget main_w, MAIN_DATA *d, XtAppContext app_context );

/* from gui_set_bias.c */
extern void db_setup_bias (Widget parent, MAIN_DATA *d, int test_type);

/* from gui_edit_header.c */
extern void db_edit_header (Widget parent, MAIN_DATA *d);

/* from gui_fet_params.c */
extern void db_fet_device_parameters (Widget parent, MAIN_DATA *d);

/* from gui_bjt_params.c */
extern void db_bjt_device_parameters (Widget parent, MAIN_DATA *d);

/* from gui_instruments.c */
extern void db_instrument_setup (Widget parent, MAIN_DATA *d);

/* from gui_tcontrol.c */
extern void db_tcontrol_setup (Widget parent, MAIN_DATA *d);

/* from gui_multisite.c */
extern void db_multisite_setup (Widget parent, MAIN_DATA *d);

/* from gui_save_load.c */
extern void db_load_config (Widget parent, MAIN_DATA *d);
extern void db_save_config (Widget parent, MAIN_DATA *d);

/* from gui_load_enr.c */
extern void db_load_enr (Widget parent, MAIN_DATA *d);

/* from gui_about.c */
extern void db_about (Widget parent);

/* from gui_calcoeff.c */
extern void db_cal_coeffs( Widget parent, MAIN_DATA * d );

/* from gui_utils.c */
extern MAIN_DATA mainDataDefaults (void);
extern void cb_browse_dialog (Widget w, XtPointer client_data, XtPointer call_data);
extern void cb_edit_text_file_dialog (Widget w, XtPointer client_data, XtPointer call_data);
extern void cb_destroy_widget (Widget w, XtPointer client_data, XtPointer call_data);
extern void db_error_message (char *msg, Widget parent);
extern void db_warning_message (char *msg, Widget parent);
extern void db_info_message (char *msg, Widget parent);
extern Widget get_top_shell (Widget w);
extern XmString create_Xm_string (char *string);
extern Widget create_text_entry_row (Widget parent, char *label, int n_cols, int max_len, char *val);
extern Widget create_label_gadget (Widget parent, char *txt);
extern Widget create_push_button (Widget parent, char *label);
extern Widget create_toggle (Widget parent, char *label, unsigned state);
extern Widget create_dialog_shell (Widget parent, MCT_DIALOG *d, char *name, char *title);
extern void popup_dialog_shell (MCT_DIALOG *d);
extern void create_dialog_action_area (Widget parent, ACTION_AREA_ITEMS *action, unsigned n_items, unsigned tightness, unsigned h_offset);
extern void create_dialog_ok_cancel (Widget parent, char *txt1, Widget *button1, char *txt2, Widget *button2);
extern void get_value_from_textbox (Widget w, int type, void *ptr);
extern unsigned get_toggle_state (Widget w);
extern char *get_str_from_dbl (double x);

/* from main.c */
extern void cb_start_gpib (Widget w, XtPointer client_data, XtPointer call_data);
extern void cb_update_mainw (Widget w, XtPointer client_data, XtPointer call_data);

#endif

