// this header contains a variable initialization for a
// vector of SAVE_LOAD_VALUES structures named save_load_v.
// This uses a global pointer to the main data structure
//  named pMainData of type MAIN_DATA

SAVE_LOAD_VALUES save_load_v[] = {
   {"Instrument-gpib_bd", TYPE_INT, &pMainData->inst_info.gpib_board},
   {"Instrument-bias1_dl", TYPE_STRING, pMainData->inst_info.bias1_dl},
   {"Instrument-bias2_dl", TYPE_STRING, pMainData->inst_info.bias2_dl},
   {"Instrument-vna_dl", TYPE_STRING, pMainData->inst_info.vna_dl},
   {"Instrument-nfm_dl", TYPE_STRING, pMainData->inst_info.nfm_dl},
   {"Instrument-ap_dl", TYPE_STRING, pMainData->inst_info.ap_dl},
   {"Instrument-tc_dl", TYPE_STRING, pMainData->inst_info.tc_dl},
   {"Instrument-bias1_addr", TYPE_INT, &pMainData->inst_info.bias1_addr},
   {"Instrument-bias2_addr", TYPE_INT, &pMainData->inst_info.bias2_addr},
   {"Instrument-vna_addr", TYPE_INT, &pMainData->inst_info.vna_addr},
   {"Instrument-nfm_addr", TYPE_INT, &pMainData->inst_info.nfm_addr},
   {"Instrument-ap_addr", TYPE_INT, &pMainData->inst_info.ap_addr},
   {"Instrument-tc_addr", TYPE_INT, &pMainData->inst_info.tc_addr},
   {"Instrument-bias1_chan", TYPE_INT, &pMainData->inst_info.bias1_chan},
   {"Instrument-bias2_chan", TYPE_INT, &pMainData->inst_info.bias2_chan},
   {"Instrument-vna_chan", TYPE_INT, &pMainData->inst_info.vna_chan},
   {"Instrument-nfm_chan", TYPE_INT, &pMainData->inst_info.nfm_chan},
   {"Instrument-ap_chan", TYPE_INT, &pMainData->inst_info.ap_chan},
   {"Instrument-tc_chan", TYPE_INT, &pMainData->inst_info.tc_chan},
   {"Instrument-bias1_tmo", TYPE_INT, &pMainData->inst_info.bias1_tmo},
   {"Instrument-bias2_tmo", TYPE_INT, &pMainData->inst_info.bias2_tmo},
   {"Instrument-vna_tmo", TYPE_INT, &pMainData->inst_info.vna_tmo},
   {"Instrument-nfm_tmo", TYPE_INT, &pMainData->inst_info.nfm_tmo},
   {"Instrument-ap_tmo", TYPE_INT, &pMainData->inst_info.ap_tmo},
   {"Instrument-tc_tmo", TYPE_INT, &pMainData->inst_info.tc_tmo},
   {NULL, -1, NULL}
};
unsigned sz_save_load_v = siz(save_load_v);


