#include "gui.h"
#include "threads.h"

/********************************************************************************** 
MODULE INFO

use threads to form a boss/worker model, where the boss will be the
main thread that handles the X11 overhead and the worker will be the thread
that does the instrument I/O, a third thread will be started to wait for the
worker thread to exit and inform the main thread - this is done to prevent a loss
in synchronization in the case that the worker thread is signalled or otherwise
terminates abnormally

using POSIX threads from the pthreads library

************************************************************************************/

/* Xt thread monitoring interval in milliseconds - this is the rate at which the
measurement dialog box will be updated */
#define MONITOR_INTERVAL     500     

/* data passed to the various Xt callback functions */
typedef struct
{
   XtAppContext app_c;
   Widget dialog, main_w;
   Widget test_type, test_func;
   Widget test_stat, multi_stat;
   Widget abort_button;
   THREAD_SHARE *share;
} MONITOR_DATA;

/* global_variables */
static pthread_mutex_t global_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_t global_gpib_thread;
static pthread_t global_monitor_thread;
static int gpib_thread_exited;
static char *global_error_string;

/* protoypes */
static void *start_gpib_main( void *t );
static void *monitor_gpib_exit( void *t );
static void cb_monitor_worker_thread( XtPointer client_data, XtIntervalId *id );
static void cb_abort_worker_thread( Widget w, XtPointer client_data, XtPointer call_data );

/* from gpib_main.c */
extern char *gpib_main( GPIB_THREAD_DATA *thread_data );

/********************************************************************************/
/********************************************************************************/

extern void start_gpib_thread( Widget main_w, MAIN_DATA *d, XtAppContext app_context )
{
   char *title = "Measuring...";
   char *name = "DialogMeasuring";
   int n_stat_chars = 35;
   Widget pane, stat_col, lab, form;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action;
   static MONITOR_DATA monitor;
   static GPIB_THREAD_DATA gpib_data;
   static THREAD_SHARE share;

   /* initialize the monitoring work procedure data */
   monitor.main_w = main_w;
   monitor.app_c = app_context;
   monitor.share = &share;

   /* initialize the GPIB thread data structure */
   gpib_data.mutex = &global_mutex;
   gpib_data.share = &share;
   gpib_data.main_data = d;

   /* initialize the shared thread data structure */
   share.abort_flag = 0;
   share.test_type = NULL;
   share.test_function = NULL;
   share.test_status = NULL;
   share.multisite_status = NULL;

   /* initialize the exit monitor flag and error string */
   gpib_thread_exited = 0;
   global_error_string = NULL;

   /* create the measurement dialog */

   pane = create_dialog_shell (main_w, &dialog, name, title);
   monitor.dialog = dialog.shell;

   stat_col = XtVaCreateWidget ("row_col", xmRowColumnWidgetClass, pane,
      NULL);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, stat_col, NULL);
   lab = create_label_gadget (form, "Test Type:        ");
   XtVaSetValues (lab, XmNleftAttachment, XmATTACH_FORM, XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM, NULL);
   monitor.test_type = XtVaCreateManagedWidget ("textbox", xmTextWidgetClass, form,
      XmNcolumns, n_stat_chars,
      XmNeditable, False,
      XmNcursorPositionVisible, False,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, lab,
      NULL);
   XtManageChild (form);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, stat_col, NULL);
   lab = create_label_gadget (form, "Test Function:    ");
   XtVaSetValues (lab, XmNleftAttachment, XmATTACH_FORM, XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM, NULL);
   monitor.test_func = XtVaCreateManagedWidget ("textbox", xmTextWidgetClass, form,
      XmNcolumns, n_stat_chars,
      XmNeditable, False,
      XmNcursorPositionVisible, False,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, lab,
      NULL);
   XtManageChild (form);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, stat_col, NULL);
   lab = create_label_gadget (form, "Test Status:      ");
   XtVaSetValues (lab, XmNleftAttachment, XmATTACH_FORM, XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM, NULL);
   monitor.test_stat = XtVaCreateManagedWidget ("textbox", xmTextWidgetClass, form,
      XmNcolumns, n_stat_chars,
      XmNeditable, False,
      XmNcursorPositionVisible, False,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, lab,
      NULL);
   XtManageChild (form);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, stat_col, NULL);
   lab = create_label_gadget (form, "Multisite Status: ");
   XtVaSetValues (lab, XmNleftAttachment, XmATTACH_FORM, XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM, NULL);
   monitor.multi_stat = XtVaCreateManagedWidget ("textbox", xmTextWidgetClass, form,
      XmNcolumns, n_stat_chars,
      XmNeditable, False,
      XmNcursorPositionVisible, False,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, lab,
      NULL);
   XtManageChild (form);

   XtManageChild (stat_col);

   /* create the action area */
   action.txt = "Abort";
   action.cb = cb_abort_worker_thread;
   action.data = &monitor;
   create_dialog_action_area (pane, &action, 1, 10, 30);
   monitor.abort_button = action.w;

   /* pop up the dialog */
   popup_dialog_shell( &dialog );

   /* create the GPIB worker thread */
   if( pthread_create( &global_gpib_thread, NULL, start_gpib_main, (void*)&gpib_data ) )
   {
      XtDestroyWidget( dialog.shell );
      db_error_message ("start_gpib_thread(): thread creation failed.", main_w);
      return;
   }

   /* add an Xt timed work procedure for monitoring the status of the worker thread */
   XtAppAddTimeOut (app_context, MONITOR_INTERVAL, cb_monitor_worker_thread, (XtPointer) &monitor);
}

/****************************************************************************/
/****************************************************************************/

static void *start_gpib_main( void *t )
{
   /* create another thread to monitor the exit status of the gpib thread */
   if( pthread_create( &global_monitor_thread, NULL, monitor_gpib_exit, NULL ) )
   {
      /* thread creation failed!!! */
      fprintf( stderr, "Fatal Error: monitor thread creation failed.\n" );
      exit( 1 );
   }

   /* run gpib_main(), the return value of this will be used as an error message
   if it is non-NULL
   the thread will implicitly call pthread_exit( ) with the return value
   of gpib_main() when it exits
   */
   return (void*) gpib_main( (GPIB_THREAD_DATA*)t );
}

/****************************************************************************/
/****************************************************************************/

static void *monitor_gpib_exit( void *t )
{
   void *retval = NULL;

   /* wait for the GPIB thread to exit */
   if( pthread_join( global_gpib_thread, &retval ) )
   {
      fprintf( stderr, "Fatal Error: unable to join GPIB thread.\n" );
      exit(1);
   }

   /* grab the global_mutex */
   pthread_mutex_lock( &global_mutex ); 

   /* flag the GPIB thread as being finished */
   gpib_thread_exited = 1;

   if( retval )
      global_error_string = (char *) retval;

   /* unlock the global mutex */
   pthread_mutex_unlock( &global_mutex );

   /* exit the thread, this implicitly calls pthread_exit( NULL ) */
   return NULL;
}

/********************************************************************************/
/********************************************************************************/

static void cb_monitor_worker_thread( XtPointer client_data, XtIntervalId *id )
{
   MONITOR_DATA *d = (MONITOR_DATA *) client_data;

   /* lock the mutex */
   pthread_mutex_lock( &global_mutex ); 

   if( gpib_thread_exited )
   {
      /* GPIB thread has exited, monitor thread must have exited also */

      /* join the monitor thread */
      if( pthread_join( global_monitor_thread, NULL ) )
      {
         fprintf( stderr, "Fatal Error: unable to join monitoring thread.\n" );
         exit(1);
      }

      /* destroy the measurement status dialog */
      XtDestroyWidget( d->dialog );

      /* if an error occured, display an error dialog */
      if( global_error_string )
      {
         db_error_message( global_error_string, d->main_w );
         mct_free( (void*) global_error_string );
      }

      /* free any left over string memory */
      mct_free( (void*)d->share->test_type );
      mct_free( (void*)d->share->test_function );
      mct_free( (void*)d->share->test_status );
      mct_free( (void*)d->share->multisite_status );

      /* unlock the mutex */
      pthread_mutex_unlock( &global_mutex );

      /* we are done monitoring, do not re-create the work procedure timer */
      return;
   }
   else if( d->share->abort_flag )
   {
      /* GPIB thread has been sent the abort flag, do not set new values for status strings */

      /* unlock the mutex */
      pthread_mutex_unlock( &global_mutex ); 

      /* re-create the timer and return */
      XtAppAddTimeOut( d->app_c, MONITOR_INTERVAL, cb_monitor_worker_thread, client_data );
      return;
   }

   /* update the measurement status dialog */

   if( d->share->test_type )
      XmTextSetString( d->test_type, d->share->test_type );

   if( d->share->test_function )
      XmTextSetString( d->test_func, d->share->test_function );

   if( d->share->test_status )
      XmTextSetString( d->test_stat, d->share->test_status );

   if( d->share->multisite_status )
      XmTextSetString( d->multi_stat, d->share->multisite_status );

   /* unlock the mutex */
   pthread_mutex_unlock( &global_mutex );

   /* re-create the timer and return */
   XtAppAddTimeOut( d->app_c, MONITOR_INTERVAL, cb_monitor_worker_thread, client_data );
}

/********************************************************************************/
/********************************************************************************/

static void cb_abort_worker_thread (Widget w, XtPointer client_data, XtPointer call_data)
{
   MONITOR_DATA *d = (MONITOR_DATA *) client_data;

   /* lock the mutex */
   pthread_mutex_lock( &global_mutex );

   /* set the abort flag */
   d->share->abort_flag = 1;

   /* unlock the mutex */
   pthread_mutex_unlock( &global_mutex );

   /* modify the measurement dialog */
   XmTextSetString( d->test_stat, "Aborting..." );
   XtVaSetValues( d->abort_button, XmNsensitive, False, NULL );
}

