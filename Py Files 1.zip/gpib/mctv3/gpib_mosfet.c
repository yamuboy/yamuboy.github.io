#include "gpib.h"

/********************************************************************************/
/********************************************************************************/

extern int measure_mosfet_device (MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error)
   {



   return 0;
   }





#if (0)

   FILE *file;
   char string[300];
   int i;
   
   if ((meas_mode == DC_SHORT) || (meas_mode == NOISE))
      {
      strcpy (error,"Test does not exist.");
      return -1;
      }

   if (meas_mode != DC_SHORT)
      {
      if (file_exists (HeaderInfo.filename))
         {   
         sprintf (string,"mv -f %s %s_bak",HeaderInfo.filename,HeaderInfo.filename);
         system (string);
         }
      }
   
   file = fopen (HeaderInfo.filename,"w+");
   
   // write the header
   get_the_time (string);
   fprintf (file,"!FILE NAME: %s\n",HeaderInfo.filename);
   fprintf (file,"!MASK NAME: %s\n",HeaderInfo.maskname);
   fprintf (file,"!WAFER NUMBER: %s\n",HeaderInfo.wafer);
   fprintf (file,"!PROCESS NAME: %s\n",HeaderInfo.process);
   fprintf (file,"!DEVICE NAME: %s\n",HeaderInfo.device);
   fprintf (file,"!GATE PERIPHERY (um): %.1f\n",HeaderInfo.gate_periphery);
   fprintf (file,"!GATE LENGTH (um): %.3f\n",HeaderInfo.gate_length);
   fprintf (file,"!UNIT GATE WIDTH (um): %.1f\n",HeaderInfo.unit_gate_width);
   fprintf (file,"!NUMBER OF GATE FINGERS: %d\n",HeaderInfo.num_gate_fingers);
   fprintf (file,"!GATE TO GATE SPACING (um): %s\n",HeaderInfo.gate_to_gate);
   fprintf (file,"!SOURCE-DRAIN SPACING (um): %.1f\n",HeaderInfo.source_to_drain);
   fprintf (file,"!TEMPERATURE (C): %.1f\n",HeaderInfo.temperature);
   fprintf (file,"!DATE AND TIME: %s\n",string);
   fprintf (file,"!COMMENTS:\n");
   if (strlen(HeaderInfo.comments) > 0)
      {
      fputc ('!',file);
      for (i = 0; HeaderInfo.comments[i]; ++i)
         {
         fputc (HeaderInfo.comments[i],file);
         if (HeaderInfo.comments[i] == '\n')
            fputc ('!',file);
         }
      if (HeaderInfo.comments[i-1] != '\n')
         fputc ('\n',file);
      }
   fprintf (file,"!\n");
   fflush (file);
   
   drivers->put_nwa_in_hold (TestParams.gpibBrdAddr, TestParams.nwaAddr);
   
   /*
   if (ldmos_dc_parameters (file,HeaderInfo.gate_periphery,error))
      {
      fclose (file);
      return -1;
      }
   
   fflush (file);
   
   if (meas_mode == DC_SHORT)
      {
      fclose (file);
      return 0;
      }
   
   if (ABORT_TEST)
      {
      fclose (file);
      return -1;
      }
   */

   fprintf (file,"!               DC IV-CURVES\n");
   fprintf (file,"!   Vds        Ids          Vgs        Igs\n");
   fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");

   if (FETparams.doDCIV)
      {
      if (ldmos_dc_iv_curves (file,HeaderInfo.gate_periphery,error))
         {
         fclose (file);
         return -1;
         }
      }

   fflush (file);

   if (meas_mode == DC_FULL)
      {
      fclose (file);
      return 0;
      }

   /*
   if (cold_ldmos_s_parameters (file,HeaderInfo.gate_periphery,error))
   {
   fclose (file);
   return -1;
   }
   */

   if (ABORT_TEST)
      {
      fclose (file);
      return -1;
      }

   if (ldmos_s_parameters_over_bias (file,HeaderInfo.gate_periphery,error))
      {
      fclose (file);
      return -1;
      }   

   fclose (file);
   return 0;
   }


/******************************************************************************************/
/******************************************************************************************/

int ldmos_dc_iv_curves (FILE *file, double periphery, char *error)
   {
   double vgs_list[500];
   double vds_list[500];
   double drain_compliance,gate_compliance;
   double vds,vgs,ids,igs;
   double power_limit;
   int num_gate_biases = 0;
   int num_drain_biases = 0;
   int i,j,status;
   BIAS *bias;
   char buffer[100];
      
   update_test_status ("LDMOS DC I-V curves");
   
   for (vgs = LDMOSparams.VgStart; vgs < (LDMOSparams.VgStop + 0.5*LDMOSparams.VgStep); vgs += LDMOSparams.VgStep, ++num_gate_biases)
      vgs_list[num_gate_biases] = vgs;
      
   for (vds = 0.0; vds < (maxLDMOSratings.max_vds + 0.5*LDMOSparams.VdStep); vds += LDMOSparams.VdStep, ++num_drain_biases)
      vds_list[num_drain_biases] = vds;   
         
   power_limit = maxLDMOSratings.max_power*1.0e-3*periphery;
   drain_compliance = LDMOSparams.maxIds*1.0e-6*periphery;
   gate_compliance = LDMOSparams.maxIgs*1.0e-9*periphery;

   bias = drivers->open_bias_supply (TestParams.gpibBrdAddr, TestParams.gateBiasAddr, 
      TestParams.drainBiasAddr, T10s, T10s);
   if (!bias)
      {
      sprintf (error,"Failed to open the bias supplies.");
      return -1;
      }

   for (i = 0; i < num_gate_biases; ++i)
      {         
      for (j = 0; j < num_drain_biases; ++j)
         {       
         if (!j)
            drivers->turn_on_bias_supply (bias, SRC_VOLTAGE, SRC_VOLTAGE, GATE_FIRST, gate_compliance, drain_compliance, MEDIUM_RES);

         sprintf (buffer,"LDMOS DC I-V curves (Vg = %.3f V, Vd = %.2f V)",vgs_list[i],vds_list[j]);
         update_test_status (buffer);

         drivers->set_bias_auto (bias, vgs_list[i], vds_list[j], LDMOSparams.delay_ms);
         if (LDMOSparams.readIgs)
            status = drivers->read_bias (bias, &vgs, &igs, &vds, &ids);
         else
            {
            status = drivers->read_bias (bias, &vgs, NULL, &vds, &ids);
            igs = 0.0;
            }

         if (status & DRAIN_COMPLIANCE)
            break; 
         if (status & GATE_COMPLIANCE)
            continue;

         if (fabs (vds*ids) > power_limit)
            {
            fprintf (file,"%+.4e %+.4e %+.4e %+.4e\n",vds,ids,vgs,igs);
            break;
            }
         
         fprintf (file,"%+.4e %+.4e %+.4e %+.4e\n",vds,ids,vgs,igs);
         }

      fflush (file);

      drivers->turn_off_bias_supply (bias, DRAIN_FIRST);
      
      if (ABORT_TEST)
         {
         drivers->close_bias_supply (bias);
         return 0;
         }
      }
   
   drivers->close_bias_supply (bias);  
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

int ldmos_s_parameters_over_bias (FILE *file, double periphery, char *error)
   {
   double drain_compliance,gate_compliance;
   double power_limit;
   double vgs,vds,igs,ids;
   double vgs_list[100];
   double vds_list[100];
   int num_gate_biases = 0;
   int num_drain_biases = 0;
   int i,nn,ii,jj,status;
   POLAR sp[MAX_FREQS][4];
   double freq[MAX_FREQS];
   char buffer[100];
   NWA *nwa;
   BIAS *bias;
   
   update_test_status ("LDMOS [S]-Parameters");
   fprintf (file,"!                                         FET S-PARAMETERS\n");
   
   for (vgs = LDMOSparams.VgStart; vgs < (LDMOSparams.VgStop + 0.5*LDMOSparams.VgStep); vgs += LDMOSparams.VgStep, ++num_gate_biases)
      vgs_list[num_gate_biases] = vgs;   
      
   for (vds = 0.0; vds < (maxLDMOSratings.max_vds + 0.01); vds += 1.0, ++num_drain_biases)
      vds_list[num_drain_biases] = vds;
      
   power_limit = maxLDMOSratings.max_power*1.0e-3*periphery;
   drain_compliance = LDMOSparams.maxIds*1.0e-6*periphery;
   gate_compliance = LDMOSparams.maxIgs*1.0e-9*periphery;

   bias = drivers->open_bias_supply (TestParams.gpibBrdAddr, TestParams.gateBiasAddr, 
      TestParams.drainBiasAddr, T10s, T10s);
   if (!bias)
      {
      sprintf (error,"Failed to open the bias supplies.");
      return -1;
      }
   
   nwa = drivers->open_nwa (TestParams.gpibBrdAddr, TestParams.nwaAddr, T10s);
   if (!nwa)
      {
      sprintf (error, "Failed to open the NWA.");
      return -1;
      }

   if (drivers->get_nwa_freq_list (nwa, freq, MAX_FREQS) < 0)
      {
      sprintf (error, "Failed to read the NWA frequency list.");
      drivers->close_bias_supply (bias);
      drivers->close_nwa (nwa);
      return -1;
      }

   for (ii = 0; ii < num_gate_biases; ++ii)
      {
      for (jj = 0; jj < num_drain_biases; ++jj)
         {
         if (!jj)
            drivers->turn_on_bias_supply (bias, SRC_VOLTAGE, SRC_VOLTAGE, GATE_FIRST, gate_compliance, drain_compliance, HIGH_RES);
         
         sprintf (buffer,"LDMOS [S]-Parameters (Vg = %.2f V, Vd = %.1f V)",vgs_list[ii],vds_list[jj]);
         update_test_status (buffer);

         drivers->set_bias_auto (bias, vgs_list[ii], vds_list[jj], FETparams.delay_ms);
         status = drivers->read_bias (bias, &vgs, &igs, &vds, &ids);

         if (status & DRAIN_COMPLIANCE)
            break;
         else if (status & GATE_COMPLIANCE)
            continue;
         
         if ((nn = drivers->read_nwa_s_params (nwa,sp,MAX_FREQS,error)) < 0)
            {
            drivers->turn_off_bias_supply (bias, DRAIN_FIRST);
            drivers->close_bias_supply (bias);
            drivers->close_nwa (nwa);
            return -1;
            }
                  
         if (Deembeding.type)
            {
            if (deembed_s_params (freq, sp, nn, error))
               {
               drivers->turn_off_bias_supply (bias, DRAIN_FIRST);
               drivers->close_bias_supply (bias);
               drivers->close_nwa (nwa);
               return -1;
               }
            }
        
         fprintf (file,"!BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n",vds,ids,vgs,igs);
         fprintf (file,"!Frequency    S11-Mag      S11-Ang     S21-Mag      S21-Ang     S12-Mag      S12-Ang     S22-Mag      S22-Ang\n");
         
         for (i = 0; i < nn; ++i)
            {
            fprintf (file,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
               freq[i],
               sp[i][0].m,sp[i][0].a,
               sp[i][2].m,sp[i][2].a,
               sp[i][1].m,sp[i][1].a,
               sp[i][3].m,sp[i][3].a);
            }
         
         fflush (file);

         if (ABORT_TEST)
            {
            drivers->turn_off_bias_supply (bias, DRAIN_FIRST);
            drivers->close_bias_supply (bias);
            drivers->close_nwa (nwa);
            return 0;
            }
         
         if (fabs (vds*ids) > power_limit)
            break;
         }
      
      drivers->turn_off_bias_supply (bias, DRAIN_FIRST);
      }
   
   drivers->close_bias_supply (bias);
   drivers->close_nwa (nwa);
   return 0;
   }


#endif

