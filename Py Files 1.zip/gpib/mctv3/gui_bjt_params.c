#include "gui.h"
#include <Xm/Notebook.h>

typedef struct
{
   MAIN_DATA *d;
   Widget em_fingers, em_wid, em_len, em_spac;
   Widget max_vce, max_pow, max_ice, max_ibe, max_vbe, min_vrev;
   Widget do_beo, do_ceo, do_cbo, do_extscr, do_fwdg, do_revg, do_flyb;
   Widget do_dciv, do_hotsp, do_cbcsp, do_cbesp, do_sparams;
   Widget ibr, max_vbr, app_beta, vce_beta, ice_beta1, ice_beta2, ice_beta3, sp_vce, capsp_off;
   Widget gstart, gstop, fstart, fstop, iv_npts, hotsp_npts, sp_npts, delay;
} BJT_PARAMS_DB;

static void cb_update_bjt_params (Widget w, XtPointer client_data, XtPointer call_data);

/****************************************************************************/
/****************************************************************************/

extern void db_bjt_device_parameters (Widget parent, MAIN_DATA *d)
{
   char *title = "BJT Device Parameters";
   char *name = "DialogFETDeviceParams";
   Widget pane, notebook, page_col, frame;
   XmString text;
   char str[20];
   static BJT_PARAMS_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);

   // create the notebook
   notebook = XtVaCreateWidget ("notebook", xmNotebookWidgetClass, pane,
      XmNbindingType, XmNONE,
      XmNfirstPageNumber, 1,
      NULL);

   // notebook page 1 - device header

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 1,
      NULL);
   text = XmStringCreateLocalized ("Device Params");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 1,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   sprintf (str, "%u", d->bjt_device.num_em_fingers);
   db.em_fingers = create_text_entry_row (page_col, "Number of Emitter Fingers:", 4, 10, str);
   db.em_wid = create_text_entry_row (page_col, "Emitter Width (um):", 8, 15, get_str_from_dbl(d->bjt_device.em_width));
   db.em_len = create_text_entry_row (page_col, "Emitter Length (um):", 8, 15, get_str_from_dbl(d->bjt_device.em_length));
   db.em_spac = create_text_entry_row (page_col, "Emitter-Emitter Spacing (um):", 8, 25, d->bjt_device.em_spacing);

   XtManageChild (page_col);

   // notebook page 2 - max ratings

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 2,
      NULL);
   text = XmStringCreateLocalized ("Max Ratings");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 2,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   db.max_vce = create_text_entry_row (page_col, "Max Vce (V):", 8, 15, get_str_from_dbl(d->bjt_device.max_vce));
   db.max_pow = create_text_entry_row (page_col, "Max Power (kW/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.max_power));
   db.max_ice = create_text_entry_row (page_col, "Max Ice (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.max_ice));
   db.max_ibe = create_text_entry_row (page_col, "Max Ibe (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.max_ibe));
   db.max_vbe = create_text_entry_row (page_col, "Max Vbe (V):", 8, 15, get_str_from_dbl(d->bjt_device.max_vbe));
   db.min_vrev = create_text_entry_row (page_col, "Max V-reverse (V):", 8, 15, get_str_from_dbl(d->bjt_device.min_vrev));

   XtManageChild (page_col);

   // notebook page 3 - enable tests

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 3,
      NULL);
   text = XmStringCreateLocalized ("Enable Tests");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 3,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   text = XmStringCreateLocalized ("Enable Device Tests");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   db.do_beo = create_toggle (page_col, "BEO Breakdown", d->bjt_device.do_beo_breakdown);
   db.do_ceo = create_toggle (page_col, "CEO Breakdown", d->bjt_device.do_ceo_breakdown);
   db.do_cbo = create_toggle (page_col, "CBO Breakdown", d->bjt_device.do_cbo_breakdown);
   db.do_extscr = create_toggle (page_col, "Extended Screen", d->bjt_device.do_extended_screen);
   db.do_fwdg = create_toggle (page_col, "Forward Gummel", d->bjt_device.do_fwd_gum);
   db.do_revg = create_toggle (page_col, "Reverse Gummel", d->bjt_device.do_rev_gum);
   db.do_flyb = create_toggle (page_col, "Emitter Flyback", d->bjt_device.do_flyback);
   db.do_dciv = create_toggle (page_col, "I-V Curves", d->bjt_device.do_dciv);
   db.do_hotsp = create_toggle (page_col, "Hot S-Parameters", d->bjt_device.do_hotsp);
   db.do_cbcsp = create_toggle (page_col, "B-C Capacitance S-Params", d->bjt_device.do_cbcsp);
   db.do_cbesp = create_toggle (page_col, "B-E Capacitance S-Params", d->bjt_device.do_cbesp);
   db.do_sparams = create_toggle (page_col, "Active S-Parameters", d->bjt_device.do_sparams);

   XtManageChild (page_col);
   XtManageChild (frame);

   // notebook page 4 - test parameters

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 4,
      NULL);
   text = XmStringCreateLocalized ("Test Params");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 4,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   db.ibr = create_text_entry_row (page_col, "Ibr (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.ibr));
   db.max_vbr = create_text_entry_row (page_col, "Max Vbr (V):", 8, 15, get_str_from_dbl(d->bjt_device.vbr_compliance));
   db.app_beta = create_text_entry_row (page_col, "Approximate Beta:", 8, 15, get_str_from_dbl(d->bjt_device.approx_beta));
   db.vce_beta = create_text_entry_row (page_col, "Vce for Beta (V):", 8, 15, get_str_from_dbl(d->bjt_device.vce_for_beta));
   db.ice_beta1 = create_text_entry_row (page_col, "Ice for Beta1 (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.ice_for_beta1));
   db.ice_beta2 = create_text_entry_row (page_col, "Ice for Beta2 (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.ice_for_beta2));
   db.ice_beta3 = create_text_entry_row (page_col, "Ice for Beta3 (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.ice_for_beta3));
   db.sp_vce = create_text_entry_row (page_col, "Vce Step for S-Params (V):", 8, 15, get_str_from_dbl(d->bjt_device.sparam_vce_step));
   db.capsp_off = create_text_entry_row (page_col, "Voffset for Cap S-Params (V):", 8, 15, get_str_from_dbl(d->bjt_device.capsp_voffs));

   XtManageChild (page_col);

   // notebook page 5 - test parameters continued

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 5,
      NULL);
   text = XmStringCreateLocalized ("Test Params (2)");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 5,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   db.gstart = create_text_entry_row (page_col, "Ext Screen Gummel Start (V):", 8, 15, get_str_from_dbl(d->bjt_device.gummel_vstart));
   db.gstop = create_text_entry_row (page_col, "Ext Screen Gummel Stop (V): ", 8, 15, get_str_from_dbl(d->bjt_device.gummel_vstop));
   db.fstart = create_text_entry_row (page_col, "Ext Screen Flyback Start (kA/cm^2):", 8, 15, get_str_from_dbl(d->bjt_device.flyback_istart));
   db.fstop = create_text_entry_row (page_col, "Ext Screen Flyback Stop (kA/cm^2): ", 8, 15, get_str_from_dbl(d->bjt_device.flyback_istop));
   sprintf (str, "%u", d->bjt_device.dciv_npts);
   db.iv_npts = create_text_entry_row (page_col, "# of Ibe pts for I-V:", 4, 10, str);
   sprintf (str, "%u", d->bjt_device.hotsp_npts);
   db.hotsp_npts = create_text_entry_row (page_col, "# of pts for Hot S-Param:", 4, 10, str);
   sprintf (str, "%u", d->bjt_device.sparam_npts);
   db.sp_npts = create_text_entry_row (page_col, "# of Ibe pts for S-Params:", 4, 10, str);
   sprintf (str, "%u", d->bjt_device.dc_delay);
   db.delay = create_text_entry_row (page_col, "Bias Measurement Delay (mS):", 5, 10, str);

   XtManageChild (page_col);

   // manage the notebook
   XtManageChild (notebook);

   // create the action area
   action[0].txt = "Done";
   action[0].cb = cb_update_bjt_params;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_bjt_params (Widget w, XtPointer client_data, XtPointer call_data)
{
   BJT_PARAMS_DB *db = (BJT_PARAMS_DB *) client_data;

   get_value_from_textbox (db->em_fingers, TYPE_UNSIGNED, &db->d->bjt_device.num_em_fingers);
   get_value_from_textbox (db->em_wid, TYPE_REAL, &db->d->bjt_device.em_width);
   get_value_from_textbox (db->em_len, TYPE_REAL, &db->d->bjt_device.em_length);
   get_value_from_textbox (db->em_spac, TYPE_STRING, db->d->bjt_device.em_spacing);

   get_value_from_textbox (db->max_vce, TYPE_REAL, &db->d->bjt_device.max_vce);
   get_value_from_textbox (db->max_pow, TYPE_REAL, &db->d->bjt_device.max_power);
   get_value_from_textbox (db->max_ice, TYPE_REAL, &db->d->bjt_device.max_ice);
   get_value_from_textbox (db->max_ibe, TYPE_REAL, &db->d->bjt_device.max_ibe);
   get_value_from_textbox (db->max_vbe, TYPE_REAL, &db->d->bjt_device.max_vbe);
   get_value_from_textbox (db->min_vrev, TYPE_REAL, &db->d->bjt_device.min_vrev);

   db->d->bjt_device.do_beo_breakdown = get_toggle_state (db->do_beo);
   db->d->bjt_device.do_ceo_breakdown = get_toggle_state (db->do_ceo);
   db->d->bjt_device.do_cbo_breakdown = get_toggle_state (db->do_cbo);
   db->d->bjt_device.do_extended_screen = get_toggle_state (db->do_extscr);
   db->d->bjt_device.do_fwd_gum = get_toggle_state (db->do_fwdg);
   db->d->bjt_device.do_rev_gum = get_toggle_state (db->do_revg);
   db->d->bjt_device.do_flyback = get_toggle_state (db->do_flyb);
   db->d->bjt_device.do_dciv = get_toggle_state (db->do_dciv);
   db->d->bjt_device.do_hotsp = get_toggle_state (db->do_hotsp);
   db->d->bjt_device.do_cbcsp = get_toggle_state (db->do_cbcsp);
   db->d->bjt_device.do_cbesp = get_toggle_state (db->do_cbesp);
   db->d->bjt_device.do_sparams = get_toggle_state (db->do_sparams);

   get_value_from_textbox (db->ibr, TYPE_REAL, &db->d->bjt_device.ibr);
   get_value_from_textbox (db->max_vbr, TYPE_REAL, &db->d->bjt_device.vbr_compliance);
   get_value_from_textbox (db->app_beta, TYPE_REAL, &db->d->bjt_device.approx_beta);
   get_value_from_textbox (db->vce_beta, TYPE_REAL, &db->d->bjt_device.vce_for_beta);
   get_value_from_textbox (db->ice_beta1, TYPE_REAL, &db->d->bjt_device.ice_for_beta1);
   get_value_from_textbox (db->ice_beta2, TYPE_REAL, &db->d->bjt_device.ice_for_beta2);
   get_value_from_textbox (db->ice_beta3, TYPE_REAL, &db->d->bjt_device.ice_for_beta3);
   get_value_from_textbox (db->sp_vce, TYPE_REAL, &db->d->bjt_device.sparam_vce_step);
   get_value_from_textbox (db->capsp_off, TYPE_REAL, &db->d->bjt_device.capsp_voffs);

   get_value_from_textbox (db->gstart, TYPE_REAL, &db->d->bjt_device.gummel_vstart);
   get_value_from_textbox (db->gstop, TYPE_REAL, &db->d->bjt_device.gummel_vstop);
   get_value_from_textbox (db->fstart, TYPE_REAL, &db->d->bjt_device.flyback_istart);
   get_value_from_textbox (db->fstop, TYPE_REAL, &db->d->bjt_device.flyback_istop);
   get_value_from_textbox (db->iv_npts, TYPE_UNSIGNED, &db->d->bjt_device.dciv_npts);
   get_value_from_textbox (db->hotsp_npts, TYPE_UNSIGNED, &db->d->bjt_device.hotsp_npts);
   get_value_from_textbox (db->sp_npts, TYPE_UNSIGNED, &db->d->bjt_device.sparam_npts);
   get_value_from_textbox (db->delay, TYPE_UNSIGNED, &db->d->bjt_device.dc_delay);
}

