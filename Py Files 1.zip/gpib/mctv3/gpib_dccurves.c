#include "gpib.h"

/********************************************************************************/
/********************************************************************************/

extern int measure_iv_curve (MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error)
{
   FILE *file;
   HEADER_INFO *head = &d->header_info;
   unsigned i;
   int e;

   update_test_function ("I-V Curve");

   create_backup_file( fname );

   file = fopen (fname, "w+");
   if (!file)
   {
      sprintf (error, "measure_iv_curve(): unable to open file for writing.");
      return 1;
   }

   // write the header
   fprintf (file, "!FILE NAME: %s\n", fname);
   fprintf (file, "!WAFER NUMBER: %s\n", head->wafer);
   fprintf (file, "!PROCESS NAME: %s\n", head->process);
   fprintf (file, "!DEVICE NAME: %s\n", head->device);
   fprintf (file, "!CALKIT: %s\n", head->calkit);
   fprintf (file, "!TEMPERATURE (C): %.1f\n", head->temperature);
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time ());
   fprintf (file, "!COMMENTS:\n");
   if (head->comments[0])
   {
      fputc ('!', file);
      for (i = 0; head->comments[i]; ++i)
      {
         fputc (head->comments[i], file);
         if (head->comments[i] == '\n')
            fputc ('!', file);
      }
      fputc ('\n', file);
   }
   fprintf (file, "!\n");
   fflush (file);






   fclose (file);
   return e;
}

/********************************************************************************/
/********************************************************************************/

extern int measure_transfer_curve (MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error)
{
   FILE *file;
   HEADER_INFO *head = &d->header_info;
   unsigned i;
   char string[100];
   double vds, vgs, ids, igs;

   update_test_function ("Transfer Curve");

   create_backup_file( fname );

   file = fopen (fname, "w+");
   if (!file)
   {
      sprintf (error, "measure_transfer_curve(): unable to open file for writing.");
      return 1;
   }

   // write the header
   fprintf (file, "!FILE NAME: %s\n", fname);
   fprintf (file, "!WAFER NUMBER: %s\n", head->wafer);
   fprintf (file, "!PROCESS NAME: %s\n", head->process);
   fprintf (file, "!DEVICE NAME: %s\n", head->device);
   fprintf (file, "!CALKIT: %s\n", head->calkit);
   fprintf (file, "!TEMPERATURE (C): %.1f\n", head->temperature);
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time ());
   fprintf (file, "!COMMENTS:\n");
   if (head->comments[0])
   {
      fputc ('!', file);
      for (i = 0; head->comments[i]; ++i)
      {
         fputc (head->comments[i], file);
         if (head->comments[i] == '\n')
            fputc ('!', file);
      }
      fputc ('\n', file);
   }
   fprintf (file, "!\n");
   fflush (file);





   fclose(file);

   return 0;
}

