#include "gui.h"
#include <Xm/Notebook.h>

typedef struct
{
   MAIN_DATA *d;
   Widget ngf, ugw, gate_len, sd_spac, gg_spac;
   Widget max_vds, max_pow, min_vgs, max_vgs, max_igs, max_ids;
   Widget do_fwdiv, do_ssbreak, do_dsbreak, do_dciv, do_transfer, do_coldfet, do_sparams;
   Widget ibr_lo, ibr_hi, vbr_max, vds_idss, vds_imax, igs_imax, vpo_pct, vpo_id;
   Widget fwdiv_igs, cold_igs, cold_npts, sp_vds, delay;
} FET_PARAMS_DB;

static void cb_update_fet_params (Widget w, XtPointer client_data, XtPointer call_data);

/****************************************************************************/
/****************************************************************************/

extern void db_fet_device_parameters (Widget parent, MAIN_DATA *d)
{
   char *title = "FET Device Parameters";
   char *name = "DialogFETDeviceParams";
   Widget pane, notebook, page_col, frame;
   XmString text;
   char str[20];
   static FET_PARAMS_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);

   // create the notebook

   notebook = XtVaCreateWidget ("notebook", xmNotebookWidgetClass, pane,
      XmNbindingType, XmNONE,
      XmNfirstPageNumber, 1,
      NULL);

   // notebook page 1 - device header

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 1,
      NULL);
   text = XmStringCreateLocalized ("Device Params");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 1,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   sprintf (str, "%u", d->fet_device.ngf);
   db.ngf = create_text_entry_row (page_col, "Number of Gate Fingers:", 4, 10, str);
   db.ugw = create_text_entry_row (page_col, "Unit Gate Width (um):", 8, 15, get_str_from_dbl(d->fet_device.ugw));
   db.gate_len = create_text_entry_row (page_col, "Gate Length (um):", 8, 15, get_str_from_dbl(d->fet_device.gate_length));
   db.sd_spac = create_text_entry_row (page_col, "Source-Drain Spacing (um):", 8, 15, d->fet_device.sd_spacing);
   db.gg_spac = create_text_entry_row (page_col, "Gate-Gate Spacing (um):", 8, 15, d->fet_device.gg_spacing);

   XtManageChild (page_col);

   // notebook page 2 - max ratings

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 2,
      NULL);
   text = XmStringCreateLocalized ("Max Ratings");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 2,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   db.max_vds = create_text_entry_row (page_col, "Max Vds (V):", 8, 15, get_str_from_dbl(d->fet_device.max_vds));
   db.max_pow = create_text_entry_row (page_col, "Max Power (W/mm):", 8, 15, get_str_from_dbl(d->fet_device.max_power));
   db.min_vgs = create_text_entry_row (page_col, "Min Vgs (V):", 8, 15, get_str_from_dbl(d->fet_device.min_vgs));
   db.max_vgs = create_text_entry_row (page_col, "Max Vgs (V):", 8, 15, get_str_from_dbl(d->fet_device.max_vgs));
   db.max_igs = create_text_entry_row (page_col, "Max Igs (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.max_igs));
   db.max_ids = create_text_entry_row (page_col, "Max Ids (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.max_ids));

   XtManageChild (page_col);

   // notebook page 3 - enable tests

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 3,
      NULL);
   text = XmStringCreateLocalized ("Enable Tests");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 3,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   text = XmStringCreateLocalized ("Enable Device Tests");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   db.do_fwdiv = create_toggle (page_col, "Forward I-V Curve", d->fet_device.do_fwd_iv);
   db.do_ssbreak = create_toggle (page_col, "Single-Sided Breakdown", d->fet_device.do_ss_breakdown);
   db.do_dsbreak = create_toggle (page_col, "3-Terminal Breakdown", d->fet_device.do_ds_breakdown);
   db.do_dciv = create_toggle (page_col, "I-V Curves", d->fet_device.do_dciv);
   db.do_transfer = create_toggle (page_col, "DC Transfer Curve", d->fet_device.do_transfer);
   db.do_coldfet = create_toggle (page_col, "Cold-FET S-Parameters", d->fet_device.do_coldfet);
   db.do_sparams = create_toggle (page_col, "Active S-Parameters", d->fet_device.do_sparams);

   XtManageChild (page_col);
   XtManageChild (frame);

   // notebook page 4 - test parameters

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 4,
      NULL);
   text = XmStringCreateLocalized ("Test Params");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 4,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   db.ibr_lo = create_text_entry_row (page_col, "Ibr Low (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.ibr_low));
   db.ibr_hi = create_text_entry_row (page_col, "Ibr High (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.ibr_high));
   db.vbr_max = create_text_entry_row (page_col, "Max Vbr (V):", 8, 15, get_str_from_dbl(d->fet_device.vbr_compliance));
   db.vds_idss = create_text_entry_row (page_col, "Vds for Idss (V):", 8, 15, get_str_from_dbl(d->fet_device.vds_for_idss));
   db.vds_imax = create_text_entry_row (page_col, "Vds for Imax (V):", 8, 15, get_str_from_dbl(d->fet_device.vds_for_imax));
   db.igs_imax = create_text_entry_row (page_col, "Igs for Imax (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.igs_for_imax));
   db.vpo_pct = create_text_entry_row (page_col, "Vpo Percent (%%):", 8, 15, get_str_from_dbl(d->fet_device.vpo_percent));
   db.vpo_id = create_text_entry_row (page_col, "Vpo Current (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.vpo_current));

   XtManageChild (page_col);

   // notebook page 5 - test parameters continued

   page_col = XtVaCreateWidget ("page_col", xmRowColumnWidgetClass, notebook,
      XmNnotebookChildType, XmPAGE,
      XmNpageNumber, 5,
      NULL);
   text = XmStringCreateLocalized ("Test Params (2)");
   XtVaCreateManagedWidget ("major_tab", xmPushButtonWidgetClass, notebook,
      XmNnotebookChildType, XmMAJOR_TAB,
      XmNpageNumber, 5,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   db.fwdiv_igs = create_text_entry_row (page_col, "Fwd I-V Max Igs (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.fwd_iv_igs));
   db.cold_igs = create_text_entry_row (page_col, "Cold-FET Max Igs (mA/mm):", 8, 15, get_str_from_dbl(d->fet_device.coldfet_igs));
   sprintf (str, "%u", d->fet_device.coldfet_npts);
   db.cold_npts = create_text_entry_row (page_col, "Cold-FET # of pts:", 4, 10, str);
   db.sp_vds = create_text_entry_row (page_col, "S-Param Vds Step (V):", 8, 15, get_str_from_dbl(d->fet_device.sparam_vds_step));
   sprintf (str, "%u", d->fet_device.dc_delay);
   db.delay = create_text_entry_row (page_col, "Bias Measurement Delay (mS):", 5, 10, str);

   XtManageChild (page_col);

   XtManageChild (notebook);

   // create the action area
   action[0].txt = "Done";
   action[0].cb = cb_update_fet_params;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_fet_params (Widget w, XtPointer client_data, XtPointer call_data)
{
   FET_PARAMS_DB *db = (FET_PARAMS_DB *) client_data;

   get_value_from_textbox (db->ngf, TYPE_UNSIGNED, &db->d->fet_device.ngf);
   get_value_from_textbox (db->ugw, TYPE_REAL, &db->d->fet_device.ugw);
   get_value_from_textbox (db->gate_len, TYPE_REAL, &db->d->fet_device.gate_length);
   get_value_from_textbox (db->sd_spac, TYPE_STRING, db->d->fet_device.sd_spacing);
   get_value_from_textbox (db->gg_spac, TYPE_STRING, db->d->fet_device.gg_spacing);

   get_value_from_textbox (db->max_vds, TYPE_REAL, &db->d->fet_device.max_vds);
   get_value_from_textbox (db->max_pow, TYPE_REAL, &db->d->fet_device.max_power);
   get_value_from_textbox (db->min_vgs, TYPE_REAL, &db->d->fet_device.min_vgs);
   get_value_from_textbox (db->max_vgs, TYPE_REAL, &db->d->fet_device.max_vgs);
   get_value_from_textbox (db->max_igs, TYPE_REAL, &db->d->fet_device.max_igs);
   get_value_from_textbox (db->max_ids, TYPE_REAL, &db->d->fet_device.max_ids);

   db->d->fet_device.do_fwd_iv = get_toggle_state (db->do_fwdiv);
   db->d->fet_device.do_ss_breakdown = get_toggle_state (db->do_ssbreak);
   db->d->fet_device.do_ds_breakdown = get_toggle_state (db->do_dsbreak);
   db->d->fet_device.do_dciv = get_toggle_state (db->do_dciv);
   db->d->fet_device.do_transfer = get_toggle_state (db->do_transfer);
   db->d->fet_device.do_coldfet = get_toggle_state (db->do_coldfet);
   db->d->fet_device.do_sparams = get_toggle_state (db->do_sparams);

   get_value_from_textbox (db->ibr_lo, TYPE_REAL, &db->d->fet_device.ibr_low);
   get_value_from_textbox (db->ibr_hi, TYPE_REAL, &db->d->fet_device.ibr_high);
   get_value_from_textbox (db->vbr_max, TYPE_REAL, &db->d->fet_device.vbr_compliance);
   get_value_from_textbox (db->vds_idss, TYPE_REAL, &db->d->fet_device.vds_for_idss);
   get_value_from_textbox (db->vds_imax, TYPE_REAL, &db->d->fet_device.vds_for_imax);
   get_value_from_textbox (db->igs_imax, TYPE_REAL, &db->d->fet_device.igs_for_imax);
   get_value_from_textbox (db->vpo_pct, TYPE_REAL, &db->d->fet_device.vpo_percent);
   get_value_from_textbox (db->vpo_id, TYPE_REAL, &db->d->fet_device.vpo_current);

   get_value_from_textbox (db->fwdiv_igs, TYPE_REAL, &db->d->fet_device.fwd_iv_igs);
   get_value_from_textbox (db->cold_igs, TYPE_REAL, &db->d->fet_device.coldfet_igs);
   get_value_from_textbox (db->cold_npts, TYPE_UNSIGNED, &db->d->fet_device.coldfet_npts);
   get_value_from_textbox (db->sp_vds, TYPE_REAL, &db->d->fet_device.sparam_vds_step);
   get_value_from_textbox (db->delay, TYPE_UNSIGNED, &db->d->fet_device.dc_delay);
}

