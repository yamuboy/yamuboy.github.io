#include "gui.h"

typedef struct
{
   MAIN_DATA *d;
   Widget enable, stop_err;
   Widget mapfile;
   Widget xindex, yindex;
} MULTISITE_DB;

static void cb_update_multisite (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_orient (Widget w, XtPointer client_data, XtPointer call_data);

static unsigned global_orient;

/****************************************************************************/
/****************************************************************************/

extern void db_multisite_setup (Widget parent, MAIN_DATA *d)
{
   char *title = "Multisite Setup";
   char *name = "DialogMultisiteSetup";
   Widget pane, main_col;
   Widget row, button1, button2;
   Widget orient;
   XmString text;
   char str[20];
   static MULTISITE_DB db;
   static BROWSE_INFO browse;
   static EDIT_TEXT_FILE edit_data;
   XmString or1, or2, or3, or4;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   // create the entry boxes and set their values

   text = XmStringCreateLocalized ("Enable Multisite");
   db.enable = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, main_col,
      XmNlabelString, text,
      XmNset, d->multisite.do_multisite ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);

   text = XmStringCreateLocalized ("Stop on All Errors");
   db.stop_err = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, main_col,
      XmNlabelString, text,
      XmNset, d->multisite.stop_on_error ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, main_col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Map File:");
   db.mapfile = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 40,
      XmNmaxLength, MAX_FNAME_LEN,
      NULL);
   XmTextSetString (db.mapfile, d->multisite.mapfile);
   button1 = create_push_button (row, "Browse...");
   XtAddCallback (button1, XmNactivateCallback, cb_browse_dialog, (XtPointer) &browse);
   button2 = create_push_button (row, "Edit...");
   XtAddCallback (button2, XmNactivateCallback, cb_edit_text_file_dialog, (XtPointer) &edit_data);
   XtManageChild (row);

   browse.path = NULL;
   browse.pattern = NULL;
   browse.dir_flag = 0;
   browse.parent = parent;
   browse.entry = db.mapfile;
   browse.cb = NULL;

   edit_data.entry = db.mapfile;
   edit_data.parent = parent;

   sprintf (str, "%u", d->multisite.xIndex);
   db.xindex = create_text_entry_row (main_col, "X-Index:", 10, 30, str);

   sprintf (str, "%u", d->multisite.yIndex);
   db.yindex = create_text_entry_row (main_col, "Y-Index:", 10, 30, str);

   if (d->multisite.orientation > 3)
      d->multisite.orientation = 0;
   global_orient = d->multisite.orientation;
   or1 = XmStringCreateLocalized ("North (1)");
   or2 = XmStringCreateLocalized ("East  (2)");
   or3 = XmStringCreateLocalized ("South (3)");
   or4 = XmStringCreateLocalized ("West  (4)");
   text = XmStringCreateLocalized ("Major Flat Orientation:");
   orient = XmVaCreateSimpleOptionMenu (main_col, "option_menu", text, 'O', global_orient, cb_set_orient,
      XmVaPUSHBUTTON, or1, '1', NULL, NULL,
      XmVaPUSHBUTTON, or2, '2', NULL, NULL,
      XmVaPUSHBUTTON, or3, '3', NULL, NULL,
      XmVaPUSHBUTTON, or4, '4', NULL, NULL,
      NULL);
   XmStringFree (or1);
   XmStringFree (or2);
   XmStringFree (or3);
   XmStringFree (or4);
   XmStringFree (text);
   XtManageChild (orient);

   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Done";
   action[0].cb = cb_update_multisite;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // add an additional callback to update the main window widgets
   XtAddCallback (action[0].w, XmNactivateCallback, cb_update_mainw, NULL);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_multisite (Widget w, XtPointer client_data, XtPointer call_data)
{
   MULTISITE_DB *db = (MULTISITE_DB *) client_data;

   db->d->multisite.do_multisite = get_toggle_state (db->enable);
   db->d->multisite.stop_on_error = get_toggle_state (db->stop_err);

   get_value_from_textbox (db->mapfile, TYPE_STRING, db->d->multisite.mapfile);
   get_value_from_textbox (db->xindex, TYPE_UNSIGNED, &db->d->multisite.xIndex);
   get_value_from_textbox (db->yindex, TYPE_UNSIGNED, &db->d->multisite.yIndex);

   db->d->multisite.orientation = global_orient;
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_orient (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_orient = (unsigned) client_data;
}


