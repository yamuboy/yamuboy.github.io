#include "gui.h"
#include <math.h>


/****************************************************************************/
/****************************************************************************/

extern void db_dciv_curves (Widget parent, MAIN_DATA *d, int test_type)
{
   char *title = "Setup Bias";
   char *name = "DialogSetupBias";
   Widget pane, main_col, frame;
   Widget row, col;
   XmString text;
   char str[20];
   static SET_BIAS_DB db;


   static BROWSE_INFO browse;
   static EDIT_TEXT_FILE edit_tf;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   d->test_type = test_type;
   db.d = d;
   db.b = &val_def;
   db.parent = parent;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   /* bias setup frame */

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, main_col,
      NULL);

   text = XmStringCreateLocalized ("I-V Bias Lists");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   col = XtVaCreateWidget ("column", xmRowColumnWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 1:    ");
   text = XmStringCreateLocalized ("Voltage      ");
   db.bias1v = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, row,
      XmNlabelString, text,
      XmNset, val_def.bias1_mode == BIAS_VOLTAGE ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);
   text = XmStringCreateLocalized ("Current");
   db.bias1c = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, row,
      XmNlabelString, text,
      XmNset, val_def.bias1_mode == BIAS_VOLTAGE ? XmUNSET : XmSET,
      NULL);
   XmStringFree (text);
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Start");
   db.start1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias1_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v1_start) : get_str_from_dbl (val_def.i1_start),
      NULL);
   create_label_gadget (row, "    Stop");
   db.stop1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias1_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v1_stop) : get_str_from_dbl (val_def.i1_stop),
      NULL);
   create_label_gadget (row, "    Step");
   db.step1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias1_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v1_step) : get_str_from_dbl (val_def.i1_step),
      NULL);
   db.units1 = val_def.bias1_mode == BIAS_VOLTAGE ? create_label_gadget (row, " (V) ") : create_label_gadget (row, " (mA)");
   XtManageChild (row);

   create_label_gadget (col, "Bias 2 Voltage:");

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Start");
   db.start2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.v2_start),
      NULL);
   create_label_gadget (row, "    Stop");
   db.stop2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.v2_stop),
      NULL);
   create_label_gadget (row, "    Step");
   db.step2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.v2_step),
      NULL);
   create_label_gadget (row, " (V) ");
   XtManageChild (row);

   XtManageChild (col);
   XtManageChild (frame);

   // set some callbacks
   XtAddCallback (db.bias1v, XmNvalueChangedCallback, cb_set_bias1_v, &db);
   XtAddCallback (db.bias1c, XmNvalueChangedCallback, cb_set_bias1_c, &db);

   /* bias supply settings */

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, main_col,
      NULL);

   text = XmStringCreateLocalized ("Bias Supply Settings");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   col = XtVaCreateWidget ("column", xmRowColumnWidgetClass, frame,
      NULL);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 1 Compliance:    Voltage");
   db.vcompl1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.vcompl1),
      NULL);
   create_label_gadget (row, "(V)    Current");
   db.icompl1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.icompl1),
      NULL);
   create_label_gadget (row, "(mA)");
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 2 Compliance:    Voltage");
   db.vcompl2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.vcompl2),
      NULL);
   create_label_gadget (row, "(V)    Current");
   db.icompl2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.icompl2),
      NULL);
   create_label_gadget (row, "(mA)");
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "DC Delay:");
   sprintf (str, "%u", val_def.delay);
   db.delay = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 6,
      XmNvalue, str,
      NULL);
   create_label_gadget (row, "(ms)");
   XtManageChild (row);

   XtManageChild (col);
   XtManageChild (frame);

   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Run Test";
   action[0].cb = cb_update_bias_and_run;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // set sensitivity
   set_sensitivity (&db, val_def.type);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_bias_and_run (Widget w, XtPointer client_data, XtPointer call_data)
{
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;
   char error[400];

   if (get_toggle_state (db->nest_tog))
      db->b->type = USE_NESTED;
   else
      db->b->type = USE_FILE;

   if (get_toggle_state (db->bias1v))
   {
      db->b->bias1_mode = BIAS_VOLTAGE;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->v1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->v1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->v1_step);
   }
   else
   {
      db->b->bias1_mode = BIAS_CURRENT;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->i1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->i1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->i1_step);
   }

   if (get_toggle_state (db->bias2v))
   {
      db->b->bias2_mode = BIAS_VOLTAGE;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->v2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->v2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->v2_step);
   }
   else
   {
      db->b->bias2_mode = BIAS_CURRENT;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->i2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->i2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->i2_step);
   }

   get_value_from_textbox (db->fname, TYPE_STRING, db->b->fname);
   get_value_from_textbox (db->vcompl1, TYPE_REAL, &db->b->vcompl1);
   get_value_from_textbox (db->vcompl2, TYPE_REAL, &db->b->vcompl2);
   get_value_from_textbox (db->icompl1, TYPE_REAL, &db->b->icompl1);
   get_value_from_textbox (db->icompl2, TYPE_REAL, &db->b->icompl2);
   get_value_from_textbox (db->delay, TYPE_UNSIGNED, &db->b->delay);

   // setup the bias structure in MAIN_DATA
   if (setup_bias_struct (db->d, db->b, error))
   {
      db_error_message (error, db->parent);
      return;
   }

   // run the test
   cb_start_gpib (NULL, (XtPointer) db->d->test_type, NULL);
}

/****************************************************************************/
/****************************************************************************/

static void set_sensitivity (SET_BIAS_DB *db, int mode)
{
   Boolean nested = (mode == USE_NESTED) ? True : False;
   Boolean file = (mode == USE_FILE) ? True : False;

   // nested loop widgets
   XtVaSetValues (db->nest_frame, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias1v, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias1c, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias2v, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias2c, XmNsensitive, nested, NULL);
   XtVaSetValues (db->start1, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->stop1, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->step1, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->start2, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->stop2, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->step2, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);

   // bias file widgets
   XtVaSetValues (db->file_frame, XmNsensitive, file, NULL);
   XtVaSetValues (db->fname, XmNsensitive, file,
      XmNcursorPositionVisible, file, NULL);
   XtVaSetValues (db->browse, XmNsensitive, file, NULL);
   XtVaSetValues (db->edit, XmNsensitive, file, NULL);

}

/****************************************************************************/
/****************************************************************************/

static void cb_set_nested (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set) // handle the case where nested mode is already active
      XtVaSetValues (db->nest_tog, XmNset, XmSET, NULL);
   else
   {
      XtVaSetValues (db->file_tog, XmNset, XmUNSET, NULL);
      set_sensitivity (db, USE_NESTED);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias_file (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set) // handle the case where nested mode is already active
      XtVaSetValues (db->file_tog, XmNset, XmSET, NULL);
   else
   {
      XtVaSetValues (db->nest_tog, XmNset, XmUNSET, NULL);
      set_sensitivity (db, USE_FILE);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias1_v (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias1v, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->i1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->i1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->i1_step);
      XmTextSetString (db->start1, get_str_from_dbl (db->b->v1_start));
      XmTextSetString (db->stop1, get_str_from_dbl (db->b->v1_stop));
      XmTextSetString (db->step1, get_str_from_dbl (db->b->v1_step));

      XtVaSetValues (db->bias1c, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (V) ");
      XtVaSetValues (db->units1, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias1_c (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias1c, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->v1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->v1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->v1_step);
      XmTextSetString (db->start1, get_str_from_dbl (db->b->i1_start));
      XmTextSetString (db->stop1, get_str_from_dbl (db->b->i1_stop));
      XmTextSetString (db->step1, get_str_from_dbl (db->b->i1_step));

      XtVaSetValues (db->bias1v, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (mA)");
      XtVaSetValues (db->units1, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias2_v (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias2v, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->i2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->i2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->i2_step);
      XmTextSetString (db->start2, get_str_from_dbl (db->b->v2_start));
      XmTextSetString (db->stop2, get_str_from_dbl (db->b->v2_stop));
      XmTextSetString (db->step2, get_str_from_dbl (db->b->v2_step));

      XtVaSetValues (db->bias2c, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (V) ");
      XtVaSetValues (db->units2, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias2_c (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias2c, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->v2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->v2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->v2_step);
      XmTextSetString (db->start2, get_str_from_dbl (db->b->i2_start));
      XmTextSetString (db->stop2, get_str_from_dbl (db->b->i2_stop));
      XmTextSetString (db->step2, get_str_from_dbl (db->b->i2_step));

      XtVaSetValues (db->bias2v, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (mA)");
      XtVaSetValues (db->units2, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static int setup_bias_struct (MAIN_DATA *d, BIAS_VAL_DEF *b, char *err)
{
   if (d->bias_data.list1)
   {
      XtFree ((void *) d->bias_data.list1);
      d->bias_data.list1 = NULL;
   }
   if (d->bias_data.list2)
   {
      XtFree ((void *) d->bias_data.list2);
      d->bias_data.list2 = NULL;
   }

   if (b->type == USE_NESTED)
   {
      double start, stop, step, x;
      unsigned i;

      d->bias_data.bias_mode = BIAS_NESTED;
      d->bias_data.src1 = b->bias1_mode;
      d->bias_data.src2 = b->bias2_mode;

      if (b->bias1_mode == BIAS_CURRENT)
      {
         d->bias_data.src1 = BIAS_CURRENT;
         start = b->i1_start*0.001;
         stop = b->i1_stop*0.001;
         step = b->i1_step*0.001;
      }
      else
      {
         d->bias_data.src1 = BIAS_VOLTAGE;
         start = b->v1_start;
         stop = b->v1_stop;
         step = b->v1_step;
      }

      step = fabs (step);
      if (start > stop)
      {
         double tmp = start;
         start = stop;
         stop = tmp;
      }

      if (step < 1.0e-11)
      {
         sprintf (err, "Bias 1 step value is too small.");
         return 1;
      }

      d->bias_data.npts1 = get_npts (start,stop,step);
      d->bias_data.list1 = (double *) XtMalloc (sizeof(double)*d->bias_data.npts1);
      for (x = start, i = 0; i < d->bias_data.npts1; x += step, ++i)
         d->bias_data.list1[i] = x;

      if (b->bias2_mode == BIAS_CURRENT)
      {
         d->bias_data.src2 = BIAS_CURRENT;
         start = b->i2_start*0.001;
         stop = b->i2_stop*0.001;
         step = b->i2_step*0.001;
      }
      else
      {
         d->bias_data.src2 = BIAS_VOLTAGE;
         start = b->v2_start;
         stop = b->v2_stop;
         step = b->v2_step;
      }

      step = fabs (step);
      if (start > stop)
      {
         double tmp = start;
         start = stop;
         stop = tmp;
      }

      if (step < 1.0e-11)
      {
         sprintf (err, "Bias 2 step value is too small.");
         XtFree ((void *) d->bias_data.list1);
         d->bias_data.list1 = NULL;
         return 1;
      }

      d->bias_data.npts2 = get_npts (start,stop,step);
      d->bias_data.list2 = (double *) XtMalloc (sizeof(double)*d->bias_data.npts2);
      for (x = start, i = 0; i < d->bias_data.npts2; x += step, ++i)
         d->bias_data.list2[i] = x;
   }
   else
   {
      FILE *file = fopen (b->fname, "r");
      if (!file)
      {
         sprintf (err, "%s: unable to open file.", b->fname);
         return 1;
      }

      if (read_bias_from_file (file, &d->bias_data, err))
         return 1;

      fclose (file);
   }

   if (d->bias_data.src1 == BIAS_CURRENT)
      d->bias_data.compl1 = b->vcompl1;
   else
      d->bias_data.compl1 = b->icompl1*0.001;

   if (d->bias_data.src2 == BIAS_CURRENT)
      d->bias_data.compl2 = b->vcompl2;
   else
      d->bias_data.compl2 = b->icompl2*0.001;

   d->bias_data.delay = b->delay;
   d->bias_data.max_power = 1000.0;
   d->bias_data.max_diff = 1000.0;

   return 0;
}



