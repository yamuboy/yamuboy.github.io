#include "gui.h"
#include <Xm/MessageB.h>

typedef struct
{
   MAIN_DATA *d;
   Widget parent, dialog, file_entry;
} SAVE_LOAD_DB;

#define VERSION_STRING      "MCTConfigFileVersion"

static void cb_load_config (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_save_config (Widget w, XtPointer client_data, XtPointer call_data);
static void db_verify_save_config (char *fname, SAVE_LOAD_DB *db);

extern int load_config_file (char *fname, MAIN_DATA *d, char *err_msg);
static int save_config_file (char *fname, MAIN_DATA *d, char *err_msg);

/****************************************************************************/
/****************************************************************************/

extern void db_load_config (Widget parent, MAIN_DATA *d)
{
   char *title = "Load Configuration";
   char *name = "DialogLoadConfig";
   Widget pane, row, button;
   static BROWSE_INFO browse;
   static SAVE_LOAD_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);

   // create the filename entry and browse button

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, pane,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "File:");
   db.file_entry = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 35,
      XmNvalue, d->config_fname,
      XmNmaxLength, MAX_FNAME_LEN,
      NULL);
   button = create_push_button (row, "Browse...");
   XtManageChild (row);

   XtAddCallback (button, XmNactivateCallback, cb_browse_dialog, (XtPointer) &browse);

   browse.parent = parent;
   browse.entry = db.file_entry;
   browse.path = NULL;
   browse.pattern = NULL;
   browse.dir_flag = 0;
   browse.cb = NULL;

   db.parent = parent;
   db.dialog = dialog.shell;

   // create the action area
   action[0].txt = "Load";
   action[0].cb = cb_load_config;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // add an additional callback to update the main window widgets
   XtAddCallback (action[0].w, XmNactivateCallback, cb_update_mainw, NULL);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

extern void db_save_config (Widget parent, MAIN_DATA *d)
{
   char *title = "Save Configuration";
   char *name = "DialogSaveConfig";
   Widget pane, row, button;
   static BROWSE_INFO browse;
   static SAVE_LOAD_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);

   // create the filename entry and browse button

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, pane,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "File:");
   db.file_entry = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 35,
      XmNvalue, d->config_fname,
      XmNmaxLength, MAX_FNAME_LEN,
      NULL);
   button = create_push_button (row, "Browse...");
   XtManageChild (row);

   XtAddCallback (button, XmNactivateCallback, cb_browse_dialog, (XtPointer) &browse);

   browse.parent = parent;
   browse.entry = db.file_entry;
   browse.path = NULL;
   browse.pattern = NULL;
   browse.dir_flag = 0;
   browse.cb = NULL;

   db.parent = parent;
   db.dialog = dialog.shell;

   // create the action area
   action[0].txt = "Save";
   action[0].cb = cb_save_config;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_load_config (Widget w, XtPointer client_data, XtPointer call_data)
{
   SAVE_LOAD_DB *db = (SAVE_LOAD_DB *) client_data;
   char error_msg[300];
   char *str;

   error_msg[0] = 0;

   // get the value of the file entry field
   str = XmTextGetString (db->file_entry);
   if (!str)
   {
      // create an error message
      db_error_message ("Failed to retrieve the configuration file name.", db->parent);
      return;
   }

   if (load_config_file (str, db->d, error_msg))
   {
      // create an error message
      db_error_message (error_msg, db->parent);
      XtFree (str);
      return;
   }

   if (error_msg[0])
      // create a warning message
      db_warning_message (error_msg, db->parent);

   // copy the config file name to the main data structure
   strcpy (db->d->config_fname, str);
   XtFree (str);
}

/****************************************************************************/
/****************************************************************************/

static void cb_save_config (Widget w, XtPointer client_data, XtPointer call_data)
{
   SAVE_LOAD_DB *db = (SAVE_LOAD_DB *) client_data;
   char error_msg[300];
   char *str;
   FILE *file;

   // get the value of the file entry field
   str = XmTextGetString (db->file_entry);
   if (!str)
   {
      // destroy the dialog
      XtDestroyWidget (db->dialog);
      // create an error message
      db_error_message ("Failed to retrieve the configuration file name.", db->parent);
      return;
   }

   // check to see if the file exists
   file = fopen (str, "r");
   if (file)
   {
      fclose (file);

      // need to verify overwriting the file
      db_verify_save_config (str, db);
      return;
   }

   // destroy the save config dialog box
   XtDestroyWidget (db->dialog);

   if (save_config_file (str, db->d, error_msg))
   {
      // create an error message
      db_error_message (error_msg, db->parent);
      XtFree (str);
      return;
   }

   // copy the config file name to the main data structure
   strcpy (db->d->config_fname, str);
   XtFree (str);
}

/****************************************************************************/
/****************************************************************************/

static void cb_save_config_verified (Widget w, XtPointer client_data, XtPointer call_data)
{
   SAVE_LOAD_DB *db = (SAVE_LOAD_DB *) client_data;
   char error_msg[300];
   char *str;

   // get the value of the file entry field
   str = XmTextGetString (db->file_entry);

   // destroy the save config dialog box
   XtDestroyWidget (db->dialog);

   if (save_config_file (str, db->d, error_msg))
   {
      // create an error message
      db_error_message (error_msg, db->parent);
      XtFree (str);
      return;
   }

   // copy the config file name to the main data structure
   strcpy (db->d->config_fname, str);
   XtFree (str);
}

/****************************************************************************/
/****************************************************************************/

static void db_verify_save_config (char *fname, SAVE_LOAD_DB *db)
{
   Widget dialog;
   Arg args[10];
   int n = 0;
   XmString text, title, ok, cancel;
   char msg[300];

   ok = XmStringCreateLocalized ("Overwrite");
   cancel = XmStringCreateLocalized ("Cancel");
   XtSetArg (args[n], XmNautoUnmanage, False); ++n;
   XtSetArg (args[n], XmNokLabelString, ok); ++n;
   XtSetArg (args[n], XmNcancelLabelString, cancel); ++n;
   dialog = XmCreateWarningDialog (db->dialog, "Confirm", args, n);
   XmStringFree (ok);
   XmStringFree (cancel);

   title = XmStringCreateLocalized ("Confirm Overwrite");
   sprintf (msg, "Overwrite File?: %s", fname); 
   text = XmStringCreateLocalized (msg);
   XtVaSetValues (dialog,
      XmNmessageString, text,
      XmNdialogTitle, title,
      XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL,
      XmNnoResize, True,
      NULL);
   XmStringFree (title);
   XmStringFree (text);
   XtFree (fname);

   XtAddCallback (dialog, XmNokCallback, cb_save_config_verified, (XtPointer) db);
   XtAddCallback (dialog, XmNokCallback, cb_destroy_widget, XtParent (dialog));
   XtAddCallback (dialog, XmNcancelCallback, cb_destroy_widget, XtParent (dialog));

   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

   XtManageChild (dialog);

   XtPopup (XtParent(dialog), XtGrabNone);
}

/****************************************************************************/
/****************************************************************************/

static int is_whitespace (char ch)
{
   if ((ch == ' ') || (ch == '\t') || (ch == '\n'))
      return 1;

   return 0;
}

/****************************************************************************/
/****************************************************************************/

extern int load_config_file( char *fname, MAIN_DATA *pMainData, char *err_msg )
{
   FILE *file = fopen (fname, "r");
   unsigned i;
   char string[500];
   double version;
   int flag;

#include "gui_save_load.h"

   if (!file)
   {
      sprintf (err_msg, "%s: Config file not found.", fname);
      return 1;
   }

   // get the config file version info
   if (!fgets (string, 499, file))
   {
      sprintf (err_msg, "%s: No data in file.", fname);
      return 1;
   }
   else if (strncmp (string, VERSION_STRING, strlen(VERSION_STRING)))
   {
      sprintf (err_msg, "%s: Wrong file type.", fname);
      return 1;
   }
   else if (!sscanf (&string[strlen(VERSION_STRING)], "%lf", &version))
   {
      sprintf (err_msg, "%s: Unable to read file version.", fname);
      return 1;
   }
   else if (version < VERSION_NUMBER)
      sprintf (err_msg, "%s: Old version detected.", fname);

   // read all the configuration data
   while (fgets (string, 499, file))
   {
      if (!strncmp (string, "[COMMENTS]", 10))
      {
         // read in the comments
         pMainData->header_info.comments[0] = 0;
         while (fgets (string, 499, file))
         {
            if (!strncmp (string, "[END]", 5))
               break;

            strcat (pMainData->header_info.comments, string);
         }

         // remove the final '\n'
         if( *pMainData->header_info.comments )
            pMainData->header_info.comments[strlen(pMainData->header_info.comments)-1] = 0;
      }
      else if ((string[0] == '!') || (string[0] == '#') || (string[0] == '\n'))
         continue;

      // remove the end-of-line '\n'
      if (*string)
         string[strlen(string)-1] = 0;
      else
         continue;

      // check for a matching parameter
      for (i = 0; i < sz_save_load_v; ++i)
      {
         if (!save_load_v[i].name || (save_load_v[i].type < 0) || !save_load_v[i].data)
            continue;

         if (!strncmp (string, save_load_v[i].name, strlen (save_load_v[i].name)))
         {
            char *str = &string[strlen(save_load_v[i].name)];
            while (is_whitespace (*str))
               ++str;

            switch (save_load_v[i].type)
            {
            case TYPE_REAL:
               sscanf (str, "%lf", (double *) save_load_v[i].data);
               break;

            case TYPE_INT:
               sscanf (str, "%d", (int *) save_load_v[i].data);
               break;

            case TYPE_UNSIGNED:
               sscanf (str, "%u", (unsigned *) save_load_v[i].data);
               break;

            case TYPE_STRING:
               strcpy ((char *) save_load_v[i].data, str);
               break;

            case TYPE_BOOL:
               sscanf (str, "%d", &flag);
               if (flag)
                  *((unsigned *) save_load_v[i].data) = 1;
               else
                  *((unsigned *) save_load_v[i].data) = 0;
               break;
            }

            break;
         }
      }
   }

   fclose (file);

   return 0;
}

/****************************************************************************/
/****************************************************************************/

static int save_config_file (char *fname, MAIN_DATA *pMainData, char *err_msg)
{
   FILE *file = fopen (fname, "w+");
   unsigned i;

#include "gui_save_load.h"

   if (!file)
   {
      sprintf (err_msg, "Error writing to disc. Check permissions.");
      return 1;
   }

   // write the config file version
   fprintf (file, "%s\t%.2f\n\n", VERSION_STRING, VERSION_NUMBER);

   // write all the configuration data
   for (i = 0; i < sz_save_load_v; ++i)
   {
      switch (save_load_v[i].type)
      {
      case TYPE_REAL:
         fprintf (file, "%s\t%.8e\n", save_load_v[i].name, *((double *) save_load_v[i].data));
         break;

      case TYPE_INT:
         fprintf (file, "%s\t%d\n", save_load_v[i].name, *((int *) save_load_v[i].data));
         break;

      case TYPE_UNSIGNED:
         fprintf (file, "%s\t%u\n", save_load_v[i].name, *((unsigned *) save_load_v[i].data));
         break;

      case TYPE_BOOL:
         fprintf (file, "%s\t%u\n", save_load_v[i].name, *((unsigned *) save_load_v[i].data) ? 1 : 0);
         break;

      case TYPE_STRING:
         fprintf (file, "%s\t%s\n", save_load_v[i].name, (char *) save_load_v[i].data);
         break;

      default:
         fprintf (file, "\n");
         break;
      }
   }

   // write the header info comments section
   fprintf (file, "\n");
   fprintf (file, "[COMMENTS]\n");
   fprintf (file, "%s\n", pMainData->header_info.comments);
   fprintf (file, "[END]\n");

   fclose (file);

   return 0;
}



