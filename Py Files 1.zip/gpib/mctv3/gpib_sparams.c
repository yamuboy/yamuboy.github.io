#include "gpib.h"

/********************************************************************************/
/********************************************************************************/

extern int measure_sparameters (MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error)
{
   FILE *file;
   HEADER_INFO *head = &d->header_info;
   unsigned i = 0;
   double *flist = NULL;

   update_test_function ("S-Parameters");

   create_backup_file( fname );

   file = fopen (fname, "w+");
   if (!file)
   {
      sprintf (error, "measure_sparameters(): unable to open file for writing.");
      return 1;
   }

   // write the header
   fprintf (file, "!FILE NAME: %s\n", fname);
   fprintf (file, "!WAFER NUMBER: %s\n", head->wafer);
   fprintf (file, "!PROCESS NAME: %s\n", head->process);
   fprintf (file, "!DEVICE NAME: %s\n", head->device);
   fprintf (file, "!CALKIT: %s\n", head->calkit);
   fprintf (file, "!TEMPERATURE (C): %.1f\n", head->temperature);
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time ());
   fprintf (file, "!COMMENTS:\n");
   if (head->comments[0])
   {
      fputc ('!', file);
      for (i = 0; head->comments[i]; ++i)
      {
         fputc (head->comments[i], file);
         if (head->comments[i] == '\n')
            fputc ('!', file);
      }
      fputc ('\n', file);
   }
   fprintf (file,"!\n");
   fflush (file);

   if (general_s_parameters (inst->vna, file, error, &flist, 1))
   {
      fclose (file);
      return 1;
   }

   fclose (file);
   return 0;
}

/********************************************************************************/
/********************************************************************************/

extern int measure_biased_sparameters (MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error)
{
   FILE *file;
   HEADER_INFO *head = &d->header_info;
   int i = 0;
   double *flist = NULL;
   double vgs, vds, igs, ids;
   int stat;

   update_test_function ("S-Parameters");

   create_backup_file( fname );

   file = fopen (fname, "w+");
   if (!file)
   {
      sprintf (error, "measure_biased_sparameters(): unable to open file for writing.");
      return 1;
   }

   // write the header
   fprintf (file, "!FILE NAME: %s\n", fname);
   fprintf (file, "!WAFER NUMBER: %s\n", head->wafer);
   fprintf (file, "!PROCESS NAME: %s\n", head->process);
   fprintf (file, "!DEVICE NAME: %s\n", head->device);
   fprintf (file, "!CALKIT: %s\n", head->calkit);
   fprintf (file, "!TEMPERATURE (C): %.1f\n", head->temperature);
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time ());
   fprintf (file, "!COMMENTS:\n");
   if (head->comments[0])
   {
      fputc ('!', file);
      for (i = 0; head->comments[i]; ++i)
      {
         fputc (head->comments[i], file);
         if (head->comments[i] == '\n')
            fputc ('!', file);
      }
      fputc ('\n', file);
   }
   fprintf (file,"!\n");
   fflush (file);

   i = 0;
   stat = set_bias_point( inst->bias1, inst->bias2, d->bias_data, i++, &vgs, &igs, &vds, &ids, error );
   while( stat >= 0 )
   {
      if( stat )
         fprintf (file, "!**BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs );
      else
      {
         fprintf (file, "!BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs );
         if (general_s_parameters (inst->vna, file, error, &flist, 1))
         {
            set_bias_off( inst->bias1, inst->bias2, d->bias_data );
            fclose (file);
            return 1;
         }
      }

      if (check_abort_flag ())
      {
         set_bias_off( inst->bias1, inst->bias2, d->bias_data );
         fclose (file);
         return 0;
      }

      stat = set_bias_point( inst->bias1, inst->bias2, d->bias_data, i++, &vgs, &igs, &vds, &ids, error );
   }

   set_bias_off( inst->bias1, inst->bias2, d->bias_data );
   fclose (file);

   if( stat < -1 )
      return 1;

   return 0;
}

