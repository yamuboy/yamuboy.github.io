
#ifndef MCT_DEVICE_DEF
#define MCT_DEVICE_DEF

typedef struct
{
   // device/header parameters
   unsigned ngf;
   double ugw;
   double periphery;
   double gate_length;
   char sd_spacing[30];
   char gg_spacing[30];

   // device/test parameters
   unsigned do_fwd_iv, do_ss_breakdown, do_ds_breakdown, do_dciv, do_transfer, do_coldfet, do_sparams;
   double max_vds, max_power, min_vgs, max_vgs, max_igs, max_ids;
   double ibr_low, ibr_high, vbr_compliance, vpo_percent, vpo_current, vds_for_idss, vds_for_imax, igs_for_imax;
   double fwd_iv_igs, coldfet_igs, sparam_vds_step;
   unsigned coldfet_npts;
   unsigned dc_delay;

   // measured dc parameters
   double vbr_ss_lo, vbr_ss_hi;
   double vbr_ds_lo, vbr_ds_hi;
   double idss, imax, vmax;
   double vpo, vpo_imax, vpo_mamm;
   double ron;

} FET_DEVICE_PARAMETERS;


typedef struct
{
   // device header
   double em_area, em_length, em_width;
   unsigned num_em_fingers;
   char em_spacing[30];

   // maximum ratings
   double max_ice, max_ibe, max_vce, max_vbe, min_vrev, max_power;

   // test parameters
   double ibr, vbr_compliance, vce_for_beta, approx_beta;
   double ice_for_beta1, ice_for_beta2, ice_for_beta3;
   unsigned dciv_npts, hotsp_npts, sparam_npts;
   double sparam_vce_step;
   unsigned dc_delay;
   double gummel_vstart, gummel_vstop, flyback_istart, flyback_istop;
   double capsp_voffs;

   // enable tests
   unsigned do_beo_breakdown, do_cbo_breakdown, do_ceo_breakdown, do_extended_screen;
   unsigned do_fwd_gum, do_rev_gum, do_flyback, do_dciv, do_hotsp, do_cbcsp, do_cbesp, do_sparams;

   // measured dc parameters
   double vbr_beo, vbr_ceo, vbr_cbo, ibe_m, vbe_m, beta1, beta2, beta3;
   // extended screen
   double ls_nb, ls_isb, ls_b_r2, ls_nc, ls_isc, ls_c_r2, ls_vth, ls_re, ls_re_r2;

} BIPOLAR_DEVICE_PARAMETERS;



typedef struct
{
   int x;

} MOSFET_DEVICE_PARAMETERS;


#endif


