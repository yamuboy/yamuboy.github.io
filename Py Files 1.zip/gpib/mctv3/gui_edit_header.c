#include "gui.h"

typedef struct
{
   MAIN_DATA *d;
   Widget wafer;
   Widget process;
   Widget device;
   Widget calkit;
   Widget temp;
   Widget comments;
} EDIT_HEADER_DB;

static void cb_update_header_info (Widget w, XtPointer client_data, XtPointer call_data);

/****************************************************************************/
/****************************************************************************/

extern void db_edit_header (Widget parent, MAIN_DATA *d)
{
   char *title = "Edit Header";
   char *name = "DialogEditHeader";
   Widget pane, main_col, form, label;
   XmString text;
   int n;
   Arg args[10];
   char str[20];
   static EDIT_HEADER_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   // create the entry boxes and set their values

   db.wafer = create_text_entry_row (main_col, "Wafer:", 25, MAX_HEADER_LEN, d->header_info.wafer);
   db.process = create_text_entry_row (main_col, "Process:", 15, MAX_HEADER_LEN, d->header_info.process);
   db.device = create_text_entry_row (main_col, "Device:", 25, MAX_HEADER_LEN, d->header_info.device);
   db.calkit = create_text_entry_row (main_col, "Cal Kit:", 25, MAX_HEADER_LEN, d->header_info.calkit);
   sprintf (str, "%.1f", d->header_info.temperature);
   db.temp = create_text_entry_row (main_col, "Temperature (C):", 10, 30, str);

   // create the multi-line text widget for the comments section

   form = XtVaCreateWidget ("form", xmFormWidgetClass, main_col, NULL);

   text = XmStringCreateLocalized ("Comments:");
   label = XtVaCreateManagedWidget ("label", xmLabelGadgetClass, form,
      XmNlabelString, text,
      XmNleftAttachment, XmATTACH_FORM,
      XmNleftOffset, 5,
      XmNtopAttachment, XmATTACH_FORM,
      NULL);
   XmStringFree (text);

   n = 0;
   XtSetArg (args[n], XmNeditMode, XmMULTI_LINE_EDIT); ++n;
   XtSetArg (args[n], XmNrows, 7); ++n;
   XtSetArg (args[n], XmNcolumns, 70); ++n;
   XtSetArg (args[n], XmNmaxLength, MAX_COMMENTS_LEN); ++n;
   XtSetArg (args[n], XmNvalue, d->header_info.comments); ++n;

   db.comments = XmCreateScrolledText (form, "entry", args, n);
   XtVaSetValues (XtParent (db.comments),
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, label,
      XmNleftAttachment, XmATTACH_FORM,
      XmNleftOffset, 5,
      XmNrightAttachment, XmATTACH_FORM,
      XmNrightOffset, 5,
      XmNbottomAttachment, XmATTACH_FORM,
      NULL);

   XtManageChild (db.comments);
   XtManageChild (XtParent (db.comments));
   XtManageChild (form);


   // manage the higher-level widgets
   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Done";
   action[0].cb = cb_update_header_info;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_header_info (Widget w, XtPointer client_data, XtPointer call_data)
{
   EDIT_HEADER_DB *db = (EDIT_HEADER_DB *) client_data;

   get_value_from_textbox (db->wafer, TYPE_STRING, db->d->header_info.wafer);
   get_value_from_textbox (db->process, TYPE_STRING, db->d->header_info.process);
   get_value_from_textbox (db->device, TYPE_STRING, db->d->header_info.device);
   get_value_from_textbox (db->calkit, TYPE_STRING, db->d->header_info.calkit);
   get_value_from_textbox (db->temp, TYPE_REAL, &db->d->header_info.temperature);
   get_value_from_textbox (db->comments, TYPE_STRING, db->d->header_info.comments);
}

