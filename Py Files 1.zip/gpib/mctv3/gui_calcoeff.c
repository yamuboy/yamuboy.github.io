#include "gui.h"

static MAIN_DATA* main_dat;
static Widget coeff_file_entry;

static void cb_read_coeffs(Widget w, XtPointer client_data, XtPointer call_data);

/****************************************************************************/
/****************************************************************************/

extern void db_cal_coeffs( Widget parent, MAIN_DATA *d )
{
   char *title = "Read VNA Cal Coeffs";
   char *name = "DialogCalCoeffs";
   Widget pane, row;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   // set the main data pointer
   main_dat = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);

   // create the filename entry and browse button

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, pane,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget( row, "File Name:" );
   coeff_file_entry = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 35,
      XmNvalue, d->coeff_fname,
      XmNmaxLength, MAX_FNAME_LEN,
      NULL);
   XtManageChild (row);

   // create the action area
   action[0].txt = "OK";
   action[0].cb = cb_read_coeffs;
   action[0].data = NULL;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_read_coeffs(Widget w, XtPointer client_data, XtPointer call_data)
{
   get_value_from_textbox( coeff_file_entry, TYPE_STRING, main_dat->coeff_fname );
   cb_start_gpib (w, (XtPointer) VNA_CAL_COEFFS, NULL);
}


