#include "gpib.h"
#include "threads.h"

/* from gpib_update.h */
extern void init_update_interface( THREAD_SHARE *share, pthread_mutex_t *mutex );

static int init_inst( MAIN_DATA *main_data, INSTRUMENTS *inst, char *err_str);
static void close_inst( INSTRUMENTS *inst );
static int measure_dut( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );
static int read_multisite_mapfile( char *fname, int **xsite, int **ysite, int *nsites, char *err_str);
static void generate_filename( char *inname, int x_site, int y_site, char *fname );

/* from main.h */
extern int global_debug_level;

/********************************************************************************/
/********************************************************************************/

extern char *gpib_main( GPIB_THREAD_DATA *thread_data )
{
   int err = 0;
   char err_str[500];
   char str[500];
   char *dev_str, *err_log;
   MAIN_DATA *main_data = thread_data->main_data;
   INSTRUMENTS inst;
   char fname[MAX_FNAME_LEN+1];

   if( global_debug_level > 0 ) {
//      gpib_set_logfile( "mct_gpib_debug.txt" );
      switch( global_debug_level )
      {
      case 1:
         gpib_set_loglevel( GPIB_LOGERR ); break;
      case 2:
         gpib_set_loglevel( GPIB_LOGERR|GPIB_LOGBUS ); break;
      case 3:
         gpib_set_loglevel( GPIB_LOGERR|GPIB_LOGBUSEXT ); break;
      case 4:
         gpib_set_loglevel( GPIB_LOGERR|GPIB_LOGBUSEXT|GPIB_LOGTS ); break;
      default:
         gpib_set_loglevel( GPIB_LOGALL ); break;
      }
   }
   else
      gpib_set_loglevel( 0 );

   /* set the pointer to the shared thread data */
   init_update_interface( thread_data->share, thread_data->mutex );

   /* update the test type string */
   switch( main_data->device_type )
   {
   case DUT_FET:
      dev_str = "FET:";
      break;
   case DUT_BIPOLAR:
      dev_str = "Bipolar:";
      break;
   case DUT_MOSFET:
      dev_str = "MOSFET:";
      break;
   default:
      dev_str = "";
      break;
   }
   switch( main_data->test_type )
   {
   case DEV_DC_SCREEN:
      sprintf( str, "%s DC Screen", dev_str );
      update_test_type( str );
      break;
   case DEV_DC:
      sprintf( str, "%s DC", dev_str );
      update_test_type( str );
      break;
   case DEV_DC_AND_S:
      sprintf( str, "%s DC and [S]", dev_str );
      update_test_type( str );
      break;
   case DEV_NOISE:
      sprintf( str, "%s Noise", dev_str );
      update_test_type( str );
      break;
   case SPARAMS:
      update_test_type( "S-Parameters" );
      break;
   case SPARAMS_W_BIAS:
      update_test_type( "S-Params w/ Bias" );
      break;
   case NOISE:
      update_test_type( "Noise" );
      break;
   case NOISE_W_BIAS:
      update_test_type( "Noise w/ Bias" );
      break;
   case IV_CURVE:
      update_test_type( "I-V Curves" );
      break;
   case TRANSFER_CURVE:
      update_test_type( "Transfer Curve" );
      break;
   case VNA_CAL_COEFFS:
      update_test_type( "VNA Cal Coeffs" );
      break;
   case NFM_LOAD_ENR:
      update_test_type( "NFM Load ENR Table" );
      break;
   }

   /* update the test function */
   update_test_function( "Initializing..." );

   /* initialize the error string and error log */
   err_str[0] = '\0';
   fname[0] = '\0';
   err_log = NULL;

   /* if we are doing something that doesn't require all of the instruments
   do that and then exit */
   if( main_data->test_type == VNA_CAL_COEFFS )
   {
      if( get_vna_cal_coeffs( main_data, err_str) )
      {
         sprintf( str, "%s:\n%s", main_data->coeff_fname, err_str );
         return mct_strdup( str );
      }

      return NULL;
   }
   else if( main_data->test_type == NFM_LOAD_ENR )
   {
      if( load_nfm_enr_table( main_data, err_str ) )
      {
         sprintf( str, "%s:\n%s", "Load NFM ENR Table", err_str );
         return mct_strdup( str );
      }

      return NULL;
   }

   /* make sure that a valid filename has been specified */
   if( !*main_data->filename )
   {
      sprintf( str, "%s:\n%s", "Initialize", "No data file name specified" );
      return mct_strdup( str );
   }

   /* initialize the GPIB bus and instruments */
   if( init_inst( main_data, &inst, err_str ) )
   {
      close_inst( &inst );
      sprintf( str, "%s:\n%s", "Instrument Init", err_str );
      return mct_strdup( str );
   }

   /* read the measurement temperature */
   if( main_data->tcontrol.read_tset )
   {
      if( gpib_tc_readtemp( inst.tc, &main_data->header_info.temperature ) )
      {
         sprintf( err_str, "%s:\n%s", "Read Temperature Setpoint", gpib_errmsg() );
         close_inst( &inst );
         return mct_strdup( err_str );
      }
   }

   /* run the test */
   if( main_data->multisite.do_multisite )  
   {
      /* multisite test */
      int site, nsites;
      int *xsite, *ysite;

      /* read in the multisite wafer map */
      if( read_multisite_mapfile( main_data->multisite.mapfile, &xsite, &ysite, &nsites, err_str ) )
      {
         sprintf( str, "%s:\n%s", "Read Map File", err_str );
         close_inst( &inst );
         return mct_strdup( str );
      }

      /* loop through the sites */
      for( site=0; site<nsites; site++ )
      {
         err = 0;
         generate_filename( main_data->filename, xsite[site], ysite[site], fname );
         sprintf( str, "%d of %d sites.", site+1, nsites );
         update_multisite_status( str );

         /* move the autoprober (for site g.t. 0) */
         if( site )
         {
            long x, y;
            long x_inc = xsite[site] - xsite[0];
            long y_inc = ysite[site] - ysite[0];
            long xidx = main_data->multisite.xIndex;
            long yidx = main_data->multisite.yIndex;

            switch( main_data->multisite.orientation )
            {
            case 1:
               x = -xidx * y_inc;
               y = -yidx * x_inc;
               break;

            case 2:
               x = -xidx * x_inc;
               y =  yidx * y_inc;
               break;

            case 3:
               x =  xidx * y_inc;
               y =  yidx * x_inc;
               break;

            case 0:
            default:
               x =  xidx * x_inc;
               y = -yidx * y_inc;
               break;
            }

            if( (err = gpib_ap_move( inst.ap, x, y, MOVE_REL_BASE )) )
            {
               sprintf( err_str, "autoprober: %s", gpib_errmsg() );
               break;
            }
         }

         /* measure the DUT */
         err = measure_dut( main_data, &inst, fname, err_str );

         if( err && (main_data->test_type == DEV_DC_SCREEN) )
         {
            /* reset the error string and error flag during DC screening */
            err_str[0] = '\0';
            err = 0;
         }

         if (err)
         {
            if( main_data->multisite.stop_on_error )
               break;
            else
            {
               /* record the error to be reported later */
               record_error_msg( &err_log, fname, err_str );
               err_str[0] = '\0';
               err = 0;
            }
         }

         /* check for an abort signal */
         if( check_abort_flag() )
            break;

      }

      /* clean up allocated memory */
      mct_free( (void*)xsite );
      mct_free( (void*)ysite );
   }
   else 
   {
      /* single site test */
      update_multisite_status( "n/a" );
      strcpy( fname, main_data->filename );
      /* measure the DUT */
      err = measure_dut( main_data, &inst, fname, err_str );
   }

   if( err )
      /* record measurement errors before exiting */
      record_error_msg( &err_log, fname, err_str );

   /* set the temperature control setpoint */
   if( main_data->tcontrol.set_on_finish || main_data->tcontrol.off_on_finish )
   {
      if( end_of_test_tcontrol( main_data, &inst, err_str ) )
         record_error_msg( &err_log, "Temp Control", err_str );
   }

   /* close the instruments and GPIB bus interface */
   close_inst( &inst );

   if( err_log )
      return mct_strdup( err_log );

   return NULL;
}

/********************************************************************************/
/********************************************************************************/

static int init_inst( MAIN_DATA *main_data, INSTRUMENTS *inst, char *error )
{
   int bidx = main_data->inst_info.gpib_board;

   /* initialize the instrument structure, this needs to be done to prevent a SIGSEGV fault during the
   close_instruments() routine in the event of a failed instrument load in this function */
   inst->board_id = -1;
   inst->bias1 = NULL;
   inst->bias2 = NULL;
   inst->vna = NULL;
   inst->nfm = NULL;
   inst->ap = NULL;
   inst->tc = NULL;

   /* get the GPIB board handle */
   if( gpib_board_open( bidx, &inst->board_id ) )
   {
      sprintf( error, "initialize_instruments(): %s", gpib_errmsg() );
      return 1;
   }

   /******** load instruments ********/

   /* bias supplies */
   switch( main_data->test_type )
   {
   case DEV_DC_SCREEN:
   case DEV_DC:
   case DEV_DC_AND_S:
   case DEV_NOISE:
   case SPARAMS_W_BIAS:
   case NOISE_W_BIAS:
   case IV_CURVE:
   case TRANSFER_CURVE:
      /* bias 1 */
      if( gpib_instr_load( &inst->bias1, "bias1", INSTR_BIAS, main_data->inst_info.bias1_dl, bidx,
         main_data->inst_info.bias1_addr, main_data->inst_info.bias1_chan,
         main_data->inst_info.bias1_tmo, 0 ) )
      {
         sprintf( error, "bias1: %s", gpib_errmsg() );
         return 1;
      }

      /* bias 2 */
      if( gpib_instr_load( &inst->bias2, "bias2", INSTR_BIAS, main_data->inst_info.bias2_dl, bidx,
         main_data->inst_info.bias2_addr, main_data->inst_info.bias2_chan,
         main_data->inst_info.bias2_tmo, 0 ) )
      {
         sprintf( error, "bias2: %s", gpib_errmsg() );
         return 1;
      }

      break;
   }

   /* network analyzer (always loaded) */
   if( gpib_instr_load( &inst->vna, "vna", INSTR_VNA, main_data->inst_info.vna_dl, bidx,
      main_data->inst_info.vna_addr, main_data->inst_info.vna_chan,
      main_data->inst_info.vna_tmo, 0 ) )
   {
      /* only return an error if the VNA is needed */
      switch (main_data->test_type)
      {
      case DEV_DC_AND_S:
      case SPARAMS:
      case SPARAMS_W_BIAS:
         sprintf( error, "vna: %s", gpib_errmsg() );
         return 1;
      }
   }

   /* noise figure meter */
   switch( main_data->test_type )
   {
   case DEV_NOISE:
   case NOISE:
   case NOISE_W_BIAS:
      if( gpib_instr_load( &inst->nfm, "nfm", INSTR_NFM, main_data->inst_info.nfm_dl, bidx,
         main_data->inst_info.nfm_addr, main_data->inst_info.nfm_chan,
         main_data->inst_info.nfm_tmo, 0 ) )
      {
         sprintf( error, "nfm: %s", gpib_errmsg() );
         return 1;
      }

      break;
   }

   /* autoprober */
   if( main_data->multisite.do_multisite || main_data->tcontrol.set_on_finish || main_data->tcontrol.off_on_finish )
   {
      if( gpib_instr_load( &inst->ap, "autoprober", INSTR_AUTOPROBER, main_data->inst_info.ap_dl, bidx,
         main_data->inst_info.ap_addr, main_data->inst_info.ap_chan,
         main_data->inst_info.ap_tmo, 0 ) )
      {
         sprintf( error, "prober: %s", gpib_errmsg() );
         return 1;
      }
   }

   /* temperature control */
   if( main_data->tcontrol.read_tset || main_data->tcontrol.set_on_finish || main_data->tcontrol.off_on_finish )
   {
      if( gpib_instr_load( &inst->tc, "tcontrol", INSTR_TCONTROL, main_data->inst_info.tc_dl, bidx,
         main_data->inst_info.tc_addr, main_data->inst_info.tc_chan,
         main_data->inst_info.tc_tmo, 0 ) )
      {
         sprintf( error, "tempcontrol: %s", gpib_errmsg() );
         return 1;
      }
   }

   return 0;
}

/********************************************************************************/
/********************************************************************************/

static void close_inst( INSTRUMENTS *inst )
{
   gpib_instr_unload( inst->bias1, 0 );
   gpib_instr_unload( inst->bias2, 0 );
   gpib_instr_unload( inst->vna, 0 );
   gpib_instr_unload( inst->nfm, 0 );
   gpib_instr_unload( inst->ap, 0 );
   gpib_instr_unload( inst->tc, 0 );

   /* close the GPIB interface */
   gpib_board_close( inst->board_id );
}

/********************************************************************************/
/********************************************************************************/

static int measure_dut( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error )
{
   switch (main_data->test_type)
   {
   case DEV_DC_SCREEN:
   case DEV_DC:
   case DEV_DC_AND_S:
   case DEV_NOISE:
      switch (main_data->device_type)
      {
      case DUT_FET:
         return measure_fet_device( main_data, inst, fname, error );

      case DUT_BIPOLAR:
         return measure_bipolar_device( main_data, inst, fname, error );

      case DUT_MOSFET:
         return measure_mosfet_device( main_data, inst, fname, error );

      default:
         sprintf( error, "measure_dut(): invalid device type." );
         return 1;
      }

   case SPARAMS:
      return measure_sparameters( main_data, inst, fname, error ); 

   case SPARAMS_W_BIAS:
      return measure_biased_sparameters( main_data, inst, fname, error );

   case NOISE:
      return measure_noise( main_data, inst, fname, error );

   case NOISE_W_BIAS:
      return measure_biased_noise( main_data, inst, fname, error );

   case IV_CURVE:
      return measure_iv_curve( main_data, inst, fname, error );

   case TRANSFER_CURVE:
      return measure_transfer_curve( main_data, inst, fname, error );

   default:
      sprintf (error, "measure_dut(): invalid test type.");
      return 1;
   }

   return 0;
}

/********************************************************************************/
/********************************************************************************/

static int read_multisite_mapfile( char *fname, int **xsite, int **ysite, int *nsites, char *err_str)
{
   FILE *file;
   char string[256];
   int n = 0;
   int d1, d2;
   int *x, *y;

   file = fopen( fname, "r" );
   if( !file )
   {
      sprintf( err_str, "%s: file not found.", fname );
      return 1;
   }

   /* determine the number of sites */
   while( fgets(string, 255, file) )
   {
      if( (string[0] == '!') || (string[0] == '#') )
         continue;

      if( sscanf(string, "%d%d", &d1, &d2) == 2 )
         n++;
   }

   if( n < 1 )
   {
      fclose( file );
      sprintf( err_str, "%s: file empty.", fname );
      return 1;
   }

   rewind(file);

   /* allocate memory */
   x = (int *) mct_malloc( sizeof(int)*n );
   y = (int *) mct_malloc( sizeof(int)*n );

   *nsites = n;
   *xsite = x;
   *ysite = y;

   n = 0;
   while (fgets (string, 255, file))
   {
      if( (string[0] == '!') || (string[0] == '#') )
         continue;

      if( n >= *nsites )
         break;

      if( sscanf (string, "%d%d", &x[n], &y[n] ) == 2 )
         n++;
   }

   fclose(file);
   return 0;
}

/********************************************************************************/
/********************************************************************************/

static void generate_filename( char *inname, int x_site, int y_site, char *fname )
{
   char string[5];
   char *ptr, *tail = NULL;

   /* copy the input filename */
   strcpy( fname, inname );

   /* find the first numerical digit in the file name */
   for( ptr=fname; ( *ptr > '9' || *ptr < '0' ) && *ptr; ptr++ );

   /* truncate the file name at this point (create the first part of the file name) */
   if( *ptr )
   {
      *ptr = 0;
      ptr++;
   }

   /* find the end of the number */
   while( *ptr <= '9' && *ptr >= '0' && *ptr )
      ptr++;

   /* create the tailing part of the file name */
   if( *ptr )
      tail = strdup( ptr ); 

   /* create the X site string */
   if( x_site < 10 )
      sprintf( string, "0%d", x_site );
   else
      sprintf( string, "%d", x_site );
   strcat( fname, string );

   /* create the Y site string */
   if( y_site < 10 )
      sprintf( string, "0%d", y_site );
   else
      sprintf( string, "%d", y_site );
   strcat( fname, string );

   /* add on the tailing part of the file name */
   if( tail )
   {
      strcat( fname, tail );
      free( (void*)tail );
   }
}
