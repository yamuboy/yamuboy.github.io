#include "common.h"
#include "threads.h"

// use a local global variable to keep track of the shared data pointer
static THREAD_SHARE *global_share;
static pthread_mutex_t *global_mutex;

/********************************************************************************/
/********************************************************************************/

extern void init_update_interface( THREAD_SHARE *share, pthread_mutex_t *mutex )
{
   global_share = share;
   global_mutex = mutex;
}

/********************************************************************************/
/********************************************************************************/

extern void update_test_type( char *str )
{
   /* lock the mutex */
   pthread_mutex_lock( global_mutex );

   if( global_share->test_type )
      mct_free( (void*)global_share->test_type );

   global_share->test_type = mct_strdup( str );

   /* unlock the mutex */
   pthread_mutex_unlock( global_mutex );
}

/********************************************************************************/
/********************************************************************************/

extern void update_test_function( char *str )
{
   /* lock the mutex */
   pthread_mutex_lock( global_mutex );

   if( global_share->test_function )
      mct_free( (void*)global_share->test_function );

   global_share->test_function = mct_strdup( str );

   /* unlock the mutex */
   pthread_mutex_unlock( global_mutex );
}

/********************************************************************************/
/********************************************************************************/

extern void update_test_status (char *str)
{
   /* lock the mutex */
   pthread_mutex_lock( global_mutex );

   if( global_share->test_status )
      mct_free( (void*)global_share->test_status );

   global_share->test_status = mct_strdup( str );

   /* unlock the mutex */
   pthread_mutex_unlock( global_mutex );
}

/********************************************************************************/
/********************************************************************************/

extern void update_multisite_status (char *str)
{
   /* lock the mutex */
   pthread_mutex_lock( global_mutex );

   if( global_share->multisite_status )
      mct_free( (void*)global_share->multisite_status );

   global_share->multisite_status = mct_strdup( str );

   /* unlock the mutex */
   pthread_mutex_unlock( global_mutex );
}

/********************************************************************************/
/********************************************************************************/

extern void record_error_msg( char **err_log, char *file, char *err_str )
{
   if( *err_log )
   {
      char *tmp = (char*) mct_malloc( sizeof(char) * ( strlen(*err_log) + strlen(file) + strlen(err_str) + 8 ) );
      sprintf( tmp, "%s\n%s:\n%s\n", *err_log, file, err_str );
      mct_free( (void*)*err_log );
      *err_log = tmp;
   }
   else
   {
      *err_log = (char*) mct_malloc( sizeof(char) * ( strlen(file) + strlen(err_str) + 6 ) );
      sprintf( *err_log, "%s:\n%s\n", file, err_str );
   }
}

/********************************************************************************/
/********************************************************************************/

extern int check_abort_flag (void)
{
   int flag;

   /* lock the mutex */
   pthread_mutex_lock( global_mutex );

   flag = global_share->abort_flag;

   /* unlock the mutex */
   pthread_mutex_unlock( global_mutex );

   return flag;
}


