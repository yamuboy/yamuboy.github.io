#include "gui.h"

typedef struct
{
   MAIN_DATA *d;
   Widget read, set_t, t_val, soak, off;
} TCONTROL_DB;

static void cb_update_tcontrol (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_tc_sensitive (Widget w, XtPointer client_data, XtPointer call_data);

/****************************************************************************/
/****************************************************************************/

extern void db_tcontrol_setup (Widget parent, MAIN_DATA *d)
{
   char *title = "Setup Temp Control";
   char *name = "DialogSetupTcontrol";
   Widget pane, main_col;
   char str[20];
   static TCONTROL_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   // create the entry boxes and set their values

   db.read = create_toggle (main_col, "Automatically read DUT temperature", d->tcontrol.read_tset);
   db.set_t = create_toggle (main_col, "Reset temperature upon test completion", d->tcontrol.set_on_finish);
   db.t_val = create_text_entry_row (main_col, "     Setpoint (C):", 8, 20, get_str_from_dbl (d->tcontrol.tset));
   sprintf (str, "%u", d->tcontrol.soak_min);
   db.soak = create_text_entry_row (main_col, "     Soak Time (minutes):", 8, 20, str);
   db.off = create_toggle (main_col, "Shutdown controller upon test completion", d->tcontrol.off_on_finish);

   XtAddCallback (db.set_t, XmNvalueChangedCallback, cb_set_tc_sensitive, &db);

   XtVaSetValues (db.t_val, XmNsensitive, d->tcontrol.set_on_finish ? True : False, NULL);
   XtVaSetValues (db.soak, XmNsensitive, d->tcontrol.set_on_finish ? True : False, NULL);

   // manage the higher-level widgets
   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Done";
   action[0].cb = cb_update_tcontrol;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // add an additional callback to update the main window widgets
   XtAddCallback (action[0].w, XmNactivateCallback, cb_update_mainw, NULL);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_tcontrol (Widget w, XtPointer client_data, XtPointer call_data)
{
   TCONTROL_DB *db = (TCONTROL_DB *) client_data;

   db->d->tcontrol.read_tset = get_toggle_state (db->read);
   db->d->tcontrol.set_on_finish = get_toggle_state (db->set_t);
   db->d->tcontrol.off_on_finish = get_toggle_state (db->off);
   get_value_from_textbox (db->t_val, TYPE_REAL, &db->d->tcontrol.tset);
   get_value_from_textbox (db->soak, TYPE_UNSIGNED, &db->d->tcontrol.soak_min);
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_tc_sensitive (Widget w, XtPointer client_data, XtPointer call_data)
{
   TCONTROL_DB *db = (TCONTROL_DB *) client_data;
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;

   XtVaSetValues (db->t_val, XmNsensitive, s->set ? True : False, NULL);
   XtVaSetValues (db->soak, XmNsensitive, s->set ? True : False, NULL);
}



