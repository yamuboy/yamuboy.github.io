#include <time.h>
#include <unistd.h>
#include "gpib.h"

/********************************************************************************/
/********************************************************************************/

static int close_exit_err( gpib_instr_t inst, int bd )
{
   gpib_instr_unload( inst, 0 );
   gpib_board_close( bd );
   return 1;
}

/********************************************************************************/
/********************************************************************************/

extern int get_vna_cal_coeffs( MAIN_DATA *d, char *error )
{
   FILE *file;
   instr_complex_t c[MAX_FREQS][12];
   double flist[MAX_FREQS];
   gpib_instr_t vna;
   int gpib_bd;
   unsigned nf, nc;
   unsigned i, j;

   update_test_function ("Calibration Coefficients");
   update_test_status ("Opening VNA...");

   if( gpib_board_open( d->inst_info.gpib_board, &gpib_bd ) )
   {
      sprintf (error, "get_vna_cal_coeffs(): %s.", gpib_errmsg() );
      return 1;
   }

   if( gpib_instr_load( &vna, "VNA", INSTR_VNA, d->inst_info.vna_dl, d->inst_info.gpib_board, d->inst_info.vna_addr,
      d->inst_info.vna_chan, d->inst_info.vna_tmo, 0) )
   {
      sprintf( error, "get_vna_cal_coeffs(): %s.", gpib_errmsg() );
      return 1;
   }

   update_test_status ("Reading...");

   file = fopen (d->coeff_fname, "w+");
   if (!file)
   {
      sprintf (error, "get_vna_cal_coeffs(): unable to open file for writing.");
      return close_exit_err( vna, gpib_bd );
   }

   // read frequency list
   if ( gpib_vna_readflist( vna, flist, MAX_FREQS, &nf) )
   {
      sprintf (error, "vna: error during frequency list read.\n%s", gpib_errmsg() );
      return close_exit_err (vna, gpib_bd);
   }

   // read cal coefficients
   if ( gpib_vna_readcal( vna, c, MAX_FREQS, &nc) )
   {
      sprintf (error, "vna: error during cal coefficient read.\n%s", gpib_errmsg() );
      return close_exit_err (vna, gpib_bd);
   }

   // check for proper alignment
   if (nf != nc)
   {
      sprintf (error, "get_vna_cal_coeffs(): size mismatch in arrays!\nThis is likely a VNA fault.");
      return close_exit_err (vna, gpib_bd);
   }

   // write the cal coefficients
   fprintf (file, "!VNA Calibration Coefficients (complex data format)\n");
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time());
   fprintf (file, "!\n");
   fprintf (file, "!Freq(Hz)    "
      "------------Edf------------   ------------Esf------------   ------------Erf------------   ------------Exf------------   "
      "------------Elf------------   ------------Etf------------   ------------Edr------------   ------------Esr------------   "
      "------------Err------------   ------------Exr------------   ------------Elr------------   ------------Etr------------\n" );
   for (i = 0; i < nc; ++i)
   {
      fprintf (file, "%.5e", flist[i]);
      for (j = 0; j < 12; ++j)
         fprintf (file, " %+.7e %+.7e", c[i][j].real, c[i][j].imag);
      fprintf (file, "\n");
   }

   fclose (file);
   close_exit_err (vna, gpib_bd);
   return 0;
}

/********************************************************************************/
/********************************************************************************/

extern int end_of_test_tcontrol (MAIN_DATA *d, INSTRUMENTS *inst, char *error)
{
   update_test_function ("Temperature Control");

   // move the autoprober to the separate position
   if ( gpib_ap_separate(inst->ap) )
   {
      sprintf (error, "autoprober: failed to move to SEPARATE position.\n%s", gpib_errmsg() );
      return 1;
   }

   if (d->tcontrol.set_on_finish)
   {
      double t = d->tcontrol.tset - 10.0;
      char str[100];

      sprintf (str, "Setting T = %.1f", d->tcontrol.tset);
      update_test_status (str);

      if ( gpib_tc_settemp(inst->tc, d->tcontrol.tset) )
      {
         sprintf (error, "tcontrol: error during set_temp().\n%s", gpib_errmsg() );
         return 1;
      }

      while (fabs (t - d->tcontrol.tset) > 1.0)
      {
         sleep (5);

         if ( gpib_tc_readtemp( inst->tc, &t) )
         {
            sprintf (error, "tcontrol: error during read_temp().\n%s", gpib_errmsg() );
            return 1;
         }

         if (check_abort_flag())
            return 0;
      }

      if (d->tcontrol.soak_min > 0)
      {
         time_t start, current, end;
         double elapsed;

         sprintf (str, "Soaking - %.0f %%", 0.0);
         update_test_status (str);

         time (&start);
         end = start + 60*d->tcontrol.soak_min;

         current = start;
         while (current < end)
         {
            sleep (5);

            time (&current);

            elapsed = ((double) (current - start)) / ((double) (end - start));
            if (elapsed > 1.0)
               elapsed = 1.0;

            sprintf (str, "Soaking - %.0f %%", elapsed * 100.0);
            update_test_status (str);

            if (check_abort_flag())
               return 0;
         }
      }
   }

   if (d->tcontrol.off_on_finish)
   {
      if ( gpib_tc_shutdown( inst->tc) )
      {
         sprintf (error, "tcontrol: error during shutdown().\n%s", gpib_errmsg() );
         return 1;
      }
   }

   return 0;
}

/********************************************************************************/
/********************************************************************************/

extern int load_nfm_enr_table (MAIN_DATA *d, char *error)
{
   gpib_instr_t nfm;
   int gpib_bd;
   ENR_TABLE *enr = (ENR_TABLE *) d->generic_data;
   double f_hz[100];
   unsigned i;

   if (!enr)
   {
      sprintf (error, "load_nfm_enr_table(): table empty.");
      return 1;
   }
   else if (enr->pts > 100)
   {
      /* this should never happen */
      sprintf (error, "load_nfm_enr_table(): too many points in ENR table.");
      return 1;
   }

   for (i = 0; i < enr->pts; ++i)
      f_hz[i] = enr->f_ghz[i]*1.0e9;

   update_test_function ("Load ENR Table");
   update_test_status ("Opening NFM...");

   if( gpib_board_open( d->inst_info.gpib_board, &gpib_bd ) )
   {
      sprintf (error, "load_nfm_enr_table(): %s.", gpib_errmsg() );
      return 1;
   }

   if( gpib_instr_load( &nfm, "NFM", INSTR_NFM, d->inst_info.nfm_dl, d->inst_info.gpib_board, d->inst_info.nfm_addr,
      d->inst_info.nfm_chan, d->inst_info.nfm_tmo, 0) )
   {
      sprintf( error, "load_nfm_enr_table(): %s.", gpib_errmsg() );
      return 1;
   }

   update_test_status ("Downloading ENR data...");

   if ( gpib_nfm_loadenr( nfm, f_hz, enr->enr, enr->pts) )
   {
      sprintf (error, "NFM: error during load_enr().\n%s", gpib_errmsg() );
      return close_exit_err (nfm, gpib_bd);
   }

   close_exit_err(nfm, gpib_bd);
   return 0;
}




