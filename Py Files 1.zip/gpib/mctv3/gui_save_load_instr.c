#include "gui.h"
#include <Xm/MessageB.h>
#include <unistd.h>
#include <stdlib.h>


static int is_whitespace (char ch)
{
   if ((ch == ' ') || (ch == '\t') || (ch == '\n'))
      return 1;

   return 0;
}

static int get_instrument_config_filename( char *fname, unsigned len_fname )
{
    char hn[256];
    char *home;
    char w[2048];
    
    // get the hostname of the system
    gethostname(hn,256);
    
    // get the home directory
    home = getenv("HOME");
    if( ! home ) {
        home = "";        
    }
    
    // create the filename
    // this is an ugly hack to fix an obsolete program, but
    // it will work for the time being
    strcpy(w,home);
    strcat(w,"/");
    strcat(w,".mctinstr-");
    strcat(w,hn);
    
    strncpy(fname,w,len_fname-1);
    fname[len_fname-1] = '\0';
    
    return 0;
}    

/****************************************************************************/
/****************************************************************************/

extern int load_instrument_config_file( MAIN_DATA *pMainData )
{
   FILE *file;
   unsigned i;
   char string[500];
   char fname[256];
   double version;
   int flag;

   get_instrument_config_filename(fname,256);
   file = fopen(fname, "r");   
   
#include "gui_save_load_instr.h"

   if (!file)
   {
      return 1;
   }

   // read the instrument configuration data
   while (fgets (string, 499, file))
   {
      if ((string[0] == '!') || (string[0] == '#') || (string[0] == '\n'))
         continue;

      // remove the end-of-line '\n'
      if (*string)
         string[strlen(string)-1] = 0;
      else
         continue;

      // check for a matching parameter
      for (i = 0; i < sz_save_load_v; ++i)
      {
         if (!save_load_v[i].name || (save_load_v[i].type < 0) || !save_load_v[i].data)
            continue;

         if (!strncmp (string, save_load_v[i].name, strlen (save_load_v[i].name)))
         {
            char *str = &string[strlen(save_load_v[i].name)];
            while (is_whitespace (*str))
               ++str;

            switch (save_load_v[i].type)
            {
            case TYPE_REAL:
               sscanf (str, "%lf", (double *) save_load_v[i].data);
               break;

            case TYPE_INT:
               sscanf (str, "%d", (int *) save_load_v[i].data);
               break;

            case TYPE_UNSIGNED:
               sscanf (str, "%u", (unsigned *) save_load_v[i].data);
               break;

            case TYPE_STRING:
               strcpy ((char *) save_load_v[i].data, str);
               break;

            case TYPE_BOOL:
               sscanf (str, "%d", &flag);
               if (flag)
                  *((unsigned *) save_load_v[i].data) = 1;
               else
                  *((unsigned *) save_load_v[i].data) = 0;
               break;
            }

            break;
         }
      }
   }

   fclose (file);

   return 0;
}

/****************************************************************************/
/****************************************************************************/

extern int save_instrument_config_file( MAIN_DATA *pMainData )
{
   FILE *file;
   unsigned i;
   char fname[256];
   
   get_instrument_config_filename(fname,256);
   file = fopen(fname, "w+");   

#include "gui_save_load_instr.h"

   if (!file)
   {
      return 1;
   }

   // write all the configuration data
   for (i = 0; i < sz_save_load_v; ++i)
   {
      switch (save_load_v[i].type)
      {
      case TYPE_REAL:
         fprintf (file, "%s\t%.8e\n", save_load_v[i].name, *((double *) save_load_v[i].data));
         break;

      case TYPE_INT:
         fprintf (file, "%s\t%d\n", save_load_v[i].name, *((int *) save_load_v[i].data));
         break;

      case TYPE_UNSIGNED:
         fprintf (file, "%s\t%u\n", save_load_v[i].name, *((unsigned *) save_load_v[i].data));
         break;

      case TYPE_BOOL:
         fprintf (file, "%s\t%u\n", save_load_v[i].name, *((unsigned *) save_load_v[i].data) ? 1 : 0);
         break;

      case TYPE_STRING:
         fprintf (file, "%s\t%s\n", save_load_v[i].name, (char *) save_load_v[i].data);
         break;

      default:
         fprintf (file, "\n");
         break;
      }
   }

   fclose (file);

   return 0;
}



