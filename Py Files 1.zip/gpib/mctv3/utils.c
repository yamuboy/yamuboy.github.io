#include <stdio.h>
#include <stdlib.h>
#include <Xm/Xm.h>


/****************************************************************************/

extern void *mct_malloc( size_t sz )
{
   void *buf;

   if( !sz )
      return NULL;

   buf = XtMalloc( sz );
   if( !buf )
   {
      fprintf( stderr, "Fatal Error: out of memory.\n" );
      exit( 1 );
   }

   return buf;
}

/****************************************************************************/

extern void mct_free( void *buf )
{
   if( !buf )
      return;

   XtFree( buf );
}

/****************************************************************************/

extern char *mct_strdup( char *str )
{
   char *buf;

   if( !str )
      return NULL;

   buf = (char*) mct_malloc( sizeof(char)*(strlen(str)+1) );
   strcpy( buf, str );

   return buf;
}

