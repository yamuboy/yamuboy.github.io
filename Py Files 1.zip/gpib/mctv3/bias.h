#ifndef MCT_BIAS_TYPES_INC
#define MCT_BIAS_TYPES_INC

/* "magic" cookies */
#define MC_BIAS_NESTED      233342
#define MC_BIAS_SIMULT      134861
#define MC_BIAS_TARGET_V    522134

typedef struct
{
   /* common elements */
   long magic_cookie;
   double compl1, compl2;
   int b2_first;
   unsigned delay;
   unsigned offset_delay;
   double power_limit1, power_limit2;
   /* elements vary with bias type */
   int src1, src2;
   unsigned npts;
   double *list1, *list2;
} BIAS_SIMULT_DATA;

typedef struct
{
   /* common elements */
   long magic_cookie;
   double compl1, compl2;
   int b2_first;
   unsigned delay;
   unsigned offset_delay;
   double power_limit1, power_limit2;
   /* elements vary with bias type */
   int src1, src2;
   unsigned npts1, npts2;
   double *list1, *list2;
} BIAS_NESTED_DATA;

typedef struct
{
   /* common elements */
   long magic_cookie;
   double compl1, compl2;
   int b2_first;
   unsigned delay;
   unsigned offset_delay;
   double power_limit1, power_limit2;
   /* elements vary with bias type */
   unsigned npts;
   double *v_out, *idd, *vin_start;
   double *vin_min, *vin_max;
} BIAS_TARGET_V_DATA;


#endif

