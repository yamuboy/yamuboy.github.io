#include "gui.h"
#include <instr/instr.h>

typedef struct
{
   MAIN_DATA *d;
   Widget gpib_bd;
   Widget bias1_dl, bias1_addr, bias1_chan;
   Widget bias2_dl, bias2_addr, bias2_chan;
   Widget vna_dl, vna_addr, vna_chan;
   Widget nfm_dl, nfm_addr, nfm_chan;
   Widget ap_dl, ap_addr, ap_chan;
   Widget tc_dl, tc_addr, tc_chan;
} INSTRUMENT_DB;

static void cb_update_instrument_setup (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_bias1_tmo (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_bias2_tmo (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_vna_tmo (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_nfm_tmo (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_ap_tmo (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_tc_tmo (Widget w, XtPointer client_data, XtPointer call_data);
static Widget create_instrument_row (Widget parent, char *name, Widget *w_dl, char *d_dl, Widget *w_addr,
                                     unsigned d_addr, void (*cb_tmo) (), unsigned d_tmo,
                                     Widget *w_chan, unsigned chan);

static int global_bias1_tmo;
static int global_bias2_tmo;
static int global_vna_tmo;
static int global_nfm_tmo;
static int global_ap_tmo;
static int global_tc_tmo;

/****************************************************************************/
/****************************************************************************/

extern void db_instrument_setup (Widget parent, MAIN_DATA *d)
{
   char *title = "Instrument Setup";
   char *name = "DialogInstrumentSetup";
   Widget pane, main_col, inst_form;
   Widget head, sep, i1, i2, i3, i4, i5, i6;
   static INSTRUMENT_DB db;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];
   char str[20];

   db.d = d;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   // create the gpib board entry
   sprintf (str, "%d", d->inst_info.gpib_board);
   db.gpib_bd = create_text_entry_row (main_col, "GPIB Board Number:", 2, 5, str);

   // create a form widget to hold the instrument setup info
   inst_form = XtVaCreateWidget ("instrument_form", xmFormWidgetClass, main_col,
      NULL);

   // create the header row
   head = create_label_gadget (inst_form, "Instrument           Library                  Address  Channel   Timeout     Info");
   XtVaSetValues (head, XmNalignment, XmALIGNMENT_BEGINNING, XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM, XmNtopAttachment, XmATTACH_FORM, NULL);

   // create a separator
   sep = XtVaCreateManagedWidget ("separator", xmSeparatorGadgetClass, inst_form,
      XmNshadowThickness, 2,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, head, 
      NULL);

   // create instrument rows
   i1 = create_instrument_row (inst_form, "Port 1 Bias:       ", &db.bias1_dl, d->inst_info.bias1_dl,
      &db.bias1_addr, d->inst_info.bias1_addr, cb_bias1_tmo, d->inst_info.bias1_tmo,
      &db.bias1_chan, d->inst_info.bias1_chan);
   i2 = create_instrument_row (inst_form, "Port 2 Bias:       ", &db.bias2_dl, d->inst_info.bias2_dl,
      &db.bias2_addr, d->inst_info.bias2_addr, cb_bias2_tmo, d->inst_info.bias2_tmo,
      &db.bias2_chan, d->inst_info.bias2_chan);
   i3 = create_instrument_row (inst_form, "Network Analyzer:  ", &db.vna_dl, d->inst_info.vna_dl,
      &db.vna_addr, d->inst_info.vna_addr, cb_vna_tmo, d->inst_info.vna_tmo,
      &db.vna_chan, d->inst_info.vna_chan);
   i4 = create_instrument_row (inst_form, "Noise Meter:       ", &db.nfm_dl, d->inst_info.nfm_dl,
      &db.nfm_addr, d->inst_info.nfm_addr, cb_nfm_tmo, d->inst_info.nfm_tmo,
      &db.nfm_chan, d->inst_info.nfm_chan);
   i5 = create_instrument_row (inst_form, "Autoprober:        ", &db.ap_dl, d->inst_info.ap_dl,
      &db.ap_addr, d->inst_info.ap_addr, cb_ap_tmo, d->inst_info.ap_tmo,
      &db.ap_chan, d->inst_info.ap_chan);
   i6 = create_instrument_row (inst_form, "Temp Controller:   ", &db.tc_dl, d->inst_info.tc_dl,
      &db.tc_addr, d->inst_info.tc_addr, cb_tc_tmo, d->inst_info.tc_tmo,
      &db.tc_chan, d->inst_info.tc_chan);

   // set attachments
   XtVaSetValues (i1, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, sep, NULL);
   XtVaSetValues (i2, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, i1, NULL);
   XtVaSetValues (i3, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, i2, NULL);
   XtVaSetValues (i4, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, i3, NULL);
   XtVaSetValues (i5, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, i4, NULL);
   XtVaSetValues (i6, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, i5, XmNbottomAttachment, XmATTACH_FORM, NULL);

   XtManageChild (inst_form);

   global_bias1_tmo = d->inst_info.bias1_tmo;
   global_bias2_tmo = d->inst_info.bias2_tmo;
   global_vna_tmo = d->inst_info.vna_tmo;
   global_nfm_tmo = d->inst_info.nfm_tmo;
   global_ap_tmo = d->inst_info.ap_tmo;
   global_tc_tmo = d->inst_info.tc_tmo;

   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Done";
   action[0].cb = cb_update_instrument_setup;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_instrument_setup (Widget w, XtPointer client_data, XtPointer call_data)
{
   INSTRUMENT_DB *db = (INSTRUMENT_DB *) client_data;

   get_value_from_textbox (db->gpib_bd, TYPE_INT, &db->d->inst_info.gpib_board);

   get_value_from_textbox (db->bias1_dl, TYPE_STRING, db->d->inst_info.bias1_dl);
   get_value_from_textbox (db->bias2_dl, TYPE_STRING, db->d->inst_info.bias2_dl);
   get_value_from_textbox (db->vna_dl, TYPE_STRING, db->d->inst_info.vna_dl);
   get_value_from_textbox (db->nfm_dl, TYPE_STRING, db->d->inst_info.nfm_dl);
   get_value_from_textbox (db->ap_dl, TYPE_STRING, db->d->inst_info.ap_dl);
   get_value_from_textbox (db->tc_dl, TYPE_STRING, db->d->inst_info.tc_dl);

   get_value_from_textbox (db->bias1_addr, TYPE_INT, &db->d->inst_info.bias1_addr);
   get_value_from_textbox (db->bias2_addr, TYPE_INT, &db->d->inst_info.bias2_addr);
   get_value_from_textbox (db->vna_addr, TYPE_INT, &db->d->inst_info.vna_addr);
   get_value_from_textbox (db->nfm_addr, TYPE_INT, &db->d->inst_info.nfm_addr);
   get_value_from_textbox (db->ap_addr, TYPE_INT, &db->d->inst_info.ap_addr);
   get_value_from_textbox (db->tc_addr, TYPE_INT, &db->d->inst_info.tc_addr);

   get_value_from_textbox (db->bias1_chan, TYPE_INT, &db->d->inst_info.bias1_chan);
   get_value_from_textbox (db->bias2_chan, TYPE_INT, &db->d->inst_info.bias2_chan);
   get_value_from_textbox (db->vna_chan, TYPE_INT, &db->d->inst_info.vna_chan);
   get_value_from_textbox (db->nfm_chan, TYPE_INT, &db->d->inst_info.nfm_chan);
   get_value_from_textbox (db->ap_chan, TYPE_INT, &db->d->inst_info.ap_chan);
   get_value_from_textbox (db->tc_chan, TYPE_INT, &db->d->inst_info.tc_chan);

   db->d->inst_info.bias1_tmo = global_bias1_tmo;
   db->d->inst_info.bias2_tmo = global_bias2_tmo;
   db->d->inst_info.vna_tmo = global_vna_tmo;
   db->d->inst_info.nfm_tmo = global_nfm_tmo;
   db->d->inst_info.ap_tmo = global_ap_tmo;
   db->d->inst_info.tc_tmo = global_tc_tmo;
}

/****************************************************************************/
/****************************************************************************/

static void cb_bias1_tmo (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_bias1_tmo = (unsigned) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_bias2_tmo (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_bias2_tmo = (unsigned) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_vna_tmo (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_vna_tmo = (unsigned) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_nfm_tmo (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_nfm_tmo = (unsigned) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_ap_tmo (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_ap_tmo = (unsigned) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_tc_tmo (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_tc_tmo = (unsigned) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_display_lib_info(Widget w, XtPointer client_data, XtPointer call_data)
{
   Widget w_dl = (Widget) client_data;
   char *dlname = XmTextGetString( w_dl );
   int inst_type = -1;
   gpib_instr_t inst;
   gpib_info_t info;
   char str[1024];

   if( !dlname )
   {
      db_error_message( "Unable to read library name.", get_top_shell(w) );
      return;
   }
   else if( !*dlname )
   {
      XtFree( (void*)dlname ); 
      db_error_message( "No library name specified.", get_top_shell(w) );
      return;
   } 

   /* determine the instrument type from the file name */
   if( !strncmp( dlname, "bi", 2 ) )
      inst_type = INSTR_BIAS;
   else if( !strncmp( dlname, "vna", 3 ) )
      inst_type = INSTR_VNA;
   else if( !strncmp( dlname, "nfm", 3 ) )
      inst_type = INSTR_NFM;
   else if( !strncmp( dlname, "ap", 2 ) )
      inst_type = INSTR_AUTOPROBER;
   else if( !strncmp( dlname, "tc", 2 ) )
      inst_type = INSTR_TCONTROL;

   if( gpib_instr_load( &inst, NULL, inst_type, dlname, 0, 0, 0, 0, 1 ) )
   {
      sprintf( str, "%s: error during load.\n%s", dlname, gpib_errmsg() );
      db_error_message( str, get_top_shell(w) );
      XtFree( (void*)dlname ); 
      return;
   }

   if( gpib_instr_getinfo( inst, &info ) )
   {
      sprintf( str, "%s: error reading info.\n%s", dlname, gpib_errmsg() );
      db_error_message( str, get_top_shell(w) );
      XtFree( (void*)dlname ); 
      gpib_instr_unload( inst, 1 );
      return;
   }

   sprintf( str, "Type: %s\n\nLibrary Name: %s\n\nVersion: %s\n\nDate: %s\n\nDescription:\n%s",
      info->instr_type, info->driver_name, info->driver_version, info->driver_date, info->driver_text );

   db_info_message( str, get_top_shell(w) );

   gpib_instr_freeinfo( info );
   gpib_instr_unload( inst, 1 );
}

/****************************************************************************/
/****************************************************************************/

static Widget create_instrument_row (Widget parent, char *name, Widget *w_dl, char *d_dl, Widget *w_addr,
                                     unsigned d_addr, void (*cb_tmo) (), unsigned d_tmo,
                                     Widget *w_chan, unsigned chan)
{
   Widget form, lab, w_tmo, but;
   XmString text, tmo[18];
   int spac = 1;
   char str[20];
   int i;

   form = XtVaCreateWidget ("form", xmFormWidgetClass, parent,
      XmNfractionBase, 100,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      NULL);

   text = XmStringCreateLocalized (name);
   lab = XtVaCreateManagedWidget ("label", xmLabelGadgetClass, form,
      XmNlabelString, text, 
      XmNalignment, XmALIGNMENT_BEGINNING,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_FORM,
      NULL);
   XmStringFree (text);

   *w_dl = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, form,
      XmNmaxLength, MAX_FNAME_LEN,
      XmNcolumns, 25,
      XmNvalue, d_dl,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, lab,
      XmNleftOffset, spac, 
      NULL);

   sprintf (str, "%u", d_addr);
   *w_addr = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, form,
      XmNvalue, str,
      XmNcolumns, 3, 
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, *w_dl,
      XmNleftOffset, spac, 
      NULL);

   sprintf (str, "%u", chan);
   *w_chan = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, form,
      XmNvalue, str,
      XmNcolumns, 3, 
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, *w_addr,
      XmNleftOffset, spac, 
      NULL);

   tmo[0] = XmStringCreateLocalized ("None");
   tmo[1] = XmStringCreateLocalized ("10 us");
   tmo[2] = XmStringCreateLocalized ("30 us");
   tmo[3] = XmStringCreateLocalized ("100 us");
   tmo[4] = XmStringCreateLocalized ("300 us");
   tmo[5] = XmStringCreateLocalized ("1 ms");
   tmo[6] = XmStringCreateLocalized ("3 ms");
   tmo[7] = XmStringCreateLocalized ("10 ms");
   tmo[8] = XmStringCreateLocalized ("30 ms");
   tmo[9] = XmStringCreateLocalized ("100 ms");
   tmo[10] = XmStringCreateLocalized ("300 ms");
   tmo[11] = XmStringCreateLocalized ("1 s");
   tmo[12] = XmStringCreateLocalized ("3 s");
   tmo[13] = XmStringCreateLocalized ("10 s");
   tmo[14] = XmStringCreateLocalized ("30 s");
   tmo[15] = XmStringCreateLocalized ("100 s");
   tmo[16] = XmStringCreateLocalized ("300 s");
   tmo[17] = XmStringCreateLocalized ("1000 s");
   w_tmo = XmVaCreateSimpleOptionMenu (form, "timeout", NULL, '\0', d_tmo, cb_tmo,
      XmVaPUSHBUTTON, tmo[0], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[1], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[2], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[3], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[4], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[5], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[6], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[7], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[8], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[9], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[10], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[11], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[12], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[13], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[14], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[15], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[16], '\0', NULL, NULL,
      XmVaPUSHBUTTON, tmo[17], '\0', NULL, NULL,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, *w_chan,
      XmNleftOffset, spac, 
      NULL);
   XtManageChild (w_tmo);

   for (i = 0; i < 18; ++i)
      XmStringFree (tmo[i]);

   text = XmStringCreateLocalized( "Info..." );
   but = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, w_tmo,
      XmNleftOffset, spac, 
      XmNrightAttachment, XmATTACH_FORM,
      NULL);
   XmStringFree (text);
   XtAddCallback( but, XmNactivateCallback, cb_display_lib_info, (XtPointer) *w_dl ); 

   XtManageChild (form);

   return form;
}
