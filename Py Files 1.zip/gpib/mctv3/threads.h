#include <pthread.h>

#ifndef MCT_THREADS_H
#define MCT_THREADS_H

typedef struct
{
   int abort_flag;
   char *test_type;
   char *test_function;
   char *test_status;
   char *multisite_status;
} THREAD_SHARE;

typedef struct 
{
   pthread_mutex_t *mutex;
   THREAD_SHARE *share;
   MAIN_DATA *main_data;
} GPIB_THREAD_DATA;

#endif

