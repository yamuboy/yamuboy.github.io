#include "gui.h"
#include <Xm/MessageB.h>

/****************************************************************************/
/****************************************************************************/

extern void db_about (Widget parent)
{
   Arg args[3];
   int n = 0;
   Widget dialog;
   XmString close,title,text;
   char string[1000];
   char tmpstr[200];

   sprintf (string, "Modeling and Characterization Test Software (MCT)\n\n");
   strcat (string, "Author: Jay Barrett\n\n");
   sprintf (tmpstr, "Version: %.2f\n\nBuild Date: %s, %s\n", VERSION_NUMBER, __DATE__, __TIME__);
   strcat (string, tmpstr);
   sprintf (tmpstr, "Compiler: %s\nCompile Flags: %s\nBuild Flags: %s\nBuild Libs: %s",
      COMPILER, CFLAGS, BUILDFLAGS, BUILDLIBS );
   strcat (string, tmpstr);

   text = create_Xm_string (string);

   XtSetArg (args[n], XmNautoUnmanage, False); ++n;
   XtSetArg (args[n], XmNdeleteResponse, XmDESTROY); ++n;
   dialog = XmCreateInformationDialog (parent, "About", args, n);

   close = XmStringCreateLocalized ("Close");
   title = XmStringCreateLocalized ("About");
   XtVaSetValues (dialog,
      XmNmessageString, text,
      XmNdialogTitle, title,
      XmNokLabelString, close,
      XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL,
      XmNnoResize, True,
      NULL);
   XmStringFree (close);
   XmStringFree (title);
   XmStringFree (text);

   XtAddCallback (dialog, XmNokCallback, cb_destroy_widget, (XtPointer) XtParent(dialog));

   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));
   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));

   XtManageChild (dialog);

   XtPopup (XtParent(dialog), XtGrabNone);
}

