#include "gui.h"
#include <math.h>

typedef struct
{
   MAIN_DATA *d;
   SET_BIAS_DATA *b;
   Widget parent;
   Widget nest_tog, nest_frame;
   Widget bias1v, bias1c;
   Widget start1, stop1, step1, units1;
   Widget bias2v, bias2c;
   Widget start2, stop2, step2, units2;
   Widget file_tog, file_frame;
   Widget fname, browse, edit, fmode, fhelp;
   Widget vcompl1, icompl1;
   Widget vcompl2, icompl2;
   Widget delay, ofs_delay, b2_first;
   Widget plim1, plim2;
} SET_BIAS_DB;

static void cb_update_bias_and_run (Widget w, XtPointer client_data, XtPointer call_data);
static void set_sensitivity (SET_BIAS_DB *db, int use_file);
static void cb_set_file_mode (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_nested (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_bias_file (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_bias1_v (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_bias1_c (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_bias2_v (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_set_bias2_c (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_display_file_help (Widget w, XtPointer client_data, XtPointer call_data);

static int setup_bias_struct (MAIN_DATA *d, char *err);

static int global_file_mode;

/****************************************************************************/
/****************************************************************************/

extern void db_setup_bias (Widget parent, MAIN_DATA *d, int test_type)
{
   char *title = "Setup Bias";
   char *name = "DialogSetupBias";
   Widget pane, main_col, frame;
   Widget row, col;
   XmString text, fms[10];
   char str[20];
   static SET_BIAS_DB db;
   static BROWSE_INFO browse;
   static EDIT_TEXT_FILE edit_tf;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];
   int i;

   /* to save me the headache of re-coding most of this section */
   SET_BIAS_DATA val_def = d->set_bias_data;


   d->test_type = test_type;
   db.d = d;
   db.b = &d->set_bias_data;
   db.parent = parent;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   /* nested sweep toggle and frame */

   text = XmStringCreateLocalized ("Nested Sweep");
   db.nest_tog = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, main_col,
      XmNlabelString, text,
      XmNset, val_def.use_file ? XmUNSET : XmSET,
      NULL);
   XmStringFree (text);
   XtAddCallback (db.nest_tog, XmNvalueChangedCallback, cb_set_nested, &db);

   db.nest_frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, main_col,
      NULL);

   col = XtVaCreateWidget ("column", xmRowColumnWidgetClass, db.nest_frame,
      NULL);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 1:    ");
   text = XmStringCreateLocalized ("Voltage      ");
   db.bias1v = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, row,
      XmNlabelString, text,
      XmNset, val_def.bias1_mode == BIAS_VOLTAGE ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);
   text = XmStringCreateLocalized ("Current");
   db.bias1c = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, row,
      XmNlabelString, text,
      XmNset, val_def.bias1_mode == BIAS_VOLTAGE ? XmUNSET : XmSET,
      NULL);
   XmStringFree (text);
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Start");
   db.start1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias1_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v1_start) : get_str_from_dbl (val_def.i1_start),
      NULL);
   create_label_gadget (row, "    Stop");
   db.stop1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias1_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v1_stop) : get_str_from_dbl (val_def.i1_stop),
      NULL);
   create_label_gadget (row, "    Step");
   db.step1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias1_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v1_step) : get_str_from_dbl (val_def.i1_step),
      NULL);
   db.units1 = val_def.bias1_mode == BIAS_VOLTAGE ? create_label_gadget (row, " (V) ") : create_label_gadget (row, " (mA)");
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 2:    ");
   text = XmStringCreateLocalized ("Voltage      ");
   db.bias2v = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, row,
      XmNlabelString, text,
      XmNset, val_def.bias2_mode == BIAS_VOLTAGE ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);
   text = XmStringCreateLocalized ("Current");
   db.bias2c = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, row,
      XmNlabelString, text,
      XmNset, val_def.bias2_mode == BIAS_VOLTAGE ? XmUNSET : XmSET,
      NULL);
   XmStringFree (text);
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Start");
   db.start2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias2_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v2_start) : get_str_from_dbl (val_def.i2_start),
      NULL);
   create_label_gadget (row, "    Stop");
   db.stop2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias2_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v2_stop) : get_str_from_dbl (val_def.i2_stop),
      NULL);
   create_label_gadget (row, "    Step");
   db.step2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, val_def.bias2_mode == BIAS_VOLTAGE ? get_str_from_dbl (val_def.v2_step) : get_str_from_dbl (val_def.i2_step),
      NULL);
   db.units2 = val_def.bias2_mode == BIAS_VOLTAGE ? create_label_gadget (row, " (V) ") : create_label_gadget (row, " (mA)");
   XtManageChild (row);

   XtManageChild (col);
   XtManageChild (db.nest_frame);

   // set some callbacks
   XtAddCallback (db.bias1v, XmNvalueChangedCallback, cb_set_bias1_v, &db);
   XtAddCallback (db.bias1c, XmNvalueChangedCallback, cb_set_bias1_c, &db);
   XtAddCallback (db.bias2v, XmNvalueChangedCallback, cb_set_bias2_v, &db);
   XtAddCallback (db.bias2c, XmNvalueChangedCallback, cb_set_bias2_c, &db);

   /* bias file toggle and frame */

   text = XmStringCreateLocalized ("Bias File");
   db.file_tog = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, main_col,
      XmNlabelString, text,
      XmNset, val_def.use_file ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);
   XtAddCallback (db.file_tog, XmNvalueChangedCallback, cb_set_bias_file, &db);

   db.file_frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, main_col,
      NULL);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, db.file_frame,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "File:");
   db.fname = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 35,
      XmNmaxLength, MAX_FNAME_LEN,
      XmNvalue, val_def.fname,
      NULL);
   db.browse = create_push_button (row, "Browse...");
   XtAddCallback (db.browse, XmNactivateCallback, cb_browse_dialog, &browse);
   db.edit = create_push_button (row, "Edit...");
   XtAddCallback (db.edit, XmNactivateCallback, cb_edit_text_file_dialog, &edit_tf);

   global_file_mode = val_def.file_mode;

   fms[0] = XmStringCreateLocalized ("V1/V2");
   fms[1] = XmStringCreateLocalized ("I1/V2");
   fms[2] = XmStringCreateLocalized ("V1/I2");
   fms[3] = XmStringCreateLocalized ("I1/I2");
   fms[4] = XmStringCreateLocalized ("V1/I2t");
   db.fmode = XmVaCreateSimpleOptionMenu (row, "file_mode", NULL, '\0', global_file_mode, cb_set_file_mode,
      XmVaPUSHBUTTON, fms[0], '\0', NULL, NULL,
      XmVaPUSHBUTTON, fms[1], '\0', NULL, NULL,
      XmVaPUSHBUTTON, fms[2], '\0', NULL, NULL,
      XmVaPUSHBUTTON, fms[3], '\0', NULL, NULL,
      XmVaPUSHBUTTON, fms[4], '\0', NULL, NULL,
      NULL);
   XtManageChild (db.fmode);
   for (i = 0; i < 5; ++i)
      XmStringFree (fms[i]);

   db.fhelp = create_push_button (row, "Help!");
   XtAddCallback (db.fhelp, XmNactivateCallback, cb_display_file_help, (XtPointer) dialog.shell );

   XtManageChild (row);

   XtManageChild (db.file_frame);

   browse.entry = db.fname;
   browse.path = NULL;
   browse.pattern = NULL;
   browse.cb = NULL;
   browse.parent = dialog.shell;
   browse.dir_flag = 0;

   edit_tf.entry = db.fname;
   edit_tf.parent = dialog.shell;

   /* bias supply settings */

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, main_col,
      NULL);
   text = XmStringCreateLocalized ("Bias Supply Settings");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   col = XtVaCreateWidget ("column", xmRowColumnWidgetClass, frame,
      NULL);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 1 Compliance:    Voltage");
   db.vcompl1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.vcompl1),
      NULL);
   create_label_gadget (row, "(V)    Current");
   db.icompl1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.icompl1),
      NULL);
   create_label_gadget (row, "(mA)");
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Bias 2 Compliance:    Voltage");
   db.vcompl2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.vcompl2),
      NULL);
   create_label_gadget (row, "(V)    Current");
   db.icompl2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 12,
      XmNvalue, get_str_from_dbl (val_def.icompl2),
      NULL);
   create_label_gadget (row, "(mA)");
   XtManageChild (row);

   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Meas Delay:");
   sprintf (str, "%u", val_def.delay);
   db.delay = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 6,
      XmNvalue, str,
      NULL);
   create_label_gadget (row, "(ms)    Offset Delay:");

   sprintf (str, "%u", val_def.ofs_delay);
   db.ofs_delay = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 6,
      XmNvalue, str,
      NULL);
   create_label_gadget (row, "(ms)");
   XtManageChild (row);


   /* power limits, added new 8/1/07 */
   row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, col,
      XmNorientation, XmHORIZONTAL,
      NULL);
   create_label_gadget (row, "Power Limit 1:");
   db.plim1 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 8,
      XmNvalue, get_str_from_dbl (val_def.plimit1),
      NULL);
   create_label_gadget (row, "(W)    Power Limit 2:");

   db.plim2 = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
      XmNcolumns, 8,
      XmNvalue, get_str_from_dbl (val_def.plimit2),
      NULL);
   create_label_gadget (row, "(W)");
   XtManageChild (row);


   text = XmStringCreateLocalized ("Set Output First");
   db.b2_first = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, col,
      XmNlabelString, text,
      XmNset, val_def.b2_first ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);

   XtManageChild (col);
   XtManageChild (frame);

   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Run Test";
   action[0].cb = cb_update_bias_and_run;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // set sensitivity
   set_sensitivity (&db, val_def.use_file);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_bias_and_run (Widget w, XtPointer client_data, XtPointer call_data)
{
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;
   char error[400];

   if (get_toggle_state (db->file_tog))
      db->b->use_file = 1;
   else
      db->b->use_file = 0;

   if (get_toggle_state (db->bias1v))
   {
      db->b->bias1_mode = BIAS_VOLTAGE;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->v1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->v1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->v1_step);
   }
   else
   {
      db->b->bias1_mode = BIAS_CURRENT;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->i1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->i1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->i1_step);
   }

   if (get_toggle_state (db->bias2v))
   {
      db->b->bias2_mode = BIAS_VOLTAGE;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->v2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->v2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->v2_step);
   }
   else
   {
      db->b->bias2_mode = BIAS_CURRENT;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->i2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->i2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->i2_step);
   }

   db->b->file_mode = global_file_mode;

   get_value_from_textbox (db->fname, TYPE_STRING, db->b->fname);
   get_value_from_textbox (db->vcompl1, TYPE_REAL, &db->b->vcompl1);
   get_value_from_textbox (db->vcompl2, TYPE_REAL, &db->b->vcompl2);
   get_value_from_textbox (db->icompl1, TYPE_REAL, &db->b->icompl1);
   get_value_from_textbox (db->icompl2, TYPE_REAL, &db->b->icompl2);
   get_value_from_textbox (db->delay, TYPE_UNSIGNED, &db->b->delay);
   get_value_from_textbox (db->ofs_delay, TYPE_UNSIGNED, &db->b->ofs_delay);

   /* power limits */
   get_value_from_textbox (db->plim1, TYPE_REAL, &db->b->plimit1);
   get_value_from_textbox (db->plim2, TYPE_REAL, &db->b->plimit2);

   if( get_toggle_state( db->b2_first ) )
      db->b->b2_first = 1;
   else
      db->b->b2_first = 0;

   if( setup_bias_struct (db->d, error) )
   {
      db_error_message( error, db->parent );
      return;
   }

   // run the test
   cb_start_gpib (NULL, (XtPointer) db->d->test_type, NULL);
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_file_mode (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_file_mode = (int) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void set_sensitivity (SET_BIAS_DB *db, int use_file)
{
   Boolean nested = use_file ? False : True;
   Boolean file = use_file ? True : False;

   // nested loop widgets
   XtVaSetValues (db->nest_frame, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias1v, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias1c, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias2v, XmNsensitive, nested, NULL);
   XtVaSetValues (db->bias2c, XmNsensitive, nested, NULL);
   XtVaSetValues (db->start1, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->stop1, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->step1, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->start2, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->stop2, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);
   XtVaSetValues (db->step2, XmNsensitive, nested,
      XmNcursorPositionVisible, nested, NULL);

   // bias file widgets
   XtVaSetValues (db->file_frame, XmNsensitive, file, NULL);
   XtVaSetValues (db->fname, XmNsensitive, file,
      XmNcursorPositionVisible, file, NULL);
   XtVaSetValues (db->browse, XmNsensitive, file, NULL);
   XtVaSetValues (db->edit, XmNsensitive, file, NULL);
   XtVaSetValues (db->fmode, XmNsensitive, file, NULL);
   XtVaSetValues (db->fhelp, XmNsensitive, file, NULL);
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_nested (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set) // handle the case where nested mode is already active
      XtVaSetValues (db->nest_tog, XmNset, XmSET, NULL);
   else
   {
      XtVaSetValues (db->file_tog, XmNset, XmUNSET, NULL);
      set_sensitivity (db, 0);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias_file (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set) // handle the case where file mode is already active
      XtVaSetValues (db->file_tog, XmNset, XmSET, NULL);
   else
   {
      XtVaSetValues (db->nest_tog, XmNset, XmUNSET, NULL);
      set_sensitivity (db, 1);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias1_v (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias1v, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->i1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->i1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->i1_step);
      XmTextSetString (db->start1, get_str_from_dbl (db->b->v1_start));
      XmTextSetString (db->stop1, get_str_from_dbl (db->b->v1_stop));
      XmTextSetString (db->step1, get_str_from_dbl (db->b->v1_step));

      XtVaSetValues (db->bias1c, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (V) ");
      XtVaSetValues (db->units1, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias1_c (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias1c, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start1, TYPE_REAL, &db->b->v1_start);
      get_value_from_textbox (db->stop1, TYPE_REAL, &db->b->v1_stop);
      get_value_from_textbox (db->step1, TYPE_REAL, &db->b->v1_step);
      XmTextSetString (db->start1, get_str_from_dbl (db->b->i1_start));
      XmTextSetString (db->stop1, get_str_from_dbl (db->b->i1_stop));
      XmTextSetString (db->step1, get_str_from_dbl (db->b->i1_step));

      XtVaSetValues (db->bias1v, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (mA)");
      XtVaSetValues (db->units1, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias2_v (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias2v, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->i2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->i2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->i2_step);
      XmTextSetString (db->start2, get_str_from_dbl (db->b->v2_start));
      XmTextSetString (db->stop2, get_str_from_dbl (db->b->v2_stop));
      XmTextSetString (db->step2, get_str_from_dbl (db->b->v2_step));

      XtVaSetValues (db->bias2c, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (V) ");
      XtVaSetValues (db->units2, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_bias2_c (Widget w, XtPointer client_data, XtPointer call_data)
{
   XmToggleButtonCallbackStruct *s = (XmToggleButtonCallbackStruct *) call_data;
   SET_BIAS_DB *db = (SET_BIAS_DB *) client_data;

   if (!s->set)
      XtVaSetValues (db->bias2c, XmNset, XmSET, NULL);
   else
   {
      XmString text;
      get_value_from_textbox (db->start2, TYPE_REAL, &db->b->v2_start);
      get_value_from_textbox (db->stop2, TYPE_REAL, &db->b->v2_stop);
      get_value_from_textbox (db->step2, TYPE_REAL, &db->b->v2_step);
      XmTextSetString (db->start2, get_str_from_dbl (db->b->i2_start));
      XmTextSetString (db->stop2, get_str_from_dbl (db->b->i2_stop));
      XmTextSetString (db->step2, get_str_from_dbl (db->b->i2_step));

      XtVaSetValues (db->bias2v, XmNset, XmUNSET, NULL);
      text = XmStringCreateLocalized (" (mA)");
      XtVaSetValues (db->units2, XmNlabelString, text, NULL);
      XmStringFree (text);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_display_file_help (Widget w, XtPointer client_data, XtPointer call_data)
{
   Widget p = (Widget) client_data;
   char str[1000];

   str[0] = '\0';

   switch( global_file_mode )
   {
   case BIAS_FILE_VINVOUT:
      sprintf( str, "Mode: V1/V2\nBoth supplies are set in voltage mode.\nEach row has two columns of data.\nV1  V2\nV1 and V2 are in volts." );
      break;
   case BIAS_FILE_IINVOUT:
      sprintf( str, "Mode: I1/V2\nbias1 = current, bias2 = voltage.\nEach row has two columns of data.\nI1  V2\nI1 is in milliamps, V2 is in volts." );
      break;
   case BIAS_FILE_VINIOUT:
      sprintf( str, "Mode: V1/I2\nbias1 = voltage, bias2 = current.\nEach row has two columns of data.\nV1  I2\nV1 is in volts, I2 is in milliamps." );
      break;
   case BIAS_FILE_IINIOUT:
      sprintf( str, "Mode: I1/I2\nBoth supplies are set in current mode.\nEach row has two columns of data.\nI1  I2\nI1 and I2 are in milliamps." );
      break;
   case BIAS_FILE_VINTARGETI:
      sprintf( str, "Mode: V1/I2t\nOutput current targeting mode.\nBoth supplies are set in voltage mode, I2 is targeted.\nEach row has five columns of data.\nV2  I2  V1_start  V1_min  V1_max\nI2 is in milliamps, V2 and V1_xxx are in volts." );
      break;
   }

   db_info_message( str, p );
}

/****************************************************************************/
/****************************************************************************/

static void delete_bias_data( void *d )
{
   long* cookie = (long*) d;
   if( !cookie )
      return;

   switch( *cookie )
   {
   case MC_BIAS_SIMULT:
      {
         BIAS_SIMULT_DATA* data = (BIAS_SIMULT_DATA*) d;
         XtFree((void*)data->list1);
         XtFree((void*)data->list2);
      }
      break;

   case MC_BIAS_NESTED:
      {
         BIAS_NESTED_DATA* data = (BIAS_NESTED_DATA*) d;
         XtFree((void*)data->list1);
         XtFree((void*)data->list2);
      }
      break;

   case MC_BIAS_TARGET_V:
      {
         BIAS_TARGET_V_DATA* data = (BIAS_TARGET_V_DATA*) d;
         XtFree((void*)data->v_out);
         XtFree((void*)data->idd);
         XtFree((void*)data->vin_start);
         XtFree((void*)data->vin_min);
         XtFree((void*)data->vin_max);
      }
      break;

   default:
      /* ahhhhh, this is bad, try to resolve the situation by freeing
      just the pointer, this could manifest as a memory leak */
      fprintf( stderr, "Yikes! Unknown bias data type during delete_bias_data().\n" );
      break;
   }

   XtFree( d );
}

/****************************************************************************/
/****************************************************************************/

static int setup_bias_struct (MAIN_DATA *d, char *err)
{
   SET_BIAS_DATA *b = &d->set_bias_data;

   if( d->bias_data )
      delete_bias_data( d->bias_data );
   d->bias_data = NULL;

   if( b->use_file )
   {
      /* read data from a bias file */
      FILE *file = fopen (b->fname, "r");
      int n = 0;
      int src1 = BIAS_VOLTAGE;
      int src2 = BIAS_VOLTAGE;
      double t[10];
      char str[256];

      if (!file)
      {
         sprintf (err, "%s: unable to open file.", b->fname);
         return 1;
      }

      /* count the number of bias points in the file */
      while( fgets( str, 255, file ) )
      {
         if( str[0] == '!' || str[0] == '#' )
            continue;

         if( b->file_mode == BIAS_FILE_VINTARGETI )
         {
            if( sscanf( str, "%lf%lf%lf%lf%lf", &t[0], &t[1], &t[2], &t[3], &t[4] ) == 5 )
               n++;
         }
         else
         {
            if( sscanf( str, "%lf%lf", &t[0], &t[1] ) == 2 )
               n++;
         }
      }

      if( n < 1 )
      {
         sprintf( err, "%s: no data.", b->fname );
         fclose( file );
         return 1;
      }

      rewind( file );

      if( b->file_mode == BIAS_FILE_VINTARGETI )
      {
         BIAS_TARGET_V_DATA *data = (BIAS_TARGET_V_DATA*) XtMalloc( sizeof(BIAS_TARGET_V_DATA) );

         /* set standard element values */
         data->magic_cookie = MC_BIAS_TARGET_V;
         data->compl1 = b->icompl1*0.001;
         data->compl2 = b->icompl2*0.001;
         data->b2_first = b->b2_first;
         data->delay = b->delay;
         data->offset_delay = b->ofs_delay;
         data->power_limit1 = b->plimit1;
         data->power_limit2 = b->plimit2;

         /* set custom element values */
         data->npts = n;
         data->v_out = (double *) XtMalloc( sizeof(double)*n );
         data->idd = (double *) XtMalloc( sizeof(double)*n );
         data->vin_start = (double *) XtMalloc( sizeof(double)*n );
         data->vin_min = (double *) XtMalloc( sizeof(double)*n );
         data->vin_max = (double *) XtMalloc( sizeof(double)*n );

         /* read in data */
         n = 0;
         while( fgets( str, 255, file ) )
         {
            if( str[0] == '!' || str[0] == '#' )
               continue;

            if( n >= data->npts )
               break;

            if( sscanf( str, "%lf%lf%lf%lf%lf", &data->v_out[n], &data->idd[n], &data->vin_start[n],
               &data->vin_min[n], &data->vin_max[n]) == 5 )
            {

               if( data->vin_min[n] > data->vin_max[n] )
               {
                  double x = data->vin_min[n];
                  data->vin_min[n] = data->vin_max[n];
                  data->vin_max[n] = x;
               }

               if( data->vin_start[n] < data->vin_min[n] || data->vin_start[n] > data->vin_max[n] )
                  data->vin_start[n] = data->vin_min[n];

               data->idd[n] = fabs( data->idd[n]*0.001 );

               n++;
            }
         }

         d->bias_data = data;
      }
      else
      {
         BIAS_SIMULT_DATA *data = (BIAS_SIMULT_DATA*) XtMalloc( sizeof(BIAS_SIMULT_DATA) );

         /* set the correct voltage/current for src1 and src2 */
         switch( b->file_mode )
         {
         case BIAS_FILE_IINVOUT:
            src1 = BIAS_CURRENT;
            src2 = BIAS_VOLTAGE;
            break;
         case BIAS_FILE_IINIOUT:
            src1 = src2 = BIAS_CURRENT;
            break;
         case BIAS_FILE_VINIOUT:
            src1 = BIAS_VOLTAGE;
            src2 = BIAS_CURRENT;
            break;
         case BIAS_FILE_VINVOUT:
         default:
            src1 = src2 = BIAS_VOLTAGE;
            break;
         }

         /* set standard element values */
         data->magic_cookie = MC_BIAS_SIMULT;
         data->compl1 = (src1 == BIAS_CURRENT) ? b->vcompl1 : b->icompl1*0.001;
         data->compl2 = (src2 == BIAS_CURRENT) ? b->vcompl2 : b->icompl2*0.001;
         data->b2_first = b->b2_first;
         data->delay = b->delay;
         data->offset_delay = b->ofs_delay;
         data->power_limit1 = b->plimit1;
         data->power_limit2 = b->plimit2;

         /* set custom element values */
         data->src1 = src1;
         data->src2 = src2;
         data->npts = n;
         data->list1 = (double *) XtMalloc( sizeof(double)*n );
         data->list2 = (double *) XtMalloc( sizeof(double)*n );

         /* read in data */
         n = 0;
         while( fgets( str, 255, file ) )
         {
            if( str[0] == '!' || str[0] == '#' )
               continue;

            if( n >= data->npts )
               break;

            if( sscanf( str, "%lf%lf", &data->list1[n], &data->list2[n] ) == 2)
            {
               if( src1 == BIAS_CURRENT )
                  data->list1[n] *= 0.001;
               if( src2 == BIAS_CURRENT )
                  data->list2[n] *= 0.001;
               n++;
            }
         }

         d->bias_data = data;
      }
   }

   else
   {
      /* use the nested sweep info from the dialog box */
      BIAS_NESTED_DATA *data;
      int src1, src2;
      double start1, stop1, step1;
      double start2, stop2, step2;
      double x;
      int i;

      if( b->bias1_mode == BIAS_CURRENT )
      {
         src1 = BIAS_CURRENT;
         start1 = b->i1_start*0.001;
         stop1 = b->i1_stop*0.001;
         step1 = b->i1_step*0.001;
      }
      else
      {
         src1 = BIAS_VOLTAGE;
         start1 = b->v1_start;
         stop1 = b->v1_stop;
         step1 = b->v1_step;
      }

      step1 = fabs( step1 );
      if (start1 > stop1)
      {
         double tmp = start1;
         start1 = stop1;
         stop1 = tmp;
      }

      if (step1 < (stop1-start1)*0.0001)
      {
         sprintf (err, "Bias 1 step value is too small.");
         return 1;
      }

      if( b->bias2_mode == BIAS_CURRENT )
      {
         src2 = BIAS_CURRENT;
         start2 = b->i2_start*0.001;
         stop2 = b->i2_stop*0.001;
         step2 = b->i2_step*0.001;
      }
      else
      {
         src2 = BIAS_VOLTAGE;
         start2 = b->v2_start;
         stop2 = b->v2_stop;
         step2 = b->v2_step;
      }

      step2 = fabs( step2 );
      if (start2 > stop2)
      {
         double tmp = start2;
         start2 = stop2;
         stop2 = tmp;
      }

      if (step2 < (stop2-start2)*0.0001)
      {
         sprintf (err, "Bias 2 step value is too small.");
         return 1;
      }

      data = (BIAS_NESTED_DATA*) XtMalloc( sizeof(BIAS_NESTED_DATA) );

      /* set standard element values */
      data->magic_cookie = MC_BIAS_NESTED;
      data->compl1 = (src1 == BIAS_CURRENT) ? b->vcompl1 : b->icompl1*0.001;
      data->compl2 = (src2 == BIAS_CURRENT) ? b->vcompl2 : b->icompl2*0.001;
      data->b2_first = b->b2_first;
      data->delay = b->delay;
      data->offset_delay = b->ofs_delay;
      data->power_limit1 = b->plimit1;
      data->power_limit2 = b->plimit2;

      /* set custom element values */
      data->src1 = src1;
      data->src2 = src2;
      data->npts1 = (start1 == stop1) ? 1 : (int) get_npts(start1,stop1,step1);
      data->npts2 = (start2 == stop2) ? 1 : (int) get_npts(start2,stop2,step2);
      data->list1 = (double *) XtMalloc( sizeof(double)*data->npts1 );
      data->list2 = (double *) XtMalloc( sizeof(double)*data->npts2 );
      for( x=start1, i=0; i<data->npts1; x+=step1, i++ )
         data->list1[i] = x;
      for( x=start2, i=0; i<data->npts2; x+=step2, i++ )
         data->list2[i] = x;

      d->bias_data = data;
   }

   return 0;
}




