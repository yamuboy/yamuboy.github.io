#include "gpib.h"

static void modified_bjt_params (BIPOLAR_DEVICE_PARAMETERS *bjt, FILE *file);
static int bjt_dc_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error);
static int bjt_dc_iv_curves (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error);
static int bjt_forward_gummel (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error);
static int bjt_reverse_gummel (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error);
static int bjt_emitter_flyback (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error);
static int bjt_short_gummel (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error);
static int bjt_short_flyback (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error);
static int bjt_s_parameters_over_bias (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error);
static int bjt_hot_s_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error);
static int bjt_cbc_s_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error);
static int bjt_cbe_s_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error);
static int bjt_noise_sweep (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t nfm, FILE *file, char *error);
static int check_for_dead_bjt (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error);
static void tracking_linefit_with_intercept (double *x, double *y, unsigned n, double *m, double *b, double *rs);

#define BJT_SHORT_PTS    11

/********************************************************************************/
/********************************************************************************/

extern int measure_bipolar_device( MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error )
{
   FILE *file;
   BIPOLAR_DEVICE_PARAMETERS *bjt = &d->bjt_device;
   HEADER_INFO *head = &d->header_info;
   unsigned i;

   // check for a valid test type
   if ((d->test_type != DEV_DC_SCREEN) && (d->test_type != DEV_DC) && (d->test_type != DEV_DC_AND_S) && (d->test_type != DEV_NOISE))
   {
      sprintf (error, "measure_bipolar_device(): invalid test type.\n");
      return 1;
   }

   // calculate and check area
   bjt->em_area = bjt->em_width * bjt->em_length * bjt->num_em_fingers;
   if (bjt->em_area < 1.0)
   {
      sprintf (error, "measure_bipolar_device(): calculated emitter area is less than 1 um^2.");
      return 1;
   }

   // check for an existing file of the same name
   if( d->test_type != DEV_DC_SCREEN )
      create_backup_file( fname );

   // open the file for writing
   file = fopen( fname, "w+");
   if (!file)
   {
      sprintf (error, "measure_bipolar_device(): unable to open file for writing.");
      return 1;
   }

   // write the header
   fprintf (file, "!FILE NAME: %s\n", fname);
   fprintf (file, "!WAFER NUMBER: %s\n", head->wafer);
   fprintf (file, "!PROCESS NAME: %s\n", head->process);
   fprintf (file, "!DEVICE NAME: %s\n", head->device);
   fprintf (file, "!EMITTER AREA (um^2): %.1f\n", bjt->em_area);
   fprintf (file, "!EMITTER LENGTH (um): %.1f\n", bjt->em_length);
   fprintf (file, "!EMITTER WIDTH (um): %.1f\n", bjt->em_width);
   fprintf (file, "!NUMBER OF EMITTER FINGERS: %u\n", bjt->num_em_fingers);
   fprintf (file, "!EMITTER SPACING (um): %s\n", bjt->em_spacing);
   fprintf (file, "!CALKIT: %s\n", head->calkit);
   fprintf (file, "!TEMPERATURE (C): %.1f\n", head->temperature);
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time ());
   fprintf (file, "!COMMENTS:\n");
   if (head->comments[0])
   {
      fputc ('!', file);
      for (i = 0; head->comments[i]; ++i)
      {
         fputc (head->comments[i], file);
         if (head->comments[i] == '\n')
            fputc ('!', file);
      }
      fputc ('\n', file);
   }
   fprintf (file,"!\n");
   fflush (file);

   // check for modified device parameters
   modified_bjt_params (bjt, file);

   if (bjt_dc_parameters (bjt, inst->bias1, inst->bias2, error))
   {
      fclose (file);
      return 1;
   }

   if (check_abort_flag())
   {
      fclose (file);
      return 0;
   }

   if (bjt->do_extended_screen)
   {
      if (bjt_short_gummel (bjt, inst->bias1, inst->bias2, error))
      {
         fclose (file);
         return 1;
      }

      if (check_abort_flag())
      {
         fclose (file);
         return 0;
      }

      if (bjt_short_flyback (bjt, inst->bias1, inst->bias2, error))
      {
         fclose (file);
         return 1;
      }

      if (check_abort_flag())
      {
         fclose (file);
         return 0;
      }

      fprintf (file, "!                            DC BJT PARAMETERS\n");
      fprintf (file, "!Vb_beo(v)   Vb_ceo(v)   Vb_cbo(v)    Beta_30k    Beta_10k    Beta_1      Ib_max(A)   Vb_max(v)");
      fprintf (file, "   Isb(A)     Nb        R^2       Isc(A)      Nc         R^2     Vth_calc(v)   Re(ohm)     R^2\n");
      fprintf (file, "%+.4e %+.4e %+.4e %+.4e %+.4e %+.4e %+.4e %+.4e %.4e %.4e %.4e %.4e %.4e %.4e %.4e %.4e %.4e\n",
         bjt->vbr_beo, bjt->vbr_ceo, bjt->vbr_cbo, bjt->beta1, bjt->beta2, bjt->beta3, bjt->ibe_m, bjt->vbe_m,
         bjt->ls_isb, bjt->ls_nb, bjt->ls_b_r2, bjt->ls_isc, bjt->ls_nc, bjt->ls_c_r2, bjt->ls_vth, bjt->ls_re, bjt->ls_re_r2);
   }
   else
   {
      fprintf (file, "!                            DC BJT PARAMETERS\n");
      fprintf (file, "!Vb_beo(v)   Vb_ceo(v)   Vb_cbo(v)    Beta_30k    Beta_10k    Beta_1       Ib_max     Vb_max\n");
      fprintf (file, "%+.4e %+.4e %+.4e %+.4e %+.4e %+.4e %+.4e %+.4e\n",
         bjt->vbr_beo, bjt->vbr_ceo, bjt->vbr_cbo, bjt->beta1, bjt->beta2, bjt->beta3, bjt->ibe_m, bjt->vbe_m);
   }

   fflush (file);

   if (d->test_type == DEV_DC_SCREEN)
   {
      fclose (file);
      return 0;
   }

   if (d->test_type != DEV_NOISE)
   {
      // forward Gummel curves
      if (bjt->do_fwd_gum)
      {
         fprintf (file,"!\n");
         fprintf (file,"!           FORWARD GUMMEL CURVES\n");
         fprintf (file,"!   Vce        Ice          Vbe        Ibe\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (bjt_forward_gummel (bjt, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return 1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      // reverse Gummel curves
      if (bjt->do_rev_gum)
      {
         fprintf (file,"!\n");
         fprintf (file,"!           REVERSE GUMMEL CURVES\n");
         fprintf (file,"!   Vce        Ice          Vbe        Ibe\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (bjt_reverse_gummel (bjt, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return -1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }


      // emitter flyback
      if (bjt->do_flyback)
      {
         fprintf (file,"!\n");
         fprintf (file,"!             RE FLYBACK CURVE\n");
         fprintf (file,"!   Vce        Ice          Vbe        Ibe\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (bjt_emitter_flyback (bjt, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return 1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      // DC I-V curves
      if (bjt->do_dciv)
      {
         fprintf (file,"!\n");
         fprintf (file,"!               DC IV-CURVES\n");
         fprintf (file,"!   Vce        Ice          Vbe        Ibe\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (bjt_dc_iv_curves (bjt, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return 1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      if (d->test_type == DEV_DC)
      {
         fclose (file);
         if (check_for_dead_bjt (bjt, inst->bias1, inst->bias2, error))
            return 1;
         return 0;
      }

      // hot S-parameters
      if (bjt->do_hotsp)
      {
         fprintf (file,"!                                       COLD BJT S-PARAMETERS\n");
         if (bjt_hot_s_parameters (bjt, inst->bias1, inst->bias2, inst->vna, file, error))
         {
            fclose (file);
            return 1;
         }

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      // B-C capacitance S-parameters
      if (bjt->do_cbcsp)
      {
         fprintf (file,"!                                       CBC BJT S-PARAMETERS\n");
         if (bjt_cbc_s_parameters (bjt, inst->bias1, inst->bias2, inst->vna, file, error))
         {
            fclose (file);
            return 1;
         }

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      // B-E capacitance S-parameters
      if (bjt->do_cbesp)
      {
         fprintf (file,"!                                       CBE BJT S-PARAMETERS\n");
         if (bjt_cbe_s_parameters (bjt, inst->bias1, inst->bias2, inst->vna, file, error))
         {
            fclose (file);
            return 1;
         }

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      // S-parameters over bias
      if (bjt->do_sparams)
      {
         fprintf (file,"!                                         BJT S-PARAMETERS\n");
         if (bjt_s_parameters_over_bias (bjt, inst->bias1, inst->bias2, inst->vna, file, error))
         {
            fclose (file);
            return 1;
         }

         if (check_abort_flag())
         {
            fclose (file);
            return 0;
         }
      }

      fclose (file);

      if (check_for_dead_bjt (bjt, inst->bias1, inst->bias2, error))
         return 1;

      return 0;
   }

   else
   {
      if (bjt_noise_sweep (bjt, inst->bias1, inst->bias2, inst->nfm, file, error))
      {
         fclose (file);
         return 1;
      }

      fclose (file);

      if (check_for_dead_bjt (bjt, inst->bias1, inst->bias2, error))
         return 1;

      return 0;
   }
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_dc_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error)
{
   char string[200];
   double base_compl, coll_compl;
   double vcc, icc, target_icc, ibb;
   unsigned n;
   double ibr = fabs (bjt->ibr * 1.0e-5 * bjt->em_area);

   update_test_function ("DC parameters");

   // base-emitter breakdown
   if (bjt->do_beo_breakdown)
   {
      update_test_status ("BEO breakdown");
      gpib_bias_set (base, SRC_CURRENT, -ibr, bjt->vbr_compliance, HIGH_RES, AUTO_RANGE, 3000);
      gpib_bias_trig (base);
      gpib_bias_read (base, NULL, &bjt->vbr_beo);
      gpib_bias_off (base);
   }
   else
      bjt->vbr_beo = -99.999999;

   // collector-base breakdown
   if (bjt->do_cbo_breakdown)
   {
      double vb;
      update_test_status ("CBO breakdown");
      gpib_bias_set (base, SRC_CURRENT, -ibr, bjt->vbr_compliance, HIGH_RES, AUTO_RANGE, 3000);
      gpib_bias_set (coll, SRC_CURRENT, ibr, bjt->vbr_compliance, HIGH_RES, AUTO_RANGE, 3000);
      trigger_smus (base, coll);
      gpib_bias_read (base, NULL, &vb);
      gpib_bias_read (coll, NULL, &bjt->vbr_cbo);
      gpib_bias_off (coll);
      gpib_bias_off (base);
      bjt->vbr_cbo -= vb;
   }
   else
      bjt->vbr_cbo = 99.999999;

   // collector-emitter breakdown
   if (bjt->do_ceo_breakdown)
   {
      update_test_status ("CEO breakdown");
      gpib_bias_set (coll, SRC_CURRENT, ibr, bjt->vbr_compliance, HIGH_RES, AUTO_RANGE, 3000);
      gpib_bias_trig (coll);
      gpib_bias_read (coll, NULL, &bjt->vbr_ceo);
      gpib_bias_off (coll);
   }
   else
      bjt->vbr_ceo = 99.999999;

   base_compl = bjt->max_vbe;
   coll_compl = bjt->em_area*1.0e-5*bjt->max_ice;

   if (check_abort_flag ())
      return 0;

   /* Beta_1 - also Vbe_max and Ibe_max */

   sprintf (string, "Beta @ %.1f V, %.1f kA/cm^2", bjt->vce_for_beta, bjt->ice_for_beta1);
   update_test_status (string);

   vcc = bjt->vce_for_beta;
   target_icc = bjt->em_area*1.0e-5*bjt->ice_for_beta1;
   ibb = target_icc / bjt->approx_beta;

   gpib_bias_set (coll, SRC_VOLTAGE, vcc, coll_compl, MEDIUM_RES, AUTO_RANGE, 500);
   gpib_bias_set (base, SRC_CURRENT, ibb, base_compl, MEDIUM_RES, AUTO_RANGE, 100);
   gpib_bias_trig (coll);
   gpib_bias_read (coll, NULL, &icc);

   if (icc < ibb)
   {
      gpib_bias_off (base);
      gpib_bias_off (coll);
      sprintf (error, "bjt_dc_parameters(): device has current gain of less than 1.\nIbb = %.3e, Icc = %.3e, Beta = %.3f", ibb, icc, icc / ibb);
      return 1;
   }

   n = 0;
   while ((fabs (icc-target_icc) > 0.01*target_icc) && (++n < 10))
   {
      ibb *= target_icc / icc;
      gpib_bias_set (coll, SRC_VOLTAGE, vcc, coll_compl, MEDIUM_RES, AUTO_RANGE, 500);
      gpib_bias_set (base, SRC_CURRENT, ibb, base_compl, MEDIUM_RES, AUTO_RANGE, 100);
      gpib_bias_trig (coll);
      gpib_bias_read (coll, NULL, &icc);
   }
   gpib_bias_trig (base);
   gpib_bias_read (base, &bjt->ibe_m, &bjt->vbe_m);
   bjt->beta1 = icc / ibb;

   if (icc > 0.98*coll_compl)
   {
      gpib_bias_off (base);
      gpib_bias_off (coll);
      sprintf (error, "bjt_dc_parameters(): the device is shorted.\nIce = %.3e", icc);
      return 1;
   }

   /* Beta_2 */

   sprintf (string, "Beta @ %.1f V, %.1f kA/cm^2", bjt->vce_for_beta, bjt->ice_for_beta2);
   update_test_status (string);

   target_icc = bjt->em_area*1.0e-5*bjt->ice_for_beta2;

   n = 0;
   while ((fabs (icc-target_icc) > 0.01*target_icc) && (++n < 10))
   {
      ibb *= target_icc / icc;
      gpib_bias_set (coll, SRC_VOLTAGE, vcc, coll_compl, MEDIUM_RES, AUTO_RANGE, 500);
      gpib_bias_set (base, SRC_CURRENT, ibb, base_compl, MEDIUM_RES, AUTO_RANGE, 100);
      gpib_bias_trig (coll);
      gpib_bias_read (coll, NULL, &icc);
   }
   bjt->beta2 = icc / ibb;

   /*   Beta_3   */

   sprintf (string, "Beta @ %.1f V, %.3f kA/cm^2", bjt->vce_for_beta, bjt->ice_for_beta3);
   update_test_status (string);

   target_icc = bjt->em_area*1.0e-5*bjt->ice_for_beta3;

   n = 0;
   while ((fabs (icc-target_icc) > 0.01*target_icc) && (++n < 10))
   {
      ibb *= target_icc / icc;
      gpib_bias_set (coll, SRC_VOLTAGE, vcc, coll_compl, MEDIUM_RES, AUTO_RANGE, 500);
      gpib_bias_set (base, SRC_CURRENT, ibb, base_compl, MEDIUM_RES, AUTO_RANGE, 100);
      gpib_bias_trig (coll);
      gpib_bias_read (coll, NULL, &icc);
   }
   bjt->beta3 = icc / ibb;

   gpib_bias_off (base);
   gpib_bias_off (coll);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_dc_iv_curves (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error)
{
   double ibe_list[50];
   double vce_list[200];
   double ibe, vce, max_vce;
   double start, stop, step;
   double max_pow, coll_compl;
   unsigned num_b, num_c;

   update_test_function ("I-V curves");

   stop  = bjt->ibe_m;
   step  = stop / ((double) bjt->dciv_npts);
   start = 0.0;
   stop += step*0.5;

   for (ibe = start, num_b = 0; ibe < stop; ibe += step, ++num_b)
   {
      if (num_b >= 50)
         break;
      ibe_list[num_b] = ibe;
   }

   if (bjt->vbr_ceo < (bjt->max_vce+0.5))
      max_vce = bjt->vbr_ceo - 0.5;
   else
      max_vce = bjt->max_vce + 0.1;

   for (vce = 0.0, num_c = 0; vce < 1.01; vce += 0.05, ++num_c)
      vce_list[num_c] = vce;
   for (vce = 1.2; vce < 2.01; vce += 0.2, ++num_c)
      vce_list[num_c] = vce;
   for (vce = 2.5; vce < max_vce; vce += 0.5, ++num_c)
   {
      if (num_c >= 200)
         break;
      vce_list[num_c] = vce;
   }

   max_pow = bjt->em_area * 1.0e-5 * bjt->max_power;
   coll_compl = bjt->em_area * 1.0e-5 * bjt->max_ice;

   return general_iv_curves (base, coll, file, error, SRC_CURRENT, ibe_list, num_b, bjt->max_vbe,
      SRC_VOLTAGE, vce_list, num_c, coll_compl, max_pow, 1.0e6, 1, bjt->dc_delay);
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_forward_gummel (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error)
{
   double coll_c, base_c;
   double vce, vbe, ice, ibe;
   double start1, stop1, step1, v;
   double start2, stop2, step2;
   unsigned pts1, pts2, i;
   char buffer[100];

   update_test_function ("Forward Gummel Curves");

   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;
   base_c = bjt->em_area * 1.0e-5 * bjt->max_ibe;

   step1  = 0.025 * bjt->vbe_m;
   start1 = step1;
   stop1  = 0.5 * bjt->vbe_m - 0.5*step1;
   pts1 = get_npts (start1, stop1, step1);

   step2 = 0.00625 * bjt->vbe_m;
   start2 = 0.5 * bjt->vbe_m;
   stop2 = bjt->vbe_m + 5.5 * step2;
   pts2 = get_npts (start2, stop2, step2);

   for (v = start1, i = 1; v < stop1; v += step1, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts1+pts2);
      update_test_status (buffer);

      gpib_bias_set (coll, SRC_VOLTAGE, v, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (base, SRC_VOLTAGE, v, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (coll, base);
      if (gpib_bias_read (coll, &vce, &ice) || gpib_bias_read (base, &vbe, &ibe))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vce, ice, vbe, ibe);

      if (check_abort_flag())
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 0;
      }
   }

   for (v = start2; v < stop2; v += step2, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts1+pts2);
      update_test_status (buffer);

      gpib_bias_set (coll, SRC_VOLTAGE, v, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (base, SRC_VOLTAGE, v, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (coll, base);
      if (gpib_bias_read (coll, &vce, &ice) || gpib_bias_read (base, &vbe, &ibe))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vce, ice, vbe, ibe);

      if (check_abort_flag())
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 0;
      }
   }

   gpib_bias_off (base);
   gpib_bias_off (coll);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_reverse_gummel (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error)
{
   double coll_c, base_c;
   double vce, vbe, ice, ibe;
   double start, stop, step, v;
   unsigned pts, i;
   char buffer[100];

   update_test_function ("Reverse Gummel Curves");

   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;
   base_c = bjt->em_area * 1.0e-5 * bjt->max_ibe;

   step  = 0.02 * bjt->vbe_m;
   start = step;
   stop  = bjt->vbe_m + 0.5*step;
   pts = get_npts (start, stop, step);

   for (v = start, i = 1; v < stop; v += step, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts);
      update_test_status (buffer);

      gpib_bias_set (base, SRC_VOLTAGE, 0.0, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (coll, SRC_VOLTAGE, -v, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (base, coll);
      if (gpib_bias_read (base, &vbe, &ibe) || gpib_bias_read (coll, &vce, &ice))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vce, ice, vbe, ibe);

      if (check_abort_flag())
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 0;
      }
   }

   gpib_bias_off (coll);
   gpib_bias_off (base);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_emitter_flyback (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, FILE *file, char *error)
{
   double coll_c, base_c;
   double vce, vbe, ice, ibe;
   double start, stop, step, ib;
   unsigned pts, i;
   char buffer[100];

   update_test_function ("Emitter Flyback");

   stop = 25.0 * bjt->ibe_m;
   if (stop > bjt->max_ibe)
      stop = bjt->max_ibe;
   step = 0.05 * stop;
   start = step;
   stop += 0.5 * step;
   pts = get_npts (start, stop, step);

   base_c = bjt->max_vbe;
   coll_c = bjt->max_vbe;

   for (ib = start, i = 1; ib < stop; ib += step, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts);
      update_test_status (buffer);

      gpib_bias_set (coll, SRC_CURRENT, 0.0, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (base, SRC_CURRENT, ib, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (coll, base);
      if (gpib_bias_read (coll, &ice, &vce) || gpib_bias_read (base, &ibe, &vbe))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vce, ice, vbe, ibe);

      if (check_abort_flag())
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 0;
      }
   }

   gpib_bias_off (base);
   gpib_bias_off (coll);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_short_gummel (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error)
{
   double coll_c, base_c;
   double vce[BJT_SHORT_PTS];
   double vbe[BJT_SHORT_PTS];
   double ice[BJT_SHORT_PTS];
   double ibe[BJT_SHORT_PTS];
   double start, stop, step, v;
   double m, b;
   unsigned i;
   char buffer[100];

   update_test_function ("Short Forward Gummel Curves");

   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;
   base_c = bjt->em_area * 1.0e-5 * bjt->max_ibe;

   start = bjt->gummel_vstart;
   stop = bjt->gummel_vstop;
   step = (stop - start) / ((double) (BJT_SHORT_PTS-1));
   stop += 0.5*step;

   for (v = start, i = 0; v < stop; v += step, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i+1, BJT_SHORT_PTS);
      update_test_status (buffer);

      gpib_bias_set (coll, SRC_VOLTAGE, v, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (base, SRC_VOLTAGE, v, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (coll, base);
      if (gpib_bias_read (coll, &vce[i], &ice[i]) || gpib_bias_read (base, &vbe[i], &ibe[i]))
         break;

      if (check_abort_flag())
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 0;
      }
   }

   gpib_bias_off (base);
   gpib_bias_off (coll);

   // calculate the base and emitter idealities and saturation currents, and threshold voltage

   for (i = 0; i < BJT_SHORT_PTS; ++i)
   {
      ibe[i] = log (ibe[i]);
      ice[i] = log (ice[i]);
   }

   tracking_linefit_with_intercept (vbe, ibe, BJT_SHORT_PTS, &m, &b, &bjt->ls_b_r2);
   bjt->ls_nb = 1.0 / (0.0259 * m);
   bjt->ls_isb = pow (10.0, b);

   tracking_linefit_with_intercept (vce, ice, BJT_SHORT_PTS, &m, &b, &bjt->ls_c_r2);
   bjt->ls_nc = 1.0 / (0.0259 * m);
   bjt->ls_isc = pow (10.0, b);

   bjt->ls_vth = bjt->ls_nc * 0.0259 * log (bjt->em_area * 1.0e-8 / bjt->ls_isc);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_short_flyback (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error)
{
   double coll_c, base_c;
   double vce[BJT_SHORT_PTS];
   double vbe[BJT_SHORT_PTS];
   double ice[BJT_SHORT_PTS];
   double ibe[BJT_SHORT_PTS];
   double start, stop, step, ib;
   double m, b;
   unsigned i;
   char buffer[100];

   update_test_function ("Short Emitter Flyback");

   start = bjt->flyback_istart * 1.0e-5 * bjt->em_area;
   stop = bjt->flyback_istop * 1.0e-5 * bjt->em_area;
   step = (stop - start) / ((double) (BJT_SHORT_PTS-1));
   stop += 0.5 * step;

   base_c = bjt->max_vbe;
   coll_c = bjt->max_vbe;

   for (ib = start, i = 0; ib < stop; ib += step, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i+1, BJT_SHORT_PTS);
      update_test_status (buffer);

      gpib_bias_set (coll, SRC_CURRENT, 0.0, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (base, SRC_CURRENT, ib, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (coll, base);
      if (gpib_bias_read (coll, &ice[i], &vce[i]) || gpib_bias_read (base, &ibe[i], &vbe[i]))
         break;

      if (check_abort_flag())
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 0;
      }
   }

   gpib_bias_off (base);
   gpib_bias_off (coll);

   // calculate the emitter resistance
   tracking_linefit_with_intercept (ibe, vce, BJT_SHORT_PTS, &m, &b, &bjt->ls_re_r2);
   bjt->ls_re = m;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

int bjt_s_parameters_over_bias (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error)
{
   double ibe_list[50];
   double vce, ice, vbe, ibe;
   double base_c, coll_c, max_pow, max_vce, coll_compl;
   double start, stop, step, vc;
   double *flist = NULL;
   unsigned i, num_b, pts;
   char buffer[100];

   update_test_function ("[S]-Parameters");

   stop = bjt->ibe_m;
   step = stop / ((double) bjt->sparam_npts);
   start = step;
   stop += step*0.5;

   for (ibe = 0.25*start, num_b = 0; ibe < 0.99 * start; ibe += step*0.25, ++num_b)
      ibe_list[num_b] = ibe;
   for (ibe = start; ibe < stop; ibe += step, ++num_b)
   {
      if (num_b >= 50)
         break;
      ibe_list[num_b] = ibe;
   }

   if (bjt->vbr_ceo < (bjt->max_vce + 0.5))
      max_vce = bjt->vbr_ceo - 0.5;
   else
      max_vce = bjt->max_vce + 0.5;

   max_pow = bjt->em_area * 1.0e-5 * bjt->max_power;
   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;
   base_c = bjt->max_vbe;
   pts = get_npts (1.0, max_vce, bjt->sparam_vce_step);

   for (i = 0; i < num_b; ++i)
   {
      for (vc = 1.0; vc < max_vce; vc += bjt->sparam_vce_step)
      {
         sprintf (buffer, "%u of %u pnts", i*pts+get_thispt(vc,1.0,bjt->sparam_vce_step), num_b*pts);
         update_test_status (buffer);

         /* calculate the power limit compliance */
         coll_compl = ( vc != 0.0 ) ? max_pow / vc : 1.0e12;
         if( coll_c < coll_compl )
            coll_compl = coll_c;

         gpib_bias_set (coll, SRC_VOLTAGE, vc, coll_compl, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
         gpib_bias_set (base, SRC_CURRENT, ibe_list[i], base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

         trigger_smus (coll, base);
         if (gpib_bias_read (coll, &vce, &ice) || gpib_bias_read (base, &ibe, &vbe))
            break;

         fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

         if (general_s_parameters (vna, file, error, &flist, 0))
         {
            gpib_bias_off (base);
            gpib_bias_off (coll);
            return 1;
         }

         if (check_abort_flag())
         {
            gpib_bias_off (base);
            gpib_bias_off (coll);
            return 0;
         }
      }

      gpib_bias_off (base);
      gpib_bias_off (coll);
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_hot_s_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error)
{
   double vce, ice, vbe, ibe;
   double base_c, coll_c;
   double start, stop, step, ib;
   double *flist = NULL;
   unsigned i;
   char buffer[100];

   update_test_function ("Hot [S]-Parameters");

   stop = bjt->em_area * 1.0e-5 * bjt->max_ibe;
   step = stop / ((double) bjt->hotsp_npts);
   start = step;
   stop += 0.5*step;

   base_c = bjt->max_vbe;
   coll_c = bjt->max_vbe;

   for (ib = start, i = 1; ib < stop; ib += step, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, bjt->hotsp_npts);
      update_test_status (buffer);

      gpib_bias_set (coll, SRC_CURRENT, 0.0, coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (base, SRC_CURRENT, ib, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (coll, base);
      if (gpib_bias_read (coll, &ice, &vce) || gpib_bias_read (base, &ibe, &vbe))
         break;

      fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (base);
         gpib_bias_off (coll);
         return 0;
      }
   }

   gpib_bias_off (base);
   gpib_bias_off (coll);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_cbc_s_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error)
{
   double vce, ice, vbe, ibe;
   double base_c, coll_c, min_vbe;
   double start1, stop1, step1, v;
   double start2, stop2, step2;
   double *flist = NULL;
   unsigned i, pts1, pts2;
   char buffer[100];

   update_test_function ("B-C Capacitance [S]-Params");

   if (bjt->min_vrev < (-bjt->vbr_cbo + 1.0))
      min_vbe = -bjt->vbr_cbo + 1.0;
   else
      min_vbe = bjt->min_vrev;

   start1 = min_vbe;
   stop1 = 0.0;
   step1 = -0.2 * min_vbe;
   pts1 = get_npts (start1, stop1, step1);
   stop1 += 0.5 * step1;

   stop2 = floor (bjt->vbe_m*10.0) * 0.1;
   step2 = 0.1 * stop2;
   start2 = step2;
   pts2 = get_npts (start2, stop2, step2);
   stop2 += 0.5 * step2;

   base_c = bjt->em_area * 1.0e-5 * bjt->max_ibe;
   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;

   for (v = start1, i = 1; v < stop1; v += step1, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts1+pts2);
      update_test_status (buffer);

      gpib_bias_set (base, SRC_VOLTAGE, -fabs(bjt->capsp_voffs), base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (coll, SRC_VOLTAGE, -v-fabs(bjt->capsp_voffs), coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (base, coll);
      if (gpib_bias_read (base, &vbe, &ibe) || gpib_bias_read (coll, &vce, &ice))
         break;

      fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 0;
      }
   }

   for (v = start2; v < stop2; v += step2, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts1+pts2);
      update_test_status (buffer);

      gpib_bias_set (base, SRC_VOLTAGE, -fabs(bjt->capsp_voffs), base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (coll, SRC_VOLTAGE, -v-fabs(bjt->capsp_voffs), coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (base, coll);
      if (gpib_bias_read (base, &vbe, &ibe) || gpib_bias_read (coll, &vce, &ice))
         break;

      fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 0;
      }
   }

   gpib_bias_off (coll);
   gpib_bias_off (base);

   return 0;
}


/******************************************************************************************/
/******************************************************************************************/

static int bjt_cbe_s_parameters (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t vna, FILE *file, char *error)
{
   double vce, ice, vbe, ibe;
   double base_c, coll_c, min_vbe;
   double start1, stop1, step1, v;
   double start2, stop2, step2;
   double *flist = NULL;
   unsigned i, pts1, pts2;
   char buffer[100];

   update_test_function ("B-C Capacitance [S]-Params");

   if (bjt->min_vrev < (bjt->vbr_beo + 1.0))
      min_vbe = bjt->vbr_beo + 1.0;
   else
      min_vbe = bjt->min_vrev;

   start1 = min_vbe;
   stop1 = 0.0;
   step1 = -0.2 * min_vbe;
   pts1 = get_npts (start1, stop1, step1);
   stop1 += 0.5 * step1;

   stop2 = floor (bjt->vbe_m*10.0) * 0.1;
   step2 = 0.1 * stop2;
   start2 = step2;
   pts2 = get_npts (start2, stop2, step2);
   stop2 += 0.5 * step2;

   base_c = bjt->em_area * 1.0e-5 * bjt->max_ibe;
   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;

   for (v = start1, i = 1; v < stop1; v += step1, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts1+pts2);
      update_test_status (buffer);

      gpib_bias_set (base, SRC_VOLTAGE, v, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (coll, SRC_VOLTAGE, v-fabs(bjt->capsp_voffs), coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (base, coll);
      if (gpib_bias_read (base, &vbe, &ibe) || gpib_bias_read (coll, &vce, &ice))
         break;

      fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 0;
      }
   }

   for (v = start2; v < stop2; v += step2, ++i)
   {
      sprintf (buffer, "%u of %u pnts", i, pts1+pts2);
      update_test_status (buffer);

      gpib_bias_set (base, SRC_VOLTAGE, v, base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
      gpib_bias_set (coll, SRC_VOLTAGE, v-fabs(bjt->capsp_voffs), coll_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

      trigger_smus (base, coll);
      if (gpib_bias_read (base, &vbe, &ibe) || gpib_bias_read (coll, &vce, &ice))
         break;

      fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (coll);
         gpib_bias_off (base);
         return 0;
      }
   }

   gpib_bias_off (coll);
   gpib_bias_off (base);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int bjt_noise_sweep (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, gpib_instr_t nfm, FILE *file, char *error)
{
   double ibe_list[50];
   double vce, ice, vbe, ibe;
   double base_c, coll_c, max_pow, max_vce, coll_compl;
   double start, stop, step, vc;
   unsigned i, num_b, pts;
   char buffer[100];

   update_test_function ("Noise");

   stop = bjt->ibe_m;
   step = stop / ((double) bjt->sparam_npts);
   start = step;
   stop += step*0.5;

   for (ibe = 0.25*start, num_b = 0; ibe < 0.99 * start; ibe += step*0.25, ++num_b)
      ibe_list[num_b] = ibe;
   for (ibe = start; ibe < stop; ibe += step, ++num_b)
   {
      if (num_b >= 50)
         break;
      ibe_list[num_b] = ibe;
   }

   if (bjt->vbr_ceo < (bjt->max_vce + 0.5))
      max_vce = bjt->vbr_ceo - 0.5;
   else
      max_vce = bjt->max_vce + 0.5;

   max_pow = bjt->em_area * 1.0e-5 * bjt->max_power;
   coll_c = bjt->em_area * 1.0e-5 * bjt->max_ice;
   base_c = bjt->max_vbe;
   pts = get_npts (1.0, max_vce, bjt->sparam_vce_step);

   for (i = 0; i < num_b; ++i)
   {
      for (vc = 1.0; vc < max_vce; vc += bjt->sparam_vce_step)
      {
         sprintf (buffer, "%u of %u pnts", i*pts+get_thispt(vc,1.0,bjt->sparam_vce_step), num_b*pts);
         update_test_status (buffer);

         /* calculate the power limit compliance */
         coll_compl = ( vc != 0.0 ) ? max_pow / vc : 1.0e12;
         if( coll_c < coll_compl )
            coll_compl = coll_c;

         gpib_bias_set (coll, SRC_VOLTAGE, vc, coll_compl, HIGH_RES, AUTO_RANGE, bjt->dc_delay);
         gpib_bias_set (base, SRC_CURRENT, ibe_list[i], base_c, HIGH_RES, AUTO_RANGE, bjt->dc_delay);

         trigger_smus (coll, base);
         if (gpib_bias_read (coll, &ice, &vce) || gpib_bias_read (base, &ibe, &vbe))
            break;

         fprintf (file,"!BIAS: VCE = %+.5e Volts ICE = %+.5e Amps VBE = %+.5e Volts IBE = %+.5e Amps\n", vce, ice, vbe, ibe);

         if (general_noise (nfm, file, error))
         {
            gpib_bias_off (base);
            gpib_bias_off (coll);
            return 1;
         }

         if (check_abort_flag())
         {
            gpib_bias_off (base);
            gpib_bias_off (coll);
            return 0;
         }
      }

      gpib_bias_off (base);
      gpib_bias_off (coll);
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int check_for_dead_bjt (BIPOLAR_DEVICE_PARAMETERS *bjt, gpib_instr_t base, gpib_instr_t coll, char *error)
{
   double vbb, icc;

   update_test_function ("Check for Dead Device");
   update_test_status ("Biasing at Ibe(beta1)");

   gpib_bias_set (coll, SRC_VOLTAGE, bjt->vce_for_beta, bjt->em_area*1.0e-5*bjt->max_ice, HIGH_RES, AUTO_RANGE, 500);
   gpib_bias_set (base, SRC_CURRENT, bjt->ibe_m, bjt->max_vbe, HIGH_RES, AUTO_RANGE, 500);
   trigger_smus (coll, base);
   gpib_bias_read (coll, NULL, &icc);
   gpib_bias_read (base, NULL, &vbb);
   gpib_bias_off (base);
   gpib_bias_off (coll);

   if (fabs (vbb - bjt->vbe_m) > 0.05)
   {
      sprintf (error, "check_for_dead_bjt(): device failed - barrier height.");
      return 1;
   }
   else if (fabs (1.0 - icc / bjt->ice_for_beta1) > 0.05)
   {
      sprintf (error, "check_for_dead_bjt(): device failed - beta.");
      return 1;
   }

   return 0;
}

/********************************************************************************/
/********************************************************************************/

static void tracking_linefit_with_intercept (double *x, double *y, unsigned n, double *m, double *b, double *rs)
{
   unsigned num_pts = 5;
   unsigned i, j;
   double xsum, ysum, xxsum, yysum;
   double xysum, slope, intercept, r_squared;
   double best_slope = 0.0;
   double best_intr = 0.0;
   double best_rs = 0.0;

   if (n < num_pts)
   {
      *m = 0.0;
      *b = 0.0;
      *rs = 0.0;
      return;
   }

   for (i = n; i > (num_pts-1); --i)
   {
      xsum = ysum = xysum = xxsum = yysum = 0.0;
      for (j = (i-num_pts); j < i; ++j)
      {
         xsum += x[j];
         ysum += y[j];
         xysum += x[j]*y[j];
         xxsum += x[j]*x[j];
         yysum += y[j]*y[j];
      }

      slope = (xysum*((double) num_pts) - xsum*ysum)/(((double) num_pts)*xxsum - xsum*xsum);
      intercept = (ysum-slope*xsum)/((double) num_pts);
      r_squared = xysum*xysum/(xxsum*yysum);

      if (r_squared > best_rs)
      {
         best_slope = slope;
         best_intr = intercept;
         best_rs = r_squared;
      }
   }

   *m = best_slope;
   *b = best_intr;
   *rs = best_rs;
}

/********************************************************************************/
/********************************************************************************/

extern MAIN_DATA mainDataDefaults (void);
extern char *get_str_from_dbl (double x);

static void modified_bjt_params (BIPOLAR_DEVICE_PARAMETERS *bjt, FILE *file)
{
   MAIN_DATA d = mainDataDefaults();
   BIPOLAR_DEVICE_PARAMETERS *def = &d.bjt_device;

   fprintf (file, "!MODIFIED DEVICE PARAMETERS:\n");

   if (bjt->max_vce != def->max_vce)
      fprintf (file, "!Max Vce = %s\n", get_str_from_dbl (bjt->max_vce));

   if (bjt->max_vbe != def->max_vbe)
      fprintf (file, "!Max Vbe = %s\n", get_str_from_dbl (bjt->max_vbe));

   if (bjt->max_power != def->max_power)
      fprintf (file, "!Max Power = %s\n", get_str_from_dbl (bjt->max_power));

   if (bjt->max_ice != def->max_ice)
      fprintf (file, "!Max Ice = %s\n", get_str_from_dbl (bjt->max_ice));

   if (bjt->max_ibe != def->max_ibe)
      fprintf (file, "!Max Ibe = %s\n", get_str_from_dbl (bjt->max_ibe));

   if (bjt->min_vrev != def->min_vrev)
      fprintf (file, "!Max V-reverse = %s\n", get_str_from_dbl (bjt->min_vrev));

   if (bjt->ibr != def->ibr)
      fprintf (file, "!Ibr = %s\n", get_str_from_dbl (bjt->ibr));

   if (bjt->vbr_compliance != def->vbr_compliance)
      fprintf (file, "!Max Vbr = %s\n", get_str_from_dbl (bjt->vbr_compliance));

   if (bjt->vce_for_beta != def->vce_for_beta)
      fprintf (file, "!Vce for Beta = %s\n", get_str_from_dbl (bjt->vce_for_beta));

   if (bjt->approx_beta != def->approx_beta)
      fprintf (file, "!Approx Beta = %s\n", get_str_from_dbl (bjt->approx_beta));

   if (bjt->ice_for_beta1 != def->ice_for_beta1)
      fprintf (file, "!Ice for Beta1 = %s\n", get_str_from_dbl (bjt->ice_for_beta1));

   if (bjt->ice_for_beta2 != def->ice_for_beta2)
      fprintf (file, "!Ice for Beta2 = %s\n", get_str_from_dbl (bjt->ice_for_beta2));

   if (bjt->ice_for_beta3 != def->ice_for_beta3)
      fprintf (file, "!Ice for Beta3 = %s\n", get_str_from_dbl (bjt->ice_for_beta3));

   if (bjt->sparam_vce_step != def->sparam_vce_step)
      fprintf (file, "!Vce Step for S-Params = %s\n", get_str_from_dbl (bjt->sparam_vce_step));

   if (bjt->capsp_voffs != def->capsp_voffs)
      fprintf (file, "!V-offset for Cap S-Params = %s\n", get_str_from_dbl (bjt->capsp_voffs));

   if (bjt->gummel_vstart != def->gummel_vstart)
      fprintf (file, "!Ext Screen Gummel Start = %s\n", get_str_from_dbl (bjt->gummel_vstart));

   if (bjt->gummel_vstop != def->gummel_vstop)
      fprintf (file, "!Ext Screen Gummel Stop = %s\n", get_str_from_dbl (bjt->gummel_vstop));

   if (bjt->flyback_istart != def->flyback_istart)
      fprintf (file, "!Ext Screen Flyback Start = %s\n", get_str_from_dbl (bjt->flyback_istart));

   if (bjt->flyback_istop != def->flyback_istop)
      fprintf (file, "!Ext Screen Flyback Stop = %s\n", get_str_from_dbl (bjt->flyback_istop));

   fprintf (file, "!\n");
}




