#include "gpib.h"

/********************************************************************************/
/********************************************************************************/

extern int set_bias_point( gpib_instr_t bias1, gpib_instr_t bias2, void *inf, int step, double *v1, double *i1, double *v2, double *i2, char *err )
{
   long* cookie = (long*) inf;
   char string[100];
   double compl1, compl2;
   double t1;

   if( !cookie )
   {
      sprintf( err, "Error: bias data structure is empty!!!" );
      return -99;
   }

   if( *cookie == MC_BIAS_SIMULT )
   {
      /* simultaneous biasing function */
      BIAS_SIMULT_DATA *b = (BIAS_SIMULT_DATA *) inf;
      double s1, m1, s2, m2;
      int stat1, stat2;
      int e = 0;

      if( step >= b->npts )
         return -1;

      sprintf (string, "%d of %d points", step+1, b->npts);
      update_test_status (string);

      // set compliance / power limit
      compl1 = fabs( b->compl1 );
      compl2 = fabs( b->compl2 );
      if( b->power_limit1 > 1.e-9 && fabs(b->list1[step]) > 1.e-12 ) {
         t1 = fabs( b->power_limit1 / b->list1[step] );
         compl1 = (t1<compl1) ? t1 : compl1;
      }
      if( b->power_limit2 > 1.e-9 && fabs(b->list2[step]) > 1.e-12 ) {
         t1 = fabs( b->power_limit2 / b->list2[step] );
         compl2 = (t1<compl2) ? t1 : compl2;
      }

      if( b->b2_first )
      {
         /* turn off supplies before setting new bias point */
         gpib_bias_off( bias1 );
         ms_delay( b->offset_delay );
         gpib_bias_off( bias2 );
         ms_delay( b->offset_delay );

         gpib_bias_set (bias2, b->src2, b->list2[step], compl2, HIGH_RES, AUTO_RANGE, b->delay);
         ms_delay( b->offset_delay );
         gpib_bias_set (bias1, b->src1, b->list1[step], compl1, HIGH_RES, AUTO_RANGE, b->delay);

         trigger_smus( bias2, bias1 );
         stat2 = gpib_bias_read( bias2, &s2, &m2 );
         stat1 = gpib_bias_read( bias1, &s1, &m1 );
      }
      else
      {
         /* turn off supplies before setting new bias point */
         gpib_bias_off (bias2);
         ms_delay( b->offset_delay );
         gpib_bias_off (bias1);
         ms_delay( b->offset_delay );

         gpib_bias_set (bias1, b->src1, b->list1[step], compl1, HIGH_RES, AUTO_RANGE, b->delay);
         ms_delay( b->offset_delay );
         gpib_bias_set (bias2, b->src2, b->list2[step], compl2, HIGH_RES, AUTO_RANGE, b->delay);

         trigger_smus( bias1, bias2 );
         stat1 = gpib_bias_read( bias1, &s1, &m1 );
         stat2 = gpib_bias_read( bias2, &s2, &m2 );
      }

      *v1 = (b->src1 == SRC_CURRENT) ? m1 : s1;
      *i1 = (b->src1 == SRC_CURRENT) ? s1 : m1;
      *v2 = (b->src2 == SRC_CURRENT) ? m2 : s2;
      *i2 = (b->src2 == SRC_CURRENT) ? s2 : m2;

      if( stat1 > 0 )
         e++;
      else if( stat1 )
      {
         sprintf( err, "SMU1 error: %s", gpib_errmsg() );
         return -99;
      }

      if( stat2 > 0 )
         e++;
      else if( stat2 )
      {
         sprintf( err, "SMU2 error: %s", gpib_errmsg() );
         return -99;
      }

      return e;
   }

   else if( *cookie == MC_BIAS_NESTED )
   {
      /* nested biasing function */
      BIAS_NESTED_DATA *b = (BIAS_NESTED_DATA *) inf;
      int i = step / b->npts2;
      int j = step % b->npts2; 
      double s1, m1, s2, m2;
      int stat1, stat2;
      int e = 0;

      if( i >= b->npts1 )
         return -1;

      sprintf (string, "%d of %d points", step+1, b->npts1*b->npts2);
      update_test_status (string);

      // set compliance / power limit
      compl1 = fabs( b->compl1 );
      compl2 = fabs( b->compl2 );
      if( b->power_limit1 > 1.e-9 && fabs(b->list1[i]) > 1.e-12 ) {
         t1 = fabs( b->power_limit1 / b->list1[i] );
         compl1 = (t1<compl1) ? t1 : compl1;
      }
      if( b->power_limit2 > 1.e-9 && fabs(b->list2[j]) > 1.e-12 ) {
         t1 = fabs( b->power_limit2 / b->list2[j] );
         compl2 = (t1<compl2) ? t1 : compl2;
      }

      if( b->b2_first )
      {
         /* turn off supplies before setting new bias point */
         gpib_bias_off( bias1 ) ;
         ms_delay( b->offset_delay );
         gpib_bias_off( bias2 );
         ms_delay( b->offset_delay );

         gpib_bias_set( bias2, b->src2, b->list2[j], compl2, HIGH_RES, AUTO_RANGE, b->delay );
         ms_delay( b->offset_delay );
         gpib_bias_set( bias1, b->src1, b->list1[i], compl1, HIGH_RES, AUTO_RANGE, b->delay );

         trigger_smus( bias2, bias1 );
         stat2 = gpib_bias_read( bias2, &s2, &m2 );
         stat1 = gpib_bias_read( bias1, &s1, &m1 );
      }
      else
      {
         /* turn off supplies before setting new bias point */
         gpib_bias_off( bias2 );
         ms_delay( b->offset_delay );
         gpib_bias_off( bias1 );
         ms_delay( b->offset_delay );

         gpib_bias_set( bias1, b->src1, b->list1[i], compl1, HIGH_RES, AUTO_RANGE, b->delay );
         ms_delay( b->offset_delay );
         gpib_bias_set( bias2, b->src2, b->list2[j], compl2, HIGH_RES, AUTO_RANGE, b->delay );

         trigger_smus( bias1, bias2 );
         stat1 = gpib_bias_read( bias1, &s1, &m1 );
         stat2 = gpib_bias_read( bias2, &s2, &m2 );
      }

      *v1 = (b->src1 == SRC_CURRENT) ? m1 : s1;
      *i1 = (b->src1 == SRC_CURRENT) ? s1 : m1;
      *v2 = (b->src2 == SRC_CURRENT) ? m2 : s2;
      *i2 = (b->src2 == SRC_CURRENT) ? s2 : m2;

      if( stat1 > 0  )
         e++;
      else if( stat1 )
      {
         sprintf( err, "SMU1 error: %s", gpib_errmsg() );
         return -99;
      }

      if( stat2 > 0 )
         e++;
      else if( stat2 )
      {
         sprintf( err, "SMU2 error: %s", gpib_errmsg() );
         return -99;
      }

      return e;
   }

   else if( *cookie == MC_BIAS_TARGET_V )
   {
      /* function to target an output current using an input voltage */
      BIAS_TARGET_V_DATA *b = (BIAS_TARGET_V_DATA *) inf;
      int stat1, stat2;
      int e = 0;
      double vgg, vstep;
      int n = 0;

      if( step >= b->npts )
         return -1;

      sprintf (string, "%d of %d points", step+1, b->npts);
      update_test_status (string);

      // set compliance / power limit
      // ignore power limit 1
      compl2 = fabs( b->compl2 );
      if( b->power_limit2 > 1.e-9 && fabs(b->v_out[step]) > 1.e-12 ) {
         t1 = fabs( b->power_limit2 / b->v_out[step] );
         compl2 = (t1<compl2) ? t1 : compl2;
      }


      vgg = b->vin_start[step];
      vstep = (b->vin_max[step] - b->vin_min[step]) * 0.1;

      if( b->b2_first )
      {
         /* turn off supplies before setting new bias point */
         gpib_bias_off (bias1);
         ms_delay( b->offset_delay );
         gpib_bias_off (bias2);
         ms_delay( b->offset_delay );

         gpib_bias_set( bias2, SRC_VOLTAGE, b->v_out[step], compl2, HIGH_RES, AUTO_RANGE, b->delay );
         ms_delay( b->offset_delay );
         gpib_bias_set( bias1, SRC_VOLTAGE, vgg, b->compl1, HIGH_RES, AUTO_RANGE, b->delay );
      }
      else
      {
         /* turn off supplies before setting new bias point */
         gpib_bias_off( bias2 );
         ms_delay( b->offset_delay );
         gpib_bias_off( bias1 );
         ms_delay( b->offset_delay );

         gpib_bias_set( bias1, SRC_VOLTAGE, vgg, b->compl1, HIGH_RES, AUTO_RANGE, b->delay );
         ms_delay( b->offset_delay );
         gpib_bias_set( bias2, SRC_VOLTAGE, b->v_out[step], compl2, HIGH_RES, AUTO_RANGE, b->delay );
      }

      trigger_smus( bias1, bias2 );
      stat1 = gpib_bias_read( bias1, v1, i1 );
      stat2 = gpib_bias_read( bias2, v2, i2 );

      if( stat1 > 0 || stat2 > 0 ) 
      {
         if( b->b2_first )
         {
            gpib_bias_off( bias1 );
            ms_delay( b->offset_delay );
            gpib_bias_off( bias2 );
         }
         else
         {
            gpib_bias_off( bias2 );
            ms_delay( b->offset_delay );
            gpib_bias_off( bias1 );
         }
         return 3;
      }

      /* start the current targeting loop */
      if( *i2 > b->idd[step] )
         vstep = -vstep;

      while( fabs( *i2 - b->idd[step] ) > 0.005*b->idd[step] && ++n <= 25 )
      {
         if( vgg == b->vin_max[step] && vstep > 0.0 )
         {
            if( b->b2_first )
            {
               gpib_bias_off( bias1 );
               ms_delay( b->offset_delay );
               gpib_bias_off( bias2 );
            }
            else
            {
               gpib_bias_off( bias2 );
               ms_delay( b->offset_delay );
               gpib_bias_off( bias1 );
            }
            return 3;
         }
         else if( vgg == b->vin_min[step] && vstep < 0.0 )
         {
            if( b->b2_first )
            {
               gpib_bias_off( bias1 );
               ms_delay( b->offset_delay );
               gpib_bias_off( bias2 );
            }
            else
            {
               gpib_bias_off( bias2 );
               ms_delay( b->offset_delay );
               gpib_bias_off( bias1 );
            }
            return 3;
         }

         ms_delay( b->offset_delay );

         vgg += vstep;
         if( vgg > b->vin_max[step] )
            vgg = b->vin_max[step];
         else if( vgg < b->vin_min[step] )
            vgg = b->vin_min[step];

         gpib_bias_set( bias1, SRC_VOLTAGE, vgg, b->compl1, HIGH_RES, AUTO_RANGE, b->delay );

         trigger_smus( bias1, bias2 );
         stat1 = gpib_bias_read( bias1, v1, i1 );
         stat2 = gpib_bias_read( bias2, v2, i2 );

         if( *i2 < b->idd[step] && vstep < 0.0 )
            vstep *= -0.5;
         else if( *i2 > b->idd[step] && vstep > 0.0 )
            vstep *= -0.5;

         if( fabs(vstep) <= 0.0005 )
            break;
      }

      if( stat1 > 0 )
         e++;

      if( stat2 > 0 )
         e++;

      if( fabs( *i2 - b->idd[step] ) > 0.1*b->idd[step] )
         e++;

      return e;
   }

   /* should not get here */
   sprintf (err, "set_bias_point(): unrecognized magic cookie - unknown bias mode.");
   return -99;
}

/********************************************************************************/
/********************************************************************************/

extern int set_bias_off( gpib_instr_t bias1, gpib_instr_t bias2, void *inf )
{
   long* cookie = (long*) inf;
   int b2_first = 0;
   int offset_delay = 0;

   if( !cookie )
      return 1;

   if( *cookie == MC_BIAS_SIMULT )
   {
      BIAS_SIMULT_DATA *b = (BIAS_SIMULT_DATA *) inf;
      b2_first = b->b2_first;
      offset_delay = b->offset_delay;
   }

   else if( *cookie == MC_BIAS_NESTED )
   {
      BIAS_NESTED_DATA *b = (BIAS_NESTED_DATA *) inf;
      b2_first = b->b2_first;
      offset_delay = b->offset_delay;
   }

   else if( *cookie == MC_BIAS_TARGET_V )
   {
      BIAS_TARGET_V_DATA *b = (BIAS_TARGET_V_DATA *) inf;
      b2_first = b->b2_first;
      offset_delay = b->offset_delay;
   }

   if( b2_first )
   {
      gpib_bias_off( bias1 );
      ms_delay( offset_delay );
      gpib_bias_off( bias2 );
   }
   else
   {
      gpib_bias_off( bias2 );
      ms_delay( offset_delay );
      gpib_bias_off( bias1 );
   }

   return 0;
}

