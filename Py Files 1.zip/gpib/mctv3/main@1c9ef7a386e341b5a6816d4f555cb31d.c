#include <Xm/MainW.h>
#include <unistd.h>
#include "gui.h"

/* global variables (statically defined) */
static MAIN_DATA *global_main_data;
static char global_home_dir[MAX_FNAME_LEN+1];
static XtAppContext global_app_context;
static Widget global_main_window;
static Widget global_fname, global_dev_type;
static Widget global_multi_stat, global_tcr_stat, global_tcc_stat, global_tcs_stat;
static unsigned long global_highlight_color, global_standard_color;

/* global debug level */
int global_debug_level=0;

/* data structure for change directory operations */
typedef struct
{
   Widget w_cwd;
   char *cwd;
   Widget parent;
} CHDIR_DATA;

static void create_main_window( int argc, char** argv );
static void update_main_window_widgets (void);

/* from gui_save_load.c */
extern int load_config_file( char *fname, MAIN_DATA *main_data, char *err_str );

#define STANDARD_COLOR    "maroon"
#define HIGHLIGHT_COLOR   "dark green"

/****************************************************************************/
/****************************************************************************/

extern int main( int argc, char** argv )
{
   MAIN_DATA main_data = mainDataDefaults();
   Display *disp;
   XColor color;
   char *home;
   int i;
   char err_str[200];

   // parse the command line
   for (i = 1; i < argc; ++i)
   {
      if( strncmp( argv[i], "-d", 2 )==0 || strncmp( argv[i], "--debug", 7 )==0 ) {
         int lev=0;
         if( strncmp( argv[i], "-d", 2 )==0 ) {
            sscanf( &argv[i][2], "%d", &lev );
         }
         else { // strncmp( argv[i], "--debug", 7 )==0 
            sscanf( &argv[i][7], "=%d", &lev );
         }
         if( lev > 0 && lev < 10 )
            global_debug_level=lev;
         else
            global_debug_level=4;
      }
      else if( !strcmp(argv[i],"--force") || !strcmp(argv[i],"-f") ) {
          main_data.force = 1;
      }
      else {
         fprintf(stderr,"Error: unrecognized parameter \'%s\'.\n",argv[i]);
         return 1;
      }
   }

   // set global variables
   global_main_data = &main_data;

   /* read in a config file named mct.cfg if it exists */
   load_config_file( "mct.cfg", &main_data, err_str );

   if( !getcwd (main_data.cwd, MAX_FNAME_LEN) )
   {
      fprintf( stderr, "%s: error: unable to get working directory.\n", argv[0] );
      return 1;
   }

   home = getenv ("HOME");
   if (!home)
   {
      fprintf( stderr, "%s: error: unable to get $HOME directory.\n", argv[0] );
      return 1;
   }
   strcpy( global_home_dir, home );

   // create the main window
   create_main_window( argc, argv );

   // set the values of the standard and highlight colors
   disp = XtDisplay (global_main_window);
   XAllocNamedColor (disp, DefaultColormap (disp, DefaultScreen (disp)), STANDARD_COLOR, &color, &color);
   global_standard_color = color.pixel;
   XAllocNamedColor (disp, DefaultColormap (disp, DefaultScreen (disp)), HIGHLIGHT_COLOR, &color, &color);
   global_highlight_color = color.pixel;

   // update the widgets in the main window
   update_main_window_widgets();

   // start the event loop
   XtAppMainLoop (global_app_context);
   return 0;
}

/****************************************************************************/
/****************************************************************************/
/*                              MAIN CALLBACKS                              */
/****************************************************************************/
/****************************************************************************/

static void cb_change_dir (Widget w, XtPointer client_data, XtPointer call_data)
{
   CHDIR_DATA *d = (CHDIR_DATA *) client_data;
   char *str = XmTextGetString( d->w_cwd );
   if (!str)
   {
      db_error_message ("Failed to read directory string.", d->parent);
      return;
   }
   else if( !*str )
   {
      db_error_message ("Invalid directory specification.", d->parent);
      XtFree (str);
      // revert the cwd widget back to the original value
      XmTextSetString (d->w_cwd, d->cwd);
      XmTextSetCursorPosition (d->w_cwd, strlen(d->cwd));
      return;
   }

   if( chdir (str) )
   {
      char string[300];
      sprintf (string, "%s: failed to change to directory.", str);
      db_error_message (string, d->parent);
      XtFree (str);
      // revert the cwd widget back to the original value
      XmTextSetString (d->w_cwd, d->cwd);
      XmTextSetCursorPosition (d->w_cwd, strlen(d->cwd));
      return;
   }

   strcpy (d->cwd, str);
   XtFree (str);
}

/****************************************************************************/
/****************************************************************************/

static void cb_update_filename (Widget w, XtPointer client_data, XtPointer call_data)
{
   char *str = XmTextGetString (global_fname);
   if (!str)
   {
      fprintf (stderr, "Failed to read data file name widget.\n");
      return;
   }

   strcpy (global_main_data->filename, str);
   XtFree (str);
}

/****************************************************************************/
/****************************************************************************/

static void cb_file_menu (Widget w, XtPointer client_data, XtPointer call_data)
{      
   switch ((int) client_data)
   {
   case 0:  // load config dialog
      db_load_config (global_main_window, global_main_data);
      break;

   case 1:  // save config dialog
      db_save_config (global_main_window, global_main_data);
      break;

   case 2:  // exit the application
      exit (0);
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_help_menu (Widget w, XtPointer client_data, XtPointer call_data)
{
   switch ((int) client_data)
   {
   case 0:  // about dialog
      db_about (global_main_window);
      break;
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_setup_file_header (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_edit_header (global_main_window, global_main_data);
};

/****************************************************************************/
/****************************************************************************/

static void cb_setup_multisite (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_multisite_setup (global_main_window, global_main_data);
};

/****************************************************************************/
/****************************************************************************/

static void cb_setup_instruments (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_instrument_setup (global_main_window, global_main_data);
};

/****************************************************************************/
/****************************************************************************/

static void cb_setup_tcontrol (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_tcontrol_setup (global_main_window, global_main_data);
};

/****************************************************************************/
/****************************************************************************/

static void cb_setup_dev_params (Widget w, XtPointer client_data, XtPointer call_data)
{
   switch (global_main_data->device_type)
   {
   case DUT_FET:
      db_fet_device_parameters (global_main_window, global_main_data);
      break;
   case DUT_BIPOLAR:
      db_bjt_device_parameters (global_main_window, global_main_data);
      break;
   case DUT_MOSFET:
      break;
   }
};

/****************************************************************************/
/****************************************************************************/

extern void cb_start_gpib (Widget w, XtPointer client_data, XtPointer call_data)
{
   global_main_data->test_type = (int) client_data;
   start_gpib_thread( global_main_window, global_main_data, global_app_context );
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_device( Widget w, XtPointer client_data, XtPointer call_data )
{
   switch ((int) client_data)
   {
   case 0:
      global_main_data->device_type = DUT_FET;
      break;
   case 1:
      global_main_data->device_type = DUT_BIPOLAR;
      break;
   case 2:
      global_main_data->device_type = DUT_MOSFET;
      break;
   }
}

/****************************************************************************/
/****************************************************************************/

static void cb_general_iv_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
}

/****************************************************************************/
/****************************************************************************/

static void cb_transfer_curve_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
}

/****************************************************************************/
/****************************************************************************/

static void cb_bias_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_setup_bias (global_main_window, global_main_data, (int) client_data);
}

/****************************************************************************/
/****************************************************************************/

static void cb_cal_coeff_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_cal_coeffs( global_main_window, global_main_data );
}

/****************************************************************************/
/****************************************************************************/

static void cb_load_enr_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
   db_load_enr( global_main_window, global_main_data );
}

/****************************************************************************/
/****************************************************************************/
/*                             MAIN WINDOW MENUS                            */
/****************************************************************************/
/****************************************************************************/

static Widget create_main_menu (Widget main_w)
{
   Widget menubar, menu;
   XmString str1, str2, str3;
   XmString acc1, acc2, acc3;

   // create the menu bar
   str1 = XmStringCreateLocalized ("File");
   str2 = XmStringCreateLocalized ("Help");
   menubar = XmVaCreateSimpleMenuBar (main_w, "menubar",
      XmVaCASCADEBUTTON, str1, 'F',
      XmVaCASCADEBUTTON, str2, 'H',
      NULL);
   XmStringFree (str1);
   XmStringFree (str2);

   // set up the file menu
   str1 = XmStringCreateLocalized ("Load...");
   str2 = XmStringCreateLocalized ("Save...");
   str3 = XmStringCreateLocalized ("Exit");
   acc1 = XmStringCreateLocalized ("Ctrl+L");
   acc2 = XmStringCreateLocalized ("Ctrl+S");
   acc3 = XmStringCreateLocalized ("Ctrl+X");
   menu = XmVaCreateSimplePulldownMenu (menubar, "file_menu", 0, cb_file_menu,
      XmVaPUSHBUTTON, str1, 'L', "Ctrl<key>l", acc1,
      XmVaPUSHBUTTON, str2, 'S', "Ctrl<key>s", acc2,
      XmVaSEPARATOR,
      XmVaPUSHBUTTON, str3, 'X', "Ctrl<key>x", acc3,
      NULL);
   XmStringFree (str1);
   XmStringFree (str2);
   XmStringFree (str3);
   XmStringFree (acc1);
   XmStringFree (acc2);
   XmStringFree (acc3);

   // create the help menu
   str1 = XmStringCreateLocalized ("About...");
   menu = XmVaCreateSimplePulldownMenu (menubar, "help_menu", 1, cb_help_menu,
      XmVaPUSHBUTTON, str1, 'A', NULL, NULL,
      NULL);
   XmStringFree (str1);

   XtManageChild (menubar);

   return menubar;
}

/****************************************************************************/
/****************************************************************************/

static Widget create_setup_menu (Widget parent)
{
   XmString text;
   Widget frame, form;
   Widget b_head, b_multi, b_inst, b_tcont;
   int h_offs = 5;
   int v_offs = 5;


   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, parent,
      NULL);

   text = XmStringCreateLocalized ("Setup Menu");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   text = XmStringCreateLocalized ("File Header");
   b_head = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_head, XmNactivateCallback, cb_setup_file_header, NULL);

   text = XmStringCreateLocalized ("Multisite");
   b_multi = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_head,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_multi, XmNactivateCallback, cb_setup_multisite, NULL);

   text = XmStringCreateLocalized ("Instruments");
   b_inst = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_multi,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_inst, XmNactivateCallback, cb_setup_instruments, NULL);

   text = XmStringCreateLocalized ("Temp Control");
   b_tcont = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_inst,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      XmNbottomOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_tcont, XmNactivateCallback, cb_setup_tcontrol, NULL);

   XtManageChild (form);
   XtManageChild (frame);

   return frame;
}

/****************************************************************************/
/****************************************************************************/

static Widget create_device_menu (Widget parent)
{
   XmString text, dut1, dut2, dut3;
   Widget frame, form;
   Widget b_parms, b_screen, b_dc;
   Widget b_dc_and_s, b_noise;
   int h_offs = 5;
   int v_offs = 5;

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, parent,
      NULL);

   text = XmStringCreateLocalized ("Device Menu");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   // create the device type drop-down menu
   dut1 = XmStringCreateLocalized ("FET");
   dut2 = XmStringCreateLocalized ("Bipolar");
   dut3 = XmStringCreateLocalized ("MOSFET");
   text = XmStringCreateLocalized ("Type:");
   global_dev_type = XmVaCreateSimpleOptionMenu (form, "device_type", text, 'D', 0, cb_set_device,
      XmVaPUSHBUTTON, dut1, 'F', NULL, NULL,
      XmVaPUSHBUTTON, dut2, 'B', NULL, NULL,
      XmVaPUSHBUTTON, dut3, 'M', NULL, NULL,
      XmNtopAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (dut1);
   XmStringFree (dut2);
   XmStringFree (dut3);
   XmStringFree (text);
   XtManageChild (global_dev_type);

   text = XmStringCreateLocalized ("Setup Parameters");
   b_parms = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, global_dev_type,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_parms, XmNactivateCallback, cb_setup_dev_params, NULL);

   text = XmStringCreateLocalized ("DC Screen");
   b_screen = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_parms,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_screen, XmNactivateCallback, cb_start_gpib, (XtPointer) DEV_DC_SCREEN);

   text = XmStringCreateLocalized ("DC");
   b_dc = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_screen,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_dc, XmNactivateCallback, cb_start_gpib, (XtPointer) DEV_DC);

   text = XmStringCreateLocalized ("DC and [S]");
   b_dc_and_s = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_dc,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_dc_and_s, XmNactivateCallback, cb_start_gpib, (XtPointer) DEV_DC_AND_S);

   text = XmStringCreateLocalized ("Noise");
   b_noise = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_dc_and_s,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      XmNbottomOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_noise, XmNactivateCallback, cb_start_gpib, (XtPointer) DEV_NOISE);

   XtManageChild (form);
   XtManageChild (frame);

   return frame;
}

/****************************************************************************/
/****************************************************************************/

static Widget create_general_test_menu (Widget parent)
{
   XmString text;
   Widget frame, form;
   Widget b_dciv, b_trans, b_sp;
   Widget b_bias_sp, b_noise, b_bias_noise, b_cal, b_enr;
   int h_offs = 5;
   int v_offs = 5;

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, parent,
      NULL);

   text = XmStringCreateLocalized ("General Test Menu");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   form = XtVaCreateWidget ("form", xmFormWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   text = XmStringCreateLocalized ("DC I-V Curve");
   b_dciv = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNsensitive, False,
      XmNtopAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_dciv, XmNactivateCallback, cb_general_iv_dialog, NULL);

   text = XmStringCreateLocalized ("DC Transfer Curve");
   b_trans = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNsensitive, False,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_dciv,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_trans, XmNactivateCallback, cb_transfer_curve_dialog, NULL);

   text = XmStringCreateLocalized ("S-Parameters");
   b_sp = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_trans,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_sp, XmNactivateCallback, cb_start_gpib, (XtPointer) SPARAMS);

   text = XmStringCreateLocalized ("Biased S-Parameters");
   b_bias_sp = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_sp,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_bias_sp, XmNactivateCallback, cb_bias_dialog, (XtPointer) SPARAMS_W_BIAS);

   text = XmStringCreateLocalized ("Noise");
   b_noise = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_bias_sp,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_noise, XmNactivateCallback, cb_start_gpib, (XtPointer) NOISE);

   text = XmStringCreateLocalized ("Biased Noise");
   b_bias_noise = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_noise,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_bias_noise, XmNactivateCallback, cb_bias_dialog, (XtPointer) NOISE_W_BIAS);

   text = XmStringCreateLocalized ("Read VNA Cal Coeffs");
   b_cal = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_bias_noise,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_cal, XmNactivateCallback, cb_cal_coeff_dialog, NULL);

   text = XmStringCreateLocalized ("Load NFM ENR Table");
   b_enr = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
      XmNlabelString, text,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, b_cal,
      XmNleftAttachment, XmATTACH_FORM,
      XmNrightAttachment, XmATTACH_FORM,
      XmNbottomAttachment, XmATTACH_FORM,
      XmNleftOffset, h_offs,
      XmNrightOffset, h_offs,
      XmNtopOffset, v_offs,
      XmNbottomOffset, v_offs,
      NULL);
   XmStringFree (text);
   XtAddCallback (b_enr, XmNactivateCallback, cb_load_enr_dialog, NULL);

   XtManageChild (form);
   XtManageChild (frame);

   return frame;
}

/****************************************************************************/
/****************************************************************************/

static Widget create_status_area (Widget parent)
{
   XmString text;
   Widget frame, col;

   frame = XtVaCreateWidget ("frame", xmFrameWidgetClass, parent,
      NULL);

   text = XmStringCreateLocalized ("Status Area");
   XtVaCreateManagedWidget ("label", xmLabelGadgetClass, frame,
      XmNframeChildType, XmFRAME_TITLE_CHILD,
      XmNchildVerticalAlignment, XmALIGNMENT_CENTER,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   col = XtVaCreateWidget ("column", xmRowColumnWidgetClass, frame,
      XmNframeChildType, XmFRAME_WORKAREA_CHILD,
      NULL);

   global_multi_stat = create_label_gadget (col, "Multisite: DISABLED");
   global_tcr_stat = create_label_gadget (col, "TC Read: DISABLED");
   global_tcc_stat = create_label_gadget (col, "TC Set: DISABLED");
   global_tcs_stat = create_label_gadget (col, "TC Shutdown: DISABLED");

   XtManageChild (col);
   XtManageChild (frame);

   return frame;
}
/****************************************************************************/
/****************************************************************************/

static void create_main_window( int argc, char** argv )
{
   Widget top, work_area;
   Widget wd_lab, row1, row2, but, cwd_disp;
   Widget setup, device, general, status;
   static BROWSE_INFO cwd_browse;
   static CHDIR_DATA chdir_data;

   // initialize the top level shell
   XtSetLanguageProc (NULL, NULL, NULL);
   top = XtVaAppInitialize (&global_app_context, "Mct", NULL, 0, &argc, argv, NULL, NULL);

   // create the main window widget
   global_main_window = XtVaCreateWidget ("mct_main_window", xmMainWindowWidgetClass, top,
      NULL);

   // create the main menu
   create_main_menu (global_main_window);

   // create the main window work area
   work_area = XtVaCreateWidget ("work_area", xmFormWidgetClass, global_main_window,
      NULL);

   // create the current working directory display widget
   row1 = XtVaCreateWidget ("row", xmRowColumnWidgetClass, work_area,
      XmNorientation, XmHORIZONTAL,
      XmNtopAttachment, XmATTACH_FORM,
      XmNleftAttachment, XmATTACH_FORM,
      NULL);
   wd_lab = create_label_gadget (row1, "CWD:");
   cwd_disp = XtVaCreateManagedWidget ("display", xmTextWidgetClass, row1,
      XmNeditable, False,
      XmNvalue, global_main_data->cwd,
      XmNcursorPosition, strlen (global_main_data->cwd),
      XmNcursorPositionVisible, False,
      XmNcolumns, 75,
      NULL);
   XtManageChild (row1);

   but = create_push_button (work_area, "Change Working Directory...");
   XtVaSetValues (but, XmNtopAttachment, XmATTACH_WIDGET, XmNtopWidget, row1,
      XmNleftAttachment, XmATTACH_FORM, XmNleftOffset, 5, NULL);
   XtAddCallback (but, XmNactivateCallback, cb_browse_dialog, &cwd_browse);
   cwd_browse.path = NULL;
   cwd_browse.pattern = NULL;
   cwd_browse.dir_flag = 1;
   cwd_browse.entry = cwd_disp;
   cwd_browse.parent = global_main_window;
   cwd_browse.cb = cb_change_dir;
   cwd_browse.cb_data = &chdir_data;

   chdir_data.parent = global_main_window;
   chdir_data.w_cwd = cwd_disp;
   chdir_data.cwd = global_main_data->cwd;

   // create the file name entry widget
   row2 = XtVaCreateWidget ("row", xmRowColumnWidgetClass, work_area,
      XmNorientation, XmHORIZONTAL,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, but,
      XmNleftAttachment, XmATTACH_FORM,
      NULL);
   create_label_gadget (row2, "Data File Name:");
   global_fname = XtVaCreateManagedWidget ("filename", xmTextWidgetClass, row2,
      XmNvalue, global_main_data->filename,
      XmNcolumns, 40,
      XmNmaxLength, MAX_FNAME_LEN,
      NULL);
   XtManageChild (row2);

   // create a callback to update the filename when losing focus
   XtAddCallback (global_fname, XmNlosingFocusCallback, cb_update_filename, NULL);

   // create the setup menu
   setup = create_setup_menu (work_area);
   XtVaSetValues (setup,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, row2,
      XmNleftAttachment, XmATTACH_FORM,
      NULL);

   // create the device menu
   device = create_device_menu (work_area);
   XtVaSetValues (device,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, row2,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, setup, 
      NULL);

   // create the general test menu
   general = create_general_test_menu (work_area);
   XtVaSetValues (general,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, row2,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, device,
      NULL);

   // create the status area
   status = create_status_area (work_area);
   XtVaSetValues (status,
      XmNtopAttachment, XmATTACH_WIDGET,
      XmNtopWidget, row2,
      XmNleftAttachment, XmATTACH_WIDGET,
      XmNleftWidget, general,
      NULL);

   XtManageChild (work_area);
   XtManageChild (global_main_window);

   // realize the main window
   XtRealizeWidget (top);
}

/****************************************************************************/
/****************************************************************************/

static void update_main_window_widgets (void)
{
   char str[30];
   Widget w, ob, dd;
   XmString text;
   unsigned long pix;

   // update the Data File Name widget
   XmTextSetString( global_fname, global_main_data->filename );

   // update the Device Type widget
   ob = XmOptionButtonGadget (global_dev_type);
   XtVaGetValues (ob, XmNsubMenuId, &dd, NULL);
   sprintf (str, "button_%d", global_main_data->device_type-1);
   w = XtNameToWidget (dd, str);
   if (w)
      XtVaSetValues (global_dev_type, XmNmenuHistory, w, NULL);
   else
      fprintf (stderr, "update_main_window_widgets(): No widget found.\n");

   // update the status area widgets
   text = global_main_data->multisite.do_multisite ? XmStringCreateLocalized ("Multisite: ENABLED") : XmStringCreateLocalized ("Multisite: DISABLED");
   pix = global_main_data->multisite.do_multisite ? global_highlight_color : global_standard_color; 
   XtVaSetValues (global_multi_stat, XmNlabelString, text, XmNforeground, pix, NULL);
   XmStringFree (text);

   text = global_main_data->tcontrol.read_tset ? XmStringCreateLocalized ("TC Read: ENABLED") : XmStringCreateLocalized ("TC Read: DISABLED");
   pix = global_main_data->tcontrol.read_tset ? global_highlight_color : global_standard_color; 
   XtVaSetValues (global_tcr_stat, XmNlabelString, text, XmNforeground, pix, NULL);
   XmStringFree (text);

   text = global_main_data->tcontrol.set_on_finish ? XmStringCreateLocalized ("TC Set: ENABLED") : XmStringCreateLocalized ("TC Set: DISABLED");
   pix = global_main_data->tcontrol.set_on_finish ? global_highlight_color : global_standard_color; 
   XtVaSetValues (global_tcc_stat, XmNlabelString, text, XmNforeground, pix, NULL);
   XmStringFree (text);

   text = global_main_data->tcontrol.off_on_finish ? XmStringCreateLocalized ("TC Shutdown: ENABLED") : XmStringCreateLocalized ("TC Shutdown: DISABLED");
   pix = global_main_data->tcontrol.off_on_finish ? global_highlight_color : global_standard_color; 
   XtVaSetValues (global_tcs_stat, XmNlabelString, text, XmNforeground, pix, NULL);
   XmStringFree (text);
}

/****************************************************************************/
/****************************************************************************/

extern void cb_update_mainw (Widget w, XtPointer client_data, XtPointer call_data)
{
   update_main_window_widgets ();
}




