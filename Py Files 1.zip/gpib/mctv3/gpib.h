#include <math.h>
#include <instr/instr.h>
#include "common.h"

#ifndef _MCT_GPIB_DEF
#define _MCT_GPIB_DEF

#define MAX_FREQS    1000

#define RENAME_CMD      "mv"
#define BACKUP_SUFFIX   "_bak"

/* instrument structure pointers */
typedef struct
{
   int board_id;
   gpib_instr_t bias1, bias2, vna, nfm, ap, tc;
} INSTRUMENTS;

/****** function prototypes ******/

/* from gpib_fet.c */
extern int measure_fet_device( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );

/* from gpib_bipolar.c */
extern int measure_bipolar_device( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );

/* from gpib_mosfet.c */
extern int measure_mosfet_device( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );

/* from gpib_set_bias.c */
extern int set_bias_point( gpib_instr_t bias1, gpib_instr_t bias2, void *inf, int step, double *v1, double *i1, double *v2, double *i2, char *err );
extern int set_bias_off( gpib_instr_t bias1, gpib_instr_t bias2, void *inf );

/* from gpib_sparams.c */
extern int measure_sparameters( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );
extern int measure_biased_sparameters( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );

/* from gpib_noise.c */
extern int measure_noise( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );
extern int measure_biased_noise( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );

/* from gpib_dccurves.c */
extern int measure_iv_curve( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );
extern int measure_transfer_curve( MAIN_DATA *main_data, INSTRUMENTS *inst, char *fname, char *error );

/* from gpib_other.c */
extern int get_vna_cal_coeffs( MAIN_DATA *main_data, char *error );
extern int end_of_test_tcontrol( MAIN_DATA *main_data, INSTRUMENTS *inst, char *error );
extern int load_nfm_enr_table( MAIN_DATA *main_data, char *error );

/* from gpib_update.c */
/*  -- not included here so that pthread headers do not need to be included
extern void init_update_interface( THREAD_SHARE *share, pthread_mutex_t *mutex )
*/
extern void update_test_type( char *str );
extern void update_test_function( char *str );
extern void update_test_status( char *str );
extern void update_multisite_status( char *str );
extern void record_error_msg( char **err_log, char *file, char *err_str );
extern int check_abort_flag( void );

/* from gpib_utils.c */
extern int general_iv_curves( gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error,
                             int gmode, double *list1, unsigned n1, double gate_c,
                             int dmode, double *list2, unsigned n2, double drain_c,
                             double max_pow, double max_vdg, int drain_first, unsigned delay );
extern int general_s_parameters( gpib_instr_t vna, FILE *file, char *error, double **flist, int write_touchstone_header );
extern int general_noise( gpib_instr_t nfm, FILE *file, char *error );
extern int file_exists( char *filename );
extern void create_backup_file( char *fname );
extern char *get_the_time( void );
extern int trigger_smus( gpib_instr_t smu1, gpib_instr_t smu2 );

#endif

