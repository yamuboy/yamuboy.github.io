#include <time.h>
#include "gpib.h"

/******************************************************************************************/
/******************************************************************************************/

extern int general_iv_curves (gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error,
                              int gmode, double *list1, unsigned n1, double gate_c,
                              int dmode, double *list2, unsigned n2, double drain_c,
                              double max_pow, double max_vdg, int drain_first, unsigned delay)
{
   unsigned i, j;
   double vgs, igs, vds, ids;
   double gs, gm, ds, dm;
   double drain_compl;
   int stg, std;
   char string[100];

   for (i = 0; i < n1; ++i)
   {         
      for (j = 0; j < n2; ++j)
      {
         if (list2[j] - list1[i] > max_vdg)
            continue;

         sprintf (string, "%d of %d points", i*n2 + j + 1, n1*n2);
         update_test_status (string);

         /* calculate the power limit compliance */
         drain_compl = ( list2[j] != 0.0 ) ? max_pow / list2[j] : 1.0e12;
         if( drain_c < drain_compl )
            drain_compl = drain_c;

         if (drain_first)
         {
            gpib_bias_set (drain, dmode, list2[j], drain_compl, HIGH_RES, AUTO_RANGE, delay );
            ms_delay (5);
            gpib_bias_set (gate, gmode, list1[i], gate_c, HIGH_RES, AUTO_RANGE, delay );
            trigger_smus (drain, gate);
            std = gpib_bias_read (drain, &ds, &dm);
            stg = gpib_bias_read (gate, &gs, &gm);
         }
         else
         {
            gpib_bias_set (gate, gmode, list1[i], gate_c, HIGH_RES, AUTO_RANGE, delay );
            ms_delay (5);
            gpib_bias_set (drain, dmode, list2[j], drain_compl, HIGH_RES, AUTO_RANGE, delay );
            trigger_smus (gate, drain);
            stg = gpib_bias_read (gate, &gs, &gm);
            std = gpib_bias_read (drain, &ds, &dm);
         }

         if (stg && !drain_first)   /* gate in compliance, and probably a FET */
            continue;
         else if ((stg && drain_first) || std)  /* gate or drain in compliance */
            break;

         if (gmode == SRC_VOLTAGE)
         {
            vgs = gs;
            igs = gm;
         }
         else if (gmode == SRC_CURRENT)
         {
            vgs = gm;
            igs = gs;
         }
         else
            vgs = igs = 0.0;

         if (dmode == SRC_VOLTAGE)
         {
            vds = ds;
            ids = dm;
         }
         else if (dmode == SRC_CURRENT)
         {
            vds = dm;
            ids = ds;
         }
         else
            vds = ids = 0.0;

         fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vds, ids, vgs, igs);

         if (check_abort_flag())
            break;
      }

      fflush (file);

      if (drain_first)
      {
         gpib_bias_off (gate);
         ms_delay (10);
         gpib_bias_off (drain);
      }
      else
      {
         gpib_bias_off (drain);
         ms_delay (10);
         gpib_bias_off (gate);
      }

      if (check_abort_flag())
         return 0;
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/
#define sqr(x)    ((x)*(x))

extern int general_s_parameters (gpib_instr_t vna, FILE *file, char *error, double **flist, int write_touchstone_header)
{
   unsigned i, ns;
   instr_complex_t sp[MAX_FREQS][4];
   // these must be static
   static double freq[MAX_FREQS];
   static unsigned nf;
   double m11, a11, m22, a22;
   double m12, a12, m21, a21;
   double rad2deg = 180.0 / acos( -1.0 );

   // if flist is NULL, we must read in the VNA frequency list
   if (!(*flist))
   {
      if ( gpib_vna_readflist (vna, freq, MAX_FREQS, &nf) )
      {
         sprintf (error, "vna: error during frequency list read.\n%s", gpib_errmsg() );
         return 1;
      }

      *flist = freq;
   }

   // read S-parameters
   if ( gpib_vna_readsp (vna, sp, MAX_FREQS, &ns) )
   {
      sprintf (error, "vna: error during S-parameter read.\n%s", gpib_errmsg() );
      return 1;
   }

   // check for proper alignment
   if (ns != nf)
   {
      sprintf (error, "general_s_parameters(): size mismatch in arrays!\nThis is most likely a VNA fault.");
      return 1;
   }

   // write the header
   if (write_touchstone_header)
      fprintf (file, "# HZ S MA R 50\n");
   fprintf (file, "!Frequency    S11-Mag      S11-Ang     S21-Mag      S21-Ang     S12-Mag      S12-Ang     S22-Mag      S22-Ang\n");

   // write the S-parameters
   for (i = 0; i < ns; ++i)
   {
      m11 = sqrt( sqr(sp[i][0].real) + sqr(sp[i][0].imag) );
      m12 = sqrt( sqr(sp[i][1].real) + sqr(sp[i][1].imag) );
      m21 = sqrt( sqr(sp[i][2].real) + sqr(sp[i][2].imag) );
      m22 = sqrt( sqr(sp[i][3].real) + sqr(sp[i][3].imag) );
      a11 = atan2( sp[i][0].imag, sp[i][0].real ) * rad2deg;
      a12 = atan2( sp[i][1].imag, sp[i][1].real ) * rad2deg;
      a21 = atan2( sp[i][2].imag, sp[i][2].real ) * rad2deg;
      a22 = atan2( sp[i][3].imag, sp[i][3].real ) * rad2deg;
      fprintf (file, "%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n", freq[i], m11, a11,
         m21, a21, m12, a12, m22, a22);
   }

   fflush (file);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

extern int general_noise (gpib_instr_t nfm, FILE *file, char *error)
{
   double freq[251];
   double nf[251];
   double gain[251];
   unsigned i, num;

   if ( gpib_nfm_readswp (nfm, freq, nf, gain, 251, &num) )
   {
      sprintf (error, "nfm: error during read.\n%s", gpib_errmsg() );
      return 1;
   }

   fprintf (file, "! Freq (Hz)   Gain (dB)   Nfig (dB)\n");
   for (i = 0; i < num; ++i)
      fprintf (file, " %.4e %+.4e %+.4e\n", freq[i], gain[i], nf[i]);

   fflush (file);

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

extern int file_exists (char *filename)
{
   FILE *file = fopen (filename,"r");

   if (file)
   {
      fclose (file);
      return 1;
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

extern void create_backup_file( char *fname )
{
   FILE *file = fopen( fname, "r" );
   if( file )
   {
      char cmd[1000];
      fclose( file );
      sprintf( cmd, "%s \"%s\" \"%s%s\"", RENAME_CMD, fname, fname, BACKUP_SUFFIX );
      system( cmd );
   }
}

/******************************************************************************************/
/******************************************************************************************/

extern char *get_the_time (void)
{
   time_t clock;
   char *pointer;
   char s_day[3];
   char s_month[4];
   char s_year[5];
   char s_time[9];
   static char string[21];

   time (&clock);

   pointer = asctime (localtime (&clock));

   sscanf (pointer+8, "%2s", s_day);
   sscanf (pointer+4, "%3s", s_month);
   sscanf (pointer+20, "%4s", s_year);
   sscanf (pointer+11, "%8s", s_time);

   sprintf (string,"%s-%s-%s %s", s_day, s_month, s_year, s_time);

   return string;
}

/******************************************************************************************/
/******************************************************************************************/

extern int trigger_smus (gpib_instr_t smu1, gpib_instr_t smu2)
{
   gpib_bias_trig(smu1);
   gpib_bias_trig(smu2);
   return 0;
}

