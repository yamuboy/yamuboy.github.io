#include "gui.h"

#define VERSION_STRING      "MCTConfigFileVersion"

/* all of the noise sources use a common frequency list */
static double f_ghz_data[] = {
   0.01, 0.1, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 
      14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 24.0, 25.0, 26.0, 26.5
};

/* S/N 3318A03719 - 6dB */
static double enr_3719[] = {
   5.51, 5.61, 5.49, 5.34, 5.23, 5.18, 5.17, 5.23, 5.36, 5.49, 5.62, 5.79, 5.89, 5.90,
      6.00, 6.02, 6.08, 6.12, 6.07, 5.93
};
static unsigned npts_3719 = 20;

/* S/N 4015A05159 - 12dB */
static double enr_5159[] = {
   12.95, 12.81, 12.89, 12.86, 12.94, 13.06, 13.16, 13.31, 13.52, 13.76, 14.15, 14.32,
      14.35, 14.52, 14.69, 14.79, 14.79, 14.75, 14.77, 14.85, 14.89, 15.01, 15.34, 15.45,
      15.81, 16.00, 15.96, 15.62, 15.35
};
static unsigned npts_5159 = 29;

/* S/N 2339A00727 */
static double enr_0727[] = {
   12.67, 12.55, 12.64, 12.62, 12.68, 12.79, 12.86, 12.98, 13.20, 13.41, 13.71, 13.94,
      14.18, 14.35, 14.52, 14.76, 14.86, 14.86, 14.85, 14.96, 14.83, 14.76, 14.81, 14.86,
      15.19, 15.23, 14.95, 14.59, 14.44
};
static unsigned npts_0727 = 29;

/* S/N 3328A03245 */
static double enr_3245[] = {
   12.91, 12.75, 12.89, 12.95, 12.96, 13.06, 13.16, 13.28, 13.46, 13.70, 13.94, 14.12,
      14.25, 14.40, 14.46, 14.49, 14.53, 14.47, 14.47, 14.50, 14.47, 14.64, 14.86, 15.15,
      15.48, 15.80, 15.91, 15.79, 15.57
}; 
static unsigned npts_3245 = 29;

/* S/N 3318A04951 - 6 dB */
static double enr_4951[] = {
   5.43, 5.43, 5.22, 5.07, 4.95, 4.89, 4.90, 4.97, 5.05, 5.10, 5.30, 5.38,
      5.42, 5.42, 5.39, 5.39, 5.44, 5.37, 5.38, 5.29
}; 
static unsigned npts_4951 = 20;

/* global variable stores the currently selected noise source index */
static int enr_index = 0;

typedef struct
{
   MAIN_DATA *d;
   Widget parent;
} ENR_TABLE_DB;

static void cb_set_enr_index (Widget w, XtPointer client_data, XtPointer call_data);
static void cb_load_enr (Widget w, XtPointer client_data, XtPointer call_data);

/****************************************************************************/
/****************************************************************************/

extern void db_load_enr (Widget parent, MAIN_DATA *d)
{
   char *title = "Load ENR Table";
   char *name = "DialogLoadENR";
   Widget pane, ns_select;
   XmString e1, e2, e3, e4, e5, text;
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[2];
   static ENR_TABLE_DB db;

   db.d = d;
   db.parent = parent;

   // create the dialog box and main widgets
   pane = create_dialog_shell (parent, &dialog, name, title);

   // create the ENR option menu
   e1 = XmStringCreateLocalized ("S/N 3318A03719 - 6dB");
   e2 = XmStringCreateLocalized ("S/N 4015A05159 - 12dB");
   e3 = XmStringCreateLocalized ("S/N 2339A00727 - 12dB");
   e4 = XmStringCreateLocalized ("S/N 3328A03245 - 12dB");
   e5 = XmStringCreateLocalized ("S/N 3318A04951 - 6dB");
   text = XmStringCreateLocalized ("Noise Source:");
   ns_select = XmVaCreateSimpleOptionMenu (pane, "ns_select", text, '\0', enr_index, cb_set_enr_index,
      XmVaPUSHBUTTON, e1, '\0', NULL, NULL,
      XmVaPUSHBUTTON, e2, '\0', NULL, NULL,
      XmVaPUSHBUTTON, e3, '\0', NULL, NULL,
      XmVaPUSHBUTTON, e4, '\0', NULL, NULL,
      XmVaPUSHBUTTON, e5, '\0', NULL, NULL,
      NULL);
   XmStringFree (e1);
   XmStringFree (e2);
   XmStringFree (e3);
   XmStringFree (e4);
   XmStringFree (e5);
   XmStringFree (text);
   XtManageChild (ns_select);

   // create the action area
   action[0].txt = "OK";
   action[0].cb = cb_load_enr;
   action[0].data = &db;
   action[1].txt = "Cancel";
   action[1].cb = cb_destroy_widget;
   action[1].data = dialog.shell;
   create_dialog_action_area (pane, action, 2, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[0].w, XmNactivateCallback, cb_destroy_widget, dialog.shell);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/****************************************************************************/
/****************************************************************************/

static void cb_set_enr_index (Widget w, XtPointer client_data, XtPointer call_data)
{
   enr_index = (int) client_data;
}

/****************************************************************************/
/****************************************************************************/

static void cb_load_enr (Widget w, XtPointer client_data, XtPointer call_data)
{
   ENR_TABLE_DB *db = (ENR_TABLE_DB *) client_data;
   static ENR_TABLE enr;

   db->d->generic_data = (void *) &enr;

   switch (enr_index)
   {
   case 0:
      enr.name = "3318A03719";
      enr.f_ghz = f_ghz_data;
      enr.enr = enr_3719;
      enr.pts = npts_3719;
      break;

   case 1:
      enr.name = "4015A05159";
      enr.f_ghz = f_ghz_data;
      enr.enr = enr_5159;
      enr.pts = npts_5159;
      break;

   case 2:
      enr.name = "2339A00727";
      enr.f_ghz = f_ghz_data;
      enr.enr = enr_0727;
      enr.pts = npts_0727;
      break;

   case 3:
      enr.name = "3328A03245";
      enr.f_ghz = f_ghz_data;
      enr.enr = enr_3245;
      enr.pts = npts_3245;
      break;

   case 4:
      enr.name = "3318A04951";
      enr.f_ghz = f_ghz_data;
      enr.enr = enr_4951;
      enr.pts = npts_4951;
      break;
      
   default:
      db_error_message ("Invalid ENR table specification.", db->parent);
      return;
   }

   cb_start_gpib (w, (XtPointer) NFM_LOAD_ENR, NULL);
}

