#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <sys/timeb.h>
#include <ni488.h>
#include "dc_v100.h"

// extern variables and functions
extern int         master;
extern char        error_string[];
extern FILE        *out_file;
extern SMU_T       SMU[];  
extern MULTISITE_T multisite_test;
extern int         check_user_abort ();

/*                                                                      */
/* ----------------- function find_device ----------------------------- */
/*                                                                      */

int find_device (int device, int tmo)
{
return (ibdev (GPIBBRD,device,0,tmo,1,0));
}

/*                                                                      */
/* ---------------------Function check_smu ---------------------------- */
/*                                                                      */

int check_smu ( int smu)
{
int    k1;
char   buffer[128];
char   tmp_str[4];
int    model_num;

// k1 = ibfind (SMU[smu].device);
k1 = find_device (SMU[smu].addr,T10s);

strcpy (buffer,"U0X");
if (ibwrt (k1,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"ERROR: could not find SMU %d",smu+1);
   ibonl (k1,0);
   return (PR_ERR);
   }

ibrd (k1,buffer,127);
sprintf (tmp_str,"%c%c%c",buffer[0],buffer[1],buffer[2]);
sscanf (tmp_str,"%d",&model_num);

SMU[smu].type = model_num;

if ((model_num == 236) || (model_num == 237))
   {
   if ((SMU[smu].compliance > (double) 0.1) && (SMU[smu].source == 1))
      {
      SMU[smu].compliance = (double) 0.1;
      sprintf (error_string,"WARNING: SMU %d compliance reset",smu+1);
      pause (100L);
      ibonl (k1,0);
      return (PR_ERR);
      }
   if ((SMU[smu].compliance > (double) 110.0) && (SMU[smu].source == 2))
      {
      SMU[smu].compliance = (double) 110.0;
      sprintf (error_string,"WARNING: SMU %d compliance reset",smu+1);
      pause (100L);
      ibonl (k1,0);
      return (PR_ERR);
      }
   }
else if (model_num == 238)
   {
   if ((SMU[smu].compliance > (double) 1.0) && (SMU[smu].source == 1))
      {
      SMU[smu].compliance = (double) 1.0;
      sprintf (error_string,"WARNING: SMU %d compliance reset",smu+1);
      pause (100L);
      ibonl (k1,0);
      return (PR_ERR);
      }
   if ((SMU[smu].compliance > (double) 110.0) && (SMU[smu].source == 2))
      {
      SMU[smu].compliance = (double) 110.0;
      sprintf (error_string,"WARNING: SMU %d compliance reset",smu+1);
      pause (100L);
      ibonl (k1,0);
      return (PR_ERR);
      }
   }   
else
   {
   sprintf (error_string,"WARNING: unknown SMU type found");
   pause (100L);
   ibonl (k1,0);
   return (PR_ERR);
   }
   
pause (100L);

ibonl (k1,0);
return 0;
}


/*                                                                      */
/* ---------------------Function one_smu ------------------------------ */
/*                                                                      */

int one_smu (int smu, double* sweep_list, int num_pts)
{
int      k1;
char     buffer[128];
int      i;
double   vm,im;
int      filter;
int      my_err = 0;

// k1 = ibfind (SMU[smu].device);
// ibtmo (k1,13);   /* 10 second time out */
k1 = find_device (SMU[smu].addr,T10s);

fprintf (out_file,"!V1(V)       I1(A)\n");

strcpy (buffer,"J0X");
if (ibwrt (k1,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[smu].addr);
   return (PR_ERR);
   }

switch (SMU[smu].filter)
   {
   case 1:
      filter = 0;
      break;
   case 2:
      filter = 1;
      break;
   case 4:
      filter = 2;
      break;
   case 8:
      filter = 3;
      break;
   case 16:
      filter = 4;
      break;
   case 32:
   default:
      filter = 5;
      break;
   }

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T4,1,0,0R1G5,2,0XH0X",SMU[smu].source-1,SMU[smu].sensing,
         filter,SMU[smu].integration,SMU[smu].compliance);
ibwrt (k1,buffer,strlen (buffer));

pause (500L);

for (i = 0; i < num_pts; ++i)
   {
   if (i == 0)
      {
      sprintf (buffer,"B%.4e,0,%dN1XH0X",sweep_list[i],SMU[smu].delay);
      }
   else
      {
      sprintf (buffer,"B%.4e,0,%dXH0X",sweep_list[i],SMU[smu].delay);
      }
   ibwrt (k1,buffer,strlen (buffer));
   
   ibrd (k1,buffer,127);
   if (SMU[smu].source == 1)
      {
      sscanf (buffer,"%lf,%lf",&vm,&im);
      }
   else
      {
      sscanf (buffer,"%lf,%lf",&im,&vm);
      }

   fprintf (out_file,"%+.4e %+.4e\n",vm,im);

   pause (10L);
   
   if (check_user_abort () )
      {
      my_err = 1;
      break;
      }
   }

strcpy (buffer,"R0XT4,0,0,0R1X");
ibwrt (k1,buffer,strlen(buffer));

strcpy (buffer,"B0,0,0XN0XH0X");
ibwrt (k1,buffer,strlen(buffer));

pause (100L);

ibonl (k1,0);

if (my_err)
   {
   sprintf (error_string,"USER ABORT!!");
   return (PR_ERR);
   }
return 0;
}


/*                                                                      */
/* ---------------------Function simult_sweep ------------------------- */
/*                                                                      */

int simult_sweep ( double * sweep_list,int num_pts)
{
int      k1,k2;
char     buffer[128];
int      i,slave;
double   vm1,im1,vm2,im2;
int      filter1,filter2;
int      my_err = 0;

if (master == 0)
   {
   // k1 = ibfind (SMU[0].device);
   // k2 = ibfind (SMU[1].device);
   k1 = find_device (SMU[0].addr,T10s);
   k2 = find_device (SMU[1].addr,T10s);
   slave = 1;
   }
else
   {
   // k1 = ibfind (SMU[1].device);
   // k2 = ibfind (SMU[0].device);
   k1 = find_device (SMU[1].addr,T10s);
   k2 = find_device (SMU[0].addr,T10s);
   slave = 0;
   }

// ibtmo (k1,13);   /* 10 second time out */
// ibtmo (k2,13);   

fprintf (out_file,"!V1(V)       I1(A)       V2(V)       I2(A)\n");

switch (SMU[master].filter)
   {
   case 1:
      filter1 = 0;
      break;
   case 2:
      filter1 = 1;
      break;
   case 4:
      filter1 = 2;
      break;
   case 8:
      filter1 = 3;
      break;
   case 16:
      filter1 = 4;
      break;
   case 32:
   default:
      filter1 = 5;
      break;
   }

switch (SMU[slave].filter)
   {
   case 1:
      filter2 = 0;
      break;
   case 2:
      filter2 = 1;
      break;
   case 4:
      filter2 = 2;
      break;
   case 8:
      filter2 = 3;
      break;
   case 16:
      filter2 = 4;
      break;
   case 32:
   default:
      filter2 = 5;
      break;
   }

strcpy (buffer,"J0X");
if (ibwrt (k1,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[master].addr);
   return (PR_ERR);
   }
if (ibwrt (k2,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[slave].addr);
   ibonl (k1,0);
   return (PR_ERR);
   }

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T4,1,1,0R1G5,2,0XH0X",SMU[master].source-1,
         SMU[master].sensing,filter1,SMU[master].integration,SMU[master].compliance);
ibwrt (k1,buffer,strlen (buffer));

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T3,1,0,0R1G5,2,0X",SMU[master].source-1,
         SMU[slave].sensing,filter2,SMU[slave].integration,SMU[slave].compliance);
ibwrt (k2,buffer,strlen (buffer));

pause (50L);

for (i = 0; i < num_pts; ++i)
   {
   if (i == 0)
      {
      sprintf (buffer,"B%.4e,0,%dN1X",sweep_list[i],SMU[master].delay);
      ibwrt (k2,buffer,strlen (buffer));
      sprintf (buffer,"B%.4e,0,%dN1XH0X",sweep_list[i],SMU[master].delay);
      ibwrt (k1,buffer,strlen (buffer));
      }
   else
      {
      sprintf (buffer,"B%.4e,0,%dX",sweep_list[i],SMU[master].delay);
      ibwrt (k2,buffer,strlen (buffer));
      sprintf (buffer,"B%.4e,0,%dXH0X",sweep_list[i],SMU[master].delay);
      ibwrt (k1,buffer,strlen (buffer));
      }
      
   ibrd (k1,buffer,127);
   if (SMU[master].source == 1)
      {
      sscanf (buffer,"%lf,%lf",&vm1,&im1);
      }
   else
      {
      sscanf (buffer,"%lf,%lf",&im1,&vm1);
      }

   ibrd (k2,buffer,127);
   if (SMU[slave].source == 1)
      {
      sscanf (buffer,"%lf,%lf",&vm2,&im2);
      }
   else
      {
      sscanf (buffer,"%lf,%lf",&im2,&vm2);
      }

   if (master == 0)
      {
      fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm1,im1,vm2,im2);
      }
   else
      {
      fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm2,im2,vm1,im1);
      }

   pause (10L);

   if (check_user_abort () )
      {
      my_err = 1;
      break;
      }
   }

strcpy (buffer,"R0XT4,0,0,0R1X");
ibwrt (k2,buffer,strlen (buffer));
ibwrt (k1,buffer,strlen (buffer));

strcpy (buffer,"B0,0,0XN0XH0X");
ibwrt (k2,buffer,strlen (buffer));
ibwrt (k1,buffer,strlen (buffer));

pause (100L);

ibonl (k2,0);
ibonl (k1,0);

if (my_err)
   {
   sprintf (error_string,"USER ABORT!!");
   return (PR_ERR);
   }
return 0;
}


/*                                                                      */
/* ---------------------Function step_sweep --------------------------- */
/*                                                                      */

int step_sweep (int stepped,double* sweep_list1, int num_pts1, double* sweep_list2, int num_pts2)
{
int      k1,k2;
char     buffer[128];
int      i,j,slave;
double   vm1,im1,vm2,im2;
int      filter1,filter2;
int      my_err = 0;

if (master == 0)
   {
   // k1 = ibfind (SMU[0].device);
   // k2 = ibfind (SMU[1].device);
   k1 = find_device (SMU[0].addr,T10s);
   k2 = find_device (SMU[1].addr,T10s);
   slave = 1;
   }
else
   {
   // k1 = ibfind (SMU[1].device);
   // k2 = ibfind (SMU[0].device);
   k1 = find_device (SMU[1].addr,T10s);
   k2 = find_device (SMU[0].addr,T10s);   
   slave = 0;
   }

// ibtmo (k1,13);   /* 10 second time out */
// ibtmo (k2,13);   

fprintf (out_file,"!V1(V)       I1(A)       V2(V)       I2(A)\n");

switch (SMU[master].filter)
   {
   case 1:
      filter1 = 0;
      break;
   case 2:
      filter1 = 1;
      break;
   case 4:
      filter1 = 2;
      break;
   case 8:
      filter1 = 3;
      break;
   case 16:
      filter1 = 4;
      break;
   case 32:
   default:
      filter1 = 5;
      break;
   }

switch (SMU[slave].filter)
   {
   case 1:
      filter2 = 0;
      break;
   case 2:
      filter2 = 1;
      break;
   case 4:
      filter2 = 2;
      break;
   case 8:
      filter2 = 3;
      break;
   case 16:
      filter2 = 4;
      break;
   case 32:
   default:
      filter2 = 5;
      break;
   }

strcpy (buffer,"J0X");
if (ibwrt (k1,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[master].addr);
   return (PR_ERR);
   }
if (ibwrt (k2,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[slave].addr);
   ibonl (k1,0);
   return (PR_ERR);
   }

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T4,1,1,0R1G5,2,0XH0X",SMU[master].source-1,
         SMU[master].sensing,filter1,SMU[master].integration,SMU[master].compliance);
ibwrt (k1,buffer,strlen (buffer));

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T3,1,0,0R1G5,2,0X",SMU[slave].source-1,
         SMU[slave].sensing,filter2,SMU[slave].integration,SMU[slave].compliance);
ibwrt (k2,buffer,strlen (buffer));

pause (50L);

if (master == stepped)
   {
   for (i = 0; i < num_pts1; ++i)
      {
      for (j = 0; j < num_pts2; ++j)
         {
         if (j == 0)
            {
            sprintf (buffer,"B%.4e,0,%dN1X",sweep_list2[j],SMU[slave].delay);
            ibwrt (k2,buffer,strlen (buffer));
            sprintf (buffer,"B%.4e,0,%dN1XH0X",sweep_list1[i],SMU[master].delay);
            ibwrt (k1,buffer,strlen (buffer));
            }
         else
            {
            sprintf (buffer,"B%.4e,0,%dX",sweep_list2[j],SMU[slave].delay);
            ibwrt (k2,buffer,strlen (buffer));
            sprintf (buffer,"B%.4e,0,%dXH0X",sweep_list1[i],SMU[master].delay);
            ibwrt (k1,buffer,strlen (buffer));
            }
         
         ibrd (k1,buffer,127);
         if (SMU[master].source == 1)
            {
            sscanf (buffer,"%lf,%lf",&vm1,&im1);
            }
         else
            {
            sscanf (buffer,"%lf,%lf",&im1,&vm1);
            }

         ibrd (k2,buffer,127);
         if (SMU[slave].source == 1)
            {
            sscanf (buffer,"%lf,%lf",&vm2,&im2);
            }
         else
            {
            sscanf (buffer,"%lf,%lf",&im2,&vm2);
            }

         if (master == 0)
            {
            fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm1,im1,vm2,im2);
            }
         else
            {
            fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm2,im2,vm1,im1);
            }

         pause (10L);

         if (check_user_abort () )
            {
            my_err = 1;
            break;
            }
         }

      strcpy (buffer,"B0,0,0XN0X");
      ibwrt (k2,buffer,strlen (buffer));
      strcpy (buffer,"N0XH0X");
      ibwrt (k1,buffer,strlen (buffer));
      
      if (my_err)
         {
         break;
         }
      
      pause (50L);

      }
   }

else
   {
   for (i = 0; i < num_pts2; ++i)
      {   
      for (j = 0; j < num_pts1; ++j)
         {   
         if (j == 0)
            {
            sprintf (buffer,"B%.4e,0,%dN1X",sweep_list2[i],SMU[slave].delay);
            ibwrt (k2,buffer,strlen (buffer));            
            sprintf (buffer,"B%.4e,0,%dN1XH0X",sweep_list1[j],SMU[master].delay);
            ibwrt (k1,buffer,strlen (buffer));
            }
         else
            {
            sprintf (buffer,"B%.4e,0,%dX",sweep_list2[i],SMU[slave].delay);
            ibwrt (k2,buffer,strlen (buffer));                      
            sprintf (buffer,"B%.4e,0,%dXH0X",sweep_list1[j],SMU[master].delay);
            ibwrt (k1,buffer,strlen (buffer));
            }
         
         ibrd (k1,buffer,127);
         if (SMU[master].source == 1)
            {
            sscanf (buffer,"%lf,%lf",&vm1,&im1);
            }
         else
            {
            sscanf (buffer,"%lf,%lf",&im1,&vm1);
            }

         ibrd (k2,buffer,127);
         if (SMU[slave].source == 1)
            {
            sscanf (buffer,"%lf,%lf",&vm2,&im2);
            }
         else
            {
            sscanf (buffer,"%lf,%lf",&im2,&vm2);
            }

         if (master == 0)
            {
            fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm1,im1,vm2,im2);
            }
         else
            {
            fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm2,im2,vm1,im1);
            }

         pause (10L);

         if (check_user_abort () )
            {
            my_err = 1;
            break;
            }
         }

      strcpy (buffer,"B0,0,0XN0X");
      ibwrt (k2,buffer,strlen (buffer));
      strcpy (buffer,"N0XH0X");
      ibwrt (k1,buffer,strlen (buffer));

      if (my_err)
         {
         break;
         }
      
      pause (50L);
      
      }
   }         

strcpy (buffer,"R0XT4,0,0,0R1X");
ibwrt (k2,buffer,strlen (buffer));
ibwrt (k1,buffer,strlen (buffer));

strcpy (buffer,"B0,0,0N1XH0XN0X");
ibwrt (k2,buffer,strlen (buffer));
ibwrt (k1,buffer,strlen (buffer));

pause (100L);

ibonl (k2,0);
ibonl (k1,0);

if (my_err)
   {
   sprintf (error_string,"USER ABORT!!");
   return (PR_ERR);
   }
return ;
}

/*                                                                      */
/* ---------------------Function const_step --------------------------- */
/*                                                                      */

int const_step (int const_smu,double* sweep_list,int num_pts)
{
int      k1,k2;
char     buffer[128];
int      i,slave;
double   vm1,im1,vm2,im2;
int      filter1,filter2;
int      my_err = 0;

if (master == 0)
   {
   // k1 = ibfind (SMU[0].device);
   // k2 = ibfind (SMU[1].device);
   k1 = find_device (SMU[0].addr,T10s);
   k2 = find_device (SMU[1].addr,T10s);
   slave = 1;
   }
else
   {
   // k1 = ibfind (SMU[1].device);
   // k2 = ibfind (SMU[0].device);
   k1 = find_device (SMU[1].addr,T10s);
   k2 = find_device (SMU[0].addr,T10s);
   slave = 0;
   }

// ibtmo (k1,13);   /* 10 second time out */
// ibtmo (k2,13);   

fprintf (out_file,"!V1(V)       I1(A)       V2(V)       I2(A)\n");

switch (SMU[master].filter)
   {
   case 1:
      filter1 = 0;
      break;
   case 2:
      filter1 = 1;
      break;
   case 4:
      filter1 = 2;
      break;
   case 8:
      filter1 = 3;
      break;
   case 16:
      filter1 = 4;
      break;
   case 32:
   default:
      filter1 = 5;
      break;
   }

switch (SMU[slave].filter)
   {
   case 1:
      filter2 = 0;
      break;
   case 2:
      filter2 = 1;
      break;
   case 4:
      filter2 = 2;
      break;
   case 8:
      filter2 = 3;
      break;
   case 16:
      filter2 = 4;
      break;
   case 32:
   default:
      filter2 = 5;
      break;
   }

strcpy (buffer,"J0X");
if (ibwrt (k1,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[master].addr);
   return (PR_ERR);
   }
if (ibwrt (k2,buffer,strlen (buffer)) & ERR)
   {
   sprintf (error_string,"Could not find SMU at address %d.\nCheck GPIB connection and address.",SMU[slave].addr);
   ibonl (k1,0);
   return (PR_ERR);
   }

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T4,1,1,0R1G5,2,0XH0X",SMU[master].source-1,
         SMU[master].sensing,filter1,SMU[master].integration,SMU[master].compliance);
ibwrt (k1,buffer,strlen (buffer));

sprintf (buffer,"R0XF%d,0O%dP%dS%dL%.4e,0T3,1,0,0R1G5,2,0X",SMU[slave].source-1,
         SMU[slave].sensing,filter2,SMU[slave].integration,SMU[slave].compliance);
ibwrt (k2,buffer,strlen (buffer));

pause (50L);

for (i = 0; i < num_pts; ++i)
   {
   if (i == 0)
      {
      if (const_smu == master)
         {
         sprintf (buffer,"B%.4e,0,%dN1X",sweep_list[i],SMU[slave].delay);
         ibwrt (k2,buffer,strlen (buffer));
         sprintf (buffer,"B%.4e,0,%dN1XH0X",SMU[master].dc_value,SMU[master].delay);
         ibwrt (k1,buffer,strlen (buffer));
         }
      else
         {
         sprintf (buffer,"B%.4e,0,%dN1X",SMU[slave].dc_value,SMU[slave].delay);
         ibwrt (k2,buffer,strlen (buffer));
         sprintf (buffer,"B%.4e,0,%dN1XH0X",sweep_list[i],SMU[master].delay);
         ibwrt (k1,buffer,strlen (buffer));
         }
      }
   else
      {
      if (const_smu == master)
         {
         sprintf (buffer,"B%.4e,0,%dX",sweep_list[i],SMU[slave].delay);
         ibwrt (k2,buffer,strlen (buffer));
         sprintf (buffer,"B%.4e,0,%dXH0X",SMU[master].dc_value,SMU[master].delay);
         ibwrt (k1,buffer,strlen (buffer));
         }
      else
         {
         sprintf (buffer,"B%.4e,0,%dX",SMU[slave].dc_value,SMU[slave].delay);
         ibwrt (k2,buffer,strlen (buffer));
         sprintf (buffer,"B%.4e,0,%dXH0X",sweep_list[i],SMU[master].delay);
         ibwrt (k1,buffer,strlen (buffer));
         }
      }
      
   ibrd (k1,buffer,127);
   if (SMU[master].source == 1)
      {
      sscanf (buffer,"%lf,%lf",&vm1,&im1);
      }
   else
      {
      sscanf (buffer,"%lf,%lf",&im1,&vm1);
      }

   ibrd (k2,buffer,127);
   if (SMU[slave].source == 1)
      {
      sscanf (buffer,"%lf,%lf",&vm2,&im2);
      }
   else
      {
      sscanf (buffer,"%lf,%lf",&im2,&vm2);
      }

   if (master == 0)
      {
      fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm1,im1,vm2,im2);
      }
   else
      {
      fprintf (out_file,"%+.4e %+.4e %+.4e %+.4e\n",vm2,im2,vm1,im1);
      }

   pause (10L);

   if (check_user_abort ())
      {
      my_err = 1;
      break;
      }
   }

strcpy (buffer,"R0XT4,0,0,0R1X");
ibwrt (k2,buffer,strlen (buffer));
ibwrt (k1,buffer,strlen (buffer));

strcpy (buffer,"B0,0,0XN0XH0X");
ibwrt (k2,buffer,strlen (buffer));
ibwrt (k1,buffer,strlen (buffer));

pause (100L);

ibonl (k2,0);
ibonl (k1,0);

if (my_err)
   {
   sprintf (error_string,"USER ABORT!!");
   return (PR_ERR);
   }
return 0;
}


/*                                                                   */
/*--- Function put_8510_in_hold_mode --------------------------------*/
/*                                                                   */

int put_8510_in_hold_mode ()

{
int               ana;

ana = find_device (ANAADDR,T10s);

ibclr (ana);
ibwrt (ana,"HOLD;",5L);

pause (10L);
ibonl (ana,0);

return 0;
}


/*                                                                      */
/* ----------------Function move_prober-------------------------------- */
/*                                                                      */

int move_prober (int n)
{
int               prober;
char              buffer[1024];
static long int   x_start = 0L,y_start = 0L;
long int          x,y;
int               num_of_attempts;

num_of_attempts = 0;

prober = find_device (PRBADDR,T10s);

if (n == 0)
   {
   strcpy (buffer,"$:SET:RESP ON");
   if (ibwrt (prober,buffer,strlen (buffer)) & ERR)
      {
      sprintf (error_string,"Failed to find the Cascade Probe Station.\nCheck that the GPIB communication server is running\nand the address is set to %d.",PRBADDR);
      ibonl (prober,0);
      return (PR_ERR);
      } 

   strcpy (buffer,":MOVE:ABS? 2");

   ibwrt (prober,buffer,strlen (buffer));
   ibrd (prober,buffer,1023);
   
   sscanf (buffer,"%ld %ld",&x_start,&y_start);
   
   ibonl (prober,0);
   return 0;
   }

BEGIN:

switch (multisite_test.orientation)
   {
   case 2:
      x = x_start-((long) multisite_test.x_index)*((long) (multisite_test.site[n][1]-multisite_test.site[0][1]));
      y = y_start-((long) multisite_test.y_index)*((long) (multisite_test.site[n][0]-multisite_test.site[0][0]));
      break;

   case 3:
      x = x_start-((long) multisite_test.x_index)*((long) (multisite_test.site[n][0]-multisite_test.site[0][0]));
      y = y_start+((long) multisite_test.y_index)*((long) (multisite_test.site[n][1]-multisite_test.site[0][1]));
      break;

   case 4:
      x = x_start+((long) multisite_test.x_index)*((long) (multisite_test.site[n][1]-multisite_test.site[0][1]));
      y = y_start+((long) multisite_test.y_index)*((long) (multisite_test.site[n][0]-multisite_test.site[0][0]));
      break;

   case 1:
   default:
      x = x_start+((long) multisite_test.x_index)*((long) (multisite_test.site[n][0]-multisite_test.site[0][0]));
      y = y_start-((long) multisite_test.y_index)*((long) (multisite_test.site[n][1]-multisite_test.site[0][1]));
      break;
   }

sprintf (buffer,":MOVE:ABS 2 %ld %ld UP",x,y);
            
ibwrt (prober,buffer,strlen (buffer));

ibrd (prober,buffer,1023);

if (ibsta & ERR)
   {
   sprintf (error_string,"Failed to verify move completion from the probe station.");
   ibonl (prober,0);
   return (PR_ERR);
   }

if (strncmp (buffer,"COMPLETE",8)) 
   {
   if (++num_of_attempts > 9)
      {
      sprintf (error_string,"Cascade prober error - after 10 attempts\n%s",buffer);
      ibonl (prober,0);
      return (PR_ERR);
      }

   goto BEGIN;
   }

ibonl (prober,0);
return 0;
}


/*                                                                      */
/* ------------------- Function pause --------------------------------- */
/*                                                                      */

int pause (delay)
long int delay;

{
long int       stop_ms,ms;
struct timeb   tbuf;
        
ftime (&tbuf);
stop_ms = tbuf.time/1000000;
stop_ms = tbuf.time - stop_ms * 1000000;
stop_ms = 1000 * stop_ms + tbuf.millitm + delay;
        
do
   {
   ftime (&tbuf);
   ms = tbuf.time/1000000;
   ms = tbuf.time - ms * 1000000;
   ms = 1000 * ms + tbuf.millitm;
   }
while (ms < stop_ms);
        
return 0;
}

