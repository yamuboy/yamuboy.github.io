#ifndef _dc_v100_struct_
#define _dc_v100_struct_

#define MAX_LOCATIONS   (1000)

#define MAX_SEGMENTS    (50)

#define SINGLE          (1)
#define SWEEP           (2)

#define SMU1_ONLY       (0)
#define SMU2_ONLY       (1)
#define SIMULT_SWP      (2)
#define STEP1_SWEEP2    (3)
#define STEP2_SWEEP1    (4)
#define STEP1_CONST2    (5)
#define STEP2_CONST1    (6)

#define STRING          (0)
#define CHARACTERS      (1)
#define INT             (2)
#define DOUBLE          (3)

#define ABORT_TEST_CHAR   (KEY_END)
#define PR_EXIT         (-99)

#define PR_ERR    (-1)

// other gpib device addresses
#define GPIBBRD    0
#define ANAADDR    16
#define PRBADDR    28

typedef struct
{
char   file_name[81];
char   mask_name[81];
char   wafer_number[81];
char   process_name[81];
char   device_name[81];
double temperature;
char   date_and_time[81];
char   comments[1025];
} HEADER_INFO;

typedef struct
{
char     map_filename[81];
int      on_or_off;
int      x_index;
int      y_index;
int      orientation;
int      site[MAX_LOCATIONS][2];
int      num_sites;
} MULTISITE_T;

typedef struct
{
int type;
char *device;
int addr;
int source;
int filter;
int integration;
int sensing;
double compliance;
double dc_value;
int delay;
} SMU_T;

typedef struct sweep_t
{
int type;
int seg_num;
double start;
double stop;
double step;
struct sweep_t *prev;
struct sweep_t *next;
}SWEEP_SEG;

typedef struct error_log_t
{
char site[10];
char error[1024];
int  lines;
struct error_log_t *next;
} ERROR_LOG;

typedef struct
{
char menu_item_text[51];
int  x_location;
int  y_location;
int  (*function) ();
} MENU_ITEM;

typedef struct
{
MENU_ITEM   *menu_item;
int         n;
} MENU;

typedef union
{
char   *string_value;
int    *int_value;
double *double_value;
} VALUE;

typedef struct
{
char *prompt_text;
int  x_text_location;
int  y_text_location;
int  x1_get_location;
int  y1_get_location;
int  x2_get_location;
int  y2_get_location;
int  return_type;
char *format;
} PROMPT_ITEM;

typedef struct 
{
PROMPT_ITEM   *prompt_item;
int           n;
} PROMPT;

#endif

