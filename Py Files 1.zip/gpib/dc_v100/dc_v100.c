/* DC test program version 1.00
       written by Jay Barrett 2/5/2002
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <malloc.h>
#include "curses_utilities.h"
#include "dc_v100.h"

/* main menu function declarations */
int recall_configuration ();
int save_configuration ();
int multisite_setup ();
int setup_header_info ();
int sweep_setup_menu ();
int smu_setup_menu ();
int measure_dc ();
int system_command ();
int quit_menu ();
int quit_program ();

/* sweep list menu function declarations */
int sweep_list_setup ();
int smu_setup ();
int set_dc ();
int add_single ();
int add_sweep ();
int insert_single ();
int insert_sweep ();
int delete_segment ();
int view_segments ();

/* other utility function declarations */
int set_master_smu ();
int set_smu_mode ();
int log_error ();
void get_the_time ();
double *make_sweep_list ();
int check_user_abort ();
int draw_menu ();
int draw_prompt ();

/* external GPIB functions */
extern int put_8510_in_hold_mode ();
extern int move_prober ();
extern int check_smu ();
extern int one_smu ();
extern int simult_sweep ();
extern int step_sweep ();
extern int const_step ();

/* global variables */

static MENU_ITEM menu1[] =
{
 {"RECALL CONFIG       ",-1,-1,recall_configuration},
 {"SAVE CONFIG         ",-1,-1,save_configuration},
 {"SETUP SMUs          ",-1,-1,smu_setup_menu},
 {"EDIT SWEEP LISTS    ",-1,-1,sweep_setup_menu},
 {"MULTI-SITE  <OFF>   ",-1,-1,multisite_setup},
 {"SETUP HEADER        ",-1,-1,setup_header_info},
 {"RUN TEST            ",-1,-1,measure_dc},
 {"UNIX COMMAND SHELL  ",-1,-1,system_command},
 {"QUIT PROGRAM        ",-1,-1,quit_program}
};

static MENU_ITEM menu2[] =
{
 {"SMU 1 SETUP           ",-1,-1,smu_setup},
 {"SMU 2 SETUP           ",-1,-1,smu_setup},
 {"MODE: SMU1 ONLY       ",-1,-1,set_smu_mode},
 {"MASTER: SMU 1         ",-1,-1,set_master_smu},
 {"MAIN MENU             ",-1,-1,quit_menu}
};

static MENU_ITEM menu3[] =
{
 {"SMU 1 SWEEP LIST SETUP ",-1,-1,sweep_list_setup},
 {"SMU 2 SWEEP LIST SETUP ",-1,-1,sweep_list_setup},
 {"MAIN MENU              ",-1,-1,quit_menu}
};

static MENU_ITEM menu4[] =
{
 {"SET CONSTANT DC VALUE   ",-1,-1,set_dc},
 {"ADD A SINGLE POINT      ",-1,-1,add_single},
 {"ADD A LINEAR SWEEP      ",-1,-1,add_sweep},
 {"INSERT A SINGLE POINT   ",-1,-1,insert_single},
 {"INSERT A LINEAR SWEEP   ",-1,-1,insert_sweep},
 {"DELETE A POINT/SWEEP    ",-1,-1,delete_segment},
 {"VIEW CURRENT SWEEP LIST ",-1,-1,view_segments},
 {"SWEEP LIST MENU         ",-1,-1,quit_menu}
};

static MENU menu[] =
{
 {menu1,9},
 {menu2,5},
 {menu3,3},
 {menu4,8}
};

static PROMPT_ITEM prompt1[] =
{
 {"FILE NAME:",0,0,11,0,90,0,STRING,"%s"},
 {"MASK NAME:",0,1,11,1,90,1,STRING,"%s"},
 {"WAFER NUMBER:",0,2,14,2,93,2,STRING,"%s"},
 {"PROCESS NAME:",0,3,14,3,93,3,STRING,"%s"},
 {"DEVICE NAME:",0,4,13,4,92,4,STRING,"%s"},
 {"TEMPERATURE (C):",0,5,17,5,97,5,DOUBLE,"%.1f"},
 {"COMMENTS:",0,6,0,7,78,14,CHARACTERS,"%s"}
};

static PROMPT_ITEM prompt2[] =
{
 {"CONFIGURATION FILE:",0,0,20,0,99,0,STRING,"%s"}
};

static PROMPT_ITEM prompt3[] =
{
 {"WAFER MAP FILE NAME:",0,0,21,0,99,0,STRING,"%s"},
 {"ORIENTATION (1-4):",0,1,19,1,29,1,INT,"%d"},
 {"X INDEX:",0,2,9,2,19,2,INT,"%d"},
 {"Y INDEX:",0,3,9,3,19,3,INT,"%d"}
};

static PROMPT_ITEM prompt4[] =
{
 {"DC VALUE:",0,0,10,0,40,0,DOUBLE,"%.2e"}
};

static PROMPT_ITEM prompt5[] =
{
 {"START:",0,0,7,0,40,0,DOUBLE,"%.1f"},
 {"STOP:",0,1,6,1,40,1,DOUBLE,"%.1f"},
 {"STEP:",0,2,6,2,40,2,DOUBLE,"%.1f"},
};

static PROMPT_ITEM prompt6[] =
{
 {"POINT VALUE:",0,0,13,0,40,0,DOUBLE,"%.1f"}
};

static PROMPT_ITEM prompt7[] =
{
 {"MODE (0=OFF,1=VOLTAGE,2=CURRENT):",0,0,34,0,38,0,INT,"%d"},
 {"INTEGRATION (0=FAST,1=MEDIUM,2=LINECYCLE):",0,1,43,1,50,1,INT,"%d"},
 {"FILTER (1,2,4,8,16,OR 32):",0,2,27,2,32,2,INT,"%d"},
 {"SENSING (0=LOCAL,1=REMOTE):",0,3,28,3,32,3,INT,"%d"},
 {"COMPLIANCE:",0,4,12,4,25,4,DOUBLE,"%.2e"},
 {"DELAY (ms):",0,5,12,5,20,5,INT,"%d"}
};

static PROMPT prompt[] =
{
 {prompt1,7},
 {prompt2,1},
 {prompt3,4},
 {prompt4,1},
 {prompt5,3},
 {prompt6,1},
 {prompt7,6}
};

static HEADER_INFO header_info =
{
 "file.dat",
 "pa86",
 "21406",
 "hi2",
 "kf44",
 27.0,
 " ",
 " "
};

MULTISITE_T multisite_test =
{
 "wafer.map",
 0,
 10000,
 10000,
 1,
 {{0},{0}},
 0 
};

SMU_T SMU[] = 
{
 {0,"dev13",21,0,32,2,1,(double) 0.1,(double) 0.0,25},
 {0,"dev14",23,0,32,2,1,(double) 1.0,(double) 0.0,25}
};

static ERROR_LOG   *error_log = NULL;
static int         used_segments[MAX_SEGMENTS][2];       
static SWEEP_SEG   *first_segment[2] = {NULL,NULL};
static SWEEP_SEG   *last_segment[2] = {NULL,NULL};
static char        CONFIGURATION_FILE[80] = "dc.config";
static int         smu_sweep_mode = SMU1_ONLY;
SWEEP_SEG          sweep_list[MAX_SEGMENTS][2];
FILE               *out_file;
char               error_string[1024];
int                master = 0;
WINDOW             *global_win;


/*                                                                   */
/*--- Function main -------------------------------------------------*/
/*                                                                   */

int main ()
{
global_win = start_curses ();
draw_menu (global_win,0,-1);
end_curses (global_win);
return 0;
}


/*                                                                   */
/*--- Function smu_setup_menu ---------------------------------------*/
/*                                                                   */

int smu_setup_menu (WINDOW * win,int item)
{
draw_menu (win,1,-1);
return 0;
}

/*                                                                   */
/*--- Function sweep_setup_menu -------------------------------------*/
/*                                                                   */

int sweep_setup_menu (WINDOW * win,int tem)
{
draw_menu (win,2,-1);
return 0;
}

/*                                                                   */
/*--- Function sweep_list_setup -------------------------------------*/
/*                                                                   */

int sweep_list_setup (WINDOW* win, int smu)
{
char string[1024];

if (SMU[smu].source == 0)
   {
   sprintf (error_string,"SMU mode set to OFF.\nMode must be set before entering sweep values.");
   return (ERR);
   }

if (SMU[smu].type == 0)
   {
   wclear (win);
   sprintf (string,"SMU not initialized, checking SMU ...");
   put_output (win,LINES/2,(COLS-strlen(string))/2,string);
   wrefresh (win);

   check_smu (smu);
   }

if (SMU[smu].type == 0)
   {
   sprintf (error_string,"Could not find SMU.  Check GPIB connection and address.");
   return (ERR);
   }
 
draw_menu (win,3,smu);

return 0;
}


/*                                                                   */
/*--- Function set_smu_mode -----------------------------------------*/
/*                                                                   */

int set_smu_mode ( WINDOW * win,int item)
{
++smu_sweep_mode;

switch (smu_sweep_mode)
   {
   case SMU1_ONLY:
      strcpy (menu2[item].menu_item_text,"MODE: SMU1 ONLY       ");
      break;
   case SMU2_ONLY:
      strcpy (menu2[item].menu_item_text,"MODE: SMU2 ONLY       ");
      break;
   case SIMULT_SWP:
      strcpy (menu2[item].menu_item_text,"MODE: SIMULTANEOUS SWP");
      break;
   case STEP1_SWEEP2:
      strcpy (menu2[item].menu_item_text,"MODE: STEP1/SWEEP2    ");
      break;
   case STEP2_SWEEP1:
      strcpy (menu2[item].menu_item_text,"MODE: SWEEP1/STEP2    ");
      break;
   case STEP1_CONST2:
      strcpy (menu2[item].menu_item_text,"MODE: STEP1/CONSTANT2 ");
      break;
   case STEP2_CONST1:
      strcpy (menu2[item].menu_item_text,"MODE: CONSTANT1/STEP2 ");
      break;
   default:
      smu_sweep_mode = SMU1_ONLY;
      strcpy (menu2[item].menu_item_text,"MODE: SMU1 ONLY       ");
      break;
   }

return 0;
}


/*                                                                   */
/*--- Function set_master_smu ---------------------------------------*/
/*                                                                   */

int set_master_smu (WINDOW* win,int item)
{
if (master == 0)
   {
   ++master;
   strcpy (menu2[item].menu_item_text,"MASTER: SMU 2         ");
   }
else
   {
   master = 0;
   strcpy (menu2[item].menu_item_text,"MASTER: SMU 1         ");
   }

return 0;
}


/*                                                                   */
/*--- Function smu_setup --------------------------------------------*/
/*                                                                   */

int smu_setup (WINDOW * win,int smu)
{
VALUE  value[6];
char   string[1024];
int    error;
int    address;

wclear (win);
sprintf (string,"Checking SMU ...");
put_output (win,LINES/2,(COLS-strlen(string))/2,string);
wrefresh (win);

check_smu (smu);

if (SMU[smu].type == 0)
   {
   sprintf (error_string,"Could not find SMU.  Check GPIB connection.");
   return (ERR);
   }

value[0].int_value = &SMU[smu].source;
value[1].int_value = &SMU[smu].integration;
value[2].int_value = &SMU[smu].filter;
value[3].int_value = &SMU[smu].sensing;
value[4].double_value = &SMU[smu].compliance;
value[5].int_value = &SMU[smu].delay;

wclear (win);

if (smu == 0)
   {
   address = 21;
   }
else
   {
   address = 23;
   }

switch (SMU[smu].type)
   {
   case 236:
      {
      sprintf (string,"Keithley 236 @ GPIB %d\nMax V source: 110 volts\nMax I source: 100 mA",address);
      break;
      }
   case 237:
      {
      sprintf (string,"Keithley 237 @ GPIB %d\nMax V source: 1100 volts\nMax I source: 100 mA",address);
      break;
      }
   case 238:
      {
      sprintf (string,"Keithley 238 @ GPIB %d\nMax V source: 110 volts\nMax I source: 1 amp",address);
      break;
      }
   default:
      {
      sprintf (string,"Unknown SMU @ GPIB %d",address);
      break;
      }
   }
put_output (win,7,0,string);

draw_prompt (win,value,6);

error = 0;

if ((SMU[smu].source < 0) || (SMU[smu].source > 2))
   {
   SMU[smu].source = 0;
   error = 1;
   }
if ((SMU[smu].integration < 0) || (SMU[smu].integration > 2))
   {
   SMU[smu].integration = 2;
   error = 1;
   }
if ((SMU[smu].filter != 1) && (SMU[smu].filter != 2) && (SMU[smu].filter != 4) && (SMU[smu].filter != 8) &&
    (SMU[smu].filter != 16) && (SMU[smu].filter != 32))
   {
   SMU[smu].filter = 32;
   error = 1;
   }
if ((SMU[smu].sensing != 0) && (SMU[smu].sensing != 1))
   {
   SMU[smu].sensing = 1;
   error = 1;
   }

SMU[smu].compliance = fabs (SMU[smu].compliance);

if (SMU[smu].source == 1)
   {
   if (SMU[smu].type != 238)
      {
      if (SMU[smu].compliance > (double) 0.1)
         {
         SMU[smu].compliance = (double) 0.1;
         error = 1;
         }
      }
   else
      {
      if (SMU[smu].compliance > (double) 1.0)
         {
         SMU[smu].compliance = (double) 1.0;
         error = 1;
         }
      }
   }
else if (SMU[smu].source == 2)
   {
   if (SMU[smu].compliance > (double) 110.0)
      {
      SMU[smu].compliance = (double) 110.0;
      error = 1;
      }
   }

if (SMU[smu].delay < 0)
   {
   SMU[smu].delay = 0;
   }

if (error)
   {
   sprintf (error_string,"WARNING!!!\nOne or more settings have been reset to defaults due to invalid entries.");
   return (ERR);
   }

return 0;
}


/*                                                                   */
/*--- Function setup_header_info ------------------------------------*/
/*                                                                   */

int setup_header_info (WINDOW* win,int item)
{
VALUE   value[7];

value[0].string_value = header_info.file_name;
value[1].string_value = header_info.mask_name;
value[2].string_value = header_info.wafer_number;
value[3].string_value = header_info.process_name;
value[4].string_value = header_info.device_name;
value[5].double_value = &header_info.temperature;
value[6].string_value = header_info.comments;

wclear (win);

draw_prompt (win,value,0);

get_the_time (header_info.date_and_time);

return 0;
}


/*                                                                   */
/*--- Function multisite_setup --------------------------------------*/
/*                                                                   */

int multisite_setup (WINDOW* win,int item)
{
FILE     *in_file;
VALUE    value[4];
char     string[201];
int      i;

value[0].string_value  = multisite_test.map_filename;
value[1].int_value     = &multisite_test.orientation;
value[2].int_value     = &multisite_test.x_index;
value[3].int_value     = &multisite_test.y_index;

wclear (win);

if (multisite_test.on_or_off)
   {
   multisite_test.on_or_off = 0;
   strcpy (menu1[item].menu_item_text,"MULTI-SITE  <OFF>   ");
   return (OK);
   }
else
   {
   multisite_test.on_or_off = 1;
   strcpy (menu1[item].menu_item_text,"MULTI-SITE  <ON>    ");
   }

draw_prompt (win,value,2);

in_file = (FILE *) NULL;
in_file = fopen (multisite_test.map_filename,"r");

if (in_file == (FILE *) NULL)
   {
   multisite_test.on_or_off = 0;
   strcpy (menu1[item].menu_item_text,"MULTI-SITE  <OFF>   ");
   sprintf (error_string,"ERROR: wafer map file - %s - not found!!",multisite_test.map_filename);
   return (ERR);
   }

i = 0;
while (fgets (string,200,in_file) != NULL)
   {   
   if ((string[0] != '!') && (string[0] != '\n'))
      {
      if (sscanf (string,"%d %d",&multisite_test.site[i][0],&multisite_test.site[i][1]) == 2)
         {
         ++i;
         }
      }   
   }

multisite_test.num_sites = i;
fclose (in_file);

if (multisite_test.num_sites < 1)
   {
   multisite_test.on_or_off = 0;
   strcpy (menu1[item].menu_item_text,"MULTI-SITE  <OFF>   ");
   sprintf (error_string,"ERROR: no data in map file!!");
   return (ERR);
   }

return 0;
}


/*                                                                   */
/*--- Function set_dc -----------------------------------------------*/
/*                                                                   */

int set_dc (WINDOW* win,int smu)
{
VALUE   value[1];

value[0].double_value = &SMU[smu].dc_value;

wclear (win);

draw_prompt (win,value,3);
      
return 0;
}


/*                                                                   */
/*--- Function add_single -------------------------------------------*/
/*                                                                   */

int add_single (WINDOW* win,int smu)
{
VALUE      value[1];
double     point_value = (double) 0.0;
SWEEP_SEG  *seg_ptr;
int        i;

value[0].double_value = &point_value;

wclear (win);

draw_prompt (win,value,5);

for (i = 0; i < MAX_SEGMENTS; ++i)
   {
   if (!used_segments[i][smu])
      {
      used_segments[i][smu] = 1;
      sweep_list[i][smu].start = point_value;
      sweep_list[i][smu].type = SINGLE;
      sweep_list[i][smu].seg_num = i;
      sweep_list[i][smu].prev = last_segment[smu];
      sweep_list[i][smu].next = NULL;
      last_segment[smu] = &sweep_list[i][smu];
      if (sweep_list[i][smu].prev != NULL)
         {
         seg_ptr = sweep_list[i][smu].prev;
         seg_ptr->next = &sweep_list[i][smu];
         }
      else
         {
         first_segment[smu] = &sweep_list[i][smu];
         }
      break;
      }
   }
   
if (i == MAX_SEGMENTS)
   {
   sprintf (error_string,"Max allocated segments is %d!!!\nSegment ignored.",MAX_SEGMENTS);
   return (ERR);
   }
      
return 0;
}

/*                                                                   */
/*--- Function add_sweep --------------------------------------------*/
/*                                                                   */

int add_sweep (win,smu)
WINDOW *win;
int    smu;

{
VALUE      value[3];
double     start = (double) 0.0;
double     stop = (double) 0.0;
double     step = (double) 0.0;
SWEEP_SEG  *seg_ptr;
int        i;

value[0].double_value = &start;
value[1].double_value = &stop;
value[2].double_value = &step;

wclear (win);

draw_prompt (win,value,4);

if (start == stop)
   {
   sprintf (error_string,"START cannot equal STOP.\nSweep ignored");
   return (ERR);
   }
else if (step == (double) 0.0)
   {
   sprintf (error_string,"STEP cannot equal 0.\nSweep ignored.");
   return (ERR);
   }   
else if ((stop > start) && (step < (double) 0.0))
   {
   sprintf (error_string,"STOP is greater than START and STEP is negative.\nSweep ignored.");
   return (ERR);
   }
else if ((stop < start) && (step > (double) 0.0))
   {
   sprintf (error_string,"STOP is less than START and STEP is positive.\nSweep ignored.");
   return (ERR);
   }

for (i = 0; i < MAX_SEGMENTS; ++i)
   {
   if (!used_segments[i][smu])
      {
      used_segments[i][smu] = 1;
      sweep_list[i][smu].start = start;
      sweep_list[i][smu].stop = stop;
      sweep_list[i][smu].step = step;
      sweep_list[i][smu].type = SWEEP;
      sweep_list[i][smu].seg_num = i;
      sweep_list[i][smu].prev = last_segment[smu];
      sweep_list[i][smu].next = NULL;
      last_segment[smu] = &sweep_list[i][smu];
      if (sweep_list[i][smu].prev != NULL)
         {
         seg_ptr = sweep_list[i][smu].prev;
         seg_ptr->next = &sweep_list[i][smu];
         }
      else
         {
         first_segment[smu] = &sweep_list[i][smu];
         }
      break;
      }
   }
   
if (i == MAX_SEGMENTS)
   {
   sprintf (error_string,"Max allocated segments is %d!!!\nSegment ignored.",MAX_SEGMENTS);
   return (ERR);
   }
      
return (OK);
}


/*                                                                   */
/*--- Function insert_single ----------------------------------------*/
/*                                                                   */

int insert_single (win,smu)
WINDOW *win;
int    smu;

{
VALUE      value[1];
double     point_value = (double) 0.0;
int        i,j,ch;
char       string[1024];
int        insert_after;
int        num_segs;
SWEEP_SEG  *seg_ptr,*last_seg;

REDRAW:
if (first_segment[smu] == NULL)
   {
   sprintf (error_string,"No segments in memory.");
   return (ERR);
   }

list_segments (win,smu,&num_segs);

sprintf (string,"INSERT AFTER SEGMENT #: ");
i = (COLS-strlen (string))/2;
put_output (win,LINES-1,i,string);

wrefresh (win);
while (1)
   {
   ch = get_response (win,LINES-1,i+strlen (string),LINES-1,i+strlen (string)+5,string);
   if( ch==PKEY_ESCAPE || ch==PKEY_EXITFUNCTION)
      return OK;
   else if (ch == ERR)
      {
      sprintf (error_string,"internal error in get response");
      return (ERR);
      }
   else if (ch == OK)
      {
      sscanf (string,"%d",&insert_after);
      if ((insert_after < 0) || (insert_after > num_segs-1))
         {
         wclear (win);
         sprintf (string,"Invalid segment number.\nValid range is 0-%d",num_segs-1);
         put_output (win,0,0,string);
         wrefresh (win);
         get_character (win);
         goto REDRAW;
         }
      break;
      }
   }

value[0].double_value = &point_value;

wclear (win);

draw_prompt (win,value,5);

for (i = 0; i < MAX_SEGMENTS; ++i)
   {
   if (!used_segments[i][smu])
      {
      used_segments[i][smu] = 1;
      sweep_list[i][smu].start = point_value;
      sweep_list[i][smu].type = SINGLE;
      sweep_list[i][smu].seg_num = i;
      
      seg_ptr = first_segment[smu];
      for (j = 0; j < insert_after; ++j)
         {
         seg_ptr = seg_ptr->next;
         if (seg_ptr == NULL)
            {
            sprintf (error_string,"Internal error with linked list!!! - Missing segment");
            return (ERR);
            }
         }
      last_seg = seg_ptr->prev;         
      
      if (last_seg == NULL)
         {
         first_segment[smu] = &sweep_list[i][smu];
         sweep_list[i][smu].prev = NULL;
         sweep_list[i][smu].next = seg_ptr;
         }
      else
         {
         sweep_list[i][smu].next = last_seg->next;
         sweep_list[i][smu].prev = last_seg;
         last_seg->next = &sweep_list[i][smu];
         }
      seg_ptr->prev = &sweep_list[i][smu];     
      break;
      }
   }
   
if (i == MAX_SEGMENTS)
   {
   sprintf (error_string,"Max allocated segments is %d!!!\nSegment ignored.",MAX_SEGMENTS);
   return (ERR);
   }
      
return (OK);
}


/*                                                                   */
/*--- Function insert_sweep -----------------------------------------*/
/*                                                                   */

int insert_sweep (win,smu)
WINDOW *win;
int    smu;

{
VALUE       value[3];
double      start = (double) 0.0;
double      stop = (double) 0.0;
double      step = (double) 0.0;
int         i,j,ch;
char        string[1024];
int         insert_after;
int         num_segs;
SWEEP_SEG   *seg_ptr,*last_seg;

REDRAW:
if (first_segment[smu] == NULL)
   {
   sprintf (error_string,"No segments in memory.");
   return (ERR);
   }

list_segments (win,smu,&num_segs);

sprintf (string,"INSERT AFTER SEGMENT #: ");
i = (COLS-strlen (string))/2;
put_output (win,LINES-1,i,string);

wrefresh (win);
while (1)
   {
   ch = get_response (win,LINES-1,i+strlen (string),LINES-1,i+strlen (string)+5,string);
   if( ch==PKEY_ESCAPE || ch==PKEY_EXITFUNCTION )
      return OK;
   else if (ch == ERR)
      {
      sprintf (error_string,"internal error in get response");
      return (ERR);
      }
   else if (ch == OK)
      {
      sscanf (string,"%d",&insert_after);
      if ((insert_after < 0) || (insert_after > num_segs-1))
         {
         wclear (win);
         sprintf (string,"Invalid segment number.\nValid range is 0-%d",num_segs-1);
         put_output (win,0,0,string);
         wrefresh (win);
         get_character (win);
         goto REDRAW;
         }
      break;
      }
   }

value[0].double_value = &start;
value[1].double_value = &stop;
value[2].double_value = &step;

wclear (win);

draw_prompt (win,value,4);

if (start == stop)
   {
   sprintf (error_string,"START cannot equal STOP.\nSweep ignored");
   return (ERR);
   }
else if (step == (double) 0.0)
   {
   sprintf (error_string,"STEP cannot equal 0.\nSweep ignored.");
   return (ERR);
   }   
else if ((stop > start) && (step < (double) 0.0))
   {
   sprintf (error_string,"STOP is greater than START and STEP is negative.\nSweep ignored.");
   return (ERR);
   }
else if ((stop < start) && (step > (double) 0.0))
   {
   sprintf (error_string,"STOP is less than START and STEP is positive.\nSweep ignored.");
   return (ERR);
   }

for (i = 0; i < MAX_SEGMENTS; ++i)
   {
   if (!used_segments[i][smu])
      {
      used_segments[i][smu] = 1;
      sweep_list[i][smu].start = start;
      sweep_list[i][smu].stop = stop;
      sweep_list[i][smu].step = step;
      sweep_list[i][smu].type = SWEEP;
      sweep_list[i][smu].seg_num = i;
      
      seg_ptr = first_segment[smu];
      for (j = 0; j < insert_after; ++j)
         {
         seg_ptr = seg_ptr->next;
         if (seg_ptr == NULL)
            {
            sprintf (error_string,"Internal error with linked list!!! - Missing segment");
            return (ERR);
            }
         }
      last_seg = seg_ptr->prev;         
      
      if (last_seg == NULL)
         {
         first_segment[smu] = &sweep_list[i][smu];
         sweep_list[i][smu].prev = NULL;
         sweep_list[i][smu].next = seg_ptr;
         }
      else
         {
         sweep_list[i][smu].next = last_seg->next;
         sweep_list[i][smu].prev = last_seg;
         last_seg->next = &sweep_list[i][smu];
         }
      seg_ptr->prev = &sweep_list[i][smu];     
      break;
      }
   }
   
if (i == MAX_SEGMENTS)
   {
   sprintf (error_string,"Max allocated segments is %d!!!\nSegment ignored.",MAX_SEGMENTS);
   return (ERR);
   }
      
return (OK);
}

/*                                                                   */
/*--- Function view_segments ----------------------------------------*/
/*                                                                   */

int view_segments (win,smu)
WINDOW *win;
int    smu;

{
int    num_segs;

if (first_segment[smu] == NULL)
   {
   sprintf (error_string,"No segments to display.");
   return (ERR);
   }

list_segments (win,smu,&num_segs);

wrefresh (win);

get_character (win);
return (OK);
}


/*                                                                   */
/*--- Function delete_segment ---------------------------------------*/
/*                                                                   */

int delete_segment (win,smu)
WINDOW *win;
int    smu;

{
int       segment;
int       i,ch;
char      string[1024];
int       num_segs;
SWEEP_SEG *seg_ptr,*seg_ptr2;

REDRAW:
if (first_segment[smu] == NULL)
   {
   sprintf (error_string,"No segments in memory.");
   return (ERR);
   }

list_segments (win,smu,&num_segs);

sprintf (string,"SEGMENT # TO DELETE: ");
i = (COLS-strlen (string))/2;
put_output (win,LINES-1,i,string);

wrefresh (win);

while (1)
   {
   ch = get_response (win,LINES-1,i+strlen (string),LINES-1,i+strlen (string)+5,string);
   if(ch==PKEY_ESCAPE||ch==PKEY_EXITFUNCTION)
     return OK; 
   else if (ch == ERR)
      {
      sprintf (error_string,"internal error in get response");
      return (ERR);
      }
   else if (ch == OK)
      {
      if ((string[0] < 48) || (string[0] > 57))
         {
         return (OK);
         }
      sscanf (string,"%d",&segment);
      if ((segment < 1) || (segment > num_segs))
         {
         wclear (win);
         sprintf (string,"Invalid segment number.\nValid range is 1-%d",num_segs);
         put_output (win,0,0,string);
         wrefresh (win);
         get_character (win);
         goto REDRAW;
         }
      seg_ptr = first_segment[smu];
      for (i = 0; i < segment-1; ++i)
         {
         seg_ptr = seg_ptr->next;
         }

      used_segments[seg_ptr->seg_num][smu] = 0;
      if ((seg_ptr->prev == NULL) && (seg_ptr->next == NULL))
         {
         first_segment[smu] = NULL;
         last_segment[smu] = NULL;
         break;
         }      
      else if (seg_ptr->prev == NULL)
         {
         seg_ptr = seg_ptr->next;
         first_segment[smu] = seg_ptr;
         seg_ptr->prev = NULL;
         }
      else if (seg_ptr->next == NULL)
         {
         seg_ptr = seg_ptr->prev;
         last_segment[smu] = seg_ptr;
         seg_ptr->next = NULL;
         }
      else
         {
         seg_ptr2 = seg_ptr->next;
         seg_ptr = seg_ptr->prev;
         seg_ptr2->prev = seg_ptr;
         seg_ptr->next = seg_ptr2;
         }

      goto REDRAW;
      }
   }
         
return (OK);
}


/*                                                                   */
/*--- Function list_segments ----------------------------------------*/
/*                                                                   */

list_segments (win,smu,num_segs)
WINDOW *win;
int    smu;
int    *num_segs;

{
char       string[1024];
char       tmp_str[51];
SWEEP_SEG  *seg_ptr;
int        decimal[3];
char       range[3];
int        seg_number;
int        i,line,column;
double     disp[3];
double     values[3];

wclear (win);
if (SMU[smu].source == 1)
   {
   sprintf (string,"SWEEP LIST (VOLTS)");
   }
else if (SMU[smu].source == 2)
   {
   sprintf (string,"SWEEP LIST (AMPS)");
   }
else
   {
   sprintf (error_string,"SMU mode is set to OFF!!!!");
   return (ERR);
   }
put_output (win,0,(COLS-strlen (string))/2,string);

sprintf (string," # TYPE  START    STOP    STEP");
put_output (win,2,0,string);
sprintf (string,"-------------------------------");
put_output (win,3,0,string);

seg_ptr = first_segment[smu];
line = 4;
column = 0;
seg_number = 1;
while (seg_ptr != NULL)
   {
   if (line > LINES-3)
      {
      line = 4;
      column += 33;
      sprintf (string," # TYPE  START    STOP    STEP");
      put_output (win,2,column,string);
      sprintf (string,"-------------------------------");
      put_output (win,3,column,string);
      }   
   if (seg_ptr->type == SINGLE)
      {
      find_display_range (&seg_ptr->start,range,disp,decimal,SINGLE);
      switch (decimal[0])
         {
         case 1:
            sprintf (string,"%2d SING %6.1f%c",seg_number,disp[0],range[0]);
            break;
         case 2:
            sprintf (string,"%2d SING %6.2f%c",seg_number,disp[0],range[0]);
            break;
         case 3:
         default:
            sprintf (string,"%2d SING %6.3f%c",seg_number,disp[0],range[0]);
            break;
         }
      put_output (win,line,column,string);
      }
   else
      {
      values[0] = seg_ptr->start;
      values[1] = seg_ptr->stop;
      values[2] = seg_ptr->step;
      find_display_range (values,range,disp,decimal,SWEEP);

      sprintf (string,"%2d SWP  ",seg_number);
      for (i = 0; i < 3; ++i)
         {
         switch (decimal[i])
            {
            case 1:
               sprintf (tmp_str,"%6.1f%c ",disp[i],range[i]);
               break;
            case 2:
               sprintf (tmp_str,"%6.2f%c ",disp[i],range[i]);
               break;
            case 3:
            default:
               sprintf (tmp_str,"%6.3f%c ",disp[i],range[i]);
               break;
            }
         strcat (string,tmp_str);
         }
      put_output (win,line,column,string);
      }

   ++seg_number;
   ++line;
   seg_ptr = seg_ptr->next;
   }
   
*num_segs = seg_number - 1;

return (OK);
}


/*                                                                   */
/*--- Function find_display_range -----------------------------------*/
/*                                                                   */

int find_display_range (value,range,rtn_value,decimal,type)
double *value;
char   *range;
double *rtn_value;
int    *decimal;
int    type;

{
int i,j;

if (type == SINGLE)
   {
   j = 1;
   }
else
   {
   j = 3;
   }

for (i = 0; i < j; ++i)
   {
   if ((fabs (value[i]) >= (double) 1.0) || (value[i] == (double) 0.0))
      {
      rtn_value[i] = value[i];
      range[i] = ' ';
      }
   else if ((fabs (value[i]) < (double) 1.0) && (fabs (value[i]) >= (double) 1.0e-3))
      {
      rtn_value[i] = value[i]*((double) 1000.0);
      range[i] = 'm';
      }
   else if ((fabs (value[i]) < (double) 1.0e-3) && (fabs (value[i]) >= (double) 1.0e-6))
      {
      rtn_value[i] = value[i]*((double) 1.0e6);
      range[i] = 'u';
      }
   else if ((fabs (value[i]) < (double) 1.0e-6) && (fabs (value[i]) >= (double) 1.0e-9))
      {
      rtn_value[i] = value[i]*((double) 1.0e9);
      range[i] = 'n';
      }
   else
      {
      rtn_value[i] = value[i]*((double) 1.0e12);
      range[i] = 'p';
      }

   if (fabs (rtn_value[i]) >= (double) 100.0)
      {
      decimal[i] = 1;
      }
   else if (fabs (rtn_value[i]) >= (double) 10.0)
      {
      decimal[i] = 2;
      }
   else
      {
      decimal[i] = 3;
      }
   }

return (OK);
}


/*                                                                   */
/*--- Function system_command ---------------------------------------*/
/*                                                                   */

int system_command (win,item)
WINDOW *win;
int    item;

{

wclear (win);
wrefresh (win);
endwin ();
system ("csh");
wclear (win);
wrefresh (win);

return (OK);
}


/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

return;
}


/*                                                                   */
/*--- Function recall_configuration ---------------------------------*/
/*                                                                   */

int recall_configuration (win,item)
WINDOW *win;
int    item;

{
FILE       *config_file;
int        i;
int        Single;
char       string[1024];
char       version[81];
char       format[81];
VALUE      value[1];
SWEEP_SEG  *seg_ptr;
double     start,stop,step;

value[0].string_value = CONFIGURATION_FILE;

wclear (win);

draw_prompt (win,value,1);

config_file = (FILE *) NULL;
config_file = fopen (CONFIGURATION_FILE,"r");

if (config_file == (FILE *) NULL)
   {
   sprintf (error_string,"config file not found!!!");
   return (ERR);
   }

fgets (string,1023,config_file);
sscanf (string,"%s",version);

if (strcmp(version,"dc_v100") == 0)
   {
   fgets (string,1023,config_file);
   strcpy (header_info.file_name," ");
   sscanf (string,"%s",header_info.file_name);
   fgets (string,1023,config_file);
   strcpy (header_info.mask_name," ");
   sscanf (string,"%s",header_info.mask_name);
   fgets (string,1023,config_file);
   strcpy (header_info.wafer_number," ");
   sscanf (string,"%s",header_info.wafer_number);
   fgets (string,1023,config_file);
   strcpy (header_info.process_name," ");
   sscanf (string,"%s",header_info.process_name);
   fgets (string,1023,config_file);
   strcpy (header_info.device_name," ");
   sscanf (string,"%s",header_info.device_name);
   fgets (string,1023,config_file);
   sscanf (string,"%lf",&header_info.temperature);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&i);
   sprintf (format,"%%%dc",i);
   fread (string,sizeof(char),i+1,config_file);
   strcpy (header_info.comments," ");
   sscanf (string,format,header_info.comments);
   header_info.comments[i] = '\0';

   strcpy (menu1[4].menu_item_text,"MULTI-SITE  <OFF>   ");
   multisite_test.on_or_off = 0;
   fgets (string,1023,config_file);
   sscanf (string,"%s",multisite_test.map_filename);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&multisite_test.orientation);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&multisite_test.x_index);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&multisite_test.y_index);
   
   fgets (string,1023,config_file);
   sscanf (string,"%d",&smu_sweep_mode);  
   switch (smu_sweep_mode)
      {
      case SMU1_ONLY:
         strcpy (menu2[2].menu_item_text,"MODE: SMU1 ONLY       ");
         break;
      case SMU2_ONLY:
         strcpy (menu2[2].menu_item_text,"MODE: SMU2 ONLY       ");
         break;
      case SIMULT_SWP:
         strcpy (menu2[2].menu_item_text,"MODE: SIMULTANEOUS SWP");
         break;
      case STEP1_SWEEP2:
         strcpy (menu2[2].menu_item_text,"MODE: STEP1/SWEEP2    ");
         break;
      case STEP2_SWEEP1:
         strcpy (menu2[2].menu_item_text,"MODE: SWEEP1/STEP2    ");
         break;
      case STEP1_CONST2:
         strcpy (menu2[2].menu_item_text,"MODE: STEP1/CONSTANT2 ");
         break;
      case STEP2_CONST1:
         strcpy (menu2[2].menu_item_text,"MODE: CONSTANT1/STEP2 ");
         break;
      default:
         smu_sweep_mode = SMU1_ONLY;
         strcpy (menu2[2].menu_item_text,"MODE: SMU1 ONLY       ");
         break;
      }   
   
   fgets (string,1023,config_file);
   sscanf (string,"%d",&master);
   if (master == 1)
      {
      strcpy (menu2[3].menu_item_text,"MASTER: SMU 2         ");
      }
   else
      {
      master = 0;
      strcpy (menu2[3].menu_item_text,"MASTER: SMU 1         ");
      }    
   
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[0].source);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[0].integration);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[0].filter);   
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[0].sensing);
   fgets (string,1023,config_file);
   sscanf (string,"%lf",&SMU[0].compliance);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[0].delay);
   fgets (string,1023,config_file);
   sscanf (string,"%lf",&SMU[0].dc_value);
   
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[1].source);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[1].integration);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[1].filter);   
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[1].sensing);
   fgets (string,1023,config_file);
   sscanf (string,"%lf",&SMU[1].compliance);
   fgets (string,1023,config_file);
   sscanf (string,"%d",&SMU[1].delay);
   fgets (string,1023,config_file);
   sscanf (string,"%lf",&SMU[1].dc_value);

   first_segment[0] = NULL;
   first_segment[1] = NULL;
   last_segment[0] = NULL;
   last_segment[1] = NULL;   
   for (i = 0; i < MAX_SEGMENTS; ++i)
      {
      used_segments[i][0] = 0;
      used_segments[i][1] = 0;
      }
   
   i = 0;
   fgets (string,1023,config_file);
   while (fgets (string,1023,config_file) != NULL)
      {
      if (!strncmp (string,"[sweep list 2]",14))
         {
         break;
         }
      else
         {
         if (string[0] == '0')
            {
            sscanf (string,"%*d %lf",&start);
            Single = 1;
            }
         else
            {
            sscanf (string,"%*d %lf %lf %lf",&start,&stop,&step);
            Single = 0;
            }
                 
         used_segments[i][0] = 1;
         if (Single)
            {
            sweep_list[i][0].start = start;
            sweep_list[i][0].type = SINGLE;
            }
         else
            {
            sweep_list[i][0].start = start;
            sweep_list[i][0].stop = stop;
            sweep_list[i][0].step = step;
            sweep_list[i][0].type = SWEEP;
            }
         sweep_list[i][0].seg_num = i;
         sweep_list[i][0].prev = last_segment[0];
         sweep_list[i][0].next = NULL;
         last_segment[0] = &sweep_list[i][0];
         if (i == 0)
            {
            first_segment[0] = &sweep_list[i][0];
            }         
         else
            {
            seg_ptr = sweep_list[i][0].prev;
            seg_ptr->next = &sweep_list[i][0];
            }

         ++i;
         }
      }

   i = 0;
   while (fgets (string,1023,config_file) != NULL)
      {
      if (string[0] == '0')
         {
         sscanf (string,"%*d %lf",&start);
         Single = 1;
         }
      else
         {
         sscanf (string,"%*d %lf %lf %lf",&start,&stop,&step);
         Single = 0;
         }
                 
      used_segments[i][1] = 1;
      if (Single)
         {
         sweep_list[i][1].start = start;
         sweep_list[i][1].type = SINGLE;
         }
      else
         {
         sweep_list[i][1].start = start;
         sweep_list[i][1].stop = stop;
         sweep_list[i][1].step = step;
         sweep_list[i][1].type = SWEEP;
         }
      sweep_list[i][1].seg_num = i;
      sweep_list[i][1].prev = last_segment[1];
      sweep_list[i][1].next = NULL;
      last_segment[1] = &sweep_list[i][1];
      if (i == 0)
         {
         first_segment[1] = &sweep_list[i][1];
         }         
      else
         {
         seg_ptr = sweep_list[i][1].prev;
         seg_ptr->next = &sweep_list[i][1];
         }

      ++i;
      }

   }
else
   {
   fclose (config_file);
   sprintf (error_string,"wrong version of config file!!");
   return (ERR);
   }

fclose (config_file);
return (OK);
}

/*                                                                   */
/*--- Function save_configuration -----------------------------------*/
/*                                                                   */

int save_configuration (win,item)
WINDOW *win;
int    item;

{
FILE       *config_file;
VALUE      value[1];
SWEEP_SEG  *seg_ptr;

value[0].string_value  = CONFIGURATION_FILE;

wclear (win);

draw_prompt (win,value,1);

config_file = fopen (CONFIGURATION_FILE,"w+");

fprintf (config_file,"dc_v100\n");
fprintf (config_file,prompt1[0].format,header_info.file_name);
fprintf (config_file,"\n");
fprintf (config_file,prompt1[1].format,header_info.mask_name);
fprintf (config_file,"\n");
fprintf (config_file,prompt1[2].format,header_info.wafer_number);
fprintf (config_file,"\n");
fprintf (config_file,prompt1[3].format,header_info.process_name);
fprintf (config_file,"\n");
fprintf (config_file,prompt1[4].format,header_info.device_name);
fprintf (config_file,"\n");
fprintf (config_file,prompt1[5].format,header_info.temperature);
fprintf (config_file,"\n");
fprintf (config_file,"%d\n",strlen(header_info.comments));
fprintf (config_file,prompt1[6].format,header_info.comments);
fprintf (config_file,"\n");

fprintf (config_file,prompt3[0].format,multisite_test.map_filename);
fprintf (config_file,"\n");
fprintf (config_file,prompt3[1].format,multisite_test.orientation);
fprintf (config_file,"\n");
fprintf (config_file,prompt3[2].format,multisite_test.x_index);
fprintf (config_file,"\n");
fprintf (config_file,prompt3[3].format,multisite_test.y_index);
fprintf (config_file,"\n");

fprintf (config_file,"%d\n",smu_sweep_mode);
fprintf (config_file,"%d\n",master);

fprintf (config_file,prompt7[0].format,SMU[0].source);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[1].format,SMU[0].integration);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[2].format,SMU[0].filter);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[3].format,SMU[0].sensing);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[4].format,SMU[0].compliance);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[5].format,SMU[0].delay);
fprintf (config_file,"\n");
fprintf (config_file,prompt4[0].format,SMU[0].dc_value);
fprintf (config_file,"\n");

fprintf (config_file,prompt7[0].format,SMU[1].source);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[1].format,SMU[1].integration);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[2].format,SMU[1].filter);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[3].format,SMU[1].sensing);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[4].format,SMU[1].compliance);
fprintf (config_file,"\n");
fprintf (config_file,prompt7[5].format,SMU[1].delay);
fprintf (config_file,"\n");
fprintf (config_file,prompt4[0].format,SMU[1].dc_value);
fprintf (config_file,"\n");

fprintf (config_file,"[sweep list 1]\n");
seg_ptr = first_segment[0];
while (seg_ptr != NULL)
   {
   if (seg_ptr->type == SINGLE)
      {
      fprintf (config_file,"0 %.4e\n",seg_ptr->start);
      }
   else
      {
      fprintf (config_file,"1 %.4e %.4e %.4e\n",seg_ptr->start,seg_ptr->stop,seg_ptr->step);
      }
   seg_ptr = seg_ptr->next;
   }
   
fprintf (config_file,"[sweep list 2]\n");
seg_ptr = first_segment[1];
while (seg_ptr != NULL)
   {
   if (seg_ptr->type == SINGLE)
      {
      fprintf (config_file,"0 %.4e\n",seg_ptr->start);
      }
   else
      {
      fprintf (config_file,"1 %.4e %.4e %.4e\n",seg_ptr->start,seg_ptr->stop,seg_ptr->step);
      }
   seg_ptr = seg_ptr->next;
   }   

fclose (config_file);
return (OK);
}


/*                                                                   */
/*--- Function quit_program -----------------------------------------*/
/*                                                                   */

int quit_program (win,item)
WINDOW *win;
int    item;

{
return (PR_EXIT);
}


/*                                                                   */
/*--- Function quit_menu --------------------------------------------*/
/*                                                                   */

int quit_menu (win,item)
WINDOW *win;
int    item;

{
return (PKEY_ESCAPE);
}


/*                                                                   */
/*--- Function measure_dc -------------------------------------------*/
/*                                                                   */

int measure_dc (win,item)
WINDOW *win;
int    item;

{
VALUE       value[7];
char        string[1024];
int         i,site,line,error = 0;
ERROR_LOG   *old_ptr;
char        site_str[21],temp_str[11];
double      *sweep_list1,*sweep_list2;
int         swp_pts1,swp_pts2,abort_test = 0;

value[0].string_value  = header_info.file_name;
value[1].string_value  = header_info.mask_name;
value[2].string_value  = header_info.wafer_number;
value[3].string_value  = header_info.process_name;
value[4].string_value  = header_info.device_name;
value[5].double_value = &header_info.temperature;
value[6].string_value = header_info.comments;

sweep_list1 = NULL;
sweep_list2 = NULL;

wclear (win);
strcpy (string,"Writing file header info ...");
put_output (win,LINES/2,(COLS-strlen(string))/2,string);
wrefresh (win);

if (file_check (header_info.file_name) != ERR)
   {   
   sprintf (string,"cp %s %s_bak",header_info.file_name,header_info.file_name);
   system (string);
   }

out_file = fopen (header_info.file_name,"w+");

for (i = 0; i < 6; ++i)
   {
   fprintf (out_file,"!%s ",prompt[0].prompt_item[i].prompt_text);
   switch (prompt[0].prompt_item[i].return_type)
      {
      case STRING:
      case CHARACTERS:
         fprintf (out_file,prompt[0].prompt_item[i].format,value[i].string_value);
         break;
      case INT:
         fprintf (out_file,prompt[0].prompt_item[i].format,*value[i].int_value);
         break;
      case DOUBLE:
         fprintf (out_file,prompt[0].prompt_item[i].format,*value[i].double_value);
         break;
      }
   fprintf (out_file,"\n");
   }

get_the_time (header_info.date_and_time);
fprintf (out_file,"!DATE AND TIME: %s\n",header_info.date_and_time);
fprintf (out_file,"!%s\n!",prompt[0].prompt_item[6].prompt_text);

i = 0;
while (header_info.comments[i] != '\0')
   {
   if (header_info.comments[i] == '\n')
      {
      fprintf (out_file,"%c!",header_info.comments[i]);
      }
   else
      {
      fprintf (out_file,"%c",header_info.comments[i]);
      }
   ++i;
   }

fprintf (out_file,"\n");
fflush (out_file);

// set the 8510 in hold mode
put_8510_in_hold_mode ();

while (error_log != NULL) /* clear the error log */
   {
   old_ptr = error_log;
   error_log = error_log->next;
   free ((char *) old_ptr);
   }

/* allocate memory, check modes, and fill the sweep lists */
swp_pts1 = swp_pts2 = 0;
sweep_list1 = sweep_list2 = NULL;
switch (smu_sweep_mode)
   {
   case SMU1_ONLY:
      if (SMU[0].source == 0)
	 {
	 sprintf (error_string,"ERROR: Smu 1 is set to OFF");
	 fclose (out_file);
	 return (ERR);
	 }
      sweep_list1 = make_sweep_list (0,&swp_pts1);
      break;
   case STEP1_CONST2:
      if ((SMU[0].source == 0) || (SMU[1].source == 0))
	 {
	 sprintf (error_string,"ERROR: Neither Smu can be set to OFF");
	 fclose (out_file);
	 return (ERR);
	 }
      sweep_list1 = make_sweep_list (0,&swp_pts1);
      break;
   case SIMULT_SWP:
      if (SMU[master].source == 0)
	 {
	 sprintf (error_string,"ERROR: Smu %d is set to OFF",master+1);
	 fclose (out_file);
	 return (ERR);
	 }
      sweep_list1 = make_sweep_list (master,&swp_pts1);
      break;
   case STEP1_SWEEP2:
   case STEP2_SWEEP1:
      if ((SMU[0].source == 0) || (SMU[1].source == 0))
	 {
	 sprintf (error_string,"ERROR: Neither Smu can be set to OFF");
	 fclose (out_file);
	 return (ERR);
	 }
      sweep_list1 = make_sweep_list (master,&swp_pts1);
      break;
   case SMU2_ONLY:
      if (SMU[1].source == 0)
	 {
	 sprintf (error_string,"ERROR: Smu 2 is set to OFF");
	 fclose (out_file);
	 return (ERR);
	 }
      sweep_list1 = make_sweep_list (1,&swp_pts1);
      break;
   case STEP2_CONST1:
      if ((SMU[0].source == 0) || (SMU[1].source == 0))
	 {
	 sprintf (error_string,"ERROR: Neither Smu can be set to OFF");
	 fclose (out_file);
	 return (ERR);
	 }
      sweep_list1 = make_sweep_list (1,&swp_pts1);
      break;
   default:
      sprintf (error_string,"ERROR: Invalid operating mode!!!");
      fclose (out_file);
      return (ERR);
      break;
   }

sprintf (error_string,"Sweep list memory allocation problem.");

if (sweep_list1 == NULL)
   {
   fclose (out_file);
   return (ERR);
   }

if ((smu_sweep_mode == STEP1_SWEEP2) || (smu_sweep_mode == STEP2_SWEEP1))
   {
   if (master == 0)
      {
      sweep_list2 = make_sweep_list (1,&swp_pts2);
      }
   else
      {
      sweep_list2 = make_sweep_list (0,&swp_pts2);
      }

   if (sweep_list2 == NULL)
      {
      free ((char *) sweep_list1);
      fclose (out_file);
      return (ERR);
      }
   }

// set curses in nodelay mode to catch abort requests
//  without blocking to wait for the next character
nodelay(win,TRUE);
      
if (multisite_test.on_or_off)
   {
   for (site = 0; site < multisite_test.num_sites; ++site)
      {
      if (multisite_test.site[site][0] < 10)
         {
         sprintf (site_str,"0%d",multisite_test.site[site][0]);
         }
      else
         {
         sprintf (site_str,"%d",multisite_test.site[site][0]);
         }          
      if (multisite_test.site[site][1] < 10)
         {
         sprintf (temp_str,"0%d",multisite_test.site[site][1]);
         }
      else
         {
         sprintf (temp_str,"%d",multisite_test.site[site][1]);
         }
      strcat (site_str,temp_str);

      wclear (win);
      sprintf (string,"Moving Cascade Probe Station ...");
      put_output (win,LINES/2,(COLS-strlen(string))/2,string);
      wrefresh (win);       

      fprintf (out_file,"!SITE: X = %d Y = %d\n",multisite_test.site[site][0],multisite_test.site[site][1]);
      if (move_prober (site) == ERR)
         {
         log_error (site_str);
         break;
         }      
               
      wclear (win);
      sprintf (string,"Performing DC measurement on site %s ...",site_str);
      put_output (win,LINES/2,(COLS-strlen(string))/2,string);
      wrefresh (win);       
      
      switch (smu_sweep_mode)
         {
         case SMU1_ONLY:
            if (one_smu (0,sweep_list1,swp_pts1) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;
         case SMU2_ONLY:
            if (one_smu (1,sweep_list1,swp_pts1) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;
         case SIMULT_SWP:
            if (simult_sweep (sweep_list1,swp_pts1) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;
         case STEP1_SWEEP2:
            if (step_sweep (0,sweep_list1,swp_pts1,sweep_list2,swp_pts2) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;
         case STEP2_SWEEP1:
            if (step_sweep (1,sweep_list1,swp_pts1,sweep_list2,swp_pts2) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;
         case STEP1_CONST2:
            if (const_step (1,sweep_list1,swp_pts1) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;         
         case STEP2_CONST1:
            if (const_step (0,sweep_list1,swp_pts1) == ERR)
               {
               if (!strncmp(error_string,"USER ABORT",10))
                  abort_test = 1;
               log_error (site_str);
               }
            break;
         default:
            break;
         }
      
      fflush (out_file);

      if (abort_test)
         break;
               
      if (check_user_abort() )
         {
         abort_test = 1;
         break;
         }
      }
   }
else
   {   
   wclear (win);
   strcpy (string,"Performing DC measurement ...");
   put_output (win,LINES/2,(COLS-strlen(string))/2,string);
   wrefresh (win);   
   
   switch (smu_sweep_mode)
      {
      case SMU1_ONLY:
         if (one_smu (0,sweep_list1,swp_pts1) == ERR)
            {
            error = 1;
            }
         break;
      case SMU2_ONLY:
         if (one_smu (1,sweep_list1,swp_pts1) == ERR)
            {
            error = 1;
            }
         break;
      case SIMULT_SWP:
         if (simult_sweep (sweep_list1,swp_pts1) == ERR)
            {
            error = 1;
            }
         break;
      case STEP1_SWEEP2:
         if (step_sweep (0,sweep_list1,swp_pts1,sweep_list2,swp_pts2) == ERR)
            {
            error = 1;
            }
         break;
      case STEP2_SWEEP1:
         if (step_sweep (1,sweep_list1,swp_pts1,sweep_list2,swp_pts2) == ERR)
            {
            error = 1;
            }
         break;
      case STEP1_CONST2:
         if (const_step (1,sweep_list1,swp_pts1) == ERR)
            {
            error = 1;
            }
         break;         
      case STEP2_CONST1:
         if (const_step (0,sweep_list1,swp_pts1) == ERR)
            {
            error = 1;
            }
         break;
      default:
         break;
      }   
   }

fclose (out_file);

/* free sweep list malloc'd memory */
free ((char *) sweep_list1);
if (sweep_list2 != NULL)
   {
   free ((char *) sweep_list2);
   }

if (error_log != NULL) /* print errors and clear malloc'd memory */
   {   
   wclear (win);
   sprintf (string,"THE FOLLOWING ERRORS OCCURED DURING MEASUREMENT:");
   put_output (win,0,0,string);

   line = 1;
   while (error_log != NULL)
      {
      sprintf (string,"%s - %s",error_log->site,error_log->error);
      put_output (win,line,0,string);
      line += error_log->lines;
      old_ptr = error_log;
      error_log = error_log->next;
      free ((char *) old_ptr);
      }
   
   wrefresh (win);
   get_character (win);
   }

// set curses back into delay mode for normal operation 
//  without blocking to wait for the next character
nodelay(win,FALSE);

if (error || abort_test)
   {
   return (ERR);
   }

return (OK);
}


/*                                                                   */
/*--- Function log_error --------------------------------------------*/
/*                                                                   */

int log_error (site)
char *site;

{
ERROR_LOG *current_error;
int       i,lines;

if (error_log == NULL)
   {
   error_log = (ERROR_LOG *) malloc (sizeof (ERROR_LOG));
   current_error = error_log;
   }
else
   {
   current_error = error_log;
   while (current_error->next != NULL)
      {
      current_error = current_error->next;
      }

   current_error->next = (ERROR_LOG *) malloc (sizeof (ERROR_LOG));
   current_error = current_error->next;
   }

if (current_error == NULL)
   {
   return (OK);
   }

current_error->next = NULL;
strcpy (current_error->error,error_string);
strcpy (current_error->site,site);

lines = 1;
for (i = 0; i < strlen (error_string) - 2; ++i)
   {
   if (error_string[i] == '\n')
      {
      ++lines;
      }
   }

current_error->lines = lines;

return (OK);
}


/*                                                                   */
/*--- Function make_sweep_list --------------------------------------*/
/*                                                                   */

double *make_sweep_list (smu,num_pts)
int      smu;
int      *num_pts;

{
unsigned int count;
double       value;
SWEEP_SEG    *seg_ptr;
double       *sweep_list;

seg_ptr = first_segment[smu];
if (seg_ptr == NULL)
   {
   sprintf (error_string,"No segments in memory for SMU %d",smu+1);
   return NULL;
   }

count = 0;
while (seg_ptr != NULL)
   {
   if (seg_ptr->type == SINGLE)
      {
      ++count;
      }
   else
      {
      count += ((int) ((seg_ptr->stop - seg_ptr->start + ((double) 0.5)*seg_ptr->step) / seg_ptr->step)) + 1;
      }

   seg_ptr = seg_ptr->next;
   }

sweep_list = (double *) malloc (sizeof (double)*count);
if (sweep_list == NULL)
   {
   sprintf (error_string,"malloc() failed.\nInadequate system resources available.");
   return NULL;
   }

seg_ptr = first_segment[smu];
count = 0;
while (seg_ptr != NULL)
   {
   if (seg_ptr->type == SINGLE)
      {
      sweep_list[count] = seg_ptr->start;
      ++count;
      }
   else
      {
      if (seg_ptr->step > (double) 0.0)
         {
         for (value = seg_ptr->start; value < (seg_ptr->stop + ((double) 0.5)*seg_ptr->step); value += seg_ptr->step)
            {
            sweep_list[count] = value;
            ++count;
            }
         }
      else
         {
         for (value = seg_ptr->start; value > (seg_ptr->stop + ((double) 0.5)*seg_ptr->step); value += seg_ptr->step)
            {
            sweep_list[count] = value;
            ++count;
            }
         }
      }

   seg_ptr = seg_ptr->next;
   }

*num_pts = count;

return sweep_list;
}


/*                                                                   */
/*--- Function check_user_abort -------------------------------------*/
/*                                                                   */

int check_user_abort ()
{
int ch = get_char_asynch (global_win);
if( ch == ABORT_TEST_CHAR ) return 1;
return 0;
}


/*                                                                   */
/*--- Function draw_prompt ------------------------------------------*/
/*                                                                   */

int draw_prompt (win,value,m)
WINDOW  *win;
VALUE   value[];
int     m;

{
int    i;
int    item;
int    ch;
char   string[1024];

for (i = 0; i < prompt[m].n; ++i)
   {
   if (put_output (win,prompt[m].prompt_item[i].y_text_location,
                       prompt[m].prompt_item[i].x_text_location,
                       prompt[m].prompt_item[i].prompt_text) != OK)
      {
      error_message (
      "setup_header_info - your window is too small to display the menu");
      return (ERR);
      }

   switch (prompt[m].prompt_item[i].return_type)
      {
      case STRING:
         sprintf (string,prompt[m].prompt_item[i].format,value[i].string_value);
         break;
      case CHARACTERS:
         sprintf (string,prompt[m].prompt_item[i].format,value[i].string_value);
         break;
      case INT:
         sprintf (string,prompt[m].prompt_item[i].format,*value[i].int_value);
         break;
      case DOUBLE:
         sprintf (string,prompt[m].prompt_item[i].format,*value[i].double_value);
         break;
      }

   if (put_output (win,prompt[m].prompt_item[i].y1_get_location,
                       prompt[m].prompt_item[i].x1_get_location,string) != OK)
      {
      error_message (
      "setup_header_info - your window is too small to display the menu");
      return (ERR);
      }
   }

wrefresh (win);

item = 0;
while (1 )
   {
   ch = get_response (win,prompt[m].prompt_item[item].y1_get_location,
                               prompt[m].prompt_item[item].x1_get_location,
                               prompt[m].prompt_item[item].y2_get_location,
                               prompt[m].prompt_item[item].x2_get_location,
                               string);
   if( ch == PKEY_ESCAPE || ch == PKEY_EXITFUNCTION )
   {
      return OK; 
   }
   else if (ch == ERR)
      {
      error_message (
      "setup_header_info - error in get_response");
      return (ERR);
      }

   switch (prompt[m].prompt_item[item].return_type)
      {
      case STRING:
         strcpy (value[item].string_value," ");
         sscanf (string,"%s",value[item].string_value);
         break;
      case CHARACTERS:
         strcpy (value[item].string_value,string);
         break;
      case INT:
         sscanf (string,"%d",value[item].int_value);
         break;
      case DOUBLE:
         sscanf (string,"%lf",value[item].double_value);
         break;
      }

   if ((ch == OK) || (ch == KEY_DOWN))
      {
      ++item;
      }
   else
      {
      --item;
      }

   if (item >= prompt[m].n)
      {
      item = 0;
      }
   else if (item < 0)
      {
      item = prompt[m].n-1;
      }
   }

return (OK);
}


/*                                                                   */
/*--- Function draw_menu --------------------------------------------*/
/*                                                                   */

int draw_menu (win,m,smu)
WINDOW *win;
int    m;
int    smu;

{
int  item;
int  ch;
int  x,y,xx,yy,i;
int  status;

item = 0;
x = menu[m].menu_item[0].x_location;
y = menu[m].menu_item[0].y_location;

do
   {
   wclear (win);
   for (i = 0; i < menu[m].n; ++i)
      {
      xx = menu[m].menu_item[i].x_location;
      yy = menu[m].menu_item[i].y_location;
      if (xx < 0)
         {
         xx = (COLS-strlen(menu[m].menu_item[i].menu_item_text))/2;
         }
      if (yy < 0)
         {
         yy = (LINES-menu[m].n)/2+i;
         }
      if (put_output (win,yy,xx,menu[m].menu_item[i].menu_item_text) != OK)
         {
         error_message ("main_menu - your window is too small to display the menu");
         return (ERR);
         }
      }
   
   if (x < 0)
      {
      x = (COLS-strlen(menu[m].menu_item[item].menu_item_text))/2;
      }
   if (y < 0)
      {
      y = (LINES-menu[m].n)/2+item;
      }
   wmove (win,y,x);
   wrefresh (win);

   ch = get_character (win);
   if ((ch >= PKEY_LOWER_A) && (ch <= PKEY_LOWER_Z))
      {
      ch = (ch-32);
      }
   switch (ch)
      {
      case PKEY_ESCAPE:
      case PKEY_EXITFUNCTION:
         if (m != 0)
            {
            return (OK);
            }
         break;
      case KEY_UP:
         if (item == 0)
            {
            item = menu[m].n-1;
            }
         else
            {
            --item;
            }
         break;
      case KEY_DOWN:
         if (item == (menu[m].n-1))
            {
            item = 0;
            }
         else
            {
            ++item;
            }
         break;
      case KEY_RIGHT:
         if (item == (menu[m].n-1))
            {
            item = 0;
            }
         else
            {
            ++item;
            }
         break;
      case KEY_LEFT:
         if (item == 0)
            {
            item = menu[m].n-1;
            }
         else
            {
            --item;
            }
         break;
      case PKEY_CARRIAGE_RETURN:
         if (smu > -1)
            {
            status = (menu[m].menu_item[item].function) (win,smu);
            }
         else
            {
            status = (menu[m].menu_item[item].function) (win,item);
            }
         if (status == PR_EXIT)
            {
            return (OK);
            }
         else if ((status == PKEY_ESCAPE) && (m != 0))
            {
            return (OK);
            }
         else if (status == ERR)
            {
            wclear (win);
            put_output (win,0,0,error_string);
            get_character (win);
            }
         break;
      default:
         beep ();
         break;
      }
   x = menu[m].menu_item[item].x_location;
   y = menu[m].menu_item[item].y_location;
   }
while (1);

}
