#include <curses.h>
#include <string.h>
#include "curses_utilities.h"

int ERROR_NUMBER  = 0;

#define MAX_MESSAGES         (100)
char ERROR_MESSAGE[MAX_MESSAGES][80];

/*                                                                   */
/*--- Function start_curses -----------------------------------------*/
/*                                                                   */

WINDOW *start_curses ()
{
WINDOW *win;
win = initscr ();
cbreak ();
noecho ();
nonl ();
intrflush (win,FALSE);
keypad (win,TRUE);
nodelay (win,FALSE);
leaveok (win,FALSE);
wrefresh (win);
return (win);
}

/*                                                                   */
/*--- Function end_curses -------------------------------------------*/
/*                                                                   */

int end_curses(WINDOW * win)
{
werase (win);
wrefresh (win);
endwin ();
return(OK);
}

/*                                                                   */
/*--- Function get_character ----------------------------------------*/
/*                                                                   */

int get_character (WINDOW* win)
{
int  ch;

while (1)
   {
   ch = wgetch (win);
   if (ch == ERR)
      {
      continue;
      }
   else
      {
      return (ch);
      }
   }
}

/*                                                                   */
/*--- Function get_response -----------------------------------------*/
/*                                                                   */

int get_response (WINDOW* win, int y1, int x1, int y2, int x2, char* string)
{
int  ch;
int  y;
int  x;
int  i;

y = y1;
x = x1;
i = 0;

if(wmove (win,y,x) != OK)
   {
   return (ERR);
   }

wrefresh (win);

do
   {
   ch = wgetch (win);
   if (ch == ERR)
      {
      continue;
      }
   else
      {
      switch (ch)
         {
	 case PKEY_EXITFUNCTION:
         case PKEY_ESCAPE:
            return (PKEY_ESCAPE);
            break;
         case PKEY_TAB:
            break;
	 case PKEY_DELETE_L:
         case PKEY_DELETE:
            if ((x <= x1) && (y <= y1))
               {
               beep ();
               continue;
               }
            else if (x == x1)
               {
               if (mvwdelch (win,y-1,x2) == OK)
                  {
                  --y;
                  x = x2;
                  }
               else
                  {
                  beep ();
                  continue;
                  }
               }
            else if (mvwdelch (win,y,x-1) == OK)
               {
               --x;
               }
            else
               {
               beep ();
               continue;
               }
            break;
	 case PKEY_BACKSPACE_L:
         case PKEY_BACKSPACE:
            if ((x <= x1) && (y <= y1))
               {
               beep ();
               continue;
               }
            else if (x == x1)
               {
               if (mvwdelch (win,y-1,x2) == OK)
                  {
                  --y;
                  x = x2;
                  }
               else
                  {
                  beep ();
                  continue;
                  }
               }
            else if (mvwdelch (win,y,x-1) == OK)
               {
               --x;
               }
            else
               {
               beep ();
               continue;
               }
            break;
         case KEY_UP:
            if (y <= y1)
               {
/*             y = y2;    */
               for (y = y1; y <= y2; ++y)
                  {
                  for (x = x1; x <= x2; ++x)
                     {
                     string[i] = (char) mvwinch (win,y,x);
                     ++i;
                     }
                  string[i] = '\n';
                  ++i;
                  }
               string[i-1] = '\0';
               wmove (win,0,0);
               wrefresh (win);
               return (KEY_UP);
               }
            else
               {
               --y;
               }
            break;
         case KEY_DOWN:
            if (y >= y2)
               {
/*             y = y1;      */
               for (y = y1; y <= y2; ++y)
                  {
                  for (x = x1; x <= x2; ++x)
                     {
                     string[i] = (char) mvwinch (win,y,x);
                     ++i;
                     }
                  string[i] = '\n';
                  ++i;
                  }
               string[i-1] = '\0';
               wmove (win,0,0);
               wrefresh (win);
               return (KEY_DOWN);
               }
            else
               {
               ++y;
               }
            break;
         case KEY_RIGHT:
            if ((x >= x2) && (y >= y2))
               {
               beep ();
               continue;
               }
            else if (x >= x2)
               {
               ++y;
               x = x1;
               }
            else
               {
               ++x;
               }
            break;
         case KEY_LEFT:
            if ((x <= x1) && (y <= y1))
               {
               beep ();
               continue;
               }
            else if (x <= x1)
               {
               --y;
               x = x2;
               }
            else
               {
               --x;
               }
            break;
         case PKEY_CARRIAGE_RETURN:
            for (y = y1; y <= y2; ++y)
               {
               for (x = x1; x <= x2; ++x)
                  {
                  string[i] = (char) mvwinch (win,y,x);
                  ++i;
                  }
               string[i] = '\n';
               ++i;
               }
            string[i-1] = '\0';
            wmove (win,0,0);
            wrefresh (win);
            return (OK);
            break;
         default:
            if ((ch < PKEY_SPACE) || (ch > PKEY_TILDA))
               {
               beep ();
               continue;
               }
            waddch (win,(chtype) ch);
            if ((x >= x2) && (y >= y2))
               {
               beep ();
               continue;
               }
            else if (x >= x2)
               {
               ++y;
               x = x1;
               }
            else
               {
               ++x;
               }
            break;
         }
      wmove (win,y,x);
      wrefresh (win);
      }
   }
while (1);

}

/*                                                                   */
/*--- Function file_check -------------------------------------------*/
/*                                                                   */

int file_check (char* string)
{
FILE *file_ptr;

file_ptr = NULL;

if ((file_ptr = fopen (string,"r")) == NULL)
   {
   return (ERR);
   }
else
   {
   fclose (file_ptr);
   file_ptr = NULL;
   return (OK);
   }

}

/*                                                                   */
/*--- Function put_output -------------------------------------------*/
/*                                                                   */

int put_output (WINDOW* win, int y, int x, char* string)
{
int x1;
int y1;
int ch;
int i;

if ((x < 0) || (y < 0) || (x >= COLS) || (y >= LINES))
   {
   error_message (
   "put_output - you are tring to place a string outside the window");
   return (ERR);
   }

i = 0;
x1 = x;
y1 = y;

while (string[i] != '\0')
   {
   ch = (int) string[i];
   if (x1 >= COLS)
      {
      error_message (
      "put_output - the string will not fit inside the window");
      return (ERR);
      }
   else if (string[i] == '\n')
      {
      ++y1;
      x1 = x;
      ++i;
      continue;
/*    return (OK);    */
      }
   else if ((ch < PKEY_SPACE) || (ch > PKEY_TILDA))
      {
      ch = PKEY_SPACE;
      }
   if (mvwaddch (win,y1,x1,(chtype) ch) != OK)
      {
      error_message (
      "put_output - mvaddch failed to write to the window");
      return (ERR);
      }
   ++x1;
   ++i;
   }

return (OK);

}

/*                                                                   */
/*--- Function error_message ----------------------------------------*/
/*                                                                   */

void error_message (char* string)
{
if (ERROR_NUMBER > MAX_MESSAGES)
   {
   return;
   }

strcpy (ERROR_MESSAGE[ERROR_NUMBER],string);
++ERROR_NUMBER;

return;
}

/*                                                                         */
/*--- Function warning_message --------------------------------------------*/
/*                                                                         */

int warning_message (WINDOW* win, int y, int x, char* string)
{
wclear (win);

if (put_output (win,y,x,string) != OK)
   {
   error_message (
   "warning_message - error on return from put_output");
   return (ERR);
   }

if (put_output (win,y+2,(strlen(string)-24)/2+x,"type any key to continue") != OK)
   {
   error_message (
   "warning_message - error on return from put_output");
   return (ERR);
   }

beep ();
wrefresh (win);

get_character (win);

return (OK);
}

/*                                                                   */
/*--- Function get_char_asynch --------------------------------------*/
/*                                                                   */

int get_char_asynch (WINDOW* win)
{
return wgetch (win);
}

