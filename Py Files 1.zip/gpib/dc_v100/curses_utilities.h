#include <ncurses.h>
#include <string.h>

#define PKEY_BACKSPACE         (8)
#define PKEY_BACKSPACE_L      (263)
#define PKEY_TAB               (9)
#define PKEY_CARRIAGE_RETURN  (13)
#define PKEY_ESCAPE           (27)
#define PKEY_SPACE            (32)
#define PKEY_0                (48)
#define PKEY_1                (49)
#define PKEY_2                (50)
#define PKEY_3                (51)
#define PKEY_4                (52)
#define PKEY_5                (53)
#define PKEY_6                (54)
#define PKEY_7                (55)
#define PKEY_8                (56)
#define PKEY_9                (57)
#define PKEY_CAPITAL_A        (65)
#define PKEY_CAPITAL_B        (66)
#define PKEY_CAPITAL_C        (67)
#define PKEY_CAPITAL_D        (68)
#define PKEY_CAPITAL_E        (69)
#define PKEY_CAPITAL_F        (70)
#define PKEY_CAPITAL_G        (71)
#define PKEY_CAPITAL_H        (72)
#define PKEY_CAPITAL_I        (73)
#define PKEY_CAPITAL_J        (74)
#define PKEY_CAPITAL_K        (75)
#define PKEY_CAPITAL_L        (76)
#define PKEY_CAPITAL_M        (77)
#define PKEY_CAPITAL_N        (78)
#define PKEY_CAPITAL_O        (79)
#define PKEY_CAPITAL_P        (80)
#define PKEY_CAPITAL_Q        (81)
#define PKEY_CAPITAL_R        (82)
#define PKEY_CAPITAL_S        (83)
#define PKEY_CAPITAL_T        (84)
#define PKEY_CAPITAL_U        (85)
#define PKEY_CAPITAL_V        (86)
#define PKEY_CAPITAL_W        (87)
#define PKEY_CAPITAL_X        (88)
#define PKEY_CAPITAL_Y        (89)
#define PKEY_CAPITAL_Z        (90)
#define PKEY_LOWER_A          (97)
#define PKEY_LOWER_B          (98)
#define PKEY_LOWER_C          (99)
#define PKEY_LOWER_D         (100)
#define PKEY_LOWER_E         (101)
#define PKEY_LOWER_F         (102)
#define PKEY_LOWER_G         (103)
#define PKEY_LOWER_H         (104)
#define PKEY_LOWER_I         (105)
#define PKEY_LOWER_J         (106)
#define PKEY_LOWER_K         (107)
#define PKEY_LOWER_L         (108)
#define PKEY_LOWER_M         (109)
#define PKEY_LOWER_N         (110)
#define PKEY_LOWER_O         (111)
#define PKEY_LOWER_P         (112)
#define PKEY_LOWER_Q         (113)
#define PKEY_LOWER_R         (114)
#define PKEY_LOWER_S         (115)
#define PKEY_LOWER_T         (116)
#define PKEY_LOWER_U         (117)
#define PKEY_LOWER_V         (118)
#define PKEY_LOWER_W         (119)
#define PKEY_LOWER_X         (120)
#define PKEY_LOWER_Y         (121)
#define PKEY_LOWER_Z         (122)
#define PKEY_TILDA           (126)
#define PKEY_DELETE          (127)
#define PKEY_DELETE_L        (330)

// F1 Key
#define PKEY_EXITFUNCTION    (KEY_HOME)

extern WINDOW *start_curses ();
extern int end_curses ();
extern int get_character ();
extern int get_response ();
extern int put_output ();
extern int file_check ();
extern int warning_message ();
extern long int display_file ();
extern long int go_back ();
extern long int go_forward ();
extern void error_message ();
extern int get_char_asynch ();

extern int ERROR_NUMBER;
extern char ERROR_MESSAGE[][80];
