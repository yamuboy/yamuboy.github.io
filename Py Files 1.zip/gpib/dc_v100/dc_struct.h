#ifndef _dc_v100_struct_
#define _dc_v100_struct_

#define MAX_LOCATIONS   (1000)

#define STATION_1      ("n349w40105L1")
#define STATION_2      ("osprey")
#define STATION_3      ("macbeth")

typedef struct
{
char   file_name[81];
char   mask_name[81];
char   wafer_number[81];
char   process_name[81];
char   device_name[81];
double temperature;
char   date_and_time[81];
char   comments[1025];
} HEADER_INFO;

typedef struct
{
char     map_filename[81];
int      on_or_off;
int      x_index;
int      y_index;
int      orientation;
int      site[MAX_LOCATIONS][2];
int      num_sites;
} MULTISITE_T;

typedef struct
{
int type;
char *device;
int addr;
int source;
int filter;
int integration;
int sensing;
double compliance;
double dc_value;
int delay;
} SMU_T;

typedef struct sweep_t
{
int type;
int seg_num;
double start;
double stop;
double step;
struct sweep_t *prev;
struct sweep_t *next;
}SWEEP_SEG;

typedef struct error_log_t
{
char site[10];
char error[1024];
int  lines;
struct error_log_t *next;
} ERROR_LOG;

typedef struct
{
char menu_item_text[51];
int  x_location;
int  y_location;
int  (*function) ();
} MENU_ITEM;

typedef struct
{
MENU_ITEM   *menu_item;
int         n;
} MENU;

typedef union
{
char   *string_value;
int    *int_value;
double *double_value;
} VALUE;

typedef struct
{
char *prompt_text;
int  x_text_location;
int  y_text_location;
int  x1_get_location;
int  y1_get_location;
int  x2_get_location;
int  y2_get_location;
int  return_type;
char *format;
} PROMPT_ITEM;

typedef struct 
{
PROMPT_ITEM   *prompt_item;
int           n;
} PROMPT;

#endif
