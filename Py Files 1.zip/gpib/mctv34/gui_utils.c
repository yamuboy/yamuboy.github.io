#include "gui.h"
#include <Xm/MessageB.h>
#include <Xm/FileSB.h>
#include <sys/stat.h>
#include <math.h>

typedef struct
{
   char *fname;
   Widget textbox, dlg;
} SAVE_TEXT;

/****************************************************************************/
/****************************************************************************/

extern MAIN_DATA mainDataDefaults(void)
{
   MAIN_DATA d;

   // main items
   strcpy (d.config_fname, "mct.cfg");
   strcpy (d.coeff_fname, "coeffs.dat");
   d.filename[0] = 0;
   d.cwd[0] = 0;
   d.test_type = 0;
   d.device_type = DUT_FET;

   // header info
   d.header_info.wafer[0] = 0;
   d.header_info.process[0] = 0;
   d.header_info.device[0] = 0;
   d.header_info.calkit[0] = 0;
   d.header_info.temperature = 27.0;
   d.header_info.comments[0] = 0;

   // multisite
   d.multisite.do_multisite = 0;
   d.multisite.mapfile[0] = 0;
   d.multisite.xIndex = 12000;
   d.multisite.yIndex = 12000;
   d.multisite.orientation = 0;
   d.multisite.stop_on_error = 1;

   // instrument info
   d.inst_info.gpib_board = 0;
   strcpy (d.inst_info.bias1_dl, "bias_k23x.so");
   strcpy (d.inst_info.bias2_dl, "bias_k23x.so");
   strcpy (d.inst_info.vna_dl, "vna_hp836x.so");
   strcpy (d.inst_info.nfm_dl, "nfm_hp8970.so");
   strcpy (d.inst_info.ap_dl, "ap_cascade.so");
   strcpy (d.inst_info.tc_dl, "tc_tt3000.so");
   d.inst_info.bias1_addr = 21;
   d.inst_info.bias2_addr = 23;
   d.inst_info.vna_addr = 16;
   d.inst_info.nfm_addr = 8;
   d.inst_info.ap_addr = 28;
   d.inst_info.tc_addr = 9;
   d.inst_info.bias1_chan = 0;
   d.inst_info.bias2_chan = 0;
   d.inst_info.vna_chan = 0;
   d.inst_info.nfm_chan = 0;
   d.inst_info.ap_chan = 0;
   d.inst_info.tc_chan = 0;
   d.inst_info.bias1_tmo = 13;
   d.inst_info.bias2_tmo = 13;
   d.inst_info.vna_tmo = 13;
   d.inst_info.nfm_tmo = 13;
   d.inst_info.ap_tmo = 13;
   d.inst_info.tc_tmo = 13;

   // fet device
   d.fet_device.ngf = 6;
   d.fet_device.ugw = 50.0;
   d.fet_device.gate_length = 0.5;
   d.fet_device.sd_spacing[0] = 0;
   d.fet_device.gg_spacing[0] = 0;
   d.fet_device.do_fwd_iv = 1;
   d.fet_device.do_ss_breakdown = 1;
   d.fet_device.do_ds_breakdown = 0;
   d.fet_device.do_dciv = 1;
   d.fet_device.do_transfer = 0;
   d.fet_device.do_coldfet = 1;
   d.fet_device.do_sparams = 1;
   d.fet_device.max_vds = 6.0;
   d.fet_device.max_power = 1.25;
   d.fet_device.min_vgs = -3.0;
   d.fet_device.max_vgs = 1.6;
   d.fet_device.max_igs = 1.0;
   d.fet_device.max_ids = 800.0;
   d.fet_device.ibr_low = 0.1;
   d.fet_device.ibr_high = 1.0;
   d.fet_device.vbr_compliance = 30.0;
   d.fet_device.vpo_percent = 2.5;
   d.fet_device.vpo_current = 1.0;
   d.fet_device.vds_for_idss = 3.0;
   d.fet_device.vds_for_imax = 1.5;
   d.fet_device.igs_for_imax = 1.0;
   d.fet_device.fwd_iv_igs = 1.0;
   d.fet_device.coldfet_igs = 10.0;
   d.fet_device.sparam_vds_step = 1.0;
   d.fet_device.coldfet_npts = 5;
   d.fet_device.dc_delay = 25;

   // bipolar device
   d.bjt_device.em_length = 30.0;
   d.bjt_device.em_width = 3.0;
   d.bjt_device.num_em_fingers = 1;
   d.bjt_device.em_spacing[0] = 0;
   d.bjt_device.max_ice = 35.0;
   d.bjt_device.max_ibe = 10.0;
   d.bjt_device.max_vce = 6.0;
   d.bjt_device.max_vbe = 1.8;
   d.bjt_device.min_vrev = -4.0;
   d.bjt_device.max_power = 150.0;
   d.bjt_device.do_beo_breakdown = 1;
   d.bjt_device.do_cbo_breakdown = 1;
   d.bjt_device.do_ceo_breakdown = 0;
   d.bjt_device.do_extended_screen = 0;
   d.bjt_device.do_fwd_gum = 1;
   d.bjt_device.do_rev_gum = 1;
   d.bjt_device.do_flyback = 1;
   d.bjt_device.do_dciv = 1;
   d.bjt_device.do_hotsp = 1;
   d.bjt_device.do_cbcsp = 1;
   d.bjt_device.do_cbesp = 1;
   d.bjt_device.do_sparams = 1;
   d.bjt_device.ibr = 0.1;
   d.bjt_device.vbr_compliance = 30.0;
   d.bjt_device.vce_for_beta = 3.0;
   d.bjt_device.approx_beta = 80.0;
   d.bjt_device.ice_for_beta1 = 30.0;
   d.bjt_device.ice_for_beta2 = 10.0;
   d.bjt_device.ice_for_beta3 = 1.0;
   d.bjt_device.dciv_npts = 11;
   d.bjt_device.hotsp_npts = 3;
   d.bjt_device.sparam_npts = 11;
   d.bjt_device.dc_delay = 50;
   d.bjt_device.sparam_vce_step = 1.0;
   d.bjt_device.capsp_voffs = 1.0;
   d.bjt_device.gummel_vstart = 0.8;
   d.bjt_device.gummel_vstop = 1.3;
   d.bjt_device.flyback_istart = 1.0;
   d.bjt_device.flyback_istop = 8.0;

   // mosfet device


   // tcontrol data
   d.tcontrol.read_tset = 0;
   d.tcontrol.set_on_finish = 0;
   d.tcontrol.off_on_finish = 0;
   d.tcontrol.tset = 85.0;
   d.tcontrol.soak_min = 30;

   // bias data
   d.bias_data = NULL;

   // generic data
   d.generic_data = NULL;

   // set bias data
   d.set_bias_data.use_file = 1;
   d.set_bias_data.bias1_mode = BIAS_VOLTAGE;
   d.set_bias_data.bias2_mode = BIAS_VOLTAGE;
   d.set_bias_data.file_mode = BIAS_FILE_VINVOUT;
   d.set_bias_data.v1_start = 0.0;
   d.set_bias_data.v1_stop = 1.0;
   d.set_bias_data.v1_step = 0.1;
   d.set_bias_data.i1_start = 0.0;
   d.set_bias_data.i1_stop = 1.0;
   d.set_bias_data.i1_step = 0.1;
   d.set_bias_data.v2_start = 0.0;
   d.set_bias_data.v2_stop = 1.0;
   d.set_bias_data.v2_step = 0.1;
   d.set_bias_data.i2_start = 0.0;
   d.set_bias_data.i2_stop = 1.0;
   d.set_bias_data.i2_step = 0.1;
   d.set_bias_data.vcompl1 = 10.0;
   d.set_bias_data.vcompl2 = 10.0;
   d.set_bias_data.icompl1 = 100.0;
   d.set_bias_data.icompl2 = 100.0;
   d.set_bias_data.max_power = 1.0e6;
   strcpy( d.set_bias_data.fname, "bias.dat" );
   d.set_bias_data.delay = 50;
   d.set_bias_data.ofs_delay = 50;
   d.set_bias_data.b2_first = 0;
   d.set_bias_data.plimit1 = 0.;
   d.set_bias_data.plimit2 = 0.;

   return d;
}

/*******************************************************************************/
/*******************************************************************************/

static void cb_update_browse_entry (Widget w, XtPointer client_data, XtPointer call_data)
{
   BROWSE_INFO *browse = (BROWSE_INFO *) client_data;
   XmFileSelectionBoxCallbackStruct *cbs = (XmFileSelectionBoxCallbackStruct *) call_data;
   char *filename;

   if (XtIsSubclass (w, xmTextWidgetClass))
      filename = XmTextGetString (w);
   else
      XmStringGetLtoR (cbs->value, XmFONTLIST_DEFAULT_TAG, &filename);

   if (!filename)
   {
      XmTextSetString (browse->entry, "");
      XmTextSetCursorPosition (browse->entry, 0);
   }
   else
   {
      XmTextSetString (browse->entry, filename);
      XmTextSetCursorPosition (browse->entry, strlen (filename));
      XtFree (filename);
   }
}

/*******************************************************************************/
/*******************************************************************************/

extern void cb_browse_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
   BROWSE_INFO *browse = (BROWSE_INFO *) client_data;
   Widget dialog;
   Arg args[20];
   int n = 0;
   XmString text, path = NULL, pattern = NULL;

   if (browse->path)
   {
      path = XmStringCreateLocalized (browse->path);
      XtSetArg (args[n], XmNdirectory, path); ++n;
   }

   if (browse->pattern)
   {
      pattern = XmStringCreateLocalized (browse->pattern);
      XtSetArg (args[n], XmNpattern, pattern); ++n;
   }

   if (browse->dir_flag)
   {
      XtSetArg (args[n], XmNfileTypeMask, XmFILE_DIRECTORY); ++n;
      text = XmStringCreateLocalized ("Select Directory");
   }
   else
   {
      XtSetArg (args[n], XmNfileTypeMask, XmFILE_REGULAR); ++n;
      text = XmStringCreateLocalized ("Select File");
   }

   XtSetArg (args[n], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL); ++n;
   XtSetArg (args[n], XmNnoResize, False); ++n;
   XtSetArg (args[n], XmNdialogTitle, text); ++n;
   XtSetArg (args[n], XmNpathMode, XmPATH_MODE_RELATIVE); ++n;
   XtSetArg (args[n], XmNfileFilterStyle, XmFILTER_HIDDEN_FILES); ++n;
   dialog = XmCreateFileSelectionDialog (browse->parent, "DialogBrowse", args, n);
   XmStringFree (text);

   if (path)
      XmStringFree (path);

   if (pattern)
      XmStringFree (pattern);

   XtAddCallback (dialog, XmNokCallback, cb_update_browse_entry, (XtPointer) browse);
   XtAddCallback (dialog, XmNokCallback, cb_destroy_widget, XtParent (dialog));
   if (browse->cb)
      XtAddCallback (dialog, XmNokCallback, browse->cb, browse->cb_data);
   XtAddCallback (dialog, XmNcancelCallback, cb_destroy_widget, XtParent (dialog));

   XtUnmanageChild (XmFileSelectionBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

   XtManageChild (dialog);

   XtVaSetValues (XtParent (dialog), XmNdeleteResponse, XmDESTROY, NULL);
   XtPopup (XtParent (dialog), XtGrabNone);
}

/*******************************************************************************/
/*******************************************************************************/

static void cb_save_text_file (Widget w, XtPointer client_data, XtPointer call_data)
{
   SAVE_TEXT *s = (SAVE_TEXT *) client_data;
   FILE *file;
   char *text;

   text = XmTextGetString (s->textbox);
   if (!text)
   {
      fprintf (stderr, "cb_save_text_file(): unable to read text from widget.\n");
      return;
   }

   file = fopen (s->fname, "w+");
   if (!file)
   {
      fprintf (stderr, "%s: unable to write file.\n", s->fname);
      XtFree (text);
      return;
   }

   fwrite (text, sizeof(char), strlen(text), file);
   if (text[strlen(text)-1] != '\n')
      fputc ('\n', file);

   fclose (file);
   XtFree (text);
}

/*******************************************************************************/
/*******************************************************************************/

static void cb_destroy_save_text_file (Widget w, XtPointer client_data, XtPointer call_data)
{
   SAVE_TEXT *s = (SAVE_TEXT *) client_data;

   XtDestroyWidget (s->dlg);
   XtFree ((void *) s->fname);
   XtFree ((void *) s);
}

/*******************************************************************************/
/*******************************************************************************/

extern void cb_edit_text_file_dialog (Widget w, XtPointer client_data, XtPointer call_data)
{
   char *name = "DialogEditFile";
   EDIT_TEXT_FILE *tf = (EDIT_TEXT_FILE *) client_data;
   char *fname, *fcontents = NULL;
   FILE *file;
   char string[256];
   struct stat st;
   SAVE_TEXT *save_text;
   Widget pane, main_col, textbox;
   int n = 0;
   Arg args[10];
   MCT_DIALOG dialog;
   ACTION_AREA_ITEMS action[3];

   fname = XmTextGetString (tf->entry);
   if (!fname)
   {
      db_error_message ("Failed to retreive file name.", tf->parent);
      return;
   }
   else if (! *fname)
   {
      db_error_message ("File name field is blank.", tf->parent);
      XtFree (fname);
      return;
   }

   // read in the contents of the file
   file = fopen (fname, "r");
   if (file)
   {
      if (stat (fname, &st))
      {
         sprintf (string, "%s: unable to determine file properties.", fname);
         db_error_message (string, tf->parent);
         XtFree (fname);
         fclose (file);
         return;
      }

      fcontents = (char *) XtMalloc (sizeof(char) * (st.st_size+1));
      fread (fcontents, sizeof(char), st.st_size, file);
      fcontents[st.st_size] = 0;
      fclose (file);
   }

   // create the dialog box
   pane = create_dialog_shell (tf->parent, &dialog, name, fcontents ? fname : "New File");
   main_col = XtVaCreateWidget ("dialog_main_col", xmRowColumnWidgetClass, pane,
      NULL);

   // turn off modality of the dialog shell
   XtVaSetValues (dialog.bulletin, XmNdialogStyle, XmDIALOG_MODELESS, NULL);

   if (!fcontents)
   {
      sprintf (string, "Creating new file named: %s", fname);
      create_label_gadget (main_col, string);
   }

   XtSetArg (args[n], XmNeditMode, XmMULTI_LINE_EDIT); ++n;
   XtSetArg (args[n], XmNrows, 20); ++n;
   XtSetArg (args[n], XmNcolumns, 70); ++n;
   textbox = XmCreateScrolledText (main_col, "edit_text", args, n);
   XtManageChild (textbox);
   XtManageChild (XtParent (textbox));

   if (fcontents)
   {
      XmTextSetString (textbox, fcontents);
      XtFree (fcontents);
   }

   save_text = (SAVE_TEXT *) XtMalloc (sizeof (SAVE_TEXT));
   save_text->fname = fname;
   save_text->textbox = textbox;
   save_text->dlg = dialog.shell;

   // manage the higher-level widgets
   XtManageChild (main_col);

   // create the action area
   action[0].txt = "Save";
   action[0].cb = cb_save_text_file;
   action[0].data = save_text;
   action[1].txt = "Save & Close";
   action[1].cb = cb_save_text_file;
   action[1].data = save_text;
   action[2].txt = "Close";
   action[2].cb = cb_destroy_save_text_file;
   action[2].data = save_text;
   create_dialog_action_area (pane, action, 3, 10, 20);

   // add an additional callback to destroy the dialog when the OK button is pressed
   XtAddCallback (action[1].w, XmNactivateCallback, cb_destroy_save_text_file, save_text);

   // pop up the dialog
   popup_dialog_shell (&dialog);
}

/*******************************************************************************/
/*******************************************************************************/

extern void cb_destroy_widget (Widget w, XtPointer client_data, XtPointer call_data)
{
   XtDestroyWidget ((Widget) client_data);
}

/*******************************************************************************/
/*******************************************************************************/

extern void db_error_message (char *msg, Widget parent)
{
   XmString text, title;
   Widget dialog;
   Arg args[10];
   int n = 0;

   if (!msg || !msg[0])
      return;

   XtSetArg (args[n], XmNautoUnmanage, False); ++n;
   XtSetArg (args[n], XmNdeleteResponse, XmDESTROY); ++n;
   dialog = XmCreateErrorDialog (parent, "DialogError", args, n);

   title = XmStringCreateLocalized ("Error");
   text = create_Xm_string (msg);
   XtVaSetValues (dialog,
      XmNdialogTitle, title,
      XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL,
      XmNmessageString, text,
      NULL);
   XmStringFree (title);
   XmStringFree (text);

   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

   XtAddCallback (dialog, XmNokCallback, cb_destroy_widget, XtParent(dialog));

   XtManageChild (dialog);

   XtPopup (XtParent(dialog), XtGrabNone);
}

/*******************************************************************************/
/*******************************************************************************/

extern void db_warning_message (char *msg, Widget parent)
{
   XmString text, title;
   Widget dialog;
   Arg args[10];
   int n = 0;

   if (!msg || !msg[0])
      return;

   XtSetArg (args[n], XmNautoUnmanage, False); ++n;
   XtSetArg (args[n], XmNdeleteResponse, XmDESTROY); ++n;
   dialog = XmCreateWarningDialog (parent, "DialogWarning", args, n);

   title = XmStringCreateLocalized ("Warning");
   text = create_Xm_string (msg);
   XtVaSetValues (dialog,
      XmNdialogTitle, title,
      XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL,
      XmNmessageString, text,
      NULL);
   XmStringFree (title);
   XmStringFree (text);

   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

   XtAddCallback (dialog, XmNokCallback, cb_destroy_widget, XtParent(dialog));

   XtManageChild (dialog);

   XtPopup (XtParent(dialog), XtGrabNone);
}

/*******************************************************************************/
/*******************************************************************************/

extern void db_info_message (char *msg, Widget parent)
{
   XmString text, title;
   Widget dialog;
   Arg args[10];
   int n = 0;

   if( !msg || !msg[0] )
      return;

   XtSetArg (args[n], XmNautoUnmanage, False); ++n;
   XtSetArg (args[n], XmNdeleteResponse, XmDESTROY); ++n;
   dialog = XmCreateInformationDialog (parent, "DialogWarning", args, n);

   title = XmStringCreateLocalized ("Information");
   text = create_Xm_string (msg);
   XtVaSetValues (dialog,
      XmNdialogTitle, title,
      XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL,
      XmNmessageString, text,
      NULL);
   XmStringFree (title);
   XmStringFree (text);

   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

   XtAddCallback (dialog, XmNokCallback, cb_destroy_widget, XtParent(dialog));

   XtManageChild (dialog);

   XtPopup (XtParent(dialog), XtGrabNone);
}

/*******************************************************************************/
/*******************************************************************************/

extern Widget get_top_shell (Widget w)
{
   while (w && !XtIsWMShell (w))
      w = XtParent (w);

   return w;
}

/****************************************************************************/
/****************************************************************************/

extern XmString create_Xm_string (char *string)
{
   char *str = strdup (string);
   char *ptr;
   unsigned i;
   XmString output, tmp;
   XmString sep = XmStringSeparatorCreate ();

   output = XmStringCreateLocalized ("");
   for (i = 0, ptr = str; i < strlen (str); ++i)
   {
      if (str[i] == '\n')
      {
         str[i] = 0;
         tmp = XmStringCreateLocalized (ptr);
         output = XmStringConcat (output, tmp);
         output = XmStringConcat (output, sep);
         XmStringFree (tmp);
         ptr = &str[i+1];
      }
   }

   if (*ptr)
   {
      tmp = XmStringCreateLocalized (ptr);
      output = XmStringConcat (output, tmp);
      XmStringFree (tmp);
   }

   XmStringFree (sep);
   free ((void *) str);

   return output;
}

/****************************************************************************/
/****************************************************************************/

extern Widget create_text_entry_row (Widget parent, char *label, int n_cols, int max_len, char *val)
{
   Widget row, entry;
   XmString text;

   if (label)
   {
      row = XtVaCreateWidget ("row", xmRowColumnWidgetClass, parent,
         XmNorientation, XmHORIZONTAL,
         NULL);

      text = XmStringCreateLocalized (label);
      XtVaCreateManagedWidget ("label", xmLabelGadgetClass, row,
         XmNlabelString, text,
         NULL);
      XmStringFree (text);

      entry = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, row,
         XmNcolumns, n_cols,
         XmNmaxLength, max_len,
         XmNvalue, val ? val : "",
         XmNcursorPosition, val ? strlen(val) : 0,
         NULL);

      XtManageChild (row);
   }

   else
   {
      entry = XtVaCreateManagedWidget ("entry", xmTextWidgetClass, parent,
         XmNcolumns, n_cols,
         XmNmaxLength, max_len,
         XmNvalue, val ? val : "",
         XmNcursorPosition, val ? strlen(val) : 0,
         NULL);
   }

   return entry;
}

/****************************************************************************/
/****************************************************************************/

extern Widget create_label_gadget (Widget parent, char *txt)
{
   XmString text;
   Widget label;

   text = XmStringCreateLocalized (txt);
   label = XtVaCreateManagedWidget ("label", xmLabelGadgetClass, parent,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);

   return label;
}

/****************************************************************************/
/****************************************************************************/

extern Widget create_push_button (Widget parent, char *label)
{
   XmString text;
   Widget button;
   text = XmStringCreateLocalized (label);
   button = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, parent,
      XmNlabelString, text,
      NULL);
   XmStringFree (text);
   return button;
}

/****************************************************************************/
/****************************************************************************/

extern Widget create_toggle (Widget parent, char *label, unsigned state)
{
   XmString text;
   Widget tog;
   text = XmStringCreateLocalized (label);
   tog = XtVaCreateManagedWidget ("toggle", xmToggleButtonWidgetClass, parent,
      XmNlabelString, text,
      XmNset, state ? XmSET : XmUNSET,
      NULL);
   XmStringFree (text);
   return tog;
}


/****************************************************************************/
/****************************************************************************/

extern Widget create_dialog_shell (Widget parent, MCT_DIALOG *d, char *name, char *title)
{

   d->shell = XtVaCreatePopupShell (name, xmDialogShellWidgetClass, parent,
      XmNdeleteResponse, XmDESTROY,
      XmNtitle, title,
      NULL);

   d->bulletin = XtVaCreateWidget ("dialog_bulletin", xmBulletinBoardWidgetClass, d->shell,
      XmNnoResize, True,
      XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL,
      NULL);

   d->pane = XtVaCreateWidget ("dialog_pane", xmPanedWindowWidgetClass, d->bulletin,
      XmNsashWidth, 1,
      XmNsashHeight, 1,
      NULL);

   return d->pane;
}

/****************************************************************************/
/****************************************************************************/

extern void popup_dialog_shell (MCT_DIALOG *d)
{
   XtManageChild (d->pane);
   XtManageChild (d->bulletin);

   XtPopup (d->shell, XtGrabNone);
}

/****************************************************************************/
/****************************************************************************/

extern void create_dialog_action_area (Widget parent, ACTION_AREA_ITEMS *action, unsigned n_items, unsigned tightness, unsigned h_offset)
{
   Widget form;
   XmString text;
   int height, margin;
   unsigned i;

   form = XtVaCreateWidget ("action_area", xmFormWidgetClass, parent,
      XmNfractionBase, n_items*tightness - 1,
      XmNleftOffset, h_offset,
      XmNrightOffset, h_offset,
      NULL);

   for (i = 0; i < n_items; ++i)
   {
      text = XmStringCreateLocalized (action[i].txt);
      action[i].w = XtVaCreateManagedWidget ("button", xmPushButtonWidgetClass, form,
         XmNlabelString, text,
         XmNtopAttachment, XmATTACH_FORM,
         XmNbottomAttachment, XmATTACH_FORM,
         XmNleftAttachment, i ? XmATTACH_POSITION : XmATTACH_FORM,
         XmNleftPosition, tightness*i,
         XmNrightAttachment, (i == n_items-1) ? XmATTACH_FORM : XmATTACH_POSITION,
         XmNrightPosition, tightness*i + tightness-1,
         XmNshowAsDefault, i ? False : True,
         XmNdefaultButtonShadowThickness, 1,
         NULL);
      XmStringFree (text);

      if (action[i].cb)
         XtAddCallback (action[i].w, XmNactivateCallback, action[i].cb, action[i].data);
   }

   XtVaGetValues (action[0].w, XmNheight, &height, NULL);
   XtVaGetValues (form, XmNmarginHeight, &margin, NULL);
   height += 2*margin;

   XtVaSetValues (form,
      XmNdefaultButton, action[0].w,
      XmNpaneMaximum, height,
      XmNpaneMinimum, height,
      NULL);

   XtManageChild (form);
}

/****************************************************************************/
/****************************************************************************/

extern void get_value_from_textbox (Widget w, int type, void *ptr)
{
   char *str;

   if (!XmIsText(w))
      return;

   str = XmTextGetString (w);
   if (!str)
      return;

   switch (type)
   {
   case TYPE_STRING:
      strcpy ((char *)ptr, str);
      break;

   case TYPE_REAL:
      *((double *)ptr) = atof (str);
      break;

   case TYPE_INT:
      *((int *)ptr) = atoi (str);
      break;

   case TYPE_UNSIGNED:
      *((unsigned *)ptr) = (unsigned) atoi (str);
      break;

   default:
      break;
   }

   XtFree (str);
}

/****************************************************************************/
/****************************************************************************/

extern unsigned get_toggle_state (Widget w)
{
   unsigned char is_set;

   if (!XmIsToggleButton(w))
      return -1;

   XtVaGetValues (w, XmNset, &is_set, NULL);
   if (is_set == (unsigned char) XmSET)
      return 1;

   return 0;
}

/****************************************************************************/
/****************************************************************************/

static unsigned get_exp_digits (double x)
{
   unsigned n = 0;
   double modval = 1.0;

   x = fabs (x);

   if (x < 1.0e-15)
      return n;

   while ((x < 1.0) || (x >= 10.0))
   {
      if (x < 1.0)
         x *= 10.0;
      else
         x *= 0.1;
   }

   x = fmod (x, modval);
   while ((x > 1.0e-10) && (fabs(x-modval) > 1.0e-10) && (n <= 10))
   {
      modval *= 0.1;
      x = fmod (x, modval);
      ++n;
   }

   return n;
}

/******************************************************************************/
/******************************************************************************/

static unsigned get_decimal_digits (double x)
{
   unsigned n = 0;
   double modval = 1.0;

   x = fabs (x);

   if (x < 1.0e-15)
      return n;

   x = fmod (x, modval);
   while ((x > 1.0e-10) && (fabs(x-modval) > 1.0e-10) && (n <= 10))
   {
      modval *= 0.1;
      x = fmod (x, modval);
      ++n;
   }

   return n;
}

/****************************************************************************/
/****************************************************************************/

extern char *get_str_from_dbl (double x)
{
   static char ret_str[50];
   unsigned n;
   char fmt[20];

   if (fabs (x) < 1.0e-15)
      return "0";
   else if ((fabs (x) < 1.0e-2) || (fabs (x) >= 1.0e5))
   {
      n = get_exp_digits (x);
      if (n > 6)
         n = 6;
      sprintf (fmt, "%%.%ue", n);
   }
   else
   {
      n = get_decimal_digits (x);
      if (n > 6)
         n = 6;
      sprintf (fmt, "%%.%uf", n);
   }

   sprintf (ret_str, fmt, x);
   return ret_str;
}

/****************************************************************************/
/****************************************************************************/


