#include "gpib.h"

#define FET_FAIL_VMAX  (1)
#define FET_FAIL_IMAX  (1<<1)
#define FET_FAIL_VPO1  (1<<3)
#define FET_FAIL_VPO2  (1<<4)
#define FET_FAIL_VPOMAMM  (1<<5)

static void modified_fet_params (FET_DEVICE_PARAMETERS *fet, FILE *file);
static int fet_dc_parameters (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, char *error);
static int fet_dc_iv_curves (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error);
static int fet_fwd_iv_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error);
static int fet_ds_vbr_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error);
static int fet_ss_vbr_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error);
static int fet_dc_transfer_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error);
static int cold_fet_s_parameters (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, gpib_instr_t vna, FILE *file, char *error);
static int fet_s_parameters_over_bias (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, gpib_instr_t vna, FILE *file, char *error);
static int fet_noise_figure_sweep (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, gpib_instr_t nfm, FILE *file, char *error);
static int check_for_dead_fet (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, char *error);

/******************************************************************************************/
/******************************************************************************************/
// this is the only exported function

extern int measure_fet_device (MAIN_DATA *d, INSTRUMENTS *inst, char *fname, char *error)
{
   FILE *file;
   FET_DEVICE_PARAMETERS *fet = &d->fet_device;
   HEADER_INFO *head = &d->header_info;
   unsigned i;
   int err;

   // check for a valid test type
   if ((d->test_type != DEV_DC_SCREEN) && (d->test_type != DEV_DC) && (d->test_type != DEV_DC_AND_S) && (d->test_type != DEV_NOISE))
   {
      sprintf (error, "measure_fet_device(): invalid test type.\n");
      return 1;
   }

   // calculate and check periphery
   fet->periphery = fet->ugw * fet->ngf;
   if (fet->periphery < 1.0)
   {
      sprintf (error, "measure_fet_device(): calculated periphery is less than 1 micron.\n");
      return 1;
   }

   // check for an existing file of the same name
   if( d->test_type != DEV_DC_SCREEN )
      create_backup_file( fname );

   // open a file
   file = fopen (fname, "w+");
   if (!file)
   {
      sprintf (error, "measure_fet_device(): unable to open file for writing.");
      return 1;
   }

   // write the header
   fprintf (file, "!FILE NAME: %s\n", fname );
   fprintf (file, "!WAFER NUMBER: %s\n", head->wafer);
   fprintf (file, "!PROCESS NAME: %s\n", head->process);
   fprintf (file, "!DEVICE NAME: %s\n", head->device);
   fprintf (file, "!GATE PERIPHERY (um): %.1f\n", fet->periphery);
   fprintf (file, "!GATE LENGTH (um): %.3f\n", fet->gate_length);
   fprintf (file, "!UNIT GATE WIDTH (um): %.1f\n", fet->ugw);
   fprintf (file, "!NUMBER OF GATE FINGERS: %u\n", fet->ngf);
   fprintf (file, "!GATE TO GATE SPACING (um): %s\n", fet->gg_spacing);
   fprintf (file, "!SOURCE-DRAIN SPACING (um): %s\n", fet->sd_spacing);
   fprintf (file, "!CALKIT: %s\n", head->calkit);
   fprintf (file, "!TEMPERATURE (C): %.1f\n", head->temperature);
   fprintf (file, "!DATE AND TIME: %s\n", get_the_time ());
   fprintf (file, "!COMMENTS:\n");
   if (head->comments[0])
   {
      fputc ('!', file);
      for (i = 0; head->comments[i]; ++i)
      {
         fputc (head->comments[i], file);
         if (head->comments[i] == '\n')
            fputc ('!', file);
      }
      fputc ('\n', file);
   }
   fprintf (file,"!\n");
   fflush (file);

   // check for modified parameters
   modified_fet_params (fet, file);

   // measure and record DC screening parameters
   err = fet_dc_parameters (fet, inst->bias1, inst->bias2, error);

   fprintf (file, "!                            DC FET PARAMETERS\n");
   fprintf (file, "!Vbr (.1mA)  Vbr (1mA)   Idss (3V)   Vpo (3V)   Imax (1.5V)  Vpo (1.5V) Vmax (1.5V) Vpo (1mA/mm) Ron (ohms)\n");
   fprintf( file, "%+.4e %+.4e %+.4e ", fet->vbr_ss_lo, fet->vbr_ss_hi, fet->idss );
   if( err & FET_FAIL_VPO1 ) fprintf( file, "*********** " );
   else fprintf( file, "%+.4e ", fet->vpo );
   fprintf( file, "%+.4e ", fet->imax );
   if( err & FET_FAIL_VPO2 ) fprintf( file, "*********** " );
   else fprintf( file, "%+.4e ", fet->vpo_imax );
   fprintf( file, "%+.4e ", fet->vmax );
   if( err & FET_FAIL_VPOMAMM ) fprintf( file, "*********** " );
   else fprintf( file, "%+.4e ", fet->vpo_mamm );
   fprintf( file, "%+.4e\n", fet->ron );

   fflush (file);

   if( err )
   {
      fclose (file);
      return 1;
   }

   if (check_abort_flag())
   {
      fclose (file);
      return 0;
   }

   if (d->test_type == DEV_DC_SCREEN)
   {
      fclose (file);
      return 0;
   }

   if (d->test_type != DEV_NOISE)
   {
      if (fet->do_ss_breakdown)
      {
         //  measure single-sided breakdown
         fprintf (file,"!           BREAKDOWN IV-CURVES\n");
         fprintf (file,"!   Vds        Ids          Vgs        Igs\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");

         if (fet_ss_vbr_curve (fet, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return 1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      if (fet->do_ds_breakdown)
      {
         //  measure three-terminal breakdown
         fprintf (file,"!       3-TERMINAL BREAKDOWN IV-CURVES\n");
         fprintf (file,"!   Vds        Ids          Vgs        Igs\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (fet_ds_vbr_curve (fet, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return 1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      if (fet->do_fwd_iv)
      {
         // measure forward-diode I-V characteristics
         fprintf (file,"!            FORWARD IV-CURVES\n");
         fprintf (file,"!   Vds        Ids          Vgs        Igs\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n"); 
         if (fet_fwd_iv_curve (fet, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return -1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      if (fet->do_transfer)
      {
         // measure DC transfer characteristic
         fprintf (file,"!               DC TRANSFER CURVES\n");
         fprintf (file,"!   Vds        Ids          Vgs        Igs\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (fet_dc_transfer_curve (fet, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return -1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      if (fet->do_dciv)
      {
         // measure DC I-V characteristic
         fprintf (file,"!               DC IV-CURVES\n");
         fprintf (file,"!   Vds        Ids          Vgs        Igs\n");
         fprintf (file,"! (Volts)     (Amps)      (Volts)     (Amps)\n");
         if (fet_dc_iv_curves (fet, inst->bias1, inst->bias2, file, error))
         {
            fclose (file);
            return -1;
         }
         fflush (file);

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      if (d->test_type == DEV_DC)
      {
         fclose (file);
         if (check_for_dead_fet (fet, inst->bias1, inst->bias2, error))
            return 1;
         return 0;
      }

      if (fet->do_coldfet)
      {
         // measure cold-FET S-parameters
         fprintf (file,"!                                       COLD FET S-PARAMETERS\n");
         if (cold_fet_s_parameters (fet, inst->bias1, inst->bias2, inst->vna, file, error))
         {
            fclose (file);
            return -1;
         }

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      if (fet->do_sparams)
      {
         // measure S-parameters over the bias plane
         fprintf (file,"!                                         FET S-PARAMETERS\n");
         if (fet_s_parameters_over_bias (fet, inst->bias1, inst->bias2, inst->vna, file, error))
         {
            fclose (file);
            return -1;
         }

         if (check_abort_flag())
         {
            fclose(file);
            return 0;
         }
      }

      fclose (file);
      if (check_for_dead_fet (fet, inst->bias1, inst->bias2, error))
         return 1;
      return 0;
   }

   else
   {
      if (fet_noise_figure_sweep (fet, inst->bias1, inst->bias2, inst->nfm, file, error))
      {
         fclose (file);
         return 1;
      }

      fclose (file);

      if (check_abort_flag())
         return 0;

      if (check_for_dead_fet (fet, inst->bias1, inst->bias2, error))
         return 1;
      return 0;
   }   
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_dc_parameters (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, char *error)
{
   double drain_c, gate_c;
   double vgg, idd, vgs_start;
   double last_vgg, step, target_ids;
   unsigned n;
   char string[100];
   int st, st2;
   int err = 0;

   // reset error string
   error[0] = '\0';
   
   update_test_function ("DC Parameters");

   vgs_start = fet->min_vgs;

   /* dual-sided breakdown  */
   if (fet->do_ds_breakdown)
   {
      update_test_status ("3-Terminal Breakdown");
      gpib_bias_set (drain, SRC_VOLTAGE, 0.0, fet->ibr_high*4.0e-6*fet->periphery, HIGH_RES, AUTO_RANGE, 0);
      gpib_bias_set (gate, SRC_CURRENT, -fabs(fet->ibr_low*1.0e-6*fet->periphery), fet->vbr_compliance, HIGH_RES, AUTO_RANGE, 1000);
      gpib_bias_trig (gate);
      gpib_bias_read (gate, NULL, &fet->vbr_ds_lo);

      gpib_bias_set (gate, SRC_CURRENT, -fabs(fet->ibr_high*1.0e-6*fet->periphery), fet->vbr_compliance, HIGH_RES, AUTO_RANGE, 1000);
      gpib_bias_trig (gate);
      gpib_bias_read (gate, NULL, &fet->vbr_ds_hi);

      gpib_bias_off (gate);
      gpib_bias_off (drain);

      if (vgs_start < 0.8*fet->vbr_ds_hi)
         vgs_start = 0.8*fet->vbr_ds_hi;
   }
   else
      fet->vbr_ds_lo = fet->vbr_ds_hi = -99.999999;

   /* single-sided breakdown */
   if (fet->do_ss_breakdown)
   {
      double tmp;

      update_test_status ("Single-Sided Breakdown");
      gpib_bias_set (gate, SRC_VOLTAGE, fet->min_vgs, fet->ibr_high*4.0e-6*fet->periphery, HIGH_RES, AUTO_RANGE, 0);
      gpib_bias_set (drain, SRC_CURRENT, fabs(fet->ibr_low*1.0e-6*fet->periphery), fet->vbr_compliance + fet->min_vgs, HIGH_RES, AUTO_RANGE, 1000);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &tmp);
      fet->vbr_ss_lo = fet->min_vgs - tmp;

      gpib_bias_set (drain, SRC_CURRENT, fabs(fet->ibr_high*1.0e-6*fet->periphery), fet->vbr_compliance + fet->min_vgs, HIGH_RES, AUTO_RANGE, 1000);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &tmp);
      fet->vbr_ss_hi = fet->min_vgs - tmp;

      gpib_bias_off (drain);
      gpib_bias_off (gate);

      if (vgs_start < 0.8*fet->vbr_ss_hi)
         vgs_start = 0.8*fet->vbr_ss_hi;
   }
   else
      fet->vbr_ss_lo = fet->vbr_ss_hi = -99.999999;

   if (check_abort_flag())
      return 0;

   /* Idss measurement Vgs=0V */

   update_test_status ("Idss");

   gpib_bias_set (gate, SRC_VOLTAGE, 0.0, fet->max_igs*1.0e-6*fet->periphery, HIGH_RES, AUTO_RANGE, 100);
   gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, fet->max_ids*1.0e-6*fet->periphery, HIGH_RES, AUTO_RANGE, 100);
   ms_delay(100);
   gpib_bias_trig (drain);
   gpib_bias_read (drain, NULL, &fet->idss);
   gpib_bias_off (drain);
   gpib_bias_off (gate);

   if (check_abort_flag())
      return 0;

   /* Imax measurement */

   update_test_status ("Imax");

   gpib_bias_set (gate, SRC_CURRENT, fet->igs_for_imax*1.0e-6*fet->periphery, fet->max_vgs, HIGH_RES, AUTO_RANGE, 100);
   gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_imax, fet->max_ids*1.0e-6*fet->periphery, HIGH_RES, AUTO_RANGE, 100);
   ms_delay(100);
   trigger_smus (gate, drain);
   st = gpib_bias_read (gate, NULL, &fet->vmax);
   st2 = gpib_bias_read (drain, NULL, &fet->imax);
   gpib_bias_off (drain);
   gpib_bias_off (gate);

   if (st)
   {
      sprintf (string, "fet_dc_parameters(): gate is open-circuited.\n");
      strcat(error,string);
      err |= FET_FAIL_VMAX;
   }
   else if (fet->vmax < 0.5)
   {
      sprintf (string, "fet_dc_parameters(): gate is short-circuited.\n");
      strcat(error,string);
      err |= FET_FAIL_VMAX;
   }
   else if (fet->imax < 10.0e-6*fet->periphery)
   {
      sprintf (string, "fet_dc_parameters(): channel is open-circuited.\n");
      strcat(error,string);
      err |= FET_FAIL_IMAX;
   }
   else if (st2)
   {
      sprintf (string, "fet_dc_parameters(): channel is short-circuited.\n");
      strcat(error,string);
      err |= FET_FAIL_IMAX;
   }

   if (check_abort_flag())
      return 0;

   /* Vpo measurement - % of Idss (Imax for E-FET) @ Vds for Idss */

   sprintf (string, "Vpo: Vds=%.1f, Ids=%.1f%%", fet->vds_for_idss, fet->vpo_percent);
   update_test_status (string);

   gate_c = fet->max_igs * 1.0e-6 * fet->periphery;
   drain_c = fet->max_ids * 1.0e-6 * fet->periphery;

   vgg = vgs_start;
   if (fet->idss < 0.05 * fet->imax)
      target_ids = 0.01*fet->vpo_percent*fet->imax;
   else
      target_ids = 0.01*fet->vpo_percent*fet->idss;

   gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, MEDIUM_RES, AUTO_RANGE, 0);
   gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, drain_c, MEDIUM_RES, AUTO_RANGE, fet->dc_delay);
   gpib_bias_trig (drain);
   gpib_bias_read (drain, NULL, &idd);

   if (idd > target_ids)
   {
      gpib_bias_off (drain);
      gpib_bias_off (gate);
      sprintf (string, "fet_dc_parameters(): device failed to pinch off.\nVgs = %.3f, Vds = %.1f, Ids = %.4e\n", vgg, fet->vds_for_idss, idd);
      strcat(error,string);
      err |= FET_FAIL_VPO1;
   }

   n = 0;
   last_vgg = 5.0 + vgg; 
   while (fabs (idd - target_ids) > 0.001*target_ids)
   {
      step = 0.65*fabs (last_vgg - vgg);
      last_vgg = vgg;
      if (idd < target_ids)
      {
         vgg += step;
         if (vgg > fet->vmax*0.8)
            vgg = fet->vmax*0.8;
      }
      else
      {
         vgg -= step;
         if (vgg < vgs_start)
            vgg = vgs_start;
      }

      gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, MEDIUM_RES, AUTO_RANGE, 0);
      gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, drain_c, MEDIUM_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &idd);

      if ((step < 1.0e-3) || (++n > 20))
         break;
   }

   fet->vpo = vgg;

   /* Vpo measurement - % of Idss (Imax for E-FET) @ Vds for Imax */

   sprintf (string, "Vpo: Vds=%.1f, Ids=%.1f%%", fet->vds_for_imax, fet->vpo_percent);
   update_test_status (string);

   vgg = vgs_start;
   if (fet->idss < 0.05 * fet->imax)
      target_ids = 0.01*fet->vpo_percent*fet->imax;
   else
      target_ids = 0.01*fet->vpo_percent*fet->idss;

   gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, MEDIUM_RES, AUTO_RANGE, 0);
   gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_imax, drain_c, MEDIUM_RES, AUTO_RANGE, fet->dc_delay);
   gpib_bias_trig (drain);
   gpib_bias_read (drain, NULL, &idd);

   if (idd > target_ids)
   {
      gpib_bias_off (drain);
      gpib_bias_off (gate);
      sprintf (string, "fet_dc_parameters(): device failed to pinch off.\nVgs = %.3f, Vds = %.1f, Ids = %.4e\n", vgg, fet->vds_for_idss, idd);
      strcat(error,string);
      err |= FET_FAIL_VPO2;
   }

   n = 0;
   last_vgg = 5.0 + vgg; 
   while (fabs (idd - target_ids) > 0.001*target_ids)
   {
      step = 0.65*fabs (last_vgg - vgg);
      last_vgg = vgg;
      if (idd < target_ids)
      {
         vgg += step;
         if (vgg > fet->vmax*0.8)
            vgg = fet->vmax*0.8;
      }
      else
      {
         vgg -= step;
         if (vgg < vgs_start)
            vgg = vgs_start;
      }

      gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, MEDIUM_RES, AUTO_RANGE, 0);
      gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_imax, drain_c, MEDIUM_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &idd);

      if ((step < 1.0e-3) || (++n > 20))
         break;
   }

   fet->vpo_imax = vgg;

   /* Vpo measurement - mA/mm */

   sprintf (string, "Vpo: Vds=%.1f, Ids=%.1f mA/mm", fet->vds_for_idss, fet->vpo_current);
   update_test_status (string);

   vgg = vgs_start;
   target_ids = fet->vpo_current*1.0e-6*fet->periphery;

   gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, MEDIUM_RES, AUTO_RANGE, 0);
   gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, drain_c, MEDIUM_RES, AUTO_RANGE, fet->dc_delay);
   gpib_bias_trig (drain);
   gpib_bias_read (drain, NULL, &idd);

   if (idd > target_ids)
   {
      gpib_bias_off (drain);
      gpib_bias_off (gate);
      sprintf (string, "fet_dc_parameters(): device failed to pinch off.\nVgs = %.3f, Vds = %.1f, Ids = %.4e\n", vgg, fet->vds_for_idss, idd);
      strcat(error,string);
      err |= FET_FAIL_VPOMAMM;
   }

   n = 0;
   last_vgg = 5.0 + vgg; 
   while (fabs (idd - target_ids) > 0.001*target_ids)
   {
      step = 0.65*fabs (last_vgg - vgg);
      last_vgg = vgg;
      if (idd < target_ids)
      {
         vgg += step;
         if (vgg > fet->vmax*0.8)
            vgg = fet->vmax*0.8;
      }
      else
      {
         vgg -= step;
         if (vgg < vgs_start)
            vgg = vgs_start;
      }

      gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, MEDIUM_RES, AUTO_RANGE, 0);
      gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, drain_c, MEDIUM_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &idd);

      if ((step < 1.0e-3) || (++n > 20))
         break;
   }

   fet->vpo_mamm = vgg;

   /* Ron measurement */

   update_test_status ("On Resistance");

   if (fet->vpo < 0.0)  // D-FET
   {
      // set Vgs = 0.0, Vds = 0.02
      gpib_bias_set (gate, SRC_VOLTAGE, 0.0, gate_c, HIGH_RES, AUTO_RANGE, 0);
      gpib_bias_set (drain, SRC_VOLTAGE, 0.02, drain_c, HIGH_RES, AUTO_RANGE, 1000);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &idd);
      fet->ron = 0.02 / idd;
   }
   else  // E-FET
   {
      /// MODIFIED FOR EPDT
      // set Vgs = 1.5, Vds = 0.02
      gpib_bias_set (gate, SRC_VOLTAGE, 1.5, gate_c, HIGH_RES, AUTO_RANGE, 0);
      gpib_bias_set (drain, SRC_VOLTAGE, 0.02, drain_c, HIGH_RES, AUTO_RANGE, 1000);
      gpib_bias_trig (drain);
      gpib_bias_read (drain, NULL, &idd);
      fet->ron = 0.02 / idd;
   }

   gpib_bias_off (drain);
   gpib_bias_off (gate);

   return err;
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_dc_iv_curves (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error)
{
   double vgs_list[50];
   double vds_list[100];
   double drain_c, gate_c, max_power, max_vdg;
   double start, stop, step, vgs, vds;
   unsigned num_g = 0;
   unsigned num_d = 0;

   update_test_function ("I-V Curves");

   step = 0.05*floor (2.0*(fet->vmax - fet->vpo) + 0.5);
   if (step < 0.05)
      step = 0.05;
   start = step*floor (fet->vpo/step - 3.0);
   stop = step*floor (fet->vmax/step + 0.01);

   // create the Vgs list
   for (vgs = start; vgs < stop; vgs += step, ++num_g)
   {
      if (num_g >= 50)
         break;
      vgs_list[num_g] = vgs;
   }

   // create the Vds list
   for (vds = 0.0; vds < 1.01; vds += 0.1, ++num_d)
      vds_list[num_d] = vds;   
   for (vds = 1.2; vds < 2.01; vds += 0.2, ++num_d)
      vds_list[num_d] = vds;   
   for (vds = 2.5; vds < (fet->max_vds + 0.01); vds += ((vds < 5.0) ? 0.5 : 1.0), ++num_d)
   {
      if (num_d >= 100)
         break;
      vds_list[num_d] = vds;
   }

   max_power = fet->max_power * 1.0e-3 * fet->periphery;
   drain_c = fet->max_ids * 1.0e-6 * fet->periphery;
   gate_c = fet->max_igs * 1.0e-6 * fet->periphery;
   max_vdg = fet->do_ss_breakdown ? fabs(0.8*fet->vbr_ss_hi) : 100.0;

   return general_iv_curves (gate, drain, file, error, SRC_VOLTAGE, vgs_list, num_g, gate_c,
      SRC_VOLTAGE, vds_list, num_d, drain_c, max_power, max_vdg, 0, fet->dc_delay);
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_fwd_iv_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error)
{
   double drain_c, gate_c;
   double v, start, stop, step, max_r;
   double vds, vgs, igs, ids;
   char string[100];

   update_test_function ("Forward I-V Curve");

   stop  = fabs (fet->fwd_iv_igs) * 1.0e-6 * fet->periphery;
   if (stop > 0.1)
      stop  = 0.1;
   max_r = stop;
   start = 0.001 * stop;

   start = log10 (start);
   stop = log10 (stop) + 0.1;
   step = 0.25;

   drain_c = fet->fwd_iv_igs * 5.0e-6 * fet->periphery;
   gate_c = fet->max_vgs; 

   for (v = start; v < stop; v += step)
   {
      sprintf (string, "%d of %d points", get_thispt(v,start,step), get_npts(start,stop,step));
      update_test_status (string);

      gpib_bias_set (drain, SRC_VOLTAGE, 0.0, drain_c, HIGH_RES, AUTO_RANGE, 200);
      gpib_bias_set (gate, SRC_CURRENT, pow(10.0,v), gate_c, HIGH_RES, max_r, 200);

      if( v == start ) {
         ms_delay(1000);
      }

      trigger_smus (drain, gate);
      gpib_bias_read (drain, &vds, &ids);
      gpib_bias_read (gate, &igs, &vgs);

/*
      if (vgs < 0.05)
      {
         gpib_bias_off (gate);
         gpib_bias_off (drain);
         sprintf (error, "fet_dc_iv_curves(): the gate is shorted.\nIgs = %.4e, Vgs = %.4f", igs, vgs);
         return 1;
      }
*/

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vds, ids, vgs, igs);

      if (check_abort_flag())
      {
         gpib_bias_off (gate);
         gpib_bias_off (drain);
         return 0;
      }
   }

   gpib_bias_off (gate);
   gpib_bias_off (drain);
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_ds_vbr_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error)
{
   double stop, step;
   double gate_c, drain_c;
   double vgs, vds, igs, ids;
   double v;
   char string[100];

   update_test_function ("3-Terminal Breakdown");

   stop = floor (10.0 * fet->vbr_ds_hi) * 0.1;
   step = stop * 0.025;
   stop += 0.5 * step;

   gate_c = fabs (fet->ibr_high) * 1.0e-6 * fet->periphery;
   drain_c = 5.0 * gate_c;

   for (v = step; v < stop; v += step)
   {
      sprintf (string, "%d of %d points", get_thispt(v,step,step), get_npts(step,stop,step));
      update_test_status (string);

      gpib_bias_set (drain, SRC_VOLTAGE, 0.0, drain_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_set (gate, SRC_VOLTAGE, v, gate_c, HIGH_RES, stop, fet->dc_delay);

      trigger_smus (drain, gate);
      if (gpib_bias_read (drain, &vds, &ids))
         break;
      else if (gpib_bias_read (gate, &vgs, &igs))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vds, ids, vgs, igs);

      if (check_abort_flag())
      {
         gpib_bias_off (gate);
         gpib_bias_off (drain);
         return 0;
      }      
   }

   gpib_bias_off (gate);
   gpib_bias_off (drain);
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_ss_vbr_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error)
{
   double start, stop, step;
   double gate_c, drain_c;
   double vgs, vds, igs, ids;
   double v;
   char string[100];

   update_test_function ("Single-Sided Breakdown");

   stop = 0.1*floor (10.0*fabs(fet->vbr_ss_hi));
   step = stop*0.025;
   start = fet->min_vgs + 0.5 - fet->vpo_mamm;
   stop += fet->min_vgs + 0.5 * step;

   gate_c = fabs (fet->ibr_high) * 1.0e-6 * fet->periphery;
   drain_c = 10.0 * gate_c;

   for (v = start; v < stop; v += step)
   {
      sprintf (string, "%d of %d points", get_thispt(v,start,step), get_npts(start,stop,step));
      update_test_status (string);

      gpib_bias_set (gate, SRC_VOLTAGE, fet->min_vgs, gate_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_set (drain, SRC_VOLTAGE, v, drain_c, HIGH_RES, stop, fet->dc_delay);

      trigger_smus (gate, drain);
      if (gpib_bias_read (gate, &vgs, &igs))
         break;
      else if (gpib_bias_read (drain, &vds, &ids))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vds, ids, vgs, igs);

      if (check_abort_flag())
      {
         gpib_bias_off (drain);
         gpib_bias_off (gate);
         return 0;
      }      
   }

   gpib_bias_off (drain);
   gpib_bias_off (gate);
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_dc_transfer_curve (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, FILE *file, char *error)
{
   double gate_c, drain_c;
   double vgs, vds, igs, ids;
   double v;
   double step = 0.05;
   char string[100];

   update_test_function ("Transfer Curve");

   gate_c = fet->max_igs * 1.0e-6 * fet->periphery;
   drain_c = fet->max_ids * 1.0e-6 * fet->periphery;

   for (v = fet->min_vgs; v < fet->vmax; v += step)
   {
      sprintf (string, "%d of %d points", get_thispt(v,fet->min_vgs,step), get_npts(fet->min_vgs,fet->vmax,step));
      update_test_status (string);

      gpib_bias_set (gate, SRC_VOLTAGE, v, gate_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, drain_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);

      trigger_smus (gate, drain);
      if (gpib_bias_read (gate, &vgs, &igs))
         break;
      else if (gpib_bias_read (drain, &vds, &ids))
         break;

      fprintf (file, "%+.4e %+.4e %+.4e %+.4e\n", vds, ids, vgs, igs);

      if (check_abort_flag())
      {
         gpib_bias_off (drain);
         gpib_bias_off (gate);
         return 0;
      }      
   }

   gpib_bias_off (drain);
   gpib_bias_off (gate);
   return 0;
}


/******************************************************************************************/
/******************************************************************************************/

static int cold_fet_s_parameters (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, gpib_instr_t vna, FILE *file, char *error)
{
   double drain_c, gate_c;
   double igs, vgs, ids, vds;
   double stop, step;
   double ig;
   double *flist = NULL;
   char string[100];
   int gstat, dstat;

   update_test_function ("Cold-FET S-Parameters");

   stop = fet->coldfet_igs * 1.0e-6 * fet->periphery;
   if (stop > 0.1)
      stop = 0.1;
   step = stop / ((double) fet->coldfet_npts);

   drain_c = 5.0 * stop;
   gate_c = fet->max_vgs;
   stop += 0.5 * step;

   /* forward gate current measurements */

   for (ig = step; ig < stop; ig += step)
   {
      sprintf (string, "Cold-FET: %d of %d", get_thispt(ig,step,step), get_npts(step,stop,step));
      update_test_status (string);

      gpib_bias_set (drain, SRC_VOLTAGE, 0.0, drain_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_set (gate, SRC_CURRENT, ig, gate_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);

      trigger_smus (drain, gate);
      dstat = gpib_bias_read (drain, &vds, &ids);
      gstat = gpib_bias_read (gate, &igs, &vgs);
      if( gstat || dstat )
      {
         fprintf (file, "!**BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);
         break;
      }

      fprintf (file, "!BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (gate);
         gpib_bias_off (drain);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (gate);
         gpib_bias_off (drain);
         return 0;
      }
   }

   gpib_bias_off (gate);
   gpib_bias_off (drain);
   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_s_parameters_over_bias (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, gpib_instr_t vna, FILE *file, char *error)
{
   double vgs, igs, vds, ids;
   double vds_list[100];
   double max_pow, drain_c, gate_c, max_vdg, drain_compl;
   double *flist = NULL;
   unsigned i, n_vds;
   double start, stop, step, step1, vg;
   double min_v = fet->do_ds_breakdown ? 0.8 * fet->vbr_ds_lo : fet->min_vgs;
   char string[100];
   int gstat, dstat;

   update_test_function ("S-Parameters");

   // attempt to adjust the min vgs if it is set to min_vgs
   if( min_v == fet->min_vgs )
      min_v = fet->do_ss_breakdown ? 0.5 * fet->vbr_ss_lo : min_v;

   step = 0.025 * floor (2.0*(fet->vmax - fet->vpo) + 0.5);
   if (step < 0.025)
      step = 0.025;
   start = step * floor (fet->vpo / step - 6.0);
   stop = step * floor (fet->vmax / step + 0.01);

   vds_list[0] = 0.0;
   vds_list[1] = 0.5;
   for (n_vds = 2, vds = 1.0; vds < fet->max_vds + 0.5 * fet->sparam_vds_step; vds += fet->sparam_vds_step, ++n_vds)
   {
      if (n_vds >= 100)
         break;
      vds_list[n_vds] = vds;
   }

   max_pow = fet->max_power * 1.0e-3 * fet->periphery;
   drain_c = fet->max_ids * 1.0e-6 * fet->periphery;
   gate_c = fet->max_igs * 1.0e-6 * fet->periphery;
   max_vdg = fet->do_ss_breakdown ? fabs (0.8 * fet->vbr_ss_hi) : 100.0; 

   // make sure the switch bias step is OK, to fix a hang problem (JB, 01/23/07)
   // also move the below-pinchoff measurement into this routine since it makes
   // more sense here
   step1 = 0.1 * (start - min_v);
   if( step1 < 0.1 )
   {
      min_v = start - 1.0;
      step1 = 0.1;
   }

   // measure below pinch-off @ Vds=0 for switch-mode extraction
   for (vg = min_v; vg < start - 0.5*step1; vg += step1)
   {
      sprintf (string, "Switch Mode: %d of %d", get_thispt(vg,min_v+step1,step1), get_npts(min_v+step1,start-0.5*step1,step1));
      update_test_status (string);

      gpib_bias_set (gate, SRC_VOLTAGE, vg, gate_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
      gpib_bias_set (drain, SRC_VOLTAGE, 0.0, drain_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);

      trigger_smus (gate, drain);
      gstat = gpib_bias_read (gate, &vgs, &igs);
      dstat = gpib_bias_read (drain, &vds, &ids);
      if( gstat || dstat )
      {
         fprintf (file, "!**BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);
         break;
      }

      fprintf (file, "!BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);

      if (general_s_parameters (vna, file, error, &flist, 0))
      {
         gpib_bias_off (gate);
         ms_delay (50);
         gpib_bias_off (drain);
         return 1;
      }

      if (check_abort_flag())
      {
         gpib_bias_off (gate);
         ms_delay (50);
         gpib_bias_off (drain);
         return 0;
      }
   }

   if (check_abort_flag())
   {
      gpib_bias_off (gate);
      ms_delay (50);
      gpib_bias_off (drain);
      return 0;
   }

   // measure the bias plane
   for (vg = start; vg < stop + 0.5*step; vg += step)
   {
      for (i = 0; i < n_vds; ++i)
      {
         sprintf (string, "Active Mode: %d of %d", (get_thispt(vg,start,step)-1)*n_vds + i,
            get_npts(start,stop,step)*n_vds);
         update_test_status (string);

         /* calculate the power limit compliance */
         drain_compl = ( vds_list[i] != 0.0 ) ? max_pow / vds_list[i] : 1.0e12;
         if( drain_c < drain_compl )
            drain_compl = drain_c;

         gpib_bias_set (gate, SRC_VOLTAGE, vg, gate_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
         gpib_bias_set (drain, SRC_VOLTAGE, vds_list[i], drain_compl, HIGH_RES, AUTO_RANGE, fet->dc_delay);

         trigger_smus (gate, drain);
         gstat = gpib_bias_read (gate, &vgs, &igs);
         dstat = gpib_bias_read (drain, &vds, &ids);
         if( gstat || dstat )
            fprintf (file, "!**BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);
         if( dstat )
            break;
         else if( gstat )
            continue;

         fprintf (file, "!BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);

         if (general_s_parameters (vna, file, error, &flist, 0))
         {
            gpib_bias_off (gate);
            ms_delay (50);
            gpib_bias_off (drain);
            return 1;
         }

         if (check_abort_flag())
         {
            gpib_bias_off (drain);
            ms_delay (50);
            gpib_bias_off (gate);
            return 0;
         }
      }

      if (check_abort_flag())
      {
         gpib_bias_off (drain);
         ms_delay (50);
         gpib_bias_off (gate);
         return 0;
      }

      gpib_bias_off (drain);
      ms_delay (50);
      gpib_bias_off (gate);
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int fet_noise_figure_sweep (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, gpib_instr_t nfm, FILE *file, char *error)
{
   double drain_c, gate_c, max_pow, drain_compl;
   double vgs, igs, vds, ids;
   double start, stop, step, vg, vd;
   char string[100];
   int gstat, dstat;

   update_test_function ("Noise");

   step = 0.025 * floor (2.0*(fet->vmax - fet->vpo) + 0.5);
   if (step < 0.025)
      step = 0.025;
   start = step * floor (fet->vpo / step - 6.0);
   stop = step * floor (fet->vmax / step + 0.01);

   max_pow = fet->max_power * 1.0e-3 * fet->periphery;
   drain_c = fet->max_ids * 1.0e-6 * fet->periphery;
   gate_c = fet->max_igs * 1.0e-6 * fet->periphery;

   for (vg = start; vg < stop + 0.5*step; vg += step)
   {
      for (vd = 1.0; vd < fet->max_vds + 0.5*fet->sparam_vds_step; vd += fet->sparam_vds_step)
      {
         sprintf (string, "%d of %d points",
            get_npts(1.0,fet->max_vds,fet->sparam_vds_step)*(get_thispt(vg,start,step)-1) + get_thispt(vd,1.0,fet->sparam_vds_step),
            get_npts(start,stop,step)*get_npts(1.0,fet->max_vds,fet->sparam_vds_step));
         update_test_status (string);

         /* calculate the power limit compliance */
         drain_compl = ( vd != 0.0 ) ? max_pow / vd : 1.0e12;
         if( drain_c < drain_compl )
            drain_compl = drain_c;

         gpib_bias_set (gate, SRC_VOLTAGE, vg, gate_c, HIGH_RES, AUTO_RANGE, fet->dc_delay);
         gpib_bias_set (drain, SRC_VOLTAGE, vd, drain_compl, HIGH_RES, AUTO_RANGE, fet->dc_delay);

         trigger_smus (gate, drain);
         gstat = gpib_bias_read (gate, &vgs, &igs);
         dstat = gpib_bias_read (drain, &vds, &ids);
         if( gstat || dstat )
            fprintf (file, "!**BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);
         if( dstat )
            break;
         else if( gstat )
            continue;

         fprintf (file, "!BIAS: VDS = %+.5e Volts IDS = %+.5e Amps VGS = %+.5e Volts IGS = %+.5e Amps\n", vds, ids, vgs, igs);

         if (general_noise (nfm, file, error))
         {
            gpib_bias_off (drain);
            ms_delay (50);
            gpib_bias_off (gate);
            return 1;
         }

         if (check_abort_flag())
         {
            gpib_bias_off (drain);
            ms_delay (50);
            gpib_bias_off (gate);
            return 0;
         }
      }

      if (check_abort_flag())
      {
         gpib_bias_off (drain);
         ms_delay (50);
         gpib_bias_off (gate);
         return 0;
      }

      gpib_bias_off (drain);
      ms_delay (50);
      gpib_bias_off (gate);
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int check_for_dead_fet (FET_DEVICE_PARAMETERS *fet, gpib_instr_t gate, gpib_instr_t drain, char *error)
{
   double drain_c, gate_c;
   double vgg, idd, igg;

   update_test_function ("Check for Dead Device");
   update_test_status ("Biasing at pinch-off.");

   gate_c = fet->max_igs * 1.0e-6 * fet->periphery;
   drain_c = fet->max_ids * 1.0e-6 * fet->periphery;

   vgg = fet->vpo - 0.2;
   if (vgg < fet->min_vgs)
      vgg = fet->min_vgs;

   gpib_bias_set (gate, SRC_VOLTAGE, vgg, gate_c, HIGH_RES, AUTO_RANGE, 100);
   gpib_bias_set (drain, SRC_VOLTAGE, fet->vds_for_idss, drain_c, HIGH_RES, AUTO_RANGE, 100);

   trigger_smus (gate, drain);
   if (gpib_bias_read (gate, NULL, &igg) || gpib_bias_read (drain, NULL, &idd))
   {
      gpib_bias_off (drain);
      gpib_bias_off (gate);
      sprintf (error, "check_for_dead_fet(): device failed - overcurrent.");
      return 1;
   }

   gpib_bias_off (drain);
   gpib_bias_off (gate);

   if (idd > 0.01*fet->vpo_percent*fet->imax)
   {
      sprintf (error, "check_for_dead_fet(): device failed - no pinch-off.");
      return 1;
   }

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

extern MAIN_DATA mainDataDefaults (void);
extern char *get_str_from_dbl (double x);

static void modified_fet_params (FET_DEVICE_PARAMETERS *fet, FILE *file)
{
   MAIN_DATA d = mainDataDefaults();
   FET_DEVICE_PARAMETERS *def = &d.fet_device;

   fprintf (file, "!MODIFIED DEVICE PARAMETERS:\n");

   if (fet->max_vds != def->max_vds)
      fprintf (file, "!Max Vds = %s\n", get_str_from_dbl (fet->max_vds));

   if (fet->max_power != def->max_power)
      fprintf (file, "!Max Power = %s\n", get_str_from_dbl (fet->max_power));

   if (fet->min_vgs != def->min_vgs)
      fprintf (file, "!Min Vgs = %s\n", get_str_from_dbl (fet->min_vgs));

   if (fet->max_vgs != def->max_vgs)
      fprintf (file, "!Max Vgs = %s\n", get_str_from_dbl (fet->max_vgs));

   if (fet->max_igs != def->max_igs)
      fprintf (file, "!Max Igs = %s\n", get_str_from_dbl (fet->max_igs));

   if (fet->max_ids != def->max_ids)
      fprintf (file, "!Max Ids = %s\n", get_str_from_dbl (fet->max_ids));

   if (fet->ibr_low != def->ibr_low)
      fprintf (file, "!Ibr Low = %s\n", get_str_from_dbl (fet->ibr_low));

   if (fet->ibr_high != def->ibr_high)
      fprintf (file, "!Ibr High = %s\n", get_str_from_dbl (fet->ibr_high));

   if (fet->vbr_compliance != def->vbr_compliance)
      fprintf (file, "!Max Vbr = %s\n", get_str_from_dbl (fet->vbr_compliance));

   if (fet->vpo_percent != def->vpo_percent)
      fprintf (file, "!Vpo Percent = %s\n", get_str_from_dbl (fet->vpo_percent));

   if (fet->vpo_current != def->vpo_current)
      fprintf (file, "!Vpo Current = %s\n", get_str_from_dbl (fet->vpo_current));

   if (fet->vds_for_idss != def->vds_for_idss)
      fprintf (file, "!Vds for Idss = %s\n", get_str_from_dbl (fet->vds_for_idss));

   if (fet->vds_for_imax != def->vds_for_imax)
      fprintf (file, "!Vds for Imax = %s\n", get_str_from_dbl (fet->vds_for_imax));

   if (fet->igs_for_imax != def->igs_for_imax)
      fprintf (file, "!Igs for Imax = %s\n", get_str_from_dbl (fet->igs_for_imax));

   if (fet->fwd_iv_igs != def->fwd_iv_igs)
      fprintf (file, "!Fwd IV Igs = %s\n", get_str_from_dbl (fet->fwd_iv_igs));

   if (fet->coldfet_igs != def->coldfet_igs)
      fprintf (file, "!Cold-FET Igs = %s\n", get_str_from_dbl (fet->coldfet_igs));

   if (fet->sparam_vds_step != def->sparam_vds_step)
      fprintf (file, "!Vds Step for S-Params = %s\n", get_str_from_dbl (fet->sparam_vds_step));

   fprintf (file, "!\n");
}


