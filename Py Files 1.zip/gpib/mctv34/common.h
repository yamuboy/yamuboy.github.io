#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "device.h"
#include "version.h"
#include "bias.h"

#ifndef _MCT_COMMON_H
#define _MCT_COMMON_H

/**** MACROS ****/

#define siz(a)  sizeof(a)/sizeof(*a)
#define get_npts(start,stop,step)    ((int)(((stop)-(start))/(step))+1)
#define get_thispt(x,start,step)     ((int)(((x)-(start))/(step))+1)

/**** DEFINITIONS ****/

// device types
#define DUT_FET        1
#define DUT_BIPOLAR    2
#define DUT_MOSFET     3

// test modes
#define DEV_DC_SCREEN       1
#define DEV_DC              2
#define DEV_DC_AND_S        3
#define DEV_NOISE           4
#define SPARAMS             5
#define SPARAMS_W_BIAS      6
#define NOISE               7
#define NOISE_W_BIAS        8
#define IV_CURVE            9
#define TRANSFER_CURVE      10
#define VNA_CAL_COEFFS      11
#define NFM_LOAD_ENR        12

// maximum string lengths
#define MAX_FNAME_LEN         255
#define MAX_HEADER_LEN        30
#define MAX_COMMENTS_LEN      1000

// bias source types
#define BIAS_VOLTAGE     1
#define BIAS_CURRENT     2

// bias_file_types
#define BIAS_FILE_VINVOUT      0
#define BIAS_FILE_IINVOUT      1
#define BIAS_FILE_VINIOUT      2
#define BIAS_FILE_IINIOUT      3
#define BIAS_FILE_VINTARGETI   4

/* structure definitions */

typedef struct
{
   char wafer[MAX_HEADER_LEN+1];
   char process[MAX_HEADER_LEN+1];
   char device[MAX_HEADER_LEN+1];
   char calkit[MAX_HEADER_LEN+1];
   double temperature;
   char comments[MAX_COMMENTS_LEN+1];
} HEADER_INFO;

typedef struct
{
   int do_multisite;
   char mapfile[MAX_FNAME_LEN+1];
   unsigned xIndex;
   unsigned yIndex;
   unsigned orientation;
   int stop_on_error;
} MULTISITE;

typedef struct
{
   int gpib_board;
   char bias1_dl[MAX_FNAME_LEN+1];
   char bias2_dl[MAX_FNAME_LEN+1];
   char vna_dl[MAX_FNAME_LEN+1];
   char nfm_dl[MAX_FNAME_LEN+1];
   char ap_dl[MAX_FNAME_LEN+1];
   char tc_dl[MAX_FNAME_LEN+1];
   int bias1_addr, bias2_addr, vna_addr, nfm_addr, ap_addr, tc_addr;
   int bias1_tmo, bias2_tmo, vna_tmo, nfm_tmo, ap_tmo, tc_tmo;
   int bias1_chan, bias2_chan, vna_chan, nfm_chan, ap_chan, tc_chan;
} INSTRUMENT_INFO;

typedef struct
{
   unsigned read_tset, set_on_finish, off_on_finish;
   double tset;
   unsigned soak_min;
} TEMPC;

typedef struct
{
   int use_file, bias1_mode, bias2_mode, file_mode;
   double v1_start, v1_stop, v1_step;
   double i1_start, i1_stop, i1_step;
   double v2_start, v2_stop, v2_step;
   double i2_start, i2_stop, i2_step;
   double vcompl1, vcompl2;
   double icompl1, icompl2;
   double plimit1, plimit2;
   double max_power;
   char fname[MAX_FNAME_LEN+1];
   unsigned delay, ofs_delay, b2_first;
} SET_BIAS_DATA;

typedef struct 
{
   char config_fname[MAX_FNAME_LEN+1];  // file name for configuration data
   char coeff_fname[MAX_FNAME_LEN+1];  // file name for cal coeffs
   char filename[MAX_FNAME_LEN+1];  // file name for test data
   char cwd[MAX_FNAME_LEN+1];  // current working directory
   int test_type;  // test type to be run
   int device_type;  // device type for device-driven tests
   HEADER_INFO header_info;  // standard header info
   MULTISITE multisite;  // multisite info
   INSTRUMENT_INFO inst_info;  // instrument info
   FET_DEVICE_PARAMETERS fet_device;  // parameters for FET devices
   BIPOLAR_DEVICE_PARAMETERS bjt_device;  // parameters for BJT devices
   MOSFET_DEVICE_PARAMETERS mos_device;  // parameters for MOSFET devices
   TEMPC tcontrol;  // automatic control of temperature
   void *bias_data; /* generic pointer for bias data */
   void *generic_data; /* another generic pointer */
   SET_BIAS_DATA set_bias_data;
} MAIN_DATA;

typedef struct
{
   char *name;
   double *f_ghz, *enr;
   unsigned pts;
} ENR_TABLE;

/* commmon prototypes */

/* from utils.c */
extern void *mct_malloc( size_t sz );
extern void mct_free( void *buf );
extern char *mct_strdup( char *str );

#endif

