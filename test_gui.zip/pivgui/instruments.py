from __future__ import unicode_literals, absolute_import, division, print_function
from wxtestgui import Instr

INSTR_LIST = [
    Instr('pulser',static=True,driver='pivgui.localinstr.FocusPulser',label='Pulser'),
    Instr('vd_lo',family='bias',label='Vd-low Supply'),
    Instr('vd_hi',family='bias',label='Vd-high Supply'),
    Instr('vg_probe',static=True,driver='pivgui.localinstr.dsomso',label='Vg Meas'),
    Instr('vd_probe',static=True,driver='pivgui.localinstr.dsomso',label='Vd Meas'),
    Instr('ig_probe',static=True,driver='pivgui.localinstr.dsomso',label='Ig Meas'),
    Instr('id_probe',static=True,driver='pivgui.localinstr.dsomso',label='Id Meas'),
    Instr('pna',static=True,driver='pivgui.localinstr.pnax',label='PNA'),
]