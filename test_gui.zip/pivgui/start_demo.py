#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function

if __name__ == '__main__':
    import wx
    from pivgui.gui import PIV_Main

    # create app and main window and run
    app = wx.App(redirect=False)
    main = PIV_Main(None,debug=True,demo=True)
    app.MainLoop()
