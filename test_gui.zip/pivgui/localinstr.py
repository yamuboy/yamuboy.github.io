"""
Module for locally-defined instruments.

These are instruments that aren't quite up to par for the
instrument library, but are needed for this application.

They are loaded by using full Python paths to the instrument driver class,
such as 'pivgui.localinstr.pnax'
"""
from __future__ import unicode_literals, absolute_import, division, print_function
from instrument import GenericInstrument, timed_wait_ms, visa_constants, logger
import struct

class pnax(GenericInstrument):
    "PNA-X driver for the pulsed I-V application"
    
    def __init__(self, *args, **kwargs):
        "class initializer"
        # support 8 channels in the driver
        kwargs['valid_channels'] = [1,2,3,4,5,6,7,8]
        super(pnax,self).__init__(*args,**kwargs)
        
        self.init()
        
    def init(self, force=False):
        "instrument initializer"
        # initial setup
        self.vi.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
        
        # put sweep in hold
        self.vi.write('SENS%d:SWE:MODE HOLD'%self.chan)
        
        # get the measurement catalog
        catalog = self.vi.ask('CALC%d:PAR:CAT?'%self.chan)
        # create measurements as needed
        for p in ('S11','S12','S21','S22'):
            measdef = "pysparams_ch%d_%s"%(self.chan,p)
            if catalog.find(measdef) == -1:
                self.vi.write("CALC%d:PAR:DEF '%s',%s"%(self.chan,measdef,p))
        
    def _close(self):
        "called when the driver is closed"
        # allow the PNA to enter continous sweep mode
        self.vi.write('SENS%d:SWE:MODE CONT'%self.chan)            
   
    def spars(self):
        "capture the 2-port S-parameters"
        chan = self.chan
            
        # detect averaging state
        count = 1
        avg = int(self.vi.ask('SENS%d:AVER:STAT?'%chan))
        if avg:
            count = int(self.vi.ask('SENS%d:AVER:COUN?'%chan))
            # restart averaging
            self.vi.write('SENS%d:AVER:CLE'%chan)
        
        # setup and clear standard event register so we
        # can detect the "operation complete" flag on overlapped
        # commands, which is enabled via the "*OPC" command
        self.vi.write('*ESE 1;*CLS')
        
        # set the group count to be equal to the averaging
        # and trigger the measurement group
        self.vi.write('SENS%d:SWE:GRO:COUN %d'%(chan,count))
        self.vi.write('SENS%d:SWE:MODE GRO;*OPC'%chan)
        
        # wait for the measurement to finish by polling the
        # standard event register for the "operation complete" flag
        while True:
            if int(self.vi.ask('*ESR?')):
                break
            timed_wait_ms(50)
        # make sure the overlapped command is actually finished
        # as detection may be unreliable using the standard event
        # register, hopefully this returns "1" immediately as it
        # could potentially create a timeout issue on a long
        # overlapped command (i.e. the averaging is set very high
        # and/or the IF bandwidth is set very small) 
        self.vi.ask('*OPC?')
        
        # get the frequency list
        freq = self.vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?'%chan,fmt=0x03)
        n = len(freq)
        
        # get the S-parameters
        sp = []
        for p in ('S11','S12','S21','S22'):
            
            self.vi.write("CALC%d:PAR:SEL 'pysparams_ch%d_%s'" % (chan,chan,p))
            r = self.vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA'%chan,fmt=0x03)
            # combine the interlaced real/imag pairs into complex numbers
            if len(r) != n*2:
                raise ValueError("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (p,n,len(r)))
            r2 = []
            for i in range(n):
                cnum = complex(r[2*i],r[2*i+1])
                r2.append(cnum)
            sp.append(r2)
        
        return tuple([freq]+sp)
        
class dsomso(GenericInstrument):
    "Keysight O-scope driver for DSO/MSO X6000/7000/9000 and maybe others"
    
    _default_scales = [
        0.002, 0.003, 0.004, 0.005, 0.008, 0.01,
        0.015, 0.02, 0.03, 0.04, 0.05, 0.08, 0.1,
        0.15, 0.2, 0.3, 0.4, 0.5, 0.8, 1.0,
        1.5, 2.0, 3.0, 4.0, 5.0
        ]
    
    def __init__(self, *args, **kwargs):
        "class initializer"
        kwargs['valid_channels'] = [1,2,3,4]
        super(dsomso,self).__init__(*args,**kwargs)
        
        # run the initializer
        self.init()
        
    def init(self, force=False):
        "init instrument state"
        p = self._get_params(self.chan)
        if force or '_initialized' not in p:
            p['_initialized'] = True
            
            # determine the probe attenuation and set the scale options
            att = float(self.vi.ask(':CHAN%d:PROB?'%self.chan))            
            p['scales'] = [att*x for x in self._default_scales]
            
            # make sure the channel is visible
            self.vi.write(':CHAN%d:DISP 1'%self.chan)
            
            # these settings are not channel specific, but they need to
            # be set correctly, so they'll get set more than once
            # some accounting of this could be done using a flag on
            # one of the channels, but setting them more than once
            # has no side effects, so this is the easy way
            self.vi.write(':WAV:POIN:MODE NORM;:WAV:POIN 1000')
                    
    def trigger(self):
        "trigger a new acquisition"
        self.vi.write(':DIG')
        
    def get_marker_position(self):
        "get marker positions, returns a 2-tuple"
        x1 = float(self.vi.ask('MARK:X1P?'))
        x2 = float(self.vi.ask('MARK:X2P?'))
        return x1, x2    
    
    def set_marker_position(self, x1, x2):
        "set marker position"
        self.vi.write('MARK:MODE WAV')
        self.vi.write('MARK:X1P %g;X2P %g'%(x1,x2))
    
    def get_y_offset(self):
        "get Y offset of the trace from the center of the display"
        return float(self.vi.ask('CHAN%d:OFFS?'%self.chan))
    
    def set_y_offset(self, value):
        "set Y offset of the trace from the center of the display"
        return self.vi.write('CHAN%d:OFFS %g'%(self.chan,value))
                
    def get_y_scale(self):
        "get Y scale of a channel"
        return float(self.vi.ask('CHAN%d:SCAL?'%self.chan))
    
    def set_y_scale(self, value):
        "set Y scale of a channel"
        self.vi.write('CHAN%d:SCAL %g'%(self.chan,value))
        
    def set_y_fullscale(self, value):
        "set Y scale of a channel"
        self.vi.write('CHAN%d:RANG %g'%(self.chan,value))
        
    def set_y_scale_index(self, idx):
        "set Y scale of a channel"
        self.vi.write('CHAN%d:SCAL %g'%(self.chan,self.get_y_scales()[idx]))
        
    def get_waveform_old(self):
        """get the scope waveform of a channel
        
        returns a 2-tuple of lists of x-values (in time units)
        and y-values (in the units of the trace)
        """
        wraw = self.vi.ask(':WAV:SOUR CHAN%d;FORM ASC;DATA?'%self.chan)[10:]
        w = [float(x) for x in wraw.split(',')]
        n = len(w)
        range = float(self.vi.ask('TIM:RANG?'))
        ref = self.vi.ask('TIM:REF?').strip().upper()
        pos = float(self.vi.ask('TIM:POS?'))
        if ref == 'LEFT':
            sf = 0.1
        elif ref == 'RIGH':
            sf = 0.9
        else:
            sf = 0.5
        
        ts = pos-sf*range
        step = range/float(n-1)
        x, y = [], []
        for v in w:
            y.append(v)
            x.append(ts)
            ts += step
        
        return x, y
    
    def get_waveform(self):
        """get the waveform by transferring in binary to speed up the transfer
        
        returns a 2-tuple of lists of x-values (in time units)
        and y-values (in the units of the trace)
        """
        # read the binary data block and the preamble
        self.vi.write(':WAV:SOUR CHAN%d;FORM WORD;UNS ON;BYT MSBF;DATA?'%self.chan)
        rawdata = self.vi.read_raw()
        preamble = self.vi.ask(':WAV:SOUR CHAN%d;PRE?'%self.chan).split(',')
        
        # pull the data from the preamble
        try:
            format = int(preamble[0])
            ty = int(preamble[1])
            npoints = int(preamble[2])
            avcnt = int(preamble[3])
            xinc = float(preamble[4])
            xorig = float(preamble[5])
            xref = int(preamble[6])
            yinc = float(preamble[7])
            yorig = float(preamble[8])
            yref = int(preamble[9])
        except Exception as e:
            raise ValueError('unable to read binary data preamble -> %s'%e)
            
        # read waveform header and convert the data
        # to a list of integers
        try:
            # number of bytes in header
            if rawdata[0:1] != b'#':
                raise ValueError('binary block is missing the leading block header')
            c = int(rawdata[1:2])
            nbytes = int(rawdata[2:2+c])
            # convert binblock to a list of integers
            binblock = rawdata[2+c:2+c+nbytes]
            if nbytes != len(binblock):
                raise ValueError('binary block is too short')
            fmt = b'>%dH'%(nbytes//2)
            data = list(struct.unpack(fmt,binblock))
            datalen = len(data)
            if npoints != datalen:
                raise ValueError('npts from header does not match data in binblock')
        except Exception as e:
            raise ValueError('binary waveform conversion failed -> %s'%e)
        
        # compute the output waveforms
        x, y = [], []
        for i in range(datalen):
            x.append((i-xref)*xinc+xorig)
            y.append((data[i]-yref)*yinc+yorig)
            
        return x, y
    
    get_waveform_binary = get_waveform

    def get_y_divisions(self):
        "number of Y divisions"
        return 8
    
    def get_y_scales(self):
        """get the possible Y per division scale values
        this list is guaranteed to be in increasing value
        """
        p = self._get_params(self.chan)
        return p['scales'][:]
        
    def get_y_fullscales(self):
        "get the possible Y full scale values"
        x = self.get_y_divisions()
        return [x*s for s in self.get_y_scales()]
        
    def set_best_scale(self, minv, maxv):
        """set the ideal trace scale and position for the given min+max trace values
        
        returns the index of the scale value from the 'get_y_scales()' list        
        """
        # figure out the scaling range
        if minv >= 0.0:
            r = abs(maxv)  
        elif maxv <= 0.0:
            r = abs(minv)
        else:
            # minv and maxv straddle 0
            r = abs(maxv-minv)
            
        found = False
        scales = self.get_y_scales()
        fscales = self.get_y_fullscales()
        for i,fs in enumerate(fscales):
            if r <= fs*0.9:
                found = True
                break
        
        if not found:
            # use the largest scale value that is possible
            i = len(scales) - 1
        
        # set the Y scale
        self.set_y_scale(scales[i])
        
        # set the position
        if minv >= 0.0:
            self.set_y_offset(0.45*fscales[i])        
        elif maxv <= 0.0:
            self.set_y_offset(-0.45*fscales[i])
        else:
            # minv and maxv straddle 0
            z = abs(minv) + 0.5*(fscales[i] - abs(minv) - abs(maxv))
            # round z to 0.05 of the full scale
            z = round(z*20.0/fscales[i])*0.05*fscales[i]
            self.set_y_offset(0.5*fscales[i]-z)
        
        return i
        
    def _close(self):
        "runs when the driver is closed"
        if self.vi:
            self.vi.write(':RUN')
        
        
class FocusPulser(GenericInstrument):
    "Focus pulsed I-V pulser driver"
    
    def __init__(self, *args, **kwargs):
        "class initializer"
        super(FocusPulser,self).__init__(*args,**kwargs)
        
        p = self._get_params(0)
        p['vdlo'] = None
        p['vdhi'] = None
        p['enabled'] = False
        p['vg'] = 0.0
        p['vgq'] = 0.0
        p['vd'] = 0.0
        p['vdq'] = 0.0
        p['width'] = 5.0
        p['period'] = 1000.0
        p['vd_in_vg'] = 0.0
        p['_options'] = {'swap_timing':True}
        p['_initialized'] = False
        
        self.init()
        
    def init(self, force=False):
        "instrument initializer"
        p = self._get_params(0)
        if not p['_initialized'] or force:
            if self.vi:
                p['_initialized'] = True
                # set up a different termination character for reading
                self.set_visa_attribute(visa_constants.VI_ATTR_TERMCHAR,ord('>'))
                self.set_visa_attribute(visa_constants.VI_ATTR_TERMCHAR_EN,True)
                # read the initial prompt
                self._read()
                
                self._write('DRAIN OFF')
                self._write('GATE OFF')
                self._write('RELAY 0')
    
    def _write(self, msg):
        "customized write routine"
        self.vi.write_raw(msg.strip()+'\n')
        # wait for the prompt to come back
        self._read()
    
    def _read(self):
        "read until the prompt"
        r = ''
        while r[-6:] != 'MPIV->':
            r += self.vi.read()
        return r
        
        
    def setup_supplies(self, vd_lo, vd_hi):
        "connect the drain voltage lo and hi supplies to the pulser driver"
        p = self._get_params(0)
        if not isinstance(vd_lo,GenericInstrument):
            raise TypeError('`vd_lo` must be sub-classed from `instrument.GenericInstrument`')
        if not isinstance(vd_hi,GenericInstrument):
            raise TypeError('`vd_hi` must be sub-classed from `instrument.GenericInstrument`')
            
        p['vdlo'] = vd_lo
        p['vdhi'] = vd_hi
        p['vdlo'].config(mode='V',vset=0.0,state=0)
        p['vdhi'].config(mode='V',vset=0.0,state=0)
        
    def config(self, **kwargs):
        "setup pulser options"
        p = self._get_params(0)
        for k in kwargs.keys():
            if k in p['_options']:
                p['_options'][k] = kwargs.pop(k)
        
        if len(kwargs):
            raise ValueError("unknown options: "+(', '.join(kwargs.keys())))

    def set_voltage(self, **kwargs):
        """set the pulser voltages
        
        Keywords:
        
        vd     pulsed drain voltage 
        vdq    quiescent drain voltage
        vg     pulsed gate voltage
        vgq    quiescent gate voltage
        """
        p = self._get_params(0)
        
        vd1 = p['vd']
        vdq1 = p['vdq']
        
        set_vg = False
        set_vd = False
        
        if 'vd' in kwargs:
            set_vd = True
            p['vd'] = float(kwargs['vd'])
        if 'vdq' in kwargs:
            set_vd = True
            p['vdq'] = float(kwargs['vdq'])
        if 'vg' in kwargs:
            set_vg = True
            p['vg'] = float(kwargs['vg'])
        if 'vgq' in kwargs:
            set_vg = True
            p['vgq'] = float(kwargs['vgq'])
        
        if p['enabled']:
            # set the values immediately if the pulser is enabled
            if set_vg:
                # Pulse_V9 style
                #self._write('GATE PULSE %g %g'%(p['vg'],p['vgq']))
                
                # Pulse_V10 style (compatible with Pulse_V9
                dac0 = 0.5*(p['vg']-p['vgq'])
                dac1 = p['vgq'] + dac0
                self._write('VOLTAGE 0 %g'%dac0)
                self._write('VOLTAGE 1 %g'%dac1)
                
                timed_wait_ms(50)
            
            # for the drain, to be sure things happen smoothly check to see
            # what the supplies and pulser were set to prior to the change
            # if the pulser has to switch its timing due to the new settings
            # then make sure it happens in a benign way
            if set_vd:
                if vd1 <= vdq1 and p['vd'] > p['vdq']:
                    # we're traversing the Q-point from below/equal to above
                    # make sure to make a stop at equal when making changes
                    # also need to make sure that vdlo is ALWAYS less than or equal to vdhi
                    if vd1 == vdq1 and vdq1 == p['vdq']:
                        pass
                    elif vdq1 <= p['vdq']:
                        p['vdhi'].config(vset=p['vdq'])
                        p['vdlo'].config(vset=p['vdq'])                    
                    else:
                        p['vdlo'].config(vset=p['vdq'])                    
                        p['vdhi'].config(vset=p['vdq'])
                    self._write('DRAIN PULSE %g %g'%(p['vd'],p['vdq']))
                    
                    # swap timings if swapping is enabled
                    if p['_options']['swap_timing'] and abs(p['vd_in_vg']) > 0.02:
                        self._send_timing_commands()
                    
                    timed_wait_ms(100)
                    p['vdhi'].config(vset=p['vd'])
                elif vd1 > vdq1 and p['vd'] <= p['vdq']:
                    # we're traversing the Q-point from above to below/equal
                    # make sure to make a stop at equal when making changes
                    # also need to make sure that vdlo is ALWAYS less than or equal to vdhi
                    if vd1 == vdq1 and vdq1 == p['vdq']:
                        pass
                    elif vdq1 <= p['vdq']:
                        p['vdhi'].config(vset=p['vdq'])
                        p['vdlo'].config(vset=p['vdq'])                    
                    else:
                        p['vdlo'].config(vset=p['vdq'])                    
                        p['vdhi'].config(vset=p['vdq'])
                    self._write('DRAIN PULSE %g %g'%(p['vd'],p['vdq']))
                    
                    # swap timings if swapping is enabled
                    if p['_options']['swap_timing'] and abs(p['vd_in_vg']) > 0.02:
                        self._send_timing_commands()
                    
                    timed_wait_ms(100)
                    if p['vd'] != p['vdq']:
                        p['vdlo'].config(vset=p['vd'])
                else:
                    # no traversal of the Q-point, just set new voltages
                    # still need to be careful to be sure that vdlo is ALWAYS
                    # less than or equal to vdhi
                    self._write('DRAIN PULSE %g %g'%(p['vd'],p['vdq']))
                    if vdq1 == p['vdq']:
                        # easy case, no change in Q-point, just change
                        # vdhi or vdlo depending on which side of Q we are on
                        if p['vd'] > p['vdq']:
                            p['vdhi'].config(vset=p['vd'])                    
                        else:
                            p['vdlo'].config(vset=p['vd'])                    
                    elif vdq1 > p['vdq']:
                        # new Q-point is above the old one, to ensure that vdhi stays
                        # above vdlo we need to move vdhi first
                        if p['vd'] > p['vdq']:
                            p['vdhi'].config(vset=p['vd'])                    
                            p['vdlo'].config(vset=p['vdq'])                                            
                        else:
                            p['vdhi'].config(vset=p['vdq'])                    
                            p['vdlo'].config(vset=p['vd'])                                            
                    else:   # vdq1 < self._vdq
                        # new Q-point is below the old one, to ensure that vdhi stays
                        # above vdlo we need to move vdlo first 
                        if p['vd'] > p['vdq']:
                            p['vdlo'].config(vset=p['vdq'])                    
                            p['vdhi'].config(vset=p['vd'])                                            
                        else:
                            p['vdlo'].config(vset=p['vd'])                    
                            p['vdhi'].config(vset=p['vdq'])                                            
    
    set_voltages = set_voltage
    
    def set_timing(self, width_us, period_us, vd_inside_vg_us):
        "setup the pulser timing"
        p = self._get_params(0)
        p['width'] = width_us
        p['period'] = period_us
        p['vd_in_vg'] = vd_inside_vg_us
        
        if p['enabled']:
            # update timing immediately
            self._write('PULSE %g %g'%(p['width'],p['period']))
            self._send_timing_commands()
        
    def _send_timing_commands(self):
        "send the timing commands to set up the Vg-Vd offset depending on the configuration"
        p = self._get_params(0)
        offs = p['vd_in_vg']
        if p['_options']['swap_timing']:
            # swap timing parameters depending on the I-V plane region
            if p['vd'] <= p['vdq']:
                self._write('TIMING GATE %g %g'%(-offs,-offs))            
            else:
                self._write('TIMING GATE %g %g'%(offs,offs))
        else:
            # use the same timing for all regions of the I-V plane
            self._write('TIMING GATE %g %g'%(-offs,-offs))
        self._write('TIMING DRAIN 0.3 0')
        self._write('TRIGGER FREE')        
        timed_wait_ms(100)
        
    def safe_stepdown(self, vgsafe, vdsafe, vgstep=0.25, vdstep=5.0):
        """slowly ramp down the gate then drain voltages to
        try to keep devices from dying at the end of the test
        """
        p = self._get_params(0)
        if p['enabled']:
        
            # step gate voltages down to vgsafe
            vgstep = abs(vgstep)
            if vgstep < 0.05:
                vgstep = 0.05
            vg = p['vg']
            while vg > vgsafe:
                vg -= vgstep
                if vg <= vgsafe:
                    self.set_voltage(vg=vgsafe)
                    break
                else:
                    self.set_voltage(vg=vg)
                timed_wait_ms(50)
                
            # step the drain voltage down
            vdstep = abs(vdstep)
            if vdstep < 1.0:
                vdstep = 1.0
            vd = p['vd']
            while vd > vdsafe:
                vd -= vdstep
                if vd <= vdsafe:
                    self.set_voltage(vd=vdsafe)
                    break
                else:
                    self.set_voltage(vd=vd)
                timed_wait_ms(50)
                                        
        
    def enable(self, flag=True):
        "disable the pulser - see enable"
        p = self._get_params(0)
        if flag:
            if p['enabled']:
                return
            
            if not p['vdlo'] or not p['vdhi']:
                raise ValueError('drain voltage supplies are not configured')
            
            # turn on the drain supplies at 0 volts
            p['vdlo'].config(mode='V',vset=0.0,state=1)
            p['vdhi'].config(mode='V',vset=0.0,state=1)
                        
            # set up the pulser timing
            self._write('PULSE %g %g'%(p['width'],p['period']))
            self._send_timing_commands()
            
            # enable the gate pulser
            # Pulse_V9 style
            #self._write('GATE PULSE %g %g'%(p['vg'],p['vgq']))
            # Pulse_V10 style (compatible with Pulse_V9)
            dac0 = 0.5*(p['vg']-p['vgq'])
            dac1 = p['vgq'] + dac0
            self._write('VOLTAGE 0 %g'%dac0)
            self._write('VOLTAGE 1 %g'%dac1)
            self._write('GATE PULSE')
            timed_wait_ms(200)
            
            # enable the drain pulser
            self._write('DRAIN PULSE %g %g'%(p['vd'],p['vdq']))
            self._write('RELAY 1')
            
            # set the drain supplies to the correct values 
            timed_wait_ms(300)
            if p['vd'] > p['vdq']:
                vh, vl = p['vd'], p['vdq']
            else:
                vh, vl = p['vdq'], p['vd']
            p['vdhi'].config(vset=vh)
            p['vdlo'].config(vset=vl)
        
            p['enabled'] = True
        else:
            # disable pulser
            if not p['enabled']:
                return
                
            if not p['vdlo'] or not p['vdhi']:
                raise ValueError('drain voltage supplies are not configured')
            
            # turn down drain supplies to 0, always turn down vd_lo first to ensure that
            # the low voltage is always lower than the high voltage
            p['vdlo'].config(vset=0.0)
            p['vdhi'].config(vset=0.0)
            timed_wait_ms(300)
            
            # turn off the drain pulser
            self._write('DRAIN OFF')
            
            # turn off the gate pulser
            timed_wait_ms(100)
            self._write('GATE OFF')
            
            # shut off the supplies
            p['vdlo'].set_state(0)
            p['vdhi'].set_state(0)
            
            # disable the output relay
            timed_wait_ms(200)
            self._write('RELAY 0')
            
            p['enabled'] = False
            
        
    def disable(self):
        "disable the pulser - see enable"
        self.enable(False)
    
    def _close(self):
        "called when the driver is closed"
        self.disable()
        
        
    

    
    
    
    
