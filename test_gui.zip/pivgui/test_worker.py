from __future__ import unicode_literals, absolute_import, division, print_function

from wxtestgui.worker import send_to_ui, get_next_message, NoMessages
import logging
from time import sleep
import random

logger = logging.getLogger('pivgui.test_worker')

def iv_sweep_main(instr, parms, cal, iv_fname, spar_fname=''):
    "test out using a worker thread and handling communication with a Window"
    
    # check calibration data
    if abs(cal['vdq']-parms['drain_q']) > 0.001:
        raise ValueError("cal data Vdq does not match Q-point")
    
    # send some log messages
    logger.info('starting I-V sweep')
    sleep(1.2)
    
    logger.warning('freeze gopher!')
    sleep(0.7)
    
    send_to_ui('bonk',3)
    
    running = True
    n = 0
    while n < 20:
        # wait for an abort signal (this call blocks)
        try:
            msg = get_next_message(block=False)
            if msg.msgtype == 'abort':
                logger.warning('premature exit...you might want to get that checked out')
                break
            elif msg.msgtype == 'pause':
                running = False
                logger.warning('the hamster is dead')
            elif msg.msgtype == 'resume':
                running = True
                logger.warning('found a new hamster...or is it a rat')
        except NoMessages:
            pass
                
        sleep(random.randint(1,15)*0.1)
        if running:
            n += 1
            if n%5 == 0:
                logger.info("%g percent complete"%(n/20.0*100.0))
    
    # this should be a 50/50 chance of exiting with an exception
    if random.randint(0,1):
        raise TypeError('hey, you scratched my anchor!')

        
def manual_mode_main(instr, parms):
    "manual mode test function"
    
    # initialzing delay
    logger.info('initializing manual mode')
    sleep(1.5)
    
    send_to_ui('ready')
    logger.warning('self distruct in 3...2...1...just kidding')
    
    enabled = False
    while True:
        # main loop
        msg = get_next_message()
        ty = msg.msgtype
        data = msg.data
        
        if ty == 'quit':
            sleep(1.1)
            logger.warning("I'm melting, melting, ahhhhh...")
            break
        elif ty == 'enable':
            if enabled:
                logger.info("updating settings")
                sleep(1.2)
                logger.info("assimilation complete")                
            else:
                logger.info("waking up...")
                sleep(2.2)
                logger.info("ready for action")
            logger.info("vg = %g, vd = %g, vg-q = %g, vd-q = %g"%(data['vg'],data['vd'],data['vgq'],data['vdq']))
            enabled = True
            send_to_ui('ack')
        elif ty == 'disable':
            if enabled:
                sleep(2.1)
                enabled = False
                logger.info("going back to sleep.")
            else:
                sleep(0.4)
                logger.warning("I'm already off dummy...")
            send_to_ui('ack')
        elif ty == 'measure':
            sleep(1.7)
            send_to_ui('measured',{'vg':0.1,'vgq':-0.3,'vd':0.4,'vdq':5.02,'id':0.0234,'idq':0.0433})
            logger.info('it is intuitively obvious')
        
    # this should be a 50/50 chance of exiting with an exception
    if random.randint(0,1):
        raise TypeError('gunga galunga...gunga lagunga')
    
def calibrate_main(instr, parms):
    "manual mode test function"
    
    logger.info('cal initializing ...')
    sleep(1.5)
    
    logger.warning('fore!!! ooops, I shoulda yelled two!')    
    
    # send some meaningless cal data back
    d = {'vdq':parms['drain_q'],'blarf':23.4}
    send_to_ui('cal_data',d)
    
    sleep(1.0)
    
def imax_droop_main(instr, parms, cal_data1, cal_data2, iv_fname):
    "imax droop test function"
    
    # check cal data
    vdq1, vgq1 = parms['imax_drain_q1'], parms['imax_gate_q1']
    vdq2, vgq2 = parms['imax_drain_q2'], parms['imax_gate_q2']
    if abs(cal_data1['vdq']-vdq1) > 0.001:
        raise ValueError("cal data Vdq does not match Q-point (cal set 1)")
    if abs(cal_data2['vdq']-vdq2) > 0.001:
        raise ValueError("cal data Vdq does not match Q-point (cal set 2)")
    
    
    
    logger.info('starting I-max droop test')
    sleep(1.2)
            
    for i in range(2):
        logger.info("sweep %d"%(i+1))
        n = 0
        while n < 20:
            # wait for an abort signal (this call blocks)
            try:
                msg = get_next_message(block=False)
                if msg.msgtype == 'abort':
                    logger.warning('premature exit...you might want to get that checked out')
                    break
            except NoMessages:
                pass
                    
            sleep(random.randint(1,15)*0.05)
            n += 1
            if n%5 == 0:
                logger.info("%g percent complete"%(n/20.0*100.0))
    
    
    
    
    
    
    
    

    
