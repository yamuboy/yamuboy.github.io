from __future__ import unicode_literals, absolute_import, division, print_function
import logging, math, time
from datetime import datetime
from io import StringIO

from wxtestgui.worker import send_to_ui, get_next_message, NoMessages
from instrument import timed_wait_ms

_default_measurements = ('vg','vd','ig','id')

# test executive logger
logger = logging.getLogger('pivgui.exec')

class InstrumentLoadError(Exception):
    "error thrown when a required instrument cannot be loaded"
    pass

class DeviceFailedError(Exception):
    "error raised when a failed device is detected"
    pass
    
class UserAbort(Exception):
    "raised when an abort message is recieved"
    pass

def check_message_queue(block=False):
    "check if an abort message is in the queue"
    try:
        msg = get_next_message(block)
        if msg.msgtype == 'abort':
            raise UserAbort
        return msg
    except NoMessages:
        return None

def iv_sweep_main(instr_list, parameters, cal_data, iv_fname, spar_fname='', waveform_fname=''):
    "main I-V test routine entry point"
    # get some parameters from the `parameters` dictionary
    vd_slew_rate = parameters['vd_slew_rate']
    check_qpoint_shift = parameters['check_qpoint_shift']
    qpoint_shift_fraction = parameters['qpoint_shift_fraction']
    vdq, vgq = parameters['drain_q'], parameters['gate_q']
    measure_spars = parameters['measure_spars']
    measure_gmgds = parameters['measure_gmgds']
    save_waveforms = parameters['save_waveforms']
    ig_scale = parameters['gate_iscale']
    id_scale = parameters['drain_iscale']

    # get the voltage lists for the I-V sweep, make sure they
    # are free of duplicate values, and sort them in ascending order
    vg_list = list(set(parameters['vg_list']))
    vd_list = list(set(parameters['vd_list']))
    vg_list.sort()
    vd_list.sort()
    
    # check that the voltage lists are ok
    if not vg_list:
        raise ValueError('`vg_list` is empty')
    if not vd_list:
        raise ValueError('`vd_list` is empty')
    for v in vg_list:
        if v < -10.0 or v > 10.0:
            raise ValueError('values in `vg_list` must fall in the range -10 <= x <= 10')
    for v in vd_list:
        if v < 0.0 or v > 80.0:
            raise ValueError('values in `vd_list` must fall in the range 0 <= x <= 80')
    
    vgmin, vgmax, vdmin, vdmax = _compute_vg_vd_min_max(parameters)
    
    # check cal data
    
    if abs(cal_data['vdq']-vdq) > 0.001:
        raise ValueError('invalid calibration data (Vdq mismatch)')
    
    if cal_data['vg_calibrated'] and vgmin < cal_data['vgmin']:
        logger.warning('potential calibration issue: minimum Vg is below the calibrated range')
        
    if cal_data['vg_calibrated'] and vgmax > cal_data['vgmax']:
        logger.warning('potential calibration issue: maximum Vg is above the calibrated range')
    
    if cal_data['vd_calibrated'] and vdmax > cal_data['vdmax']:
        logger.warning('potential calibration issue: maximum Vd is above than the calibrated range')    
        
    # load instruments
    logger.info("Loading instruments ...")
    reqd_instr = ['pulser','vd_lo','vd_hi','id_probe']
    opt_instr = ['ig_probe','vg_probe','vd_probe']
    if measure_spars:
        reqd_instr.append('pna')
    else:
        opt_instr.append('pna')
    instruments = _load_instruments(instr_list,reqd_instr,opt_instr)
    pulser = instruments['pulser']
    vd_probe = instruments['vd_probe']
    vg_probe = instruments['vg_probe']
    
    fp = None
    fpspar = None
    fpwave = None
    try:
        try:
            # configure the pulser
            pulser.setup_supplies(instruments['vd_lo'],instruments['vd_hi'])
            pwid, pper, vg_vd_offs = _check_pulse_params(parameters['pulse_width'],parameters['pulse_period'],parameters['vgs_vds_offset'])
            pulser.set_timing(pwid,pper,vg_vd_offs)
            pulser.config(swap_timing=parameters['swap_timing'])
        
            # set drain current limits  
            instruments['vd_lo'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
            instruments['vd_hi'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
                    
            # position the markers on the scope
            pstart = parameters['pwin_start']*1.0e-6
            pwin = parameters['pwin_width']*1.0e-6
            instruments['id_probe'].set_marker_position(pstart,pstart+pwin)
                    
            # set the drain voltage measurement up in the range than makes sense
            if vd_probe:
                if vd_list[0] <= vdmin:
                    cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmin)
                else:
                    cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmax)
                    
            # check for user aborts
            check_message_queue()
            
            # set up the fixed Q-point condition using the first sweep point
            pulser.set_voltage(vg=vg_list[0],vgq=vgq,vd=vd_list[0],vdq=vdq)
            pulser.enable()
            
            # if Q-point targeting is enabled, then run that routine
            # to set the gate Q voltage
            if parameters['qpoint_mode']:
                logger.info('starting Q-point target routine ...')
                vgq = _target_qpoint(instruments,parameters,cal_data)
                
            # measure initial q-point
            initial_data = _measure(instruments,parameters,cal_data)
            idq_initial = initial_data['idq']*id_scale
            vgq_meas = initial_data.get('vgq',0.0)
            vdq_meas = initial_data.get('vdq',0.0)
            
            if idq_initial < 0.005:
                # don't try to check Q-point shift when the initial Id-q is close to 0
                # it becomes messy since Q-point shift is defined as a fractional delta
                # and the measurement resolution of the system is only about 0.001 on
                # a sunny day with no breeze
                check_qpoint_shift = False
            
            # check for user aborts
            check_message_queue()
            
            # create header text
            head = StringIO()
            head.write('! TestDate: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
            head.write('! Q-Point:\n')
            head.write('!    Vg = %g V (meas: %g V)\n'%(vgq,vgq_meas))
            head.write('!    Vd = %g V (meas: %g V)\n'%(vdq,vdq_meas))
            head.write('!    Id = %g mA\n'%(idq_initial*1000.0))
            head.write('! Drain Max Voltage = %g V\n'%vdmax)
            head.write('! Probe Offsets:\n')
            _write_header_probe_offsets(head,'!    Vg[%g] = %g V\n',cal_data,'vg')
            _write_header_probe_offsets(head,'!    Vd[%g] = %g V\n',cal_data,'vd')
            _write_header_probe_offsets(head,'!    Id[%g] = %g mA\n',cal_data,'id',1000.0)
            _write_header_probe_offsets(head,'!    Ig[%g] = %g mA\n',cal_data,'ig',1000.0)
            head.write('!\n!-----------------------------------------------------------------------------\n')
            head_str = head.getvalue()
            head.close()
            
            # open and write headers in I-V data file
            fp = open(iv_fname,'w')
            fp.write('!$$version: 2\n')
            fp.write('! Pulsed I-V Test\n!\n')
            fp.write(head_str)
            fp.write('!Index\tVg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_meas[A]\tIg_meas[A]')
            if measure_gmgds:
                fp.write('\tgm[S]\tgds[S]')
            fp.write('\n')
            send_to_ui('ivfile',iv_fname)
            
            if measure_spars:
                # open and write headers in S-param data file
                fpspar = open(spar_fname,'w')
                fpspar.write('!$$version: 2\n')
                fpspar.write('! Pulsed S-Parameter Test\n!\n')
                fpspar.write(head_str)
                send_to_ui('sparfile',spar_fname)
                
            if save_waveforms:
                # open and write headers in waveform data file
                fpwave = open(waveform_fname,'w')
                fpwave.write('!$$version: 2\n')
                fpwave.write('! Pulsed I-V Waveforms\n!\n')
                fpwave.write(head_str)
            
            ### start the measurement loop ###
            
            last_vd = vd_list[0]
            idx = 0
            logger.info('starting I-V curve measurements ...')
            for i,vg in enumerate(vg_list):
                logger.info('measuring curve: Vg = %g (%d of %d)'%(vg,i+1,len(vg_list)))
                
                if i:
                    # step the pulser back down to safe values
                    # before starting the next I-V sweep
                    pulser.safe_stepdown(vg_list[0],vd_list[0])

                for vd in vd_list:
                
                    # check for pause messages and user aborts
                    m = check_message_queue()
                    if m and m.msgtype == 'pause':
                        # pause the current test
                        logger.warning('pausing I-V sweep ...')
                        pulser.safe_stepdown(vg_list[0],vd_list[0])
                        pulser.disable()
                        logger.info('sweep paused.')
                        
                        # wait for a resume message (or an abort)
                        while True:
                            # this call will block indefinitely
                            # until a message from the UI is received
                            m = check_message_queue(True)
                            if m and m.msgtype == 'resume':
                                break
                        
                        # resume the I-V sweep
                        logger.warning('resuming I-V sweep ...')
                        pulser.set_voltage(vg=vg_list[0],vd=vd_list[0],vgq=vgq,vdq=vdq)
                        pulser.enable()
                        timed_wait_ms(500)
                        last_vd = vd_list[0]
                                
                    # set the pulser voltages
                    pulser.set_voltage(vg=vg,vd=vd)
                    
                    # allow the system to settle
                    vd_delta = abs(last_vd - vd)
                    timed_wait_ms(200+vd_delta*1000/vd_slew_rate)
                    last_vd = vd
                    
                    # set the vd_probe scaling
                    if vd_probe:
                        if vd <= vdmin:
                            cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmin)
                        else:
                            cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmax)
                    
                    # measure all probes
                    data = _measure(instruments,parameters,cal_data,save_waveforms=save_waveforms)
                    id_meas = data['id']*id_scale
                    ig_meas = data.get('ig',0.0)*ig_scale
                    if 'vd' in data:
                        pcalc = data['vd']*id_meas
                    else:
                        pcalc = vd*id_meas
                    
                    # check Q-point shifts
                    idq_meas = data['idq']*id_scale
                    if check_qpoint_shift and abs(idq_meas-idq_initial) > qpoint_shift_fraction*abs(idq_initial):
                        # uh-oh, device either shifted a lot or blew up
                        raise DeviceFailedError('device failed -> initial Id-q = %g mA, current Id-q = %g mA'%(idq_initial*1000.0,idq_meas*1000.0))
                        
                    # check power limit
                    plimit = _calc_power_limit(parameters,vd)
                    if pcalc > plimit:
                        break
                    
                    # write the I-V data
                    fp.write('%d\t%.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e'%(idx,vg,vd,data.get('vg',0.0),data.get('vd',0.0),id_meas,ig_meas))
                    if measure_gmgds:
                        # break into the gm+gds measurement sub-routine
                        # to measure small deltas around the current pulse point
                        gm, gds = _gmgds_sub(instruments,parameters,vg,vd)
                        fp.write('\t%.4e\t%.4e'%(gm,gds))
                    fp.write('\n')
                    fp.flush()
                    
                    if measure_spars:
                        # do pulsed S-parameter measurements and write
                        # the data to the spar file
                        fpspar.write('!INDEX: %d\n'%idx)                
                        fpspar.write('!      Vg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_meas[A]\tIg_meas[A]\n')                
                        fpspar.write('!PULSE: %.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(vg,vd,data.get('vg',0.0),data.get('vd',0.0),id_meas,ig_meas))
                        fpspar.write('# HZ S MA R 50\n')
                        fpspar.write('!\n')
                        
                        freq, s11, s12, s21, s22 = instruments['pna'].spars()
                        for k in range(len(freq)):
                            fpspar.write('%.5e\t%.5e\t%.5e'%(freq[k],abs(s11[k]),_angle(s11[k])))
                            fpspar.write('\t%.5e\t%.5e'%(abs(s21[k]),_angle(s21[k])))
                            fpspar.write('\t%.5e\t%.5e'%(abs(s12[k]),_angle(s12[k])))
                            fpspar.write('\t%.5e\t%.5e\n'%(abs(s22[k]),_angle(s22[k])))
                        fpspar.flush()
                    
                    if save_waveforms:
                        # write waveform data to the file
                        _write_waveform_data(fpwave,idx,vg,vd,data,id_scale,ig_scale)
                        fpwave.flush()
                    
                    
                    idx += 1
                
                fp.write('\n')
            
            logger.info('I-V measurement complete.')
        except UserAbort:
            logger.warning('exiting on user abort ...')
    finally:
        try:
            pulser.safe_stepdown(vg_list[0],vd_list[0])
            pulser.disable()
        except Exception as e:
            logger.warning('could not run pulser safe shutdown routine -> %s'%e)
        
        # close all open files
        if fp:
            fp.close()
        if fpspar:
            fpspar.close()
        if fpwave:
            fpwave.close()
            
        # unload all instruments
        _unload_instruments(instruments)
                
def imax_droop_main(instr_list, parameters, cal_data1, cal_data2, iv_fname):
    "main I-V test routine entry point"
    # get some parameters from the `parameters` dictionary
    vd_slew_rate = parameters['vd_slew_rate']
    vdq1, vgq1 = parameters['imax_drain_q1'], parameters['imax_gate_q1']
    vdq2, vgq2 = parameters['imax_drain_q2'], parameters['imax_gate_q2']
    soak1, soak2 = parameters['imax_soak1'], parameters['imax_soak2']
    vg_pulse = parameters['imax_vg']
    vd_for_droop = parameters['imax_vd_for_droop']
    
    ig_scale = parameters['gate_iscale']
    id_scale = parameters['drain_iscale']

    # get the voltage lists for the I-V sweep, make sure they
    # are free of duplicate values, and sort them in ascending order
    vd_list = list(set(parameters['imax_vd_list']))
    vd_list.sort()
    
    # check that the voltage lists are ok
    if not vd_list:
        raise ValueError('`imax_vd_list` is empty')
    for v in vd_list:
        if v < 0.0 or v > 80.0:
            raise ValueError('values in `imax_vd_list` must fall in the range 0 <= x <= 80')
    
    # compute vdmin and vdmax
    vgmin1 = min(vg_pulse,vgq1)
    vgmax1 = max(vg_pulse,vgq1)
    vgmin2 = min(vg_pulse,vgq2)
    vgmax2 = max(vg_pulse,vgq2)
    vdmin = max(vdq1,vdq2,5.0)
    vdmax = max(vd_list)
    vdmax = max(vdmax,vdq1,vdq2)
    if vdmax < vdmin:
        vdmax = vdmin
    
    # check cal data
    
    if abs(cal_data1['vdq']-vdq1) > 0.001:
        raise ValueError('invalid calibration data (Vdq mismatch, cal set 1)')
    if abs(cal_data2['vdq']-vdq2) > 0.001:
        raise ValueError('invalid calibration data (Vdq mismatch, cal set 2)')
    
    if cal_data1['vg_calibrated'] and vgmin1 < cal_data1['vgmin']:
        logger.warning('potential calibration issue: minimum Vg is below the calibrated range (cal set 1)')
        
    if cal_data1['vg_calibrated'] and vgmax1 > cal_data1['vgmax']:
        logger.warning('potential calibration issue: maximum Vg is above the calibrated range (cal set 1)')
    
    if cal_data1['vd_calibrated'] and vdmax > cal_data1['vdmax']:
        logger.warning('potential calibration issue: maximum Vd is above than the calibrated range (cal set 1)')    
        
    if cal_data2['vg_calibrated'] and vgmin2 < cal_data2['vgmin']:
        logger.warning('potential calibration issue: minimum Vg is below the calibrated range (cal set 2)')
        
    if cal_data2['vg_calibrated'] and vgmax2 > cal_data2['vgmax']:
        logger.warning('potential calibration issue: maximum Vg is above the calibrated range (cal set 2)')
    
    if cal_data2['vd_calibrated'] and vdmax > cal_data2['vdmax']:
        logger.warning('potential calibration issue: maximum Vd is above than the calibrated range (cal set 2)')
        
    # load instruments
    logger.info("Loading instruments ...")
    reqd_instr = ['pulser','vd_lo','vd_hi','id_probe']
    opt_instr = ['ig_probe','vg_probe','vd_probe']
    instruments = _load_instruments(instr_list,reqd_instr,opt_instr)
    pulser = instruments['pulser']
    vd_probe = instruments['vd_probe']
    vg_probe = instruments['vg_probe']
    
    fp = None
    pulser_off = True
    try:
        try:
            # configure the pulser
            pulser.setup_supplies(instruments['vd_lo'],instruments['vd_hi'])
            pwid, pper, vg_vd_offs = _check_pulse_params(parameters['pulse_width'],parameters['pulse_period'],parameters['vgs_vds_offset'])
            pulser.set_timing(pwid,pper,vg_vd_offs)
            pulser.config(swap_timing=parameters['swap_timing'])
        
            # set drain current limits  
            instruments['vd_lo'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
            instruments['vd_hi'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
                    
            # position the markers on the scope
            pstart = parameters['pwin_start']*1.0e-6
            pwin = parameters['pwin_width']*1.0e-6
            instruments['id_probe'].set_marker_position(pstart,pstart+pwin)
                    
            # check for user aborts
            check_message_queue()
            
            # create header text
            head = StringIO()
            head.write('! TestDate: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
            head.write('! Drain Max Voltage = %g V\n'%vdmax)
            head.write('! Imax Droop Drain Voltage = %g V\n'%vd_for_droop)
            head.write('! Probe Offsets (cal set 1):\n')
            _write_header_probe_offsets(head,'!    Vg[%g] = %g V\n',cal_data1,'vg')
            _write_header_probe_offsets(head,'!    Vd[%g] = %g V\n',cal_data1,'vd')
            _write_header_probe_offsets(head,'!    Id[%g] = %g mA\n',cal_data1,'id',1000.0)
            _write_header_probe_offsets(head,'!    Ig[%g] = %g mA\n',cal_data1,'ig',1000.0)
            head.write('! Probe Offsets (cal set 2):\n')
            _write_header_probe_offsets(head,'!    Vg[%g] = %g V\n',cal_data2,'vg')
            _write_header_probe_offsets(head,'!    Vd[%g] = %g V\n',cal_data2,'vd')
            _write_header_probe_offsets(head,'!    Id[%g] = %g mA\n',cal_data2,'id',1000.0)
            _write_header_probe_offsets(head,'!    Ig[%g] = %g mA\n',cal_data2,'ig',1000.0)
            head_str = head.getvalue()
            head.close()
            
            # open and write headers in I-V data file
            fp = open(iv_fname,'w')
            fp.write('!$$version: 2\n')
            fp.write('! Pulsed Imax Droop Test\n!\n')
            fp.write(head_str+'!\n')
            send_to_ui('ivfile',iv_fname)
                        
            ### start the measurement loop ###
            
            logger.info('starting I-max droop measurements ...')
            idsdata1, idsdata2 = [], []
            vdsdata1, vdsdata2 = [], []
            for i in range(2):
                idx = 0
                last_vd = vd_list[0]
                if not i:
                    # first Q-point
                    vgq, vdq = vgq1, vdq1
                    cal_data = cal_data1
                    soak_time = soak1
                    idsdata = idsdata1
                    vdsdata = vdsdata1
                else:
                    # second Q-point
                    vgq, vdq = vgq2, vdq2
                    cal_data = cal_data2
                    soak_time = soak2
                    idsdata = idsdata2
                    vdsdata = vdsdata2
                    
                # set the drain voltage measurement up in the range than makes sense
                if vd_probe:
                    if vd_list[0] <= vdmin:
                        cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmin)
                    else:
                        cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmax)
                    
                # set the Q-point
                pulser.set_voltage(vg=vg_pulse,vgq=vgq,vd=vd_list[0],vdq=vdq)
                pulser.enable()
                pulser_off = False
                
                # let the Q-point soak
                if soak_time > 0.0:
                    logger.info("waiting for Q-point %d soak time (%g seconds)"%(i+1,soak_time))
                    _wait_for_delay(soak_time)
                
                # measure q-point
                qppoint_data = _measure(instruments,parameters,cal_data)
                idq_initial = qppoint_data['idq']*id_scale
                vgq_meas = qppoint_data.get('vgq',0.0)
                vdq_meas = qppoint_data.get('vdq',0.0)
                    
                fp.write('! **** CURVE %d ****\n'%(i+1))
                fp.write('! Q-Point:\n')
                fp.write('!    Vg = %g V (meas: %g V)\n'%(vgq,vgq_meas))
                fp.write('!    Vd = %g V (meas: %g V)\n'%(vdq,vdq_meas))
                fp.write('!    Id = %g mA\n'%(idq_initial*1000.0))
                fp.write('!\n!-----------------------------------------------------------------------------\n')
                fp.write('!Index\tVg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_meas[A]\tIg_meas[A]\n')
                    
                logger.info('measuring curve: Vg-q = %g, Vd-q = %g (%d of 2)'%(vgq,vdq,i+1))
                
                for vd in vd_list:
                
                    # check for pause messages and user aborts
                    check_message_queue()
                                
                    # set the pulser voltages
                    pulser.set_voltage(vg=vg_pulse,vd=vd)
                    
                    # allow the system to settle
                    vd_delta = abs(last_vd - vd)
                    timed_wait_ms(200+vd_delta*1000/vd_slew_rate)
                    last_vd = vd
                    
                    # set the vd_probe scaling
                    if vd_probe:
                        if vd <= vdmin:
                            cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmin)
                        else:
                            cal_data['vd_idx'] = vd_probe.set_best_scale(0.0,vdmax)
                    
                    # measure all probes
                    data = _measure(instruments,parameters,cal_data)
                    id_meas = data['id']*id_scale
                    ig_meas = data.get('ig',0.0)*ig_scale
                    if 'vd' in data:
                        pcalc = data['vd']*id_meas
                    else:
                        pcalc = vd*id_meas
                    idsdata.append(id_meas)
                    vdsdata.append(data.get('vd',vd))
                                            
                    # check power limit
                    plimit = _calc_power_limit(parameters,vd)
                    if pcalc > plimit:
                        break
                    
                    # write the I-V data
                    fp.write('%d\t%.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(idx,vg_pulse,vd,data.get('vg',0.0),data.get('vd',0.0),id_meas,ig_meas))
                    fp.flush()
                                        
                    idx += 1
                
                # shut down pulser
                pulser.safe_stepdown(vg_pulse,vd_list[0])                
                pulser.disable()
                pulser_off = True
                fp.write('\n')
                
                if not i:
                    delay_time = parameters['imax_delay']
                    if delay_time < 0.5:
                        # put in a small delay if none exists
                        delay_time = 0.5
                    logger.info("waiting for delay time between sweeps (%g seconds)"%delay_time)
                    _wait_for_delay(delay_time)
            
            # compute the droop from the 2 Ids/Vds data sets
            try:
                ids1 = _get_ids_interpolate(idsdata1,vdsdata1,vd_for_droop)
                ids2 = _get_ids_interpolate(idsdata2,vdsdata2,vd_for_droop)
                if ids1 < ids2:
                    droop = (1.0 - ids1/ids2)*100.0            
                else:
                    droop = (1.0 - ids2/ids1)*100.0
                
                fp.write('\n')
                fp.write('! CALCULATED IMAX DROOP (%%): %g\n'%droop)            
            except Exception as e:
                logger.warning('unable to compute Imax droop -> {}'.format(e))
            
            logger.info('Imax droop measurement complete.')
        except UserAbort:
            logger.warning('exiting on user abort ...')
    finally:
        if not pulser_off:
            try:
                pulser.safe_stepdown(vg_pulse,vd_list[0])
                pulser.disable()
            except Exception as e:
                logger.warning('could not run pulser safe shutdown routine -> %s'%e)
        
        # close all open files
        if fp:
            fp.close()
            
        # unload all instruments
        _unload_instruments(instruments)
        
def manual_mode_main(instr_list, parameters):
    "main entry point for manual mode pulsed I-V setup"
    ig_scale = parameters['gate_iscale']
    id_scale = parameters['drain_iscale']
    
    # load instruments
    logger.info("Loading instruments ...")
    reqd_instr = ['pulser','vd_lo','vd_hi','id_probe']
    opt_instr = ['ig_probe','vg_probe','vd_probe','pna']
    instruments = _load_instruments(instr_list,reqd_instr,opt_instr)
    pulser = instruments['pulser']
    
    try:
        # configure the pulser
        pulser.setup_supplies(instruments['vd_lo'],instruments['vd_hi'])
        pwid, pper, vg_vd_offs = _check_pulse_params(parameters['pulse_width'],parameters['pulse_period'],parameters['vgs_vds_offset'])
        pulser.set_timing(pwid,pper,vg_vd_offs)
        pulser.config(swap_timing=parameters['swap_timing'])
        
        # set drain current limits  
        instruments['vd_lo'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
        instruments['vd_hi'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
        
        # position the markers on the scope
        pstart = parameters['pwin_start']*1.0e-6
        pwin = parameters['pwin_width']*1.0e-6
        instruments['id_probe'].set_marker_position(pstart,pstart+pwin)
        
    except Exception:
        _unload_instruments(instruments)
        raise
    
    # everything is ready, send a message to the UI
    send_to_ui('ready')
    logger.info("Manual mode ready.")
    pulser_enabled = False
    try:
        try:
            while True:
                # wait for commands
                msg = get_next_message()
                msgtype = msg.msgtype
                
                if msgtype == 'quit':
                    if pulser_enabled:
                        pulser.disable()
                    break
                elif msgtype == 'enable':
                    data = msg.data
                    if 'vg' in data:
                        if data['vg'] < -10.0 or data['vg'] > 10.0:
                            raise ValueError("'vg' must fall in the range -10 <= vg <= 10")
                    if 'vgq' in data:
                        if data['vgq'] < -10.0 or data['vgq'] > 10.0:
                            raise ValueError("'vgq' must fall in the range -10 <= vgq <= 10")
                    if 'vd' in data:
                        if data['vd'] < 0.0 or data['vd'] > 80.0:
                            raise ValueError("'vd' must fall in the range 0 <= vd <= 80")
                    if 'vdq' in data:
                        if data['vdq'] < 0.0 or data['vdq'] > 80.0:
                            raise ValueError("'vdq' must fall in the range 0 <= vdq <= 80")
                    pulser_enabled = True
                    pulser.set_voltage(**data)
                    pulser.enable()
                    send_to_ui('ack')
                elif msgtype == 'disable':
                    pulser_enabled = False
                    pulser.disable()
                    send_to_ui('ack')
                elif msgtype == 'measure':
                    data = _measure(instruments,parameters,autoscale=False)
                    data['id'] *= id_scale
                    data['idq'] *= id_scale
                    if 'ig' in data:
                        data['ig'] *= ig_scale
                        data['igq'] *= ig_scale
                    send_to_ui('measured',data)
                    
        except Exception:
            raise
    finally:
        _unload_instruments(instruments)

    logger.info("Manual mode exit.")
        
def calibrate_main(instr_list, parameters):
    "calibration entry point"
    
    # load instruments
    logger.info("Loading instruments ...")
    reqd_instr = ['pulser','vd_lo','vd_hi','id_probe']
    opt_instr = ['ig_probe','vg_probe','vd_probe']
    instruments = _load_instruments(instr_list,reqd_instr,opt_instr)
    pulser = instruments['pulser']
    
    try:
        # configure the pulser
        pulser.setup_supplies(instruments['vd_lo'],instruments['vd_hi'])
        pwid, pper, vg_vd_offs = _check_pulse_params(parameters['pulse_width'],parameters['pulse_period'],parameters['vgs_vds_offset'])
        pulser.set_timing(pwid,pper,vg_vd_offs)
        pulser.config(swap_timing=parameters['swap_timing'])
        
        # set drain current limits  
        instruments['vd_lo'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
        instruments['vd_hi'].config(ilimit=parameters['drain_ilimit']*parameters['periphery']*1.0e-3)
        
        # position the markers on the scope
        pstart = parameters['pwin_start']*1.0e-6
        pwin = parameters['pwin_width']*1.0e-6
        instruments['id_probe'].set_marker_position(pstart,pstart+pwin)
        
    except Exception:
        _unload_instruments(instruments)
        raise
    
    # run the cal routine and send the data back to the
    # main window
    try:
        try:
            caldata = _calibrate_measurements(instruments,parameters)
            send_to_ui("cal_data",caldata)
            # give the UI time to receive the "cal_data" message
            # otherwise it might get the WorkerExit signal first
            # which will put it into an invalid state
            time.sleep(1.0)
        except Exception:
            raise
    finally:
        _unload_instruments(instruments)
    logger.info("Calibration complete.")

_rad2deg = 180.0/math.pi        
def _angle( x ):
    "compute the angle of a complex number"
    try:
        return math.atan2(x.imag,x.real)*_rad2deg
    except ValueError:
        return 0.0
    
def _load_instruments( instr_list, required=[], optional=[] ):
    "load all instruments and return them in a dictionary"
    
    intr = list(set(required).intersection(optional))
    if len(intr):
        raise ValueError("duplicate instrument names exist in `required` and `optional`: %s"%(', '.join(intr)))
    
    out = {}
    tmp = {}
    for instr in instr_list:
        tmp[instr.name] = instr 
                
    try:
        for name in required:
            if name not in tmp:
                raise ValueError("no definition for instrument '%s'"%name)
                
            try:
                logger.debug("attempting to load instrument '%s'"%name)
                out[name] = tmp[name].open_instrument()
                if out[name] is None:
                    raise ValueError('not configured')
            except Exception as e:
                 raise InstrumentLoadError("could not load required instrument '%s' -> %s"%(tmp[name].label,e))
        
        for name in optional:
            if name not in tmp:
                out[name] = None
            else:
                try:
                    logger.debug("attempting to load instrument '%s' (optional)"%name)
                    out[name] = tmp[name].open_instrument()
                except Exception:
                    # optional instruments do not need to be loaded successfully
                    out[name] = None
                    logger.debug("instrument '%s' could not be loaded"%name)
    except Exception:
        # unload instruments when exceptions occur during loading
        _unload_instruments(out)
        raise
    
    return out

def _unload_instruments( instr_dict ):
    "unload instruments, all errors are logged but ignored"
    # unload the pulser first
    logger.debug("unloading instrument 'pulser'")
    try:
        instr_dict['pulser'].close()
    except Exception as e:
        logger.warning("when unloading instrument 'pulser' -> {}".format(e))

    # unload the rest
    for k in instr_dict:
        if k == 'pulser':
            continue
        i = instr_dict[k]
        if i:
            logger.debug("unloading instrument '%s'"%k)
            try:
                i.close()
            except Exception as e:
                logger.warning("when unloading instrument '{}' -> {}".format(k,e))

def _calc_power_limit(parameters, vd):
    "calculate the power limit in Watts"
    periph = parameters['periphery']
    v12 = parameters['plimit_r12_v']
    v23 = parameters['plimit_r23_v']
    
    if vd <= v12:
        plim = parameters['plimit_r1']*periph*1.0e-3
    elif vd <= v23:
        plim = parameters['plimit_r2']*periph*1.0e-3    
    else:
        plim = parameters['plimit_r3']*periph*1.0e-3
    
    if plim <= 0.0:
        # no power limit
        plim = 10000.0
        
    return plim
                
def _compute_vg_vd_min_max(parameters):
    "compute vgmin, vgmax, vdmin, vdmax"
    vgmin = min(parameters['vg_list'])
    vgmin = min(vgmin,parameters['gate_q'])
    vgmax = max(parameters['vg_list'])
    vgmax = max(vgmax,parameters['gate_q'])
    vdmax = max(parameters['vd_list'])
    vdmax = max(vdmax,parameters['drain_q'])
    # use 5 volts as the min value for vdmin
    # no point in calibrating smaller ranges
    vdmin = max(parameters['drain_q'],5.0)
    if vdmax < vdmin:
        vdmax = vdmin
    return vgmin, vgmax, vdmin, vdmax
    
def _get_ids_interpolate(idsl, vdsl, vds_tgt):
    "get the ids value corresponding to vds_tgt"
    if len(idsl) != len(vdsl):
        raise ValueError("Ids and Vds data lists are not the same length")
    
    for i in range(1,len(vdsl)):
        if vdsl[i-1] <= vds_tgt and vdsl[i] >= vds_tgt:
            # found the brackets
            if vdsl[i-1] == vds_tgt:
                return idsl[i-1]
            elif vdsl[i] == vds_tgt:
                return idsl[i]
            else:
                # interpolate
                return idsl[i-1] + (idsl[i]-idsl[i-1])*((vds_tgt-vdsl[i-1]))/((vdsl[i]-vdsl[i-1]))
                
    raise ValueError("could not interpolte data (target Vds not in data range)")

def _wait_for_delay(seconds):
    "wait for a cetain number of seconds (floating point)"
    tcurr = time.time()
    tend = tcurr + seconds 
    while tcurr < tend:
        diff = tend - tcurr
        if diff < 0.005:
            break
        time.sleep(diff)
        tcurr = time.time()
    
def _calibrate_measurements(instruments, parameters):
    "do the calibration steps to get the offsets for the measurements"
    cal = {}
    
    qstart = parameters['qwin_start']*1.0e-6
    qwid = parameters['qwin_width']*1.0e-6
    pstart = parameters['pwin_start']*1.0e-6
    pwid = parameters['pwin_width']*1.0e-6
    
    # number of times the measurement is repeated and averaged
    averages = parameters['cal_averages']
    
    # ensure that the pulser is disabled (it should be)
    pulser = instruments['pulser']
    pulser.disable()
    
    vgmin, vgmax, vdmin, vdmax = _compute_vg_vd_min_max(parameters)
    
    # set up the Vg probe and measure its calibration offset
    cal['vgmin'] = vgmin
    cal['vgmax'] = vgmax
    cal['vg_calibrated'] = False
    if instruments['vg_probe']:
        logger.info("calibrating Vg ...")
        p = instruments['vg_probe']
        cal['vg'] = {}
        i = p.set_best_scale(vgmin,vgmax)
        offs = 0.0
        for _a in range(averages):
            p.trigger()
            offs += _get_measure_cal(p,qstart,qwid,pstart,pwid,'vg',None,False)[1]
        offs /= float(averages)
        cal['vg'][i] = {
            'offset':offs,
            'scale':p.get_y_scale(),
            'position':p.get_y_offset(),
        }
        cal['vg_idx'] = i
        cal['vg_calibrated'] = True

    # set up the Vd probe and measure its calibration offsets
    # there can be more than one range for Vd depending on
    # the I-V curve sweep settings
    cal['vdmin'] = vdmin
    cal['vdmax'] = vdmax
    cal['vd_calibrated'] = False
    cal['vdq'] = parameters['drain_q']
    if instruments['vd_probe']:
        logger.info("calibrating Vd ...")
        p = instruments['vd_probe']
        cal['vd'] = {}
        i = p.set_best_scale(0.0,vdmin)
        j = p.set_best_scale(0.0,vdmax)
        if parameters['force_vd_thru_zero'] and instruments['id_probe']:
            # forcing Vd thru 0, compute a slope between 2 measure Vd values to
            # calculate where the zero offset lies
            p_id = instruments['id_probe']
            vd1 = parameters['vd_zero_cal1']
            vd2 = parameters['vd_zero_cal2']
            pulser.set_voltage(vg=0.0,vgq=parameters['cal_gate_v'],vd=0.0,vdq=parameters['drain_q'])
            pulser.enable()
            for idx in range(i,j+1):
                p.set_y_scale_index(idx)   
                p.set_y_offset(0.45*p.get_y_fullscales()[idx])
                
                pulser.set_voltage(vg=0.0,vgq=parameters['cal_gate_v'],vd=vd1,vdq=parameters['drain_q'])
                vdoffs = 0.0
                idoffs = 0.0
                for _a in range(averages):
                    p.trigger()
                    p_id.trigger()
                    vdoffs += _get_measure_cal(p,qstart,qwid,pstart,pwid,'vd',None,False)[1]
                    idoffs += _get_measure_cal(p_id,qstart,qwid,pstart,pwid,'id',None,False)[1]
                vdoffs /= float(averages)
                idoffs /= float(averages)
                
                pulser.set_voltage(vg=0.0,vgq=parameters['cal_gate_v'],vd=vd2,vdq=parameters['drain_q'])
                vdoffs2 = 0.0
                idoffs2 = 0.0
                for _a in range(averages):
                    p.trigger()
                    p_id.trigger()
                    vdoffs2 += _get_measure_cal(p,qstart,qwid,pstart,pwid,'vd',None,False)[1]
                    idoffs2 += _get_measure_cal(p_id,qstart,qwid,pstart,pwid,'id',None,False)[1]
                vdoffs2 /= float(averages)
                idoffs2 /= float(averages)
                
                slope = (idoffs2 - idoffs) / (vdoffs2 - vdoffs)
                yint = idoffs - slope*vdoffs
                
                cal['vd'][idx] = {
                    'offset':-yint/slope,
                    'scale':p.get_y_scale(),
                    'position':p.get_y_offset(),
                }
            
            pulser.disable()
    
        else:
            # not forcing Vd thru 0, measure a simple offset instead
            for idx in range(i,j+1):
                p.set_y_scale_index(idx)   
                p.set_y_offset(0)
                offs = 0.0
                for _a in range(averages):
                    p.trigger()
                    offs += _get_measure_cal(p,qstart,qwid,pstart,pwid,'id',None,False)[1]
                offs /= float(averages)
                cal['vd'][idx] = {
                    'offset':offs,
                    'scale':p.get_y_scale(),
                    'position':p.get_y_offset(),
                }    
                    
        # set the range back to the initial setting
        cal['vd_idx'] = p.set_best_scale(0.0,vdmin)
        cal['vd_calibrated'] = True
    
    # set up the Ig probe and measure its calibration offsets
    # measure all ranges up to 5x the gate_ilimit
    max_ig = parameters['gate_ilimit']*parameters['periphery']*5.0e-6
    cal['igmax'] = max_ig
    cal['ig_calibrated'] = False
    if instruments['ig_probe']:
        logger.info("calibrating Ig ...")
        p = instruments['ig_probe']
        p.set_y_offset(0)
        ranges = p.get_y_fullscales()
        cal['ig'] = {}
        for i,r in enumerate(ranges):
            if r > max_ig:
                break
            p.set_y_fullscale(r)
            offs = 0.0
            for _a in range(averages):
                p.trigger()
                offs += _get_measure_cal(p,qstart,qwid,pstart,pwid,'ig',None,False)[1]
            offs /= float(averages)
            cal['ig'][i] = {
                'offset':offs,
                'scale':p.get_y_scale(),
                'position':p.get_y_offset(),
            }
            
        # set the range back the range 0
        cal['ig_idx'] = p.set_best_scale(0.0,0.0)
        cal['ig_calibrated'] = True
        
    # set up the Id probe and measure its calibration offsets
    # measure all ranges up to 5x the drain_ilimit
    max_id = parameters['drain_ilimit']*parameters['periphery']*5.0e-6
    cal['idmax'] = max_id
    cal['id_calibrated'] = False
    if instruments['id_probe']:
        logger.info("calibrating Id ...")
        p = instruments['id_probe']
        p.set_y_offset(0)
        ranges = p.get_y_fullscales()
        
        if parameters['cal_id_on_state']:
            # do another calibration with the pulser on
            vgset = parameters['cal_gate_v']
            pulser.set_voltage(vg=vgset,vgq=vgset,vd=0.0,vdq=parameters['drain_q'])
            pulser.enable()
            
        cal['id'] = {}
        for i,r in enumerate(ranges):
            if r > max_id:
                break            
            p.set_y_fullscale(r)
            offs = 0.0
            for _a in range(averages):
                p.trigger()
                offs += _get_measure_cal(p,qstart,qwid,pstart,pwid,'id',None,False)[1]
            offs /= float(averages)
            cal['id'][i] = {
                'offset':offs,
                'scale':p.get_y_scale(),
                'position':p.get_y_offset(),
            }
            
        # set the range back the range 0
        cal['id_idx'] = p.set_best_scale(0.0,0.0)
        cal['id_calibrated'] = True
                            
    return cal
    
def _target_qpoint(instruments, parameters, cal_data=None):
    "target the Q-point"
    mn, mx = parameters['gate_q_min'], parameters['gate_q_max']
    target = parameters['drain_q_ids']*parameters['periphery']*1.0e-6
    vg = parameters['gate_q']
    id_scale = parameters['drain_iscale']
    
    if mn >= mx:
        raise ValueError("'gate_q_min' >= 'gate_q_max'")
    
    # target acceptable error, use 2%, but don't try to get closer than 1 mA
    # due to the resolution issues with the pulsed I-V system
    target_err = target*0.02
    if target_err < 0.001:
        target_err = 0.001
    
    logger.info('attempting to hit Q-point target = %g mA'%(target*1000.0))
    
    pulser = instruments['pulser']
        
    # measure the initial current
    idm = _measure(instruments,parameters,cal_data,measure=('id',))['idq']*id_scale
    
    # set initial step
    step = (mx - mn)*0.1
    if idm > target:
        step = -step
    
    n = 0
    while n < 20:    
        # check for limits
        if step > 0.0 and vg == mx:
            logger.warning("target_qpoint(): hit upper Vg limit")
            break
        elif step < 0.0 and vg == mn:
            logger.warning("target_qpoint(): hit lower Vg limit")
            break
        
        # change vg and re-measure
        vg += step
        if vg < mn:
            vg = mn
        elif vg > mx:
            vg = mx        
        pulser.set_voltage(vgq=vg)
        
        # measure the new current
        idm = _measure(instruments,parameters,cal_data,measure=('id',))['idq']*id_scale
        
        # see if we hit the target
        if abs(idm-target) <= target_err:
            break
            
        # if we overshoot target then reverse the step and cut it by a factor of 4
        if (idm > target and step > 0.0) or (idm < target and step < 0.0):
            step *= -0.25        
                
        n += 1
    
    if abs(idm-target) > target_err:
        logger.warning('could not hit Q-point target: Id-q(actual) = %g mA, Id-q(target) = %g mA, Vg-q = %g V'%(idm*1000.0,target*1000.0,vg))    
    else:
        logger.info('Q-point target result: Vg-q = %g, Id-q = %g mA'%(vg,idm*1000.0))
        
    return vg

def _measure(instruments, parameters, cal_coeffs=None, autoscale=True, measure=_default_measurements, save_waveforms=False):
    "measure voltage and currents"
    d = {}
    
    qstart = parameters['qwin_start']*1.0e-6
    qwid = parameters['qwin_width']*1.0e-6
    pstart = parameters['pwin_start']*1.0e-6
    pwid = parameters['pwin_width']*1.0e-6
    
    # first trigger a measurement on all measurement instruments
    unique_instr = set()
    for instr in [instruments['vd_probe'], instruments['vg_probe'], instruments['ig_probe'], instruments['id_probe']]:
        if instr and instr.vi_session and instr.vi_session not in unique_instr:
            unique_instr.add(instr.vi_session)
            instr.trigger()
    
    # measure vd, vdq, vg, and vgq (if their instruments exist)
    
    if instruments['vd_probe'] and 'vd' in measure:
        d['vdq'], d['vd'], d['vd_x'], d['vd_y'] = _get_measure_cal(instruments['vd_probe'],qstart,qwid,pstart,pwid,'vd',cal_coeffs,save_waveforms)
    
    if instruments['vg_probe'] and 'vg' in measure:
        d['vgq'], d['vg'], d['vg_x'], d['vg_y'] = _get_measure_cal(instruments['vg_probe'],qstart,qwid,pstart,pwid,'vg',cal_coeffs,save_waveforms)
    
    # measure id and idq, autoscaling if it is allowed
    if instruments['id_probe'] and 'id' in measure:
        if autoscale:
            d['idq'], d['id'], d['id_x'], d['id_y'] = _get_measure_cal_auto(instruments['id_probe'],qstart,qwid,pstart,pwid,'id',cal_coeffs,save_waveforms)
        else:
            d['idq'], d['id'], d['id_x'], d['id_y'] = _get_measure_cal(instruments['id_probe'],qstart,qwid,pstart,pwid,'id',cal_coeffs,save_waveforms)
    
    # measure ig and igq, autoscaling if it is allowed
    if instruments['ig_probe'] and 'ig' in measure:
        if autoscale:
            d['igq'], d['ig'], d['ig_x'], d['ig_y'] = _get_measure_cal_auto(instruments['ig_probe'],qstart,qwid,pstart,pwid,'ig',cal_coeffs,save_waveforms)
        else:
            d['igq'], d['ig'], d['ig_x'], d['ig_y'] = _get_measure_cal(instruments['ig_probe'],qstart,qwid,pstart,pwid,'ig',cal_coeffs,save_waveforms)
    
    return d


def _get_measure_cal(probe, qstart, qwid, pstart, pwid, parm, cal, save_waveforms):
    "do all the common stuff related to reading and measuring the waveform data"
    x, y = probe.get_waveform()
    
    # compute the window edges
    if x[0] > qstart:
        # qpoint leading edge falls outside of the waveform range, so
        # make it start at the leading edge of the waveform
        q1, q2 = x[0], x[0]+qwid
    else:
        q1, q2 = qstart, qstart+qwid
    p1, p2 = pstart, pstart+pwid
    
    # average the q and p measurements over the points that fall in
    # their respective ranges
    p, q = 0.0, 0.0
    pc, qc = 0, 0
    for i in range(len(x)):
        if q1 <= x[i] <= q2:
            q += y[i]
            qc += 1
        if p1 <= x[i] <= p2:
            p += y[i]
            pc += 1
    
    if qc > 1:
        q /= float(qc)
    if pc > 1:
        p /= float(pc)
        
    if cal and parm in cal:
        # apply calibration coefficients
        try:
            offset = cal[parm][cal[parm+'_idx']]['offset']
            q -= offset
            p -= offset
            if save_waveforms:
                for i in range(len(y)):
                    y[i] -= offset
        except Exception:
            logger.debug("could not apply cal coeff for '%s' due to error with cal_coeffs dict"%parm.title())
            
    if save_waveforms:
        return q, p, x, y
    else:
        return q, p, None, None
    
def _get_measure_cal_auto(probe, qstart, qwid, pstart, pwid, parm, cal, save_waveforms):
    "do all the common stuff related to reading and measuring the waveform data w/ autoscaling"
    track_scale_index = False
    if cal and parm in cal and parm+'_idx' in cal:
        track_scale_index = True
    
    # get the initial measurement
    q, p, x, y = _get_measure_cal(probe,qstart,qwid,pstart,pwid,parm,cal,save_waveforms)
    
    ranges = set()
    # get the best fit range from the probe
    i = probe.set_best_scale(0.0,max(p,q))
    ranges.add(i)
    if track_scale_index:
        cal[parm+'_idx'] = i
    
    n = 0
    while n < 4:
        # trigger and measure again
        probe.trigger()
        q, p, x, y = _get_measure_cal(probe,qstart,qwid,pstart,pwid,parm,cal,save_waveforms)
        # get the best range again
        i = probe.set_best_scale(0.0,max(p,q))
        if i in ranges:
            # already had a measurement at this range
            # use this range as the right one
            if track_scale_index:
                cal[parm+'_idx'] = i
            break
        else:                
            ranges.add(i)   
            if track_scale_index:
                cal[parm+'_idx'] = i
        
        n += 1
    
    return q, p, x, y
    
def _gmgds_sub(instruments, parameters, vg, vd):
    "measure gm and gds by iterating around the current measurement point"
    gm_del = abs(parameters['gm_delta_v'])
    gds_del = abs(parameters['gds_delta_v'])
    id_scale = parameters['drain_iscale']
    pulser = instruments['pulser']
    
    # measure gm by doing a 2-sided delta around the current measurement
    pulser.set_voltage(vg=vg-gm_del)
    d = _measure(instruments,parameters,autoscale=False,measure=('vg','id'))
    id1, vg1 = d['id'], d.get('vg',vg-gm_del)
    pulser.set_voltage(vg=vg+gm_del)
    d = _measure(instruments,parameters,autoscale=False,measure=('vg','id'))
    id2, vg2 = d['id'], d.get('vg',vg+gm_del)
    pulser.set_voltage(vg=vg)
    
    if abs(vg2-vg1) < 1.0e-7:
        gm = 0.0
    else:
        gm = (id2-id1)*id_scale/(vg2-vg1)
    
    # measure gds by doing a 2-sided delta around the current measurement
    # unless vd is very close to 0, in which case only do a 1-side measurement
    if vd < gds_del + 0.1:
        vds1, vds2 = vd, vd+gds_del
    else:
        vds1, vds2 = vd-gds_del, vd+gds_del
        
    pulser.set_voltage(vd=vds1)
    d = _measure(instruments,parameters,autoscale=False,measure=('vd','id'))
    id1, vd1 = d['id'], d.get('vd',vds1)
    pulser.set_voltage(vd=vds2)
    d = _measure(instruments,parameters,autoscale=False,measure=('vd','id'))
    id2, vd2 = d['id'], d.get('vd',vds2)
    pulser.set_voltage(vd=vd)
    
    if abs(vd2-vd1) < 1.0e-7:
        gds = 0.0
    else:
        gds = (id2-id1)*id_scale/(vd2-vd1)
    
    return gm, gds
   
   
def _check_pulse_params( width, period, vg_vd_offset ):
    "check pulse parameters to be sure they are legal"
    if width < 0.3:
        width = 0.3
        logger.warning('invalid pulse width -> set to 0.3 us')
    elif width > 36.0:
        width = 36.0
        logger.warning('invalid pulse width -> set to 36 us')
    
    if period < width + 36.0:
        period = width + 36.0
        logger.warning('invalid pulse period -> set to %g us'%period)
    elif period > 2200.0:
        period = 2200.0
        logger.warning('invalid pulse period -> set to 2200 us')
    
    if vg_vd_offset < -5.0:
        vg_vd_offset = -5.0
        logger.warning('invalid vg to vd timing offset value -> set to -5 us')
    elif vg_vd_offset > 0.5*(width-0.3):
        vg_vd_offset = 0.5*(width-0.3)
        logger.warning('invalid vg to vd timing offset value -> set to %g us'%vg_vd_offset)
    
    return width, period, vg_vd_offset
    
def _write_header_probe_offsets(fp, fmt, cal_data, parm, scale=1.0):
    "write probe offsets into the header"
    if cal_data and parm in cal_data:
        d = cal_data[parm]
        range_idx = d.keys()
        range_idx.sort()
        for r in range_idx:
            fp.write(fmt%(d[r]['scale'],d[r]['offset']*scale))
    
def _write_waveform_data(fp, idx, vg, vd, data, idsc, igsc):
    "write waveform data to the data file"
    fp.write('!INDEX: %d\n'%idx)
    fp.write('!VG: %g V\n!VD: %g V\n'%(vg,vd))
    fp.write('!Vg_x(s)\tVg_y(V)\tVd_x(s)\tVd_y(V)\tId_x(s)\tId_y(A)\tIg_x(s)\tIg_y(A)\n')
    
    # load the waveforms
    vgn, vdn, ign, idn = -1, -1, -1, -1
    if data.get('vg_x',None) is not None:
        vgx = data['vg_x']
        vgy = data['vg_y']
        vgn = len(vgx)
    if data.get('vd_x',None) is not None:
        vdx = data['vd_x']
        vdy = data['vd_y']
        vdn = len(vdx)
    if data.get('ig_x',None) is not None:
        igx = data['ig_x']
        igy = data['ig_y']
        ign = len(igx)
    if data.get('id_x',None) is not None:
        idx = data['id_x']
        idy = data['id_y']
        idn = len(idx)
    
    # write data
    i = 0
    while True:
        wrote_data = False
        out = []
        if i < vgn:
            out.append('{:g}'.format(vgx[i]))
            out.append('{:g}'.format(vgy[i]))
            wrote_data = True
        else:
            out.extend(['-','-'])
            
        if i < vdn:
            out.append('{:g}'.format(vdx[i]))
            out.append('{:g}'.format(vdy[i]))
            wrote_data = True
        else:
            out.extend(['-','-'])
        
        if i < idn:
            out.append('{:g}'.format(idx[i]))
            out.append('{:g}'.format(idy[i]*idsc))
            wrote_data = True
        else:
            out.extend(['-','-'])
        
        if i < ign:
            out.append('{:g}'.format(igx[i]))
            out.append('{:g}'.format(igy[i]*igsc))
            wrote_data = True
        else:
            out.extend(['-','-'])
        
        if wrote_data:
            fp.write('\t'.join(out)+'\n')
        else:
            break

        i += 1
    
