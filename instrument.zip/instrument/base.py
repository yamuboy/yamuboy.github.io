from __future__ import division, print_function, unicode_literals, absolute_import
import re, weakref, warnings

from .errors import InstrumentError, DriverNotFound, InvalidDriver, VisaError, VisaIOError
from .visa_library import open_resource, parse_resource_name
from .utils import is_integer, timed_wait_ms
from .logger import logger

from . import _str_type

# keywords that are used by the pyVISA subsystem
_visakw = ('timeout','chunk_size','values_format','term_char','send_end',
    'delay','lock','baud_rate','data_bits','stop_bits','parity')

def set_global_visa_debugging( f=True ):
    """turn global VISA debugging on/off - not used anymore
    """
    # not used anymore
    pass

def create( cls, driver, rsc_string=None, **kwargs ):
    """Create a new instrument object.  The primary purpose of this function
    is to provide a consistent wrapper to create instrument objects rather than
    having to create them directly.
    
    Arguments:
    cls - (string or type object) the instrument class/family (can also be None to
       search solely based on the driver name).
    driver - (string) the name of the driver that implements the instrument-specific
      backend calls to perform instrument operations.
    rsc_string - (string) the VISA resource string, if this is None then virtually all
      instrument-related calls to the created object will fail.
    
    Keywords:    
     All keywords are VISA and instrument specific.
      
    This function can raise errors if the cls argument is invalid, the driver
    cannot be located, or the resource string is invalid or a VISA resource cannot
    be created.  The instrument driver may also raise errors during creation due
    to the driver not being handle the instrument it's connected to or due to
    other communication/interfacing issues
    """
    return InstrumentManager().open_driver(cls,driver,rsc_string,**kwargs)

def driver( cls, driver ):
    """Retrieve the type object for an instrument
    
    Arguments:
    cls - (string or type object) the instrument class/family (can also be None to
       search solely based on the driver name).
    driver - (string) the name of the driver that implements the instrument-specific
      backend calls to perform instrument operations.
    
    This function can raise errors if the cls argument is invalid or the driver
    cannot be located.
    """
    return InstrumentManager().get_driver(cls,driver)
    
    
class BasicInstrument(object):
    """Base class for all instruments.
    
    ** This class is ONLY to be used as a base class for the
    ** GenericInstrument class.  It should not be used as a base class
    ** for any instrument drivers directly.
    """
    _log = logger
    
    def __init__(self,resource_name,**kwargs):
        """Initializer. Opens the VISA interface object.
        
        Arguments:
        resource_name - string, the VISA resource name for the instrument.
           This can also be None, though this will not open a VISA interface (VI)
           and any call that depends on the existance of the VI will fail.
           
        Keywords:
        name - string, set the instrument driver name. This is a convenience
          that can be useful for debugging.
        visa_debug - bool, enable VISA debugging on this object
        
        All pyVISA keywords are stored for use in initializing the VI.
        """
        if type(self) is BasicInstrument:
            raise TypeError("`BasicInstrument` is an abstract class and cannot be instanciated")
        
        # set properties
        self.__vi = None
        self.__name = '{}'.format(kwargs.pop('name',''))
        visa_debug = bool(kwargs.pop('visa_debug',False))
        
        # store VISA-specific keywords, ignore all others (but generate a warning)
        self.__visa_kwargs = dict()
        for k in kwargs:
            if k in _visakw:
                self.__visa_kwargs[k] = kwargs[k]
            else:
                warnings.warn("invalid keyword '%s'"%k)
        
        if isinstance(resource_name,_str_type) and len(resource_name):
            # open a VISA interface object for this instrument
            try:
                self.__vi = InstrumentManager().open_vi(resource_name,**self.__visa_kwargs)
            except VisaIOError as ex:
                # raise a different error
                raise InstrumentError("VISA I/O error for '{}' => {}".format(resource_name,ex))
            
            if visa_debug:
                # enable VISA debugging
                self._enable_visa_debugging(True)
        
        # store this instrument object in the instrument manager
        InstrumentManager()._register_instr(self)
    
    @property
    def vi(self):
        "pyVISA interface"
        return self.__vi
        
    @property
    def vi_session(self):
        "get the raw vi session handle, or return None"
        if self.__vi:
            try:
                return self.__vi.session
            except AttributeError:
                # old version of pyvisa
                return self.__vi.vi
        else:
            return None
    
    def _getname(self):
        """Get the instrument name."""
        return self.__name
    def _setname(self,name):
        """Set the instrument name."""
        self.__name = '{}'.format(name)
    name = property(_getname,_setname)
    
    def close_vi(self):
        """Close the pyVISA interface.
        
        Once this is called the VI becomes inactive and any calls
        to methods that depend on the presence of the VI will fail miserably.
        """
        self.__vi = None
            
    def configure_vi(self, **kwargs):
        """Configure an already open VI.        
        """
        self._vicheck()
        
        # store VISA-specific keywords, ignore all others
        # and configure the vi
        for k in kwargs:
            if k in _visakw:
                v = kwargs[k]
                self.__visa_kwargs[k] = v
                setattr(self.__vi,k,v)
            
    def _vicheck(self):
        """Check that the VISA interface is valid."""
        if self.__vi is None:
            self._error("resource is not open")
    
    def _error(self, msg, *args):
        """Generate an error message and raise an exception."""
        rsc = None
        if self.__vi:
            rsc = self.__vi.resource_name
        logger.error(msg)
        raise InstrumentError(msg, rsc=rsc, name=self.__name)
    _raise_error = _error
    
    def _warning(self, msg, *args):
        """Generate warnings to the logging subsystem."""
        rsc = None
        if self.__vi:
            rsc = self.__vi.resource_name
        logger.warning(msg)
    
    def _enable_visa_debugging(self, f=True):
        """enable VISA debugging by wrapping the internal pyVISA object with 
        a VisaDebugger object
        """
        """  - disable all of this for now
        if self.__vi:
            if bool(f):
                # need to check so that we don't wrap it more than once
                if not isinstance(self.__vi,visa_library.VisaDebugger):
                    self.__vi = visa_library.VisaDebugger(self.__vi)        
            else:
                if isinstance(self.__vi,visa_library.VisaDebugger):
                    self.__vi = self.__vi._getvi()
        """
        pass
    
    def set_visa_attribute(self, attr_name, value):
        """Set a Visa attribute on the Visa resource"""
        self._vicheck()
            
        try:
            self.__vi.set_visa_attribute(attr_name,value)
        except AttributeError:
            # old version of pyvisa
            from pyvisa.vpp43 import set_attribute
            set_attribute(self.__vi.vi,attr_name,value)
        
class GenericInstrument(BasicInstrument):
    """A generic instrument object that can be used as a proxy for direct
    I/O with any instrument using low-level commands.
    
    This is the parent class for all other instrument classes and defines
    some basic common behaviors.

    ** This class must be in the parent heriarchy for all instrument driver
    ** objects.  This behavior is enforced by the InstrumentManager.
    
    One of the common behaviors that this class introduces is the concept of
    a default channel on which to operate.  The default channel should be
    overridable on a per call basis (if the instrument drivers are written
    properly), but this provides the default channel on which to perform
    operations.
        
    This class also defines the "capabilities" interface that allows
    instrument driver families to use a set of string capabilities to flag
    optional behaviors for instruments.  Using this, a test routine that
    uses a driver can check that the driver actually has the capability that
    is needed for the application.
    """
        
    def __init__(self,resource_name=None,**kwargs):
        """Object initializer."""
        # set up a legal channels listing first
        self.__legal_channels = None
        if 'valid_channels' in kwargs:
            chanlist = kwargs.pop('valid_channels')
            if chanlist is not None and len(chanlist):
                self.__legal_channels = []
                for ch in chanlist:
                    ch = int(ch)
                    if ch not in self.__legal_channels:
                        self.__legal_channels.append(ch)
                
        # set the default channel
        if self.__legal_channels is not None:
            # set the default channel to the first channel listed in
            # the legal channels list
            self.__default_channel = self.__legal_channels[0]
        else:
            # default to channel 0
            self.__default_channel = 0
            
        if 'chan' in kwargs:
            self.set_channel(kwargs.pop('chan'))
        
        # set capabilities
        cap = kwargs.pop('capabilities',None)
        if cap is not None:
            # verify the capabilities list
            if not isinstance(cap,(tuple,list,)):
                self._error("'capabilities' keyword must be a list or tuple.")
            try:
                for c in cap:
                    assert isinstance(c,_str_type)
            except Exception:
                self._error("'capabilities' keyword must be a list or tuple containing strings.")
            
            self.__capabilities = cap[:]
        
        # initialize the parent
        super(GenericInstrument,self).__init__(resource_name,**kwargs)
        
    def init(self, force=False):
        """Override this in child classes to define behaviors to perform when
        the instrument is to be initialized. For most classes of instruments this
        should configure the instrument into a "standard" known state, though it
        might not be necessary for some types of instruments.
        
        The force argument should inform the driver that the instrument should
        be forced to be re-initialized.  Without this argument most drivers will
        not actually re-initialize the instrument when this is called and will
        simply re-initialize the driver instead.
        """
        pass
    
    def reinit(self):
        """Force reinitialization."""
        self.init(force=True)
    
    def close(self, deinit=True):
        """Close the VISA interface.
        This will call the instrument driver method _close() prior
        to closing the instrument unless the deinit argument is
        set to False (it defaults to True).
        """
        try:
            if deinit and self.vi and hasattr(self,'_close'):
                self._close()
        finally:
            # run the close method even if exceptions occur here
            self.close_vi()
    
    def _config_valid_channels(self, chanlist):
        """set up a list of valid channels for the instrument"""
        # no longer used
        pass
    _config_legal_channels = _config_valid_channels
    
    def set_channel(self,chan):
        """Set the default channel."""
        try:
            ch = int(chan)
            if ch < 0:
                self._error("channel must be 0 or greater") 
            self.__default_channel = ch
        except TypeError:
            self._error("channel must be an integer.")
    def _get_channel(self,chan=None,**kwargs):
        """Convenience method to resolve the channel number from keywords
        or using the default_channel property if keywords are not set."""
        c = chan
        if c is None:
            c = self.__default_channel
        try:
            c = int(c)
        except TypeError:
            raise TypeError("'chan' keyword must be an integer.")
        if self.__legal_channels is not None and c not in self.__legal_channels:
            raise ValueError("channel '%d' is not legal for this instrument."%c)
                
        return c
    default_channel = property(_get_channel,set_channel)
    chan = default_channel
    
    def check_capability(self,cap):
        """Check for a given capability or set of capabilities.
        
        Capabilities are designed to be used by a given family of instruments
        to flag the presense or absense of certain optional features.
        
        cap is a string or a sequence of strings to check against the stored
        capabilites of the instrument
        
        Returns False if the check fails, True if it succeeds.
        """
        if isinstance(cap,_str_type):
            if cap not in self.__capabilities:
                return False
        else:
            for c in cap:
                assert isinstance(c,_str_type)
                if c not in self.__capabilities:
                    return False
        return True
            
    def assert_capability(self,cap):
        """Same as the check_capability() method except an assertion failure
        will occur if the check fails.
        """
        assert self.check_capability(cap)
    
    def _get_capabilities(self):
        """Get the instrument capabilities."""
        return self.__capabilities[:]
    capabilities = property(_get_capabilities)
            
    def _get_params(self,chan=None,**kwargs):
        """Get the parameter dictionary for the given channel of an instrument.
        
        The returned object is an arbitrary dictionary-like object that can
        contain any number of channel-specific properties for the instrument.
        
        For example, this can be used by a class that controls a multi-channel
        power supply to store the configured state of each channel so that it
        knows which channels are configured and which are not, which channels are
        on/off, what the configured limits are, etc.
        """
        c = self._get_channel(chan)
        if self.vi is None:
            raise InstrumentError("GenericInstrument._get_params(): resource is not open")
        if not hasattr(self.vi,'_channel_parameters'):
            self.vi._channel_parameters = dict()
        if c not in self.vi._channel_parameters:
            self.vi._channel_parameters[c] = dict()
        return self.vi._channel_parameters[c]

    def query(self, kw, chan=None):
        """Query the instrument driver for the value of a keyword.
        
        This is a default implementation that could be replaced if
        additional logic is required.
        """
        return self._get_params(chan).get(kw)
        
    def _set_params(self,chan=None,**kwargs):
        """
        Set the parameter dictionary for the given channel of the instrument
        """
        c = self._get_channel(chan)
        p = self._get_params(chan)
        
        for k in kwargs:
            self.vi._channel_parameters[c][k] = kwargs[k]
                
    def _check_use_srq(self):
        """Check for the instrument-level or global use SRQ flag."""
        #### TODO: create this
        return False
    _use_srqs = property(_check_use_srq)
        
    #def __getattr__(self,name):
    #    """Proxy access to the methods/properties of the underlying VISA interface."""
    #    return getattr(self.vi,name)

class DummyInstrument(GenericInstrument):
    """Base class for a virtual instrument"""
    _log = logger
    
    def __init__(self,resource_name,**kwargs):
        """Initializer. Registers the driver with the instrument manager
        """
        if type(self) is DummyInstrument:
            raise TypeError("`DummyInstrument` is an abstract class and cannot be instanciated")
        
        """Object initializer."""
        # set up a legal channels listing first
        self.__legal_channels = range(10)
        self.__default_channel = 0
        self.__capabilities = [ ]

        # set properties
        self.__vi = None
        self.__name = '{}'.format(kwargs.pop('name',''))

        # store this instrument object in the instrument manager
        InstrumentManager()._register_instr(self)

    @property
    def vi(self):
        "pyVISA interface"
        return self.__vi
        
    @property
    def vi_session(self):
        return None
    
    def close_vi(self):
        pass
            
    def configure_vi(self, **kwargs):
        pass
    
    def set_visa_attribute(self, attr_name, value):
        pass

    def init(self, force=False):
        """Override this in child classes to define behaviors to perform when
        the instrument is to be initialized. For most classes of instruments this
        should configure the instrument into a "standard" known state, though it
        might not be necessary for some types of instruments.
        
        The force argument should inform the driver that the instrument should
        be forced to be re-initialized.  Without this argument most drivers will
        not actually re-initialize the instrument when this is called and will
        simply re-initialize the driver instead.
        """
        pass
    
    def reinit(self):
        """Force reinitialization."""
        self.init(force=True)
    
    def close(self, deinit=True):
        self.close_vi()
    
    def check_capability(self,cap):
        return True
            
    def assert_capability(self,cap):
        pass

    def query(self, kw, chan=None):
        return None
        
class MeasurementInstrument:
    "mix-in class that defines methods that are used by all measurement instruments"
    
    def initiate(self, chan=None):
        "initiate a measurement"
        raise NotImplementedError
        
    def ask_if_done(self, chan=None):
        "check to see if a measurement is done"
        raise NotImplementedError
        
    def fetch(self, chan=None):
        "fetch measured data from the instrument"
        raise NotImplementedError
        
    def measure(self, chan=None):
        """convenience method that initiates a measurement, waits for
        it to complete, and fetches and returns the result
        """
        self.initiate(chan)
        while True:
            if self.ask_if_done(chan):
                break
            timed_wait_ms(50)
        return self.fetch(chan)
    

class _fake_regex:
    def match(self,string,*args):
        return False
    
class DriverDef(object):
    """Internal class used to internally store registered driver types."""
    
    def __init__(self, ty):
        """Initializer.
        
        Arguments:
        ty - the driver type (class) object that is used to create new
          driver objects
        """
        if not hasattr(ty,'drvname'):
            raise ValueError("driver has no 'drvname' attribute")
        
        if hasattr(ty,'regex'):
            regex = ty.regex
        else:
            regex = _fake_regex()
            
        if isinstance(regex,_str_type):
            regex = re.compile(regex,re.I)
        elif not hasattr(regex,'match') or not callable(regex.match):
            raise TypeError('driver regular expression is invalid')
            
        if not issubclass(ty,GenericInstrument):
            raise TypeError('all drivers must be derived from `instrument.GenericInstrument`')
        
        self.name = ty.drvname
        self.name_lower = ty.drvname.lower()
        self.re = regex
        self.ty = ty
        
    def match_name(self, string, family=None):
        """Check if the driver def name matches the passed string."""
        if string == self.name_lower:
            if family is None or issubclass(self.ty,family):
                return True
        return False        
                
    def match_regex(self, string, family=None):
        """Check if the driver def regex matches the passed string."""
        if self.re.match(string):
            if family is None or issubclass(self.ty,family):
                return True
        return False
    
    def __str__(self):
        """Create a human-readable string representation."""
        return "DriverDef(r'%s',%s)"%(self.name,self.ty)
        
            
class InstrumentManager(object):
    """The InstrumentManager keeps track of registered drivers and currently
    connected instruments.
    
    This uses a borg-pattern initialization such that all InstrumentManager
    objects have the same internal state.
    """
    # borg-pattern shared state
    __shared_state = dict()
    
    def __init__(self):
        """InstrumentManager initializer. This loads the borg-pattern
        internal state and sets it up as needed.
        """
        self.__dict__ = self.__shared_state
        
        # set up internal objects as needed
        if '_isinitialized' not in self.__dict__:
            self._isinitialized = True
            # store a dictionary of registered drivers
            self.__driver_list = []
            # weak references dictionary of all VISA objects
            self.__open_vis = weakref.WeakValueDictionary()
            # initialize the debugging flag
            self.__debug_visa = False
            # list of weak references to opened instruments
            self.__instruments = []

    def set_visa_debug(self, st=True):
        """Set the VISA debugging mode."""
        self.__debug_visa = bool(st)
    
    def _register_instr(self, instr):
        """register a created instrument - this should ONLY be called by
        `instrument.BasicInstrument` as part of it's initializer
        """
        if not isinstance(instr,BasicInstrument):
            raise TypeError("expected a `instrument.BasicInstrument` object")
        self.__instruments.append(weakref.ref(instr))
    
    def open_vi(self,rsc_name,**kwargs):
        """Open the pyVISA interface for an instrument.  If an instrument already
        exists with the given VISA resource string then a reference to that
        interface will be returned - this behavior is used to ensure that two or
        more driver objects that interface with a single physical instrument will be
        able to share state parameters about the instrument between each other.
        
        Arguments:
        rsc_name - string, the VISA resource name string
        
        Keywords:
        Anything allowed by the pyVISA instrument() helper funtion.
        
        Returns:
        A pyVISA object.
        """
        # get a consistent VISA resource string to use in the comparison
        rsc = self._resolve_visa_resource_name(rsc_name)
        if rsc is None:
            rsc = rsc_name
             
        if rsc != rsc_name:
            logger.debug("open_vi(): re-wrote resource name '%s' to '%s'"%(rsc_name,rsc))
        
        # check for an already open VI
        vi = self.__open_vis.get(rsc)
        if vi is not None:
            logger.debug("open_vi(): found existing VISA connection to '%s'"%rsc)
            #if self.__debug_visa:
            #    # debugging mode
            #    logger.debug("open_vi(): inserting debugging wrapper for '%s'"%rsc)
            #    return visa_library.VisaDebugger(vi)
            #else:         
            return vi
        
        # there is no open VI, open a new one
        logger.debug("open_vi(): creating new connection to '%s'"%rsc)
        vi = open_resource(rsc,**kwargs)
        self.__open_vis[rsc] = vi
        
        #if self.__debug_visa:
        #    # debugging mode
        #    logger.debug("open_vi(): inserting debugging wrapper for '%s'"%rsc)
        #    return visa_library.VisaDebugger(vi)
        #else:         
        return vi
        
    def get_driver(self, family, drv_name, search_mode='both'):
        """Get a driver object given an instrument class (family) type object
        and the driver name.
        
        Arguments:
        family - string or type object, the instrument family. Drivers that
           match the driver name will be limited to families of this type.
           This can also be None, in which case the first driver name that matches
           will be returned.  This uses issubclass() to determine if a given
           matched driver object is part of the family.
        drv_name - string, the name of the driver to load.  This is matched
           against names and/or regex objects for all known drivers until a match is found
           that satisfies the instrument class argument
        search_mode - string, one of 'name', 'regex', or 'both' which respectively match the
           driver name (case-insensitive), driver regex, or both (name then regex)
         
        
        Return:
        An instrument driver type object.  The type object can be used
        to instatiate a driver object by calling it with appropriate arguments.
        """
        if not family:
            # set family to explicitly None
            # this fixes the case where an empty string is passed
            family = None
        
        if family is not None and (type(family) is not type or not issubclass(family,GenericInstrument)):
            # need to load the type object for the family
            from .family import get_instr_family_from_str
            t = family
            family = get_instr_family_from_str(family)
            logger.debug("get_driver(): mapped family '%s' to '%s'"%(t,family))
            
        
        if drv_name.find('.') > -1:
            # driver name is a Python path, load it differently
            
            dprt = drv_name.split('.')
            module = '.'.join(dprt[:-1])
            cls = dprt[-1]
            # use __import__ to load the instrument driver class from the module
            # only do absolute importing to prevent problems with package resolution
            try:
                _tmp = __import__(module,globals(),locals(),[cls],0)
                ty = getattr(_tmp,cls)
            except ImportError:
                raise DriverNotFound("'%s'"%drv_name)
            
            if not issubclass(ty,GenericInstrument) or (family and not issubclass(ty,family)):
                logger.debug("get_driver(): driver '%s' was loaded but it's type was invalid"%drv_name)
                raise InvalidDriver("'%s'"%drv_name)
            
            return ty
        
        else:
            # search for the driver by name and/or regex in the instrument manager registry
            # this is the normal way that instruments are loaded
            
            if search_mode not in ('name','regex','both'):
                raise ValueError("invalid 'search_mode' - value must be one of 'name', 'regex', or 'both'")
            
            ty = None
            if search_mode in ('name','both'):
                dl = drv_name.lower()
                for drv in self.__driver_list:
                    if drv.match_name(dl,family):
                        ty = drv.ty
                        break
            
            if ty is None and search_mode in ('regex','both'):
                for drv in self.__driver_list:
                    if drv.match_regex(drv_name,family):
                        ty = drv.ty
                        break
            
            if ty is None:
                logger.error("get_driver(): no match for driver '%s' (family: %s)"%(drv_name,repr(family)))
                raise DriverNotFound("'%s'"%drv_name)
                
            return ty
    
    def open_driver(self, family, drv_name, *args, **kwargs):
        """Get a driver object and open it by calling it with the the specified
        arguments.
        
        Arguments:
        See get_driver() for a description of the family and drv_name arguments.
        Positional and keyword arguments are passed along to the instrument driver
        __init__() method.
        
        Return:
        An instrument object.
        """
        obj = self.get_driver(family,drv_name)
        return obj(*args, **kwargs)
        
    
    def register_driver(self, driver_type):
        """This method should be called by driver modules when they are imported
        to register drivers.
        
        Arguments:
        driver_type - a type object that will create a new driver object
           when called.
        
        """
        try:
            self.__driver_list.append( DriverDef(driver_type) )
        except Exception as e:
            logger.warning("driver registration failed. Message: %s"%e)
    
    def list_by_family(self, family):
        "get a list of driver object names by family"
        if type(family) is not type or not issubclass(family,GenericInstrument):
            from .family import get_instr_family_from_str
            family = get_instr_family_from_str(family)
        
        lst = []
        for drv in self.__driver_list:
            if issubclass(drv.ty,family):
                lst.append(drv.name)
        
        return lst
            
    def _resolve_visa_resource_name(self, rsc_name):
        """Resolve a VISA resource name into a more determined version."""
        # resolve the name using the VISA library
        return parse_resource_name(rsc_name)
    
    @property
    def _all_instruments(self):
        "list of all instruments that currently exist"
        ret = []
        todel = []
        for i,r in enumerate(self.__instruments):
            instr = r()
            if instr is None:
                # instrument has been deleted
                todel.append(i)
            else:
                ret.append(instr)
        
        if len(todel):
            # remove weak references to instruments that have been deleted
            for i in reversed(todel):
                del self.__instruments[i]
                
        return ret
    
    @property
    def _all_vis(self):
        "list of all pyVISA objects that currently exist"
        ret = []
        for v in self.__open_vis.values():
            if v is not None:
                ret.append(v)
        return ret
        
    @property
    def driver_list(self):
        "list of all registered drivers"
        return self.__driver_list[:]
    
    def print_drivers(self):
        "Print registered drivers"
        for d in self.__driver_list:
            print(d)
        
    def print_vis(self):
        "print pyVISA objects that exist"
        for v in self._all_vis:
            print(v.resource_name+" -> "+repr(v))

def register( drv_type ):
    """A convenience method for calling the InstrumentManager.register_driver
    method."""
    InstrumentManager().register_driver(drv_type)

    
