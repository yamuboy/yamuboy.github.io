from __future__ import division, print_function, unicode_literals, absolute_import
import logging, warnings
import pyvisa
try:
    # only the old version of PyVisa has this
    import pyvisa.visa
except ImportError:
    pass

from . import _str_type
    
## define flags for values_format pyVisa field ##
VF_ASCII = 0
VF_SINGLE = 1
VF_DOUBLE = 3
VF_LITTLEENDIAN = 0
VF_BIGENDIAN = 4

_resource_manager = None

def _init_rm():
    "init the resource manager"
    global _resource_manager
    if _resource_manager is None:
        try:
            _resource_manager = pyvisa.ResourceManager()
        except OSError:
            _resource_manager = pyvisa.ResourceManager('@py')   # attempt to open pyVisa-py backend if loading ni backend fails
        except AttributeError:
            # old version of PyVisa
            _resource_manager = pyvisa.visa.resource_manager
    
def open_resource( name, **kwargs ):
    "open a VISA resource"
    _init_rm()

    try:
        return _resource_manager.open_resource(name,**kwargs)
    except AttributeError:
        # old version of PyVisa
        return pyvisa.visa.instrument(name,**kwargs)
    
def parse_resource_name( name ):
    "parse the resource name into a standard format"
    _init_rm()
        
    try:
        return _resource_manager.visalib.parse_resource_extended(_resource_manager.session,name)[0].resource_name
    except AttributeError:
        # old version of PyVisa
        return pyvisa.vpp43.parse_resource_extended(_resource_manager.session,name)[3]
    
class PyvisaWrapper(object):
    """Wrapper for PyVISA that provides better exception message handling
    """
    
    def __init__(self, resource, name):
        "initializer"
        if not isinstance(resource,pyvisa.Resource):
            raise TypeError("argument 1 must be a `pyvisa.Resource` object")
        if not isinstance(name,_str_type):
            raise TypeError("argument 2 must be a string object")
        
        self.__rsc = resource
        self.__name = name
            
    def __getattr__(self, name):
        if hasattr(self,name):
            return getattr(super(PyvisaWrapper,self),name)
        else:
            a = getattr(self.__rsc,name)
            # wrap the attribute in an exception handler if it
            # is a callable function
            if hasattr(a,'__call__'):
                return PyvisaExcWrap(a,self.__rsc,self.__name)
            else:
                return a
        
    def __setattr__(self, name, value):
        if hasattr(self.__rsc,name):
            # trying to set an attribute on the PyVISA object 
            try:
                setattr(self.__rsc,name,value)
            except pyvisa.Error as e:
                # modify the error and re-raise it
                e.resource_address = self.__rsc.resource_name
                e.resource_name = self.__name
                raise        
        else:
            # setting a local attribute
            setattr(super(PyvisaWrapper,self),name,value)
    
    def __delattr__(self, name):
        "only allow deletion of local attributes"
        if hasattr(self.__rsc,name):
            # not allowed
            raise something        
        else:
            # deleting a local attribute
            delattr(super(PyvisaWrapper,self),name)
    
class PyvisaExcWrap(object):
    "exception wrapper for function calls to the PyVISA library"
    
    def __init__(self, func, resource, name):
        "initializer"
        self._f = func
        self._r = resource
        self._n = name
    
    def __call__(self, *args, **kwargs):
        "call wrapper"
        try:
            return self._f(*args,**kwargs)
        except pyvisa.Error as e:
            e.resource_address = self._r.resource_name
            e.resource_name = self._n
            raise
    
    
class VisaDebugger(object):
    """Log debug messages for VISA calls.
    
    Turning this into a no-op wrapper this as pyvisa
    provides plenty of debug logging - JB
    """
    
    def __init__(self, vi):
        self.__visa = vi
        #self.__log = logging.getLogger('instrument.VisaDebugger')
        
    def __getattr__(self, key):
        #self._debugmsg("unlogged access to '%s'"%key)
        return getattr(self.__visa,key)

    def __setattr__(self, key, value):
        #self._debugmsg("unlogged access to '%s'"%key)
        return setattr(self.__visa,key,value)
        
    # def read(self):
        # r = self.__visa.read()
        # self._debugmsg('read()',r)
        # return r        
    
    # def write(self, msg):
        # self._debugmsg('write(%s)'%repr(msg))
        # self.__visa.write(msg)    
    
    # def ask(self, msg,*args):
        # r = self.__visa.ask(msg,*args)
        # self._debugmsg('ask(%s)'%repr(msg),r)
        # return r    
    
    # def read_values(self,*args):
        # r = self.__visa.read_values(*args)
        # self._debugmsg('read_values()',r)
        # return r        
        
    # def ask_for_values(self, msg, *args):
        # r = self.__visa.ask_for_values(msg,*args)
        # self._debugmsg('ask_for_values(%s)'%repr(msg),r)
        # return r        
        
    # def read_raw(self):
        # r = self.__visa.read_raw()
        # self._debugmsg('read_raw()',r)
        # return r
    
    # def clear(self):
        # self._debugmsg('CLEAR')
        # self.__visa.clear()        
        
    # def trigger(self):
        # self._debugmsg('TRIGGER')
        # self.__visa.trigger()
    
    # def close(self):
        # self._debugmsg('close()')
        # self.__visa.close()
    
    # def _getstb(self):
        # st = self.__visa.stb
        # self._debugmsg('STB = %d (%x)'%(st,st))
        # return st
    # stb = property(_getstb)
        
    # def _getrsc(self):
        # return self.__visa.resource_name
    # resource_name = property(_getrsc)
    
    # def _debugmsg(self, cmd, ret=None):
        # self.__log.debug('%-20s: %s'%(self.resource_name,cmd))
        # if ret is not None:
            # r = repr(ret)
            # if len(r) > 255:
                # r = r[:251] + "...'"
            # self.__log.debug("   Response: %s"%r)
    
    # def _getvi(self):
        # return self.__visa


