from __future__ import division, print_function, unicode_literals, absolute_import
# setup module logging
import logging as _l

logger = _l.getLogger('instrument')

# point the top-level library log target at the null handler
if hasattr(_l,'NullHandler'):
    _h = _l.NullHandler()
else:
    class _NullHandler(_l.Handler):    
        def emit(self, record):
            pass
    _h = _NullHandler()
logger.addHandler(_h)

