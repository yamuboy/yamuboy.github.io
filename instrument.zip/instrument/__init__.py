from __future__ import division, print_function, unicode_literals, absolute_import
# initialize the logger
from .logger import logger

try:
    _str_type = basestring
except NameError:
    _str_type = str    
    
# import pyvisa constants
try:
    import pyvisa.constants as visa_constants
except ImportError:
    try:
        import pyvisa.vpp43_constants as visa_constants
    except ImportError:
        raise ImportError('`pyvisa` is required to use the instrument library')

# import some stuff that needs to be imported early
from .utils import timed_wait, timed_wait_ms

# import some core modules
from .errors import *
from .base import (InstrumentManager, register, create, driver, GenericInstrument,
    MeasurementInstrument, DummyInstrument)

# import some constants
from .visa_library import VF_ASCII, VF_SINGLE, VF_DOUBLE, VF_LITTLEENDIAN, VF_BIGENDIAN
    
# import the instrument families before any drivers are imported
# otherwise a recursive import will occur and an error will be raised
from . import family

# import the drivers to cause them to register themselves
from . import drivers as _drivers

# create some shortcuts/aliases
manager = InstrumentManager

