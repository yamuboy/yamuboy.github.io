from __future__ import division, print_function, unicode_literals, absolute_import

import instrument
import logging, os
from . import _str_type

class Multisite(object):
    """Class that handles all aspects of multi-site wafer testing."""
    
    _log = logging.getLogger('instrument.Multisite')
    
    def __init__(self):
        """Initialize."""
        self.__xi = 10000
        self.__yi = 10000
        self.__mf = 'N'
        self.__sites = []
        self.__prober = None
        self.__curpos = (0,0)
        self.__startpos = None
        self.__cursite = -1
        self.__startsite = -1
        
    def read_map(self, fname, type = 'nr'):
        """Read a wafer map file.
        
        The wafer map file has the following format:
        ---------------------------------
        xindex: XXXXX
        yindex: YYYYY
        majorflat: Z
        
        [sites]
        x1 y1
        x2 y2
        x3 y3
        .
        .
        .
        ---------------------------------
        
        Where:
        XXXXX is the step index for X (positive integer)
        YYYYY is the step index for Y (positive integer)
        Z is either N, S, W, or E for the position of the major flat
        
        Any line with a leading '#' is a comment
        
        """
        if os.path.splitext(fname)[1] == '.map': 
            self.map_type = 'nr'        
            f = open(fname,'r')
            startsites = False
            try:
                for line in f:
                    if line.startswith('#'):
                        continue
                    
                    line = line[:-1]
                    if not startsites:
                        if line.startswith('xindex:'):
                            self._setxindex(int(line[7:]))
                        elif line.startswith('yindex:'):
                            self._setyindex(int(line[7:]))
                        elif line.startswith('majorflat:'):
                            mf = line[10:].strip()
                            self._setmf(mf)
                        elif line.startswith('[sites]'):
                            startsites = True
                    else:
                        if not len(line):
                            continue
                            
                        try:
                            x,y = tuple(line.split())
                            self.add_site(x,y)
                        except Exception as e:
                            self._log.warning("%s: illegal line '%s' in file"%(fname,line))
                            continue
            finally:
                f.close()
        elif os.path.splitext(fname)[1] == '.rmap':
            self.map_type = 'r'
            self.rmap_dict = {}
            with open(fname,'r') as fp:
                exec(compile(fp.read(),fname,'exec'),globals(),self.rmap_dict)
            # Add sites
            self._setxindex(self.rmap_dict['x_ref'])
            self._setyindex(self.rmap_dict['y_ref'])
            self._setmf(self.rmap_dict['major_flat'])
            for s in self.rmap_dict['sites']:
                x,y = s
                self.add_site(x,y)
            
    read_map_file = read_map
    
        
    def get_map_type(self):
        return self.map_type
    
    def configure(self, **kwargs):
        """Configure multi-site
        
        Keywords:
        
        xindex
        yindex
        majorflat
        """
        
        if 'xindex' in kwargs:
            try:
                xi = int(kwargs['xindex'])
                if xi < 1:
                    raise ValueError()
                self.__xi = xi
            except Exception:
                raise ValueError("'xindex' must be a positive integer")
            
        if 'yindex' in kwargs:
            try:
                yi = int(kwargs['yindex'])
                if yi < 1:
                    raise ValueError()
                self.__yi = yi
            except Exception:
                raise ValueError("'yindex' must be a positive integer")
        
        if 'majorflat' in kwargs:
            mf = kwargs['majorflat'].upper()
            if mf not in ('N','S','W','E'):
                raise ValueError("'majorflat' must be one of: 'N', 'S', 'W', or 'E'")
            self.__mf = mf
            
        if 'reticle_x' in kwargs:
            self.retx = kwargs['reticle_x']
            
        if 'reticle_y' in kwargs:
            self.rety = kwargs['reticle_y']
            
        if 'reticle_info' in kwargs:
            # The reticle information is a list of dictionaries, where each item is a die dictionary containing
            # all the information about that die, including it's x and y dimensions and name
            self.reticle_info = kwargs['reticle_info']
            
    def get_reticle_dict(self):
        return self.rmap_dict['reticle_dict']
        
    def set_die_tbm(self,die_name,die_loc):
        reticle_dies = self.rmap_dict['reticle_dict']
        for d in reticle_dies:
            if (d['name'] == die_name) and (d['location'] == die_loc):
                self.die_tbm = d
        # Now calculate the x_ref and y_ref accordingly
        # key assumption is that the x and y reference in the file is of the top left die
                
                
    def add_site(self, x, y):
        """Add a site to the map.
        
        Sites are integer indexed starting at the top-left.
        """
        x, y = int(x), int(y)
        if x < 1 or y < 1:
            raise ValueError("'x' and 'y' must be greater than 0")
        elif x > 99 or y > 99:
            raise ValueError("'x' and 'y' must be less than 100")
        name = '%0.2d%0.2d'%(x,y)
        self.__sites.append( (name,x,y) )
    
    def clear_sites(self):
        """Clear all sites from the site list"""
        self.__sites = []
    
    def _compute_pos(self, idx, startidx=0):
        """Compute the differential position from the starting index."""
        indexing_map = dict(N=(self.__xi,-self.__yi),S=(-self.__xi,self.__yi),
            E=(-self.__yi,-self.__xi), W=(self.__yi,self.__xi))
        column_map = dict(N=(1,2), S=(1,2), E=(2,1), W=(2,1))
        
        start = self.__sites[startidx]
        current = self.__sites[idx]
        cm = column_map[self.__mf]
        im = indexing_map[self.__mf]
        return (current[cm[0]]-start[cm[0]])*im[0], (current[cm[1]]-start[cm[1]])*im[1]
        
        
    def get_site_name(self, idx):
        """Get the name of the site at the given index."""
        return self.__sites[idx][0]
       
    def get_site_index(self, *args):
        """Get the ordinal index of a site
        
        The site can be specified using the 4-character name string (i.e. '0304', '1102', etc),
        or by specifying the integer x and y values for the site as a tuple or as 2 arguments
        
        Important: this method will find the first matching site, so if the 
           same site is listed more than once in the map then only the
           first instance will be found.
        """
        if len(args) == 1:
            a = args[0]
            if isinstance(a,_str_type):
                for i,v in enumerate(self.__sites):
                    if a == v[0]:
                        return i
                raise IndexError("'%s' not found in map"%a)
            elif isinstance(a,(list,tuple)):
                if len(a) != 2:
                    raise ValueError("when 1 argument is specified it must be a string or a 2-element list/tuple")
                x, y = int(a[0]), int(a[1])
                for i,v in enumerate(self.__sites):
                    if x == v[1] and y == v[2]:
                        return i
                raise IndexError("(%d,%d) not found in map"%(x,y))
            else:
                raise ValueError("when 1 argument is specified it must be a string or a 2-element list/tuple")
        elif len(args) == 2:
            x, y = int(args[0]), int(args[1])
            for i,v in enumerate(self.__sites):
                if x == v[1] and y == v[2]:
                    return i
            raise IndexError("(%d,%d) not found in map"%(x,y))
        else:
            raise ValueError("either 1 or 2 arguments must be specified")
    
    def all_sites(self, rettype='name'):
        """Return a list containing all sites either by string name
         or as coordinates in 2-tuple form
        """
        if rettype == 'name':
            return [n[0] for n in self.__sites]
        elif rettype == 'coord':
            return [(n[1],n[2]) for n in self.__sites]            
        else:
            raise ValueError("'rettype' must be one of: 'name' or 'coord'")

    def init_prober(self, drvname, addr):
        """initialize the Autoprober driver
        drvname - driver name string
        addr - VISA resource address string (i.e. 'GPIB::28')
        """
        if self.__prober:
            # close the old prober object
            self.__prober.close()
            self.__prober = None
        
        # create the prober instrument
        self.__prober = instrument.create('prober',drvname,addr)
        
        # get the current position
        self.__curpos = self.__prober.get_position()
    
    def init_multisite(self, index=0, drvname=None, addr=None):
        """initialize multi-site testing
        
        Keywords:
        index - integer, index of the starting site in the map file (defaults to 0)
           useful if restarting a multi-site test partway through a map
        drvname - prober driver name, used for single call initialization of the prober
           and multi-site testing
        addr - prober VISA address string, used for single call initialization of the prober
           and multi-site testing
        """
        if drvname is not None and addr is not None:
            self.init_prober(drvname,addr)
        
        # check that the prober is initialized
        if not self.__prober:
            raise RuntimeError("prober has not been initialized")
                
        index = int(index)
        if index < 0 or index >= len(self.__sites):
            raise IndexError("invalid 'index'")
        self.__cursite = index
        self.__startsite = self.__cursite
        
        # get the current position and save it as the starting position
        self.__curpos = self.__prober.get_position()
        self.__startpos = self.__curpos
    
    def next_site(self):
        """move to the next site in the map
        
        raises a StopIteration exception if there
        are no more site
        
        Typical use in multi-site testing
        
        m = Multisite()
        m.read_map('my_map_file')
        m.init_prober('12k','GPIB::28')
        m.init_multisite()
                
        try:
            while True:
                # run some testing
                # ...
                # ...
                
                m.next_site()            
        
        except StopIteration:
            pass
        """
        # check that init_multisite() was called
        if self.__startsite < 0 or self.__cursite < 0:
            raise ValueError("init_multisite() has to be called first")
        
        i = self.__cursite + 1
        if i >= len(self.__sites):
            raise StopIteration
        
        # compute the next site position and move the prober
        xr, yr = self._compute_pos(i,self.__startsite)
        x, y = xr+self.__startpos[0], yr+self.__startpos[1]
        self.__prober.set_position(x,y,synch=True)
        self.__curpos = self.__prober.get_position()
        self.__cursite = i
    
    """
    def iter_sites(self, index=None):
        "iterator method for looping over sites"
        if index is not None:
            i = int(index)
        else:
            i = 0
        
    """    
    
    def close(self):
        "close the prober driver and un-initialize multisite"
        if self.__prober:
            self.__prober.close()
            self.__prober = None
        self.__startsite = -1
        self.__cursite = -1
        self.__startpos = None
    
    def _getxindex(self):
        return self.__xi
    def _setxindex(self, v):
        self.configure(xindex=v)
    xindex = property(_getxindex,_setxindex,None,"X index")
    
    def _getyindex(self):
        return self.__yi
    def _setyindex(self, v):
        self.configure(yindex=v)
    yindex = property(_getyindex,_setyindex,None,"Y index")

    def _getmf(self):
        return self.__mf
    def _setmf(self, v):
        self.configure(majorflat=v)
    majorflat = property(_getmf,_setmf,None,"major flat orientation")
    
    @property
    def current_index(self):
        "index of the current site"
        return self.__cursite
    
    @property
    def current_coord(self):
        "coordinates of the current site"
        i = self.__cursite
        if i < 0 or i >= len(self.__sites):
            return (-1,-1)
        return (self.__sites[i][1], self.__sites[i][2])
        
    @property
    def current_name(self):
        "name of the current site"
        i = self.__cursite
        if i < 0 or i >= len(self.__sites):
            return ''
        return self.__sites[i][0]    
    
    def __getitem__(self,i):
        return self.__sites[i]
    
    def __len__(self):
        return len(self.__sites)
        

        
            
        
    
        
        
