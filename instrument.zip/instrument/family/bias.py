from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, MeasurementInstrument, timed_wait_ms
from . import register_family_name

__all__ = ['VOLTAGE','CURRENT','BiasInstrument']

# global constants that are used to define the source mode
VOLTAGE = 'V'
CURRENT = 'I'

_valid_modes = (VOLTAGE,CURRENT,)

class BiasInstrument(GenericInstrument,MeasurementInstrument):
    """A driver for instruments that supply DC bias voltage and current."""
    
    def config(self, **kwargs):
        """Every bias instrument must implement this method, it does the bulk
        of the configuration of the instrument.
        
        Standard Keywords:
        --------------------------------------------
        mode - string, set the source mode, valid values are 'V' and 'I'
        state - bool, set the state to on (True) or off (False)
        vset - float, the voltage set point (volts), used when the source is
          operating in voltage mode 
        iset - float, the current set point (volts), used when the source is
          operating in current mode 
        vlimit - float, set the source voltage limit (volts), used when the source is
          operating in current mode
        ilimit - float, set the source current limit (amps), used when the source is
          operating in voltage mode
        vrange - float, set the source voltage range (volts), this is the largest value that
           is required from the source, it can also be None for autoranging **
        irange - float, set the source current range (amps), this is the largest value that
           is required from the source, it can also be None for autoranging **
        vmrange - float, set the voltage measurement range (volts), it can also be None
           for autoranging **
        imrange - float, set the current measurement range (amps), it can also be None 
           for autoranging **
        remote - bool, enable remote sensing **
        resolution - string, set the measurement resolution, it can be one of
           'low', 'medium', 'high', or 'very high'
        
        ** some parameters might not be supported in all instruments, they should
        be ignored by the drivers of those instruments
        
        Instrument-specific keywords can also be used, though the use of them
        would make the driver less portable.
        
        In the implementation of the drivers, passed keywords that are completely
        invalid for the capabilities of the instrument should raise exceptions.
        Keywords or keyword values that can be safely ignored should be ignored.
        Unrecognized (instrument-specific) keywords should generate warnings.
        """
        raise NotImplementedError
    
    def ask_if_limiting(self,chan=None):
        """Check to see if the last measurement was being limited due to the
        'ilimit' or 'vlimit' settings.
        
        A default implementation is given here that can be replaced by an
        instrument-specific version. This implementation relies on the driver
        setting the 'limiting' key of the channel state parameter dictionary
        to the value of True or False after each measurement.
        """
        return bool(self.query('limiting',chan=chan))
    limiting = property(ask_if_limiting)
        
    ############ Convenience methods ##############

    def get_mode(self, chan=None):
        """Get the current source mode."""
        return self.query('mode',chan=chan)
        
    def set_mode(self, mode, chan=None):
        """Convenience method to change the source mode to I or V."""
        self.config(mode=mode,chan=chan)
    
    def get_source(self, chan=None):
        """Get the source value."""
        m = self.query('mode',chan=chan)
        if m == CURRENT:
            return self.query('iset',chan=chan)
        elif m == VOLTAGE:
            return self.query('vset',chan=chan)
        else:
            raise InstrumentError("Invalid source mode.")
        
    def set_source(self, val, chan=None):
        """Set the source value."""
        # first get the current mode
        m = self.query('mode',chan=chan)
        if m == CURRENT:
            self.config(iset=val,chan=chan)
        elif m == VOLTAGE:
            self.config(vset=val,chan=chan)
        else:
            raise InstrumentError("Invalid source mode.")
        
    def get_state(self, chan=None):
        """Get the state of the output."""
        self.query('state', chan=chan)
        
    def set_state(self, state, chan=None):
        """Turn on/off the output."""
        self.config(state=bool(state), chan=chan)
    
# register family names for bias instruments        
register_family_name('bias',BiasInstrument)
register_family_name('dcsupply',BiasInstrument)
register_family_name('powersupply',BiasInstrument)

