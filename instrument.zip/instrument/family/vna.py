from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, MeasurementInstrument, timed_wait_ms
from . import register_family_name

##### constants #####

# OLD measurement modes (these could be extended for 4-port VNAs)
# -- could also add modes for using the PNA as a power signal source
PORT1 = 'PORT1'
PORT2 = 'PORT2'
TWO_PORT = 'TWO_PORT'
RAW = 'RAW'

### NEW measurement modes ###
S1P_P1 = 'S1P_P1'    # 1-port S-params, port 1
S1P_P2 = 'S1P_P2'    # 1-port S-params, port 2
S2P = 'S2P'          # 2-port S-params 
CUSTOM = 'CUSTOM'    # custom measurements

# cal coefficient names 
ESRM = 'ESRM'  # source match
ERFT = 'ERFT'  # reflection tracking
EDIR = 'EDIR'  # directivity
ETRT = 'ETRT'  # transmission tracking
ELDM = 'ELDM'  # load match
EISO = 'EISO'  # isolation


class NetworkAnalyzer(GenericInstrument, MeasurementInstrument):
    """instrument  that interacts with a network analyzer"""
        
    def config(self,chan=None,**kwargs):
        """Set configuration parameters.
        
        Standard Keywords (must be supported):
        mode - one of the measurement mode constants
           (a mode must be selected before a measurement will succeed)
        measparam - a helper parameter that compliments the 'mode' in cases where
           a custom or complicated measurement must be defined
           TODO: define the syntax for this parameter
        """
        raise NotImplementedError
           
    def get_cal_coeffs(self,coeff,chan=None):
        """Get cal coefficients from the instrument.
        coeff - (string) the name of the coefficient to get plus the port
          information.  The form of this string is 'name,port1,port2' where
          the names are:
          ESRM - source match 
          ERFT - reflection tracking 
          EDIR - directivity 
          ETRT - transmission tracking 
          ELDM - load match 
          EISO - isolation
          and port1/port2 are integers from 1-N denoting the analyzer port
          number, where N is the number of ports. For ESRM, ERFT, and EDIR the
          port1 and port2 values must be equal and for ETRT, ELDM, and EISO the
          port values must not be equal.
          
          Older 2-port VNAs that use an 8-term error model will not have values for
          ETRT and ELDM and should return None instead.
           
        Must return a sequence of complex-valued cal coefficients.
        """
        raise NotImplementedError
        
    def set_cal_coeffs(self,coeff,values,chan=None):
        """Set cal coefficients in the instrument.        
        coeff - (string) the name of the coefficient to set, see get_cal_coeffs()
          for more details
        values - a sequence of complex-valued cal coefficients, the length of
          this must match the length of the frequency list
        """
        raise NotImplementedError
                
    def get_flist(self,chan=None):
        """Get the frequency list.
        Must return a sequence of real-valued numbers.
        """
        raise NotImplementedError
                
    def save_state(self,state_id):
        """Save the current instrument state."""
        raise NotImplementedError
                
    def recall_state(self,state_id):
        """Recall a saved instrument state."""
        raise NotImplementedError
    
    @staticmethod
    def parse_cal_coeff(coeff):
        "check the format of a cal coefficient specifier"
        try:
            cname,mp,sp = tuple(coeff.split(','))
        except Exception as e:
            self._error("badly formed 'coeff': format is 'name,measport,srcport' => %s"%e)
            
        try:
            mp, sp = int(mp), int(sp)
        except:
            self._error("measport and srcport must be integers")
            
        cname = cname.strip().upper()
        if cname not in ('ESRM','ERFT','EDIR','ETRT','ELDM','EISO'):
            self._error("invalid cal coefficent name")
        
        if cname in ('ESRM','ERFT','EDIR'):
            if mp != sp:
                self._error("for cal coeff '%s' srcport and measport must be the same"%cname)
        else:
            if mp == sp:
                self._error("for cal coeff '%s' srcport and measport must not be the same"%cname)
        
        return cname,mp,sp
            
        
        
# register family names for VNA instruments        
register_family_name('vna',NetworkAnalyzer)
register_family_name('nwa',NetworkAnalyzer)
register_family_name('pna',NetworkAnalyzer)
register_family_name('ena',NetworkAnalyzer)
register_family_name('networkanalyzer',NetworkAnalyzer)

