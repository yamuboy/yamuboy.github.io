from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, timed_wait_ms
from . import register_family_name

class Autoprober(GenericInstrument):
    """A driver for auto-probers."""
    
    def __init__(self,resource_name,**kwargs):
        """Create the object."""
        super(Autoprober,self).__init__(resource_name,**kwargs)
    
    def config(self, **kwargs):
        """Every autoprober instrument must implement this method though
        it might not actually do anything.
        
        Standard Keywords:
        --------------------------------------------
        *** none defined yet ***
        """
        raise NotImplementedError
    
    def query(self, kw):
        """Query the driver for the value of a keyword.
        
        This is a default implementation that could be replaced if
        additional logic is required.
        """
        return self._get_params(0).get(kw)

    def set_position(self, x, y, synch=False):
        """Set the prober (x,y) position. This is an asyncronous
        operation by default, though the 'synch' keyword can force synchronous
        operation.
        """
        raise NotImplementedError
        
    def get_position(self):
        """Get the current prober (x,y) position."""
        raise NotImplementedError
        
    def ask_if_done(self):
        """Check to see if an asynchronous move is done."""
        raise NotImplementedError
    
    def set_position_synch(self, x, y):
        """Convenience method for calling set_position() with the 'synch'
        keyword set to True.
        """
        return self.set_position(x,y,synch=True)
 
# register family names for autoprober instruments        
register_family_name('prober',Autoprober)
register_family_name('autoprober',Autoprober)
register_family_name('probestation',Autoprober)


 
        