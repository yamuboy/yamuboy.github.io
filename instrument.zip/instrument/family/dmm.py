from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, MeasurementInstrument, timed_wait_ms
from . import register_family_name

class dmm(GenericInstrument, MeasurementInstrument):
    
    def config(self,**kwargs):
        raise NotImplementedError
        
    def measure(self):
        raise NotImplementedError

register_family_name('dmm',dmm)
register_family_name('multimeter',dmm)