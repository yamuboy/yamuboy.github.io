from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, timed_wait_ms
from . import register_family_name

class PulserInstrument(GenericInstrument):

    def __init__(self,resource_address,**kwargs):
        super(PulserInstrument,self).__init__(resource_address,**kwargs)
    def config(self, **kwargs):

        """
        Keywords:

        width- Pulse width, minimum pulse width is 0.3us, maximum pulse width is Period-36us
        period- Pulse Period, minimum pulse period is 36 us, maximum period is 2200us 
        vgq- Gate Quiescent Voltage
        vdq- Drain Quiescent Voltage
        vdp- pulsed drain voltage
        vgp- pulsed gate voltage
        pulser_mode- Pulser mode, OFF or PULSE
        drain_mode- usage DRAIN [OFF|ON|QUI|PULSE|?] <Von> <Vqui>
                    OFF, ON, QUI, PULSE
                    OFF- Opens the drain output relay, output becomes floating
                    ON- Keeps the output constant at VON voltage, useful for DCIV
                    QUI- Keeps the output constant at Vqui voltage
                    PULSE- toggle ouput between Vqui and Von
        gate_mode-  usage GATE [OFF|ON|QUI|PULSE|?] <Von> <Vqui>
                    OFF, ON, QUI, PULSE
                    OFF- Opens the gate output relay, output becomes floating
                    ON- Keeps the output constant at VON voltage, useful for DCIV
                    QUI- Keeps the output constant at Vqui voltage
                    PULSE- toggle ouput between Vqui and Von
        trigger-   trigger mode, can be FREE, EXTERNAL or SINGLE
        pre_us- pre delay used by the pulse generator
        post_us- post delay used by the pulse generator
        timing- GATE or DRAIN, sets the timing, pre and post on either the gate or drain
                usage- TIMING [GATE|DRAIN] <pre_us> <post_us>
        reset- reset the microcontroller and the tcp-ip communication, 0/1
        state- on/off. Set the state of the pulser. Setting the state on sets the relay to 1, off to 0.
                                
        """
        raise NotImplementedError

    def query(self, kw, chan=None):
        return self._get_params(chan=chan).get(kw)

    def init(self,**kwargs):
        raise NotImplementedError

    def init_pulser(self,**kwargs):
        raise NotImplementedError

    def setup(self,**kwargs):
        self.configure(**kwargs)

    def enable(self):
        raise NotImplementedError
    
    def disable(self):
        raise NotImplementedError
        
# register family names for dcpulser instruments        
register_family_name('dcpulser',PulserInstrument)
register_family_name('pulser',PulserInstrument)
        
        
        
        
