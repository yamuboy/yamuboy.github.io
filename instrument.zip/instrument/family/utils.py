from __future__ import division, print_function, unicode_literals, absolute_import
import re
from .. import GenericInstrument, BadFamilyName

class _InstrumentFamilyRegistry(object):
    """registry of instrument families
    
    each family can register 1 or more string names for
    the family such as 'bias', 'vna', etc that can be
    used in a call to one of the InstrumentManager
    driver loading methods
    
    there is only 1 object of this class instanciated
    """
    __reg = dict()
    
    def register(self, name, ty):
        """register a new family name
        
        name is an ASCII string
        ty is a type object derived from `instrument.GenericInstrument`
        """
        n = name.lower().strip()
        if n in self.__reg:
            if self.__reg[n] is not ty:
                raise ValueError("family name '%s' is already in use by '%s'"%(n,ty))
            return
        
        if not issubclass(ty,GenericInstrument):
            raise TypeError("type object subclassed from `GenericInstrument`")
        
        self.__reg[n] = ty
    
    def get(self, name):
        "get the type object for a given name"
        n = name.lower()
        if n in self.__reg:
            return self.__reg[n]
        return None
    
    @property
    def list_names(self):
        "list all family names"
        lst = self.__reg.keys()
        lst.sort()
        return lst
        
    
    
_registry = _InstrumentFamilyRegistry()

def get_instr_family_from_str(family):
    """Get a type object for the instrument family
    
    family - a string representation of the family
    
    returns a type object
    """
    ty = _registry.get(family)
    if ty is None:
        raise BadFamilyName("'%s'"%family)
    return ty

def register_family_name(name, ty):
    "wrapper for registering instrument families"
    _registry.register(name,ty)

def list_family_names():
    "returns a list of registered family names"
    return _registry.list_names
    
    