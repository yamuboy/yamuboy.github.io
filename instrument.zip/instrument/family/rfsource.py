from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, timed_wait_ms
from . import register_family_name

class RFSource(GenericInstrument):
    """Generic "family" implementation of an RF
    signal source such as a signal generator, sweeper, or
    a VNA being operated as a simple source.
    """
    
    def config(self, **kwargs):
        """configure the instrument (this is the workhorse method)
        
        Keywords:
        state - bool, set the state of the RF to on (True) or off (False)
        plevel - float, set the output power in dBm
        freq - float, set the output frequency in Hz
        
        Instrument-specific keywords can also be used, though the use of them
        would make the driver less portable.

        In the implementation of the drivers, passed keywords that are completely
        invalid for the capabilities of the instrument should raise exceptions.
        Keywords or keyword values that can be safely ignored should be ignored.
        Unrecognized (instrument-specific) keywords should generate warnings.        
        """
        raise NotImplementedError
    
    def set_freq(self, f, chan=None):
        "convenience function for setting frequency"
        self.config(freq=f)
                
    def set_power(self, p, chan=None):
        "convenience function for setting frequency"
        self.config(plevel=p)
    
    def set_state(self, s, chan=None):
        self.config(state=s)
    
    def get_freq(self, chan=None):
        "get the current frequency in Hz"
        raise NotImplementedError
    
    def get_power(self, chan=None):
        "get the current output power level in dBm"
        raise NotImplementedError
    
    def get_state(self, chan=None):
        "get the current output state"
        s = self.query('state',chan)
        if s is None:
            raise NotImplementedError
        return s
    
    
    
# register family names for this family
register_family_name('rfsource',RFSource)
register_family_name('siggen',RFSource)
register_family_name('signalsource',RFSource)
register_family_name('signalgenerator',RFSource)

