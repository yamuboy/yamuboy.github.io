from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, MeasurementInstrument, timed_wait_ms
from . import register_family_name

class PowerMeter(GenericInstrument, MeasurementInstrument):
    """Generic implementation of a power meter"""

    def config(self, **kwargs):
        """workhorse method for configuring the meter
        
        Standard Keywords:
        offset - float, power measurement offset in dBm
        freq - float, frequency of measured power in Hz 
        mode - string, sensor measurement mode can be one of: 'CW', 'PULSE', or 'MOD' **

        ** not all sensors/meters can support all of these measurment modes
        
        """
        raise NotImplementedError
    
# register family names
register_family_name('powermeter',PowerMeter)
register_family_name('pmeter',PowerMeter)