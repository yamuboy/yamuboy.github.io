from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, timed_wait_ms
from . import register_family_name

class CustomInstrument(GenericInstrument):
    """ This class defines a custom instrument which could be any instrument that does not
        fall under the family of instruments currently defined. This class should be used as a family
        for instruments that are bench/test specific. Instruments like the ASX16C used for CATV distortion measurements
    """
    def config(self,**kwargs):
        """Use this to configure the instrument."""
        raise NotImplementedError
    def init(self,**kwargs):
        """Use this to initialize the instrument or put it in a safe operating mode"""
        raise NotImplementedError
        
register_family_name('custom',CustomInstrument)
