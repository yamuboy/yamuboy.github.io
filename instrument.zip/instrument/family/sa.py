from __future__ import division, print_function, unicode_literals, absolute_import
from .. import GenericInstrument, timed_wait_ms
from . import register_family_name

class SpectrumAnalyzer(GenericInstrument):
    """Driver for specturm analyzer instruments."""
    
    def set_reflevel(self,level):
        """Set the reference level of the anaylzer."""
        raise NotImplementedError
        
        
    def set_atten(self,att=None):
        """Set the RF attenuator value.
        
        If called with no arguments, the RF attentuator is set
        to "auto" mode (if supported), or the default of the instrument.
        """
        raise NotImplementedError
        
        
    def set_freqs(self,start=None,stop=None,**keyw):
        """Set the frequencies for the analyzer.
        """
        raise NotImplementedError
    
    def set_bandwidth(self,rbw=None,vbw=None,**keyw):
        """Set the bandwidths (resolution and video).
        
        The default value of None sets the bandwidths to "auto".
        """
        raise NotImplementedError
        
        
    def set_marker(self,*args,**keyw):
        """Set the marker position.
        
        The keywords determine how the marker will be placed,
        the default with no arguments is to place it at the center
        of the band.
        """
        raise NotImplementedError
    
    def set_trigger(self,mode=None):
        """Set the trigger mode.
        
        The default trigger mode is free-run, which is set
        by leaving the mode parameter at the default of None.
        
        Other trigger modes are:
        'external' or 'ext'
        'single'
        """
        raise NotImplementedError
        
        
    def trigger(self):
        """Trigger a sweep.
        
        If the analyzer is set in free-run or external mode, the
        trigger mode will be set to 'single' before initiating
        a new trigger sequence.
        """
        raise NotImplementedError
    
    def is_done(self):
        """Check that the last triggered sweep is done.
        
        Returns true if the sweep is completed, false otherwise.
        """
        raise NotImplementedError
    
    def get_trace(self,fmt=None):
        """Returns a single trace of data.
        
        The fmt parameter can be used to modify the returned data
        format.
        
        This function will not check that the measurement is done
        and therefore could cause a timeout if the analyzer is
        in the middle of the long sweep.
        """
        raise NotImplementedError
    
    def get_marker(self):
        """Get the position and value of the current marker.
        
        The data is returned as a tuple of the form (freq,value)
        
        This will not wait for a measurement to finish.  It is up to
        the user to check this.
        """
        raise NotImplementedError
    
register_family_name('sa',SpectrumAnalyzer)
register_family_name('specan',SpectrumAnalyzer)    
register_family_name('specana',SpectrumAnalyzer)    
        
        
