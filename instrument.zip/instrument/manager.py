from __future__ import division, print_function, unicode_literals, absolute_import
from .base import InstrumentManager, register
