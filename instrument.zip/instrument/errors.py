from __future__ import division, print_function, unicode_literals, absolute_import

class Error(Exception):
    "base exception for all errors"
    pass


class InstrumentError(Error):
    "Base exception for instrument-related errors"
    def __init__(self,msg=None,*args,**kwargs):
        super(InstrumentError,self).__init__(msg) 

class DriverNotFound(Error):
    "Exception for when a driver cannot be located"
    pass
      
class InvalidDriver(Error):
    "Exception for a driver that does not have a valid class hierarchy or subclass type"    
    pass
      
class BadFamilyName(Error):
    "Exception for when an invalid instrument family name is encountered"
    pass
        
        
try:
    from pyvisa.errors import Error as VisaError, VisaIOError
except ImportError:
    try:
        # try to load the exceptions from older versions of pyVisa 
        from pyvisa.visa_exceptions import Error as VisaError, VisaIOError
    except ImportError:
        # pyvisa might not be present on a testing system
        # create dummy versions for the VISA exceptions
        class VisaError(Exception):
            "base class for all VISA exceptions"
            pass
        
        class VisaIOError(VisaError):
            "exception for all I/O-related errors"
            pass
    
    
    

