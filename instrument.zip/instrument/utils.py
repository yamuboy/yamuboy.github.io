from __future__ import division, print_function, unicode_literals, absolute_import
import time

try:
    _int_types = (int,long)
except NameError:
    # python3
    _int_types = (int,)

def is_integer( n ):
    """Check if the passed parameter is an integer."""
    return isinstance(n,_int_types)
    
def timed_wait( seconds ):
    """Start a timed wait period."""
    start = time.time()
    remain = float(seconds)
    while remain > 0.0:
        time.sleep(remain)
        stop = time.time()
        remain = seconds - (stop-start)
    
def timed_wait_ms( milliseconds ):
    """Start a timed wait period."""
    timed_wait(milliseconds*1.0e-3)
