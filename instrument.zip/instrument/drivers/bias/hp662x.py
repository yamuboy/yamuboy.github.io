from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import BiasInstrument, VOLTAGE, CURRENT
from .. import timed_wait_ms, register

class HP662x_Driver(BiasInstrument):
    """HP/Agilent 6625A/6626A/6628A/6629A 2 or 4 channel power supply driver"""
    
    drvname = 'HP 662xA'
    regex = r'(hp)?662[5689x].*'
    
    def __init__(self,*args,**kwargs):
        """Create the driver object."""
        # define capabilities and call the parent initializer
        kwargs['capabilities'] = ('source_v','source_i',
            'measure_v','measure_i',)
        super(HP662x_Driver,self).__init__(*args,**kwargs)
        
        # check the default channel and make sure it is legal
        if self.chan == 0:
            self.chan = 1
        
        # run the instrument init routine
        self.init()
                
    def init(self, force=False):
        """
        Initialize the driver and instrument.
        force can be set to True to force re-initialization of the instrument
           (it is used by the reinit() method to do just that)
        """
        
        # run the initialization, if it has not been run
        if self.vi is not None and (not hasattr(self.vi,'_hp662xmodel') or force):
            # query the ID string, check it for validity, and store the model number
            idstr = self.vi.ask("CLR;ID?")
            model = None
            for m in ('6625A','6626A','6628A','6629A','6632A','6624A'):
                if idstr.find(m) > -1:
                    model = m
                    break
            if model is None:
                self._error("driver does not support this instrument.")
            self.vi._hp662xmodel = model
                    
            # configure legal channels for the detected instrument type
            if model in ('6626A','6629A','6624A'):
                maxchan = 4
                self._config_legal_channels( [1,2,3,4] )
            elif model in ('6625A','6628A'):
                maxchan = 2
                self._config_legal_channels( [1,2] )
            else:
                maxchan= 1
                self._config_legal_chanels([1])
                
            # set up the channel configuration dictionaries
            for i in range(1,5):
                if model in ('6625A','6628A',) and i > 2:
                    break
                p = self._get_params(i)
                p['state'] = 0
                p['mode'] = VOLTAGE
                p['vset'] = 0.0
                p['iset'] = 0.0
                self.vi.write("OUT%d,0;OCP%d,0;VSET%d,0;ISET%d,0"%(i,i,i,i))
                    
    def _close(self):
        """Stuff to be done prior to closing the VISA interface."""
        self._vicheck()
        
        # shut off the output
        self.vi.write("OUT%d,0"%self.chan)
        self._get_params()['state'] = 0
        
    def config(self,chan=None,**kwargs):
        """Set configuration parameters. This is the workhorse method.
        
        This method obeys the following standard keywords:
        mode, state, vset, iset, vlimit, ilimit,
        vrange, irange, vmrange, imrange        
	    """
        self._vicheck()
        
        p = self._get_params(chan)
        mode = p['mode']
        ch = self._get_channel(chan=chan)
        
        # store ranges and limits
        rlkw = ('vlimit','ilimit','vrange','irange','vmrange','imrange')
        for k in rlkw:
            if k in kwargs:
                v = kwargs.pop(k)
                # check that the value is OK
                if v is None:
                    p[k] = v
                else:
                    try:
                        p[k] = abs(float(v))
                    except ValueError:
                        raise ValueError(k)
                        
        # store changes in the vset/iset values
        vset, iset = False, False
        if 'vset' in kwargs:
            p['vset'] = float(kwargs.pop('vset'))
            vset = True
        if 'iset' in kwargs:
            p['iset'] = float(kwargs.pop('iset'))
            iset = True
        
        mode_changed = False
        if 'mode' in kwargs and mode != kwargs['mode']:
            # need to change the operating mode
            mode = kwargs.pop('mode')
            if mode not in (VOLTAGE,CURRENT):
                raise ValueError("Invalid 'mode'.")
            self.vi.write("OUT%d,0"%ch)
            timed_wait_ms(50)
            p['mode'] = mode
            p['state'] = 0
            mode_changed = True
            
        # set the source
        v, i, rng = self._hp662x_src_compl(mode,p,ch)
        if mode == VOLTAGE and (mode_changed or vset):
            self.vi.write("VRSET%d,%g;ISET%d,%g;VSET%d,%g"%(ch,rng,ch,i,ch,v))
        elif mode == CURRENT and (mode_changed or iset):
            self.vi.write("IRSET%d,%g;VSET%d,%g;ISET%d,%g"%(ch,rng,ch,v,ch,i))
        
        # determine the instrument output state
        if 'state' in kwargs:
            s = bool(kwargs.pop('state'))
            if s and not p['state']:
                self.vi.write('OUT%d,1'%ch)
                p['state'] = 1
            elif not s and p['state']:
                self.vi.write('OUT%d,0'%ch)
                p['state'] = 0
        
        # pass additional keyword arguments on to pyVISA
        if len(kwargs):
            self.configure_vi(**kwargs)

    def initiate(self,chan=None):
        """Initiate a measurement."""
        self._vicheck()
        if self._use_srqs:
            # don't know what to do here
            pass
        # instrument measures continuously
        # no need to do anything
        
    def ask_if_done(self,chan=None):
        """Check to see if a pending measurement is done."""
        # this instrument has no capacity for trigger, so it
        # is always ready to measure
        return True
    
    def fetch(self,chan=None):
        """Retrieve a measurement from the instrument."""
        self._vicheck()
        p = self._get_params(chan)
        ch = self._get_channel(chan=chan)
        # read voltage and current
        vm = float(self.vi.ask('VOUT?%d'%ch))         
        im = float(self.vi.ask('IOUT?%d'%ch))    
        if p['mode'] == CURRENT:
            ret = vm
            if abs(vm - p['vlimit']) < 0.08 and abs(im - p['iset']) > 0.003:
                p['limiting'] = True
        else:
            ret = im
            if abs(im - p['ilimit']) < 0.003 and abs(vm - p['vset']) > 0.08:
                p['limiting'] = True
        return ret
    
    def _hp662x_src_compl(self,srcmode,params,chan):
        """Get a corrected source and compliance value based on the instrument
        model and current source mode.  This is to prevent front panel warnings from
        mismatched parameters to the instrument.
        """
        def limit_value(var, val):
            """Local function to limit the value of a variable."""
            if var > val:
                return val
            return var
            
        if self.vi._hp662xmodel in ('6625A','6628A',):
            lowchans = (1,)
            hichans = (2,)
        else:
            lowchans = (1,2,)
            hichans = (3,4,)
        
        if srcmode == CURRENT:
            i = params.get('iset',0.0)
            v = params.get('vlimit')
            if v is None or v > 50.0:
                v = 50.0
            
            if chan in lowchans:
                rng = 0.5
                if i > 0.5:
                    i = 0.5
            else:
                rng = 2.0
                if i > 2.0:
                    i = 2.0
        else:
            v = params.get('vset',0.0)
            i = params.get('ilimit')
            if v > 50.0:
                v = 50.0
            rng = 50.0
            
            if chan in lowchans:
                if i is None or i > 0.5:
                    i = 0.5
            else:
                if i is None or i > 2.0:
                    i = 2.0
        
        return v, i, rng
        
        
# add the class to the instrument manager
register(HP662x_Driver)


