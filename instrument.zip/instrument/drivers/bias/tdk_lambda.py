from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import BiasInstrument, VOLTAGE, CURRENT
from .. import timed_wait_ms, register

class Lambda(BiasInstrument):
    "driver the TDK Lambda power supply"
    
    drvname = 'TDK xxxx'
    regex = r'(?:tdk)?lambda'
    
    def __init__(self, *args, **kwargs):
        "object initializer"
        # init parent
        kwargs['capabilities']= ('source_v','measure_i',)
        super(Lambda,self).__init__(*args,**kwargs)
        
        # init instrument
        self.init()

    def init(self, force=False):
        "instrument initializer"
        if self.vi and (force or not hasattr(self.vi,'_tdklambda')):
            model = self.vi.ask('*IDN?')
            if model.find('Lambda') < 0:
                self._error('instrument not supported')
            
            # initialize the supply to a known condition
            
            
            
            
            p = self._get_params(0)
            p['mode']= 'V'
            p['vset']= 0.0
            p['iset']= 0.1
            p['state']= 0
            p['vlimit']= 0.0
            p['ilimit']= 0.0
              
                
    def config(self, **kwargs):
        "configure the supply"
        self._vicheck()
        p = self._get_params(0)
        
        if not hasattr(self.vi,'_tdklambda'):
            self._error("init() must be called before config()")

        req_state = None
        if 'state' in kwargs:
            req_state = bool(kwargs.pop('state'))
            if not req_state:
                # shut off supply
                self.vi.write('OUTP:STAT 0')
                p['state'] = 0
                timed_wait_ms(50)
        
        if 'mode' in kwargs:
            mode = kwargs.pop('mode').upper()
            if mode != 'V':
                self._error("supply can only source voltage")            

        if 'ilimit' in kwargs:
            v = kwargs.pop('ilimit')
            if v is None:
                p['ilimit'] = None            
            else:
                p['ilimit'] = float(v)
            self.vi.write(':CURR %g'%self._lambda_ilimit(p['ilimit']))
            timed_wait_ms(30)
                
        if 'vset' in kwargs:
            p['vset'] = float(kwargs.pop('vset'))
            self.vi.write(':VOLT %g'%p['vset'])
                
        if req_state:
            # turn on output
            self.vi.write('OUTP:STAT 1')
            timed_wait_ms(100)
            p['state'] = 1
        
        # clean out keywords that are ignored by this driver
        for k in ('vlimit','irange','imrange','vrange','vmrange','iset','resolution','remote'):
            if k in kwargs:
                kwargs.pop(k)
                
        # pass remaining keywords on the VISA
        if len(kwargs):
            self.configure_vi(**kwargs)
        
    def initiate(self, chan=None):
        "start a measurement"
        pass
        
    def ask_if_done(self, chan=None):
        "ask if a measurement has been completed"
        return True
        
    def fetch(self, chan=None):
        "fetch a measurement"
        self._vicheck()
        p = self._get_params(0)
        if p['mode'] == 'V':
            val = float(self.vi.ask('MEAS:CURR?'))
        else:
            val = float(self.vi.ask('VOLT?'))
            
        #TODO: check for limiting
        
        return val
    
    def _lambda_ilimit(self, v):
        "set a valid current limit"
        
        
        
        #todo
        
        
        return v
        
        
# add the driver to the registry
register(Lambda)
        
