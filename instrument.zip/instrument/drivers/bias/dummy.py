from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import BiasInstrument, VOLTAGE, CURRENT
from .. import timed_wait_ms, register, DummyInstrument
import random

class dummy(DummyInstrument, BiasInstrument):
    """Virtual bias driver"""

    drvname = 'dummy'
    regex = r'dummy'

    def __init__(self,*args,**kwargs):
        minval = kwargs.pop('minval', -10.0)
        maxval = kwargs.pop('maxval', 10.0)
        super(dummy, self).__init__(*args, **kwargs)

        self._minval = minval
        self._maxval = maxval

    def _close(self):
        """Stuff to be done prior to closing the VISA interface."""
        pass

    def config(self,chan=None,**kwargs):
        """Set configuration parameters. This is the workhorse method.

        This method obeys the following standard keywords:
        mode, state, vset, iset, vlimit, ilimit,
        vrange, irange, vmrange, imrange

        Instrument-specific keywords:
        remote - boolean indicating whether remote sensing should be enabled
        resolution - string indicating the desired instrument measurement resolution
           can be be one of 'low', 'medium', 'high', or 'very high'
	    """
        pass

    def initiate(self,chan=None):
        """Initiate a measurement."""
        pass

    def ask_if_done(self,chan=None):
        """Check to see if a pending measurement is done."""
        # always done
        return True

    def fetch(self,chan=None):
        """Returns a random float between on interval [self._minval, self._maxval] not including [-1e-12, 1e-12] to avoid divide by zero"""
        result = 0.0
        while abs(result < 1e-12):
            result = random.uniform(self._minval, self._maxval)
        return result

# add the class to the instrument manager with an appropriate regular expression
register(dummy)


