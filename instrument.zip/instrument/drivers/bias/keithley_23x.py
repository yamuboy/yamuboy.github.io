from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import BiasInstrument, VOLTAGE, CURRENT
from .. import timed_wait_ms, register
import re, math

if not hasattr(math,'copysign'):
    # older python2 does not define this
    math.copysign = lambda v1, v2: -v1 if v2 < 0.0 else v1

class Keithley23x_Driver(BiasInstrument):
    """Driver for Keithley 236/237/238 SMUs."""
    
    drvname = 'Keithley 23x'
    regex = r'k?(?:eithley)?23[x678]'
    
    def __init__(self,*args,**kwargs):
        """Create the driver object."""
        # define capabilities and call the parent initializer
        kwargs['capabilities'] = ('source_v','source_i',
            'measure_v','measure_i','bipolar',)
        super(Keithley23x_Driver,self).__init__(*args,**kwargs)
        
        # automatically run the initialization, if it has not been run
        if self.vi is not None and not hasattr(self.vi,'_k23Xmodel'):
            self.init()
    
    def init(self):
        """Initialize the instrument."""
        # query the ID string, check it for validity, and store the model number
        self.vi.write("U0X")
        timed_wait_ms(10)
        idstr = self.vi.read()
        timed_wait_ms(10)
        model = idstr[:3]
        if model not in ('236','237','238'):
            self._raise_error('instrument not supported')
        self.vi._k23Xmodel = model
        
        # do a "preset"
        self.vi.write("J0X")
        timed_wait_ms(300)
        
        # set some params
        p = self._get_params(0)
        p['state'] = 0
        p['mode'] = VOLTAGE
        p['vset'] = 0.0
        p['iset'] = 0.0
        p['_averaging'] = 'P1'
        p['_sensing'] = 'O0'
        p['_integration'] = 'S2'
        
        # set the data format and triggering
        self.vi.write("G4,0,0X")
        timed_wait_ms(10)
        
    def _close(self):
        """Stuff to be done prior to closing the VISA interface."""
        # shut off the output 
        self.config(state=0)
        
    def config(self,chan=None,**kwargs):
        """Set configuration parameters. This is the workhorse method.
        
        This method obeys the following standard keywords:
        mode, state, vset, iset, vlimit, ilimit,
        vrange, irange, vmrange, imrange
        
        remote - boolean, remote sensing enable
        resolution - string, one of 'low', 'medium', 'high', or 'very high'
          
        # deprecated keywords
        sensing - (string) 'local' or 'remote'
        averaging - (int) requesting averaging [deprecated, use 'resolution' instead]
        integration - (string) 'fast', 'slow', or 'linecycle'          
	    """
        
        p = self._get_params(0)
        if not '_averaging' in p:
            self._raise_error("init() method must be called before config() can be used.")
        
        # store ranges and limits
        rlkw = ('vlimit','ilimit','vrange','irange','vmrange','imrange')
        for k in rlkw:
            if k in kwargs:
                v = kwargs.pop(k)
                # check that the value is OK
                if v is None:
                    p[k] = v
                else:
                    try:
                        p[k] = abs(float(v))
                    except ValueError:
                        raise ValueError(k)
                        
        # store changes in the vset/iset values
        vset, iset = False, False
        if 'vset' in kwargs:
            p['vset'] = float(kwargs.pop('vset'))
            vset = True
        if 'iset' in kwargs:
            p['iset'] = float(kwargs.pop('iset'))
            iset = True
        
        # determine the instrument output state
        req_state = None
        if 'state' in kwargs:
            req_state = bool(kwargs.pop('state'))
            if not req_state:
                # immediately shut off the output
                self.vi.write("N0XR0XT4,0,0,0R1XH0X")
                p['state'] = 0
                timed_wait_ms(50)
        
        mode_changed = False
        if 'mode' in kwargs:
            newmode = kwargs.pop('mode').upper()
            if p['mode'] != newmode:
                # need to change the operating mode
                if newmode not in (VOLTAGE,CURRENT):
                    raise ValueError("Invalid 'mode'.")
                if newmode == VOLTAGE:
                    s = 'F0,0H0X'
                else:
                    s = 'F1,0H0X'
                self.vi.write(s)
                p['mode'] = newmode
                if p['state'] and req_state is None:
                    # supply was on and no state change was requested
                    # need to turn it back on since
                    # a mode change will shut off the Keithley
                    req_state = True
                p['state'] = 0
                mode_changed = True
                timed_wait_ms(300)
                    
        cfgstr = ''
        # set resolution
        if 'resolution' in kwargs:
            res_map = {'very low':'S0P0', 'low':'S1P0', 'medium':'S2P1', 'high':'S2P3', 'very high':'S2P5'} 
            v = kwargs.pop('resolution').lower()
            if v not in res_map:
                self._raise_error("'resolution' must be one of: 'very low', 'low', 'medium', 'high', or 'very high'")
            p['_resolution'] = res_map[v]
            kwargs.pop('integration',None)
            kwargs.pop('averaging',None)
            cfgstr += p['_resolution']
        elif 'integration' in kwargs or 'averaging' in kwargs:
            if 'integration' in kwargs:
                integ_map = {'fast':'S0', 'slow':'S1', 'linecycle':'S2'}
                v = kwargs.pop('integration').lower()
                if v not in integ_map:
                    self._raise_error("'integration' must be one of: 'fast', 'slow', or 'linecycle'")
                mv = integ_map[v]
                p['_integration'] = mv
            if 'averaging' in kwargs:
                try:
                    v = int(kwargs.pop('averaging'))
                except ValueError:
                    v = 0
                if v > 16: avg = "P5"
                elif v > 8: avg = "P4"
                elif v > 4: avg = "P3"
                elif v > 2: avg = "P2"
                elif v > 1: avg = "P1"
                else: avg = "P0"
                p['_averaging'] = avg
            p['_resolution'] = p['_integration'] + p['_averaging']
            cfgstr += p['_resolution']
        
        # set local or remote sensing
        if 'remote' in kwargs:
            v = bool(kwargs.pop('remote'))
            if v:
                p['_sensing'] = 'O1'
            else:
                p['_sensing'] = 'O0'
            cfgstr += p['_sensing']
            kwargs.pop('sensing',None)
        elif 'sensing' in kwargs:
            sense_map = {'local':'O0', 'remote':'O1'}
            v = kwargs.pop('sensing').lower()
            if v not in sense_map:
                self._raise_error("'sensing' must be one of 'local' or 'remote'")
            mv = sense_map[v]
            p['_sensing'] = mv
            cfgstr += mv
        
        if mode_changed or req_state == True:
            # when changing modes or switching on the output,
            # force sensing and resolution to be set
            cfgstr = p['_sensing'] + p['_resolution']
            
        # determine what to write for source values
        if p['mode'] == VOLTAGE and (mode_changed or vset or req_state is not None):
            s,c,sr,cr = self._k23x_src_compl(p['mode'],p)
            self.vi.write(cfgstr+"L%.4e,%dB%.4e,%d,0H0X"%(c,cr,s,sr))
            timed_wait_ms(30)
        elif p['mode'] == CURRENT and (mode_changed or iset or req_state is not None):
            s,c,sr,cr = self._k23x_src_compl(p['mode'],p)
            self.vi.write(cfgstr+"L%.4e,%dB%.4e,%d,0H0X"%(c,cr,s,sr))
            timed_wait_ms(30)
        
        # determine the instrument output state
        if req_state and not p['state']:
            # turn on the output
            self.vi.write("R0XT4,2,0,0R1XN1H0X")
            p['state'] = 1
            timed_wait_ms(50)

        # pass additional keyword arguments on to pyVISA
        if len(kwargs):
            self.configure_vi(**kwargs)

    def initiate(self,chan=None):
        """Initiate a measurement."""
        # set a flag to show that a measurement has been requested
        p = self._get_params(0)
        p['_measuring'] = True
        
        ## wait for a "ready for trigger" condition
        while True:
            s = self.vi.stb
            timed_wait_ms(20)
            if s & 32:
                # error!
                self._raise_error("error occurred in 'wait for trigger-ready' loop")            
            elif s & 16:
                # ready for trigger
                break
        
        #srq = 'M0,0X'
        #if self._use_srqs:
        #    srq = 'M136,1X'
        #self.vi.write(srq+"H0X")
        self.vi.write("H0X")
        timed_wait_ms(20)
        
    def ask_if_done(self,chan=None):
        """Check to see if a pending measurement is done."""
        # ignore keywords since the only keyword that could be useful
        # is the 'channel' keyword and this is a single channel instrument
        if not self._get_params(0).get('_measuring'):
            self._raise_error('no measurement pending')
        return True
        #result = self.vi.stb
        #if result & 8: return True
        #return False
    
    def fetch(self,chan=None):
        """Retrieve a measurement from the instrument."""
        p = self._get_params(0)
        if not p.get('_measuring'):
            self._raise_error('no measurement pending')
        m = self.vi.read()
        # this wait is important
        timed_wait_ms(20)
        # clear the SRQ mode
        #if self._use_srqs:
        #    self.vi.write('M0,0X')
        #    # this wait is important
        #    timed_wait_ms(10)
        stat = m[:5]
        val = float(m[5:].split(',')[0])
        # reset the measuring flag
        p['_measuring'] = False
        # if the measurement is in compliance, set the limiting flag
        if stat[:1] == 'O': p['limiting'] = True
        else: p['limiting'] = False
        return val
    
    def _k23x_src_compl(self,srcmode,params):
        """Get a corrected source and compliance value based on the instrument
        model and current source mode.  This is to prevent front panel warnings from
        mismatched parameters to the instrument.
        """
        def limit_value(var, val):
            """Local function to limit the value of a variable."""
            if var > val:
                return val
            return var
        
        if srcmode == VOLTAGE:
            srcval = params.get('vset',0.0)
            compl = params.get('ilimit')
        else:
            srcval = params.get('iset',0.0)
            compl = params.get('vlimit')
            
        sabs = abs(srcval)
        try:
            compl = float(compl)
        except:
            compl = 1.0e12
        
        if srcmode == VOLTAGE:
            #### voltage mode ####
            sr = self._k23x_range(VOLTAGE,params.get('vrange'))
            if self.vi._k23Xmodel == '238':
                # limit source voltage to 150 V
                sabs = limit_value(sabs,150.0)
                # limit the compliance to 0.1 A if source voltage is > 15 or
                # the source range is set to 3, limit it to 1.0 A otherwise
                if sabs > 15.0 or sr == 3: compl = limit_value(compl,0.1)
                else: compl = limit_value(compl,1.0)
            else:
                if self.vi._k23Xmodel == '237':
                    # limit source voltage to 1100 V
                    sabs = limit_value(sabs,1100.0)
                    # limit the compliance to 0.01 A if source voltage is > 110 or
                    # the source range is set to 4, limit it to 0.1 A otherwise
                    if sabs > 110.0 or sr == 4: compl = limit_value(compl,0.01)
                    else: compl = limit_value(compl,0.1)
                else:  # K236
                    # limit source voltage to 110 V and compliance to 0.1 A
                    sabs = limit_value(sabs,110.0)
                    compl = limit_value(compl,0.1)
            # determine measurement/compliance range
            mrange = params.get('imrange')
            if mrange is not None and mrange < compl:
                # measurement range must be at least equal to compliance
                mrange = compl
            cr = self._k23x_range(CURRENT,mrange)
        else:
            #### current mode ####
            sr = self._k23x_range(CURRENT,params.get('irange'))
            if self.vi._k23Xmodel == '238':
                # limit source current to 1 A
                sabs = limit_value(sabs,1.0)
                # limit the compliance to 15 V if source current is > 0.1 or
                # the source range is set to 10, limit it to 150 V otherwise
                if sabs > 0.1 or sr == 10: compl = limit_value(compl,15.0)
                else: compl = limit_value(compl,150.0)
            else:
                # limit source current to 0.1 A
                sabs = limit_value(sabs,0.1)
                if self.vi._k23Xmodel == '237':
                    # limit the compliance to 110 V if source current is > 0.01 or
                    # the source range is set to 9, limit it to 1100 V otherwise
                    if sabs > 0.01 or sr == 9: compl = limit_value(compl,110.0)
                    else: compl = limit_value(compl,1100.0)
                else: # K236
                    # limit compliance to 110 V
                    compl = limit_value(compl,110.0)
            # determine measurement/compliance range
            mrange = params.get('vmrange')
            if mrange is not None and mrange < compl:
                # measurement range must be at least equal to compliance
                mrange = compl
            cr = self._k23x_range(VOLTAGE,mrange)
            
        return math.copysign(sabs,srcval),compl,sr,cr
        
    def _k23x_range(self,mode,value):
        """Get the fixed range for a given mode/value pair.
        mode - the source mode
        value - the voltage/current value to find the range for
        """
        if value is None:
            # auto range
            return 0
        
        r = 0
        if mode == VOLTAGE:
            # voltage
            if self.vi._k23Xmodel == '238':
                if value <= 1.5: r = 1
                elif value <= 15.0: r = 2
                elif value <= 150.0: r = 3
            else:
                if value <= 1.1: r = 1
                elif value <= 11.0: r = 2
                elif value <= 110.0: r = 3
                elif value <= 1100.0 and self.vi._k23Xmodel == '237': r = 4
        else:
            # current
            if value <= 1.e-9: r = 1
            elif value <= 1.e-8: r = 2
            elif value <= 1.e-7: r = 3
            elif value <= 1.e-6: r = 4
            elif value <= 1.e-5: r = 5
            elif value <= 1.e-4: r = 6
            elif value <= 1.e-3: r = 7
            elif value <= 1.e-2: r = 8
            elif value <= 1.e-1: r = 9
            elif value <= 1.0 and self.vi._k23Xmodel == '238': r = 10
        return r

# add the class to the instrument manager with an appropriate regular expression
register(Keithley23x_Driver)


