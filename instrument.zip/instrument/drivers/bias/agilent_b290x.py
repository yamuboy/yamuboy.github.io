from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import BiasInstrument, VOLTAGE, CURRENT
from .. import timed_wait_ms, register

class Agilent_B29XX_Driver(BiasInstrument):
    """Agilent B2901/B2902/B2911/B2912 precision SMU driver"""
    
    drvname = 'Agilent B290x'
    regex = r'b?29[01][12][ab]?'
    
    def __init__(self,*args,**kwargs):
        """Create the driver object."""
        # define capabilities and call the parent initializer
        kwargs['capabilities'] = ('source_v','source_i',
            'measure_v','measure_i','bipolar',)
        kwargs['valid_channels'] = [1,2]
        super(Agilent_B29XX_Driver,self).__init__(*args,**kwargs)

        # automatically run instrument initialization
        self.init()
    
    def init(self, force=False):
        """Initialize the instrument."""
        if self.vi is not None and (not hasattr(self.vi,'_b2900model') or force):
            # query the ID string, check it for validity, and store the model number
            idn = self.vi.ask("*IDN?")
            if idn.find('B2901') > -1:
                model = '2901'
                nch = 1
            elif idn.find('B2902') > -1:
                model = '2902'
                nch = 2
            elif idn.find('B2911') > -1:
                model = '2911'
                nch = 1
            elif idn.find('B2912') > -1:
                model = '2912'
                nch = 2
            else:
                self._raise_error('instrument is not supported by this driver')
                
            self.vi._b2900model = model
            
            if nch == 1:
                # reset the valid channels list to only be a single channel
                self._config_valid_channels([1])
            
            # set the instrument into a known state
            self.vi.write("*RST")
            # init channel 1
            self.vi.write("OUTP1:STAT 0 ")
            self.vi.write("SOUR1:FUNC:MODE VOLT")
            self.vi.write("SOUR1:VOLT:RANG:AUTO 1")
            self.vi.write("SENS1:CURR:PROT 100e-6")
            self.vi.write("SOUR1:VOLT 0.0")
            if nch == 2:
                # init channel 2
                self.vi.write("OUTP2:STAT 0 ")
                self.vi.write("SOUR2:FUNC:MODE VOLT")
                self.vi.write("SOUR2:VOLT:RANG:AUTO 1")
                self.vi.write("SENS2:CURR:PROT 100e-6")
                self.vi.write("SOUR2:VOLT 0.0")
            
            # set some params
            for i in range(nch):
                p = self._get_params(i+1)
                p['state'] = 0
                p['mode'] = VOLTAGE
                p['vset'] = 0.0
                p['iset'] = 0.0
                p['vrange'] = None
                p['irange'] = None
                p['vmrange'] = None
                p['imrange'] = None
                p['vlimit'] = 1.0
                p['ilimit'] = 100e-6
                
    def _close(self):
        """Stuff to be done prior to closing the VISA interface."""
        # shut off the output and set continuous triggers
        self.vi.write("OUTP%d:STAT 0"%self.chan) 
        self._get_params(self.chan)['state'] = 0
        
    def config(self,chan=None,**kwargs):
        """Set configuration parameters. This is the workhorse method.
        
        This method obeys the following standard keywords:
        mode, state, vset, iset, vlimit, ilimit,
        vrange, irange, vmrange, imrange
        
        Instrument-specific keywords:
        remote - boolean indicating whether remote sensing should be enabled
        resolution - string indicating the desired instrument measurement resolution
           can be be one of 'low', 'medium', 'high', or 'very high'
	    """
        c = self._get_channel(chan)
        p = self._get_params(c)
        if not 'state' in p:
            self._raise_error("init() method must be called before config()")
        mode = p['mode']
        
        # store ranges and limits
        rlkw = ('vlimit','ilimit','vrange','irange','vmrange','imrange')
        for k in rlkw:
            if k in kwargs:
                v = kwargs.pop(k)
                # check that the value is OK
                if v is None:
                    p[k] = v
                else:
                    try:
                        p[k] = abs(float(v))
                    except ValueError:
                        raise ValueError(k)
        
        # check the requested instrument state
        req_state = None
        if 'state' in kwargs:
            req_state = bool(kwargs.pop('state'))
            if not req_state:
                # shut off the output immediately
                self.vi.write('OUTP%d:STAT 0'%c)
                p['state'] = 0

        
        # store changes in the vset/iset values
        vset, iset = False, False
        if 'vset' in kwargs:
            p['vset'] = float(kwargs.pop('vset'))
            vset = True
        if 'iset' in kwargs:
            p['iset'] = float(kwargs.pop('iset'))
            iset = True
        
        mode_changed = False
        if 'mode' in kwargs and mode != kwargs['mode']:
            # need to change the operating mode
            mode = kwargs.pop('mode').upper()
            if mode not in (VOLTAGE,CURRENT):
                self._raise_error("invalid 'mode'")
            self.vi.write("OUTP%d:STAT 0"%c)
            if mode == VOLTAGE:
                self.vi.write("SOUR%d:FUNC:MODE VOLT"%c)
            else:
                self.vi.write("SOUR%d:FUNC:MODE CURR"%c)
            p['mode'] = mode
            mode_changed = True
            if p['state'] and req_state is None:
                # need to force the SMU back on again
                req_state = True
            p['state'] = 0
            timed_wait_ms(50)
        
        if 'remote' in kwargs:
            if bool(kwargs.pop('remote')):
                p['_remsense'] = 1
            else:
                p['_remsense'] = 0
        
        if 'resolution' in kwargs:
            v = kwargs.pop('resolution').lower()
            res_map = {'very low':0.1, 'low':1.0, 'medium':4.0, 'high':8.0, 'very high':16.0}
            if v in res_map:
                p['_nplc'] = res_map[v]
            else:
                self._raise_error("'resolution' keyword must be one of: 'very low', 'low', 'medium', 'high', or 'very high'")
            
        # determine what to write for source values
        rang_str = ''
        if mode == VOLTAGE and (mode_changed or vset or req_state):
            if p.get('vrange') is None:
                # auto ranging
                self.vi.write("SOUR%d:VOLT:RANG:AUTO 1"%c)
            else:
                # manual voltage ranging
                self.vi.write("SOUR%d:VOLT:RANG:AUTO 0"%c)
                rang_str = ';:SOUR%d:VOLT:RANG %g'%(c,self._b2900_range(VOLTAGE,p['vrange']))
                
            # set current measurement ranging
            if p.get('imrange') is None:
                self.vi.write("SENS%d:CURR:RANG:AUTO 1"%c)
            else:
                self.vi.write("SENS%d:CURR:RANG:AUTO 0;:SENS%d:CURR:RANG %g"%(c,c,self._b2900_meas_range(mode,p['imrange'])))
            
            # set sensing and measurment integration
            self.vi.write("SENS%d:REM %d;:SENS%d:CURR:NPLC %g"%(c,p.get('_remsense',0),c,p.get('_nplc',0.1)))

            # set output voltage and current limits
            self.vi.write((':SOUR%d:VOLT %g;:SENS%d:CURR:PROT %g'%(c,p['vset'],c,self._b2900_adjust_compl(mode,p['vset'],p['ilimit'])))+rang_str)
            
        elif mode == CURRENT and (mode_changed or iset or req_state):
            if p.get('irange') is None:
                # auto ranging
                self.vi.write("SOUR%d:CURR:RANG:AUTO 1"%c)
            else:
                # manual current ranging
                self.vi.write("SOUR%d:CURR:RANG:AUTO 0"%c)
                rang_str = ';:SOUR%d:CURR:RANG %g'%(c,self._b2900_range(CURRENT,p['irange']))
        
            # set voltage measurement ranging
            if p.get('vmrange') is None:
                self.vi.write("SENS%d:VOLT:RANG:AUTO 1"%c)
            else:
                self.vi.write("SENS%d:VOLT:RANG:AUTO 0;:SENS%d:VOLT:RANG %g"%(c,c,self._b2900_meas_range(mode,p['vmrange'])))
                
            # set sensing and measurment integration
            self.vi.write("SENS%d:REM %d;:SENS%d:VOLT:NPLC %g"%(c,p.get('_remsense',0),c,p.get('_nplc',0.1)))
            
            # set output current and voltage limits
            self.vi.write((':SOUR%d:CURR %g;:SENS%d:VOLT:PROT %g'%(c,p['iset'],c,self._b2900_adjust_compl(mode,p['iset'],p['vlimit'])))+rang_str)

        if req_state and not p['state']:
            # turn the output on
            self.vi.write('OUTP%d:STAT 1'%c)
            p['state'] = 1
            timed_wait_ms(20)

        # pass additional keyword arguments on to pyVISA
        if len(kwargs):
            self.configure_vi(**kwargs)

    def initiate(self,chan=None):
        """Initiate a measurement."""
        # init a measurment 
        #c = self._get_channel(chan)
        #self.vi.write('*CLS;:INIT:ACQ (@%d)'%c)
        self.vi.write('*CLS')
        
    def ask_if_done(self,chan=None):
        """Check to see if a pending measurement is done."""
        # always done
        return True
    
    def fetch(self,chan=None):
        """Retrieve a measurement from the instrument."""
        # do a measurement and return the results
        c = self._get_channel(chan)
        p = self._get_params(c)
        if p['mode'] == VOLTAGE:
            # r = self.vi.ask("FETC:CURR? (@%d)"%c)
            r = self.vi.ask(":MEAS:CURR? (@%d)"%c)
            lim = self.vi.ask("SENS%d:CURR:PROT:TRIP?"%c)
        else:
            # r = self.vi.ask("FETC:VOLT? (@%d)"%c)
            r = self.vi.ask(":MEAS:VOLT? (@%d)"%c)
            lim = self.vi.ask("SENS%d:VOLT:PROT:TRIP?"%c)

        # if the measurement is in compliance, set the limiting flag
        p['limiting'] = bool(int(lim))
        return float(r)
            
    def _b2900_range(self, mode, value):
        """Get the fixed range for a given mode/value pair.
        mode - the source mode
        value - the voltage/current value to find the range for
        """
        """Get the fixed range for a given mode/value pair.
        mode - the source mode
        value - the voltage/current value to find the range for
        """
        if value is None:
            # auto range
            return None
        
        value = abs(value)
        if mode == VOLTAGE:
            # voltage
            if value > 21.0: r = 200.0
            elif value > 2.1: r = 20.0
            elif value > 0.21: r = 2.0
            else: r = 0.2
        else:
            # current
            if value > 1.515: r = 3.0
            elif value > 1.05: r = 1.5
            elif value > 0.105: r = 1.0
            elif value > 10.5e-3: r = 0.1
            elif value > 1.05e-3: r = 0.01
            elif value > 105.0e-6: r = 0.001
            elif value > 10.5e-6: r = 100.0e-6
            elif value > 1.05e-6: r = 10.0e-6
            elif value > 105.0e-9: r = 1.0e-6
            else: r = 100.0e-9
        return r 
        
    def _b2900_meas_range(self, mode, src, meas):
        "get the compliance range"
        if mode == VOLTAGE:
            r = self._b2900_range(CURRENT,meas)
            if r is None:
                return r
            if src > 6.0 and r > 1.5:
                r = 1.5
            elif src > 21.0 and r > 0.1:
                r = 0.1
        else:
            r = self._b2900_range(VOLTAGE,meas)
            if r is None:
                return r
            if src > 1.515 and r > 20.0:
                r = 20.0
    
        return r
    
    def _b2900_adjust_compl(self, mode, src, compl):
        "get the adjusted compliance value"
        s = abs(src)
        c = abs(compl)
        
        mc = 10000.0
        if mode == VOLTAGE:
            if s > 21.0:
                mc = 0.105
            elif  s > 6.0:
                mc = 1.515
            else:
                mc = 3.03
        else:
            if s > 1.515:
                mc = 6.0
            elif s > 0.105:
                mc = 21.0
            else:
                mc = 210.0
    
        if c > mc:
            c = mc
        
        return c
            
# add the class to the instrument manager with an appropriate regular expression
register(Agilent_B29XX_Driver)


