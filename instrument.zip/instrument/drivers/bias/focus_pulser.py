from instrument import timed_wait_ms, register
from instrument.family.bias import BiasInstrument


class FocusPulser(BiasInstrument):
    """Focus pulser driver"""
    
    drvname = 'Focus Pulser'
    regex = r'focus'
    
    def __init__(self, *args, **kwargs):
        "initialize"
        super(BiasInstrument,self).__init__(*args,**kwargs)
        self.init()        
        
        
    def init(self, force=False):
        "init instrument state"
        if self.vi is not None and (not hasattr(self.vi,'_focusinit') or force):
            # do first-time initialization stuff
            self.vi._focusinit = True
            
            # set up initial state
            self._drainlo = None
            self._drainhi = None            
            
            # Get some initial parameters
            p = {
                'enabled':False,
                'width': 1.0,
                'mode':'pulse',
                'period': 1000,
                'gate_latency': 0.1,
                'drain_latency':0.3,
                'gate_to_drain':0.1,
                'trig_delay':0,
                'gate_mode':'pulse',
                'drain_mode':'pulse',
                'trig_mode':'free',
                'vgq':-3.0,
                'vdq':8.0,
                'vgp':0.0,
                'vdp':0.0,
            }
            self._set_params(1,**p)
                                    
    
    @property
    def needs_gate_supplies(self):
        "defines whether gate-side bias instruments are required"
        return False
            
    @property
    def needs_drain_supplies(self):
        "defines whether drain-side bias instruments are required"
        return True   

    @property
    def needs_timing_generator(self):
        "defines whether a timing generator is required"
        return False 
        
    def setup_instruments(self, gate_lo=None, gate_hi=None, drain_lo=None, drain_hi=None, timing_generator=None):
        "tie the bias instruments to the pulser"
        # ignore the gate_lo and gate_hi values since this system does not need them 
        # ignore the timing_generator since this system has one built in 
        
        if drain_lo is not None:
            if not isinstance(drain_lo,BiasInstrument):
                raise TypeError("'drain_lo' must be a `BiasInstrument` object")
            self._drainlo = drain_lo
            self._drainlo.config(state=0,mode='V',vset=0.0)
        else:
            self._drainlo = None
        
        if drain_hi is not None:
            if not isinstance(drain_hi,BiasInstrument):
                raise TypeError("'drain_hi' must be a `BiasInstrument` object")
            self._drainhi = drain_hi
            self._drainhi.config(state=0,mode='V',vset=0.0)
        else:
            self._drainhi = None
    
    def set_current_limits(self, iglimit=None, idlimit=None):
        "set the current limits for the pulser supplies"
        # this pulser does not have the ability to set a gate current limit
        # the gate pulser is hardware limited at about 15 mA 
        
        if idlimit is not None:
            if not self._drainhi or not self._drainlo:
                raise InstrumentConfigError("drain low and high power supplies must be configured via `setup_instruments` first")
            
            if idlimit <= 0.0:
                idlimit=None
            
            self._drainhi.config(ilimit=idlimit)
            self._drainlo.config(ilimit=idlimit)
    
    def setup_pulse(self, **kwargs):
        """set up the pulse and timing conditions
        
        TIMING NOTES:
        
        - Everything is synchronized based on the oscope sync pulse
        - The width and period are defined with respect to the drain pulse
        - The drain_latency and gate_latency should be set to values that cause the
          gate and drain pulses to line up with the sync pulse
        - The drain pulse edge will ALWAYS be coincident with the sync pulse if the
          drain_latency is set correctly
        - The gate_to_drain parameter sets the time delay from the edge of the gate pulse
          to the edge of the drain pulse.  Positive values will cause the gate pulse to 
          be outside of drain pulse, negative values with be the opposite.
        
        
        
        Keywords:
        ------------------------------------------------------------------
        width             float, pulse width in seconds
        period            float, pulse period in seconds
        gate_to_drain     float, gate pulse pre-de (pulse start) in seconds
        gate_latency      float, gate pulser latency with respect the the timing signal in seconds
        drain_latency     float, drain pulser latency with respect the the timing signal in seconds
        trig_delay        float, ext trigger pulse delay in seconds
        gate_mode         string, gate pulse mode, one of 'off', 'constq', 'constp', or 'pulse'
        drain_mode        string, drain pulse mode, one of 'off', 'constq', 'constp', or 'pulse'      
        
        
        """
        # get the parameters dictionary
        p = self._get_params(1)
        
        need_pulse_cmd = False
        need_trig_free = False
        need_adjust = False
        add_delay = False
        valid_pulse_modes = ['pulse','off','constq','constp']
        
        # Width and period will not be changed unless a TRIGGER FREE command is issued.        
        if 'width' in kwargs or 'period' in kwargs:
            # width and/or period set
            need_pulse_cmd = True
            
            wid = float(kwargs.get('width',p['width']))
            per = float(kwargs.get('period',p['period']))
            if wid < 3e-7:
                wid = 3e-7
            if per < 36e-6:
            
                per = 36e-6
            elif per > 2200e-6: 
                per = 2200e-6
            
            p['width'] = wid
            p['period'] = per
            self.vi.write('PULSE %g %g'%(wid*1e6,per*1e6))            
        
        #### see if any of the timing parameters are set ####
        
        # check for latencies first since they impact other calculations
        if 'drain_latency' in kwargs:
            need_trig_free = True
            v = float(kwargs['drain_latency'])
            if v < 0.0:
                v = 0.0
            elif v > 2.0e-6:
                # limit to 2 us, since any larger would be silly
                v = 2.0e-6
            p['drain_latency'] = v
            self.vi.write('TIMING DRAIN %g %g'%(v*1e6,0.0))        
        
        if 'gate_latency' in kwargs:
            need_adjust = True
            v = float(kwargs['gate_latency'])
            if v > p['drain_latency']:
                # gate latency cannot be greater than
                # drain latency due to the timing diagram
                v = p['drain_latency']
            elif v < -2.0e-6:
                # limit to -2 us, since any smaller would be silly
                v = -2.0e-6
            p['gate_latency'] = v
            
        if 'gate_to_drain' in kwargs or need_adjust:
            need_trig_free = True
            if 'gate_to_drain' in kwargs:
                v = float(kwargs['gate_to_drain'])
            else:
                v = p['gate_to_drain']
            gl = p['gate_latency']
            minv = -0.5*(p['width']-0.3e-6)
            maxv = p['drain_latency'] - gl
            if v < minv:
                v = minv
            elif v > maxv:
                v = maxv
                
            p['gate_to_drain'] = v
            self.vi.write('TIMING GATE %g %g'%(v*1e6+gl,v*1e6-gl))
            
        if 'trig_delay' in kwargs:
            need_trig_free = True
            v = float(kwargs['trig_delay'])
            minv = -0.5*(p['width']-0.3e-6)
            maxv = p['drain_latency'] - gl
            if v < -p['drain_latency']:
                v = -p['drain_latency']
            elif v > 33e-6:
                v = 33e-6
            
            p['trig_delay'] = v
            self.vi.write('TIMING TRIGGER %g'%(v*1e6))
            
        
        if 'gate_mode' in kwargs:
            v = str(kwargs['gate_mode']).lower()
            if v not in valid_pulse_modes:
                raise ValueError("invalid 'gate_mode` - must be one of 'off', 'constq', 'constp', or 'pulse'")
            if v != p['gate_mode']:
                if p['enabled']:
                    add_delay = True
                    self._set_pulse_mode('GATE',v)
                    if v == 'pulse':
                        need_pulse_cmd = False
                p['gate_mode'] = v
        
        if 'drain_mode' in kwargs:
            v = str(kwargs['drain_mode']).lower()
            if v not in valid_pulse_modes:
                raise ValueError("invalid `drain_mode` - must be one of 'off', 'constq', 'constp', or 'pulse'")
            if v != p['drain_mode']:
                if p['enabled']:
                    add_delay = True
                    self._set_pulse_mode('DRAIN',v)
                    if v == 'pulse':
                        need_pulse_cmd = False
                p['drain_mode'] = v
                
        
        if p['enabled']:
            # pulser is enabled, see if we need to send any commands
            # to apply the changed settings
            # need to send a gate or drain pulse command to change
            # the timing
            if need_pulse_cmd:
                if p['drain_mode'] == 'pulse':
                    add_delay = True
                    self.vi.write('DRAIN PULSE')
                elif p['gate_mode'] == 'pulse':
                    add_delay = True
                    self.vi.write('GATE PULSE')
            
            if need_trig_cmd:
                add_delay = True
                self.vi.write('TRIGGER FREE')
                if p['trig_mode'] != 'free':
                    self.set_trigger_mode(p['trig_mode'])

        if add_delay:
            # delay to make sure the pulser has time to settle
            timed_wait_ms(1000)
        
            
    def set_pulse_timing(self, pre_gate = None, post_gate = None, pre_drain = None, post_drain = None):
        # Convenience method to allow the programmer to explicitly set the timing
        # Need to follow the timing commands with TRIGGER FREE for changes to take effect
        if pre_gate and pre_drain:
            self.vi.write("TIMING GATE %g %g"%(pre_gate,post_gate))
        if pre_drain and post_drain:
            self.vi.write("TIMING DRAIN %g %g"%(pre_drain,post_drain))
        self.set_trigger_mode(mode = 'free')

    def _set_pulse_mode(self, side, val, vp=None, vq=None):
        "internal function to set the gate/drain pulser"
        modes = {'off':'OFF', 'constq':'QUI', 'constp':'ON', 'pulse':'PULSE'}
        voltages = ''
        if vp is not None and vq is not None:
            voltages = ' %g %g'%(vp,vq)        
        self.vi.write(side+' '+modes[val]+voltages)
                
    def set_voltages(self, vgp=None, vgq=None, vdp=None, vdq=None):
        "set up the pulser voltages"
        p = self._get_params(1)
        # Set gate voltages and make a call to set_drain_voltages
        if (vgp != None) and (vgq != None):
            self.vi.write("GATE %s %g %g"%(p['gate_mode'],vgp,vgq))
            
        if (vdp != None) and (vdq != None):
            # Set the supply voltages
            self.set_drain_voltages(vdp,vdq)
            
    def set_gate_p(self,vgq,vgp):
        # Convenience method to explicitly set the gate
        p = self._get_params(1)        
        self.vi.write('GATE %s %g %g'%(p['gate_mode'], vgp,vgq))

    def set_supply_voltages(self, d_hi=None, d_lo=None):
        if d_hi:
            self._drainhi.config(vset = d_hi)
        if d_lo:
            self._drainlo.config(vset = d_lo)        
        
    def set_drain_p(self, vdp, vdq):
        "set up the drain pulse voltages"
        params = self._get_params(1)
        if not self._drainlo or not self._drainhi:
            raise ValueError("Low or high drain voltage not specified")        
        if vdp > vdq:
            # pulsed voltage is greater than the q-point voltage
            self._drainlo.config(state = 1)
            self._drainhi.config(state = 1)
            timed_wait_ms(300)
            self.vi.write('DRAIN %s %g %g'%(params['drain_mode'],vdq,0.0))
            
        else:
            # pulsed voltage is less than or equal to the q-point voltage
            self._drainlo.config(state = 1)
            self._drainhi.config(state = 1)
            timed_wait_ms(300)
            self.vi.write('DRAIN %s %g %g'%(params['drain_mode'],0.0,vdq))
            
    def get_supply_voltages(self):
        # Returns a tuple of supply voltages (low,high)
        return (self._drainlo.get_source(),self._drainhi.get_source())
        
    def turn_off_supplies(self):
        self._drainhi.config(state = 0)
        self._drainlo.config(state = 0)    
    
    def set_trigger_mode(self, mode='free'):
        "set the trigger mode FREE|EXTERNAL|SINGLE"
        p = self._get_params(1)
        if p['trig_mode'] != mode:
            p['trig_mode'] = mode
        self.vi.write("TRIGGER %s"%p['trig_mode'])
        
    def get_trigger_mode(self):
        "get the trigger mode"
        p = self._get_params(1)
        return p['trig_mode']       

    def set_pulse_mode(self, mode='pulse'):
        "set the pulse mode"
        p = self._get_params(1)
        self.vi.write("MODE %s"%p['mode'])        
    
    def get_pulse_mode(self, mode='pulse'):
        "set the pulse mode"
        p = self._get_params(1)
        return p['mode']
        
    def set_relay(self, relay = 1):
        # Convenience Method to set the relay
        self.vi.write('RELAY %g'%relay)        
    
    def enable(self, state=True):
        "enable/disable the pulser"
        p = self._get_params(1)
        if state:
        
            self.vi.write('TRIGGER FREE')
            self.vi.write('MODE PULSE')
            self.vi.write('RELAY 1')
            timed_wait_ms(500)
            p['enabled'] = True                    
        
        else:
            self.vi.write('DRAIN OFF')
            #self.vi.write('MODE PULSE')
            timed_wait_ms(500)
            self.vi.write('GATE OFF')
            self.vi.write('RELAY 0')
            timed_wait_ms(500)
            p['enabled'] = False
            
    def disable(self):
        "disable the pulser"
        
        self.enable(False)
            
    
    def _close(self):
        "called when closing the driver"
        self._drainhi.close()
        self._drainlo.close()
        self.vi.close()
        
register(FocusPulser)
        
    
    

 