from __future__ import division, print_function, unicode_literals, absolute_import
# this module should not export anything, do not change this line
__all__ = []

# driver initialization routine, by encapsulating this inside a function that
# starts with an underscore we prevent namespace clutter
def _init():
    import os, os.path, logging
    
    dir_path = os.path.dirname(__file__)
    module_path = __name__
    for m in os.listdir(dir_path):
        base, ext = os.path.splitext(m)
        if ext.lower() != '.py' or base.startswith('_'):
            continue
        mod = module_path+'.'+base
        try:
            __import__(mod)
        except Exception as e:
            logging.getLogger(module_path).warning("import error '%s' => %s"%(mod,e))

# init the module
_init()


