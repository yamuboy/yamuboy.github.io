from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import RFSource
from .. import timed_wait_ms, register

class RFSource_SCPI(RFSource):
    """RF signal source driver for any RF source that talks using 
    basic SCPI commands.
    
    This driver has a few basic restrictions on the values of power
    and frequency to protect against programming errors:
    
    -110 dBm <= power <= +30 dBm
    100 kHz <= freq <= 100 GHz    
    """
    
    drvname = 'SCPI'
    regex = r'(?:generic)?scpi'
    
    def __init__(self, *args, **kwargs):
        "object initializer"
        # init parent class
        super(RFSource_SCPI,self).__init__(*args,**kwargs)
        
        # init the instrument
        self.init()
            
    def init(self, force=False):
        "instrument initialization"
        if self.vi and (force or not hasattr(self.vi,'_rfsourcescpiinit')):
            self.vi._rfsourcescpiinit = True
            self.config(state=0,plevel=-50)
            p = self._get_params(0)
            p['state'] = 0
    
    def config(self, **kwargs):
        """workhorse method that does all of the instrument configuration"""
        self._vicheck()
        req_state = None
        p = self._get_params(0)
        
        if 'state' in kwargs:
            req_state = bool(kwargs.pop('state'))
            if not req_state:
                # shut off output immediately
                self.vi.write('OUTP:STAT 0')
                timed_wait_ms(100)
                
        if 'plevel' in kwargs:
            v = float(kwargs.pop('plevel'))
            if v < -110.0 or v > 30.0:
                raise ValueError("Invalid 'plevel': -110 <= plevel <= +30")
            self.vi.write('POW %g'%v)
            timed_wait_ms(100)
              
        if 'freq' in kwargs:
            v = float(kwargs.pop('freq'))
            if v < 100e3 or v > 100e9:
                raise ValueError("Invalid 'freq': 100 kHz <= freq <= 100 GHz")
            self.vi.write('FREQ %g'%v)
            timed_wait_ms(100)
        
        if req_state:
            # need to turn on the output
            self.vi.write('OUTP:STAT 1')
            p['state'] = 1
            timed_wait_ms(100)
        
    def get_freq(self, chan=None):
        "method for reading the current frequency"
        self._vicheck()
        return float(self.vi.ask('FREQ?'))
        
    def get_power(self, chan=None):
        "method for reading the current power level"
        self._vicheck()
        return float(self.vi.ask('POW?'))
    
# register this driver with an appropriate regex
register(RFSource_SCPI)

