from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import dmm
from .. import timed_wait_ms, register

class hp3478a_driver(dmm):

    drvname = "HP 3478A"
    regex = r'hp347[89][ab]'
    
    def __init__(self,*args,**kwargs):
        super(hp3478a_driver,self).__init__(*args,**kwargs)
        
    def config(self,**kwargs):
        """
        RANGE:
            Default Range is Auto
            For V-Range:
                0 - Most sensitive range
                1 - 30mV DC or most sensitive range
                2 - 300mV DC or AC or most sensitive range for any function
                3 - 3V DC or 3V AC 
                4 - 30V DC or 30V AC
                5 - 300V DC or 300V AC
            For I-Range:
                0 - Most sensitive range
                1 - 30mA or most sensitive range
                2 - 300mA 
                3 - 3A 
            For R-Range:
                0 - 3Ohms 
                1 - 30Ohms
                2 - 300Ohms
                3 - 3KOhms
                4 - 30KOhms
                5 - 300KOhms
                6 - 3MOhms
                7 - 30MOhms
                
        """
        v_range = {0:'R-3',1:'R-2',2:'R-1',3:'R0',4:'R1',5:'R2'}
        i_range = {0:'R-3',1:'R-2',2:'R-1',3:'R0'}
        r_range = {0:'R0',1:'R1',2:'R2',3:'R3',4:'R4',5:'R5',6:'R6',7:'R7'}
        if 'mode' in kwargs:
            if kwargs['mode'].lower() == 'v':
                if 'range' in kwargs:
                    self.vi.write("H1;%s"%v_range[kwargs['range']])
                else:
                    self.vi.write("H1;RA")
            elif kwargs['mode'].lower == 'i':
                if 'range' in kwargs:
                    self.vi.write("H5;%s"%i_range[kwargs['range']])
                else:
                    self.vi.write("H5;RA")
            elif kwargs['mode'].lower == 'r':
                if 'range' in kwargs:
                    self.vi.write("H3;%s"%r_range[kwargs['range']])
                else:
                    self.vi.write("H3;RA")
                    
    def measure(self):
        self.vi.write("T3")
        return (float(self.vi.read()))
        
register(hp3478a_driver)
        
            