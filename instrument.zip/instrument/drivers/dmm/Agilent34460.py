from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import dmm
from .. import timed_wait_ms, register

class Agilent34460_driver(dmm):

    drvname = "Agilent 34460A"
    regex = r'3446[01][ab]'
    
    def __init__(self,*args,**kwargs):
        super(Agilent34460_driver,self).__init__(*args,**kwargs)
        self.vi.write("*RST")
        self.vi.write("TRIG:SOUR IMM")
        
    def config(self,**kwargs):
        v_range = {0:'0.1',1:'1',2:'10',3:'100',4:'1000'}
        i_range = {0:'0.0001',1:'0.001',2:'0.01',3:'0.1',4:'1',5:'3',6:'10'}
        r_range = {0:'100',1:'1K',2:'10K',3:'100K',4:'1M',5:'10M',6:'100M'}
        if 'mode' in kwargs:
            if kwargs['mode'].lower() == 'v':
                if 'range' in kwargs:
                    self.vi.write(":CONF:VOLT:DC %s"%v_range[kwargs['range']])
                else:
                    self.vi.write(":CONF:VOLT:DC AUTO")
            elif kwargs['mode'].lower == 'i':
                if 'range' in kwargs:
                    self.vi.write(":CONF:CURR:DC,%s"%i_range[kwargs['range']])
                else:
                    self.vi.write(":CONF:CURR:DC AUTO")
            elif kwargs['mode'].lower == 'r':
                if 'range' in kwargs:
                    self.vi.write(":CONF:RES %s"%r_range[kwargs['range']])
                else:
                    self.vi.write(":CONF:RES AUTO")
    def measure(self):
        return (float(self.vi.ask("READ?")))
    def close(self):
        self.vi.write('*RST')
        
register(Agilent34460_driver)
