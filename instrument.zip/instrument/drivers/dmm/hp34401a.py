from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import dmm
from .. import timed_wait_ms, register

class hp34401a_driver(dmm):

    drvname = "HP 34401A"
    regex = r'hp344[01][ab]'
    
    def __init__(self,*args,**kwargs):
        super(hp34401a_driver,self).__init__(*args,**kwargs)
    def config(self,**kwargs):
        v_range = {0:':VOLT:DC:RANG:UPP 0',1:':VOLT:DC:RANG:UPP 1',2:':VOLT:DC:RANG:UPP 10',3:':VOLT:DC:RANG:UPP 100',4:':VOLT:DC:RANG:UPP 1000',5:':VOLT:DC:RANG:UPP 1000'}
        i_range = {0:':CURR:DC:RANG:UPP 0',1:':CURR:DC:RANG:UPP 1',2:':CURR:DC:RANG:UPP 2',3:':CURR:DC:RANG:UPP 3'}
        r_range = {0:':RES:RANG:UPP 0',1:':RES:RANG:UPP 1',2:':RES:RANG:UPP 10',3:':RES:RANG:UPP 100',4:':RES:RANG:UPP 1000',5:':RES:RANG:UPP 10000',6:':RES:RANG:UPP 100000',7:':RES:RANG:UPP 1000000'}
        if 'mode' in kwargs:
            if kwargs['mode'].lower() == 'v':
                if 'range' in kwargs:
                    self.vi.write(":CONF:VOLT:DC;%s"%v_range[kwargs['range']])
                else:
                    self.vi.write(":CONF:VOLT:DC;:VOLT:DC:RANG:AUTO On")
            elif kwargs['mode'].lower == 'i':
                if 'range' in kwargs:
                    self.vi.write(":CONF:CURR:DC;%s"%i_range[kwargs['range']])
                else:
                    self.vi.write(":CONF:CURR:DC;:CURR:DC:RANG:AUTO On")
            elif kwargs['mode'].lower == 'r':
                if 'range' in kwargs:
                    self.vi.write(":CONF:RES;%s"%r_range[kwargs['range']])
                else:
                    self.vi.write(":CONF:RES;RES:RANG:AUTO On")
    def measure(self):
        return float(self.vi.ask("MEAS?"))
        
register(hp34401a_driver)