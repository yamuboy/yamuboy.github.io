from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import Autoprober
from .. import timed_wait_ms, register, DummyInstrument
 
class dummy(DummyInstrument, Autoprober):
    """Virtual prober class for testing."""
    
    drvname = 'dummy'
    regex = r'dummy'
    
    def __init__(self, *args, **kwargs):
        """Object initializer."""
        super(dummy, self).__init__(*args, **kwargs)
        
        self._x = 0
        self._y = 0
    
    def init(self):
        """Initialize the instrument."""
        pass
    
    def config(self, **kwargs):
        """method is required, but does not do anything."""
        pass
        
    def get_position(self):
        """Get the current position."""
        return (self._x, self._y)
        
    def set_position(self, x, y, synch=False):
        """Set the prober position."""
        self._x = x
        self._y = y
        
    def ask_if_done(self):
        """Determine if an asynchronous move have been completed."""
        return True

# add the class to the instrument manager with an appropriate regular expression
register(dummy)


