from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import Autoprober
from .. import timed_wait_ms, register

class MPI_TS2000SE(Autoprober):
    """Simple class for controlling an MPI TS2000-SE probe station."""

    drvname = 'MPI TS2000-SE'
    regex = r'M?(?:PI_)?TS2000SE'

    def __init__(self, *args, **kwargs):
        """Object initializer."""
        # call the parent initializer
        super(MPI_TS2000SE,self).__init__(*args,**kwargs)

        # automatically run the initialization, if it has not been run
        if self.vi is not None:
            if not hasattr(self.vi,'_init'):
                self.init()
                self.vi._init = True

    def init(self):
        """Initialize the instrument."""

        # set read/write termination chars
        self.vi.read_termination = '\r\n'
        self.vi.write_termination = '\n\n'

        # # check the prober model
        # ident = self.vi.ask("*idn?").strip()

        # check that it is in Contact mode by checking if z height is within 1um of contact height
        r = self.vi.ask('get_chuck_z c').strip()
        dist = float(r.split(',')[2])
        if abs(dist) > 1.0:
            print(dist)
            self._error('prober chuck is not in the Contact position.')

    def config(self, **kwargs):
        """method is required, but does not do anything."""
        pass

    def get_position(self):
        """Get the current position."""
        r = self.vi.ask('get_chuck_xy')
        pos = tuple(r.split(',')[2:])
        return -float(pos[0]), -float(pos[1])

    def set_position(self, x, y, synch=False):
        """Set the prober position."""
        x,y = -float(x), -float(y)
        # separate chuck
        self.vi.ask("move_chuck_z s")
        # move to x-y position
        self.vi.ask("move_chuck_xy z,{:g},{:g}".format(x, y))
        # bring chuck back to contact
        self.vi.ask("move_chuck_z c")

    def ask_if_done(self):
        """assume always ready for more commands"""
        return True

# add the class to the instrument manager with an appropriate regular expression
register(MPI_TS2000SE)
    