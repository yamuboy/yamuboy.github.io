from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import Autoprober
from .. import timed_wait_ms, register
 
class Cascade12k(Autoprober):
    """Simple class for controlling a Cascade 12K probe station."""
    
    drvname = 'Cascade 12K'
    regex = r'c?(?:ascade)?12k'
    
    def __init__(self, *args, **kwargs):
        """Object initializer."""
        # call the parent initializer
        super(Cascade12k,self).__init__(*args,**kwargs)
        
        # automatically run the initialization, if it has not been run
        if self.vi is not None:
            if not hasattr(self.vi,'_12kinit'):
                self.init()
                self.vi._12kinit = True
    
    def init(self):
        """Initialize the instrument."""
        # check the prober model
        ident = self.vi.ask("*idn?").strip()
        #if ident.find('12000') < 0:
        #    raise ValueError("wrong instrument for this driver '%s'."%ident)
        
        # initialize
        self.vi.write('$:set:resp off;$:set:err:abor on;$:set:syntax win')
        
        # check that it is in Contact mode
        r = self.vi.ask(':move:cont? 2').strip()
        if r.upper() != 'TRUE':
            self._error('prober chuck is not in the Contact position.')
    
    def config(self, **kwargs):
        """method is required, but does not do anything."""
        pass
        
    def get_position(self):
        """Get the current position."""
        pos = tuple(self.vi.ask(':move:abs? 2').strip().split()[:2])
        return int(pos[0]),int(pos[1])
        
    def set_position(self, x, y, synch=False):
        """Set the prober position."""
        x,y = int(x),int(y)
        # clear the status byte send the move command
        self.vi.write("*cls;:move:abs 2 %d %d UP;*opc"%(x,y))
        self.vi._12kmoving = True
        if synch:
            # wait for the move the complete
            while True:
                timed_wait_ms(50)
                if self.ask_if_done():
                    break
        
    def ask_if_done(self):
        """Determine if an asynchronous move have been completed."""
        if not hasattr(self.vi,'_12kmoving') or not self.vi._12kmoving:
            return True
        stb = self.vi.stb
        if stb & 0x01:
            # error
            self._error('autoprober move failure')                
        elif stb & 0x02:
            self.vi._12kmoving = False
            return True
        return False

# add the class to the instrument manager with an appropriate regular expression
register(Cascade12k)


