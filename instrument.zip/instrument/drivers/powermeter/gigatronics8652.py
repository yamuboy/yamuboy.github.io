from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import PowerMeter
from .. import timed_wait_ms, register

class Gigatronics8652(PowerMeter):
    """Giga-tronics 8650-series power meter in SCPI mode"""
    
    drvname = 'Gig 8650'
    regex = r'(?:gig)?a?865[012][ab]?'

    def __init__(self,rsc_name,**kwargs):
        "object initializer"
        # init parent
        kwargs['valid_channels'] = [1,2]
        super(Gigatronics8652,self).__init__(rsc_name,**kwargs)

        # run the instrument initializer
        self.init()

    def init(self, force=False):
        "instrument initializer"
        if self.vi and (not hasattr(self.vi,'_giga8650') or force):
            # check the instrument ID
            model = self.vi.ask("*IDN?")
            if model.find('Giga-tronics') < 0 or model.find('8650') < 0:
                self._error("instrument not supported")
            
            self.vi._giga8650 = True
            
            # reset to a known state
            self.vi.write('*RST')
            self.vi.write('*CLS')
            
            # set the sensors for both channels up as CW
            # with freq = 1 GHz and offset = 0.0
            for ch in [1,2]:
                p = self._get_params(ch)
                self.vi.write('SENS%d:CONF:CW'%ch)
                self.vi.write('SENS%d:CORR:FREQ 1e9'%ch)
                self.vi.write('SENS%d:CORR:OFFS 0.0'%ch)
                self.vi.write('SENS%d:CORR:OFFS:STAT OFF'%ch)
                self.vi.write('CALC%d:POW %d'%(ch,ch))
                self.vi.write('CALC%d:UNIT DBM'%ch)
                p['mode'] = 'CW'
                p['offset'] = 0.0
                p['freq'] = 1.0e9
                p['_meas'] = None
            
            # set up triggering and store the trigger state
            self.vi.write('INIT:CONT OFF')
            self.vi.write('TRIG:SOUR IMM')
            p = self._get_params(0)
            p['_triggered'] = 0
    
    def _close(self):
        "prior to closing instrument, reset triggering to free-run"
        if self.vi:
            self.vi.write('INIT:CONT ON')

    def config(self, chan=None, **kwargs):
        """workhorse method for configuring the meter"""
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        
        if 'offset' in kwargs:
            v = kwargs.pop('offset')
            if v is None:
                v = 0.0
            if v < -99.9 or v > 99.9:
                self._error("invalid offset: -99.9 <= 'offset' <= 99.9")
            if v == 0.0:
                self.vi.write('SENS%d:CORR:OFFS 0.0'%ch)
                self.vi.write('SENS%d:CORR:OFFS:STAT OFF'%ch)            
            else:
                self.vi.write('SENS%d:CORR:OFFS %.2f'%(ch,v))
                self.vi.write('SENS%d:CORR:OFFS:STAT ON'%ch)
            p['offset'] = v
            
        if 'freq' in kwargs:
            v = float(kwargs.pop('freq'))
            if v < 1.0e5 or v > 100.0e9:
                self._error("invalid frequency: 100 kHz <= 'freq' <= 100 GHz")
            self.vi.write('SENS%d:CORR:FREQ %g'%(ch,v))
            p['freq'] = v
        
        if 'mode' in kwargs:
            mode = kwargs.pop('mode').upper()
            if mode not in ('CW','PULSE','MOD'):
                self._error("invalid sensor 'mode'")
                
            if mode == 'CW':
                self.vi.write('SENS%d:CONF:CW'%ch)
                p['mode'] = 'CW'
            elif mode in ('MOD','AVG','AVERAGE'):
                ## TODO
                pass
            elif mode == 'PULSE':
                ## TODO
                pass
                        
        
    def initiate(self, chan=None):
        "trigger a measurement"
        # since this is a 2-channel instrument and triggers
        # cannot be sent to individual channels we need to keep
        # track of triggers to prevent over-triggering
        ch = self._get_channel(chan)
        p = self._get_params(0)
        if p['_triggered'] in (0,ch):
            # need a new trigger
            self.vi.write('*CLS;*ESE 1;:INIT;*OPC')
            p['_triggered'] = ch
            for i in [1,2]:
                p = self._get_params(i)
                p['_meas'] = None
        
    def ask_if_done(self, chan=None):
        "check if the measurment is complete"
        t = int(self.vi.ask('*ESR?'))
        if t & 1:
            return True
        return False
    
    def fetch(self, chan=None):
        "fetch a measurment"
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        if p['_meas'] is not None:
            # this means that the data was already read when this method
            # was called on the other channel, so return the stored measurement value
            return p['_meas']
        else:
            # need to read data from the instrument
            p1 = self._get_params(0)
            if not p1['_triggered']:
                self._error("channel not triggered")
            
            # read both channels and store the data
            for i in [1,2]:
                p2 = self._get_params(i)
                p2['_meas'] = float(self.vi.ask('FETC%d?'%i))
            
            # return the data for the requested channel
            return p['_meas']

    def measure(self, chan=None):
        "override the measure method to provide one that is more efficient"
        ch = self._get_channel(chan)
        return float(self.vi.write('MEAS%d?'%ch))
        
# register the driver
register(Gigatronics8652)
        
