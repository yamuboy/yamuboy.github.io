from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import PowerMeter
from .. import timed_wait_ms, register

class Agilent_Eseries(PowerMeter):
    """Agilent E-series power meter driver"""

    drvname = 'Agilent E-series'
    regex = r'eseries|e?441.'

    def __init__(self,rsc_name,**kwargs):
        "object initializer"
        # init parent
        kwargs['valid_channels'] = [1,2]
        super(Agilent_Eseries,self).__init__(rsc_name,**kwargs)

        # run the instrument initializer
        self.init()

    def init(self, force=False):
        "instrument initializer"
        if self.vi and (not hasattr(self.vi,'_agilent_eseries') or force):
            # check the instrument ID
            model = self.vi.ask("*IDN?")
            if model.find('Agilent') < 0 or model.find('E441') < 0:
                self._error("instrument not supported")
            
            self.vi._agilent_eseries = True
            
            # reset to a known state
            self.vi.write('*RST;*CLS')
            self.vi.write('SYST:LANG SCPI')
            self.vi.write(':INIT:CONT OFF')
            self.vi.write(':TRIG:SOUR IMM')
            
            # set the sensors for both channels up as CW
            # with freq = 1 GHz and offset = 0.0
            for ch in [1,2]:
                p = self._get_params(ch)
                self.vi.write('SENS%d:FREQ 1e9'%ch)
                self.vi.write('SENS%d:CORR:GAIN2 0.0'%ch)
                self.vi.write('SENS%d:CORR:GAIN2:STAT OFF'%ch)
                self.vi.write('UNIT%d:POW DBM'%ch)
                self.vi.write('SENS%d:DET:FUNC AVERAGE'%ch)
                self.vi.write('SENS%d:AVER:STAT ON'%ch)
                self.vi.write('SENS%d:AVER:COUN:AUTO ON'%ch)
                p['mode'] = 'AVG'
                p['offset'] = 0.0
                p['freq'] = 1.0e9
                p['_meas'] = None
                
    def _close(self):
        "prior to closing instrument, reset triggering to free-run"
        if self.vi:
            self.vi.write('INIT:CONT ON')

    def config(self, chan=None, **kwargs):
        """workhorse method for configuring the meter"""
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        
        if 'offset' in kwargs:
            v = kwargs.pop('offset')
            if v is None:
                v = 0.0
            if v < -100.0 or v > 100.0:
                self._error("invalid offset: -100 <= 'offset' <= 100")
            if v == 0.0:
                self.vi.write('SENS%d:CORR:GAIN2 0.0'%ch)
                self.vi.write('SENS%d:CORR:GAIN2:STAT OFF'%ch)            
            else:
                self.vi.write('SENS%d:CORR:GAIN2 %g'%(ch,v))
                self.vi.write('SENS%d:CORR:GAIN2:STAT ON'%ch)
            p['offset'] = v
            
        if 'freq' in kwargs:
            v = float(kwargs.pop('freq'))
            if v < 1.0e5 or v > 100.0e9:
                self._error("invalid frequency: 100 kHz <= 'freq' <= 100 GHz")
            self.vi.write('SENS%d:FREQ %g'%(ch,v))
            p['freq'] = v
        
        if 'mode' in kwargs:
            mode = kwargs.pop('mode').upper()
            if mode in ('CW','MOD','AVG','AVERAGE'):
                self.vi.write('SENS%d:DET:FUNC AVERAGE'%ch)
                p['mode'] = 'AVG'
            else:
                self.vi.write('SENS%d:DET:FUNC NORMAL'%ch)
                p['mode'] = 'NORM'
                
        if 'resolution' in kwargs:
            res = kwargs.pop('resolution').lower()
            if res not in ('very low','low','medium','high','very high','auto'):
                raise ValueError("invalid 'resolution' - must be one of 'very low', 'low', 'medium', 'high', 'very high', or 'auto'")
            
            if res == 'very low':
                r = 1
            elif res == 'low':
                r = 2
            elif res in ('medium','high','auto'):
                r = 3
            else:
                r = 4
            self.vi.write('DISP:WIND%d:RES %d'%(ch,r))
        
    def initiate(self, chan=None):
        "trigger a measurement"
        # since this is a 2-channel instrument and triggers
        # cannot be sent to individual channels we need to keep
        # track of triggers to prevent over-triggering
        ch = self._get_channel(chan)
        self.vi.write(':INIT:CONT OFF')
        self.vi.write('*CLS;*ESE 1;:INIT%d;*OPC'%ch)
        
    def ask_if_done(self, chan=None):
        "check if the measurement is complete"
        t = int(self.vi.ask('*ESR?'))
        if t & 1:
            return True
        return False
    
    def fetch(self, chan=None):
        "fetch a measurment"
        ch = self._get_channel(chan)
        return float(self.vi.ask('FETC%d?'%ch))
        
    def measure(self,chan = None):
        "Custom method to initiate a measurement, ask if done, and fetch the result"
        self.initiate()
        self.ask_if_done()
        self.fetch()
        
        
# register the driver
register(Agilent_Eseries)
        
