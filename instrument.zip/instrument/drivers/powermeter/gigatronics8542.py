from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import PowerMeter
from .. import timed_wait_ms, register

_chan_map = {1:'A',2:'B'}

class Gigatronics8542(PowerMeter):
    """Giga-tronics 8542 power meter driver"""
    
    drvname = 'Gig 8542'
    regex = r'(?:gig)?a?854[012][ab]?'

    def __init__(self,rsc_name,**kwargs):
        "object initializer"
        # init parent
        kwargs['valid_channels'] = [1,2]
        super(Gigatronics8542,self).__init__(rsc_name,**kwargs)

        # run the instrument initializer
        self.init()

    def init(self, force=False):
        "instrument initializer"
        if self.vi and (not hasattr(self.vi,'_giga8540') or force):
            # check the instrument ID
            model = self.vi.ask("*IDN?")
            if model.lower().find('giga-tronics') < 0 or model.find('854') < 0:
                self._error("instrument not supported")
            
            self.vi._giga8540 = True
            
            # reset to a known state
            self.vi.write('*RST')
            self.vi.write('*CLS')
            
            # set the sensors for both channels up as CW
            # with freq = 1 GHz and offset = 0.0
            for ch in [1,2]:
                c = _chan_map[ch]
                p = self._get_params(ch)
                self.vi.write('CW %s'%c)
                self.vi.write('%sE FR 1 GZ'%c)
                self.vi.write('%sE OS 0.0 EN'%c)
                self.vi.write('%sE OF0'%c)
                p['mode'] = 'CW'
                p['offset'] = 0.0
                p['freq'] = 1.0e9
                p['resolution'] = 'auto'
                
            
            # set up triggering and store the trigger state
            self.vi.write('TR0')
            p = self._get_params(1)
            p['_triggered'] = 0
    
    def _close(self):
        "prior to closing instrument, reset triggering to free-run"
        if self.vi:
            self.vi.write('TR3')

    def config(self, chan=None, **kwargs):
        """workhorse method for configuring the meter"""
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        
        c = _chan_map[ch]
        
        if 'offset' in kwargs:
            v = kwargs.pop('offset')
            if v is None:
                v = 0.0
            if v < -99.9 or v > 99.9:
                self._error("invalid offset: -99.9 <= 'offset' <= 99.9")
            if v == 0.0:
                self.vi.write('%sE OS 0.0 EN'%c)
                self.vi.write('%sE OF0'%c)
            else:
                self.vi.write('%sE OS %g EN'%(c,v))
                self.vi.write('%sE OF0'%c)
            p['offset'] = v
            
        if 'freq' in kwargs:
            v = float(kwargs.pop('freq'))
            if v < 1.0e5 or v > 100.0e9:
                self._error("invalid frequency: 100 kHz <= 'freq' <= 100 GHz")
            self.vi.write('%sE FR %g MZ'%(c,v*1.0e-6))
            p['freq'] = v
        
        if 'mode' in kwargs:
            mode = kwargs.pop('mode').upper()
            if mode not in ('CW','PULSE','MOD'):
                self._error("invalid sensor 'mode'")
                
            if mode == 'CW':
                self.vi.write('CW %s'%c)
                p['mode'] = 'CW'
            elif mode in ('MOD','AVG','AVERAGE'):
                ## TODO
                pass
            elif mode == 'PULSE':
                ## TODO
                pass
        
        if 'resolution' in kwargs:
            res = kwargs.pop('resolution').lower()
            if res not in ('very low','low','medium','high','very high','auto'):
                raise ValueError("invalid 'resolution' - must be one of 'very low', 'low', 'medium', 'high', 'very high', or 'auto'")
            p['resolution'] = res
        
    def initiate(self, chan=None):
        "trigger a measurement"
        # since this is a 2-channel instrument and triggers
        # cannot be sent to individual channels we need to keep
        # track of triggers to prevent over-triggering
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        # need a new trigger
        c = _chan_map[ch]
        st = self.vi.ask('SM')
        if st.find(c) < 0:
            raise ValueError("channel %d has no sensor"%ch)
        self.vi.write('%sE'%c)
        self.vi.write('%sP'%c)
        # set measurement filter (resolution)
        res = p['resolution']
        if res == 'auto':
            rstr = 'FA'
        else:
            resmap = {'very low':1, 'low':3, 'medium':5, 'high':7, 'very high':9}
            rstr = 'FM %d EN'%resmap[res]
        self.vi.write('%sE %s'%(c,rstr))
        
        # trigger measurement
        self.vi.write('CS')
        self.vi.write('TR2')
        p['_triggered'] = True
        
    def ask_if_done(self, chan=None):
        "check if the measurement is complete"
        if self.vi.stb & 1:
            return True
        return False
    
    def fetch(self, chan=None):
        "fetch a measurment"
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        # need to read data from the instrument
        if not p['_triggered']:
            self._error("channel not triggered")
        
        # return the data for the requested channel
        return float(self.vi.read())

    
# register the driver
register(Gigatronics8542)
        
