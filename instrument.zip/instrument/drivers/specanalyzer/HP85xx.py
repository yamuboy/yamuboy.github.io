from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import SpectrumAnalyzer
from .. import timed_wait_ms, register

class HP85xx_Driver(SpectrumAnalyzer):
    "HP 856x series spectrum analyzer"
    
    drvname = 'HP 856x'
    regex = r'(hp)?85[6x].*'
    
    def __init__(self,address=None,**kwargs):
        if address is None:
            address="GPIB::18"
        super(HP85xx_Driver,self).__init__(address,timeout=20.0,**kwargs)
        #self.init()
        
    def init(self):
        self.vi.write("IP")
        timed_wait_ms(100)
        
    def error_check(self):
        e=self.vi.ask("ERR?")
        if e!='0':
            raise Exception("Spectrum Analyzer Error!")
    def set_ref_level(self,level):
        self.vi.write("RL %f"%level)
    set_reflevel = set_ref_level
    def set_averages(self,vavg):
        if vavg==0:
            self.vi.write("VAVG OFF")
        else:
            self.vi.write("VAVG ON")
            self.vi.write("VAVG %d"%vavg)
    def set_attn(self,att=None):
        if att!=None:
            self.vi.write("AT MAN")
            self.vi.write("AT %d"%att)
        else:
            self.vi.write("AT AUTO")
    def set_cf(self,cf):
        # Sets the Center Frequency in MHz
        self.vi.write("CF %f"%cf)
    def set_span(self,span):
        # Sets the span in KHz
        self.vi.write("SP %f"%span)
    def set_bandwidth(self,rbw=None,vbw=None):
        # Sets the bandwidth in KHz
        if rbw!=None:
            self.vi.write("RB %f"%rbw)
        else:
            self.vi.write("RB AUTO")
        if vbw!=None:
            self.vi.write("VB %f"%vbw)
        else:
            self.vi.write("VB AUTO")
    def set_swptime(self,swptime=None):
        if swptime!=None:
            self.vi.write("ST %g"%swptime)
        else:
            self.vi.write("ST AUTO")
    def set_detector(self,det_mode=None):
        # Sets the detector mode. Default is normal peak detection mode.
        if det_mode=="SAMP":
            self.vi.write("DET SMP")
        elif det_mode=="PEAK":
            self.vi.write("DET NRM")
    def set_marker(self,mode=None,freq=None):
        # Sets the marker mode. If mode is None, it just sets the marker to the center of the frequency band
        # First turn off all makers before setting the marker type. This ensures that if the noise marker is on, it's turned off.
        self.vi.write("MKOFF")
        if mode!=None:
            if mode=="max":
                self.vi.write("MKPK HI")
            elif mode=="min":
                self.vi.write("MKMIN")
            elif mode=="noise":
                self.vi.write("MKN")
                self.vi.write("MKNOISE ON")
                self.vi.write("MKMIN")
            elif mode=="freq":
                if freq:
                    self.vi.write("MKF %f"%freq)
                else:
                    raise ValueError("Need Frequency value for this marker type")
        else:
            f= self.vi.ask("CF?")
            self.vi.write("MKF %s"%f)
    def setup_trace(self,trace_mode=None):
        if trace_mode=='view':
            self.vi.write("VIEW TRA")
        elif trace_mode=='clear':
            self.vi.write("CLRW TRA")
    def set_scaleunits(self,scale=None,units=None):
        if scale!=None:
            self.vi.write("%s"%scale)
        else:
            self.vi.write("LG 10")
        if units!=None:
            self.vi.write("AUNITS %s")
        else:
            self.vi.write("AUNITS AUTO")
            
    def clear_trace(self):
        self.vi.write("CLRW TRA")
        
    def optimize_ref_level(self):
        rl = last_rl = -10.0
        self.vi.write("RL %f"%rl)
        while True:
            self.sweep()
            self.vi.write("MKPK HI")
            ampl, rl = float(self.vi.ask("MKA?")), float(self.vi.ask("RL?"))
            if (ampl > rl) or (ampl + 11.0 < rl):
                if ampl > rl:
                    rl += 10.0
                    if rl > 10.0:
                        rl = 10.0
                else:
                    rl -= math.floor((rl - ampl)*0.1)*10.0
                    if rl < -50.0:
                        rl = -50.0
                
                if abs(rl-last_rl) < 0.1:
                    break
                self.vi.write("RL %f"%rl)        
                last_rl = rl
            else:
                break
    def sweep(self, type=None):
        # The sweep type can be continuous or single- CONTS or SNGLS
        if type!=None:
            self.vi.write(type)
        # Trigger a single sweep. This is the default mode and it triggers a single sweep and waits for avergaing, if any.
        else:
            self.vi.write("RQS 16;TS")
            while True:
                if int(self.vi.ask("STB?"))&4==0:
                    self.vi.write("RQS 0")
                    break
    def measure_marker(self):
        return float(self.vi.ask("MKA?"))
    def get_ref_level(self):
        return float(self.vi.ask("RL?"))
    def get_marker_frequency(self):
        return float(self.vi.ask("MKF?"))
    def get_attn(self):
        return (float(self.vi.ask("AT?")))
    def get_trace(self):
        # Just get the start, stop frequencies, span and trace values and return that data. 
        # Higher level methods can use that data to get the max, min, etc
        f1=float(self.vi.ask('FA?'))
        f2=float(self.vi.ask('FB?'))
        span=float(self.vi.ask('SP?'))
        trace=self.vi.ask_for_values('TA')
        return (f1,f2,span,trace)
                

register(HP85xx_Driver)
        
        
        