from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import SpectrumAnalyzer
from .. import timed_wait_ms, register
import math

class Cxa_Driver(SpectrumAnalyzer):
    "Agilent X series spectrum analyzer"
    
    drvname = 'CXA N9000A'
    regex = r'(cxa) N?90[0x].*'
    
    def __init__(self,address=None,**kwargs):
        if address is None:
            address="GPIB::18"
        super(Cxa_Driver,self).__init__(address,**kwargs)
    def set_reflevel(self,level):
        self.vi.write(":DISP:WIND:TRAC:Y:RLEV %f"%level)
        
    set_ref_level = set_reflevel
    def set_averages(self,vavg):
        if vavg==0:
            self.vi.write(":TRAC:TYPE WRIT")
            self.sweep()
        else:
            self.vi.write(":TRAC:TYPE AVER")
            self.vi.write("AVER:COUN %d"%vavg)
    def set_attn(self,att=None):
        if att!=None:
            self.vi.write(":POW:ATT:AUTO OFF")
            self.vi.write(":POW:ATT %d"%att)
        else:
            self.vi.write(":POW:ATT:AUTO ON")
    def set_cf(self,cf):
        # Sets the Center Frequency in MHz
        self.vi.write(":FREQ:CENT %f"%cf)
    def set_span(self,span):
        # Sets the span in Hz
        self.vi.write(":FREQ:SPAN %f"%span)
    def set_bandwidth(self,rbw=None,vbw=None):
        # Sets the bandwidth in KHz
        if rbw!=None:
            self.vi.write("BAND %f"%rbw)
        else:
            self.vi.write("BAND:AUTO ON")
        if vbw!=None:
            self.vi.write("BAND:VID %f"%vbw)
        else:
            self.vi.write("BAND:VID:AUTO ON")
    def set_swptime(self,swptime=None):
        if swptime!=None:
            self.vi.write(":SWE:TIME:AUTO OFF")
            self.vi.write(":SWE:TIME %ds"%swptime)
        else:
            self.vi.write(":SWE:TIME:AUTO ON")
    def set_detector(self,det_mode=None):
        # Sets the detector mode. Default is normal peak detection mode.
        if det_mode!=None:
            if det_mode=='PEAK':
                self.vi.write("SENS:DET NORM")
            else:
                self.vi.write("SENS:DET %s"%det_mode)
    def set_marker(self,mode=None,freq=None):
        # Sets the marker mode. If mode is None, it just sets the marker to the center of the frequency band
        # First turn off all makers before setting the marker type. This ensures that if the noise marker is on, it's turned off.
        self.vi.write("CALC:MARK:FUNC OFF")
        if mode!=None:
            if mode=="max":
                self.vi.write("CALC:MARK:MAX")
            elif mode=="min":
                self.vi.write("CALC:MARK:MIN")
            elif mode=="noise":
                self.vi.write("CALC:MARK:FUNC NOIS")
                self.vi.write("CALC:MARK:MIN")
            elif mode=="freq":
                if freq:
                    self.vi.write("CALC:MARK X %fMHZ"%freq)
                else:
                    raise ValueError("Need Frequency value for this marker type")
        else:
            f= self.vi.ask("CALC:MARK:X?")
            self.vi.write("CALC:MARK:X %s"%f)
    def setup_trace(self,trace_mode=None):
        if trace_mode=='view':
            self.vi.write("TRAC:MODE VIEW")
        elif trace_mode=='clear':
            self.vi.write("TRAC:CLE:ALL")
    def set_scaleunits(self,scale=None,units=None):
        if scale!=None:
            if "LG" in scale:
                self.vi.write("DISP:WIND:TRAC:Y:SPAC LOG")
                self.vi.write("DISP:WIND:TRAC:Y:PDIV %d"%int(scale.split()[1]))
            elif "LN" in scale:
                self.vi.write("DISP:WIND:TRAC:Y:SPAC LIN")
        if units!=None:
            self.vi.write("UNIT:POW %s")
        else:
            self.vi.write("UNIT:POW DBM")
            
    def clear_trace(self):
        self.vi.write("TRAC:CLE:ALL")
    def sweep(self, type=None):
        #First check if auto align is turned on, if it is, turn it off
        if self.vi.ask(":CAL:AUTO?")=="ON":
            self.vi.write(":CAL:AUTO OFF")
        # The sweep type can be continuous or single- CONTS or SNGLS
        if type == "SNGLS" or type == "TS":
            self.vi.write("INIT:CONT OFF")
            self.vi.write("INIT:IMM")
        if type == "CONTS":
            self.vi.write("INIT:CONT ON")
        self.vi.write("ABORT")
        self.vi.write("INIT:CONT OFF")
        self.vi.write("*CLS")
        self.vi.write("STAT:OPER:ENAB 16")
        self.vi.write("STAT:OPER:PTR 0")
        self.vi.write("INIT:IMM")
        while True:
            if self.vi.ask("*OPC?")!='1':
                next
            else:
                break
        # Turn the calibration back on 
        self.vi.write("CAL:AUTO ON")
    def measure_marker(self):
        return float(self.vi.ask("CALC:MARK:Y?"))
    def get_ref_level(self):
        return float(self.vi.ask(":DISP:WIND:TRAC:Y:RLEV?"))
    def get_trace(self):
        # Just get the start, stop frequencies, span and trace values and return that data. 
        # Higher level methods can use that data to get the max, min, etc
        f1=float(self.vi.ask('FREQ:STAR?'))
        f2=float(self.vi.ask('FREQ:SPAN?'))
        span=float(self.vi.ask('FREQ:SPAN?'))
        trace=self.vi.ask_for_values('CALC:DATA?')
        return (f1,f2,span,trace)
    def xmod_refsideband(self,c_freq,demod_freq = None):
        if demod_freq == None:
            demod_freq = 15750000.0
        self.vi.write("INST:SEL ADEMOD")
        self.vi.write(":SENS:POW:RF:ATT 10")
        # Set the analog demod bandwidth to 40KHz
        
        # Set the scale to 10db/div for RF spectrum and AF Spectrum
        self.vi.write(":DISP:AM:WIND1:TRAC:Y:SCAL:PDIV 10DB")
        self.vi.write(":DISP:AM:WIND3:TRAC:Y:SCAL:PDIV 10DB")
        # Turn the internal pre-amp on/off
        self.vi.write(":SENS:POW:RF:GAIN:STAT 1")
        # Set the center frequency
        self.vi.write(":SENS:FREQ:CENT %f"%c_freq)
        # Set the Af Spectrum start and stop frequency
        self.vi.write(":SENS:AM:AFS:FREQ:STAR 10KHz")
        self.vi.write(":SENS:AM:AFS:FREQ:STOP 20KHz")
        # Set the number of averages to 30
        self.vi.write(":SENS:AM:AVER:COUN 30")
        # Set the marker mode to Delta for reading the XMOD value in dB
        # Set the marker in the AF Spectrum window
        self.vi.write(":CALC:AM:MARK1:TRAC AFSP")
        self.vi.write(":CALC:AM:MARK1:MODE DEL")
        # Set the marker to the peak
        self.vi.write(":CALC:AM:MARK1:MAX")
        self.sweep()
        ref_sideband = float(self.vi.ask(":CALC:AM:MARK1:Y?"))
        return ref_sideband
        
    def xmod_rest(self):
        self.sweep()
        ref_sideband_cw = float(self.vi.ask(":CALC:AM:MARK1:Y?"))
        # Measure the noise
        self.vi.write(":CALC:AM:MARK1:TRAC RFSP")
        self.vi.write(":CALC:AM:MARK1:MODE POS")
        self.vi.write(":CALC:AM:MARK1:MIN")
        self.sweep()
        noise = float(self.vi.ask(":CALC:AM:MARK1:Y?"))
        # Set the CXA back to spectrum analyzer mode
        self.vi.write("INST:SEL SA")
        return ref_sideband_cw, noise
        
        

register(Cxa_Driver)