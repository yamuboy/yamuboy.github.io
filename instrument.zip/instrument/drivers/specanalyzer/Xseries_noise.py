from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import SpectrumAnalyzer
from .. import timed_wait_ms, register

"""
This instrument can be used as a noise figure analyzer or as a spectrum analyzer
"""

class pxa_driver(SpectrumAnalyzer):
    "Agilent X series spectrum analyzer"
    
    drvname = 'PXA N9030A'
    regex = r'(pxa) N?90[30x].*'
    
    def __init__(self,*args,**kwargs):
        kwargs['capabilities'] = ('noise','sa')
        super(pxa_driver,self).__init__(*args,**kwargs)
        self.init()
    
    def init(self):
        
        cnf = self.vi.ask(":CONF?").strip('\n')
        if cnf != "NFIG":
            raise Exception("Instrument Not Configured to Perform Noise Figure Measurements")
        
        # Turn off the continuous trigger
        self.vi.write(":INIT:CONT OFF")
        
    def close(self):
        # Turn on continuous trigger
        self.vi.write(":INIT:CONT ON")
        
        # Set the cal mode to auto
        self.vi.write(":CAL:AUTO ON")
        
    def read_noise_sweep(self):
        
        # Turn the auto cal feature to off
        self.vi.write(":CAL:AUTO OFF")
        
        # Initiate a measurement
        self.vi.write(":INIT:CONT OFF;REST")
        
        # Trigger a measurement
        while True:
            sb = int(self.vi.ask(":STAT:OPER?"))
            if (sb & 8) !=True:
                break 
                
        # Read the frequency list, but first check the mode
        md = self.vi.ask(":SENS:NFIG:FREQ:MODE?")
        if md[:1] == 'L':
            frl = self.vi.query_ascii_values(":SENS:NFIG:FREQ:LIST:DATA?")
        elif md[:1] == 'F':
            frl = self.vi.query_ascii_values(':SENS:NFIG:FREQ:FIX?')
        # The mode is swept, so get start and stop frequencies
        else:
            start = float(self.vi.ask(":SENS:NFIG:FREQ:STAR?"))
            span = float(self.vi.ask(":SENS:NFIG:FREQ:SPAN?"))
            pts = int(self.vi.ask(":SENS:NFIG:SWE:POIN?"))
            
            step = span/(pts - 1)
            
            frl = []            
            for i in range(pts):
                frl.append(start + (step*i))
            
        # Read noise figure data
        nfig = self.vi.query_ascii_values(":FORM:DATA ASC;:FETC:NFIG:ARR:CORR:NFIG?")
        
        nga = self.vi.query_ascii_values(":FORM:DATA ASC;:FETC:NFIG:ARR:CORR:GAIN?")

        if (len(frl)!=len(nfig)) or (len(frl)!=len(nga)):
            raise Exception("Array Size Mismatch!")
            
        # Run filter alignments that are pending
        self.vi.ask(":CAL:EXP?")
        
        # Return the values of the frequency list, gain and noise figure        
        return frl,nga,nfig
        
register(pxa_driver)

    
            
        