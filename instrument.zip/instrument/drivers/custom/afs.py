from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import CustomInstrument
from .. import timed_wait_ms, register
import re

class afs_driver(CustomInstrument):
    "Matrix AFS filter bank"
    
    drvname = 'Matrix AFS'
    
    def __init__(self,*args,**kwargs):
        super(afs_driver,self).__init__(*args,**kwargs)
        # Call the init method that sets up the instrument
        
        # make sure we can address it
        self.get_filter()
        
    def set_filter(self, filter):
        """Sets the AFS to the specified filter setting. The filter number is an integer"""
        self.vi.write("F%d"%filter)
        
    def get_filter(self):
        """Requests the current filter number. Response from the AFS is a three digit number, with leading zeros as necessary."""
        return int(self.vi.ask("FV"))
        
    def set_post_amps(self,n=0):
        """ Turns on the 2 post amps on or off. post amp1 has a gain of 20dB and post amp2 has a gain of 37dB.
        """        
        if n == 2:
            self.vi.write('PA1IN')
            self.vi.write('PA2IN')
        elif n == 1:
            self.vi.write('PAOUT')
            self.vi.write('PA1IN')
        else:
            self.vi.write('PAOUT')

register(afs_driver)
        
        