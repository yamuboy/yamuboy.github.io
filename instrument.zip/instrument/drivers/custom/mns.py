from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import CustomInstrument
from .. import timed_wait_ms, register

class mns_driver(CustomInstrument):
    "Matrix noise source driver"
    
    drvname = 'Matrix Noise Src'
    
    def __init__(self,*args,**kwargs):
        # init parent class
        super(mns_driver,self).__init__(*args,**kwargs)
        self.init()
        
    def init(self,force=False):
        #self.vi.write("RESET")
        if not hasattr(self.vi,'_mnsinit') or force:
            self.vi.write("OUTCRLF")
            r1= self.vi.ask("R1?")
            r2= self.vi.ask("R2?")
            self.vi.write("R2DDDDDDDD")
            self.vi.write("R1UDDDDDDD")
            self.vi._mnsinit = True
                                               
    def set_attenuator(self, att):
        # Sets the value of the 'A' attenuator
        self.vi.write("AA%.1f"%float(att))
            
    def get_attenuator(self):
        # Gets the value of the current attenuator setting
        return float(self.vi.ask("AVA"))
        
    def set_relay_state(self, state=None):
        # Turns the noise source relay on/off. The default value doesn't change the current setting
        if state==1:
            self.vi.write("R2DDDDDDUU")
        elif state==0:
            self.vi.write("R2DDDDDDDD")
        else:
            self.vi.write("X")
            
    def set_tilt(self, tilt=None):
        # Sets the noise tilt- F gives a flat tilt, T gives a tilt and E gives an external tilt. Default is flat
        if tilt=='9db_tilt':
            self.vi.write("R1UDDDDDDD")
        elif tilt=='ext':
            self.vi.write("R1UUDDDDDD")
        else:
            # Default is flat tilt
            self.vi.write("R1DXDDDDDD")
            
    def set_notches(self,notches=None):
        # Enables the notch filters. Default is No Notch Filters
        if notches==1:
            self.vi.write("UXXXXX")
        elif notches==2:
            self.vi.write("XUXXXX")
        elif notches==3:
            self.vi.write("XXUXXX")
        elif notches==4:
            self.vi.write("XXXUXX")
        else:
            self.vi.write("DDDDXX")
            
register(mns_driver)
            

            
        
