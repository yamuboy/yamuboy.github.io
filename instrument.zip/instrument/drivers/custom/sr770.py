from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import CustomInstrument
from .. import timed_wait_ms, register
import re

class sr770_driver(CustomInstrument):
    "Stanford Reseach SR770 FFT analyzer"
    
    drvname = 'SR 770'
    
    def __init__(self,*args,**kwargs):
        super(sr770_driver,self).__init__(*args,**kwargs)
        # Call the init method that sets up the instrument for X-MOD measurements
        self.clear()
        self.init()
        
    def clear(self):
        self.vi.write("*CLS")
        self.vi.write("*RST")
        
    def init(self):
        self.vi.write("AOFM 0.")
        # The OVRM command sets or queries the GPIB Overide Remote Yes/No condition.
        self.vi.write("OVRM 1")
        # Clear the status registers
        self.vi.write("*CLS")
        
    def set_cf(self,cf):
        # Set the Center Frequency of the SR770
        # For example, if you need to set the CF to 15.75 KHz, you should send 15750
        self.vi.write("CTRF %d;"%cf)
        
    def set_irng(self,irange):
        # Sets the input range to i dbv full scale
        self.vi.write("IRNG %d"%(irange))
        
    def set_units(self,units,trace=None):
        if trace is None:
            trace=-1
        self.vi.write("UNIT %d,%d"%(trace,units))
        
    def set_window(self,window,trace=None):
        if trace is None:
            trace=-1
        self.vi.write("WNDO %d,%d"%(trace,window))
        
    def set_tref(self,tref,trace=None):
        if trace is None:
            trace=-1
        self.vi.write("TREF %d,%d"%(trace,tref))
        
    def set_ydiv(self,ydiv,trace=None):
        if trace is None:
            trace=-1
        self.vi.write("YDIV %d,%d"%(trace,ydiv))
        
    def set_span(self,span=None):
        # Sets the span of the SR770, if span is None, a default value is used.
        if span:
            self.vi.write("SPAN %d"%span)
        else:
            self.vi.write("SPAN 0")
            
    def ask_if_done(self):
        # Query the FFT status byte. Set it to 7 and query it till it's 1
        stb= float(self.vi.ask("FFTS? 7"))
        while True:
            if stb==1:
                break
            else:
                timed_wait_ms(20)
                stb= float(self.vi.ask("FFTS? 7"))
                
    def set_marker_offset(self,offset,trace=None):
        if trace is None:
            trace=-1
        self.vi.write("MROF %d,%d"%(trace,offset))
        
    def set_avg_state(self,state):
        if state == 0:
            self.vi.write("AVGO 0")
        else:
            self.vi.write("AVGO 1")
            
    def restart_trace(self):
        self.vi.write("STRT")
            
    def set_avg_num(self,avg):
        self.vi.write("NAVG %d"%avg)
        
    def set_marker_width(self,width,trace=None):
        if trace is None:
            trace=-1
        self.vi.write("MRKW %d,%d"%(trace,width))
        
    def set_auto_range(self,state):
        self.vi.write('ARNG %d'%state)

            
    def set_grid_mode(self,mode,trace=None):
        # The grid mode can be off(0), 8 divisions(1), or 10 divisions(2)
        if trace is None:
            trace=-1
        self.vi.write("GRID %d,%d"%(trace,mode))  

    def set_marker_mode(self,mode,trace=None):
        # Sets the marker type to maximum(0), minimum(1), or mean(2)
        if trace is None:
            trace=-1
        self.vi.write("MRKM %d,%d"%(trace,mode)) 
        
    def move_to_bin(self,bin,trace=None):
        # The MBIN command moves the trace g marker region to bin i where 0 
        # 399. The marker region will be centered on bin i. The marker will seek the max,
        # min, or mean within the region as set by the marker seek mode.
        if trace is None:
            trace=-1
        self.vi.write("MBIN %d,%d"%(trace,bin))       
        
    def set_marker_type(self,type):
        # The marker type MRKCN makes Marker X position the center of the span
        # The marker type MKPK, The marker region will be centered around the maximum or
        # minimum data value on the screen depending upon the marker seeks mode.
        # only the marker on the active graph is affected
        if type=="cn":
            self.vi.write("MRKCN")
        if type=="pk":
            self.vi.write("MKPK")   
        
    def measure_marker(self,trace=None):
        if trace is None:
            trace = -1
        return float(self.vi.ask("MRKY? %d"%trace))
        
register(sr770_driver)
            
        
        
        
    