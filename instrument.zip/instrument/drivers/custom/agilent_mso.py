
from instrument.family import CustomInstrument
from instrument import timed_wait_ms, register

# Need to find a way to map channels

class AgilentMSO(CustomInstrument):
    "Agilent MSO/DSO scope driver"
    
    drvname = 'Agilent DSO/MSO'
    regex = r'[md]so'
    
    def __init__(self, *args, **kwargs):
        "initialize"
        #kwargs['capabilities'] = ()
        kwargs['valid_channels'] = [1,2,3,4]
        super(AgilentMSO,self).__init__(*args,**kwargs)
        
        
        # automatically run instrument initialization
        self.init()
                
    def init(self, force=False):
        "init instrument state"
        if self.vi is not None and (not hasattr(self.vi,'_msomodel') or force):
            # do first-time initialization stuff
            ty = self.vi.ask('*IDN?')
            self.vi._msomodel = ty
            self.vi.write('*CLS')
            
            # set waveform mode to normal
            self.vi.write('WAV:POIN:MODE NORM')
            
            self._ydivs = 8.0
            self._scope_fs_ranges = [0.16,0.24,0.32,0.4,0.64,0.8,1.0,1.6,2.4,3.2,4.0,6.4,8.0,10.0,12.0]
            
            self.set_trigger_mode()
            self.set_marker_mode()
    
    def get_ydivs(self):
        return self._ydivs
            
    def set_scope_ranges(self,ilimit = None):
        use_fs_iranges = []
        if ilimit:
            for x in self._scope_fs_ranges:
                if 0.9*x <= ilimit:
                    use_fs_iranges.append(x)
            if not len(self.use_fs_iranges):
                use_fs_iranges.append(self._scope_fs_ranges[0])
        else:
            use_fs_iranges.append(self._scope_fs_ranges[0])
        # scope ranges to use for measuring drain current
        # this code produces a list of 3-tuples, where the contents of each
        # 3-tuple are (`range_high`, `scale_value`, `offset_value`)
        # `range_high` is the current at which the scale setting should be increased
        #    this is defined as 85% of the full-scale range
        # `scale_value` is the value of the Y-axis per-division scale for this range
        # `offset_value` is the value of the Y-axis offset for this range
        self._scope_iranges  = [(r*0.85,r/self._ydivs,r*0.45) for r in use_fs_iranges]
        
    def get_oscope_iranges(self):
        return self._scope_iranges
            
    def config(self, chan = None,**kwargs):
        """configure basic instrument functions
        
        Keywords:
        ------------------------------------------------
        avg           int, set the averaging count - set to None to disable
        marker_mode   sets the marker mode to 
                      off - removes the marker mode from the display
                      man - enables a manual placement of the markers
                      wav - tracks the current waveform
                      meas - tracks the most recent measurement
                      FFT - tracks the current FFT peak that has been navigated to
        
        """   
        
        c = self._get_channel()
        
        if 'avg' in kwargs:
            avg = kwargs.pop('avg')
            try:
                # try to enable averaging
                n = int(avg)
                if n < 2:
                    raise ValueError()
                self.vi.write('ACQ:TYPE AVER;COUN %d;COMP 100'%n)
            except:
                # turn off averaging
                self.vi.write('ACQ:TYPE NORM;COUN 1;COMP 100')                
        
            
    def set_trigger_mode(self, mode='free'):
        "set the instrument trigger mode"
        
        allowed_modes = ('free','single')
        m = mode.lower()
        if m not in allowed_modes:
        
            raise ValueError('trigger mode `%s` is not suported'%mode)
        
        if m == 'free':
            self.vi.write(":TRIG:SWE AUTO")
        
        elif m == 'single':
            self.vi.write(":TRIG:SWE SING")    
        
        
        self.vi._msotrigmode = m
        
    def get_trigger_mode(self):
        "retrieve trigger mode"
        return self.vi._msotrigmode
    
    def trigger(self):
        "trigger an acquisition"
        self.vi.write(':DIG')

    def _get_channel(self):
        return self.chan    
        
    def get_waveform(self, chan=None):
        """get the scope waveform of a channel
        
        returns a 2-tuple of lists of x-values (in time units)
        and y-values (in the units of the trace)
        """
        c = self._get_channel()
        w = self.vi.ask('WAV:SOUR CHAN%d;FORM ASC;DATA?'%c)
        # Covert from unicode to string and get rid of leading annoying character --> '#8001...' 
        # That leading character causes visa's read_ascii_values, and ask_for_values methods to fail
        w = w.encode('ascii','ignore').strip('\n')
        # Get rid of leading # thing
        w = w.split(',')
        try:
            w[0] = w[0].split(' ')[1]
        except IndexError:
            w[0] = w[0].split('#800012999')[1]
        w = [float(x) for x in w]
        n = len(w)
        range = float(self.vi.ask('TIM:RANG?'))
        ref = self.vi.ask('TIM:REF?').strip().upper()
        pos = float(self.vi.ask('TIM:POS?'))
        if ref == 'LEFT':
            sf = 0.1
        elif ref == 'RIGH':
            sf = 0.9
        else:
            sf = 0.5
        
        ts = pos-sf*range
        step = range/float(n-1)
        x, y = [], []
        for v in w:
            y.append(v)
            x.append(ts)
            ts += step
        
        return x, y

       
    def set_marker_mode(self, mode='manual'):
        "set the scope marker mode"
        allowed_modes = ('manual','freq','period','wav')
        if mode not in allowed_modes:
            raise Exception("Marker Mode not supported")
        self.vi.write("MARK:MODE %s"%mode.upper())
        self.vi._msomarkmode = mode        
    
    def get_marker_mode(self):
        "set the scope marker mode"
        return self.vi._msomarkmode
        
    def set_marker_pos(self, x1, x2):
        "set the position of the markers (only valid in certain modes)"
        if self._vi._msomarkmode == 'manual':
            self.vi.write('MARK:X1P %g;X2P %g'%(x1,x2))
        
    def get_marker_pos(self):
        "get the position of the markers"
        return float(self.vi.ask('MARK:X1P?')), float(self.vi.ask('MARK:X2P?'))
        
            
    def get_marker_value(self):
        "get the marker value, this can be either a single float or a 2-tuple depending on the mode. Right now only supports wav mode"
        if self.vi._msomarkmode == 'wav':
            c = self._get_channel()
            w = self.vi.ask('WAV:SOUR CHAN%d;FORM ASC;DATA?'%c)
            # Covert from unicode to string and get rid of leading annoying character --> '#8001...' 
            # That leading character causes visa's read_ascii_values, and ask_for_values methods to fail
            w = w.encode('ascii','ignore').strip('\n')
            # Get rid of leading # thing
            w = w.split(',')
            # Need to check if the value is negative
            try:
                w[0] = w[0].split(' ')[1]
            except IndexError:
                w[0] = w[0].split('#800012999')[1]
                
            w = [float(x) for x in w]            
            n = len(w)
            range = float(self.vi.ask('TIM:RANG?'))
            ref = self.vi.ask('TIM:REF?').strip().upper()
            pos = float(self.vi.ask('TIM:POS?'))
            if ref == 'LEFT':
                sf = 0.1
            elif ref == 'RIGH':
                sf = 0.9
            else:
                sf = 0.5
            
            ts = pos-sf*range
            step = range/float(n-1)
            x, y = [], []
            for v in w:
                y.append(v)
                x.append(ts)
                ts += step
            
            self.vi.ask('MARK:X1Y1 CHAN%d;X2Y2 CHAN%d;*OPC?'%(c,c))
            x1 = float(self.vi.ask('MARK:X1P?'))
            x2 = float(self.vi.ask('MARK:X2P?'))
            
            zidx = int(n*(sf-pos/range))
            
            x1i = int((x1/range)*n) + zidx
            x2i = int((x2/range)*n) + zidx
            
            if x1i > x2i:
                x1i, x2i = x2i, x1i
            av = 0.0
            for v in w[x1i:x2i+1]:
                av += v
            av = av/float(x2i-x1i+1)
            
        return av
                        
    
    def get_x_divisions(self):
        "returns the number of x divisions"
        return 10
    
    def set_x_scale(self, v):
        "set the time axis scale"
        self.vi.write('TIM:SCAL %g'%v)   
    
    def get_x_scale(self):
        "get the time axis scale"
        return float(self.vi.ask('TIM:SCAL?'))

    def set_x_range(self, v):
        "set the time axis scale"
        self.vi.write('TIM:RANG %g'%v)   
    
    def get_x_range(self):
        "get the time axis scale"
        return float(self.vi.ask('TIM:RANG?'))
                
    def get_y_divisions(self):
        "returns the number of y divisions"
        return 8
    
    def set_y_scale(self, scale, chan=None):
        "set the y-axis scale for the channel"
        c = self._get_channel(chan)
        self.vi.write('CHAN%d:SCAL %g'%(c,scale))
    
    def get_y_scale(self, chan=None):
        "get the y-axis scale for the channel"
        c = self._get_channel(chan)
        return float(self.vi.ask('CHAN%d:SCAL?'%c))

    def set_y_range(self, r, chan=None):
        "set the y-axis full-scale range for the channel"
        c = self._get_channel(chan)
        self.vi.write('CHAN%d:RANG %g'%(c,r))    
    
    def get_y_range(self, chan=None):
        "get the y-axis full-scale range for the channel"
        c = self._get_channel(chan)
        return float(self.vi.ask('CHAN%d:RANG?'%c))

    def set_y_offset(self,offs,chan = None):
        c = self._get_channel(chan)
        self.vi.write('CHAN%d:OFFS %g'%(c,offs))
        
    def set_y_position(self, pos, chan=None):
        "set the y-position of the channel, measured from the bottom of the screen"
        c = self._get_channel(chan)
        offset = 0.5*self.get_y_range(chan=chan) - pos
        self.vi.write('CHAN%d:OFFS %g'%(c,offset))    
    
    def get_y_position(self, chan=None):
        "set the y-position of the channel, measured from the bottom of the screen"
        c = self._get_channel(chan)
        return 0.5*self.get_y_range(chan=chan) - float(self.vi.ask('CHAN%d:OFFS?'%c))
    
    def _close(self):
        "called when the instrument is closed"
        # set mode back to free-run
        if self.vi:
            self.vi.write(':RUN')


            

# register the driver
register(AgilentMSO)     
        