from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import CustomInstrument
from .. import timed_wait_ms, register

_allchans = range(1,167)
class asx16c_driver(CustomInstrument):
    "Matrix ASX16C signal source driver"
    
    drvname = 'Matrix ASX16C'
    
    def __init__(self,*args,**kwargs):
        """Init the parent class which is a child of the GenericInstrument class"""
        super(asx16c_driver,self).__init__(*args,**kwargs)
        self.init()
    
    def init(self, force=False):
        """Sets the ASX-16C/D to the same power-on state created by pressing the Front Panel RESET button. This feature is only available on Model ASX-16C/D,Serial Number 14 and later""" 
        if not hasattr(self.vi,'_asxinit') or force:
            self.vi._asxinit = True
            self.vi.write("QLOW")
            self.vi.write("P0")
            timed_wait_ms(500)
            self.vi.write('OUTCRLF')
            # query atten
            a = int(self.vi.ask('AV'))
            # set atten
            self.vi.write('A 80')
            # query atten again
            a2 = int(self.vi.ask('AV'))
            # do other stuff
            self.vi.write('FD')
            self.vi.ask('FF')
            self.vi.write('MODNORM')
            self.vi.write('GFOUT')
    
    def init_channels(self, chanlist):
        "initialize channels, return attenuator levels and states"
        out = []
        for ch in chanlist:
            st = self.vi.ask('SM%d'%ch).strip().lower()
            lvl = int(self.vi.ask('LMH%d'%ch))
            x = int(self.vi.ask('BVH%d'%ch))
            y = int(self.vi.ask('FRVA%d'%ch))
            out.append((lvl,st))
        return out
        
    def all_mod(self,channels=None):
        "set all channels in the list to modulated mode"
        if channels is None:
            channels = _allchans
        self.set_modules(channels,state='mod')
    all_carriers_modulated = all_mod
            
    def all_cw(self,channels=None):
        """ Turn on all carriers in CW mode. The channels argument is a list of all the carrier modules enabled for the test"""
        if channels is None:
            channels = _allchans
        self.set_modules(channels,state='cw')
    all_carriers_cw = all_cw            
            
    def all_low(self,channels=None):
        """In this mode all the carriers are unmodulated with their amplitudes at least 35dB lower than normal.
           The ASX16C powers up in the QLOW mode.
        """
        if channels is None:
            channels = _allchans
        self.set_modules(channels,state='low')
    all_carriers_low = all_low

    def all_off(self,channels=None):
        """ Sets the quality factor to "off". All modules have their power removed"""
        if channels is None:
            channels = _allchans
        self.set_modules(channels,state='off')
                    
    def get_main_attenuator(self):
        """ Gets the value of the main RF attenuator """
        return float(self.vi.ask('AV'))
    get_main_attenuation = get_main_attenuator

    def set_main_attenuator(self,att):
        """Sets the main attenuation level"""
        self.vi.write('A%d'%(att))
    set_main_attenuation_level = set_main_attenuator
    
    def get_module_level(self,chan):
        """ Asks for the step level of the specified module in high resolution mode. Value should be
            between 0-720
        """ 
        return int(self.vi.ask('LMH%d'%chan))
    get_currentmodule_level = get_module_level
        
    def set_module_level(self,chan,level):
        """Sets the attenuation level of the individual module"""
        self.set_modules(chan,level=level)

    def get_module_mode(self,chan):
        """ Requests the operating mode of the specified module. Response from the ASX is always a three character string.
            For CW, the the response is "CW", for Modulated operation it's "MOD", for power-off it's "OFF" and for 
            -35dB down it's "LOW"            
        """       
        return self.vi.ask("SM%d"%chan).strip().lower()
        
    def set_module_mode(self,chan,mode):
        """ The chan is the module number, for example the module corresponding to the frequency 55.25MHz is 9.
            This method sets the module mode to CW ON, Mod, or OFF            
        """
        self.set_modules(chan,state=mode)
    
    def set_modules(self, chanlist, **kwargs):
        """Set module states and attenuations"""
        
        if isinstance(chanlist,int):
            # turn chanlist into a 1-tuple so that we can iterate over it
            chanlist = (chanlist,)
            
        setstate, setlevel = False, False
        statelist, levellist = False, False
        if 'state' in kwargs:
            state = kwargs.pop('state')
            setstate = True
        elif 'mode' in kwargs:
            state = kwargs.pop('mode')
            setstate = True
        
        if setstate:
            if isinstance(state,(list,tuple)):
                if len(state) != len(chanlist):
                    raise ValueError("'state' list has a different length than channel list")
                statelist = True
            else:
                state = state.lower()
        
        
        if 'level' in kwargs:
            level = kwargs.pop('level')
            setlevel = True
        elif 'att' in kwargs:
            level = kwargs.pop('att')
            setlevel = True
        
        if setlevel:
            if isinstance(level,(list,tuple)):
                if len(level) != len(chanlist):
                    raise ValueError("'level' list has a different length than channel list")
                levellist = True
            else:
                level = int(level)
        
        if len(kwargs):
            raise ValueError("unknown keywords: "+(', '.join(kwargs.keys())))
        
        modemap = {'off':'P','low':'P','cw':'C','mod':'M'}
        for i,ch in enumerate(chanlist):
            if setstate:
                if statelist:
                    st = state[i].lower()
                else:
                    st = state
                curst = self.get_module_mode(ch)
                if st != curst:
                    if st == 'off':
                        self.vi.write('QOFF')
                    elif st == 'low':
                        self.vi.write("QLOW")
                    self.vi.write('%s%d'%(modemap[st],ch))
            
            if setlevel:
                if levellist:
                    lvl = int(level[i])
                else:
                    lvl = level
                if lvl < 0 or lvl > 720:
                    raise ValueError("illegal attenuator value (%d,%d)"%(ch,lvl))
                    
                curr = self.get_module_level(ch)
                adj = lvl - curr
                if adj != 0:
                    ok = self.vi.ask('LH%d,%d'%(ch,adj)).upper().strip()
                    if ok != 'G':
                        raise ValueError("could not set channel attenuator (%d,%d)"%(ch,lvl))
    set_module = set_modules

        
        
# register this driver with an appropriate regex
register(asx16c_driver)