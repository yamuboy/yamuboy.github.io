from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import PulserInstrument
from .. import timed_wait_ms, register

class Focus_pulser(PulserInstrument):
    """Focus gate and drain pulser"""
    
    drvname = 'Focus pulser'
    regex = r'focus'
    
    def __init__(self, rsc_name, **kwargs):
        "object initializer"
        # massage VISA resource string and init parent
        if (rsc_name is None or not len(rsc_name)) and 'ipaddress' in kwargs:
            rsc_name = "TCPIP::%s::%d::SOCKET"%self._parse_ipaddr(kwargs.pop('ipaddress'))
        else:
            if not rsc_name.upper().startswith('TCPIP::'):
                self._error("resource string format is 'TCPIP::<ipaddress>::<port>::SOCKET'")
        super(Focus_pulser,self).__init__(rsc_name,**kwargs)
        
        # init instrument
        self.init()

    def init(self, force=False):
        "initialize the instrument"
        if self.vi and (force or not hasattr(self.vi,'_focuspulser')):
            
            
            # preset the pulser
            self.vi.write('DRAIN OFF')
            self.vi.write('GATE OFF')
            self.vi.write('MODE OFF')
            self.vi.write('TRIGGER FREE')
            self.vi.write('RELAY 0')
            self.vi.write('DRAIN OFF 0.0 1.0')
            self.vi.write('GATE OFF 0.0 -0.5')
            self.vi.write('DRAIN TIMING 0.0 0.0')
            self.vi.write('GATE TIMING 0.3 -0.3')
            
            # set the preset parameters
            p = self._get_params(0)
            p['width'] = 1.0e-6
            p['period'] = 1.0e-3
            p['vgq'] = 0.0
            p['vgp'] = -0.5
            p['vdq'] = 0.0
            p['vdp'] = 1.0
            p['drain_mode'] = 'PULSE'
            p['gate_mode'] = 'PULSE'
            p['trigger'] = 'FREE'
            p['drain_pre'] = 0.0
            p['drain_post'] = 0.0
            p['gate_pre'] = 300e-9
            p['gate_post'] = -300e-9
            p['state'] = 0
            p['inverted'] = False
        
    def config(self, **kwargs):
        """
        
        DOCUMENT!!!!!!
        
        
        """
        if not hasattr(self.vi,'_focuspulser'):
            self._error("init() must be called before config()")
            
        p = self._get_params(0)
        
        req_state = None
        if 'state' in kwargs:
            req_state = bool(kwargs.pop('state'))
            if not req_state and p['state']:
                # turn off the pulser
                self._pulser_off(p)

        # check for changes to the pulse parameters (width and period)
        pulseparams = False
        for k in ('width', 'period'):
            if k in kwargs:
                pulseparams = True
                break
        
        if pulseparams:
            # pulse parameters specified, change pulse characteristics
            period = kwargs.pop('period',p['period'])
            width = kwargs.pop('width',p['width'])
            
            if width < 300.0e-9 or width > 1.0e-2:
                self._error("invalid pulse width: 300 ns <= 'width' <= 10 ms")
            if period < 1.0e-6 or period > 0.1:
                self._error("invalid pulse period: 1 us <= 'period' <= 100 ms")
            if (period - width) < 500.0e-9:
                self._error("invalid pulse parameters: ('period' - 'width') >= 500 ns")
            
            p['width'] = width
            p['period'] = period
            self._pulser_setup_pulse(p)
        
        # check for changes in pulse timing
        timingparams = False
        timing_plist = ('gate_pre', 'gate_post', 'drain_pre', 'drain_post')
        for k in timing_plist:
            if k in kwargs:
                timingparams = True
                break
        
        if timingparams:
            # timing parameters specified, change pulser timing
            parms = {}
            for k in timing_plist:
                parms[k] = kwargs.pop(k,p[k])
                if parms[k] < -800e-9 or parms[k] > 800e9:
                    self._error("invalid timing parameter: -800 ns <= '%s' <= 800 ns"%k)
            # verify that the timing parameters are valid for the pulse width specified
            ## TODO
            
            for k in timing_plist:
                p[k] = parms[k]
            
            # update pulse timing
            self._pulser_adjust_timing(p)
                
        # check for changes in the gate or drain mode
        # valid_gd_mode = ('OFF','ON','QUI','PULSE')


        
        # check for changes in the quiescent and pulse voltages
        
        

        # check for changes in the trigger specification
        ### TODO
        # trig_modes = ('FREE','EXTERNAL','SINGLE')
        
        
        
        if req_state and not p['state']:
            # turn on the pulser
            self._pulser_on(p)
                    
    def _pulser_on(self, params):
        "turn on the pulser"
        self.vi.write('MODE PULSE')
        self.vi.write('GATE %s'%params['gate_mode'])
        timed_wait_ms(50)
        self.vi.write('DRAIN %s'%params['drain_mode'])
        self.vi.write('RELAY 1')
        timed_wait_ms(50)
        params['state'] = 1
        
    def _pulser_off(self, params):
        "turn off the pulser"
        self.vi.write('DRAIN OFF')
        self.vi.write('RELAY 0')
        timed_wait_ms(50)
        self.vi.write('GATE OFF')
        timed_wait_ms(50)
        self.vi.write('MODE OFF')
        params['state'] = 0
        
    def _pulser_setup_pulse(self, params):
        "adjust the pulse width and period"
        if params['state']:
            self.vi.write('MODE OFF')
            timed_wait_ms(200)
        
        # setup the pulse parameters
        
        
        if params['state']:
            self.vi.write('MODE PULSE')
            timed_wait_ms(200)
        
        
        
    def _pulser_adjust_timing(self, params):
        "adjust the gate and drain timing parameters"
        self.vi.write('DRAIN TIMING %.3f %.3f'%(params['drain_pre']*1.0e6,params['drain_post']*1.0e6))
        self.vi.write('GATE TIMING %.3f %.3f'%(params['gate_pre']*1.0e6,params['gate_post']*1.0e6))
        if params['state']:
            self.vi.write('MODE PULSE')        
        
# register the driver
register(Focus_pulser)   
