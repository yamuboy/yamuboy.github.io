from __future__ import division, print_function, unicode_literals, absolute_import
# this package has no exported names
__all__ = []

import sys
from .. import timed_wait_ms, register, DummyInstrument

def _init():
    import os, os.path, logging
    
    base = os.path.dirname(__file__)
    module_path = __name__
    for d in os.listdir(base):
        if d.startswith('.') or d.startswith('_'):
            continue
        dpath = os.path.join(base,d)
        # import each of the driver sub-directories
        if os.path.isdir(dpath):
            mod = module_path+'.'+d
            try:
                __import__(mod)
            except ImportError as e:
                logging.getLogger(module_path).warning("import error for '%s' => %s"%(mod,e))
# init the module
_init()
