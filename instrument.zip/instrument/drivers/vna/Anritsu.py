from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import (NetworkAnalyzer, S1P_P1, S1P_P2, S2P, CUSTOM, ESRM, ERFT, EDIR, ETRT, ELDM, EISO,
    PORT1, PORT2, TWO_PORT, RAW)
from .. import timed_wait_ms, register

class AnritsuVNA(NetworkAnalyzer):
    """ Driver for the Anritsu VNA"""

    def __init__(self,*args,**kwargs):
        '''kwargs['values_format']=VF_DOUBLE'''
        kwargs['capabilities']=('MS2P','Phase','Delay','SWR','Power')
        super(AnritsuVNA,self).__init__(*args,**kwargs)


    def init(self):
        """Initializing the Instrument
           Anritsu can display up-to 16 active traces at a time. This driver is meant to display four active traces relevant to usual SPar measurements(S11, S21,etc),
           and measure data on each active trace. The VNA has tonnes of other capavilities which will be added to this driver, including ability to make multiple channel
           measurements. The following measurement formats are valid:
           MLOG- Log magnitude
           PHASE- Phase
           LOGPH- Displays and takes log magnitude and phase data on current active trace. If number of points is 201 and this measurement option is enabled, half the
                  output values are Log Mag and the other half are phase.
           SWR- VSWR
           GDEL- Group Delay
           PWRI- Power In
           PERO- Power Out
    
        """
        model=self.vi.ask('*IDN?')
        if model !='ANRITSU,MS4644A,1118212,1.4.0':
            self._raise_error('VNA not supported by this driver')

        # Setting the format to Log Magnitude
        p0=self._get_params(0)
        p0['_numports']= 2
        p0['averaging']= 'POIN'
        p0['_format']='MLOG'
                  
        if self.default_channel<=0:
            self.set_channel(1)

        #Set sweep from Continuous to Hold
        self.vi.write('*SRE 0; :SENS:HOLD:FUNC HOLD')
        
        #Error Check. If No error, clear the error register
        err_mesg = self.vi.ask(':SYST:ERR?')
        if (err_mesg != 'No Error'):
            self._raise_error('Error register not clear, refresh instrument')

        #Clear error register
        self.vi.write(':SYST:ERR:CLE')

        #Clear Status Register
        self.vi.write('*CLS')
        
        # Make sure language is native and not something else
        self.vi.write('LANG NATIVE')
        p=self._get_params()


    def config(self,chan=None,**kwargs):

        #tuple for channel measurement format. Just in Case...
        sel_form=('MLOG','PHAS','LOGPH','SWR','GDEL','PWRI','PWRO')
        #set traces for SPar measurement
        trace={'CH1':'S11','CH2':'S21','CH3':'S12','CH4':'S22'}
       
        p=self._get_params(0)
        if 'averaging' not in p:
            self._raise_error('init() must be called before config() can be used')
        
        format_meas = ':CALC:SEL:FORM '+ p['_format']

                
        for k,v in trace.items():
            s=k+';'+v
            self.vi.write(s)
            self.vi.write(format_meas)

            

    def get_cal_coeffs(self,coeff,chan=None):

        raise NotImplemented

    def set_cal_coeffs(self,chan=None):

        raise NotImplemented

    def get_flist(self,chan=None):

        ch=self._get_channel(chan=chan)
        return self.vi.ask_for_values(':FORM:DATA REAL;:FORM:BORD SWAP; SENS:FREQ:DATA?')
        # format bord NORM if ieee_double enabled in values_format

    def initiate(self,chan=None):

        p = self._get_params(chan)
        ch=self._get_channel(chan=chan)
        if '_numports' not in p:
            self._raise_error('Channel not configured')

        # Checking averaging state and type
        # If type is anything but point,set to point by point averaging
        avg_state=self.vi.ask(':SENS:AVER:STAT?')
        if avg_state=='ON':
            avg_count=self.vi.ask(':SENS:AVER:COUNT?')
            avg_type= self.vi.ask(':SENS:AVER:TYP?')
            if avg_type=='SWE':
                self._raise_error('Only point by point averaging allowed, setting to point by point...')
                self.vi.write(':SENS:AVER:TYP POIN')

        #Triggering a measurement
        self.vi.write(':TRIG:SING; *ESE 1;*OPC')

                 
    def ask_if_done(self,chane=None):
        # Polling the status register to see if sweep completed  
        timed_wait_ms(10)
        status=self.vi.ask('*ESR?')
        return status
        
    def fetch(self,chan=None):

        #Fetching the measurement results
        p=self._get_params(chan)
        if '_numports' not in p:
            self._raise_error('Channel not configured')

        #hard coding number of traces now, but will modify to query nunmber of traces and loop accordingly
        trace={'1':'S11','2':'S21','3':'S12','4':'S22'}
        for k,v in trace.items():
            ch_sel='CH'+k
            self.vi.write(ch_sel)
            self.vi.write(':FORM:DATA REAL;:FORM:BORD')
            r=self.vi.ask_for_values(':CALC:SEL:DATA:SDAT?')
            r2=[]
            result=[]
            for i in range(len(r)/2):
                cnum= complex(r[2*i],r[2*i+1])
                r2.append(cnum)
            result.append(r2)
        return(tuple(result))
           

    def save_state(self, state_id):
        state= 'SV'+state_id
        self.vi.write(state)

    def recall_state(self, state_id):
        state='RC'+state_id
        self.vi.write(state)

    
        
               
            
