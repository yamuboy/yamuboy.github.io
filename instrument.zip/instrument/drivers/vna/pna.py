from __future__ import division, print_function, unicode_literals, absolute_import
from ...family import (NetworkAnalyzer, S1P_P1, S1P_P2, S2P, CUSTOM, ESRM, ERFT, EDIR, ETRT, ELDM, EISO,
    PORT1, PORT2, TWO_PORT, RAW)
from .. import timed_wait_ms, register
from ... import VF_DOUBLE

class AgilentPNA(NetworkAnalyzer):
    """Agilent 836X-series PNA driver"""
    
    drvname = 'Agilent PNA'
    regex = r'(?:agilent)?pna'
    
    def __init__(self, *args, **kwargs):
        """Create the object."""
        kwargs['values_format'] = VF_DOUBLE
        kwargs['valid_channels'] = range(1,17)
        super(AgilentPNA,self).__init__(*args,**kwargs)
                
        # run the initialization
        self.init()
                
    def init(self, force=False):
        """Initialize the driver and instrument."""
        
        if self.vi is not None and (not hasattr(self.vi,'_836xmodel') or force):            
            # query the identification string and verify that this is
            # a valid instrument for this driver
            ident = self.vi.ask('*CLS;*IDN?')
            if not(ident.find("Agilent") > -1 or ident.find("Keysight") > -1) or not(ident.find(",836") > -1 or ident.find(",N524") > -1):
                self._error('instrument is not supported by this driver')
                    
            self.vi._836xmodel = ident
            
    def config(self, chan=None, **kwargs):
        """Set configuration parameters.
        
        Standard Keywords (must be supported):
        mode - one of the measurement mode constants
           (a mode must be selected before a measurement will succeed)
        measparam - a helper parameter that compliments the 'mode' in cases where
           a custom or complicated measurement must be defined
           TODO: define the syntax for this parameter
        """
        self._vicheck()
        
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        
        mode = kwargs.pop('mode',None)
        if mode is not None:
            meas = []                        
            if mode == S2P:
                meas = [('S',1,1),('S',1,2),('S',2,1),('S',2,2)]
            elif mode == S1P_P1:
                meas = [('S',1,1)]
            elif mode == S1P_P2:
                meas = [('S',2,2)]          
            elif mode == CUSTOM:
                ## TODO: define and create these
                
                # error out for now...
                self._error("unsupported mode '%s'"%mode)
                                
                
                
            else:
                self._error("unsupported mode '%s'"%mode)
            
            # configure the newly defined measurements
            p['_mlist'] = self._pna_config_measurements(ch,meas)
            p['mode'] = mode
        
        # pass additional keyword arguments on to pyVISA
        if len(kwargs):
            self.configure_vi(**kwargs)
        
    def _pna_config_measurements(self, ch, meas):
        """Configure a set of measurements for the instrument.
        returns a list of the configured measurement names for later use
        in the fetch() method
        """
        basename = 'pyinstrlib_ch%d_'%ch
        
        # first delete existing measurements
        for i,m in enumerate(self.vi.ask('CALC%d:PAR:CAT?'%ch).strip('"').split(',')):
            if i%2==0 and m.startswith(basename):
                self.vi.write("CALC%d:PAR:DEL '%s'"%(ch,m))
        
        # now define new measurements based on the passed meas parameter
        # and return a list of the names of the new measurements
        mlist = []
        for m in meas:
            parm = m[0]
            if parm == 'S':
                # S-parameter measurements
                mp = m[1]
                sp = m[2]
                mn = 'S%d%d'%(mp,sp)
                name = basename + mn
                self.vi.write("CALC%d:PAR:DEF '%s',%s"%(ch,name,mn))
                mlist.append( (name,'SDATA',) )
                
            ## TODO: other cases (once they are defined)
        
        self._pna_check_errors()
        return mlist
        
    def _pna_check_errors(self):
        """Check for errors that occured and raise them."""
        n = int(self.vi.ask(":SYST:ERR:COUN?"))
        if n > 0:
            # read in all errors and raise them
            lst = []
            for i in range(n):
                lst.append(self.vi.ask(":SYST:ERR?"))
            self._error("instrument errors -> %s"%('; '.join(lst)))
    
    def get_cal_coeffs(self,coeff,chan=None):
        """Get cal coefficients from the instrument.
        coeff - (string) the name of the coefficient to get plus the port
          information.  The form of this string is 'name,measport,srcport' where
          the names are:
          ESRM - source match 
          ERFT - reflection tracking 
          EDIR - directivity 
          ETRT - transmission tracking 
          ELDM - load match 
          EISO - isolation
          and measport/srcport are integers from 1 to N denoting the port
          numbers, where N is the number of ports. For ESRM, ERFT, and EDIR the
          measport and srcport values must be equal and for ETRT, ELDM, and EISO the
          port values must not be equal.
          
          Older 2-port VNAs that use an 8-term error model will not have values for
          ETRT and ELDM and should return None instead.
           
        Must return a sequence of complex-valued cal coefficients.
        """
        ch = self._get_channel(chan)
        cname,mp,sp = NetworkAnalyzer.parse_cal_coeff(coeff)
            
        r = self.vi.ask_for_values("FORM:DATA REAL,64;BORD SWAP;:SENS%d:CORR:CSET:DATA? %s,%d,%d"%(ch,cname,mp,sp))
        r2 = []
        for i in range(len(r)//2):
            r2.append(complex(r[2*i],r[2*i+1]))
        
        self._pna_check_errors()
        return r2
        
    def set_cal_coeffs(self,coeff,values,chan=None):
        """Set cal coefficients in the instrument.        
        coeff - (string) the name of the coefficient to set, see get_cal_coeffs()
          for more details
        values - a sequence of complex-valued cal coefficients, the length of
          this must match the length of the frequency list for the channel
        """
        raise NotImplemented
                
    def get_flist(self,chan=None):
        """Get the frequency list.
        Must return a sequence of real-valued numbers.
        """
        self._vicheck()
        ch = self._get_channel(chan)
        return self.vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?'%ch)
        
    def initiate(self, chan=None):
        """Initiate a measurement."""
        self._vicheck()
        p = self._get_params(chan)
        ch = self._get_channel(chan)
        if '_mlist' not in p:
            self._error("channel '%d' not configured."%ch)        
        
        # set up the SRQ mask
        srqm = 0
        if self._use_srqs:
            srqm = 36
        
        # abort any pending measurements, put the channel in hold, and set up
        # triggering and SRQs
        self.vi.write('SENS%d:SWE:MODE HOLD;:ABOR;*SRE %d;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1'%(ch,srqm))
        
        # detect averaging state
        avg = int(self.vi.ask('SENS%d:AVER:STAT?'%ch))
        if avg:
            # restart averaging and get the averaging count
            count = int(self.vi.ask('SENS%d:AVER:CLEAR;COUN?'%ch))
        else:
            count = 1
    
        # set the group trigger count to be equal to the averaging count
        self.vi.write('SENS%d:SWE:GRO:COUN %d'%(ch,count))
        # trigger a measurement group
        self.vi.write('SENS%d:SWE:MODE GRO;*ESE 1;*OPC'%ch)
        
        self._pna_check_errors()
        
    def ask_if_done(self, chan=None):
        """Check to see if a measurement is done."""
        # chan is ignored since measurement triggering is coupled to 
        # all channels
        self._vicheck()
        return bool(int(self.vi.ask('*ESR?')))
        
    def fetch(self, chan=None):
        """Fetch the measured data from the instrument."""
        self._vicheck()
        ch = self._get_channel(chan)
        p = self._get_params(ch)
        if '_mlist' not in p:
            self._error("channel '%d' not configured."%ch)
        
        measlist = p['_mlist']
                        
        # get the measurements
        result = []
        for name,mode in measlist:
            # select the measurement
            self.vi.write("CALC%d:PAR:SEL '%s'" % (ch,name))
            r = self.vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? %s'%(ch,mode))
            # combine the interlaced real/imag pairs into complex numbers
            ## FIXME!!! - need to handle non-complex data
            ##         (what are the non-complex cases???)
            r2 = []
            for i in range(len(r)//2):
                r2.append(complex(r[2*i],r[2*i+1]))
            result.append(r2)
        
        self._pna_check_errors()
        return tuple(result)
        
    def save_state(self,state_id):
        """Save the current instrument state."""
        raise NotImplemented
                
    def recall_state(self,state_id):
        """Recall a saved instrument state."""
        raise NotImplemented
        
# register the driver
register(AgilentPNA)
