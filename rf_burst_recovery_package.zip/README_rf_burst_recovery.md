# RF burst drain-current recovery measurement

This package controls a Keysight MXG and a Keithley/Tektronix 4200A-SCS PMU to measure drain current recovery after a modulated RF burst.

## Files

- `rf_burst_recovery_measure.py` — main script
- `rf_burst_recovery_config.yaml` — editable configuration file
- `requirements_rf_burst_recovery.txt` — Python dependencies except pylptlib

## Install

On the 4200A host or compatible 32-bit Python environment:

```bash
pip install -r requirements_rf_burst_recovery.txt
pip install path_to_pylptlib-4200SCS
```

pylptlib wraps the 4200A LPT DLL and usually needs 32-bit Python on the parameter analyzer.

## Recommended timing

For 300 us to 1 ms RF bursts, use hardware timing. Configure the MXG ARB for single triggered burst playback. Use the PMU trigger output to start the MXG burst, or use an MXG marker to trigger the PMU. Do not use Python timing for production trapping data.

## Typical sequence

1. Configure the loaded WiFi/802.11ac burst waveform on the MXG.
2. Edit `rf_burst_recovery_config.yaml`.
3. Run:

```bash
python rf_burst_recovery_measure.py --config rf_burst_recovery_config.yaml inspect-lpt
python rf_burst_recovery_measure.py --config rf_burst_recovery_config.yaml test-mxg
python rf_burst_recovery_measure.py --config rf_burst_recovery_config.yaml run
```

## Outputs

Each run creates a timestamped output directory containing:

- `summary.csv` — RF power, baseline current, collapse percentage, recovery fit constants
- `drain_recovery_*.csv` — decoded Id(t), Vd(t), timestamp/status when available
- `drain_raw_*.npz` — raw numeric arrays returned by `pulse_fetch`
- `*_decode_summary_*.json` — decoder diagnostics
- `measurement.log` — SCPI/LPT log

## First recommended settings

- VDS: 12 V
- Capture time: 10 ms
- Sample rate: 1 MSa/s
- Burst length: 1 ms
- RF power sweep: start low and increase slowly
- First controls: RF-off control, CW burst, then WiFi burst

## Notes

The script is intentionally conservative around LPT calls. If your installed pylptlib uses a slightly different signature for `pulse_fetch`, `pulse_output`, or trigger functions, edit the methods in the `Keithley4200PMU` class. The experiment logic is isolated from those low-level calls.
