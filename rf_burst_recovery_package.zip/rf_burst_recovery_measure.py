#!/usr/bin/env python3
"""
RF burst drain-current recovery measurement for GaN trapping studies.

Instruments:
  - Keysight MXG signal generator with preloaded modulated 802.11ac/WiFi waveform
  - Keithley/Tektronix 4200A-SCS with 4225-PMU and optionally 4225-RPM

Main use case:
  Measure drain current Id(t) before, during, and after a modulated RF burst.
  Use the recovery transient after the burst to evaluate current collapse, trapping,
  thermal/bias memory, and waveform-dependent trap activation.

Important timing guidance:
  For 300 us to 1 ms RF bursts, do not rely on Python/SCPI timing to gate RF on/off.
  Use the MXG ARB in triggered single-burst mode and use a hardware trigger between
  the Keithley and the MXG. The script can configure/arm both instruments, but the
  actual burst edge should be hardware timed.

Install:
  pip install pyvisa pyyaml numpy pandas scipy matplotlib
  pip install path_to_pylptlib-4200SCS

Typical run:
  python rf_burst_recovery_measure.py --config rf_burst_recovery_config.yaml run

Debug helpers:
  python rf_burst_recovery_measure.py --config rf_burst_recovery_config.yaml inspect-lpt
  python rf_burst_recovery_measure.py --config rf_burst_recovery_config.yaml test-mxg
  python rf_burst_recovery_measure.py --write-example-config rf_burst_recovery_config.yaml

Notes on pylptlib:
  pylptlib wraps Keithley's 32-bit lptlib.dll. It generally must run on the 4200A host
  or on a compatible remote setup. Function names follow LPT names converted to
  lower-case Python style. Pointer output arguments are usually omitted and returned.
"""

from __future__ import annotations

import argparse
import csv
import dataclasses
import json
import logging
import math
import os
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

try:
    import yaml
except Exception as exc:  # pragma: no cover
    yaml = None

try:
    import pyvisa
except Exception:  # pragma: no cover
    pyvisa = None

try:
    from pylptlib import lpt, param
except Exception:  # pragma: no cover
    lpt = None
    param = None


# =============================================================================
# Configuration
# =============================================================================

EXAMPLE_CONFIG = r"""
# RF burst drain-current recovery measurement configuration

run:
  output_dir: "rf_burst_recovery_results"
  repetitions: 3
  settle_between_repetitions_s: 0.5
  operator_note: "GaN RF burst drain-current recovery test"

instruments:
  mxg_visa: "TCPIP0::192.168.0.50::inst0::INSTR"
  pmu_name: "PMU1"
  visa_timeout_ms: 20000
  use_external_10mhz_reference: false

mxg:
  carrier_hz: 7.5e9

  # RF powers to sweep. These are MXG RF output power setpoints.
  # Start low. Include external RF path loss/gain in your lab notes.
  power_sweep_dbm: [-25, -22, -19, -16, -13, -10]

  # If true, the script turns RF output on before arming the waveform.
  # The waveform/ARB trigger should define the burst envelope.
  rf_output_on_when_armed: true
  modulation_on_when_armed: true

  # Optional static SCPI commands to configure/select the already-loaded ARB waveform.
  # These are deliberately user-editable because MXG ARB/Signal Studio commands vary
  # by firmware, option set, and waveform application.
  configure_scpi:
    # Examples only; uncomment and edit after verifying on your MXG:
    # - "SOUR:RAD:ARB:STAT ON"
    # - "SOUR:RAD:ARB:WAV 'WIFI_AC_BURST'"
    # - "SOUR:RAD:ARB:TRIG:SOUR EXT"
    # - "SOUR:RAD:ARB:TRIG:TYPE SING"
    []

  # Commands issued immediately before each burst acquisition.
  arm_scpi:
    # Example placeholders; verify with your MXG manual/front-panel state:
    # - "SOUR:RAD:ARB:TRIG:ARM"
    []

  # Bus trigger command, used only in trigger_mode = "bus_debug".
  bus_trigger_scpi: "*TRG"

  # Optional commands after each burst. Useful if your ARB needs explicit stop/reset.
  after_burst_scpi: []

pmu:
  # PMU channel assignments.
  drain_channel: 1

  # Optional gate channel. Set enabled false if you use a DC SMU/gate supply outside this script.
  gate:
    enabled: false
    channel: 2
    vgs_v: -2.7
    current_range_a: 0.01
    voltage_range_v: 10
    current_limit_a: 0.01
    power_limit_w: 0.1

  # Drain bias. Keep limits conservative for first tests.
  vds_v: 12.0
  drain_current_range_a: 0.2
  drain_voltage_range_v: 40
  drain_source_range_v: 40
  drain_current_limit_a: 0.2
  drain_power_limit_w: 2.0

  # Use 4225-RPM path if available. The script calls rpm_config for configured channels.
  use_rpm: true

  # Measurement acquisition.
  sample_rate_sps: 1.0e6
  capture_time_s: 0.010

  # PMU pulse timing used to create a timing event while sourcing constant VDS.
  # The script sources vlow=vhigh=vds for drain so the drain is quasi-constant-biased.
  # The pulse timing still defines the measurement/acquisition window.
  pulse_delay_s: 100.0e-6
  pulse_width_s: 1.0e-3
  pulse_rise_s: 1.0e-6
  pulse_fall_s: 1.0e-6

  # Waveform measurement pre/post percentages relative to the pulse region.
  # Use these if your LPT version supports pulse_meas_timing with pre/post percentages.
  pre_pulse_percent: 20.0
  post_pulse_percent: 100.0

  # If true, enable timestamp acquisition through pulse_meas_wfm.
  enable_timestamps: true

  # If true, configure PMU trigger output for hardware triggering the MXG.
  enable_trigger_output: true
  trigger_polarity: "rising"   # rising or falling

  # If the script cannot decode timestamp data from pulse_fetch, it generates a uniform time axis.
  fallback_time_start_s: -0.001

triggering:
  # Preferred: "pmu_trig_out". The Keithley waveform timing/trigger output starts the MXG ARB burst.
  # Debug only: "bus_debug". Python starts PMU, waits bus_debug_trigger_delay_s, then sends *TRG to MXG.
  # Alternate lab setup: "external_marker_to_pmu". The MXG marker triggers the PMU; script arms MXG first.
  trigger_mode: "pmu_trig_out"

  # Only used in bus_debug mode. Not deterministic enough for production trapping data.
  bus_debug_trigger_delay_s: 0.001

  # If true, prompt user before each RF power condition.
  prompt_before_each_power: false

analysis:
  # Used only for post-processing. Set these to match your loaded burst waveform.
  # If the burst begins/ends at different times due to marker delays, update here.
  burst_start_s: 0.0
  burst_length_s: 1.0e-3

  # Pre-burst baseline window used for current-collapse normalization.
  baseline_window_s: [-0.0008, -0.0001]

  # Recovery-fit window relative to burst end. Set fit_recovery false for first debugging.
  fit_recovery: true
  recovery_fit_window_s: [5.0e-6, 8.0e-3]

safety:
  require_user_confirm: true
  max_abs_vds_v: 40.0
  max_abs_vgs_v: 10.0
  max_drain_current_range_a: 0.5
  turn_rf_off_on_error: true
  turn_pmu_outputs_off_on_error: true
""".strip() + "\n"


def write_example_config(path: Path) -> None:
    path.write_text(EXAMPLE_CONFIG, encoding="utf-8")


def load_yaml(path: Path) -> Dict[str, Any]:
    if yaml is None:
        raise RuntimeError("PyYAML is not installed. Run: pip install pyyaml")
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def cfg_get(d: Dict[str, Any], dotted: str, default: Any = None) -> Any:
    cur: Any = d
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def as_float_list(x: Any) -> List[float]:
    if x is None:
        return []
    if isinstance(x, (int, float)):
        return [float(x)]
    return [float(v) for v in x]


# =============================================================================
# Logging and utility helpers
# =============================================================================


def setup_logger(output_dir: Path) -> logging.Logger:
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("rf_burst_recovery")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s")

    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.INFO)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    fh = logging.FileHandler(output_dir / "measurement.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger


def now_tag() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def dbm_to_mw(dbm: float) -> float:
    return 10 ** (dbm / 10.0)


def mw_to_dbm(mw: float) -> float:
    return 10 * math.log10(mw) if mw > 0 else float("-inf")


def safe_makedirs(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def user_confirm(prompt: str) -> None:
    ans = input(prompt + " Type YES to continue: ").strip()
    if ans != "YES":
        raise RuntimeError("User did not confirm. Aborting.")


def write_json(path: Path, data: Any) -> None:
    def default(obj: Any) -> Any:
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.floating, np.integer)):
            return obj.item()
        if dataclasses.is_dataclass(obj):
            return dataclasses.asdict(obj)
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=default)


# =============================================================================
# MXG SCPI wrapper
# =============================================================================


class MXG:
    def __init__(self, visa_addr: str, timeout_ms: int = 20000, logger: Optional[logging.Logger] = None):
        if pyvisa is None:
            raise RuntimeError("pyvisa is not installed. Run: pip install pyvisa")
        self.logger = logger or logging.getLogger(__name__)
        self.rm = pyvisa.ResourceManager()
        self.inst = self.rm.open_resource(visa_addr)
        self.inst.timeout = int(timeout_ms)
        self.visa_addr = visa_addr

    def write(self, cmd: str) -> None:
        self.logger.debug("MXG << %s", cmd)
        self.inst.write(cmd)

    def query(self, cmd: str) -> str:
        self.logger.debug("MXG ?? %s", cmd)
        resp = self.inst.query(cmd)
        self.logger.debug("MXG >> %s", resp.strip())
        return resp

    def opc(self) -> None:
        try:
            self.query("*OPC?")
        except Exception as exc:
            self.logger.warning("MXG *OPC? failed: %s", exc)

    def idn(self) -> str:
        return self.query("*IDN?").strip()

    def err(self) -> str:
        try:
            return self.query("SYST:ERR?").strip()
        except Exception as exc:
            return f"Could not query SYST:ERR?: {exc}"

    def try_write(self, cmd: str) -> None:
        try:
            self.write(cmd)
            self.opc()
        except Exception as exc:
            self.logger.warning("MXG command failed: %s | %s", cmd, exc)

    def configure_reference(self, use_external: bool) -> None:
        if use_external:
            self.try_write("ROSC:SOUR EXT")
        else:
            # Do not force internal unless requested; some labs distribute 10 MHz externally.
            pass

    def configure_rf(self, freq_hz: float, power_dbm: float) -> None:
        self.write(f"FREQ {float(freq_hz):.12g}")
        self.write(f"POW {float(power_dbm):.6f} DBM")
        self.opc()

    def rf_output(self, state: bool) -> None:
        self.write(f"OUTP {'ON' if state else 'OFF'}")
        self.opc()

    def modulation_output(self, state: bool) -> None:
        self.write(f"OUTP:MOD {'ON' if state else 'OFF'}")
        self.opc()

    def run_scpi_list(self, commands: Sequence[str], label: str = "SCPI list") -> None:
        for cmd in commands or []:
            if not str(cmd).strip():
                continue
            self.logger.info("MXG %s: %s", label, cmd)
            self.write(str(cmd))
        self.opc()

    def bus_trigger(self, trigger_cmd: str = "*TRG") -> None:
        self.write(trigger_cmd)
        self.opc()

    def close(self) -> None:
        try:
            self.inst.close()
        except Exception:
            pass
        try:
            self.rm.close()
        except Exception:
            pass


# =============================================================================
# Keithley 4200A PMU LPT wrapper
# =============================================================================


class LPTCallError(RuntimeError):
    pass


class Keithley4200PMU:
    """
    Thin compatibility layer around pylptlib.lpt.

    The script deliberately keeps every LPT call in one place because installations
    often differ. If a call signature is wrong for your pylptlib version, edit the
    method here rather than changing the experiment logic.
    """

    def __init__(self, pmu_name: str = "PMU1", logger: Optional[logging.Logger] = None):
        if lpt is None:
            raise RuntimeError(
                "pylptlib is not installed/importable. Install SweepMe/pylptlib-4200SCS "
                "and run in a 32-bit Python environment compatible with lptlib.dll."
            )
        self.logger = logger or logging.getLogger(__name__)
        self.pmu_name = pmu_name
        self.pmu_id = None

    def initialize(self) -> None:
        self.logger.info("Initializing LPT library")
        self._call("initialize")
        self._call("devint")
        self.pmu_id = self._call("getinstid", self.pmu_name)
        self.logger.info("Using PMU %s with LPT id %s", self.pmu_name, self.pmu_id)

    def _call(self, func_name: str, *args: Any, required: bool = True) -> Any:
        if not hasattr(lpt, func_name):
            msg = f"pylptlib.lpt has no function {func_name}"
            if required:
                raise LPTCallError(msg)
            self.logger.warning(msg)
            return None
        func = getattr(lpt, func_name)
        self.logger.debug("LPT %s%s", func_name, args)
        try:
            return func(*args)
        except Exception as exc:
            msg = f"LPT call failed: {func_name}{args}: {exc}"
            if required:
                raise LPTCallError(msg) from exc
            self.logger.warning(msg)
            return None

    def _param(self, name: str, default: Any = None) -> Any:
        if param is not None and hasattr(param, name):
            return getattr(param, name)
        return default

    def configure_rpm_channel(self, channel: int) -> None:
        ki_rpm_pathway = self._param("KI_RPM_PATHWAY")
        ki_rpm_pulse = self._param("KI_RPM_PULSE")
        if ki_rpm_pathway is None or ki_rpm_pulse is None:
            self.logger.warning("RPM constants not found in pylptlib.param; skipping rpm_config")
            return
        self._call("rpm_config", self.pmu_id, int(channel), ki_rpm_pathway, ki_rpm_pulse, required=False)

    def configure_channel_ranges(
        self,
        channel: int,
        source_range_v: float,
        voltage_range_v: float,
        current_range_a: float,
    ) -> None:
        # Common LPT convention: range_type fixed = 2. If your installation defines a param, use it.
        fixed = self._param("KI_FIXED_RANGE", 2)
        self._call(
            "pulse_ranges",
            self.pmu_id,
            int(channel),
            float(source_range_v),
            fixed,
            float(voltage_range_v),
            fixed,
            float(current_range_a),
            required=True,
        )

    def configure_channel_limits(
        self,
        channel: int,
        voltage_limit_v: float,
        current_limit_a: float,
        power_limit_w: float,
    ) -> None:
        self._call(
            "pulse_limits",
            self.pmu_id,
            int(channel),
            float(voltage_limit_v),
            float(current_limit_a),
            float(power_limit_w),
            required=True,
        )

    def configure_waveform_measurement(
        self,
        channel: int,
        measure_voltage: bool = True,
        measure_current: bool = True,
        enable_timestamp: bool = True,
        llec_enable: bool = False,
    ) -> None:
        # AcquireType value may differ by version; 0/discrete is a common safe first choice.
        acquire_type = self._param("KI_PULSE_ACQUIRE_DISCRETE", 0)
        en = 1
        dis = 0
        self._call(
            "pulse_meas_wfm",
            self.pmu_id,
            int(channel),
            acquire_type,
            en if measure_voltage else dis,
            en if measure_current else dis,
            en if enable_timestamp else dis,
            en if llec_enable else dis,
            required=True,
        )

    def configure_sample_rate(self, sample_rate_sps: float) -> None:
        self._call("pulse_sample_rate", self.pmu_id, float(sample_rate_sps), required=True)

    def configure_source_timing(
        self,
        channel: int,
        period_s: float,
        delay_s: float,
        width_s: float,
        rise_s: float,
        fall_s: float,
    ) -> None:
        self._call(
            "pulse_source_timing",
            self.pmu_id,
            int(channel),
            float(period_s),
            float(delay_s),
            float(width_s),
            float(rise_s),
            float(fall_s),
            required=True,
        )

    def configure_meas_timing(self, channel: int, pre_percent: float, post_percent: float, points_per_measure: int = 1) -> None:
        # This signature is LPT-version dependent. Keep nonfatal, since waveform fetch may still work.
        self._call(
            "pulse_meas_timing",
            self.pmu_id,
            int(channel),
            float(pre_percent),
            float(post_percent),
            int(points_per_measure),
            required=False,
        )

    def set_vlow_vhigh(self, channel: int, vlow: float, vhigh: float) -> None:
        # Function names exist in many LPT wrappers. If absent, user can configure via segment ARB or KULT.
        self._call("pulse_vlow", self.pmu_id, int(channel), float(vlow), required=False)
        self._call("pulse_vhigh", self.pmu_id, int(channel), float(vhigh), required=False)

    def set_output(self, channel: int, state: bool) -> None:
        self._call("pulse_output", self.pmu_id, int(channel), 1 if state else 0, required=False)

    def configure_trigger_output(self, enable: bool, polarity: str = "rising") -> None:
        if polarity.lower().startswith("fall"):
            pol = self._param("KI_NEGATIVE", 0)
        else:
            pol = self._param("KI_POSITIVE", 1)
        self._call("pulse_trig_polarity", self.pmu_id, pol, required=False)
        self._call("pulse_trig_output", self.pmu_id, 1 if enable else 0, required=False)

    def configure_trigger_source_external(self) -> None:
        # Optional for MXG-marker-to-PMU mode. Constants/signature vary; leave as best-effort.
        ext_rising = self._param("KI_PULSE_TRIG_EXTERNAL_RISING", None)
        if ext_rising is not None:
            self._call("pulse_trig_source", self.pmu_id, ext_rising, required=False)
        else:
            self.logger.warning("No external trigger source constant found; configure external PMU trigger manually if needed.")

    def execute(self, pulse_mode: int = 0) -> None:
        result = self._call("pulse_exec", int(pulse_mode), required=True)
        if isinstance(result, (int, np.integer)) and int(result) not in (0,):
            self.logger.warning("pulse_exec returned nonzero status: %s", result)

    def wait_until_complete(self, poll_s: float = 0.005, timeout_s: float = 30.0) -> None:
        start = time.time()
        while True:
            status = self._call("pulse_exec_status", required=False)
            self.logger.debug("pulse_exec_status -> %r", status)
            running = False
            if status is None:
                # If unsupported, assume done after a small delay.
                time.sleep(0.1)
                return
            elif isinstance(status, tuple) and len(status) > 0:
                running = bool(status[0])
            else:
                try:
                    running = bool(int(status))
                except Exception:
                    running = False

            if not running:
                return
            if time.time() - start > timeout_s:
                raise TimeoutError("Timed out waiting for PMU pulse execution to finish")
            time.sleep(poll_s)

    def fetch(self, channel: int, start_index: int, stop_index: int) -> Any:
        # Try the most likely pylptlib signature first.
        try:
            return self._call("pulse_fetch", self.pmu_id, int(channel), int(start_index), int(stop_index), required=True)
        except LPTCallError as exc1:
            self.logger.warning("pulse_fetch signature 1 failed: %s", exc1)
            # Some versions may not need pmu_id.
            try:
                return self._call("pulse_fetch", int(channel), int(start_index), int(stop_index), required=True)
            except LPTCallError as exc2:
                self.logger.error("pulse_fetch fallback failed: %s", exc2)
                raise

    def clear(self) -> None:
        self._call("devint", required=False)

    def close(self) -> None:
        # Many LPT installations do not require explicit close. Leave best-effort.
        self._call("devabort", required=False)


# =============================================================================
# Fetch parsing and analysis
# =============================================================================


@dataclass
class WaveformData:
    time_s: np.ndarray
    voltage_v: Optional[np.ndarray]
    current_a: Optional[np.ndarray]
    status: Optional[np.ndarray]
    raw_summary: Dict[str, Any] = field(default_factory=dict)


def _is_numeric_arraylike(x: Any) -> bool:
    try:
        arr = np.asarray(x, dtype=float)
        return arr.size > 1 and arr.ndim <= 2
    except Exception:
        return False


def _flatten_numeric(x: Any) -> np.ndarray:
    return np.asarray(x, dtype=float).reshape(-1)


def summarize_raw(raw: Any) -> Dict[str, Any]:
    summary: Dict[str, Any] = {"type": str(type(raw))}
    if isinstance(raw, (tuple, list)):
        summary["length"] = len(raw)
        items = []
        for i, item in enumerate(raw):
            item_info = {"index": i, "type": str(type(item))}
            if _is_numeric_arraylike(item):
                arr = _flatten_numeric(item)
                item_info.update({
                    "size": int(arr.size),
                    "min": float(np.nanmin(arr)),
                    "max": float(np.nanmax(arr)),
                    "mean": float(np.nanmean(arr)),
                    "first5": arr[:5].tolist(),
                })
            else:
                item_info["repr"] = repr(item)[:500]
            items.append(item_info)
        summary["items"] = items
    elif isinstance(raw, dict):
        summary["keys"] = list(raw.keys())
    else:
        summary["repr"] = repr(raw)[:1000]
    return summary


def decode_pulse_fetch(
    raw: Any,
    n_expected: int,
    sample_rate_sps: float,
    fallback_time_start_s: float,
    expected_v_bias: Optional[float] = None,
) -> WaveformData:
    """
    Convert a pylptlib pulse_fetch return into time/voltage/current arrays.

    Because pylptlib omits pointer args and returns buffers differently depending
    on function implementation, this decoder uses conservative heuristics:
      - timestamp: monotonic increasing numeric array
      - voltage: array with median closest to expected_v_bias
      - current: remaining numeric waveform array with non-integer status-like values
      - status: integer-ish array if present
    Raw arrays are also saved separately by the caller.
    """
    raw_summary = summarize_raw(raw)

    arrays: List[Tuple[int, np.ndarray]] = []

    if isinstance(raw, dict):
        # Common friendly cases.
        keys = {str(k).lower(): k for k in raw.keys()}
        time_key = next((keys[k] for k in keys if "time" in k or "stamp" in k), None)
        v_key = next((keys[k] for k in keys if k in ("v", "volt", "voltage") or "volt" in k), None)
        i_key = next((keys[k] for k in keys if k in ("i", "curr", "current") or "curr" in k), None)
        s_key = next((keys[k] for k in keys if "status" in k), None)
        t = _flatten_numeric(raw[time_key]) if time_key is not None else None
        v = _flatten_numeric(raw[v_key]) if v_key is not None else None
        i = _flatten_numeric(raw[i_key]) if i_key is not None else None
        s = _flatten_numeric(raw[s_key]) if s_key is not None else None
        if t is None:
            size = len(i) if i is not None else len(v) if v is not None else n_expected
            t = fallback_time_start_s + np.arange(size) / float(sample_rate_sps)
        return WaveformData(t, v, i, s, raw_summary)

    if isinstance(raw, (tuple, list)):
        for idx, item in enumerate(raw):
            if _is_numeric_arraylike(item):
                arr = _flatten_numeric(item)
                # Keep arrays that look like waveforms.
                if arr.size >= max(10, min(n_expected // 10, 10)):
                    arrays.append((idx, arr))

    if not arrays and _is_numeric_arraylike(raw):
        arrays.append((0, _flatten_numeric(raw)))

    # Trim arrays to common length near expected.
    if arrays:
        # Use the median size of the longest arrays.
        sizes = sorted([arr.size for _, arr in arrays], reverse=True)
        target_size = sizes[0]
        arrays = [(idx, arr[:target_size]) for idx, arr in arrays if arr.size >= target_size]
    else:
        target_size = int(n_expected)

    time_arr: Optional[np.ndarray] = None
    voltage_arr: Optional[np.ndarray] = None
    current_arr: Optional[np.ndarray] = None
    status_arr: Optional[np.ndarray] = None

    remaining: List[Tuple[int, np.ndarray]] = []

    # Identify timestamp/status candidates.
    for idx, arr in arrays:
        finite = arr[np.isfinite(arr)]
        if finite.size < 2:
            continue
        diffs = np.diff(arr)
        monotonic = np.all(diffs >= -1e-15)
        span = float(np.nanmax(arr) - np.nanmin(arr))
        integerish = np.allclose(arr, np.round(arr), atol=1e-9)

        if monotonic and span > 0 and span < 10_000 and not integerish:
            # Timestamp likely seconds or similar.
            if time_arr is None:
                time_arr = arr
                continue
        if integerish and len(np.unique(arr[: min(arr.size, 1000)])) < 20:
            if status_arr is None:
                status_arr = arr
                continue
        remaining.append((idx, arr))

    # Identify voltage/current among remaining.
    if remaining:
        if expected_v_bias is not None:
            med_diffs = [(abs(float(np.nanmedian(arr)) - expected_v_bias), idx, arr) for idx, arr in remaining]
            med_diffs.sort(key=lambda x: x[0])
            voltage_arr = med_diffs[0][2]
            remaining = [(idx, arr) for idx, arr in remaining if idx != med_diffs[0][1]]
        else:
            # Voltage often has larger magnitude than current.
            mags = [(abs(float(np.nanmedian(arr))), idx, arr) for idx, arr in remaining]
            mags.sort(reverse=True, key=lambda x: x[0])
            voltage_arr = mags[0][2]
            remaining = [(idx, arr) for idx, arr in remaining if idx != mags[0][1]]

    if remaining:
        # Current often remaining analog waveform. Prefer smaller magnitude.
        mags = [(abs(float(np.nanmedian(arr))), idx, arr) for idx, arr in remaining]
        mags.sort(key=lambda x: x[0])
        current_arr = mags[0][2]

    # If only one analog array was returned, it might be current. Prefer current for this experiment.
    if current_arr is None and voltage_arr is not None and expected_v_bias is not None:
        med = abs(float(np.nanmedian(voltage_arr)) - expected_v_bias)
        if med > max(1.0, 0.2 * abs(expected_v_bias)):
            current_arr = voltage_arr
            voltage_arr = None

    if time_arr is None:
        size = 0
        for arr in [current_arr, voltage_arr, status_arr]:
            if arr is not None:
                size = arr.size
                break
        if size <= 0:
            size = int(n_expected)
        time_arr = fallback_time_start_s + np.arange(size) / float(sample_rate_sps)

    # Equalize lengths.
    size = time_arr.size
    for arr in [voltage_arr, current_arr, status_arr]:
        if arr is not None:
            size = min(size, arr.size)
    time_arr = time_arr[:size]
    if voltage_arr is not None:
        voltage_arr = voltage_arr[:size]
    if current_arr is not None:
        current_arr = current_arr[:size]
    if status_arr is not None:
        status_arr = status_arr[:size]

    return WaveformData(time_arr, voltage_arr, current_arr, status_arr, raw_summary)


@dataclass
class AnalysisResult:
    baseline_current_a: Optional[float]
    min_current_after_burst_a: Optional[float]
    immediate_collapse_percent: Optional[float]
    max_collapse_percent: Optional[float]
    recovery_tau1_s: Optional[float]
    recovery_tau2_s: Optional[float]
    fit_model: str
    fit_success: bool
    fit_message: str


def analyze_recovery(
    time_s: np.ndarray,
    current_a: Optional[np.ndarray],
    burst_start_s: float,
    burst_length_s: float,
    baseline_window_s: Sequence[float],
    fit_recovery: bool,
    recovery_fit_window_s: Sequence[float],
) -> AnalysisResult:
    if current_a is None or current_a.size == 0:
        return AnalysisResult(None, None, None, None, None, None, "none", False, "No current waveform decoded")

    t = np.asarray(time_s, dtype=float)
    i = np.asarray(current_a, dtype=float)
    burst_end_s = float(burst_start_s) + float(burst_length_s)

    bl0, bl1 = float(baseline_window_s[0]), float(baseline_window_s[1])
    baseline_mask = (t >= bl0) & (t <= bl1)
    if not np.any(baseline_mask):
        # Fallback: first 5% of record.
        n = max(1, int(0.05 * i.size))
        baseline_i = float(np.nanmean(i[:n]))
    else:
        baseline_i = float(np.nanmean(i[baseline_mask]))

    post_mask = t >= burst_end_s
    if not np.any(post_mask):
        return AnalysisResult(baseline_i, None, None, None, None, None, "none", False, "No post-burst data")

    post_i = i[post_mask]
    min_after = float(np.nanmin(post_i))
    immediate_i = float(post_i[0])
    immediate_collapse = 100.0 * (1.0 - immediate_i / baseline_i) if baseline_i != 0 else None
    max_collapse = 100.0 * (1.0 - min_after / baseline_i) if baseline_i != 0 else None

    if not fit_recovery:
        return AnalysisResult(baseline_i, min_after, immediate_collapse, max_collapse, None, None, "none", False, "Fit disabled")

    try:
        from scipy.optimize import curve_fit
    except Exception:
        return AnalysisResult(baseline_i, min_after, immediate_collapse, max_collapse, None, None, "none", False, "scipy not installed")

    fit0 = burst_end_s + float(recovery_fit_window_s[0])
    fit1 = burst_end_s + float(recovery_fit_window_s[1])
    fit_mask = (t >= fit0) & (t <= fit1) & np.isfinite(i)
    if np.count_nonzero(fit_mask) < 20:
        return AnalysisResult(baseline_i, min_after, immediate_collapse, max_collapse, None, None, "none", False, "Too few points for fit")

    tf = t[fit_mask] - burst_end_s
    yf = i[fit_mask]

    def double_exp(tt: np.ndarray, i_inf: float, a1: float, tau1: float, a2: float, tau2: float) -> np.ndarray:
        return i_inf - a1 * np.exp(-tt / tau1) - a2 * np.exp(-tt / tau2)

    i_inf0 = float(np.nanmedian(yf[-max(5, yf.size // 10):]))
    amp0 = float(i_inf0 - np.nanmin(yf))
    if not np.isfinite(amp0) or amp0 == 0:
        amp0 = float(abs(baseline_i) * 0.05 + 1e-6)

    # Bounds keep taus positive and within broad measurement window.
    tmin = max(float(np.nanmin(tf[tf > 0])) if np.any(tf > 0) else 1e-9, 1e-9)
    tmax = max(float(np.nanmax(tf)), tmin * 10)
    p0 = [i_inf0, 0.6 * amp0, max(tmin * 10, 10e-6), 0.4 * amp0, min(tmax / 2, 1e-3)]
    bounds = (
        [-np.inf, -np.inf, tmin, -np.inf, tmin],
        [np.inf, np.inf, tmax * 10, np.inf, tmax * 10],
    )

    try:
        popt, _ = curve_fit(double_exp, tf, yf, p0=p0, bounds=bounds, maxfev=20000)
        tau1, tau2 = sorted([float(popt[2]), float(popt[4])])
        return AnalysisResult(baseline_i, min_after, immediate_collapse, max_collapse, tau1, tau2, "double_exp", True, "OK")
    except Exception as exc:
        return AnalysisResult(baseline_i, min_after, immediate_collapse, max_collapse, None, None, "double_exp", False, str(exc))


def save_waveform_csv(path: Path, data: WaveformData, metadata: Dict[str, Any], analysis: AnalysisResult) -> None:
    fieldnames = ["time_s"]
    if data.voltage_v is not None:
        fieldnames.append("voltage_v")
    if data.current_a is not None:
        fieldnames.append("current_a")
    if data.status is not None:
        fieldnames.append("status")

    with path.open("w", newline="", encoding="utf-8") as f:
        f.write("# metadata_json=" + json.dumps(metadata, default=str) + "\n")
        f.write("# analysis_json=" + json.dumps(dataclasses.asdict(analysis), default=str) + "\n")
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        n = data.time_s.size
        for k in range(n):
            row = {"time_s": float(data.time_s[k])}
            if data.voltage_v is not None:
                row["voltage_v"] = float(data.voltage_v[k])
            if data.current_a is not None:
                row["current_a"] = float(data.current_a[k])
            if data.status is not None:
                row["status"] = float(data.status[k])
            writer.writerow(row)


def save_raw_npz(path: Path, raw: Any) -> None:
    arrays = {}
    if isinstance(raw, dict):
        for key, val in raw.items():
            if _is_numeric_arraylike(val):
                arrays[str(key)] = _flatten_numeric(val)
    elif isinstance(raw, (tuple, list)):
        for idx, val in enumerate(raw):
            if _is_numeric_arraylike(val):
                arrays[f"raw_{idx}"] = _flatten_numeric(val)
    elif _is_numeric_arraylike(raw):
        arrays["raw"] = _flatten_numeric(raw)
    if arrays:
        np.savez_compressed(path, **arrays)


# =============================================================================
# Experiment orchestration
# =============================================================================


def validate_safety(cfg: Dict[str, Any]) -> None:
    vds = float(cfg_get(cfg, "pmu.vds_v", 0.0))
    vgs = float(cfg_get(cfg, "pmu.gate.vgs_v", 0.0))
    id_range = float(cfg_get(cfg, "pmu.drain_current_range_a", 0.0))
    max_vds = float(cfg_get(cfg, "safety.max_abs_vds_v", 40.0))
    max_vgs = float(cfg_get(cfg, "safety.max_abs_vgs_v", 10.0))
    max_id = float(cfg_get(cfg, "safety.max_drain_current_range_a", 0.5))

    if abs(vds) > max_vds:
        raise ValueError(f"Configured VDS={vds} V exceeds safety.max_abs_vds_v={max_vds} V")
    if abs(vgs) > max_vgs:
        raise ValueError(f"Configured VGS={vgs} V exceeds safety.max_abs_vgs_v={max_vgs} V")
    if abs(id_range) > max_id:
        raise ValueError(f"Configured drain current range={id_range} A exceeds safety.max_drain_current_range_a={max_id} A")


def configure_pmu_from_config(pmu: Keithley4200PMU, cfg: Dict[str, Any], logger: logging.Logger) -> None:
    drain_ch = int(cfg_get(cfg, "pmu.drain_channel", 1))
    gate_enabled = bool(cfg_get(cfg, "pmu.gate.enabled", False))
    gate_ch = int(cfg_get(cfg, "pmu.gate.channel", 2))
    use_rpm = bool(cfg_get(cfg, "pmu.use_rpm", True))

    sample_rate = float(cfg_get(cfg, "pmu.sample_rate_sps", 1e6))
    capture_time = float(cfg_get(cfg, "pmu.capture_time_s", 0.01))
    vds = float(cfg_get(cfg, "pmu.vds_v", 12.0))

    period = capture_time
    delay = float(cfg_get(cfg, "pmu.pulse_delay_s", 100e-6))
    width = float(cfg_get(cfg, "pmu.pulse_width_s", 1e-3))
    rise = float(cfg_get(cfg, "pmu.pulse_rise_s", 1e-6))
    fall = float(cfg_get(cfg, "pmu.pulse_fall_s", 1e-6))
    pre_pct = float(cfg_get(cfg, "pmu.pre_pulse_percent", 20.0))
    post_pct = float(cfg_get(cfg, "pmu.post_pulse_percent", 100.0))
    timestamps = bool(cfg_get(cfg, "pmu.enable_timestamps", True))

    if use_rpm:
        pmu.configure_rpm_channel(drain_ch)
        if gate_enabled:
            pmu.configure_rpm_channel(gate_ch)

    pmu.configure_sample_rate(sample_rate)

    logger.info("Configuring drain PMU channel %d", drain_ch)
    pmu.configure_channel_ranges(
        channel=drain_ch,
        source_range_v=float(cfg_get(cfg, "pmu.drain_source_range_v", 40.0)),
        voltage_range_v=float(cfg_get(cfg, "pmu.drain_voltage_range_v", 40.0)),
        current_range_a=float(cfg_get(cfg, "pmu.drain_current_range_a", 0.2)),
    )
    pmu.configure_channel_limits(
        channel=drain_ch,
        voltage_limit_v=abs(vds) + 2.0,
        current_limit_a=float(cfg_get(cfg, "pmu.drain_current_limit_a", 0.2)),
        power_limit_w=float(cfg_get(cfg, "pmu.drain_power_limit_w", 2.0)),
    )
    pmu.configure_waveform_measurement(drain_ch, True, True, timestamps, llec_enable=False)
    pmu.configure_source_timing(drain_ch, period, delay, width, rise, fall)
    pmu.configure_meas_timing(drain_ch, pre_pct, post_pct, 1)
    pmu.set_vlow_vhigh(drain_ch, vds, vds)

    if gate_enabled:
        vgs = float(cfg_get(cfg, "pmu.gate.vgs_v", -2.7))
        logger.info("Configuring gate PMU channel %d", gate_ch)
        pmu.configure_channel_ranges(
            channel=gate_ch,
            source_range_v=float(cfg_get(cfg, "pmu.gate.voltage_range_v", 10.0)),
            voltage_range_v=float(cfg_get(cfg, "pmu.gate.voltage_range_v", 10.0)),
            current_range_a=float(cfg_get(cfg, "pmu.gate.current_range_a", 0.01)),
        )
        pmu.configure_channel_limits(
            channel=gate_ch,
            voltage_limit_v=abs(vgs) + 1.0,
            current_limit_a=float(cfg_get(cfg, "pmu.gate.current_limit_a", 0.01)),
            power_limit_w=float(cfg_get(cfg, "pmu.gate.power_limit_w", 0.1)),
        )
        pmu.configure_waveform_measurement(gate_ch, True, True, timestamps, llec_enable=False)
        pmu.configure_source_timing(gate_ch, period, delay, width, rise, fall)
        pmu.configure_meas_timing(gate_ch, pre_pct, post_pct, 1)
        pmu.set_vlow_vhigh(gate_ch, vgs, vgs)

    pmu.configure_trigger_output(
        enable=bool(cfg_get(cfg, "pmu.enable_trigger_output", True)),
        polarity=str(cfg_get(cfg, "pmu.trigger_polarity", "rising")),
    )


def arm_mxg_from_config(mxg: MXG, cfg: Dict[str, Any], rf_power_dbm: float, logger: logging.Logger) -> None:
    fc = float(cfg_get(cfg, "mxg.carrier_hz", 7.5e9))
    mxg.configure_rf(fc, rf_power_dbm)
    mxg.run_scpi_list(cfg_get(cfg, "mxg.configure_scpi", []), label="configure")
    mxg.modulation_output(bool(cfg_get(cfg, "mxg.modulation_on_when_armed", True)))
    mxg.rf_output(bool(cfg_get(cfg, "mxg.rf_output_on_when_armed", True)))
    mxg.run_scpi_list(cfg_get(cfg, "mxg.arm_scpi", []), label="arm")
    logger.info("MXG armed at %.6f GHz, %.2f dBm", fc / 1e9, rf_power_dbm)


def run_single_condition(
    cfg: Dict[str, Any],
    mxg: MXG,
    pmu: Keithley4200PMU,
    output_dir: Path,
    rf_power_dbm: float,
    repetition: int,
    logger: logging.Logger,
) -> Dict[str, Any]:
    trigger_mode = str(cfg_get(cfg, "triggering.trigger_mode", "pmu_trig_out"))
    drain_ch = int(cfg_get(cfg, "pmu.drain_channel", 1))
    gate_enabled = bool(cfg_get(cfg, "pmu.gate.enabled", False))
    gate_ch = int(cfg_get(cfg, "pmu.gate.channel", 2))
    sample_rate = float(cfg_get(cfg, "pmu.sample_rate_sps", 1e6))
    capture_time = float(cfg_get(cfg, "pmu.capture_time_s", 0.01))
    n_expected = max(10, int(round(sample_rate * capture_time)))
    fallback_t0 = float(cfg_get(cfg, "pmu.fallback_time_start_s", -0.001))
    vds = float(cfg_get(cfg, "pmu.vds_v", 12.0))

    tag = f"P{rf_power_dbm:+.1f}dBm_rep{repetition:03d}".replace("+", "p").replace("-", "m").replace(".", "p")
    logger.info("Starting condition %s, trigger_mode=%s", tag, trigger_mode)

    metadata = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "rf_power_dbm": rf_power_dbm,
        "repetition": repetition,
        "trigger_mode": trigger_mode,
        "carrier_hz": float(cfg_get(cfg, "mxg.carrier_hz", 7.5e9)),
        "sample_rate_sps": sample_rate,
        "capture_time_s": capture_time,
        "vds_v": vds,
        "vgs_v": cfg_get(cfg, "pmu.gate.vgs_v", None),
        "operator_note": cfg_get(cfg, "run.operator_note", ""),
    }

    # Arm MXG before PMU execution unless MXG marker triggers PMU externally.
    if trigger_mode in ("pmu_trig_out", "bus_debug"):
        arm_mxg_from_config(mxg, cfg, rf_power_dbm, logger)
    elif trigger_mode == "external_marker_to_pmu":
        arm_mxg_from_config(mxg, cfg, rf_power_dbm, logger)
        pmu.configure_trigger_source_external()
    else:
        raise ValueError(f"Unknown trigger_mode: {trigger_mode}")

    # Enable PMU outputs as late as possible.
    pmu.set_output(drain_ch, True)
    if gate_enabled:
        pmu.set_output(gate_ch, True)

    raw_drain = None
    raw_gate = None

    if trigger_mode == "bus_debug":
        # Debug only. Python/SCPI timing is not reliable for production 300 us burst data.
        pmu.execute(pulse_mode=0)
        time.sleep(float(cfg_get(cfg, "triggering.bus_debug_trigger_delay_s", 0.001)))
        mxg.bus_trigger(str(cfg_get(cfg, "mxg.bus_trigger_scpi", "*TRG")))
        pmu.wait_until_complete(timeout_s=max(30.0, capture_time * 5.0))
    elif trigger_mode == "pmu_trig_out":
        # Preferred: PMU starts acquisition/timing and trigger output starts MXG ARB.
        pmu.execute(pulse_mode=0)
        pmu.wait_until_complete(timeout_s=max(30.0, capture_time * 5.0))
    elif trigger_mode == "external_marker_to_pmu":
        # Alternate: MXG marker triggers PMU; bus trigger only starts the armed waveform if needed.
        # If your MXG begins on external trigger instead, leave bus_trigger_scpi empty and trigger externally.
        pmu.execute(pulse_mode=0)
        bus_cmd = str(cfg_get(cfg, "mxg.bus_trigger_scpi", "*TRG"))
        if bus_cmd.strip():
            mxg.bus_trigger(bus_cmd)
        pmu.wait_until_complete(timeout_s=max(30.0, capture_time * 5.0))

    # Fetch drain and optional gate.
    raw_drain = pmu.fetch(drain_ch, 0, n_expected - 1)
    drain_wfm = decode_pulse_fetch(raw_drain, n_expected, sample_rate, fallback_t0, expected_v_bias=vds)

    # Optional gate fetch. It may not be meaningful if the gate channel wasn't configured for waveform measurement.
    gate_wfm = None
    if gate_enabled:
        raw_gate = pmu.fetch(gate_ch, 0, n_expected - 1)
        gate_wfm = decode_pulse_fetch(
            raw_gate,
            n_expected,
            sample_rate,
            fallback_t0,
            expected_v_bias=float(cfg_get(cfg, "pmu.gate.vgs_v", -2.7)),
        )

    # Run after-burst SCPI, if any.
    mxg.run_scpi_list(cfg_get(cfg, "mxg.after_burst_scpi", []), label="after_burst")

    # Analyze drain current recovery.
    analysis = analyze_recovery(
        time_s=drain_wfm.time_s,
        current_a=drain_wfm.current_a,
        burst_start_s=float(cfg_get(cfg, "analysis.burst_start_s", 0.0)),
        burst_length_s=float(cfg_get(cfg, "analysis.burst_length_s", 1e-3)),
        baseline_window_s=cfg_get(cfg, "analysis.baseline_window_s", [-8e-4, -1e-4]),
        fit_recovery=bool(cfg_get(cfg, "analysis.fit_recovery", True)),
        recovery_fit_window_s=cfg_get(cfg, "analysis.recovery_fit_window_s", [5e-6, 8e-3]),
    )

    # Save outputs.
    drain_csv = output_dir / f"drain_recovery_{tag}.csv"
    drain_npz = output_dir / f"drain_raw_{tag}.npz"
    save_waveform_csv(drain_csv, drain_wfm, metadata, analysis)
    save_raw_npz(drain_npz, raw_drain)
    write_json(output_dir / f"drain_decode_summary_{tag}.json", drain_wfm.raw_summary)

    if gate_wfm is not None and raw_gate is not None:
        # Do not perform trapping analysis on gate current by default, but save it.
        dummy_analysis = AnalysisResult(None, None, None, None, None, None, "none", False, "gate waveform saved only")
        save_waveform_csv(output_dir / f"gate_waveform_{tag}.csv", gate_wfm, metadata, dummy_analysis)
        save_raw_npz(output_dir / f"gate_raw_{tag}.npz", raw_gate)
        write_json(output_dir / f"gate_decode_summary_{tag}.json", gate_wfm.raw_summary)

    summary = dict(metadata)
    summary.update(dataclasses.asdict(analysis))
    summary["drain_csv"] = str(drain_csv)
    summary["drain_npz"] = str(drain_npz)

    logger.info(
        "Done %s | baseline Id=%s A | max collapse=%s %% | tau1=%s s | tau2=%s s | fit=%s",
        tag,
        _fmt_opt(analysis.baseline_current_a),
        _fmt_opt(analysis.max_collapse_percent),
        _fmt_opt(analysis.recovery_tau1_s),
        _fmt_opt(analysis.recovery_tau2_s),
        analysis.fit_message,
    )
    return summary


def _fmt_opt(x: Optional[float]) -> str:
    if x is None:
        return "None"
    return f"{x:.6g}"


def append_summary_csv(path: Path, row: Dict[str, Any]) -> None:
    exists = path.exists()
    # Stable fieldnames: union with existing header if file exists.
    if exists:
        with path.open("r", newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            try:
                fieldnames = next(reader)
            except StopIteration:
                fieldnames = []
    else:
        fieldnames = []
    for k in row.keys():
        if k not in fieldnames:
            fieldnames.append(k)
    # If new columns were added, rewrite file.
    old_rows = []
    if exists:
        with path.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            old_rows = list(reader)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for old in old_rows:
            writer.writerow(old)
        writer.writerow(row)


def run_experiment(config_path: Path) -> None:
    cfg = load_yaml(config_path)
    validate_safety(cfg)

    base_output = Path(str(cfg_get(cfg, "run.output_dir", "rf_burst_recovery_results")))
    output_dir = base_output / now_tag()
    safe_makedirs(output_dir)
    logger = setup_logger(output_dir)

    # Save exact config copy for traceability.
    (output_dir / "config_used.yaml").write_text(config_path.read_text(encoding="utf-8"), encoding="utf-8")

    logger.info("Output directory: %s", output_dir)
    logger.info("Config file: %s", config_path)

    if bool(cfg_get(cfg, "safety.require_user_confirm", True)):
        print("\nSafety check before enabling RF/PMU outputs:")
        print(f"  VDS = {cfg_get(cfg, 'pmu.vds_v')} V")
        if bool(cfg_get(cfg, "pmu.gate.enabled", False)):
            print(f"  VGS = {cfg_get(cfg, 'pmu.gate.vgs_v')} V")
        print(f"  drain current range = {cfg_get(cfg, 'pmu.drain_current_range_a')} A")
        print(f"  RF powers = {cfg_get(cfg, 'mxg.power_sweep_dbm')} dBm")
        print("  Confirm probes, RF load/termination, bias tees, attenuators, and current limits.")
        user_confirm("Proceed with RF burst recovery measurement?")

    mxg = None
    pmu = None
    try:
        mxg = MXG(
            str(cfg_get(cfg, "instruments.mxg_visa")),
            timeout_ms=int(cfg_get(cfg, "instruments.visa_timeout_ms", 20000)),
            logger=logger,
        )
        logger.info("MXG IDN: %s", mxg.idn())
        mxg.configure_reference(bool(cfg_get(cfg, "instruments.use_external_10mhz_reference", False)))

        pmu = Keithley4200PMU(str(cfg_get(cfg, "instruments.pmu_name", "PMU1")), logger=logger)
        pmu.initialize()
        configure_pmu_from_config(pmu, cfg, logger)

        powers = as_float_list(cfg_get(cfg, "mxg.power_sweep_dbm", [-20]))
        repetitions = int(cfg_get(cfg, "run.repetitions", 1))
        settle_s = float(cfg_get(cfg, "run.settle_between_repetitions_s", 0.5))
        summary_csv = output_dir / "summary.csv"

        for pwr in powers:
            if bool(cfg_get(cfg, "triggering.prompt_before_each_power", False)):
                user_confirm(f"Ready for RF power {pwr:.2f} dBm?")
            for rep in range(1, repetitions + 1):
                row = run_single_condition(cfg, mxg, pmu, output_dir, pwr, rep, logger)
                append_summary_csv(summary_csv, row)
                time.sleep(settle_s)

        logger.info("Measurement complete. Summary: %s", summary_csv)

    except Exception as exc:
        logger.exception("Measurement failed: %s", exc if 'logger' in locals() else exc)
        raise
    finally:
        # Fail-safe outputs off.
        try:
            if mxg is not None and bool(cfg_get(cfg, "safety.turn_rf_off_on_error", True)):
                mxg.rf_output(False)
        except Exception:
            pass
        try:
            if pmu is not None and bool(cfg_get(cfg, "safety.turn_pmu_outputs_off_on_error", True)):
                drain_ch = int(cfg_get(cfg, "pmu.drain_channel", 1))
                pmu.set_output(drain_ch, False)
                if bool(cfg_get(cfg, "pmu.gate.enabled", False)):
                    pmu.set_output(int(cfg_get(cfg, "pmu.gate.channel", 2)), False)
        except Exception:
            pass
        try:
            if mxg is not None:
                mxg.close()
        except Exception:
            pass
        try:
            if pmu is not None:
                pmu.close()
        except Exception:
            pass


# =============================================================================
# Debug commands
# =============================================================================


def inspect_lpt() -> None:
    if lpt is None:
        print("pylptlib.lpt is not importable.")
        return
    names = sorted(name for name in dir(lpt) if not name.startswith("_"))
    interesting = [
        n for n in names
        if n.startswith("pulse") or n.startswith("rpm") or n in ("initialize", "devint", "getinstid", "devabort")
    ]
    print("Available pylptlib.lpt functions relevant to PMU:")
    for n in interesting:
        print("  ", n)
    if param is not None:
        pnames = sorted(name for name in dir(param) if name.startswith("KI_"))
        print("\nAvailable pylptlib.param constants, filtered:")
        for n in pnames:
            if any(tok in n for tok in ["RPM", "PULSE", "FIX", "RANGE", "TRIG", "POS", "NEG"]):
                print("  ", n, "=", getattr(param, n))


def test_mxg(config_path: Path) -> None:
    cfg = load_yaml(config_path)
    output_dir = Path(str(cfg_get(cfg, "run.output_dir", "rf_burst_recovery_results"))) / ("mxg_test_" + now_tag())
    logger = setup_logger(output_dir)
    mxg = MXG(str(cfg_get(cfg, "instruments.mxg_visa")), int(cfg_get(cfg, "instruments.visa_timeout_ms", 20000)), logger)
    try:
        logger.info("MXG IDN: %s", mxg.idn())
        pwr = as_float_list(cfg_get(cfg, "mxg.power_sweep_dbm", [-20]))[0]
        arm_mxg_from_config(mxg, cfg, pwr, logger)
        logger.info("MXG error after arm: %s", mxg.err())
        bus_cmd = str(cfg_get(cfg, "mxg.bus_trigger_scpi", "*TRG"))
        if bus_cmd.strip():
            logger.info("Sending bus trigger for debug: %s", bus_cmd)
            mxg.bus_trigger(bus_cmd)
            logger.info("MXG error after trigger: %s", mxg.err())
    finally:
        mxg.rf_output(False)
        mxg.close()


def plot_summary(summary_csv: Path) -> None:
    try:
        import pandas as pd
        import matplotlib.pyplot as plt
    except Exception as exc:
        raise RuntimeError("Install pandas and matplotlib to plot: pip install pandas matplotlib") from exc

    df = pd.read_csv(summary_csv)
    if "max_collapse_percent" not in df.columns:
        raise ValueError("summary.csv has no max_collapse_percent column")
    plt.figure()
    plt.plot(df["rf_power_dbm"], df["max_collapse_percent"], marker="o", linestyle="")
    plt.xlabel("MXG RF power setpoint (dBm)")
    plt.ylabel("Maximum current collapse (%)")
    plt.title("RF-burst induced current collapse")
    plt.grid(True)
    out = summary_csv.with_suffix(".collapse_plot.png")
    plt.savefig(out, dpi=180, bbox_inches="tight")
    print(f"Saved {out}")


# =============================================================================
# CLI
# =============================================================================


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="RF burst drain-current recovery measurement with Keysight MXG and Keithley 4200A PMU")
    parser.add_argument("command", nargs="?", default="run", choices=["run", "inspect-lpt", "test-mxg", "plot-summary"], help="Command to run")
    parser.add_argument("--config", type=Path, default=Path("rf_burst_recovery_config.yaml"), help="YAML config file")
    parser.add_argument("--write-example-config", type=Path, help="Write an example YAML config and exit")
    parser.add_argument("--summary-csv", type=Path, help="summary.csv path for plot-summary")

    args = parser.parse_args(argv)

    if args.write_example_config:
        write_example_config(args.write_example_config)
        print(f"Wrote example config to {args.write_example_config}")
        return 0

    if args.command == "inspect-lpt":
        inspect_lpt()
        return 0
    if args.command == "test-mxg":
        test_mxg(args.config)
        return 0
    if args.command == "plot-summary":
        if args.summary_csv is None:
            raise SystemExit("--summary-csv is required for plot-summary")
        plot_summary(args.summary_csv)
        return 0

    run_experiment(args.config)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
