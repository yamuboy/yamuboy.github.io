"""
PERM Disclosure Data: Harmonization Script
============================================
Combines PERM files from FY2008–FY2025 into a single panel.

Three schema generations exist:
  - Early (FY2008–FY2013): ~25 columns, some use spaces instead of underscores
  - Mid (FY2014–FY2019): ~120 columns, richer employer/job/worker info
  - Late (FY2020–FY2025): similar to mid, possible minor renames

This script extracts a common set of analysis-relevant columns from all
files and outputs a single CSV panel.

USAGE:
  1. Place all PERM .xlsx files in INPUT_DIR (default: /mnt/user-data/uploads/)
  2. Run: python3 harmonize_perm.py
  3. Output: perm_panel.csv in OUTPUT_DIR
"""

import pandas as pd
import numpy as np
import os
import re
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# CONFIGURATION
# ============================================================
INPUT_DIR = "C:/Users/nisha/OneDrive/Desktop/Causal Inference Course and Project/HB Project"
OUTPUT_DIR = "C:/Users/nisha/OneDrive/Desktop/Causal Inference Course and Project/HB Project/perm_panel_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Target columns for the harmonized panel
TARGET_COLS = [
    'fiscal_year',
    'case_number',
    'case_status',
    'decision_date',
    'employer_name',
    'employer_city',
    'employer_state',
    'employer_postal_code',
    'employer_num_employees',   # only available mid/late format
    'naics_code',
    'naics_title',
    'soc_code',
    'job_title',
    'pw_level',
    'pw_amount',
    'pw_unit_of_pay',
    'wage_offer_from',
    'wage_offer_to',
    'wage_offer_unit_of_pay',
    'work_city',
    'work_state',
    'country_of_citizenship',
    'class_of_admission',
    'fw_education',             # only available mid/late format
]

# ============================================================
# FILE DISCOVERY
# ============================================================

def extract_fiscal_year(filename):
    """Extract fiscal year from PERM filename."""
    # Match patterns like FY2024, FY2008, FY16, FY15, etc.
    m = re.search(r'FY(\d{4})', filename)
    if m:
        return int(m.group(1))
    m = re.search(r'FY(\d{2})', filename)
    if m:
        yr = int(m.group(1))
        return 2000 + yr if yr < 50 else 1900 + yr
    return None


def find_perm_files(input_dir):
    """Find all PERM xlsx files and extract fiscal years."""
    files = []
    for f in sorted(os.listdir(input_dir)):
        if f.startswith('PERM') and f.endswith('.xlsx'):
            fy = extract_fiscal_year(f)
            if fy:
                files.append((fy, os.path.join(input_dir, f)))
    return files


# ============================================================
# COLUMN MAPPING
# ============================================================

def standardize_column_name(col):
    """Normalize column names: uppercase, underscores, strip whitespace."""
    return col.strip().upper().replace(' ', '_')


def map_columns(df, fiscal_year):
    """
    Map source columns to target columns based on schema generation.
    Returns a new DataFrame with standardized column names.
    """
    # Standardize all column names first
    df.columns = [standardize_column_name(c) for c in df.columns]

    # Build mapping from standardized source names to target names
    col_map = {}

    # --- Universal columns (all generations) ---
    # Each list tries source names in priority order; first match wins.

    for src in ['CASE_NUMBER']:
        if src in df.columns:
            col_map[src] = 'case_number'

    for src in ['CASE_STATUS']:
        if src in df.columns:
            col_map[src] = 'case_status'

    for src in ['DECISION_DATE']:
        if src in df.columns:
            col_map[src] = 'decision_date'

    # Employer name: EMP_BUSINESS_NAME (new form) or EMPLOYER_NAME (old)
    for src in ['EMPLOYER_NAME', 'EMP_BUSINESS_NAME']:
        if src in df.columns and 'employer_name' not in col_map.values():
            col_map[src] = 'employer_name'

    for src in ['EMPLOYER_CITY', 'EMP_CITY']:
        if src in df.columns and 'employer_city' not in col_map.values():
            col_map[src] = 'employer_city'

    for src in ['EMPLOYER_STATE', 'EMP_STATE']:
        if src in df.columns and 'employer_state' not in col_map.values():
            col_map[src] = 'employer_state'

    for src in ['EMPLOYER_POSTAL_CODE', 'EMP_POSTCODE']:
        if src in df.columns and 'employer_postal_code' not in col_map.values():
            col_map[src] = 'employer_postal_code'

    # --- NAICS (different column names across generations) ---
    for src in ['NAICS_US_CODE', '2007_NAICS_US_CODE', 'EMP_NAICS']:
        if src in df.columns and 'naics_code' not in col_map.values():
            col_map[src] = 'naics_code'

    for src in ['NAICS_US_TITLE', '2007_NAICS_US_TITLE']:
        if src in df.columns and 'naics_title' not in col_map.values():
            col_map[src] = 'naics_title'

    # --- SOC code ---
    for src in ['PW_SOC_CODE', 'PWD_SOC_CODE']:
        if src in df.columns and 'soc_code' not in col_map.values():
            col_map[src] = 'soc_code'

    # --- Job title (different names across generations) ---
    for src in ['JOB_INFO_JOB_TITLE', 'PW_JOB_TITLE_9089', 'JOB_TITLE']:
        if src in df.columns and 'job_title' not in col_map.values():
            col_map[src] = 'job_title'

    # --- Prevailing wage ---
    for src in ['PW_LEVEL_9089']:
        if src in df.columns:
            col_map[src] = 'pw_level'

    for src in ['PW_AMOUNT_9089']:
        if src in df.columns:
            col_map[src] = 'pw_amount'

    for src in ['PW_UNIT_OF_PAY_9089']:
        if src in df.columns:
            col_map[src] = 'pw_unit_of_pay'

    # --- Offered wage (old form vs new form) ---
    for src in ['WAGE_OFFER_FROM_9089', 'JOB_OPP_WAGE_FROM']:
        if src in df.columns and 'wage_offer_from' not in col_map.values():
            col_map[src] = 'wage_offer_from'

    for src in ['WAGE_OFFER_TO_9089', 'JOB_OPP_WAGE_TO']:
        if src in df.columns and 'wage_offer_to' not in col_map.values():
            col_map[src] = 'wage_offer_to'

    for src in ['WAGE_OFFER_UNIT_OF_PAY_9089', 'JOB_OPP_WAGE_PER']:
        if src in df.columns and 'wage_offer_unit_of_pay' not in col_map.values():
            col_map[src] = 'wage_offer_unit_of_pay'

    # --- Work location ---
    for src in ['JOB_INFO_WORK_CITY', 'PRIMARY_WORKSITE_CITY']:
        if src in df.columns and 'work_city' not in col_map.values():
            col_map[src] = 'work_city'

    for src in ['JOB_INFO_WORK_STATE', 'PRIMARY_WORKSITE_STATE']:
        if src in df.columns and 'work_state' not in col_map.values():
            col_map[src] = 'work_state'

    # --- Foreign worker info ---
    for src in ['COUNTRY_OF_CITIZENSHIP', 'COUNTRY_OF_CITZENSHIP']:
        if src in df.columns and 'country_of_citizenship' not in col_map.values():
            col_map[src] = 'country_of_citizenship'

    # CLASS_OF_ADMISSION: not available in new form (FY2024+)
    for src in ['CLASS_OF_ADMISSION']:
        if src in df.columns:
            col_map[src] = 'class_of_admission'

    # --- Mid/late format only ---
    for src in ['EMPLOYER_NUM_EMPLOYEES', 'EMP_NUM_PAYROLL']:
        if src in df.columns and 'employer_num_employees' not in col_map.values():
            col_map[src] = 'employer_num_employees'

    for src in ['FOREIGN_WORKER_INFO_EDUCATION', 'FW_INFO_EDUCATION']:
        if src in df.columns and 'fw_education' not in col_map.values():
            col_map[src] = 'fw_education'

    # Apply mapping
    result = pd.DataFrame()
    for src_col, tgt_col in col_map.items():
        result[tgt_col] = df[src_col]

    # Add fiscal year
    result['fiscal_year'] = fiscal_year

    # Fill missing target columns with NaN
    for tc in TARGET_COLS:
        if tc not in result.columns:
            result[tc] = np.nan

    return result[TARGET_COLS]


# ============================================================
# STANDARDIZE VALUES
# ============================================================

def standardize_values(df):
    """Clean and standardize values across generations."""

    # --- Case status: uppercase and normalize ---
    if 'case_status' in df.columns:
        df['case_status'] = (df['case_status'].astype(str).str.strip()
                             .str.upper().str.replace('-', '_'))
        # Normalize variants
        status_map = {
            'CERTIFIED': 'CERTIFIED',
            'CERTIFIED_EXPIRED': 'CERTIFIED_EXPIRED',
            'DENIED': 'DENIED',
            'WITHDRAWN': 'WITHDRAWN',
        }
        df['case_status'] = df['case_status'].map(
            lambda x: status_map.get(x, x)
        )

    # --- Employer name: uppercase, strip ---
    if 'employer_name' in df.columns:
        df['employer_name'] = df['employer_name'].astype(str).str.strip().str.upper()

    # --- Class of admission: uppercase, strip ---
    if 'class_of_admission' in df.columns:
        df['class_of_admission'] = (df['class_of_admission'].astype(str)
                                     .str.strip().str.upper())

    # --- Decision date: coerce to datetime ---
    if 'decision_date' in df.columns:
        df['decision_date'] = pd.to_datetime(df['decision_date'], errors='coerce')

    # --- Wage: coerce to numeric ---
    for wc in ['pw_amount', 'wage_offer_from', 'wage_offer_to']:
        if wc in df.columns:
            df[wc] = pd.to_numeric(df[wc], errors='coerce')

    # --- Wage unit: uppercase ---
    for uc in ['pw_unit_of_pay', 'wage_offer_unit_of_pay']:
        if uc in df.columns:
            df[uc] = df[uc].astype(str).str.strip().str.upper()
            # Normalize: YR/YEAR -> YEAR, HR/HOUR -> HOUR
            df[uc] = df[uc].replace({
                'YR': 'YEAR', 'HR': 'HOUR',
                'WK': 'WEEK', 'MTH': 'MONTH', 'MO': 'MONTH',
                'BI': 'BIWEEKLY',
            })

    # --- NAICS: string, strip ---
    if 'naics_code' in df.columns:
        df['naics_code'] = df['naics_code'].astype(str).str.strip().str.replace('.0', '', regex=False)

    # --- SOC code: strip ---
    if 'soc_code' in df.columns:
        df['soc_code'] = df['soc_code'].astype(str).str.strip()

    # --- State codes: uppercase ---
    for sc in ['employer_state', 'work_state']:
        if sc in df.columns:
            df[sc] = df[sc].astype(str).str.strip().str.upper()

    # --- H-1B flag for convenience ---
    df['from_h1b'] = df['class_of_admission'].str.contains(
        'H-1B|H1B', na=False, case=False
    ).astype(int)

    # --- Annualize wage offer ---
    df['wage_offer_annual'] = np.nan
    mask_yr = df['wage_offer_unit_of_pay'] == 'YEAR'
    mask_hr = df['wage_offer_unit_of_pay'] == 'HOUR'
    mask_wk = df['wage_offer_unit_of_pay'] == 'WEEK'
    mask_mo = df['wage_offer_unit_of_pay'] == 'MONTH'
    mask_bw = df['wage_offer_unit_of_pay'] == 'BIWEEKLY'

    df.loc[mask_yr, 'wage_offer_annual'] = df.loc[mask_yr, 'wage_offer_from']
    df.loc[mask_hr, 'wage_offer_annual'] = df.loc[mask_hr, 'wage_offer_from'] * 2080
    df.loc[mask_wk, 'wage_offer_annual'] = df.loc[mask_wk, 'wage_offer_from'] * 52
    df.loc[mask_mo, 'wage_offer_annual'] = df.loc[mask_mo, 'wage_offer_from'] * 12
    df.loc[mask_bw, 'wage_offer_annual'] = df.loc[mask_bw, 'wage_offer_from'] * 26

    return df


# ============================================================
# MAIN
# ============================================================

def main():
    perm_files = find_perm_files(INPUT_DIR)

    if not perm_files:
        print("No PERM files found in", INPUT_DIR)
        return

    print(f"Found {len(perm_files)} PERM files:")
    for fy, fp in perm_files:
        print(f"  FY{fy}: {os.path.basename(fp)}")

    all_frames = []
    for fy, fp in perm_files:
        print(f"\nProcessing FY{fy}...", end=" ")
        try:
            df = pd.read_excel(fp)
            print(f"{len(df):,} rows, {len(df.columns)} cols", end=" -> ")
            mapped = map_columns(df, fy)
            print(f"mapped to {len(mapped.columns)} target cols")
            all_frames.append(mapped)
        except Exception as e:
            print(f"ERROR: {e}")
            # Try with openpyxl engine explicitly
            try:
                df = pd.read_excel(fp, engine='openpyxl')
                print(f"  Retry with openpyxl: {len(df):,} rows")
                mapped = map_columns(df, fy)
                all_frames.append(mapped)
            except Exception as e2:
                print(f"  Retry also failed: {e2}")
                print(f"  *** SKIPPING FY{fy} — re-upload this file ***")

    if not all_frames:
        print("\nNo files could be processed.")
        return

    # Concatenate
    panel = pd.concat(all_frames, ignore_index=True)
    print(f"\n{'='*60}")
    print(f"Combined panel: {len(panel):,} rows x {len(panel.columns)} cols")

    # Standardize values
    panel = standardize_values(panel)

    # Summary
    print(f"\n{'='*60}")
    print("PANEL SUMMARY")
    print(f"{'='*60}")
    print(f"\nFiscal years: {sorted(panel['fiscal_year'].unique())}")
    print(f"\nRows by fiscal year:")
    print(panel['fiscal_year'].value_counts().sort_index().to_string())
    print(f"\nCase status distribution:")
    print(panel['case_status'].value_counts().to_string())
    print(f"\nClass of admission (top 10):")
    print(panel['class_of_admission'].value_counts().head(10).to_string())
    print(f"\nH-1B pipeline cases: {panel['from_h1b'].sum():,} "
          f"({100*panel['from_h1b'].mean():.1f}%)")
    print(f"\nMedian annual wage offer: ${panel['wage_offer_annual'].median():,.0f}")
    print(f"\nMissing values:")
    for c in TARGET_COLS:
        pct = 100 * panel[c].isna().mean()
        if pct > 0:
            print(f"  {c}: {pct:.1f}%")

    # Save
    out_path = os.path.join(OUTPUT_DIR, "perm_panel.csv")
    panel.to_csv(out_path, index=False)
    print(f"\nSaved to: {out_path}")
    print(f"File size: {os.path.getsize(out_path)/1024/1024:.1f} MB")

    return panel


if __name__ == "__main__":
    panel = main()

