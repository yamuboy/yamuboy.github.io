import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt

# 1. SETUP & DATA LOADING
# ---------------------------------------------------------
print("Loading Data...")
df = pd.read_csv('Final_Panel_Dataset_2013_2023.csv')

# Load US Shapefile (Census Bureau 20m resolution)
print("Downloading US Map Geometry...")
usa = gpd.read_file("https://www2.census.gov/geo/tiger/GENZ2018/shp/cb_2018_us_state_20m.zip")

# Filter to Continental US for better visibility (Exclude AK/HI/PR for zoom)
# If you want AK/HI included, comment out this line
usa = usa[~usa['STUSPS'].isin(['AK', 'HI', 'PR'])]

# 2. DEFINING THE MAPPING FUNCTION
# ---------------------------------------------------------
def create_map_grid(variable, title, cmap, filename, label_text):
    print(f"Generating {filename}...")
    
    # Determine scale min/max automatically based on data range
    # This ensures 2013 colors are comparable to 2023 colors
    vmin = df[variable].min()
    vmax = df[variable].max()
    
    # Create 3x4 Grid (12 spots for 11 years)
    fig, axes = plt.subplots(3, 4, figsize=(20, 12))
    axes = axes.flatten()
    
    years = sorted(df['Year'].unique())
    
    for i, ax in enumerate(axes):
        if i < len(years):
            year = years[i]
            
            # Filter Data for specific year
            data_year = df[df['Year'] == year]
            
            # Merge with Geography
            # Left join ensures all US states appear (as grey background)
            map_data = usa.merge(data_year, left_on='STUSPS', right_on='State_Abbr', how='left')
            
            # 1. Plot Base Layer (Grey for non-selected states)
            usa.plot(ax=ax, color='#f0f0f0', edgecolor='#d0d0d0')
            
            # 2. Plot Data Layer (Colored for your 12 states)
            valid_data = map_data.dropna(subset=[variable])
            
            if not valid_data.empty:
                valid_data.plot(column=variable, ax=ax, cmap=cmap, 
                                vmin=vmin, vmax=vmax, 
                                edgecolor='black', linewidth=0.5)
            
            ax.set_title(str(year), fontweight='bold', fontsize=12)
            ax.axis('off')
        else:
            # Turn off unused subplots
            ax.axis('off')
            
    # Add Colorbar
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(vmin=vmin, vmax=vmax))
    sm._A = []
    cbar = fig.colorbar(sm, ax=axes, orientation='horizontal', fraction=0.02, pad=0.05)
    cbar.set_label(label_text, fontsize=14, fontweight='bold')
    
    plt.suptitle(title, fontsize=24, y=0.95)
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close() # Close plot to free memory
    print(f"Saved {filename}")

# 3. GENERATE THE MAPS
# ---------------------------------------------------------

# Map 1: Net Migration Rate
# Comparison: Red (Inflow) vs Blue (Outflow)
create_map_grid(
    variable='Net_Migration_Rate',
    title='Evolution of Migration Patterns (2013-2023)',
    cmap='RdBu',  # Diverging Scale
    filename='Map_Migration_Trends.png',
    label_text='Net Migration Rate (per 1k)'
)

# Map 2: Median Rent
# Comparison: Light Yellow (Cheap) to Dark Red (Expensive)
create_map_grid(
    variable='Median_Rent',
    title='The Rise of Rental Costs (2013-2023)',
    cmap='YlOrRd', # Sequential Scale
    filename='Map_Median_Rent.png',
    label_text='Median 2-Bedroom Rent ($)'
)

# Map 3: Cost of Living Index (RPP)
# Comparison: Purple/Blue (Low Cost) to Yellow/Green (High Cost)
# 'viridis' is great for this as it is colorblind friendly and shows intensity well
create_map_grid(
    variable='Cost_of_Living_Index',
    title='Cost of Living Index (USA = 100)',
    cmap='viridis',
    filename='Map_COLI.png',
    label_text='Regional Price Parity (Index)'
)

print("\nDone! Check your folder for the 3 PNG files.")