import pandas as pd
import os


files = {
    'migration': 'final_migration_dependent_vars.csv',
    'census':    'final_census_panel.csv',
    'bls':       'final_bls_panel_fixed.csv',
    'qcew':      'final_qcew_panel_complete.csv',
    'hud':       'final_hud_rent_panel.csv',
    'hpi':       'hpi_at_state.xlsx',     
    'rpp':       'RPP_byState_BEA.xlsx'   
}

# The specific 12 states being analyzed
target_states = ['FL', 'TX', 'CA', 'AZ', 'MI', 'MA', 'OH', 'PA', 'GA', 'NC', 'NY', 'VA']

target_years = list(range(2013, 2024)) # 2013 to 2023

# Mapping: Full Name -> Abbreviation (Needed for Census/BLS/QCEW/RPP)
name_to_abbr = {
    'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
    'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
    'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
    'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
    'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS',
    'Missouri': 'MO', 'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH',
    'New Jersey': 'NJ', 'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC',
    'North Dakota': 'ND', 'Ohio': 'OH', 'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA',
    'Rhode Island': 'RI', 'South Carolina': 'SC', 'South Dakota': 'SD', 'Tennessee': 'TN',
    'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT', 'Virginia': 'VA', 'Washington': 'WA',
    'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY', 'District of Columbia': 'DC'
}

print("Loading datasets...")

# --- A. Migration (The Base) ---
df_mig = pd.read_csv(files['migration'])
df_mig.rename(columns={'state_abbr': 'State_Abbr'}, inplace=True)
# Keep only necessary columns
cols_mig = ['State_Abbr', 'Year', 'Net_Migration_Rate', 'In_Migration_Rate', 'Out_Migration_Rate']
df_mig = df_mig[cols_mig]

# --- B. Census ---
df_cen = pd.read_csv(files['census'])
# Map Full Name to Abbr
df_cen['State_Abbr'] = df_cen['St Name'].map(name_to_abbr)
df_cen.drop(columns=['St Name'], inplace=True)

# --- C. BLS ---
df_bls = pd.read_csv(files['bls'])
df_bls['State_Abbr'] = df_bls['St Name'].map(name_to_abbr)
df_bls.drop(columns=['St Name'], inplace=True)

# --- D. QCEW ---
df_qcew = pd.read_csv(files['qcew'])
df_qcew['State_Abbr'] = df_qcew['St Name'].map(name_to_abbr)
df_qcew.drop(columns=['St Name'], inplace=True)

# --- E. HUD Rent ---
df_hud = pd.read_csv(files['hud'])
# Rename standard columns for clarity
df_hud.rename(columns={'Median_Rent_2BR': 'Median_Rent'}, inplace=True)


# --- F. HPI (House Price Index) ---
print("Processing HPI...")

# 1. Read without a header first to scan the top rows
df_hpi_raw = pd.read_excel(files['hpi'], header=None, engine='openpyxl')

# 2. Find the row that contains the actual headers
# We look for the column "HPI with 2000 base" or "Abbreviation"
header_row_idx = None
for i in range(20): # Scan the top 20 rows
    row_values = df_hpi_raw.iloc[i].astype(str).values
    if 'HPI with 2000 base' in row_values or 'Abbreviation' in row_values:
        header_row_idx = i
        break

if header_row_idx is not None:
    # 3. Reload the file using the correct header row
    df_hpi = pd.read_excel(files['hpi'], header=header_row_idx, engine='openpyxl')
    
    # Clean column names (strip spaces)
    df_hpi.columns = df_hpi.columns.str.strip()
    
    # 4. Select and Rename
    # Check if columns actually exist now
    if 'Abbreviation' in df_hpi.columns and 'HPI with 2000 base' in df_hpi.columns:
        df_hpi = df_hpi[['Abbreviation', 'Year', 'HPI with 2000 base']].copy()
        df_hpi.rename(columns={'Abbreviation': 'State_Abbr', 'HPI with 2000 base': 'HPI_Index'}, inplace=True)
        print(f"   -> Found HPI headers on Row {header_row_idx+1}")
    else:
        print(f"❌ Error: Found header row {header_row_idx}, but columns were missing. Found: {df_hpi.columns}")
        # Create empty placeholder to prevent crash
        df_hpi = pd.DataFrame(columns=['State_Abbr', 'Year', 'HPI_Index'])
else:
    print("❌ Error: Could not find 'HPI with 2000 base' header in top 20 rows.")
    df_hpi = pd.DataFrame(columns=['State_Abbr', 'Year', 'HPI_Index'])

# --- G. RPP (Cost of Living) ---
print("Processing RPP...")

# 1. Read raw to find the header
df_rpp_raw = pd.read_excel(files['rpp'], header=None, engine='openpyxl')

# 2. Hunt for "GeoName"
header_row_idx = None
for i in range(20):
    row_vals = df_rpp_raw.iloc[i].astype(str).values
    if 'GeoName' in row_vals:
        header_row_idx = i
        break

if header_row_idx is not None:
    print(f"   -> Found RPP headers on Row {header_row_idx+1}")
    
    # 3. Reload with correct header
    df_rpp = pd.read_excel(files['rpp'], header=header_row_idx, engine='openpyxl')
    
    # 4. Map State Names to Abbr
    # Your map includes "Alabama", "Alaska", etc.
    df_rpp['State_Abbr'] = df_rpp['GeoName'].map(name_to_abbr)
    
    # Drop rows that are not states (Regions, US Total, etc.)
    df_rpp = df_rpp.dropna(subset=['State_Abbr'])
    
    # 5. Filter Columns (Keep only State and Target Years)
    # The columns in the Excel are integers (e.g., 2013), but pandas might read them as strings or ints.
    # We check both just in case.
    cols_to_keep = ['State_Abbr']
    valid_years = []
    
    for y in target_years: # [2013, 2014... 2023]
        if y in df_rpp.columns:
            cols_to_keep.append(y)
            valid_years.append(y)
        elif str(y) in df_rpp.columns: # Check string version '2013'
            cols_to_keep.append(str(y))
            valid_years.append(y)
            
    df_rpp = df_rpp[cols_to_keep]
    
    # 6. Melt (Wide -> Long)
    # This turns columns [2013, 2014...] into rows
    df_rpp = df_rpp.melt(id_vars=['State_Abbr'], var_name='Year', value_name='Cost_of_Living_Index')
    
    # Ensure Year is integer
    df_rpp['Year'] = df_rpp['Year'].astype(int)

else:
    print("❌ Error: Could not find 'GeoName' header in RPP file.")
    df_rpp = pd.DataFrame(columns=['State_Abbr', 'Year', 'Cost_of_Living_Index'])


# 3. FILTERING (PRE-MERGE)
# ---------------------------------------------------------
# To save memory and ensure cleanliness, filter all DFs to the target now.

def filter_data(df):
    # Filter States
    df = df[df['State_Abbr'].isin(target_states)]
    # Filter Years
    df = df[df['Year'].isin(target_years)]
    return df

df_mig = filter_data(df_mig)
df_cen = filter_data(df_cen)
df_bls = filter_data(df_bls)
df_qcew = filter_data(df_qcew)
df_hud = filter_data(df_hud)
df_hpi = filter_data(df_hpi)
df_rpp = filter_data(df_rpp)


# 4. MASTER MERGE
# ---------------------------------------------------------
print("Merging all panels...")

# Start with Migration Data as the base
master = df_mig.copy()

# Merge Census
master = pd.merge(master, df_cen, on=['State_Abbr', 'Year'], how='left')

# Merge BLS
master = pd.merge(master, df_bls, on=['State_Abbr', 'Year'], how='left')

# Merge QCEW
master = pd.merge(master, df_qcew, on=['State_Abbr', 'Year'], how='left')

# Merge HUD
master = pd.merge(master, df_hud, on=['State_Abbr', 'Year'], how='left')

# Merge HPI
master = pd.merge(master, df_hpi, on=['State_Abbr', 'Year'], how='left')

# Merge RPP
master = pd.merge(master, df_rpp, on=['State_Abbr', 'Year'], how='left')


# 5. FINAL CLEANUP & SAVE
# ---------------------------------------------------------
# Sort
master.sort_values(by=['State_Abbr', 'Year'], inplace=True)

# Reorder columns slightly for readability
first_cols = ['State_Abbr', 'Year', 'Net_Migration_Rate']
other_cols = [c for c in master.columns if c not in first_cols]
master = master[first_cols + other_cols]

# Save
output_filename = 'Final_Panel_Dataset_2013_2023.csv'
master.to_csv(output_filename, index=False)

print("\n" + "="*40)
print(f"SUCCESS! Panel created for 12 States, 2013-2023.")
print(f"Saved to: {output_filename}")
print(f"Dimensions: {master.shape} (Should be roughly 132 rows: 12 states * 11 years)")
print("="*40)
print(master.head())