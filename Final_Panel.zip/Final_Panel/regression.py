import pandas as pd
import numpy as np
from linearmodels.panel import PanelOLS
import statsmodels.api as sm

# 1. LOAD DATA
# ---------------------------------------------------------
df = pd.read_csv('Final_Panel_Dataset_2013_2023.csv')

# 2. PREPARE FOR PANEL REGRESSION
# ---------------------------------------------------------
# Linearmodels requires a MultiIndex (Entity, Time)
df = df.set_index(['State_Abbr', 'Year'])

# Select Independent Variables (IVs)
# Note: We must be careful of multicollinearity (e.g., Rent and HPI are similar).
# Let's test a robust mix.
exog_vars = [
    'Median_Rent',           # Cost of Housing (Renters)
    'HPI_Index',             # Cost of Housing (Owners)
    'Job_Growth_Pct',        # Economic Opportunity
    'Unemployment_Rate',     # Economic Distress
    'Cost_of_Living_Index',  # General Affordability (Groceries/Services)
    # 'Worked_From_Home_Pct' # Optional: Add this if you extracted it from Census
]

# Ensure no missing data (Regression will crash on NaNs)
# We drop rows only if specific columns are missing
df_reg = df.dropna(subset=exog_vars + ['Net_Migration_Rate', 'In_Migration_Rate', 'Out_Migration_Rate'])

# Add a Constant (Intercept)
df_reg = sm.add_constant(df_reg)

# 3. DEFINE THE REGRESSION FUNCTION
# ---------------------------------------------------------
def run_fixed_effects(dependent_var, name):
    print(f"\n{'='*20} MODEL: {name.upper()} {'='*20}")
    
    # Define Model: PanelOLS(Y, X, EntityEffects=True, TimeEffects=True)
    mod = PanelOLS(df_reg[dependent_var], 
                   df_reg[['const'] + exog_vars], 
                   entity_effects=True, 
                   time_effects=True) # Turn this to False if you want to see the "Covid Effect" explicitly
    
    # Fit Model with Clustered Standard Errors (Robust to autocorrelation)
    res = mod.fit(cov_type='clustered', cluster_entity=True)
    
    print(res)
    return res

# 4. RUN THE THREE MODELS
# ---------------------------------------------------------

# Model 1: Net Migration (The "Bottom Line")
res_net = run_fixed_effects('Net_Migration_Rate', 'Net Migration')

# Model 2: In-Migration (The "Pull" Factors)
res_in = run_fixed_effects('In_Migration_Rate', 'In-Migration (Pull)')

# Model 3: Out-Migration (The "Push" Factors)
res_out = run_fixed_effects('Out_Migration_Rate', 'Out-Migration (Push)')

# 5. DIAGNOSTICS (Collinearity Check)
# ---------------------------------------------------------
print("\n=== Correlation Check (Multicollinearity) ===")
print(df[exog_vars].corr().round(2))