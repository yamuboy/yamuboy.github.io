import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 1. LOAD DATA
# ---------------------------------------------------------
df = pd.read_csv('Final_Panel_Dataset_2013_2023.csv')

# Create a short label column (e.g., "TX 15") for cleaner text
df['Label'] = df['State_Abbr'] + " " + df['Year'].astype(str).str[-2:]

# Set visual style
sns.set_theme(style="whitegrid")

# ---------------------------------------------------------
# PLOT 1: THE HOUSING PUSH (Annotated)
# ---------------------------------------------------------
plt.figure(figsize=(14, 8))

# Draw the regression plot (dots + line)
p1 = sns.regplot(data=df, x='HPI_Index', y='Out_Migration_Rate', 
                 scatter_kws={'alpha':0.6, 's':60}, # s = size of dots
                 line_kws={'color':'red', 'alpha':0.5})

# Annotate every point
# We use a small offset (+1 on y) so the text sits slightly above the dot
for i in range(df.shape[0]):
    p1.text(x=df.HPI_Index.iloc[i], 
            y=df.Out_Migration_Rate.iloc[i] + 0.2, 
            s=df.Label.iloc[i], 
            fontdict={'size': 8, 'color': 'black', 'weight': 'light'})

plt.title('The Push Factor: HPI vs. Out-Migration (State Paths)', fontsize=16, fontweight='bold')
plt.xlabel('Housing Price Index (HPI)', fontsize=12)
plt.ylabel('Out-Migration Rate (per 1,000)', fontsize=12)
plt.tight_layout()
plt.show()


# ---------------------------------------------------------
# PLOT 2: THE ECONOMIC PULL (Annotated)
# ---------------------------------------------------------
plt.figure(figsize=(14, 8))

# Draw the regression plot
p2 = sns.regplot(data=df, x='Job_Growth_Pct', y='In_Migration_Rate', 
                 scatter_kws={'alpha':0.6, 's':60}, 
                 line_kws={'color':'green', 'alpha':0.5})

# Annotate every point
for i in range(df.shape[0]):
    p2.text(x=df.Job_Growth_Pct.iloc[i], 
            y=df.In_Migration_Rate.iloc[i] + 0.2, 
            s=df.Label.iloc[i], 
            fontdict={'size': 8, 'color': 'black', 'weight': 'light'})

plt.title('The Pull Factor: Job Growth vs. In-Migration', fontsize=16, fontweight='bold')
plt.xlabel('Job Growth (%)', fontsize=12)
plt.ylabel('In-Migration Rate (per 1,000)', fontsize=12)
plt.tight_layout()
plt.show()