import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt

# 1. SETUP
df = pd.read_csv('Final_Panel_Dataset_2013_2023.csv')
usa = gpd.read_file("https://www2.census.gov/geo/tiger/GENZ2018/shp/cb_2018_us_state_20m.zip")

# Limit map to Continental US for better zoom (Removing AK/HI for cleaner grid)
usa = usa[~usa['STUSPS'].isin(['AK', 'HI', 'PR'])]

# 2. CREATE GRID
# 3 rows, 4 columns
fig, axes = plt.subplots(3, 4, figsize=(20, 12))
axes = axes.flatten() # Flattens the 3x4 grid into a list of 12 axes

years = sorted(df['Year'].unique())
vmin, vmax = -15, 15 # Fix scale for comparison

for i, ax in enumerate(axes):
    if i < len(years):
        year = years[i]
        
        # Merge
        data_year = df[df['Year'] == year]
        map_data = usa.merge(data_year, left_on='STUSPS', right_on='State_Abbr', how='left')
        
        # Plot Base (Grey)
        usa.plot(ax=ax, color='#f2f2f2', edgecolor='#d9d9d9')
        
        # Plot Data (Colored)
        valid_data = map_data.dropna(subset=['Net_Migration_Rate'])
        valid_data.plot(column='Net_Migration_Rate', ax=ax, cmap='RdBu', 
                        vmin=vmin, vmax=vmax, edgecolor='black')
        
        ax.set_title(str(year), fontweight='bold', fontsize=14)
        ax.axis('off')
    else:
        # Hide unused plots (if you have fewer years than grid spots)
        ax.axis('off')

# Add Colorbar at bottom
sm = plt.cm.ScalarMappable(cmap='RdBu', norm=plt.Normalize(vmin=vmin, vmax=vmax))
sm._A = []
cbar = fig.colorbar(sm, ax=axes, orientation='horizontal', fraction=0.02, pad=0.05)
cbar.set_label('Net Migration Rate (Red = Inflow, Blue = Outflow)', fontsize=14)

plt.suptitle('Evolution of Migration (2013-2023)', fontsize=24)
plt.savefig('Migration_Grid_Map.png', dpi=300)
print("Saved 'Migration_Grid_Map.png'")
plt.show()