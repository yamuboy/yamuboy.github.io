import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 1. LOAD DATA
# ---------------------------------------------------------
df = pd.read_csv('Final_Panel_Dataset_2013_2023.csv')

# Set visual style
sns.set_theme(style="whitegrid")
plt.rcParams['figure.figsize'] = (12, 8)

# 2. VIZ 1: THE TRENDS (Winners vs. Losers)
# ---------------------------------------------------------
# Purpose: Show which states are gaining vs. losing people over time.
plt.figure(figsize=(14, 8))
sns.lineplot(data=df, x='Year', y='Net_Migration_Rate', hue='State_Abbr', linewidth=2.5, marker='o')

# Add a black line at 0 to separate Gainers from Losers
plt.axhline(0, color='black', linewidth=2, linestyle='--')

plt.title('Net Migration Rate (2013-2023): The "Exodus" vs. The "Boom"', fontsize=16, fontweight='bold')
plt.ylabel('Net Migration Rate (per 1,000 people)', fontsize=12)
plt.xlabel('Year', fontsize=12)
plt.legend(title='State', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()


# 3. VIZ 2: THE HOUSING PUSH (HPI vs. Out-Migration)
# ---------------------------------------------------------
# Hypothesis: As Housing Price Index (HPI) goes UP, Out-Migration should go UP.
plt.figure(figsize=(10, 6))

# Create a scatter plot with a regression line
sns.regplot(data=df, x='HPI_Index', y='Out_Migration_Rate', 
            scatter_kws={'alpha':0.5}, line_kws={'color':'red'})

# Label a few points for context (Optional)
# This loops through the data and labels outliers (e.g., high HPI points)
for i in range(df.shape[0]):
    if df.HPI_Index.iloc[i] > 300 or df.Out_Migration_Rate.iloc[i] > 40:
        plt.text(x=df.HPI_Index.iloc[i]+2, y=df.Out_Migration_Rate.iloc[i], 
                 s=df.State_Abbr.iloc[i], fontdict=dict(color='black', size=9))

plt.title('The Push Factor: Do High House Prices Drive People Away?', fontsize=16, fontweight='bold')
plt.xlabel('Housing Price Index (HPI)', fontsize=12)
plt.ylabel('Out-Migration Rate (per 1,000)', fontsize=12)
plt.show()


# 4. VIZ 3: THE ECONOMIC PULL (Jobs vs. In-Migration)
# ---------------------------------------------------------
# Hypothesis: Higher Job Growth should attract more people (Pull).
plt.figure(figsize=(10, 6))

sns.regplot(data=df, x='Job_Growth_Pct', y='In_Migration_Rate', 
            scatter_kws={'alpha':0.6}, line_kws={'color':'green'})

plt.title('The Pull Factor: Does Job Growth Attract People?', fontsize=16, fontweight='bold')
plt.xlabel('Job Growth (%)', fontsize=12)
plt.ylabel('In-Migration Rate (per 1,000)', fontsize=12)
plt.show()


# 5. VIZ 4: THE CORRELATION HEATMAP
# ---------------------------------------------------------
# Purpose: Summarize ALL relationships at once.
# This helps you decide which variables to keep for your regression.

# Select only numeric columns of interest
cols_to_corr = [
    'Net_Migration_Rate', 'In_Migration_Rate', 'Out_Migration_Rate',
    'Median_Rent', 'HPI_Index', 'Job_Growth_Pct', 'Unemployment_Rate',
    'Median_Age', 'Worked_From_Home_Pct', 'Cost_of_Living_Index'
]

# Calculate Correlation Matrix
corr_matrix = df[cols_to_corr].corr()

plt.figure(figsize=(12, 10))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
plt.title('Correlation Matrix: What actually drives Migration?', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()