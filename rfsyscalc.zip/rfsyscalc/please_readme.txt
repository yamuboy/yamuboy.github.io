
8/16/2004 LL
-made mostly minor cosmetic and documentation tweaks (mostly notes in the spreadsheet) resulting in version 4.0h


10/10/2001 LL

RFsyscalc 4.0f is released
-broadband noise graph (TX) was altered slightly....
-better explanation was given for placing filter BW's when doing bb noise analysis


10/9/2001 LL
RFsyscalc 4.000e is released
-hopefully again this is the appropriate TX noise analysis.. who knows

10/8/2001 LL
RFsyscalc 4.000d is released
-fixed an error in the summary table
->think I have the TX broadband noise analysis working almost correctly.

10/7/2001 LL
RFsyscalc 4.000c is released with even more features
-> plots of rough "input IP3" vs bandwidth for receivers (the effect of filters, using a brick wall bandwidth approximation)
->plots of required input interference levels (based on IIP3) to cause 3 dB loss of sensitivity
-> preliminary (crude) approximation for broadband transmitter noise output based on these filter bandwidths.  I hope to improve this analysis... it's just a starting point /placeholder

10/6/2001 LL

RFsyscalc 4.000b is released with lots of new features and many reformatting changes
-> graphs and tables added for looking at various parameters over AGC range.  The formatting of the graphs is poor but somewhat useful.
-> psat sanity check added (not really accounted for fully when AGC is active ... it's just a visual thing)
-> calcs now use average power unless otherwise specified (rather than per tone)
-> delayed AGC feature added ****
-> more cells in the input area

->old documentation is mainly obsolete, it is being left in this package with the previous versions of the spreadsheet in case it helps in any way...


7/16/2001 LL

RFsyscalc 3.9 is released to add a TX noise calculation.  Nothing much else



12/20/2000

RFsyscalc 3.8 has been released to fix a bug in the noise figure
calculation. This was a problem when the gain of the system dropped
below zero (not typical in a receiver, but possible in a transmitter).

Please use the worksheet with caution and let me know of any bugs you
find.  I believe this bug was a result of me trying to make something
more complicated than it needed to be, but perahps I was onto
something and just screwed up the implementation.

The specific equation was the NFt (total noise figure) calculation and
how it was conditionally computed.


Sincerely,

Lance Lascari
lance_lascari@ieee.org

http://tools.rfdude.com
