from __future__ import division, print_function, unicode_literals, absolute_import
try:
    import threading as _threading
except ImportError:
    import dummy_threading as _threading
import os as _os, re as _re

_valid_preference = _re.compile(r'^[a-zA-Z][a-zA-Z0-9_]*$')

class ApplicationPreferences(object):
    """Store application preferences
    
    This stores application preferences such as:
      - the last main window size/position
      - last used paths for file storage
      - last used configuration file
      - etc
      
    It is designed to be loaded at application startup, periodicially updated
    as the application is run, and then written back out to disc when the
    application is closed.
    """
    
    # borg-pattern class with a shared instance dictionary
    __shared = dict()
    
    def __init__(self, default_filename=None):
        "initialize"
        self.__dict__ = self.__shared
    
        if '_prefs' not in self.__dict__:
            # this is the first instance of an object of this class
            # initialize the storage and locking machinery
            self._prefs = dict()
            self._default_prefs = dict()
            self._lock = _threading.Lock()
            if not default_filename:
                default_filename = _os.path.expanduser('~/appprefs.prf')
            self._default_fname = default_filename
        else:
            if default_filename and default_filename != self._default_fname:
                self.set_default_filename(default_filename)
    
    def get_default_filename(self):
        "get the default filename to use when loading/saving preferences"
        return self._default_fname

    def set_default_filename(self, fname):
        "set the default filename to use when loading/saving preferences"
        self._default_fname = fname

    def get_default_preferences(self, prefs):
        "get a copy of the default preferences"
        self._lock.acquire()
        try:
            p = self._default_prefs.copy()
            return p    
        finally:
            self._lock.release()
    
    def set_default_preferences(self, prefs):
        "set the default preferences to use if they have not been defined"
        if not isinstance(prefs,dict):
            raise TypeError("the argument must be a dictionary")
        self._lock.acquire()
        try:
            self._default_prefs.update(prefs)
        finally:
            self._lock.release()
    
    def load(self, fname=None):
        "load preferences from a file"
        if fname is None:
            fname = self._default_fname
        
        self._lock.acquire()
        try:
            cfg = {}
            with open(fname,'r') as fp:
                exec(compile(fp.read(),fname,'exec'),globals(),cfg)
            for k in cfg:
                if k.startswith('_'):
                    continue
                self._prefs[k] = cfg[k]
        finally:
            self._lock.release()
        
    def save(self, fname=None):
        "save preferences to a file"
        if fname is None:
            fname = self._default_fname
            
        self._lock.acquire()
        try:
            keys = list(self._prefs.keys())
            keys.sort()
            fp = open(fname,'w')
            fp.write("# Application Preferences\n#\n\n")
            try:
                for k in keys:
                    # check that the key is a valid Python identifier
                    if not _valid_preference.match(k):
                        continue
                    fp.write("{} = {}\n".format(k,repr(self._prefs[k])))           
            finally:
                fp.close()
        finally:
            self._lock.release()
            
    def get(self, name, default=None):
        "get a preference value, or return the default value"
        try:
            return self[name]        
        except KeyError:
            pass
        return default
        
    def __contains__(self, name):
        "check to see if the preference is set (unreliable)"
        return name in self._prefs or name in self._default_prefs
    
    def __getitem__(self, name):
        "get a preference by name"
        self._lock.acquire()
        try:
            try:
                return self._prefs[name]
            except KeyError:
                pass
            return self._default_prefs[name]
        finally:
            self._lock.release()
    
    def __setitem__(self, name, val):
        "set the preference value"
        self._lock.acquire()
        try:
            self._prefs[name] = val
            return val
        finally:
            self._lock.release()
    
    def __delitem__(self, name):
        "delete a preference"
        self._lock.acquire()
        try:
            del self._prefs[name]
        finally:
            self._lock.release()
    
    def __len__(self):
        "number of preferences (unreliable)"
        return len(self._prefs)
       
