from __future__ import division, print_function, unicode_literals, absolute_import

class Error(Exception):
    "base class for all errors"
    pass

class ValidationError(Error):
    "exception for when validation of a parameter fails"
    pass

