from __future__ import division, print_function, unicode_literals, absolute_import
import wx
from wx.lib.scrolledpanel import ScrolledPanel
from .params import Param, ParamGroup, ParamPage
from .errors import *
import os, os.path


class EditTestParamsPanel(wx.Panel):
    """A panel that allows test parameters to be edited
    """
    
    def __init__(self, parms, *args, **kwargs):
        "create the panel"
        if not isinstance(parms,(list,tuple)):
            raise TypeError("'parms' must be a list/tuple")
        if not len(parms):
            raise ValueError("'parms' list is empty")
        super(EditTestParamsPanel,self).__init__(*args,**kwargs)
        self.test_params = parms[:]
        self.LISTDISPTEXTFG = wx.Colour(100,100,120)
        self.InitUI()
        
        # update controls
        self.update_controls()
        
    def InitUI(self):
        "initialize the panel"        
        pagemode = False
        if isinstance(self.test_params[0],ParamPage):
            pagemode = True
        
        self.indexed_params = []
        
        dw, dh = wx.DisplaySize()

        # create an outer notebook, regardless of whether we are in page mode or not
        book = wx.Notebook(self)        
        if pagemode:
            for p in self.test_params:
                if isinstance(p,ParamPage):
                    if not p.hidden:
                        #bookpanel = wx.Panel(book)
                        bookpanel = ScrolledPanel(book)                        
                        book.AddPage(bookpanel,p.label)
                        self._fillpanel(bookpanel,p.params)
                        bookpanel.SetupScrolling()
                        w, h = bookpanel.GetSizer().GetMinSize()
                        if w > dw*0.75:
                            w = int(dw*0.75)
                        if h > dh*0.75:
                            h = int(dh*0.75)
                        bookpanel.SetMinSize((w,h))

                else:
                    if p.hidden:
                        pass                    
                    else:
                        raise TypeError("only `ParamPage` objects are allowed in the test parameter list (page mode)")
        else:
            #bookpanel = wx.Panel(book)
            bookpanel = ScrolledPanel(book)                        
            book.AddPage(bookpanel,"Parameters")
            self._fillpanel(bookpanel,self.test_params)
            bookpanel.SetupScrolling()
            w, h = bookpanel.GetSizer().GetMinSize()
            if w > dw*0.75:
                w = int(dw*0.75)
            if h > dh*0.75:
                h = int(dh*0.75)
            bookpanel.SetMinSize((w,h))
        
        sz = wx.BoxSizer(wx.VERTICAL)
        sz.Add(book,1,wx.EXPAND)
        self.SetSizer(sz)

        # set tooltips to enabled
        wx.ToolTip.Enable(True)
        wx.ToolTip.SetDelay(500)
        
        
    def _fillpanel(self, panel, items):
        "fill a parameter panel on a page of the parameters dialog"
        
        # vertical sizer to put parameters into
        vsz = wx.BoxSizer(wx.VERTICAL)
        fgsz = None
        for p in items:
            if isinstance(p,Param):
                if not fgsz:
                    fgsz = wx.FlexGridSizer(cols=2,vgap=6,hgap=8)
                    fgsz.AddGrowableCol(1,1)
                self._add_parm(p,panel,fgsz)
            else:
                # ParamGroup
                if len(p):
                    if fgsz:
                        # close out the existing sizer and add it
                        vsz.Add(fgsz,0,wx.EXPAND|wx.ALL,3)
                    
                    # create a static box to stick the parameters into
                    szbox = wx.StaticBoxSizer(wx.StaticBox(panel,label=p.label),wx.VERTICAL)
                    fgsz = wx.FlexGridSizer(cols=2,vgap=6,hgap=8)
                    fgsz.AddGrowableCol(1,1)
                    # add parameters to the box
                    for p2 in p.params:
                        self._add_parm(p2,panel,fgsz)             
                    szbox.Add(fgsz,1,wx.EXPAND|wx.ALL,3)
                    vsz.Add(szbox,0,wx.EXPAND|wx.ALL,3)
                    fgsz = None
                    
        if fgsz:
            vsz.Add(fgsz,0,wx.EXPAND|wx.ALL,3)
        vsz.Add((-1,-1),1)
        panel.SetSizer(vsz)
        
    
    def _add_parm(self, p, parent, sizer):
        "add a parameter"
        ty = p.type
        
        # create a horizontal sizer to add parameters to
        # and a label for the control
        label = wx.StaticText(parent,-1,p.label)
        if len(p.help_text.strip()):
            #label.Bind(wx.EVT_MOTION,self.OnMouseOver)
            label.SetToolTip(wx.ToolTip(p.help_text))
        sizer.Add(label,0,wx.ALIGN_CENTER_VERTICAL)
        
        pholder = {'param':p,'label':label}
        
        if ty == 'string':
            # create a StaticText for the label and an TextCtrl for the text entry
            ctrl = wx.TextCtrl(parent,size=(200,-1))
            sizer.Add(ctrl)
            pholder['ctrl'] = ctrl
            
        elif ty in ('int','float'):
            # create a TextCtrl for the text entry
            ctrl = wx.TextCtrl(parent,size=(60,-1))
            sizer.Add(ctrl)
            pholder['ctrl'] = ctrl

        elif ty == 'boolean':
            # create a CheckBox
            ctrl = wx.CheckBox(parent)
            sizer.Add(ctrl)
            pholder['ctrl'] = ctrl
        
        elif ty == 'choice':
            # create a Choice
            ctrl = wx.Choice(parent,choices=p.choice_labels)
            sizer.Add(ctrl)
            pholder['choice'] = ctrl
        
        elif ty in ('file','directory'):
            # create a TextCtrl for the text entry
            hsz = wx.BoxSizer(wx.HORIZONTAL)
            ctrl = wx.TextCtrl(parent)
            ctrl.SetMinSize((300,-1))
            b = wx.Button(parent,-1,"Browse...")            
            hsz.Add(ctrl,1,wx.RIGHT,8)
            hsz.Add(b)
            sizer.Add(hsz,1)
            self.Bind(wx.EVT_BUTTON,self.OnButton,id=b.GetId())
            pholder['button_id'] = b.GetId()
            pholder['ctrl'] = ctrl
            
        elif ty in ('float_list','int_list','ordered_list'):
            # generate some text that shows what is in the int/float list
            hsz = wx.BoxSizer(wx.HORIZONTAL)
            ctrl = wx.TextCtrl(parent)
            ctrl.SetMinSize((300,-1))
            ctrl.SetEditable(False)
            ctrl.SetForegroundColour(self.LISTDISPTEXTFG)
            b = wx.Button(parent,-1,"Edit...")            
            hsz.Add(ctrl,1,wx.RIGHT,8)
            hsz.Add(b)
            sizer.Add(hsz,1)
            self.Bind(wx.EVT_BUTTON,self.OnButton,id=b.GetId())
            pholder['button_id'] = b.GetId()
            pholder['ctrl'] = ctrl
            pholder['value'] = p.value
        
        else:
            raise ValueError("don't know how to create an edit control for a '%s'"%ty)
        
        self.indexed_params.append(pholder)
    
    def update_controls(self):
        "update the values of all controls from the parameters"
        for p in self.indexed_params:
            parm = p['param']
            ty = parm.type
            
            if ty == 'boolean':
                p['ctrl'].SetValue(parm.value)                
            elif ty == 'choice':
                p['choice'].SetSelection(parm.selected_index)            
            elif ty in ('float_list','int_list','ordered_list'):
                p['ctrl'].SetValue(_compute_list_text(ty,parm.value))
                p['value'] = parm.value
            else:
                p['ctrl'].SetValue('{}'.format(parm.value))
                
    
    def save_parms(self):
        "called when the parameters are to be saved"
        
        # validate all parameters before doing the actual save
        errs = []
        for p in self.indexed_params:
            parm = p['param']
            if 'value' in p:
                v = p['value']
            elif 'ctrl' in p:
                v = p['ctrl'].GetValue()
            elif 'choice' in p:
                v = parm.get_byindex(p['choice'].GetSelection())
                
            try:
                parm.validate(v)
            except Exception as e:
                errs.append("%s: %s"%(parm.label,e))
                    
        if errs:
            raise ValidationError('\n'.join(errs))
        
        # OK, now do the actual save
        # there should be no errors in the parameter values
        for p in self.indexed_params:
            parm = p['param']
            if 'value' in p:
                v = p['value']
            elif 'ctrl' in p:
                v = p['ctrl'].GetValue()
            elif 'choice' in p:
                v = parm.get_byindex(p['choice'].GetSelection())
            
            parm.value = v
        
    def OnButton(self, e):
        "event handler for a button pressed to edit a parameter like a float list"
        
        eid = e.GetId()
        for p in self.indexed_params:
            if 'button_id' in p and p['button_id'] == eid:
                parm = p['param']
                if parm.type == 'float_list':
                    dlg = EditNumberListDialog(p,parent=self,conv=float,title='Edit: '+parm.label)
                    if dlg.ShowModal() == wx.ID_OK:
                        p['ctrl'].SetValue(_compute_list_text(parm.type,p['value']))
                    dlg.Destroy()

                elif parm.type == 'int_list':
                    dlg = EditNumberListDialog(p,parent=self,conv=int,title='Edit: '+parm.label)
                    if dlg.ShowModal() == wx.ID_OK:
                        p['ctrl'].SetValue(_compute_list_text(parm.type,p['value']))
                    dlg.Destroy()
                
                elif parm.type == 'ordered_list':
                    dlg = EditOrderedListDialog(p,parent=None,title='Edit: '+parm.label)
                    if dlg.ShowModal() == wx.ID_OK:
                        p['ctrl'].SetValue(_compute_list_text(parm.type,p['value']))
                    dlg.Destroy()
                    
                elif parm.type == 'file':
                    current = p['ctrl'].GetValue().strip()
                    kw = {'style':wx.FD_OPEN}
                    if current:
                        kw['defaultDir'] = os.path.dirname(current) 
                    dlg = wx.FileDialog(None,'Select File',**kw)
                    if dlg.ShowModal() == wx.ID_OK:
                        p['ctrl'].SetValue(dlg.GetPath())
                    dlg.Destroy()
                        
                elif parm.type == 'directory':
                    current = p['ctrl'].GetValue().strip()
                    kw = {'style':wx.DD_DIR_MUST_EXIST}
                    if current:
                        kw['defaultPath'] = os.path.dirname(current) 
                    dlg = wx.DirDialog(None,'Select Directory',**kw)
                    if dlg.ShowModal() == wx.ID_OK:
                        p['ctrl'].SetValue(dlg.GetPath())
                    dlg.Destroy()
                
                # replace the list text that shows the contents of the list
                break
    
    # def OnMouseOver(self, e):
        # "display tool tips when the mouse hovers over labels"
        # w = e.GetEventObject()
        # for p in self.indexed_params:
            # if w == p['label']:
                # w.SetToolTip(p['param'].help_text)
                # break
            
    
    
class EditTestParamsDialog(wx.Dialog):
    """A dialog wrapper around the EditTestParamPanel"""
    
    def __init__(self, parms, *args, **kwargs):
        "initializer"
        help = None
        if 'help_text' in kwargs:
            help = kwargs.pop('help_text')
            
        if 'style' in kwargs:
            kwargs['style'] |= wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER
        else:
            kwargs['style'] = wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER
        super(EditTestParamsDialog,self).__init__(*args,**kwargs)
        
        mainpanel = wx.Panel(self)
        sz = wx.BoxSizer(wx.VERTICAL)
        
        if help:
            _create_help_panel(mainpanel,sz,help)
            
        # create the EditTestParamsPanel
        self.panel = EditTestParamsPanel(parms,mainpanel)
        sz.Add(self.panel,1,wx.EXPAND|wx.ALL,2)
        
        # add a seperator
        #sep = wx.StaticLine(self)
        #sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(mainpanel,wx.ID_OK)
        cancel = wx.Button(mainpanel,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        # bind show/hide events
        self.Bind(wx.EVT_SHOW,self.OnShowDialog)
        
        mainpanel.SetSizer(sz)
        sz.Fit(self)
        
        self.SetTitle("Edit Test Parameters")
        
    def OnShowDialog(self, event):
        "called when the dialog is shown/hidden"
        if event.Show:
            # update the panel controls from the stored parameters
            self.panel.update_controls()
        
    def OnOK(self, e):
        "callback for when the OK button is pressed"
                
        try:
            self.panel.save_parms()
            e.Skip()
        except ValidationError as e:
            dlg = wx.MessageDialog(self,'{}'.format(e),'Validation Error',wx.OK|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        except Exception as e:
            dlg = wx.MessageDialog(self,'{}'.format(e),'Error',wx.OK|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
    
        
ID_ADD_SINGLE = wx.NewId()
ID_ADD_RANGE = wx.NewId()
ID_INSERT_SINGLE = wx.NewId()
ID_INSERT_RANGE = wx.NewId()
ID_DELETE_SINGLE = wx.NewId()
ID_DELETE_ALL = wx.NewId()
ID_SORT_ASC = wx.NewId()
ID_SORT_DES = wx.NewId()
ID_REMOVE_DUP = wx.NewId()
        
class EditNumberListDialog(wx.Dialog):
    """A dialog for editing a list of floating-point numbers"""
    
    def __init__(self, parm, conv=float, *args, **kwargs):
        "initializer"
        help = None
        if 'help_text' in kwargs:
            help = kwargs.pop('help_text')
            
        super(EditNumberListDialog,self).__init__(*args,**kwargs)
        
        if not issubclass(conv,(int,float)):
            raise TypeError("'conv' must be a number type")
                
        # save the parameter
        self.parameter = parm
        self.convert = conv
        
        # get the list of values
        if hasattr(parm,'value'):
            v = parm.value
        elif 'value' in parm:
            v = parm['value']
        else:
            raise ValueError("'parm' must have an attribute or key named 'value'")
        
        if not isinstance(v,(list,tuple)):
            raise ValueError("the 'values' attribute or key of 'parm' must be a list/tuple")
        self.value_list = [self.convert(x) for x in v]
        
        mainpanel = wx.Panel(self)
        sz = wx.BoxSizer(wx.VERTICAL)
        
        if help:
            _create_help_panel(mainpanel,sz,help)

            # create the horizontal sizer
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        sz.Add(hsz,1,wx.EXPAND|wx.ALL,8)
        
        # create the ListBox
        vals = ['{}'.format(x) for x in self.value_list]
        self.listbox = wx.ListBox(mainpanel,choices=vals,size=(80,200))
        hsz.Add(self.listbox,1,wx.EXPAND|wx.RIGHT,10)
        
        # create the button sizer and add buttons
        gsz = wx.GridSizer(rows=0,cols=2,vgap=4,hgap=4)
        gsz.Add(wx.Button(mainpanel,ID_ADD_SINGLE,"Add Value"),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_DELETE_SINGLE,"Delete Value"),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_ADD_RANGE,"Add Range"),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_DELETE_ALL,"Delete All"),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_INSERT_SINGLE,"Insert Value"),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_SORT_ASC,"Sort Asc."),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_INSERT_RANGE,"Insert Range"),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_SORT_DES,"Sort Desc."),0,wx.EXPAND)
        gsz.Add(wx.Button(mainpanel,ID_REMOVE_DUP,"Remove Dup."),0,wx.EXPAND)
        hsz.Add(gsz)
        
        # bind all of the buttons
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_ADD_SINGLE)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_DELETE_SINGLE)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_ADD_RANGE)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_DELETE_ALL)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_INSERT_SINGLE)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_SORT_ASC)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_INSERT_RANGE)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_SORT_DES)
        self.Bind(wx.EVT_BUTTON,self.OnButton,id=ID_REMOVE_DUP)
        
        # add a seperator
        sep = wx.StaticLine(mainpanel)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(mainpanel,wx.ID_OK)
        cancel = wx.Button(mainpanel,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        mainpanel.SetSizer(sz)
        sz.Fit(self)        
        self.CenterOnParent()
        
    def OnOK(self, event):
        "callback for when the OK button is pressed"
        vals = [self.convert(x) for x in self.listbox.GetItems()]
        try:
            if hasattr(self.parameter,'value'):
                self.parameter.value = vals
            elif 'value' in self.parameter:
                self.parameter['value'] = vals
            event.Skip()
        except ValidationError as e:
            dlg = wx.MessageDialog(self,'{}'.format(e),'Validation Error',wx.OK|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        except Exception as e:
            dlg = wx.MessageDialog(self,'{}'.format(e),'Error',wx.OK|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
                
    def OnButton(self, e):
        "event callback for button presses"
        eid = e.GetId()
        if eid == ID_ADD_SINGLE:
            r = {}
            dlg = SingleValueDialog(r,self,title='Add Value')
            dlg.ShowModal()
            dlg.Destroy()
            if 'value' in r:
                try:
                    v = self.convert(r['value'])
                    self.listbox.Append('{}'.format(v))
                except Exception as e:
                    dlg = wx.MessageDialog(self,'Error adding value: %s'%e,'Error',wx.OK|wx.ICON_ERROR)
                    dlg.ShowModal()
                    dlg.Destroy()
        
        elif eid == ID_ADD_RANGE:
            r = {}
            dlg = RangeValueDialog(r,self,title='Add Range')
            dlg.ShowModal()
            dlg.Destroy()
            if 'start' in r:
                try:
                    start = self.convert(r['start'])
                    stop = self.convert(r['stop'])
                    step = self.convert(r['step'])
                    if issubclass(self.convert,float):
                        vals = _float_range(start,stop,step)
                    else:
                        vals = range(start,stop+1,step)
                    s = ['{}'.format(x) for x in vals]
                    self.listbox.AppendItems(s)
                except Exception as e:
                    dlg = wx.MessageDialog(self,'Error adding range: %s'%e,'Error',wx.OK|wx.ICON_ERROR)
                    dlg.ShowModal()
                    dlg.Destroy()
        
        elif eid == ID_INSERT_SINGLE:
            n = self.listbox.GetSelection()
            if n == wx.NOT_FOUND:
                dlg = wx.MessageDialog(self,'Nothing is selected','Error',wx.OK|wx.ICON_ERROR)
                dlg.ShowModal()
                dlg.Destroy()
            else:
                r = {}
                dlg = SingleValueDialog(r,self,title='Insert Value')
                dlg.ShowModal()
                dlg.Destroy()
                if 'value' in r:
                    try:
                        v = self.convert(r['value'])
                        self.listbox.Insert('{}'.format(v),n)
                    except Exception as e:
                        dlg = wx.MessageDialog(self,'Error inserting value: %s'%e,'Error',wx.OK|wx.ICON_ERROR)
                        dlg.ShowModal()
                        dlg.Destroy()
        
        elif eid == ID_INSERT_RANGE:
            n = self.listbox.GetSelection()
            if n == wx.NOT_FOUND:
                dlg = wx.MessageDialog(self,'Nothing is selected','Error',wx.OK|wx.ICON_ERROR)
                dlg.ShowModal()
                dlg.Destroy()
            else:
                r = {}
                dlg = RangeValueDialog(r,self,title='Insert Range')
                dlg.ShowModal()
                dlg.Destroy()
                if 'start' in r:
                    try:
                        start = self.convert(r['start'])
                        stop = self.convert(r['stop'])
                        step = self.convert(r['step'])
                        if issubclass(self.convert,float):
                            vals = _float_range(start,stop,step)
                        else:
                            vals = range(start,stop+1,step)
                        for j,s in enumerate(['{}'.format(x) for x in vals]):
                            self.listbox.Insert(s,n+j)
                    except Exception as e:
                        dlg = wx.MessageDialog(self,'Error inserting range: %s'%e,'Error',wx.OK|wx.ICON_ERROR)
                        dlg.ShowModal()
                        dlg.Destroy()
        
        elif eid == ID_DELETE_SINGLE:
            # delete the selected item
            n = self.listbox.GetSelection()
            if n != wx.NOT_FOUND:
                self.listbox.Delete(n)
        elif eid == ID_DELETE_ALL:
            # delete all items
            self.listbox.Clear()
        elif eid == ID_SORT_ASC:
            # sort in ascending order
            vals = [self.convert(x) for x in self.listbox.GetItems()]
            vals.sort()
            svals = ['{}'.format(x) for x in vals]
            self.listbox.SetItems(svals)
        elif eid == ID_SORT_DES:
            # sort in descending order
            vals = [self.convert(x) for x in self.listbox.GetItems()]
            vals.sort(reverse=True)
            svals = ['{}'.format(x) for x in vals]
            self.listbox.SetItems(svals)
        elif eid == ID_REMOVE_DUP:
            # remove duplicate items
            s = set()
            outvals = []
            for v in [self.convert(x) for x in self.listbox.GetItems()]:
                if v not in s:
                    s.add(v)
                    outvals.append(v)
            svals = ['{}'.format(x) for x in outvals]
            self.listbox.SetItems(svals)

class EditOrderedListDialog(wx.Dialog):
    """A dialog for editing an ordered list of strings"""
    
    def __init__(self, parm, *args, **kwargs):
        "initializer"
        help = None
        if 'help_text' in kwargs:
            help = kwargs.pop('help_text')
            
        super(EditOrderedListDialog,self).__init__(*args,**kwargs)
                
        # save the parameter
        self.parameter = parm
        
        # get the list of values
        if hasattr(parm,'value'):
            v = parm.value
        elif 'value' in parm:
            v = parm['value']
        else:
            raise ValueError("'parm' must have an attribute or key named 'value'")
        
        if not isinstance(v,(list,tuple)):
            raise ValueError("the 'value' attribute or key of 'parm' must be a list/tuple")
        self.value_list = list(v[:])
        
        mainpanel = wx.Panel(self)
        sz = wx.BoxSizer(wx.VERTICAL)
        
        if help:
            _create_help_panel(mainpanel,sz,help)
            
        # create the horizontal sizer
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        sz.Add(hsz,1,wx.EXPAND|wx.ALL,8)
        
        # create the ListBox
        self.listbox = wx.ListBox(mainpanel,choices=self.value_list,size=(150,200))
        hsz.Add(self.listbox,1,wx.EXPAND|wx.RIGHT,10)
        
        # create the button sizer and add buttons
        bsz = wx.BoxSizer(wx.VERTICAL)
        self.move_to_top = wx.Button(mainpanel,wx.ID_ANY,"Move to Top")
        self.move_to_bot = wx.Button(mainpanel,wx.ID_ANY,"Move to Bottom")
        self.move_up = wx.Button(mainpanel,wx.ID_ANY,"Move Up")
        self.move_down = wx.Button(mainpanel,wx.ID_ANY,"Move Down")
        bsz.Add(self.move_to_top,0,wx.EXPAND)
        bsz.Add(self.move_up,0,wx.EXPAND)
        bsz.Add(self.move_down,0,wx.EXPAND)
        bsz.Add(self.move_to_bot,0,wx.EXPAND)
        hsz.Add(bsz)
        
        # bind all of the buttons
        self.Bind(wx.EVT_BUTTON,self.OnButton,self.move_to_top)
        self.Bind(wx.EVT_BUTTON,self.OnButton,self.move_to_bot)
        self.Bind(wx.EVT_BUTTON,self.OnButton,self.move_up)
        self.Bind(wx.EVT_BUTTON,self.OnButton,self.move_down)
        
        # add a seperator
        sep = wx.StaticLine(mainpanel)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(mainpanel,wx.ID_OK)
        cancel = wx.Button(mainpanel,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        mainpanel.SetSizer(sz)
        sz.Fit(self)
        self.CenterOnParent()
        
    def OnOK(self, event):
        "callback for when the OK button is pressed"
        vals = self.listbox.GetItems()
        try:
            if hasattr(self.parameter,'value'):
                self.parameter.value = vals
            elif 'value' in self.parameter:
                self.parameter['value'] = vals
            event.Skip()
        except ValidationError as e:
            dlg = wx.MessageDialog(self,'{}'.format(e),'Validation Error',wx.OK|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        except Exception as e:
            dlg = wx.MessageDialog(self,'{}'.format(e),'Error',wx.OK|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
                
    def OnButton(self, e):
        "event callback for button presses"
        n = self.listbox.GetSelection()
        if n == wx.NOT_FOUND:
            return
        item = self.listbox.GetString(n)
        count = self.listbox.GetCount()
        
        eid = e.GetId()
        if eid == self.move_to_top.GetId():
            newpos = 0
        elif eid == self.move_to_bot.GetId():
            newpos = count-1
        elif eid == self.move_up.GetId():
            newpos = n-1
        elif eid == self.move_down.GetId():
            newpos = n+1
                
        if newpos < 0 or newpos >= count or newpos == n:
            # trying to move something off the edge of the list
            # or move it to the same position it is already in
            return
        
        self.listbox.Delete(n)
        if newpos > n:
            if newpos == count-1:
                # special case for appending the item at the end
                self.listbox.Append(item)
                self.listbox.SetSelection(count-1)
            else:
                self.listbox.Insert(item,newpos)
                self.listbox.SetSelection(newpos)
        else:
            self.listbox.Insert(item,newpos)
            self.listbox.SetSelection(newpos)

            
class SingleValueDialog(wx.Dialog):
    """A dialog for entering a single value"""
    
    def __init__(self, store_in, *args, **kwargs):
        "initializer"
        help = None
        if 'help_text' in kwargs:
            help = kwargs.pop('help_text')
            
        super(SingleValueDialog,self).__init__(*args,**kwargs)
        
        if not isinstance(store_in,dict):
            raise TypeError("'store_in' must be a dictionary")
        
        # save the object to use to store the entered value in
        self.store = store_in
        
        mainpanel = wx.Panel(self)
        sz = wx.BoxSizer(wx.VERTICAL)
        
        if help:
            _create_help_panel(mainpanel,sz,help)
            
        # create the horizontal sizer
        hsz = wx.BoxSizer(wx.HORIZONTAL)
        sz.Add(hsz,1,wx.EXPAND|wx.ALL,20)
        
        # create the label and the text control
        label = wx.StaticText(mainpanel,-1,"Value")
        self.entry = wx.TextCtrl(mainpanel,size=(60,-1))
        hsz.Add(label,0,wx.RIGHT,10)
        hsz.Add(self.entry)

        # add a seperator
        sep = wx.StaticLine(mainpanel)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(mainpanel,wx.ID_OK)
        cancel = wx.Button(mainpanel,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        mainpanel.SetSizer(sz)        
        sz.Fit(self)
        self.CenterOnParent()
       
    def OnOK(self, e):
        "callback for when the OK button is pressed"
        self.store['value'] = self.entry.GetValue()
        e.Skip()
        
              
class RangeValueDialog(wx.Dialog):
    """A dialog for entering a single value"""
    
    def __init__(self, store_in, *args, **kwargs):
        "initializer"
        help = None
        if 'help_text' in kwargs:
            help = kwargs.pop('help_text')
        
        super(RangeValueDialog,self).__init__(*args,**kwargs)
        
        if not isinstance(store_in,dict):
            raise TypeError("'store_in' must be a dictionary")
        
        # save the object to use to store the entered value in
        self.store = store_in
        
        mainpanel = wx.Panel(self)
        sz = wx.BoxSizer(wx.VERTICAL)
        
        if help:
            _create_help_panel(mainpanel,sz,help)
        
        # create the horizontal sizer
        gsz = wx.FlexGridSizer(rows=0,cols=2,hgap=4,vgap=6)
        sz.Add(gsz,1,wx.EXPAND|wx.ALL,20)
        
        # create the label and the text control
        label = wx.StaticText(mainpanel,-1,"Start")
        self.start = wx.TextCtrl(mainpanel,size=(60,-1))
        gsz.Add(label)
        gsz.Add(self.start)
        label = wx.StaticText(mainpanel,-1,"Stop")
        self.stop = wx.TextCtrl(mainpanel,size=(60,-1))
        gsz.Add(label)
        gsz.Add(self.stop)
        label = wx.StaticText(mainpanel,-1,"Step")
        self.step = wx.TextCtrl(mainpanel,size=(60,-1))
        gsz.Add(label)
        gsz.Add(self.step)

        # add a seperator
        sep = wx.StaticLine(mainpanel)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(mainpanel,wx.ID_OK)
        cancel = wx.Button(mainpanel,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        mainpanel.SetSizer(sz)    
        sz.Fit(self)
        self.CenterOnParent()
       
    def OnOK(self, e):
        "callback for when the OK button is pressed"
        self.store['start'] = self.start.GetValue()
        self.store['stop'] = self.stop.GetValue()
        self.store['step'] = self.step.GetValue()
        e.Skip()
        
def _float_range( start, stop, step ):
    "compute a range of floats"
    if step == 0.0:
        raise ValueError("illegal step size")
    
    r = []
    if stop > start:
        if step < 0.0:
            raise ValueError("step cannot be negative when (stop > start)")
        r.append(start)
        v = start+step
        while v < stop+0.001*step:
            r.append(v)
            v += step
    
    elif stop < start:
        if step > 0.0:
            raise ValueError("step cannot be positive when (stop < start)")
        r.append(start)
        v = start+step
        while v > stop+0.001*step:
            r.append(v)
            v += step            
    
    else:
        # stop == start
        r.append(start)
    
    return r

def _compute_list_text(ty, value):
    "compute the list text"
    return ', '.join(['{}'.format(x) for x in value])

def _create_help_panel(wxobj, sizer, text):
    "add a simple help text panel to a wx object"    
    pan = wx.Panel(wxobj,style=wx.SIMPLE_BORDER)
    sz = wx.BoxSizer(wx.VERTICAL)
    sz.Add(wx.StaticText(pan,wx.ID_ANY,text),0,wx.EXPAND|wx.ALL,6)
    pan.SetSizer(sz)
    sizer.Add(pan,0,wx.EXPAND|wx.ALL,6)
        
    
    
    
    
    
