"""
File for things that are only available in wxPython 4.0+ to
avoid having compatibility issues with machines running older
version of wxPython - JB 

"""
from __future__ import unicode_literals, absolute_import, division, print_function
import wx

class CtrlComboPopup(wx.ComboPopup):
    """
    Generic interface to a wxComboPopup, which allows its use as the popup for a wxComboCtrl.
    """
    def __init__(self, control_class, *control_args, **control_kwargs):
        wx.ComboPopup.__init__(self)
        self._control = None
        self._control_class = control_class
        self._control_args = control_args
        self._control_kwargs = control_kwargs

    def Init(self):
        pass

    def Create(self, parent):
        self._control = self._control_class(parent, *self._control_args, **self._control_kwargs)
        return True
        
    def GetControl(self):
        return self._control
        
