from __future__ import division, print_function, unicode_literals, absolute_import
import logging
import wx

from wx import NullColour, Colour, Validator
from wx import CHK_UNDETERMINED
#from wx.lib.pubsub import setupkwargs
from wx.lib.pubsub import pub
from . import ustr

def parm( name, type='string', **kwargs ):
    """define a test routine parameter
    
    Each parm must have a 'name' - the name must be a string, and
       there are certain requirements of this name string
    
    'type' (if defined) sets the parameter type, the following types
       are supported:
       
       - 'string', 'str', 'unicode' (the default), the value is stored as a
             string
       - 'boolean' or 'bool', the value is stored as a True/False value
       - 'integer' or 'int', the value is stored as an integer
       - 'float', the value is stored as a float
       - 'choice', the value is stored as a choice from a list of choices
       - 'integer_list' or 'int_list', the value is stored as a list
             of integer values
       - 'float_list', the value is stored as a list of floating
             point values
    
    -------------------------------------------------------------------
    
    Keywords to this function are dependent on the type of parameter,
    but all parameters support the following keywords:
    
    'value', the initial/default value of the parameter - this must be
       able to be coerced to the correct type for the parameter type 
    
    'label', a string that will be used as a "human-friendly" label
       for the parameter when needed - if this is not defined then
       a label will be auto-generated
    
    'validator', a callable object that is used to validate the
       parameter value - it will be passed 2 arguments, the parameter
       name and the parameter value
    
    'help_text', a string that is used to display help text for the
       parameter
    
    -------------------------------------------------------------------
    
    Special information for the 'choice' parameter type:
    
    The 'choice' type has a required keyword called 'choices' which
    must be a list/tuple of 2-tuples. Each 2-tuple consists of a
    label string for the choice and a value (the value can be of
    any type). When the 'value' for a 'choice' parameter is set
    it must be the label string portion of one of the 'choices'
    that is used.

    Example:
        MYCHOICES = (
            ('Choice 1',1),
            ('Choice 2',2),
            ('Choice 3','fudge'),
        )
        
        # define parameter 'choice1' using the choice list
        # MYCHOICES, the default will be 'Choice 1'
        parm('choice1',type='choice',choices=MYCHOICES)
        
        # define parameter 'choice2' using the choice list
        # MYCHOICES, and set the default to 'Choice 3'
        parm('choice2',type='choice',choices=MYCHOICES,value='fudge')
    
    """
    from .params import StringParam, BooleanParam, FloatParam, IntParam, \
        FloatListParam, IntegerListParam, ChoiceParam, OrderedListParam, \
        FileParam, DirectoryParam
    
    name = ustr(name)
    type = ustr(type)
    
    # get the type object for the parameter
    if type in ('str','string','unicode'):
        t = StringParam
    elif type in ('bool','boolean'):
        t = BooleanParam        
    elif type == 'float':
        t = FloatParam    
    elif type in ('int','integer'):
        t = IntParam
    elif type == 'float_list':
        t = FloatListParam
    elif type in ('int_list','integer_list'):
        t = IntegerListParam
    elif type == 'choice':
        t = ChoiceParam    
    elif type == 'file':
        t = FileParam    
    elif type in ('dir','directory'):
        t = DirectoryParam    
    elif type == 'ordered_list':
        t = OrderedListParam    
    else:
        raise ValueError("invalid type '{}' for parameter '{}'".format(type,name))

    # generate the parameter object
    kwargs['name'] = name
    return t(**kwargs)

class WxPubLoggingHandler(logging.Handler):
    "LoggingHandler that broadcasts log messages via a wx.pubsub.pub message with arguments 'message' and 'level'"
    
    def __init__(self, pubmsg='logging.newMessage'):
        "Initializer. Accepts a single string argument that allows a custom pubsub message string to be sent upon a logging event"
        super(WxPubLoggingHandler,self).__init__()
        self.formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s','%H:%M:%S')
        self._msg = pubmsg
    
    def emit(self, record):
        "Format and broadcast a logging record. Sends a message with arguments 'message' and 'level'"
        m = self.format(record)
        pub.sendMessage(self._msg, message=m, level=record.levelno)
    
    def flush(self):
        "does nothing"
        pass

class WxOptionValidator(Validator):
    """
    Generic wx option input validator class. Requires a test function and an associated object and attribute to be passed into the constructor.

    The test function should take in True, False or None (for tri-state) as an input argument, and return a 2-tuple (valid, value) where:
        - 'valid' is a boolean indicating whether or not the input passes the validation test
        - 'value' is the resulting value of the control (True, False or None for tri-state)

    If the test function returns a value, this value will be stored into the attribute, assuming it's valid.
    If the test function doesn't return a value, no change will be made to the backend attribute.
    If the test function determines the input is invalid, the control's background will change color, with no change to the attribute.
    If the test function throws an exception, it will invalidate the control.

    Arguments:
        vfunction   -   function that takes a single argument (boolean or None) and returns a 2-tuple (boolean, ***), where *** is the value
                        to be stored in the backend attribute
        obj         -   Python object that contains the backend attribute to store the data associated with the control
        attribute   -   string containing the name of the backend attribute, or custom data if custom get/set functions are passed in

    Keywords:
        set_function    -   optional function that takes in the 'obj' and 'attribute' fields from this class and uses them to place the
                            value into the specified field. If no function is supplied, then the attribute is set directly using
                            setattr(obj, attribute, value). This is necessary if 'obj' is a complex object or a dictionary, etc.
        get_function    -   optional function that takes in the 'obj' and 'attribute' fields from this class and uses them to retrieve the
                            value from the specified field. If no function is supplied, then the attribute is acquired directly using
                            getattr(obj, attribute, value). This is necessary if 'obj' is a complex object or a dictionary, etc.
    """

    def __init__(self, vfunction, obj, attribute, *args, **kwargs):
        super(WxOptionValidator, self).__init__()

        set_function = kwargs.pop('set_function', None)
        get_function = kwargs.pop('get_function', None)

        self._valid_function = vfunction
        self._set_function = set_function
        self._get_function = get_function
        self._obj = obj
        self._attribute = attribute
        self._value = None

    def Clone(self):
        return WxOptionValidator(self._valid_function, self._obj, self._attribute, set_function=self._set_function, get_function=self._get_function)

    def Validate(self, parent):
        ctrl = self.GetWindow()

        if ctrl.Is3State():
            val = ctrl.Get3StateValue()
            if val == CHK_UNDETERMINED:
                valid = True
        else:
            val = ctrl.IsChecked()

        # check if the option is valid
        try:
            valid, value = self._valid_function(val)
        except:
            valid = False

        # if valid, store the converted value if one was returned, otherwise just store the original string
        if valid:
            ctrl.SetBackgroundColour(NullColour)
            self._value = value if value is not None else val
        # otherwise, color the control and clear the stored value
        else:
            ctrl.SetBackgroundColour(Colour(255, 128, 128)) # pink background to indicate invalid input
            self._value = None

        # mark the control for re-draw
        ctrl.Refresh()
        
        return valid

    def TransferFromWindow(self):
        "Override of superclass function to transfer the data from the parent control to the associated backend data"

        # if valid data exists
        if self._value is not None:
            try:
                # use the provided setter function
                if self._set_function:
                    self._set_function(self._obj, self._attribute, self._value)
                # if no setter function, assume an object/attribute hierarchy and set the data directly
                else:
                    setattr(self._obj, self._attribute, self._value)
            except:
                return False

        return True

    def TransferToWindow(self):
        "Override of superclass function to transfer the data from the associated backend data to the parent control"

        # try to acquire data from backend attribute
        try:
            # use the provided getter function
            if self._get_function:
                value = self._get_function(self._obj, self._attribute)
            # if no getter function, assume an object/attribute hierarchy and get the data directly
            else:
                value = getattr(self._obj, self._attribute)
        # value acquisition fails
        except:
            value = None

        # no data or acquisition failed
        if value is None:
            return False

        # set the value in the control
        ctrl = self.GetWindow()
        ctrl.SetValue(value)

        return True

class WxTextValidator(Validator):
    """
    Generic wx text input validator class. Requires a test function and an associated object and attribute to be passed into the constructor.

    The test function should take in the text as an input argument, and return a 2-tuple (valid, value) where:
        - 'valid' is a boolean indicating whether or not the input text passes the validation test
        - 'value' is the value of the text coerced to the type of its associated attribute, or None

    If the test function returns a value, this value will be stored into the attribute, assuming it's valid.
    If the test function doesn't return a value, the raw input text string will be stored into the attribute, assuming it's valid.
    If the test function determines the input is invalid, the control's background will change color, with no change to the attribute.
    If the test function throws an exception (e.g. tries to convert a word to an int), it will invalidate the control.

    Arguments:
        vfunction   -   function that takes a single string argument and returns a 2-tuple (boolean, ***), where *** is the value to be
                        stored in the backend attribute
        obj         -   Python object that contains the backend attribute to store the data associated with the control
        attribute   -   string containing the name of the backend attribute, or custom data if custom get/set functions are passed in

    Keywords:
        set_function    -   optional function that takes in the 'obj' and 'attribute' fields from this class and uses them to place the
                            value into the specified field. If no function is supplied, then the attribute is set directly using
                            setattr(obj, attribute, value). This is necessary if 'obj' is a complex object or a dictionary, etc.
        get_function    -   optional function that takes in the 'obj' and 'attribute' fields from this class and uses them to retrieve the
                            value from the specified field. If no function is supplied, then the attribute is acquired directly using
                            getattr(obj, attribute, value). This is necessary if 'obj' is a complex object or a dictionary, etc.
        str_function    -   optional function that converts the attribute value into a string to be placed into the box. If no function is
                            supplied, then the attribute is converted to a string directly using the appropriate string type constructor
    """

    def __init__(self, vfunction, obj, attribute, *args, **kwargs):
        super(WxTextValidator, self).__init__()

        set_function = kwargs.pop('set_function', None)
        get_function = kwargs.pop('get_function', None)
        str_function = kwargs.pop('str_function', None)

        self._valid_function = vfunction
        self._set_function = set_function
        self._get_function = get_function
        self._str_function = str_function
        self._obj = obj
        self._attribute = attribute
        self._value = None

    def Clone(self):
        return WxTextValidator(self._valid_function, self._obj, self._attribute, set_function=self._set_function, get_function=self._get_function, str_function=self._str_function)

    def Validate(self, parent):
        ctrl = self.GetWindow()
        input_text = ctrl.GetValue()

        # check if the text is valid
        try:
            valid, value = self._valid_function(input_text)
        except:
            valid = False

        # if valid, store the converted value if one was returned, otherwise just store the original string
        if valid:
            ctrl.SetBackgroundColour(NullColour)
            self._value = value if value is not None else input_text
        # otherwise, color the control and clear the stored value
        else:
            ctrl.SetBackgroundColour(Colour(255, 128, 128)) # pink background to indicate invalid input
            self._value = None

        # mark the control for re-draw
        ctrl.Refresh()
        
        return valid

    def TransferFromWindow(self):
        "Override of superclass function to transfer the data from the parent control to the associated backend data"

        # if valid data exists
        if self._value:
            try:
                # use the provided setter function
                if self._set_function:
                    self._set_function(self._obj, self._attribute, self._value)
                # if no setter function, assume an object/attribute hierarchy and set the data directly
                else:
                    setattr(self._obj, self._attribute, self._value)
            except:
                return False

        return True

    def TransferToWindow(self):
        "Override of superclass function to transfer the data from the associated backend data to the parent control"

        # try to acquire data from backend attribute
        try:
            # use the provided getter function
            if self._get_function:
                value = self._get_function(self._obj, self._attribute)
            # if no getter function, assume an object/attribute hierarchy and get the data directly
            else:
                value = getattr(self._obj, self._attribute)
        # value acquisition fails
        except:
            value = None

        # no data or acquisition failed
        if value is None:
            return False

        # convert value to string using supplied function
        if self._str_function is not None:
            text = self._str_function(value)
        # convert value to string directly
        else:
            text = ustr(value)

        # set the text in the control
        ctrl = self.GetWindow()
        ctrl.ChangeValue(text)

        return True