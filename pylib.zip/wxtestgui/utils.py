from __future__ import division, print_function, unicode_literals, absolute_import

def generate_label( name ):
    "generate a label from the parameter name"
    return name.replace('_',' ').replace('.',' - ').title()
    
def ValidateRecursively(control):
    """
    Validate this control and all of its children recursively, returning whether all controls are valid or not, unlike the built-in
    wx.Window.Validate() function, which stops validating after the first invalid control.
    """
    validator = control.GetValidator()

    isValid = validator.Validate(control) if validator else True

    for childControl in control.GetChildren():

        # only validate enabled controls
        if childControl.IsEnabled():
            isValid &= ValidateRecursively(childControl)

    return isValid