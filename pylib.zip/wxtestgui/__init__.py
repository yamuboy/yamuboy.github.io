from __future__ import division, print_function, unicode_literals, absolute_import

def ustr(s):
    "ensure an object is a unicode string"
    if 'unicode' in __builtins__:
        return unicode(s)
    else:
        return str(s)

from .errors import *
from .params import Param, ParamGroup, ParamPage, TestParameters
from .helpers import parm
from .edit_params import EditTestParamsDialog
#from .app_prefs import ApplicationPreferences
from .worker import (Worker, send_to_ui, get_next_message, NoMessages, WorkerMessage,
EVT_WORKER_MESSAGE, WorkerExiting, EVT_WORKER_EXITING)
from .instr import Instr
from .edit_instruments import InstrumentConfigDialog

# legacy support 
parm_group = ParamGroup
parm_page = ParamPage