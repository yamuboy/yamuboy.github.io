from __future__ import division, print_function, unicode_literals, absolute_import
import wx
from wx.lib.scrolledpanel import ScrolledPanel

from .instr import Instr
from .errors import *
import instrument
import re
from . import ustr



class InstrumentConfigPanel(ScrolledPanel):
    """A panel that allows instruments to be configured
    """
    
    def __init__(self, instr_list, *args, **kwargs):
        "create the panel"
        if not isinstance(instr_list,(list,tuple)):
            raise TypeError("'instr_list' must be a list/tuple")
        if not len(instr_list):
            raise ValueError("'instr_list' list is empty")            
        for p in instr_list:
            if not isinstance(p,Instr):
                raise TypeError("'instr_list' must contain only `Instr` instances")
        
        super(InstrumentConfigPanel,self).__init__(*args,**kwargs)
        self.instr_list = instr_list
        self.InitUI()
        self.SetupScrolling()
        
        # set a min size
        # this is necessary when using the ScrolledPanel
        # class since otherwise the window will start out tiny
        dw, dh = wx.DisplaySize()
        w, h = self.mainpanel.GetSizer().GetMinSize()
        if w > dw*0.75:
            w = int(dw*0.75)
        if h > dh*0.75:
            h = int(dh*0.75)
        self.SetMinSize((w,h))

        self._last_config = None
        
        # update controls
        self.update_controls()
        
    def InitUI(self):
        "initialize the panel"
        
        self.indexed_instr = []
        
        # main panel
        mainpanel = wx.Panel(self)
        self.mainpanel = mainpanel
        
        # vertical sizer to put panel elements into
        vsz = wx.BoxSizer(wx.VERTICAL)
        
        # flex grid sizer for instrument coonfiguration
        fgsz = wx.FlexGridSizer(rows=0,cols=6,hgap=6,vgap=4)
        vsz.Add(fgsz,0,wx.EXPAND|wx.ALL,5)
        
        # add table headers
        fgsz.Add((1,1))
        fgsz.Add(wx.StaticText(mainpanel,-1,'Driver'))
        fgsz.Add(wx.StaticText(mainpanel,-1,'VISA Address'))
        fgsz.Add(wx.StaticText(mainpanel,-1,'Chan'))
        fgsz.Add(wx.StaticText(mainpanel,-1,'Custom Params'))
        fgsz.Add((1,1))
        
        fam_cache = {}
        instrmgr = instrument.InstrumentManager()
        
        # add instruments
        for p in self.instr_list:
            d = {'instr':p}
            fgsz.Add(wx.StaticText(mainpanel,-1,p.label))
            
            # get a list of instruments in the family
            fam = p.family
            st = False
            if p.static or not p.family:
                # driver is not selectable at runtime
                st = True
                drv = wx.StaticText(mainpanel,-1,'(static)')
                lst = []
            else:
                if fam in fam_cache:
                    lst = fam_cache[fam]
                else:
                    lst = [''] + instrmgr.list_by_family(fam)
                    fam_cache[fam] = lst
                    
                drv = wx.Choice(mainpanel,choices=lst)
            fgsz.Add(drv)
            
            rsc = wx.TextCtrl(mainpanel,size=(160,-1))
            fgsz.Add(rsc)
            chan = wx.TextCtrl(mainpanel,size=(30,-1))
            fgsz.Add(chan)
            parms = wx.Button(mainpanel,-1,'Modify ...')
            fgsz.Add(parms)
            b = wx.Button(mainpanel,-1,"Driver Info")
            fgsz.Add(b)
            
            parms.Bind(wx.EVT_BUTTON,self.OnParamsButton)            
            b.Bind(wx.EVT_BUTTON,self.OnInfoButton)            
            
            d['static'] = st
            d['drv'] = drv
            d['drv_list'] = lst
            d['rsc'] = rsc
            d['chan'] = chan
            d['parms'] = p.parms
            d['parms_button'] = parms.GetId()
            d['info_button'] = b.GetId()
            
            self.indexed_instr.append(d)
        
        # create load and save buttons
        buttonpan = wx.Panel(mainpanel)
        sz1 = wx.StaticBoxSizer(wx.StaticBox(buttonpan,label="File I/O"),wx.HORIZONTAL)
        buttonsz = wx.BoxSizer(wx.HORIZONTAL)
        sz1.Add(buttonsz,0,wx.TOP|wx.BOTTOM,8)
        load = wx.Button(buttonpan,-1,'Load ...')
        save = wx.Button(buttonpan,-1,'Save ...')
        self.Bind(wx.EVT_BUTTON,self.OnLoad,load)
        self.Bind(wx.EVT_BUTTON,self.OnSave,save)
        buttonsz.Add((8,-1))
        buttonsz.Add(load,0,wx.RIGHT,10)
        buttonsz.Add(save)
        buttonsz.Add((8,-1))
        buttonpan.SetSizer(sz1)
        vsz.Add((-1,10))
        vsz.Add(buttonpan,0,wx.LEFT|wx.RIGHT,5)
        
        mainpanel.SetSizer(vsz)
        vsz.Fit(mainpanel)
        
    def OnInfoButton(self, e):
        "display information about the instrument driver"
        
        eid = e.GetId()
        for p in self.indexed_instr:    
            if eid == p['info_button']:
                family = p['instr'].family
                drv = None
                if p['static']:
                    drv = p['instr'].driver_name
                else:
                    n = p['drv'].GetSelection()
                    if n != wx.NOT_FOUND:
                        drv = p['drv_list'][n]
                        
                if not drv:
                    dlg = wx.MessageDialog(self,'No driver specified!','Error',wx.OK|wx.CENTRE|wx.ICON_ERROR)
                else:
                    d = None
                    try:
                        d = instrument.driver(family,drv)
                    except instrument.DriverNotFound:
                        pass
                    
                    if d is None:
                        dlg = wx.MessageDialog(self,'Unable to load driver!','Error',wx.OK|wx.CENTRE|wx.ICON_ERROR)
                    else:
                        doc = d.__doc__
                        if not doc:
                            doc = 'No information available'
                        dlg = wx.MessageDialog(self,doc,'Driver Info',wx.OK|wx.CENTRE)                
                
                dlg.ShowModal()
                dlg.Destroy()
                break
                
    def OnParamsButton(self, e):
        "edit custom parameters"
        eid = e.GetId()
        for p in self.indexed_instr:    
            if eid == p['parms_button']:
                # create a dialog for editing the parameters
                dlg = InstrumentEditCustomParams(p['parms'],parent=self)
                dlg.ShowModal()
                dlg.Destroy()
                break
    
    def OnLoad(self, event):
        "load instrument configuration from a file"
        kw = {'style':wx.FD_OPEN,'wildcard':"Instrument Config Files (*.cfg)|*.cfg"}
        if self._last_config:
            dir, fname = os.path.split(self._last_config)
            if os.path.isdir(dir):
                kw['defaultDir'] = dir
                kw['defaultFile'] = fname
            
        dlg = wx.FileDialog(self,'Load Instrument Config',**kw)
        dlg.CenterOnParent()
        if dlg.ShowModal() == wx.ID_OK:
            try:
                fname = dlg.GetPath()
                fp = open(fname,'rb')
                try:
                    data = {}
                    exec(compile(fp.read(),fname,'exec'), data)
                    if 'INSTRUMENTS' not in data:
                        raise ValueError('could not find `INSTRUMENTS` variable in file')
                    for cfg in data['INSTRUMENTS']:
                        if 'name' not in cfg:
                            raise ValueError('missing `name` in configuration')
                            
                        # search for the instrument config object
                        name = cfg['name']
                        for instr in self.instr_list:
                            if instr.name == name:
                                # found the right instrument
                                if not instr.static:
                                    instr.driver_name = cfg.get('driver','')
                                instr.visa_rsc = cfg.get('resource','')
                                instr.chan = cfg.get('channel',1)
                                instr.parms = cfg.get('params',{})
                finally:
                    fp.close()
            except Exception as e:
                dlg2 = wx.MessageDialog(dlg,ustr(e),'Error loading config',wx.ICON_ERROR|wx.OK)
                dlg2.ShowModal()
                dlg2.Destroy()
                
        dlg.Destroy()
        self.update_controls()
    
    def OnSave(self, event):
        "save instrument configuration to a file"
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT,'wildcard':"Instrument Config Files (*.cfg)|*.cfg"}
        if self._last_config:
            dir, fname = os.path.split(self._last_config)
            if os.path.isdir(dir):
                kw['defaultDir'] = dir
                kw['defaultFile'] = fname
            
        dlg = wx.FileDialog(self,'Save Instrument Config',**kw)
        dlg.CenterOnParent()
        if dlg.ShowModal() == wx.ID_OK:
            try:
                fp = open(dlg.GetPath(),'w')
                try:
                    fp.write('# instrument configuration\n\n')
                    fp.write('INSTRUMENTS = [\n')
                    for instr in self.instr_list:
                        fp.write('    {\n')
                        fp.write("        'name': %s,\n"%repr(instr.name))
                        fp.write("        'driver': %s,\n"%repr(instr.driver_name))
                        fp.write("        'resource': %s,\n"%repr(instr.visa_rsc))
                        fp.write("        'channel': %s,\n"%repr(instr.chan))
                        fp.write("        'params': %s,\n"%repr(instr.parms))
                        fp.write('    },\n')                
                    fp.write(']\n\n')
                finally:
                    fp.close()
            except Exception as e:
                dlg2 = wx.MessageDialog(dlg,ustr(e),'Error saving config',wx.ICON_ERROR|wx.OK)
                dlg2.ShowModal()
                dlg2.Destroy()
                
        dlg.Destroy()
    
    def update_controls(self):
        "update control values"
        for p in self.indexed_instr:
            instr = p['instr']
            if not p['static']:
                if instr.driver_name in p['drv_list']: 
                    p['drv'].SetSelection(p['drv_list'].index(instr.driver_name))
            
            p['rsc'].SetValue(instr.visa_rsc)
            p['chan'].SetValue('%d'%instr.chan)
            p['parms'] = instr.parms
        
                
    def save_config(self):
        "called to save the instrument configuration"
        errs = []
        for p in self.indexed_instr:
            instr = p['instr']
            try:
                if not p['static']:
                    n = p['drv'].GetSelection()
                    if n != wx.NOT_FOUND:
                        instr.driver_name = p['drv_list'][n]
                    else:
                        instr.driver_name = ''
                instr.visa_rsc = p['rsc'].GetValue()
                instr.chan = p['chan'].GetValue()
                instr.parms = p['parms']
            
            except Exception as e:
                errs.append('%s: %s'%(instr.name,e))
        
        if len(errs):
            raise ValidationError('\n'.join(errs))
        
    
class InstrumentConfigDialog(wx.Dialog):
    """A dialog the wraps the InstrumentConfigPanel
    """
    
    def __init__(self, instr_list, *args, **kwargs):
        "initializer"
        if 'style' in kwargs:
            kwargs['style'] |= wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER
        else:
            kwargs['style'] = wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER
        super(InstrumentConfigDialog,self).__init__(*args,**kwargs)
        
        mainpanel = wx.Panel(self)
        sz = wx.BoxSizer(wx.VERTICAL)
        
        # create the InstrumentConfigPanel
        self.panel = InstrumentConfigPanel(instr_list,mainpanel)
        sz.Add(self.panel,1,wx.EXPAND|wx.ALL,8)
        
        # add a seperator
        sep = wx.StaticLine(mainpanel)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(mainpanel,wx.ID_OK)
        cancel = wx.Button(mainpanel,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        mainpanel.SetSizer(sz)
        
        sz.Fit(self)
        self.SetTitle("Instrument Configuration")
        
        # reset the sizes of the driver drop-down menus
        biggest = -1
        for p in self.panel.indexed_instr:
            w,h = p['drv'].GetSize()
            if w > biggest:
                biggest = w
        for p in self.panel.indexed_instr:
            p['drv'].SetSize(biggest,-1)
        
        # bind show/hide events
        self.Bind(wx.EVT_SHOW,self.OnShowDialog)
        
    def OnShowDialog(self, event):
        "called when the dialog is shown/hidden"
        if event.Show:
            # update the panel controls from the stored parameters
            self.panel.update_controls()
           
    def OnOK(self, e):
        "callback for when the OK button is pressed"
                
        try:
            self.panel.save_config()
            e.Skip()
        except ValidationError as e:
            dlg = wx.MessageDialog(self,ustr(e),'Validation Error',wx.OK|wx.CENTRE|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        except Exception as e:
            dlg = wx.MessageDialog(self,ustr(e),'Error',wx.OK|wx.CENTRE|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
        
        

class InstrumentEditCustomParams(wx.Dialog):
    "dialog used to edit custom parameters"
    
    def __init__(self, parm_dict, *args, **kwargs):
        "initializer"
        super(InstrumentEditCustomParams,self).__init__(*args,**kwargs)
        
        self.NUM_FIELDS = 8
        
        if not isinstance(parm_dict,dict):
            raise TypeError("`parm_dict` must be a dictionary")
        self._p = parm_dict
        
        sz = wx.BoxSizer(wx.VERTICAL)
        
        # create the UI
        panel = wx.Panel(self)
        
        # flex grid sizer for instrument coonfiguration
        psz = wx.BoxSizer(wx.VERTICAL)
        fgsz = wx.FlexGridSizer(rows=0,cols=2,hgap=0,vgap=0)
        psz.Add(fgsz,0,wx.EXPAND)
        
        # add table headers
        fgsz.Add(wx.StaticText(panel,-1,'Name'))
        fgsz.Add(wx.StaticText(panel,-1,'Value'))
        
        # add 8 rows for parameters
        self._w = []
        for i in range(self.NUM_FIELDS):
            n = wx.TextCtrl(panel,size=(80,-1))
            v = wx.TextCtrl(panel,size=(80,-1))
            fgsz.Add(n)
            fgsz.Add(v)
            self._w.append( (n,v) )
        
        # populate the parameter values
        pnames = self._p.keys()
        pnames.sort()
        if len(pnames) > self.NUM_FIELDS:
            # silently truncate more than NUM_FIELDS, should never happen
            # anyway so this should not be an issue
            pnames = pnames[:self.NUM_FIELDS]
        for i,p in enumerate(pnames):
            self._w[i][0].SetValue(p)
            self._w[i][1].SetValue('%s'%self._p[p])
        
        panel.SetSizer(psz)
        sz.Add(panel,1,wx.EXPAND|wx.ALL,8)
        
        # add a seperator
        sep = wx.StaticLine(self)
        sz.Add(sep,0,wx.EXPAND|wx.LEFT|wx.RIGHT,3)
        
        # add the dialog buttons
        ok = wx.Button(self,wx.ID_OK)
        cancel = wx.Button(self,wx.ID_CANCEL)
        buttonsz = wx.StdDialogButtonSizer()
        buttonsz.AddButton(ok)
        buttonsz.AddButton(cancel)
        buttonsz.Realize()
        sz.Add(buttonsz,0,wx.EXPAND|wx.ALL,8)
        
        # bind the OK button
        self.Bind(wx.EVT_BUTTON,self.OnOK,id=wx.ID_OK)
        
        self.SetSizer(sz)
        
        self.Fit()
        self.SetTitle("Custom Parameters")
        self.CenterOnParent()
                
    def OnOK(self, e):
        "callback for when the OK button is pressed"
                
        try:
            # get the parameters from the widgets and check them for validity
            data = {}
            for i in range(self.NUM_FIELDS):
                n = self._w[i][0].GetValue().strip()
                v = self._w[i][1].GetValue().strip()
                if n:
                    v = _custom_param_check(n,v)
                    data[n] = v
            
            # update the parameter dictionary
            self._p.update(data)
            for k in self._p.keys():
                if k not in data:
                    del self._p[k]
                
            e.Skip()
        except Exception as e:
            dlg = wx.MessageDialog(self,ustr(e),'Error',wx.OK|wx.CENTRE|wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
            
_nameok = re.compile(r'^[a-z_][a-z0-9_]*$',re.I)
_boolean_val = re.compile(r'^(?:true|false|yes|no|y|n)$',re.I)
        
def _custom_param_check(name, value):
    "make sure custom parameters are valid"
    # make sure the name is valid - convert to lowercase as well as all
    # instrument keywords are lowercase by convention
    if not _nameok.match(name):
        raise ValueError("'%s' is not a valid parameter name"%name)
            
    #### try to convert the value ####
    
    conv = False
    # check for boolean first
    if _boolean_val.match(value):
        conv = True
        if value[0].lower() in 'yt':
            v = True
        else:
            v = False
    
    # then check for floats
    if not conv:
        try:
            v = float(value)
            conv = True                
        except Exception:
            pass
    
    # lastly, leave the value as a string
    if not conv:
        v = value
    
    return v    
    
    
    
    
    
