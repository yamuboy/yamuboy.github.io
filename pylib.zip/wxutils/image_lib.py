from __future__ import division, print_function, unicode_literals, absolute_import
import wx
import os, sys
import base64

__all__ = ['ImglibItem','scan_directory','write_image_lib','scan_and_write']

DEFAULT_IMAGE_EXTENSIONS = ('.png','.gif','.jpg','.jpeg','.bmp')
DEFAULT_IMAGE_LIB_NAME = 'imglib.py'

_IMGLIB_CHARS_PER_LINE = 100

try:
    # python2
    ustr = unicode
    strtype = basestring
except NameError:
    # python3
    ustr = str
    strtype = str

class ImglibItem(object):
    "image item for the library"
    
    def __init__(self, alias, path):
        """initializer
        
        alias   string or a list/tuple of strings used to reference an image
        path    filesystem path to the image
        """
        if isinstance(alias,strtype):
            alias = (alias,)
        
        if not isinstance(alias,(list,tuple)):
            raise TypeError("'alias' must be a string or a list/tuple of strings")
        for a in alias:
            if not isinstance(a,strtype):
                raise TypeError("'alias' list/tuple must contain strings")
        
        self.aliases = tuple(alias)
        self.path = ustr(path)

def scan_directory( dir, exts=DEFAULT_IMAGE_EXTENSIONS, maxsize=-1, include_full_name=False, force_lowercase=False, space_to_underscore=True ):
    """scan a directory for images
    
    dir                  directory to scan for image files
    exts                 list/tuple of image file extensions to include (must be lowercase)
    maxsize              maximum images size in bytes (default is no max size)
    include_full_name    boolean to include the "full name" version of the image into the returned
                           alias list for the image, normally only the shortened name (without
                           the extension) is included in the alias list
    force_lowercase      boolean to force the image alias to be lowercase
    space_to_underscore  boolean to force the image alias to contain underscores instead of spaces
    """
    lst = []
    for f in os.listdir(dir):
        ff = os.path.join(dir,f)
        if os.path.isfile(ff):
            ext = os.path.splitext(f)[1].lower()
            if ext in exts:
                # make sure the image size is not too large
                if maxsize <= 0 or (maxsize > 0 and os.stat(ff).st_size < maxsize):
                    if force_lowercase:
                        f = f.lower()
                    if space_to_underscore:
                        f = f.replace(' ','_')                    
                    names = [os.path.splitext(f)[0]]
                    if include_full_name:
                        names.append(f)
                    lst.append( ImglibItem(names,ff) )
    return lst
    
def write_image_lib( lst, libname=DEFAULT_IMAGE_LIB_NAME, wd=None ):
    """create the image library
    
    lst       list of ImglibItem objects
    libname   name for the library
    wd        working directory for images specified by relative path
                will default to the current working directory
    """
    
    if not lst:
        raise ValueError('list is empty')
    
    if wd is None:
        wd = os.getcwd()
    
    # write the image library
    fp = open(libname,'wb')
    try:
        fp.write('""" auto-generated image library for wxPython programs\n\n')
        fp.write('IMAGE NAMES AVAILABLE\n--------------------------------------\n')
        for d in lst:
            for a in d.aliases:
                fp.write(' - {0}\n'.format(a))
        fp.write('\n"""\n')    
        fp.write(_imglib_header)
        fp.write('_IMAGE_DICT = {\n')
        for idx, d in enumerate(lst):
            for a in d.aliases:
                fp.write("    '{}':{},\n".format(a,idx))
        fp.write('}\n\n')
        fp.write('_IMAGE_DATA = [\n')
        for d in lst:
            try:
                fullpath = d.path
                if not os.path.isabs(fullpath):
                    fullpath = os.path.join(wd,fullpath)
                fimg = open(fullpath,'rb')
                try:
                    out = base64.b64encode(fimg.read())
                finally:
                    fimg.close()
                i = 0
                while i < len(out):
                    if i > 0:
                        fp.write('\n')
                    fp.write('    "'+out[i:i+_IMGLIB_CHARS_PER_LINE]+'"')
                    i += _IMGLIB_CHARS_PER_LINE
                fp.write(',\n')        
            except Exception as e:
                fp.write('    "", # unable to read "{0}"\n'.format(fullpath))
                sys.stderr.write('WARNING: unable to read "{0}"\n'.format(fullpath))
        fp.write(']\n')
    finally:
        fp.close()

    
def scan_and_write( dir, exts=DEFAULT_IMAGE_EXTENSIONS, maxsize=-1, include_full_name=False,
    force_lowercase=False, space_to_underscore=True, libname=DEFAULT_IMAGE_LIB_NAME ):
    "combine scan_directory() with write_image_lib() as a convenience function"
    write_image_lib(scan_directory(dir,exts,maxsize,include_full_name,force_lowercase,space_to_underscore),libname,dir)
    
    
_imglib_header = """from __future__ import division, print_function, unicode_literals, absolute_import
import wx as _wx
import base64 as _base64
try:
    # python3
    from io import BytesIO as _ImgStream
except ImportError:
    # python2
    from StringIO import StringIO as _ImgStream
    
__all__ = ['get_image','get_bitmap','get_image_list','ImageNotAvailable']

########################################################################################
###                           EXTERNALLY USABLE STUFF                                ###
########################################################################################

class ImageNotAvailable(KeyError): pass

def get_image(name):
    '''return the wx.Image object associated with 'name'
    
    raises an ImageNotAvailable exception if 'name' is not
    valid and may raise other wx exceptions
    '''
    try:
        return _load_image(_IMAGE_DICT[name]).image()
    except KeyError:
        raise ImageNotAvailable("{0}".format(name))

def get_bitmap(name):
    '''return the wx.Bitmap object associated with 'name'
    
    raises an ImageNotAvailable exception if 'name' is not
    valid and may raise other wx exceptions
    '''
    try:
        return _load_image(_IMAGE_DICT[name]).bitmap()
    except KeyError:
        raise ImageNotAvailable("{0}".format(name))

def get_image_list():
    "list of image names in this library"
    return list(_IMAGE_DICT.keys())

########################################################################################
###                                INTERNAL STUFF                                    ###
########################################################################################

def _load_image(index):
    "load an image by index"
    if index not in _IMAGE_CACHE:
        _IMAGE_CACHE[index] = _ImageStorage(index)      
    return _IMAGE_CACHE[index]
    
class _ImageStorage(object):
    "contains data for a single image"
    
    def __init__(self, data_index):
        "initializer"
        self.__data_index = data_index
        self.__img = None
        self.__bmp = None
        
    def image(self):
        "return the wxImage object"
        if self.__img is None:
            self.__img = _ImageStorage._load_image_by_index(self.__data_index)
        return self.__img
        
    def bitmap(self):
        "return the wxBitmap object"
        if self.__bmp is None:
            self.__bmp = self.image().ConvertToBitmap()
        return self.__bmp
    
    @staticmethod
    def _load_image_by_index(idx):
        "load image data into a wx.Image"
        try:
            # newer wx versions
            img = _wx.Image()
        except Exception:
            # older wx versions
            img = _wx.EmptyImage(1,1)
        io = _ImgStream(_base64.b64decode(_IMAGE_DATA[idx]))
        if hasattr(img,'LoadStream'):
            # newer wx versions
            img.LoadStream(io)
        else:
            # older wx versions
            img.LoadFile(io)
        return img

# cache for images already loaded
_IMAGE_CACHE = {}

"""

    