from __future__ import division, print_function, unicode_literals, absolute_import
import wx

def showModalMessageDialog(parent, title, message):
    """
    Pops up a modal dialog with a specified title, message, and an "OK" button.

    Arguments:
    parent - wx.Window parent for the created modal dialog
    title - String displayed in the titlebar of the modal dialog
    message - String displayed as the message in the modal dialog
    """
    dlg = wx.MessageDialog(parent, message, caption=title, style=wx.OK)
    dlg.ShowModal()
    dlg.Destroy()

def showModalYesNoCancelDialog(parent, title, message, yes_str='Yes', no_str='No', cancel_str='Cancel', default_option=wx.CANCEL_DEFAULT):
    """
    Pops up a modal dialog with a specified title, message, and three option buttons. Returns the corresponding wx ID for the selected option

    Arguments:
    parent - wx.Window parent for the created modal dialog
    title - String displayed in the titlebar of the modal dialog
    message - String displayed as the message in the modal dialog
    yes_str - String displayed on the first option button
    no_str - String displayed on the second option button
    cancel_str - String displayed on the third option button
    default_option - wx.YES_DEFAULT, wx.NO_DEFAULT, or wx.CANCEL_DEFAULT style
    """
    dlg = wx.MessageDialog(parent, message, caption=title, style=wx.YES_NO | wx.CANCEL | default_option)
    dlg.SetYesNoCancelLabels(yes_str, no_str, cancel_str)
    result = dlg.ShowModal()
    dlg.Destroy()
    return result

def showModalYesNoDialog(parent, title, message, yes_str='Yes', no_str='No', default_option=wx.NO_DEFAULT):
    """
    Pops up a modal dialog with a specified title, message, and two option buttons. Returns the corresponding wx ID for the selected option

    Arguments:
    parent - wx.Window parent for the created modal dialog
    title - String displayed in the titlebar of the modal dialog
    message - String displayed as the message in the modal dialog
    yes_str - String displayed on the first option button
    no_str - String displayed on the second option button
    default_option - wx.YES_DEFAULT or wx.NO_DEFAULT style
    """
    dlg = wx.MessageDialog(parent, message, caption=title, style=wx.YES_NO | default_option)
    dlg.SetYesNoLabels(yes_str, no_str)
    result = dlg.ShowModal()
    dlg.Destroy()
    return result

def promptUnsavedChanges(parent):
    """
    Prompt user to save modified changes before continuing. Returns 'True' if the user doesn't want to save or successfully saves changes,
    otherwise returns 'False' if the user cancels
    """
    while parent._datamgr.isModified:
        result = showModalYesNoCancelDialog(parent, 'Continue without saving changes?', 'Current configuration has unsaved changes. Save changes before continuing?')
        
        # return 'False' if cancel is selected
        if result == wx.ID_CANCEL:
            return False

        # break out of loop if no changes are to be saved
        elif result == wx.ID_NO:
            break

        # remain in loop until sucessfully saved
        elif result == wx.ID_YES:
            parent.onSaveConfig(None)

    return True