#ifdef __cplusplus
extern "C" {
#endif

#ifndef __COMPLEX_TYPES
#define __COMPLEX_TYPES

typedef struct
{
double r;
double i;
} COMPLEX;

typedef struct
{
double m;
double a;
} POLAR;

#endif

/* --- Function Prototypes --- */

#ifndef __COMPLEX_LIB
#define __COMPLEX_LIB

#define Cpx(x)        ((COMPLEX){x,0.})
#define Complex(x)    ((COMPLEX){x,0.})
#define Cnum(x,y)     ((COMPLEX){x,y})

// COMPLEX math tools
extern COMPLEX Cadd (COMPLEX a, COMPLEX b);   // add
extern COMPLEX Csub (COMPLEX a, COMPLEX b);   // subtract
extern COMPLEX Cmult (COMPLEX a, COMPLEX b);  // multiply
extern COMPLEX Cdiv (COMPLEX a, COMPLEX b);   // divide
extern COMPLEX Caddx (int n_args, ...);    // elipsis add function
extern COMPLEX Csubx (int n_args, ...);    // elipsis sub function
extern COMPLEX Cmultx (int n_args, ...);   // elipsis multiply function

// COMPLEX utilities
extern COMPLEX Ccopy (COMPLEX a);   // copy value
extern COMPLEX Cconj (COMPLEX a);   // conjugate
extern COMPLEX Cneg (COMPLEX a);    // negate
extern double Cmag (COMPLEX a);     // magnitude
extern COMPLEX Ccmag (COMPLEX a);   // magnitude returned as a complex number
extern double Cangle (COMPLEX a);   // angle
extern double Creal (COMPLEX a);    // real part
extern double Cimag (COMPLEX a);    // imaginary part
extern double Cmag2 (COMPLEX a);    // magnitude squared
// extern COMPLEX Cnum (double r, double i);  // create a complex number

// POLAR math tools
extern POLAR Padd (POLAR a, POLAR b);
extern POLAR Psub (POLAR a, POLAR b);
extern POLAR Pmult (POLAR a, POLAR b);
extern POLAR Pdiv (POLAR a, POLAR b);
extern POLAR Pnum (double a, double b);

// conversion utilities
extern POLAR C2P (COMPLEX a);         /* complex to polar */
extern COMPLEX P2C (POLAR a);       /* polar to complex */
extern POLAR *CA2PA (COMPLEX *a, POLAR *result, int rows, int cols);      /* complex array to polar array */
extern COMPLEX *PA2CA (POLAR *a, COMPLEX *result, int rows, int cols);    /* polar array to complex array */

// COMPLEX array tools
extern COMPLEX *CAadd (COMPLEX *a, COMPLEX *b, COMPLEX *result, int rows, int cols);    /* complex array add */
extern COMPLEX *CAsub (COMPLEX *a, COMPLEX *b, COMPLEX *result, int rows, int cols);    /* complex array subtract */
extern COMPLEX *CAmult (COMPLEX *a, COMPLEX *b, COMPLEX *result, int rowsa, int colsa_rowsb, int colsb);   /* complex array multiply */
extern COMPLEX *CAmult2x2 (COMPLEX *a, COMPLEX *b, COMPLEX *result); /* complex 2x2 array multiply */
extern COMPLEX *CAinv (COMPLEX *a, COMPLEX *result, int msize);    /* complex array inverse */
extern COMPLEX *CAinv2x2 (COMPLEX *a, COMPLEX *result); /* complex 2x2 array inverse */
extern COMPLEX CAdet (COMPLEX *a, int size);     /* complex array determinant */
extern COMPLEX CAdet2x2 (COMPLEX *a);  /* complex 2x2 array determinant */
extern COMPLEX *CAtrans (COMPLEX *a, COMPLEX *result, int rows, int cols);  /* complex array transpose */
extern COMPLEX *CAtrans2x2 (COMPLEX *a, COMPLEX *result); /* complex 2x2 array transpose */
extern COMPLEX *CAtranssqr (COMPLEX *a, COMPLEX *b, int msize); /* complex square array transpose */

// 2-port s-parameter embeding and de-embeding
extern COMPLEX *CSembed (COMPLEX *fxa, COMPLEX *s, COMPLEX *fxb, COMPLEX *result);
extern COMPLEX *CSdeembed (COMPLEX *fxa, COMPLEX *s, COMPLEX *fxb, COMPLEX *result);

// 2-port s-parameter K and MAG
extern void k_mag (COMPLEX *s, double *k, double *mag, double *b);

/* ========== 2-port conversion utilities =============== */

// conversion between cascadable and non-cascadable [S] parameters
extern COMPLEX *s2t (COMPLEX *s, COMPLEX *t);
extern COMPLEX *t2s (COMPLEX *t, COMPLEX *s);

// [S] conversion utils
extern COMPLEX *s2h (COMPLEX *s, COMPLEX *h, double rref);
extern COMPLEX *s2y (COMPLEX *s, COMPLEX *y, double rref);
extern COMPLEX *s2z (COMPLEX *s, COMPLEX *z, double rref);
extern COMPLEX *s2abcd (COMPLEX *s, COMPLEX *abcd, double rref);

// [Y] conversion utils
extern COMPLEX *y2h (COMPLEX *y, COMPLEX *h);
extern COMPLEX *y2z (COMPLEX *y, COMPLEX *z);
extern COMPLEX *y2abcd (COMPLEX *y, COMPLEX *abcd);
extern COMPLEX *y2s (COMPLEX *y, COMPLEX *s, double rref);

// [Z] conversion utils
extern COMPLEX *z2h (COMPLEX *z, COMPLEX *h);
extern COMPLEX *z2y (COMPLEX *z, COMPLEX *y);
extern COMPLEX *z2abcd (COMPLEX *z, COMPLEX *abcd);
extern COMPLEX *z2s (COMPLEX *z, COMPLEX *s, double rref);

// [ABCD] conversion utils
extern COMPLEX *abcd2h (COMPLEX *abcd, COMPLEX *h);
extern COMPLEX *abcd2y (COMPLEX *abcd, COMPLEX *y);
extern COMPLEX *abcd2z (COMPLEX *abcd, COMPLEX *z);
extern COMPLEX *abcd2s (COMPLEX *abcd, COMPLEX *s, double rref);

#endif // end of __COMPLEX_LIB

#ifdef __cplusplus
}
#endif

