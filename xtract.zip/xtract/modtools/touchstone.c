#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "touchstone.h"

/* some constants */
#define MAX_TSTONE_LINE_LENGTH      (256)
#define MAX_HEADER_LINES            (100)
#define MAX_TSTONE_FLOATS_PER_LINE  (11)

/* frequency multiplier strings for the touchstone header */
static const char* fstring_thz = "THZ";
static const char* fstring_ghz = "GHZ";
static const char* fstring_mhz = "MHZ";
static const char* fstring_khz = "KHZ";
static const char* fstring_hz = "HZ";

/* file state struct,
   for restoring the file state to a previously
   saved condition */
struct file_state_ {
   struct file_data_ *data;
   long int offset; 
   int lineno;
};

/*  ERROR MESSAGE CODES */
enum touchstone_error_codes {
   TSERR_FILENOTREADABLE=-1000,
   TSERR_INVALIDSTATE,
   TSERR_FILESEEKERR,
   TSERR_MEMORYFAILURE,
   TSERR_BLOCKFORMATERR,
   TSERR_INCOMPLETEBLOCK,
   TSERR_BLOCKMISMATCH,
   TSERR_INVALIDNUMPORTS,
   TSERR_EMPTYFILE,
   TSERR_MISMATCH,
   TSERR_FILEWRITEERR,
   TSERR_FILEFORMATERR,
   TSERR_FORMATSTRING,
   TSERR_INVALIDARG
};

/*************************************************************************************************/

static struct file_state_ get_file_state( struct file_data_* file );
static int restore_file_state( struct file_state_ st );
static char * get_tstone_line( struct file_data_* file );
static int read_touchstone_header( char *str, struct touchstone_file_ *d );
static int get_touchstone_data( struct file_data_* f, struct touchstone_file_ *d, struct network_parameters_ *np );
static int touchstone_alloc( struct network_parameters_ *d );
static int read_floats( char *str, double *vals );
static int determine_touchstone_block_size( struct file_data_* f );
static int read_touchstone_block( struct file_data_* f, struct touchstone_file_ *d, struct network_parameters_ *np, int *bsize, int* bptr, double* last_freq );
static int write_touchstone_block( FILE* f, struct touchstone_file_ * td, struct network_parameters_ * np, int ptr );

/*************************************************************************************************/

const char * get_ts_error_message( int err_code )
{
   const char* e;
   switch( err_code )
   {
   case 0:
      e = "No error"; break;
   case TSERR_FILENOTREADABLE:
      e = "The touchstone data file in not readable"; break;
   case TSERR_INVALIDSTATE:
      e = "An invalid file state exists (internal error)"; break;
   case TSERR_FILESEEKERR:
      e = "File seek error (file system failure)"; break;
   case TSERR_MEMORYFAILURE:
      e = "Out of memory."; break;
   case TSERR_BLOCKFORMATERR:
      e = "Invalid touchstone block format"; break;
   case TSERR_INCOMPLETEBLOCK:
      e = "Incomplete block read"; break;
   case TSERR_BLOCKMISMATCH:
      e = "Block size mismatch (internal error)"; break;
   case TSERR_INVALIDNUMPORTS:
      e = "Unable to correctly determine the number of ports (format error)"; break;
   case TSERR_EMPTYFILE:
      e = "No data in file"; break;
   case TSERR_MISMATCH:
      e = "Frequency point mismatch (internal error)"; break;
   case TSERR_FILEWRITEERR:
      e = "File write failure (file system failure)"; break;
   case TSERR_FILEFORMATERR:
      e = "General file format error"; break;
   case TSERR_FORMATSTRING:
      e = "Touchstone format string syntax error"; break;
   case TSERR_INVALIDARG:
      e = "Invalid function argument (null pointer?)"; break;

   default:
      e = "Unknown error"; break;
   }
   return e;
}

/*************************************************************************************************/
struct touchstone_file_* create_touchstone_file_data( void )
{
   struct touchstone_file_* d = (struct touchstone_file_*) malloc( sizeof(struct touchstone_file_) );
   if( !d ) return NULL;

   d->header = 0;
   d->freq_str = fstring_hz;
   d->fmult = 1.;
   d->param_type = 'S';
   d->format = Touchstone_MA;
   d->rref = 50.;

   d->seperator = '\t';
   d->indent = "\t\t";
   d->precision = 6;
   d->num_format = FP_auto;

   return d;
}

/*************************************************************************************************/
struct network_parameters_* create_network_parameter_data( void )
{
   struct network_parameters_* d = (struct network_parameters_*) malloc( sizeof(struct network_parameters_) );
   if( !d ) return NULL;

   d->n_freqs = 0;
   d->n_ports = 0;
   d->alloc_freqs_ = 0;
   d->alloc_ports_ = 0;
   d->frequency = 0;
   d->data = 0;

   return d;
}

/*************************************************************************************************/
void free_touchstone_file_data( struct touchstone_file_* d )
{
   if( d )
   {
      if( d->header )
         free((void*) d->header);
      free((void*)d );
   }
}
/*************************************************************************************************/
void free_network_parameter_data( struct network_parameters_* d )
{
   if( d )
   {
      if( d->frequency )
         free((void*)d->frequency);
      if( d->data ) {
         int i;
         for( i=0; i<d->alloc_freqs_; ++i ) {
            if( d->data[i] )
               free((void*)d->data[i]);
         }
         free((void*)d->data);
      }
      free((void*)d );
   }
}

/*************************************************************************************************/
/* high-level interface, touchstone_file_ and network_parameters_ structs will be created
    and initialized, they must be freed by the user when no longer needed
    the file_data_ struct will be created from the supplied file name (fname)
    touchstone_file_ and network_parameters_ will be filled
 */
int read_touchstone_file( const char* fname, struct touchstone_file_ ** td, struct network_parameters_** np )
{
   int e=0;
   struct file_data_ *fp = open_ts_file( fname );

   *td = create_touchstone_file_data();
   *np = create_network_parameter_data();
   if( !fp ) {
      fprintf( stderr, "%s: file not readable.\n", fname );
      return TSERR_FILENOTREADABLE;
   }
   else if( ! *td || ! *np ) {
      close_ts_file( fp );
      fprintf( stderr, "Memory allocation failure.\n" );
      return TSERR_MEMORYFAILURE;
   }

   e = get_touchstone_data( fp, *td, *np );
   if( e ) {
      fprintf( stderr, "%s: %s: at %d.\n", fname, get_ts_error_message(e), fp->lineno );
   }
   close_ts_file( fp );
   return e;
}

/*************************************************************************************************/
/* high-level interface for writing a touchstone file
 */
int write_touchstone_file( const char* fname, struct touchstone_file_ * td, struct network_parameters_ * np )
{
   FILE * f = fopen( fname, "w+" );
   int e = write_touchstone_raw( f, td, np, 0 );
   if( f ) fclose( f );
   return e;
}

/*************************************************************************************************/
/* lowish-level interface for writing a touchstone file, uses a user-supplied FILE pointer
    to write data
    the flags variable defines behaviors such as whether or not to write the header data
    and touchstone header
 */
int write_touchstone_raw( FILE* f, struct touchstone_file_ * td, struct network_parameters_ * np, unsigned flags )
{
   int i, e;

   if( !f )
      return TSERR_FILEWRITEERR;

   if( !(flags & TF_NoHeader) && td->header )
   {
      e = fprintf( f, "%s", td->header );
      if(e<0) return TSERR_FILEWRITEERR;
      if( td->header[strlen(td->header)-1] != '\n' ) {
         e = fprintf( f, "\n" );
         if(e<0) return TSERR_FILEWRITEERR;
      }
   }

   if( !(flags & TF_NoTouchstoneHeader) )
   {
      const char *fmt;
      switch( td->format )
      {
      case Touchstone_RI:
         fmt = "RI"; break;
      case Touchstone_DB:
         fmt = "DB"; break;
      case Touchstone_MA:
      default:
         fmt = "MA"; break;
      }
      e = fprintf( f, "# %s %c %s R %g\n", td->freq_str, td->param_type, fmt, td->rref );
      if(e<0) return TSERR_FILEWRITEERR;
   }

   fflush(f);

   for( i=0; i<np->n_freqs; ++i ) {
      e = write_touchstone_block( f, td, np, i );
      if( e<0 )
         return e;
   }

   fflush(f);
   return 0;
}

/*************************************************************************************************/
/* low-level interface for reading a touchstone file
    file_data_, touchstone_file_ and network_parameters_ structs
    must be probperly initialized by the user
    touchstone_file_ and network_parameters_ will be filled
 */
int read_ts_file( struct file_data_* fp, struct touchstone_file_ *td, struct network_parameters_ * np )
{
   if( !fp )
      return TSERR_FILENOTREADABLE;
   if( !td || !np )
      return TSERR_INVALIDARG;

   return get_touchstone_data( fp, td, np );
}

/*************************************************************************************************/
/* allocate a file_data_ struct and open the specified file with a FILE pointer */
struct file_data_* open_ts_file( const char* fname )
{
   struct file_data_* fp = (struct file_data_*) malloc( sizeof(struct file_data_) );
   if( !fp ) return NULL;
   fp->f = fopen(fname, "r");
   if( !fp->f ) {
      free((void*) fp);
      return NULL;
   }
   fp->fname = strdup( fname );
   fp->str = (char*) malloc( sizeof(char) * MAX_TSTONE_LINE_LENGTH );
   if( !fp->str ) {
      fclose( fp->f );
      free((void*) fp);
      return NULL;
   }
   fp->sz_str = MAX_TSTONE_LINE_LENGTH;
   fp->lineno = 0;
   return fp;
}

/*************************************************************************************************/
/* allocate a file_data_ struct using an already open FILE pointer */
struct file_data_* alloc_ts_file( FILE * f )
{
   if( !f ) return NULL;
   struct file_data_* fp = (struct file_data_*) malloc( sizeof(struct file_data_) );
   if( !fp ) return NULL;
   fp->f = f;
   fp->fname=strdup( "(unknown name)" );
   fp->str = (char*) malloc( sizeof(char) * MAX_TSTONE_LINE_LENGTH );
   if( !fp->str ) {
      free((void*) fp);
      return NULL;
   }
   fp->sz_str = MAX_TSTONE_LINE_LENGTH;
   fp->lineno = 0;
   return fp;
}

/*************************************************************************************************/
/* close the file, and dealloc the struct */
void close_ts_file( struct file_data_ * fp )
{
   if( fp )
   {
      if( fp->f )
         fclose( fp->f );
      if( fp->fname )
         free((void*)fp->fname);
      if( fp->str )
         free((void*)fp->str);
      free((void*) fp);
   }
}

/*************************************************************************************************/
/* dealloc the struct only (do not close the FILE pointer) */
void free_ts_file( struct file_data_ * fp )
{
   if( fp )
   {
      if( fp->fname )
         free((void*)fp->fname);
      if( fp->str )
         free((void*)fp->str);
      free((void*) fp );
   }
}

/*************************************************************************************************/
/* get the file state */
static struct file_state_ get_file_state( struct file_data_* file )
{
   struct file_state_ st;
   st.data = file;
   if( file ) {
      if( !file->f )
         st.offset = -1;
      else
         st.offset = ftell( file->f );
      st.lineno = file->lineno;
   }
   else {
      st.offset = -1;
      st.lineno = -1;
   }
   return st;
}

/*************************************************************************************************/
/* restore the file state */
static int restore_file_state( struct file_state_ st )
{
   if( !st.data || st.offset < 0 )
      return TSERR_INVALIDSTATE;
   if( fseek( st.data->f, st.offset, SEEK_SET ) )
      return TSERR_FILESEEKERR;
   st.data->lineno = st.lineno;
   return 0;
}

/*************************************************************************************************/
/* read a line of data */
static char * get_tstone_line( struct file_data_* file )
{
   if( fgets( file->str, file->sz_str-1, file->f ) ) {
      ++file->lineno;
      return file->str;
   }
   return NULL;
}


/*************************************************************************************************/
/* read the touchstone data line and set the values in the touchstone_file_ struct */
static int read_touchstone_header( char *str, struct touchstone_file_ *d )
{
   char freq[8], type[8], fmt[8];
   if( sscanf( str, "#%7s%7s%7s%*s%lf", freq, type, fmt, &d->rref ) != 4 ) return TSERR_FORMATSTRING;
   switch( *freq )
   {
   case 'T':
   case 't':
      d->freq_str = fstring_thz; d->fmult = 1.e12; break;
   case 'G':
   case 'g':
      d->freq_str = fstring_ghz; d->fmult = 1.e9; break;
   case 'M':
   case 'm':
      d->freq_str = fstring_mhz; d->fmult = 1.e6; break;
   case 'K':
   case 'k':
      d->freq_str = fstring_khz; d->fmult = 1.e3; break;
   case 'H':
   case 'h':
   default:
      d->freq_str = fstring_hz; d->fmult = 1.; break;
   }
   switch( *type )
   {
   case 't':
   case 'T':
      d->param_type = 'T'; break;
   case 'h':
   case 'H':
      d->param_type = 'H'; break;
   case 'y':
   case 'Y':
      d->param_type = 'Y'; break;
   case 'z':
   case 'Z':
      d->param_type = 'Z'; break;
   case 'a':
   case 'A':
      d->param_type = 'A'; break;
   case 's':
   case 'S':
   default:
      d->param_type = 'S'; break;
   }
   switch( *fmt )
   {
   case 'd':
   case 'D':
      d->format = Touchstone_DB; break;
   case 'r':
   case 'R':
      d->format = Touchstone_RI; break;
   case 'm':
   case 'M':
   default:
      d->format = Touchstone_MA; break;
   }
   if( d->rref < 1. || d->rref > 377. ) d->rref = 50.;

   return 0;
}

/*************************************************************************************************/
/* scan the file and read the header and touchstone data line
    also determine the number of frequncy points in the file
    and the number of ports that the data represents */
static int get_touchstone_data( struct file_data_* f, struct touchstone_file_ *d, struct network_parameters_ *np )
{
   struct file_state_ fs = get_file_state(f);
   struct file_state_ start = fs;
   char *str;
   char *ln;
   char *header_lines[MAX_HEADER_LINES];
   int hptr=0;
   int hlen=0;
   int count=0;
   int bsize=0;
   int e=0;
   int i;
   double lastf;

   if( !f->f ) {
      return TSERR_FILENOTREADABLE;
   }

   /* scan the file and read comments and touchstone header information */
   while( (str = get_tstone_line( f )) )
   {
      /* strip leading whitespace */
      ln = str;
      while( *ln == ' ' || *ln == '\t' || *ln == '\r' || *ln == '\n' ) ++ln;
      /* determine if this is a data line, comment line, touchstone header, or blank line */
      if( *ln == '!' ) {
         /* store the header comment */
         if( hptr < MAX_HEADER_LINES ) {
            header_lines[hptr] = strdup( str );
            if( !header_lines[hptr] ) {
               e = TSERR_MEMORYFAILURE;
               break;
            }
            hlen += strlen( str );
            ++hptr;
         }
      }
      else if( *ln == '#' ) {
         e = read_touchstone_header( ln, d );
         if( e ) break;
      }
      else if( strlen( ln ) == 0 ) {
         // blank lines are ignored
      }
      else if( strchr( "+-0123456789", *ln ) ) {
         // rewind the file to the start of this line
         e = restore_file_state( fs );
         // done reading header and touchstone info
         break;
      }
      else {
         // must be a formatting error
         // print a message to stderr ???
         e = TSERR_FILEFORMATERR;
         break;
      }
      fs = get_file_state( f );
   }

   /* check for errors */
   if( e ) {
      for( i=0; i<hptr; ++i )
         free((void*)header_lines[i]);
      return e;
   }

   /* create the header data string */
   if( hptr ) {
      if( d->header ) free((void*)d->header);
      d->header = (char*) malloc( sizeof(char) * (hlen+1) );
      if( !d->header ) {
         for( i=0; i<hptr; ++i )
            free((void*)header_lines[i]);
         return TSERR_MEMORYFAILURE;
      }
      *d->header = '\0';
      for( i=0; i<hptr; ++i ) {
         strcat( d->header, header_lines[i] );
         free((void*)header_lines[i]);
      }
   }
   else {
      if( d->header ) free((void*)d->header);
      d->header=0;
   }

   // "read" blocks of touchstone data
   //  in actuality the data is being discarded, but the block size
   //  and block count will be determined by this function
   while( 1 ) {
      e = read_touchstone_block( f, d, NULL, &bsize, &count, &lastf );
      if( e<0 )
         return e;  // error occured
      else if( e>0 )
         break;  // end of data reached
   }

   /* set some values in the network_parameters_ struct */
   np->n_freqs = count;
   np->n_ports = bsize;

   /* rewind the file pointer to the location it was when the function was entered */
   e = restore_file_state( start );
   if( e ) return e;

   /* allocate memory as needed */
   e = touchstone_alloc( np );
   if( e ) return e;

   /* read in the actual parameter data */
   count = 0;
   while( 1 ) {
      e = read_touchstone_block( f, d, np, &bsize, &count, &lastf );
      if( e<0 )
         return e;  // error occured
      else if( e>0 && count )
         break;  // end of data reached
   }

   if( count != np->n_freqs ) {
      return TSERR_MISMATCH;
   }

   return 0;
}

/*************************************************************************************************/
/* check to make sure that enough memory is allocated */
static int touchstone_alloc( struct network_parameters_ *d )
{
   int i;
   if( d->n_ports < 1 || d->n_freqs < 1 )
      return TSERR_EMPTYFILE;

   if( d->alloc_ports_ < d->n_ports )
   {
      /* first free memory allocated for parameters */
      for( i=0; i<d->alloc_freqs_; ++i )
         if(d->data[i]) free((void*)d->data[i]);
      /* if there is not enough space for the frequencies, reallocate those arrays */
      if( d->alloc_freqs_ < d->n_freqs ) {
         if( d->data ) free((void*)d->data);
         if( d->frequency ) free((void*)d->frequency);
         d->data = (struct parameter_complex_data_ **) malloc( sizeof(struct parameter_complex_data_ *) * d->n_freqs );
         d->frequency = (double *) malloc( sizeof(double) * d->n_freqs );

         if( !d->data || !d->frequency )
            return TSERR_MEMORYFAILURE;
         memset( d->data, 0, sizeof(struct parameter_complex_data_ *) * d->n_freqs );
         d->alloc_freqs_ = d->n_freqs;
      }
      /* now reallocate space for the parameters */
      for( i=0; i<d->alloc_freqs_; ++i ) {
         d->data[i] = (struct parameter_complex_data_ *) malloc( sizeof(struct parameter_complex_data_) * d->n_ports * d->n_ports );
         if( !d->data[i] )
            return TSERR_MEMORYFAILURE;
      }
      d->alloc_ports_ = d->n_ports;
   }
   else if( d->alloc_freqs_ < d->n_freqs )
   {
      struct parameter_complex_data_ **tmp = (struct parameter_complex_data_ **) malloc( sizeof(struct parameter_complex_data_ *) * d->n_freqs );
      if( !tmp )
         return TSERR_MEMORYFAILURE;
      memset( tmp, 0, sizeof(struct parameter_complex_data_ *) * d->n_freqs );
      for( i=0; i<d->alloc_freqs_; ++i )
         tmp[i] = d->data[i];
      if( d->data ) free((void*)d->data);
      d->data = tmp;
      /* allocate new parameter memory for the added parameters */
      for( i=d->alloc_freqs_; i<d->n_freqs; ++i ) {
         d->data[i] = (struct parameter_complex_data_ *) malloc( sizeof(struct parameter_complex_data_) * d->n_ports * d->n_ports );
         if( !d->data[i] )
            return TSERR_MEMORYFAILURE;
      }
      /* need to reallocate the frequency */
      if( d->frequency ) free((void*)d->frequency);
      d->frequency = (double *) malloc( sizeof(double) * d->n_freqs );
      if( !d->frequency )
         return TSERR_MEMORYFAILURE;

      d->alloc_freqs_ = d->n_freqs;
      d->alloc_ports_ = d->n_ports;
   }
   return 0;
}

/*************************************************************************************************/
/* read floating point values from a string */
static int read_floats( char *str, double *vals )
{
   char *p = str;
   char *p2;
   int i=0;

   while( i<MAX_TSTONE_FLOATS_PER_LINE ) {
      vals[i] = strtod( p, &p2 );
      if( p2 == p )
         return i;
      ++i;
      p = p2;
   }
   return i;
}

/*************************************************************************************************/
/* determine the touchstone block size */
static int determine_touchstone_block_size( struct file_data_* f )
{
   struct file_state_ fs = get_file_state(f);
   int bs;
   int fc=0;
   int n;
   char *str;
   double vals[MAX_TSTONE_FLOATS_PER_LINE];
   double root;

   while(1)
   {
      str = get_tstone_line( f );
      if( !str )
         return TSERR_INVALIDNUMPORTS;
      n = read_floats( str, vals );
      if( n ) {
         if( !fc ) {
            /* the first line of the block should have an odd number of floats */
            if( !(n%2) )
               return TSERR_INVALIDNUMPORTS;
         }
         else {
            /* if this line has an odd number of floats it is part of the
               next data block */
            if( n%2 ) break;
         }
         fc += n;
      }
   }

   /* calculate the block size based on the number of floats read */
   if( !(fc%2) || fc < 3 )
      /* total float count must be odd and at least 3 */
      return TSERR_INVALIDNUMPORTS; 
   root = sqrt( ((fc-1)/2) );
   bs = (int) nearbyint( root );
   if( 2*bs*bs+1 != fc )
      return TSERR_INVALIDNUMPORTS;

   n = restore_file_state( fs );
   if( n ) return n;
   return bs;
}

/*************************************************************************************************/
/* read a block of touchstone data - this is the workhorse of reading a touchstone file
    return status is 0 for success, 1 for the end of a touchstone data set and negative
    for all errors
 */
static int read_touchstone_block( struct file_data_* f, struct touchstone_file_ *d, struct network_parameters_ *np, int *bsize, int* bptr, double* last_freq )
{
   struct file_state_ fs = get_file_state(f);
   double vals[MAX_TSTONE_FLOATS_PER_LINE];
   int count=0;
   int needed_floats=(*bsize)*(*bsize)*2+1;
   int dp=0;
   char *str;
   char *ln;
   double freq;
   int r, i;
   static const double deg_to_rad = M_PI / 180.;

   if( np ) {
      /* do some error checking */
      if( *bptr >= np->alloc_freqs_ || *bptr >= np->n_freqs )
         return 1;  // watch for data overruns (this really shouldn't be a problem)
      else if( *bsize != np->n_ports )
         return TSERR_BLOCKMISMATCH;
   }
   else if( *bsize < 1 ) {
      /* need to determine the block size */
      *bsize = determine_touchstone_block_size( f );
      if( *bsize < 0 )
         return (*bsize);
      needed_floats=(*bsize)*(*bsize)*2+1;
   }

   while( count < needed_floats )  /* block read loop */
   {
      str = get_tstone_line( f );
      if( !str ) {
         if( count )
            /* EOF was hit with an imcomplete block */
            return TSERR_INCOMPLETEBLOCK;
         return 1;
      }
      ln = str;
      while( *ln == ' ' || *ln == '\t' || *ln == '\r' || *ln == '\n' ) ++ln;
      if( *ln == '#' ) {
         if( count )
            /* the block read was incomplete */
            return TSERR_INCOMPLETEBLOCK;
         if( *bptr ) {
            /* if we have already read in data then rewind the file pointer
            since this must be a new set of data */
            dp = restore_file_state(fs);
            if( dp ) return dp;
         }
         return 1;
      }
      else if( *ln == '!' ) {
         if( count ) {
            /* comments are not allowed in the middle
              of a block - they can exist between blocks though */
            return TSERR_BLOCKFORMATERR;
         }
      }

      r = read_floats( str, vals );
      if( r )
      {
         if( ((r%2 && count) || (!count && !(r%2))) ) {
            /* this line has an invalid number of floats
               either it has an odd number and we are still
               in the middle of reading a block or it has an even
               number and this is the first line of a block */
            return TSERR_BLOCKFORMATERR;
         }

         if( !count ) {
            if( !(r%2) )
               /* this line should have an odd number of floats */
               return TSERR_BLOCKFORMATERR;

            freq = vals[0]*d->fmult;
            /* check to see if we hit another data set */
            if( *bptr && freq < *last_freq ) {
               /* we did hit another data set, rewind the file */
               dp = restore_file_state(fs);
               if( dp ) return dp;
               return 1;
            }
         }
         else {
            if( r%2 )
               /* this line should have an even number of floats */
               return TSERR_BLOCKFORMATERR;
         }


         count += r;
         if( count > needed_floats )
            /* we read too many values for the block !!! */
            return TSERR_BLOCKFORMATERR;


         /* store data in the network_parameters_ struct
              if it NULL, the data just gets thrown away */
         if( np )
         {
            for( i=0; i<r; ++i, ++dp ) {
               if( !dp )
                  np->frequency[*bptr] = freq;
               else {
                  if( dp%2 )
                     np->data[*bptr][(dp-1)/2].d[0] = vals[i];
                  else
                     np->data[*bptr][(dp-1)/2].d[1] = vals[i];
               }
            }
         }
      }
   }  /* block read complete (correct number of floats read) */

   /* convert the data to real/imag complex format if it is not there already */
   if( np )
   {
      double t;
      switch( d->format )
      {
      case Touchstone_MA:
         for( i=0; i<(*bsize)*(*bsize); ++i ) {
            t = np->data[*bptr][i].d[0];
            np->data[*bptr][i].d[0] = t * cos( np->data[*bptr][i].d[1] * deg_to_rad );
            np->data[*bptr][i].d[1] = t * sin( np->data[*bptr][i].d[1] * deg_to_rad );
         }
         break;

      case Touchstone_DB:
         for( i=0; i<(*bsize)*(*bsize); ++i ) {
            t = pow( 10., 0.05 * np->data[*bptr][i].d[0] );
            np->data[*bptr][i].d[0] = t * cos( np->data[*bptr][i].d[1] * deg_to_rad );
            np->data[*bptr][i].d[1] = t * sin( np->data[*bptr][i].d[1] * deg_to_rad );
         }
         break;

      case Touchstone_RI:  /* already in the right format */
      default:
         break;
      }

      /***** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ******/
      /* fix the data order for 2-port data files  */
      /*  (why is touchstone format so DUMB???!!!) */
      if( np->n_ports == 2 ) {
         struct parameter_complex_data_ t = np->data[*bptr][1];
         np->data[*bptr][1] = np->data[*bptr][2];
         np->data[*bptr][2] = t;
      }
      /***** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ******/
   }

   /* successful block read, increment block pointer */
   ++(*bptr);
   /* update the last_freq pointer */
   *last_freq = freq;
   /* return success */
   return 0;
}

/*************************************************************************************************/
/* write a block of touchstone data - this is the workhorse of writing a touchstone file
    return status is 0 for success and negative for all errors
 */
static int write_touchstone_block( FILE* f, struct touchstone_file_ * td, struct network_parameters_ * np, int ptr )
{
   int cpx_to_write = np->n_ports*np->n_ports;
   int idx, count;
   char fmt1[32];
   char fmt2[32];
   char fmt3[32];
   double c1, c2;
   int e;
   static const double rad_to_deg = 180. / M_PI;

   if( cpx_to_write < 1 )
      return TSERR_INVALIDNUMPORTS;

   /* create the format strings
       fmt1 is used to write the frequency
       fmt2 is used to append a complex pair to the line 
       fmt3 is used to start a new line, indent, then write a complex pair
    */
   switch( td->num_format )
   {
   case FP_fixed:
      sprintf( fmt1, "%%.%df", td->precision );
      sprintf( fmt2, "%c%%.%df%c%%.%df", td->seperator, td->precision, td->seperator, td->precision );
      sprintf( fmt3, "\n%s%%.%df%c%%.%df", td->indent, td->precision, td->seperator, td->precision );
      break;
   case FP_scientific:
      sprintf( fmt1, "%%.%de", td->precision );
      sprintf( fmt2, "%c%%.%de%c%%.%de", td->seperator, td->precision, td->seperator, td->precision );
      sprintf( fmt3, "\n%s%%.%de%c%%.%de", td->indent, td->precision, td->seperator, td->precision );
      break;
   case FP_auto:
   default:
      sprintf( fmt1, "%%.%dg", td->precision );
      sprintf( fmt2, "%c%%.%dg%c%%.%dg", td->seperator, td->precision, td->seperator, td->precision );
      sprintf( fmt3, "\n%s%%.%dg%c%%.%dg", td->indent, td->precision, td->seperator, td->precision );
      break;
   }


   /* write the frequency */
   e = fprintf( f, fmt1, np->frequency[ptr] );
   if( e<0 )
      return TSERR_FILEWRITEERR;

   /* write the data in the correct format */
   for( count=0; count<cpx_to_write; ++count )
   {
      /***** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ******/
      /* fix the data order for 2-port data files  */
      /*  (why is touchstone format so DUMB???!!!) */
      idx = count;
      if( np->n_ports == 2 && count == 1 ) ++idx;
      else if( np->n_ports == 2 && count == 2 ) --idx;
      /***** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ******/

      switch( td->format )
      {
      case Touchstone_RI:
         c1 = np->data[ptr][idx].d[0];
         c2 = np->data[ptr][idx].d[1];
         break;
      case Touchstone_DB:
         c1 = 20. * log10( sqrt( np->data[ptr][idx].d[0]*np->data[ptr][idx].d[0] + np->data[ptr][idx].d[1]*np->data[ptr][idx].d[1] ) + 1.e-100 );
         c2 = (!np->data[ptr][idx].d[0] && !np->data[ptr][idx].d[1]) ? 0. : atan2( np->data[ptr][idx].d[1], np->data[ptr][idx].d[0] ) * rad_to_deg;
         break;
      case Touchstone_MA:
      default:
         c1 = sqrt( np->data[ptr][idx].d[0]*np->data[ptr][idx].d[0] + np->data[ptr][idx].d[1]*np->data[ptr][idx].d[1] );
         c2 = (!np->data[ptr][idx].d[0] && !np->data[ptr][idx].d[1]) ? 0. : atan2( np->data[ptr][idx].d[1], np->data[ptr][idx].d[0] ) * rad_to_deg;
         break;
      }

      if( count && np->n_ports > 2 && !(count%4) ) {
         /* create a new line and use the specified indent string
             to indent the data (fmt3 definition) */
         e = fprintf( f, fmt3, c1, c2 );
         if( e<0 )
            return TSERR_FILEWRITEERR;
      }
      else {
         /* use fmt2 */
         e = fprintf( f, fmt2, c1, c2 );
         if( e<0 )
            return TSERR_FILEWRITEERR;
      }
   }

   /* trailing newline */
   e = fprintf( f, "\n" );
   if( e<0 )
      return TSERR_FILEWRITEERR;

   return 0;
}




