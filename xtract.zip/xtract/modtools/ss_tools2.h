#ifndef SS_TOOLS_H_DEFINED
#define SS_TOOLS_H_DEFINED

#include <cmplxlib.h>
#include <optimize4.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _NETLIST_DEF
 {
 int type;            // element type
 char id[10];            // id string
 unsigned nodes[10];     // node connections
 double value[10];      // element values
 unsigned index[10];       // gradient array position index
 struct _NETLIST_DEF *next;  // linked list pointer
 } NETLIST;

#define Netlist_UNKNOWN  0
#define Netlist_R        1
#define Netlist_G        2
#define Netlist_C        3
#define Netlist_L        4
#define Netlist_SRL      5
#define Netlist_SRC      6
#define Netlist_TCAP     7
#define Netlist_VCCS     8

#define UNKNOWN_DEVICE  0
#define FET_DEVICE      1
#define HBT_DEVICE      2

#define STATIC_COMPONENT   ((unsigned) -1)

typedef struct
 {
 double freq;
 COMPLEX s[4];
 double k;
 double MAG;
 double b;
 } S_2PORT;

typedef struct
   {
   double vds,ids,vgs,igs;
   int dtype;
   } S_BIAS;


// create a square 2-D COMPLEX matrix
extern COMPLEX **allocate_2d_complex_matrix (unsigned size);

// free the COMPLEX matrix created by the above function
extern void free_matrix (COMPLEX **matrix, unsigned size);

// complex matrix reduction by gaussian elimination, performed in place
extern void complex_matrix_reduction (COMPLEX **x, unsigned xsize, unsigned reduced_size);

// solve a [Y] matrix for 2-port [S] parameters, ym reduction is done in place
extern void solve_y_for_2port_s (COMPLEX **y, COMPLEX *s, unsigned ysize);

// two-port [Y] matrix solution for ym and ym(transpose)
// p, q, pa, and qa are the output vectors of the node voltage solutions
// ym is reduced in place
extern void twoport_adjoint_solution (COMPLEX **y, COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, unsigned ysize);

// returns the needed size of a [Y]-matrix to optimize/model the passed netlist
extern unsigned determine_y_size (NETLIST *nlist);

// automatically perform a small-signal optimization on the PARAM_STRUCT p
// where the nlist.index[] in this case is used to determine the position of each
//  nlist.value[] within the PARAM_STRUCT
extern int small_signal_optimizer (NETLIST *nlist, OPT_PARAMETER *p, unsigned n_params, S_2PORT *sp,
                            unsigned numf, unsigned max_iter, double *weights, unsigned long flags,
			    double *err_out);

// return 2-port S-parameters from the given netlist
extern int small_signal_model (NETLIST *nlist, double freq, COMPLEX *s);

// generate a netlist pointer for a single component
extern NETLIST *netlist_component (int type, ...);

// prepare a linked-list netlist from a NULL terminated list of netlist component pointers
// start is a meaningless integer used to determine the starting address of the
// variable argument list
extern NETLIST *va_prepare_netlist (int start, ...);

// prepare a linked-list netlist from an array of netlist component pointers
extern NETLIST *prepare_netlist (NETLIST *nlist[], int szNlist);

// free a netlist generated with one of the above two functions
extern void free_netlist (NETLIST *nlist);

// read [S]-parameters from a file
extern int read_s_from_file (char *filename, S_2PORT *sp, S_BIAS *bias, int sizeofsp);

// write a netlist representation to a file
extern int write_netlist_to_file (char *fname, NETLIST *nlist);

#ifdef __cplusplus
}
#endif

#endif  /* SS_TOOLS_H_DEFINED */

