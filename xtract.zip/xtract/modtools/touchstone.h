#ifndef TOUCHSTONE_DATA_FILES
#define TOUCHSTONE_DATA_FILES

#ifdef __cplusplus
extern "C" {
#endif

/* complex data storage */
struct parameter_complex_data_ {
   double d[2];  // real = d[0], imag = d[1]
};

/* network parameters structure */
struct network_parameters_ {
   int n_freqs;
   int n_ports;
   int alloc_freqs_;
   int alloc_ports_;
   double *frequency;
   struct parameter_complex_data_ **data;
};

/* touchstone data format */
enum TouchstoneFormat {
   Touchstone_MA=0,
   Touchstone_RI,
   Touchstone_DB
};

/* used to set the output floating-point format */
enum NumberFormat {
   FP_auto=0,
   FP_fixed,
   FP_scientific
};

/* flags, used by write_touchstone_raw() */
#define TF_NoHeader                (1<<0)
#define TF_NoTouchstoneHeader      (1<<1)

/* touchstone file structure */
struct touchstone_file_ {
   // file header
   char *header;
   // touchstone header info
   const char *freq_str;   // DO NOT SET TO NULL
   double fmult;
   char param_type;
   enum TouchstoneFormat format;
   double rref;
   // other format parameters
   //  used for writing
   char seperator;
   const char *indent;  // DO NOT SET TO NULL
   int precision;
   enum NumberFormat num_format;
};

/* file data, used mostly internally to read touchstone files
   main reason for use is to store the line number for error messages
 */
struct file_data_ {
   char *fname;  // caution, can be NULL
   FILE *f;
   char *str;
   int sz_str;
   int lineno;
};

/* get the error message for a return code */
const char * get_ts_error_message( int err_code );

/* create/free touchstone_file_ structures */
struct touchstone_file_* create_touchstone_file_data( void );
void free_touchstone_file_data( struct touchstone_file_* );

/* create/free network_parameters_ structures */
struct network_parameters_* create_network_parameter_data( void );
void free_network_parameter_data( struct network_parameters_* );

/* high-level interface to read a touchstone data file
   the touchstone_file_ and network_parameters_ pointers are
   allocated automatically and returned
   these pointers must be freed using the appropriate function
   to prevent memory leaks once they are not longer needed
   - the pointers must be freed even if the return value is non-zero
   - the first argument is the file name of the touchstone data file
 */
int read_touchstone_file( const char* , struct touchstone_file_ **, struct network_parameters_** );

/* write a touchtone file either by supplying a filename or an already opened FILE pointer
    the flags parameter in the second version can control the write behavior
    supplying a value of 0 for this parameter result in the default behavior
    both functions rely on settings in the touchstone_file_ struct to control
    the touchstone format, numerical precsion, etc
 */
int write_touchstone_file( const char* fname, struct touchstone_file_ * td, struct network_parameters_ * np );
int write_touchstone_raw( FILE* f, struct touchstone_file_ * td, struct network_parameters_ * np, unsigned flags );

/********* low-level interface *********/

/* create a file_data_ structure from a file name,
   returns NULL on failure (file not found/readable or memory allocation)
 */
struct file_data_* open_ts_file( const char* fname );

/* create a file_data_ structure from a passed FILE pointer
   retuns NULL on failure (invalid FILE pointer or memory allocation)
 */
struct file_data_* alloc_ts_file( FILE * f );

/* close the FILE pointer and free the file_data_ struct */
void close_ts_file( struct file_data_ * fp );

/* free the file_data_ struct only (FILE pointer is left open) */
void free_ts_file( struct file_data_ * fp );

/* low-level interface to read touchstone files
    the user must allocate all of the structs using the appropriate functions
    returns 0 on success, non-zero on any errors
    - very useful when multiple touchstone datasets are located in a single file
       since the high-level function will only read the first dataset
    - also useful for custom error handling since the high-level version
       writes messages to stderr
 */
int read_ts_file( struct file_data_* fp, struct touchstone_file_ *td, struct network_parameters_ * np );

/* some typedefs to make type names shorter */
typedef struct network_parameters_ NetworkParams;
typedef struct touchstone_file_ Touchstone;
typedef struct file_data_ TSFile;

#ifdef __cplusplus
}
#endif

#endif   /* TOUCHSTONE_DATA_FILES */
