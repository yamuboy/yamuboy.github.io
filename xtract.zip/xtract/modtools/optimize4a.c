#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <signal.h>
#include <setjmp.h>
#include "optimize4.h"
#ifdef WIN32
#include <float.h>
#define isnan  _isnan
#endif

/* definitions */

#define MIN_VALUE      (1.e-30)
#define MAX_GRADIENT   (1.e20)

#define ERR_NO_MEM        (-100)
#define ERR_FUNCTION      (-101)
#define ERR_NO_PARAMS     (-102)
#define ERR_NO_ERF        (-103)
#define ERR_NO_FUNCTION   (-104)
#define ERR_INVALID_ARG   (-105)
#define ERR_GRADIENT_EXT  (-106)
#define ERR_WRONGMODE     (-107)
#define ERR_NAN           (-108)

#define OPT_DONE      1

/* global error variable */

static int global_error = 0;
static int global_intr_flag = 0;
static jmp_buf global_jmpbuf;

/**************************************************************************/
/**************************************************************************/

static int sdir_reset_flag (OPTIMIZE *opt, unsigned iter)
   {
   if( !iter || !opt->reset_interval )
      return 0;

   return ( (iter % opt->reset_interval) == 0 );
   }

/**************************************************************************/
/**************************************************************************/

static void print_error_values( OPTIMIZE *opt, int iter )
   {
   static char *default_format = "\t%.5g";

   if( opt->flags & OPT_VERBOSE )
      {
      fprintf (stderr,"%-5d", iter);

      if( opt->flags & OPT_SINGLE_ERROR )
         {
         if( *opt->print_format )
            fprintf( stderr, opt->print_format, opt->current_total_error );
         else
            fprintf( stderr, default_format, opt->current_total_error );
         }
      else
         {
         unsigned i;
         for( i=0; i<opt->n_errors; i++ )
            {
            if( *opt->print_format )
               fprintf( stderr, opt->print_format, opt->current_error[i] );
            else
               fprintf( stderr, default_format, opt->current_error[i] );
            }
         }
      fprintf (stderr,"\n");
      }
   }
      
/**************************************************************************/
/**************************************************************************/

static double opt_function( OPTIMIZE *opt, double *pl )
   {
   double x = 0.0;
   unsigned i;
   
   /* copy the parameters into the list sent to the error function */
   for( i=0; i<opt->n_params; i++ )
      {
      if( isnan( pl[i] ) ) 
         {
         /* this is bad, very bad, return NaN and hope for recovery */
         return pl[i];
         }

      // check to make sure that the parameter falls within the min/max range
      if( opt->param_flag[i] )
         {
         if( pl[i] < opt->params[i].min )
            pl[i] = opt->function_p_list[i] = opt->params[i].min;
         else if( pl[i] > opt->params[i].max )
            pl[i] = opt->function_p_list[i] = opt->params[i].max;
         else
            opt->function_p_list[i] = pl[i];         
         }
      else
         opt->function_p_list[i] = opt->params[i].nom;
      }

   // set the error vector values to zero
   for( i=0; i<opt->n_errors; i++ )
      opt->func_err[i] = 0.;

   // call the error function
   if( opt->function( opt->function_p_list, opt->function_data, opt->func_err, opt->n_errors ) )
      longjmp( global_jmpbuf, ERR_FUNCTION );
   
   /* weight the errors and compute the total function error */
   for( i=0; i<opt->n_errors; i++ )
      {
      if( opt->weights )
         opt->func_err[i] = fabs( opt->func_err[i]*opt->weights[i] );
      else
         opt->func_err[i] = fabs( opt->func_err[i] );
      x += opt->func_err[i];
      }
   
   return x;
   }

/**************************************************************************/
/**************************************************************************/

static void compute_gradients( OPTIMIZE *opt )
   {
   unsigned i,j;
   
   /* copy the current gradients for memory */
   for( i=0; i<opt->n_params; i++ )
      for( j=0; j<opt->n_errors; j++ )
         opt->old_grads[i][j] = opt->grads[i][j];

   if( opt->gradients )
      {
      /* external gradient function supplied */
      if( opt->gradients( opt->p_list, opt->gradient_data, opt->grads, opt->n_params, opt->n_errors, opt->param_flag ) )
         longjmp( global_jmpbuf, ERR_GRADIENT_EXT );
      }
   
   else
      {
      /* otherwise do numerical gradients */
      double *error_hi = opt->temp_error1;
      double *error_lo = opt->temp_error2;
      double delta,pval_lo,pval_hi,interval,temp;

      /* copy the current parameter values into a temporary parameter list */
      for( i=0; i<opt->n_params; i++ )
         opt->temp_pl[i] = opt->p_list[i];

      for( i=0; i<opt->n_params; i++ )
         {
         /* check to see if this a parameter that we need to calculate a gradient for */
         if( !opt->param_flag[i] )
            continue;

         /* calculate delta based on the specified optimization range */
         delta = opt->numerical_delta * (opt->params[i].max - opt->params[i].min);
         temp = opt->temp_pl[i];

         /* do the high side numerical delta */
         if ( !(opt->flags & LOW_SIDE_GRADIENT) ||
            ((opt->flags & LOW_SIDE_GRADIENT) && (temp <= opt->params[i].min)) )
            {
            opt->temp_pl[i] = temp + delta;
            opt_function( opt, opt->temp_pl );

            for( j=0; j<opt->n_errors; j++ )
               error_hi[j] = opt->func_err[j];
            pval_hi = opt->temp_pl[i];
            }
         else
            {
            pval_hi = temp;
            for( j=0; j<opt->n_errors; j++ )
               error_hi[j] = opt->current_error[j];
            }

         /* do the low side numerical delta */
         if ( !(opt->flags & HIGH_SIDE_GRADIENT) ||
            ((opt->flags & HIGH_SIDE_GRADIENT) && (temp >= opt->params[i].max)) )
            {
            opt->temp_pl[i] = temp - delta;
            opt_function( opt, opt->temp_pl );

            for( j=0; j<opt->n_errors; j++ )
               error_lo[j] = opt->func_err[j];
            pval_lo = opt->temp_pl[i];
            }
         else
            {
            pval_lo = temp;
            for( j=0; j<opt->n_errors; j++ )
               error_lo[j] = opt->current_error[j];
            }

         interval = pval_hi - pval_lo;

         /* use negative gradient */
         for( j=0; j<opt->n_errors; j++ )
            opt->grads[i][j] = (error_lo[j] - error_hi[j]) / (pval_hi - pval_lo);

         /* reset the value that we changed to do the gradients */
         opt->temp_pl[i] = temp;
         }
      }

   /* protect gradients from numerical overflow */
   for( i=0; i<opt->n_params; i++ )
      {
      if( !opt->param_flag[i] )
         continue;

      for( j=0; j<opt->n_errors; j++ )
         {
         if( isnan( opt->grads[i][j] ) )
            {
            opt->grads[i][j] = 0.0;
            if( opt->flags & OPT_VERBOSE )
               fprintf( stderr, "WARNING: NaN encountered in gradient. Parameter '%s', index %u, value %.3e.\n",opt->params[i].name,i,opt->p_list[i] );
            }
         else if( fabs( opt->grads[i][j] ) > MAX_GRADIENT )
            {
            if( opt->grads[i][j] < 0. )
               opt->grads[i][j] = -MAX_GRADIENT;
            else
               opt->grads[i][j] = MAX_GRADIENT;
            }
         }
      }
   }

/**************************************************************************/
/**************************************************************************/

static void compute_search_dirs( OPTIMIZE *opt, unsigned iter )
   {
   double beta = 0.0;
   unsigned i,j;

   /* zero the search direction vector if this is the first iteration */
   if( iter <= 1 )
      {
      for( i=0; i<opt->n_params; i++ )
         opt->s_dirs[i] = 0.;
      }

   /* find beta for iterations greater than 1 */
   if( (iter > 1) && !sdir_reset_flag (opt, iter) && (opt->maximum_beta > 0.0) )
      {
      double x1 = 0.0;
      double x2 = 0.0;
      for (i = 0; i < opt->n_params; ++i)
         {
         if (opt->param_flag[i])
            {
            double x3 = 0.0;
            double x4 = 0.0;

            for ( j=0; j<opt->n_errors; j++ )
               {
               if( opt->weights )
                  {
                  x3 += opt->old_grads[i][j] * opt->weights[j];
                  x4 += opt->grads[i][j] * opt->weights[j];
                  }
               else
                  {
                  x3 += opt->old_grads[i][j];
                  x4 += opt->grads[i][j];
                  }
               }

            x1 += x3*x3;
            x2 += x4*x4;
            }
         }
      beta = fabs( x2/x1 );
      }

   if( isnan (beta) )
      beta = 0.0;
   else if( beta > opt->maximum_beta )
      beta = opt->maximum_beta;

   // compute the search direction
   for( i=0; i < opt->n_params; i++ )
      {
      if( opt->param_flag[i] )
         {
         double x=0.0;
         opt->s_dirs[i] *= beta;
         for( j=0; j<opt->n_errors; j++ )
            {
            if( opt->weights )
               x += opt->grads[i][j] * opt->weights[j];
            else
               x += opt->grads[i][j];
            }
         opt->s_dirs[i] += x;
         }
      }
   }
   
/**************************************************************************/
/**************************************************************************/

static int perform_line_search( OPTIMIZE *opt )
   {
   double alpha;
   double x1,x2,x3,y1,y2,y3,z1;
   int repeat, max_grad;
   unsigned i,j;
   unsigned k = 0;

   /* set the values of the temporary parameter list */
   for( i=0; i<opt->n_params; i++ )
      opt->temp_pl[i] = opt->p_list[i];

   /* find the parameter with the largest s_dir (gradient) */
   for( i=0, max_grad=-1, x1=0.; i<opt->n_params; i++ )
      {
      if( opt->param_flag[i] )
         {
         x2 = fabs( opt->s_dirs[i] );
         if( x2 > x1 )
            {
            x1 = x2;
            max_grad = i;
            }
         }
      }

   if( max_grad < 0 )
      {
      if( opt->flags & OPT_VERBOSE )
         fprintf (stderr,"WARNING: All gradients are zero in line search.\n");
      return OPT_DONE;
      }

   alpha = opt->alpha_numerator * (opt->params[max_grad].max - opt->params[max_grad].min) / x1;
   
   /* reduce alpha until the function error decreases */
   y1 = opt->current_total_error;
   x1 = 0.;
   j = 0;
   do {
      for( i=0; i<opt->n_params; i++ )
         if( opt->param_flag[i] )
            opt->temp_pl[i] = opt->p_list[i] + alpha * opt->s_dirs[i];

      y2 = opt_function (opt, opt->temp_pl);
      
      if( (y2 > y1) || isnan(y2) )
         {
         y2 = y1 + 1.0;  /* make sure y2 > y1 in the case of y2 = NaN */
         alpha *= 0.25;
         }

      if( (fabs(alpha) < MIN_VALUE) || (++j > 10) )
         {
         if( opt->flags & OPT_VERBOSE )
            fprintf (stderr,"WARNING: Optimization appears to be stuck.\n");
         return OPT_DONE;
         }
      }
   while( y2 > y1 );
   x2 = alpha;
   
   /* perform the line search */
   do {
      repeat = 0;
      x3 = x2 + alpha;
      for( i=0; i<opt->n_params; i++ )
         if( opt->param_flag[i] )
            opt->temp_pl[i] = opt->p_list[i] + x3 * opt->s_dirs[i];
      y3 = opt_function( opt, opt->temp_pl );
      if( isnan (y3) )
         {
         /* revert to the x2 parameter values */
         for( i=0; i<opt->n_params; i++ )
            if( opt->param_flag[i] )
               opt->p_list[i] += x2 * opt->s_dirs[i];
         opt->current_total_error = opt_function( opt, opt->p_list );
         for( j=0; j<opt->n_errors; j++ )
            opt->current_error[j] = opt->func_err[j];
         return 0;
         }
      
      if( (y3 < y2) && (++k < opt->max_search_segments) )
         {
         y1 = y2;
         x1 = x2;
         y2 = y3;
         x2 = x3;
         repeat=1;
         }
      }
   while( repeat );
   
   /* now the local minimum is bounded between alpha=x1 and alpha=x3
        with alpha=x2 as the minimum, do a quadratic fit to find the optimum alpha
    */
   alpha = 0.5*(x1 + x2 + (y1-y2)*(x3-x1)*(x3-x2)/(x1*(y2-y3) + x2*(y3-y1) + x3*(y2-y1)));
   
   /* calculate the resulting error from the quadratically fit alpha */
   for( i=0; i<opt->n_params; i++ )
      if( opt->param_flag[i] )
         opt->temp_pl[i] = opt->p_list[i] + alpha * opt->s_dirs[i];
   z1 = opt_function (opt, opt->temp_pl);

   /* check if the new error is better */
   if( !isnan (z1) && (z1 < y2) )
      {
      for( i=0; i<opt->n_params; i++ )
         if( opt->param_flag[i] )
            opt->p_list[i] = opt->temp_pl[i];
      opt->current_total_error = z1;
      for( j=0; j<opt->n_errors; j++ )
         opt->current_error[j] = opt->func_err[j];
      }
   else
      {
      /* revert to the x2 value of alpha */
      for( i=0; i<opt->n_params; i++ )
         if( opt->param_flag[i] )
            opt->p_list[i] += x2 * opt->s_dirs[i];
      opt->current_total_error = opt_function( opt, opt->p_list );
      for( j=0; j<opt->n_errors; j++ )
         opt->current_error[j] = opt->func_err[j];
      }

   return 0;
   }
   
/**************************************************************************/
/**************************************************************************/

static int sngl_param_line_search( OPTIMIZE *opt )
   {
   double alpha;
   double x1,x2,x3,y1,y2,y3,z1;
   int repeat;
   unsigned i,j;
   unsigned k = 0;

   /* set the values of the temporary parameter list */
   for( i=0; i<opt->n_params; i++ )
      opt->temp_pl[i] = opt->p_list[i];

   /* for each optimizable parameter, find alpha and find the optimium value */
   for( i=0; i<opt->n_params; i++ )
      {
      if( !opt->param_flag[i] || opt->s_dirs[i] == 0. )
         continue;

      alpha = opt->alpha_numerator * (opt->params[i].max - opt->params[i].min) / fabs( opt->s_dirs[i] );
      /* set alpha to a maximum of 0.05% of the parameter range */
      if( alpha > 0.005*(opt->params[i].max - opt->params[i].min) )
         alpha = 0.005*(opt->params[i].max - opt->params[i].min);

      /* reduce alpha until the function error decreases */
      y1 = opt->current_total_error;
      x1 = 0.0;
      j = 0;
      do {
         opt->temp_pl[i] = opt->p_list[i] + alpha * opt->s_dirs[i];
         y2 = opt_function( opt, opt->temp_pl );
         if( isnan(y2) )
            break;
         else if( y2 > y1 )
            alpha *= 0.25;

         if( alpha < MIN_VALUE || ++j > 10 )
            break;
         }
      while( y2 > y1 );
      x2 = alpha;

      /* unable to optimize this parameter */
      if( isnan( y2 ) || alpha < MIN_VALUE )
         continue;

      /* perform the parameter line search */
      do {
         repeat = 0;
         x3 = x2 + alpha;
         opt->temp_pl[i] = opt->p_list[i] + x3 * opt->s_dirs[i];

         y3 = opt_function (opt, opt->temp_pl);
         if( isnan (y3) )
            {
            opt->p_list[i] += x2 * opt->s_dirs[i];
            opt->temp_pl[i] = opt->p_list[i];
            opt->current_total_error = opt_function( opt, opt->p_list );
            for( j=0; j<opt->n_errors; j++ )
               opt->current_error[j] = opt->func_err[j];
            break;
            }

         if( y3 < y2 && ++k < opt->max_search_segments )
            {
            y1 = y2;
            x1 = x2;
            y2 = y3;
            x2 = x3;
            repeat=1;
            }
         }
      while (repeat);

      /* done with this parameter */
      if( isnan( y3 ) )
         continue;
   
      /* now the local minimum is bounded between alpha=x1 and alpha=x3
         with alpha=x2 as the minimum, do a quadratic fit to find the optimum alpha
      */
      alpha = 0.5*(x1 + x2 + (y1-y2)*(x3-x1)*(x3-x2)/(x1*(y2-y3) + x2*(y3-y1) + x3*(y2-y1)));
  
      /* calculate the resulting error from the quadratically fit alpha */
      opt->temp_pl[i] = opt->p_list[i] + alpha * opt->s_dirs[i];
      z1 = opt_function( opt, opt->temp_pl );

      /* check which error is best */
      if( !isnan (z1) && z1 < y2 )
         {  
         opt->p_list[i] += alpha * opt->s_dirs[i];
         opt->temp_pl[i] = opt->p_list[i];
         opt->current_total_error = z1;
         for( j=0; j<opt->n_errors; j++ )
            opt->current_error[j] = opt->func_err[j];
         }
      else
         {
         /* revert back to alpha=x2 */
         opt->p_list[i] += x2 * opt->s_dirs[i];
         opt->temp_pl[i] = opt->p_list[i];
         opt->current_total_error = opt_function( opt, opt->p_list );
         for( j=0; j<opt->n_errors; j++ )
            opt->current_error[j] = opt->func_err[j];
         }
      }
         
   return 0;
   }
   
/**************************************************************************/
/**************************************************************************/
   
static int cg_malloc( OPTIMIZE *opt, int allocate )
   {   
   if (allocate)
      {
      unsigned np = opt->n_params;
      unsigned ne = opt->n_errors;
      unsigned i;
      
      if ((ne < 1) || (np < 1))
         return -1;
      
      opt->old_error = (double *) malloc (sizeof (double)*ne);
      opt->current_error = (double *) malloc (sizeof (double)*ne);
      opt->func_err = (double *) malloc (sizeof (double)*ne);
      opt->temp_error1 = (double *) malloc (sizeof (double)*ne);
      opt->temp_error2 = (double *) malloc (sizeof (double)*ne);

      opt->p_list = (double *) malloc (sizeof (double)*np);
      opt->old_p_list = (double *) malloc (sizeof (double)*np);
      opt->function_p_list = (double *) malloc (sizeof (double)*np);
      opt->temp_pl = (double *) malloc (sizeof (double)*np);
      
      opt->s_dirs = (double *) malloc (sizeof (double)*np);

      opt->param_flag = (int *) malloc (sizeof (int)*np);
      
      opt->grads = (double **) malloc (sizeof (double *)*np);
      opt->old_grads = (double **) malloc (sizeof (double *)*np);

      if (!opt->grads || !opt->old_grads)
         {
         cg_malloc (opt, 0);
         return -1;
         }

      for (i = 0; i < np; ++i)
         {
         opt->grads[i] = (double *) malloc (sizeof (double)*ne);
         opt->old_grads[i] = (double *) malloc (sizeof (double)*ne);

         if (!opt->grads[i] || !opt->old_grads[i])
            {
            cg_malloc (opt, 0);
            return -1;
            }
         }
      }
   else
      {
      free ((void *) opt->old_error); opt->old_error = NULL;
      free ((void *) opt->current_error); opt->current_error = NULL;
      free ((void *) opt->func_err); opt->func_err = NULL;
      free ((void *) opt->temp_error1); opt->temp_error1 = NULL;
      free ((void *) opt->temp_error2); opt->temp_error2 = NULL;
      free ((void *) opt->p_list); opt->p_list = NULL;
      free ((void *) opt->old_p_list); opt->old_p_list = NULL;
      free ((void *) opt->function_p_list); opt->function_p_list = NULL;
      free ((void *) opt->temp_pl); opt->temp_pl = NULL;
      free ((void *) opt->s_dirs); opt->s_dirs = NULL;
      free ((void *) opt->param_flag); opt->param_flag = NULL;

      if (opt->grads)
         {
         unsigned i;

         for (i = 0; i < opt->n_params; ++i)
            free ((void *) opt->grads[i]);

         free ((void *) opt->grads);
         opt->grads = NULL;
         }

      if (opt->old_grads)
         {
         unsigned i;

         for (i = 0; i < opt->n_params; ++i)
            free ((void *) opt->old_grads[i]);

         free ((void *) opt->old_grads);
         opt->old_grads = NULL;
         }

      return 0;
      }

   // check to make sure that memory allocation succeeded
   if (!opt->old_error || !opt->current_error || !opt->func_err ||
      !opt->p_list || !opt->temp_pl || !opt->old_p_list ||
      !opt->s_dirs || !opt->grads || !opt->old_grads || !opt->param_flag ||
      !opt->temp_error1 || !opt->temp_error2)
      {
      // recursively call to deallocate memory
      cg_malloc (opt, 0);
      return -1;
      }
   
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

static void my_sigint_handler( int signal )
   {
   global_intr_flag = 1;
   }

/**************************************************************************/
/**************************************************************************/
/*                                                                        */
/*                       MAIN OPTIMIZATION ROUTINES                       */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/

extern int optimize( OPTIMIZE *opt, int opt_mode, unsigned max_iterations, double *final_error )
   {
   if( opt_mode == OMODE_GRADIENT )
      return cg_optimize4( opt, max_iterations, final_error );
   else if( opt_mode == OMODE_RANDOM )
      return random_optimize( opt, max_iterations, final_error );
   else if( opt_mode == OMODE_RANDOM_GRADIENT )
      {
      int e = random_optimize( opt, max_iterations, final_error );
      if( e == 0 )
         return cg_optimize4( opt, max_iterations, final_error );
      else
         return e;
      }
   else
      {
      global_error = ERR_WRONGMODE;
      return ERR_WRONGMODE;
      }
   }

/**************************************************************************/
/**************************************************************************/

extern int random_optimize( OPTIMIZE *opt, unsigned max_iterations, double *final_error )
   {
   global_error = -333;
   return -333;
   }

/**************************************************************************/
/**************************************************************************/

extern int cg_optimize4( OPTIMIZE *opt, unsigned max_iterations, double *final_error )
   {
   unsigned i,j;
   unsigned k = 0;
   unsigned count = 0;
   unsigned flag;
   int single_parameter_mode = 0;
   int stat, err;
   
   /* init global variables */
   global_error = 0;
   global_intr_flag = 0;

   /* check for valid fields in the OPTIMIZE structure */
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   else if( !opt->params || !opt->n_params )
      {
      global_error = ERR_NO_PARAMS;
      return ERR_NO_PARAMS;
      } 
   else if( !opt->function )
      {
      global_error = ERR_NO_FUNCTION;
      return ERR_NO_FUNCTION;
      }
   else if (!opt->n_errors)
      {
      global_error = ERR_NO_ERF;
      return ERR_NO_ERF;
      }

   /* initialize the jump buffer */
   err = setjmp( global_jmpbuf );
   if( err )
      {
      global_error = err;
      cg_malloc( opt, 0 );
      return err;
      }

   if( opt->flags & OPT_SINGLE_PARAM )
      single_parameter_mode = 1;

   /* allocate memory */
   if( cg_malloc(opt, 1) )
      {
      global_error = ERR_NO_MEM;
      return ERR_NO_MEM;
      }

   /* create a parameter list and map the parameters to be optimized */
   for( i=0; i<opt->n_params; i++ )
      {
      opt->p_list[i] = opt->old_p_list[i] = opt->params[i].nom;
      if( opt->params[i].optimize &&
         opt->params[i].min < opt->params[i].max &&
         opt->params[i].nom <= opt->params[i].max &&
         opt->params[i].nom >= opt->params[i].min )
         {
         opt->param_flag[i] = 1;
         k++;
         }
      else
         opt->param_flag[i] = 0;
      }

   if( k < 1 )
      {
      global_error = ERR_NO_PARAMS;
      cg_malloc(opt, 0);
      return ERR_NO_PARAMS;
      }

   /* make sure that the weight values are positive */
   if (opt->weights)
      for( i=0; i<opt->n_errors; i++ )
         opt->weights[i] = fabs( opt->weights[i] );
      
   /* calculate the initial error */
   opt->current_total_error = opt_function( opt, opt->p_list );
   for( j=0; j<opt->n_errors; j++ )
      opt->current_error[j] = opt->func_err[j];

   /* check for an initial NaN value for the error function */
   if( isnan( opt->current_total_error ) )
      {
      global_error = ERR_NAN;
      cg_malloc(opt, 0);
      return ERR_NAN;
      }
      
   /* if maximum iterations is 0, print the error and return */
   if( !max_iterations )
      {
      print_error_values( opt, 0 );
      if( final_error )
         {
         for( j=0; j<opt->n_errors; j++ )
            final_error[j] = opt->current_error[j];
         }
      cg_malloc( opt, 0 );
      return 0;
      }
   
   /* set signal handler to trap INT (CTRL-C) */ 
   signal( SIGINT, my_sigint_handler );
   
   /************** MAIN OPTIMIZATION LOOP ***************/
   
   for( i=1; i<=max_iterations; i++ )
      {
      /* copy the current error vector to the old error vector */
      for( j=0; j<opt->n_errors; j++ )
         opt->old_error[j] = opt->current_error[j];
      opt->old_total_error = opt->current_total_error;
      
      /* calculate the gradients */
      compute_gradients( opt );

      /* compute the search direction vector */
      compute_search_dirs( opt, i );

      /* perform the line search */
      if (single_parameter_mode)
         stat = sngl_param_line_search( opt );
      else
         stat = perform_line_search( opt );
      
      if( stat )
         {
         if( (opt->flags & OPT_AUTO) && !single_parameter_mode )
            single_parameter_mode = 1;
         else
            break;
         }
               
      /* print the error */
      print_error_values( opt, i );

      /* exit if the error functions changed by less than the specified error fraction
         for the number of iterations specified in opt->err_fraction_repeat + 1
       */
      if( opt->err_fraction_repeat && opt->err_fraction > 0.0 )
         {
         if (fabs (opt->old_total_error - opt->current_total_error) < (opt->err_fraction * opt->current_total_error))
            count++;
         else
            count = 0;

         if( count > opt->err_fraction_repeat )
            {
            if( (opt->flags & OPT_AUTO) && !single_parameter_mode )
               {
               single_parameter_mode = 1;
               count = 0;
               }
            else
               break;
            }
         }

      /* exit if the change in each parameter since the last iteration is less than
           the tolerance of that parameter
       */
      flag = k = 0;
      for( j=0; j<opt->n_params; j++ )
         {
         if( opt->param_flag[j] )
            {
            k++;
            if( fabs(opt->old_p_list[j] - opt->p_list[j]) < opt->params[j].tol )
               flag++;
            }
         opt->old_p_list[j] = opt->p_list[j];
         }
      if( flag == k )
         {
         if( (opt->flags & OPT_AUTO) && !single_parameter_mode )
            single_parameter_mode = 1;
         else
            break;
         }
      
      /* check to see if an interrupt was trapped */
      if( global_intr_flag )
         break;

      } /* end of main optimization loop */
   
   /* copy the optimized parameters back to the param structure */
   for( j=0; j<opt->n_params; j++ )
      {
      if( opt->param_flag[j] )
         opt->params[j].nom = opt->p_list[j];
      }

   /* call the optimization function once more to make sure the final error is current */
   opt->current_total_error = opt_function( opt, opt->p_list );
   for( j=0; j<opt->n_errors; j++ )
      opt->current_error[j] = opt->func_err[j];

   /* load the error return vector */
   if( final_error )
      {
      for( j=0; j<opt->n_errors; j++ )
         final_error[j] = opt->current_error[j];
      }
   
   /* free all allocated memory */
   cg_malloc( opt, 0);
   
   /* reset the signal handler */
   signal (SIGINT, SIG_DFL);
      
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern char *get_opt_error_msg( int errcode )
   {
   static struct err_str_list {
      int code;
      char *errmsg;
      }
   elist[] = {
      {ERR_NO_MEM,       "Memory allocation failed. System resources may be depleted."},
      {ERR_FUNCTION,     "Optimization error function returned an error."},
      {ERR_NO_PARAMS,    "No parameters to be optimized."},
      {ERR_NO_FUNCTION,  "The error function is not defined."},
      {ERR_NO_ERF,       "No errors defined for the error function."},
      {ERR_INVALID_ARG,  "Invalid function argument."},
      {ERR_GRADIENT_EXT, "External gradient function returned an error."},
      {ERR_WRONGMODE,    "Invalid optimization mode."},
      {ERR_NAN,          "Unrecoverable NaN error."}
      };
   int i;

   for( i=0; i<sizeof( elist ) / sizeof( *elist ); i++ )
      {
      if( errcode == elist[i].code )
         return elist[i].errmsg;
      }

   return "Unknown error.";
   }

/**************************************************************************/
/**************************************************************************/

extern char *get_opt_error( void )
   {
   return get_opt_error_msg( global_error );
   }

/**************************************************************************/
/**************************************************************************/

extern char *get_cg_error( void )
   {
   return get_opt_error( );
   }

/**************************************************************************/
/**************************************************************************/

extern OPTIMIZE *initialize_optimizer( void )
   {
   OPTIMIZE *opt = (OPTIMIZE *) malloc( sizeof(OPTIMIZE) );
   global_error = 0;
   if( !opt ) 
      {
      global_error = ERR_NO_MEM;
      return NULL;
      }
   *opt = default_optimizer_values;
   return opt;
   }

/**************************************************************************/
/**************************************************************************/

extern OPTIMIZE *initialize_cg_optimizer( void )
   {
   return initialize_optimizer( );
   }

/**************************************************************************/
/**************************************************************************/

extern int set_opt_parameters( OPTIMIZE *opt, OPT_PARAMETER *p, unsigned n_params )
   {
   global_error = 0;
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   if( !p || (n_params < 1) )
      {
      opt->params = NULL;
      opt->n_params = 0;
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   opt->params = p;
   opt->n_params = n_params;
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern int set_cg_parameters( OPTIMIZE *opt, OPT_PARAMETER *p, unsigned n_params )
   {
   return set_opt_parameters( opt, p, n_params );
   }

/**************************************************************************/
/**************************************************************************/

extern int set_opt_error_function( OPTIMIZE *opt, int (*func) (double *, void *, double *,
                                   unsigned), void *data, unsigned n_errs, double *weights )
   {
   global_error = 0;
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   opt->function = func;
   opt->function_data = data;
   opt->n_errors = n_errs;
   opt->weights = weights;
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern int set_cg_error_function( OPTIMIZE *opt, int (*func) (double *, void *, double *,
                                  unsigned), void *data, unsigned n_errs, double *weights )
   {
   return set_opt_error_function( opt, func, data, n_errs, weights );
   }

/**************************************************************************/
/**************************************************************************/

extern int set_opt_gradient_function( OPTIMIZE *opt, int (*func) (double *, void *, double **,
                                      unsigned, unsigned, int *), void *data )
   {
   global_error = 0;
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   opt->gradients = func;
   opt->gradient_data = data;
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern int set_cg_gradient_function( OPTIMIZE *opt, int (*func) (double *, void *, double **,
                                     unsigned, unsigned, int *), void *data )
   {
   return set_opt_gradient_function( opt, func, data );
   }

/**************************************************************************/
/**************************************************************************/

extern int set_opt_print_format( OPTIMIZE *opt, char *fmt )
   {
   global_error = 0;
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   if( !fmt || !*fmt )
      *opt->print_format = '\0';
   else
      {
      strncpy( opt->print_format, fmt, 19 );
      opt->print_format[19] = '\0';
      }
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern int set_cg_print_format( OPTIMIZE *opt, char *fmt )
   {
   return set_opt_print_format( opt, fmt );
   }

/**************************************************************************/
/**************************************************************************/

extern int set_opt_error_fraction( OPTIMIZE *opt, double fraction, unsigned repeat )
   {
   global_error = 0;
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   opt->err_fraction = fraction;
   opt->err_fraction_repeat = repeat;
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern int set_cg_error_fraction( OPTIMIZE *opt, double fraction, unsigned repeat )
   {
   return set_opt_error_fraction( opt, fraction, repeat );
   }

/**************************************************************************/
/**************************************************************************/

extern int set_opt_flags( OPTIMIZE *opt, unsigned long flags )
   {
   global_error = 0;
   if( !opt )
      {
      global_error = ERR_INVALID_ARG;
      return ERR_INVALID_ARG;
      }
   opt->flags = flags;
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

extern int set_cg_flags( OPTIMIZE *opt, unsigned long flags )
   {
   return set_opt_flags( opt, flags );
   }




