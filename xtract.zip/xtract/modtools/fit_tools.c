#include <math.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "fit_tools.h"

/*****************************************************************************/
/*****************************************************************************/

void linefit_mxb (double *x, double *y, unsigned n, double *m, double *b, double *r2)
{
   unsigned i;
   double xsum = 0.0;
   double ysum = 0.0;
   double xxsum = 0.0;
   double yysum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 2)
   {
      *m = 0.0;
      *b = 0.0;
      *r2 = 0.0;
      return;
   }

   for (i = 0; i < n; ++i)
   {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
   }

   *m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
   *b  = (xxsum*ysum - xysum*xsum) / (xxsum*((double) n) - xsum*xsum);
   // *r2 = xysum*xysum / (xxsum*yysum);

   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
   {
      err += ((*m)*x[i] + (*b) - y[i])*((*m)*x[i] + (*b) - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
   }

   *r2 = sqrt (1.0 - err/max);
}

/*****************************************************************************/
/*****************************************************************************/

void linefit_mx0 (double *x, double *y, unsigned n, double *m, double *r2)
{
   unsigned i;
   double ysum = 0.0;
   double xxsum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 1)
   {
      *m = 0.0;
      *r2 = 0.0;
      return;
   }

   for (i = 0; i < n; ++i)
   {
      ysum  += y[i];
      xxsum += x[i]*x[i];
      xysum += x[i]*y[i];
   }

   *m = xysum / xxsum;
   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
   {
      err += ((*m)*x[i] - y[i])*((*m)*x[i] - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
   }

   *r2 = sqrt (1.0 - err/max);
}

/*****************************************************************************/
/*****************************************************************************/

int solve_linear_system (double **a, double *b, double *x, int n)
{
   double *y, **z;
   int *col_point;
   double tempd, maxv;
   int tempi, i, j, k, col, row;
   int err_lev = 0;

   if( n < 2 )
      return 1;

   /* allocate memory */

   y = (double *) malloc (sizeof (double) * n);
   col_point = (int *) malloc (sizeof (int) * n);

   z = (double **) malloc (sizeof (double *) * n);
   for (i = 0; i < n; ++i)
      z[i] = (double *) malloc (sizeof (double) * n);

   /* initialize everything */

   for (i = 0; i < n; ++i)
   {
      y[i] = b[i];
      col_point[i] = i;
      for (j = 0; j < n; ++j)
         z[i][j] = a[i][j];
   }

   /* invert the matrix */

   for( k=0; k<n-1; k++ )  // k is the current row pointer
   {

      // find the largest value in the matrix
      maxv = 0.0;
      row = col = k;
      for ( i=k; i<n; i++ )
      {
         for ( j=k; j<n; j++ )
         {
            tempd = fabs( z[i][j] );
            if (tempd > maxv)
            {
               row = i;
               col = j;
               maxv = tempd;
            }
         }
      }

      if (row != k)
      {
         // rotate rows
         for ( j=0; j<n; j++ )
         {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
         }
         // rotate the independent vector
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
      }

      if (col != k)
      {
         // rotate columns
         for ( i=0; i<n; i++ )
         {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
         }
         // rotate the column pointer
         tempi = col_point[k];
         col_point[k] = col_point[col];
         col_point[col] = tempi;
      }

      // gaussian elimination
      for ( i=k+1; i<n; i++ )
      {
         tempd = z[i][k] / z[k][k];
         y[i] -= tempd * y[k];
         for( j=k; j<n; j++ )
            z[i][j] -= tempd * z[k][j];
      }
   }


   // matrix now looks like this:
   //  |  a11  a12  a13  a14  . |
   //  |   0   a22  a23  a24  . |
   //  |   0    0   a33  a34  . |
   //  |   0    0    0   a44  . |
   /// |   .    .    .    .   . |

   /* back substitution */
   x[col_point[n-1]] = y[n-1] / z[n-1][n-1];
   for ( k=n-2; k>=0; k-- )
   {
      tempd = y[k];
      for ( i=n-1; i>k; i-- )
         tempd -= z[k][i]*x[col_point[i]];

      x[col_point[k]] = tempd / z[k][k];
   }

   /* check for a singular matrix */

   if (fabs (z[n-1][n-1]) < 1.0e-24)
      err_lev = 1;

   /* free memory */

   free ((void *) col_point);
   free ((void *) y);
   for ( i=0; i<n; i++ )
      free ((void *) z[i]);
   free ((void *) z);

   return err_lev;
}

/*****************************************************************************/
/*****************************************************************************/

double bubble_average (double *values, unsigned n)
{
   unsigned i,j;
   double temp;
   double delta;

   if (!n)
      return 0.0;
   else if (n == 1)
      return values[0];

   // sort the values vector in ascending order
   for (i = 0; i < n-1; ++i)
   {
      for (j = i+1; j < n; ++j)
      {
         if (values[j] < values[i])
         {
            temp = values[i];
            values[i] = values[j];
            values[j] = temp;
         }
      }
   }

   // take the average of all the values within 25% of the median value of the vector
   delta = fabs (values[n/2]) * 0.25;
   for (j = 0, i = 0, temp = 0.0; j < n; ++j)
   {
      if (fabs (values[j]-values[n/2]) <= delta)
      {
         ++i;
         temp += values[j];
      }
   }

   if (!i)
      i = 1;

   return temp / ((double) i);
}

/*****************************************************************************/
/*****************************************************************************/
void write_model_param_mdif (FILE *file, char *names[], double *values, unsigned n, unsigned width, unsigned cols)
{
   unsigned i = 0;
   unsigned j;
   unsigned tmp;
   char txt_fmt[20];
   char num_fmt[20];

   if (!file || !n || !cols || !width)
      return;

   sprintf (txt_fmt, "%%-%ds ", width);
   sprintf (num_fmt, "%%-%d.3e ", width);

   fprintf (file, "BEGIN BDTA\n");

   while (i < n)
   {
      tmp = i;

      fprintf (file, "%%\t");
      for (j = 0; j < cols; ++j, ++i)
      {
         if (i >= n)
            break;

         fprintf (file, txt_fmt, names[i]);
      }
      fprintf (file, "\n");

      fprintf (file, "\t");
      for (j = 0, i = tmp; j < cols; ++j, ++i)
      {
         if (i >= n)
            break;

         fprintf (file, num_fmt, values[i]);
      }
      fprintf (file, "\n");
   }

   fprintf (file, "END\n");
}

/*****************************************************************************/
/*****************************************************************************/

int get_iv_data ( const char *fname, IV_DATA *d, unsigned max_pts, unsigned *n)
{
   FILE *file;
   char string[256];
   double vgs,vds,igs,ids;
   int first = 1;
   int piv_file = 0;

   *n = 0;

   file = fopen (fname, "r");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", fname);
      return 1;
   }

   while (fgets (string, 255, file))
   {
      if (first)
      {
         if (string[0] == '\\')
            piv_file = 1;

         first = 0;
         continue;
      }

      if ((string[0] != '!') && (string[0] != '\\') && (sscanf (string, "%lf%lf%lf%lf", &vds, &ids, &vgs, &igs) == 4))
      {
         if (*n >= max_pts)
         {
            fprintf (stderr, "Warning: %s: too many data points in file.\n", fname);
            break;
         }

         if (piv_file)
         {
            // data fields are in a different order in PIV files
            d[*n].vgs = vds;
            d[*n].vds = ids;
            d[*n].ids = vgs;
            d[*n].igs = igs;
         }
         else
         {
            d[*n].vds = vds;
            d[*n].ids = ids;
            d[*n].vgs = vgs;
            d[*n].igs = igs;
         }

         ++(*n);
      }
   }

   fclose (file);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

int read_model_parameters_from_file ( const char *fname, MODEL_PARAMS **p, unsigned *np)
{
   FILE *file;
   char string[200];
   double min, nom, max, tol;
   char name[20];
   MODEL_PARAMS *m, *last = NULL;
   unsigned count = 0;

   /* open the file */

   file = fopen (fname, "r");
   if (!file)
   {
      printf ("Error: %s: unable to open file.\n", fname);
      return 1;
   }

   /* read in the parameters from the file */

   while (fgets (string, 199, file))
   {
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (sscanf (string,"%lf%lf%lf%lf%19s", &min, &nom, &max, &tol, name) == 5)
      {
         m = (MODEL_PARAMS *) malloc (sizeof (MODEL_PARAMS));
         m->next = NULL;
         m->min = min;
         m->nom = nom;
         m->max = max;
         m->tol = tol;
         strcpy (m->name, name);

         if (!last)
            *p = m;
         else
            last->next = m;

         last = m;
         ++count;
      }
   }

   fclose (file);

   if (np)
      *np = count;

   return 0;
}


/*****************************************************************************/
/*****************************************************************************/

int write_model_parameters_to_file (MODEL_PARAMS *p, const char *fname)
{
   FILE *file;
   MODEL_PARAMS *ptr;

   /* open the file */

   file = fopen (fname, "w+");
   if (!file)
   {
      printf ("Error: %s: unable to write to disc.\n", fname);
      return 1;
   }

   /* write the parameters to the file */

   for (ptr = p; ptr; ptr = ptr->next)
      fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", ptr->min, ptr->nom, ptr->max, ptr->tol, ptr->name);

   fclose (file);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

void free_model_parameters( MODEL_PARAMS *p )
{
   MODEL_PARAMS *t;
   while( p ) {
      t = p;
      p = p->next;
      free((void*)t);
   }
}

/*****************************************************************************/
/*****************************************************************************/

int set_parameter_value (MODEL_PARAMS *p, OPT_PARAMETER x)
{
   MODEL_PARAMS *ptr;

   for (ptr = p; ptr; ptr = ptr->next)
   {
      if (!strcasecmp (ptr->name, x.name))
      {
         ptr->min = x.min;
         ptr->nom = x.nom;
         ptr->max = x.max;
         ptr->tol = x.tol;
         return 0;
      }
   }

   return 1;
}

/*****************************************************************************/
/*****************************************************************************/

int set_all_parameters (MODEL_PARAMS *p, OPT_PARAMETER *x, unsigned n)
{
   MODEL_PARAMS *ptr;
   unsigned i;
   int found;
   int err = 0;

   for (i = 0; i < n; ++i)
   {
      found = 0;
      for (ptr = p; ptr; ptr = ptr->next)
      {
         if (!strcasecmp (ptr->name, x[i].name))
         {
            ptr->min = x[i].min;
            ptr->nom = x[i].nom;
            ptr->max = x[i].max;
            ptr->tol = x[i].tol;
            found = 1;
            break;
         }
      }

      if (!found)
      {
         printf ("Warning: set_all_parameters(): parameter \'%s\' not found.\n", x[i].name);
         err = 1;
      }
   }

   return err;
}

/*****************************************************************************/
/*****************************************************************************/

int get_parameter_value ( const char *name, MODEL_PARAMS *p, OPT_PARAMETER *x)
{
   MODEL_PARAMS *ptr;

   for (ptr = p; ptr; ptr = ptr->next)
   {
      if (!strcasecmp (ptr->name, name))
      {
         x->min = ptr->min;
         x->nom = ptr->nom;
         x->max = ptr->max;
         x->tol = ptr->tol;
         strcpy (x->name, ptr->name);
         x->optimize = 0;
         return 0;
      }
   }

   return 1;
}

/*****************************************************************************/
/*****************************************************************************/

int get_all_parameters ( const char *names[], unsigned n, MODEL_PARAMS *p, OPT_PARAMETER *x)
{
   MODEL_PARAMS *ptr;
   unsigned i;
   int found;
   int err = 0;

   for (i = 0; i < n; ++i)
   {
      found = 0;
      for (ptr = p; ptr; ptr = ptr->next)
      {
         if (!strcasecmp (ptr->name, names[i]))
         {
            x[i].min = ptr->min;
            x[i].nom = ptr->nom;
            x[i].max = ptr->max;
            x[i].tol = ptr->tol;
            strcpy (x[i].name, ptr->name);
            x[i].optimize = 0;
            found = 1;
            break;
         }
      }

      if (!found)
      {
         printf ("Warning: get_all_parameters(): parameter \'%s\' not found.\n", names[i]);
         err = 1;
      }
   }

   return err;
}

/*****************************************************************************/
/*****************************************************************************/

static void option_file_error_print( const char *line, const char *ch )
{
   const char* i;
   fprintf( stderr, "   %s\n   ", line );
   for( i=line; i<ch; ++i )
      fputc( ' ', stderr );
   fputc( '^', stderr );
   fputc( '\n', stderr );
}

/*****************************************************************************/
/*****************************************************************************/

OptionSet* create_option( const char* name, const char* val, OptionSet* prev, OptionSet* next )
{
   OptionSet *t = (OptionSet*) malloc( sizeof( OptionSet ) );
   t->name = strdup( name );
   t->value = (val && *val!='\0') ? strdup(val) : NULL;
   t->next = next;
   t->prev = prev;

   // set pointers
   if( next )
      next->prev = t;
   if( prev )
      prev->next = t;

   return t;
}

/*****************************************************************************/
/*****************************************************************************/
// delete the current option and return the next option in the list
//   or the previous option if the next option is NULL
//   or NULL if both the next and previous options are NULL
OptionSet* delete_option( OptionSet* opt )
{
   OptionSet *r = NULL;
   if( opt ) {
      // fix linked-list pointers
      if( opt->next ) {
         opt->next->prev = opt->prev;
         r = opt->next;
      }
      if( opt->prev ) {
         opt->prev->next = opt->next;
         if( !r ) r = opt->prev;
      }

      // free memory
      free((void*)opt->name);
      if( opt->value ) free((void*)opt->value);
      free((void*)opt);
   }
   return r;
}

/*****************************************************************************/
/*****************************************************************************/
// read a file of options
//  -each line is read as a single option - no line continuation is possible
//  -option names must not contain any spaces and must start with a letter or underscore
//  -all options are read as strings, they can be later converted to desired types
//  -leading white space is automatically removed
//  -a valid option must contain an = between the option name and value
//  -an option name with or without the = and no value results in an empty string as the value for that option
//  -both 'option=' and 'option =' are valid
//  -the maximum line length is fixed at 1024 characters
//  -the # starts a comment, unless it is escaped by a '\'
int read_option_file( const char *fname, OptionSet **opt )
{
   char str[1028], name[128], val[1028];
   FILE *f = fopen( fname, "r" );
   int lineno=0;
   static const char *valid_start_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
   static const char *valid_name_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_-.";
   short ok;
   char *p, *n, *name_start, *val_start;
   OptionSet *current = *opt;

   if( !f )
   {
      fprintf( stderr, "Error: %s: file not found or not readable.\n", fname );
      return -1;
   }

   while( fgets( str, 1024, f ) )
   {
      ++lineno;

      // remove the trailing '\n'
      str[strlen(str)-1] = '\0';

      // start by chopping the string at the first non-escaped '#' character
      for( p=str; p; ++p ) {
         if( *p == '#' && (p>str ? *(p-1)!='\\' : 1 ) ) {
            *p = '\0';
            break;
         }
      }

      if( !strlen(str) ) continue;

      // ***************************************************************************
      // STEP 1: determine the option name -----------------------------------------
      // ***************************************************************************

      // find the start of the name by scanning past leading whitspace
      for( name_start=str; *name_start!='\0' && (*name_start==' ' || *name_start=='\t'); ++name_start );

      // make sure the leading character of the option name is valid
      if( *name_start && !strchr( valid_start_chars, *name_start ) )
      {
         fprintf( stderr, "%s: %d: option name must start with a letter or underscore.\n", fname, lineno );
         option_file_error_print( str, name_start );
         continue;
      }

      // copy the option name to the name string
      ok=1;
      for( p=name_start, n=name; *p!='\0' && *p!=' ' && *p!='\t' && *p!='='; ++p, ++n ) {
         if( !strchr(valid_name_chars,*p)  ){
            ok=0;
            fprintf( stderr, "%s: %d: invalid character in option name.\n", fname, lineno );
            option_file_error_print( str, p );
            break;
         }
         else if( (int)(p-name_start) > 127 ) {
            ok=0;
            fprintf( stderr, "%s: %d: option name cannot be more than 127 characters.\n", fname, lineno );
            option_file_error_print( str, p );
            break;
         }
         // copy as lowercase
         if( *p >= 'A' && *p <= 'Z' )
            *n = *p + ('a'-'A');
         else
            *n = *p;
      }
      *n = '\0';  // null-terminate the option name

      if( !ok || n==name ) continue;  // error or strlen(name) == 0

      // ***************************************************************************
      // STEP 2: find the value ----------------------------------------------------
      // ***************************************************************************

      // set the value pointer
      val_start = p;

      // remove the = and make sure that no other non-ws characters come between the option name and the =
      ok = 1;
      for( ; *val_start != '\0' && *val_start != '='; ++val_start ) {
         if( *val_start != ' ' && *val_start != '\t' ) {
            fprintf( stderr, "%s: %d: parse error.\n", fname, lineno );
            option_file_error_print( str, val_start );
            ok=0;
            break;
         }
      }
      if( *val_start == '=' )
         ++val_start;

      if( !ok ) continue;

      // remove the leading whitespace between the = and the start of the value
      for( ; *val_start!='\0' && (*val_start==' ' || *val_start=='\t'); ++val_start );

      // copy the value
      for( p=val_start, n=val; *p!='\0'; ++p, ++n )
      {
         if( *p == '\\' )
         {
            // catch escape sequences, only handle \n and \t right now
            ++p;
            switch( *p )
            {
            case 't':
               *n = '\t'; break;
            case 'n':
               *n = '\n'; break;
            default:
               *n = *p;
               break;
            }
         }
         else
            *n = *p;
      }
      *n = '\0';  // null-terminate the option value

      // ***************************************************************************
      // STEP 3: create a new entry in the OptionSet list --------------------------
      // ***************************************************************************

      // the entry goes at the beginning of the list, that way
      //  options further down the file take precedence if there are duplicates
      current = add_option_before( current, name, val );
   }

   fclose(f);
   *opt = current;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

void free_option_set( OptionSet *opt )
{
   // traverse the list and free all memory
   while( opt )
      opt = delete_option(opt);
}


/*****************************************************************************/
/*****************************************************************************/

int get_option_value( OptionSet *opt, const char * name, char * val, int sz_val )
{
   OptionSet *t = option_set_begin(opt);

   // initialize the return array
   val[0] = '\0';

   t = option_set_find_next( t, name );
   if( t ) {
      if( t->value )
      {
         int i;
         for( i=0; i<sz_val-1; ++i ) {
            if( !t->value[i] ) break;
            val[i] = t->value[i];
         }
         val[i] = '\0';
      }
      return 0;
   }

   // not found
   return 1;
}

/*****************************************************************************/
/*****************************************************************************/
// add a new option before the passed option, return a pointer to the
//  newly created option
OptionSet* add_option_before( OptionSet *opt, const char * name, const char * val )
{
   if( name && *name )
      return create_option( name, val, opt?opt->prev:NULL, opt );
   return opt;
}

/*****************************************************************************/
/*****************************************************************************/
// add a new option after the passed option, return a pointer to the
//  newly created option
OptionSet* add_option_after( OptionSet *opt, const char * name, const char * val )
{
   if( name && *name )
      return create_option( name, val, opt, opt?opt->next:NULL );
   return opt;

}

/*****************************************************************************/
/*****************************************************************************/
// get the beginning of the option list
OptionSet* option_set_begin( OptionSet* opt )
{
   OptionSet* r = opt;
   if( r ) for( ; r->prev; r = r->prev );
   return r;
}

/*****************************************************************************/
/*****************************************************************************/
// get the end of the option list
OptionSet* option_set_end( OptionSet* opt )
{
   OptionSet* r = opt;
   if( r ) for( ; r->next; r = r->next );
   return r;
}

/*****************************************************************************/
/*****************************************************************************/
// find a named option in the list by traversing forward from the passed
//  pointer
OptionSet* option_set_find_next( OptionSet* opt, const char* name )
{
   OptionSet *t = opt;
   char lwr[128];
   int i;

   // get a lowercase representation of the name
   for( i=0; name[i]; ++i ) {
      if( i > 126 )
         return NULL;
      lwr[i] = (name[i] >='A' && name[i]<='Z')?name[i]+('a'-'A'):name[i];
   }
   lwr[i] = '\0';

   // attempt to find the option name in the list
   for( ; t; t=t->next ) {
      if( strcmp(t->name,lwr)==0 ) {
         return t;
      }
   }
   return NULL;
}

/*****************************************************************************/
/*****************************************************************************/
// find a named option in the list by traversing backward from the passed
//  pointer
OptionSet* option_set_find_prev( OptionSet* opt, const char* name )
{
   OptionSet *t = opt;
   char lwr[128];
   int i;

   // get a lowercase representation of the name
   for( i=0; name[i]; ++i ) {
      if( i > 126 )
         return NULL;
      lwr[i] = (name[i] >='A' && name[i]<='Z')?name[i]+('a'-'A'):name[i];
   }
   lwr[i] = '\0';

   // attempt to find the option name in the list
   for( ; t; t=t->prev ) {
      if( strcmp(t->name,lwr)==0 ) {
         return t;
      }
   }
   return NULL;
}

/*****************************************************************************/
/*****************************************************************************/
// remove an option from the list,
//  set the passed pointer to the next element in the list
//  or the previous element if the next element is NULL
//  or NULL if both next and previous are NULL
OptionSet* remove_option( OptionSet *opt, const char * name )
{
   OptionSet *t = option_set_begin(opt);
   t = option_set_find_next( t, name );
   if( t ) {
      return delete_option(t);
   }
   // not found
   return opt;
}

/*****************************************************************************/
/*****************************************************************************/

/*  -- need to finish
struct CommandLineParameter_
{
   const char* ;
   int flag;
   const char* map_to_option;
}

int parse_command_line( int * argc, char **argv, OptionSet **opt )
{


}

*/

/*****************************************************************************/
/*****************************************************************************/
/*
const char** get_file_listing( const char* pattern )
{
   char* tmpfile;
   char str[256];
   FILE *f;
   const char** listing;
   int n=0;
   int i=0;

   // create the file listing
   tmpfile = tempnam( NULL, NULL );
   if( !tmpfile )
      return NULL;
   sprintf( str, "ls %s > %s 2>/dev/null", pattern, tmpfile );
   system( str );

   // open the listing file
   f = fopen( tmpfile, "r" );
   if( !f ) {
      free((void*)tmpfile);
      return NULL;
   }

   // scan for number of files in listing
   while( fgets( str, 255, f ) ) {
      if( *str )
         str[strlen(str)-1] = '\0';

      if( *str ) {
         ++n;
      }
   }

   // check for an empty file set
   if( !n ) {
      fclose( f );
      unlink( tmpfile );
      free((void*)tmpfile);
      return NULL;
   }

   // rewind file
   rewind( f );

   // allocate memory
   listing = (const char**) malloc( sizeof(char*)*(n+1) );
   if( !listing ) {
      fclose( f );
      unlink( tmpfile );
      free((void*)tmpfile);
      return NULL;
   }

   // load file listing
   while( fgets( str, 255, f ) ) {
      if( i >= n ) break;
      if( *str )
         str[strlen(str)-1] = '\0';

      if( *str ) {
         listing[i] = strdup( str );
         ++i;
      }
   }
   listing[i] = NULL;

   fclose( f );
   unlink( tmpfile );
   free((void*)tmpfile);
   return listing;
}
*/

#include <wordexp.h>

const char** get_file_listing( const char* pattern )
{
    wordexp_t we;
    if( wordexp( pattern, &we, 0 ) ) {
        fprintf( stderr, "Error in word expansion.\n" );
        wordfree( &we );
        return NULL;
    }

    if( ! we.we_wordc ) {
        wordfree( &we );
        return NULL;
    }
    else {
        const char** listing = (const char**) malloc( sizeof(char*)*(we.we_wordc+1) );
        int i;
        for( i=0; i<we.we_wordc; ++i ) {
            listing[i] = strdup( we.we_wordv[i] );
        }
        wordfree( &we );
        return listing;
    }
}


/*****************************************************************************/
/*****************************************************************************/
void free_file_listing( const char** l )
{
   if( l ) {
      int i=0;
      for( ; l[i]; ++i ) {
         free((void*) l[i]);
      }
      free((void*) l);
   }
}

/*****************************************************************************/
/*****************************************************************************/
void strip_extension( char *str )
{
   char *p = str + strlen(str) - 1;
   for( ; p > str; --p ) {
      if( *p == '.' ) {
         if( *(p-1) != '/' && *(p-1) != '\\' ) {
            *p = '\0';
         }
         break;
      }
      else if( *p == '/' || *p == '\\' ) break;
   }
}




