/*****************       SORT_S linked-list structure        **********************/
/* - param is a pointer to an array of doubles that are used to sort the data     */
/*   they can be entered in any order, sort order is determined by the index      */
/*   of the double data, as it is given in the SORT_ORDER structure array         */
/* - position can be used to keep track of the initial position of the data prior */
/*   to sorting, it is not a necessary parameter for sort_data ()                 */
/* - next points to the next SORT_S structure that contains sorting data, the     */
/*   next element of the last SORT_S structure must be set to NULL                */

typedef struct _sorting_struct
{
double                  *params;
unsigned long           position;
struct _sorting_struct  *next;
} SORT_S;

/************************     SORT_ORDER structure      ****************************/
/* - param is the array index of the param element in the SORT_S structure         */
/* - descending is set to 0 for ascending sort and non-zero for descending sort    */
/* - for multiple sorting criteria, create an array of SORT_ORDER structures       */
/*   the primary sorting criteria should be in the 0 index position, with          */
/*   secondary, etc. sorting criteria in following array indexes                   */

typedef struct _sort_order
{
int   param;
int   descending;
} SORT_ORDER;

/*****   SORT_S *sort_data (SORT_S *p, SORT_ORDER *q, int num_of_criteria)   ******/
/* - p is a pointer to the beginning of linked list of SORT_S sturctures to be    */
/*   sorted                                                                       */
/* - q is a pointer to an array of SORT_ORDER sturctures that determine the       */
/*   sorting order (index 0 is most significant)                                  */
/* - num_of_criteria is an integer number of SORT_ORDER structure in the array    */ 
/* - returns a pointer to a linked list of sorted SORT_S structures               */

extern SORT_S *sort_data ();

