#ifndef _GRADIENT_OPTIMZER_TYPES
#define _GRADIENT_OPTIMZER_TYPES

// optimizer flags
#define OPT_VERBOSE      1   // print iteration number and errors to stderr (default)
#define OPT_STATUS       2   // print status messages indicating more detail about the optimization
#define OPT_SNGLERR      4   // print only a single error instead of one for each opt. criteria

// mapping modes
#define OPT_ATANH_MAPPING   0
#define OPT_LINEAR_MAPPING  1

/* optimizer configuration structure */
typedef struct _optimization_struct
{
int num_of_params;       // size of the PARAM_STRUCT vector passed to cg_optimize
int num_of_criteria;     // number of optimization criteria, size of the double vector returned by the error function
double *weights;         // pointer to a vector of weights (vector size = num_of_criteria) that are applied 
                           // to the error function vector to compute a combined error value
unsigned long flags;     // optimizer flags
int max_iterations;      // maximum number of optimization line searches
double err_fraction;     // percent change error fraction that causes halting of the optimization loop 
                           // calculated as (fabs(last_error-current_error) < current_error*err_fraction)
double *(*function) ();  // pointer to the optimization error function, the function must return a pointer
                           // to a staticly defined double vector of size num_of_criteria
                           // the function is of the form "double *function(double *pl)", where pl
                           // is a vector of parameter values from the PARAM_STRUCT vector passed to cg_optimize()
double *(*gradients) (); // optional pointer to the function that returns conjugate gradients for each parameter
                           // the function is of the form "double *gradients(double *pl)"
                           // where pl is a vector of parameter values from the PARAM_STRUCT vector passed to cg_optimize()
                           // the function must return a staticly defined vector of gradients equal in length
                           // to num_of_parameters*num_of_criteria, gradients are accessed by
                           // [param*num_of_criteria + crit] where 0 <= param < num_of_parameters and
                           // 0 <= crit < num_of_criteria, gradients for parameters that have their "optimize"
                           // flag set to FALSE in the PARAM_STRUCT vector passed to cg_optimize are ignored but the
                           // indexes must still exist in the return vector, if this pointer is set to NULL,
                           // the optimizer performs numerical gradients for each parameter instead, set to NULL by default
char pformat[20];        // printing format for printing error functions to stderr, default is %.6e
double maximum_beta;     // optimization memory parameter, default is 10.0
double alpha_numerator;  // step size calculation numerator, default is 0.1
double numerical_delta;  // two-sided delta to use in numerical derivatives, default is 1.0e-5
int max_search_segs;     // maximum line search length, default is 10 iterations
int reset_interval;      // search direction reset interval, default is 10 iterations
int mapping_mode;        // parameter mapping mode, default is OPT_ATANH_MAPPING, hyperbolic arctangent mapping
} OPT_STRUCT;

/* parameter structure */
typedef struct _parameter_struct
{
double min;     // minimum value
double nom;     // nominal value
double max;     // maximum value
double tol;     // relative tolerance
char name[20];  // parameter name
char units[20]; // parameter units (optional, obselete)
int optimize;   // optimize flag, TRUE or FALSE
} PARAM_STRUCT;

#endif  // _OPTIMZER_TYPES

#ifndef TRUE
#define TRUE    1
#endif

#ifndef FALSE
#define FALSE   0
#endif

