#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <malloc.h>
#include "cmplxlib.h"
#include "ss_types.h"
#include "optimize3.h"
#ifdef WIN32
#include "microsuck.h"
#endif

/* macros and definitions */

#define EPS  1.0e-9
#define PI   3.14519265359

#define mindex(row,col,ncols)  ((row)*(ncols) + (col))

/* global variables */

static NETLIST   *global_netlist_pointer;
static double    *global_gradient_pointer;
static S_2PORT   *global_sp_pointer;
static COMPLEX   **global_y_matrix;
static COMPLEX   *global_p;
static COMPLEX   *global_q;
static COMPLEX   *global_pa;
static COMPLEX   *global_qa;
static unsigned  number_of_frequencies;
static unsigned  number_of_parameters;
static unsigned  y_matrix_size;

/********************************************************************************************/
/********************************************************************************************/

COMPLEX **allocate_2d_complex_matrix (unsigned size)
   {
   COMPLEX **matrix;
   unsigned i;

   matrix = (COMPLEX **) malloc (sizeof (COMPLEX *)*size);

   for (i = 0; i < size; ++i)
      matrix[i] = (COMPLEX *) malloc (sizeof (COMPLEX)*size);

   return matrix;
   }

/********************************************************************************************/
/********************************************************************************************/

void free_matrix (COMPLEX **matrix, unsigned size)
   {
   unsigned i;
   
   if (!matrix)
      return;

   for (i = 0; i < size; ++i)
      free ((void *) matrix[i]);

   free ((void *) matrix);
   }

/********************************************************************************************/
/********************************************************************************************/

void complex_matrix_reduction (COMPLEX **y, unsigned msize, unsigned rsize)
   {
   COMPLEX temp;
   COMPLEX denom;
   double max,tmax;
   unsigned i,j,k;
   unsigned row,col;
   static COMPLEX neg_one = {-1.0,0.0};

   // perform reduction with full pivoting

   for (k = (msize-1); k > (rsize-1); --k)
      {
      // find largest element
      max = 0.0;
      row = k;
      col = k;
      for (i = rsize; i <= k; ++i)
         {
         for (j = rsize; j <= k; ++j)
            {
            tmax = Cmag (y[i][j]);
            if (tmax > max)
               {
               row = i;
               col = j;
               max = tmax;
               }
            }
         }
      
      // pivot rows
      if (row != k)
         {
         for (j = 0; j <= k; ++j)
            {
            temp = y[k][j];
            y[k][j] = y[row][j];
            y[row][j] = temp;
            }
         }
      
      // pivot columns
      if (col != k)
         {
         for (i = 0; i <= k; ++i)
            {
            temp = y[i][k];
            y[i][k] = y[i][col];
            y[i][col] = temp;
            }
         }
      
      // perform nodal reduction      
      denom = Cdiv (neg_one,y[k][k]);
      for (i = 0; i < k; ++i)
         {
         temp = Cmult (y[i][k],denom);
         for (j = 0; j <= k; ++j)
            y[i][j] = Cadd (y[i][j],Cmult (y[k][j],temp));
         }
      }
   }

/********************************************************************************************/
/********************************************************************************************/

void solve_y_for_2port_s (COMPLEX **y, COMPLEX *s, unsigned ysize)
   {
   COMPLEX yp[4];

   complex_matrix_reduction (y, ysize, 3);

   yp[0] = y[1][1];
   yp[1] = y[1][2];
   yp[2] = y[2][1];
   yp[3] = y[2][2];

   y2s (yp,s,50.0);
   }

/********************************************************************************************/
/********************************************************************************************/

void twoport_adjoint_solution (COMPLEX **y, COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, unsigned msize)
   {
   COMPLEX temp;
   COMPLEX denom;
   double max,tmax;
   unsigned i,j,k;
   unsigned row;
   static COMPLEX one     = {1.0,0.0};
   static COMPLEX neg_one = {-1.0,0.0};
   static COMPLEX zero    = {0.0,0.0};
   static unsigned *pointer = (unsigned *) malloc (sizeof (unsigned) * msize);

   // initialize the node pointer
   for (i = 0; i < msize; ++i)
      pointer[i] = i;

   // perform reduction with diagonal pivoting
   for (k = (msize-1); k > 2; --k)
      {
      // find largest diagonal element
      max = 0.0;
      row = k;
      for (i = 3; i < k; ++i)
         {
         tmax = Cmag2 (y[i][i]);
         if (tmax > max)
            {
            row = i;
            max = tmax;
            }
         }
      
      // pivot rows, columns and node pointer
      if (row != k)
         {
         for (j = 0; j < msize; ++j) // rows
            {
            temp = y[k][j];
            y[k][j] = y[row][j];
            y[row][j] = temp;
            }

         for (i = 0; i < msize; ++i) // columns
            {
            temp = y[i][k];
            y[i][k] = y[i][row];
            y[i][row] = temp;
            }

         i = pointer[k];
         pointer[k] = pointer[row];
         pointer[row] = i;
         }

      // perform nodal reduction 
      denom = Cdiv (neg_one,y[k][k]);
      for (i = 1; i < k; ++i)
         {
         y[i][k] = Cmult (y[i][k],denom);
         for (j = 1; j < k; ++j)
            y[i][j] = Cadd (y[i][j],Cmult (y[k][j],y[i][k]));
         }
         
      for (j = 1; j < k; ++j)
         y[k][j] = Cmult (y[k][j],denom);

      }

   // solve for two-port voltages: p[] = solution with port 2 o.c., q[] = solution with port 1 o.c.
   //   pa[]  and qa[] are the solutions for the adjoint network where Y = YT (transpose)
   p[0]  = zero;
   q[0]  = zero;
   pa[0] = zero;
   qa[0] = zero;

   denom = Csub (Cmult (y[1][1],y[2][2]),Cmult (y[1][2],y[2][1]));
   denom = Cdiv (one,denom);

   p[1] = Cmult (y[2][2],denom);
   p[2] = Cdiv (Cmult (Cneg (p[1]),y[2][1]),y[2][2]);
   q[1] = Cmult (Cneg (y[1][2]),denom);
   q[2] = Cdiv (Cmult (Cneg (q[1]),y[1][1]),y[1][2]);

   pa[1] = p[1];
   pa[2] = Cdiv (Cmult (Cneg (pa[1]),y[1][2]),y[2][2]);
   qa[1] = Cmult (Cneg (y[2][1]),denom);
   qa[2] = Cdiv (Cmult (Cneg (qa[1]),y[1][1]),y[2][1]);

   // solve for internal node voltages, since internal node rows have been normalized to -y[row][row]
   //  already in matrix reduction step, no need to divide solution by -y[row][row]
   for (i = 3; i < msize; ++i)
      {
      p[pointer[i]]  = zero;
      q[pointer[i]]  = zero;
      pa[pointer[i]] = zero;
      qa[pointer[i]] = zero;
      for (j = 1; j < i; ++j)
         {
         p[pointer[i]] = Cadd (p[pointer[i]],Cmult (y[i][j],p[pointer[j]]));
         q[pointer[i]] = Cadd (q[pointer[i]],Cmult (y[i][j],q[pointer[j]]));
         pa[pointer[i]] = Cadd (pa[pointer[i]],Cmult (y[j][i],pa[pointer[j]]));
         qa[pointer[i]] = Cadd (qa[pointer[i]],Cmult (y[j][i],qa[pointer[j]]));
         }
      }
   
   free ((void *) pointer);
   }

/********************************************************************************************/
/********************************************************************************************/

static void s_k_mag_deriv (COMPLEX yderiv, COMPLEX *ysens, S_2PORT sp, COMPLEX *derv)
   {
   COMPLEX s11,s12,s21,s22;
   COMPLEX s11c,s12c,s21c,s22c;
   COMPLEX t11,t12,t21,t22;
   COMPLEX del,delc,tmp;
   static COMPLEX one  = {1.0,0.0};
   static COMPLEX norm = {0.01,0.0};

   s11 = Csub (one,sp.s[0]);
   s12 = sp.s[1];
   s21 = sp.s[2];
   s22 = Csub (one,sp.s[3]);

   t11 = Csub (Cmult (ysens[0],s11),Cmult (ysens[1],s21));
   t12 = Csub (Cmult (ysens[1],s22),Cmult (ysens[0],s12));
   t21 = Csub (Cmult (ysens[2],s11),Cmult (ysens[3],s21));
   t22 = Csub (Cmult (ysens[3],s22),Cmult (ysens[2],s12));

   derv[0] = Cmultx (3,Csub (Cmult (s11,t11),Cmult (s12,t21)),norm,yderiv);
   derv[1] = Cmultx (3,Csub (Cmult (s11,t12),Cmult (s12,t22)),norm,yderiv);
   derv[2] = Cmultx (3,Csub (Cmult (s22,t21),Cmult (s21,t11)),norm,yderiv);
   derv[3] = Cmultx (3,Csub (Cmult (s22,t22),Cmult (s21,t12)),norm,yderiv);

   // now calculate K and MAG sensistivities from [S]
   s11 = sp.s[0];
   s22 = sp.s[3];
   s11c = Cconj (s11);
   s12c = Cconj (s12);
   s21c = Cconj (s21);
   s22c = Cconj (s22);
   del = Csub (Cmult (s11,s22),Cmult (s12,s21));
   delc = Cconj (del);

   // sensitivity w.r.t. K
   derv[4] = Cmult( delc, Caddx( 4,Cmult(s22,derv[0]),Cmult(s11,derv[3]),Cneg(Cmult(s21,derv[1])),Cneg(Cmult(s12,derv[2])) ) );
   derv[4] = Cdiv( Caddx( 3,derv[4],Cneg(Cmult(s11c,derv[0])),Cneg(Cmult(s22c,derv[3])) ),Ccmag(Cmult(s12,s21)) );
   tmp = Cdiv( Cmultx( 4,Complex (sp.k),s12c,s21c,Cadd(Cmult(derv[2],s12),Cmult(derv[1],s21)) ),Complex(Cmag2(Cmult(s12,s21))) );
   derv[4] = Csub (derv[4],tmp);
   derv[4].i = 0.0;

   // sensistivity w.r.t. MAG/MSG
   tmp = Complex (10.0*log10 (exp (1.0)));
   derv[5] = Cmult (tmp,Csub (Cdiv (derv[2],s21),Cdiv (derv[1],s12)));
   if (sp.k > 1.0)
      {
      tmp = Cdiv (Cmult (tmp,derv[4]),Complex (sqrt (sp.k*sp.k - 1.0)));
      if (sp.MAG >= 0.0)
         derv[5] = Csub (derv[5],tmp);
      else
         derv[5] = Cadd (derv[5],tmp);
      }
   derv[5].i = 0.0;
   }

/********************************************************************************************/
/********************************************************************************************/

static void add_ybranch (COMPLEX x, int n1, int n2, COMPLEX **y)
   {
   y[n1][n1] = Cadd (y[n1][n1],x);
   y[n2][n2] = Cadd (y[n2][n2],x);
   y[n1][n2] = Csub (y[n1][n2],x);
   y[n2][n1] = Csub (y[n2][n1],x);
   }

/********************************************************************************************/
/********************************************************************************************/

static void add_yvccs (COMPLEX x, int vp, int vm, int cm, int cp, COMPLEX **y)
   {
   y[cm][vp] = Cadd (y[cm][vp],x);
   y[cp][vm] = Cadd (y[cp][vm],x);
   y[cp][vp] = Csub (y[cp][vp],x);
   y[cm][vm] = Csub (y[cm][vm],x);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_resistance (double r, int n1, int n2, COMPLEX **y)
   {
   COMPLEX x;

   if (fabs (r) < EPS)
      r = EPS;

   x.r = 1.0/r;
   x.i = 0.0;

   add_ybranch (x,n1,n2,y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_resistance (double r, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                        COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   // parameter derivative
   if (fabs (r) < EPS*EPS)
      r = EPS*EPS;

   x.r = -1.0/(r*r);
   x.i = 0.0;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_capacitance (double c, double f, int n1, int n2, COMPLEX **y)
   {
   COMPLEX x;

   x.r = 0.0;
   x.i = 2.0*PI*f*c;

   add_ybranch (x,n1,n2,y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_capacitance (double c, double f, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                         COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   x.r = 0.0;
   x.i = 2.0*PI*f;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_inductance (double l, double f, int n1, int n2, COMPLEX **y)
   {
   COMPLEX x;
   double tmp;

   tmp = 2.0*PI*f*l;
   if (fabs (tmp) < EPS)
      {
      x.r = 1.0/EPS;
      x.i = 0.0;
      }
   else
      {
      x.r = 0.0;
      x.i = -1.0/tmp;
      }

   add_ybranch (x,n1,n2,y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_inductance (double l, double f, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                        COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];
   double tmp;

   tmp = 2.0*PI*f*l*l;
   if (fabs (tmp) < EPS)
      {
      x.r = 0.0;
      x.i = 0.0;
      }
   else
      {
      x.r = 0.0;
      x.i = -1.0/tmp;
      }

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_conductance (double g, int n1, int n2, COMPLEX **y)
   {
   COMPLEX x;

   x.r = g;
   x.i = 0.0;

   add_ybranch (x,n1,n2,y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_conductance (double g, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                         COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   x.r = 1.0;
   x.i = 0.0;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_series_rl (double r, double l, double f, int n1, int n2, COMPLEX **y)
   {
   COMPLEX x;
   double denom,w;

   w = 2.0*PI*f;
   denom = r*r+w*w*l*l;
   if (fabs (denom) < EPS)
      denom = EPS;

   x.r = r/denom;
   x.i = -w*l/denom;

   add_ybranch (x, n1, n2, y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_series_rl (double r, double l, double f, int n1, int n2, S_2PORT sp, COMPLEX *p,
                       COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr, COMPLEX *dervl)
   {
   COMPLEX x1,x2;
   COMPLEX ysens[4];
   double denom,denom2,w;

   w = 2.0*PI*f;
   denom = r*r+w*w*l*l;
   if (fabs (denom) < EPS)
      denom = EPS;

   denom2 = 1.0/(denom*denom);

   x1.r = (denom-2.0*r*r)*denom2;
   x1.i = 2.0*w*r*l*denom2;
   x2.r = -2.0*w*w*r*l*denom2;
   x2.i = w*(2.0*w*w*l*l-denom)*denom2;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));

   s_k_mag_deriv (x1, ysens, sp, dervr);
   s_k_mag_deriv (x2, ysens, sp, dervl);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_series_rc (double r, double c, double f, int n1, int n2, COMPLEX **y)
   {
   COMPLEX x;
   double denom,w;

   w = 2.0*PI*f;
   denom = 1.0 + w*w*r*r*c*c;
   if (fabs (denom) < EPS)
      denom = EPS;

   x.r = w*w*r*c*c/denom;
   x.i = w*c/denom;

   add_ybranch (x, n1, n2, y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_series_rc (double r, double c, double f, int n1, int n2, S_2PORT sp, COMPLEX *p,
                       COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr, COMPLEX *dervc)
   {
   COMPLEX x1,x2;
   COMPLEX ysens[4];
   double denom,denom2,w;

   w = 2.0*PI*f;
   denom = 1.0 + w*w*r*r*c*c;
   if (fabs (denom) < EPS)
      denom = EPS;

   denom2 = 1.0/(denom*denom);

   x1.r = (w*w*c*c - w*w*w*w*r*r*c*c*c*c)*denom2;
   x1.i = -2.0*w*w*w*r*c*c*c*denom2;
   x2.r = 2.0*w*w*r*c*denom2;
   x2.i = (w - w*w*w*r*r*c*c)*denom2;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));

   s_k_mag_deriv (x1, ysens, sp, dervr);
   s_k_mag_deriv (x2, ysens, sp, dervc);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_tcap (double c, double f, int vp, int vm, int cm, int cp, COMPLEX **y)
   {
   COMPLEX x;

   x.r = 0.0;
   x.i = 2.0*PI*f*c;
 
   add_yvccs (x,vp,vm,cm,cp,y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_tcap (double c, double f, int vp, int vm, int cm, int cp, S_2PORT sp,
                       COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   x.r = 0.0;
   x.i = 2.0*PI*f;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[cp],pa[cm]),Csub (p[vp],p[vm]));
   ysens[1] = Cmult (Csub (pa[cp],pa[cm]),Csub (q[vp],q[vm]));
   ysens[2] = Cmult (Csub (qa[cp],qa[cm]),Csub (p[vp],p[vm]));
   ysens[3] = Cmult (Csub (qa[cp],qa[cm]),Csub (q[vp],q[vm]));

   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

static void addy_vccs (double g, double t, double f, int vp, int vm, int cm, int cp, COMPLEX **y)
   {
   COMPLEX x;
   double arg;

   arg = -2.0*PI*f*t;
   x.r = g*cos (arg);
   x.i = g*sin (arg);
 
   add_yvccs (x,vp,vm,cm,cp,y);
   }

/********************************************************************************************/
/********************************************************************************************/

static void derivy_vccs (double g, double t, double f, int vp, int vm, int cm, int cp, S_2PORT sp,
                          COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervg, COMPLEX *dervt)
   {
   COMPLEX x1,x2;
   COMPLEX ysens[4];
   double arg;

   arg = -2.0*PI*f*t;
   x1.r = cos (arg);
   x1.i = sin (arg);
   x2.r = 2.0*PI*f*g*cos (arg);
   x2.i = 2.0*PI*f*g*sin (arg);

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[cp],pa[cm]),Csub (p[vp],p[vm]));
   ysens[1] = Cmult (Csub (pa[cp],pa[cm]),Csub (q[vp],q[vm]));
   ysens[2] = Cmult (Csub (qa[cp],qa[cm]),Csub (p[vp],p[vm]));
   ysens[3] = Cmult (Csub (qa[cp],qa[cm]),Csub (q[vp],q[vm]));   

   s_k_mag_deriv (x1, ysens, sp, dervg);
   s_k_mag_deriv (x2, ysens, sp, dervt);
   }

/********************************************************************************************/
/********************************************************************************************/

void create_y_matrix (NETLIST *nlist, double freq, COMPLEX **y, int ysize)
   {
   int i,j;
   static COMPLEX zero = {0.0,0.0};
   NETLIST *ptr;

   // zero the [Y] matrix
   for (i = 0; i < ysize; ++i)
      for (j = 0; j < ysize; ++j)
         y[i][j] = zero;

   // load the elements
   for (ptr = nlist; ptr; ptr = ptr->next)
      {
      switch (ptr->type)
         {
         case Netlist_R:
            addy_resistance (ptr->value[0],ptr->nodes[0],ptr->nodes[1],y);
            break;
         case Netlist_G:
            addy_conductance (ptr->value[0],ptr->nodes[0],ptr->nodes[1],y);
            break;
         case Netlist_C:
            addy_capacitance (ptr->value[0],freq,ptr->nodes[0],ptr->nodes[1],y);
            break;
         case Netlist_L:
            addy_inductance (ptr->value[0],freq,ptr->nodes[0],ptr->nodes[1],y);
            break;
         case Netlist_SRL:
            addy_series_rl (ptr->value[0],ptr->value[1],freq,ptr->nodes[0],ptr->nodes[1],y);
            break;
         case Netlist_SRC:
            addy_series_rc (ptr->value[0],ptr->value[1],freq,ptr->nodes[0],ptr->nodes[1],y);
            break;
         case Netlist_VCCS:
            addy_vccs (ptr->value[0],ptr->value[1],freq,ptr->nodes[0],ptr->nodes[1],ptr->nodes[2],ptr->nodes[3],y);
            break;
         case Netlist_TCAP:
            addy_tcap (ptr->value[0],freq,ptr->nodes[0],ptr->nodes[1],ptr->nodes[2],ptr->nodes[3],y);
            break;
         }
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static void gradient_1value (NETLIST *nlist, S_2PORT sp, double freq, COMPLEX *p, COMPLEX *q,
                      COMPLEX *pa, COMPLEX *qa, COMPLEX *grad)
   {
   switch (nlist->type)
      {
      case Netlist_R:
         derivy_resistance (nlist->value[0],nlist->nodes[0],nlist->nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_G:
         derivy_conductance (nlist->value[0],nlist->nodes[0],nlist->nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_C:
         derivy_capacitance (nlist->value[0],freq,nlist->nodes[0],nlist->nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_L:
         derivy_inductance (nlist->value[0],freq,nlist->nodes[0],nlist->nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_TCAP:
         derivy_tcap (nlist->value[0],freq,nlist->nodes[0],nlist->nodes[1],nlist->nodes[2],nlist->nodes[3],sp,p,q,pa,qa,grad);
         break;
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static void gradient_2value (NETLIST *nlist, S_2PORT sp, double freq, COMPLEX *p, COMPLEX *q,
                      COMPLEX *pa, COMPLEX *qa, COMPLEX *grad1, COMPLEX *grad2)
   {
   switch (nlist->type)
      {
      case Netlist_SRL:
         derivy_series_rl (nlist->value[0],nlist->value[1],freq,nlist->nodes[0],nlist->nodes[1],sp,p,q,pa,qa,grad1,grad2);
         break;
      case Netlist_SRC:
         derivy_series_rc (nlist->value[0],nlist->value[1],freq,nlist->nodes[0],nlist->nodes[1],sp,p,q,pa,qa,grad1,grad2);
         break;
      case Netlist_VCCS:
         derivy_vccs (nlist->value[0],nlist->value[1],freq,nlist->nodes[0],nlist->nodes[1],nlist->nodes[2],nlist->nodes[3],sp,p,q,pa,qa,grad1,grad2);
         break;
      }
   }

/********************************************************************************************/
/********************************************************************************************/

void compute_s_grads (NETLIST *nlist, S_2PORT *sMeas, unsigned numf, double *grads)
   {
   unsigned i,j;
   COMPLEX  **y = global_y_matrix;
   COMPLEX  *p = global_p;
   COMPLEX  *q = global_q;
   COMPLEX  *pa = global_pa;
   COMPLEX  *qa = global_qa;
   COMPLEX  grad1[6],grad2[6];
   COMPLEX  yp[4],sdiff[4];
   double   kdiff,magdiff,tmp;
   S_2PORT  sp;
   NETLIST  *ptr;

   // zero the gradient array
   for (j = 0; j < number_of_parameters*6; ++j)
      grads[j] = 0.0;

   for (i = 0; i < numf; ++i)
      {
      create_y_matrix (nlist, sMeas[i].freq, y, y_matrix_size);

      // solve the Y matrix and adjoint matrix, compute s-params, k, and MAG
      twoport_adjoint_solution (y, p, q, pa, qa, y_matrix_size);

      yp[0] = y[1][1];
      yp[1] = y[1][2];
      yp[2] = y[2][1];
      yp[3] = y[2][2];
      y2s (yp,sp.s,50.0);
      k_mag (sp.s,&sp.k,&sp.MAG,&sp.b);
      
      // measured vs. modeled differences

      CAsub (sMeas[i].s,sp.s,sdiff,2,2);

      kdiff = sMeas[i].k - sp.k;
      if (kdiff < 0.0)
         kdiff = -1.0;
      else
         kdiff = 1.0;

      magdiff = sMeas[i].MAG - sp.MAG;
      if (magdiff < 0.0)
         magdiff = -1.0;
      else
         magdiff = 1.0;

      for (ptr = nlist; ptr; ptr = ptr->next)
         {
         switch (ptr->type)
            {
            case Netlist_R:
            case Netlist_C:
            case Netlist_G:
            case Netlist_L:
            case Netlist_TCAP:
               if (ptr->index[0] != STATIC_COMPONENT)
                  {
                  gradient_1value (ptr, sp, sMeas[i].freq, p, q, pa, qa, grad1);
                  
                  grads[mindex(ptr->index[0],0,6)] += Creal (Cmult (Cconj (sdiff[0]),grad1[0]))/Cmag (sdiff[0]);
                  grads[mindex(ptr->index[0],1,6)] += Creal (Cmult (Cconj (sdiff[1]),grad1[1]))/Cmag (sdiff[1]);
                  grads[mindex(ptr->index[0],2,6)] += Creal (Cmult (Cconj (sdiff[2]),grad1[2]))/Cmag (sdiff[2]);
                  grads[mindex(ptr->index[0],3,6)] += Creal (Cmult (Cconj (sdiff[3]),grad1[3]))/Cmag (sdiff[3]);
                  grads[mindex(ptr->index[0],4,6)] += kdiff*Creal (grad1[4]);
                  grads[mindex(ptr->index[0],5,6)] += magdiff*Creal (grad1[5]);
                  }
               break;

            case Netlist_SRL:
            case Netlist_SRC:
            case Netlist_VCCS:
               if ((ptr->index[0] != STATIC_COMPONENT) || (ptr->index[1] != STATIC_COMPONENT))
                  gradient_2value (ptr, sp, sMeas[i].freq, p, q, pa, qa, grad1, grad2);
               
               if (ptr->index[0] != STATIC_COMPONENT)
                  {
                  grads[mindex(ptr->index[0],0,6)] += Creal (Cmult (Cconj (sdiff[0]),grad1[0]))/Cmag (sdiff[0]);
                  grads[mindex(ptr->index[0],1,6)] += Creal (Cmult (Cconj (sdiff[1]),grad1[1]))/Cmag (sdiff[1]);
                  grads[mindex(ptr->index[0],2,6)] += Creal (Cmult (Cconj (sdiff[2]),grad1[2]))/Cmag (sdiff[2]);
                  grads[mindex(ptr->index[0],3,6)] += Creal (Cmult (Cconj (sdiff[3]),grad1[3]))/Cmag (sdiff[3]);
                  grads[mindex(ptr->index[0],4,6)] += kdiff*Creal (grad1[4]);
                  grads[mindex(ptr->index[0],5,6)] += magdiff*Creal (grad1[5]);
                  }
               
               if (ptr->index[1] != STATIC_COMPONENT)
                  {
                  grads[mindex(ptr->index[1],0,6)] += Creal (Cmult (Cconj (sdiff[0]),grad2[0]))/Cmag (sdiff[0]);
                  grads[mindex(ptr->index[1],1,6)] += Creal (Cmult (Cconj (sdiff[1]),grad2[1]))/Cmag (sdiff[1]);
                  grads[mindex(ptr->index[1],2,6)] += Creal (Cmult (Cconj (sdiff[2]),grad2[2]))/Cmag (sdiff[2]);
                  grads[mindex(ptr->index[1],3,6)] += Creal (Cmult (Cconj (sdiff[3]),grad2[3]))/Cmag (sdiff[3]);
                  grads[mindex(ptr->index[1],4,6)] += kdiff*Creal (grad2[4]);
                  grads[mindex(ptr->index[1],5,6)] += magdiff*Creal (grad2[5]);
                  }
               break;
            }
         }
      }

   // divide by the number of frequency points
   tmp = 1.0/((double) numf);
   for (j = 0; j < number_of_parameters*6; ++j)
      grads[j] *= tmp;

   }

/********************************************************************************************/
/********************************************************************************************/

void compute_s_error (NETLIST *nlist, S_2PORT *sMeas, unsigned numf, double *error)
   {
   unsigned i;
   COMPLEX  **y = global_y_matrix;
   COMPLEX  yp[4];
   double   tmp;
   S_2PORT  sp;
   
   for (i = 0; i < 6; ++i)
      error[i] = 0.0;

   for (i = 0; i < numf; ++i)
      {
      create_y_matrix (nlist, sMeas[i].freq, y, y_matrix_size);

      complex_matrix_reduction (y, y_matrix_size, 3);

      yp[0] = y[1][1];
      yp[1] = y[1][2];
      yp[2] = y[2][1];
      yp[3] = y[2][2];
      y2s (yp,sp.s,50.0);
      k_mag (sp.s,&sp.k,&sp.MAG,&sp.b);

      error[0] += Cmag (Csub (sp.s[0],sMeas[i].s[0]));
      error[1] += Cmag (Csub (sp.s[1],sMeas[i].s[1]));
      error[2] += Cmag (Csub (sp.s[2],sMeas[i].s[2]));
      error[3] += Cmag (Csub (sp.s[3],sMeas[i].s[3]));
      error[4] += fabs (sMeas[i].k - sp.k);
      error[5] += fabs (sMeas[i].MAG - sp.MAG);
      }

   tmp = 1.0/((double) numf);
   for (i = 0; i < 6; ++i)
      error[i] *= tmp;
   }

/********************************************************************************************/
/********************************************************************************************/

static void update_netlist (double *p_list, NETLIST *nlist)
   {
   NETLIST *ptr;

   for (ptr = nlist; ptr; ptr = ptr->next)
      {
      switch (ptr->type)
         {
         case Netlist_SRL:
         case Netlist_SRC:
         case Netlist_VCCS:
            if (ptr->index[1] != STATIC_COMPONENT)
               ptr->value[1] = p_list[ptr->index[1]];

         case Netlist_R:
         case Netlist_C:
         case Netlist_G:
         case Netlist_L:
         case Netlist_TCAP:
            if (ptr->index[0] != STATIC_COMPONENT)
               ptr->value[0] = p_list[ptr->index[0]];
            break;
         }
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static double *ss_error_interface (double *pl)
   {
   static double error[6];

   // update the netlist values
   update_netlist (pl, global_netlist_pointer);

   // compute the error function
   compute_s_error (global_netlist_pointer, global_sp_pointer, number_of_frequencies, error);

   return error;
   }

/********************************************************************************************/
/********************************************************************************************/

static double *ss_gradient_interface (double *pl)
   {
   // update the netlist values
   update_netlist (pl, global_netlist_pointer);

   // compute the gradient function
   compute_s_grads (global_netlist_pointer, global_sp_pointer, number_of_frequencies, global_gradient_pointer);

   return global_gradient_pointer;
   }


/********************************************************************************************/
/********************************************************************************************/

static int check_netlist (NETLIST *nlist, PARAM_STRUCT *p, unsigned n_params)
   {
   NETLIST   *ptr;
   int *node_check;
   int *index_check;
   unsigned largest = 0;
   unsigned i,msize;
   int removed_nodes = 0;
   int error = 0;

   if (!nlist)
      return -1;

   // check that the netlist is valid and that all parameters and netlist values match up

   for (ptr = nlist; ptr; ptr = ptr->next)
      {
      switch (ptr->type)
         {
         case Netlist_VCCS:
         case Netlist_TCAP:
            if (ptr->nodes[2] > largest)
               largest = ptr->nodes[2];

            if (ptr->nodes[3] > largest)
               largest = ptr->nodes[3];

            if ((ptr->index[1] >= n_params) && (ptr->index[1] != STATIC_COMPONENT))
               {
               fprintf (stderr,"NETLIST ERROR: parameter \'%s\' - index value is illegal.\n",ptr->id);
               error = 1;
               }

         case Netlist_R:
         case Netlist_C:
         case Netlist_G:
         case Netlist_L:
         case Netlist_SRL:
         case Netlist_SRC:
            if (ptr->nodes[0] > largest)
               largest = ptr->nodes[0];

            if (ptr->nodes[1] > largest)
               largest = ptr->nodes[1];

            if ((ptr->index[0] >= n_params) && (ptr->index[0] != STATIC_COMPONENT))
               {
               fprintf (stderr,"NETLIST ERROR: parameter \'%s\' - index value is illegal.\n",ptr->id);
               error = 1;
               }

            break;

         default:
            fprintf (stderr,"NETLIST ERROR: parameter \'%s\' - unknown type.\n",ptr->id);
            error = 1;
            break;
         }
      }

   if (error)
      return -1;

   msize = largest+1;
   node_check = (int *) malloc (sizeof (int)*(msize));
   index_check = (int *) malloc (sizeof (int)*(n_params));

   for (i = 0; i < msize; ++i)
      node_check[i] = 0;
   for (i = 0; i < n_params; ++i)
      index_check[i] = 0;

   for (ptr = nlist; ptr; ptr = ptr->next)
      {
      switch (ptr->type)
         {
         case Netlist_VCCS:
         case Netlist_TCAP:
            ++node_check[ptr->nodes[2]];
            ++node_check[ptr->nodes[3]];

         case Netlist_SRL:
         case Netlist_SRC:
            if (ptr->index[1] != STATIC_COMPONENT)
               ++index_check[ptr->index[1]];

         case Netlist_R:
         case Netlist_C:
         case Netlist_G:
         case Netlist_L:
            ++node_check[ptr->nodes[0]];
            ++node_check[ptr->nodes[1]];
            if (ptr->index[0] != STATIC_COMPONENT)
               ++index_check[ptr->index[0]];
         }
      }

   if (node_check[1] < 1)
      {
      fprintf (stderr,"NETLIST ERROR: nothing connected to PORT 1.\n");
      error = 1;
      }

   if (node_check[2] < 1)
      {
      fprintf (stderr,"NETLIST ERROR: nothing connected to PORT 2.\n");
      error = 1;
      }

   for (i = 3; i <= largest; ++i)
      {
      if (node_check[i] < 2)
         {
         fprintf (stderr,"NETLIST ERROR: node %d has only one connection.\n",i);
         error = 1;
         }
      else if (node_check[i] < 1)
         {
         // remove this node
         for (ptr = nlist; ptr; ptr = ptr->next)
            {
            switch (ptr->type)
               {
               case Netlist_VCCS:
               case Netlist_TCAP:
                  if (ptr->nodes[2] > i)
                     --ptr->nodes[2];
                  if (ptr->nodes[3] > i)
                     --ptr->nodes[3];
                  
               case Netlist_R:
               case Netlist_C:
               case Netlist_G:
               case Netlist_L:
               case Netlist_SRL:
               case Netlist_SRC:
                  if (ptr->nodes[0] > i)
                     --ptr->nodes[0];
                  if (ptr->nodes[1] > i)
                     --ptr->nodes[1];
                  break;
               }
            }

         ++removed_nodes;
         --msize;
         }
      }

   if (removed_nodes)
      fprintf (stderr,"NETLIST WARNING: removed %d unused nodes.\n",removed_nodes);

   for (i = 0; i < n_params; ++i)
      {
      if (index_check[i] > 1)
         fprintf (stderr,"NETLIST WARNING: more than 1 component is assigned to parameter \'%s\'.\n",p[i].name);

      else if (index_check[i] < 1)
         {
         p[i].optimize = FALSE;
         fprintf (stderr,"NETLIST WARNING: no component is assigned to parameter \'%s\'.\n",p[i].name);
         }
      }

   free ((void *) node_check);
   free ((void *) index_check);

   if (error)
      return -1;

   return -0;
   }

/********************************************************************************************/
/********************************************************************************************/

unsigned determine_y_size (NETLIST *nlist)
   {
   unsigned largest = 0;
   NETLIST *ptr;

   for (ptr = nlist; ptr; ptr = ptr->next)
      {
      switch (ptr->type)
         {
         case Netlist_VCCS:
         case Netlist_TCAP:
            if (ptr->nodes[2] > largest)
               largest = ptr->nodes[2];

            if (ptr->nodes[3] > largest)
               largest = ptr->nodes[3];

         case Netlist_R:
         case Netlist_C:
         case Netlist_G:
         case Netlist_L:
         case Netlist_SRL:
         case Netlist_SRC:
            if (ptr->nodes[0] > largest)
               largest = ptr->nodes[0];

            if (ptr->nodes[1] > largest)
               largest = ptr->nodes[1];

            break;
         }
      }

   return largest + 1;
   }

/********************************************************************************************/
/********************************************************************************************/

#ifdef DEBUG
static void compare_gradients_debug (NETLIST *nlist, S_2PORT *sp, unsigned num_s, PARAM_STRUCT *p,
                              unsigned num_p, char *numeric_file, char *tellegrin_file)
   {
   FILE *file;
   double *pl = (double *) malloc (sizeof (double)*num_p);
   double *grads = (double *) malloc (sizeof (double)*num_p*6);
   double e1[6];
   double e2[6];
   unsigned i;
   double tmp,delta;
   double del = 0.05;

   for (i = 0; i < num_p; ++i)
      pl[i] = p[i].nom;

   /* compute tellegrin gradients */

   update_netlist (pl, nlist);
   compute_s_grads (nlist, sp, num_s, grads);

   file = fopen (tellegrin_file, "w+");

   for (i = 0; i < num_p; ++i)
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %12.4e %12.4e\n",
         grads[i*6],grads[i*6 + 1],grads[i*6 + 2],
         grads[i*6 + 3],grads[i*6 + 4],grads[i*6 + 5]);

   fclose (file);

   /* compute numerical gradients */

   file = fopen (numeric_file, "w+");

   for (i = 0; i < num_p; ++i)
      {
      tmp = pl[i];

      delta = fabs (pl[i]*del);
      if (delta < 1.0e-16)
         delta = 1.0e-16;

      // positive
      pl[i] = tmp + delta;
      update_netlist (pl, nlist);
      compute_s_error (nlist, sp, num_s, e1);

      // negative
      pl[i] = tmp - delta;
      update_netlist (pl, nlist);
      compute_s_error (nlist, sp, num_s, e2);

      pl[i] = tmp;

      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %12.4e %12.4e\n",
         (e2[0]-e1[0])*0.5/delta,(e2[1]-e1[1])*0.5/delta,(e2[2]-e1[2])*0.5/delta,
         (e2[3]-e1[3])*0.5/delta,(e2[4]-e1[4])*0.5/delta,(e2[5]-e1[5])*0.5/delta);
      }

   fclose (file);

   free ((void *) pl);
   free ((void *) grads);
   }
#endif

/********************************************************************************************/
/********************************************************************************************/

int small_signal_optimizer (NETLIST *nlist, PARAM_STRUCT *p, unsigned n_params, S_2PORT *sp,
                            unsigned numf, int max_iter, double *weights)
   {
   OPT_STRUCT  opt;
   int error = 0;

   if (check_netlist (nlist, p, n_params))
      {
      fprintf (stderr,"Error(s) encountered during netlist parsing. Unable to continue.\n");
      return -1;
      }

   y_matrix_size = determine_y_size (nlist);
   if (y_matrix_size < 2)
      {
      fprintf (stderr,"ERROR: Not enough nodes. Minimum is 2.\n");
      return -1;
      }

   // make the netlist and measured S-parameters available globally
   global_netlist_pointer = nlist;
   global_sp_pointer = sp;
   number_of_frequencies = numf;
   number_of_parameters = n_params;

   // allocate memory 
   global_y_matrix = allocate_2d_complex_matrix (y_matrix_size);
   global_gradient_pointer = (double *) malloc (sizeof (double)*n_params*6);
   global_p = (COMPLEX *) malloc (sizeof(COMPLEX)*y_matrix_size);
   global_q = (COMPLEX *) malloc (sizeof(COMPLEX)*y_matrix_size);
   global_pa = (COMPLEX *) malloc (sizeof(COMPLEX)*y_matrix_size);
   global_qa = (COMPLEX *) malloc (sizeof(COMPLEX)*y_matrix_size);

   // set up the optimization structure
   initialize_optimizer (&opt,n_params,6,weights,max_iter,&ss_error_interface);
   opt.err_fraction = 1.0e-9;
   opt.gradients = &ss_gradient_interface;
   // opt.mapping_mode = OPT_LINEAR_MAPPING;
   strcpy (opt.pformat,"%.3f");

   if (cg_optimize (opt,p))
      error = 1;

   compare_gradients_debug (nlist, sp, numf, p, n_params, "grad_n.txt", "grad_t.txt");

   // free allocated memory
   free_matrix (global_y_matrix, y_matrix_size);
   free ((void *) global_gradient_pointer);
   free ((void *) global_p);
   free ((void *) global_q);
   free ((void *) global_pa);
   free ((void *) global_qa);

   if (error)
      return -1;

   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

COMPLEX *small_signal_model (NETLIST *nlist, COMPLEX **y, unsigned sizeofy, double freq)
   {
   static COMPLEX sp[4];

   create_y_matrix (nlist, freq, y, sizeofy);

   solve_y_for_2port_s (y, sp, sizeofy);

   return sp;
   }

/********************************************************************************************/
/********************************************************************************************/

NETLIST *netlist_component (int type, ...)
   {
   va_list  ap;
   NETLIST  *nlist = malloc (sizeof(NETLIST));

   va_start (ap, type);

   nlist->type = type;
   switch (type)
      {
      case Netlist_R:
      case Netlist_C:
      case Netlist_G:
      case Netlist_L:
         nlist->value[0] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, unsigned);
         nlist->nodes[1] = va_arg (ap, unsigned);
         nlist->index[0] = va_arg (ap, unsigned);
         break;

      case Netlist_TCAP:
         nlist->value[0] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, unsigned);
         nlist->nodes[1] = va_arg (ap, unsigned);
         nlist->nodes[2] = va_arg (ap, unsigned);
         nlist->nodes[3] = va_arg (ap, unsigned);
         nlist->index[0] = va_arg (ap, unsigned);
         break;

      case Netlist_SRL:
      case Netlist_SRC:
         nlist->value[0] = va_arg (ap, double);
         nlist->value[1] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, unsigned);
         nlist->nodes[1] = va_arg (ap, unsigned);
         nlist->index[0] = va_arg (ap, unsigned);
         nlist->index[1] = va_arg (ap, unsigned);
         break;

      case Netlist_VCCS:
         nlist->value[0] = va_arg (ap, double);
         nlist->value[1] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, unsigned);
         nlist->nodes[1] = va_arg (ap, unsigned);
         nlist->nodes[2] = va_arg (ap, unsigned);
         nlist->nodes[3] = va_arg (ap, unsigned);
         nlist->index[0] = va_arg (ap, unsigned);
         nlist->index[1] = va_arg (ap, unsigned);
         break;

      default:
         nlist->type = Netlist_UNKNOWN;
         break;
      }

   va_end (ap);
   return nlist;
   }

/********************************************************************************************/
/********************************************************************************************/

void free_netlist (NETLIST *nlist)
   {
   NETLIST *ptr = nlist;
   NETLIST *lptr;

   while (ptr)
      {
      lptr = ptr;
      ptr = ptr->next;
      free ((void *) lptr);
      }
   }

/********************************************************************************************/
/********************************************************************************************/

NETLIST *va_generate_netlist (int start, ...)
   {
   va_list  ap;
   NETLIST  *nlist = NULL;
   NETLIST  *lptr = NULL;
   NETLIST  *ptr;

   va_start (ap, start);

   while (ptr = va_arg (ap, NETLIST *))
      {
      if (lptr)
         {
         lptr->next = ptr;
         ptr->next = NULL;
         lptr = ptr;
         }
      else
         {
         nlist = ptr;
         lptr = ptr;
         }
      }

   va_end (ap);

   return nlist;
   }

/********************************************************************************************/
/********************************************************************************************/

NETLIST *generate_netlist (NETLIST *nlist[], int szNlist)
   {
   int i;

   for (i = 1; i < szNlist; ++i)
      {
      nlist[i-1]->next = nlist[i];
      nlist[i]->next = NULL;
      }

   return nlist[0];
   }

/********************************************************************************************/
/********************************************************************************************/

static char *string_to_upper (char *string)
   {
   unsigned i;

   for (i = 0; i < strlen (string); ++i)
      {
      if ((string[i] > (char) 96) && (string[i] < (char) 123))
         string[i] -= (char) 32;
      }

   return string;
   }

/********************************************************************************************/
/********************************************************************************************/

unsigned read_s_from_file (char *filename, S_2PORT *sp, S_BIAS *bias, unsigned sizeofs)
   {
   FILE *infile;
   double freq_mult = 1.0;
   double t[4];
   double impedance;
   POLAR tmpp[4];
   char string[300];
   char units[6],dtype[6],ptype;
   int ri_format = 0;
   int db_format = 0;
   unsigned i = 0;
   int flag = 0;

   infile = fopen (filename,"r");
   if (!infile)
      return 0;

   if (!sp || (sizeofs < 1))
      return 0;

   if (bias)
      {
      bias->vgs = bias->vds = bias->ids = bias->igs = 0.0;
      bias->dtype = UNKNOWN_DEVICE;
      }

   while (fgets (string,299,infile))
      {
      if (!strncmp (string,"!BIAS",5) && bias)
         {
         if (flag)
            break;

         string_to_upper (string);
         if (sscanf (string,"!BIAS: VCE = %lf VOLTS ICE = %lf AMPS VBE = %lf VOLTS IBE = %lf AMPS",&t[0],&t[1],&t[2],&t[3]) == 4)
            {
            bias->vds = t[0];
            bias->ids = t[1];
            bias->vgs = t[2];
            bias->igs = t[3];
            bias->dtype = HBT_DEVICE;
            }
         else if (sscanf (string,"!BIAS: VDS = %lf VOLTS IDS = %lf AMPS VGS = %lf VOLTS IGS = %lf AMPS",&t[0],&t[1],&t[2],&t[3]) == 4)
            {
            bias->vds = t[0];
            bias->ids = t[1];
            bias->vgs = t[2];
            bias->igs = t[3];
            bias->dtype = FET_DEVICE;
            }
         }
      else if (string[0] == '!')
         {
         if (flag)
            break;
         continue;
         }

      if (sscanf (string,"# %5s %c %5s R %lf",units,&ptype,dtype,&impedance) == 4)
         {
         if (!strcasecmp (units,"khz"))
            freq_mult = 1.0e3;
         else if (!strcasecmp (units,"mhz"))
            freq_mult = 1.0e6;
         else if (!strcasecmp (units,"ghz"))
            freq_mult = 1.0e9;
            
         if (!strcasecmp (dtype,"ri"))
            ri_format = 1;
         else if (!strcasecmp (dtype,"db"))
            db_format = 1;
         }
      
      if (i >= sizeofs)
         break;

      if (ri_format)
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&sp[i].freq,&sp[i].s[0].r,&sp[i].s[0].i,
            &sp[i].s[2].r,&sp[i].s[2].i,&sp[i].s[1].r,&sp[i].s[1].i,&sp[i].s[3].r,&sp[i].s[3].i) == 9)
            {
            flag = 1;
            sp[i].freq *= freq_mult;
            k_mag (sp[i].s, &sp[i].k, &sp[i].MAG, &sp[i].b);
            ++i;
            }
         }
      else
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&sp[i].freq,&tmpp[0].m,&tmpp[0].a,
            &tmpp[2].m,&tmpp[2].a,&tmpp[1].m,&tmpp[1].a,&tmpp[3].m,&tmpp[3].a) == 9)
            {
            if (db_format)
               {
               tmpp[0].m = pow (10.0, tmpp[0].m*0.05);
               tmpp[1].m = pow (10.0, tmpp[1].m*0.05);
               tmpp[2].m = pow (10.0, tmpp[2].m*0.05);
               tmpp[3].m = pow (10.0, tmpp[3].m*0.05);
               }
            flag = 1;
            PA2CA (tmpp, sp[i].s, 2, 2);
            sp[i].freq *= freq_mult;
            k_mag (sp[i].s, &sp[i].k, &sp[i].MAG, &sp[i].b);
            ++i;
            }         
         }
      }

   fclose (infile);

   return i;
   }






