typedef struct _NETLIST_DEF
 {
 int type;          // element type
 int nodes[10];     // node connections
 double value[10];  // element values
 int index[10];     // gradient array position index
 } NETLIST;

#define Netlist_R      0
#define Netlist_G      1
#define Netlist_C      2
#define Netlist_L      3
#define Netlist_SRL    4
#define Netlist_SRC    5
#define Netlist_TCAP   6
#define Netlist_VCCS   7

typedef struct _S_2PORT_DEF
 {
 double freq;
 COMPLEX s[4];
 double k;
 double MAG;
 double b;
 } S_2PORT;

typedef struct _s_bias
   {
   double vds,ids,vgs,igs;
   } S_BIAS;
 

