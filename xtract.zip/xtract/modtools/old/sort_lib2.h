
#ifndef _SORTING_TYPES
#define _SORTING_TYPES

union sort_types
   {
   double *dbl;
   int *intv;
   char *strg;
   };

typedef struct _sorting_struct
{
union sort_types *value; 
unsigned long position;
struct _sorting_struct *next;
} SORT_STRUCT;

#define INT      10
#define DOUBLE   12
#define STRING   14

extern SORT_STRUCT *sort_data (SORT_STRUCT *sort_struct, int order[], int types[], int n);
extern SORT_STRUCT *create_sorting_structure (int nparams, int types[], unsigned long position,
                                       SORT_STRUCT *prev, ...);
extern void free_sorting_structure (SORT_STRUCT *s);
extern void free_sorting_list (SORT_STRUCT *s);

#endif
