#include <cmplxlib.h>
#include <ss_types.h>
#include <optimize3.h>

// create a square 2-D COMPLEX matrix
extern COMPLEX **allocate_2d_complex_matrix (unsigned size);

// free the COMPLEX matrix created by the above function
extern void free_matrix (COMPLEX **matrix, unsigned size);
 
// complex matrix reduction by gaussian elimination, performed in place
extern void complex_matrix_reduction (COMPLEX **x, unsigned xsize, unsigned reduced_size);

// solve a [Y] matrix for 2-port [S] parameters, ym reduction is done in place
extern void solve_y_for_2port_s (COMPLEX **y, COMPLEX *s, unsigned ysize); 

// two-port [Y] matrix solution for ym and ym(transpose)
// p, q, pa, and qa are the output vectors of the node voltage solutions
// ym is reduced in place
extern void twoport_adjoint_solution (COMPLEX **y, COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, unsigned ysize);

// create a [Y] matrix from a NETLIST
extern void create_y_matrix (NETLIST *nlist, double freq, COMPLEX **y, unsigned ysize);

// compute gradients for elements of a NETLIST 
// gradients are returned in grads[][6], where the outer index position of grads is
//  determined from the nlist.index[] for each nlist.value[]
extern void compute_s_grads (NETLIST *nlist, S_2PORT *sMeas, unsigned numf, double *grads);

// compute the error functions w.r.t. [S], K and MAG for a NETLIST
// error functions are returned in error[6]
extern void compute_s_error (NETLIST *nlist, S_2PORT *sMeas, unsigned numf, double *error);

// returns the needed size of a [Y]-matrix to optimize/model the passed netlist
extern unsigned determine_y_size (NETLIST *nlist);

// automatically perform a small-signal optimization on the PARAM_STRUCT p
// where the nlist.index[] in this case is used to determine the position of each
//  nlist.value[] within the PARAM_STRUCT
extern int small_signal_optimizer (NETLIST *nlist, PARAM_STRUCT *p, unsigned n_params, S_2PORT *sp,
                            unsigned numf, int max_iter, double *weights);

// return s-parameters from the given netlist
extern COMPLEX *small_signal_model (NETLIST *nlist, COMPLEX **y, unsigned sizeofy, double freq);

// generate a netlist pointer for a single component
extern NETLIST *netlist_component (int type, ...);

// generate a netlist from a NULL terminated list of netlist component pointers
// start is a meaningless integer used to determine the starting address of the
// variable argument list
NETLIST *va_generate_netlist (int start, ...);

// generate a netlist from an array of netlist component pointers
NETLIST *generate_netlist (NETLIST *nlist[], int szNlist);

// free a netlist generated with one of the above two functions
extern void free_netlist (NETLIST *nlist);

// read [S]-parameters from a file
extern unsigned read_s_from_file (char *filename, S_2PORT *sp, S_BIAS *bias, unsigned sizeofsp);




 