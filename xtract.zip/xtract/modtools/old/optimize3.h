#ifndef _GRADIENT_OPTIMIZER_INCLUDES
#define _GRADIENT_OPTIMIZER_INCLUDES

#include "optimize_types.h"

extern int cg_optimize (OPT_STRUCT x, PARAM_STRUCT *p);
extern void initialize_optimizer (OPT_STRUCT *x, int np, int nc, double *weights, int niter, double *(*err_f)(double *pl));

#endif
