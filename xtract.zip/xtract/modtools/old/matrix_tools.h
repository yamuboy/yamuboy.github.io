#include <math.h>
#include "cmplxlib.h"
#include "matrix_types.h"
#include "optimize3.h"

// 2-dimensional matrix position indexing function, column indexes are from 0 to (ncols-1)
extern int mindex (int row, int col, int ncols);

// complex matrix reduction by gaussian elimination, performed in place
extern void complex_matrix_reduction (COMPLEX *x, int xsize, int reduced_size);

// solve a [Y] matrix for 2-port [S] parameters, ym reduction is done in place
extern void solve_y_for_2port_s (COMPLEX *ym, COMPLEX *s, int ymsize); 

// two-port [Y] matrix solution for ym and ym(transpose)
// p, q, pa, and qa are the output vectors of the node voltage solutions
// ym is reduced in place
extern void twoport_adjoint_solution (COMPLEX *ym, COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, int ymsize);

// functions to add general admittances to the [Y] array ym
extern void add_ybranch (COMPLEX y, int n1, int n2, COMPLEX *ym, int ymsize);
extern void add_yvccs (COMPLEX y, int vp, int vm, int cm, int cp, COMPLEX *ym, int ymsize);

// functions to add specific elements to the [Y] array ym
extern void addy_resistance (double r, int n1, int n2, COMPLEX *ym, int ymsize);
extern void addy_conductance (double g, int n1, int n2, COMPLEX *ym, int ymsize);
extern void addy_capacitance (double c, double freq, int n1, int n2, COMPLEX *ym, int ymsize);
extern void addy_inductance (double l, double freq, int n1, int n2, COMPLEX *ym, int ymsize);
extern void addy_series_rl (double r, double l, double freq, int n1, int n2, COMPLEX *ym, int ymsize);
extern void addy_series_rc (double r, double c, double freq, int n1, int n2, COMPLEX *ym, int ymsize);
extern void addy_trans_cap (double c, double freq, int n_vp, int n_vm, int n_cm, int n_cp, COMPLEX *ym, int ymsize);
extern void addy_delayed_vccs (double gm, double tau, double freq, int n_vp, int n_vm, int n_cm, int n_cp, COMPLEX *ym, int ymsize);

// derivative functions for derivatives of [S], K and MAG w.r.t. circuit elements
// dervX are the output vectors and are of size 6
extern void derivy_resistance (double r, int n1, int n2, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr);
extern void derivy_conductance (double g, int n1, int n2, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervg);
extern void derivy_capacitance (double c, double freq, int n1, int n2, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervc);
extern void derivy_inductance (double l, double freq, int n1, int n2, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervl);
extern void derivy_series_rl (double r, double l, double freq, int n1, int n2, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr, COMPLEX *dervl);
extern void derivy_series_rc (double r, double c, double freq, int n1, int n2, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr, COMPLEX *dervc);
extern void derivy_trans_cap (double c, double freq, int vp, int vm, int cm, int cp, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervc);
extern void derivy_delayed_vccs (double gm, double tau, double freq, int vp, int vm, int cm, int cp, S_2PORT meas_s,
                 COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervgm, COMPLEX *dervtau);

// create a [Y] matrix from a NETLIST
extern int create_y (NETLIST *nlist, int nelem, double freq, COMPLEX *ym, int maxnode);

// compute gradients for elements of a NETLIST 
// gradients are returned in grads[][6], where the outer index position of grads is
//  determined from the nlist.index[] for each nlist.value[]
extern void compute_s_grads (NETLIST *nlist, int nelem, S_2PORT *sMeas, int numf, double *grads);

// compute the error functions w.r.t. [S], K and MAG for a NETLIST
// error functions are returned in error[6]
extern void compute_s_error (NETLIST *nlist, int nelem, S_2PORT *sMeas, int numf, double *error);

// automatically perform a small-signal optimization on the PARAM_STRUCT p
// where the nlist.index[] in this case is used to determine the position of each
//  nlist.value[] within the PARAM_STRUCT
extern int small_signal_optimizer (NETLIST *nlist, int nelem, PARAM_STRUCT *p, int n_params, S_2PORT *sp,
                            int numf, int max_iter, double *weights);

extern void netlist_component (NETLIST *nlist, int type, ...);

extern int read_s_from_file (char *filename, S_2PORT *sp, S_BIAS *sbias, int spsize);




 