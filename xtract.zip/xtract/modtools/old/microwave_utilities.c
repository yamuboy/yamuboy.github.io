#include <math.h>

typedef struct
{
double real;
double imag;
} COMPLEX;

typedef struct
{
double mag;
double ang;
} POLAR;

COMPLEX complex_add ();
COMPLEX complex_sub ();
COMPLEX complex_mult ();
COMPLEX complex_div ();
COMPLEX polar_to_rect ();

POLAR polar_div ();
POLAR polar_mult ();
POLAR polar_sub ();
POLAR polar_add ();
POLAR rect_to_polar ();

COMPLEX *polar_2x2_rect ();
POLAR   *rect_2x2_polar ();

COMPLEX *complex_2x2_add ();
COMPLEX *complex_2x2_sub ();
COMPLEX *complex_2x2_mult ();
COMPLEX *complex_2x2_inv ();

COMPLEX *embed ();
COMPLEX *deembed ();

COMPLEX *s2h ();
COMPLEX *s2y ();
COMPLEX *s2z ();
COMPLEX *s2t ();
COMPLEX *s2abcd ();

COMPLEX *y2h ();
COMPLEX *y2z ();
COMPLEX *y2t ();
COMPLEX *y2abcd ();
COMPLEX *y2s ();

COMPLEX *z2h ();
COMPLEX *z2y ();
COMPLEX *z2t ();
COMPLEX *z2abcd ();
COMPLEX *z2s ();

COMPLEX *abcd2h ();
COMPLEX *abcd2y ();
COMPLEX *abcd2z ();
COMPLEX *abcd2t ();
COMPLEX *abcd2s ();

COMPLEX *t2h ();
COMPLEX *t2y ();
COMPLEX *t2s ();
COMPLEX *t2abcd ();
COMPLEX *t2z ();

/*                                                                   */
/*--- Function complex_add ------------------------------------------*/
/*                                                                   */

COMPLEX complex_add (a,b)
COMPLEX a;
COMPLEX b;

{
COMPLEX c;

c.real = a.real+b.real;
c.imag = a.imag+b.imag;

return (c);

}

/*                                                                   */
/*--- Function complex_sub ------------------------------------------*/
/*                                                                   */

COMPLEX complex_sub (a,b)
COMPLEX a;
COMPLEX b;

{
COMPLEX c;

c.real = a.real-b.real;
c.imag = a.imag-b.imag;

return (c);

}

/*                                                                   */
/*--- Function complex_mult -----------------------------------------*/
/*                                                                   */

COMPLEX complex_mult (a,b)
COMPLEX a;
COMPLEX b;

{
COMPLEX c;

c.real = (a.real*b.real)-(a.imag*b.imag);
c.imag = (a.real*b.imag)+(b.real*a.imag);

return (c);

}

/*                                                                   */
/*--- Function complex_div ------------------------------------------*/
/*                                                                   */

COMPLEX complex_div (a,b)
COMPLEX a;
COMPLEX b;

{
COMPLEX c;

c.real = ((a.real*b.real)+(a.imag*b.imag))/((b.real*b.real)+(b.imag*b.imag));
c.imag = ((b.real*a.imag)-(a.real*b.imag))/((b.real*b.real)+(b.imag*b.imag));

return (c);

}

/*                                                                   */
/*--- Function polar_add --------------------------------------------*/
/*                                                                   */

POLAR polar_add (a,b)
POLAR a;
POLAR b;

{
POLAR  c;
double rad_to_deg;
double deg_to_rad;
double real;
double imag;

deg_to_rad = acos((double) -1.0)/((double) 180.0);
rad_to_deg = ((double) 180.0)/acos((double) -1.0);

real = a.mag*cos(a.ang*deg_to_rad)+b.mag*cos(b.ang*deg_to_rad);
imag = a.mag*sin(a.ang*deg_to_rad)+b.mag*sin(b.ang*deg_to_rad);

c.mag = sqrt((real*real)+(imag*imag));
c.ang = rad_to_deg*atan2(imag,real);

return (c);

}

/*                                                                   */
/*--- Function polar_sub --------------------------------------------*/
/*                                                                   */

POLAR polar_sub (a,b)
POLAR a;
POLAR b;

{
POLAR  c;
double rad_to_deg;
double deg_to_rad;
double real;
double imag;

deg_to_rad = acos((double) -1.0)/((double) 180.0);
rad_to_deg = ((double) 180.0)/acos((double) -1.0);

real = a.mag*cos(a.ang*deg_to_rad)-b.mag*cos(b.ang*deg_to_rad);
imag = a.mag*sin(a.ang*deg_to_rad)-b.mag*sin(b.ang*deg_to_rad);

c.mag = sqrt((real*real)+(imag*imag));
c.ang = rad_to_deg*atan2(imag,real);

return (c);

}

/*                                                                   */
/*--- Function polar_mult -------------------------------------------*/
/*                                                                   */

POLAR polar_mult (a,b)
POLAR a;
POLAR b;

{
POLAR c;

c.mag = a.mag*b.mag;
c.ang = a.ang+b.ang;

if (c.ang > ((double) 180.0))
   {
   c.ang = c.ang-((double) 360.0);
   }
else if (c.ang < ((double) -180.0))
   {
   c.ang = c.ang+((double) 360.0);
   }

return (c);

}

/*                                                                   */
/*--- Function polar_div --------------------------------------------*/
/*                                                                   */

POLAR polar_div (a,b)
POLAR a;
POLAR b;

{
POLAR c;

c.mag = a.mag/b.mag;
c.ang = a.ang-b.ang;

if (c.ang > ((double) 180.0))
   {
   c.ang = c.ang-((double) 360.0);
   }
else if (c.ang < ((double) -180.0))
   {
   c.ang = c.ang+((double) 360.0);
   }

return (c);

}

/*                                                                   */
/*--- Function polar_to_rect ----------------------------------------*/
/*                                                                   */

COMPLEX polar_to_rect (a)
POLAR a;

{
COMPLEX b;
double  deg_to_rad;

deg_to_rad = acos((double) -1.0)/((double) 180.0);

b.real = a.mag*cos(a.ang*deg_to_rad);
b.imag = a.mag*sin(a.ang*deg_to_rad);

return (b);

}

/*                                                                   */
/*--- Function rect_to_polar ----------------------------------------*/
/*                                                                   */

POLAR rect_to_polar (a)
COMPLEX a;

{
POLAR  b;
double rad_to_deg;

rad_to_deg = ((double) 180.0)/acos((double) -1.0);

b.mag = sqrt(a.real*a.real+a.imag*a.imag);

if ((a.real == ((double) 0.0)) && (a.imag == ((double) 0.0)))
   {
   b.ang = (double) 0.0;
   }
else
   {
   b.ang = rad_to_deg*atan2(a.imag,a.real);
   }

return (b);

}

/*                                                                   */
/*--- Function rect_2x2_polar ---------------------------------------*/
/*                                                                   */

POLAR *rect_2x2_polar (a,b)
COMPLEX *a;
POLAR   *b;

{

b[0] = rect_to_polar (a[0]);
b[1] = rect_to_polar (a[1]);
b[2] = rect_to_polar (a[2]);
b[3] = rect_to_polar (a[3]);

return (b);

}

/*                                                                   */
/*--- Function polar_2x2_rect ---------------------------------------*/
/*                                                                   */

COMPLEX *polar_2x2_rect (a,b)
POLAR   *a;
COMPLEX *b;

{

b[0] = polar_to_rect (a[0]);
b[1] = polar_to_rect (a[1]);
b[2] = polar_to_rect (a[2]);
b[3] = polar_to_rect (a[3]);

return (b);

}

/*                                                                   */
/*--- Function complex_2x2_add --------------------------------------*/
/*                                                                   */

COMPLEX *complex_2x2_add (a,b,c)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;

{

c[0] = complex_add(a[0],b[0]);
c[1] = complex_add(a[1],b[1]);
c[2] = complex_add(a[2],b[2]);
c[3] = complex_add(a[3],b[3]);

return (c);

}

/*                                                                   */
/*--- Function complex_2x2_sub --------------------------------------*/
/*                                                                   */

COMPLEX *complex_2x2_sub (a,b,c)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;

{

c[0] = complex_sub(a[0],b[0]);
c[1] = complex_sub(a[1],b[1]);
c[2] = complex_sub(a[2],b[2]);
c[3] = complex_sub(a[3],b[3]);

return (c);

}

/*                                                                   */
/*--- Function complex_2x2_mult -------------------------------------*/
/*                                                                   */

COMPLEX *complex_2x2_mult (a,b,c)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;

{
COMPLEX x[4];

x[0] = complex_add(complex_mult(a[0],b[0]),complex_mult(a[1],b[2]));
x[1] = complex_add(complex_mult(a[0],b[1]),complex_mult(a[1],b[3]));
x[2] = complex_add(complex_mult(a[2],b[0]),complex_mult(a[3],b[2]));
x[3] = complex_add(complex_mult(a[2],b[1]),complex_mult(a[3],b[3]));

c[0].real = x[0].real;
c[0].imag = x[0].imag;
c[1].real = x[1].real;
c[1].imag = x[1].imag;
c[2].real = x[2].real;
c[2].imag = x[2].imag;
c[3].real = x[3].real;
c[3].imag = x[3].imag;

return (c);

}

/*                                                                   */
/*--- Function complex_2x2_inv --------------------------------------*/
/*                                                                   */

COMPLEX *complex_2x2_inv (a,b)
COMPLEX *a;
COMPLEX *b;

{
COMPLEX denom;
COMPLEX zero;
COMPLEX x[4];

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_sub(complex_mult(a[0],a[3]),complex_mult(a[1],a[2]));

x[0] = complex_div(a[3],denom);
x[1] = complex_sub(zero,complex_div(a[1],denom));
x[2] = complex_sub(zero,complex_div(a[2],denom));
x[3] = complex_div(a[0],denom);

b[0].real = x[0].real;
b[0].imag = x[0].imag;
b[1].real = x[1].real;
b[1].imag = x[1].imag;
b[2].real = x[2].real;
b[2].imag = x[2].imag;
b[3].real = x[3].real;
b[3].imag = x[3].imag;

return (b);

}

/*                                                                   */
/*--- Function embed ------------------------------------------------*/
/*                                                                   */

COMPLEX *embed (a,b,c,d)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;
COMPLEX *d;

{
COMPLEX z[4];
COMPLEX x[4];

complex_2x2_mult(a,complex_2x2_mult(b,c,z),x);

d[0].real = x[0].real;
d[0].imag = x[0].imag;
d[1].real = x[1].real;
d[1].imag = x[1].imag;
d[2].real = x[2].real;
d[2].imag = x[2].imag;
d[3].real = x[3].real;
d[3].imag = x[3].imag;

return (d);

}

/*                                                                   */
/*--- Function deembed ----------------------------------------------*/
/*                                                                   */

COMPLEX *deembed (a,b,c,d)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;
COMPLEX *d;

{
COMPLEX t1[4];
COMPLEX t2[4];
COMPLEX t3[4];
COMPLEX x[4];

complex_2x2_mult(complex_2x2_inv(a,t3),complex_2x2_mult(b,complex_2x2_inv(c,t1),t2),x);

d[0].real = x[0].real;
d[0].imag = x[0].imag;
d[1].real = x[1].real;
d[1].imag = x[1].imag;
d[2].real = x[2].real;
d[2].imag = x[2].imag;
d[3].real = x[3].real;
d[3].imag = x[3].imag;

return (d);

}

/*                                                                   */
/*--- Function s2h --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2h (s,h,rref)
COMPLEX *s;
COMPLEX *h;
double  rref;

{
COMPLEX one;
COMPLEX two;
COMPLEX neg2;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(one,complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])));

x[0] = complex_mult(complex_mult(complex_sub(complex_mult(complex_add(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom),crref);
x[1] = complex_mult(two,complex_mult(s[1],denom));
x[2] = complex_mult(neg2,complex_mult(s[2],denom));
x[3] = complex_div(complex_mult(complex_sub(complex_mult(complex_sub(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom),crref);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function s2y --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2y (s,y,rref)
COMPLEX *s;
COMPLEX *y;
double  rref;

{
COMPLEX one;
COMPLEX neg2;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(one,complex_mult(complex_sub(complex_mult(complex_add(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),crref));

x[0] = complex_mult(complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom);
x[1] = complex_mult(neg2,complex_mult(s[1],denom));
x[2] = complex_mult(neg2,complex_mult(s[2],denom));
x[3] = complex_mult(complex_add(complex_mult(complex_add(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom);

y[0].real = x[0].real;
y[0].imag = x[0].imag;
y[1].real = x[1].real;
y[1].imag = x[1].imag;
y[2].real = x[2].real;
y[2].imag = x[2].imag;
y[3].real = x[3].real;
y[3].imag = x[3].imag;

return (y);

}

/*                                                                   */
/*--- Function s2z --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2z (s,z,rref)
COMPLEX *s;
COMPLEX *z;
double  rref;

{
COMPLEX one;
COMPLEX two;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(crref,complex_sub(complex_mult(complex_sub(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])));

x[0] = complex_mult(complex_add(complex_mult(complex_add(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom);
x[1] = complex_mult(two,complex_mult(s[1],denom));
x[2] = complex_mult(two,complex_mult(s[2],denom));
x[3] = complex_mult(complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom);

z[0].real = x[0].real;
z[0].imag = x[0].imag;
z[1].real = x[1].real;
z[1].imag = x[1].imag;
z[2].real = x[2].real;
z[2].imag = x[2].imag;
z[3].real = x[3].real;
z[3].imag = x[3].imag;

return (z);

}

/*                                                                   */
/*--- Function s2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2t (s,t)
COMPLEX *s;
COMPLEX *t;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,s[2]);

x[0] = complex_add(zero,denom);
x[1] = complex_sub(zero,complex_mult(s[3],denom));
x[2] = complex_mult(s[0],denom);
x[3] = complex_mult(complex_sub(complex_mult(s[1],s[2]),complex_mult(s[0],s[3])),denom);

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function s2abcd -----------------------------------------------*/
/*                                                                   */

COMPLEX *s2abcd (s,abcd,rref)
COMPLEX *s;
COMPLEX *abcd;
double  rref;

{
COMPLEX one;
COMPLEX two;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(one,complex_mult(two,s[2]));

x[0] = complex_mult(complex_add(complex_mult(complex_add(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom);
x[1] = complex_mult(complex_mult(complex_sub(complex_mult(complex_add(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom),crref);
x[2] = complex_div(complex_mult(complex_sub(complex_mult(complex_sub(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom),crref);
x[3] = complex_mult(complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom);

abcd[0].real = x[0].real;
abcd[0].imag = x[0].imag;
abcd[1].real = x[1].real;
abcd[1].imag = x[1].imag;
abcd[2].real = x[2].real;
abcd[2].imag = x[2].imag;
abcd[3].real = x[3].real;
abcd[3].imag = x[3].imag;

return (abcd);

}

/*                                                                   */
/*--- Function y2h --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2h (y,h)
COMPLEX *y;
COMPLEX *h;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,y[0]);

x[0] = complex_add(zero,denom);
x[1] = complex_sub(zero,complex_mult(y[1],denom));
x[2] = complex_mult(y[2],denom);
x[3] = complex_mult(complex_sub(complex_mult(y[0],y[3]),complex_mult(y[1],y[2])),denom);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function y2z --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2z (y,z)
COMPLEX *y;
COMPLEX *z;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,complex_sub(complex_mult(y[0],y[3]),complex_mult(y[1],y[2])));

x[0] = complex_mult(y[3],denom);
x[1] = complex_sub(zero,complex_mult(y[1],denom));
x[2] = complex_sub(zero,complex_mult(y[2],denom));
x[3] = complex_mult(y[0],denom);

z[0].real = x[0].real;
z[0].imag = x[0].imag;
z[1].real = x[1].real;
z[1].imag = x[1].imag;
z[2].real = x[2].real;
z[2].imag = x[2].imag;
z[3].real = x[3].real;
z[3].imag = x[3].imag;

return (z);

}

/*                                                                   */
/*--- Function y2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2t (y,t,rref)
COMPLEX *y;
COMPLEX *t;
double  rref;

{
COMPLEX y11,y12,y21,y22;
COMPLEX one;
COMPLEX neg2;
COMPLEX zero;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

y11 = complex_mult(y[0],crref);
y12 = complex_mult(y[1],crref);
y21 = complex_mult(y[2],crref);
y22 = complex_mult(y[3],crref);

denom = complex_div(one,complex_mult(neg2,y21));

x[0] = complex_mult(complex_sub(complex_mult(complex_add(one,y11),complex_add(one,y22)),complex_mult(y12,y21)),denom);
x[1] = complex_sub(zero,complex_mult(complex_add(complex_mult(complex_add(one,y11),complex_sub(one,y22)),complex_mult(y12,y21)),denom));
x[2] = complex_mult(complex_add(complex_mult(complex_sub(one,y11),complex_add(one,y22)),complex_mult(y12,y21)),denom);
x[3] = complex_sub(zero,complex_mult(complex_sub(complex_mult(complex_sub(one,y11),complex_sub(one,y22)),complex_mult(y12,y21)),denom));

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function y2abcd -----------------------------------------------*/
/*                                                                   */

COMPLEX *y2abcd (y,abcd)
COMPLEX *y;
COMPLEX *abcd;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,y[2]);

x[0] = complex_sub(zero,complex_mult(y[3],denom));
x[1] = complex_sub(zero,denom);
x[2] = complex_mult(complex_sub(complex_mult(y[1],y[2]),complex_mult(y[0],y[3])),denom);
x[3] = complex_sub(zero,complex_mult(y[0],denom));

abcd[0].real = x[0].real;
abcd[0].imag = x[0].imag;
abcd[1].real = x[1].real;
abcd[1].imag = x[1].imag;
abcd[2].real = x[2].real;
abcd[2].imag = x[2].imag;
abcd[3].real = x[3].real;
abcd[3].imag = x[3].imag;

return (abcd);

}

/*                                                                   */
/*--- Function y2s --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2s (y,s,rref)
COMPLEX *y;
COMPLEX *s;
double  rref;

{
COMPLEX y11,y12,y21,y22;
COMPLEX one;
COMPLEX neg2;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

y11 = complex_mult(y[0],crref);
y12 = complex_mult(y[1],crref);
y21 = complex_mult(y[2],crref);
y22 = complex_mult(y[3],crref);

denom = complex_div(one,complex_sub(complex_mult(complex_add(one,y11),complex_add(one,y22)),complex_mult(y12,y21)));

x[0] = complex_mult(complex_add(complex_mult(complex_sub(one,y11),complex_add(one,y22)),complex_mult(y12,y21)),denom);
x[1] = complex_mult(neg2,complex_mult(y12,denom));
x[2] = complex_mult(neg2,complex_mult(y21,denom));
x[3] = complex_mult(complex_add(complex_mult(complex_add(one,y11),complex_sub(one,y22)),complex_mult(y12,y21)),denom);

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}

/*                                                                   */
/*--- Function z2h --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2h (z,h)
COMPLEX *z;
COMPLEX *h;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,z[3]);

x[0] = complex_mult(complex_sub(complex_mult(z[0],z[3]),complex_mult(z[1],z[2])),denom);
x[1] = complex_mult(z[1],denom);
x[2] = complex_sub(zero,complex_mult(z[2],denom));
x[3] = complex_add(zero,denom);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function z2y --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2y (z,y)
COMPLEX *z;
COMPLEX *y;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,complex_sub(complex_mult(z[0],z[3]),complex_mult(z[1],z[2])));

x[0] = complex_mult(z[3],denom);
x[1] = complex_sub(zero,complex_mult(z[1],denom));
x[2] = complex_sub(zero,complex_mult(z[2],denom));
x[3] = complex_mult(z[0],denom);

y[0].real = x[0].real;
y[0].imag = x[0].imag;
y[1].real = x[1].real;
y[1].imag = x[1].imag;
y[2].real = x[2].real;
y[2].imag = x[2].imag;
y[3].real = x[3].real;
y[3].imag = x[3].imag;

return (y);

}

/*                                                                   */
/*--- Function z2abcd -----------------------------------------------*/
/*                                                                   */

COMPLEX *z2abcd (z,abcd)
COMPLEX *z;
COMPLEX *abcd;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,z[2]);

x[0] = complex_mult(z[0],denom);
x[1] = complex_mult(complex_sub(complex_mult(z[0],z[3]),complex_mult(z[1],z[2])),denom);
x[2] = complex_add(zero,denom);
x[3] = complex_mult(z[3],denom);

abcd[0].real = x[0].real;
abcd[0].imag = x[0].imag;
abcd[1].real = x[1].real;
abcd[1].imag = x[1].imag;
abcd[2].real = x[2].real;
abcd[2].imag = x[2].imag;
abcd[3].real = x[3].real;
abcd[3].imag = x[3].imag;

return (abcd);

}

/*                                                                   */
/*--- Function z2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2t (z,t,rref)
COMPLEX *z;
COMPLEX *t;
double  rref;

{
COMPLEX z11,z12,z21,z22;
COMPLEX one;
COMPLEX two;
COMPLEX zero;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

z11 = complex_div(z[0],crref);
z12 = complex_div(z[1],crref);
z21 = complex_div(z[2],crref);
z22 = complex_div(z[3],crref);

denom = complex_div(one,complex_mult(two,z21));

x[0] = complex_mult(complex_sub(complex_mult(complex_add(z11,one),complex_add(z22,one)),complex_mult(z12,z21)),denom);
x[1] = complex_sub(zero,complex_mult(complex_sub(complex_mult(complex_add(z11,one),complex_sub(z22,one)),complex_mult(z12,z21)),denom));
x[2] = complex_mult(complex_sub(complex_mult(complex_sub(z11,one),complex_add(z22,one)),complex_mult(z12,z21)),denom);
x[3] = complex_sub(zero,complex_mult(complex_sub(complex_mult(complex_sub(z11,one),complex_sub(z22,one)),complex_mult(z12,z21)),denom));

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function z2s --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2s (z,s,rref)
COMPLEX *z;
COMPLEX *s;
double  rref;

{
COMPLEX z11,z12,z21,z22;
COMPLEX one;
COMPLEX two;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

z11 = complex_div(z[0],crref);
z12 = complex_div(z[1],crref);
z21 = complex_div(z[2],crref);
z22 = complex_div(z[3],crref);

denom = complex_div(one,complex_sub(complex_mult(complex_add(z11,one),complex_add(z22,one)),complex_mult(z12,z21)));

x[0] = complex_mult(complex_sub(complex_mult(complex_sub(z11,one),complex_add(z22,one)),complex_mult(z12,z21)),denom);
x[1] = complex_mult(two,complex_mult(z12,denom));
x[2] = complex_mult(two,complex_mult(z21,denom));
x[3] = complex_mult(complex_sub(complex_mult(complex_add(z11,one),complex_sub(z22,one)),complex_mult(z12,z21)),denom);

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}

/*                                                                   */
/*--- Function abcd2h -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2h (abcd,h)
COMPLEX *abcd;
COMPLEX *h;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,abcd[3]);

x[0] = complex_mult(abcd[1],denom);
x[1] = complex_mult(complex_sub(complex_mult(abcd[0],abcd[3]),complex_mult(abcd[1],abcd[2])),denom);
x[2] = complex_sub(zero,denom);
x[3] = complex_mult(abcd[2],denom);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function abcd2y -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2y (abcd,y)
COMPLEX *abcd;
COMPLEX *y;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,abcd[1]);

x[0] = complex_mult(abcd[3],denom);
x[1] = complex_mult(complex_sub(complex_mult(abcd[1],abcd[2]),complex_mult(abcd[0],abcd[3])),denom);
x[2] = complex_sub(zero,denom);
x[3] = complex_mult(abcd[0],denom);

y[0].real = x[0].real;
y[0].imag = x[0].imag;
y[1].real = x[1].real;
y[1].imag = x[1].imag;
y[2].real = x[2].real;
y[2].imag = x[2].imag;
y[3].real = x[3].real;
y[3].imag = x[3].imag;

return (y);

}

/*                                                                   */
/*--- Function abcd2z -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2z (abcd,z)
COMPLEX *abcd;
COMPLEX *z;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,abcd[2]);

x[0] = complex_mult(abcd[0],denom);
x[1] = complex_mult(complex_sub(complex_mult(abcd[0],abcd[3]),complex_mult(abcd[1],abcd[2])),denom);
x[2] = complex_add(zero,denom);
x[3] = complex_mult(abcd[3],denom);

z[0].real = x[0].real;
z[0].imag = x[0].imag;
z[1].real = x[1].real;
z[1].imag = x[1].imag;
z[2].real = x[2].real;
z[2].imag = x[2].imag;
z[3].real = x[3].real;
z[3].imag = x[3].imag;

return (z);

}

/*                                                                   */
/*--- Function abcd2t -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2t (abcd,t,rref)
COMPLEX *abcd;
COMPLEX *t;
double  rref;

{
COMPLEX a,b,c,d;
COMPLEX pt5;
COMPLEX zero;
COMPLEX crref;
COMPLEX x[4];

pt5.real = (double) 0.5;
pt5.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

a = complex_add(abcd[0],zero);
b = complex_div(abcd[1],crref);
c = complex_mult(abcd[2],crref);
d = complex_add(abcd[3],zero);

x[0] = complex_mult(pt5,complex_add(complex_add(a,b),complex_add(c,d)));
x[1] = complex_mult(pt5,complex_add(complex_sub(a,b),complex_sub(c,d)));
x[2] = complex_mult(pt5,complex_sub(complex_add(a,b),complex_add(c,d)));
x[3] = complex_mult(pt5,complex_sub(complex_sub(a,b),complex_sub(c,d)));

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function abcd2s -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2s (abcd,s,rref)
COMPLEX *abcd;
COMPLEX *s;
double  rref;

{
COMPLEX a,b,c,d;
COMPLEX one;
COMPLEX two;
COMPLEX zero;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

a = complex_add(abcd[0],zero);
b = complex_div(abcd[1],crref);
c = complex_mult(abcd[2],crref);
d = complex_add(abcd[3],zero);

denom = complex_div(one,complex_add(complex_add(a,b),complex_add(c,d)));

x[0] = complex_mult(complex_sub(complex_add(a,b),complex_add(c,d)),denom);
x[1] = complex_mult(two,complex_mult(complex_sub(complex_mult(a,d),complex_mult(b,c)),denom));
x[2] = complex_mult(two,denom);
x[3] = complex_mult(complex_sub(complex_sub(b,a),complex_sub(c,d)),denom);

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}
/*
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE T2H(T,H,RREF)
      REAL*8     RREF
      COMPLEX*16 T(2,2),H(2,2),DENOM
C
      DENOM = (1.0D+0,0.0D+0)/(T(1,1)-T(1,2)-T(2,1)+T(2,2))
C
      H(1,1) = (T(1,1)-T(1,2)+T(2,1)-T(2,2))*DENOM*RREF
      H(1,2) = (2.0D+0,0.0D+0)*(T(1,1)*T(2,2)-T(1,2)*T(2,1))*DENOM
      H(2,1) = (-2.0D+0,0.0D+0)*DENOM
      H(2,2) = (T(1,1)+T(1,2)-T(2,1)-T(2,2))*DENOM/RREF
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE T2Y(T,Y,RREF)
      REAL*8     RREF
      COMPLEX*16 T(2,2),Y(2,2),DENOM
C
      DENOM = (1.0D+0,0.0D+0)/((T(1,1)-T(1,2)+T(2,1)-T(2,2))*RREF)
C
      Y(1,1) = (T(1,1)-T(1,2)-T(2,1)+T(2,2))*DENOM
      Y(1,2) = (-2.0D+0,0.0D+0)*(T(1,1)*T(2,2)-T(1,2)*T(2,1))*DENOM
      Y(2,1) = (-2.0D+0,0.0D+0)*DENOM
      Y(2,2) = (T(1,1)+T(1,2)+T(2,1)+T(2,2))*DENOM
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE T2Z(T,Z,RREF)
      REAL*8     RREF
      COMPLEX*16 T(2,2),Z(2,2),DENOM
C
      DENOM = RREF/(T(1,1)+T(1,2)-T(2,1)-T(2,2))
C
      Z(1,1) = (T(1,1)+T(1,2)+T(2,1)+T(2,2))*DENOM
      Z(1,2) = (2.0D+0,0.0D+0)*(T(1,1)*T(2,2)-T(1,2)*T(2,1))*DENOM
      Z(2,1) = (2.0D+0,0.0D+0)*DENOM
      Z(2,2) = (T(1,1)-T(1,2)-T(2,1)+T(2,2))*DENOM
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE T2ABCD(T,ABCD,RREF)
      REAL*8     RREF
      COMPLEX*16 T(2,2),ABCD(2,2)
C
      ABCD(1,1) = (0.50D+0,0.0D+0)*(T(1,1)+T(1,2)+T(2,1)+T(2,2))
      ABCD(1,2) = (0.50D+0,0.0D+0)*(T(1,1)-T(1,2)+T(2,1)-T(2,2))*RREF
      ABCD(2,1) = (0.50D+0,0.0D+0)*(T(1,1)+T(1,2)-T(2,1)-T(2,2))/RREF
      ABCD(2,2) = (0.50D+0,0.0D+0)*(T(1,1)-T(1,2)-T(2,1)+T(2,2))
C
      RETURN
      END
*/
/*                                                                   */
/*--- Function s2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *t2s (t,s)
COMPLEX *t;
COMPLEX *s;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,t[0]);

x[0] = complex_mult(t[2],denom);
x[1] = complex_mult(complex_sub(complex_mult(t[0],t[3]),complex_mult(t[1],t[2])),denom);
x[2] = complex_add(zero,denom);
x[3] = complex_sub(zero,complex_mult(t[1],denom));

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}
/*
A
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE SNY(S,Y,RREF,N)
      INTEGER    N,I,J
      REAL*8     RREF
      COMPLEX*16 S(4,4),Y(4,4),S1(4,4),S2(4,4)
C
      DO 200 I=1,N
       DO 100 J=1,N
        IF(I.EQ.J)THEN
         S1(I,J) = (1.0D+0,0.0D+0)-S(I,J)
         S2(I,J) = (1.0D+0,0.0D+0)+S(I,J)
        ELSE
         S1(I,J) = -S(I,J)
         S2(I,J) = S(I,J)
        ENDIF
100    CONTINUE
200   CONTINUE
C
      CALL CMINV(S2,S2,N)
      CALL CMMULT(S1,S2,Y,N)
C
      DO 400 I=1,N
       DO 300 J=1,N
        Y(I,J) = Y(I,J)/RREF
300    CONTINUE
400   CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE SNZ(S,Z,RREF,N)
      INTEGER    N,I,J
      REAL*8     RREF
      COMPLEX*16 S(4,4),Z(4,4),S1(4,4),S2(4,4)
C
      DO 200 I=1,N
       DO 100 J=1,N
        IF(I.EQ.J)THEN
         S1(I,J) = (1.0D+0,0.0D+0)+S(I,J)
         S2(I,J) = (1.0D+0,0.0D+0)-S(I,J)
        ELSE
         S1(I,J) = S(I,J)
         S2(I,J) = -S(I,J)
        ENDIF
100    CONTINUE
200   CONTINUE
C
      CALL CMINV(S2,S2,N)
      CALL CMMULT(S1,S2,Z,N)
C
      DO 400 I=1,N
       DO 300 J=1,N
        Z(I,J) = Z(I,J)*RREF
300    CONTINUE
400   CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE YNZ(Y,Z,N)
      INTEGER    N
      COMPLEX*16 Y(4,4),Z(4,4)
C
      CALL CMINV(Y,Z,N)
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE YNS(Y,S,RREF,N)
      INTEGER    N,I,J
      REAL*8     RREF
      COMPLEX*16 Y(4,4),S(4,4),Y1(4,4),Y2(4,4)
C
      DO 200 I=1,N
       DO 100 J=1,N
        IF(I.EQ.J)THEN
         Y1(I,J) = (1.0D+0,0.0D+0)/RREF-Y(I,J)
         Y2(I,J) = (1.0D+0,0.0D+0)/RREF+Y(I,J)
        ELSE
         Y1(I,J) = -Y(I,J)
         Y2(I,J) = Y(I,J)
        ENDIF
100    CONTINUE
200   CONTINUE
C
      CALL CMINV(Y2,Y2,N)
      CALL CMMULT(Y1,Y2,S,N)
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE ZNY(Z,Y,N)
      INTEGER    N
      COMPLEX*16 Z(4,4),Y(4,4)
C
      CALL CMINV(Z,Y,N)
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE ZNS(Z,S,RREF,N)
      INTEGER    N,I,J
      REAL*8     RREF
      COMPLEX*16 Z(4,4),S(4,4),Z1(4,4),Z2(4,4)
C
      DO 200 I=1,N
       DO 100 J=1,N
        IF(I.EQ.J)THEN
         Z1(I,J) = Z(I,J)-RREF
         Z2(I,J) = Z(I,J)+RREF
        ELSE
         Z1(I,J) = Z(I,J)
         Z2(I,J) = Z(I,J)
        ENDIF
100    CONTINUE
200   CONTINUE
C
      CALL CMINV(Z2,Z2,N)
      CALL CMMULT(Z1,Z2,S,N)
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE CMINV(A,AINV,N)
      INTEGER    N,I,J,K,ROW,COLUMN,ITEMP,POINT(4)
      REAL*8     MAX
      COMPLEX*16 A(4,4),AINV(4,4),B(4,4),IMTRX(4,4),CTEMP1,CTEMP2
C
C                                BUFFER THE A MATRIX
      DO 200 I=1,N
       DO 100 J=1,N
        B(I,J) = A(I,J)
100    CONTINUE
200   CONTINUE
C                                CREATE THE IDENTITIY MATRIX
      DO 400 I=1,N
       DO 300 J=1,N
        IF(I.EQ.J)THEN
         IMTRX(I,J) = (1.0D+0,0.0D+0)
        ELSE
         IMTRX(I,J) = (0.0D+0,0.0D+0)
        ENDIF
300    CONTINUE
400   CONTINUE
C                                KEEP TRACK OF ROW EXCHANGES
      DO 500 I=1,N
       POINT(I) = I
500   CONTINUE
C                                UPPER TRIANGULARIZE WITH FULL PIVOTING
      DO 1200 K=1,N-1
       MAX = 0.0D+0
C                                FIND MAX
       DO 700 I=K,N
        DO 600 J=K,N
         IF(CDABS(B(I,J)).GT.MAX)THEN
          ROW = I
          COLUMN = J
          MAX = CDABS(B(I,J))
         ENDIF
600     CONTINUE
700    CONTINUE
C                                ROTATE ROWS
       IF(ROW.NE.K)THEN
        DO 800 J=1,N
         CTEMP1 = B(K,J)
         B(K,J) = B(ROW,J)
         B(ROW,J) = CTEMP1
         CTEMP1 = IMTRX(K,J)
         IMTRX(K,J) = IMTRX(ROW,J)
         IMTRX(ROW,J) = CTEMP1
800     CONTINUE
       ENDIF
C                                ROTATE COLUMNS
       IF(COLUMN.NE.K)THEN
        DO 900 I=1,N
         CTEMP1 = B(I,K)
         B(I,K) = B(I,COLUMN)
         B(I,COLUMN) = CTEMP1
900     CONTINUE
        ITEMP = POINT(K)
        POINT(K) = POINT(COLUMN)
        POINT(COLUMN) = ITEMP
       ENDIF
C                                GAUSSIAN ELIMINATION
       CTEMP1 = B(K,K)
       DO 1100 I=K+1,N
        CTEMP2 = B(I,K)/CTEMP1
        DO 1000 J=1,N
         B(I,J) = B(I,J)-CTEMP2*B(K,J)
         IMTRX(I,J) = IMTRX(I,J)-CTEMP2*IMTRX(K,J)
1000    CONTINUE
1100   CONTINUE
1200  CONTINUE
C                                DIAGONALIZE
      DO 1500 K=N,2,-1
       CTEMP1 = B(K,K)
       DO 1400 I=K-1,1,-1
        CTEMP2 = B(I,K)/CTEMP1
        DO 1300 J=1,N
         B(I,J) = B(I,J)-CTEMP2*B(K,J)
         IMTRX(I,J) = IMTRX(I,J)-CTEMP2*IMTRX(K,J)
1300    CONTINUE
1400   CONTINUE
1500  CONTINUE
C                                SOLVE FOR INVERSE
      DO 1700 I=1,N
       DO 1600 J=1,N
        AINV(POINT(I),J) = IMTRX(I,J)/B(I,I)
1600   CONTINUE
1700  CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE CMMULT(A,B,C,N)
      INTEGER    N,I,J,K
      COMPLEX*16 A(4,4),B(4,4),C(4,4),A1(4,4),B1(4,4)
C
C                                BUFFER THE A AND B MATRICIES
      DO 200 I=1,N
       DO 100 J=1,N
        A1(I,J) = A(I,J)
        B1(I,J) = B(I,J)
100    CONTINUE
200   CONTINUE
C                                MULTIPLY A1 AND B1 MATRICIES
      DO 500 I=1,N
       DO 400 J=1,N
        C(I,J) = (0.0D+0,0.0D+0)
        DO 300 K=1,N
         C(I,J) = A1(I,K)*B1(K,J)+C(I,J)
300     CONTINUE
400    CONTINUE
500   CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE AXB(A,AR,AC,X,XR,B,BR,N,ERROR)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    AR,AC,XR,BR
      INTEGER    I,J,K,N,ROW,COLUMN,ITEMP,POINT(NUMVAR),ERROR
      REAL*8     Z(NUMVAR,NUMVAR),Y(NUMVAR)
      REAL*8     A(AR,AC),X(XR),B(BR)
      REAL*8     MAX,TEMP1,TEMP2
C
C--- BUFFER THE A MATRIX AND B VECTOR --------------------------------
C
      DO 200 I=1,N,1
       Y(I) = B(I)
       DO 100 J=1,N,1
        Z(I,J) = A(I,J)
100    CONTINUE
200   CONTINUE
C
C--- KEEP TRACK OF ROW EXCHANGES -------------------------------------
C
      DO 300 I=1,N,1
       POINT(I) = I
300   CONTINUE
C
C--- UPPER TRIANGULARIZE WITH FULL PIVOTING --------------------------
C
      DO 1000 K=1,N-1,1
       MAX = 0.0D+0
C
C--- FIND MAX --------------------------------------------------------
C
       DO 500 I=K,N,1
        DO 400 J=K,N,1
         IF(DABS(Z(I,J)).GT.MAX)THEN
          ROW    = I
          COLUMN = J
          MAX    = DABS(Z(I,J))
         ENDIF
400     CONTINUE
500    CONTINUE
C
C--- ROTATE ROWS -----------------------------------------------------
C
       IF(ROW.NE.K)THEN
        DO 600 J=1,N,1
         TEMP1    = Z(K,J)
         Z(K,J)   = Z(ROW,J)
         Z(ROW,J) = TEMP1
600     CONTINUE
        TEMP1    = Y(K)
        Y(K)     = Y(ROW)
        Y(ROW)   = TEMP1
       ENDIF
C
C--- ROTATE COLUMNS --------------------------------------------------
C
       IF(COLUMN.NE.K)THEN
        DO 700 I=1,N,1
         TEMP1       = Z(I,K)
         Z(I,K)      = Z(I,COLUMN)
         Z(I,COLUMN) = TEMP1
700     CONTINUE
        ITEMP         = POINT(K)
        POINT(K)      = POINT(COLUMN)
        POINT(COLUMN) = ITEMP
       ENDIF
C
C--- GAUSSIAN ELIMINATION --------------------------------------------
C
       TEMP1 = Z(K,K)
       DO 900 I=K+1,N,1
        TEMP2 = Z(I,K)/TEMP1
        Y(I) = Y(I)-TEMP2*Y(K)
        DO 800 J=K,N,1
         Z(I,J) = Z(I,J)-TEMP2*Z(K,J)
800     CONTINUE
900    CONTINUE
1000  CONTINUE
C
C--- RETURN ERROR IF A MATRIX IS NOT INVERTABLE ----------------------
C
      IF(DABS(Z(N,N)).LT.1.0D-35)THEN
       ERROR = 1
       RETURN
      ELSE
       ERROR = 0
      ENDIF
C
C--- BACK SUBSTITUTION -----------------------------------------------
C
      X(POINT(N)) = Y(N)/Z(N,N)
C
      DO 1200 K=N-1,1,-1
       TEMP1 = Y(K)
       DO 1100 I=N,K+1,-1
        TEMP1 = TEMP1-Z(K,I)*X(POINT(I))
1100   CONTINUE
       X(POINT(K)) = TEMP1/Z(K,K)
1200  CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE CAXB(A,AR,AC,X,XR,B,BR,N,ERROR)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    AR,AC,XR,BR
      INTEGER    I,J,K,N,ROW,COLUMN,ITEMP,POINT(NUMVAR),ERROR
      REAL*8     MAX
      COMPLEX*16 Z(NUMVAR,NUMVAR),Y(NUMVAR)
      COMPLEX*16 A(AR,AC),X(XR),B(BR)
      COMPLEX*16 TEMP1,TEMP2
C
C--- BUFFER THE A MATRIX AND B VECTOR --------------------------------
C
      DO 200 I=1,N,1
       Y(I) = B(I)
       DO 100 J=1,N,1
        Z(I,J) = A(I,J)
100    CONTINUE
200   CONTINUE
C
C--- KEEP TRACK OF ROW EXCHANGES -------------------------------------
C
      DO 300 I=1,N,1
       POINT(I) = I
300   CONTINUE
C
C--- UPPER TRIANGULARIZE WITH FULL PIVOTING --------------------------
C
      DO 1000 K=1,N-1,1
       MAX = 0.0D+0
C
C--- FIND MAX --------------------------------------------------------
C
       DO 500 I=K,N,1
        DO 400 J=K,N,1
         IF(CDABS(Z(I,J)).GT.MAX)THEN
          ROW    = I
          COLUMN = J
          MAX    = CDABS(Z(I,J))
         ENDIF
400     CONTINUE
500    CONTINUE
C
C--- ROTATE ROWS -----------------------------------------------------
C
       IF(ROW.NE.K)THEN
        DO 600 J=1,N,1
         TEMP1    = Z(K,J)
         Z(K,J)   = Z(ROW,J)
         Z(ROW,J) = TEMP1
600     CONTINUE
        TEMP1    = Y(K)
        Y(K)     = Y(ROW)
        Y(ROW)   = TEMP1
       ENDIF
C
C--- ROTATE COLUMNS --------------------------------------------------
C
       IF(COLUMN.NE.K)THEN
        DO 700 I=1,N,1
         TEMP1       = Z(I,K)
         Z(I,K)      = Z(I,COLUMN)
         Z(I,COLUMN) = TEMP1
700     CONTINUE
        ITEMP         = POINT(K)
        POINT(K)      = POINT(COLUMN)
        POINT(COLUMN) = ITEMP
       ENDIF
C
C--- GAUSSIAN ELIMINATION --------------------------------------------
C
       TEMP1 = Z(K,K)
       DO 900 I=K+1,N,1
        TEMP2 = Z(I,K)/TEMP1
        Y(I) = Y(I)-TEMP2*Y(K)
        DO 800 J=K,N,1
         Z(I,J) = Z(I,J)-TEMP2*Z(K,J)
800     CONTINUE
900    CONTINUE
1000  CONTINUE
C
C--- RETURN ERROR IF A MATRIX IS NOT INVERTABLE ----------------------
C
      IF(CDABS(Z(N,N)).LT.1.0D-35)THEN
       ERROR = 1
       RETURN
      ELSE
       ERROR = 0
      ENDIF
C
C--- BACK SUBSTITUTION -----------------------------------------------
C
      X(POINT(N)) = Y(N)/Z(N,N)
C
      DO 1200 K=N-1,1,-1
       TEMP1 = Y(K)
       DO 1100 I=N,K+1,-1
        TEMP1 = TEMP1-Z(K,I)*X(POINT(I))
1100   CONTINUE
       X(POINT(K)) = TEMP1/Z(K,K)
1200  CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE CDET(A,AR,AC,N,DET)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    I,J,K,N,AR,AC,ROW,COLUMN
      REAL*8     MAX
      COMPLEX*16 Z(NUMVAR,NUMVAR)
      COMPLEX*16 A(AR,AC)
      COMPLEX*16 TEMP1,TEMP2,FACT,DET
C
C--- CHANGE SIGN OF DET IF ROW OR COLUMN SWAP ------------------------
C
      FACT = (1.0D+0,0.0D+0)
C
C--- BUFFER THE A MATRIX ---------------------------------------------
C
      DO 200 I=1,N,1
       DO 100 J=1,N,1
        Z(I,J) = A(I,J)
100    CONTINUE
200   CONTINUE
C
C--- UPPER TRIANGULARIZE WITH FULL PIVOTING --------------------------
C
      DO 1000 K=1,N-1,1
       MAX = 0.0D+0
C
C--- FIND MAX --------------------------------------------------------
C
       DO 500 I=K,N,1
        DO 400 J=K,N,1
         IF(CDABS(Z(I,J)).GT.MAX)THEN
          ROW    = I
          COLUMN = J
          MAX    = CDABS(Z(I,J))
         ENDIF
400     CONTINUE
500    CONTINUE
C
C--- ROTATE ROWS -----------------------------------------------------
C
       IF(ROW.NE.K)THEN
        DO 600 J=1,N,1
         TEMP1    = Z(K,J)
         Z(K,J)   = Z(ROW,J)
         Z(ROW,J) = TEMP1
600     CONTINUE
        FACT = -FACT
       ENDIF
C
C--- ROTATE COLUMNS --------------------------------------------------
C
       IF(COLUMN.NE.K)THEN
        DO 700 I=1,N,1
         TEMP1       = Z(I,K)
         Z(I,K)      = Z(I,COLUMN)
         Z(I,COLUMN) = TEMP1
700     CONTINUE
        FACT = -FACT
       ENDIF
C
C--- GAUSSIAN ELIMINATION --------------------------------------------
C
       TEMP1 = Z(K,K)
       DO 900 I=K+1,N,1
        TEMP2 = Z(I,K)/TEMP1
        DO 800 J=K,N,1
         Z(I,J) = Z(I,J)-TEMP2*Z(K,J)
800     CONTINUE
900    CONTINUE
1000  CONTINUE
C
C--- CALCULATE DET = MULTIPLICATION OF DIAGONAL ELEMENTS -------------
C
      DET = (1.0D+0,0.0D+0)
C
      DO 1100 I=1,N,1
       DET = DET*Z(I,I)
1100  CONTINUE
C
      DET = FACT*DET
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE CINV(A,AR,AC,AINV,BR,BC,N)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    I,J,K,N,AR,AC,BR,BC,ROW,COLUMN,ITEMP,POINT(NUMVAR)
      REAL*8     MAX
      COMPLEX*16 A(AR,AC),AINV(BR,BC)
      COMPLEX*16 B(NUMVAR,NUMVAR),IMTRX(NUMVAR,NUMVAR)
      COMPLEX*16 CTEMP1,CTEMP2
C
C--- BUFFER THE A MATRIX -----------------------------------------------
C
      DO 200 I=1,N,1
       DO 100 J=1,N,1
        B(I,J) = A(I,J)
100    CONTINUE
200   CONTINUE
C
C--- CREATE THE IDENTITIY MATRIX ---------------------------------------
C
      DO 400 I=1,N,1
       DO 300 J=1,N,1
        IF(I.EQ.J)THEN
         IMTRX(I,J) = (1.0D+0,0.0D+0)
        ELSE
         IMTRX(I,J) = (0.0D+0,0.0D+0)
        ENDIF
300    CONTINUE
400   CONTINUE
C
C--- KEEP TRACK OF ROW EXCHANGES ---------------------------------------
C
      DO 500 I=1,N,1
       POINT(I) = I
500   CONTINUE
C
C--- UPPER TRIANGULARIZE WITH FULL PIVOTING ----------------------------
C
      DO 1200 K=1,N-1,1
       MAX = 0.0D+0
C
C--- FIND MAX ----------------------------------------------------------
C
       DO 700 I=K,N,1
        DO 600 J=K,N,1
         IF(CDABS(B(I,J)).GT.MAX)THEN
          ROW = I
          COLUMN = J
          MAX = CDABS(B(I,J))
         ENDIF
600     CONTINUE
700    CONTINUE
C
C--- ROTATE ROWS -------------------------------------------------------
C
       IF(ROW.NE.K)THEN
        DO 800 J=1,N,1
         CTEMP1 = B(K,J)
         B(K,J) = B(ROW,J)
         B(ROW,J) = CTEMP1
         CTEMP1 = IMTRX(K,J)
         IMTRX(K,J) = IMTRX(ROW,J)
         IMTRX(ROW,J) = CTEMP1
800     CONTINUE
       ENDIF
C
C--- ROTATE COLUMNS ----------------------------------------------------
C
       IF(COLUMN.NE.K)THEN
        DO 900 I=1,N,1
         CTEMP1 = B(I,K)
         B(I,K) = B(I,COLUMN)
         B(I,COLUMN) = CTEMP1
900     CONTINUE
        ITEMP = POINT(K)
        POINT(K) = POINT(COLUMN)
        POINT(COLUMN) = ITEMP
       ENDIF
C
C--- GAUSSIAN ELIMINATION ----------------------------------------------
C
       CTEMP1 = B(K,K)
       DO 1100 I=K+1,N,1
        CTEMP2 = B(I,K)/CTEMP1
        DO 1000 J=1,N,1
         B(I,J) = B(I,J)-CTEMP2*B(K,J)
         IMTRX(I,J) = IMTRX(I,J)-CTEMP2*IMTRX(K,J)
1000    CONTINUE
1100   CONTINUE
1200  CONTINUE
C
C--- DIAGONALIZE -------------------------------------------------------
C
      DO 1500 K=N,2,-1
       CTEMP1 = B(K,K)
       DO 1400 I=K-1,1,-1
        CTEMP2 = B(I,K)/CTEMP1
        DO 1300 J=1,N,1
         B(I,J) = B(I,J)-CTEMP2*B(K,J)
         IMTRX(I,J) = IMTRX(I,J)-CTEMP2*IMTRX(K,J)
1300    CONTINUE
1400   CONTINUE
1500  CONTINUE
C
C--- SOLVE FOR INVERSE -------------------------------------------------
C
      DO 1700 I=1,N,1
       DO 1600 J=1,N,1
        AINV(POINT(I),J) = IMTRX(I,J)/B(I,I)
1600   CONTINUE
1700  CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE CMULT(A,AROW,ACOL,B,BROW,BCOL,C,CROW,CCOL,AR,AC,BR,BC)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    I,J,K,AROW,ACOL,BROW,BCOL,CROW,CCOL,AR,AC,BR,BC
      COMPLEX*16 A(AROW,ACOL),B(BROW,BCOL),C(CROW,CCOL)
      COMPLEX*16 A1(NUMVAR,NUMVAR),B1(NUMVAR,NUMVAR)
C
C--- BUFFER THE A MATRIX -----------------------------------------------
C
      DO 200 I=1,AR,1
       DO 100 J=1,AC,1
        A1(I,J) = A(I,J)
100    CONTINUE
200   CONTINUE
C
C--- BUFFER THE B MATRIX -----------------------------------------------
C
      DO 400 I=1,BR,1
       DO 300 J=1,BC,1
        B1(I,J) = B(I,J)
300    CONTINUE
400   CONTINUE
C
C--- MULTIPLY A1 AND B1 MATRICIES --------------------------------------
C
      DO 700 I=1,AR,1
       DO 600 J=1,BC,1
        C(I,J) = (0.0D+0,0.0D+0)
        DO 500 K=1,AC,1
         C(I,J) = A1(I,K)*B1(K,J)+C(I,J)
500     CONTINUE
600    CONTINUE
700   CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE SNY(S,RS,CS,Y,RY,CY,RREF,N)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    N,I,J,RS,CS,RY,CY
      REAL*8     RREF
      COMPLEX*16 S(RS,CS),Y(RY,CY),S1(NUMVAR,NUMVAR),S2(NUMVAR,NUMVAR)
      COMPLEX*16 S3(NUMVAR,NUMVAR)
C
      DO 200 I=1,N,1
       DO 100 J=1,N,1
        IF(I.EQ.J)THEN
         S1(I,J) = (1.0D+0,0.0D+0)-S(I,J)
         S2(I,J) = (1.0D+0,0.0D+0)+S(I,J)
        ELSE
         S1(I,J) = -S(I,J)
         S2(I,J) = S(I,J)
        ENDIF
100    CONTINUE
200   CONTINUE
C
      CALL CINV(S2,NUMVAR,NUMVAR,S3,NUMVAR,NUMVAR,N)
      CALL CMULT(S1,NUMVAR,NUMVAR,S3,NUMVAR,NUMVAR,Y,RY,CY,N,N,N,N)
C
      DO 400 I=1,N,1
       DO 300 J=1,N,1
        Y(I,J) = Y(I,J)/RREF
300    CONTINUE
400   CONTINUE
C
      RETURN
      END
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
      SUBROUTINE YNS(Y,RY,CY,S,RS,CS,RREF,N)
      INTEGER    NUMVAR
      PARAMETER  (NUMVAR=12)
      INTEGER    N,I,J,RS,CS,RY,CY
      REAL*8     RREF
      COMPLEX*16 S(RS,CS),Y(RY,CY),S1(NUMVAR,NUMVAR),S2(NUMVAR,NUMVAR)
      COMPLEX*16 S3(NUMVAR,NUMVAR)
C
      DO 200 I=1,N,1
       DO 100 J=1,N,1
        IF(I.EQ.J)THEN
         S1(I,J) = (1.0D+0,0.0D+0)-Y(I,J)*RREF
         S2(I,J) = (1.0D+0,0.0D+0)+Y(I,J)*RREF
        ELSE
         S1(I,J) = -Y(I,J)*RREF
         S2(I,J) = Y(I,J)*RREF
        ENDIF
100    CONTINUE
200   CONTINUE
C
      CALL CINV(S2,NUMVAR,NUMVAR,S3,NUMVAR,NUMVAR,N)
      CALL CMULT(S1,NUMVAR,NUMVAR,S3,NUMVAR,NUMVAR,S,RS,CS,N,N,N,N)
C
      RETURN
      END
*/
