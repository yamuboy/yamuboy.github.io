#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include "optimize_types4.h"

/* definitions */

#define MIN_VALUE   1.0e-30

#define NO_ERROR          0
#define ERR_NO_MEM        1
#define ERR_FUNCTION      2
#define ERR_NO_PARAMS     3
#define ERR_NO_ERF        4
#define ERR_NO_FUNCTION   5
#define ERR_INVALID_ARG   6
#define ERR_GRADIENT_INT  7
#define ERR_GRADIENT_EXT  8

/* global error variable */

static unsigned cg_global_error = 0;

/**************************************************************************/
/**************************************************************************/

#if defined (WIN32)
static int isnan (double x)
   {
   if ((x > -HUGE_VAL) && (x < HUGE_VAL))
      return 0;
   
   return 1;
   }
#endif

/**************************************************************************/
/**************************************************************************/

static void set_cg_error (int err)
   {
   cg_global_error = err;
   }

/**************************************************************************/
/**************************************************************************/

static int sdir_reset_flag (OPTIMIZE *opt, unsigned iter)
   {
#define mod(x,y)         ((x) - ((unsigned)((x)/(y))) * (y))

   if (!iter || !opt->reset_interval)
      return 0;

   return (mod(iter, opt->reset_interval) == 0);
   }

/**************************************************************************/
/**************************************************************************/
   
static double map_parameter (OPT_PARAMETER p, double *offset, double *mag)
   {
   *mag = 2.0 / (p.max - p.min);
   *offset = (p.max + p.min) * 0.5;  

   return (*mag) * (p.nom - (*offset));
   }
   
/**************************************************************************/
/**************************************************************************/

static double unmap_parameter (double val, double offset, double mag)
   {
   // parameter must be bounded between +/- 1
   if (val > 1.0)
      val = 1.0;
   else if (val < -1.0)
      val = -1.0;

   return val/mag + offset;
   }

/**************************************************************************/
/**************************************************************************/

static void print_error_values (OPTIMIZE *opt, int iter)
   {
   unsigned i;
   char *default_format = "%13.4e";

   if (opt->flags & OPT_VERBOSE)
      {
      fprintf (stderr,"%-5d ", iter);

      if (opt->flags & OPT_SINGLE_ERROR)
         {
         if (opt->print_format[0])
            fprintf (stderr, opt->print_format, opt->current_total_error);
         else
            fprintf (stderr, default_format, opt->current_total_error);
         }
      else
         {
         for (i = 0; i < opt->n_errors; ++i)
            {
            if (opt->print_format[0])
               fprintf (stderr, opt->print_format, opt->current_error[i]);
            else
               fprintf (stderr, default_format, opt->current_error[i]);
            }
         }
      fprintf (stderr,"\n");
      }
   }
      
/**************************************************************************/
/**************************************************************************/

static double opt_function (OPTIMIZE *opt, double *pl)
   {
   double x = 0.0;
   unsigned i;
   
   for (i = 0; i < opt->n_params; ++i)
      if (opt->param_flag[i])
         opt->function_p_list[i] = unmap_parameter (pl[i], opt->offset[i], opt->mfactor[i]);

   if (opt->function (opt->function_p_list, opt->function_data, opt->func_err, opt->n_errors))
      {
      set_cg_error (ERR_FUNCTION);
      return -1.0;
      }
   
   for (i = 0; i < opt->n_errors; ++i)
      {
      if (opt->weights)
         {
         opt->func_err[i] = fabs (opt->func_err[i]*opt->weights[i]);
         x += opt->func_err[i];
         }
      else
         {
         opt->func_err[i] += fabs (opt->func_err[i]);
         x += opt->func_err[i];
         }
      }
   
   return x;
   }

/**************************************************************************/
/**************************************************************************/

static int compute_gradients (OPTIMIZE *opt)
   {
   unsigned i,j;
   
   // copy the current gradients for memory
   for (i = 0; i < opt->n_params; ++i)
      for (j = 0; j < opt->n_errors; ++j)
         opt->old_grads[i][j] = opt->grads[i][j];

   // external gradient function supplied
   if (opt->gradients)
      {
      if (opt->gradients (opt->p_list, opt->gradient_data, opt->grads, opt->n_params, opt->n_errors, opt->param_flag))
         {
         set_cg_error (ERR_GRADIENT_EXT);
         return -1;
         }
      }
   
   // otherwise do numerical gradients
   else
      {
      double temp;
      double interval;
      double *error_hi = (double *) malloc (sizeof (double)*opt->n_errors);
      double *error_lo = (double *) malloc (sizeof (double)*opt->n_errors);

      if (!error_hi || !error_lo)
         {
         if (error_hi)
            free ((void *) error_hi);
         if (error_lo)
            free ((void *) error_lo);
         set_cg_error (ERR_NO_MEM);
         return -1;
         }

      for (i = 0; i < opt->n_params; ++i)
         {
         // check to see if this a parameter that we need to calculate a gradient for
         if (opt->param_flag[i])
            {
            temp = opt->mp_list[i];  
            interval = 0.0;
         
            // do the high side numerical delta
            if (!(opt->flags & LOW_SIDE_GRADIENT) ||
               ((opt->flags & LOW_SIDE_GRADIENT) && (temp <= -1.0)))
               {
               opt->mp_list[i] = temp + opt->numerical_delta;
               if (opt->mp_list[i] >= 1.0)
                  interval += 1.0 - temp;
               else
                  interval += opt->numerical_delta;

               if (opt_function (opt, opt->mp_list) < 0.0)
                  {
                  set_cg_error (ERR_GRADIENT_INT);
                  free ((void *) error_hi);
                  free ((void *) error_lo);
                  return -1;
                  }

               for (j = 0; j < opt->n_errors; ++j)
                  error_hi[j] = opt->func_err[j];
               }
            else
               {
               for (j = 0; j < opt->n_errors; ++j)
                  error_hi[j] = opt->current_error[j];
               }

            // do the low side numerical delta
            if (!(opt->flags & HIGH_SIDE_GRADIENT) ||
               ((opt->flags & HIGH_SIDE_GRADIENT) && (temp >= 1.0)))
               {
               opt->mp_list[i] = temp - opt->numerical_delta;
               if (opt->mp_list[i] <= -1.0)
                  interval += 1.0 + temp;
               else
                  interval += opt->numerical_delta;

               if (opt_function (opt, opt->mp_list) < 0.0)
                  {
                  set_cg_error (ERR_GRADIENT_INT);
                  free ((void *) error_hi);
                  free ((void *) error_lo);
                  return -1;
                  }

               for (j = 0; j < opt->n_errors; ++j)
                  error_lo[j] = opt->func_err[j];
               }
            else
               {
               for (j = 0; j < opt->n_errors; ++j)
                  error_lo[j] = opt->current_error[j];
               }
         
            // use negative gradient
            if (!interval)
               {
               for (j = 0; j < opt->n_errors; ++j)
                  opt->grads[i][j] = 0.0;
               }
            else
               {
               for (j = 0; j < opt->n_errors; ++j)
                  opt->grads[i][j] = (error_lo[j] - error_hi[j])/interval;
               }

            // reset the value that we changed to do the gradients
            opt->mp_list[i] = temp;
            }
         }

      free ((void *) error_hi);
      free ((void *) error_lo);
      }

   // protect gradients from invalid numerical data
   for (i = 0; i < opt->n_params; ++i)
      {
      if (opt->param_flag[i])
         {
         for (j = 0; j < opt->n_errors; ++j)
            {
            if (isnan (opt->grads[i][j]))
               {
               opt->grads[i][j] = 0.0;
               if (opt->flags & OPT_VERBOSE)
                  fprintf (stderr,"WARNING: NaN encountered in gradient. Parameter '%s', index %u.\n",opt->params[i].name,i);
               }
            }
         }
      }

   return 0;
   }

/**************************************************************************/
/**************************************************************************/

static void compute_search_dirs (OPTIMIZE *opt, unsigned iter)
   {
   double beta = 0.0;
   unsigned i,j;

   // zero the search direction vector if this is the first iteration
   if (iter <= 1)
      {
      for (i = 0; i < opt->n_params; ++i)
         opt->s_dirs[i] = 0.0;
      }

   // find beta for itererations greater than 1
   if ((iter > 1) && !sdir_reset_flag (opt, iter))
      {
      double x1 = 0.0;
      double x2 = 0.0;
      for (i = 0; i < opt->n_params; ++i)
         {
         if (opt->param_flag[i])
            {
            double x3 = 0.0;
            double x4 = 0.0;

            for (j = 0; j < opt->n_errors; ++j)
               {
               if (opt->weights)
                  {
                  x3 += opt->old_grads[i][j] * opt->weights[j];
                  x4 += opt->grads[i][j] * opt->weights[j];
                  }
               else
                  {
                  x3 += opt->old_grads[i][j];
                  x4 += opt->grads[i][j];
                  }
               }

            x1 += x3*x3;
            x2 += x4*x4;
            }
         }
      
      beta = x2/x1;
      }

   if (isnan (beta))
      beta = 0.0;
   else if (beta > opt->maximum_beta)
      beta = opt->maximum_beta;

   // compute the search direction
   for (i = 0; i < opt->n_params; ++i)
      {
      if (opt->param_flag[i])
         {
         double x = 0.0;

         for (j = 0; j < opt->n_errors; ++j)
            {
            if (opt->weights)
               x += opt->grads[i][j] * opt->weights[j];
            else
               x += opt->grads[i][j];
            }
         opt->s_dirs[i] = opt->s_dirs[i] * beta + x;
         }
      }
   }
   
/**************************************************************************/
/**************************************************************************/

static int perform_line_search (OPTIMIZE *opt)
   {
   double alpha;
   double x1,x2,x3,y1,y2,y3,z1;
   int repeat;
   unsigned i,j;
   unsigned k = 0;

   double *tp = (double *) malloc (sizeof (double)*opt->n_params);
   if (!tp)
      {
      set_cg_error (ERR_NO_MEM);
      return -1;
      }

   // find a new alpha based on the largest s_dir
   x1 = 0.0;
   for (i = 0; i < opt->n_params; ++i)
      {
      if (opt->param_flag[i])
         {
         x2 = fabs (opt->s_dirs[i]);
         if (x2 > x1)
            x1 = x2;
         }
      }

   if (x1 < MIN_VALUE)
      {
      if (opt->flags & OPT_VERBOSE)
         fprintf (stderr,"WARNING: All gradients are zero in line search.\n");
      free ((void *) tp);
      return 0;
      }

   alpha = opt->alpha_numerator/x1;
   
   // find the best approximate step size (alpha)

   y1 = opt->old_total_error;
   x1 = 0.0;
   do {
      for (i = 0; i < opt->n_params; ++i)
         if (opt->param_flag[i])
            tp[i] = opt->mp_list[i] + alpha * opt->s_dirs[i];

      y2 = opt_function (opt, tp);
      
      if ((y2 > y1) || isnan (y2) || (y2 < 0.0))
         alpha *= 0.5;

      if (alpha < MIN_VALUE)
         {
         free ((void *) tp);
         return 0;
         }
      }
   while (y2 > y1);
   x2 = alpha;

   // new error calculation is less than old error
   for (j = 0; j < opt->n_errors; ++j)
      opt->current_error[j] = opt->func_err[j];
   opt->current_total_error = y2;

   // perform the line search

   do {
      repeat = 0;
      x3 = x2 + alpha;
      for (i = 0; i < opt->n_params; ++i)
         if (opt->param_flag[i])
            tp[i] = opt->mp_list[i] + x3 * opt->s_dirs[i];

      y3 = opt_function (opt, tp);
            
      if (isnan (y3) || (y3 < 0.0))
         break;
      
      if ((y3 < y2) && (k++ < opt->max_search_segments))
         {
         y1 = y2;
         x1 = x2;
         y2 = y3;
         x2 = x3;
         repeat = 1;

         // new error calculation is less than old error
         for (j = 0; j < opt->n_errors; ++j)
            opt->current_error[j] = opt->func_err[j];
         opt->current_total_error = y2;
         }
      }
   while (repeat);
   
   /* now the local minimum is bounded between alpha=x1 and alpha=x3 */
   /* do a quadratic fit to find the optimum alpha */
   alpha = 0.5*(x1 + x2 + (y1-y2)*(x3-x1)*(x3-x2)/(x1*(y2-y3) + x2*(y3-y1) + x3*(y2-y1)));

   // if alpha is invalid, use alpha=x2 
   if ((alpha <= x1) || (alpha >= x3) || isnan (alpha))
      {
      for (i = 0; i < opt->n_params; ++i)
         if (opt->param_flag[i])
            opt->mp_list[i] += x2 * opt->s_dirs[i];

      free ((void *) tp);
      return 0;
      }
   
   // calculate the resulting error from the quadratically fit alpha
   for (i = 0; i < opt->n_params; ++i)
      if (opt->param_flag[i])
         tp[i] = opt->mp_list[i] + alpha * opt->s_dirs[i];
   z1 = opt_function (opt, tp);

   // check which error is best
   if (isnan (z1) || (y2 < z1) || (z1 < 0.0))
      {
      for (i = 0; i < opt->n_params; ++i)
         if (opt->param_flag[i])
            opt->mp_list[i] += x2 * opt->s_dirs[i];
      }
   else
      {
      for (i = 0; i < opt->n_params; ++i)
         if (opt->param_flag[i])
            opt->mp_list[i] = tp[i];

      // new error calculation is less than old error
      for (j = 0; j < opt->n_errors; ++j)
         opt->current_error[j] = opt->func_err[j];
      opt->current_total_error = z1;
      }

   free ((void *) tp);

   return 0;
   }
   
/**************************************************************************/
/**************************************************************************/
   
static int cg_malloc (OPTIMIZE *opt, int allocate)
   {   
   if (allocate)
      {
      unsigned np = opt->n_params;
      unsigned ne = opt->n_errors;
      unsigned i;
      
      if ((ne < 1) || (np < 1))
         return -1;
      
      opt->old_error = (double *) malloc (sizeof (double)*ne);
      opt->current_error = (double *) malloc (sizeof (double)*ne);
      opt->func_err = (double *) malloc (sizeof (double)*ne);
      
      opt->p_list = (double *) malloc (sizeof (double)*np);
      opt->op_list = (double *) malloc (sizeof (double)*np);
      opt->function_p_list = (double *) malloc (sizeof (double)*np);
      opt->mp_list = (double *) malloc (sizeof (double)*np);
      
      opt->mfactor = (double *) malloc (sizeof (double)*np);
      opt->offset = (double *) malloc (sizeof (double)*np);
      opt->s_dirs = (double *) malloc (sizeof (double)*np);

      opt->param_flag = (int *) malloc (sizeof (int)*np);
      
      opt->grads = (double **) malloc (sizeof (double *)*np);
      opt->old_grads = (double **) malloc (sizeof (double *)*np);

      if (!opt->grads || !opt->old_grads)
         {
         cg_malloc (opt, 0);
         return -1;
         }

      for (i = 0; i < np; ++i)
         {
         opt->grads[i] = (double *) malloc (sizeof (double)*ne);
         opt->old_grads[i] = (double *) malloc (sizeof (double)*ne);

         if (!opt->grads[i] || !opt->old_grads[i])
            {
            cg_malloc (opt, 0);
            return -1;
            }
         }
      }
   else
      {
      free ((void *) opt->old_error); opt->old_error = NULL;
      free ((void *) opt->current_error); opt->current_error = NULL;
      free ((void *) opt->func_err); opt->func_err = NULL;
      free ((void *) opt->p_list); opt->p_list = NULL;
      free ((void *) opt->op_list); opt->op_list = NULL;
      free ((void *) opt->function_p_list); opt->function_p_list = NULL;
      free ((void *) opt->mp_list); opt->mp_list = NULL;
      free ((void *) opt->mfactor); opt->mfactor = NULL;
      free ((void *) opt->offset); opt->offset = NULL;
      free ((void *) opt->s_dirs); opt->s_dirs = NULL;
      free ((void *) opt->param_flag); opt->param_flag = NULL;

      if (opt->grads)
         {
         unsigned i;

         for (i = 0; i < opt->n_params; ++i)
            free ((void *) opt->grads[i]);

         free ((void *) opt->grads);
         opt->grads = NULL;
         }

      if (opt->old_grads)
         {
         unsigned i;

         for (i = 0; i < opt->n_params; ++i)
            free ((void *) opt->old_grads[i]);

         free ((void *) opt->old_grads);
         opt->old_grads = NULL;
         }

      return 0;
      }

   // check to make sure that memory allocation succeeded
   if (!opt->old_error || !opt->current_error || !opt->func_err ||
      !opt->p_list || !opt->mp_list || !opt->op_list || !opt->mfactor ||
      !opt->offset || !opt->s_dirs || !opt->grads || !opt->old_grads ||
      !opt->param_flag)
      {
      // recursively call to deallocate memory
      cg_malloc (opt, 0);
      return -1;
      }
   
   return 0;
   }

/**************************************************************************/
/**************************************************************************/
/*                                                                        */
/*                       MAIN OPTIMIZATION ROUTINES                       */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/

int cg_optimize4 (OPTIMIZE *opt, unsigned max_iterations, double *final_error)
   {
   unsigned i,j;
   unsigned k = 0;
   unsigned count = 0;
   unsigned flag;
   
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return -1;
      }

   // check for valid fields in the OPTIMIZE structure

   if (!opt->params || !opt->n_params)
      {
      set_cg_error (ERR_NO_PARAMS);
      return -1;
      } 
   else if (!opt->function)
      {
      set_cg_error (ERR_NO_FUNCTION);
      return -1;
      }
   else if (!opt->n_errors)
      {
      set_cg_error (ERR_NO_ERF);
      return -1;
      }

   // allocate memory
   if (cg_malloc (opt, 1))
      {
      set_cg_error (ERR_NO_MEM);
      return -1;
      }

   // create a parameter list and map the parameters to be optimized
   for (i = 0; i < opt->n_params; ++i)
      {
      opt->p_list[i] = opt->op_list[i] = opt->function_p_list[i] = opt->params[i].nom;
      if (opt->params[i].optimize &&
         (opt->params[i].min < opt->params[i].max) &&
         (opt->params[i].nom <= opt->params[i].max) &&
         (opt->params[i].nom >= opt->params[i].min))
         {
         opt->mp_list[i] = map_parameter (opt->params[i], &opt->offset[i], &opt->mfactor[i]);
         opt->param_flag[i] = 1;
         ++k;
         }
      else
         {
         opt->param_flag[i] = 0;
         opt->mp_list[i] = 0.0;
         opt->offset[i] = 0.0;
         opt->mfactor[i] = 0.0;
         }
      }

   if (k < 1)
      {
      set_cg_error (ERR_NO_PARAMS);
      cg_malloc (opt, 0);
      return -1;
      }

   // make sure that the weight values are positive
   if (opt->weights)
      for (i = 0; i < opt->n_errors; ++i)
         opt->weights[i] = fabs (opt->weights[i]);
      
   // calculate the initial error
   opt->current_total_error = opt_function (opt, opt->mp_list);
   if (opt->current_total_error < 0.0)
      {
      cg_malloc (opt, 0);
      return -1;
      }
   for (j = 0; j < opt->n_errors; ++j)
      opt->current_error[j] = opt->func_err[j];
      
   // if maximum iterations is 0, print the error and return
   if (!max_iterations)
      {
      print_error_values (opt, 0);
      cg_malloc (opt, 0);
      return 0;
      }
   
   /************** MAIN OPTIMIZATION LOOP ***************/
   
   for (i = 1; i <= max_iterations; ++i)
      {
      // copy the current error vector to the old error vector
      for (j = 0; j < opt->n_errors; ++j)
         opt->old_error[j] = opt->current_error[j];
      opt->old_total_error = opt->current_total_error;
      
      // calculate the gradients
      if (compute_gradients (opt))
         {
         cg_malloc (opt, 0);
         return -1;
         }

      // compute the search direction vector
      compute_search_dirs (opt, i);
      
      // perform the line search
      if (perform_line_search (opt))
         {
         cg_malloc (opt, 0);
         return -1;
         }

      // unmap the new parameters to the parameter list
      for (j = 0; j < opt->n_params; ++j)
         {
         if (opt->param_flag[j])
            {
            if (opt->mp_list[j] < -1.0)
               opt->mp_list[j] = -1.0;
            if (opt->mp_list[j] > 1.0)
               opt->mp_list[j] = 1.0;
               
            opt->p_list[j] = unmap_parameter (opt->mp_list[j], opt->offset[j], opt->mfactor[j]);
            }
         }
      
      // print the error
      print_error_values (opt, i);

      // exit if the error functions changed by less than the specified error fraction
      //  for the number of iterations specified in opt->err_fraction_repeat + 1
      if (opt->err_fraction_repeat && (opt->err_fraction > 0.0))
         {
         if (fabs (opt->old_total_error - opt->current_total_error) < (opt->err_fraction * opt->current_total_error))
            ++count;
         else
            count = 0;

         if (count > opt->err_fraction_repeat)
            break;
         }

      // exit if the change in each parameter since the last iteration is less than
      // the tolerance of that parameter
      flag = k = 0;
      for (j = 0; j < opt->n_params; ++j)
         {
         if (opt->param_flag[j])
            {
            ++k;
            if (fabs (opt->op_list[j] - opt->p_list[j]) < opt->params[j].tol)
               ++flag;
            }
         opt->op_list[j] = opt->p_list[j];
         }
      if (flag == k)
         break;

      } // end of main optimization loop
   
   // copy the optimized parameters back to the param structure
   for (j = 0; j < opt->n_params; ++j)
      {
      opt->params[j].nom = opt->p_list[j];
      opt->mp_list[j] = map_parameter (opt->params[j], &opt->offset[j], &opt->mfactor[j]);
      }

   // run one more iteration of the optimization function to make sure the final error is current
   opt->current_total_error = opt_function (opt, opt->mp_list);
   for (j = 0; j < opt->n_errors; ++j)
      opt->current_error[j] = opt->func_err[j];

   if (final_error)
      {
      for (j = 0; j < opt->n_errors; ++j)
         final_error[j] = opt->current_error[j];
      }
   
   // free all allocated memory 
   cg_malloc (opt, 0);
      
   return 0;
   }

/**************************************************************************/
/**************************************************************************/

char *get_cg_error (void)
   {
   static char *error_def[] = 
      {
      NULL,
      "Memory allocation failed. System resources may be depleted.",
      "Optimization error function returned an error.",
      "No parameters to be optimized.",
      "No errors defined for the error function.",
      "The error function is not defined,",
      "Invalid function argument.",
      "Error during numerical gradient calculation",
      "External gradient function returned an error"
      };

   if (cg_global_error > 8)
      return NULL;

   return error_def[cg_global_error];
   }

/**************************************************************************/
/**************************************************************************/

OPTIMIZE *initialize_cg_optimizer (void)
   {
   OPTIMIZE *opt = (OPTIMIZE *) malloc (sizeof (OPTIMIZE));
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_NO_MEM);
      return NULL;
      }

   *opt = default_optimizer_values;

   return opt;
   }

/**************************************************************************/
/**************************************************************************/

int set_cg_parameters (OPTIMIZE *opt, OPT_PARAMETER *p, unsigned n_params)
   {
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   if (!p || (n_params < 1))
      {
      opt->params = NULL;
      opt->n_params = 0;
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   opt->params = p;
   opt->n_params = n_params;

   return 0;
   }

/**************************************************************************/
/**************************************************************************/

int set_cg_error_function (OPTIMIZE *opt, int (*func) (double *, void *, double *,
                           unsigned), void *data, unsigned n_errs, double *weights)
   {
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   opt->function = func;
   opt->function_data = data;
   opt->n_errors = n_errs;
   opt->weights = weights;

   return 0;
   }

/**************************************************************************/
/**************************************************************************/

int set_cg_gradient_function (OPTIMIZE *opt, int (*func) (double *, void *, double **,
                              unsigned, unsigned, int *), void *data)
   {
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   opt->gradients = func;
   opt->gradient_data = data;

   return 0;
   }

/**************************************************************************/
/**************************************************************************/

int set_cg_print_format (OPTIMIZE *opt, char *fmt)
   {
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   if (!fmt || (fmt[0] == 0))
      opt->print_format[0] = 0;
   else
      {
      strncpy (opt->print_format, fmt, 19);
      opt->print_format[19] = 0;
      }

   return 0;
   }

/**************************************************************************/
/**************************************************************************/

int set_cg_error_fraction (OPTIMIZE *opt, double fraction, unsigned repeat)
   {
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   opt->err_fraction = fraction;
   opt->err_fraction_repeat = repeat;

   return 0;
   }

/**************************************************************************/
/**************************************************************************/

int set_cg_flags (OPTIMIZE *opt, unsigned long flags)
   {
   set_cg_error (NO_ERROR);

   if (!opt)
      {
      set_cg_error (ERR_INVALID_ARG);
      return 1;
      }

   opt->flags = flags;

   return 0;
   }






