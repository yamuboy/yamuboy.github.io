typedef struct _NETLIST_DEF
 {
 int type;            // element type
 char id[10];            // id string
 unsigned nodes[10];     // node connections
 double value[10];      // element values
 unsigned index[10];       // gradient array position index
 struct _NETLIST_DEF *next;  // linked list pointer
 } NETLIST;

#define Netlist_UNKNOWN  0 
#define Netlist_R        1
#define Netlist_G        2
#define Netlist_C        3
#define Netlist_L        4
#define Netlist_SRL      5
#define Netlist_SRC      6
#define Netlist_TCAP     7
#define Netlist_VCCS     8

#define UNKNOWN_DEVICE  0
#define FET_DEVICE      1
#define HBT_DEVICE      2

#define STATIC_COMPONENT   ((unsigned) -1)

typedef struct
 {
 double freq;
 COMPLEX s[4];
 double k;
 double MAG;
 double b;
 } S_2PORT;

typedef struct
   {
   double vds,ids,vgs,igs;
   int dtype;
   } S_BIAS;
 

