#ifndef JB_SORTING_TYPES
#define JB_SORTING_TYPES

#define INTEGER_TYPE  10
#define DOUBLE_TYPE   12
#define STRING_TYPE   14

#ifdef __cplusplus
extern "C" {
#endif

typedef union
   {
   double *dval;
   int *ival;
   char *strg;
   } JB_SORT_VALUES;

typedef struct _sorting_struct
   {
   JB_SORT_VALUES *value;
   int szvalue;
   unsigned long position;
   struct _sorting_struct *next;
   } JB_SORT_STRUCT;


extern JB_SORT_STRUCT *sort_data (JB_SORT_STRUCT *sort_struct, int order[], int types[], unsigned n);

extern JB_SORT_STRUCT *append_sorting_list (unsigned nparams, int types[], unsigned long position,
                                       JB_SORT_STRUCT *start, JB_SORT_VALUES *vals);

extern JB_SORT_STRUCT *va_append_sorting_list (unsigned nparams, int types[], unsigned long position,
                                       JB_SORT_STRUCT *start, ...);

extern void free_sorting_list (JB_SORT_STRUCT *s);

#ifdef __cplusplus
}
#endif

#endif /* JB_SORTING_TYPES */

