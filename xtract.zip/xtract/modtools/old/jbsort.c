#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "jbsort.h"

/***********************************************************************************/
/***********************************************************************************/

static int do_sort (JB_SORT_STRUCT *ptr1, JB_SORT_STRUCT *ptr2, int order[], int types[], unsigned p, unsigned n)
   {
   int i,strtst;

   if (p >= n)
      return 0;

   i = abs (order[p]) - 1;

   if ((i >= ptr1->szvalue) || (i >= ptr2->szvalue))
      {
      fprintf (stderr,"ERROR: array over-index during sort. Invalid sort order\n");
      fprintf (stderr,"or invalid member in linked list.\n");
      return -1;
      }

   switch (types[i])
      {
      case INTEGER_TYPE:
         if (*(ptr1->value[i].ival) == *(ptr2->value[i].ival))
            // go one level deeper...
            return do_sort (ptr1,ptr2,order,types,p+1,n);
         else if ((order[p] < 0) && (*(ptr1->value[i].ival) < *(ptr2->value[i].ival)))
            return 1;
         else if ((order[p] > 0) && (*(ptr1->value[i].ival) > *(ptr2->value[i].ival)))
            return 1;
         break;

      case DOUBLE_TYPE:
         if (*(ptr1->value[i].dval) == *(ptr2->value[i].dval))
            // go one level deeper...
            return do_sort (ptr1,ptr2,order,types,p+1,n);
         else if ((order[p] < 0) && (*(ptr1->value[i].dval) < *(ptr2->value[i].dval)))
            return 1;
         else if ((order[p] > 0) && (*(ptr1->value[i].dval) > *(ptr2->value[i].dval)))
            return 1;
         break;

      case STRING_TYPE:
         strtst = strcasecmp (ptr1->value[i].strg,ptr2->value[i].strg);
         if (!strtst)
            // go one level deeper
            return do_sort (ptr1,ptr2,order,types,p+1,n);
         else if ((order[p] < 0) && (strtst < 0))
            return 1;
         else if ((order[p] > 0) && (strtst > 0))
            return 1;
         break;

      default: // invalid type specification, go one level deeper
         return do_sort (ptr1,ptr2,order,types,p+1,n);
      }

   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/

JB_SORT_STRUCT *sort_data (JB_SORT_STRUCT *sort_struct, int order[], int types[], unsigned n)
   {
   JB_SORT_STRUCT *begin_sort,*list_ptr,*tmp,*last;
   unsigned changed,i,j;
   int swap;

   /* error checking */
   if (!sort_struct || !sort_struct->next)
      {
      fprintf (stderr,"\nERROR: No sorting data sent to sort_data(), or\n");
      fprintf (stderr,"badly formed linked list\n");
      return NULL;
      }
   else if (n < 1)
      {
      fprintf (stderr,"\nERROR: Number of sorting parameters cannot be 0.\n");
      return NULL;
      }

   for (i = 0; i < n-1; ++i)
      {
      for (j = i+1; j < n; ++j)
         {
         if (order[i] == order[j])
            {
            printf ("\nERROR: Column %d appears more than once in the sorting order.\n",abs (order[i]));
            return NULL;
            }
         else if (!order[i] || !order[j])
            {
            printf ("\nERROR: Column 0 does not exist.\n");
            return NULL;
            }
         }
      }

   /* initial starting point */
   begin_sort = sort_struct;

   do {
      for (list_ptr = begin_sort, changed = 0; list_ptr->next; )   
         {
         swap = do_sort (list_ptr,list_ptr->next,order,types,0,n);

         if (swap > 0)
            {
            tmp = list_ptr->next;
            /* now swap */
            list_ptr->next = tmp->next;
            tmp->next = list_ptr;
            if (list_ptr == begin_sort)
               begin_sort = tmp;
            else
               last->next = tmp;
            last = tmp;
            changed = 1;
            }
         else if (swap < 0)
            {
            fprintf (stderr,"An error occured during sorting.\n");
            return NULL;
            }
         else
            {
            last = list_ptr;
            list_ptr = list_ptr->next;
            }
         }
      }
   while (changed);

   /* done sorting, now return new begining point */
   return begin_sort;
   }

/***********************************************************************************/
/***********************************************************************************/

JB_SORT_STRUCT *append_sorting_list (unsigned nparams, int types[], unsigned long position,
                                       JB_SORT_STRUCT *start, JB_SORT_VALUES *vals)
   {
   JB_SORT_STRUCT *s,*prev;
   JB_SORT_VALUES *v;
   va_list ap;
   int i;

   // find the last item of the linked list
   if (start)
      for (prev = start; prev->next; prev = prev->next);

   if (nparams < 1)
      {
      fprintf (stderr,"WARNING: Unable to append sorting list.\n");
      fprintf (stderr,"Number of parameters cannot be <= 0.\n");
      return start;
      }

   s = (JB_SORT_STRUCT *) malloc (sizeof (JB_SORT_STRUCT));
   if (!s)
      {
      fprintf (stderr,"WARNING: Unable to append sorting list.\n");
      fprintf (stderr,"Out of memory.\n");
      return start;
      }

   v = (JB_SORT_VALUES *) malloc (sizeof (JB_SORT_VALUES)*nparams);
   if (!v)
      {
      free ((void *) s);
      fprintf (stderr,"WARNING: Unable to append sorting list.\n");
      fprintf (stderr,"Out of memory.\n");
      return start;
      }

   s->value = v;
   s->szvalue = nparams;
   s->position = position;
   s->next = NULL;

   for (i = 0; i < nparams; ++i)
      v[i] = vals[i];

   if (start)
      {
      prev->next = s;
      return start;
      }

   return s;  // this should only happen when this is the first item of the sorting list
   }

/***********************************************************************************/
/***********************************************************************************/

JB_SORT_STRUCT *va_append_sorting_list (unsigned nparams, int types[], unsigned long position,
                                       JB_SORT_STRUCT *start, ...)
   {
   JB_SORT_STRUCT *s,*prev;
   JB_SORT_VALUES *v;
   va_list ap;
   int i;

   // find the last item of the linked list
   if (start)
      for (prev = start; prev->next; prev = prev->next);

   if (nparams < 1)
      {
      fprintf (stderr,"WARNING: Unable to append sorting list.\n");
      fprintf (stderr,"Number of parameters cannot be <= 0.\n");
      return start;
      }

   s = (JB_SORT_STRUCT *) malloc (sizeof (JB_SORT_STRUCT));
   if (!s)
      {
      fprintf (stderr,"WARNING: Unable to append sorting list.\n");
      fprintf (stderr,"Out of memory.\n");
      return start;
      }

   v = (JB_SORT_VALUES *) malloc (sizeof (JB_SORT_VALUES)*nparams);
   if (!v)
      {
      free ((void *) s);
      fprintf (stderr,"WARNING: Unable to append sorting list.\n");
      fprintf (stderr,"Out of memory.\n");
      return start;
      }

   s->value = v;
   s->szvalue = nparams;
   s->position = position;
   s->next = NULL;

   va_start (ap,start);

   for (i = 0; i < nparams; ++i)
      {
      switch (types[i])
         {
         case INTEGER_TYPE:
            v[i].ival = va_arg (ap,int *);
            break;
         case DOUBLE_TYPE:
            v[i].dval = va_arg (ap,double *);
            break;
         case STRING_TYPE:
            v[i].strg = va_arg (ap,char *);
            break;
         default:
            free ((void *) s);
            free ((void *) v);
            va_end (ap);
            fprintf (stderr,"WARNING: Unable to append sorting list.\n");
            fprintf (stderr,"Invalid type specification.\n");
            return start;
         }
      }

   va_end (ap);

   if (start)
      {
      prev->next = s;
      return start;
      }

   return s;  // this should only happen when this is the first item of the sorting list
   }

/***********************************************************************************/
/***********************************************************************************/

void free_sorting_list (JB_SORT_STRUCT *s)
   {
   JB_SORT_STRUCT *tmp;

   while (s)
      {
      tmp = s;
      s = s->next;
      free ((void *) tmp->value);
      free ((void *) tmp);
      }
   }


            









