
#define OPT_VERBOSE      (1)

typedef struct _optimization_struct
{
int num_of_params;
int num_of_criteria;
double *weights;
unsigned long flags;
int max_iterations;
double err_fraction;
double *(*function) ();
} OPT_STRUCT;

typedef struct _parameter_struct
{
double min;
double nom;
double max;
double tol;
char   name[20];
char   units[20];
int    optimize;
} PARAM_STRUCT;
