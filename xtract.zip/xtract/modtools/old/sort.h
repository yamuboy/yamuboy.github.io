#include <sorttypes.h>

#ifndef JB_SORTING_PROTO
#define JB_SORTING_PROTO

extern JB_SORT_STRUCT *sort_data (JB_SORT_STRUCT *sort_struct, int order[], int types[], unsigned n);

extern JB_SORT_STRUCT *append_sorting_list (unsigned nparams, int types[], unsigned long position,
                                       JB_SORT_STRUCT *start, JB_SORT_VALUES *vals);

extern JB_SORT_STRUCT *va_append_sorting_list (unsigned nparams, int types[], unsigned long position,
                                       JB_SORT_STRUCT *start, ...);

extern void free_sorting_list (JB_SORT_STRUCT *s);

#endif

