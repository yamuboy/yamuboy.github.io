#ifndef JB_SORTING_TYPES
#define JB_SORTING_TYPES

#define INTEGER_TYPE  10
#define DOUBLE_TYPE   12
#define STRING_TYPE   14

typedef union
   {
   double *dval;
   int *ival;
   char *strg;
   } JB_SORT_VALUES;

typedef struct _sorting_struct
   {
   union sort_types *value;
   int szvalue;
   unsigned long position;
   struct _sorting_struct *next;
   } JB_SORT_STRUCT;

#endif
