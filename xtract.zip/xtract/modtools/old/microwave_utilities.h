typedef struct
{
double real;
double imag;
} COMPLEX;

typedef struct
{
double mag;
double ang;
} POLAR;

extern COMPLEX complex_add ();
extern COMPLEX complex_sub ();
extern COMPLEX complex_mult ();
extern COMPLEX complex_div ();
extern COMPLEX polar_to_rect ();

extern POLAR polar_div ();
extern POLAR polar_mult ();
extern POLAR polar_sub ();
extern POLAR polar_add ();
extern POLAR rect_to_polar ();

extern COMPLEX *polar_2x2_rect ();
extern POLAR   *rect_2x2_polar ();

extern COMPLEX *complex_2x2_add ();
extern COMPLEX *complex_2x2_sub ();
extern COMPLEX *complex_2x2_mult ();
extern COMPLEX *complex_2x2_inv ();

extern COMPLEX *embed ();
extern COMPLEX *deembed ();

extern COMPLEX *s2h ();
extern COMPLEX *s2y ();
extern COMPLEX *s2z ();
extern COMPLEX *s2t ();
extern COMPLEX *s2abcd ();

extern COMPLEX *y2h ();
extern COMPLEX *y2z ();
extern COMPLEX *y2t ();
extern COMPLEX *y2abcd ();
extern COMPLEX *y2s ();

extern COMPLEX *z2h ();
extern COMPLEX *z2y ();
extern COMPLEX *z2t ();
extern COMPLEX *z2abcd ();
extern COMPLEX *z2s ();

extern COMPLEX *abcd2h ();
extern COMPLEX *abcd2y ();
extern COMPLEX *abcd2z ();
extern COMPLEX *abcd2t ();
extern COMPLEX *abcd2s ();

extern COMPLEX *t2h ();
extern COMPLEX *t2y ();
extern COMPLEX *t2s ();
extern COMPLEX *t2abcd ();
extern COMPLEX *t2z ();
