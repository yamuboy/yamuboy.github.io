#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include <optimize3.h>

/* DECLARATIONS */

#define MAXARG           70.0
#define RESET_INTERVAL   5
#define mod(x,y)         ((x) - ((int)((x)/(y))) * (y))

typedef struct _opt_mem_alloc
   {
   double    *old_err;
   double    *cur_err;
   double    *func_err;
   double    *error1;
   double    *error2;
   double    *p_list;
   int       *mapping;
   double    *mp_list;
   double    *tp_list;
   double    *op_list;
   double    *mfactor;
   double    *offset;
   double    *tol;
   double    *s_dirs;
   double    *grads;
   double    *old_grads;
   } OPT_MEM_ALLOC;

// globally accessible variables
static OPT_STRUCT      *pnfo;
static OPT_MEM_ALLOC   *mem1;
static PARAM_STRUCT    *parms;
static double          max_mapping_value;

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

static int sdir_reset (int x)
   {
   if (x < 1)
      return 0;
   else if (x == 1)
      return 1;
   else
      return (mod(x,pnfo->reset_interval) == 1);
   }

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

#ifdef WIN32  // windows does not have the isnan facility
static int isnan (double x)
   {
   if ((x > -HUGE_VAL) && (x < HUGE_VAL))
      return 0;
   
   return 1;
   }
#endif

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/
      
static double tan_hyp (double x)
   {   
   if (x > MAXARG)
      return 1.0;
   else if (x < -MAXARG)
      return -1.0;
   else
      {
      double res1 = exp (x);
      double res2 = exp (-x);
      return (res1 - res2)/(res1 + res2);
      }
   }

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/
   
static double arctan_hyp (double x)
   {
   
   if (x >= 1.0)
      return MAXARG;
   else if (x <= -1.0)
      return -MAXARG;
   else
      return 0.5*log ((1.0 + x)/(1.0 - x));
   }

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/
   
static double map_parameter (PARAM_STRUCT *p, double *offset, double *mag, double *tol)
   {
   *mag = 2.0 / (p->max - p->min);
   *offset = (p->max + p->min) * 0.5;
   
   if (pnfo->mapping_mode)
      {
      *tol = p->tol * (*mag);
      return (*mag) * (p->nom - (*offset));
      }
   else
      {
      *tol = arctan_hyp(p->tol * (*mag));
      return arctan_hyp((*mag) * (p->nom - (*offset)));
      }
   }
   
/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

static double unmap_parameter (double mparam, double offset, double mag)
   {
   if (pnfo->mapping_mode)
      return mparam/mag + offset;
   else
      return tan_hyp(mparam)/mag + offset;
   }
      
/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

static double opt_function (double *mpl, int np)
   {
   double   *err1;
   double   x = 0.0;
   int      i;
   
   for (i = 0; i < np; ++i)
      mem1->p_list[mem1->mapping[i]] = unmap_parameter (mpl[i],mem1->offset[i],mem1->mfactor[i]);

   err1 = pnfo->function (mem1->p_list);
   
   for (i = 0; i < pnfo->num_of_criteria; ++i)
      {
      x += err1[i]*pnfo->weights[i];
      mem1->func_err[i] = err1[i]; 
      }
   
   return x;
   }

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

static void compute_gradients (int np)
   {
   double *grads;
   double *error1;
   double *error2;
   double *pl,*mpl;
   double delta;
   double temp1,temp2;
   double grad_func;
   int i,j;
   int nc;
   
   nc = pnfo->num_of_criteria;
   
   /* copy the current gradients for memory */
   for (i = 0; i < nc*np; ++i)
      mem1->old_grads[i] = mem1->grads[i];
   
   // gradient function supplied in optimization struct
   if (pnfo->gradients)
      {
      grads = pnfo->gradients (mem1->p_list);
      mpl = mem1->mp_list;
      
      for (i = 0; i < np; ++i)
         {
         if (pnfo->mapping_mode)
            grad_func = 1.0;
         else
            // this function models the effect on delta_mp w.r.t delta_p
            // grad_func = 1.0/exp (1.6*arctan_hyp (mpl[i]*mpl[i]));
         
         // map gradients
         for (j = 0; j < nc; ++j)
            mem1->grads[i*nc+j] = grads[mem1->mapping[i]*nc+j]*grad_func;
         }

      grads = mem1->grads;
      }
   
   // else do numerical gradients
   else
      {
      pl = mem1->p_list;
      mpl = mem1->mp_list;
      error1 = mem1->error1;
      error2 = mem1->error2;
      grads = mem1->grads;

      for (i = 0; i < np; ++i)
         {
         if (pnfo->mapping_mode)
            delta = pnfo->numerical_delta;
         else
            {
            // map delta using the modeling function, this is done s.t. delta will be
            //  approx. the same no matter where the parameter is mapped to
            /*
            delta = pnfo->numerical_delta*exp (((double) 1.6)*arctan_hyp (mpl[i]*mpl[i]));
            if (delta < pnfo->numerical_delta)
               {
               delta = pnfo->numerical_delta;
               }
            */
            delta = pnfo->numerical_delta;
            }
           
         temp1 = mpl[i];  
         temp2 = pl[mem1->mapping[i]];
         
         mpl[i] = temp1+delta;
         opt_function (mpl,np);
         for (j = 0; j < nc; ++j)
            {
            error1[j] = mem1->func_err[j];
            }
         
         mpl[i] = temp1-delta;
         opt_function (mpl,np);
         for (j = 0; j < nc; ++j)
            {
            error2[j] = mem1->func_err[j];
            }
         
         mpl[i] = temp1;
         pl[mem1->mapping[i]] = temp2;

         /* use negative gradient */
         for (j = 0; j < nc; ++j)
            grads[i*nc+j] = (error2[j]-error1[j])*0.5/delta;
         }
      }

   // protect gradients
   for (i = 0; i < np; ++i)
      {
      for (j = 0; j < nc; ++j)
         {
         if (isnan (grads[i*nc+j]))
            {
            grads[i*nc+j] = 0.0;
            fprintf (stderr,"WARNING: NaN encountered in gradient. Parameter \'%s\'\n",parms[mem1->mapping[i]].name);
            }
            
         /* don't allow gradients to point outside of min/max range */
         if ((mpl[i] > max_mapping_value) && (grads[i*nc+j] > 0.0))
            grads[i*nc+j] = 0.0;
         else if ((mpl[i] < -max_mapping_value) && (grads[i*nc+j] < 0.0))
            grads[i*nc+j] = 0.0;
         }
      }
   }

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

static void compute_sdirs (int np, int iter)
   {
   double         *s_dir;
   double         *gr,*ogr,*wts;
   double         x1,x2,x3,x4;
   double         beta;
   int            i,j,nc;

   nc = pnfo->num_of_criteria;
   wts = pnfo->weights;
   gr = mem1->grads;
   ogr = mem1->old_grads;
   s_dir = mem1->s_dirs;

   beta = 0.0;

   // find beta for itererations greater than 1
   if (iter > 1)
      {
      x1 = 0.0;
      x2 = 0.0;
      for (i = 0; i < np; ++i)
         {
         x3 = 0.0;
         x4 = 0.0;
         for (j = 0; j < nc; ++j)
            {
            x3 += ogr[i*nc+j]*wts[j];
            x4 += gr[i*nc+j]*wts[j];
            }
         x1 += x3*x3;
         x2 += x4*x4;
         }
      
      beta = x2/x1;
      }
     
   if ((beta > pnfo->maximum_beta) || isnan (beta) || sdir_reset (iter))
      beta = 0.0;

   /* compute the search direction */
   for (i = 0; i < np; ++i)
      {
      x1 = 0.0;
      for (j = 0; j < nc; ++j)
         x1 += gr[i*nc+j]*wts[j];

      s_dir[i] = s_dir[i]*beta + x1;
      }
   }
   
/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

static void perform_line_search (int np, double *last_err)
   {
   double         *s_dir;
   double         *mpl,*tp;
   double         alpha;
   double         last_alpha;
   double         x1,x2,x3,y1,y2,y3,z1;
   int            repeat;
   int            i,j,k;
   int            nc;
   
   nc = pnfo->num_of_criteria;
   mpl = mem1->mp_list;
   tp = mem1->tp_list;
   s_dir = mem1->s_dirs;

   /* find a new alpha based on the largest s_dir */
   x1 = 0.0;
   for (i = 0; i < np; ++i)
      {
      x2 = fabs (s_dir[i]);
      if (x2 > x1)
         x1 = x2;
      }

   if (x1 < 1.0e-16)
      {
      fprintf (stderr,"WARNING: All gradients are zero in line search.\n");
      return;
      }

   alpha = pnfo->alpha_numerator/x1;
   
   /* find the best approximate step size (alpha) */
   y1 = *last_err;
   x1 = 0.0;
   last_alpha = alpha;
   do {
      for (i = 0; i < np; ++i)
         tp[i] = mpl[i]+alpha*s_dir[i];

      y2 = opt_function (tp,np);
      
      if ((y2 > y1) || isnan (y2))
         alpha *= 0.5;

      if (alpha < 1.0e-16)
         return;
      }
   while (y2 > y1);
   x2 = alpha;

   // new error calculation is less than old error
   for (j = 0; j < nc; ++j)
      mem1->cur_err[j] = mem1->func_err[j];

   /* perform the line search */
   k = -1;
   do {
      repeat = 0;
      x3 = x2+alpha;
      for (i = 0; i < np; ++i)
         tp[i] = mpl[i]+x3*s_dir[i];

      y3 = opt_function (tp,np);
            
      if (isnan (y3))
         break;
      
      if ((y3 < y2) && (++k < pnfo->max_search_segs))
         {
         y1 = y2;
         x1 = x2;
         y2 = y3;
         x2 = x3;
         repeat = 1;

         // new error calculation is less than old error
         for (j = 0; j < nc; ++j)
            mem1->cur_err[j] = mem1->func_err[j];
         }
      }
   while (repeat);
   
   /* now the local minimum is bounded between alpha=x1 and alpha=x3 */
   /* do a quadratic fit to find the optimum alpha */
   alpha = 0.5*(x1+x2+(y1-y2)*(x3-x1)*(x3-x2)/(x1*(y2-y3)+x2*(y3-y1)+x3*(y2-y1)));
   if ((alpha <= x1) || (alpha >= x3) || isnan (alpha))
      {
      for (i = 0; i < np; ++i)
         mpl[i] = mpl[i]+x2*s_dir[i];

      *last_err = y2;
      return;
      }
   
   // calculate the resulting error from the quadratically fit alpha
   for (i = 0; i < np; ++i)
      tp[i] = mpl[i]+alpha*s_dir[i];
   z1 = opt_function (tp,np);

   // check which error is best
   if (isnan (z1) || (y2 < z1))
      {
      for (i = 0; i < np; ++i)
         mpl[i] = mpl[i]+x2*s_dir[i];
      *last_err = y2;
      }
   else
      {
      for (i = 0; i < np; ++i)
         mpl[i] = mpl[i]+alpha*s_dir[i];

      *last_err = z1;
      // new error calculation is less than old error
      for (j = 0; j < nc; ++j)
         mem1->cur_err[j] = mem1->func_err[j];
      }
   }
   
/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/
   
static OPT_MEM_ALLOC *cg_malloc (int np, int nc, int mode)
   {
   static OPT_MEM_ALLOC pmem;
   int freemem = 0;
   
   if (mode > 0)
      {
      if ((np < 1) || (nc < 1))
         return NULL;
      else
         {
         pmem.old_err = (double *) malloc (sizeof (double)*nc);
         pmem.cur_err = (double *) malloc (sizeof (double)*nc);
         pmem.error1 = (double *) malloc (sizeof (double)*nc);
         pmem.error2 = (double *) malloc (sizeof (double)*nc);
         pmem.func_err = (double *) malloc (sizeof (double)*nc);
         pmem.p_list = (double *) malloc (sizeof (double)*np);
         pmem.mp_list = (double *) malloc (sizeof (double)*np);
         pmem.tp_list = (double *) malloc (sizeof (double)*np);
         pmem.op_list = (double *) malloc (sizeof (double)*np);
         pmem.mapping = (int *) malloc (sizeof (int)*np);
         pmem.mfactor = (double *) malloc (sizeof (double)*np);
         pmem.offset = (double *) malloc (sizeof (double)*np);
         pmem.tol = (double *) malloc (sizeof (double)*np);
         pmem.s_dirs = (double *) malloc (sizeof (double)*np);
         pmem.grads = (double *) malloc (sizeof (double)*np*nc);
         pmem.old_grads = (double *) malloc (sizeof (double)*np*nc);
         
         if (!pmem.old_err || !pmem.cur_err || !pmem.error1  ||
             !pmem.error2  || !pmem.p_list  || !pmem.mapping ||
             !pmem.mp_list || !pmem.tp_list || !pmem.mfactor ||
             !pmem.offset  || !pmem.s_dirs  || !pmem.grads   ||
             !pmem.old_grads || !pmem.tol   || !pmem.op_list ||
             !pmem.func_err
             )
            freemem = 1;
         }
      }
   
   if ((mode < 0) || freemem)
      {
      free ((void *) pmem.old_err);
      free ((void *) pmem.cur_err);
      free ((void *) pmem.error1);
      free ((void *) pmem.error2);
      free ((void *) pmem.func_err);
      free ((void *) pmem.p_list);
      free ((void *) pmem.mapping);
      free ((void *) pmem.mp_list);
      free ((void *) pmem.tp_list);
      free ((void *) pmem.op_list);
      free ((void *) pmem.mfactor);
      free ((void *) pmem.offset);
      free ((void *) pmem.tol);
      free ((void *) pmem.s_dirs);
      free ((void *) pmem.grads);
      free ((void *) pmem.old_grads);
      return NULL;
      }
   
   return &pmem;
   }

/****************************************************************************/
/*                       MAIN OPTIMIZATION ROUTINES                         */
/****************************************************************************/

void initialize_optimizer (OPT_STRUCT *opt, int np, int nc, double *weights, int niter, double *(*function)())
   {
   opt->num_of_params = np;
   opt->num_of_criteria = nc;
   opt->weights = weights;
   opt->flags = OPT_VERBOSE;
   opt->max_iterations = niter;
   opt->err_fraction = 1.0e-9;
   opt->function = function;
   opt->gradients = NULL;
   strcpy (opt->pformat,"%.6e");
   opt->maximum_beta = 10.0;
   opt->alpha_numerator = 0.1;
   opt->numerical_delta = 1.0e-5;
   opt->max_search_segs = 10;
   opt->reset_interval = 10;
   opt->mapping_mode = 0;
   }

/*-------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------*/

int cg_optimize (OPT_STRUCT opt, PARAM_STRUCT *params)
   {
   double *current_error;
   double *old_error;
   double offset;
   double mfactor;
   double err_delta;
   double errorf;
   double tol;
   int i,j,k;
   int flag,count;
   int p_to_opt;
   char fmat[25];
   
   if (opt.num_of_params < 1)
      {
      fprintf (stderr,"ERROR: Number of Parameters cannot be less than 1.\n");
      return -1;
      }
   else if (opt.num_of_criteria < 1)
      {
      fprintf (stderr,"ERROR: Number of Optimization Criteria cannot be less than 1.\n");
      return -1;
      }
   
   mem1 = cg_malloc (opt.num_of_params,opt.num_of_criteria,1);
   if (!mem1)
      {
      fprintf (stderr,"ERROR: Unable to allocate memory.\n");
      return -1;
      }
   
   // make the optimization structure globally accessible
   pnfo = &opt;
   parms = params;

   if (opt.mapping_mode)
      max_mapping_value = 1.0;
   else
      max_mapping_value = 15.0;

   // set up the format string for printing error values
   strcpy (fmat,opt.pformat);
   strcat (fmat," ");
   
   current_error = mem1->cur_err;
   old_error = mem1->old_err;
   
   // create a parameter list and map the parameters to be optimized
   k = 0;
   for (j = 0; j < opt.num_of_params; ++j)
      {    
      mem1->p_list[j] = params[j].nom;
      if (params[j].optimize)
         {
         if (params[j].min < params[j].max)
            {
            mem1->mapping[k] = j;
            mem1->mp_list[k] = map_parameter (&params[j],&offset,&mfactor,&tol);
            mem1->offset[k] = offset;
            mem1->mfactor[k] = mfactor;
            mem1->op_list[k] = mem1->mp_list[k];
            mem1->tol[k] = tol;
            ++k;
            }
         }
      }
   p_to_opt = k;
   if (p_to_opt < 1)
      {
      fprintf (stderr,"ERROR: no parameters to optimize.\n");
      cg_malloc (0,0,-1);
      return -1;
      }
      
   // calculate the initial error
   errorf = opt_function (mem1->mp_list,p_to_opt);
   for (j = 0; j < opt.num_of_criteria; ++j)
      current_error[j] = mem1->func_err[j];
   
   // if maximum iterations is less than 1, print the error and return
   if (opt.max_iterations < 1)
      {
      if (opt.flags & OPT_VERBOSE)
         {
         fprintf (stderr,"%-5d ",0);

         if ((opt.flags & OPT_SNGLERR) || (opt.num_of_criteria == 1))
            fprintf (stderr,fmat,errorf);
         else
            {
            for (j = 0; j < opt.num_of_criteria; ++j)
               fprintf (stderr,fmat,current_error[j]*opt.weights[j]);
            }
         fprintf (stderr,"\n");
         }
            
      cg_malloc (0,0,-1);
      return 0;
      }
   
   /* ======== MAIN OPTIMIZATION LOOP =============== */
   
   count = 0;
   for (i = 1; i <= opt.max_iterations; ++i)
      {
      // copy the current error vector to the old error vector
      for (j = 0; j < opt.num_of_criteria; ++j)
         old_error[j] = current_error[j];
      
      // calculate the gradients
      compute_gradients (p_to_opt);

      // compute the search direction vector
      compute_sdirs (p_to_opt,i);
      
      // perform the line search
      perform_line_search (p_to_opt,&errorf);

      // unmap the new parameters to the parameter list
      for (j = 0; j < p_to_opt; ++j)
         mem1->p_list[mem1->mapping[j]] = unmap_parameter (mem1->mp_list[j],mem1->offset[j],mem1->mfactor[j]);
      
      // print the error 
      if (opt.flags & OPT_VERBOSE)
         {
         fprintf (stderr,"%-5d ",i);

         if ((opt.flags & OPT_SNGLERR) || (opt.num_of_criteria == 1))
            fprintf (stderr,fmat,errorf);
         else
            {
            for (j = 0; j < opt.num_of_criteria; ++j)
               fprintf (stderr,fmat,current_error[j]*opt.weights[j]);
            }
         fprintf (stderr,"\n");
         }
      
      // exit if the error functions changed by less than the specified error fraction
      //   for 3 straight iterations
      flag = 0;
      for (j = 0; j < opt.num_of_criteria; ++j)
         {
         err_delta = fabs (old_error[j]-current_error[j])*opt.weights[j];
         if (err_delta > opt.err_fraction*fabs (current_error[j]))
            ++flag;
         }
      
      if (!flag)
         {
         if (++count > 3)
            break;
         }
      else
         count = 1;

      // exit if the change in each parameter since the last iteration is less than
      // the tolerance of that parameter
      flag = 0;
      for (j = 0; j < p_to_opt; ++j)
         {
         if (fabs (mem1->op_list[j]-mem1->mp_list[j]) < mem1->tol[j])
            ++flag;
         mem1->op_list[j] = mem1->mp_list[j];
         }

      if (flag == p_to_opt)
         break;

      } // end of main optimization loop
   
   // copy the optimized parameters back to the param structure
   for (j = 0; j < opt.num_of_params; ++j)
      {
      params[j].nom = mem1->p_list[j];
      }
   
   // free all allocated memory 
   cg_malloc (0,0,-1);
      
   return 0;
   }


