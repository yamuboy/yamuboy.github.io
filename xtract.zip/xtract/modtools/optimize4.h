#ifndef _OPTIMIZE_H_INCLUDED
#define _OPTIMIZE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#ifndef TRUE
#define TRUE   1
#endif

#ifndef FALSE
#define FALSE  0
#endif

/* optimization parameter structure */

typedef struct
   {
   double min;  // minimum value
   double nom;  // nominal value
   double max;  // maximum value
   double tol;  // relative tolerance
   char name[20];  // optional name
   int optimize;  // optimize flag, TRUE or FALSE
   } OPT_PARAMETER;

/* optimizer modes */
enum optimize_modes {
   OMODE_GRADIENT,
   OMODE_RANDOM,
   OMODE_RANDOM_GRADIENT
   };

/* optimizer flags */

#define OPT_VERBOSE          1   // print iteration number and errors to stderr
#define OPT_SINGLE_ERROR     2   // print a single error function instead of multiple
#define HIGH_SIDE_GRADIENT   8   // single-sided gradient, using the high side
#define LOW_SIDE_GRADIENT    16  // single-sided gradient, using the low side
#define OPT_AUTO             32  // automatically switch over the single parameter mode, when simultaneous mode finishes
#define OPT_SINGLE_PARAM     64  // single parameter mode enabled, each parameter is optimized individually (much slower)

/* optimizer setup structure */

typedef struct
   {
   // vector of optimization parameters
   OPT_PARAMETER *params;

    // number of OPT_PARAMETER elements in the above vector
   unsigned n_params;

   // number of optimization error functions
   unsigned n_errors;

   // pointer to a vector of weights for the error functions
   // the length of this vector should be equal to n_errors
   // if NULL, a default weighting of 1 is used for all error functions
   double *weights;

   // optimizer flags (shown above)
   unsigned long flags;

   // fractional change in error that causes halting of the optimization loop
   // when the error changes less than the specified fractional change
   // calculated as {fabs(last_error-current_error) < current_error*err_fraction}
   double err_fraction;

   // number of iterations to continue to attempt optimization while the
   // err_fraction condition exists
   unsigned err_fraction_repeat;

   // interation count after which search directions are reset,
   // this resets the "memory" of the optimization
   unsigned reset_interval;

   // delta to be used when performing numerical gradients
   double numerical_delta;

   // maximum value of the "memory" parameter
   double maximum_beta;

   // sets the initial step size for the line search as alpha_numerator/(max gradient value)
   double alpha_numerator;

   // sets the maximum number of segments to calculate during the line search
   unsigned max_search_segments;

   // sets the format for printing errors
   char print_format[20];

   // pointer to the optimization error function:
   // p_list is a vector of parameter values equal in length to n_params,
   // data is a user defined pointer,
   // errors is a return vector of error values,
   // n_errors is the size of the errors vector,
   // the function should set values for all of the entries in the errors
   //  vector to prevent numerical problems in the optimizer
   // the function should return 0 on success, non-zero on failure
   int (*function) (double *p_list, void *data, double *errors, unsigned n_errors);

   // user defined pointer that is passed to the optimization error function
   void *function_data;

   // pointer to the gradient calculation function:
   // if this pointer is NULL gradients are calculated numerically by
   // repeated calls to the optimization error function
   // p_list is a vector of parameter values equal in length to n_params,
   // data is a user defined pointer,
   // gradients is a return array of conjugate gradients,
   // n_params is the size of the outer dimension of gradients,
   // n_errors is the size of the inner dimension of gradients,
   // flag is a vector of length n_params that has non-zero entries (boolean)
   //  for each outer gradient index that must be filled by the function
   //  other entries in the gradients array are ignored (parameter index is not
   //  being optimized)
   // the function should return 0 on success, non-zero on failure
   int (*gradients) (double *p_list, void *data, double **gradients, unsigned n_params, unsigned n_errors, int *flag);

   // user defined pointer that is passed to the gradient calculation function
   void *gradient_data;

   /***** INTERNAL USAGE ONLY *****/

   // values of the current and last total error calculations
   double current_total_error;
   double old_total_error;

   // pointers to internally allocated memory
   //  memory is freed when the main optimization loop terminates
   double *current_error;
   double *old_error;
   double *func_err;
   double *temp_error1;
   double *temp_error2;
   double *p_list;
   double *old_p_list;
   double *function_p_list;
   double *temp_pl;
   double *s_dirs;
   double **grads;
   double **old_grads;
   int *param_flag;
   } OPTIMIZE;

/* default structure values */

static const OPTIMIZE default_optimizer_values =
   {
   NULL,      // params
   0,         // n_params
   0,         // n_errors
   NULL,      // weights
   0L,        // flags
   0.0,       // err_fraction
   0,         // err_fraction_repeat
   4,         // reset_interval
   1.0e-4,    // numerical_delta
   0.5,       // maximum_beta
   100.0,     // alpha_numerator
   10,        // max_search_segments
   "",        // print_format
   NULL,      // function
   NULL,      // function_data
   NULL,      // gradients
   NULL,      // gradient_data
   // internal usage
   0.0,       // current_total_error
   0.0,       // old_total_error
   NULL,      // current_error
   NULL,      // old_error
   NULL,      // func_err
   NULL,      // temp_error1
   NULL,      // temp_error2
   NULL,      // p_list
   NULL,      // old_p_list
   NULL,      // function_p_list
   NULL,      // temp_pl
   NULL,      // s_dirs
   NULL,      // grads
   NULL,      // old_grads
   NULL       // param_flag
   };

extern int optimize( OPTIMIZE *opt, int opt_mode, unsigned max_iterations, double *final_error );
extern char *get_opt_error_msg( int errcode );
extern char *get_opt_error( void );
extern OPTIMIZE *initialize_optimizer( void );
extern int set_opt_parameters( OPTIMIZE *opt, OPT_PARAMETER *p, unsigned n_params );
extern int set_opt_error_function( OPTIMIZE *opt, int (*func) (), void *data, unsigned n_errs, double *weights );
extern int set_opt_gradient_function( OPTIMIZE *opt, int (*func) (), void *data );
extern int set_opt_print_format( OPTIMIZE *opt, char *fmt );
extern int set_opt_error_fraction( OPTIMIZE *opt, double fraction, unsigned repeat );
extern int set_opt_flags( OPTIMIZE *opt, unsigned long flags );

/* deprecated function names */
extern int cg_optimize4( OPTIMIZE *opt, unsigned max_iterations, double *final_error );
extern int random_optimize( OPTIMIZE *opt, unsigned max_iterations, double *final_error );
extern char *get_cg_error( void );
extern OPTIMIZE *initialize_cg_optimizer( void );
extern int set_cg_parameters( OPTIMIZE *opt, OPT_PARAMETER *p, unsigned n_params );
extern int set_cg_error_function( OPTIMIZE *opt, int (*func) (), void *data, unsigned n_errs, double *weights );
extern int set_cg_gradient_function( OPTIMIZE *opt, int (*func) (), void *data );
extern int set_cg_print_format( OPTIMIZE *opt, char *fmt );
extern int set_cg_error_fraction( OPTIMIZE *opt, double fraction, unsigned repeat );
extern int set_cg_flags( OPTIMIZE *opt, unsigned long flags );

#ifdef __cplusplus
}
#endif

#endif   // _OPTIMIZE_H_INCLUDED

