#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdarg.h>
#include "cmplxlib.h"

/* --- Global Constants --- */
static COMPLEX   zero = { 0.0,0.0};
static COMPLEX   one  = { 1.0,0.0};
static COMPLEX   two  = { 2.0,0.0};
static COMPLEX   neg2 = {-2.0,0.0};

/*********************************************************************/
/*********************************************************************/
/*                        INTERNAL FUNCTIONS                         */
/*********************************************************************/
/*********************************************************************/

static void CAcopy (COMPLEX *a, COMPLEX *b, int rows, int cols)
   {
   int i;
   
   for (i = 0; i < (rows*cols); ++i)
      b[i] = a[i];
   }

/*********************************************************************/
/*********************************************************************/
/*                          COMPLEX FUNCTIONS                        */
/*********************************************************************/
/*********************************************************************/

COMPLEX Cadd (COMPLEX a, COMPLEX b)
   {
   a.r += b.r;
   a.i += b.i;
   return a;
   }

/*********************************************************************/

COMPLEX Csub (COMPLEX a, COMPLEX b)
   {
   a.r -= b.r;
   a.i -= b.i;
   return a;
   }

/*********************************************************************/

COMPLEX Cmult (COMPLEX a, COMPLEX b)
   {
   COMPLEX c;
   c.r = (a.r*b.r) - (a.i*b.i);
   c.i = (a.r*b.i) + (b.r*a.i);
   return c;
   }

/*********************************************************************/

COMPLEX Cdiv (COMPLEX a, COMPLEX b)
   {
   COMPLEX c;
   c.r = (a.r*b.r + a.i*b.i)/(b.r*b.r + b.i*b.i);
   c.i = (b.r*a.i - a.r*b.i)/(b.r*b.r + b.i*b.i);
   return c;
   }

/*********************************************************************/

COMPLEX Cconj (COMPLEX a)
   {
   a.i = -a.i;   
   return a;
   }

/*********************************************************************/

COMPLEX Cneg (COMPLEX a)
   {
   a.r = -a.r;
   a.i = -a.i;
   return a;
   }

/*********************************************************************/

double Creal (COMPLEX a)
   {
   return a.r;
   }

/*********************************************************************/

double Cimag (COMPLEX a)
   {
   return a.i;
   }

/*********************************************************************/
/*
COMPLEX Cnum (double r, double i)
   {
   COMPLEX a;
   a.r = r;
   a.i = i;
   return a;
   }
*/
/*********************************************************************/

double Cmag (COMPLEX a)
   {   
   return sqrt (a.r*a.r + a.i*a.i);
   }

/*********************************************************************/

double Cmag2 (COMPLEX a)
   {   
   return a.r*a.r + a.i*a.i;
   }

/*********************************************************************/

COMPLEX Ccmag (COMPLEX a)
   {
   COMPLEX c;
   c.r = sqrt (a.r*a.r + a.i*a.i);
   c.i = 0.0;
   return c;
   }

/*********************************************************************/

double Cangle (COMPLEX a)
   {   
   double rad_to_deg = 180.0/acos(-1.0);
         
   if ((a.r == 0.0) && (a.i == 0.0))
      return 0.0;
   else
      return rad_to_deg*atan2(a.i,a.r);
   }

/*********************************************************************/
/*********************************************************************/
/*                    ELIPSIS COMPLEX FUNCTIONS                      */
/*********************************************************************/
/*********************************************************************/

COMPLEX Caddx (int n, ...)
   {
   COMPLEX  a;
   va_list  ap;
   int      i;

   if (n < 1)
      {
      a.r = 0.0;
      a.i = 0.0;
      return a;
      }

   va_start (ap,n);
   a = va_arg (ap,COMPLEX);

   for (i = 1; i < n; ++i)
      a = Cadd (a,va_arg (ap,COMPLEX));

   va_end (ap);

   return a;
   }

/*********************************************************************/

COMPLEX Csubx (int n, ...)
   {
   COMPLEX  a;
   va_list  ap;
   int      i;

   if (n < 1)
      {
      a.r = 0.0;
      a.i = 0.0;
      return a;
      }

   va_start (ap,n);
   a = va_arg (ap,COMPLEX);

   for (i = 1; i < n; ++i)
      a = Csub (a,va_arg (ap,COMPLEX));

   va_end (ap);

   return a;
   }

/*********************************************************************/

COMPLEX Cmultx (int n, ...)
   {
   COMPLEX  a;
   va_list  ap;
   int      i;

   if (n < 1)
      {
      a.r = 0.0;
      a.i = 0.0;
      return a;
      }

   va_start (ap,n);
   a = va_arg (ap,COMPLEX);

   for (i = 1; i < n; ++i)
      a = Cmult (a,va_arg (ap,COMPLEX));

   va_end (ap);

   return a;
   }

/*********************************************************************/
/*********************************************************************/
/*                         POLAR FUNCTIONS                           */
/*********************************************************************/
/*********************************************************************/

POLAR Padd (POLAR a, POLAR b)
   {
   POLAR  c;
   double rad_to_deg = acos(-1.0)/180.0;
   double deg_to_rad = 180.0/acos(-1.0);
   double real,imag;
      
   real = a.m*cos(a.a*deg_to_rad) + b.m*cos(b.a*deg_to_rad);
   imag = a.m*sin(a.a*deg_to_rad) + b.m*sin(b.a*deg_to_rad);
   
   c.m = sqrt(real*real + imag*imag);
   c.a = rad_to_deg*atan2(imag,real);
   
   return c;
   }

/*********************************************************************/

POLAR Psub (POLAR a, POLAR b)
   {
   POLAR  c;
   double rad_to_deg = acos(-1.0)/180.0;
   double deg_to_rad = 180.0/acos(-1.0);
   double real;
   double imag;
      
   real = a.m*cos(a.a*deg_to_rad) - b.m*cos(b.a*deg_to_rad);
   imag = a.m*sin(a.a*deg_to_rad) - b.m*sin(b.a*deg_to_rad);
   
   c.m = sqrt(real*real + imag*imag);
   c.a = rad_to_deg*atan2(imag,real);
   
   return c;
   }

/*********************************************************************/

POLAR Pmult (POLAR a, POLAR b)
   {
   POLAR c;
   
   c.m = a.m*b.m;
   c.a = a.a+b.a;
   
   if (c.a > 180.0)
      c.a -= 360.0;
   else if (c.a <= -180.0)
      c.a += 360.0;
   
   return c;
   }

/*********************************************************************/

POLAR Pdiv (POLAR a, POLAR b)
   {
   POLAR c;
   
   c.m = a.m/b.m;
   c.a = a.a-b.a;
   
   if (c.a > 180.0)
      c.a -= 360.0;
   else if (c.a <= -180.0)
      c.a += 360.0;
   
   return c;
   }

/*********************************************************************/

POLAR Pnum (double m, double a)
   {
   POLAR c;

   c.m = m;
   c.a = a;

   return c;
   }

/*********************************************************************/
/*********************************************************************/
/*                       CONVERSION FUNCTIONS                        */
/*********************************************************************/
/*********************************************************************/

COMPLEX P2C (POLAR a)
   {
   COMPLEX b;
   double  deg_to_rad = acos(-1.0)/180.0;
      
   b.r = a.m*cos(a.a*deg_to_rad);
   b.i = a.m*sin(a.a*deg_to_rad);
   
   return b;
   }

/*********************************************************************/

POLAR C2P (COMPLEX a)
   {
   POLAR  b;
   double rad_to_deg = 180.0/acos(-1.0);
      
   b.m = sqrt(a.r*a.r + a.i*a.i);
   
   if ((a.r == 0.0) && (a.i == 0.0))
      b.a = 0.0;
   else
      b.a = rad_to_deg*atan2(a.i,a.r);
   
   return b;
   }

/*********************************************************************/

POLAR *CA2PA (COMPLEX *a, POLAR *b, int n, int m)
   {
   int   i;
   
   for (i = 0; i < n*m; ++i)
      b[i] = C2P (a[i]);
   
   return b;
   }

/*********************************************************************/

COMPLEX *PA2CA (POLAR *a, COMPLEX *b, int n, int m)
   {
   int   i;
   
   for (i = 0; i < n*m; ++i)
      b[i] = P2C (a[i]);
   
   return b;
   }

/*********************************************************************/
/*********************************************************************/
/*                       COMPLEX ARRAY FUNCTIONS                     */
/*********************************************************************/
/*********************************************************************/

COMPLEX *CAadd (COMPLEX *a, COMPLEX *b, COMPLEX *c, int n, int m)
   {
   int       i;
   
   for (i = 0; i < (n*m); ++i)
      c[i] = Cadd (a[i],b[i]);
   
   return c;
   }

/*********************************************************************/

COMPLEX *CAsub (COMPLEX *a, COMPLEX *b, COMPLEX *c, int n, int m)
   {
   int       i;
   
   for (i = 0; i < (n*m); ++i)
      c[i] = Csub (a[i],b[i]);
   
   return c;
   }

/*********************************************************************/

COMPLEX *CAmult (COMPLEX *a, COMPLEX *b, COMPLEX *c, int rowsa, int n, int colsb)
   {
   int      i,j,k;
   COMPLEX  temp;
   COMPLEX  *d;
   
   d = (COMPLEX *) malloc (sizeof (COMPLEX)*rowsa*colsb);
   
   for (i = 0; i < rowsa; ++i)
      {
      for (j = 0; j < colsb; ++j)
         {
         temp = zero;
         for (k = 0; k < n; ++k)
            temp = Cadd (temp,Cmult (a[i*n+k],b[k*colsb+j]));
         
         d[i*colsb+j] = temp;
         }
      }
   
   CAcopy (d,c,rowsa,colsb);
   free ((void *) d);
   
   return c;
   }

/*********************************************************************/

COMPLEX *CAmult2x2 (COMPLEX *a, COMPLEX *b, COMPLEX *c)
   {
   COMPLEX  d[4];
   
   d[0] = Cadd (Cmult (a[0],b[0]),Cmult (a[1],b[2]));
   d[1] = Cadd (Cmult (a[0],b[1]),Cmult (a[1],b[3]));
   d[2] = Cadd (Cmult (a[2],b[0]),Cmult (a[3],b[2]));
   d[3] = Cadd (Cmult (a[2],b[1]),Cmult (a[3],b[3]));
   
   CAcopy (d,c,2,2);
   
   return c;
   }

/*********************************************************************/

COMPLEX CAdet2x2 (COMPLEX *a)
   {
   COMPLEX b;
   
   b = Csub (Cmult (a[0],a[3]),Cmult (a[1],a[2]));
   
   return b;
   }

/*********************************************************************/

COMPLEX CAdet (COMPLEX *a, int n)
   {   
   if( n <= 0 )
      return zero;
   else if( n == 1 )
      return a[0];
   else if( n == 2 )
      return CAdet2x2(a);
   else
      {
      /* for larger cases (3x3, 4x4, etc.) we need to perform the recursive algorithm */
      COMPLEX r = zero;
      COMPLEX *x = (COMPLEX *) malloc(sizeof(COMPLEX)*(n-1)*(n-1));
      int i, j, k, idx;

      for( i=0, idx=0; i<n; ++i )
         {
         /* build the sub-matrix */
         for( j=1; j<n; ++j )
            {
            for( k=0; k<n; ++k )
               {
               if( k != i )
                  x[idx++] = a[j*n+k];
               }
            }

         /* calculate (recursively) the determinant */
         if( (((int)(i/2))*2) == i )  /* i is even */
            r = Cadd( r, Cmult( a[i], CAdet( x, n-1 ) ) );
         else  /* i is odd */
            r = Csub( r, Cmult( a[i], CAdet( x, n-1 ) ) );
         }

      free((void *) x);
      return r;
      }
   }

/*********************************************************************/

COMPLEX *CAinv (COMPLEX *a, COMPLEX *b, int n)
   {
   int      i,j,k;
   int      row;
   int      error = 0;
   double   max;
   double   mag;
   COMPLEX  *c,*d;
   COMPLEX  temp;
   COMPLEX  alpha;
   COMPLEX  beta;
   
   c = (COMPLEX *) malloc (sizeof (COMPLEX)*n*n);
   d = (COMPLEX *) malloc (sizeof (COMPLEX)*n*n);
   
   // load the elimination arrays
   for (i = 0; i < n; ++i)
      {
      for (j = 0; j < n; ++j)
         {
         c[i*n*j] = a[i*n+j];
         if (i == j)
            d[i*n+j] = one;
         else
            d[i*n+j] = zero;
         }
      }
   
   // perform gaussian elimination
   for (i = 0; i < n; ++i)
      {
      /* pivot rows */
      max = 0.0;
      row = i;
      for (j = i; j < n; ++j)
         {
         mag = Cmag (c[j*n+i]);
         if (mag > max)
            row = j;
         }
      if (row != i)
         {
         for (j = 0; j < n; ++j)
            {
            temp       = c[i*n+j];
            c[i*n+j]   = c[row*n+j];
            c[row*n+j] = temp;
            temp       = d[i*n+j];
            d[i*n+j]   = d[row*n+j];
            d[row*n+j] = temp;
            }
         }
      
      /* gaussian elimination */
      alpha = c[i*n+i];
      if (Cmag (alpha) < 1.0e-30) /* matrix is singular */
         {
         error = 1;
         break;
         }
      for (j = 0; j < n; ++j)
         {
         c[i*n+j] = Cdiv (c[i*n+j],alpha);
         d[i*n+j] = Cdiv (d[i*n+j],alpha);
         }
      for (k = 0; k < n; ++k)
         {
         if (k != i)
            {
            beta = c[k*n+i];
            for (j = 0; j < n; ++j)
               {
               c[k*n+j] = Csub (c[k*n+j],Cmult (beta,c[i*n+j]));
               d[k*n+j] = Csub (d[k*n+j],Cmult (beta,d[i*n+j]));
               }
            }
         }
      }
   
   if (error)
      for (i = 0; i < n*n; ++i)
         b[i] = zero;
   else
      CAcopy (d,b,n,n);
   
   free ((void *) c);
   free ((void *) d);
   
   return b;
   }

/*********************************************************************/

COMPLEX *CAinv2x2 (COMPLEX *a, COMPLEX *b)
   {
   COMPLEX  c[4];
   COMPLEX  denom;
   
   denom = Cdiv (one,CAdet2x2 (a));
   
   c[0] = Cmult (a[3],denom);
   c[1] = Cmult (Cneg (a[1]),denom);
   c[2] = Cmult (Cneg (a[2]),denom);
   c[3] = Cmult (a[0],denom);
   
   CAcopy (c,b,2,2);
   
   return b;
   }


/*********************************************************************/

COMPLEX *CAtrans (COMPLEX *a, COMPLEX *b, int n, int m)
   {
   int     i,j;
   COMPLEX *c;
   
   c = (COMPLEX *) malloc (sizeof (COMPLEX)*n*m);
   
   for (i = 0; i < n; ++i)
      {
      for (j = 0; j < m; ++j)
         c[j*n+i] = a[i*n+j];
      }
   
   CAcopy (c,b,n,m);
   
   free ((void *) c);
   
   return b;
   }

/*********************************************************************/

COMPLEX *CAtrans2x2 (COMPLEX *a, COMPLEX *b)
   {
   COMPLEX tmp;

   b[0] = a[0];
   tmp  = a[1];
   b[1] = a[2];
   b[2] = tmp;
   b[3] = a[3];
   
   return b;
   }

/*********************************************************************/

COMPLEX *CAtranssqr (COMPLEX *a, COMPLEX *b, int msize)
   {
   int     i,j;
   COMPLEX tmp;
   
   for (i = 0; i < msize; ++i)
      {
      for (j = i; j < msize; ++j)
         {
         if (i == j)
            b[i*msize+j] = a[i*msize+j];
         else
            {
            tmp = a[j*msize+i];
            b[j*msize+i] = a[i*msize+j];
            b[i*msize+j] = tmp;
            }
         }
      }
   
   return a;
   }

/*********************************************************************/
/*********************************************************************/
/*********************************************************************/
/*                   PARAMETER CONVERSION ROUTINES                   */
/*********************************************************************/
/*********************************************************************/
/*********************************************************************/

COMPLEX *s2t (COMPLEX *s, COMPLEX *t)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,s[2]);
   
   x[0] = Cmult(Csub(Cmult(s[1],s[2]),Cmult(s[0],s[3])),denom);
   x[1] = Cmult(s[0],denom);
   x[2] = Cneg(Cmult(s[3],denom));
   x[3] = denom;
   
   CAcopy (x,t,2,2);
   
   return t;
   }

/*********************************************************************/

COMPLEX *t2s (COMPLEX *t, COMPLEX *s)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,t[3]);
   
   x[0] = Cmult(t[1],denom);
   x[1] = Cmult(Csub(Cmult(t[0],t[3]),Cmult(t[1],t[2])),denom);
   x[2] = denom;
   x[3] = Cneg(Cmult(t[2],denom));
   
   CAcopy (x,s,2,2);
   
   return s;
   }

/*********************************************************************/

COMPLEX *s2h (COMPLEX *s, COMPLEX *h, double rref)
   {
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   denom = Cdiv(one,Cadd(Cmult(Csub(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])));
   
   x[0] = Cmult(Cmult(Csub(Cmult(Cadd(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])),denom),crref);
   x[1] = Cmult(two,Cmult(s[1],denom));
   x[2] = Cmult(neg2,Cmult(s[2],denom));
   x[3] = Cdiv(Cmult(Csub(Cmult(Csub(one,s[0]),Csub(one,s[3])),Cmult(s[1],s[2])),denom),crref);
   
   CAcopy (x,h,2,2);
   
   return h;
   }

/*********************************************************************/

COMPLEX *s2y (COMPLEX *s, COMPLEX *y, double rref)
   {
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   denom = Cdiv(one,Cmult(Csub(Cmult(Cadd(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])),crref));
   
   x[0] = Cmult(Cadd(Cmult(Csub(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])),denom);
   x[1] = Cmult(neg2,Cmult(s[1],denom));
   x[2] = Cmult(neg2,Cmult(s[2],denom));
   x[3] = Cmult(Cadd(Cmult(Cadd(one,s[0]),Csub(one,s[3])),Cmult(s[1],s[2])),denom);
   
   CAcopy (x,y,2,2);
   
   return y;
   }

/*********************************************************************/

COMPLEX *s2z (COMPLEX *s, COMPLEX *z, double rref)
   {
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   denom = Cdiv(crref,Csub(Cmult(Csub(one,s[0]),Csub(one,s[3])),Cmult(s[1],s[2])));
   
   x[0] = Cmult(Cadd(Cmult(Cadd(one,s[0]),Csub(one,s[3])),Cmult(s[1],s[2])),denom);
   x[1] = Cmult(two,Cmult(s[1],denom));
   x[2] = Cmult(two,Cmult(s[2],denom));
   x[3] = Cmult(Cadd(Cmult(Csub(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])),denom);
   
   CAcopy (x,z,2,2); 
   
   return z;
   }

/*********************************************************************/

COMPLEX *s2abcd (COMPLEX *s, COMPLEX *abcd, double rref)
   {
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   denom = Cdiv(one,Cmult(two,s[2]));
   
   x[0] = Cmult(Cadd(Cmult(Cadd(one,s[0]),Csub(one,s[3])),Cmult(s[1],s[2])),denom);
   x[1] = Cmult(Cmult(Csub(Cmult(Cadd(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])),denom),crref);
   x[2] = Cdiv(Cmult(Csub(Cmult(Csub(one,s[0]),Csub(one,s[3])),Cmult(s[1],s[2])),denom),crref);
   x[3] = Cmult(Cadd(Cmult(Csub(one,s[0]),Cadd(one,s[3])),Cmult(s[1],s[2])),denom);
   
   CAcopy (x,abcd,2,2);
   
   return abcd;
   }

/*********************************************************************/

COMPLEX *y2h (COMPLEX *y, COMPLEX *h)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,y[0]);
   
   x[0] = Cadd(zero,denom);
   x[1] = Csub(zero,Cmult(y[1],denom));
   x[2] = Cmult(y[2],denom);
   x[3] = Cmult(Csub(Cmult(y[0],y[3]),Cmult(y[1],y[2])),denom);
   
   CAcopy (x,h,2,2);
   
   return h;
   }

/*********************************************************************/

COMPLEX *y2z (COMPLEX *y, COMPLEX *z)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,Csub(Cmult(y[0],y[3]),Cmult(y[1],y[2])));
   
   x[0] = Cmult(y[3],denom);
   x[1] = Csub(zero,Cmult(y[1],denom));
   x[2] = Csub(zero,Cmult(y[2],denom));
   x[3] = Cmult(y[0],denom);
   
   CAcopy (x,z,2,2);
   
   return z;
   }

/*********************************************************************/

COMPLEX *y2abcd (COMPLEX *y, COMPLEX *abcd)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,y[2]);
   
   x[0] = Csub(zero,Cmult(y[3],denom));
   x[1] = Csub(zero,denom);
   x[2] = Cmult(Csub(Cmult(y[1],y[2]),Cmult(y[0],y[3])),denom);
   x[3] = Csub(zero,Cmult(y[0],denom));
   
   CAcopy (x,abcd,2,2);
   
   return abcd;
   }

/*********************************************************************/

COMPLEX *y2s (COMPLEX *y, COMPLEX *s, double rref)
   {
   COMPLEX y11,y12,y21,y22;
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   y11 = Cmult(y[0],crref);
   y12 = Cmult(y[1],crref);
   y21 = Cmult(y[2],crref);
   y22 = Cmult(y[3],crref);
   
   denom = Cdiv(one,Csub(Cmult(Cadd(one,y11),Cadd(one,y22)),Cmult(y12,y21)));
   
   x[0] = Cmult(Cadd(Cmult(Csub(one,y11),Cadd(one,y22)),Cmult(y12,y21)),denom);
   x[1] = Cmult(neg2,Cmult(y12,denom));
   x[2] = Cmult(neg2,Cmult(y21,denom));
   x[3] = Cmult(Cadd(Cmult(Cadd(one,y11),Csub(one,y22)),Cmult(y12,y21)),denom);
   
   CAcopy (x,s,2,2);
   
   return s;
   }

/*********************************************************************/

COMPLEX *z2h (COMPLEX *z, COMPLEX *h)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,z[3]);
   
   x[0] = Cmult(Csub(Cmult(z[0],z[3]),Cmult(z[1],z[2])),denom);
   x[1] = Cmult(z[1],denom);
   x[2] = Csub(zero,Cmult(z[2],denom));
   x[3] = Cadd(zero,denom);
   
   CAcopy (x,h,2,2);
   
   return h;
   }

/*********************************************************************/

COMPLEX *z2y (COMPLEX *z, COMPLEX *y)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,Csub(Cmult(z[0],z[3]),Cmult(z[1],z[2])));
   
   x[0] = Cmult(z[3],denom);
   x[1] = Csub(zero,Cmult(z[1],denom));
   x[2] = Csub(zero,Cmult(z[2],denom));
   x[3] = Cmult(z[0],denom);
   
   CAcopy (x,y,2,2);
   
   return y;
   }

/*********************************************************************/

COMPLEX *z2abcd (COMPLEX *z, COMPLEX *abcd)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,z[2]);
   
   x[0] = Cmult(z[0],denom);
   x[1] = Cmult(Csub(Cmult(z[0],z[3]),Cmult(z[1],z[2])),denom);
   x[2] = Cadd(zero,denom);
   x[3] = Cmult(z[3],denom);
   
   CAcopy (x,abcd,2,2);
   
   return abcd;
   }

/*********************************************************************/

COMPLEX *z2s (COMPLEX *z, COMPLEX *s, double rref)
   {
   COMPLEX z11,z12,z21,z22;
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   z11 = Cdiv(z[0],crref);
   z12 = Cdiv(z[1],crref);
   z21 = Cdiv(z[2],crref);
   z22 = Cdiv(z[3],crref);
   
   denom = Cdiv(one,Csub(Cmult(Cadd(z11,one),Cadd(z22,one)),Cmult(z12,z21)));
   
   x[0] = Cmult(Csub(Cmult(Csub(z11,one),Cadd(z22,one)),Cmult(z12,z21)),denom);
   x[1] = Cmult(two,Cmult(z12,denom));
   x[2] = Cmult(two,Cmult(z21,denom));
   x[3] = Cmult(Csub(Cmult(Cadd(z11,one),Csub(z22,one)),Cmult(z12,z21)),denom);
   
   CAcopy (x,s,2,2);
   
   return s;
   }

/*********************************************************************/

COMPLEX *abcd2h (COMPLEX *abcd, COMPLEX *h)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,abcd[3]);
   
   x[0] = Cmult(abcd[1],denom);
   x[1] = Cmult(Csub(Cmult(abcd[0],abcd[3]),Cmult(abcd[1],abcd[2])),denom);
   x[2] = Csub(zero,denom);
   x[3] = Cmult(abcd[2],denom);
   
   CAcopy (x,h,2,2);
   
   return h;
   }

/*********************************************************************/

COMPLEX *abcd2y (COMPLEX *abcd, COMPLEX *y)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,abcd[1]);
   
   x[0] = Cmult(abcd[3],denom);
   x[1] = Cmult(Csub(Cmult(abcd[1],abcd[2]),Cmult(abcd[0],abcd[3])),denom);
   x[2] = Csub(zero,denom);
   x[3] = Cmult(abcd[0],denom);
   
   CAcopy (x,y,2,2);
   
   return y;
   }

/*********************************************************************/

COMPLEX *abcd2z (COMPLEX *abcd, COMPLEX *z)
   {
   COMPLEX denom;
   COMPLEX x[4];
   
   denom = Cdiv(one,abcd[2]);
   
   x[0] = Cmult(abcd[0],denom);
   x[1] = Cmult(Csub(Cmult(abcd[0],abcd[3]),Cmult(abcd[1],abcd[2])),denom);
   x[2] = Cadd(zero,denom);
   x[3] = Cmult(abcd[3],denom);
   
   CAcopy (x,z,2,2);
   
   return z;
   }

/*********************************************************************/

COMPLEX *abcd2s (COMPLEX *abcd, COMPLEX *s, double rref)
   {
   COMPLEX a,b,c,d;
   COMPLEX crref;
   COMPLEX denom;
   COMPLEX x[4];
   
   crref.r = rref;
   crref.i = 0.0;
   
   a = Cadd(abcd[0],zero);
   b = Cdiv(abcd[1],crref);
   c = Cmult(abcd[2],crref);
   d = Cadd(abcd[3],zero);
   
   denom = Cdiv(one,Cadd(Cadd(a,b),Cadd(c,d)));
   
   x[0] = Cmult(Csub(Cadd(a,b),Cadd(c,d)),denom);
   x[1] = Cmult(two,Cmult(Csub(Cmult(a,d),Cmult(b,c)),denom));
   x[2] = Cmult(two,denom);
   x[3] = Cmult(Csub(Csub(b,a),Csub(c,d)),denom);
   
   CAcopy (x,s,2,2);
   
   return s;
   }

/*********************************************************************/
/*********************************************************************/

void k_mag (COMPLEX *s, double *k, double *MAG, double *b)
   {
   double s11m2 = Cmag2 (s[0]);
   double s22m2 = Cmag2 (s[3]);
   double s12m  = Cmag (s[1]);
   double s21m  = Cmag (s[2]);
   double delm2 = Cmag2 (Csub (Cmult (s[0],s[3]),Cmult (s[1],s[2])));
   double tmp;
   
   *b = 1.0 + s11m2 - s22m2 - delm2;
   *k = 1.0 - s11m2 - s22m2 + delm2;
   tmp = 2.0*Cmag(Cmult(s[1],s[2]));
   if (tmp < 1.0e-12)
      tmp = 1.0e-12;
   *k /= tmp;
   
   if (s12m < 1.0e-15)
      s12m = 1.0e-15;
   
   *MAG = s21m/s12m;
   
   if (*k > 1.0)
      {
      if (*b < 0.0)
         *MAG *= (*k) + sqrt ((*k)*(*k) - 1.0);
      else
         *MAG *= (*k) - sqrt ((*k)*(*k) - 1.0);
      }
   
   *MAG = 10.0*log10 (*MAG);
   }

/*********************************************************************/

COMPLEX *CSembed (COMPLEX *fxa, COMPLEX *s, COMPLEX *fxb, COMPLEX *se)
   {
   COMPLEX z[4],x[4],fxa1[4],fxb1[4],s1[4];
   
   s2t (s,s1);
   s2t (fxa,fxa1);
   s2t (fxb,fxb1);
              
   CAmult2x2 (fxa1,CAmult2x2 (s1,fxb1,z),x);

   t2s (x,se);
   
   return se;
   }

/*********************************************************************/

COMPLEX *CSdeembed (COMPLEX *fxa, COMPLEX *s, COMPLEX *fxb, COMPLEX *sd)
   {
   COMPLEX z[4],x[4],fxa1[4],fxb1[4],s1[4];

   s2t (s,s1);
   
   CAinv2x2 (s2t (fxa,fxa1),fxa1);
   CAinv2x2 (s2t (fxb,fxb1),fxb1);
   
   CAmult2x2 (fxa1,CAmult2x2 (s1,fxb1,z),x);
   
   t2s (x,sd);
   
   return sd;
   }


