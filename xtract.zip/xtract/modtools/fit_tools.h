#ifndef FIT_TOOLS_DEFINED_
#define FIT_TOOLS_DEFINED_

#include <optimize4.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
   double vgs, vds, igs, ids;
} IV_DATA;

typedef struct _model_params_
{
   char name[20];
   double min, nom, max, tol;
   struct _model_params_ *next;
} MODEL_PARAMS;


typedef struct OptionSet_
{
   const char *name;
   const char *value;
   struct OptionSet_ *prev, *next;
} OptionSet;



void linefit_mxb( double *x, double *y, unsigned n, double *m, double *b, double *r2 );
void linefit_mx0( double *x, double *y, unsigned n, double *m, double *r2 );
int solve_linear_system( double **a, double *b, double *x, int n );
void write_model_param_mdif( FILE *file, char *names[], double *values, unsigned n, unsigned width, unsigned cols );
double bubble_average( double *values, unsigned n );
int get_iv_data ( const char *fname, IV_DATA *d, unsigned max_pts, unsigned *n );
int read_model_parameters_from_file( const char *fname, MODEL_PARAMS **p, unsigned *np );
int write_model_parameters_to_file( MODEL_PARAMS *p, const char *fname );
void free_model_parameters( MODEL_PARAMS *p );

int set_parameter_value( MODEL_PARAMS *p, OPT_PARAMETER x );
int set_all_parameters( MODEL_PARAMS *p, OPT_PARAMETER *x, unsigned n );
int get_parameter_value( const char *name, MODEL_PARAMS *p, OPT_PARAMETER *x );
int get_all_parameters( const char *names[], unsigned n, MODEL_PARAMS *p, OPT_PARAMETER *x );

int read_option_file( const char *fname, OptionSet **opt );
void free_option_set( OptionSet *opt );
int get_option_value( OptionSet *opt, const char * name, char * val, int sz_val );

OptionSet* add_option_before( OptionSet *opt, const char * name, const char * val );
OptionSet* add_option_after( OptionSet *opt, const char * name, const char * val );
OptionSet* option_set_begin( OptionSet* opt );
OptionSet* option_set_end( OptionSet* opt );
OptionSet* option_set_find_next( OptionSet* opt, const char* name );
OptionSet* option_set_find_prev( OptionSet* opt, const char* name );

OptionSet* remove_option( OptionSet *opt, const char * name );
OptionSet* create_option( const char* name, const char* val, OptionSet* prev, OptionSet* next );
OptionSet* delete_option( OptionSet* opt );

const char** get_file_listing( const char* pattern );
void free_file_listing( const char** l );
void strip_extension( char *fname );


#ifdef __cplusplus
}
#endif

#endif  /* FIT_TOOLS_DEFINED_ */

