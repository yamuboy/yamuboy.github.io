/**
    \file
    \author Jay Barrett
    \brief A parser for MCT data file

*/

#include <string>
#include <fstream>
#include <sstream>
#include <complex>
#include <list>

#ifndef MCT_FILE_PARSER_CLASS
#define MCT_FILE_PARSER_CLASS

/// struct to hold DC data
struct DC_Data
{
    double vin, vout, iin, iout;
    DC_Data( double vi=0., double vo=0., double ii=0., double io=0. ) : vin(vi), vout(vo), iin(ii), iout(io) {}
};

/// struct to hold noise figure and gain data
struct NF_Data
{
    double freq, nf, gain;
    NF_Data( double f=0., double n=0., double g=0. ) : freq(f), nf(n), gain(g) {}
};

/// struct to hold 2-port S-param data
struct S2P_Data
{
    double freq;
    std::complex<double> s11, s12, s21, s22;
    S2P_Data( double f=0., std::complex<double> s_11=0., std::complex<double> s_12=0.,
        std::complex<double> s_21=0., std::complex<double> s_22=0. ) : freq(f), s11(s_11),
        s12(s_12), s21(s_21), s22(s_22) {}
};

/// a template class that defines behaviors common to all data blocks
/**
    this template is used to form specialized data block types for each type
    of data that can exist in an MCT data file
*/
template<class Ty> class DataBlock_base
{
public:
    typedef typename std::list<Ty> StorageT;   ///< data block internal storage type
    typedef typename std::list<Ty>::iterator iterator;   ///< iterator
    typedef typename std::list<Ty>::const_iterator const_iterator;   ///< const_iterator

    /// get the name of the data block
    const std::string& getName() const { return name_; }

    /// set the name of the data block
    void setName( const std::string& nm ) { name_ = nm; }

    /// get the size of the data block
    size_t size() const { return data_.size(); }

    /// empty the data block
    void clear() { data_.clear(); }

    /// push data into the block
    void push( const Ty& data ) { data_.push_back(data); }

    /// iterator function
    iterator begin() { return data_.begin(); }
    /// coonst_iterator function
    const_iterator begin() const { return data_.begin(); }
    /// iterator function
    iterator end() { return data_.end(); }
    /// const_iterator function
    const_iterator end() const { return data_.end(); }

    /// create an unnamed data block
    DataBlock_base() : name_("<unnamed>") {}
    /// create a data block with the given name
    /**
        \param nm the name for the data block
    */
    DataBlock_base( const std::string& nm ) : name_(nm) {}

    virtual ~DataBlock_base() {}
protected:
    std::string name_;   ///< data block name
    StorageT data_;   ///< data storage
};

/// storage container for data blocks that have bias information attached
template<class Ty> class BiasedDataBlock : public DataBlock_base<Ty>
{
public:
    /// get the bias information
    const DC_Data& getBias() const { return bias_; }
    /// set the bias information
    void setBias( const DC_Data& d ) { bias_ = d; }

    BiasedDataBlock() {}
    BiasedDataBlock( const std::string& nm ) : DataBlock_base<Ty>(nm) {}

    virtual ~BiasedDataBlock() {}
protected:
    DC_Data bias_;   /// storage of the bias information
};

/// storage type for DC data blocks (like I-V curves, etc)
typedef DataBlock_base<DC_Data> DC_DataBlock;

/// storage type for noise figure data blocks
typedef BiasedDataBlock<NF_Data> NF_DataBlock;

/// storage type for 2-port S-param data blocks
typedef BiasedDataBlock<S2P_Data> S2P_DataBlock;

/*********************************************************************/
/// exception thrown by the MCT_FIle_Parser class
/**
    these are caught internally by MCT_File_Parser::parse
    so there is no need to try/catch for this exception when parsing

    it may be necessary to handle this exception when calling other
    methods of MCT_File_Parser though

    refer to the documentation of the individual methods
*/
class MCT_Parser_Exception : public std::exception
{
protected:
    std::string err_;

public:
    /// create an exception object
    /** \param str the error message string */
    MCT_Parser_Exception( const std::string& str ) throw() : err_(str) {}

    virtual ~MCT_Parser_Exception() throw() {}

    /// returns the error message string
    const char* what() const throw() { return err_.c_str(); }
};

/*********************************************************************/
/// parser class for MCT data files
/** objects for this class are (generally) able to parse
    an MCT data file into the internal structure of the class

    once the data is read in from the MCT data file,
    the data can be retrieved from the internal structure and
    used somehow by the program

    an example might be to use MCT_File_Parser to parse a data
    file and then the create a series of NetworkParamSet objects
    from the 2-port S-param data sets that were parsed from the file

    \warning This code always assumes that S-param data is in MA
            format (MCT's format), so if that has been changed
            in any way then reading the data with this class
            will corrupt the data

    normal use:
    \code
    MCT_File_Parser p( "file.dat" );    // create an object that will parse a file named "file.dat"
    if ! p.parse() ) {                  // parse the file
        // whoops, error occured, do something
        std::cerr << p.getError() << std::endl;
        std::cerr << "Yikes, this might not be an MCT data file." << std::endl;
        exit(1);
    }

    // now do something with the parsed data
    // perhaps iterate over the s2p blocks and print to stdout
    \endcode
*/
class MCT_File_Parser
{
public:
    /// parse the file
    /**  the file to parse must have been already set,
         i.e. specified in the ctor
        \return false on failure
    */
    bool parse();

    /// parse the file
    /**  \param fname the name of the file to parse
         \sa MCT_File_Parser::parse()
         \return false on failure
    */
    bool parse( const std::string& fname ) {
        fname_ = fname;
        return parse();
    }

    /// get the file name of the parsed (or maybe not yet) file
    const std::string& getFileName() const { return fname_; }

    /// get the file header
    /** the header ends when the first data block is encountered */
    const std::string& getHeader() const { return header_; }

    /// retrieve the error string (when parse() returns false)
    const std::string& getError() const { return errstr_; }

    /// get a formatted report string of the content of the parsed file
    std::string getInfo() const;

    /* ----------------------------------------------- */
    // work with DC data blocks
    /* ----------------------------------------------- */

    /// return the number of DC data blocks that were parsed
    size_t dcBlockCount() const { return dcblocks_.size(); }

    /// DC data block iterator function
    std::list<DC_DataBlock>::const_iterator dcBegin() const { return dcblocks_.begin(); }
    /// DC data block iterator function
    std::list<DC_DataBlock>::const_iterator dcEnd() const { return dcblocks_.end(); }

    /// get a list of the names of the DC data blocks
    std::list<std::string> dcBlockNames() const;

    /// check to see if a DC data block of the given name is present
    /**
        \param name the name of the block
        \return true if the block is present
    */
    bool dcHasBlock( const std::string& name ) const {
        for( std::list<DC_DataBlock>::const_iterator i=dcblocks_.begin(); i!=dcblocks_.end(); ++i ) {
            if( i->getName() == name ) return true;
        }
        return false;
    }

    /// retrieve a reference to the DC data block with the given name
    /**
        \param name the name of the block
        \return a const reference to the block
        \exception MCT_Parser_Exception
    */
    const DC_DataBlock& dcGetBlock( const std::string& name ) const {
        for( std::list<DC_DataBlock>::const_iterator i=dcblocks_.begin(); i!=dcblocks_.end(); ++i ) {
            if( i->getName() == name ) return *i;
        }
        throwError( std::string("MCT_File_Parser::dcGetBlock(): ") + name +  ": block not found." );
    }

    /* ----------------------------------------------- */
    // work with S2P data blocks
    /* ----------------------------------------------- */

    /// return the number of S2P data blocks that were parsed
    size_t s2pBlockCount() const { return s2pblocks_.size(); }

    /// S2P data block iterator function
    std::list<S2P_DataBlock>::const_iterator s2pBegin() const { return s2pblocks_.begin(); }
    /// S2P data block iterator function
    std::list<S2P_DataBlock>::const_iterator s2pEnd() const { return s2pblocks_.end(); }

    /// get a list of the names of the S2P data blocks
    std::list<std::string> s2pBlockNames() const;

    /// check to see if a S2P data block of the given name is present
    /**
        \param name the name of the block
        \return true if the block is present
    */
    bool s2pHasBlock( const std::string& name ) const {
        for( std::list<S2P_DataBlock>::const_iterator i=s2pblocks_.begin(); i!=s2pblocks_.end(); ++i ) {
            if( i->getName() == name ) return true;
        }
        return false;
    }

    /// retrieve a reference to the S2P data block with the given name
    /**
        \param name the name of the block
        \return a const reference to the block
        \exception MCT_Parser_Exception
    */
    const S2P_DataBlock& s2pGetBlock( const std::string& name ) const {
        for( std::list<S2P_DataBlock>::const_iterator i=s2pblocks_.begin(); i!=s2pblocks_.end(); ++i ) {
            if( i->getName() == name ) return *i;
        }
        throwError( std::string("MCT_File_Parser::s2pGetBlock(): ") + name +  ": block not found." );
    }

    /* ----------------------------------------------- */
    // work with NF data blocks
    /* ----------------------------------------------- */

    /// return the number of NF data blocks that were parsed
    size_t nfBlockCount() const { return nfblocks_.size(); }

    /// NF data block iterator function
    std::list<NF_DataBlock>::const_iterator nfBegin() const { return nfblocks_.begin(); }
    /// NF data block iterator function
    std::list<NF_DataBlock>::const_iterator nfEnd() const { return nfblocks_.end(); }

    /// get a list of the names of the NF data blocks
    std::list<std::string> nfBlockNames() const;

    /// check to see if a NF data block of the given name is present
    /**
        \param name the name of the block
        \return true if the block is present
    */
    bool nfHasBlock( const std::string& name ) const {
        for( std::list<NF_DataBlock>::const_iterator i=nfblocks_.begin(); i!=nfblocks_.end(); ++i ) {
            if( i->getName() == name ) return true;
        }
        return false;
    }

    /// retrieve a reference to the NF data block with the given name
    /**
        \param name the name of the block
        \return a const reference to the block
        \exception MCT_Parser_Exception
    */
    const NF_DataBlock& nfGetBlock( const std::string& name ) const {
        for( std::list<NF_DataBlock>::const_iterator i=nfblocks_.begin(); i!=nfblocks_.end(); ++i ) {
            if( i->getName() == name ) return *i;
        }
        throwError( std::string("MCT_File_Parser::nfGetBlock(): ") + name +  ": block not found." );
    }

    /* ----------------------------------------------- */
    // ctors/dtor
    /* ----------------------------------------------- */
    /// default ctors
    MCT_File_Parser() {}

    /// ctor which sets the name of the file to parse
    /**
        \param fname is a valid file name string
    */
    MCT_File_Parser( const std::string& fname ) : fname_(fname) {}
    // dtor
    virtual ~MCT_File_Parser() {}
protected:
    std::string fname_;   ///< file name
    std::string header_;  ///< file header string
    std::list<DC_DataBlock> dcblocks_;   ///< DC data block storage
    std::list<S2P_DataBlock> s2pblocks_;  ///< S2P data block storage
    std::list<NF_DataBlock> nfblocks_;   ///< NF data block storage
    int mode_;
    int lineno_;
    size_t line_sp_;
    std::ifstream is_;    ///< internal stream object
    std::string errstr_;  ///< error string storage

    /// initialize variables
    /**  called from parse() */
    void initVars() {
        dcblocks_.clear();
        s2pblocks_.clear();
        nfblocks_.clear();
        header_ = "";
        mode_=0;
        lineno_=0;
        line_sp_=0;
        if( is_.is_open() ) is_.close();
        is_.clear();
        errstr_ = "";
    }

    /// set the error message variable
    void setError( const std::string& str ) { errstr_ = str; }

    /// throw a MCT_Parser_Exception exception
    /**
        \param str the error string
        \exception MCT_Parser_Exception
    */
    void throwError( const std::string& str ) const throw(MCT_Parser_Exception) {
        throw MCT_Parser_Exception( str ); }

    /// read the header and detect the file mode (FET, HBT, generic, etc)
    /**  called from parse() */
    void readHeader();

    /// read a line of data
    /** this function keeps track of its internal state so that lines of data can be "un-read"
        \param line a reference to a string in which the line data will be stored
        \return true on successful read, false on EOF
    */
    bool readLine( std::string& line ) {
        line_sp_ = is_.tellg();
        std::getline(is_,line);
        if( is_.bad() ) throwError( std::string("MCT_File_Parser::readLine(): ") + fileLineStr() + ": stream failure." );
        else if( is_.fail() && !is_.eof() ) throwError( std::string("MCT_File_Parser::readLine(): ") + fileLineStr() + ": stream failure." );
        else if( !is_ ) return false;
        ++lineno_;
        return true;
    }

    /// un-read the last line (reset the stream pointer and line counter)
    /** this can only un-read a single line of data */
    void unreadLine() {
        if( line_sp_ < is_.tellg() ) {
            is_.seekg( line_sp_ );
            if( is_.fail() || is_.bad() )
                throwError( std::string("MCT_File_Parser::unreadLine(): ") + fileLineStr() + ": file seek error." );
            --lineno_;
        }
    }

    /// parse a gereric MCT data file
    /** called from parse() */
    void parseGeneric();

    /// parse an MCT FET data file
    /** called from parse() */
    void parseFET();

    /// parse an MCT HBT data file
    /** called from parse() */
    void parseBipolar();

    /// parse a block of DC data
    /**
        \param name the name to give to the parsed block
    */
    void parseBlockDC( const std::string& name );

    /// parse a block of S2P data
    /**
        \param name the name to give to the parsed block
        \param bias bias information for the block
    */
    void parseBlockS2P( const std::string& name, const DC_Data& bias );

    /// parse a block of NF data
    /**
        \param name the name to give to the parsed block
        \param bias bias information for the block
    */
    void parseBlockNoise( const std::string& name, const DC_Data& bias );

    /// count floating-point numbers on a line
    /** used to determine the type of data block encountered
        \param line the line of data from the file
        \return the number of floats on the line
    */
    int countFloats( const std::string& line ) const;

    /// read floats into an array
    /** used to read data into a data block
        \param line the line of data from the file
        \param vals an array into which the read values are placed
        \param n_vals the number of values to read from the line
        \return true on success
    */
    bool readFloats( const std::string& line, double* vals, int n_vals ) const;

    /// read the touchstone header
    /** this is a noop, since all MCT data files use the same format */
    void readTouchstoneHeader( const std::string& line ) {
        // do nothing
        //  all MCT files use the same data format
    }

    /// read a DC bias line
    /** this uses MCT standard format to read the bias information from a line
        that begins with the string "!BIAS:"
        \param line the line of data from the file containing bias information
        \exception MCT_Parser_Exception
    */
    DC_Data readBiasLine( const std::string& line ) const;

    /// return a string with the file name and line number
    /** used when generating error messages */
    std::string fileLineStr() const {
        std::ostringstream r;
        r << fname_ << '(' << lineno_ << ')';
        return r.str();
    }
};

#endif   // MCT_FILE_PARSER_CLASS
