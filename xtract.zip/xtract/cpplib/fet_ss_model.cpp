#include "fet_ss_model.hpp"
#include "matrix/cmatrix.h"
#include "network_params.hpp"
#include <stdexcept>

inline std::complex<double> compute_rl( const double& r, const double& l, const double& w ) {
    double den = 1. / (r*r + w*w*l*l);
    return std::complex<double>( r*den, -w*l*den );
}

const matrix::CMatrix& FET_SS_Model::compute_z( const double& freq )
{
    // grab component values
    double rg = pv("RG");
    double rd = pv("RD");
    double rs = pv("RS");
    double ri = pv("RI");
    double lg = pv("B1");
    double ld = pv("B2");
    double ls = pv("LS");
    double c11 = pv("C11");
    double c22 = pv("C22");
    double c1 = pv("C1");
    double c2 = pv("C2");
    double cgs = pv("CGS");
    double cgd = pv("CDG");
    double cds = pv("CDS");
    double gm = pv("GM");
    double gds = pv("GDS");
    double tau = pv("TAU1");
    double tau2 = pv("TAU2");
    double ggs = pv("GGS");
    double ggd = pv("GDG");
    double w = freq * 2. * M_PI;
    std::complex<double> gmtau = gm*std::exp( std::complex<double>(0.,-w*tau) );
    matrix::LUPermutation perm;
    matrix::CVector sub(8);
    matrix::CVector sol(8);

    // zero the matrix
    ypmat_ = std::complex<double>(0.);

    // load the Y matrix
    insert_admittance( 2, 3, 1./rg );
    insert_admittance( 6, 7, 1./rd );
    insert_admittance( 0, 2, compute_rl(1.e-6,lg,w) );
    insert_admittance( 7, 1, compute_rl(1.e-6,ld,w) );
    insert_admittance( 2, 5, std::complex<double>(0.,w*c11) );
    insert_admittance( 7, 5, std::complex<double>(0.,w*c22) );
    insert_admittance( 3, 4, std::complex<double>(ggs,w*cgs) );
    insert_admittance( 3, 6, std::complex<double>(ggd,w*cgd) );
    insert_admittance( 5, 6, gds * std::exp(std::complex<double>(0.,-w*tau2)) + std::complex<double>(0.,w*cds) );
    insert_admittance( 4, 5, 1./ri );
    ypmat_(0,0) += std::complex<double>(0.,w*c1);
    ypmat_(1,1) += std::complex<double>(0.,w*c2);
    ypmat_(5,5) += compute_rl(rs,ls,w);
    ypmat_(6,3) += gmtau;
    ypmat_(6,4) -= gmtau;
    ypmat_(5,3) -= gmtau;
    ypmat_(5,4) += gmtau;


    // LU decomposition
    if( matrix::lu_decomp(ypmat_,perm) ) {
        // throw some error
        throw std::logic_error( std::string( "LU decomposition failure - singular matrix." ) );
    }

    // solve the first two rows
    sub = std::complex<double>(0.); sub(0) = 1.;
    if( ! matrix::lu_solve( ypmat_, perm, sub, sol ) ) {
        // throw some error
        throw std::logic_error( std::string( "Should not see this. LU solve error." ) );
    }
    result_(0,0) = sol(0);
    result_(1,0) = sol(1);
    sub(0) = 0.; sub(1) = 1.;
    if( ! matrix::lu_solve( ypmat_, perm, sub, sol ) ) {
        // throw some error
        throw std::logic_error( std::string( "Should not see this. LU solve error." ) );
    }
    result_(0,1) = sol(0);
    result_(1,1) = sol(1);

    return result_;
}

const matrix::CMatrix& FET_SS_Model::compute_y( const double& freq )
{
    this->compute_z( freq );
    result_ = ZtoY_( result_ );
    return result_;
}

const matrix::CMatrix& FET_SS_Model::compute_s( const double& freq )
{
    matrix::CVector zref(2);
    zref = std::complex<double>(50.);
    this->compute_z( freq );
    result_ = ZtoS_( result_, zref );
    return result_;
}



