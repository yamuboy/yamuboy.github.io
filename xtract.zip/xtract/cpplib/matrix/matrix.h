#ifndef MATRIX_CLASS_DEFINED
#define MATRIX_CLASS_DEFINED 1

#include <matrix/data.h>
#include <matrix/range.h>
#include <matrix/vector.h>

BEGIN_MATRIX_NAMESPACE()


template<class Ty>
class Matrix : public MatrixHeap<Ty>
{
protected:
   size_t offset_;
   size_t cstride_;
   size_t rstride_;
   size_t cols_;
   size_t rows_;

   void error_( const char* msg ) const {
      throw MatrixError( msg );
   }

   // create a Matrix of unknown size from a MatrixHeap
   //  this can be part of the slicing process
   Matrix<Ty>( const MatrixHeap<Ty>& rhs ) : MatrixHeap<Ty>(rhs), offset_(0), cstride_(1), rstride_(1), cols_(0), rows_(0) { }

public:
   size_t rows() const {
      return rows_;
   }

   size_t cols() const {
      return cols_;
   }

   // resize the vector, no guarantee that any data will be preserved
   void resize( size_t rows, size_t cols ) {
      // determine if the vector still fits in the memory footprint
      if( rows == rows_ && cols == cols_ ) return;
      else if( rows <= rows_ && cols <= cols_ ) {
         rows_ = rows;
         cols_ = cols;
      }
      else {
         this->realloc( rows*cols );
         offset_ = 0;
         cstride_ = 1;
         rstride_ = cols;
         cols_ = cols;
         rows_ = rows;
      }
   }

   // explicit copy, resizes as necessary
   Matrix<Ty> copy() const {
       Matrix<Ty> ret( this->rows_, this->cols_ );
       for( size_t i=0; i<this->rows_; ++i )
            for( size_t j=0; j<this->cols_; ++j )
                ret.fast(i,j) = this->fast(i,j);
        return ret;
   }

   /***** indexing operators *****/

   // fast indexing operator
   Ty& fast( size_t i, size_t j ) {
      return MatrixHeap<Ty>::idx_(offset_+i*rstride_+j*cstride_);
   }
   Ty& operator()( size_t i, size_t j ) {
      return MatrixHeap<Ty>::idx_(offset_+i*rstride_+j*cstride_);
   }

   // const fast indexing operator
   const Ty& fast( size_t i, size_t j ) const {
      return MatrixHeap<Ty>::idx_(offset_+i*rstride_+j*cstride_);
   }
   const Ty& operator()( size_t i, size_t j ) const {
      return MatrixHeap<Ty>::idx_(offset_+i*rstride_+j*cstride_);
   }

   // safe indexing operator (size/argument checking)
   Ty& at( size_t i, size_t j ) {
      if( i >= rows_ ) error_( "Matrix indexing error: exceeded maximum row." );
      else if( j >= cols_ ) error_( "Matrix indexing error: exceeded maximum column." );
      return MatrixHeap<Ty>::idxat_(offset_+i*rstride_+j*cstride_);
   }

   // const safe indexing operator (size/argument checking)
   const Ty& at( size_t i, size_t j ) const {
      if( i >= rows_ ) error_( "Matrix indexing error: exceeded maximum row." );
      else if( j >= cols_ ) error_( "Matrix indexing error: exceeded maximum column." );
      return MatrixHeap<Ty>::idxat_(offset_+i*rstride_+j*cstride_);
   }

   // sub-matrix operator
   Matrix<Ty> operator()( Range rr, Range rc ) {
      if( !rows_ || !cols_ ) error_( "Sub-matrix error: matrix is empty." );
      else if( rr.start_ >= rows_ ) error_( "Sub-matrix error: invalid starting row index." );
      else if( rc.start_ >= cols_ ) error_( "Sub-matrix error: invalid starting column index." );
      if( rr.stop_ >=  rows_ ) rr.stop_ = rows_ - 1;
      if( rc.stop_ >=  cols_ ) rc.stop_ = cols_ - 1;
      Matrix<Ty> a(*this);
      a.offset_ = offset_ + rr.start_ * rstride_ + rc.start_ * cstride_;
      a.rstride_ = rstride_ * rr.stride_;
      a.cstride_ = cstride_ * rc.stride_;
      a.rows_ = (rr.stop_ - rr.start_) / rr.stride_ + 1;
      a.cols_ = (rc.stop_ - rc.start_) / rc.stride_ + 1;
      return a;
   }

   // const sub-matrix operator
   const Matrix<Ty> operator()( Range rr, Range rc ) const {
      if( !rows_ || !cols_ ) error_( "Sub-matrix error: matrix is empty." );
      else if( rr.start_ >= rows_ ) error_( "Sub-matrix error: invalid starting row index." );
      else if( rc.start_ >= cols_ ) error_( "Sub-matrix error: invalid starting column index." );
      if( rr.stop_ >=  rows_ ) rr.stop_ = rows_ - 1;
      if( rc.stop_ >=  cols_ ) rc.stop_ = cols_ - 1;
      Matrix<Ty> a(*this);
      a.offset_ = offset_ + rr.start_ * rstride_ + rc.start_ * cstride_;
      a.rstride_ = rstride_ * rr.stride_;
      a.cstride_ = cstride_ * rc.stride_;
      a.rows_ = (rr.stop_ - rr.start_) / rr.stride_ + 1;
      a.cols_ = (rc.stop_ - rc.start_) / rc.stride_ + 1;
      return a;
   }

   // column vector slice operator
   Vector<Ty> operator()( Range rr, size_t c ) {
      if( !rows_ || !cols_ ) error_( "Slicing error: matrix is empty." );
      else if( rr.start_ >= rows_ ) error_( "Slicing error: invalid column slice starting row index." );
      else if( c >= cols_ ) error_( "Slicing error: column slice index is invalid." );
      if( rr.stop_ >=  rows_ ) rr.stop_ = rows_ - 1;
      Vector<Ty> a(*this);
      a.offset_ = offset_ + rr.start_ * rstride_ + c * cstride_;
      a.stride_ = rr.stride_ * rstride_;
      a.size_ = (rr.stop_ - rr.start_) / rr.stride_ + 1;
      return a;
   }

   // const column vector slice operator
   const Vector<Ty> operator()( Range rr, size_t c ) const {
      if( !rows_ || !cols_ ) error_( "Slicing error: matrix is empty." );
      else if( rr.start_ >= rows_ ) error_( "Slicing error: invalid column slice starting row index." );
      else if( c >= cols_ ) error_( "Slicing error: column slice index is invalid." );
      if( rr.stop_ >=  rows_ ) rr.stop_ = rows_ - 1;
      Vector<Ty> a(*this);
      a.offset_ = offset_ + rr.start_ * rstride_ + c * cstride_;
      a.stride_ = rr.stride_ * rstride_;
      a.size_ = (rr.stop_ - rr.start_) / rr.stride_ + 1;
      return a;
   }

   // row vector slice operator
   Vector<Ty> operator()( size_t r, Range rc ) {
      if( !rows_ || !cols_ ) error_( "Slicing error: matrix is empty." );
      else if( rc.start_ >= cols_ ) error_( "Slicing error: invalid row slice starting column index." );
      else if( r >= rows_ ) error_( "Slicing error: row slice index is invalid." );
      if( rc.stop_ >= cols_ ) rc.stop_ = cols_ - 1;
      Vector<Ty> a(*this);
      a.offset_ = offset_ + rc.start_ * cstride_ + r * rstride_;
      a.stride_ = rc.stride_ * cstride_;
      a.size_ = (rc.stop_ - rc.start_) / rc.stride_ + 1;
      return a;
   }

   // const row vector slice operator
   const Vector<Ty> operator()( size_t r, Range rc ) const {
      if( !rows_ || !cols_ ) error_( "Slicing error: matrix is empty." );
      else if( rc.start_ >= cols_ ) error_( "Slicing error: invalid row slice starting column index." );
      else if( r >= rows_ ) error_( "Slicing error: row slice index is invalid." );
      if( rc.stop_ >= cols_ ) rc.stop_ = cols_ - 1;
      Vector<Ty> a(*this);
      a.offset_ = offset_ + rc.start_ * cstride_ + r * rstride_;
      a.stride_ = rc.stride_ * cstride_;
      a.size_ = (rc.stop_ - rc.start_) / rc.stride_ + 1;
      return a;
   }

   // return a reference to oneself
   //  why was this needed?
   Matrix<Ty>& ref() {
      return (*this);
   }
   const Matrix<Ty>& ref() const {
      return (*this);
   }

   /***** assignment operators *****/

   // copy a scalar value into every location in the matrix
   Matrix<Ty>& operator=( const Ty& rhs ) {
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) = rhs;
      return *this;
   }

   /***** boolean operators *****/

   // equality operator
   bool operator==( const Matrix<Ty>& rhs ) const {
      if( cols_ == rhs.cols_ && rows_ == rhs.rows_ )
      {
         if( MatrixHeap<Ty>::operator==(rhs) && offset_ == rhs.offset_ && rstride_ == rhs.rstride_ && cstride_ == rhs.cstride_ )
            return true;
         else {
            for( size_t i=0; i<rows_; ++i )
               for( size_t j=0; j<cols_; ++j )
                  if(fast(i,j) != rhs.fast(i,j)) return false;
            return true;
         }
      }
      return false;
   }

   // inequality operator
   bool operator!=( const Matrix<Ty>& rhs ) const {
      return !operator==(rhs);
   }

   // not operator, checks for all matrix entries to be zero/false
   bool operator!() const {
      for( size_t i=0; i<rows(); ++i )
         for( size_t j=0; j<cols(); ++j )
            if(fast(i,j)) return false;
      return true;
   }

   /***** math operators *****/

   Matrix<Ty>& operator+=( const Ty& rhs ) {
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) += rhs;
      return *this;
   }

   Matrix<Ty>& operator+=( const Matrix<Ty>& rhs ) {
      if( rhs.rows_ != rows_ || rhs.cols_ != cols_ ) error_( "Matrix size mismatch in operator+=." );
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) += rhs.fast(i,j);
      return *this;
   }

   Matrix<Ty>& operator-=( const Ty& rhs ) {
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) -= rhs;
      return *this;
   }

   Matrix<Ty>& operator-=( const Matrix<Ty>& rhs ) {
      if( rhs.rows_ != rows_ || rhs.cols_ != cols_ ) error_( "Matrix size mismatch in operator-=." );
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) -= rhs.fast(i,j);
      return *this;
   }

   Matrix<Ty>& operator*=( const Ty& rhs ) {
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) *= rhs;
      return *this;
   }

   Matrix<Ty>& operator*=( const Matrix<Ty>& rhs ) {
      if( rhs.rows_ != rows_ || rhs.cols_ != cols_ ) error_( "Matrix size mismatch in operator*=." );
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) *= rhs.fast(i,j);
      return *this;
   }

   Matrix<Ty>& operator/=( const Ty& rhs ) {
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) /= rhs;
      return *this;
   }

   Matrix<Ty>& operator/=( const Matrix<Ty>& rhs ) {
      if( rhs.rows_ != rows_ || rhs.cols_ != cols_ ) error_( "Matrix size mismatch in operator/=." );
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) /= rhs.fast(i,j);
      return *this;
   }

   /***** Constructors *****/

   // an empty matrix
   //  if any operation other than assignment is attempted on it
   //  it may die with either an exception or a signal
   Matrix<Ty>() : offset_(0), cstride_(1), rstride_(1), cols_(0), rows_(0) { }

   // an uninitialized matrix of mxn elements
   Matrix<Ty>( size_t m, size_t n ) : MatrixHeap<Ty>(m*n), offset_(0), cstride_(1), rstride_(n), cols_(n), rows_(m) { }

   // a matrix of m elements all initialized to the value of init
   Matrix<Ty>( size_t m, size_t n, const Ty& init ) : MatrixHeap<Ty>(m*n,init), offset_(0), cstride_(1), rstride_(n), cols_(n), rows_(m) { }

   // a matrix of m elements all initialized to the values stored in the array init
   //  the array has a size of init_size
   Matrix<Ty>( size_t m, size_t n, const Ty* init, size_t init_size ) : MatrixHeap<Ty>(m*n,init,init_size), offset_(0), cstride_(1), rstride_(n), cols_(n), rows_(m) { }

   // copy constructor creates a reference to the existing heap
   Matrix<Ty>( const Matrix<Ty>& rhs ) : MatrixHeap<Ty>(rhs), offset_(rhs.offset_), cstride_(rhs.cstride_), rstride_(rhs.rstride_), cols_(rhs.cols_), rows_(rhs.rows_) { }

   // create an n x 1 Matrix from a Vector of size n
   Matrix<Ty>( const Vector<Ty>& rhs ) : MatrixHeap<Ty>(rhs), offset_(rhs.offset_), cstride_(1), rstride_(rhs.stride_), cols_(1), rows_(rhs.size_) { }

   // destructor
   virtual ~Matrix<Ty>() { }

};

END_MATRIX_NAMESPACE()


#endif  /* MATRIX_CLASS_DEFINED */

/* include additonal matrix math functions defined outside the class scope */
#include <matrix/m_math.h>
