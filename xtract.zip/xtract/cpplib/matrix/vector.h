#ifndef VECTOR_CLASS_DEFINED
#define VECTOR_CLASS_DEFINED  1

#include <matrix/data.h>
#include <matrix/range.h>

BEGIN_MATRIX_NAMESPACE()

// forward declaration
template<class Ty> class Matrix;

template<class Ty>
class Vector : public MatrixHeap<Ty>
{
   friend class Matrix<Ty>;

protected:
   size_t offset_;
   size_t stride_;
   size_t size_;

   void error_( const char* msg ) const {
      throw MatrixError( msg );
   }

   // create a Vector from a MatrixHeap
   //   part of the slicing process
   Vector<Ty>( const MatrixHeap<Ty>& rhs ) : MatrixHeap<Ty>(rhs), offset_(0), stride_(1), size_(0) { }

public:
   size_t size() const {
      return size_;
   }

   // resize the vector, no guarantee that any data will be preserved
   void resize( size_t newsize ) {
      // determine if the vector still fits in the memory footprint
      if( newsize == size_ ) return;
      else if( newsize < size_ ) {
         // reduce size_ to match newsize
         size_ = newsize;
      }
      else {
         this->realloc( newsize );
         size_ = newsize;
         stride_ = 1;
         offset_ = 0;
      }
   }

   // create an explicit copy of this object
   Vector<Ty> copy() const {
       Vector<Ty> ret( this->size_ );
       for( size_t i=0; i<this->size_; ++i )
            ret.fast(i) = this->fast(i);
      return ret;
   }

   /***** indexing operators *****/

   // fast indexing operator, no checking
   Ty& fast( size_t i ) {
      return MatrixHeap<Ty>::idx_(offset_+i*stride_);
   }
   Ty& operator()( size_t i ) {
      return MatrixHeap<Ty>::idx_(offset_+i*stride_);
   }

   // const fast indexing operator, no checking
   const Ty& fast( size_t i ) const {
      return MatrixHeap<Ty>::idx_(offset_+i*stride_);
   }
   const Ty& operator()( size_t i ) const {
      return MatrixHeap<Ty>::idx_(offset_+i*stride_);
   }

   // safe indexing operator (size/argument checking)
   Ty& at( size_t i ) {
      if( i >= size_ ) error_( "Vector indexing error: exceeded maximum size." );
      return MatrixHeap<Ty>::idxat_(offset_+i*stride_);
   }

   // const safe indexing operator (size/argument checking)
   const Ty& at( size_t i ) const {
      if( i >= size_ ) error_( "Vector indexing error: exceeded maximum size." );
      return MatrixHeap<Ty>::idxat_(offset_+i*stride_);
   }

   // sub-vector operator
   Vector<Ty> operator()( Range r ) {
      if( !size_ ) error_( "Sub-vector error: vector is empty." );
      else if( r.start_ >= size_ ) error_( "Sub-vector error: invalid slice starting index." );
      if( r.stop_ >=  size_ ) r.stop_ = size_ - 1;
      Vector<Ty> a(*this);
      a.offset_ = offset_ + r.start_ * stride_;
      a.stride = stride_ * r.stride_;
      a.size_ = (r.stop_ - r.start_) / r.stride_ + 1;
      return a;
   }

   // const sub-vector operator
   const Vector<Ty> operator()( Range r ) const {
      if( !size_ ) error_( "Sub-vector error: vector is empty." );
      else if( r.start_ >= size_ ) error_( "Sub-vector error: invalid slice starting index." );
      if( r.stop_ >=  size_ ) r.stop_ = size_ - 1;
      Vector<Ty> a(*this);
      a.offset_ = offset_ + r.start_ * stride_;
      a.stride = stride_ * r.stride_;
      a.size_ = (r.stop_ - r.start_) / r.stride_ + 1;
      return a;
   }

   /***** assignment operators *****/

   // copy a scalar value into every location in the vector
   Vector<Ty>& operator=( const Ty& rhs ) {
      for( size_t i=0; i<size(); ++i )
         fast(i) = rhs;
      return *this;
   }

   // return a reference to oneself
   //   why did I need to do this???
   Vector<Ty>& ref() {
      return (*this);
   }
   const Vector<Ty>& ref() const {
      return (*this);
   }

   /***** boolean operators *****/

   // equality operator
   bool operator==( const Vector<Ty>& rhs ) const {
      if( size_ == rhs.size_ )
      {
         if( MatrixHeap<Ty>::operator==(rhs) && offset_ == rhs.offset_ && stride_ == rhs.stride_ )
            return true;  // same data, must be equal
         else {
            for( size_t i=0; i<size_; ++i )
               if(fast(i) != rhs.fast(i)) return false;
            return true;
         }
      }
      return false;
   }

   // inequality operator
   bool operator!=( const Vector<Ty>& rhs ) const {
      return !operator==(rhs);
   }

   // not operator, checks for all matrix entries to be zero/false
   bool operator!() const {
      for( size_t i=0; i<size_; ++i )
         if(fast(i)) return false;
      return true;
   }

   /***** math operators *****/

   Vector<Ty>& operator+=( const Ty& rhs ) {
      for( size_t i=0; i<size_; ++i )
         fast(i) += rhs;
      return *this;
   }

   Vector<Ty>& operator+=( const Vector<Ty>& rhs ) {
      if( rhs.size_ != size_ ) error_( "Vector size mismatch in operator+=." );
      for( size_t i=0; i<size_; ++i )
         fast(i) += rhs.fast(i);
      return *this;
   }

   Vector<Ty>& operator-=( const Ty& rhs ) {
      for( size_t i=0; i<size_; ++i )
         fast(i) -= rhs;
      return *this;
   }

   Vector<Ty>& operator-=( const Vector<Ty>& rhs ) {
      if( rhs.size_ != size_ ) error_( "Vector size mismatch in operator-=." );
      for( size_t i=0; i<size_; ++i )
         fast(i) -= rhs.fast(i);
      return *this;
   }

   Vector<Ty>& operator*=( const Ty& rhs ) {
      for( size_t i=0; i<size_; ++i )
         fast(i) *= rhs;
      return *this;
   }

   Vector<Ty>& operator*=( const Vector<Ty>& rhs ) {
      if( rhs.size_ != size_ ) error_( "Vector size mismatch in operator*=." );
      for( size_t i=0; i<size_; ++i )
         fast(i) *= rhs.fast(i);
      return *this;
   }

   Vector<Ty>& operator/=( const Ty& rhs ) {
      for( size_t i=0; i<size_; ++i )
         fast(i) /= rhs;
      return *this;
   }

   Vector<Ty>& operator/=( const Vector<Ty>& rhs ) {
      if( rhs.size_ != size_ ) error_( "Vector size mismatch in operator/=." );
      for( size_t i=0; i<size_; ++i )
         fast(i) /= rhs.fast(i);
      return *this;
   }

   /***** Constructors *****/

   // an empty vector
   //  if any indexing or assignement operation is attempted on it
   //  it will die with either an exception or a signal or cause
   //  strange failures
   // an uninitialized vector of m elements
   Vector<Ty>( size_t m=0 ) : MatrixHeap<Ty>(m), offset_(0), stride_(1), size_(m) { }

   // a vector of m elements all initialized to the value of init
   Vector<Ty>( size_t m, const Ty& init ) : MatrixHeap<Ty>(m,init), offset_(0), stride_(1), size_(m) { }

   // a vector of m elements all initialized to the values stored in the array init
   //  the array has a size of init_size
   Vector<Ty>( size_t m, const Ty* init, size_t init_size ) : MatrixHeap<Ty>(m,init,init_size), offset_(0), stride_(1), size_(m) { }

   // copy constructor
   Vector<Ty>( const Vector<Ty>& rhs ) : MatrixHeap<Ty>(rhs), offset_(rhs.offset_), stride_(rhs.stride_), size_(rhs.size_) { }

   // destructor
   virtual ~Vector<Ty>() { }

};

END_MATRIX_NAMESPACE()

#endif  /* VECTOR_CLASS_DEFINED */

/* include additonal vector math functions defined outside the class scope */
#include <matrix/v_math.h>
