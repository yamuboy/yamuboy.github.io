#ifndef MATRIX_IO_INCLUDED
#define MATRIX_IO_INCLUDED

#include <ostream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <matrix/matrix.h>

BEGIN_MATRIX_NAMESPACE()

/**************************************************************************
 * Writing output to an ostream
 *
 **************************************************************************/

template<class E, class Tr, class Ty> std::basic_ostream<E, Tr>& operator<<( std::basic_ostream<E, Tr>& os, const Vector<Ty>& m ) {
   std::basic_ostringstream<E, Tr, std::allocator<E> > ss;
   ss.flags(os.flags());
   ss.imbue(os.getloc());
   ss.precision(os.precision());
   ss << "Vector: " << m.size() << std::endl;
   ss << '[' << std::endl;
   for( size_t i=0; i<m.size(); ++i ) {
      ss << "   " << m(i) << std::endl;
   }
   ss << ']' << std::endl;
   return ( os << ss.str().c_str() );
}

template<class E, class Tr, class Ty> std::basic_ostream<E, Tr>& operator<<( std::basic_ostream<E, Tr>& os, const Matrix<Ty>& m ) {
   std::basic_ostringstream<E, Tr, std::allocator<E> > ss;
   std::vector<std::string> elem;
   std::vector<size_t> widths;
   widths.reserve( m.cols() );
   ss.flags(os.flags());
   ss.imbue(os.getloc());
   ss.precision(os.precision());
   // initialize the widths
   for( size_t j=0; j<m.cols(); ++j )
      widths.push_back( 0 );
   // write each of the elements to a string
   //  and calculate the max width of each column
   for( size_t i=0; i<m.rows(); ++i ) {
      for( size_t j=0; j<m.cols(); ++j ) {
         ss.str("");
         ss << m(i,j);
         if( ss.str().length() > widths[j] )
            widths[j] = ss.str().length();
      }
   }
   ss.str("");
   ss << std::left;
   ss << "Matrix: " << m.rows() << " X " << m.cols() << std::endl;
   ss << '[' << std::endl;
   for( size_t i=0; i<m.rows(); ++i ) {
      ss << "  [  ";
      for( size_t j=0; j<m.cols(); ++j ) {
          ss << std::setw(widths[j]+2) << m(i,j);
      }
      ss << std::setw(0) << "]" << std::endl;
   }
   ss << ']' << std::endl;
   return ( os << ss.str().c_str() );
}

END_MATRIX_NAMESPACE()

#endif  // MATRIX_IO_INCLUDED
