#ifndef MATRIX_EXCEPTION_CLASS
#define MATRIX_EXCEPTION_CLASS 1

#include <exception>
#include <string.h>

// define some macros
#define MATRIX_NAMESPACE_NAME       matrix
#define BEGIN_MATRIX_NAMESPACE()    namespace MATRIX_NAMESPACE_NAME {
#define END_MATRIX_NAMESPACE()      }
#define USE_MATRIX_NAMESPACE()      using namespace MATRIX_NAMESPACE_NAME ;

BEGIN_MATRIX_NAMESPACE()

// matrix exception class
class MatrixError : public std::exception
{
protected:
   char* msg_;

public:
   MatrixError( const char* msg ) throw() {
      msg_ = new char [strlen(msg)+1];
      strcpy( msg_, msg );
   }

   virtual const char* what() const throw() {
      return msg_;
   }

   virtual ~MatrixError() throw() {
      delete [] msg_;
   }
};

END_MATRIX_NAMESPACE()

#endif  /* MATRIX_EXCEPTION_CLASS */
