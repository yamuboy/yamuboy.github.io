#ifndef MATRIX_DATA_STORAGE_CLASS
#define MATRIX_DATA_STORAGE_CLASS 1

#include <matrix/heap.h>
#include "ref_count.hpp"

BEGIN_MATRIX_NAMESPACE()

template <class Ty>
class MatrixHeap
{
private:
   RC< RawHeap<Ty> > heap_;

protected:
   // fast indexing operator
   Ty& idx_( size_t i ) {
      return (*this->heap_)[i];
   }

   // const fast indexing operator
   const Ty& idx_( size_t i ) const {
      return (*this->heap_)[i];
   }

   // safe indexing operator
   Ty& idxat_( size_t i ) {
      if( !this->heap_->indexOK(i) ) throw MatrixError( "Heap indexing error." );
      return (*this->heap_)[i];
   }

   // const safe indexing operator
   const Ty& idxat_( size_t i ) const {
      if( ! this->heap_->indexOK(i) ) throw MatrixError( "Heap indexing error." );
      return (*this->heap_)[i];
   }

   // reallocate heap space
   void realloc( size_t sz ) {
      this->heap_ = new RawHeap<Ty>(sz);
   }

   // boolean equality operator
   bool operator==( const MatrixHeap<Ty>& rhs ) const {
      return heap_->operator==( *rhs.heap_ );
   }

   // boolean inequality operator
   bool operator!=( const MatrixHeap<Ty>& rhs ) const {
      return heap_->operator!=( *rhs.heap_ );
   }

   // allow the heap to be set manually
   void setheap( Ty* heap, size_t sz ) {
      heap_ = new RawHeap<Ty>( heap, sz );
   }

   // set a reference to an existing heap, does the same thing as the
   //  copy operator
   void reference( const MatrixHeap<Ty>& rhs ) {
      heap_ = rhs.heap_;
   }
   MatrixHeap<Ty>& operator=( const MatrixHeap<Ty>& rhs ) {
       heap_ = rhs.heap_;
       return *this;
   }

   /**** Constructors ****/

   MatrixHeap<Ty>() { }
   MatrixHeap<Ty>( size_t sz ) : heap_(new RawHeap<Ty>(sz)) { }
   MatrixHeap<Ty>( size_t sz, const Ty& init ) : heap_(new RawHeap<Ty>(sz,init)) { }
   MatrixHeap<Ty>( size_t sz, const Ty* init, size_t init_size ) : heap_(new RawHeap<Ty>(sz,init,init_size)) { }
   // copy construction
   MatrixHeap<Ty>( const MatrixHeap<Ty>& rhs ) : heap_(rhs.heap_) { }
   virtual ~MatrixHeap<Ty>() { }

public:
   typedef Ty StorageT;

   // get the size of the heap
   size_t heapsize() const { return heap_->size(); }
};

END_MATRIX_NAMESPACE()

#endif  /* MATRIX_DATA_STORAGE_CLASS */
