#ifndef RANGE_CLASS_DEFINED
#define RANGE_CLASS_DEFINED  1

BEGIN_MATRIX_NAMESPACE()

struct Range
{
   size_t start_, stop_, stride_;

   // this static member will always equal a Range
   //  of the maximum possible size with a stride of 1
   static Range all() {
      return Range();
   }

   // constructor
   // start, stop, and stride (step) in that order
   Range( size_t sta=0, size_t stp=0xffffffff, size_t str=1 ) : start_(sta), stop_(stp), stride_(str) {
      // fix potential problems with the Range
      if( stride_ < 1 ) stride_ = 1;
      if( stop_ < start_ ) {
         size_t t = start_;
         start_ = stop_;
         stop_  = t;
      }
   }
};

END_MATRIX_NAMESPACE()

#endif  /* RANGE_CLASS_DEFINED */
