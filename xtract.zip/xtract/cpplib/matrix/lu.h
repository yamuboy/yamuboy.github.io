#ifndef MATRIX_CLASS_DEFINED
#error matrix.h must be included before lu.h
#endif

#ifndef LU_MATRIX_H
#define LU_MATRIX_H

#include <matrix/cmatrix.h>
#include <cmath>

#ifndef isnormal
#define isnormal  std::isnormal
#endif

BEGIN_MATRIX_NAMESPACE()

// permutation class for row interchanges in partial pivot LU decomposition
class LUPermutation
{
private:
   int *p;
   int sz_p;

public:
   void init( const int s ) {
      if( s > 0 ) {
         if( !p ) {
            p = new int [s];
            sz_p = s;
         }
         else if( sz_p < s ) {
            delete [] p;
            p = 0;
            sz_p = 0;
            p = new int [s];
            sz_p = s;
         }
         for( int i=0; i<s; ++i )
            p[i]=i;
      }
   }

   int operator[]( const int i ) const {
      return p[i];
   }

   void swap( const int a, const int b ) {
      int t = p[a];
      p[a] = p[b];
      p[b] = t;
   }

   LUPermutation() : p(0), sz_p(0) { }
   LUPermutation( int sz ) : p(0), sz_p(0) { this->init(sz); }
   ~LUPermutation() {
      delete [] p;
   }
};

// initial LUTraits class
//  will work for float, double, and long double types
template <typename Ty>
struct LUTraits
{
   typedef Ty valType;
   typedef Ty magType;

   static magType abs( const valType& x ) {
      return std::fabs(x);
   }

   static bool check_normal( const magType& x ) {
      return (bool) isnormal(x);
   }
};


// specialization for std::complex<float>
template<>
struct LUTraits< std::complex<float> >
{
   typedef std::complex<float> valType;
   typedef float magType;

   static magType abs( const valType& x ) {
      return std::abs(x);
   }

   static bool check_normal( const magType& x ) {
      return (bool) isnormal(x);
   }
};

// specialization for std::complex<double>
template<>
struct LUTraits< std::complex<double> >
{
   typedef std::complex<double> valType;
   typedef double magType;

   static magType abs( const valType& x ) {
      return std::abs(x);
   }

   static bool check_normal( const magType& x ) {
      return (bool) isnormal(x);
   }
};

// specialization for std::complex<long double>
template<>
struct LUTraits< std::complex<long double> >
{
   typedef std::complex<long double> valType;
   typedef long double magType;

   static magType abs( const valType& x ) {
      return std::abs(x);
   }

   static bool check_normal( const magType& x ) {
      return (bool) isnormal(x);
   }
};

/*----------------------------------------------------------------------------------------*/
// LU decomposition with partial pivoting (pivoted rows)
//  performed in place
//  the int* argument stores symbolic row interchanges and
//  is used by the lu_solve routine to correctly fill the solution matrix
//  the size of this array must be at least as big as the rows/cols of A

template <class Ty>
int lu_decomp( Matrix<Ty>& A, LUPermutation& p )
{
   size_t i, j, k;
   typename LUTraits<Ty>::magType m, t;
   Ty tc;
   const Ty one(1.);

   // check for a valid input matrix
   if( A.rows() < 2 || (A.rows() != A.cols()) )
      return -1;

   // initialize the permutation array
   p.init(A.rows());

   // start LU decomposition
   for( i=0; i<A.rows()-1; ++i )
   {
      // find an appropriate pivot point
      k=i;
      m = LUTraits<Ty>::abs( A.fast(p[i],i) );
      for( j=i+1; j<A.rows(); ++j )
      {
         t = LUTraits<Ty>::abs( A.fast(p[j],i) );
         if( t>m ) {
            k=j;
            m=t;
         }
      }

      if( ! LUTraits<Ty>::check_normal(m) ) {
         // matrix is either singular or nearly singular and therefore unworkable
         return 1+p[i];
      }

      if( k != i ) {
         // pivot rows symbolically
         p.swap(i,k);
      }

      // perform Gaussian elimination on each row below the
      //  current working row and store the scaling factor
      tc = one / A.fast(p[i],i);  // eliminates the need for an expensive divide operation in each loop
      for( j=i+1; j<A.rows(); ++j ) {
         A.fast(p[j],i) *= tc;  // calculation and storage of scaling factor
         for( k=i+1; k<A.rows(); ++k ) {  // gaussian elimination
            A.fast(p[j],k) -= A.fast(p[i],k) * A.fast(p[j],i);
         }
      }
   }

   // verify that the last diagonal value is OK
   //  all others were checked inside the loop above
   if( ! LUTraits<Ty>::check_normal(LUTraits<Ty>::abs(A.fast(p[i],i))) ) {
      // matrix is either singular or nearly singular and therefore unworkable
      return 1+p[i];
   }

   return 0;
}

/* ----------------------------------------------------------------------------- */
// LU back-substitution solver
//  the right-hand side vector rhs is used to determine the return vector x
//  through forward and back substitution with the decomposed matrix LU
//  and the permutation array p
template <class Ty>
bool lu_solve( const Matrix<Ty>& LU, const LUPermutation& p, const Vector<Ty>& rhs, Vector<Ty>& x )
{
   size_t i, j, count;

   // verify matrix sizes
   if( rhs.size() < LU.rows() || LU.rows() != LU.cols() || x.size() < LU.rows() )
      return false;

   // LUx = rhs, Ux = c, Lc = rhs
   // first find c by forward substitution
   //  c is stored in the return vector x
   for( i=0; i<LU.rows(); ++i ) {
      x.fast(i) = rhs.fast(p[i]);
      for( j=0; j<i; ++j ) {
         x.fast(i) -= LU.fast(p[i],j) * x.fast(j);
      }
   }

   // now find x by back substitution
   //  this involves manipulating the already stored
   //  values of c
   for( count=0, i=LU.rows()-1; count<LU.rows(); ++count, --i ) {
      for( j=i+1; j<LU.rows(); ++j ) {
         x.fast(i) -= LU.fast(p[i],j) * x.fast(j);
      }
      x.fast(i) /= LU.fast(p[i],i);
   }
   return true;
}

//  same as above, except rhs and x are matrices, so the solution is performed on
//   each column vector of rhs
template <class Ty>
bool lu_solve( const Matrix<Ty>& LU, const LUPermutation& p, const Matrix<Ty>& rhs, Matrix<Ty>& x )
{
   size_t i, j, k;

   // verify matrix sizes
   if( rhs.rows() < LU.rows() || LU.rows() != LU.cols() || x.rows() < LU.rows() || x.cols() < LU.cols() )
      return false;

   // loop over the columns of rhs
   for( k=0; k<rhs.cols(); ++k ) {

      // LUx = rhs, Ux = c, Lc = rhs
      // first find c by forward substitution
      //  c is stored in the return vector x
      for( i=0; i<LU.rows(); ++i ) {
         x.fast(i,k) = rhs.fast(p[i],k);
         for( j=0; j<i; ++j ) {
            x.fast(i,k) -= LU.fast(p[i],j) * x.fast(j,k);
         }
      }

      // now find x by back substitution
      //  this involves manipulating the already stored
      //  values of c
      for( i=LU.rows()-1; i>=0; --i ) {
         for( j=i+1; j<LU.rows(); ++j ) {
            x.fast(i,k) -= LU.fast(p[i],j) * x.fast(j,k);
         }
         x.fast(i,k) /= LU.fast(p[i],i);
      }

   }
   return true;
}

/* -------------------------------------------------------------------------------------- */
//                                Matrix Inversion                                        //
/* -------------------------------------------------------------------------------------- */

template <class Ty>
Matrix<Ty> invert( const Matrix<Ty>& a )
{
   // argument checking
   if( ! a.rows() || a.rows() != a.cols() )
      throw MatrixError( "invert(): invalid argument." );

   Matrix<Ty> ainv( a.rows(), a.cols() );

   if( a.rows() == 1 ) {
      ainv.fast(0,0) = Ty(1.) / a.fast(0,0);
   }
   else if( a.rows() == 2 ) {
      Ty d = Ty(1.) / (a.fast(0,0)*a.fast(1,1) - a.fast(1,0)*a.fast(0,1));
      Ty t = a.fast(0,0);
      ainv.fast(0,0) = a.fast(1,1) * d;
      ainv.fast(1,1) = t * d;
      ainv.fast(0,1) = -a.fast(0,1) * d;
      ainv.fast(1,0) = -a.fast(1,0) * d;
   }
   else {
      // use LU decomposition
      //  need a temporary storage matrix
      Matrix<Ty> tmp(a.copy());
      //  and a permutation object
      LUPermutation perm;
      //  and a rhs vector
      Vector<Ty> rhs(a.rows(),Ty(0.));
      // do the decomposition
      if( lu_decomp( tmp, perm ) )
         throw MatrixError( "matrix::invert(): LU decomposition failed." );
      // for each column of a, create the rhs and solve for the column of ainv
      for( size_t i=0; i<a.cols(); ++i ) {
         rhs.fast(i) = Ty(1.);
         lu_solve( tmp, perm, rhs, ainv(Range::all(),i).ref() );
         rhs.fast(i) = Ty(0.);
      }
   }
   return ainv;
}


END_MATRIX_NAMESPACE()


#endif  // LU_MATRIX_H
