#ifndef COMPLEX_MATRIX_INCLUDED
#define COMPLEX_MATRIX_INCLUDED

#include <complex>
#include <matrix/cvector.h>
#include <matrix/matrix.h>

BEGIN_MATRIX_NAMESPACE()


/*
// specialization of the Vector class various std::complex datatypes
template <>
class Matrix<std::complex<double> >
{
   typedef std::complex<double> MyT; 
   typedef double MyBaseT; 
public:
   // specialty constructor, conversion from real to complex
   Matrix<MyT>( const Matrix<MyBaseT>& rhs ) : data_(rhs.rows_*rhs.cols_), offset_(0), cstride_(1), rstride_(rhs.cols_), cols_(rhs.cols_), rows_(rhs.rows_) {
      // if the supplied matrix is transposed, transpose this one 
      if( rhs.cstride_ > rhs.rstride_ ) {
         size_t t = cstride_;
         cstride_ = rstride_;
         rstride_ = t;
      }
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) = MyT(rhs.fast(i,j));
   }
};

template <>
class Matrix<std::complex<float> >
{
   typedef std::complex<float> MyT; 
   typedef float MyBaseT; 
public:
   // specialty constructor, conversion from real to complex
   Matrix<MyT>( const Matrix<MyBaseT>& rhs ) : data_(rhs.rows_*rhs.cols_), offset_(0), cstride_(1), rstride_(rhs.cols_), cols_(rhs.cols_), rows_(rhs.rows_) {
      // if the supplied matrix is transposed, transpose this one 
      if( rhs.cstride_ > rhs.rstride_ ) {
         size_t t = cstride_;
         cstride_ = rstride_;
         rstride_ = t;
      }
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) = MyT(rhs.fast(i,j));
   }
};

template <>
class Matrix<std::complex<long double> >
{
   typedef std::complex<long double> MyT; 
   typedef long double MyBaseT; 
public:
   // specialty constructor, conversion from real to complex
   Matrix<MyT>( const Matrix<MyBaseT>& rhs ) : data_(rhs.rows_*rhs.cols_), offset_(0), cstride_(1), rstride_(rhs.cols_), cols_(rhs.cols_), rows_(rhs.rows_) {
      // if the supplied matrix is transposed, transpose this one 
      if( rhs.cstride_ > rhs.rstride_ ) {
         size_t t = cstride_;
         cstride_ = rstride_;
         rstride_ = t;
      }
      for( size_t i=0; i<rows_; ++i )
         for( size_t j=0; j<cols_; ++j )
            fast(i,j) = MyT(rhs.fast(i,j));
   }
};
*/

// define some template functions only for use with complex Matrix types

template <class Ty>
Matrix<Ty> real( const Matrix<std::complex<Ty> >& v )
{
   Matrix<Ty> r(v.rows(),v.cols());
   for( size_t i=0; i<v.rows(); ++i )
      for( size_t j=0; j<v.cols(); ++j )
         r.fast(i,j) = v.fast(i,j).real();
   return r;
}

template <class Ty>
Matrix<Ty> imag( const Matrix<std::complex<Ty> >& v )
{
   Matrix<Ty> r(v.rows(),v.cols());
   for( size_t i=0; i<v.rows(); ++i )
      for( size_t j=0; j<v.cols(); ++j )
         r.fast(i,j) = v.fast(i,j).imag();
   return r;
}

template <class Ty>
Matrix<Ty> abs( const Matrix<std::complex<Ty> >& v )
{
   Matrix<Ty> r(v.rows(),v.cols());
   for( size_t i=0; i<v.rows(); ++i )
      for( size_t j=0; j<v.cols(); ++j )
         r.fast(i,j) = abs(v.fast(i,j));
   return r;
}

template <class Ty>
Matrix<Ty> arg( const Matrix<std::complex<Ty> >& v )
{
   Matrix<Ty> r(v.rows(),v.cols());
   for( size_t i=0; i<v.rows(); ++i )
      for( size_t j=0; j<v.cols(); ++j )
         r.fast(i,j) = arg(v.fast(i,j));
   return r;
}

template <class Ty>
Matrix<std::complex<Ty> > conj( const Matrix<std::complex<Ty> >& v )
{
   Matrix<std::complex<Ty> > r(v.rows(),v.cols());
   for( size_t i=0; i<v.rows(); ++i )
      for( size_t j=0; j<v.cols(); ++j )
         r.fast(i,j) = conj(v.fast(i,j));
   return r;
}


// typedef for the CMatrix type, a standard complex Matrix in double precision
typedef std::complex<double> CMatrixT;
typedef Matrix<CMatrixT> CMatrix;

END_MATRIX_NAMESPACE()


#endif  /* COMPLEX_MATRIX_INCLUDED */
