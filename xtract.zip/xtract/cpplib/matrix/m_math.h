#ifndef MATRIX_CLASS_DEFINED
#error matrix.h must be included before m_math.h
#endif

#ifndef MATRIX_MATH_DEFINED
#define MATRIX_MATH_DEFINED


BEGIN_MATRIX_NAMESPACE()

//------------ Addition -------------//

template<class Ty> Matrix<Ty> operator+( const Matrix<Ty>& v1, const Matrix<Ty>& v2 )
{
   // sizes must match
   if( v1.rows() != v2.rows() || v1.cols() != v2.cols() ) throw MatrixError( "Matrix size mismatch in operator+." );
   Matrix<Ty> mr( v1.copy() );
   mr += v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator+( const Matrix<Ty>& v1, const Ty& v2 )
{
   Matrix<Ty> mr( v1.copy() );
   mr += v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator+( const Ty& v1, const Matrix<Ty>& v2 )
{
   Matrix<Ty> mr( v2.copy() );
   mr += v2;
   return mr;
}

//------------ Subtraction -------------//

template<class Ty> Matrix<Ty> operator-( const Matrix<Ty>& v1, const Matrix<Ty>& v2 )
{
   // sizes must match
   if( v1.rows() != v2.rows() || v1.cols() != v2.cols() ) throw MatrixError( "Matrix size mismatch in operator-." );
   Matrix<Ty> mr( v1.copy() );
   mr -= v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator-( const Matrix<Ty>& v1, const Ty& v2 )
{
   Matrix<Ty> mr( v1.copy() );
   mr -= v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator-( const Ty& v1, const Matrix<Ty>& v2 )
{
   Matrix<Ty> mr( v2.copy() );
   for( size_t i=0; i<v2.rows(); ++i )
      for( size_t j=0; j<v2.cols(); ++j )
         mr.fast(i,j) = v1 - mr.fast(i,j);
   return mr;
}

//------------ Multiplication -------------//

// this is element-by-element multiplication, NOT THE BLAS DOT PRODUCT
template<class Ty> Matrix<Ty> operator*( const Matrix<Ty>& v1, const Matrix<Ty>& v2 )
{
   // sizes must match
   if( v1.rows() != v2.rows() || v1.cols() != v2.cols() ) throw MatrixError( "Matrix size mismatch in operator*." );
   Matrix<Ty> mr( v1.copy() );
   mr *= v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator*( const Matrix<Ty>& v1, const Ty& v2 )
{
   Matrix<Ty> mr( v1.copy() );
   mr *= v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator*( const Ty& v1, const Matrix<Ty>& v2 )
{
   Matrix<Ty> mr( v2.copy() );
   mr *= v1;
   return mr;
}

//------------ Division -------------//

// this is element-by-element division
template<class Ty> Matrix<Ty> operator/( const Matrix<Ty>& v1, const Matrix<Ty>& v2 )
{
   // sizes must match
   if( v1.rows() != v2.rows() || v1.cols() != v2.cols() ) throw MatrixError( "Matrix size mismatch in operator/." );
   Matrix<Ty> mr( v1.copy() );
   mr /= v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator/( const Matrix<Ty>& v1, const Ty& v2 )
{
   Matrix<Ty> mr( v1.copy() );
   mr /= v2;
   return mr;
}

template<class Ty> Matrix<Ty> operator/( const Ty& v1, const Matrix<Ty>& v2 )
{
   Matrix<Ty> mr( v2.copy() );
   for( size_t i=0; i<v2.rows(); ++i )
      for( size_t j=0; j<v2.cols(); ++j )
         mr.fast(i,j) = v1 / mr.fast(i,j);
   return mr;
}

//------------ Higher-level math functions -------------//











//------------ BLAS functions -------------//

template<class Ty> Vector<Ty> dot_product( const Vector<Ty>& v1, const Matrix<Ty>& v2 )
{
   if( v1.size() != v2.cols() ) throw MatrixError( "Vector/Matrix size mismatch in dot_product." );
   Vector<Ty> r( v2.rows(), 0. );
   for( size_t i=0; i<v2.rows(); ++i )
      for( size_t j=0; j<v1.size(); ++j )
         r.fast(i) += v1.fast(j) * v2.fast(i,j);
   return r;
}

template<class Ty> Vector<Ty> dot_product( const Matrix<Ty>& v1, const Vector<Ty>& v2 )
{
   if( v1.cols() != v2.size() ) throw MatrixError( "Matrix/Vector size mismatch in dot_product." );
   Vector<Ty> r( v1.rows(), 0. );
   for( size_t i=0; i<v1.rows(); ++i )
      for( size_t j=0; j<v2.size(); ++j )
         r.fast(i) += v1.fast(i,j) * v2.fast(j);
   return r;
}

template<class Ty> Matrix<Ty> dot_product( const Matrix<Ty>& v1, const Matrix<Ty>& v2 )
{
   if( v1.cols() != v2.rows() ) throw MatrixError( "Matrix/Matrix size mismatch in dot_product." );
   Matrix<Ty> r( v1.rows(), v2.cols(), 0. );
   for( size_t i=0; i<v1.rows(); ++i )
      for( size_t j=0; j<v2.cols(); ++j )
         for( size_t k=0; k<v1.cols(); ++k )
            r.fast(i,j) += v1.fast(i,k) * v2.fast(k,j);
   return r;
}

//------------ Identity Matrix shortcut -------------//

template <class Ty> Matrix<Ty> identity( size_t sz )
{
   Matrix<Ty> r( sz, sz, 0. );
   Ty one(1.);
   for( size_t i=0; i<sz; ++i )
      r.fast(i,i) = one;
   return r;
}

//------------ Calculate the determinant recursively -------------//

template <class Ty> Ty Determinant( const Matrix<Ty>& x )
{
   if( x.rows() != x.cols() )
      throw MatrixError( "Determinant(): matrix is not square." );
   else if( ! x.rows() )
      return Ty(0.);
   Ty r(0.);
   if( x.rows() == 1 ) {
      r = x(0,0);
   }
   else {
      // use a recursive algorithm
      Matrix<Ty> y( x.rows()-1, x.rows()-1 );
      static Ty s;
      for( int k=0; k<x.rows(); ++k ) {
         // build the submatrix
         for( int i=0; i<x.rows(); ++i ) {
            if( i != k )
            {
               for( int j=1; j<x.rows(); j++ ) {
                  if( i < k )
                     y(i,j-1) = x(i,j);
                  else
                     y(i-1,j-1) = x(i,j);
               }
            }
         }
         // calculate the sign
         s = (k%2) ? Ty(-1.) : Ty(1.);
         // calculate the recursive determinant
         r += s * x(k,0) * Determinant( y );
      }
   }
   return r;
}

END_MATRIX_NAMESPACE()

#include <matrix/lu.h>


#endif    /* MATRIX_MATH_DEFINED */
