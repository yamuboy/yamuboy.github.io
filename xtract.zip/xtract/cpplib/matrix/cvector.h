#ifndef COMPLEX_VECTOR_INCLUDED
#define COMPLEX_VECTOR_INCLUDED

#include <complex>
#include <matrix/vector.h>

BEGIN_MATRIX_NAMESPACE()

/*
// specialization of the Vector class various std::complex datatypes
template <>
class Vector<std::complex<double> >
{
   typedef std::complex<double> MyT; 
   typedef double MyBaseT; 
public:
   // specialty constructor, conversion from real to complex
   Vector<MyT>( const Vector<MyBaseT>& rhs ) : MatrixHeap<MyT>(rhs.size_), offset_(0), stride_(1), size_(rhs.size_) {
      for( size_t i=0; i<size_; ++i )
         data_[i] = MyT(rhs.fast(i));
   }
};

template <>
class Vector<std::complex<float> >
{
   typedef std::complex<float> MyT; 
   typedef float MyBaseT; 
public:
   // specialty constructor, conversion from real to complex
   Vector<MyT>( const Vector<MyBaseT>& rhs ) : MatrixHeap<MyT>(rhs.size_), offset_(0), stride_(1), size_(rhs.size_) {
      for( size_t i=0; i<size_; ++i )
         data_[i] = MyT(rhs.fast(i));
   }
};

template <>
class Vector<std::complex<long double> >
{
   typedef std::complex<long double> MyT; 
   typedef long double MyBaseT; 
public:
   // specialty constructor, conversion from real to complex
   Vector<MyT>( const Vector<MyBaseT>& rhs ) : MatrixHeap<MyT>(rhs.size_), offset_(0), stride_(1), size_(rhs.size_) {
      for( size_t i=0; i<size_; ++i )
         data_[i] = MyT(rhs.fast(i));
   }
};
*/

// define some template functions only for use with complex Vector types

template <class Ty>
Vector<Ty> real( const Vector<std::complex<Ty> >& v )
{
   Vector<Ty> r(v.size());
   for( size_t i=0; i<v.size(); ++i )
      r.fast(i) = v.fast(i).real();
   return r;
}

template <class Ty>
Vector<Ty> imag( const Vector<std::complex<Ty> >& v )
{
   Vector<Ty> r(v.size());
   for( size_t i=0; i<v.size(); ++i )
      r.fast(i) = v.fast(i).imag();
   return r;
}

template <class Ty>
Vector<Ty> abs( const Vector<std::complex<Ty> >& v )
{
   Vector<Ty> r(v.size());
   for( size_t i=0; i<v.size(); ++i )
      r.fast(i) = abs(v.fast(i));
   return r;
}

template <class Ty>
Vector<Ty> arg( const Vector<std::complex<Ty> >& v )
{
   Vector<Ty> r(v.size());
   for( size_t i=0; i<v.size(); ++i )
      r.fast(i) = arg(v.fast(i));
   return r;
}

template <class Ty>
Vector<std::complex<Ty> > conj( const Vector<std::complex<Ty> >& v )
{
   Vector<std::complex<Ty> > r(v.size());
   for( size_t i=0; i<v.size(); ++i )
      r.fast(i) = conj(v.fast(i));
   return r;
}


// typedef for the CVector type, a standard complex Vector in double precision
typedef std::complex<double> CVectorT;
typedef Vector<CVectorT> CVector;

END_MATRIX_NAMESPACE()

#endif  /* COMPLEX_VECTOR_INCLUDED */
