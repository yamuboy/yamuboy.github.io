#ifndef MATRIX_MEMORY_HEAP_CLASS
#define MATRIX_MEMORY_HEAP_CLASS 1

#include <matrix/exception.h>

#ifdef MATRIX_HEAP_DEBUG
#include <iostream>
#endif

BEGIN_MATRIX_NAMESPACE()

template <class Ty> class RawHeap
{
private:
   // do not allow copying, it could lead to all kinds of funny
   //  behavior and is unnecessary for what this class is designed to do
   RawHeap<Ty>& operator=( const RawHeap<Ty>& rhs ) { return *this; }
   RawHeap<Ty>( const RawHeap<Ty>& rhs ) { }

   Ty * top_;      // top of the heap
   size_t size_;   // size of the heap (# of elements)

public:
   // indexing operator
   Ty& operator[]( size_t i ) {
#ifdef MATRIX_CHECK_MEMORY
      if( ! top_ || i >= size_ ) {
         throw MatrixError( "Memory access error." );
      }
#endif
      return *(top_ + i);
   }

   // const indexing operator
   const Ty& operator[]( size_t i ) const {
#ifdef MATRIX_CHECK_MEMORY
      if( !top_ || i >= size_ ) {
         throw MatrixError( "Memory access error." );
      }
#endif
      return *(top_ + i);
   }

   // return the size of heap in elements
   size_t size() const {
      return size_;
   }

   // return the size of the heap in bytes
   size_t bytesize() const {
      return sizeof(Ty)*size_;
   }

   // check whether an index is valid
   bool indexOK( size_t i ) const {
      return (top_ && i<size_);
   }

   bool operator==( const RawHeap<Ty>& rhs ) const {
       return (this->top_ && this->top_ == rhs.top_);
   }

   bool operator!=( const RawHeap<Ty>& rhs ) const {
       return ( !this->top_ || this->top_ != rhs.top_);
   }

   // create a copy of the heap
   RawHeap<Ty> copy() const {
       RawHeap<Ty> ret( this->size_ );
       if( this->size_ ) memcpy(ret.top_,this->top_,sizeof(Ty)*this->size_);
       return ret;
   }

   // default constructor allocates space for sz elements, uninitialized
   RawHeap<Ty>( size_t sz=0 ) : top_(0), size_(sz) {
      if(sz) top_ = new Ty [sz];
   }

   // constructor allocates space for sz elements, initialized to the value init
   RawHeap<Ty>( size_t sz, const Ty& init ) : top_(0), size_(sz) {
      if(sz) {
         top_ = new Ty [sz];
         for( size_t i=0; i<sz; ++i ) top_[i] = init;
      }
   }

   // constructor allocates space for sz elements, initialized to the values in the array init
   RawHeap<Ty>( size_t sz, const Ty* init, size_t init_size ) : top_(0), size_(sz) {
      if(sz) {
         top_ = new Ty [sz];
         if( init_size ) {
            for( size_t i=0; i<sz; ++i )
               top_[i] = init[(i<init_size)?i:init_size-1];
         }
      }
   }

   // constructor accepts a pre-allocated block of memory
   //  it must have been created with the new opeartor and it
   //  will be deleted automatically when it is no longer referenced
   RawHeap<Ty>( Ty* h, size_t sz ) : top_(h), size_(sz) { }

   // destructor
   virtual ~RawHeap<Ty>() { delete [] top_; }
};

END_MATRIX_NAMESPACE()

#endif   /* MATRIX_MEMORY_HEAP_CLASS */

