#ifndef VECTOR_CLASS_DEFINED
#error vector.h must be included before v_math.h
#endif

#ifndef VECTOR_MATH_DEFINED
#define VECTOR_MATH_DEFINED

BEGIN_MATRIX_NAMESPACE()

//------------ Addition -------------//

template<class Ty> Vector<Ty> operator+( const Vector<Ty>& v1, const Vector<Ty>& v2 )
{
   // sizes must match
   if( v1.size() != v2.size() ) throw new MatrixError( "Vector size mismatch in operator+." );
   Vector<Ty> vr( v1.copy() );
   vr += v2;
   return vr;
}

template<class Ty> Vector<Ty> operator+( const Vector<Ty>& v1, const Ty& v2 )
{
   Vector<Ty> vr( v1.copy() );
   vr += v2;
   return vr;
}

template<class Ty> Vector<Ty> operator+( const Ty& v1, const Vector<Ty>& v2 )
{
   Vector<Ty> vr( v2.copy() );
   vr += v1;
   return vr;
}

//------------ Subtraction -------------//

template<class Ty> Vector<Ty> operator-( const Vector<Ty>& v1, const Vector<Ty>& v2 )
{
   // sizes must match
   if( v1.size() != v2.size() ) throw new MatrixError( "Vector size mismatch in operator-." );
   Vector<Ty> vr( v1.copy() );
   vr -= v2;
   return vr;
}

template<class Ty> Vector<Ty> operator-( const Vector<Ty>& v1, const Ty& v2 )
{
   Vector<Ty> vr( v1.copy() );
   vr -= v2;
   return vr;
}

template<class Ty> Vector<Ty> operator-( const Ty& v1, const Vector<Ty>& v2 )
{
   Vector<Ty> vr( v2.copy() );
   for( size_t i=0; i<vr.size(); ++i )
      vr.fast(i) = v1 - vr.fast(i);
   return vr;
}

//------------ Multiplication -------------//

// this is element-by-element multiplication, NOT THE BLAS DOT PRODUCT
template<class Ty> Vector<Ty> operator*( const Vector<Ty>& v1, const Vector<Ty>& v2 )
{
   // sizes must match
   if( v1.size() != v2.size() ) throw new MatrixError( "Vector size mismatch in operator*." );
   Vector<Ty> vr( v1.copy() );
   vr *= v2;
   return vr;
}

template<class Ty> Vector<Ty> operator*( const Vector<Ty>& v1, const Ty& v2 )
{
   Vector<Ty> vr( v1.copy() );
   vr *= v2;
   return vr;
}

template<class Ty> Vector<Ty> operator*( const Ty& v1, const Vector<Ty>& v2 )
{
   Vector<Ty> vr( v2.copy() );
   vr *= v1;
   return vr;
}

//------------ Division -------------//

// this is element-by-element division
template<class Ty> Vector<Ty> operator/( const Vector<Ty>& v1, const Vector<Ty>& v2 )
{
   // sizes must match
   if( v1.size() != v2.size() ) throw new MatrixError( "Vector size mismatch in operator/." );
   Vector<Ty> vr( v1.copy() );
   vr /= v2;
   return vr;
}

template<class Ty> Vector<Ty> operator/( const Vector<Ty>& v1, const Ty& v2 )
{
   Vector<Ty> vr( v1.copy() );
   vr /= v2;
   return vr;
}

template<class Ty> Vector<Ty> operator/( const Ty& v1, const Vector<Ty>& v2 )
{
   Vector<Ty> vr( v2.copy() );
   for( size_t i=0; i<vr.size(); ++i )
      vr.fast(i) = v1 / vr.fast(i);
   return vr;
}

//------------ Higher-level math functions -------------//









//------------ BLAS functions -------------//

template<class Ty> Ty dot_product( const Vector<Ty>& v1, const Vector<Ty>& v2 )
{
   // sizes must match
   if( v1.size() != v2.size() ) throw new MatrixError( "Vector size mismatch in dot_product." );
   Ty r(0);
   for( size_t i=0; i<v1.size(); ++i )
      r += v1.fast(i) * v2.fast(i);
   return r;
}

END_MATRIX_NAMESPACE()

#endif  /* VECTOR_MATH_DEFINED  */

