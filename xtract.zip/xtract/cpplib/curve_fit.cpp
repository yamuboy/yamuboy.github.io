#include "curve_fit.hpp"


/***************************************************************************************/
void linefit_mxb( const double* x, const double* y, size_t n, double& m, double& b, double& r2 )
{
    double xsum = 0.;
    double ysum = 0.;
    double xxsum = 0.;
    double yysum = 0.;
    double xysum = 0.;
    double err = 0.;
    double tot = 0.;
    double ymean, t;

    if( n < 2 ) throw GenericError( "linefit_mxb(): at least 2 points are required to draw a line." );

    // compute slope and intercept
    for( size_t i=0; i<n; ++i ) {
        xsum  += x[i];
        ysum  += y[i];
        xxsum += x[i]*x[i];
        yysum += y[i]*y[i];
        xysum += x[i]*y[i];
    }
    m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
    ymean = ysum / ((double) n );
    b  = ymean - m * xsum / ((double) n);

    // compute R^2
    for( size_t i=0; i<n; ++i ) {
        t = m*x[i] + b - y[i];
        err += t * t;
        t = y[i] - ymean;
        tot += t * t;
    }
    r2 = 1. - err/tot;
}

/***************************************************************************************/
void linefit_mx0( const double *x, const double *y, size_t n, double& m, double& r2 )
{
    double ysum = 0.;
    double xxsum = 0.;
    double xysum = 0.;
    double err = 0.;
    double tot = 0.;
    double ymean, t;

    if( n < 1 ) throw GenericError( "linefit_mx0(): at least 1 point is required." );

    // compute slope
    for( size_t i=0; i<n; ++i ) {
        ysum  += y[i];
        xxsum += x[i]*x[i];
        xysum += x[i]*y[i];
    }
    m = xysum / xxsum;

    // compute R^2
    ymean = ysum/((double) n);
    for( size_t i=0; i<n; ++i ) {
        t = m*x[i] - y[i];
        err += t * t;
        t = y[i] - ymean;
        tot += t * t;
    }
    r2 = 1. - err/tot;
}
