#include <iostream>

using namespace std;

#define MATRIX_HEAP_DEBUG  1

template <typename T>
struct myType
{
   typedef T ty;
};

template <typename T>
bool myFunc( const T& x )
{
   myType<T>::ty c;

   c = -9.5;
   return ((c+x) > 0.);
}



int main( int argc, char** argv )
{
   myType<double>::ty d;
   d = 5.4;
   cout << d << endl;

   if( myFunc( 12.6 ) )
      cout << "greater than zero" << endl;


   return 0;
}

