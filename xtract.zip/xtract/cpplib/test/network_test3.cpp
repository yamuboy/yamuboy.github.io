#include <iostream>
#include "network_parameters.h"
#include <matrix/io.h>

int main( int argc, char** argv )
{
   NetworkParams np1(2,NetworkParams::Z_Param);
   matrix::CMatrix m(2,2);
   matrix::CMatrix res(2,2);
   matrix::CMatrix res2(2,2);
   matrix::CVector zref(2);
   matrix::CVector zref2(2);

   m(0,0) = matrix::CMatrixT(0.3,-0.44);
   m(0,1) = matrix::CMatrixT(0.0034,-0.0025);
   m(1,0) = matrix::CMatrixT(12.5,-1.3);
   m(1,1) = matrix::CMatrixT(-0.22,0.41);

   zref(0) = matrix::CMatrixT(50.);
   zref(1) = matrix::CMatrixT(50.);

   zref2(0) = matrix::CMatrixT(75.);
   zref2(1) = matrix::CMatrixT(75.);

   std::cout << m;

   StoT(m,res);
   std::cout << "StoT" << std::endl << res;

   TtoS(res,res2);
   std::cout << "TtoS" << std::endl << res2;

   StoS(m,res2,zref,zref2);
   std::cout << "StoS" << std::endl << res2;

   TtoT(res,res2,zref,zref2);
   std::cout << "TtoT" << std::endl << res2;

   TtoS(res2,res2);
   std::cout << "TtoS" << std::endl << res2;

   return 0;
}
