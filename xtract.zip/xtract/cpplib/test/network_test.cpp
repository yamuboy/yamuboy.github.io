#include <iostream>
#include "network_parameters.hpp"

int main( int argc, char** argv )
{
   NetworkParams np1;
   NetworkParams np2;
   NetworkParams np3;
   matrix::CMatrix one(1,1);
   matrix::CMatrix two(2,2);
   matrix::CMatrix three(3,3);

   std::cout << " ========================================================= " << std::endl;
   std::cout << "     1-PORT Conversions" << std::endl;
   std::cout << " ========================================================= " << std::endl;

   one(0,0) = std::complex<double>( 0.5, -0.6 );
   np1.add( 1., one );

   std::cout << np1;
   np1.convert_to( "Z" );
   std::cout << np1;
   np1.convert_to( "Y" );
   std::cout << np1;
   np1.convert_to( "S" );
   std::cout << np1;
   np1.convert_to( "Y" );
   std::cout << np1;
   np1.convert_to( "Z" );
   std::cout << np1;
   np1.convert_to( "S" );
   std::cout << np1;

   std::cout << " ========================================================= " << std::endl;
   std::cout << "     2-PORT Conversions" << std::endl;
   std::cout << " ========================================================= " << std::endl;

   two(0,0) = std::complex<double>( 0.5, -0.6 );
   two(0,1) = std::complex<double>( 0.05, -0.02 );
   two(1,0) = std::complex<double>( 17., -12.5 );
   two(1,1) = std::complex<double>( -0.2, -0.4 );
   np2.add( 1., two );

   std::cout << np2;
   np2.convert_to( "Z" );
   std::cout << np2;
   np2.convert_to( "Y" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;
   np2.convert_to( "Y" );
   std::cout << np2;
   np2.convert_to( "Z" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;

   std::cout << " ========================================================= " << std::endl;
   std::cout << "     3-PORT Conversions" << std::endl;
   std::cout << " ========================================================= " << std::endl;

   three(0,0) = std::complex<double>( 0.5, -0.6 );
   three(0,1) = std::complex<double>( 0.05, -0.02 );
   three(0,2) = std::complex<double>( -0.3, -0.1 );
   three(1,0) = std::complex<double>( 17., -12.5 );
   three(1,1) = std::complex<double>( -0.2, -0.4 );
   three(1,2) = std::complex<double>( 0. );
   three(2,0) = std::complex<double>( 0.35, 0.25 );
   three(2,1) = std::complex<double>( 0.0007 );
   three(2,2) = std::complex<double>( -0.2, 0.55 );
   np3.add( 1., three );

   std::cout << np3;
   np3.convert_to( "Z" );
   std::cout << np3;
   np3.convert_to( "Y" );
   std::cout << np3;
   np3.convert_to( "S" );
   std::cout << np3;
   np3.convert_to( "Y" );
   std::cout << np3;
   np3.convert_to( "Z" );
   std::cout << np3;
   np3.convert_to( "S" );
   std::cout << np3;

   std::cout << " ========================================================= " << std::endl;
   std::cout << "     More 2-PORT Conversions" << std::endl;
   std::cout << " ========================================================= " << std::endl;

   std::cout << np2;
   np2.convert_to( "T" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;
   np2.convert_to( "H" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;
   np2.convert_to( "ABCD" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;
   np2.convert_to( "G" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;

   std::cout << " ========================================================= " << std::endl;
   std::cout << "     More 2-PORT Conversions (through Z)" << std::endl;
   std::cout << " ========================================================= " << std::endl;

   std::cout << np2;
   np2.convert_to( "Z" );
   np2.convert_to( "H" );
   std::cout << np2;
   np2.convert_to( "Z" );
   np2.convert_to( "S" );
   std::cout << np2;
   np2.convert_to( "Z" );
   np2.convert_to( "ABCD" );
   std::cout << np2;
   np2.convert_to( "Z" );
   np2.convert_to( "S" );
   std::cout << np2;
   np2.convert_to( "Z" );
   std::cout << np2;
   np2.convert_to( "G" );
   std::cout << np2;
   np2.convert_to( "Z" );
   std::cout << np2;
   np2.convert_to( "S" );
   std::cout << np2;


   return 0;
}
