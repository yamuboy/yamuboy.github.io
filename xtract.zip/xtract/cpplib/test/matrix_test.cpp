// #define MATRIX_HEAP_DEBUG  1
// #define MATRIX_CHECK_MEMORY 1


#include <iostream>
#include <matrix/cmatrix.h>
#include <matrix/io.h>

using namespace std;


int main( int argc, char** argv )
{
   matrix::Matrix<double> a(3,3);
   matrix::Matrix<double> b(3,3);
   matrix::Matrix<double> c(3,3);

   a = 0.;
   b = 5.;

   a(0,1) = 3.2;
   a(1,0) = -7.5;
   a(1,2) = 0.6;
   a(2,2) = -0.77;

   c = a + b;

   cout << "Matrix a:" << endl;
   cout << a;

   cout << "Matrix b:" << endl;
   cout << b;

   cout << "Matrix c:" << endl;
   cout << c;

   cout << "Matrix d: reference to a." << endl;
   matrix::Matrix<double> d(a);

   try {
      matrix::invert( d, b );
   }
   catch( std::exception* e ) {
      cerr << e->what() << endl;
      exit(1);
   }

   cout << "Matrix b after inversion of d:" << endl;
   cout << b;


   return 0;
}

