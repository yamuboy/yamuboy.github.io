#include "touchstone.hpp"
#include <iostream>
#include <string>

int main( int argc, char** argv )
{
   Touchstone t;
   int e;
   std::string fname;
   double fstart, fstop, fstep, f;

   std::cout << "Enter a touchstone file name." << std::endl;
   std::cin >> fname;

   std::cout << "Enter frequencies for start stop and step in GHz." << std::endl;
   std::cin >> fstart >> fstop >> fstep;

   fstart *= 1.e9;
   fstop *= 1.e9;
   fstep *= 1.e9;

   e = t.read_file( fname.c_str() );
   if( e ) {
      std::cerr << "Error: " << Touchstone::error_string( e ) << std::endl;
      return 1;
   }

   NetworkParams np(t.ports());
   Touchstone::DataT mat(t.ports(),t.ports());
   for( f=fstart; f<=fstop; f+=fstep ) {
      t.extract( f, mat );
      np.add( f, mat );
   }

   t = np;
   fname += ".xxx";

   e = t.write_file( fname.c_str() );
   if( e ) {
      std::cerr << "Error: " << Touchstone::error_string( e ) << std::endl;
      return 1;
   }

   return 0;
}
