#include "logger.hpp"
#include <iostream>

void log_stuff()
{
   // create an error message
   logEvent( EventLogger::ErrorEvent, "This is an error event." );

   // create an error message
   logEvent( EventLogger::WarningEvent, "This is a warning event." );

   // create an error message
   logEvent( EventLogger::MessageEvent, "This is a message event." );

   // create an error message
   logEvent( EventLogger::DebugEvent, "This is a debug event." );

   // create an error code to be translated
   logEvent( EventLogger::ErrorEvent, 23, "This is an error event with a code to be translated." );

   // create an error code with an empty message field
   logEvent( EventLogger::ErrorEvent, -21 );
}

const char * translator( const int code )
{
   static char msg[256];
   sprintf( msg, "Error code is %d.", code );
   return msg;
}

int main( int argc, char **argv )
{

   std::cout << "First run." << std::endl;
   log_stuff();

   std::cout << "Set log level to 5." << std::endl;
   SetLoggingLevel(5);
   log_stuff();

   // use the stream logger
   std::cout << "Use the stream logger." << std::endl;
   if( 1 ) {
       EventLogStream s( WarningEvent );

       s << "This is a warning: " << 23 << " is a scary number.";
   }

   std::cout << "Set log level to 0." << std::endl;
   SetLoggingLevel(0);
   log_stuff();

   std::cout << "Log level=3, set timestamps on." << std::endl;
   SetLoggingLevel(3);
   SetLoggingTimestamp(true);
   log_stuff();

   std::cout << "Add a translator." << std::endl;
   PushEventLogTranslator( &translator );
   log_stuff();

   std::cout << "Set the log target to a file." << std::endl;
   EventLogger * logger = new FileEventLogger( "test.log" );
   SetLoggingTarget( logger );
   log_stuff();

   return 0;
}

