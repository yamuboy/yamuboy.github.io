#include <iostream>
#include "network_parameters.h"
#include <matrix/io.h>

int main( int argc, char** argv )
{
   NetworkParams np1(2,NetworkParams::Z_Param);
   matrix::CMatrix m(3,3);
   matrix::CMatrix res(3,3);
   matrix::CMatrix res2(3,3);
   matrix::CVector zref(3);

   m(0,0) = matrix::CMatrixT(344.,-22.);
   m(0,1) = matrix::CMatrixT(14.,1223.);
   m(0,2) = matrix::CMatrixT(8199.,-223.);
   m(1,0) = matrix::CMatrixT(1.);
   m(1,1) = matrix::CMatrixT(224.,-2e4);
   m(1,2) = matrix::CMatrixT(33.2e9,0.);
   m(2,0) = matrix::CMatrixT(21.,-55.3);
   m(2,1) = matrix::CMatrixT(27.,2243.);
   m(2,2) = matrix::CMatrixT(5e6);

   zref(0) = matrix::CMatrixT(75.,-10.);
   zref(1) = matrix::CMatrixT(50.);
   zref(2) = matrix::CMatrixT(35.,40.);

   std::cout << m;

   ZtoS(m,res,zref);
   std::cout << "ZtoS" << std::endl << res;

   StoZ(res,res2,zref);
   std::cout << "StoZ" << std::endl << res2;

   ZtoY_(m,m);
   std::cout << "ZtoY" << std::endl << m;

   YtoS(m,res,zref);
   std::cout << "YtoS" << std::endl << res;

   StoY(res,res2,zref);
   std::cout << "StoY" << std::endl << res2;

//   np1.add( 23.2e9, m );
//   std::cout << np1;

//   np1.convert_to_y();
//   std::cout << np1;

//   np1.convert_to_s(zref);
//   std::cout << np1;

   //np1.convert_to_h();
   //std::cout << np1;

   //np1.convert_to_y();
   //std::cout << np1;

//   np1.convert_to_abcd();
//   std::cout << np1;

//   np1.convert_to_z();
//   std::cout << np1;

   return 0;
}
