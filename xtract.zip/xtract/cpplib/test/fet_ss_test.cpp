#include "fet_ss_model.hpp"
#include "matrix/io.h"
#include <iostream>

int main( int argc, char **argv )
{
    ModelParamSet params;
    FET_SS_Model model;
    matrix::CMatrix ymat;

    if( argc != 2 ) {
        std::cout << "USAGE: " << argv[0] << " file" << std::endl << "   where file is an model .end file" << std::endl;
        return 1;
    }

    try {
        params = ReadModelParams( argv[1] );

        for( ModelParamSet::iterator p = params.begin(); p != params.end(); ++p ) {
            std::cout << (**p).getName() << " = " << (**p).value() << std::endl;
        }
        std::cout << std::endl;

        model.bindParams( params );


        ymat = model.compute_z( 50.e9 );
        std::cout << "Z-params:" << std::endl;
        std::cout << ymat;

        ymat = model.compute_y( 50.e9 );
        std::cout << "Y-params:" << std::endl;
        std::cout << ymat;

        ymat = model.compute_s( 50.e9 );
        std::cout << "S-params:" << std::endl;
        std::cout << ymat;
    }
    catch( ModelParamException& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
        return -1;
    }
    catch( std::exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
        return -1;
    }

    return 0;
}
