#include "touchstone.hpp"
#include <iostream>

int main( int argc, char** argv )
{
   Touchstone t;

   try {
        t.read( "test.s7p" );


        for( Touchstone::iterator i = t.begin(); i != t.end(); ++i ) {
            std::cout << (**i).parms(0,0) << std::endl;
        }

        std::cout << static_cast<NetworkParams>(t);
   }
   catch( TouchstoneError& e ) {
      std::cerr << "Touchstone Error: " << e.what() << std::endl;
      return 1;
   }
   catch( std::exception& e ) {
      std::cerr << "Error: " << e.what() << std::endl;
      return 1;
   }


   return 0;
}
