#include <iostream>
#include <typeinfo>

class X
{
public:
   X() {}
   virtual ~X() {}
   virtual void blah() {
      std::cout << "X::blah()" << std::endl;
   }
};

class Y : public X
{
public:
   Y() {}
   virtual ~Y() {}
   virtual void blah() {
      std::cout << "Y::blah()" << std::endl;
   }
};

int main( int argc, char** argv )
{
   Y y;
   X* xp = &y;
   X& xr = y;

   std::cout << "Accessing xp->blah()" << std::endl;
   xp->blah();

   std::cout << "Accessing xr.blah()" << std::endl;
   xr.blah();

   std::cout << "Creating new pointer using typeof(*xp)." << std::endl;
   X* xtop = new __typeof__(*xp);

   std::cout << "Accessing xtop->blah()" << std::endl;
   xtop->blah();

   std::cout << "Creating new pointer using typeof(xr)." << std::endl;
   X* xtor = new __typeof__(xr);

   std::cout << "Accessing xtor->blah()" << std::endl;
   xtor->blah();

   delete xtop;
   delete xtor;

   return 0;
}


