#include "lu.h"
#include "lu_invert.h"
#include <matrix/matrix_io.h>
#include <complex>
#include <cmath>
#include <iostream>

USE_NAMESPACE_MATRIX()

typedef std::complex<double> Cmplx;
typedef Matrix<double> RealMatrix;
typedef Matrix<Cmplx> ComplexMatrix;

int main( int argc, char** argv )
{
   // LU solver test

   RealMatrix a( 4, 4 );
   RealMatrix b( 4, 1 );
   RealMatrix x;
   LUPermutation p;
   a(0,0) = 1.;
   a(0,1) = 2.;
   a(0,2) = 3.;
   a(0,3) = 4.;

   a(1,0) = 5.;
   a(1,1) = 6.;
   a(1,2) = 7.;
   a(1,3) = 8.;

   a(2,0) = 0.;
   a(2,1) = 10.;
   a(2,2) = 11.;
   a(2,3) = 12.;

   a(3,0) = 13.;
   a(3,1) = 14.;
   a(3,2) = 0.;
   a(3,3) = 16.;

   b(0) = -2.;
   b(1) = 14.;
   b(2) = 0.3;
   b(3) = 0.;


   lu_decomp( a, p );

   std::cout << a;
   std::cout << "P: ";
   for( int i=0; i<4; ++i )
      std::cout << p[i] << " ";
   std::cout << std::endl;

   lu_solve( a, p, b, x );
   std::cout << x;

   a(0,0) = 1.;
   a(0,1) = 2.;
   a(0,2) = 3.;
   a(0,3) = 4.;

   a(1,0) = 5.;
   a(1,1) = 6.;
   a(1,2) = 7.;
   a(1,3) = 8.;

   a(2,0) = 0.;
   a(2,1) = 10.;
   a(2,2) = 11.;
   a(2,3) = 12.;

   a(3,0) = 13.;
   a(3,1) = 14.;
   a(3,2) = 0.;
   a(3,3) = 16.;

   lu_invert( a );
   std::cout << a;



   return 0;
}

