#include "options.hpp"
#include <iostream>

int main( int argc, char** argv )
{
    int i;
    OptionDef opt_defs[] = {
        OptionDef( "widget", "-w ?|--widget=?", "Widgets|widgets", option_any, "", "" ),
        OptionDef( "gadget", "-g ?|--gadget=?", "Gadgets|gadgets", option_any, "", "" ),
        OptionDef( "bloop", "-bl ?|--ploop=?", "Bloop_bloop|bloop", option_any, "", "" ),
        OptionDef( "bob", "-b ?|-b?|--bob=?", "Bob|BigBadBob", option_any, "", "" )
    };

    OptionSet options;

    options.addDef( opt_defs, 4 );
    options.set( "OptionsVerbose", "1" );

    std::cout << "------------------------------------------------\nCommand Line before processsing:\n";
    for( i=0; i<argc; ++i ) {
        std::cout << i << "\t" << argv[i] << std::endl;
    }

    options.processCL( argc, argv );

    std::cout << "\n\n------------------------------------------------\nCommand Line after processsing:\n";
    for( i=0; i<argc; ++i ) {
        std::cout << i << "\t" << argv[i] << std::endl;
    }

    std::cout << "\n\n------------------------------------------------\nOptions Set Holds:\n";
    for( OptionSet::Iter it=options.begin(); it != options.end(); ++it ) {
        std::cout << it->first << ": " << it->second << std::endl;
    }

    return 0;
}
