#include "network_params.hpp"
#include <sstream>

// complex-valued constants for type conversion
static const std::complex<double> ComplexOne = 1.;
static const std::complex<double> ComplexZero = 0.;

/* -------------------------------------------------------------------------------------------- */
NetworkParam NetworkParamSet::getparm_( const double& freq, e_interp_mode mode ) const
{
    // get the lower bound element
    const_iterator i1 = f_lower(freq);
    if( i1 != params_.end() && i1->freq() == freq ) return i1->copy();  // exact match found
    else {
        if( i1 == params_.begin() || i1 == params_.end() ) {
            // freq is outside the range of the data
            std::ostringstream ss;
            ss << "Extrapolation is not supported: freq = " << freq;
            throw NetworkParametersError( ss.str(), E_EXTRAPOLATION );
        }
        // interpolate, iterator i1 must be the first iterator greater than
        //  the desired freq, so pass it and the one below it to the interpolation routine
        return interpolate_( freq, i1--, i1, mode );
    }
}

/* -------------------------------------------------------------------------------------------- */
NetworkParam NetworkParamSet::interpolate_( const double& freq, const_iterator il, const_iterator ih, e_interp_mode mode ) const
{
   double f = (freq - il->freq()) / (ih->freq() - il->freq());
   if( mode == Auto ) {
      switch( ptype_ )
      {
      case S_Param:
      case T_Param:
         mode = Polar; break;
      default:
         mode = Rect; break;
      }
   }

   NetworkParam::DataT dat( nports_, nports_ );
   // do interpolation
   if( mode == Polar ) {
      // polar interpolation (requires more math = slower)
      double m1, a1, a2, mr, ar, ad;
      for( size_t i=0; i<nports_; ++i )
         for( size_t j=0; j<nports_; ++j ) {
            m1 = std::abs( (*il)(i,j) );
            mr = m1 + f * (std::abs( (*ih)(i,j) ) - m1);
            a1 = std::arg( (*il)(i,j) );
            a2 = std::arg( (*ih)(i,j) );
            ad = a2 - a1;
            if( a2 <= a1 && a1 - a2 > M_PI ) ad += 2. * M_PI;
            else if( a2 > a1 && a2 - a1 >= M_PI ) ad -= 2. * M_PI;
            ar = a1 + f * ad;
            dat(i,j) = NetworkParam::DataT::StorageT( mr*cos(ar), mr*sin(ar) );
         }
   }
   else {
      // default to rectangular interpolation
      for( size_t i=0; i<nports_; ++i )
         for( size_t j=0; j<nports_; ++j )
            dat(i,j) = (*il)(i,j) + f * ( (*ih)(i,j) - (*il)(i,j) );
   }
   return NetworkParam( freq, dat );
}

/*****************************************************************************************/
void NetworkParamSet::add( const double& freq, const DataT& data )
{
    if( !nports_ ) {  // there is no data in the data set
        if( params_.size() )  // yikes, this is a bug
            throw NetworkParametersError( "NetworkParams::add(): invalid state.", E_INVALID_STATE );

        if( ! data.rows() || data.rows() != data.cols() )
            throw NetworkParametersError( "NetworkParams::add(): invalid argument.", E_INVALID_ARGUMENT );

        // set nports_ based on the size of this data
        nports_ = data.rows();
        params_.push_back( NetworkParam(freq,data.copy()) );  // add the data
    }
    else {  // there is already data in the data set
        if( data.rows() != nports_ || data.rows() != data.cols() )
            // wrong data shape
            throw NetworkParametersError( "NetworkParams::add(): invalid argument.", E_INVALID_ARGUMENT );
        iterator it = f_lower(freq);
        if( it != params_.end() && it->freq() == freq ) *it = data.copy();  // frequency exists, replace existing data
        else params_.insert( it, NetworkParam(freq,data.copy()) );   // frequency doesn't exist, insert the data into the correct location
    }
}

/*****************************************************************************************/
void NetworkParamSet::renormalize( const RefImpT& new_zref )
{
    if( nports_ && new_zref != ref_imp_ ) {
        if( ptype_ == S_Param ) {
            matrix::CVector old_zref_v( nports_, ref_imp_ );
            matrix::CVector new_zref_v( nports_, new_zref );
            // renormalize
            for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
                *i = YtoS_( StoY_(*i,old_zref_v), new_zref_v );
            }
        }
        else if( ptype_ == T_Param ) {
            matrix::CVector old_zref_v( nports_, ref_imp_ );
            matrix::CVector new_zref_v( nports_, new_zref );
            for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
                *i = StoT_( YtoS_( StoY_(TtoS_(*i),old_zref_v), new_zref_v ) );
            }
        }
    }
    ref_imp_ = new_zref;
}

/*****************************************************************************************/
// convert to [S] parameters from the current parameter type
void NetworkParamSet::convert_to_s()
{
    if( nports_ ) {
        matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
             return;
          case T_Param:
                *i = TtoS_(*i); break;
          case Y_Param:
                *i = YtoS_(*i,zref); break;
          case Z_Param:
                *i = ZtoS_(*i,zref); break;
          case ABCD_Param:
                *i = YtoS_( ABCDtoY_(*i), zref ); break;
          case H_Param:
                *i = YtoS_( HtoY_(*i), zref ); break;
          case G_Param:
                *i = YtoS_( GtoY_(*i), zref ); break;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_s(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = S_Param;
}

/*****************************************************************************************/
// convert to [T] parameters from the current parameter type
void NetworkParamSet::convert_to_t()
{
    if( nports_ ) {
       if( nports_ != 2 )
          throw NetworkParametersError( "NetworkParams::convert_to_t(): conversion only supported for 2-ports.", E_NOT_2PORT );

       matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
                *i = StoT_(*i); break;
          case T_Param:
             return;
          case Y_Param:
                *i = StoT_( YtoS_(*i,zref) ); break;
          case Z_Param:
                *i = StoT_( ZtoS_(*i,zref) ); break;
          case ABCD_Param:
                *i = StoT_( YtoS_( ABCDtoY_(*i), zref ) ); break;
          case H_Param:
                *i = StoT_( YtoS_( HtoY_(*i), zref ) ); break;
          case G_Param:
                *i = StoT_( YtoS_( GtoY_(*i), zref ) ); break;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_t(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = T_Param;
}

/*****************************************************************************************/
// convert to [Y] parameters from the current parameter type
void NetworkParamSet::convert_to_y()
{
    if( nports_ ) {
        matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
                *i = StoY_(*i,zref); break;
          case T_Param:
                *i = StoY_( TtoS_(*i), zref ); break;
          case Y_Param:
               return;
          case Z_Param:
                *i = ZtoY_(*i); break;
          case ABCD_Param:
                *i = ABCDtoY_(*i); break;
          case H_Param:
                *i = HtoY_(*i); break;
          case G_Param:
                *i = GtoY_(*i); break;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_y(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = Y_Param;
}

/*****************************************************************************************/
// convert to [Z] parameters from the current parameter type
void NetworkParamSet::convert_to_z()
{
    if( nports_ ) {
        matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
                *i = StoZ_(*i,zref); break;
          case T_Param:
                *i = StoZ_( TtoS_(*i), zref ); break;
          case Y_Param:
                *i = YtoZ_(*i); break;
          case Z_Param:
               return;
          case ABCD_Param:
                *i = ABCDtoZ_(*i); break;
          case H_Param:
                *i = HtoZ_(*i); break;
          case G_Param:
                *i = GtoZ_(*i); break;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_z(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = Z_Param;
}

/*****************************************************************************************/
// convert to [H] parameters from the current parameter type
void NetworkParamSet::convert_to_h()
{
    if( nports_ ) {
       if( nports_ != 2 )
          throw NetworkParametersError( "NetworkParams::convert_to_h(): conversion only supported for 2-ports.", E_NOT_2PORT );

       matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
                *i = YtoH_( StoY_(*i,zref) ); break;
          case T_Param:
                *i = YtoH_( StoY_( TtoS_(*i), zref ) ); break;
          case Y_Param:
                *i = YtoH_(*i); break;
          case Z_Param:
                *i = ZtoH_(*i); break;
          case ABCD_Param:
                *i = YtoH_( ABCDtoY_(*i) ); break;
          case H_Param:
                return;
          case G_Param:
                *i = YtoH_( GtoY_(*i) ); break;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_h(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = H_Param;
}

/*****************************************************************************************/
// convert to [ABCD] parameters from the current parameter type
void NetworkParamSet::convert_to_abcd()
{
    if( nports_ ) {
       if( nports_ != 2 )
          throw NetworkParametersError( "NetworkParams::convert_to_abcd(): conversion only supported for 2-ports.", E_NOT_2PORT );

       matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
                *i = YtoABCD_( StoY_(*i,zref) ); break;
          case T_Param:
                *i = YtoABCD_( StoY_( TtoS_(*i), zref ) ); break;
          case Y_Param:
                *i = YtoABCD_(*i); break;
          case Z_Param:
                *i = ZtoABCD_(*i); break;
          case ABCD_Param:
                return;
          case H_Param:
                *i = YtoABCD_( HtoY_(*i) ); break;
          case G_Param:
                *i = YtoABCD_( GtoY_(*i) ); break;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_abcd(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = ABCD_Param;
}

/*****************************************************************************************/
// convert to [ABCD] parameters from the current parameter type
void NetworkParamSet::convert_to_g()
{
    if( nports_ ) {
       if( nports_ != 2 )
          throw NetworkParametersError( "NetworkParams::convert_to_g(): conversion only supported for 2-ports.", E_NOT_2PORT );

       matrix::CVector zref( nports_, ref_imp_ );
       for( StorageT::iterator i=params_.begin(); i != params_.end(); ++i ) {
          switch( ptype_ )
          {
          case S_Param:
                *i = YtoG_( StoY_(*i,zref) ); break;
          case T_Param:
                *i = YtoG_( StoY_( TtoS_(*i), zref ) ); break;
          case Y_Param:
                *i = YtoG_(*i); break;
          case Z_Param:
                *i = ZtoG_(*i); break;
          case ABCD_Param:
                *i = YtoG_( ABCDtoY_(*i) ); break;
          case H_Param:
                *i = YtoG_( HtoY_(*i) ); break;
          case G_Param:
                return;
          default:
             throw NetworkParametersError( "NetworkParams::convert_to_g(): current type invalid.", E_CURRENT_TYPE_INVALID );
          }
       }
    }
   ptype_ = G_Param;
}


/*****************************************************************************************/
// convert to a new type specified by the first argument
//  zlst is the port impedance list that is only used for
//  conversions to S or T parameters
void NetworkParamSet::convert_to( e_param_type new_type )
{
   switch( new_type )
   {
      case S_Param:
         return convert_to_s();
      case T_Param:
         return convert_to_t();
      case Y_Param:
         return convert_to_y();
      case Z_Param:
         return convert_to_z();
      case ABCD_Param:
         return convert_to_abcd();
      case H_Param:
         return convert_to_h();
      case G_Param:
         return convert_to_g();
      default:
         throw NetworkParametersError( "NetworkParams:convert_to(): invalid type argument.", E_INVALID_TYPE );
   }
}

/*****************************************************************************************/

void NetworkParamSet::convert_to( const char* typestr )
{
    std::string ty( typestr );
    for( std::string::iterator i = ty.begin(); i!= ty.end(); ++i ) {
        if( *i >= 'A' && *i <= 'Z' ) *i += 'a' - 'A';
    }

    if( ty == "s" )
        return convert_to_s();
    else if( ty == "y" )
        return convert_to_y();
    else if( ty == "z" )
        return convert_to_z();
    else if( ty == "t" )
        return convert_to_t();
    else if( ty == "h" )
        return convert_to_h();
    else if( ty == "g" )
        return convert_to_g();
    else if( ty == "abcd" || ty == "chain" )
        return convert_to_abcd();
    else
        throw NetworkParametersError( "NetworkParams:convert_to(): invalid type string argument.", E_INVALID_TYPE );
}


/*****************************************************************************************/
/*****************************************************************************************/
/*                                 CONVERSION FUNCTIONS                                  */
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
// conversion of [S] to [Y]
matrix::CMatrix StoY_( const matrix::CMatrix& s, const matrix::CVector& zref )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun stoy(s, zRef)
   {
   decl z0 = if (zRef == NULL) then 50.0 else zRef;
   decl size_sx = size(s);         // s can be a scalar reflection coef.
   decl size_s = if (size_sx == 1) then {1,1} else size_sx;
   if (size(z0)==1 || size(z0)==size_s(1)) {
   decl identMat = identity(size_s(1));
   decl zref= identMat.*z0;
   decl gref=identMat.*(0.5./sqrt(abs(real(z0))));
   return inverse(gref)*inverse(s*zref+conj(zref))*(identMat-s)*gref;
   }
   print_function_error("stoy","Incompatible arguments");
   }
   */
   // note that zref, gref, inverse(gref), and identMat in the AEL code
   //  above are all diagonal matricies
   matrix::CMatrix ret(s.rows(),s.rows());

   if( s.rows() == 1 ) {
        ret(0,0) =  (ComplexOne-s(0,0)) / (s(0,0)*zref(0) + std::conj(zref(0)));
   }
   else if( s.rows() == 2 ) {
       double gr = sqrt(fabs(zref(0).real()/zref(1).real()));
       matrix::CMatrixT den = ComplexOne / ((s(0,0)*zref(0)+std::conj(zref(0)))*(s(1,1)*zref(1)+std::conj(zref(1))) - s(1,0)*s(0,1)*zref(0)*zref(1));
       matrix::CMatrixT y00 = zref(1)*(s(0,1)*s(1,0)+s(1,1)-s(0,0)*s(1,1)) + std::conj(zref(1))*(ComplexOne-s(0,0));
       matrix::CMatrixT y01 = -s(0,1)*(zref(1)+std::conj(zref(1)));
       matrix::CMatrixT y10 = -s(1,0)*(zref(0)+std::conj(zref(0)));
       matrix::CMatrixT y11 = zref(0)*(s(0,1)*s(1,0)+s(0,0)-s(0,0)*s(1,1)) + std::conj(zref(0))*(ComplexOne-s(1,1));
       ret(0,0) = y00 * den;
       ret(0,1) = y01 * den * gr;
       ret(1,0) = y10 * den / gr;
       ret(1,1) = y11 * den;
   }
   else if ( s.rows() > 2 ) {
        matrix::CMatrix tmp1;

       // this loop calculates: s*zref+conj(zref)
       for( size_t i=0; i<s.rows(); ++i ) {
          for( size_t j=0; j<s.cols(); ++j ) {
             ret(i,j) = s(i,j) * zref(j);
             if( i==j ) ret(i,j) += conj(zref(j));
          }
       }
       // compute the inverse(s*zref+conj(zref))
       tmp1 = matrix::invert(ret);
       // compute the rest of the expression
       for( size_t i=0; i<s.rows(); ++i ) {
          for( size_t j=0; j<s.cols(); ++j ) {
             ret(i,j) = ComplexZero;
             for( size_t k=0; k<s.cols(); ++k ) {
                // compute inverse(s*zref+conj(zref))*(identMat-s)
                //  tmp1 currently stores the value of inverse(s*zref+conj(zref))
                ret(i,j) += tmp1(i,k) * ((j==k?ComplexOne:ComplexZero) - s(k,j));
             }
             // compute the inverse(gref) pre-multiplier and gref post-multiplier
             //  it can be done this way because both multipliers are diagonal matrices
             if(i==j) ret(i,j) *= sqrt(fabs(zref(i).real()/zref(j).real()));
          }
       }
   }

   return ret;
}

/*****************************************************************************************/
// conversion of [S] to [Z]
matrix::CMatrix StoZ_( const matrix::CMatrix& s, const matrix::CVector& zref )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun stoz(s, zRef)
   {
   decl z0 = if (zRef == NULL) then 50.0 else zRef;
   decl size_sx = size(s);         // s can be a scalar reflection coef.
   decl size_s = if (size_sx == 1) then {1,1} else size_sx;
   if (size(z0)==1 || size(z0)==size_s(1)) {
   decl identMat = identity(size_s(1));
   decl zref= identMat.*z0;
   decl gref=identMat.*(0.5./sqrt(abs(real(z0))));
   decl retV = if (s == 1.0) then inverse(0.0) else (inverse(gref)*inverse(identMat-s)*(s*zref+conj(zref))*gref);
   return retV;
   }
   print_function_error("stoz","Incompatible arguments");
   }
    */
   // note that zref, gref, inverse(gref), and identMat in the AEL code
   //  above are all diagonal matricies
   matrix::CMatrix ret(s.rows(),s.rows());

   if( s.rows() == 1 ) {
        ret(0,0) = (s(0,0)*zref(0)+std::conj(zref(0))) / (ComplexOne-s(0,0));
   }
   else if( s.rows() == 2 ) {
       double gr = sqrt(fabs(zref(0).real()/zref(1).real()));
       matrix::CMatrixT den = ComplexOne / ((ComplexOne-s(0,0))*(ComplexOne-s(1,1)) - s(1,0)*s(0,1));
       matrix::CMatrixT z00 = (ComplexOne-s(1,1))*(s(0,0)*zref(0)+std::conj(zref(0))) + s(0,1)*s(1,0)*zref(0);
       matrix::CMatrixT z01 = s(0,1)*(zref(1)+std::conj(zref(1)));
       matrix::CMatrixT z10 = s(1,0)*(zref(0)+std::conj(zref(0)));
       matrix::CMatrixT z11 = (ComplexOne-s(0,0))*(s(1,1)*zref(1)+std::conj(zref(1))) + s(0,1)*s(1,0)*zref(1);
       ret(0,0) = z00 * den;
       ret(0,1) = z01 * den * gr;
       ret(1,0) = z10 * den / gr;
       ret(1,1) = z11 * den;
   }
   else if( s.rows() > 2 ) {
        matrix::CMatrix tmp1;
       // this loop calculates: identMat-s
       for( size_t i=0; i<s.rows(); ++i ) {
          for( size_t j=0; j<s.cols(); ++j ) {
             ret(i,j) = ((i==j?ComplexOne:ComplexZero) - s(i,j));
          }
       }
       // compute inverse(identMat-s)
       tmp1 = matrix::invert(ret);
       // compute the rest of the expression
       for( size_t i=0; i<s.rows(); ++i ) {
          for( size_t j=0; j<s.cols(); ++j ) {
             ret(i,j) = ComplexZero;
             for( size_t k=0; k<s.cols(); ++k ) {
                // compute inverse(identMat-s)*(s*zref+conj(zref))
                //  tmp1 currently stores the value of inverse(identMat-s)
                ret(i,j) += tmp1(i,k) * ( s(k,j) * zref(j) + (k==j?conj(zref(j)):ComplexZero) );
             }
             // compute the inverse(gref) pre-multiplier and gref post-multiplier
             //  it can be done this way because both multipliers are diagonal matrices
             if(i==j) ret(i,j) *= sqrt(fabs(zref(i).real()/zref(j).real()));
          }
       }
   }
   return ret;
}

/*****************************************************************************************/
// conversion of [S] to [T]
matrix::CMatrix StoT_( const matrix::CMatrix& s )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun stot(s)
   {
   decl aSMatSize = size(s);
   if (aSMatSize(1) == 2 && aSMatSize(2) == 2) {

   //Calculate the T-parameters
   decl T11 = (-s(1,1) * s(2,2) + s(1,2) * s(2,1))/s(2,1);
   decl T12 = s(1,1)/s(2,1);
   decl T21 = -s(2,2)/s(2,1);
   decl T22 = 1/s(2,1);

   //Construct and return the matrix
   return {{T11, T12}, {T21, T22}};
   } //if
   print_function_error("stot","Transformation is only available for 2-port scattering parameters");
   } //fun - stot
   */
   // the order here is very important!!!
   //  because s and t could be the same matrix...
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / s(1,0);
   ret(0,0) = s(0,1) - s(0,0)*s(1,1)*den;
   ret(0,1) = s(0,0) * den;
   ret(1,0) = -s(1,1) * den;
   ret(1,1) = den;
   return ret;
}

/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
// conversion of [Y] to [S]
matrix::CMatrix YtoS_( const matrix::CMatrix& y, const matrix::CVector& zref )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ytos(y,zRef)
   {
   decl z0 = if (zRef == NULL) then 50.0 else zRef;
   decl size_yx = size(y);       // y can be a scalar
   decl size_y = if (size_yx == 1) then {1,1} else size_yx;
   if (size(z0)==1 || size(z0)==size_y(1)) {
   decl identMat = identity(size_y(1));
   decl zref= identMat.*z0;
   decl gref=identMat.*(0.5./sqrt(abs(real(z0))));
   return gref*(identMat-conj(zref)*y)*inverse(identMat+zref*y)*inverse(gref);
   }
   print_function_error("ytos","Incompatible arguments");
   }
    */
   // create a reference to tmp that is the same dimension as s
   //  this makes the inversion step easier

   matrix::CMatrix ret(y.rows(),y.rows());

   if( y.rows() == 1 ) {
        ret(0,0) = (ComplexOne-std::conj(zref(0))*y(0,0)) / (ComplexOne+zref(0)*y(0,0));
   }
   else if( y.rows() == 2 ) {
       double gr = sqrt(fabs(zref(0).real()/zref(1).real()));
       matrix::CMatrixT den = ComplexOne / ((ComplexOne+y(0,0)*zref(0))*(ComplexOne+y(1,1)*zref(1)) - y(1,0)*y(0,1)*zref(0)*zref(1));
       matrix::CMatrixT s00 = (ComplexOne-std::conj(zref(0))*y(0,0))*(ComplexOne+zref(1)*y(1,1)) + y(0,1)*y(1,0)*std::conj(zref(0))*zref(1);
       matrix::CMatrixT s01 = -y(0,1) * (zref(0)+std::conj(zref(0)));
       matrix::CMatrixT s10 = -y(1,0) * (zref(1)+std::conj(zref(1)));
       matrix::CMatrixT s11 = (ComplexOne-std::conj(zref(1))*y(1,1))*(ComplexOne+zref(0)*y(0,0)) + y(0,1)*y(1,0)*std::conj(zref(1))*zref(0);
       ret(0,0) = s00 * den;
       ret(0,1) = s01 * den / gr;
       ret(1,0) = s10 * den * gr;
       ret(1,1) = s11 * den;
   }
   else if( y.rows() > 2 ) {
        matrix::CMatrix tmp1;
       // this loop calculates: identMat+zref*y
       for( size_t i=0; i<y.rows(); ++i ) {
          for( size_t j=0; j<y.cols(); ++j ) {
             ret(i,j) = y(i,j) * zref(i);
             if( i==j ) ret(i,j) += ComplexOne;
          }
       }
       // compute the inverse(identMat+zref*y)
       //  tmp2 is a passed scratch buffer to reduce the need for
       //  heap memory allocation in the inversion function
       tmp1 = matrix::invert(ret);
       // compute the rest of the expression
       for( size_t i=0; i<y.rows(); ++i ) {
          for( size_t j=0; j<y.cols(); ++j ) {
             ret(i,j) = ComplexZero;
             for( size_t k=0; k<y.cols(); ++k ) {
                // compute (identMat-conj(zref)*y)*inverse(identMat+zref*y)
                //  tmp1 currently stores the value of inverse(identMat+zref*y)
                ret(i,j) += ((i==k?ComplexOne:ComplexZero) - std::conj(zref(i))*y(i,k)) * tmp1(k,j);
             }
             // compute the gref pre-multiplier and inverse(gref) post-multiplier
             //  it can be done this way because both multipliers are diagonal matrices
             if(i==j) ret(i,j) *= sqrt(fabs(zref(j).real()/zref(i).real()));
          }
       }
   }
   return ret;
}

/*****************************************************************************************/
// conversion of [Y] to [Z]
matrix::CMatrix YtoZ_( const matrix::CMatrix& y )
{
   return matrix::invert(y);
}

/*****************************************************************************************/
// conversion of [Y] to [H]
matrix::CMatrix YtoH_( const matrix::CMatrix& y )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ytoh(y)
   {
   decl size_y = size(y);
   if ( size_y(1) == 2 && size_y(2) == 2 )
   {
   decl h11 = 1.0/y(1,1);
   decl h12 = -1.0*y(1,2)/y(1,1);
   decl h21 = 1.0*y(2,1)/y(1,1);
   decl h22 = 1.0*(y(1,1)*y(2,2)-y(2,1)*y(1,2))/y(1,1);
   return {{h11,h12},{h21,h22}};
   }
   print_function_error("ytoh","Transformation is only available for 2-port admittance parameters");
   }
   */
   // order is important
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / y(0,0);
   ret(0,0) = den;
   ret(0,1) = -y(0,1) * den;
   ret(1,0) = y(1,0) * den;
   ret(1,1) = y(1,1) - y(0,1)*y(1,0)*den;
   return ret;
}

/*****************************************************************************************/
// conversion of [Y] to [ABCD]
matrix::CMatrix YtoABCD_( const matrix::CMatrix& y )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ytoabcd(y)
   {
   decl size_y = size(y);
   if ( size_y(1) == 2 && size_y(2) == 2 )
   {
   decl a = -1.0*y(2,2)/y(2,1);
   decl b = -1.0/y(2,1);
   decl c = -1.0*(y(1,1)*y(2,2)-y(2,1)*y(1,2))/y(2,1);
   decl d = -1.0*y(1,1)/y(2,1);
   return {{a,b},{c,d}};
   }
   print_function_error("ytoabcd","Transformation is only available for 2-port admittance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = -ComplexOne / y(1,0);
   ret(0,0) = y(1,1) * den;
   ret(0,1) = den;
   ret(1,0) = y(0,0)*y(1,1)*den + y(0,1);
   ret(1,1) = y(0,0) * den;
   return ret;
}

/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
// conversion of [Z] to [S]
matrix::CMatrix ZtoS_( const matrix::CMatrix& z, const matrix::CVector& zref )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ztos(z,zRef)
   {
   decl z0 = if (zRef == NULL) then 50.0 else zRef;
   decl size_zx = size(z);       // z can be a scalar
   decl size_z = if (size_zx == 1) then {1,1} else size_zx;
   if (size(z0)==1 || size(z0)==size_z(1)) {
   decl identMat = identity(size_z(1));
   decl zref= identMat.*z0;
   decl gref=identMat.*(0.5./sqrt(abs(real(z0))));
   return gref*(z-conj(zref))*inverse(z+zref)*inverse(gref);
   }
   print_function_error("ztos","Incompatible arguments");
   }
   */

   matrix::CMatrix ret(z.rows(),z.rows());

   if( z.rows() == 1 ) {
        ret(0,0) = (z(0,0)-std::conj(zref(0))) / (z(0,0)+zref(0));
   }
   else if( z.rows() == 2 ) {
       double gr = sqrt(fabs(zref(0).real()/zref(1).real()));
       matrix::CMatrixT den = ComplexOne / ((z(0,0)+zref(0))*(z(1,1)+zref(1)) - z(1,0)*z(0,1));
       matrix::CMatrixT s00 = (z(0,0)-std::conj(zref(0)))*(z(1,1)+zref(1)) - z(1,0)*z(0,1);
       matrix::CMatrixT s01 = z(0,1)*(zref(0)+std::conj(zref(0)));
       matrix::CMatrixT s10 = z(1,0)*(zref(1)+std::conj(zref(1)));
       matrix::CMatrixT s11 = (z(1,1)-std::conj(zref(1)))*(z(0,0)+zref(0)) - z(1,0)*z(0,1);
       ret(0,0) = s00 * den;
       ret(0,1) = s01 * den / gr;
       ret(1,0) = s10 * den * gr;
       ret(1,1) = s11 * den;
   }
   else {
       matrix::CMatrix tmp1;
       // this loop calculates: z+zref
       for( size_t i=0; i<z.rows(); ++i ) {
          for( size_t j=0; j<z.cols(); ++j ) {
             ret(i,j) = z(i,j);
             if( i==j ) ret(i,j) += zref(i);
          }
       }
       // compute the inverse(z+zref)
       tmp1 = matrix::invert(ret);
       // compute the rest of the expression
       for( size_t i=0; i<z.rows(); ++i ) {
          for( size_t j=0; j<z.cols(); ++j ) {
             ret(i,j) = ComplexZero;
             for( size_t k=0; k<z.cols(); ++k ) {
                // compute (z-conj(zref))*inverse(z+zref)
                //  tmp1 currently stores the value of inverse(z+zref)
                ret(i,j) += (z(i,k) - (i==k?std::conj(zref(i)):ComplexZero)) * tmp1(k,j);
             }
             // compute the gref pre-multiplier and inverse(gref) post-multiplier
             //  it can be done this way because both multipliers are diagonal matrices
             if(i==j) ret(i,j) *= sqrt(fabs(zref(j).real()/zref(i).real()));
          }
       }
   }
   return ret;
}

/*****************************************************************************************/
// conversion of [Z] to [Y]
matrix::CMatrix ZtoY_( const matrix::CMatrix& z )
{
   return matrix::invert(z);
}

/*****************************************************************************************/
// conversion of [Z] to [H]
matrix::CMatrix ZtoH_( const matrix::CMatrix& z )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ztoh(z)
   {
   decl size_z = size(z);
   if ( size_z(1) == 2 && size_z(2) == 2 )
   {
   decl h11 = 1.0*(z(1,1)*z(2,2) - z(2,1)*z(1,2))/z(2,2);
   decl h12 = 1.0*z(1,2)/z(2,2);
   decl h21 = -1.0*z(2,1)/z(2,2);
   decl h22 = 1.0/z(2,2);
   return {{h11,h12},{h21,h22}};
   }
   print_function_error("ztoh","Transformation is only available for 2-port impedance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / z(1,1);
   ret(0,0) = z(0,0) - z(0,1)*z(1,0)*den;
   ret(0,1) = z(0,1) * den;
   ret(1,0) = -z(1,0) * den;
   ret(1,1) = den;
   return ret;
}

/*****************************************************************************************/
// conversion of [Z] to [ABCD]
matrix::CMatrix ZtoABCD_( const matrix::CMatrix& z )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ztoabcd(z)
   {
   decl size_z = size(z);
   if ( size_z(1) == 2 && size_z(2) == 2 )
   {
      decl a = 1.0*z(1,1)/z(2,1);
      decl b = 1.0*(z(1,1)*z(2,2)-z(2,1)*z(1,2))/z(2,1);
      decl c = 1.0/z(2,1);
      decl d = 1.0*z(2,2)/z(2,1);
      return {{a,b},{c,d}};
   }
   print_function_error("ztoabcd","Transformation is only available for 2-port impedance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / z(1,0);
   ret(0,0) = z(0,0) * den;
   ret(0,1) = z(0,0)*z(1,1)*den - z(0,1);
   ret(1,0) = den;
   ret(1,1) = z(1,1) * den;
   return ret;
}

/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
// conversion of [H] to [Z]
matrix::CMatrix HtoZ_( const matrix::CMatrix& h )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun htoz(h)
   {
   decl size_h = size(h);
   if ( size_h(1) == 2 && size_h(2) == 2 )
   {
   decl z11 = 1.0*(h(1,1)*h(2,2)-h(2,1)*h(1,2))/h(2,2);
   decl z12 = 1.0*h(1,2)/h(2,2);
   decl z21 = -1.0*h(2,1)/h(2,2);
   decl z22 = 1.0/h(2,2);
   return {{z11,z12},{z21,z22}};
   }
   print_function_error("htoz","Transformation is only available for 2-port impedance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / h(1,1);
   ret(0,0) = h(0,0) - h(0,1)*h(1,0)*den;
   ret(0,1) = h(0,1) * den;
   ret(1,0) = -h(1,0) * den;
   ret(1,1) = den;
   return ret;
}

/*****************************************************************************************/
// conversion of [H] to [Y]
matrix::CMatrix HtoY_( const matrix::CMatrix& h )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun htoy(h)
   {
   decl size_h = size(h);
   if ( size_h(1) == 2 && size_h(2) == 2 )
   {
   decl y11 = 1.0/h(1,1);
   decl y12 = -1.0*h(1,2)/h(1,1);
   decl y21 = 1.0*h(2,1)/h(1,1);
   decl y22 = 1.0*(h(1,1)*h(2,2)-h(2,1)*h(1,2))/h(1,1);
   return {{y11,y12},{y21,y22}};
   }
   print_function_error("htoy","Transformation is only available for 2-port admittance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / h(0,0);
   ret(0,0) = den;
   ret(0,1) = -h(0,1) * den;
   ret(1,0) = h(1,0) * den;
   ret(1,1) = h(1,1) - h(0,1)*h(1,0)*den;
   return ret;
}


/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/

/*****************************************************************************************/
// conversion of [ABCD] to [Z]
matrix::CMatrix ABCDtoZ_( const matrix::CMatrix& abcd )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun abcdtoz(a)
   {
   decl size_a = size(a);
   if ( size_a(1) == 2 && size_a(2) == 2 )
   {
   decl z11 = 1.0*a(1,1)/a(2,1);
   decl z12 = 1.0*(a(1,1)*a(2,2)-a(2,1)*a(1,2))/a(2,1);
   decl z21 = 1.0/a(2,1);
   decl z22 = 1.0*a(2,2)/a(2,1);
   return {{z11,z12},{z21,z22}};
   }
   print_function_error("abcdtoz","Transformation is only available for 2-port impedance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / abcd(1,0);
   ret(0,0) = abcd(0,0) * den;
   ret(0,1) = abcd(0,0)*abcd(1,1)*den - abcd(0,1);
   ret(1,0) = den;
   ret(1,1) = abcd(1,1) * den;
   return ret;
}

/*****************************************************************************************/
// conversion of [ABCD] to [Y]
matrix::CMatrix ABCDtoY_( const matrix::CMatrix& abcd )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun abcdtoy(a)
   {
   decl size_a = size(a);
   if ( size_a(1) == 2 && size_a(2) == 2 )
   {
   decl y11 = 1.0*a(2,2)/a(1,2);
   decl y12 = -1.0*(a(1,1)*a(2,2)-a(2,1)*a(1,2))/a(1,2);
   decl y21 = -1.0/a(1,2);
   decl y22 = 1.0*a(1,1)/a(1,2);
   return {{y11,y12},{y21,y22}};
   }
   print_function_error("abcdtoy","Transformation is only available for 2-port admittance parameters");
   }
   */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / abcd(0,1);
   ret(0,0) = abcd(1,1) * den;
   ret(0,1) = abcd(1,0) - abcd(0,0)*abcd(1,1)*den;
   ret(1,0) = -den;
   ret(1,1) = abcd(0,0) * den;
   return ret;
}

/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
// conversion of [T] to [S]
matrix::CMatrix TtoS_( const matrix::CMatrix& t )
{
   /*  Agilent ADS AEL code: from network_fun.ael
   defun ttos(T)
   {
   decl aTMatSize = size(T);
   if (aTMatSize(1) == 2 && aTMatSize(2) == 2) {

   //Calculate the S-parameters
   decl S11 = T(1,2) / T(2,2);
   decl S12 = T(1,1) - (T(1,2) * T(2,1))/T(2,2);
   decl S21 = 1/T(2,2);
   decl S22 = -T(2,1)/T(2,2);

   //Construct and return the matrix
   return {{S11, S12}, {S21, S22}};
   } //if
   print_function_error("ttos","Transformation is only available for 2-port scattering parameters");
   } //fun - ttos
    */
   // the order here is very important!!!
   //  because t and s could be the same matrix...
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / t(1,1);
   ret(0,0) = t(0,1) * den;
   ret(0,1) = t(0,0) - t(0,1)*t(1,0) * den;
   ret(1,0) = den;
   ret(1,1) = -t(1,0) * den;
   return ret;
}

/*****************************************************************************************/

matrix::CMatrix YtoG_( const matrix::CMatrix& y )
{
    /* derived this myself - JB */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / y(1,1);
   ret(0,0) = y(0,0) - y(0,1)*y(1,0)*den;
   ret(0,1) = y(0,1)*den;
   ret(1,0) = -y(1,0)*den;
   ret(1,1) = den;
   return ret;
}

/*****************************************************************************************/

matrix::CMatrix ZtoG_( const matrix::CMatrix& z )
{
    /* derived this myself - JB */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / z(0,0);
   ret(0,0) = den;
   ret(0,1) = -z(0,1)*den;
   ret(1,0) = z(1,0)*den;
   ret(1,1) = z(1,1) - z(0,1)*z(1,0)*den;
   return ret;
}

/*****************************************************************************************/

matrix::CMatrix GtoY_( const matrix::CMatrix& g )
{
    /* derived this myself - JB */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / g(1,1);
   ret(0,0) = g(0,0) - g(0,1)*g(1,0)*den;
   ret(0,1) = g(0,1)*den;
   ret(1,0) = -g(1,0)*den;
   ret(1,1) = den;
   return ret;
}

/*****************************************************************************************/

matrix::CMatrix GtoZ_( const matrix::CMatrix& g )
{
    /* derived this myself - JB */
   matrix::CMatrix ret(2,2);
   matrix::CMatrixT den = ComplexOne / g(0,0);
   ret(0,0) = den;
   ret(0,1) = -g(0,1)*den;
   ret(1,0) = g(1,0)*den;
   ret(1,1) = g(1,1) - g(1,0)*g(0,1)*den;
   return ret;
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

void compute_k_and_mag( const matrix::CMatrix& sp, double& k, double& MAG )
{
    if( sp.rows() != 2 || sp.cols() != 2 ) throw NetworkParametersError( "compute_k_and_mag(): matrix must be 2x2.", E_INVALID_ARGUMENT );
    double s11m2 = (sp(0,0) * std::conj(sp(0,0))).real();
    double s22m2 = (sp(1,1) * std::conj(sp(1,1))).real();
    std::complex<double> tc = sp(0,0)*sp(1,1) - sp(0,1)*sp(1,0);
    double delm2 = (tc * std::conj(tc)).real();
    double b = 1. + s11m2 - s22m2 - delm2;
    double td = 2. * std::abs( sp(0,1) * sp(1,0) );;

    if( td < 1.e-30 ) td = 1.e-30;

    k = (1. - s11m2 - s22m2 + delm2) / td;

    td = std::abs(sp(0,1));
    if( td < 1.0e-30 ) td = 1.0e-30;

    MAG = std::abs(sp(1,0)) / td;

    if( k > 1. )
        MAG *= (b < 0.) ? (k + sqrt( k*k - 1. )) : (k - sqrt( k*k - 1. ));
}


