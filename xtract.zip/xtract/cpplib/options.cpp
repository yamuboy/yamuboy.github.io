#include "options.hpp"
#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <stdlib.h>

#ifdef WIN32
static const char dir_delim = '\\';
#else
static const char dir_delim = '/';
#endif

static const std::string ws_chars = " \t\n\r";
static const std::string arg_start_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
static const std::string arg_name_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-0123456789";

/*****************************************************************************/
bool default_option_help_cb( OptionSet* options, const std::string& name, std::string& val )
{
    // name should be equal to "help" and
    //  val should be either "cl", "file", or "all"

    if( name != "help" ) {
        std::cerr << "default_option_help_cb(): called with invalid \'name\' parameter." << std::endl;
    }
    else if( val == "cl" ) {
        std::cout << "Command-line help:" << std::endl
            << "================================================================================" << std::endl;
        std::cout << options->getHelpCL();
        std::cout << std::endl;
    }
    else if( val == "file" ) {
        std::cout << "Option file help:" << std::endl
            << "================================================================================" << std::endl;
        std::cout << options->getHelpFile();
        std::cout << std::endl;
    }
    else if( val == "all" || val == "" || val == "1" ) {
        std::cout << "Command-line help:" << std::endl
            << "================================================================================" << std::endl;
        std::cout << options->getHelpCL();
        std::cout << std::endl << std::endl;
        std::cout << "Option file help:" << std::endl
            << "================================================================================" << std::endl;
        std::cout << options->getHelpFile();
        std::cout << std::endl;
    }
    else {
        std::cout << "No help available for topic \'" << val << "\'." << std::endl;
    }

    // exit the program
    exit(0);
}

/*****************************************************************************/
OptionSet::PatternList OptionSet::split_pattern( const std::string& pat ) const
{
    PatternList lst;
    std::string sub;
    std::string remain = pat;
    std::string::iterator fwd;
    size_t pos;
    while( remain.length() ) {
        pos = remain.find( '|' );
        sub = remain.substr(0,pos);
        if( pos != std::string::npos ) {
            remain = remain.substr(pos);
            remain.erase( remain.begin() );
        }
        else remain = "";
        // remove leading and trailing whitespace
        for( fwd = sub.begin(); fwd != sub.end() && ws_chars.find( *fwd ) != std::string::npos; )
            sub.erase( fwd );
        for( fwd = --(sub.end()); fwd != sub.begin() && ws_chars.find( *fwd ) != std::string::npos; )
            sub.erase( fwd-- );
        // push the pattern onto the list
        if( sub.length() ) lst.push_back( sub );
    }
    return lst;
}

/*****************************************************************************/
bool OptionSet::get_option( const std::string& name, std::string& val ) const
{
    OptionPairs::const_iterator i = pairs_.find( name );
    if( i != pairs_.end() ) {
        val = i->second;
        return true;
    }
    return false;
}

/*****************************************************************************/
bool OptionSet::processBoolean( const std::string& val ) const
{
    if( val == "0" || !val.length() || val[0] == 'n' || val[0] == 'N' || val[0] == 'f' || val[0] == 'F' || val[0] == '0' ) return false;
    return true;
}

/*****************************************************************************/
void OptionSet::processOption( const OptionDef& def, const std::string& val )
{
    std::string val2( val );
    // verify the parameter by type
    //  and process any special attributes (such as negation)
    if( def.option_type == option_boolean ) {
        val2 = processBoolean(val) ? "1" : "0";
    }
    else if( def.option_type == option_negative_boolean ) {
        val2 = processBoolean(val) ? "0" : "1";
    }
    // other cases to verify???

    if( def.callback != 0 ) {
        if( ! def.callback( this, def.unique_name, val2 ) ) return;
    }

    pairs_[def.unique_name] = val2;
}

/*****************************************************************************/
void OptionSet::addDef( const OptionDef& opt )
{
    defs_.push_back(opt);
}

/*****************************************************************************/
void OptionSet::addDef( const OptionDef* opt, int n_opts )
{
    for( int i=0; i<n_opts; ++i )
        defs_.push_back(opt[i]);
}

/*****************************************************************************/
void OptionSet::set( const std::string& unique_name, const std::string& value )
{
    pairs_[unique_name] = value;
}

/*****************************************************************************/
void OptionSet::processCL( int& argc, char** argv, bool remove_recognized )
{
    int i;
    std::string arg, val;
    PatternList lst;
    PatternList::iterator pati;
    std::string::iterator ia, ip;
    std::list<int> toremove;
    bool verbose = asBoolean("OptionsVerbose");
    bool debug = asBoolean("OptionsDebug");
    bool warnings = asBoolean("OptionsPrintWarnings");
    bool warning_as_err = asBoolean("OptionsWarningsAsErrors");
    bool match;
    bool found;
    for( i=1; i<argc; ++i ) {
        arg = argv[i];
        if( debug ) std::cout << "Processing: " << arg << std::endl;
        if( *arg.begin() == '@' ) {
            // special pattern to recognize option files to be parsed
            processFile( arg.substr(1), 0, true );
            toremove.push_back(i);
            continue;
        }
        else if( *arg.begin() != '-' ) continue;  // args must start with a hyphen
        // iterate through the option definitions
        found=false;
        for( OptionDefList::iterator d = defs_.begin(); d != defs_.end(); ++d ) {
            // split the command line options string at the | characters and process each
            if( debug ) std::cout << "  " << arg << " -> " << d->unique_name << std::endl;
            lst = split_pattern( d->cl_patterns );
            for( pati = lst.begin(); pati != lst.end(); ++pati ) {
                if( debug ) std::cout << "    " << *pati << std::endl;
                // process the pattern
                //  skip patterns that do not start with a hyphen
                if( *pati->begin() != '-' ) continue;
                ia = arg.begin();
                ip = pati->begin();
                match = true;
                for( ; ip != pati->end(); ++ia, ++ip ) {
                    if( ia == arg.end() ) {
                        // end of the argument string
                        //  handle two special cases:
                        if( ws_chars.find( *ip ) != std::string::npos ) {
                            // encountered pattern whitespace
                            //  check that the rest of the pattern is valid
                            //  it can ONLY consist of more whitespace and a single '?' character
                            while( ip != pati->end() && ws_chars.find( *ip ) != std::string::npos ) ++ip;
                            if( ip == pati->end() || *ip != '?' ) {
                                // this is an error
                                if( debug || verbose || warnings ) std::cout << "OptionSet::processCL(): illegal pattern: " << *pati << std::endl;
                                throw OptionError( (std::string("OptionSet::processCL(): illegal pattern: ") + *pati).c_str() );
                            }
                            // pattern is valid
                            //  make sure there is another argument
                            if( ++i == argc || argv[i][0] == '-' ) {
                                // matches, but with no data
                                --i;
                                processOption( *d, "" );
                                toremove.push_back(i);
                                if( debug || verbose || warnings ) std::cerr << "Warning: OptionSet::processCL(): expected argument after: " << argv[i-1] << std::endl;
                                if( warning_as_err ) throw OptionError( std::string("OptionSet::processCL(): expected argument after: ") + argv[i-1] );
                            }
                            arg = argv[i];
                            // everything ok
                            if( debug ) std::cout << "  Pattern Match: " << d->unique_name << " = " << arg << std::endl;
                            processOption( *d, arg );
                            toremove.push_back(i-1);
                            toremove.push_back(i);
                            found=true;
                        }
                        else if( *ip == '?' ) {
                            // pattern matches, but data is an empty string
                            //  store an empty string for the option value
                            processOption( *d, "" );
                            toremove.push_back(i);
                            if( debug ) std::cout << "  Pattern Match: " << d->unique_name << " = <nothing>" << std::endl;
                            found=true;
                        }
                        // otherwise, the pattern doesn't match
                        // just break out of the loop
                        match=false;
                        break;
                    }

                    else if( *ip == '?' ) {
                        // pattern matched
                        //  now grab whatever is left of the argument
                        val = "";
                        for( ; ia != arg.end(); ++ia )
                            val += *ia;
                        // do any special processing
                        processOption( *d, val );
                        toremove.push_back(i);
                        // set match to false so that processing doesn't occur
                        //  after this loop
                        if( debug ) std::cout << "  Pattern Match: " << d->unique_name << " = " << val << std::endl;
                        found=true;
                        match=false;
                        break;
                    }
                    else if( *ia != *ip ) {
                        // non-matching pattern
                        match = false;
                        break;
                    }
                    else if( ws_chars.find( *ip ) != std::string::npos ) {
                        // non-matching pattern
                        match = false;
                        break;
                    }
                }

                if( match ) {
                    // this is a match to a pattern that has no value (no '?')
                    //  the pattern must be boolean, so set the pattern
                    //  value to 1
                    processOption( *d, "1" );
                    toremove.push_back(i);
                    if( debug ) std::cout << "  Pattern Match: " << d->unique_name << " = True" << std::endl;
                    found = true;
                }
                if( found ) break;
            }
            if( found ) break;
        }
    }
    // remove arguments from the argument list
    if( remove_recognized ) {
        std::list<int>::iterator rmi = toremove.end();
        --rmi;
        for( i=argc-1; i>0; --i ) {
            if( i == *rmi ) {
                toremove.erase( rmi );
                --rmi;
                for( int j=i+1; j<argc; ++j )
                    argv[j-1] = argv[j];
                --argc;
            }
        }
    }
}

/*****************************************************************************/
void OptionSet::processFile( const std::string& fname, int parent_dirs, bool err_not_found )
{
    std::ifstream is( fname.c_str() );
    std::string line, arg, val, fn = fname;
    size_t p;
    PatternList lst;
    PatternList::iterator pati;
    std::string::iterator fwd;
    bool found;
    bool debug = asBoolean("OptionsDebug");
    bool verbose = asBoolean("OptionsVerbose");
    bool warnings = asBoolean("OptionsPrintWarnings");
    bool warning_as_err = asBoolean("OptionsWarningsAsErrors");
    size_t lineno = 0;

    if( debug ) std::cout << "Process File: \'" << fn << "\' Search levels: " << parent_dirs << std::endl;

    if( !is.is_open() && fn.length() && *fn.begin() != '/' && (fn.length() < 2 || fn[1] != ':') ) {
        for( int i=0; i<parent_dirs; ++i ) {
            fn = (std::string("..") + dir_delim) + fn;
            is.open( fn.c_str() );
            if( is.is_open() ) break;
        }
    }

    if( is.is_open() ) {
         if( debug || verbose ) std::cout << "Reading options from \'" << fn << "\'" << std::endl;
    }
    else {
        if( verbose || debug ) std::cout << "Warning: options file \'" << fname << "\' not found" << std::endl;
        if( err_not_found || warning_as_err )
            throw OptionError( std::string("OptionSet::processFile(): file not found: ") + fname );
        return;
    }

    // process the file
    while( ! is.eof() ) {
        std::getline( is, line );
        if( debug ) std::cout << "line(" << lineno << "): " << line;
        ++lineno;
        // remove commented out parts of the line
        p = line.find('#');
        if( p != std::string::npos )
            line = line.substr( 0, p );
        // see if the line contains an '=' sign
        p = line.find('=');
        if( p != std::string::npos ) {
            arg = line.substr( 0, p );
            val = line.substr(p);
            val.erase( val.begin() );
        }
        else {
            arg = line;
            val = "";
        }

        // remove trailing whitespace from the argument name
        for( fwd = --(arg.end()); fwd != arg.begin() && ws_chars.find( *fwd ) != std::string::npos; )
            arg.erase( fwd-- );

        // remove leading and trailing whitespace from the value
        for( fwd = val.begin(); fwd != val.end() && ws_chars.find( *fwd ) != std::string::npos; )
            val.erase( fwd );
        for( fwd = --(val.end()); fwd != val.begin() && ws_chars.find( *fwd ) != std::string::npos; )
            val.erase( fwd-- );

        if( ! arg.length() ) {
            if( debug ) std::cout << "  `- skipping" << std::endl;
            continue;  // blank line
        }

        // verify that the argument name is valid
        if( arg_start_chars.find( *arg.begin() ) == std::string::npos ||
            arg.find_first_not_of( arg_name_chars ) != std::string::npos ) {
            // illegal starting character
            if( debug || verbose || warnings ) std::cout << "Warning: " << fn << ": line " << lineno << ": illegal argument name: " << arg << std::endl;
            if( warning_as_err ) {
                std::ostringstream ss;
                ss << "Error: " << fn << ": line " << lineno << ": illegal argumemt name: " << arg;
                throw OptionError( ss.str() );
            }
            continue;
        }

        if( debug ) std::cout << "  " << arg << " = \'" << val << "\'" << std::endl;

        // search for the argument in the option definitions
        found = false;
        for( OptionDefList::iterator d = defs_.begin(); d != defs_.end(); ++d ) {
            // split the command line options string at the | characters and process each
            lst = split_pattern( d->names_in_file );
            for( pati = lst.begin(); pati != lst.end(); ++pati ) {
                if( debug ) std::cout << "    " << *pati << std::endl;
                if( arg == *pati ) {
                    processOption( *d, val );
                    found=true;
                    if( debug ) std::cout << "    File Pattern Match: " << d->unique_name << " = \'" << val << "\'" << std::endl;
                    break;
                }
            }
            if( found ) break;
        }
    }
    if( debug ) std::cout << "Finished processing file." << std::endl;
}

/*****************************************************************************/
double OptionSet::asDouble( const std::string& name, double def ) const
{
    std::string str;
    double val;
    if( get_option(name,str) ) {
        std::istringstream ss( str );
        ss >> val;
        if( !ss.fail() ) return val;
        else return def;
    }
    else return def;
}

/*****************************************************************************/
std::string OptionSet::asString( const std::string& name, const std::string& def ) const
{
    std::string str;
    if( get_option(name, str) ) return str;
    else return def;
}

/*****************************************************************************/
bool OptionSet::asBoolean( const std::string& name, bool def ) const
{
    std::string str;
    if( get_option( name, str ) ) return processBoolean( str );
    return def;
}

/*****************************************************************************/
bool OptionSet::asBool( const std::string& name, bool def ) const
{
    return asBoolean( name, def );
}

/*****************************************************************************/
int OptionSet::asInt( const std::string& name, int def ) const
{
    std::string str;
    int val;
    if( get_option( name, str ) ) {
        std::istringstream ss( str );
        ss >> val;
        if( !ss.fail() ) return val;
        else return def;
    }
    return def;
}

/*****************************************************************************/
unsigned int OptionSet::asUnsigned( const std::string& name, unsigned int def ) const
{
    std::string str;
    unsigned int val;
    if( get_option( name, str ) ) {
        std::istringstream ss( str );
        ss >> val;
        if( !ss.fail() ) return val;
        else return def;
    }
    return def;
}

/*****************************************************************************/
std::vector<std::string> word_wrap( const std::string& desc, size_t w )
{
    std::vector<std::string> ret;
    std::string s;

    if( w < 20 ) return ret;

    for( std::string::const_iterator i = desc.begin(); i != desc.end(); ++i ) {
        if( *i == '\n' ) {
            ret.push_back(s);
            s = "";
        }
        else if( *i == '\r' ) continue;
        else if( *i == '\t' ) s += " ";
        else s += *i;

        if( s.length() > w ) {
            // find a good "splitting" point
            for( size_t p = s.length() - 3; p > 0; --p ) {
                if( s[p] == '-' ) {
                    ret.push_back(s.substr(0,++p));
                    s = s.substr(p);
                    break;
                }
                else if( s[p] == ' ' ) {
                    ret.push_back(s.substr(0,p));
                    s = s.substr(++p);
                    break;
                }
            }
        }

    }
    if( s.length() ) ret.push_back(s);

    return ret;
}



/*****************************************************************************/
std::string OptionSet::getHelpCL() const
{
    std::ostringstream os;
    PatternList lst;
    size_t longest=0;
    int total_w = 80;
    int optw, desc_w;
    std::vector<std::string> desc;

    os.setf( std::ios_base::left, std::ios_base::adjustfield );

    // find the longest command-line option string
    for( OptionDefList::const_iterator d = defs_.begin(); d != defs_.end(); ++d ) {
        // split the command line options string
        if( ! d->cl_patterns.length() ) continue;
        lst = split_pattern( d->cl_patterns );
        for( PatternList::iterator i = lst.begin(); i!=lst.end(); ++i ) {
            // find the longest one
            if( i->length() > longest ) longest = i->length();
        }
    }

    if( !longest ) {
        return std::string( "No command-line options are available." );
    }

    // print the options to the string
    optw = longest + 5;
    desc_w = total_w - optw;
    for( OptionDefList::const_iterator d = defs_.begin(); d != defs_.end(); ++d ) {
        // split the command line options string
        if( ! d->cl_patterns.length() ) continue;
        lst = split_pattern( d->cl_patterns );
        for( PatternList::iterator i = lst.begin(); i!=lst.end(); ++i ) {
            // print each option
            if( i != lst.begin() ) os << "\n";
            os << "   " << std::setw(longest) << *i << std::setw(0) << "  ";
        }

        // split the description into multiple lines as necessary
        //  then print each line, indenting as necessary
        desc = word_wrap( d->description, desc_w );
        for( std::vector<std::string>::iterator i = desc.begin(); i != desc.end(); ++i ) {
            if( i != desc.begin() ) os << std::setw(optw) << " " << std::setw(0);
            os << *i << "\n";
        }
        os << "\n";
    }

    return os.str();
}

/*****************************************************************************/
std::string OptionSet::getHelpFile() const
{
    std::ostringstream os;
    PatternList lst;
    size_t longest=0;
    int total_w = 80;
    int optw, desc_w;
    std::vector<std::string> desc;

    os.setf( std::ios_base::left, std::ios_base::adjustfield );

    // find the longest command-line option string
    for( OptionDefList::const_iterator d = defs_.begin(); d != defs_.end(); ++d ) {
        // split the command line options string
        if( ! d->names_in_file.length() ) continue;
        lst = split_pattern( d->names_in_file );
        for( PatternList::iterator i = lst.begin(); i!=lst.end(); ++i ) {
            // find the longest one
            if( i->length() > longest ) longest = i->length();
        }
    }

    if( !longest ) {
        return std::string( "No file-based options are available." );
    }

    // print the options to the string
    optw = longest + 5;
    desc_w = total_w - optw;
    for( OptionDefList::const_iterator d = defs_.begin(); d != defs_.end(); ++d ) {
        // split the command line options string
        if( ! d->names_in_file.length() ) continue;
        lst = split_pattern( d->names_in_file );
        for( PatternList::iterator i = lst.begin(); i!=lst.end(); ++i ) {
            // print each option
            if( i != lst.begin() ) os << "\n";
            os << "   " << std::setw(longest) << *i << std::setw(0) << "  ";
        }

        // split the description into multiple lines as necessary
        //  then print each line, indenting as necessary
        desc = word_wrap( d->description, desc_w );
        for( std::vector<std::string>::iterator i = desc.begin(); i != desc.end(); ++i ) {
            if( i != desc.begin() ) os << std::setw(optw) << " " << std::setw(0);
            os << *i << "\n";
        }
        os << "\n";
    }

    return os.str();
}

/*****************************************************************************/
OptionSet::OptionSet() : helpcb_(default_option_help_cb)
{
    // create some default OptionDefs
    addDef( OptionDef( "help",
        "-h ?|--help=?|--help",
        "",
        option_any,
        "Built-in help. The optional argument is the help topic.",
        helpcb_ ) );




}
