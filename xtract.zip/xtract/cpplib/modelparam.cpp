#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include "modelparam.hpp"

const ModelParam::flgtype ModelParam::fixed = 1<<0;        // value cannot be modified/optimized
const ModelParam::flgtype ModelParam::positive = 1<<1;     // value must be >= 0
const ModelParam::flgtype ModelParam::negative = 1<<2;     // value must be <= 0


/********************************************************************************/
void ModelParamSet::push( const ModelParam& p, letter_case c )
{
    std::string n = p.getName();

    if( !n.length() )
        throw ModelParamException( "ModelParamSet::push(): ModelParam objects must be named." );

    switch(c) {
    case upper_case:
        for( std::string::iterator i = n.begin(); i != n.end(); ++i )
            if( *i >= 'a' && *i <= 'z' ) *i -= ('a' - 'A');
        break;
    case lower_case:
        for( std::string::iterator i = n.begin(); i != n.end(); ++i )
            if( *i >= 'A' && *i <= 'Z' ) *i += ('a' - 'A');
        break;
    case default_case:
    default:
        break;
    }

    parms_[n] = p;
    order_.push_back( n );
}

/********************************************************************************/
void ModelParamSet::merge( const ModelParamSet& pset, bool overwrite )
{
    ModelParamSet::iterator m;
    for( ModelParamSet::const_iterator i = pset.begin(); i != pset.end(); ++i ) {
        if( !overwrite ) {
            m = parms_.find( i->first );
            if( m == parms_.end() ) parms_[i->first] = i->second;
        }
        else parms_[i->first] = i->second;
    }
}

/********************************************************************************/
ModelParamSet::iterator ModelParamSet::ci_find( const std::string& name )
{
    std::string n = name;
    std::string np;
    for( std::string::iterator i=n.begin(); i!=n.end(); ++i ) {
        if( *i>='A' && *i<='Z' ) *i += ('a' - 'A');
    }
    for( iterator p=begin(); p!=end(); ++p ) {
        np = p->first;
        for( std::string::iterator i=np.begin(); i!=np.end(); ++i ) {
            if( *i>='A' && *i<='Z' ) *i += ('a' - 'A');
        }
        if( n == np ) return p;
    }
    return end();
}

/********************************************************************************/
ModelParamSet::const_iterator ModelParamSet::ci_find( const std::string& name ) const
{
    std::string n = name;
    std::string np;
    for( std::string::iterator i=n.begin(); i!=n.end(); ++i ) {
        if( *i>='A' && *i<='Z' ) *i += ('a' - 'A');
    }
    for( const_iterator p=begin(); p!=end(); ++p ) {
        np = p->first;
        for( std::string::iterator i=np.begin(); i!=np.end(); ++i ) {
            if( *i>='A' && *i<='Z' ) *i += ('a' - 'A');
        }
        if( n == np ) return p;
    }
    return end();
}

/********************************************************************************/
ModelParamSet ModelParamSet::copy() const
{
    ModelParamSet r;
    for( const_iterator i = begin(); i != end(); ++i ) {
        r[i->first] = i->second.copy();
    }
    return r;
}

/********************************************************************************/
bool ModelParamSet::read_end_file( const std::string& fname, letter_case c )
{
    std::ifstream is( fname.c_str() );
    std::istringstream ss;
    std::string line;
    double mn, nom, mx, tol;
    std::string nm;

    parms_.clear();
    order_.clear();

    if( !is.is_open() ) return false;

    while( std::getline(is,line).good() ) {
        ss.clear();
        ss.str(line);
        ss >> mn >> nom >> mx >> tol >> nm;
        if( ! ss.fail() ) {
            ModelParam p( nm, nom );
            p.setOptBoth( mn, mx );
            p.setTol( tol );
            this->push( p, c );
        }
    }
    return true;
}

/********************************************************************************/
bool ModelParamSet::write_end_file( const std::string& fname ) const
{
    ModelParamSet tmp( *this );
    std::ofstream os( fname.c_str() );
    ModelParamSet::iterator pi;

    if( ! os.is_open() ) return false;

    os << std::scientific << std::setprecision(4);

    // write the parameters in the same order they "pushed"
    //  this only does something for parameters added with the push()
    //  method of the object
    for( std::list<std::string>::const_iterator oi=order_.begin(); oi!=order_.end(); ++oi ) {
        pi = tmp.find( *oi );
        if( pi != tmp.end() ) {
            os << pi->second.getOptL() << " " << pi->second.value() << " " << pi->second.getOptH()
                << " " << pi->second.getTol() << " " << pi->second.getName() << std::endl;
            tmp.erase( pi );
        }
    }

    // write any other parameters that were not ordered
    for( pi=tmp.begin(); pi!=tmp.end(); ++pi ) {
        if( pi->second.getName().length() )
            os << pi->second.getOptL() << " " << pi->second.value() << " " << pi->second.getOptH()
                << " " << pi->second.getTol() << " " << pi->second.getName() << std::endl;
        else {


        }
    }
    return true;
}

