/** \file
    \author Jay Barrett
    \brief Classes that deal with model parameters
*/
#include <string>
#include <list>
#include <map>
#include <fstream>
#include <exception>
#include "ref_count.hpp"

#ifndef MODELPARAM_CLASS_DEFINED
#define MODELPARAM_CLASS_DEFINED

/// exception thrown for various ModelParam and ModelParamSet related errors
class ModelParamException : public std::exception
{
protected:
    std::string msg_;  ///< storage of the error message
public:
    /// ctor
    /** \param s the error message string */
    ModelParamException( const std::string& s ) throw() : msg_(s) {}

    virtual ~ModelParamException() throw() {}

    /// returns the error message string
    const char* what() const throw() { return msg_.c_str(); }
};

/*************************************************************************************/
/// the ModelParam class holds model parameters
/** Aside from the parameter name and value, it also holds absolute limits, optimization limits
    and a bunch of convenience methods
    \warning THIS IS A REFERENCE-COUNTED OBJECT
       - when a ModelParam is copied using the copy operator - operator=()
            both objects will reference the same data
       - in most cases this is the desired behavior, and is necessary
           for certain applications, such as optimization
           where one ModelParam object is stored by a Model
           and another is stored by the OptProblem object, but
           they both reference the same parameter data so that changes
           to the parameter value made by the optimizer will show up in the model
       - this behavior can be suppressed by using the copy() method
           which will create a new copy of the data
           that is "de-coupled" from the original object
*/
class ModelParam
{
public:
   typedef unsigned int flgtype;

   /* parameter lags */
   static const flgtype fixed;        // value cannot be modified/optimized
   static const flgtype positive;     // value must be >= 0
   static const flgtype negative;     // value must be <= 0

protected:
    /// model parameter data
    struct ParamData {
        std::string name_;  ///< parameter name
        double value_, optmin_, optmax_, limitl_, limith_, tol_;
        flgtype flags_;  ///< parameter flags

        /// verify that everything jives
        void verify_limits() {
            // make sure that limitl_ <= limith_
            if( limitl_ > limith_ ) {
                double t = limitl_;
                limitl_ = limith_;
                limith_ = t;
            }

            // enforce the positive flag
            if( flags_ & positive ) {
                if( limitl_ < 0. ) limitl_ = 0.;
                if( limith_ < 0. ) limith_ = 0.;
            }
            // enforce the negative flag (if the positive flag is not set)
            else if( flags_ & negative ) {
                if( limitl_ > 0. ) limitl_ = 0.;
                if( limith_ > 0. ) limith_ = 0.;
            }

            // enforce that the optimization limits fall within the range
            //  set by limitl_ and limith_
            if( optmin_ < limitl_ ) optmin_ = limitl_;
            else if( optmin_ > limith_ ) optmin_ = limith_;
            if( optmax_ < limitl_ ) optmax_ = limitl_;
            else if( optmax_ > limith_ ) optmax_ = limith_;

            // make sure that optmin_ <= optmax_
            if( optmin_ > optmax_ ) {
                double t = optmin_;
                optmin_ = optmax_;
                optmax_ = t;
            }

            // make sure that the value is with the limitl_/limith_ range
            if( value_ < limitl_ ) value_ = limitl_;
            else if( value_ > limith_ ) value_ = limith_;
        }

        /// ctor
        /**
            \param n parameter name
            \param val parameter value
            \param flg parameter flags
        */
        ParamData( const std::string& n="", const double& val=0., flgtype flg=0 ) :
            name_(n), value_(val), optmin_(val), optmax_(val), limitl_(-1.e300),
            limith_(1.e300), tol_(0), flags_(flg) { this->verify_limits(); }
        ~ParamData() {}
    };


    ///  referenced-counted parameter data
    /**
        ModelParam data is stored in a reference-counted internal container
        this allows multiple ModelParam objects to share a reference to
        the same data

        This is a very useful behavior that makes lots of stuff easier to do.
         \sa RC<Ty>
    */
    RC<ParamData> d_;

public:
    /// set the parameter value
    /**  parameter absolute limits are enforced (silently),
         optimization limits are ignored, an exception is thrown
         if the "fixed" flag is set
         \param val the new ModelParam value
         \exception ModelParamException
    */
    void setVal( const double& val ) {
        if( d_->flags_ & fixed )
            throw ModelParamException( std::string("ModelParam::setVal(): parameter \'") + d_->name_ + "\' is \'fixed\' and cannot be modified." );
        else if( val < d_->limitl_ ) d_->value_ = d_->limitl_;
        else if( val > d_->limith_ ) d_->value_ = d_->limith_;
        else d_->value_ = val;
    }
    void setValue( const double& val ) { return this->setVal( val ); }
    void value( const double& val ) { return this->setVal( val ); }

    /// set the parameter value forcibly
    /**  parameter absolute limits are still enforced (silently),
         optimization limits are ignored, and the setting of the
         "fixed" flag is ignored
         \param val the new ModelParam value
    */
    void setValForce( const double& val ) {
        if( val < d_->limitl_ ) d_->value_ = d_->limitl_;
        else if( val > d_->limith_ ) d_->value_ = d_->limith_;
        else d_->value_ = val;
    }

   /// set the parameter value during optimization
   /**
        this call is specifically designed for use with the OptMethod
        optimization classes, it should only be used by those objects

        \param val the new value for the ModelParam
        \return false if the new value could not be set
            (it fell outside the optimization limits)
   */
   //  returns false if the passed value falls outside the
   //  optimization limits
   bool setValOpt( const double& val ) {
      if( d_->flags_ & fixed || val < d_->optmin_ || val > d_->optmax_ ) return false;
      d_->value_ = val;
      return true;
   }

   /// set the lower absolute limit
   /**
        this is subject to automatic adjustment
        to fit within contraints set by the parameter flags
   */
   void setAbsL( const double& v ) {
      d_->limitl_ = v;
      d_->verify_limits();
   }

   /// set the upper absolute limit
   /**
        this is subject to automatic adjustment
        to fit within contraints set by the parameter flags
   */
   void setAbsH( const double& v ) {
      d_->limith_ = v;
      d_->verify_limits();
   }

   /// set the lower and upper absolute limits at once
   /**
        these are subject to automatic adjustment
        to fit within contraints set by the parameter flags
        \param minv the absolute lower limit
        \param maxv the absolute upper limit
   */
   void setAbsBoth( const double& minv, const double& maxv ) {
      d_->limitl_ = minv;
      d_->limith_ = maxv;
      d_->verify_limits();
   }

   /// set the lower optimization limit
   /**
        this is subject to automatic adjustment
        to fit within contraints set by the absolute lower/upper
        limits and the parameter flags
   */
   void setOptL( const double& v ) {
      d_->optmin_ = v;
      d_->verify_limits();
   }

   /// set the upper optimization limit
   /**
        this is subject to automatic adjustment
        to fit within contraints set by the absolute lower/upper
        limits and the parameter flags
   */
   void setOptH( const double& v ) {
      d_->optmax_ = v;
      d_->verify_limits();
   }

   /// set both lower and upper optimization limits at once
   /**
        these are subject to automatic adjustment
        to fit within contraints set by the absolute lower/upper
        limits and the parameter flags
        \param minv the optimization lower limit
        \param maxv the optimization upper limit
   */
   void setOptBoth( const double& minv, const double& maxv ) {
      d_->optmin_ = minv;
      d_->optmax_ = maxv;
      d_->verify_limits();
   }

    /// set the tolerance parameter
    /**  this is not really used at this time
        it exists to support legacy .end file format
    */
   void setTol( const double& tol=0. ) { d_->tol_ = tol; }

   /// get the parameter name
   /**  the parameter name can only be set by the constructor
    */
   const std::string& getName() const { return d_->name_; }

    /// check if 2 ModelParam objects reference the same data
   bool operator==( const ModelParam& p ) const { return (d_==p.d_); }

    /// check if 2 ModelParam objects do not reference the same data
   bool operator!=( const ModelParam& p ) const { return (d_!=p.d_); }

    /// see if the name of this parameter matches the passed string
    /**
        \param name the name to attempt to match this parameter to (case sensitive)
        \return true if the passed name matches the name of this parameter
    */
   bool match( const std::string& name ) const { return (d_->name_.length() && d_->name_ == name); }

   /// get the parameter flags
   /**  the parameter flags can only be set by the constructor
    */
   flgtype getFlags() const { return d_->flags_; }

   /// get the parameter absolute low limit
   const double& getAbsL() const { return d_->limitl_; }

   /// get the parameter absolute low limit
   const double& getAbsH() const { return d_->limith_; }

   /// get the parameter optimization low limit
   const double& getOptL() const { return d_->optmin_; }

   /// get the parameter optimization low limit
   const double& getOptH() const { return d_->optmax_; }

    /// get the optimization tolerance
    /**  this is not really used at this time
        it exists to support legacy .end file format
    */
   const double& getTol() const { return d_->tol_; }

   /// get the range of the optimization limits (max - min)
   double getOptR() const { return (d_->optmax_ - d_->optmin_); }

   /// get the parameter value
   const double& getValue() const { return d_->value_; }
   /// get the parameter value
   const double& value() const { return d_->value_; }
   /// get the parameter value
   const double& val() const { return d_->value_; }

   /// check whether the parameter can be optimized
   bool canOptimize() const {
      if( d_->flags_ & fixed ||
        d_->value_ < d_->optmin_ ||
        d_->value_ > d_->optmax_ ||
        d_->optmin_ == d_->optmax_ ||
        !d_->name_.length() ) return false;
      return true;
   }

    /// create a unique copy of the parameter
    /**
        this is often referred to as a "deep" copy

        this call is necessary when a "decoupled" ModelParam
        is needed (it is not needed very often, only in very
        special cases)

        \return a ModelParam object that references
            a newly allocated ParamData object, de-coupling it from
            this object
    */
   ModelParam copy() const {
        ModelParam r;
        *r.d_ = *d_;
        return r;
   }

    /// default constructor
    /** creates a new ModelParam object
        when called with no parameters the object will be un-named
        and will have the default value of 0
        \param name the parameter name
        \param val the parameter value
        \param flg flags that define parameter behaviors
    */
    ModelParam( const std::string& name="", const double& val=0., const flgtype flg=0 ) :
        d_( new ParamData(name,val,flg) ) { }

    virtual ~ModelParam() { }
};

/*************************************************************************************/
// math operators for ModelParam objects

inline double operator+( const double& x, const ModelParam& y ) { return x + y.value(); }
inline double operator+( const ModelParam& y, const double& x ) { return x + y.value(); }

inline double operator-( const double& x, const ModelParam& y ) { return x - y.value(); }
inline double operator-( const ModelParam& y, const double& x ) { return x - y.value(); }

inline double operator*( const double& x, const ModelParam& y ) { return x * y.value(); }
inline double operator*( const ModelParam& y, const double& x ) { return x * y.value(); }

inline double operator/( const double& x, const ModelParam& y ) { return x / y.value(); }
inline double operator/( const ModelParam& y, const double& x ) { return y.value() / x; }

/*************************************************************************************/
/// a class that holds a set of ModelParam objects
/** The purpose of a ModelParamSet is to "maintain" a set
    of ModelParam objects in a consistent and abstractable
    interface.

    \warning ModelParam objects are reference-counted objects.
        Therefore, when a ModelParam is push() 'ed into the ModelParamSet
        a reference to the passed parameter is created, not a unique copy.
        This is the desired behavior, but it requires using caution since
        the objects remain "coupled" after the call to push() .
*/
class ModelParamSet
{
public:
    typedef std::map<std::string,ModelParam> StorT;
    typedef StorT::iterator iterator;
    typedef StorT::const_iterator const_iterator;
    typedef StorT::reverse_iterator reverse_iterator;
    typedef StorT::const_reverse_iterator const_reverse_iterator;

    /// define the "case" that is used when storing ModelParam objects
    /** parameters in a ModelParamSet are accessed via a std::map
        object using a string as a key

        since this is a case-sensitive approach, it is important
        that the user be able to access the ModelParam objects
        in a consistent manner

        to accomplish this, the letter_case may be specified when
        push() 'ing new ModelParam objects into the ModelParamSet

        the default is to use the exact same
        string as returned by ModelParam::getName() object

        the other options are to map the parameter in upper case
        or in lower case
    */
    enum letter_case {
        default_case,
        upper_case,
        lower_case
    };

protected:
    /* protected data */
    StorT parms_;     ///< parameter data, it's type is map<string,ModelParam>
    std::list<std::string> order_;  ///< the order that ModelParams were added using push()

public:
    /// find a model parameter in the set
    /**
        \param name the name of the parameter (case-sensitive)
        \return an iterator to the matching ModelParam object or the
            "end" iterator if the parameter is not found
    */
    iterator find( const std::string& name ) { return parms_.find( name ); }

    /// find a model parameter in the set
    /**
        \param name the name of the parameter (case-sensitive)
        \return a const_iterator to the matching ModelParam object or the
            (const) "end" iterator if the parameter is not found
    */
    const_iterator find( const std::string& name ) const { return parms_.find( name ); }

    /// case-insensitive version of find()
    /**
        \param name the name of the parameter (case-insensitive)
        \return an iterator to the matching ModelParam object or the
            "end" iterator if the parameter is not found
        \sa ModelParamSet::find()
    */
    iterator ci_find( const std::string& name );

    /// case-insensitive version of find()
    /**
        \param name the name of the parameter (case-insensitive)
        \return an const_iterator to the matching ModelParam object or the
            (const) "end" iterator if the parameter is not found
        \sa ModelParamSet::find()
    */
    const_iterator ci_find( const std::string& name ) const;

    /// check if a parameter exists in the set
    /**
        \param name the name of the parameter (case-sensitive)
    */
    bool exists( const std::string& name ) const { return (parms_.find(name) != parms_.end()); }


    /// check if a parameter exists in the set (case-insensisive)
    /**
        \param name the name of the parameter (case-insensitive)
        \sa ModelParamSet::exists()
    */
    bool ci_exists( const std::string& name ) const { return (ci_find(name) != parms_.end()); }

    /// add a ModelParam object to the set
    /**
        \param p the ModelParam object to add
        \param c the "case" to use when mapping the parameter
        \sa ModelParamSet::letter_case
    */
    void push( const ModelParam& p, letter_case c=default_case );

    /// clear the model parameter set (delete all ModelParam objects)
    void clear() { parms_.clear(); }

    /// merge another ModelParamSet into this one
    /**
        \param pset the ModelParamSet to merge into this one
        \param overwrite overwrite a flag indicates whether existing parameters
            in this object are overwritten or not (default = false)
    */
    void merge( const ModelParamSet& pset, bool overwrite=false );

    /// access a ModelParam (case-sensitive)
    /**
        \param name the name of the parameter (case-sensitive)
        \return a reference to the ModelParam object, if a parameter with the given name
            does not exist, a "blank" ModelParam will be returned with the
            characteristics of a ModelParam object's default ctor
        \sa ModelParam::ModelParam()
    */
    ModelParam& operator[]( const std::string& name ) { return parms_[name]; }

    /// access a ModelParam (case-sensitive) const-version
    /**
        this differs from the non-const version since when
        dealing with a const ModelParamSet object it is not possible to add
        a new "blank" ModelParam object to the internal pmap_
        \param name the name of the parameter (case-sensitive)
        \return a reference to the ModelParam object, if a parameter with the given name
            does not exist, an exception is thrown
        \sa ModelParam::ModelParam()
        \exception ModelParamException
    */
    const ModelParam& operator[]( const std::string& name ) const {
        ModelParamSet::const_iterator i = parms_.find(name);
        if( i == parms_.end() ) throw ModelParamException( std::string("const ModelParamSet::operator[](): parameter \'") + name + "\' is not defined." );
        return i->second;
    }

    /// create a new copy of the ModelParamSet
    /**  the parameters in the new object reference
         different memory than the parameter in this object

         the default assignment operation, operator=(), creates
         references, which are shared between the rhs and lhs objects
         so that the two objects would become coupled

         this effectively de-couples the new object from this object
    */
    ModelParamSet copy() const;

    /// read the model parameter data in ".end" file format
    /**
        as model parameters are read from the file ModelParam objects are created
        and then push() 'ed into this object

        this method keeps track of the order in which parameters are read
        so that they can be written in the same order by write_end_file()

        \param fname the file name of the ".end" file
        \param c defines how the parameters are mapped into
            the storage container of this object
        \return true on success, false on failure (invalid file, or other file error)
        \sa ModelParamSet::letter_case ModelParamSet::push()
    */
    bool read_end_file( const std::string& fname, letter_case c=default_case );

    /// write model parameters in ".end" file format
    /**
        the data from each of the ModelParam objects is written to the file

        this method uses the order in which parameters were push() 'ed
        into the ModelParamSet to write the ModelParam s to the file
        this way the order in the file is preserved between a read and write
        of a ".end" file

        \param fname the file name of the ".end" file
        \return true on success, false on failure (unable to write file)
    */
    bool write_end_file( const std::string& fname ) const;

    /*----------------------------*/
    // iterator functions
    iterator begin() { return parms_.begin(); }
    const_iterator begin() const { return parms_.begin(); }
    reverse_iterator rbegin() { return parms_.rbegin(); }
    const_reverse_iterator rbegin() const { return parms_.rbegin(); }
    iterator end() { return parms_.end(); }
    const_iterator end() const { return parms_.end(); }
    reverse_iterator rend() { return parms_.rend(); }
    const_reverse_iterator rend() const { return parms_.rend(); }
    /*----------------------------*/

    /// erase a ModelParam from this object
    void erase( iterator i ) { parms_.erase( i ); }

    // ctor and dtor
    ModelParamSet() {}
    virtual ~ModelParamSet() {}
};

#endif  /* MODELPARAM_CLASS_DEFINED */
