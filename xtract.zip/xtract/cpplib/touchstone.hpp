/**
 \file
 \brief A class for reading %Touchstone-formatted data
 \author Jay Barrett
*/
#ifndef TOUCHSTONE_CLASS
#define TOUCHSTONE_CLASS

#include "network_params.hpp"
#include <string>
#include <iostream>
#include <exception>

#define E_STREAM_ERROR       (-200)
#define E_INVALID_FNAME      (-201)
#define E_COMPLEX_IMPEDANCE  (-203)
#define E_BLOCK_FORMAT       (-204)
#define E_NO_DATA            (-205)
#define E_NO_PORTS           (-206)

/// exception thrown by the Touchstone class
/**
  This behaves much like any other exception.
 */
class TouchstoneError : public NetworkParametersError
{
public:
    /// constructor
    /** \param str is the error message string
        \param code is the (optional) error code
    */
    TouchstoneError( const std::string& str, int code=0 ) throw() : NetworkParametersError(str,code) { }
    /// destructor
    virtual ~TouchstoneError() throw() {}

};

/// touchstone data reading/writing class
/**
  Objects of this class can be used to read and write
  %Touchstone data files.

  \bug Impedance normalization is not currently implemented for
       Z, Y, G, and H parameters. So, when reading/writing these
       parameters, the normalization factor is always 1 (even
       when it is not, in the read() case).  This is normally a
       non-issue, since reading normalized sets of these parameters
       is rare.

  \warning Only S, Z, Y, H, and G parameters can be read/written
           from/to files.  This is because the %Touchstone standard
           only deals with these parameter types. The parent
           NetworkParamSet object can also deal with ABCD and T
           parameters, but attempts to read/write files of these types
           will result in an exception.
*/
class Touchstone : public NetworkParamSet
{
public:
   /// formats for writing complex data
   enum e_write_format {
      MagAngle,
      RealImag,
      DbAngle
   };
   /// frequency scaling constants
   enum e_freq_scale {
      Hertz,
      Kilohertz,
      Megahertz,
      Gigahertz,
      Terahertz
   };
   /// floating-point modes
   enum e_fp_mode {
      FPauto,
      FPscientific,
      FPfixed
   };

protected:
   std::string fname_;
   std::string header_;
   e_write_format writeFormat_;
   e_freq_scale freqScale_;
   size_t precision_;
   std::string blockIndent_;
   std::string recordSep_;
   std::string complexSep_;
   e_fp_mode fpMode_;
   std::istream *is_;
   size_t linecount_;

   /// internal struct for keeping track of the current position in a file
   struct Bookmark {
       size_t sp;
       size_t lc;
       Bookmark() : sp(0), lc(0) { }
   };

   static const double radians2degrees;
   static const double degrees2radians;

   /// compute cos() with a degree argument
   static double cosdeg( const double& x ) {
      return std::cos(x*degrees2radians);
   }

   /// compute sin() with a degree argument
   static double sindeg( const double& x ) {
      return std::sin(x*degrees2radians);
   }

   /// write a complex-valued quantity to an ostream
   /** \param os the stream to write to
       \param d the data to write
   */
   std::ostream& write_complex( std::ostream& os, const ScalarDataT& d ) const {
      switch( writeFormat_ )
      {
      case RealImag:
         os << d.real() << complexSep_ << d.imag();
         break;
      case DbAngle:
         os << 20. * std::log10(std::abs(d)) << complexSep_ << std::arg(d) * radians2degrees;
         break;
      case MagAngle:
      default:
         os << std::abs(d) << complexSep_ << std::arg(d) * radians2degrees;
         break;
      }
      return os;
   }

   /// write a block of NetworkParam data to an ostream
   /** \param os the stream to write to
       \param data the data to write
   */
   void write_data_block( std::ostream& os, const NetworkParam& data ) const;

   /// read a block of data from the currently opened file
   bool read_data_block();

   /// get the block size
   void get_block_size();

   /// get the line number of the input file begin parsed
   /** \return a string of the form " line x."
       Used in the generation of exceptions
   */
   std::string get_line_number() const {
       std::ostringstream os;
       os << " line " << linecount_ << ".";
       return os.str();
   }

    /// read a line from a stream and keep a running line count
    /** \param line A C++ string to store the read data in
    */
    void read_line( std::string& line ) {
        if( is_ ) {
            std::getline( *is_, line );
            ++linecount_;
        }
        else throw TouchstoneError( "Touchstone::read_line(): invalid stream pointer", E_INVALID_STATE );
    }

    /// create a bookmark
    /** This is used to store the current position in the
        input file being parsed, so that it can be restored later.
        \return a Bookmark object
    */
    Bookmark create_bookmark() {
        Bookmark m;
        if( is_ ) {
            m.sp = is_->tellg();
            m.lc = linecount_;
        }
        return m;
    }
    /// seek the input file to the bookmark
    /** \param mark a previously created Bookmark object
    */
    void seek_bookmark( Bookmark mark ) {
        if( is_ ) {
            is_->seekg( mark.sp );
            linecount_ = mark.lc;
        }
    }

public:
   /// get the filename of the last file read with read()
   const std::string& fname() const { return fname_; }

   /// get a mutable reference to the header
   std::string& header() { return header_; }
   /// get a const reference to the header
   const std::string& header() const { return header_; }

   /// set formatting parameters all at once
   /** calling this function with no arguments will reset
       the default formatting parameters
       \param fmt the complex-data format
       \param scale the frequency scaling factor
       \param precision the floating-point precision
       \param fpmode the floating point mode
   */
   void set_format( e_write_format fmt=MagAngle, e_freq_scale scale=Hertz, size_t precision=6, e_fp_mode fpmode=FPauto ) {
      writeFormat_ = fmt;
      freqScale_ = scale;
      precision_ = precision>15 ? 15 : precision;
      fpMode_ = fpmode;
   }
   /// set the complex-data parameter format
   void set_param_format( e_write_format fmt ) { writeFormat_ = fmt; }

   /// set the frequency scaling
   void set_freq_scaling( e_freq_scale scale ) { freqScale_ = scale; }

   /// set the floating point precision
   /** the maximum precision is 15, though in practice this
       many digits of precision is rarely avaiable from the data
   */
   void set_fp_precision( size_t prec ) { precision_ = (prec > 15)?15:prec; }

   /// set the floating point mode
   void set_fp_mode( e_fp_mode fpmode ) { fpMode_ = fpmode; }

   /// set seperators used for writing files
   /**
     \param record sets the record seperator that is inserted between
            network parameter complex pairs
     \param cmplx sets the complex number seperator that is inserted
            between the real and imag parts of a complex number
     \param block_ind sets the block indent string that is printed
            at the start of each line after the first in multi-line
            data blocks.  These only occur in 3+ port data files.
     \warning Setting these seperators to anything other than space/tab
              characters (or combinations of spaces and tabs) can corrupt
              the data, with the exception of the block_ind seperator
              which may be set to an empty string if no indent is desired
              (an indent is not required by the standard, it just makes
              the data easier to read)
   */
   void set_separators( const std::string& record, const std::string& cmplx, const std::string& block_ind ) {
      recordSep_ = record;
      complexSep_ = cmplx;
      blockIndent_ = block_ind;
   }

   /// set the string the separates adjacent parameters
   /** the default value is "\t" */
   void set_record_separator( const std::string& str ) { recordSep_ = str; }

   /// set the string that separates the real and imag parts of complex numbers
   /** the default value is " " */
   void set_complex_separator( const std::string& str ) { complexSep_ = str; }

   /// set the block indent string for mutli-line data blocks (3+ port data)
   /** the default value is "\t\t" */
   void set_block_indent( const std::string& str ) { blockIndent_ = str; }

   /// read a %Touchstone data file
   /**
     \param fname the filename of the file to read
     \exception TouchstoneError
   */
   Touchstone& read( const std::string& fname );

   /// write a %Touchstone data file
   /**
     \param fname the filename of the file to write
     \exception TouchstoneError
   */
   const Touchstone& write( const std::string& fname ) const;

   /// read %Touchstone data from a stream
   /**
     This method is used to implement the read() method after
     the file has been opened.
     \param is the stream to read data from
     \param initial_linecount the line number of the stream
            used to correctly report line numbers in the case
            of error messages
     \exception TouchstoneError
     \warning this class can only read from file/buffer-based streams
               since it needs to be able to seek
     \warning TTY streams will cause an exception
   */
   std::istream& read_stream( std::istream& is, size_t initial_linecount=0 );

   /// write %Touchstone data directly to a stream
   /**
     This method is used to implement the write() method after
     the file has been opened.
     \param os the stream to write data to
     \exception TouchstoneError
   */
   std::ostream& write_stream( std::ostream& os ) const;

   /// parse a touchstone format string
   /** Whatever usable data can be read from the format
       string will be used to configure the objects
       internal state. This method is used during file
       reads, and may be used to set up the object
       to write data in a certain format
       \param line the format string line
       \warning this method DOES NOT convert any data that
                exists in the object to a different type
                if the "type" argument (S, G, H, etc) does
                not match the current "type"
       \warning therefore, supplying a "type" that is different
                than that of data currently stored in the object
                WILL CORRUPT THE DATA
    */
    void parse_format_string( const std::string& line );

    /// clear all of the data from the object
    /** this clears all data and resets
        all internal states to defaults
    */
    virtual void clear() {
        NetworkParamSet::clear();
        header_ = "";
        writeFormat_ = MagAngle;
        freqScale_ = Hertz;
        precision_ = 6;
        blockIndent_ = "\t\t";
        recordSep_ = "\t";
        complexSep_ = " ";
        fpMode_ = FPauto;
        is_ = 0;
        linecount_ = 0;
    }

    /// return the linecount of the input stream after parsing it
    /** this is useful when using the read_stream() interface
        for files with multiple %Touchstone data blocks

        this method can be used to set the initial_linecount
        parameter to read_stream() each time a %Touchstone
        data set is read - keeping the line counter consistent
        with the file's real line number
    */
    size_t get_linecount() const {
        return linecount_;
    }

   /// copy operator for the base class
   /** This allows NetworkParamSet objects to be "promoted" to
       Touchstone objects so that the data can be written

       none of the Touchstone -specific data is modified
       (header, data formats, seperators, etc)

       the self copy operator is auto-generated
       so it does not appear in the documentation
       \param rhs a NetworkParamSet object to copy into this object
       \warning This does not create a unique copy of the data contained
                in the rhs object, but rather a reference to that data.
                If the data is modified in one object it will change
                in the other
   */
   Touchstone& operator=( const NetworkParamSet& rhs ) {
      NetworkParamSet::operator=( rhs );
      // does not modify any of the data for the Touchstone derived class
      return (*this);
   }

   /**** Ctors / Dtor ****/
   /// default ctor
   Touchstone();
   /// copy ctor
   /** \param rhs another Touchstone object to copy
       \warning network parameter data is referenced, not copied
   */
   Touchstone( const Touchstone& rhs );
   ///  copy ctor from a NetworkParams class
   /** all of the formatting/state members
       unique to the Touchstone class are set to defaults
       \param rhs a NetworkParamSet object to copy
       \warning network parameter data is referenced, not copied
   */
   Touchstone( const NetworkParamSet& rhs );
   /// dtor, empty
   virtual ~Touchstone() { }

}; /* end of Touchstone class defintion */

/// overloaded stream output operator
/** this is implemented with the Touchstone::write_stream() method
    \param os the stream to write to
    \param t the Touchstone object
*/
inline std::ostream& operator<<( std::ostream& os, const Touchstone& t )
{
   return t.write_stream(os);
}

/// overloaded stream input operator
/** this is implemented with the Touchstone::read_stream() method
    \param is the stream to read from
    \param t the Touchstone object in which to store the data
    \warning the stream MUST be a file-like stream (able to seek)
*/
inline std::istream& operator>>( std::istream& is, Touchstone& t )
{
   return t.read_stream(is);
}

#endif  // TOUCHSTONE_CLASS defined


