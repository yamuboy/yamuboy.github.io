#include "ref_count.hpp"

#ifdef REF_COUNT_MEM_DEBUG
static RC_debug RC_debug_static_;

RC_debug& get_RC_debug() {
    return RC_debug_static_;
}

#endif
