#include <iostream>
#include <cmath>
#include <map>
#include <vector>
#include <sstream>
#include <sys/time.h>
#include <stdlib.h>
#include "optimize.hpp"


void shuffle_vector( std::vector<int>& v );


class RandNG
{
protected:


public:

    virtual double rand() const { return drand48(); }


    RandNG() {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        unsigned long seed =  ((0xFFFFF & tv.tv_usec) << 12);
        seed |= (tv.tv_usec & tv.tv_sec & 0xFFF00) >> 8;
        srand48(seed);
    }

    virtual ~RandNG() {}
};

static RandNG RNG;

/*****************************************************************************/
class OptMethod_Gradient : public OptMethod
{
protected:
    double min_step_;
    unsigned max_search_steps_;
    bool randomize_order_;

    // compute the gradient for an OptParam
    //  used in gradient-based optimization
    void compute_grad( OptProblem& prob, OptParam& p, const double& e );

public:
    virtual void init( OptProblem& prob, const OptionSet& opt );
    virtual bool optimize( OptProblem& p );

    static double quadratic_fit( const double& x1, const double& x2, const double& y1, const double& y2 );

    OptMethod_Gradient() : min_step_(1.e-30), max_search_steps_(5), randomize_order_(false) {}
    virtual ~OptMethod_Gradient() {}
};

/*****************************************************************************/
class OptMethod_SimultGradient : public OptMethod_Gradient
{
protected:


public:
    virtual void init( OptProblem& prob, const OptionSet& opt ) {}
    virtual bool optimize( OptProblem& p );

    OptMethod_SimultGradient() {}
    virtual ~OptMethod_SimultGradient() {}
};

/*****************************************************************************/
class OptMethod_Random : public OptMethod
{
protected:
    // protected internal variables
    size_t maxevals_;
    double window_;

public:
    virtual void init( OptProblem& prob, const OptionSet& opt );
    virtual bool optimize( OptProblem& p );

    OptMethod_Random() : maxevals_(1000), window_(0.2) { }
    virtual ~OptMethod_Random() {}
};

/*****************************************************************************/
class OptIterationCB_toStdout : public OptIterationCB
{
public:
    virtual void initial( const double& err ) {
        std::cout << "Starting optimization." << std::endl;
        std::cout << "Initial: " << err << std::endl;
    }

    virtual void final( const double& err ) {
        std::cout << "Final: " << err << std::endl;
        std::cout << "Optimization complete." << std::endl;
    }

    virtual bool onIter( size_t iter, const double& err ) {
        std::cout << "   " << iter << "    " << err << std::endl;
        return true;
    }

    virtual ~OptIterationCB_toStdout() {}
};

/*****************************************************************************/
class OptIterationCB_toNull : public OptIterationCB
{
public:
    virtual void initial( const double& err ) { }
    virtual void final( const double& err ) { }
    virtual bool onIter( size_t iter, const double& err ) { return true; }
    virtual ~OptIterationCB_toNull() {}
};

/*****************************************************************************/
/*****************************************************************************/
//                              STATIC DATA                                  //
/*****************************************************************************/
/*****************************************************************************/

static OptIterationCB_toStdout toStdout;
static OptIterationCB_toNull toNull;

OptIterationCB* OptIterationCB_stdout = &toStdout;
OptIterationCB* OptIterationCB_null = &toNull;

/*****************************************************************************/
/*****************************************************************************/
//                       OptMethod_Random                                    //
/*****************************************************************************/
/*****************************************************************************/
bool OptMethod_Random::optimize( OptProblem& prob )
{
    double e0 = prob.lastErr();
    double e1 = e0;
    // loop over maximum evaluations
    for( size_t i=0; i<maxevals_; ++i ) {
        // loop over the parameter list
        if( window_ < 1. ) {
            for( OptParamSet::iterator parm = prob.params().begin(); parm != prob.params().end(); ++parm )
                parm->compute_window( RNG.rand(), window_ );
        }
        else {
            for( OptParamSet::iterator parm = prob.params().begin(); parm != prob.params().end(); ++parm )
                parm->compute_direct( RNG.rand() );
        }
        if( prob.eval() < e1 ) {
            prob.saveState();
            e1 = prob.lastErr();
            // other checks, maybe halt the loop if improvement is more than some threshold??




        }
    }

    return (e1 < e0);
}

/*****************************************************************************/
void OptMethod_Random::init( OptProblem& p, const OptionSet& opt )
{
    window_ = opt.asDouble("opt_rand_window",window_);
    maxevals_ = opt.asUnsigned("opt_rand_maxevals",maxevals_);
}

/*****************************************************************************/
/*****************************************************************************/
//                       OptMethod_Gradient                                  //
/*****************************************************************************/
/*****************************************************************************/
bool OptMethod_Gradient::optimize( OptProblem& prob )
{
    double ss, ssmin, e0, e1, e2;
    OptParam* p;
    std::vector<int> order;
    std::vector<int>::iterator it;
    unsigned n;
    bool ok;

    // create a parameter order vector
    order.reserve( prob.params().size() );
    for( size_t i=0; i<prob.params().size(); ++i )
        order.push_back(i);

    // rearrange the parameter order vector
    if( randomize_order_ ) shuffle_vector(order);

    // begin the parameter loop
    e0 = prob.lastErr();
    for( it=order.begin(); it != order.end(); ++it ) {
        p = &prob.params().at(*it);

        // compute the gradient
        compute_grad( prob, *p, e0 );
        if( ! p->gradient() ) continue;

        // set the minimum step size
        ssmin = fabs(p->value()) * 1.e-12;
        if( ssmin < min_step_ ) ssmin = min_step_;

        // determine the initial step size
        //  set the initial step size to 5% of the parameter value
        ss = copysign( 0.05 * p->value(), p->gradient() );
        if( fabs(ss) < 20.*ssmin ) ss = copysign( 20.*ssmin, ss );


        /// ---------------------------------------------------------
        /// Step 1: reduce the step size until the "error" decreases
        /// ---------------------------------------------------------
        ok = true;
        for( n=0; n<10; ++n ) {
            // calculate the parameter offset and error function
            if( !p->compute_offset(ss) || ((e1 = prob.eval()) > e0) ) {
                // offset calculation failed (hit edge of range),
                // or error increased
                //   -> reduce the step size by a factor of 4 and try again
                ss *= 0.25;
                if( fabs(ss) < ssmin ) {
                    // optimization cannot continue for this parameter
                    // probably at a local minima or up against one
                    // of the parameter limits
                    p->recall_state();
                    ok = false;
                    break;
                }
            }
            else break;
        }
        if( !ok ) continue;  // step size decrease loop failed

        /// ---------------------------------------------------------
        /// Step 2: search in multiples of the step size for the
        ///         minimum "error"
        /// ---------------------------------------------------------
        n = 2;      // this is the next step size multiple to calculate
        e2 = e1;    // e2 must be initialized to something...
        while( 1 ) {
            if( !p->compute_offset( ss*n ) ) {
                // offset calculation failed (hit edge of range)
                --n; break;
            }
            e2 = prob.eval();
            if( e2 < e1 ) {
                if( n > max_search_steps_ ) break;
                // go another step
                e0 = e1;
                e1 = e2;
                ++n;
            }
            else break; // error increased
        }

        /// ---------------------------------------------------------
        /// Step 3: interpret the results of the search, do a
        ///         quadratic fit if possible to find the minimum
        ///         "error" point between the evaluated points
        /// ---------------------------------------------------------
        if( e2 < e1 ) {
            //  last evaluation of n had the minimum error
            e0 = e2;
        }
        else if( n >= 2 && e2 > e1 ) {
            // do a quadratic fit, minimum must be bounded by n and n-2
            double ex;
            double x = quadratic_fit( n-2, n, e0, e2 );
            if( x > n-2 && x < n && p->compute_offset(x*ss) && (ex=prob.eval()) < e1 )
                // successful quadratic fit
                e0 = ex;
            else {
                // revert to the n-1 offset, which had the best "error"
                p->compute_offset( (n-1)*ss );
                e0 = e1;
            }
        }
        else {
            // n=2 calculation failed
            //  revert to n=1
            p->compute_offset(ss);
            e0 = e1;
        }
    }

    // return true if the current "error" is less than the "error"
    //  at the start of this routine
    return (e0 < prob.lastErr());
}

/*****************************************************************************/
void OptMethod_Gradient::init( OptProblem& p, const OptionSet& opt )
{
    min_step_ = opt.asDouble( "opt_grad_min_step", min_step_ );
    randomize_order_ = opt.asBool( "opt_grad_randomize" );
    max_search_steps_ = opt.asUnsigned( "opt_grad_search_steps", max_search_steps_ );

    // other initialization ??
}


/*****************************************************************************/
// compute the gradient of a parameter
void OptMethod_Gradient::compute_grad( OptProblem& prob, OptParam& p, const double& err )
{
    double e2;
    double delt = 1.e-4 * p.range();
    double deltv = 1.e-5 * fabs(p.value());
    if( delt < deltv ) delt = deltv;

    if( err > 1.e299 ) {
        p.set_gradient(0.);
        return;
    }

    if( ! p.compute_offset(delt) ) {
        // parameter must have hit the edge of the range
        //  compute the gradient in the other direction
        delt = -delt;
        if( ! p.compute_offset(delt) ) {
            // hit the other edge of the range
            //  parameter range is too small to optimize
            //  reset the parameter value, set the gradient to 0, and return
            p.recall_state();
            p.set_gradient( 0. );
            return;
        }
    }

    // compute the error function for "nominal + delta"
    if( (e2 = prob.eval()) > 1.e299 ) {
        // error function computation failed
        //  probably because of a NaN or Infinity value
        //  reset the parameter value, set the gradient to 0, and return
        p.recall_state();
        p.set_gradient( 0. );
        return;
    }

    // compute the gradient:
    //  we are trying to minimize the error
    //  so the gradient is the negative of the slope
    //  reset the parameter value, set the gradient, and return
    p.recall_state();
    p.set_gradient( (err - e2) / delt );
}

/*****************************************************************************/
double OptMethod_Gradient::quadratic_fit( const double& x1, const double& x2, const double& y1, const double& y2 )
{
    return 0.5 * (x1*x1 - x2*x2 - y1 + y2) / (x1 - x2);
}

/*****************************************************************************/
/*****************************************************************************/
//                       OptMethod_SimultGradient                            //
/*****************************************************************************/
/*****************************************************************************/
bool OptMethod_SimultGradient::optimize( OptProblem& prob )
{
    double ei = prob.lastErr();
    double g = 0.;
    double t, ss, ssmin, e1, e2, efin, x;
    OptParamSet::iterator it, largest;
    int n = 0;

    // compute the gradients
    //  also determine the largest gradient
    for( it=prob.params().begin(); it != prob.params().end(); ++it ) {
        compute_grad( prob, *it, ei );
        t = fabs( it->gradient() );
        if( t > g ) {
            largest = it;
            g = t;
        }
    }

    //  check to see that at least one gradient is non-zero
    if( ! g ) return false;

    // set the absolute minimum limit for the step size
    ssmin = largest->range() * 1.e-8;
    if( ssmin < min_step_ ) ssmin = min_step_;

    // determine the initial step size
    //  set the initial step size to 0.05% of the parameter range
    ss = 0.0005 * largest->range();
    if( ss < ssmin ) ss = ssmin;

    // this loop will reduce the step size until the goal error
    //   is less than the current error
    while(1) {
        // calculate the parameter offsets
        for( it = prob.params().begin(); it != prob.params().end(); ++it ) {
            if( it != largest )
                it->compute_offset( ss * it->gradient() / g );
            else
                it->compute_offset( copysign( ss, largest->gradient() ) );
        }
        // calculate the error function
        if( (e1 = prob.eval()) > ei ) {
            // error increased
            //   -> reduce the step size by a factor of 4 and try again
            ss *= 0.25;
            if( ss < ssmin || ++n > 10 ) {
                // optimization cannot continue
                //  we are probably at a local minima
                return false;
            }
        }
        else break;  // error was reduced
    }


    // search for the minimum along the direction of the step size
    //  only allow a few steps since we do not want the parameter value to change too much
    //  on any given iteration

    // this is the next step size offset to calculate
    n = 2;
    while(1) {
        // calculate the parameter offsets
        for( it = prob.params().begin(); it != prob.params().end(); ++it ) {
            if( it != largest )
                it->compute_offset( n * ss * it->gradient() / g );
            else
                it->compute_offset( copysign( n * ss, largest->gradient() ) );
        }
        e2 = prob.eval();
        if( e2 < e1 ) {
            // if the error is less, repeat the search again
            //  but only go a couple of steps total
            if( n > 5 ) break;
            e1 = e2;
            ++n;
        }
        else break;
    }

    if( e2 > e1 ) {
        // attempt a quadratic fit of the error
        x = quadratic_fit( n-1, n, e1, e2 );
        if( x > n || x < n-1 ) {
            // calculate the parameter offsets
            for( it = prob.params().begin(); it != prob.params().end(); ++it ) {
                if( it != largest )
                    it->compute_offset( (n-1) * ss * it->gradient() / g );
                else
                    it->compute_offset( copysign( (n-1) * ss, largest->gradient() ) );
            }
            efin = prob.eval();
        }
        else {
            // calculate the parameter offsets
            for( it = prob.params().begin(); it != prob.params().end(); ++it ) {
                if( it != largest )
                    it->compute_offset( x * ss * it->gradient() / g );
                else
                    it->compute_offset( copysign( x * ss, largest->gradient() ) );
            }
            efin = prob.eval();
        }
    }
    else {
        // the value of n-1 contains the offset that produced the best error
        for( it = prob.params().begin(); it != prob.params().end(); ++it ) {
            if( it != largest )
                it->compute_offset( (n-1) * ss * it->gradient() / g );
            else
                it->compute_offset( copysign( (n-1) * ss, largest->gradient() ) );
        }
        efin = prob.eval();
    }

    // determine if this overall iteration was successful or not
    return( efin < ei );
}

/*****************************************************************************/
/*****************************************************************************/
//                          OptProblem                                       //
/*****************************************************************************/
/*****************************************************************************/
void OptProblem::setOptParams( const ModelParamSet& parms, const std::string& names )
{
    ModelParamSet::const_iterator pi;
    OptParamSet::iterator oi;
    std::istringstream is;
    std::string n;
    bool found;

    // clear the parameter list
    parms_.clear();

    is.str( names );
    while( !is.eof() ) {
        is >> n;
        if( is.fail() ) break;
        else if( ! n.length() ) continue;

        if( n == "__ALL__" || n == "__all__" || n == "__All__" ) {
            // special case where all "optimizable" parameters will be added
            for( pi = parms.begin(); pi != parms.end(); ++pi ) {
                if( pi->second.canOptimize() ) {
                    // make sure the parameter is not already in the parameter set
                    found = false;
                    for( oi = parms_.begin(); oi != parms_.end(); ++oi ) {
                        if( *oi == pi->second ) {
                            found = true;
                            break;
                        }
                    }

                    if( !found ) parms_.push_back( OptParam(pi->second) );
                }
            }

            break;
        }

        pi = parms.ci_find( n );
        if( pi != parms.end() && pi->second.canOptimize() ) {
            // make sure the parameter is not already in the parameter set
            found = false;
            for( oi = parms_.begin(); oi != parms_.end(); ++oi ) {
                if( *oi == pi->second ) {
                    found = true;
                    break;
                }
            }

            if( !found ) parms_.push_back( OptParam(pi->second) );
        }
    }
}

/*****************************************************************************/
void OptProblem::saveState()
{
    lasterr_ = err_;
    for( OptParamSet::iterator i = parms_.begin(); i != parms_.end(); ++i )
        i->save_state();
}

/*****************************************************************************/
void OptProblem::recallState()
{
    err_ = lasterr_;
    for( OptParamSet::iterator i = parms_.begin(); i != parms_.end(); ++i )
        i->recall_state();
}

/*****************************************************************************/
/*****************************************************************************/
///                          OptEngine                                      ///
/*****************************************************************************/
/*****************************************************************************/
class OptimizationComplete : public std::exception
{
    const char* what() const throw() { return "OptimizationComplete"; }
};

/*****************************************************************************/
void OptimizeEngine::optimize( OptProblem& p, const OptionSet& opt )
{
    OptMethodList::iterator itm;
    OptMethod* method;
    bool round_robin = false;

    // make sure some stuff is set up correctly
    if( ! p.params().size() )
        throw OptimizeError( "OptEngine::optimize(): the problem has no parameters to optimize.", E_OPT_CONFIG );
    if( ! om_.size() )
        throw OptimizeError( "OptEngine::optimize(): no optimization methods have been configured.", E_OPT_CONFIG );

    // grab parameters from the OptionSet
    niter_ = opt.asInt("opt_num_iterations",niter_);
    round_robin = opt.asBool("opt_round_robin");
    success_frac_ = opt.asDouble("opt_success_fraction",success_frac_);

    // perform the initial evaluation of the error
    starterrv_ = p.init();

    // call the "initial" callback
    cb_->initial( starterrv_ );

    // clear the history
    hist_.clear();

    // initialize the first optimization method
    itm = om_.begin();
    method = *itm;
    method->init( p, opt );

    // start the optimization loop with the first method
    try {
        for( size_t iter=1; iter<=niter_; ++iter ) {
            // perform a single optimization iteration
            if( method->optimize( p ) ) {
                // iteration succeeded
                p.saveState();  // save the problem state
                errv_ = p.err();
                store_history( true, errv_ );   // store the result of this iteration
            }
            else {
                // iteration failed
                p.recallState();  // recall the problem state
                store_history( false, errv_ );  // store the result of this iteration
            }

            // use the callback for the end of the iteration
            //   break out of the optimization if it returns false
            if( !cb_->onIter(iter,errv_) ) break;

            // do some checks to see if optimization should continue
            //  with the current method, or switch to a new method
            //  or quit the optimization if all methods are exhausted
            //  (and round-robin mode is not selected)
            if( exit_method() ) {
                // select the next method
                ++itm;
                if( itm == om_.end() ) {
                    if( round_robin ) itm = om_.begin();
                    else break;
                }
                method = *itm;
                method->init( p, opt );
            }
        }
    }
    catch( OptimizationComplete& e ) { }

    // call the "final" callback
    cb_->final(errv_);
}

/*****************************************************************************/
bool OptimizeEngine::exit_method()
{
    int f=0;
    int n=0;
    if( hist_.size() < 5 ) return false; // not enough iterations yet

    // check the history to see what the last several optimization
    //  iterations did, if certain criteria are met, return true to exit the
    //  current optimization method
    for( History::iterator i = hist_.begin(); i != hist_.end(); ++i ) {
        if( ! i->first ) ++f;
        ++n;
        if( n == 3 && f == 3 ) return true;
        else if( n==5 && f >= 3 ) return true;
    }

    if( f >= 6 ) return true;
    else if( fabs(hist_[4].second - hist_[0].second) < fabs((1. - success_frac_) * hist_[4].second) ) return true;

    return false;
}

/*****************************************************************************/
void OptimizeEngine::store_history( bool success, const double& err )
{
    // if the error is less than or equal to 0
    //  throw a special exception
    if( err <= 0. ) throw OptimizationComplete();

    // store the result of the most recent optimization iteration
    // and dump the oldest - if there have been enough iterations
    //  this stores the last 10 iteration results
    hist_.push_front( std::pair<bool,double>(success,err) );
    if( hist_.size() > 10 ) hist_.pop_back();
}

/*****************************************************************************/
void OptimizeEngine::setMethod( const std::string& name )
{
    std::istringstream is;
    std::string mn;
    OptMethod* m;

    // clean up allocated methods
    for( OptMethodList::iterator i = om_.begin(); i != om_.end(); ++i )
        delete *i;
    om_.clear();

    // parse the name string into method names
    is.str(name);
    while( !is.eof() ) {
        is >> mn;
        if( !is.fail() && mn.length() ) {
            m = OptMethod::factory( mn );
            if( !m ) throw OptimizeError( std::string("OptimizeEngine::setMethod(): invalid method \'") + mn + std::string("\'."), E_OPT_BADMETHOD );
            om_.push_back( m );
        }
    }
}


/*****************************************************************************/
OptimizeEngine::OptimizeEngine()
: cb_(OptIterationCB_null), starterrv_(1.e300), errv_(1.e300), success_frac_(1.e-5), niter_(100)
{ }

/*****************************************************************************/
OptimizeEngine::~OptimizeEngine()
{
    // clean up allocated methods
    for( OptMethodList::iterator i = om_.begin(); i != om_.end(); ++i )
        delete *i;
}


/*****************************************************************************/
/*****************************************************************************/
//                            OptMethod factory                              //
/*****************************************************************************/
/*****************************************************************************/
OptMethod* OptMethod::factory( const std::string& name )
{
    std::string n = name;
    for( std::string::iterator i = n.begin(); i!= n.end(); ++i ) {
        if( *i >= 'A' && *i <= 'Z' ) *i += ('a' - 'A');
    }

    if( n == "gradient" || n == "grad" ) {
        return new OptMethod_Gradient;
    }
    else if( n == "simultgrad" || n == "simultgradient" ) {
        return new OptMethod_SimultGradient;
    }
    else if( n == "random" || n == "rand" ) {
        return new OptMethod_Random;
    }

    return (OptMethod*) 0;
}

/*****************************************************************************/
void shuffle_vector( std::vector<int>& v )
{
    std::vector<int>::iterator i1, i2;
    double r = RNG.rand();
    size_t n;
    size_t i, j;
    size_t szv = v.size();
    int t;

    if( szv < 3 ) {
        if( szv == 2 && r >= 0.5) {
            t = v[0];
            v[0] = v[1];
            v[1] = t;
        }
        return;
    }

    // determine the number of passes
    if( r < 0.2 ) n = szv;
    else if( r < 0.4 ) n = szv * 2;
    else if( r < 0.6 ) n = szv * 3;
    else if( r < 0.8 ) n = szv * 4;
    else n = szv * 5;

    for( size_t c=0; c<n; ++c ) {
        i = (size_t) (RNG.rand() * szv);
        j = (size_t) (RNG.rand() * szv);
        if( i != j && i < szv && j < szv && RNG.rand() >= 0.5 ) {
            t = v[i];
            v[i] = v[j];
            v[j] = t;
        }
    }
}


