/**
  \file
  \brief Classes and functions for storing and manipulating network parameter data.
  \author Jay Barrett

*/
#ifndef NETWORK_PARAMETERS_NEW_CLASS
#define NETWORK_PARAMETERS_NEW_CLASS

#include <matrix/cmatrix.h>
#include <matrix/io.h>
#include <list>
#include <stdexcept>
#include "ref_count.hpp"

// define error codes
#define E_CURRENT_TYPE_INVALID     (-100)
#define E_INVALID_ZLIST            (-101)
#define E_NOT_2PORT                (-102)
#define E_INVALID_TYPE             (-103)
#define E_INVALID_ARGUMENT         (-105)
#define E_EXTRAPOLATION            (-106)
#define E_INVALID_STATE            (-107)
#define E_INVALID_ASSIGNMENT       (-109)
#define E_MATRIX_DIM               (-110)

/// exception class for NetworkParam and NetworkParamSet errors
class NetworkParametersError : public std::exception
{
protected:
    std::string msg_;
    int code_;

public:
    /// constructor
    /** \param msg the error message
        \param code the (optional) error code
    */
    NetworkParametersError( const std::string& msg, int code=0 ) throw() : msg_(msg), code_(code) { }
    virtual ~NetworkParametersError() throw() { }

    /// returns the exception error message
    virtual const char* what() const throw() { return msg_.c_str(); }
    /// returns the exception error code
    /** error codes can be checked against the
        E_* error codes defined in the header
        to determine a proper course of action in a
        try/catch block
    */
    virtual int code() const throw() { return code_; }
};

/******************************************************************************/
/******************************************************************************/
/// NetworkParam is a single set of network parameter data
/** This is basically a CMatrix object with an added frequency data
    field
*/
class NetworkParam : public matrix::Matrix< std::complex<double> >
{
protected:
    double freq_; ///< frequency (in Hz) of this data point

public:
    /// typedef to make stuff easier to read
    typedef matrix::Matrix< std::complex<double> > DataT;

    /// return the frequency
    const double& freq() const { return freq_; }
    /// return the number of ports
    /** this is the number of rows/cols in the matrix
    */
    size_t ports() const { return this->rows_; }

    /// create an explicit copy of the data
    /** this circumvents the reference-counted
        nature of the CMatrix parent object
        by forcing an explicit copy of the internal data
        to a new object
        \return a NetworkParam object with an independent
                copy of the internal data
    */
    NetworkParam copy() const {
        NetworkParam r( *this );
        r = DataT::copy();
        return r;
    }

    /// standard assignment operator
    NetworkParam& operator=( const NetworkParam& rhs ) {
        freq_ = rhs.freq_;
        DataT::operator=( rhs );
        return (*this);
    }

    /// assignment operator from a CMatrix object
    NetworkParam& operator=( const matrix::Matrix< std::complex<double> >& rhs ) {
        if( this->rows_ != rhs.rows() || this->rows_ != rhs.cols() )
            throw NetworkParametersError( "NetworkParam::operator=(): invalid assignment.", E_INVALID_ASSIGNMENT );
        DataT::operator=( rhs );
        return (*this);
    }

    /// default constructor (empty object)
    NetworkParam() : freq_(-1.) {}

    /// normal constructor
    /** \param f frequency of the network parameter data
        \param m network parameter data
        \warning an exception is thrown if the data is not square
        \exception NetworkParametersError
    */
    NetworkParam( const double& f, const DataT& m ) :
        DataT(m), freq_(f) {
        if( rows_ != cols_ ) throw NetworkParametersError( "NetworkParam::NetworkParam(): illegal matrix dimension.", E_MATRIX_DIM );
    }

    /// copy ctor
    NetworkParam( const NetworkParam& m ) :
        DataT(m), freq_(m.freq_) {}

    /// destructor
    virtual ~NetworkParam() {}
};

/******************************************************************************/
/******************************************************************************/
/// stores a set of NetworkParam objects
/**
    also performs various features such as interpolation
    between stored NetworkParam objects and conversion between
    various parameter types.

*/
class NetworkParamSet
{
public:
    // typdefs, to make type names shorter when used
    // elsewhere in this class
    typedef std::list<NetworkParam> StorageT;  ///< internal storage type for data
    typedef NetworkParam::DataT DataT;  ///< data type for network parameter data (CMatrix)
    typedef matrix::CVector::StorageT RefImpT; ///< type for reference impedance data (std::complex<double>)
    typedef NetworkParam::DataT::StorageT ScalarDataT;  ///< scalar network parameter data type (std::complex<double>)

    /// network parameter "types"
    enum e_param_type {
        S_Param,
        T_Param,
        Y_Param,
        Z_Param,
        ABCD_Param,
        H_Param,
        G_Param
    };

    /// interpolation modes
    enum e_interp_mode {
        Auto,
        Polar,
        Rect
    };

   // iterator types
   typedef StorageT::iterator iterator;
   typedef StorageT::const_iterator const_iterator;
   typedef StorageT::reverse_iterator reverse_iterator;
   typedef StorageT::const_reverse_iterator const_reverse_iterator;

protected:
    /** protected data **/
    StorageT params_;    ///< a list of NetworkParam objects
    size_t nports_;  ///< number of ports
    enum e_param_type ptype_;  ///< current parameter type
    RefImpT ref_imp_;   ///< reference impedance (complex)

   // return an iterator to the parameter whose
   //  frequency is greater than or equal to the passed frequency argument
   iterator f_lower( const double& freq ) {
       iterator i = params_.begin();
       for( ; i!=params_.end(); ++i ) {
           if( freq <= i->freq() ) break;
       }
       return i;
   }
   const_iterator f_lower( const double& freq ) const {
       const_iterator i = params_.begin();
       for( ; i!=params_.end(); ++i ) {
           if( freq <= i->freq() ) break;
       }
       return i;
   }

   /// retrieve the parameter data given a value of frequency
   /** this method will interpolate as needed
       it will always retrieve a new copy of the data
       even if an exact match is avaiable in the data set

       reference-counted data is never returned, so changes
       made to the returned NetworkParam object do not affect the
       data in the data set
       \param freq the desired frequency to retrieve data for
       \param mode the interpolation mode to use. the default
              value of Auto is normally the best choice
       \return a NetworkParam object with an independent internal
               data set
   */
   NetworkParam getparm_( const double& freq, e_interp_mode mode=Auto ) const;

   /// interpolate data
   /**  given iterators to the elements above and below
        a new set of network parameters are computed
        and returned in a NetworkParam object
        \param freq the desired frequency
        \param il an iterator pointing to the closest NetworkParam object
                  with a frequency less than freq
        \param ih an iterator pointing to the closest NetworkParam object
                  with a frequency greater than freq
        \param mode the interpolation mode
        \return a NetworkParam object with the computed parameters
   */
   NetworkParam interpolate_( const double& freq, const_iterator il, const_iterator ih, e_interp_mode mode ) const;

public:
   /// size of the data set (number of frequencies)
   size_t size() const { return params_.size(); }

   /// number of ports (size of the parameter matrix)
   /** this is 0 for an empty data set */
   size_t ports() const { return nports_; }

   /// is the data set empty?
   bool empty() const { return params_.empty(); }

   /// remove all data
   /** the current parameter type and reference impedance
        are retained though
   */
   virtual void clear() {
      nports_ = 0;
      params_.clear();
   }

   /// return the current parameter type as a string
   const char * const typestr() const {
      switch( ptype_ ) {
         case S_Param:
            return "S";
         case T_Param:
            return "T";
         case Y_Param:
            return "Y";
         case Z_Param:
            return "Z";
         case ABCD_Param:
            return "ABCD";
         case H_Param:
            return "H";
         case G_Param:
            return "G";
         default:
            return "<invalid>";
      }
   }

    /// return the current reference impedance
    /**  this is a complex number */
    const RefImpT& zref() const { return ref_imp_; }

    /// renormalize to a new reference impedance
    /** this only matters for S or T parameters
        parameters of other types do not change when this is modified

        conversions from other parameter types to S or T
        parameters will take this new reference impedance into account
        \param ref The new reference impedance (a complex number)
    */
    void renormalize( const RefImpT& ref );

    /// convert to another type using the enumerated parameter type
    /**  \param new_type the new parameter type
        \warning Some parameter represenations are only valid
                 for 2-port networks. Attempting to convert
                 to these representations for a non-2-port
                 network will result in an exception.
        \exception NetworkParametersError MatrixError
    */
    void convert_to( e_param_type new_type );

    /// convert to another type using a string
    /**  the recognized strings are (case insensitive):
        - "s"
        - "y"
        - "z"
        - "g"
        - "t"
        - "abcd"
        - "chain" (an alias for "abcd")
        - "h"

        \param typestr the name of the parameter type
        \warning Some parameter represenations are only valid
                 for 2-port networks. Attempting to convert
                 to these representations for a non-2-port
                 network will result in an exception.
        \exception NetworkParametersError MatrixError
    */
    void convert_to( const char* typestr );

    /// convert to S-parameters
    /**
      \exception NetworkParametersError MatrixError
    */
   void convert_to_s();

    /// convert to T-parameters
    /**
      \warning This is 2-port-only network representation.
      \exception NetworkParametersError MatrixError
    */
   void convert_to_t();

    /// convert to Y-parameters
    /**
      \exception NetworkParametersError MatrixError
    */
   void convert_to_y();

    /// convert to Z-parameters
    /**
      \exception NetworkParametersError MatrixError
    */
   void convert_to_z();

    /// convert to H-parameters
    /**
      \warning This is 2-port-only network representation.
      \exception NetworkParametersError MatrixError
    */
   void convert_to_h();

    /// convert to ABCD(chain)-parameters
    /**
      \warning This is 2-port-only network representation.
      \exception NetworkParametersError MatrixError
    */
   void convert_to_abcd();

    /// convert to G-parameters
    /**
      \warning This is 2-port-only network representation.
      \exception NetworkParametersError MatrixError
    */
   void convert_to_g();

   /// add data to the data set or replace existing data
   /** if the freq parameter matches a frequency that exists in the
       data set, the data in the data set will be replaced
       \param freq the frequency of the data
       \param data The network parameter data.
                   The matrix must be square
       \exception NetworkParametersError
   */
    void add( const double& freq, const DataT& data );

   /// add data to the data set or replace existing data
   /**
      \param data a NetworkParam object to add to the data set
               an explicit (not ref-counted) copy of this object is created
      \see add(double,DataT)
   */
    void add( const NetworkParam& data ) { this->add( data.freq(), data ); }

   /// remove a single data point by frequency
   /** if no matching frequency is found, nothing is removed
       and the method will fail silently
       \param freq the frequency to remove data for
   */
   void erase( const double& freq ) {
      iterator it = f_lower( freq );
      if( it != params_.end() && it->freq() == freq ) {
         params_.erase(it);
      }
   }

   /// remove a range of network parameter data sets by frequency
   /**  everything between and including the frequencies flow and fupp
        will be erased
      \param flow starting frequency
      \param fupp stopping frequency (inclusive)
   */
   void erase( const double& flow, const double& fupp ) {
      iterator it = f_lower( flow );
      while( it != params_.end() && it->freq() >= flow && it->freq() <= fupp ) {
         params_.erase(it);
      }
   }

   /// remove a single point by iterator
   void erase( iterator i ) { params_.erase(i); }

   /// remove a range of data using iterators
   /** all data starting at the lo iterator
       up to but not including the hi iterator will be erased
       \param lo the starting iterator
       \param hi the iterator to stop at (non-inclusive)
   */
   void erase( iterator lo, iterator hi ) {
      while( lo != params_.end() && lo != hi ) {
         params_.erase(lo);
      }
   }

   /// extract a single NetworkParam object for the given frequency
   /**  interpolation will be used if necesary
        an exception will be thrown for a freq parameter that
        is outside of the data range
       \param freq the frequency to extract data for
       \param mode the interpolation mode. The default value of Auto is
              good for most cases - it selects the mode based on the
              parameter type
       \exception NetworkParametersError
   */
   NetworkParam extract( const double& freq, e_interp_mode mode=Auto ) const {
      return getparm_( freq, mode );
   }

    /// explicit copy
    /**
        the copy operator only creates a reference not a "deep" copy
        so this method must be used when it is necessary to "de-couple"
        two NetworkParamSet objects
        \return a de-coupled NetworkParamSet object that is otherwise
                identical to this object
    */
    virtual NetworkParamSet copy() const {
        NetworkParamSet ret(this->nports_,this->ptype_,this->ref_imp_);
        for( const_iterator i=this->params_.begin(); i != this->params_.end(); ++i ) {
            ret.params_.push_back( i->copy() );
        }
        return ret;
    }

   /* ---------------------------------------------------------------------------------- */
   ///////                                 Iterators                               ////////
   /* ---------------------------------------------------------------------------------- */

   iterator begin() { return params_.begin(); }
   iterator end() { return params_.end(); }
   const_iterator begin() const { return params_.begin(); }
   const_iterator end() const { return params_.end(); }
   reverse_iterator rbegin() { return params_.rbegin(); }
   reverse_iterator rend() { return params_.rend(); }
   const_reverse_iterator rbegin() const { return params_.rbegin(); }
   const_reverse_iterator rend() const { return params_.rend(); }

   /* ---------------------------------------------------------------------------------- */
   ///////                             Ctors / Dtor                                ////////
   /* ---------------------------------------------------------------------------------- */

   /// default constructor
   /**
      \param nports number of ports (default=0)
      \param ptype parameter type, (default=S_Param)
      \param zref reference impedance (default=50)
   */
   NetworkParamSet( size_t nports=0, e_param_type ptype=S_Param, const RefImpT& zref=50. ) : nports_(nports), ptype_(ptype), ref_imp_(zref) { }

   /// copy constructor
   /**  create references to the NetworkParam objects in the rhs object
        this results in a new object that is "coupled" to the passed object
        so changes to NetworkParam data members in either object will affect the other.
        \param rhs the NetworkParamSet object to "copy"
   */
   NetworkParamSet( const NetworkParamSet& rhs ) : params_(rhs.params_), nports_(rhs.nports_), ptype_(rhs.ptype_), ref_imp_(rhs.ref_imp_) { }

   /// destructor
   virtual ~NetworkParamSet() { }

};   /* end of NetworkParams class defintion */

/// stream output operator
template<class E, class Ty>
std::basic_ostream<E, Ty>& operator<<( std::basic_ostream<E, Ty>& os, const NetworkParamSet& np )
{
   os << "NetworkParamSet" << std::endl << "Type: " << np.typestr() << std::endl << "Ports: " << np.ports() << std::endl << "Points: " << np.size() << std::endl;
   os << "Port Impedance List:" << std::endl << np.zref() << std::endl;
   for( NetworkParamSet::const_iterator i=np.begin(); i!= np.end(); ++i ) {
      os << "Freq: " << i->freq << std::endl << const_cast<const NetworkParamSet::DataT>(*i) << std::endl;
   }
   return os;
}

/* --------------------------------------------------------------------------------------- */
/////////////////////////////////////////////////////////////////////////////////////////////
//                               RAW CONVERSION FUNCTIONS                                  //
/////////////////////////////////////////////////////////////////////////////////////////////
/* --------------------------------------------------------------------------------------- */
// THESE PERFORM NO ARGUMENT CHECKING, SO IT IS UP TO THE USER TO ENSURE THAT
//  THEY ARE USING THE FUNCTIONS CORRECTLY AND PROVIDING VALID ARGUMENTS
//  - s, y, and z matrices must be square
//  - the zr vector (reference impedance vector)
//       must have the same dimension as the parameter data
//  - t, g, h, and abcd matrices must be 2x2
//  - when converting to t, g, h, or abcd
//       the input matrix must be 2x2
//  - to do conversions from say [S] to [H]
//      you must go through [Y] or [Z] since there is no direct conversion
//      the same goes for lots of other conversions
//  - these "can" throw a NetworkParametersError exception if something funny
//      happens, or potentially a matrix::MatrixError exception


matrix::CMatrix StoY_( const matrix::CMatrix& s, const matrix::CVector& zr );
matrix::CMatrix StoZ_( const matrix::CMatrix& s, const matrix::CVector& zr );
matrix::CMatrix StoT_( const matrix::CMatrix& s );

matrix::CMatrix YtoS_( const matrix::CMatrix& y, const matrix::CVector& zr );
matrix::CMatrix YtoZ_( const matrix::CMatrix& y );
matrix::CMatrix YtoH_( const matrix::CMatrix& y );
matrix::CMatrix YtoABCD_( const matrix::CMatrix& y );
matrix::CMatrix YtoG_( const matrix::CMatrix& y );

matrix::CMatrix ZtoS_( const matrix::CMatrix& z, const matrix::CVector& zr );
matrix::CMatrix ZtoY_( const matrix::CMatrix& z );
matrix::CMatrix ZtoH_( const matrix::CMatrix& z );
matrix::CMatrix ZtoABCD_( const matrix::CMatrix& z );
matrix::CMatrix ZtoG_( const matrix::CMatrix& z );

matrix::CMatrix HtoZ_( const matrix::CMatrix& h );
matrix::CMatrix HtoY_( const matrix::CMatrix& h );

matrix::CMatrix ABCDtoZ_( const matrix::CMatrix& abcd );
matrix::CMatrix ABCDtoY_( const matrix::CMatrix& abcd );

matrix::CMatrix TtoS_( const matrix::CMatrix& t );

matrix::CMatrix GtoZ_( const matrix::CMatrix& g );
matrix::CMatrix GtoY_( const matrix::CMatrix& g );

/*************************************************************************************/
/***                       Other stuff                                             ***/
/*************************************************************************************/

void compute_k_and_mag( const matrix::CMatrix& sp, double& k, double& MAG );


#endif  // NETWORK_PARAMETERS_NEW_CLASS
