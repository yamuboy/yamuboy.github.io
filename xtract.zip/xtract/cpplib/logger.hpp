/** \file
    \author Jay Barrett
    \brief A message-logging facility
*/

#ifndef EVENT_LOGGER_H
#define EVENT_LOGGER_H

#include <string>
#include <sstream>

// global constants
extern const int DebugEvent;   ///< a constant denoting a "debug" level event
extern const int MessageEvent; ///< a constant denoting a "message" level event
extern const int WarningEvent; ///< a constant denoting a "warning" level event
extern const int ErrorEvent;   ///< a constant denoting an "error" level event

/**************************************************************************************/
/// EventLogger base (abstract) class
class EventLogger
{
public:
   static const int DebugEvent;     ///< a constant denoting a "debug" level event
   static const int MessageEvent;   ///< a constant denoting a "message" level event
   static const int WarningEvent;   ///< a constant denoting a "warning" level event
   static const int ErrorEvent;     ///< a constant denoting an "error" level event
   static const int Debug;          ///< a constant denoting a "debug" level event
   static const int Message;        ///< a constant denoting a "message" level event
   static const int Warning;        ///< a constant denoting a "warning" level event
   static const int Error;          ///< a constant denoting an "error" level event

    /// log an event
    /** this method gets overridden in derived classes
        \param event_type one of the event type constants denoting the "level" of the event
        \param msg a string describing the event
    */
   virtual void logEvent( int event_type, const std::string& msg ) =0;
   virtual ~EventLogger() { }
};

/**************************************************************************************/
/// EventTranslator function typedef
/**
   functions of this type are passed to PushEventLogTranslator()
   to be added to the translator stack

   the translator function takes an integer event code as an arguemnt
   and return a constant character pointer or a null pointer if the event

   code cannot be translated
*/
typedef const char * (*EventTranslator) ( const int code );

/**************************************************************************************/
/// log messages to stdout
/**
   this is the default event logger
*/
/**************************************************************************************/
class StdoutEventLogger : public EventLogger
{
public:
    /// log an event
    /**
        \sa EventLogger::logEvent
        \param event_type one of the event type constants denoting the "level" of the event
        \param msg a string describing the event
    */
   virtual void logEvent( int event_type, const std::string& msg );
   virtual ~StdoutEventLogger() { }
};

/**************************************************************************************/
/// log messages to stderr
class StderrEventLogger : public EventLogger
{
public:
    /// log an event
    /**
        \sa EventLogger::logEvent
        \param event_type one of the event type constants denoting the "level" of the event
        \param msg a string describing the event
    */
   virtual void logEvent( int event_type, const std::string& msg );
   virtual ~StderrEventLogger() { }
};

/**************************************************************************************/
/// log events to a log file
/**
    if the file name of the log file is invalid
    or the file cannot be opened, then all log message are "lost" silently
*/
class FileEventLogger : public EventLogger
{
protected:
   const char* fname_;

public:
    /// log an event
    /**
        \sa EventLogger::logEvent
        \param event_type one of the event type constants denoting the "level" of the event
        \param msg a string describing the event
    */
   virtual void logEvent( int event_type, const std::string& msg );

    /// ctor
    /**
        \param fname a C-string denoting the file name
        \param append if true (the default) the logged events will be appended
               otherwise the log file will be truncated when first opened
    */
   FileEventLogger( const char * fname=(const char*)0, bool append=true );


   virtual ~FileEventLogger();
};

/**************************************************************************************/
/// this event logger throws away all events
class NullEventLogger : public EventLogger
{
public:
    /// log an event
    /**
        \sa EventLogger::logEvent
        \param event_type one of the event type constants denoting the "level" of the event
        \param msg a string describing the event
    */
   virtual void logEvent( int event_type, const std::string& msg ) { }
   virtual ~NullEventLogger() { }
};

/**************************************************************************************/
/// convenience function to log events to the current log target
/**
    \sa EventLogger::logEvent
    \param evt_type one of the event type constants denoting the "level" of the event
    \param msg a string describing the event
*/
void logEvent( int evt_type, const std::string& msg );

/// convenience function to log events to the current log target
/**
    \sa EventLogger::logEvent
    \param evt_type one of the event type constants denoting the "level" of the event
    \param code an integer error code that will attempt to be translated into a log message
           by the current translator stack
    \param msg a string describing the event
*/
void logEvent( int evt_type, const int code, const std::string& msg="" );

/**************************************************************************************/
/// set the logging target
/**
    \param logger the new log target - MUST NOT BE NULL
           use the NullEventLogger if no logging is desired
    \return the old event logger
*/
EventLogger * SetLoggingTarget( EventLogger * logger );

/**************************************************************************************/
/// set logging level
/**
   \param level an integer spcifying the logging level
          - \<2 : errors only are logged (errors are always logged)
          -  2 : errors and warnings are logged
          -  3 : errors, warnings, and messages are logged
          -  4 : errors, warnings, messages, and debug messages are logged
          -  \>4 : everything is logged (including unknown event types)
          the default level is 3
   \return the previous log level
*/
int SetLoggingLevel( int level );

/**************************************************************************************/
/// set timestamps on or off
/** \param enable if true timestamps are enabled
                  by default they are disabled
    \return the previous value of the timestamp enable state
*/
bool SetLoggingTimestamp( bool enable );

/**************************************************************************************/
/// push a new event code translator function onto the stack
/**
    \param t an event translator function to push onto the stack
            translators at the top of the stack take precidence over
            those further down (for translating events with a given event code)
    \return true on success, false if the translator is invalid (null pointer)
*/
bool PushEventLogTranslator( EventTranslator t );

/**************************************************************************************/
/// pop an event code translator function off the stack
/**
    \return true on success, false if the stack is empty
*/
bool PopEventLogTranslator();

/**************************************************************************************/
/// an event log based on a ostringstream object
/**
    this makes is convenient to create log messages
    from non-string types

    \code
    // if some_error is true, then an "error" level event log will be generated
    //  the message gets generated at the end of the block when the "log"
    //  object goes out of scope and is destroyed
    if( some_error ) {
        EventLogStream log( ErrorEvent );
        log << "The start of the message.";
        log << foo;    // include ostream output from an object foo in the message
        log << " more information.";
        log << 23 << " is a good number to log.";
    }
    \endcode

    the message can be "logged" by either calling the flush() member
    or, by destroying the object

    any message information remaining in the internal buffer
    when the object is destroyed will result in a log message
*/

/**************************************************************************************/
class EventLogStream : public std::ostringstream
{
protected:
    int evt_type_;
public:
    /// flush the current buffer to the event log
    void flush() {
        logEvent( evt_type_, this->str() );
        this->str( "" );
    }

    /// ctor
    /**
        \param ty is a constant dneoting the "level" of the event to be logged
                the default value is to log it as a "message"
    */
    EventLogStream( int ty=EventLogger::MessageEvent ) : evt_type_(ty) { }

    /// dtor
    /** when the object is destroyed, any remaining message information in the
        internal buffer will be immediately set to the log
    */
    virtual ~EventLogStream() {
        if( this->str().length() ) logEvent( evt_type_, this->str() );
    }
};

/**************************************************************************************/
/// grab a timestamp string
/** this is a convenience function
    \return a string with the current date/time timestamp
            the format is always MM/DD/YYYY HH:MM:SS.XXX (XXX is milliseconds)
*/
std::string getTimestamp();


#endif  // EVENT_LOGGER_H
