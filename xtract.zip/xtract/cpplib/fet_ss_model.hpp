/**
    \file
    \author Jay Barrett
    \brief FET small signal model class
*/

#include "model.hpp"
#include "matrix/cmatrix.h"

#ifndef FET_SS_MODEL_DEFINED
#define FET_SS_MODEL_DEFINED


/*****************************************************************/
/// FET small signal model
/** This is the M/A-COM standard FET small-signal model


    RG, RD, RS, RI, LG, B1, B2, C11, C22, C1, C2, GM, GDS
    TAU1, TAU2, GDG, GGS, CDG, CGS, and CDS

    Typical usage:
    \code
    FET_SS_Model model;
    matrix::CMatrix yp;
    ModelParamSet parms;

    parms.read_end_file( "somefile.end" );  // read model parameters from a .end file
    model.bindParams( parms );              // bind model parameters to the model
    yp = model.compute_y( 1.e9 );           // compute Y-params of the model at 1 GHz
    \endcode


    in the above code snippet, model parameters are loaded
    from a file named "somefile.end", they are bound to the model
    and the model Y-params are computed at 1 GHz
    the model.compute_y() statement could be repeated at
    other frequencies to create a set of [S], [Y] or [Z] parameters
    which could all be stored in one or more NetworkParamSet objects
*/
class FET_SS_Model : public Model
{
protected:
    matrix::CMatrix ypmat_;
    matrix::CMatrix result_;

    /// convenience method for adding an admittance to the Y-matrix
    void insert_admittance( size_t n1, size_t n2, const std::complex<double>& v ) {
        ypmat_(n1,n1) += v;
        ypmat_(n2,n2) += v;
        ypmat_(n2,n1) -= v;
        ypmat_(n1,n2) -= v;
    }

public:
    /// compute Y parameters
    /**
        \param freq the frequency to compute at in Hz
        \return a complex matrix of size 2x2
    */
    const matrix::CMatrix& compute_y( const double& freq );

    /// compute Z parameters
    /**
        \param freq the frequency to compute at in Hz
        \return a complex matrix of size 2x2
    */
    const matrix::CMatrix& compute_z( const double& freq );

    /// compute S parameters (50 ohm reference)
    /**
        \param freq the frequency to compute at in Hz
        \return a complex matrix of size 2x2
    */
    const matrix::CMatrix& compute_s( const double& freq );

    /// ctor
    FET_SS_Model() : ypmat_(8,8), result_(2,2) {}
    /// dtor
    virtual ~FET_SS_Model() {}
};

#endif  /* FET_SS_MODEL_DEFINED */
