/**
    \file
    \author Jay Barrett
    \brief Define a generic exception that can be used in programs
*/

#include <exception>
#include <string>

#ifndef GENERIC_ERROR_CLASS_DEFINED
#define GENERIC_ERROR_CLASS_DEFINED

/// a generic exception class
/** this stores an error message as a string object
*/
class GenericError : public std::exception
{
protected:
    std::string msg_;   ///< the error string

public:
    /// returns the error string
    virtual const char* what() const throw() { return msg_.c_str(); }

    /// ctor
    /** \param m the error message string */
    GenericError( const std::string& m ) throw() : msg_(m) {}
    /// dtor
    virtual ~GenericError() throw() {}
};

#endif  // GENERIC_ERROR_CLASS_DEFINED
