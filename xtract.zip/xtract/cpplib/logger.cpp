#include "logger.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <list>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <string.h>

#if defined(__GNUC__)
#define HAVE_LOCALTIME_R 1
#endif

const int DebugEvent=0x01;
const int MessageEvent=0x02;
const int WarningEvent=0x04;
const int ErrorEvent=0x08;

const int EventLogger::DebugEvent=0x01;
const int EventLogger::MessageEvent=0x02;
const int EventLogger::WarningEvent=0x04;
const int EventLogger::ErrorEvent=0x08;
const int EventLogger::Debug=0x01;
const int EventLogger::Message=0x02;
const int EventLogger::Warning=0x04;
const int EventLogger::Error=0x08;

/**************************************************************************/
// static variables used by the event logger
//  shared among all threads, changes in one thread affect all threads
/**************************************************************************/
static int eventLoggerLogLevel_ = 3;
static bool eventLoggerTimestamp_ = false;
static StdoutEventLogger eventLoggerDefaultLogTarget_;
static EventLogger * eventLoggerCurrentTarget_ = &eventLoggerDefaultLogTarget_;
static std::list<EventTranslator> eventLoggerTranslatorList_;

/**************************************************************************************/
void StdoutEventLogger::logEvent( int event_type, const std::string& msg )
{
   const char *pref = "Unknown: ";
   switch( event_type )
   {
   case EventLogger::ErrorEvent:
      pref = "Error: "; break;
   case EventLogger::WarningEvent:
      pref = "Warning: "; break;
   case EventLogger::MessageEvent:
      pref = "Message: "; break;
   case EventLogger::DebugEvent:
      pref = "Debug: "; break;
   }
   std::cout << pref << msg << std::endl;
}

/**************************************************************************************/
void StderrEventLogger::logEvent( int event_type, const std::string& msg )
{
   const char *pref = "Unknown: ";
   switch( event_type )
   {
   case EventLogger::ErrorEvent:
      pref = "Error: "; break;
   case EventLogger::WarningEvent:
      pref = "Warning: "; break;
   case EventLogger::MessageEvent:
      pref = "Message: "; break;
   case EventLogger::DebugEvent:
      pref = "Debug: "; break;
   }
   std::cerr << pref << msg << std::endl;
}

/**************************************************************************************/
void FileEventLogger::logEvent( int event_type, const std::string& msg )
{
   std::ofstream f( fname_, std::ios_base::app | std::ios_base::ate );
   const char *pref = "Unknown: ";
   switch( event_type )
   {
   case EventLogger::ErrorEvent:
      pref = "Error: "; break;
   case EventLogger::WarningEvent:
      pref = "Warning: "; break;
   case EventLogger::MessageEvent:
      pref = "Message: "; break;
   case EventLogger::DebugEvent:
      pref = "Debug: "; break;
   }

   if( f.fail() ) return; // unable to open file, return silently
   f << pref << msg << std::endl;
   f.close();
}

/**************************************************************************************/
FileEventLogger::FileEventLogger( const char * fname, bool append )
{
   if( !fname || ! *fname )
      fname = "event.log";

   fname_ = strdup( fname );

   if( !append ) {
      // delete an existing file if it exists
      unlink( fname_ );
   }
}

/**************************************************************************************/
FileEventLogger::~FileEventLogger()
{
   free((void*)fname_);
}

/**************************************************************************************/

#if !defined(HAVE_LOCALTIME_R)
struct tm * localtime_r( const time_t* t, struct tm *res )
{
   struct tm * x = localtime( t );
   *res = *x;
   return res;
}
#endif

/**************************************************************************************/
std::string getTimestamp()
{
   std::ostringstream str;
   struct timeval tv;
   struct tm tm;
   if( gettimeofday( &tv, NULL ) ) {
      // call failed, return an empty string
      return str.str();
   }
   // convert time to a useful form
   localtime_r( &tv.tv_sec, &tm );
   // set the fill character
   str.fill( '0' );

   // create a date/time string
   str << std::setfill('0') << std::setw(2) << tm.tm_mon+1 << '/';
   str << std::setfill('0') << std::setw(2) << tm.tm_mday << '/';
   str << std::setfill('0') << std::setw(4) << tm.tm_year+1900 << ' ';
   str << std::setfill('0') << std::setw(2) << tm.tm_hour << ':';
   str << std::setfill('0') << std::setw(2) << tm.tm_min << ':';
   str << std::setfill('0') << std::setw(2) << tm.tm_sec << '.';
   str << std::setfill('0') << std::setw(3) << tv.tv_usec/1000;

   return str.str();
}

/**************************************************************************************/
void logEvent( int evt_type, const std::string& msg )
{
   // determine if we need to log this event
   if( eventLoggerLogLevel_ < 2 ) {
      if( ! (evt_type & EventLogger::ErrorEvent) ) return;
   }
   else if( eventLoggerLogLevel_ == 2 ) {
      if( ! (evt_type & (EventLogger::ErrorEvent|EventLogger::WarningEvent) ) ) return;
   }
   else if( eventLoggerLogLevel_ == 3 ) {
      if( ! (evt_type & (EventLogger::ErrorEvent|EventLogger::WarningEvent|EventLogger::MessageEvent) ) ) return;
   }
   else if( eventLoggerLogLevel_ == 4 ) {
      if( ! (evt_type & (EventLogger::ErrorEvent|EventLogger::WarningEvent|EventLogger::MessageEvent|EventLogger::DebugEvent) ) ) return;
   }
   // eventLoggerLogLevel_ > 4, accept all evt_type values

   // create the message
   std::string emsg;
   // add a timestamp if necessary
   if( eventLoggerTimestamp_ ) {
      emsg += getTimestamp();
      emsg += ": ";
   }

   // add the event message text
   if( msg.length() ) emsg += msg;
   else emsg += "<null message>";

   // log it to the current target
   eventLoggerCurrentTarget_->logEvent( evt_type, emsg );
}

/**************************************************************************************/
void logEvent( int evt_type, const int code, const std::string& msg )
{
   // determine if we need to log this event
   if( eventLoggerLogLevel_ < 2 ) {
      if( ! (evt_type & EventLogger::ErrorEvent) ) return;
   }
   else if( eventLoggerLogLevel_ == 2 ) {
      if( ! (evt_type & (EventLogger::ErrorEvent|EventLogger::WarningEvent) ) ) return;
   }
   else if( eventLoggerLogLevel_ == 3 ) {
      if( ! (evt_type & (EventLogger::ErrorEvent|EventLogger::WarningEvent|EventLogger::MessageEvent) ) ) return;
   }
   else if( eventLoggerLogLevel_ == 4 ) {
      if( ! (evt_type & (EventLogger::ErrorEvent|EventLogger::WarningEvent|EventLogger::MessageEvent|EventLogger::DebugEvent) ) ) return;
   }
   // eventLoggerLogLevel_ > 4, accept all evt_type values

   // create the message
   std::string emsg;
   const char * trans = (const char*)0;
   char codestr[12];
   sprintf( codestr, "(%d): ", code );
   // add a timestamp if necessary
   if( eventLoggerTimestamp_ ) {
      emsg += getTimestamp();
      emsg += ": ";
   }

   // add an event code tranlation, if possible
   for( std::list<EventTranslator>::reverse_iterator i = eventLoggerTranslatorList_.rbegin(); i != eventLoggerTranslatorList_.rend(); ++i ) {
      trans = (**i)( code );
      if( trans ) break;  // found a translation for the error code
   }
   if( trans ) {
      emsg += codestr;
      emsg += trans;
      emsg += ": ";
   }
   else {
      emsg += codestr;
      emsg += "<unable to translate>: ";
   }

   // add the event message text
   if( msg.length() ) emsg += msg;
   else emsg += "<null message>";

   // log it to the current target
   eventLoggerCurrentTarget_->logEvent( evt_type, emsg );
}

/**************************************************************************************/
EventLogger * SetLoggingTarget( EventLogger * logger )
{
   EventLogger * old = eventLoggerCurrentTarget_;
   if( ! logger ) {
      // invalid target, do nothing
      return old;
   }

   eventLoggerCurrentTarget_ = logger;
   return old;
}

/**************************************************************************************/
int SetLoggingLevel( int level )
{
   int old = eventLoggerLogLevel_;
   if( level < 0 )
      level = 0;
   if( level > 5 )
      level = 5;
   eventLoggerLogLevel_ = level;
   return old;
}


/**************************************************************************************/
bool SetLoggingTimestamp( bool enable )
{
   bool old = eventLoggerTimestamp_;
   eventLoggerTimestamp_ = enable;
   return old;
}

/**************************************************************************************/
bool PushEventLogTranslator( EventTranslator t )
{
   if( ! t )
      return false;
   eventLoggerTranslatorList_.push_back(t);
   return true;
}

/**************************************************************************************/
bool PopEventLogTranslator()
{
   if( !eventLoggerTranslatorList_.empty() ) {
      eventLoggerTranslatorList_.pop_back();
      return true;
   }
   return false;
}

