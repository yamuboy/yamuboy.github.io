/**
    \file
    \author Jay Barrett
    \brief Curve fitting tools
*/
#ifndef CURVE_FIT_CXX_DEFINED
#define CURVE_FIT_CXX_DEFINED

#include "generic_err.hpp"

/*** various line/curve fitting routines ***/

/// linear fit
/**
    \param x an array of doubles that holds the "X" values
    \param y an array of doubles that holds the "Y" values
    \param n number of values in the x and y arrays
    \param m (out) variable in which the slope of the line is stored
    \param b (out) variable in which the Y-intercept of the line is stored
    \param r2 (out) variable in which the R-squared ("goodness of fit" or
           "coefficient of determination") is stored
*/
void linefit_mxb( const double* x, const double* y, size_t n, double& m, double& b, double& r2 );

/// linear fit where the Y-intercept passes through the origin
/**
    \param x an array of doubles that holds the "X" values
    \param y an array of doubles that holds the "Y" values
    \param n number of values in the x and y arrays
    \param m (out) variable in which the slope of the line is stored
    \param r2 (out) variable in which the R-squared ("goodness of fit" or
           "coefficient of determination") is stored
*/
void linefit_mx0( const double *x, const double *y, size_t n, double& m, double& r2 );

#endif  /* CURVE_FIT_CXX_DEFINED */
