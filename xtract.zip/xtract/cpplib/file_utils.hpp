/**
    \file
    \author Jay Barrett
    \brief File utilities
*/
#ifndef FILE_UTILS_CXX_DEFINED
#define FILE_UTILS_CXX_DEFINED

#include <string>

/// generate a new filename from a pattern
/**
//  returns a new filename, given an input filename and a replacement pattern
//  the replacement pattern can consist of any number of non-pattern characters
//  plus optionally 1 or more replacement strings
//
//  replacement strings have the syntax: %(keyword:modifier)

//  at this time the recognized keywords are:
//     - base      => the "basename" of filename, path and extension are stripped
//     - fname     => the complete filename, unaltered
//     - path      => the path, up to and including the final '/' (can be an empty string)
//     - ext       => the extension (can be an empty string
//
//   there are currently no supported modifiers

//   the idea is to add functionality for simple substring and posibly regular expression
//   modification of the replacement string

    An example:
    \code
    a = filename_pattern_replace( "/some/path/info/foobar.txt", "%(base)-23.aa%(ext)" );
    // the variable a now contains the string "foobar-23.aa.txt"
    \endcode

    \param fname the file name to use as a template
    \param pattern the pattern to generate
    \return the generated file name
*/
std::string filename_pattern_replace( const std::string& fname, const std::string& pattern );




#endif  /* FILE_UTILS_CXX_DEFINED */
