/**
  \file
  \brief Wrappers around the C-library's glob() and wordexp() functions
  \author Jay Barrett
  The classes defined here are very basic wrappers around the glob()
  and wordexp() functions that automatically handle freeing the
  data returned from these function.
*/
#include <list>
#include <string>
#include <glob.h>
#include <wordexp.h>

#ifndef SHELL_GLOB_CXX_DEFINED
#define SHELL_GLOB_CXX_DEFINED

/***************************************************************************/
/***************************************************************************/

/// A wrapper around the C-library glob() function
/** glob() performs a shell glob operation on the current
    working directory given a "pattern" to work with.

    For detailed information on how this works, see the man
    page for glob:

    man glob

*/
class ShellGlob
{
protected:
    std::list<std::string> words_;  ///< internally maintained list of returned words
    int err_; ///< error number returned form the last glob() call

public:
    // iterator types
    typedef std::list<std::string>::iterator iterator;
    typedef std::list<std::string>::const_iterator const_iterator;
    typedef std::list<std::string>::reverse_iterator reverse_iterator;
    typedef std::list<std::string>::const_reverse_iterator const_reverse_iterator;

    /// the number of words in the last expansion
    size_t num_words() const { return words_.size(); }

    /// execute a shell glob expansion
    /** this uses the C-library glob() function
        \param pattern a pattern to be passed to glob()
        \param flags a combination of GLOB_* flags defined in
               the system include file <glob.h>
               the default value of GLOB_NOCHECK means
               that the original pattern will be returned as the
               only result if no matches are found
        \return a reference to this object
                that can be used for success/failure testing
    */
    ShellGlob& exec( const char* pattern, unsigned flags = GLOB_NOCHECK );

    /// check for errors
    /** \return true if no errors occured */
    bool ok() const { return (err_ == 0); }
    /// check for errors
    /**   \return true if an error occured */
    bool operator!() const { return (err_ != 0); }

    /// get the error message for the current error condition
    const char* errmsg() const;

    // iterator functions
    iterator begin() { return words_.begin(); }
    const_iterator begin() const { return words_.begin(); }
    iterator end() { return words_.end(); }
    const_iterator end() const { return words_.end(); }
    reverse_iterator rbegin() { return words_.rbegin(); }
    const_reverse_iterator rbegin() const { return words_.rbegin(); }
    reverse_iterator rend() { return words_.rend(); }
    const_reverse_iterator rend() const { return words_.rend(); }

    /// ctor
    ShellGlob() : err_(0) {}
    /// dtor
    virtual ~ShellGlob() {}
};

/****************************************************************************/
/// A wrapper around the C-library wordexp() function
/** wordexp() performs a shell word expansion operation on the current
    working directory given a "pattern" to work with.

    For detailed information on how this works, see the man
    page for wordexp:

    man wordexp

*/
class ShellWordExp
{
protected:
    std::list<std::string> words_;  ///< internally maintained list of returned words
    int err_; ///< error number returned form the last wordexp() call

public:
    // iterator types
    typedef std::list<std::string>::iterator iterator;
    typedef std::list<std::string>::const_iterator const_iterator;
    typedef std::list<std::string>::reverse_iterator reverse_iterator;
    typedef std::list<std::string>::const_reverse_iterator const_reverse_iterator;

    /// return the number of words in the last expansion
    size_t num_words() const { return words_.size(); }

    /// execute word expansion on the pattern
    /** \param pattern the pattern to perform word expansion on
        \param flags the WRDE_* flags defined in
               the system include file <wordexp.h>
               by default, none of the flags are set
        \return a reference to this object
                that can be used for success/failure testing
    */
    ShellWordExp& exec( const char* pattern, unsigned flags = 0 );

    /// check for errors
    /** \return true if no errors occured */
    bool ok() const { return (err_ == 0); }
    /// check for errors
    /** \return true if an error occured */
    bool operator!() const { return (err_ != 0); }

    /// get the error message for the current error condition
    const char* errmsg() const;

    // iterator functions
    iterator begin() { return words_.begin(); }
    const_iterator begin() const { return words_.begin(); }
    iterator end() { return words_.end(); }
    const_iterator end() const { return words_.end(); }
    reverse_iterator rbegin() { return words_.rbegin(); }
    const_reverse_iterator rbegin() const { return words_.rbegin(); }
    reverse_iterator rend() { return words_.rend(); }
    const_reverse_iterator rend() const { return words_.rend(); }

    /// ctor
    ShellWordExp() : err_(0) {}
    /// dtor
    virtual ~ShellWordExp() {}
};


#endif  /* SHELL_GLOB_CXX_DEFINED */
