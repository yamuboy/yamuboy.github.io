/**
  \file
  \brief Defines a reference-couting wrapper class
  \author Jay Barrett
*/
#ifndef REFCOUNT_CLASS_DEFINED
#define REFCOUNT_CLASS_DEFINED

/* #define REF_COUNT_MEM_DEBUG   1 */

#ifdef REF_COUNT_MEM_DEBUG
#include <list>
#include <iostream>
#endif

/***********************************************************************/
/// RefCount is a class for counting references
/** RefCount is basically an integer counter
    with a few convienient methods and an initializer

    it is used by the RC<Ty> template class below
*/
/***********************************************************************/
class RefCount
{
private:
    /// internal counter
    int count_;

public:
    /// add a reference (increment the counter)
    /** \return the current reference count */
    int AddRef() { return ++count_; }
    /// delete a reference (decrement the counter)
    /** \return the current reference count */
    int DelRef() { return --count_; }

    RefCount() : count_(0) {}
    ~RefCount() {}
};


#ifdef REF_COUNT_MEM_DEBUG
/***********************************************************************/
// this is a debugging class, it is normally removed by the
//  preprocessor unless the macro REF_COUNT_MEM_DEBUG is defined
class RC_debug {
private:
    std::list<const void *> segs_;

public:
    void add( const void * seg ) {
        segs_.push_back( seg );
    }
    void remove( const void * seg ) {
        std::list<const void *>::iterator i = segs_.begin();
        for( ; i != segs_.end(); ++i ) {
            if( *i == seg ) break;
        }
        if( i != segs_.end() ) segs_.erase( i );
        else std::cerr << "Error: segment " << seg << " not managed." << std::endl;
    }

    void list() const {
        for( std::list<const void *>::const_iterator i = segs_.begin(); i != segs_.end(); ++i ) {
            std::cerr << *i << std::endl;
        }
    }

    ~RC_debug() {
        if( ! segs_.empty() ) {
            std::cerr << "MEMORY LEAK!!!!" << std::endl;
            this->list();
            std::cerr << "--------------------------" << std::endl;
        }
    }
};

RC_debug& get_RC_debug();
/** end of debugging class **/
#endif


/*****************************************************************************/
/// reference-counting wrapper class template 
/**
 * template class RC<ty> is the reference-counting wrapper
 *  the normal way to use it is to construct an object of some type with the new
 *  operator and then feed it into the constructor of the RC<> template object
 *  for example:
 *  \code
     RC<Foo> x( new Foo );
    \endcode
 *  which creates an RC<> object x that holds a pointer to
 *  a Foo object
 *  to access the Foo object:
 *  \code
       *x          // is the Foo object
        x->bar()   // accesses the bar() method of the Foo object
    \endcode
 *  \tparam Ty the object type that is to be reference counted
 *  \warning Reference-counted objects behave differently than
             "normal" C++ objects, since multiple copies of the
             same reference-counted object are actually the same
             object. So, changes to one object affect all of the
             other reference objects as well.
 */
/*****************************************************************************/
template<class Ty> class RC
{
private:
    Ty* ref_;        ///< the pointer being reference-counted
    RefCount* rc_;   ///< the reference-counting object (a fancy integer object)

public:
    /// member access operator
    /** \return a pointer to the ref-counted object that
                is used to access its member functions and data
    */
    Ty* operator->() { return ref_; }
    /// member access operator (const version)
    /** \return a const pointer to the ref-counted object that
                is used to access its (const) member functions and data
    */
    const Ty* operator->() const { return ref_; }

    /// de-referencing operator
    /** \return a reference to the ref-counted object */
    Ty& operator*() { return *ref_; }
    /// de-referencing operator (const)
    /** \return a const reference to the ref-counted object */
    const Ty& operator*() const { return *ref_; }

    /// compare_equal operator
    /** see if two RC<Ty> objects hold a reference to the same pointer
      \param rhs the object that this object is being compared against
      \return true if the two RC<Ty> object refer to the same pointer
    */ 
    bool operator==( const RC<Ty>& rhs ) const { return (ref_==rhs.ref_); }

    /// compare_not_equal operator
    /** see if two RC<Ty> objects hold a reference to different pointers
      \param rhs the object that this object is being compared against
      \return true if the two RC<Ty> object refer to different pointers 
    */ 
    bool operator!=( const RC<Ty>& rhs ) const { return (ref_!=rhs.ref_); }

    /// check if the pointer that is being refcounted is non-null
    bool isValid() const { return (bool) ref_; }
    /// check if the pointer that is being refcounted is null
    bool isNull() const { return (ref_==0); }
    /// check if the pointer that is being refcounted is null
    bool operator!() const { return (ref_==0); }

    /// assignment (copy) operator
    /** Change the internally-held reference
        to that of the rhs object
 
        Automatically free the previous reference if necessary
        \param rhs a RC<Ty> object to "copy"
    */
    RC<Ty>& operator=( const RC<Ty>& rhs ) {
        if( this != &rhs ) {
            // only make changes if the rhs object
            //  is not the same object as this object
            //  as in "a = a;"
            if( rc_->DelRef() == 0 ) {
#ifdef REF_COUNT_MEM_DEBUG
                get_RC_debug().remove( ref_ );
#endif
                delete ref_;
                delete rc_;
            }
            ref_ = rhs.ref_;
            rc_ = rhs.rc_;
            rc_->AddRef();
        }
        return *this;
    }

    /** contructors **/
    /// create a reference-counted null pointer
    /**  this serves no purpose except to define a default constructor
         this is necessary in order to make this class compatible
         with STL containers that require objects to have a default
         constructor 
    */
    RC() : ref_(0), rc_(0) {
        rc_ = new RefCount;
        rc_->AddRef();
    }
    /// create a new reference-counted object
    /**  allocate a new reference counter and store the
         pointer passed in
         \param p a pointer to an object of type Ty that was
                allocated with the new operator
         \warning the pointer MUST be allocated with new, otherwise
                  a segfault (or worse) will occur when the object
                  is freed
    */
    RC( Ty* p ) : ref_(p), rc_(0) {
#ifdef REF_COUNT_MEM_DEBUG
        get_RC_debug().add( ref_ );
#endif
        rc_ = new RefCount;
        rc_->AddRef();
    }
    /// copy constructor
    /** stores copies of the reference counter and the pointer
        from the rhs object in the member data
        
        then increments the reference counter
        \param rhs a Rc<Ty> object to "copy"
    */
    RC( const RC<Ty>& rhs ) : ref_(rhs.ref_), rc_(rhs.rc_) {
        rc_->AddRef();
    }

    /// destructor 
    /**  decrements the reference count by 1
         if the count reaches zero
         both the reference count object
         and the pointer are deleted
         using the delete operator
    */
    ~RC() {
        if( rc_->DelRef() == 0 ) {
#ifdef REF_COUNT_MEM_DEBUG
            get_RC_debug().remove( ref_ );
#endif
            delete ref_;
            delete rc_;
        }
    }
};

#endif   /* REFCOUNT_CLASS_DEFINED */

