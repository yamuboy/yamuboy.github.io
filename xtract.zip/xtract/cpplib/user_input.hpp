/**
 * \file
 * \author Jay Barrett
 * \brief A very simple class for interactive user input
 */
#include <fstream>
#include <string>

#ifndef UserInput_Class_defined
#define UserInput_Class_defined

// error codes
#define E_USERINPUT_NOSTREAM        (-1)
#define E_USERINPUT_BADSTREAM       (-2)
#define E_USERINPUT_STREAMFAIL      (-3)
#define E_USERINPUT_EOF             (-4)
#define E_USERINPUT_NUMFAIL         (-5)
#define E_USERINPUT_TOOFEW          (-6)


/// UserInput is a class that queries the user for data using stdin/stdout
/** The main feature is the overloaded get() method.
   The get() method prints a string to stdout
   (which can be suppressed by setting silent mode)
   then reads a single line from the input stream (stdin, unless
   a different stream is tie() 'd) and the appropriate data is read
   from that line.

   \warning Only a single line is read, so all the expected data must appear
            on that single line
*/
class UserInput
{
public:
    /// ask for a C++ string from the user
    /** \param outstr a string to print to stdout
        \param str a std::string that holds the user reponse
        \return a reference to the UserInput object
    */
    UserInput& get( const char* outstr, std::string& str ) {
        get_response( outstr );
        if( !err_ ) str = ln_;
        return *this;
    }

    /// ask for a C-style string from the user
    /** \param outstr a string to print to stdout
        \param str a C-style string that holds the user reponse
        \param sz the size of the C-style string
        \return a reference to the UserInput object
    */
    UserInput& get( const char* outstr, char* str, size_t sz ) {
        get_response( outstr );
        if( !err_ ) {
            // copy up to n-1 characters into the array
            // to leave space for the final \0 character
            ln_.copy( str, sz-1 );
            // ensure NULL-termination
            str[(sz<=ln_.length()) ? sz-1 : ln_.length()] = '\0';
        }
        return *this;
    }

    /// ask for a double-precision float from the user
    /** \param outstr a string to print to stdout
        \param dbl a double reference that holds the user reponse
        \return a reference to the UserInput object
    */
    UserInput& get( const char* outstr, double& dbl ) {
        get_response( outstr );
        if( !err_ ) {
            std::istringstream is( ln_ );
            is >> dbl;
            if( is.fail() ) err_ = E_USERINPUT_NUMFAIL;
        }
        return *this;
    }

    /// ask for an array of double-precision floats from the user
    /** \param outstr a string to print to stdout
        \param lst a double array that holds the user reponse
        \param n the number of floats to read (lst must be at least this size)
        \return a reference to the UserInput object
    */
    UserInput& get( const char* outstr, double* lst, size_t n ) {
        get_response( outstr );
        if( !err_ ) {
            std::istringstream is( ln_ );
            for( size_t i=0; i<n; i++ ) {
                is >> lst[i];
                if( is.fail() ) {
                    err_ = E_USERINPUT_TOOFEW;
                    break;
                }
            }
        }
        return *this;
    }

    /// ask for an integer from the user
    /** \param outstr a string to print to stdout
        \param in an integer reference that holds the user reponse
        \return a reference to the UserInput object
    */
    UserInput& get( const char* outstr, int& in ) {
        get_response( outstr );
        if( !err_ ) {
            std::istringstream is( ln_ );
            is >> in;
            if( is.fail() ) err_ = E_USERINPUT_NUMFAIL;
        }
        return *this;
    }

    /// ask for an array of integers from the user
    /** \param outstr a string to print to stdout
        \param lst an integer array that holds the user reponse
        \param n the number of ints to read (lst must be at least this size)
        \return a reference to the UserInput object
    */
    UserInput& get( const char* outstr, int* lst, size_t n ) {
        get_response( outstr );
        if( !err_ ) {
            std::istringstream is( ln_ );
            for( size_t i=0; i<n; i++ ) {
                is >> lst[i];
                if( is.fail() ) {
                    err_ = E_USERINPUT_TOOFEW;
                    break;
                }
            }
        }
        return *this;
    }

    /// set/unset silent mode
    /** in silent mode the output string is not printed to stdout
        \param yes if true (the default), set silent mode
        \return void
    */
    void set_silent( bool yes=true ) { silent_ = yes; }

    /// tie a stream for reading input
    /** \param s the stream to tie
        \return void
    */
    void tie( std::istream& s ) {
        stream_ = &s;
        clear(); }

    /// revert to reading from stdin
    /** \return void */
    void untie() { stream_ = &std::cin; }

    /// get the current error messsage
    /** \return a const char* indicating the most recent error */
    const char* errmsg() const {
        switch( err_ ) {
            case E_USERINPUT_NOSTREAM:
                return "No stream is tied.";
            case E_USERINPUT_BADSTREAM:
                return "Fatal stream failure.";
            case E_USERINPUT_STREAMFAIL:
                return "Stream failure.";
            case E_USERINPUT_EOF:
                return "EOF encountered during read.";
            case E_USERINPUT_NUMFAIL:
                return "Failed to read a numeric value.";
            case E_USERINPUT_TOOFEW:
                return "Failed to read the correct number of values.";
            case 0:
                return "No error.";
            default:
                return "Unexpected error code.";
        }
    }

    /// clear error flags
    /** \return void */
    void clear() { if( stream_ ) stream_->clear(); err_=0; }

    /// check for errors
    /** \return true when an error condition is present */
    bool operator!() const { return err_; }
    /// check for errors
    /** \return true if no error condition is present */
    bool ok() const { return !err_; }

    /// default constructor
    UserInput() : stream_(&std::cin), err_(0), silent_(0) { }
    /// constructor
    /** \param is a stream to tie() */
    UserInput( std::istream& is ) : stream_(&is), err_(0), silent_(0) { }

    /// destructor
    virtual ~UserInput() { }

protected:
    std::string ln_;
    std::istream* stream_;
    int err_;
    bool silent_;

    /// get the user response
    /**
       write the output string to stdout (if not in silent mode)
       then read the user response line
       \param outstr the string to write to the output
    */
    UserInput& get_response( const char* outstr ) {
        if( ! silent_ ) std::cout << outstr << std::endl;
        if( ! err_ ) {
            if( ! stream_ ) err_ = E_USERINPUT_NOSTREAM;
            else if( stream_->bad() ) err_ = E_USERINPUT_BADSTREAM;
            else if( stream_->eof() ) err_ = E_USERINPUT_EOF;
            else {
                std::getline( *stream_, ln_ );
                if( stream_->fail() ) err_ = E_USERINPUT_STREAMFAIL;
            }
        }
        return *this;
    }
};

#endif  // UserInput_Class_defined
