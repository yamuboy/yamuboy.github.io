/**
    \file
    \author Jay Barrett
    \brief Random number abstraction tools

    This file is currently unfinished and not used by anything else.
*/


/*****************************************************************************/

class RandFloat
{
protected:

public:
    virtual double getRand() const =0;

    virtual ~RandNG() {}

    static double rand();
    static void setMethod(  );
};


class RandNG_drand48 : public RandNG
{
protected:
    virtual void init();

public:
    virtual double rand() const =0;

    RandNG() { this->init(); }
    virtual ~RandNG() {}
};



    // initialize the random number generator
    void rand_init();
    // compute a random number
    double rand() { return drand48(); }




