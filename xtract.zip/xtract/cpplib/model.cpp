#include "model.hpp"


void Model::merge_default_params()
{
    std::map<std::string,double>::const_iterator i = default_params.begin();
    ModelParamSet::iterator m;
    for( ; i != default_params.end(); ++i ) {
        m = pmap_.find( i->first );
        if( m == pmap_.end() ) {
            pmap_[i->first] = ModelParam( i->first, i->second, ModelParam::fixed );
        }
    }
}

Model::~Model() {}

