#include "file_utils.hpp"
#include "logger.hpp"


/***************************************************************************************/
std::string filename_pattern_replace( const std::string& fname, const std::string& pattern )
{
    std::string ret;
    std::string tmp( pattern );
    std::string pat, name, mod, repl;
    size_t p;

    while( (p = tmp.find( "%(" )) != std::string::npos ) {
        ret += tmp.substr(0,p);
        tmp = tmp.substr(p);
        p = tmp.find( ')' );
        if( p == std::string::npos ) break;
        pat = tmp.substr(0,p+1);
        if( p+1 < tmp.length() ) tmp = tmp.substr(p+1);
        else tmp = "";

        // process the pattern
        //  make sure it is not empty
        //  then split it into a name and modifier (if the modifier is present)
        if( pat.length() > 3 ) {
            pat = pat.substr(2,pat.length()-3);
            p = pat.find( ':' );
            if( p < pat.length() - 1 ) {
                name = pat.substr(0,p);
                mod = pat.substr(++p);
            }
            else {
                name = pat;
                mod = "";
            }
        }
        else continue;

        // determine the un-modified replacement string
        repl = "";
        if( name == "base" ) {
            p = fname.find_last_of( ".\\/" );
            if( p != std::string::npos && fname[p] == '.' && p && fname[p-1] != '/' && fname[p-1] != '\\' )
                repl = fname.substr(0,p);
            else repl = fname;
            p = repl.find_last_of( "\\/" );
            if( p != std::string::npos ) {
                if( p < repl.length()-1 ) repl = repl.substr(p+1);
                else repl = "";
            }
        }
        else if( name == "path" ) {
            p = fname.find_last_of( "\\/" );
            if( p != std::string::npos ) repl = fname.substr(0,p+1);
        }
        else if( name == "ext" ) {
            p = fname.find_last_of( ".\\/" );
            if( p != std::string::npos && fname[p] == '.' && p && fname[p-1] != '/' && fname[p-1] != '\\' )
                repl = fname.substr(p);
        }
        else if( name == "fname" ) {
            repl = fname;
        }
        else {
            EventLogStream log( WarningEvent );
            log << "filename_pattern_replace(): invalid pattern: " << name;
        }

        // do replacement string modification


        /*** UNFINISHED ***/



        // add the modified replacement data to the return string
        ret += repl;
    }

    // push any remaining characters into the return string
    ret += tmp;

    return ret;
}


