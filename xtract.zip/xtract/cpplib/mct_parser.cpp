#include "mct_parser.hpp"

/*********************************************************************************/

bool MCT_File_Parser::parse()
{
    // init class variables
    initVars();

    // check the file name
    if( ! fname_.length() ) {
        setError( "MCT_File_Parser::parse(): no file name set." );
        return false;
    }

    // open the file
#ifdef WIN32
    is_.open(fname_.c_str(),std::ios_base::in|std::ios_base::binary);
#else
    is_.open(fname_.c_str());
#endif
    if( is_.fail() ) {
        setError( std::string("MCT_File_Parser::parse(): ") + fname_ + ": file not readable." );
        return false;
    }

    // parse the file
    try {
        // read the header
        readHeader();

        // see if this file gets special handling
        // otherwise run in through the standard parser
        if( mode_==1 ) {
            parseFET();
        }
        else if( mode_==2 ) {
            parseBipolar();
        }
        else {
            parseGeneric();
        }
    }
    catch( std::exception& e ) {
        is_.close();
        setError( std::string("Exception: ") + std::string(e.what()) + " Caught by MCT_File_Parser::parse()." );
        return false;
    }

    is_.close();
    return true;
}

/*********************************************************************************/

std::string MCT_File_Parser::getInfo() const
{
    std::ostringstream ss;
    std::list<std::string> names;
    ss << "DC blocks: " << dcBlockCount() << std::endl;
    names = dcBlockNames();
    for( std::list<std::string>::iterator i=names.begin(); i != names.end(); ++i ) {
        ss << "     " << *i << std::endl;
    }

    ss << "S2P blocks: " << s2pBlockCount() << std::endl;
    names = s2pBlockNames();
    for( std::list<std::string>::iterator i=names.begin(); i != names.end(); ++i ) {
        ss << "     " << *i << std::endl;
    }

    ss << "NF blocks: " << nfBlockCount() << std::endl;
    names = nfBlockNames();
    for( std::list<std::string>::iterator i=names.begin(); i != names.end(); ++i ) {
        ss << "     " << *i << std::endl;
    }

    return ss.str();
}

/*********************************************************************************/

void MCT_File_Parser::readHeader()
{
    std::string line;
    // make sure the header string storage is adequately sized
    header_.reserve( 4096 );
    // read the file header
    while( readLine(line) )
    {
        if( lineno_==1 && line.substr(0,11) != "!FILE NAME:" ) {
            throwError( std::string("MCT_File_Parser::getHeader(): ") + fname_ + ": invalid format (not an MCT data file?)." );
            return;
        }
        if( !line.length() ) continue;

        // check for conditions that signify the end of the header
        if( line[0] != '!' || line.substr(0,6) == "!BIAS:" || line.substr(0,8) == "!**BIAS:" ||
         (line.find("Freq") != std::string::npos && (line.find("Nfig") != std::string::npos || line.find("S11-Mag") != std::string::npos)) )
        {
            unreadLine();
            break;
        }
        else if( (line.substr(0,4) == "!Vbr" || line.substr(0,5) == "! Vbr") && line.find("Idss") != std::string::npos) {
            // this is a FET data file
            mode_=1;
            header_ += line;
            header_ += '\n';
            if( readLine(line) ) {
                header_ += '!';
                header_ += line;
                header_ += '\n';
            }
            break;
        }
        else if( line.substr(0,7) == "!Vb_beo" ) {
            // this is an HBT data file
            mode_=2;
            header_ += line;
            header_ += '\n';
            if( readLine(line) ) {
                header_ += '!';
                header_ += line;
                header_ += '\n';
            }
            break;
        }
        // append this line to the header
        header_ += line;
        header_ += '\n';
    }
}

/*********************************************************************************/

std::list<std::string> MCT_File_Parser::dcBlockNames() const
{
    std::list<std::string> r;
    bool match;
    for( std::list<DC_DataBlock>::const_iterator i = dcBegin(); i != dcEnd(); ++i ) {
        match = false;
        for( std::list<std::string>::iterator j = r.begin(); j != r.end(); ++j ) {
            if( i->getName() == *j ) {
                match = true;
                break;
            }
        }
        if( !match ) r.push_back( i->getName() );
    }
    return r;
}

/*********************************************************************************/

std::list<std::string> MCT_File_Parser::s2pBlockNames() const
{
    std::list<std::string> r;
    bool match;
    for( std::list<S2P_DataBlock>::const_iterator i = s2pBegin(); i != s2pEnd(); ++i ) {
        match = false;
        for( std::list<std::string>::iterator j = r.begin(); j != r.end(); ++j ) {
            if( i->getName() == *j ) {
                match = true;
                break;
            }
        }
        if( !match ) r.push_back( i->getName() );
    }
    return r;
}

/*********************************************************************************/

std::list<std::string> MCT_File_Parser::nfBlockNames() const
{
    std::list<std::string> r;
    bool match;
    for( std::list<NF_DataBlock>::const_iterator i = nfBegin(); i != nfEnd(); ++i ) {
        match = false;
        for( std::list<std::string>::iterator j = r.begin(); j != r.end(); ++j ) {
            if( i->getName() == *j ) {
                match = true;
                break;
            }
        }
        if( !match ) r.push_back( i->getName() );
    }
    return r;
}

/*********************************************************************************/

void MCT_File_Parser::parseGeneric()
{
    std::string line;
    std::string dcname = "dcdata";
    std::string s2pname = "s2p";
    std::string nfname = "noise";
    DC_Data bias;

    while( readLine(line) )
    {
        if( !line.length() ) continue;

        if( line[0] == '#' ) readTouchstoneHeader( line );
        else if( line[0] == '!' ) {
            if( line.substr(0,6) == "!BIAS:" ) {
                // bias point info for S2P and noise data
                bias = readBiasLine(line);
            }
        }
        else {
            // this is probably a data line
            // unread the line (this pushes back the stream pointer)
            unreadLine();

            // determine which parser to call
            //  by the number of floats on the line
            switch( countFloats(line) ) {
            case 3:
                parseBlockNoise( nfname, bias ); break;
            case 4:
                parseBlockDC( dcname ); break;
            case 9:
                parseBlockS2P( s2pname, bias ); break;
            default:
                throwError( std::string("MCT_File_Parser::parseGeneric(): ") + fileLineStr() + ": parse error." );
            }
        }
    }
}

/*********************************************************************************/

void MCT_File_Parser::parseFET()
{
    std::string line;
    std::string dcname = "unknown";
    std::string s2pname = "unknown";
    std::string nfname = "noise";
    DC_Data bias;

    while( readLine(line) )
    {
        if( !line.length() ) continue;

        if( line[0] == '#' ) readTouchstoneHeader( line );
        else if( line[0] == '!' ) {
            // look for patterns that signify section breaks in the file
            if( line.find("BREAKDOWN IV") != std::string::npos )
                dcname = "vbriv";
            else if( line.find("FORWARD IV") != std::string::npos )
                dcname = "fwdiv";
            else if( line.find("DC IV") != std::string::npos )
                dcname = "ivcurves";
            else if( line.find("COLD FET") != std::string::npos )
                s2pname = "coldfet";
            else if( line.find("S-PARAMETERS") != std::string::npos )
                s2pname = "s2p";
            else if( line.substr(0,6) == "!BIAS:" ) {
                // bias point info for S2P and noise data
                bias = readBiasLine(line);
            }
        }
        else {
            // this is probably a data line
            // unread the line (this pushes back the stream pointer)
            unreadLine();

            // determine which parser to call
            //  by the number of floats on the line
            switch( countFloats(line) ) {
            case 3:
                parseBlockNoise( nfname, bias ); break;
            case 4:
                parseBlockDC( dcname ); break;
            case 9:
                parseBlockS2P( s2pname, bias ); break;
            default:
                throwError( std::string("MCT_File_Parser::parseFET(): ") + fileLineStr() + ": parse error." );
            }
        }
    }
}

/*********************************************************************************/

void MCT_File_Parser::parseBipolar()
{
    std::string line;
    std::string dcname = "unknown";
    std::string s2pname = "unknown";
    std::string nfname = "noise";
    DC_Data bias;

    while( readLine(line) )
    {
        if( !line.length() ) continue;

        if( line[0] == '#' ) readTouchstoneHeader( line );
        else if( line[0] == '!' ) {
            // look for patterns that signify section breaks in the file
            if( line.find("FORWARD GUMMEL") != std::string::npos )
                dcname = "fwdgummel";
            else if( line.find("REVERSE GUMMEL") != std::string::npos )
                dcname = "revgummel";
            else if( line.find("FLYBACK") != std::string::npos )
                dcname = "flyback";
            else if( line.find("IV-CURVES") != std::string::npos )
                dcname = "ivcurves";
            else if( line.find("COLD BJT") != std::string::npos )
                s2pname = "hothbt";
            else if( line.find("CBC BJT") != std::string::npos )
                s2pname = "cbc";
            else if( line.find("CBE BJT") != std::string::npos )
                s2pname = "cbe";
            else if( line.find("S-PARAMETERS") != std::string::npos )
                s2pname = "s2p";
            else if( line.substr(0,6) == "!BIAS:" ) {
                // bias point info for S2P and noise data
                bias = readBiasLine(line);
            }
        }
        else {
            // this is probably a data line
            // unread the line (this pushes back the stream pointer)
            unreadLine();

            // determine which parser to call
            //  by the number of floats on the line
            switch( countFloats(line) ) {
            case 3:
                parseBlockNoise( nfname, bias ); break;
            case 4:
                parseBlockDC( dcname ); break;
            case 9:
                parseBlockS2P( s2pname, bias ); break;
            default:
                throwError( std::string("MCT_File_Parser::parseBipolar(): ") + fileLineStr() + ": parse error." );
            }
        }
    }
}

/*********************************************************************************/

DC_Data MCT_File_Parser::readBiasLine( const std::string& line ) const
{
    double v1, v2;
    double i1, i2;
    std::istringstream ss( line );
    std::string x;

    ss >> x >> x >> x >> v2;
    ss >> x >> x >> x >> i2;
    ss >> x >> x >> x >> v1;
    ss >> x >> x >> x >> i1;

    return DC_Data( v1, v2, i1, i2 );
}

/*********************************************************************************/

int MCT_File_Parser::countFloats( const std::string& line ) const
{
    int n = 0;
    double x;
    std::istringstream ss( line );
    while( !ss.fail() ) {
        ss >> x;
        if( !ss.fail() ) ++n;
    }
    return n;
}

/*********************************************************************************/

bool MCT_File_Parser::readFloats( const std::string& line, double* vals, int n_vals ) const
{
    int n = 0;
    std::istringstream ss( line );
    while( !ss.fail() && n < n_vals )
        ss >> vals[n++];
    return (!ss.fail());
}

/*********************************************************************************/

void MCT_File_Parser::parseBlockDC( const std::string& name )
{
    DC_DataBlock d( name );
    std::string line;
    double vals[4];
    while( readLine(line) && readFloats(line,vals,4) )
        d.push( DC_Data(vals[2],vals[0],vals[3],vals[1]) );
    if( d.size() ) dcblocks_.push_back( d );
    if( !is_.eof() ) unreadLine();
}

/*********************************************************************************/

void MCT_File_Parser::parseBlockS2P( const std::string& name, const DC_Data& bias )
{
    S2P_DataBlock d( name );
    std::string line;
    double vals[9];
    d.setBias(bias);
    static const double deg2rad = M_PI / 180.;
    while( readLine(line) && readFloats(line,vals,9) ) {
        // convert data
        //  this could be more complicated if we didn't ignore
        //  the touchstone header, but it is irrelevant for MCT data
        d.push( S2P_Data(vals[0],
            std::complex<double>(vals[1]*cos(deg2rad*vals[2]),vals[1]*sin(deg2rad*vals[2])),
            std::complex<double>(vals[5]*cos(deg2rad*vals[6]),vals[5]*sin(deg2rad*vals[6])),
            std::complex<double>(vals[3]*cos(deg2rad*vals[4]),vals[3]*sin(deg2rad*vals[4])),
            std::complex<double>(vals[7]*cos(deg2rad*vals[8]),vals[7]*sin(deg2rad*vals[8]))) );
    }
    if( d.size() ) s2pblocks_.push_back( d );
    if( !is_.eof() ) unreadLine();
}

/*********************************************************************************/

void MCT_File_Parser::parseBlockNoise( const std::string& name, const DC_Data& bias )
{
    NF_DataBlock d( name );
    std::string line;
    double vals[3];
    d.setBias(bias);
    while( readLine(line) && readFloats(line,vals,3) )
        d.push( NF_Data(vals[0],vals[1],vals[2]) );
    if( d.size() ) nfblocks_.push_back( d );
    if( !is_.eof() ) unreadLine();
}

