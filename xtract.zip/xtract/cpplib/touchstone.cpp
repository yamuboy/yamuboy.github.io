#include "touchstone.hpp"
#include <sstream>
#include <fstream>

static size_t read_doubles_from_string( const std::string& str, double* v, size_t sz_v );

/*****************************************************************************************/

const double Touchstone::radians2degrees = 57.295779513082320876;
const double Touchstone::degrees2radians = 0.017453292519943295769;

/************************************************************************************************/
/************************************************************************************************/

Touchstone::Touchstone() : writeFormat_(MagAngle), freqScale_(Hertz), precision_(6), blockIndent_("\t\t"), recordSep_("\t"),
complexSep_(" "), fpMode_(FPauto), is_(0), linecount_(0) { }

Touchstone::Touchstone( const Touchstone& rhs )
: NetworkParamSet(rhs), header_(rhs.header_), writeFormat_(rhs.writeFormat_), freqScale_(rhs.freqScale_), precision_(rhs.precision_),
blockIndent_(rhs.blockIndent_), recordSep_(rhs.recordSep_), complexSep_(rhs.complexSep_), fpMode_(rhs.fpMode_), is_(rhs.is_), linecount_(rhs.linecount_) { }

Touchstone::Touchstone( const NetworkParamSet& rhs )
: NetworkParamSet(rhs), writeFormat_(MagAngle), freqScale_(Hertz), precision_(6), blockIndent_("\t\t"), recordSep_("\t"),
complexSep_(" "), fpMode_(FPauto), is_(0), linecount_(0) { }

/*****************************************************************************************/
// read touchstone data from a file
Touchstone& Touchstone::read( const std::string& fname )
{
    fname_ = fname;
   if( fname.empty() )
        throw TouchstoneError( "Touchstone::read_file(): invalid filename.", E_INVALID_FNAME );
   std::ifstream file( fname.c_str() );
   if( !file )
        throw TouchstoneError( std::string("Touchstone::read_file(): stream could not be opened for reading: ") + fname, E_STREAM_ERROR );
   this->read_stream( file );
   return (*this);
}

/*****************************************************************************************/
// write touchstone data to a file
const Touchstone& Touchstone::write( const std::string& fname ) const
{
   if( fname.empty() )
        throw TouchstoneError( "Touchstone::write_file(): invalid filename.", E_INVALID_FNAME );
   std::ofstream file( fname.c_str() );
   if( !file )
        throw TouchstoneError( std::string("Touchstone::write_file(): stream could not be opened for writing: ") + fname, E_STREAM_ERROR );
   this->write_stream( file );
   return (*this);
}

/*****************************************************************************************/
// write touchstone data to an ostream
std::ostream& Touchstone::write_stream( std::ostream& os ) const
{
   if( os.bad() )
      throw TouchstoneError( "Touchstone::write_stream(): stream failure.", E_STREAM_ERROR );
   else if( !nports_ )
      throw TouchstoneError( "Touchstone::write_stream(): data set has no ports.", E_NO_PORTS );

   //  check that the reference impedance is purely real (only for S-params)
   if( ptype_ == S_Param && ref_imp_.imag() != 0. )
      throw TouchstoneError( "Touchstone::write_stream(): complex port impedances are not allowed.", E_COMPLEX_IMPEDANCE );

   // make sure that we are writing a supported parameter type
   if( ptype_ != S_Param && ptype_ != Y_Param && ptype_ != Z_Param && ptype_ != G_Param && ptype_ != H_Param )
        throw TouchstoneError( "Touchstone::write_stream(): invalid parameter type.", E_INVALID_TYPE );

   // everything appears to be OK, continue with the data write

   // set the stream exception mask
   std::ios::iostate except_msk = os.exceptions();
   os.exceptions( std::ostream::badbit | std::ostream::failbit );

    try {
       // write the header
       if( header_.length() > 0 ) {
          os << header_;
          if( *header_.rbegin() != '\n' )
             os << std::endl;
       }

       // write the touchstone format line
       os << "# ";
       switch( freqScale_ )  // frequency scaling
       {
       case Terahertz:
          os << "THZ "; break;
       case Gigahertz:
          os << "GHZ "; break;
       case Megahertz:
          os << "MHZ "; break;
       case Kilohertz:
          os << "KHZ "; break;
       default:
       case Hertz:
          os << "HZ "; break;
       }
       switch( ptype_ )  // parameter type
       {
       case Z_Param:
          os << "Z "; break;
       case Y_Param:
          os << "Y "; break;
       case G_Param:
          os << "G "; break;
       case H_Param:
          os << "H "; break;
       case S_Param:
          os << "S "; break;
       case T_Param:
       case ABCD_Param:  // these are handled above, this is to prevent compiler warnings
          break;
       }
       switch( writeFormat_ )  // data format
       {
       case RealImag:
          os << "RI "; break;
       case DbAngle:
          os << "DB "; break;
       default:
       case MagAngle:
          os << "MA "; break;
       }
       if( ptype_ == S_Param ) os << "R " << ref_imp_.real() << std::endl;  // reference impedance
       else os << "R 1" << std::endl;  // for non-S-params, normalizing impedance is always 1

       // set stream formatting parameters
       std::streamsize prec = os.precision( precision_ );
       std::ios_base::fmtflags flg = os.flags();
       switch( fpMode_ ) {
       case FPscientific:
          os.setf( std::ios_base::scientific, std::ios_base::floatfield );
          break;
       case FPfixed:
          os.setf( std::ios_base::fixed, std::ios_base::floatfield );
          break;
       default:
       case FPauto:
          os.setf( std::ios_base::fmtflags(0), std::ios_base::floatfield );
          break;
       }
       // always show the +/-
       // os.setf( std::ios_base::showpos );

       // write data
       for( const_iterator i = begin(); i != end(); ++i )
          write_data_block( os, *i );
       os.flags( flg );
       os.precision( prec );
    }
    catch( std::ostream::failure& e ) {
       // reset stream stuff
       os.exceptions( except_msk );
       throw TouchstoneError( "Touchstone::write_stream(): stream failure.", E_STREAM_ERROR );
    }

   // reset stream stuff
   os.exceptions( except_msk );

   return os;
}

/*****************************************************************************************/
// write a single frequency of touchstone data to an ostream
void Touchstone::write_data_block( std::ostream& os, const NetworkParam& p ) const
{
   size_t np = nports_ * nports_;
   size_t count=0;
   size_t rc=0;
   size_t cc=0;
   size_t cpl = nports_ == 3 ? 3 : 4;

   // write the frequency
   switch( freqScale_ ) {
   case Terahertz:
      os << p.freq() * 1.e-12; break;
   case Gigahertz:
      os << p.freq() * 1.e-9; break;
   case Megahertz:
      os << p.freq() * 1.e-6; break;
   case Kilohertz:
      os << p.freq() * 1.e-3; break;
   case Hertz:
   default:
      os << p.freq(); break;
   }

   // write the parameters
   for( ; count<np; ++count, ++cc )
   {
      if( cc && !(cc % nports_) ) {
         // next row of parameter data
         ++rc; cc=0;
      }

      if( count && !(count % cpl) ) {
         // time to start a new line
         os << std::endl << blockIndent_;
         write_complex( os, p(rc,cc) );
      }
      else {
         // this lovely bit of code is to account for
         //  the morons that invented touchstone formatting
         //  who felt that for some reason 2-port data
         //  should be ordered differently than data
         //  for any other number of ports
         if( nports_ == 2 && count == 1 ) {
            os << recordSep_;
            write_complex( os, p(1,0) );
         }
         else if( nports_ == 2 && count == 2 ) {
            os << recordSep_;
            write_complex( os, p(0,1) );
         }
         else {
            os << recordSep_;
            write_complex( os, p(rc,cc) );
         }
      }
   }
   // end of block new-line
   os << std::endl;
}

/*****************************************************************************************/
// read a touchstone data file from a stream
std::istream& Touchstone::read_stream( std::istream& is, size_t initial_linecount )
{
   std::istringstream ss;
   std::string str;
   char first;
   const std::string numbers = "01234567890+-.";
   Bookmark bookmark;

   //  -clear the parameter data
   //  -clear the header data
   //  all other variables will retain their values
   //  unless they are modified during the read process
   //  such as when a touchstone format line is read
   header_.clear();
   params_.clear();
   linecount_ = initial_linecount;

   // set the istream exception mask to throw exceptions on failures
   std::ios::iostate except_msk = is.exceptions();
   is.exceptions( std::istream::badbit );

   // tie the internal istream pointer with the passed one
   is_ = &is;
   try {
      // read the header and format line, if either exists
      while( ! is_->eof() )
      {
         // capture the current stream pointer
         bookmark = create_bookmark();
         // read a line of data
         this->read_line( str );
         // get the first non-ws character
         ss.clear();
         ss.str( str );
         ss >> first;

         if( first == '#' ) {
             this->parse_format_string( str );
         }
         else if( numbers.find(first) != std::string::npos ) {
            // this is the first data line - back up the stream pointer to the beginning of the line
            //  and then break out of this while loop
            seek_bookmark( bookmark );
            break;
         }
         else {
            header_ += str;
            header_ += '\n';
         }
      }

      // determine the blocksize if it is not already set
      if( ! nports_ ) this->get_block_size();

      // now start to read the data
      while( ! is_->eof() ) {
         if( ! read_data_block() ) {
            // the block read failed
            // this is probably due to EOF, but
            // could also be that a new set of frequencies was found
            //   all other failures throw exceptions
            // the read_data_block() member function will automatically
            //  back up the stream pointer so, we will just break out of the loop
            break;
         }
      }
   }
   catch( std::istream::failure& e ) {
      // catches exceptions due to stream failures
      //  reset the mask
      is.exceptions( except_msk );
      // untie the internal istream
      is_ = 0;
      // throws a new exception
      throw TouchstoneError( std::string("Touchstone::read_stream(): stream failure.") + get_line_number(), E_STREAM_ERROR );
   }
   catch( TouchstoneError& e ) {
        // reset the stream exception mask
        is.exceptions( except_msk );
        // untie the internal istream pointer
        is_ = 0;
      // throws a new exception
      throw TouchstoneError( std::string(e.what()) + get_line_number(), e.code() );
   }
   // untie the internal istream
   is_ = 0;
   return is;
}

/*****************************************************************************************/

void Touchstone::parse_format_string( const std::string& line )
{
    // create a lowercase version of the format string
    std::string str = line;
    for( std::string::iterator i=str.begin(); i != str.end(); ++i ) {
        if( *i >= 'A' && *i <= 'Z' )
            *i += ('a' - 'A');
    }

    std::istringstream ss(str);
    std::string s;
    while( ! ss.fail() ) {
        ss >> s;
        if( ss.fail() ) break;

        if( s == "s" ) ptype_ = S_Param;
        else if( s == "z" ) ptype_ = Z_Param;
        else if( s == "y" ) ptype_ = Y_Param;
        else if( s == "g" ) ptype_ = G_Param;
        else if( s == "h" ) ptype_ = H_Param;
        else if( s == "hz" ) freqScale_ = Hertz;
        else if( s == "khz" ) freqScale_ = Kilohertz;
        else if( s == "mhz" ) freqScale_ = Megahertz;
        else if( s == "ghz" ) freqScale_ = Gigahertz;
        else if( s == "thz" ) freqScale_ = Terahertz;
        else if( s == "ma" ) writeFormat_ = MagAngle;
        else if( s == "ri" ) writeFormat_ = RealImag;
        else if( s == "db" ) writeFormat_ = DbAngle;
        else if( s == "r" ) {
            double rref;
            ss >> rref;
            if( ! ss.fail() ) {
                // read the normalizing resistance
                if( rref < 1.e-12 ) {
                    // invalid R, set it based on the parameter type
                    if( ptype_ == S_Param ) ref_imp_ = 50.;
                    else ref_imp_ = 1.;
                }
                else ref_imp_ = rref;
            }
        }
    }
}

/*****************************************************************************************/
// read the first block of data from a stream and return the block size
void Touchstone::get_block_size()
{
   // allow up the 15 floats per line,
   // this violates the touchstone standard
   //  but, so what
   size_t max_floats=15;
   double vect[15];
   size_t nf=0;
   size_t n;
   std::string str;
   // capture the current stream position
   Bookmark mark = create_bookmark();

   while( ! is_->eof() ) {
      this->read_line( str );
      n = read_doubles_from_string( str, vect, max_floats );
      if( n ) {
         if( !nf ) {
            // this is the first line, it must have an odd number of floats
            if( !(n%2) ) throw TouchstoneError( "Touchstone::get_block_size(): block format error: missing frequency.", E_BLOCK_FORMAT );
         }
         else {
            // this is not the first line of the block
            // if it has an odd number of floats, it is the start of a new block
            if( n%2 )
               break;
         }
         nf += n;
      }
   }

   // see if we read any data
   if( !nf )
      throw TouchstoneError( "Touchstone::get_block_size(): no data.", E_NO_DATA );

   // calculate the block size
   n = (size_t) (sqrt(double((nf-1)/2)) + 0.1);
   if( 2*n*n+1 != nf )
      throw TouchstoneError( "Touchstone::get_block_size(): block format error: could not determine number of ports.", E_BLOCK_FORMAT );

   // reset the stream pointer, set the block size and return
   seek_bookmark( mark );
   nports_ = n;
}

/*****************************************************************************************/
// read a block of data
bool Touchstone::read_data_block()
{
   // allow up the 15 floats per line
   // this violates the touchstone standard
   //  but, so what
   size_t max_floats=15;
   double vect[15];
   size_t tf = 2*(nports_*nports_) + 1;
   size_t nf=0;
   size_t n;
   size_t rc=0;
   size_t cc=0;
   size_t i;
   std::string str;
   double freq;
   matrix::CMatrix data(nports_,nports_);
   // capture the current stream position
   Bookmark mark = create_bookmark();

   while( ! is_->eof() && nf < tf ) {
      // read a line of data
      this->read_line( str );
      // read all of the floats on the line
      n = read_doubles_from_string( str, vect, max_floats );
      if( n )
      {
         if( nf+n > tf )
            // too many floats in the block (or too few in the last one)
            throw TouchstoneError( "Touchstone::read_data_block(): block format error: float count overflow.", E_BLOCK_FORMAT );

         if( !nf ) {
            // first line of the block
            if( !(n%2) ) // first line of a block must have an odd number of floats
                throw TouchstoneError( "Touchstone::read_data_block(): block format error: missing frequency.", E_BLOCK_FORMAT );
            else if( nports_ == 1 && n != 3 )
                throw TouchstoneError( "Touchstone::read_data_block(): block format error: 1-port data blocks can only occupy one line.", E_BLOCK_FORMAT );
            else if( nports_ == 2 && n != 9 )
                throw TouchstoneError( "Touchstone::read_data_block(): block format error: 2-port data blocks can only occupy one line.", E_BLOCK_FORMAT );
            else if( nports_ == 3 && n != 7 )
                throw TouchstoneError( "Touchstone::read_data_block(): block format error: 3-port data blocks have a specific format.", E_BLOCK_FORMAT );

            // grab the frequency
            freq = vect[0];
            // scale the frequency
            switch( freqScale_ ) {
            case Terahertz:
               freq *= 1.e12; break;
            case Gigahertz:
               freq *= 1.e9; break;
            case Megahertz:
               freq *= 1.e6; break;
            case Kilohertz:
               freq *= 1.e3; break;
            case Hertz:
                break;
            }
            // check the frequency, if it is less than the highest
            //  frequency in the data set, then this must be a new
            //  set of data
            if( params_.rbegin() != params_.rend() && params_.rbegin()->freq() > freq ) {
               seek_bookmark( mark );
               return false;
            }
            // start at index 1 of the vector
            i=1;
         }
         else {
            // subsequent lines of the block
            if( n%2 ) // subsequent lines of a block must have an even number of floats
                throw TouchstoneError( "Touchstone::read_data_block(): block format error: float count error.", E_BLOCK_FORMAT );
            else if( nports_ == 3 && n != 6 )
                throw TouchstoneError( "Touchstone::read_data_block(): block format error: 3-port data blocks have a specific format.", E_BLOCK_FORMAT );

            // start at index 0 of the vector
            i=0;
         }

         // copy data into the parameter matrix
         //  also convert to real/imag complex format as necessary
         for( ; i<n; i+=2, ++cc ) {
            if( cc && !(cc % nports_) ) {
               // next row of data
               ++rc; cc=0;
            }
            switch( writeFormat_ ) {
            case DbAngle:
               data(rc,cc) = ScalarDataT( std::pow(10.,vect[i]*0.05) * cosdeg(vect[i+1]), std::pow(10.,vect[i]*0.05) * sindeg(vect[i+1]) );
               break;
            case RealImag:
               data(rc,cc) = ScalarDataT( vect[i], vect[i+1] );
            break;
            default:
            case MagAngle:
               data(rc,cc) = ScalarDataT( vect[i] * cosdeg(vect[i+1]), vect[i] * sindeg(vect[i+1]) );
               break;
            }
         }

         nf += n;
      }
   }

    if( nf == tf ) {
       // correct parameter order for 2-port data
       if( nports_ == 2 ) {
          // stupid 2-port touchstone format
          ScalarDataT t = data(0,1);
          data(0,1) = data(1,0);
          data(1,0) = t;
       }
       // push the data into the data set
       params_.push_back( NetworkParam(freq, data) );
       // EOF, return false
       //   otherwise true
       return ! is_->eof();
    }

    if( nf && is_->eof() ) // hit EOF in the middle of a block
        throw TouchstoneError( "Touchstone::read_data_block(): block format error: unexpected EOF.", E_BLOCK_FORMAT );

    // must have hit EOF
    return false;
}

/*****************************************************************************************/
// read double-precision floating-point numbers from a string
static size_t read_doubles_from_string( const std::string& str, double* v, size_t sz_v )
{
   size_t n=0;
   std::istringstream ss( str );
   while( n<sz_v && !ss.fail() ) {
      ss >> v[n];
      if( !ss.fail() ) ++n;
   }
   return n;
}

