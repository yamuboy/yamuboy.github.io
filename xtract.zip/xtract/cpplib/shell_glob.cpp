#include "shell_glob.hpp"

ShellGlob& ShellGlob::exec( const char* pattern, unsigned flags )
{
    glob_t g;
    words_.clear();
    err_ = glob( pattern, flags, NULL, &g );
    if( err_ == 0 ) {
        for( size_t i=0; i<g.gl_pathc; ++i ) {
            words_.push_back( std::string(g.gl_pathv[i]) );
        }
    }
    globfree( &g );
    return (*this);
}

ShellWordExp& ShellWordExp::exec( const char* pattern, unsigned flags )
{
    wordexp_t we;
    words_.clear();
    err_ = wordexp( pattern, &we, flags );
    if( err_ == 0 ) {
        for( size_t i=0; i<we.we_wordc; ++i ) {
            words_.push_back( std::string(we.we_wordv[i]) );
        }
    }
    wordfree( &we );
    return (*this);
}

const char* ShellGlob::errmsg() const
{
    switch( err_ )
    {
    case GLOB_NOSPACE:
        return "Out of memory.";
    case GLOB_ABORTED:
        return "Read error.";
    case GLOB_NOMATCH:
        return "No matching files.";
    case 0:
    default:
        return "";
    }
}

const char* ShellWordExp::errmsg() const
{
    switch( err_ )
    {
    case WRDE_BADCHAR:
        return "Illegal charecter.";
    case WRDE_BADVAL:
        return "Undefined shell variable.";
    case WRDE_CMDSUB:
        return "Illegal command substitution.";
    case WRDE_NOSPACE:
        return "Out of memory.";
    case WRDE_SYNTAX:
        return "Syntax error.";
    case 0:
    default:
        return "";
    }
}

