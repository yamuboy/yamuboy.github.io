/**
    \file
    \author Jay Barrett
    \brief An abstract model class for building models
*/
#include "modelparam.hpp"
#include <string>
#include <map>

#ifndef MODEL_CLASS_DEFINED
#define MODEL_CLASS_DEFINED

/**********************************************************************************/
///  The Model class is an abstract base class for models
/**  The primary purpose is to provide a consistent interface for
     dealing with ModelParamSet and ModelParam objects
     within the context of a model
*/
class Model
{
private:
    /// the parameters for this model
    ModelParamSet pmap_;

protected:
    /// a default set of model parameters
    /**
        this should be populated when the derived class is constructed

        this list will be referenced if a parameter cannot be found
    */
    std::map<std::string,double> default_params;

    /// merge default params into the pmap_ ModelParamSet
    /**
        this behavior needs some improvement...

    */
    void merge_default_params();

public:
    /// retrieve a ModelParam object with the given name
    /**
        if a parameter of the given name is not found in pmap_ a new blank object is
        constructed with the fall-back parameter value of 0
        \param name the name of the parameter, names are case-sensitive
        \sa ModelParamSet::operator[]
        \return a ModelParam object reference
    */
    ModelParam& getParam( const std::string& name ) {
        return pmap_[name]; }
    /// an alias for getParam
    /**
        \param name the name of the parameter, names are case-sensitive
        \sa ModelParamSet::getParam
    */
    ModelParam& p( const std::string& name ) {
        return pmap_[name]; }

    /// get a reference to the parameter set for this object
    ModelParamSet& getParams() { return pmap_; }

    /// get a (const) reference to the parameter set for this object
    const ModelParamSet& getParams() const { return pmap_; }

    /// get the value of a parameter
    /** this follows the same behavior pattern as getParam()
        \param name the name of the parameter, names are case-sensitive
        \sa ModelParamSet::getParam
    */
    const double& getParamValue( const std::string& name ) {
        return getParam(name).value(); }
    /// an alias for getParamValue()
    /**
        \param name the name of the parameter, names are case-sensitive
        \sa ModelParamSet::getParamValue ModelParamSet::getParam
    */
    const double& pv( const std::string& name ) {
        return getParam(name).value(); }

    /// bind a ModelParamSet object to this model
    /** "binding" the ModelParamSet object has the effect
        of creating references to all of the ModelParam objects
        in the ModelParamSet object

        In this way, changes to the ModelParam objects (setting a new value, etc)
        in either place will result in simultaneous changes in both ModelParamSet
        objects

        This behavior is highly desirable, and allows algorithms like
        optimization to be implemented in a clean and easy to maintain manner

        \param pset a ModelParamSet object to bind to this model
    */
    void bindParams( const ModelParamSet& pset ) {
        pmap_.merge( pset, true );
        merge_default_params();
    }

    /// clear the parameter set
    /** this empties the internal ModelParamSet object */
    void clearParams() { pmap_.clear(); }

    /// "reset" the model
    /** the default implementation simply calls clearParams()
        but it can be overridden in a derived class to provide
        more functionality
        \sa ModelParamSet::clearParams
    */
    virtual void reset() { clearParams(); }

    Model() {}
    virtual ~Model() =0;
};

#endif  /* MODEL_CLASS_DEFINED */
