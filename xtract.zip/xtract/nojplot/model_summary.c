#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "fit_tools.h"

typedef struct
{
   char wafer[9],process[9];
   double periphery,vds,ids,vgs,igs;
   double ggs,ggd,rg,rs,rd,ri;
   double gm,t1,gds,t2,cgs,cds,cgd;
   double c11,ls,c22;
} DEVICE_DATA;

void print_usage( const char* progname )
{
    printf( "\n" );
    printf( "USAGE: %s [ -ext=.XXX -out=fname ] file1.dmb [ file2.dmb ... ]\n\n", progname );
    printf( "   Summarize model parameter files into a table that can be read\n" );
    printf( "   by large-signal modeling tools.\n\n" );
    printf( "OPTIONS:\n" );
    printf( "   -ext=.XXX    Set the extension for model parameter files, default = \'.end\'\n\n" );
    printf( "   -out=fname   Set the output file name.\n\n" );
}

static char *get_the_time (char *str);

/*******************************************************************************************/
/*******************************************************************************************/

int main( int argc, char **argv )
{
   FILE *file,*meas_file,*end_file;
   char buffer[256];
   char string[256];
   char end_name[256];
   char out_name[256];
   char name[30];
   int j, k;
   int n_files = 0;
   int n_models = 0;
   DEVICE_DATA *data, tmp;
   double b1,b2,c1,c2,val;
   const char ** flist;
   const char ** fname;
   char extension[30];

   strcpy( extension, ".end" );
   strcpy( out_name, "model.summary" );

   if( argc < 2 ) {
       print_usage( argv[0] );
       exit(1);
   }

   flist = (const char**) malloc( sizeof(const char*) * (argc+2) );

   for( j=1; j<argc; ++j ) {
       if( argv[j][0] == '-' ) {
           if( !strncmp( argv[j], "-ext=", 5 ) ) {
                strcpy( extension, &argv[j][5] );
           }
           else if( !strncmp( argv[j], "--ext=", 6 ) ) {
                strcpy( extension, &argv[j][6] );
           }
           else if( !strncmp( argv[j], "-out=", 5 ) ) {
                strcpy( out_name, &argv[j][5] );
           }
           else if( !strncmp( argv[j], "--out=", 6 ) ) {
                strcpy( out_name, &argv[j][6] );
           }
           else {
               fprintf( stderr, "Error: unrecognized option: \'%s\'.\n", argv[j] );
               exit(1);
           }
       }
       else {
           flist[n_files++] = argv[j];
       }
   }

   flist[n_files] = NULL;

   if( ! n_files ) {
       fprintf( stderr, "Error: no files to summarize.\n" );
       exit(1);
   }

   /* allocate memory */
   data = (DEVICE_DATA *) malloc( sizeof(DEVICE_DATA)*n_files );

   /* read in all the data */
   printf ("Reading model data ....\n");

   for( fname=flist; *fname; ++fname ) {
      strcpy( end_name, *fname );
      strip_extension( end_name );
      strcat( end_name, extension );

      if( !strcmp( *fname, end_name ) ) {
          fprintf(stderr, "Warning: measured file and parameter file cannot be the same: %s\n", *fname );
          continue;
      }

      meas_file = fopen( *fname, "r" );
      if( !meas_file ) {
          fprintf( stderr, "Warning: %s: file not readable.\n", *fname );
          continue;
      }

      end_file = fopen( end_name, "r" );
      if( !end_file ) {
          fprintf( stderr, "Warning: %s: file not readable.\n", end_name );
          fclose( meas_file );
          continue;
      }

      // read in data from the model file

      while( fgets( buffer, 255, meas_file ) ) {
         if (!strncmp (buffer,"!PROCESS NAME:",14))
            sscanf (buffer, "!PROCESS NAME: %8s", data[n_models].process);
         else if (!strncmp (buffer,"!WAFER NUMBER:",14))
            sscanf (buffer, "!WAFER NUMBER: %8s", data[n_models].wafer);
         else if (!strncmp (buffer,"!GATE PERIPHERY (um):",21))
            sscanf (buffer, "!GATE PERIPHERY (um): %lf", &data[n_models].periphery);
         else if (!strncmp (buffer, "!BIAS:", 6)) {
            sscanf (buffer, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
               &data[n_models].vds, &data[n_models].ids, &data[n_models].vgs, &data[n_models].igs);
            data[n_models].ids *= 1.0e3;
            data[n_models].igs *= 1.0e3;
            break;
         }
         else if( buffer[0] != '!' ) break;
      }

      // read in parameter values from the end file

      while( fgets(buffer, 255, end_file) ) {
         if( sscanf(buffer, "%*f%lf%*f%*f%29s", &val, name) == 2 )
         {
            if (!strcmp (name, "RG"))
               data[n_models].rg = val;
            else if (!strcmp (name, "RD"))
               data[n_models].rd = val;
            else if (!strcmp (name, "RS"))
               data[n_models].rs = val;
            else if (!strcmp (name, "RI"))
               data[n_models].ri = val;
            else if (!strcmp (name, "GGS"))
               data[n_models].ggs = val;
            else if (!strcmp (name, "GDG"))
               data[n_models].ggd = val;
            else if (!strcmp (name, "C11"))
               data[n_models].c11 = val;
            else if (!strcmp (name, "C22"))
               data[n_models].c22 = val;
            else if (!strcmp (name, "LS"))
               data[n_models].ls = val;
            else if (!strcmp (name, "GM"))
               data[n_models].gm = val;
            else if (!strcmp (name, "TAU1"))
               data[n_models].t1 = val;
            else if (!strcmp (name, "GDS"))
               data[n_models].gds = val;
            else if (!strcmp (name, "TAU2"))
               data[n_models].t2 = val;
            else if (!strcmp (name, "CDS"))
               data[n_models].cds = val;
            else if (!strcmp (name, "CGS"))
               data[n_models].cgs = val;
            else if (!strcmp (name, "CDG"))
               data[n_models].cgd = val;
            else if (!strcmp (name, "C1"))
               c1 = val;
            else if (!strcmp (name, "C2"))
               c2 = val;
            else if (!strcmp (name, "B1"))
               b1 = val;
            else if (!strcmp (name, "B2"))
               b2 = val;
         }
      }

      // scale all of the parameters

      data[n_models].periphery *= 0.001;
      data[n_models].ggs *= 1000.0;
      data[n_models].ggd *= 1000.0;
      data[n_models].cgs *= 1.0e12;
      data[n_models].cgd *= 1.0e12;
      data[n_models].cds *= 1.0e12;
      data[n_models].c11 *= 1.0e12;
      data[n_models].c22 *= 1.0e12;
      data[n_models].ls  *= 1.0e12;
      data[n_models].gm  *= 1000.0;
      data[n_models].gds *= 1000.0;
      data[n_models].t1  *= 1.0e12;
      data[n_models].t2  *= 1.0e12;
      c1 *= 1.0e12;
      c2 *= 1.0e12;
      b1 *= 1.0e12;
      b2 *= 1.0e12;

      // increment the parameter counter
      ++n_models;

      fclose (meas_file);
      fclose (end_file);
   }

   free ((void *) flist);

   if( !n_models ) {
      fprintf( stderr, "Error: no data.\n" );
      free((void *) data);
      return -1;
   }

   /* perform the sorting procedure */
   printf ("Sorting model data ....\n");
   for( j=0; j<n_models; ++j ) {
       for( k=j+1; k<n_models; ++k ) {
           if( data[k].vgs > data[j].vgs || (data[k].vgs==data[j].vgs && data[k].vds < data[j].vds ) ) {
               tmp = data[j];
               data[j] = data[k];
               data[k] = tmp;
           }
       }
   }

   /* write the sorted model data to the file */
   file = fopen( out_name, "w+" );
   if( !file ) {
      fprintf( stderr, "Error: unable to open \'model.summary\' for writing.\n" );
      free((void *) data);
      return -1;
   }

   fprintf (file, "!\n");
   fprintf (file, "!    FET MODEL SUMMARY PROGRAM VERSION 3.06        %s\n", get_the_time (string));
   fprintf (file, "!\n");
   fprintf (file, "!                Periphery    Vds    Ids      Vgs      Ig     Ggs     Gdg     Rg     Rs     Rd     Ri      Gm     T1     Gds     T2     Cgs     Cds     Cdg     C11     Ls      C22\n");
   fprintf (file, "! Wafer  Process   (mm)     (volts)  (mA)   (volts)   (mA)    (mS)    (mS)  (Ohms) (Ohms) (Ohms) (Ohms)   (mS)   (pS)    (mS)   (pS)    (pF)    (pF)    (pF)    (pF)   (pH)     (pF)\n");
   //                 |      | |      |  |   |    |    | |     |  |     |  |    |  |    |  |    | |    | |    | |    | |    |  |     | |    | |     | |    | |     | |     | |     | |     | |     | |     |
   for( j=0; j<n_models; ++j ){
      fprintf (file, "%-8s %-8s  %5.3f    %6.2f %7.2f  %7.3f  %6.3f  %6.3f  %6.3f %6.3f %6.3f %6.3f %6.3f  %7.3f %6.2f %7.3f %6.2f %7.3f %7.3f %7.3f %7.3f %7.3f %7.3f\n",
         data[j].wafer, data[j].process, data[j].periphery, data[j].vds, data[j].ids, data[j].vgs, data[j].igs, data[j].ggs,
         data[j].ggd, data[j].rg, data[j].rs, data[j].rd, data[j].ri, data[j].gm, data[j].t1, data[j].gds,
         data[j].t2, data[j].cgs, data[j].cds, data[j].cgd, data[j].c11, data[j].ls, data[j].c22);

      if( j < n_models-1 && data[j+1].vgs != data[j].vgs )
         fprintf (file, "!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
   }
   fclose (file);

   printf( "Wrote file: %s\n", out_name );

   free ((void *) data);
   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

static char *get_the_time (char *str)
   {
   char *ptr;
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];
   time_t now;

   time (&now);
   ptr = asctime (localtime (&now));
   sscanf (ptr+8,"%s",s_day);
   sscanf (ptr+4,"%s",s_month);
   sscanf (ptr+20,"%s",s_year);
   sscanf (ptr+11,"%s",s_time);
   sprintf (str,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

   return str;
   }

