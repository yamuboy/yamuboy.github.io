#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "cmplxlib.h"

typedef struct
   {
   double vgs, vds, igs, ids, ft;
   } FT_DATA;

int main (int argc, char *argv[])
   {
   char string[256];
   char files_for_ft[256];
   char fname[256];
   char out_name[256];
   char tmp_file_name[50];
   FILE *tfile, *ofile, *sfile;
   int i, j, done, fcount;
   int dev_type = 0;
   double desired_freq, freq;
   FT_DATA *ft;
   POLAR sp[4];
   COMPLEX sc[4], hc[4];
   time_t t;

   printf ("Filenames for ft calculation?\n");
   fgets (files_for_ft, 255, stdin);
   files_for_ft[strlen(files_for_ft)-1] = 0;

   printf ("Frequency for calculation (GHz)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &desired_freq);
   desired_freq *= 1.0e9;

   printf ("Output filename?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", out_name);

   sprintf (tmp_file_name, "tmp.%ld", time(&t));
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);
   sprintf (string, "ls -1 %s > %s", files_for_ft, tmp_file_name);
   system (string);

   tfile = fopen (tmp_file_name, "r");
   if( !tfile )
      {
      printf ("Error: %s: file not found.\n", tmp_file_name);
      return 1;
      }

   fcount = 0;
   while( fgets(string, 255, tfile) && strlen(string) > 0)
      ++fcount;
   rewind(tfile);

   ft = (FT_DATA *) malloc( sizeof(FT_DATA)*fcount );
   if( !ft )
      {
      printf ("Error: no memory.\n");
      sprintf (string, "rm -f %s", tmp_file_name);
      system (string);
      return 1;
      }

   fcount = 0;
   while ( fgets(fname,255,tfile) )
      {
      fname[strlen(fname)-1] = 0;

      sfile = fopen(fname,"r");
      if ( !sfile )
         {
         printf ("Warning: %s: file not found.\n", fname);
         continue;
         }

      done = 0;
      ft[fcount].vgs = ft[fcount].vds = ft[fcount].igs = ft[fcount].ids = 0.0;
      while ( fgets(string,255,sfile) )
         {
         if( string[0] == '!' && !strncmp( string, "!BIAS:", 6 ) )
            {
            if( dev_type != 2 && sscanf( string, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
               &ft[fcount].vds, &ft[fcount].ids, &ft[fcount].vgs, &ft[fcount].igs ) == 4)
               dev_type = 1;
            else if ( dev_type != 1 && sscanf( string, "!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf",
               &ft[fcount].vds, &ft[fcount].ids, &ft[fcount].vgs, &ft[fcount].igs ) == 4)
               dev_type = 2;
            else
               printf ("Warning: %s: unable to read bias.\n", fname);
            }
         else if( string[0] != '!' && sscanf( string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &freq, &sp[0].m, &sp[0].a,
            &sp[2].m, &sp[2].a, &sp[1].m, &sp[1].a, &sp[3].m, &sp[3].a ) == 9)
            {
            if( freq >= desired_freq )
               {
               s2h( PA2CA( sp, sc, 2, 2 ), hc, 50.0 );
               ft[fcount].ft = freq * 1.0e-9 * Cmag( hc[2] );
               done = 1;
               break;
               }
            }
         }
      fclose(sfile);

      if( done )
         fcount++;
      }

   fclose(tfile);
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   /* sort the data */
   if( dev_type )
      {
      for( i = 0; i < fcount-1; i++ )
         {
         for( j = i; j < fcount; j++ )
            {
            if( dev_type == 1 )
               {
               /* for FETs sort by Vds then Vgs */
               if( ft[j].vds < ft[i].vds || (ft[j].vds == ft[i].vds && ft[j].vgs < ft[i].vgs) )
                  {
                  FT_DATA d = ft[i];
                  ft[i] = ft[j];
                  ft[j] = d;
                  }
               }
            else if( dev_type == 2 )
               {
               /* for BJTs sort by Vce then Ibe */
               if( ft[j].vds < ft[i].vds || (ft[j].vds == ft[i].vds && ft[j].igs < ft[i].igs) )
                  {
                  FT_DATA d = ft[i];
                  ft[i] = ft[j];
                  ft[j] = d;
                  }
               }
            }
         }
      }

   /* write the output file */
   ofile = fopen (out_name, "w+");
   if( !ofile )
      {
      printf( "Error: %s: unable to write to disc.\n", out_name );
      return 1;
      }

   fprintf (ofile, "! Vds/Vce Vgs/Vbe   Ids/Ice     Igs/Ibe   Ft(GHz)\n");
   for( i = 0; i < fcount; i++ )
      fprintf (ofile, "%7.3f %7.4f %11.4e %11.4e %6.2f\n", ft[i].vds, ft[i].vgs, ft[i].ids, ft[i].igs, ft[i].ft);
   fclose(ofile);

   free((void *)ft);

   return 0;
   }

