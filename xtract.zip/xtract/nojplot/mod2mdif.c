#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fit_tools.h"

#define MAX_PARAMS   100
#define MAX_MODELS   50

typedef struct {
    int mod_num;
    char *header;
    char *pnames[MAX_PARAMS];
    double pvals[MAX_PARAMS];
    int n;
} MODEL_STRUCT;

static char *append_string (char *str1, char *str2);

/*****************************************************************************/
/*****************************************************************************/

int main (int argc, char *argv[])
{
    FILE *infile,*outfile;
    int i, j, k;
    char mdfname[256];
    char str[256];
    MODEL_STRUCT mlist[MAX_MODELS];
    char pname[40];
    double pval;
    int mod_num;
    int max_model;
    int midx, found;
    
    if( argc < 2 )
    {
        printf( "\n\n" );
        printf( "USAGE:  %s [files]\n\n", argv[0] );
        return 0;
    }
    
    for( i=1; i<argc; i++ )
    {
        strcpy( mdfname, argv[i] );
        strcat( mdfname, ".mdf" );
        
        infile = fopen (argv[i], "r");
        if (!infile)
        {
            printf ("Could not open file: %s\n", argv[i]);
            continue;
        }
        
        outfile = fopen (mdfname, "w+");
        if (!outfile)
        {
            printf ("Could not create output file: %s\n", mdfname);
            fclose (infile);
            continue;
        }
        
        mod_num = -1;
        max_model = 0;
        while( fgets (str, 255, infile) )
        {
            if( mod_num < 0 )
            {
                /* still writing the header */
                if( !strncmp( str, "!FILE", 5 ) )
                {
                    mod_num++;
                    mlist[mod_num].header = append_string( NULL, str );
                    mlist[mod_num].mod_num = 0;
                    mlist[mod_num].n = 0;
                    continue;
                }
                
                fprintf( outfile, "%s", str );
            }
            
            else  /* mod_num >= 0 */
            {
                if( !strncmp( str, "!FILE", 5 ) || !strncmp( str, "!!FILE", 6 ) )
                {
                    if( mod_num >= MAX_MODELS-1 )
                    {
                        printf( "Warning: MAX_MODELS exceeded.\n" );
                        break;
                    }
                    
                    mod_num++;
                    if( str[1] == '!' )
                        mlist[mod_num].header = append_string( NULL, &str[1] );
                    else
                        mlist[mod_num].header = append_string( NULL, str );
                    mlist[mod_num].mod_num = 0;
                    mlist[mod_num].n = 0;
                    continue;
                }
                else if( str[0] == '!' && !mlist[mod_num].n )
                {
                    mlist[mod_num].header = append_string( mlist[mod_num].header, str );
                }
                else if( sscanf( str, "model = %d", &mlist[mod_num].mod_num ) == 1 ) {
                    if(mlist[mod_num].mod_num > max_model) max_model = mlist[mod_num].mod_num;
                }
                else if( str[0] != '!' && sscanf( str, "%39s = %lf", pname, &pval ) == 2 )
                {
                    if( mlist[mod_num].n >= MAX_PARAMS )
                    {
                        printf( "Warning: MAX_PARAMS exceeded.\n" );
                        continue;
                    }
                    
                    mlist[mod_num].pnames[mlist[mod_num].n] = strdup( pname );
                    mlist[mod_num].pvals[mlist[mod_num].n] = pval;
                    mlist[mod_num].n++;
                }
            }
        }
        
        // write the model data
        if( mod_num < 0 || !max_model )
            printf( "%s: no data.\n", argv[i] );
        else
        {
            for( j=1; j<=max_model; ++j ) {
                //find the right model number index
                found=0;
                for( k=0; k<=mod_num; ++k ) {
                    if( mlist[k].mod_num == j ) {
                        midx = k;
                        found=1;
                        break;
                    }
                }
                if( !found ) {
                    printf( "Warning: %s: missing model index %d\n", argv[i], j );
                    continue;
                }
                
                fprintf( outfile, "%s", mlist[midx].header );
                fprintf( outfile, "VAR model = %d\n", mlist[midx].mod_num );
                write_model_param_mdif (outfile, mlist[midx].pnames, mlist[midx].pvals, mlist[midx].n, 12, 5);
            }
        }
        
        // free memory
        for( j=0; j<=mod_num; ++j ) {
            /* free memory */
            for(k=0; k<mlist[j].n; k++)
                free((void*)mlist[j].pnames[k]);
            free((void*)mlist[j].header);
        }
        
        fclose (infile);
        fclose (outfile);
    }
    
    return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static char *append_string (char *str1, char *str2)
{
    if( !str2 || ! *str2 )
        return str1;
    else if( !str1 )
        return strdup( str2 );
    else
    {
        char *ret = (char *) malloc (sizeof (char) * (strlen(str1) + strlen(str2) + 1));
        strcpy (ret, str1);
        strcat (ret, str2);
        free ((void *) str1);
        return ret;
    }
}



