#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

main ()
{
FILE  *in_file;
FILE  *out_file;
FILE  *batch_file;
char  in_name[201];
char  out_name[201];
char  fname[201];
char  buffer[201];
char  extension[21];
char  tmp_file_name[80];
char  port_num[21];
double freq,t[8];
time_t dummy;

printf ("files to convert?\n");
scanf ("%200s",in_name);

printf ("S11 or S22?\n");
scanf ("%20s",port_num);

printf ("extension for output files?\n");
scanf ("%20s",extension);

sprintf (tmp_file_name,"tmp.%d",time (&dummy));
sprintf (buffer,"rm -f %s",tmp_file_name);
system (buffer);
sprintf (buffer,"ls -1 %s > %s",in_name,tmp_file_name);
system (buffer);

batch_file = fopen (tmp_file_name,"r");
if (batch_file == (FILE *) NULL)
   {
   printf ("** error ** unable to open temporary file.\n");
   return -1;
   }

while (fgets (fname,200,batch_file) != NULL)
   {
   fname[strlen(fname)-1] = 0;
   
   in_file = fopen (fname,"r");
   if (in_file == (FILE *) NULL)
      {
      printf ("** error ** unable to open %s.\n",fname);
      continue;
      }
   
   sscanf (fname,"%[^.]",out_name);
   strcat (out_name,extension);
   
   out_file = fopen (out_name,"w+");
      
   while (fgets (buffer,200,in_file) != NULL)
      {
      if (sscanf (buffer,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&t[0],&t[1],&t[2],&t[3],&t[4],&t[5],&t[6],&t[7]) == 9)
         {
         if (!strcmp (port_num,"s22") || !strcmp (port_num,"S22"))
            {
            fprintf (out_file,"%.5e %.5e %+.5e\n",freq,t[6],t[7]);
            }
         else
            {
            fprintf (out_file,"%.5e %.5e %+.5e\n",freq,t[0],t[1]);
            }
         }
      else if (!strncmp (buffer,"!Frequency",10))
         {
         fprintf (out_file,"!Frequency    S11-Mag      S11-Ang\n");
         }
      else
         {
         fprintf (out_file,"%s",buffer);
         }
      }
   fclose (in_file);
   fclose (out_file);
   
   }
fclose (batch_file);

sprintf (buffer,"rm -f %s",tmp_file_name);
system (buffer);

return 0;
}
