#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

enum {
   FET_FILE,
   HBT_FILE,
   OTHER_FILE
};

enum {
   VGS_NAMING,
   IDS_NAMING
};

static int make_fet_files (FILE *infile, char *header, char *prefix);
static int make_hbt_files (FILE *infile, char *header, char *prefix);
static int make_s_files (FILE *infile, char *header, char *prefix, int name_mode );
static int make_noise_files (FILE *infile, char *header, char *prefix, int name_mode );
static int make_dc_files( FILE* infile, char* head, char* pref ); 

static char noi_suffix[20];
static char sp_suffix[20];
static char iv_suffix[20];
static char dc_suffix[20];

/*********************************************************************************/
/*********************************************************************************/

static void print_usage( char *progname )
{
   printf( "\n\n" );
   printf( "USAGE: %s [options] file1 [file2 ...]\n\n", progname );
   printf( "   --pre=xx    Use xx as file prefix.\n" );
   printf( "   --iv=.xx    Use .xx as I-V file suffix.\n" );
   printf( "   --sp=.xx    Use .xx as S-Parameter file suffix.\n" );
   printf( "   --noi=.xx   Use .xx as noise file suffix.\n" );
   printf( "   --ids       Use Ids as the naming parameter for generic files.\n" );
   printf( "\n\n" );
}

/*********************************************************************************/
/*********************************************************************************/

int main (int argc, char *argv[])
{
   char header[3000];
   char string[256];
   FILE *file;
   char *prefix;
   char user_prefix[20];
   int i, n;
   int noise_file, header_done, file_mode;
   int name_mode = VGS_NAMING;
   int dc_file;

   /* initialize variables */
   *user_prefix = '\0';
   strcpy( noi_suffix, ".nfig" );
   strcpy( sp_suffix, ".dmb" );
   strcpy( iv_suffix, ".iv" );
   strcpy( dc_suffix, ".dc" );

   /* parse the command line */

   if (argc < 2)
   {
      print_usage( argv[0] );
      return 0;
   }

   for( i=1; i<argc; i++ )
   {
      if( *argv[i] != '-' )
         continue;

      if( !strncmp( argv[i], "--pre=", 6 ) )
         strcpy( user_prefix, &argv[i][6] );
      else if( !strncmp( argv[i], "--sp=", 5 ) )
      {
         if( argv[i][5] != '.' )
         {
            strcpy( sp_suffix, "." );
            strcat( sp_suffix, &argv[i][5] );
         }
         else
            strcpy( sp_suffix, &argv[i][5] );
      }
      else if( !strncmp( argv[i], "--noi=", 6 ) )
      {
         if( argv[i][6] != '.' )
         {
            strcpy( noi_suffix, "." );
            strcat( noi_suffix, &argv[i][6] );
         }
         else
            strcpy( noi_suffix, &argv[i][6] );
      }
      else if( !strncmp( argv[i], "--iv=", 5 ) )
      {
         if( argv[i][5] != '.' )
         {
            strcpy( iv_suffix, "." );
            strcat( iv_suffix, &argv[i][5] );
         }
         else
            strcpy( iv_suffix, &argv[i][5] );
      }
      else if( !strcmp( argv[i], "-ids" ) || !strcmp( argv[i], "--ids" ) )
         name_mode = IDS_NAMING;
      else if( !strncmp( argv[i], "-h", 2 ) || !strncmp( argv[i], "--help", 6 ) )
      {
         print_usage( argv[0] );
         return 0;
      }
      else
      {
         fprintf( stderr, "Unknown option: %s\n", argv[i] );
         print_usage( argv[0] );
         return 1;
      } 
   }

   /* scan through the list of files */

   for( i=1; i<argc; i++ )
   {
      if( *argv[i] == '-' )
         continue;

      file = fopen( argv[i], "r" );
      if (!file)
      {
         fprintf( stderr, "Warning: %s: cannot open file.\n", argv[i] );
         continue;
      }

      /* determine the file type and create the header */  
      file_mode = -1;
      noise_file = 0;
      dc_file=0;
      header_done = 0;
      *header = '\0';
      n = 0;
      while( fgets( string, 255, file ) )
      {
         if ( string[0] != '!' )
            header_done = 1;
         else if( !header_done && ++n > 40 )
         {
            fprintf( stderr, "Warning: %s: header is too big, file format error.\n", argv[i] );
            fclose( file );
            break;
         }

         if( strstr(string,"DC FET PARAMETERS") )
         {
            strcat (header,string);
            fgets (string,199,file);
            strcat (header,string);
            fgets (string,199,file);
            strcat (header,"!");
            strcat (header,string);
            file_mode = FET_FILE;
            header_done = 1;
         }
         else if( strstr( string,"DC BJT PARAMETERS") )
         {
            strcat (header,string);
            fgets (string,199,file);
            strcat (header,string);
            fgets (string,199,file);
            strcat (header,"!");
            strcat (header,string);
            file_mode = HBT_FILE;
            header_done = 1;
         }
         else if( strstr( string,"S-PARAMETERS") || strstr( string,"S11-Mag" ) )
         {
            /* found S-parameter data, this is not a noise file */
            if( file_mode == -1 )
               file_mode = OTHER_FILE;
            header_done = 1;
            break;
         }
         else if( strstr( string,"Nfig (dB)" ) )
         {
            noise_file = 1;
            if( file_mode == -1 )
               file_mode = OTHER_FILE;
            header_done = 1;
            break;
         }
         else if( !strncmp( string,"!BIAS:", 6 ) )
            header_done = 1;
         else if( !strncmp( string,"!SITE:", 6 ) ) {
            header_done = 1;
            if( file_mode == -1 )
               file_mode = OTHER_FILE;
            dc_file=1;
         }

         if( !header_done )
            strcat (header,string);
      }

      strcat (header,"!\n");

      /* run the appropriate file-splitting function */

      rewind( file );

      if( *user_prefix )
         prefix = user_prefix;
      else
      {
         if( noise_file )
            prefix = "n";
         else if( dc_file )
            prefix = "a";
         else
            prefix = "s";
      }

      if( file_mode == FET_FILE )
         make_fet_files( file, header, prefix );
      else if( file_mode == HBT_FILE )
         make_hbt_files( file, header, prefix );
      else if( file_mode == OTHER_FILE )
      {
         if( noise_file )
            make_noise_files( file, header, prefix, name_mode );
         else if( dc_file )
            make_dc_files( file, header, prefix );
         else
            make_s_files( file, header, prefix, name_mode );
      }
      else
         fprintf( stderr, "Error: %s: unknown file type.\n", argv[i] );            

      fclose (file);
   }

   printf ("Complete.\n");
   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int make_fet_files (FILE *infile, char *header, char *prefix)
{
   char string[200];
   char fname[100];
   char str1[20];
   char str2[20];
   char minus = 'm';
   char plus = 'p';
   char *ptr;
   FILE *outfile = NULL;
   double vds,ids,vgs,igs;
   double periphery;

   ptr = strstr (header,"!GATE PERIPHERY");
   sscanf (ptr,"!GATE PERIPHERY (um): %lf",&periphery);

   while (1)
   {
      if (strstr (string,"BREAKDOWN IV-CURVES"))
      {
         printf ("Breakdown IV curves.\n");

         sprintf (fname,"%svbr%s",prefix, iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"FORWARD IV-CURVES"))
      {
         printf ("Forward IV curves.\n");

         sprintf (fname,"%sfwd%s",prefix, iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"DC IV-CURVES"))
      {
         printf ("DC IV curves.\n");

         sprintf (fname,"%sdc%s",prefix, iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"COLD FET"))
      {
         printf ("Cold S-Parameters.\n");
         string[0] = 0;

         while (fgets (string,199,infile))
         {
            if (string[0] == '#')
               continue;
            else if (string[0] == '!')
            {
               if (strstr (string,"S-PARAMETERS"))
                  break;

               else if (!strncmp (string, "!BIAS", 5))
               {
                  if (outfile)
                  {
                     fclose (outfile);
                     outfile = NULL;
                  }

                  sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
                     &vds,&ids,&vgs,&igs);

                  if (igs < 0.0)
                     sprintf (fname,"%s000c000.dmb",prefix);
                  else
                  {
                     sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
                     sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (igs)*10000.0*1000.0/periphery)));
                     sprintf (fname,"%s%sc%s%s",prefix, &str1[1], &str2[1], sp_suffix);
                  }

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fprintf (outfile,"# HZ S MA R 50.0\n");
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
      }

      else if (strstr (string,"S-PARAMETERS"))
      {
         printf ("S-Parameters.\n");
         string[0] = 0;

         while (fgets (string,199,infile))
         {
            if (string[0] == '#')
               continue;
            else if (string[0] == '!')
            {
               if (!strncmp (string,"!BIAS:",6))
               {
                  if (outfile)
                  {
                     fclose (outfile);
                     outfile = NULL;
                  }

                  sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
                     &vds,&ids,&vgs,&igs);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
                  sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (vgs)*100.0)));
                  sprintf (fname,"%s%s%c%s%s",prefix, &str1[1], vgs < 0.0 ? minus : plus, &str2[1], sp_suffix);

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fprintf (outfile,"# HZ S MA R 50.0\n");
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
      }

      else if (!strncmp (string,"!BIAS:",6))
      {
         /* noise files have no title line */

         printf ("Noise.\n");

         do
         {
            if (string[0] == '!')
            {
               if (outfile)
               {
                  fclose (outfile);
                  outfile = NULL;
               }

               if (!strncmp (string,"!BIAS:",6))
               {
                  sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
                     &vds,&ids,&vgs,&igs);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
                  sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (vgs)*100.0)));
                  sprintf (fname,"%s%s%c%s%s",prefix, &str1[1], vgs < 0.0 ? minus : plus, &str2[1], noi_suffix);

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fgets (string,199,infile);
                  fprintf (outfile,"%s",string);
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
         while (fgets (string,199,infile));
      }

      else
      {
         if (!fgets (string,199,infile))
            break;
      }


      if (outfile)
      {
         fclose (outfile);
         outfile = NULL;
      }
   }

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int make_hbt_files (FILE *infile, char *header, char *prefix)
{
   char string[200];
   char fname[100];
   char str1[20];
   char str2[20];
   char minus = 'm';
   char plus = 'p';
   char *ptr;
   FILE *outfile = NULL;
   double area = 0.0;
   double vce,ice,vbe,ibe;

   ptr = strstr (header,"!EMITTER AREA");
   sscanf (ptr,"!EMITTER AREA (um^2): %lf",&area);

   if (area < 1.0)
   {
      printf ("** error ** area was detected to be less than 1.0 um^2\n");
      return -1;
   }

   while (1)
   {
      if (strstr (string,"FORWARD GUMMEL CURVES"))
      {
         printf ("Forward Gummel curves.\n");

         sprintf (fname,"fwdgummel%s", iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"REVERSE GUMMEL CURVES"))
      {
         printf ("Reverse Gummel curves.\n");

         sprintf (fname,"revgummel%s", iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"RE FLYBACK CURVE"))
      {
         printf ("Emitter flyback.\n");

         sprintf (fname,"flyback%s", iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"DC IV-CURVES"))
      {
         printf ("DC IV curves.\n");

         sprintf (fname,"dccurves%s", iv_suffix);
         outfile = fopen (fname,"w+");

         fprintf (outfile,"%s",header);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);
         fgets (string,199,infile);
         fprintf (outfile,"%s",string);

         while (fgets (string,199,infile))
         {
            if (string[0] == '!')
            {
               fclose (outfile);
               outfile = NULL;
               break;
            }

            fprintf (outfile,"%s",string);
         }
      }

      else if (strstr (string,"COLD BJT S-PARAMETERS"))
      {
         printf ("Cold S-Parameters.\n");
         string[0] = 0;

         while (fgets (string,199,infile))
         {
            if (string[0] == '#')
               continue;
            else if (string[0] == '!')
            {
               if (outfile)
               {
                  fclose (outfile);
                  outfile = NULL;
               }

               if (strstr (string,"BJT S-PARAMETERS") || strstr (string,"CBC S-PARAMETERS") ||
                  strstr (string,"CBE S-PARAMETERS"))
                  break;
               else if (!strncmp (string,"!BIAS:",6))
               {
                  sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",
                     &vce,&ice,&vbe,&ibe);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (ibe)*1.0e6/area)));
                  sprintf (fname,"%s000h%s%s",prefix, &str1[1], sp_suffix );

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fprintf (outfile,"# HZ S MA R 50.0\n");
                  fgets (string,199,infile);
                  fprintf (outfile,"%s",string);
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
      }

      else if (strstr (string,"CBC BJT S-PARAMETERS"))
      {
         printf ("CBC S-Parameters.\n");
         string[0] = 0;

         while (fgets (string,199,infile))
         {
            if (string[0] == '#')
               continue;
            else if (string[0] == '!')
            {
               if (outfile)
               {
                  fclose (outfile);
                  outfile = NULL;
               }

               if (strstr (string,"BJT S-PARAMETERS"))
                  break;
               else if (!strncmp (string,"!BIAS:",6))
               {
                  sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",
                     &vce,&ice,&vbe,&ibe);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vbe-vce)*100.0)));
                  sprintf (fname,"%scbc%c%s%s",prefix, (vbe - vce) < 0.0 ? minus : plus, &str1[1], sp_suffix);

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fprintf (outfile,"# HZ S MA R 50.0\n");
                  fgets (string,199,infile);
                  fprintf (outfile,"%s",string);
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
      }

      else if (strstr (string,"CBE BJT S-PARAMETERS"))
      {
         printf ("CBE S-Parameters.\n");
         string[0] = 0;

         while (fgets (string,199,infile))
         {
            if (string[0] == '#')
               continue;
            else if (string[0] == '!')
            {
               if (outfile)
               {
                  fclose (outfile);
                  outfile = NULL;
               }

               if (strstr (string,"S-PARAMETERS"))
                  break;
               else if (!strncmp (string,"!BIAS:",6))
               {
                  sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",
                     &vce,&ice,&vbe,&ibe);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vbe)*100.0)));
                  sprintf (fname,"%scbe%c%s%s", prefix, vbe < 0.0 ? minus : plus, &str1[1], sp_suffix);

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fprintf (outfile,"# HZ S MA R 50.0\n");
                  fgets (string,199,infile);
                  fprintf (outfile,"%s",string);
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
      }

      else if (strstr (string,"S-PARAMETERS"))
      {
         printf ("S-Parameters.\n");
         string[0] = 0;

         while (fgets (string,199,infile))
         {
            if (string[0] == '#')
               continue;
            else if (string[0] == '!')
            {
               if (outfile)
               {
                  fclose (outfile);
                  outfile = NULL;
               }

               if (!strncmp (string,"!BIAS:",6))
               {
                  sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",
                     &vce,&ice,&vbe,&ibe);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vce)*10.0)));
                  sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (ice)*1.0e6/area)));
                  sprintf (fname,"%s%sc%s%s",prefix, &str1[1], &str2[1], sp_suffix);

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fprintf (outfile,"# HZ S MA R 50.0\n");
                  fgets (string,199,infile);
                  fprintf (outfile,"%s",string);
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
      }

      else if (!strncmp (string,"!BIAS:",6))
      {
         /* noise files have no title line */

         printf ("Noise.\n");

         do
         {
            if (string[0] == '!')
            {
               if (outfile)
               {
                  fclose (outfile);
                  outfile = NULL;
               }

               if (!strncmp (string,"!BIAS:",6))
               {
                  sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",
                     &vce,&ice,&vbe,&ibe);

                  sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vce)*10.0)));
                  sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (ice)*1000.0*area)));
                  sprintf (fname,"%s%sc%s%s",prefix, &str1[1], &str2[1], noi_suffix );

                  outfile = fopen (fname,"w+");
                  fprintf (outfile,"%s",header);
                  fprintf (outfile,"%s",string);
                  fgets (string,199,infile);
                  fprintf (outfile,"%s",string);
               }
            }
            else
            {
               if (outfile)
                  fprintf (outfile,"%s",string);
            }
         }
         while (fgets (string,199,infile));
      }

      else
      {
         if (!fgets (string,199,infile))
            break;
      }

      if (outfile)
      {
         fclose (outfile);
         outfile = NULL;
      }
   }

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int make_s_files( FILE *infile, char *header, char *prefix, int name_mode )
{
   FILE *outfile = NULL;
   double vgs,igs,vds,ids;
   char string[200];
   char str1[20];
   char str2[20];
   char fname[100];
   char minus = 'm';
   char plus = 'p';

   while (fgets (string,199,infile))
   {
      if (string[0] == '#')
         continue;
      else if (string[0] == '!')
      {
         if (outfile)
         {
            fclose (outfile);
            outfile = NULL;
         }

         if (!strncmp (string,"!BIAS:",6))
         {
            sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
               &vds,&ids,&vgs,&igs);

            if( name_mode == IDS_NAMING )
            {
               sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
               sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (ids)*1000.0)));
               sprintf (fname,"%s%sc%s%s",prefix, &str1[1], &str2[1], sp_suffix );
            }
            else
            {
               sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
               sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (vgs)*100.0)));
               sprintf (fname,"%s%s%c%s%s",prefix, &str1[1], vgs < 0.0 ? minus : plus, &str2[1], sp_suffix );
            }

            outfile = fopen (fname,"w+");
            fprintf (outfile,"%s",header);
            fprintf (outfile,"%s",string);
            fprintf (outfile,"# HZ S MA R 50.0\n");
            fgets (string,199,infile);
            if (string[0] == '#')
               fgets (string,199,infile);
            fprintf (outfile,"%s",string);
         }
      }
      else
      {
         if (outfile)
            fprintf (outfile,"%s",string);
      }
   }

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int make_noise_files( FILE *infile, char *header, char *prefix, int name_mode )
{
   FILE *outfile = NULL;
   double vgs,igs,vds,ids;
   char string[200];
   char str1[20];
   char str2[20];
   char fname[100];
   char minus = 'm';
   char plus = 'p';

   while (fgets (string,199,infile))
   {
      if (string[0] == '#')
         continue;
      else if (string[0] == '!')
      {
         if (outfile)
         {
            fclose (outfile);
            outfile = NULL;
         }

         if (!strncmp (string,"!BIAS:",6))
         {
            sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
               &vds,&ids,&vgs,&igs);

            if( name_mode == IDS_NAMING )
            {
               sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
               sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (ids)*1000.0)));
               sprintf (fname,"%s%sc%s%s",prefix, &str1[1], &str2[1], noi_suffix );
            }
            else
            {
               sprintf (str1,"%d",(int) (1000.0 + ceil (fabs (vds)*10.0)));
               sprintf (str2,"%d",(int) (1000.0 + ceil (fabs (vgs)*100.0)));
               sprintf (fname,"%s%s%c%s%s", prefix, &str1[1], vgs < 0.0 ? minus : plus, &str2[1], noi_suffix );
            }

            outfile = fopen (fname,"w+");
            fprintf (outfile,"%s",header);
            fprintf (outfile,"%s",string);
            fgets (string,199,infile);
            fprintf (outfile,"%s",string);
         }
      }
      else
      {
         if (outfile)
            fprintf (outfile,"%s",string);
      }
   }

   return 0;
}

/*********************************************************************************/
/*********************************************************************************/

static int make_dc_files( FILE *infile, char *header, char *prefix )
{
   char string[200];
   char fname[100];
   FILE *ofile=NULL;
   int x, y;

   while (fgets (string,199,infile))
   {
      if (string[0] == '#')
         continue;
      else if (string[0] == '!')
      {
         if (ofile)
         {
            fclose (ofile);
            ofile = NULL;
         }

         if (!strncmp (string,"!SITE:",6))
         {
            x=y=0;
            sscanf (string,"!SITE: X = %d Y = %d", &x, &y);
            sprintf( fname, "%s%s%d%s%d%s", prefix, x<10 ? "0" : "", x, y<10 ? "0" : "", y, dc_suffix );
            ofile = fopen (fname,"w+");
            fprintf (ofile,"%s",header);
            fprintf (ofile,"%s",string);
            fgets (string,199,infile);
            fprintf (ofile,"%s",string);
         }
      }
      else
      {
         if (ofile)
            fprintf (ofile,"%s",string);
      }
   }

   return 0;
}

