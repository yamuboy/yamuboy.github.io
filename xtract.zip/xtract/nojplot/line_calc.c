#include <stdio.h>
#include <string.h>
#include <math.h>
#include "cmplxlib.h"

/* some constants */
#define PI      3.1415926535897932
#define c0      2.99792458e8 
#define u0      (4.0*PI*1.0e-7)
#define e0      8.854187814e-12
#define ZF0     (sqrt(u0/e0))

/* minimum conductor thickness */
#define MIN_THICKNESS    1.0e-12
/* maximum conductivity */
#define MAX_SIGMA        1.0e20

/* some macros */
#define sqr(x)    ((x)*(x))
#define cube(x)   ((x)*(x)*(x))
#define siz(x)    (sizeof(x)/sizeof(*x))

/* function prototypes */
static void hammerstad_Z0_and_Eeff (double W, double h, double t, double er, double *Zl, double *Ereff);
static void kirschning_dispersion (double f, double W, double h, double er, double er_eff, double zl,
                                   double *Er_f, double *Zl_f);
static double microstrip_loss (double f, double W, double t, double er, double er_eff, double Zl, double tan_d,
                               double sigma, double delta);
static void calc_mstrip_s_params (double alpha, double er_eff, double Zl, double f, double l, COMPLEX *s);

/* substrate definition structure */
typedef struct
   {
   char *name;
   double er;
   double tand;
   double sigma;
   double delta;
   double t;
   } SubstrateDef;

/***********************************************************************************/
/***********************************************************************************/

int main (int argc, char *argv[])
   {
   char fname[256], string[256];
   FILE *file;
   double start, stop, step;
   double len = 0.0;
   double wid = 0.0;
   double h = 0.0;
   int i, n = 0;
   double Er_s, Zl_s, Er, Zl, alpha, f;
   COMPLEX s[4];
   POLAR sp[4];
   int verbose = 0;

   SubstrateDef subst[] = {
      {"dummy", 0.0, 0.0, 0.0, 0.0, 0.0},
      {"GaAs, standard", 12.9, 0.002, 4.1e7, 0.0, 5.5e-6},
      {"GaAs, standard, w/ 0.2um roughness", 12.9, 0.002, 4.1e7, 0.2e-6, 5.5e-6},
      {"GaAs, OV only (2.25um Au)", 12.9, 0.002, 4.1e7, 0.0, 2.25e-6},
      {"GaAs, ideal (lossless)", 12.9, 0.0, 1.0e30, 0.0, 5.5e-6} 
      };

   /* parse the command line */

   if (!strcmp(argv[0], "port_ext"))
      {
      printf ("\nUse of port_ext is no longer supported.\n");
      printf ("Use \"line_calc\" instead to produce real lines.\n\n");
      return 0;
      }

   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\n");
         printf ("LineCalcJB v1.0\n");
         printf ("----------------------------------------------------------\n");
         printf ("This program uses the microstrip line equations\n");
         printf ("developed by Hammerstad/Jensen/Wheeler to calculate quasi-\n");
         printf ("static values for characteristic impedance and effective\n");
         printf ("dielectric constant of a microstrip transmission line.\n");
         printf ("These values are then modified via the Kirschning/Jansen\n");
         printf ("dispersion equations to obtain the frequency-\n");
         printf ("dependent result.  Dielectric and conductor losses are\n");
         printf ("calculated using standard formulas. The output is a\n");
         printf ("Touchstone-format S-parameter data file.\n\n");
         return 0;
         }
      else if (!strncmp (argv[i], "-v", 2))
         verbose = 1;
      }

   /* get user inputs */

   printf ("\nSubstrate definition (enter number):\n");
   for (i = 1; i < siz(subst); ++i)
      printf ("  %d.) %s\n", i, subst[i].name);
   printf ("\n? > ");
   fgets (string, 255, stdin);
   sscanf (string, "%d", &n);

   if ((n < 1) || (n >= siz(subst)))
      {
      printf ("Error: invalid substrate selection.\n");
      return 1;
      }

   printf ("Substrate height in microns?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &h);

   if (h <= 0.0)
      {
      printf ("Error: substrate height must be > 0.\n");
      return 1;
      }

   printf ("Line width in microns?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &wid);

   if (wid <= 0.0)
      {
      printf ("Error: width must be > 0.\n");
      return 1;
      }

   printf ("Line length in microns?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &len);

   if (len <= 0.0)
      {
      printf ("Error: length must be > 0.\n");
      return 1;
      }

   printf ("Output file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fname);

   printf ("Frequency range for output (start stop step) in GHz?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf%lf%lf", &start, &stop, &step);

   if (start > stop)
      {
      printf ("Error: start frequency is greater than stop frequency.\n");
      return 1;
      }
   else if (step <= 0.0)
      {
      printf ("Error: frequency step is <= 0.\n");
      return 1;
      }

   /* parameter scaling */

   h *= 1.0e-6;
   len *= 1.0e-6;
   wid *= 1.0e-6;
   start *= 1.0e9;
   stop *= 1.0e9;
   step *= 1.0e9;

   /* check for validity */





   /* write the touchstone data file */

   file = fopen (fname, "w+");
   if (!file)
      {
      printf ("Error: unable to write to disc.\n");
      return 1;
      }

   /* pre-calculate the static er_eff and Zl */
   hammerstad_Z0_and_Eeff (wid, h, subst[n].t, subst[n].er, &Zl_s, &Er_s);

   /* write the file header */
   fprintf (file, "! LineCalcJB v1.0\n");
   fprintf (file, "!\n");
   fprintf (file, "! Line Parameters:\n");
   fprintf (file, "! Length = %.4e m\n", len);
   fprintf (file, "! Width = %.4e m\n", wid);
   fprintf (file, "!\n");
   fprintf (file, "! Substrate/Process Parameters:\n");
   fprintf (file, "! Height = %.3e m\n", h);
   fprintf (file, "! Er = %.3f\n", subst[n].er);
   fprintf (file, "! Loss Tangent = %.5f\n", subst[n].tand);
   fprintf (file, "! Conductivity = %.4e S/m\n", subst[n].sigma);
   fprintf (file, "! Roughness (rms) = %.3e m\n", subst[n].delta);
   fprintf (file, "! Conductor Thickness = %.3e m\n", subst[n].t);
   fprintf (file, "!\n");
   fprintf (file, "! Frequency List:\n");
   fprintf (file, "! Start = %.4e Hz\n", start); 
   fprintf (file, "! Stop = %.4e Hz\n", stop); 
   fprintf (file, "! Step = %.4e Hz\n", step); 
   fprintf (file, "!\n");
   fprintf (file, "! Calculated Parameters:\n");
   fprintf (file, "! Er_eff(0) = %.5f\n", Er_s);
   fprintf (file, "! Zl(0) = %.3f Ohms\n", Zl_s);
   fprintf (file, "!\n");
   fprintf (file, "# HZ S MA R 50\n");

   if (verbose)
      {
      printf ("     Freq        Zl      Er_eff\n");
      printf ("     (Hz)      (Ohms)\n");
      printf ("--------------------------------\n");
      /*       |           | |      | |       |  */
      }

   for (f = start; f < (stop + 0.5*step); f += step)
      {
      /* calculate frequency-dependent er_eff, Zl, and loss */
      kirschning_dispersion (f, wid, h, subst[n].er, Er_s, Zl_s, &Er, &Zl);
      alpha = microstrip_loss (f, wid, subst[n].t, subst[n].er, Er, Zl, subst[n].tand, subst[n].sigma, subst[n].delta);

      if (verbose)
         printf ("%13.4e %8.3f %9.4f\n", f, Zl, Er);

      /* calculate the S-parameters */
      calc_mstrip_s_params (alpha, Er, Zl, f, len, s);

      /* convert to polar and write to the file */
      CA2PA (s, sp, 2, 2);
      fprintf (file, "%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n", f, sp[0].m, sp[0].a,
         sp[2].m, sp[2].a, sp[1].m, sp[1].a, sp[3].m, sp[3].a);
      }

   fclose (file);

   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/
/* missing math library functions */

static double coth (double x)
   {
   return 1.0 / tanh(x);
   }

static double sech (double x)
   {
   return 1.0 / cosh(x);
   }

/***********************************************************************************/
/***********************************************************************************/
/* Hammerstad/Jensen/Wheeler equations for microstrip effective dielectric constant
    and characteristic impedance
    these equations return static (non-frequency-dependent) results
*/

static double hammerstad_Zl1 (double W, double h)
   {
   double ui = h/W;
   double fu = 6.0 + (2.0*PI-6.0)*exp( -pow( 30.666*ui, 0.7528 ) );
   return ZF0/(2.0*PI) * log( fu*ui + sqrt( 1.0+sqr(2.0*ui) ) );
   }

static double hammerstad_Ereff (double W, double h, double er)
   {
   double u = W/h;
   double u4 = u*u*u*u;
   double a = 1.0 + log( (u4 + sqr(u/52.0))/(u4+0.432) )/49.0 + log( 1.0+cube(u/18.1) )/18.7;
   double b = 0.564*pow( (er-0.9)/(er+3.0), 0.053 );
   return 0.5*(er+1.0) + 0.5*(er-1.0)*pow( 1.0+10.0/u, -a*b );
   }

static void hammerstad_Z0_and_Eeff (double W, double h, double t, double er, double *Zl, double *Ereff)
   {
   if (t < MIN_THICKNESS)
      {
      /* calculate for the case where thickness --> 0 */
      *Ereff = hammerstad_Ereff( W, h, er );
      *Zl = hammerstad_Zl1( W, h ) / sqrt( *Ereff );
      }
   else
      {
      /* calculate for the non-zero thickness case */
      double dW1 = t/PI * log( 1.0 + 4.0*exp(1.0)/(t/h*sqr(coth(sqrt(6.517*W/h)))));
      double dWr = 0.5*dW1*( 1.0+sech( sqrt(er-1.0) ) );
      double W1 = W + dW1;
      double Wr = W + dWr;
      double z1 = hammerstad_Zl1( W1, h );
      double zr = hammerstad_Zl1( Wr, h );
      double er1 = hammerstad_Ereff( Wr, h, er );

      *Zl = zr / sqrt( er1 );
      *Ereff = er1 * sqr(z1 / zr);
      }
   }

/***********************************************************************************/
/***********************************************************************************/
/* Kirschning/Jansen equations for frequency-dependent dispersion based on
    calculated static values for effective dielectic constant and
    characteristic impedance
*/

static void kirschning_dispersion (double f, double W, double h, double er, double er_eff0, double zl0,
                                   double *Er_f, double *Zl_f)
   {
   double fn = f*h*1.0e-6;  /* 1.0e-6 is to convert to units of [GHz*mm] */
   double u = W/h;

   /* effective dielectric constant dispersion calculation */
   double P1 = 0.27488 + ( 0.6315+0.525/pow( 1.0+0.0157*fn, 20.0 ) )*u - 0.065683*exp( -8.7513*u );
   double P2 = 0.33622*( 1.0-exp( -0.03442*er ) );
   double P3 = 0.0363*exp( -4.6*u )*( 1.0-exp( -pow( fn/38.7, 4.97 ) ) );
   double P4 = 1.0 + 2.751*( 1.0-exp( -pow( er/15.916, 8.0 ) ) );
   double P = P1*P2*pow( fn*(0.1844+P3*P4), 1.5763 );
   double er_efff = er - (er - er_eff0) / (1.0 + P);

   /* characteristic impedance dispersion calculation */
   double R1 = 0.03891*pow( er, 1.4 );
   double R2 = 0.267*pow( u, 7.0 );
   double R3 = 4.766*exp( -3.228*pow( u, 0.641 ) );
   double R4 = 0.016 + pow( 0.0514*er, 4.524 );
   double R5 = pow( fn/28.843, 12.0 );
   double R6 = 22.20*pow( u, 1.92 );
   double R7 = 1.206 - 0.3144*exp( (-R1 < -20.0) ? -20.0 : -R1  )*(1.0-exp( (-R2 < -20.0) ? -20.0 : -R2 ));
   double R8 = 1.0 + 1.275*( 1.0-exp( -0.004625*((R3 > 20.0) ? 20.0 : R3)*pow( er, 1.674 ) )*pow( fn/18.365, 2.745 ) );
   double R9 = 5.086*R4*R5/(0.3838+0.386*R4)*exp( -R6 )/(1.0+1.2992*R5)*pow( er-1.0, 6.0 )/(1.0+10.0*pow( er-1.0, 6.0 ));
   double R10 = 0.00044*pow( er, 2.136 ) + 0.0184;
   double R11 = pow( fn/19.47, 6.0 )/(1.0+0.0962*pow( fn/19.47, 6.0 ));
   double R12 = 1.0/(1.0+0.00245*sqr(u));
   double R13 = 0.9408*pow( er_efff, R8 ) - 0.9603;
   double R14 = (0.9408-R9)*pow( er_eff0, R8 ) - 0.9603;
   double R15 = 0.707*R10*pow( fn/12.3, 1.097 );
   double R16 = 1.0 + 0.0503*sqr(er)*R11*( 1.0-exp( -pow( u/15.0, 6.0 ) ) );
   double R17 = R7*( 1.0-1.1241*R12/R16*exp( -0.026*pow( fn, 1.15656 )-R15 ) );

   *Er_f = er_efff;
   *Zl_f = zl0*pow( R13/R14, R17 );
   }

/***********************************************************************************/
/***********************************************************************************/

static double microstrip_loss (double f, double W, double t, double er, double er_eff0, double Zl0, double tan_d,
                               double sigma, double delta)
   {
   /* dielectric loss */
   double alpha_d = PI * f/c0 * er/sqrt(er_eff0) * (er_eff0-1.0)/(er-1.0) * tan_d;

   /* conductor loss */
   double d = sqrt (1.0/(PI*f*u0*sigma));  /* skin depth */
   double alpha_c;
   if( (t < MIN_THICKNESS) || (sigma > MAX_SIGMA) )
      {
      /* lossless case */
      alpha_c = 0.0;
      }
   else 
      {
      /* skin depth is used to calculate loss */
      double Ki = exp( -1.2*pow( Zl0/ZF0, 0.7 ) );
      double Rs = ( 1.0 + 2.0/PI*atan( 1.4*sqr(delta/d) ) ) / (sigma * d);

      alpha_c = 0.5 * Rs/(Zl0*W) * Ki;
      }

   return alpha_c + alpha_d;
   }

/***********************************************************************************/
/***********************************************************************************/
/* calculate the S-parameters of the line */

static COMPLEX Ccosh (COMPLEX x)
   {
   COMPLEX z;
   z.r = cosh(x.r) * cos(x.i);
   z.i = sinh(x.r) * sin(x.i);
   return z;
   }

static COMPLEX Csinh (COMPLEX x)
   {
   COMPLEX z;
   z.r = sinh(x.r) * cos(x.i);
   z.i = cosh(x.r) * sin(x.i);
   return z;
   }

static COMPLEX Ctanh (COMPLEX x)
   {
   return Cdiv( Csinh(x), Ccosh(x) );
   }

static void calc_mstrip_s_params (double alpha, double er_eff, double Zl, double f, double l, COMPLEX *s)
   {
   double Z0 = 50.0;  /* set reference impedance */
   double beta = sqrt(er_eff) * 2.0*PI*f*sqrt(e0*u0);
   COMPLEX two = {2.0, 0.0};
   COMPLEX gamma = Cnum(alpha,beta);
   COMPLEX z = Cpx(Zl/Z0);
   COMPLEX y = Cpx(Z0/Zl);
   COMPLEX gl = Cmult(Cpx(l),gamma);
   COMPLEX d1 = Cmult(two, Ccosh(gl));
   COMPLEX d2 = Cmult(Cadd (z,y), Csinh(gl));
   COMPLEX d3 = Cadd(d1,d2);
   COMPLEX yp[4];
   COMPLEX one = {1.0, 0.0};
   COMPLEX mone = {-1.0, 0.0};

   s[0] = s[3] = Cdiv (Cmult(Csub(z,y), Csinh(gl)), d3);
   s[1] = s[2] = Cdiv (two, d3);

   yp[0] = yp[3] = Cdiv( one, Cmult( Cpx(Zl), Ctanh(gl) ) );
   yp[1] = yp[2] = Cdiv( mone, Cmult( Cpx(Zl), Csinh(gl) ) );
   y2s (yp, s, 50.0);
   }




