#include <iostream>
#include <iomanip>
#include "mct_parser.hpp"

class MCT_to_MDIF : public MCT_File_Parser
{
public:
    void setDirectory( const std::string& dir ) {
        dirname_ = dir;
    }
    const std::string& getDirectory() const {
        return dirname_;
    }

    bool createMDIF();
    bool createMDIF( const std::string& fname ) {
        fname_ = fname;
        return createMDIF();
    }

    MCT_to_MDIF() {}
    MCT_to_MDIF( const std::string& fname, const std::string& dir="" ) : MCT_File_Parser(fname), dirname_(dir) {}
    virtual ~MCT_to_MDIF() {}
protected:
    std::string dirname_;

    void mdifGeneric();
    void mdifFET();
    void mdifBipolar();

    // build the path to an output file
    std::string buildPath( const std::string& fname ) const {
        std::string p = dirname_;
#ifdef WIN32
        char sep = '\\';
#else
        char sep = '/';
#endif
        if(p.length()) p += sep;
        p += fname;
        return p;
    }

    // open a file to write an add the header information
    void openOutputFile( std::ofstream& f, const std::string& fname ) {
        f.open( buildPath(fname).c_str() );
        if( !f ) throwError( std::string("MCT_to_MDIF::openOutputFile(): ") + fname + ": failed to open file for writing." );
        f << header_;
        f << std::scientific << std::setprecision(4);
    }

    void writeBlockBiasComment( std::ofstream& os, const DC_Data& d );
    void writeBlockS2P( std::ofstream& os, const S2P_DataBlock& d );
    void writeBlockNF( std::ofstream& os, const NF_DataBlock& d );
};

/*********************************************************************************/

bool MCT_to_MDIF::createMDIF()
{
    std::list<std::string> names;
    // run the MCT_File_Parser::parse method
    if( !parse() ) return false;

    // detect the type of data contained (FET, HBT, Generic)
    try{

        if( mode_==1 ) {
            mdifFET();
        }
        else if( mode_==2 ) {
            mdifBipolar();
        }
        else {
            mdifGeneric();
        }
    }
    catch( std::exception& e ) {
        setError( std::string("Exception: ") + std::string(e.what()) + " Caught by MCT_to_MDIF::createMDIF()." );
        return false;
    }

    return true;
}


/*********************************************************************************/

void MCT_to_MDIF::mdifGeneric()
{
    // create DC MDIF files

    // create S2P MDIF files


    // create noise figure MDIF files

    throwError( "MCT_to_MDIF::mdifGeneric(): function not implemented." );
}

/*********************************************************************************/

void MCT_to_MDIF::mdifFET()
{
    std::ofstream os;

    // create DC MDIF files
    if( dcHasBlock("fwdiv") ) {
        const DC_DataBlock& b = dcGetBlock("fwdiv");
        openOutputFile(os,"fwdiv.mdf");
        os << "BEGIN FWDIV" << std::endl;
        os << "% Vg(1) Ig(1) Id(1)" << std::endl;
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            if( i->vout != 0. ) continue;
            os << i->vin << "\t" << i->iin << "\t" << i->iout << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    if( dcHasBlock("vbriv") ) {
        const DC_DataBlock& b = dcGetBlock("vbriv");
        openOutputFile(os,"vbriv.mdf");
        os << "BEGIN VBRIV" << std::endl;
        os << "% Vdg(1) Id(1) Ig(1)" << std::endl;
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            os << (i->vout - i->vin) << "\t" << i->iout << "\t" << i->iin << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    if( dcHasBlock("ivcurves") ) {
        const DC_DataBlock& b = dcGetBlock("ivcurves");
        double vg = -1.e12;
        bool first=true;
        openOutputFile(os,"dciv.mdf");
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            if( vg != i->vin ) {
                // need to write a new header
                if( !first ) os << "END" << std::endl;
                os << "! DC-IV Data Set" << std::endl;
                os << "VAR Vgs(1) = " << i->vin << std::endl;
                os << "BEGIN DCIV" << std::endl;
                os << "% Vds(1) Ids(1) Igs(1)" << std::endl;
                vg = i->vin;
                first=false;
            }
            os << i->vout << "\t" << i->iout << "\t" << i->iin << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    // create S2P MDIF files
    if( s2pHasBlock("coldfet") ) {
        openOutputFile(os,"coldfet.mdf");
        for( std::list<S2P_DataBlock>::iterator i = s2pblocks_.begin(); i != s2pblocks_.end(); ++i ) {
            if( i->getName() != "coldfet" ) continue;
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Igs = " << i->getBias().iin << std::endl;
            writeBlockS2P(os,*i);
        }
        os.close();
    }

    if( s2pHasBlock("s2p") ) {
        openOutputFile(os,"sparams.mdf");
        for( std::list<S2P_DataBlock>::iterator i = s2pblocks_.begin(); i != s2pblocks_.end(); ++i ) {
            if( i->getName() != "s2p" ) continue;
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Vgs = " << i->getBias().vin << std::endl;
            os << "VAR Vds = " << i->getBias().vout << std::endl;
            writeBlockS2P(os,*i);
        }
        os.close();
    }

    // create noise figure MDIF files
    if( nfblocks_.size() ) {
        openOutputFile(os,"noise.mdf");
        for( std::list<NF_DataBlock>::iterator i = nfblocks_.begin(); i != nfblocks_.end(); ++i ) {
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Vgs(1) = " << i->getBias().vin << std::endl;
            os << "VAR Vds(1) = " << i->getBias().vout << std::endl;
            writeBlockNF(os,*i);
        }
        os.close();
    }
}

/*********************************************************************************/

void MCT_to_MDIF::mdifBipolar()
{
    std::ofstream os;

    // create DC MDIF files
    if( dcHasBlock("fwdgummel") ) {
        const DC_DataBlock& b = dcGetBlock("fwdgummel");
        openOutputFile(os,"fwdgummel.mdf");
        os << "BEGIN FWDGUMMEL" << std::endl;
        os << "% Vb(1) Ib(1) Ic(1)" << std::endl;
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            os << i->vin << "\t" << i->iin << "\t" << i->iout << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    if( dcHasBlock("revgummel") ) {
        const DC_DataBlock& b = dcGetBlock("revgummel");
        openOutputFile(os,"revgummel.mdf");
        os << "BEGIN REVGUMMEL" << std::endl;
        os << "% Vb(1) Ib(1) Ie(1)" << std::endl;
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            os << (-i->vout) << "\t" << i->iin << "\t" << (-i->iout-i->iin) << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    if( dcHasBlock("flyback") ) {
        const DC_DataBlock& b = dcGetBlock("flyback");
        openOutputFile(os,"flyback.mdf");
        os << "BEGIN FLYBACK" << std::endl;
        os << "% Ib(1) Vc(1)" << std::endl;
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            os << i->iin << "\t" << i->vout << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    if( dcHasBlock("ivcurves") ) {
        const DC_DataBlock& b = dcGetBlock("ivcurves");
        double ib = -1.e12;
        bool first=true;
        openOutputFile(os,"ivcurves.mdf");
        for( DC_DataBlock::const_iterator i = b.begin(); i != b.end(); ++i ) {
            if( ib != i->iin ) {
                // need to write a new header
                if( !first ) os << "END" << std::endl;
                os << "! DC-IV Data Set" << std::endl;
                os << "VAR Ibe(1) = " << i->iin << std::endl;
                os << "BEGIN DCIV" << std::endl;
                os << "% Vce(1) Ice(1) Vbe(1)" << std::endl;
                ib = i->iin;
                first=false;
            }
            os << i->vout << "\t" << i->iout << "\t" << i->vin << std::endl;
        }
        os << "END" << std::endl;
        os.close();
    }

    // create S2P MDIF files
    if( s2pHasBlock("hothbt") ) {
        openOutputFile(os,"hothbt.mdf");
        for( std::list<S2P_DataBlock>::iterator i = s2pblocks_.begin(); i != s2pblocks_.end(); ++i ) {
            if( i->getName() != "hothbt" ) continue;
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Ibe = " << i->getBias().iin << std::endl;
            writeBlockS2P(os,*i);
        }
        os.close();
    }

    if( s2pHasBlock("cbc") ) {
        openOutputFile(os,"cbc.mdf");
        for( std::list<S2P_DataBlock>::iterator i = s2pblocks_.begin(); i != s2pblocks_.end(); ++i ) {
            if( i->getName() != "cbc" ) continue;
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Vj = " << (i->getBias().vin - i->getBias().vout) << std::endl;
            writeBlockS2P(os,*i);
        }
        os.close();
    }

    if( s2pHasBlock("cbe") ) {
        openOutputFile(os,"cbe.mdf");
        for( std::list<S2P_DataBlock>::iterator i = s2pblocks_.begin(); i != s2pblocks_.end(); ++i ) {
            if( i->getName() != "cbe" ) continue;
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Vj = " << i->getBias().vin << std::endl;
            writeBlockS2P(os,*i);
        }
        os.close();
    }

    if( s2pHasBlock("s2p") ) {
        openOutputFile(os,"sparams.mdf");
        for( std::list<S2P_DataBlock>::iterator i = s2pblocks_.begin(); i != s2pblocks_.end(); ++i ) {
            if( i->getName() != "s2p" ) continue;
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Ibe = " << i->getBias().iin << std::endl;
            os << "VAR Vce = " << i->getBias().vout << std::endl;
            writeBlockS2P(os,*i);
        }
        os.close();
    }

    // create noise figure MDIF files
    if( nfblocks_.size() ) {
        openOutputFile(os,"noise.mdf");
        for( std::list<NF_DataBlock>::iterator i = nfblocks_.begin(); i != nfblocks_.end(); ++i ) {
            writeBlockBiasComment(os,i->getBias());
            os << "VAR Ibe(1) = " << i->getBias().iin << std::endl;
            os << "VAR Vce(1) = " << i->getBias().vout << std::endl;
            writeBlockNF(os,*i);
        }
        os.close();
    }
}

/*********************************************************************************/

void MCT_to_MDIF::writeBlockBiasComment( std::ofstream& os, const DC_Data& bias )
{
    os << "! --- Bias Data ---" << std::endl;
    os << "!  Vin,Iin,Vout,Iout" << std::endl;
    os << "!@BIAS: " << bias.vin << ',' << bias.iin << ',' << bias.vout << ',' << bias.iout << std::endl;
    os << "! -----------------" << std::endl;
}

/*********************************************************************************/

void MCT_to_MDIF::writeBlockS2P( std::ofstream& os, const S2P_DataBlock& d )
{
    static const double rad2deg = 180. / M_PI;
    // begin the block
    os << "BEGIN ACDATA" << std::endl;
    // format line
    os << "#AC( HZ S MA R 50 )" << std::endl;
    // variable identifier line
    os << "% F n11x n11y n21x n21y n12x n12y n22x n22y" << std::endl;
    // then the data
    for( S2P_DataBlock::const_iterator i = d.begin(); i!=d.end(); ++i ) {
        os << i->freq << "\t";
        os << sqrt(i->s11.real()*i->s11.real()+i->s11.imag()*i->s11.imag()) << "\t" << (atan2(i->s11.imag(),i->s11.real())*rad2deg) << "\t";
        os << sqrt(i->s21.real()*i->s21.real()+i->s21.imag()*i->s21.imag()) << "\t" << (atan2(i->s21.imag(),i->s21.real())*rad2deg) << "\t";
        os << sqrt(i->s12.real()*i->s12.real()+i->s12.imag()*i->s12.imag()) << "\t" << (atan2(i->s12.imag(),i->s12.real())*rad2deg) << "\t";
        os << sqrt(i->s22.real()*i->s22.real()+i->s22.imag()*i->s22.imag()) << "\t" << (atan2(i->s22.imag(),i->s22.real())*rad2deg) << std::endl;
    }
    os << "END" << std::endl;
}

/*********************************************************************************/

void MCT_to_MDIF::writeBlockNF( std::ofstream& os, const NF_DataBlock& d )
{
    // begin the block
    os << "BEGIN NOISE" << std::endl;
    // variable identifier line
    os << "% freq(1) nf(1) gain(1)" << std::endl;
    // then the data
    for( NF_DataBlock::const_iterator i = d.begin(); i!=d.end(); ++i ) {
        os << i->freq << "\t" << i->nf << "\t" << i->gain << std::endl;
    }
    os << "END" << std::endl;
}

/*********************************************************************************/

void print_usage( const char *progname )
{
    std::cout << progname << " [options] filename" << std::endl;
}

/*********************************************************************************/
/*********************************************************************************/

int main( int argc, char** argv )
{
    MCT_to_MDIF tomdif;
    std::string fname, ar;
    bool verbose = false;

    if( argc < 2 ) {
        print_usage(argv[0]);
        return 0;
    }

    // read command line options
    for( int i=1; i<argc; ++i )
    {
        ar = argv[i];
        if( ar == "-v" || ar == "--verbose" ) verbose = true;
        else if( *(ar.begin()) != '-' && !fname.length() ) fname = ar;
    }

    if( !fname.length() ) {
        std::cerr << "Error: no file specified." << std::endl;
        print_usage(argv[0]);
        return 1;
    }

    if( verbose ) std::cout << "Creating MDIF files from: " << fname << std::endl << std::endl;

    // run the command
    if( ! tomdif.createMDIF(fname) ) {
        std::cerr << tomdif.getError() << std::endl;
        return 1;
    }

    // done
    if( verbose ) std::cout << "Done." << std::endl << std::endl;

    return 0;
}

