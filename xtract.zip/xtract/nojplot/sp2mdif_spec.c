#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define Z0   50.0

int main (int argc, char *argv[])
   {
   char string[256],filename[256],outname[256];
   char sp_fmt_string[256];
   FILE *infile,*outfile;
   double  m11,m12,m21,m22;
   double  a11,a12,a21,a22;
   double freq,vds,vgs,ids,igs;
   int header_done, first, i;
   int state;

   // set the default format string
   strcpy (sp_fmt_string, "# HZ S MA R 50\n");

   // look for command line args
   if (argc < 2)
      {
      printf ("\n\nUSAGE: %s file1 [file2 ...]\n\n", argv[0]);
      return 0;
      }

   // start the file loop
   for (i = 1; i < argc; ++i)
      {
      sscanf (argv[i], "%s", filename);

      // determine the output file name
      sscanf (filename, "%[^.]", outname);
      strcat (outname, ".mdf");
      if (!strcmp (filename, outname))
         {
         printf ("\nWarning: %s: cannot have .mdf extension.\n\n", filename);
         continue;
         }

      // open the input file
      infile = fopen (filename, "r");
      if (!infile)
         {
         printf ("\nWarning: %s: cannot open file.\n\n", filename);
         continue;
         }

      // open the output file
      outfile = fopen (outname,"w+");
      if (!outfile)
         {
         printf ("Error: unable to write to disc.\n\n");
         continue;
         }

      // read the input file and write to the output file
      header_done = 0;
      first = 1;
      state = 0;
      while (fgets (string, 255, infile))
         {
         if (!header_done)
            {
            if ((string[0] != '!') || strstr (string, "S-PARAMETERS") || strstr (string, "!BIAS:") || (string[0] == '#'))
               {
               header_done = 1;
               fprintf (outfile,"!\n");
               }
            else
               {
               fprintf (outfile, "%s", string);
               continue;
               }
            }

         if (string[0] == '#')
            {
            strcpy (sp_fmt_string, string);
            continue;
            }
         else if (string[0] == '!')
            {
            if (sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",&vds,&ids,&vgs,&igs) == 4)
               {
               if (!first)
                  fprintf (outfile,"END\n!\n");

               fprintf (outfile, "%s", string);
               fprintf (outfile, "VAR State = %d\n", state++);
               fprintf (outfile, "BEGIN ACDATA\n");
               fprintf (outfile, "%s", sp_fmt_string);
               fprintf (outfile, "%% F n11x n11y n21x n21y n12x n12y n22x n22y\n");

               first = 0;
               }
            else if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&vds,&ids,&vgs,&igs) == 4)
               {
               if (!first)
                  fprintf (outfile,"END\n!\n");

               fprintf (outfile, "%s",string);
               fprintf (outfile, "VAR State = %d\n", state++);
               fprintf (outfile, "BEGIN ACDATA\n");
               fprintf (outfile, "%s", sp_fmt_string);
               fprintf (outfile, "%% F n11x n11y n21x n21y n12x n12y n22x n22y\n");

               first = 0;
               }

            continue;
            }

         if (!first && (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&m11,&a11,&m21,&a21,&m12,&a12,&m22,&a22) == 9))
            fprintf (outfile, "%s", string);
         }

      fprintf (outfile,"END\n");

      fclose (infile);
      fclose (outfile);
      }

   return 0;
   }
