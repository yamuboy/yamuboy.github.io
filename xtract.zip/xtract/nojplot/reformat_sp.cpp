#include <iostream>
#include <string>
#include <list>
#include <touchstone.hpp>
#include <stdlib.h>

void print_usage( const char* pname )
{
   std::cout << "USAGE: " << pname << " [options] filename [filename2 ...]" << std::endl << std::endl;
   std::cout << "Options:" << std::endl << std::endl;
   std::cout << "  --fmt=XX   Set the file format to one of ma, db, or ri." << std::endl;
   std::cout << "  --fs=XX    Set the frequency scaling to Hz, KHz, MHz, GHz, or THz." <<std::endl;
   std::cout << "  --prec=X   Set the floating point precision." << std::endl;
   std::cout << "  -fix, --fix  Use fixed-point format." << std::endl;
   std::cout << "  -sci, --sci  Use scientific format." << std::endl;



   std::cout << std::endl;
}

std::string str2lower( std::string str )
{
   for( std::string::iterator i = str.begin(); i != str.end(); ++i ) {
      if( *i >= 'A' && *i <= 'Z' ) {
         *i += ('a' - 'A');
      }
   }
   return str;
}

int main( int argc, char **argv )
{
   Touchstone in;
   Touchstone::e_write_format fmt = Touchstone::MagAngle;
   Touchstone::e_freq_scale scale = Touchstone::Hertz;
   Touchstone::e_fp_mode fpmode = Touchstone::FPauto;
   int prec = 6;
   int e;
   std::string ar;
   std::string val;
   std::list<std::string> filelist;
   size_t pos;
   std::string ext;
   std::string fout;

   /* process the command line */
   for( int i=1; i<argc; ++i )
   {
      ar = argv[i];
      if( argv[i][0] == '-' ) {
         // starts with a dash, must be an option
         if( ar.substr(0,6) == "--fmt=" ) {
	    val = str2lower(ar.substr(6));
	    if( val=="ma" ) {
	       fmt = Touchstone::MagAngle;
	    }
	    else if( val=="ri" ) {
	       fmt = Touchstone::RealImag;
	    }
	    else if( val=="db" ) {
	       fmt = Touchstone::DbAngle;
	    }
	    else {
	       std::cerr << "Invalid value: " << ar << std::endl;
	       print_usage(argv[0]);
	       exit(1);
	    }
	 }
	 else if( ar.substr(0,5) == "--fs=" ) {
	    val = str2lower(ar.substr(5));
	    if( val.length() ) {
	       int ch = val[0];
	       switch( ch )
	       {
	       case 'h':
	          scale = Touchstone::Hertz; break;
	       case 'k':
	          scale = Touchstone::Kilohertz; break;
	       case 'm':
	          scale = Touchstone::Megahertz; break;
	       case 'g':
	          scale = Touchstone::Gigahertz; break;
	       case 't':
	          scale = Touchstone::Terahertz; break;
	       default:
	          std::cerr << "Invalid value: " << ar << std::endl;
	          print_usage(argv[0]);
	          exit(1);
	       }
	    }
	    else {
	       std::cerr << "Invalid value: " << ar << std::endl;
	       print_usage(argv[0]);
	       exit(1);
	    }
	 }
	 else if( ar.substr(0,7) == "--prec=" ) {
	    val = ar.substr(7);
	    sscanf( val.c_str(), "%d", &prec );
	    if( prec < 3 ) prec = 3;
	    else if( prec > 15 ) prec = 15;
	 }
	 else if( ar == "-sci" || ar == "--sci" ) {
            fpmode = Touchstone::FPscientific;
	 }
	 else if( ar == "-fix" || ar == "--fix" ) {
            fpmode = Touchstone::FPfixed;
	 }
	 else {
            std::cerr << "Invalid parameter: " << ar << std::endl;
            print_usage(argv[0]);
            exit(1);
	 }
      }

      else {
         // doesn't start with a dash, must be a filename
         filelist.push_back(ar);
      }
   }

   // see if any files were listed
   if( filelist.empty() ) {
      std::cerr << "No files listed." << std::endl;
      print_usage(argv[0]);
      exit(1);
   }

   // loop through the files listed on the command line
   for( std::list<std::string>::iterator fname = filelist.begin(); fname != filelist.end(); ++fname ) {
      try {
          // read the file
          in.read( *fname );

          // generate a filename for output
          pos = fname->find_last_of('.');
          if( pos != std::string::npos ) ext = fname->substr(pos);
          else ext = "";

          if( ext.find_first_of('/') != std::string::npos || ext.find_first_of('\\') != std::string::npos ) {
             fout = *fname + "-1";
          }
          else {
             fout = fname->substr(0,pos) + "-1";
             fout += ext;
          }

          // adjust formatting parameters
          in.set_format( fmt, scale, prec, fpmode );

          // output the file with adjusted formatting
          in.write( fout );
      }
      catch( TouchstoneError& e ) {
            std::cerr << "Warning: " << e.what() << std::endl;
            continue;
      }
   }

   return 0;
}
