#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>

#define MAX_SITES       50

typedef struct {
   char site_num[10];
   char mask[50], wafer[50];
   double periphery, ugw, ngf, temperature;
   char dc_param_head[256];
   char dc_param_data[256];
   int start_idx;
   int end_idx;
} DeviceGroup;

typedef struct {
    double vds, ids, vgs, igs;
} Bias;


static char *get_the_time( char *str );
static void get_filenames( const char *in_name, char *end_name, char *noise_name );
static char *get_sitenum( const char *str );

static int read_bias_and_header( const char* s2p_file, DeviceGroup* dev, Bias* b, char* header );
static int read_model_params( const char* end_file, double* parms );
static int read_noise_params( const char* rpc_file, double* vv, double* ii );

/*******************************************************************************************/
/*******************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *file;
   char noise_filename[256], end_filename[256];
   char *outname = "model.dscr";
   int i, j, k, linec;
   int include_noise = 0;
   int n = 0;
   int siten = 0;
   DeviceGroup dev[MAX_SITES];
   DeviceGroup tdev;
   double **params;
   char string[256];
   char last_site[50];
   int n_files=0;
   const char **file_list, **fname;
   char header[2000];
   Bias bias;

   // parameter stuff
   static char *labels[] = {"  Periphery ", "     ugw    ", "     ngf    ", "     Vds    ", "     Ids    ",
                            "    mA_mm   ", "     Vgs    ", "     Igs    ", "     Rg     ", "     Rs     ",
                            "     Rd     ", "     Ri     ", "     Cgs    ", "     Cdg    ", "     Cds    ",
                            "     C1     ", "     C2     ", "     Ls     ", "     Lg     ", "     Ld     ",
                            "     Ggs    ", "     Gdg    ", "     Gm     ", "     T1     ", "     Gds    ",
                            "     T2     ", "     C11    ", "     C22    ", "     vv     ", "     ii     "};
   static double factors[] = {1.0e-03, 1.0e+00, 1.0e+00, 1.0e+00, 1.0e+03,
                              1.0e+03, 1.0e+00, 1.0e+03, 1.0e+00, 1.0e+00,
                              1.0e+00, 1.0e+00, 1.0e+12, 1.0e+12, 1.0e+12,
                              1.0e+12, 1.0e+12, 1.0e+12, 1.0e+12, 1.0e+12,
                              1.0e+03, 1.0e+03, 1.0e+03, 1.0e+12, 1.0e+03,
                              1.0e+12, 1.0e+12, 1.0e+12, 1.0e+00, 1.0e+00};


   /* parse the command line */
   header[0] = '\0';

   file_list = (const char**) malloc( sizeof(const char*) * (argc+2) );

   if( strstr(argv[0], "noise") ) {
      include_noise = 1;
      outname = "noise.dscr";
   }

   for( i=1; i<argc; i++ ) {
       if( argv[i][0] == '-' ) {
       }
       else file_list[n_files++] = argv[i];
   }

   file_list[n_files] = NULL;

   if( !n_files ) {
      fprintf( stderr, "Error: no files to summarize.\n");
      return -1;
   }

   /* allocate memory */
   params = (double **) malloc( sizeof(double *) * n_files );
   for( i=0; i<n_files; ++i )
      params[i] = (double *) malloc( sizeof(double) * 31 );

   /* read in all the data */

   printf ("Reading model data ....\n");

   for( fname=file_list; *fname; ++fname ) {
      get_filenames( *fname, end_filename, noise_filename );

      // read data
      if( read_bias_and_header( *fname, &tdev, &bias, *header ? NULL : header ) ||
          read_model_params( end_filename, &params[n][8] ) )
          continue;
      if( include_noise && read_noise_params( noise_filename, &params[n][28], &params[n][29] ) )
          continue;

      /* verify the data */
      if( tdev.ugw <= 0. || tdev.ngf < 0. || tdev.ugw * tdev.ngf != tdev.periphery ||
          ! tdev.temperature ) {
              fprintf( stderr, "%s: incomplete header.\n", *fname );
              continue;
      }

      params[n][0] = tdev.periphery;
      params[n][1] = tdev.ugw;
      params[n][2] = tdev.ngf;
      params[n][3] = bias.vds;
      params[n][4] = bias.ids;
      params[n][5] = bias.ids * 1000. / tdev.periphery;
      params[n][6] = bias.vgs;
      params[n][7] = bias.igs;

      if( strcmp( tdev.site_num, last_site ) ) {
          // this is a new device
          dev[siten] = tdev;
          dev[siten].start_idx = n;
          dev[siten].end_idx = n;

          // print the current device number
          printf( "Device %s ....\n", dev[siten].site_num );

          strcpy( last_site, dev[siten].site_num );
          ++siten;
      }

      // increment the data counter
      //  and the end index counter of the current site
      ++n;
      if( siten ) ++dev[siten-1].end_idx;
   }

   if( !n || !siten ) {
      fprintf( stderr, "Error: no data.\n" );
      for( i=0; i<n_files; ++i )
         free( (void *) params[i] );
      free( (void *) params );
      return 1;
  }

   printf( "Sorting model data ....\n" );

   /**** sort data for each site by increasing Vds then Vgs ****/
   for( i=0; i<siten; ++i ) {
        for( j=dev[i].start_idx; j<dev[i].end_idx; ++j ) {
            for( k=j; k<dev[i].end_idx; ++k ) {
                if( params[j][3] > params[k][3] ||
                    (params[j][3] == params[k][3] && params[j][6] > params[k][6]) ) {
                        double* t = params[j];
                        params[j] = params[k];
                        params[k] = t;
                }
            }
        }
   }

   /**** re-order the site numbers ??? ****/
   for( i=0; i<siten; ++i ) {
       // do something in here???



   }

   /**** write the sorted DSCR data to the file ****/

   file = fopen( outname, "w+" );
   if( !file ) {
      fprintf( stderr, "Error: %s: unable to open file for writing.\n", outname );
      return 1;
   }

   // write headers
   fprintf( file, header );
   fprintf( file, "!Model Dev  Mask     Lot              Temp  Periphery UGW   NGF %s", dev[0].dc_param_head );
   fprintf( file, "!                                     (C)     (um)    (um)      \n" );
   for( i=0; i<siten; ++i ) {
      fprintf (file,"!%-5d %-4s %-8s %-15s %5.1f   %6.1f %6.2f %3d %s",
          i+1, dev[i].site_num, dev[i].mask, dev[i].wafer, dev[i].temperature,
          dev[i].periphery, dev[i].ugw, (int) dev[i].ngf, dev[i].dc_param_data );
   }
   fprintf( file, "!\n" );
   fprintf( file, "! FET MODEL DSCR PROGRAM VERSION 2.00 %s\n", get_the_time(string) );
   fprintf( file, "!\n" );
   fprintf( file, "BEGIN DSCRDATA\n" );
   fprintf( file, "%% index " );
   for( i=0; i < (28 + include_noise*2); ++i )
      fprintf( file, "%s", labels[i] );
   fprintf( file, "\n" );

   // write data
   linec = 0;
   for( i=0; i<siten; ++i ) {
       fprintf( file, "!DEV_NUM: %d\n", i+1 );
       for( j=dev[i].start_idx; j<dev[i].end_idx; ++j ) {
           ++linec;
           fprintf( file, "%5d   ", linec );
           for( k=0; k < (28 + include_noise*2); ++k )
                fprintf( file, " %+.4e", params[j][k]*factors[k] );
           fprintf( file, "\n" );
       }
   }

    // free memory
   for( i=0; i<n_files; ++i )
      free( (void *) params[i] );
   free( (void *) params );

   printf("Complete!\n");

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static char *get_the_time( char *str )
{
   char *ptr;
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];
   time_t now;

   time (&now);
   ptr = asctime (localtime (&now));
   sscanf (ptr+8,"%s",s_day);
   sscanf (ptr+4,"%s",s_month);
   sscanf (ptr+20,"%s",s_year);
   sscanf (ptr+11,"%s",s_time);
   sprintf (str,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

   return str;
}

/*******************************************************************************************/
/*******************************************************************************************/

static void get_filenames( const char *in_name, char *end_name, char *noise_name )
{
   size_t i;

   strcpy( end_name, in_name );

   for( i=strlen(end_name)-1; i>0; --i ) {
      if( end_name[i] == '.' ) {
         end_name[i] = '\0';
         break;
      }
      else if( end_name[i] == '/' || end_name[i] == '\\' ) break;
   }

   strcpy( noise_name, end_name );
   strcat( end_name, ".end" );
   strcat( noise_name, ".rpc" );

   // determine if there is a slash in the filename in order to seperate the file name from the path
   for( i=strlen(noise_name)-1; i>0; --i ) {
      if( noise_name[i] == '/' || noise_name[i] == '\\' ) {
         ++i;  break;
      }
   }
   noise_name[i] = 'n';
}

/*******************************************************************************************/
/*******************************************************************************************/

static int read_bias_and_header( const char* s2p_file, DeviceGroup* dev, Bias* b, char* header )
{
    FILE* file;
    char string[256];

    /* initialize stuff */
    dev->site_num[0] = '\0';
    dev->mask[0] = '\0';
    dev->wafer[0] = '\0';
    dev->periphery = 0.;
    dev->ugw = 0.;
    dev->ngf = 0.;
    dev->temperature = 0.;
    dev->dc_param_head[0] = '\0';
    dev->dc_param_data[0] = '\0';
    dev->start_idx = 0;
    dev->end_idx = 0;
    b->vds = b->vgs = b->ids = b->igs = 0.;
    if( header ) header[0] = '\0';

    file = fopen( s2p_file, "r" );
    if( !file ) {
        fprintf( stderr, "%s: unable to open file.\n", s2p_file );
        return 1;
    }

    /* read in information from the S-parameter file */
    while( fgets(string, 255, file) ) {
        if( string[0] != '!' ) break;
        else if( !strncmp(string, "!FILE NAME:", 11) ) {
            char str2[256];
            str2[0] = '\0';
            sscanf( string, "!FILE NAME: %255s", str2 );
            strcpy( dev->site_num, get_sitenum(str2) );
        }
        else if( !strncmp(string,"!MASK NAME:",11) )
            sscanf( string, "!MASK NAME: %49s", dev->mask );
        else if( !strncmp(string,"!WAFER NUMBER:",14) )
            sscanf (string, "!WAFER NUMBER: %49s", dev->wafer );
        else if( !strncmp(string,"!GATE PERIPHERY (um):",21) )
            sscanf( string, "!GATE PERIPHERY (um): %lf", &dev->periphery );
        else if( !strncmp(string,"!UNIT GATE WIDTH (um):",22) )
            sscanf( string, "!UNIT GATE WIDTH (um): %lf", &dev->ugw );
        else if( !strncmp(string,"!NUMBER OF GATE FINGERS:",24) )
            sscanf( string, "!NUMBER OF GATE FINGERS: %lf", &dev->ngf );
        else if( !strncmp(string,"!TEMPERATURE (C):",17) )
            sscanf( string, "!TEMPERATURE (C): %lf", &dev->temperature);
        else if( !strncmp(string,"!Vbr",4) ) {
            strcpy( dev->dc_param_head, &string[1] );
            if( fgets(string, 255, file) )
                strcpy( dev->dc_param_data, &string[1] );
            else {
                fclose( file );
                fprintf( stderr, "%s: incomplete file.\n", s2p_file );
                return 1;
            }
        }
        else if( !strncmp(string,"!BIAS:", 6) ) {
            sscanf( string, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
                &b->vds, &b->ids, &b->vgs, &b->igs );
            break;
        }

        // only need to read these values once
        if( header ) {
            if( !strncmp(string,"!PROCESS NAME:",14) ||
                !strncmp(string,"!DEVICE NAME:",13) ||
                !strncmp(string,"!GATE LENGTH (um):",18) ||
                !strncmp(string,"!GATE TO GATE SPACING (um):",27) ||
                !strncmp(string,"!SOURCE-DRAIN SPACING (um):",27) )
                strcat( header, string );
        }
    }

    fclose(file);
    return 0;
}



/*******************************************************************************************/
/*******************************************************************************************/

static int read_model_params( const char* end_file, double* parms )
{
   FILE *file;
   unsigned i=0;
   char string[256];
   char nm[35];
   double pt;
   static const char* names[] = { "RG", "RS", "RD", "RI", "CGS", "CDG", "CDS", "C1", "C2", "LS",
        "B1", "B2", "GGS", "GDG", "GM", "TAU1", "GDS", "TAU2", "C11", "C22" };

   file = fopen( end_file, "r");
   if( !file ) {
      fprintf( stderr, "%s: unable to open file.\n", end_file );
      return 1;
   }

   while( fgets(string, 255, file) ) {
      if( i == 20 ) break;

      if( string[0] == '!' || string[0] == '#' )
         continue;

      if( sscanf(string, "%*f%lf%*f%*f%20s", &pt, nm ) == 2 ) {
          if( strcmp( nm, names[i] ) ) {
              fclose (file);
              fprintf( stderr, "%s: error invalid parameter or parameter order.\n", end_file );
              return 1;
          }
          parms[i] = pt;
          ++i;
      }
   }

   fclose (file);

   if( i != 20 ) {
      fprintf( stderr, "%s: missing parameters.\n", end_file );
      return 1;
   }

   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

static int read_noise_params( const char* rpc_file, double* vv, double* ii )
{
   FILE *file;
   char string[256];
   int found = 0;

   file = fopen( rpc_file, "r");
   if( !file ) {
      fprintf( stderr, "%s: unable to open file.\n", rpc_file );
      return 1;
   }

   while( fgets(string, 255, file) ) {
      if( string[0] == '!' || string[0] == '#' )
         continue;

      if( sscanf(string, "%*f%*f%*f%*f%*f%*f%*f%*f%*f%lf%lf", vv, ii ) == 2 ) {
          found = 1;
          break;
      }
   }

   fclose (file);

   if( ! found ) {
      fprintf( stderr, "%s: unable to read noise parameters.\n", rpc_file );
      return 1;
   }

   return 0;
}


/*******************************************************************************************/
/*******************************************************************************************/

static char *get_sitenum( const char *str )
{
   static char site[12];
   const char *ptr;
   int i;

   /* find the first numeric digit in the string */
   for( ptr=str; *ptr; ++ptr ) {
      if( *ptr >= '0' && *ptr <= '9' ) break;
   }

   /* read up to four numeric digits from the string */
   for( i=0; *ptr && (i < 4); ++ptr, ++i ) {
      if( *ptr >= '0' && *ptr <= '9' ) site[i] = *ptr;
      else break;
   }

   /* terminate the string */
   site[i] = '\0';

   return site;
}



