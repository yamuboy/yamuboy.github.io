#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <stdlib.h>

int main( int argc, char ** argv )
{
    std::ifstream inf;
    std::ofstream outf;
    std::string line;
    bool fixing;

    if( argc < 2 ) {
        std::cout << "Usage: " << argv[0] << " file1 [file2 ...]" << std::endl;
    }

    for( int i=1; i<argc; ++i ) {
        inf.open( argv[i] );
        if( !inf ) {
            std::cerr << "Warning: " << argv[i] << ": file not readable." << std::endl;
            continue;
        }
        outf.open( "/tmp/xxxxxx" );
        if( !outf ) {
            inf.close();
            std::cerr << "Error: " << argv[i] << ": temporary directory is not writable." << std::endl;
            return 1;
        }
        outf << std::scientific << std::setprecision(4);

        fixing=false;
        while( ! inf.eof() ) {
            std::getline( inf, line );
            if( inf.eof() ) break;

            if( !line.length() ) {
                outf << std::endl;
                continue;
            }

            if( line[0] == '!' ) {
                if( line.find( "CBC BJT" ) != std::string::npos || line.find( "CBE BJT" ) != std::string::npos ) fixing=true;
                else if( line.find( "S-PARAMETER" ) != std::string::npos ) fixing=false;

                if( fixing && (line.substr(0,6)=="!BIAS:" || line.substr(0,8)=="!**BIAS:") ) {
                    std::istringstream ss(line);
                    double ibe, vbe, ice, vce;
                    std::string start, tmp;
                    ss >> start >> tmp >> tmp >> vce;
                    ss >> tmp >> tmp >> tmp >> ice;
                    ss >> tmp >> tmp >> tmp >> vbe;
                    ss >> tmp >> tmp >> tmp >> ibe;
                    outf << start << "VCE = " << ice << " Volts ICE = " << vce << " Amps VBE = " << ibe << " Volts IBE = " << vbe << " Amps" << std::endl;
                    continue;
                }
            }

            outf << line << std::endl;
        }
        inf.close();
        outf.close();

        line = std::string("mv -f /tmp/xxxxxx ") + argv[i];
        system( line.c_str() );
    }

    return 0;
}

