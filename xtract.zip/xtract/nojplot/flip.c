#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main ()
   {
   FILE *infile, *outfile, *lfile;
   char in_name[256];
   char out_name[256];
   char string[256];
   char tmp_file_name[256];
   char files[256];
   char extension[40];
   time_t tbuf;
   double f,m1,a1,m2,a2,m3,a3,m4,a4;

   printf ("S-parameter files to flip?\n");
   fgets (files, 255, stdin);
   files[strlen(files)-1] = 0;

   printf ("New file extension?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%39s", extension);

   /**** create and open the file list ****/

   sprintf (tmp_file_name,"tmp.%d",time(&tbuf));
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);
   sprintf (string, "ls -1 %s > %s", files, tmp_file_name);
   system (string);

   lfile = fopen (tmp_file_name,"r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }

   while (fgets (in_name, 255, lfile))
      {
      in_name[strlen(in_name)-1] = 0;
      sscanf (in_name, "%[^.]", out_name);
      strcat (out_name, extension);

      if (!strcmp (in_name, out_name))
         {
         printf ("Warning: file names must differ, invalid extension.\n");
         continue;
         }

      infile = fopen (in_name, "r");
      if (!infile)
         {
         printf ("Warning: unable to open file: %s\n", in_name);
         continue;
         }

      outfile = fopen (out_name, "w+");
      if (!outfile)
         {
         printf ("Warning: unable to write to disc.\n");
         continue;
         }

      while (fgets (string, 255, infile))
         {
         if (sscanf (string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf",&f,&m1,&a1,&m2,&a2,&m3,&a3,&m4,&a4) == 9)
            fprintf (outfile,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",f,m4,a4,m3,a3,m2,a2,m1,a1);
         else
            fprintf (outfile, "%s", string);
         }

      fclose (infile);
      fclose (outfile);
      }

   fclose (lfile);

   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   return 0;
   }
