#include <iostream>
#include <fstream>
#include "touchstone.hpp"
#include "shell_glob.hpp"
#include "file_utils.hpp"

static void deembed_data( NetworkParamSet& dut, const NetworkParamSet& in_fix, const NetworkParamSet& out_fix, bool embed_mode );

/******************************************************************************************/
/******************************************************************************************/

int main( int argc, char **argv )
{
   ShellWordExp file_list, we;
   bool ideal_input = false;
   bool ideal_output = false;
   bool equal_fixtures = false;
   bool embed_mode = false;
   std::string arg;
   Touchstone in_fix, out_fix, dut;
   std::ifstream is;
   std::ofstream os;
   std::string s_files, in_file, out_file, pattern, out_name;
   matrix::CMatrix ideal_t(2,2);

   ideal_t(0,0) = 1.;
   ideal_t(0,1) = 0.;
   ideal_t(1,0) = 0.;
   ideal_t(1,1) = 1.;

   /* parse command line options */
   arg = argv[0];
   if( arg == "cascade" || arg ==  "embed" ) embed_mode = true;

   if( embed_mode ) std::cout << "\nOperating mode: CASCADE\n\n";
   else std::cout << "\nOperating mode: DEEMBED\n\n";

   /* get user inputs */
   std::cout << "DUT S-parameter file name(s)?" << std::endl;
   std::getline( std::cin, s_files );

   std::cout << "Input fixture S-Parameter file (leave blank for none)?" << std::endl;
   std::getline( std::cin, in_file );

   std::cout << "Output fixture S-Parameter file (leave blank for none, \'.\' for the same as the input)?" << std::endl;
   std::getline( std::cin, out_file );

   std::cout << "Pattern for output files (leave blank for default = \'%(base).dm2\')?" << std::endl;
   std::getline( std::cin, pattern );

   // compute file names using shell word expansion
   file_list.exec( s_files.c_str() );
   if( ! file_list.num_words() ) {
       std::cerr << "Error: no files.\n";
       return 1;
   }

   // if the input fixture file contains shell special characters, do word expansion on it
   if( in_file == "" )
       ideal_input = true;
   else if( in_file.find_first_of( "$~`*?\'\"" ) != std::string::npos ) {
       we.exec( in_file.c_str() );
       if( we.num_words() != 1 ) {
           std::cerr << "Error: expansion of the input fixture expression yielded " << we.num_words() << " words.\n";
           return 1;
       }
       in_file = *we.begin();
   }

   // if the output fixture file is ".", use the input fixture file
   //  otherwise if it contains shell special characters, do word expansion on it
   if( out_file == "" )
       ideal_output = true;
   else if( out_file == "." ) equal_fixtures = true;
   else if( out_file.find_first_of( "$~`*?\'\"" ) != std::string::npos ) {
       we.exec( out_file.c_str() );
       if( we.num_words() != 1 ) {
           std::cerr << "Error: expansion of the output fixture expression yielded " << we.num_words() << " words.\n";
           return 1;
       }
       out_file = *we.begin();
   }

   // check for a pattern string, or set the default pattern
   if( ! pattern.length() ) pattern = "%(base).dm2";
   else if( file_list.num_words() > 1 && pattern.find( "%(" ) == std::string::npos ) {
       std::cerr << "Warning: more than 1 input file was specified." << std::endl;
       std::cerr << "Warning: the output file pattern does not appear to contain any replacement patterns." << std::endl;
       std::cout << "Do you wish to continue (y/N)?" << std::endl;
       std::getline( std::cin, arg );
       if( arg != "Y" && arg != "y" ) return 0;
   }

   // read in and convert fixture data
   try {
       if( ideal_input ) {
           in_fix.convert_to_t();
           in_fix.add( 0., ideal_t );
           in_fix.add( 100.e9, ideal_t );
           std::cout << "Input fixture: <none>" << std::endl;
       }
       else {
           in_fix.read( in_file );
           in_fix.convert_to_t();
           std::cout << "Input fixture: " << in_file << std::endl;
       }

       if( ideal_output ) {
           out_fix.convert_to_t();
           out_fix.add( 0., ideal_t );
           out_fix.add( 100.e9, ideal_t );
           std::cout << "Output fixture: <none>" << std::endl;
       }
       else if( equal_fixtures ) {
           out_fix = in_fix;
           std::cout << "Output fixture: " << in_file << std::endl;
       }
       else {
           out_fix.read( out_file );
           out_fix.convert_to_t();
           std::cout << "Output fixture: " << out_file << std::endl;
       }
   }
   catch( std::exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
   }

   std::cout << "working";
   std::cout.flush();

   for( ShellWordExp::iterator fname = file_list.begin(); fname != file_list.end(); ++fname ) {
        try {
           // create an output file name from the pattern
           out_name = filename_pattern_replace( *fname, pattern );

           // open the input file
           is.open( fname->c_str() );
           if( !is ) {
                is.close();
                std::cerr << std::endl << "Warning: " << *fname << ": file not readable.";
                continue;
           }

           // open the output file
           os.open( out_name.c_str() );
           if( ! os ) {
                os.close();
                is.close();
                std::cerr << std::endl << "Warning: " << out_name << ": file not writeable.";
                continue;
           }

           // loop for multiple S2P data sets in the file
           dut.clear();
           while( ! is.eof() ) {
               dut.read_stream( is, dut.get_linecount() );
               dut.convert_to_t();
               deembed_data( dut, in_fix, out_fix, embed_mode );
               dut.convert_to_s();
               os << dut;
               std::cout << ".";
               std::cout.flush();
           }
       }
       catch( std::exception& e ) {
           std::cerr << std::endl << "Warning: " << e.what();
       }
       is.close();
       os.close();
   }

   std::cout << std::endl;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static void deembed_data( NetworkParamSet& dut, const NetworkParamSet& in_fix, const NetworkParamSet& out_fix, bool embed_mode )
{
    matrix::CMatrix fxa, fxb, r;
    for( NetworkParamSet::iterator i = dut.begin(); i != dut.end(); ++i ) {
        fxa = in_fix.extract( i->freq() );
        fxb = out_fix.extract( i->freq() );
        if( embed_mode ) r = matrix::dot_product( matrix::dot_product(fxa,*i), fxb );
        else r = matrix::dot_product( matrix::dot_product(matrix::invert(fxa),*i), matrix::invert(fxb) );;
        *i = r;
    }
}
