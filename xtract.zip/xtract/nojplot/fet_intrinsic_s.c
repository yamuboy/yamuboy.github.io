#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "touchstone.h"
#include "cmplxlib.h"
#include "fit_tools.h"

struct fet_extrinsics
{
   double rg, rd, rs, lg, ld, ls, cpg, cpd, c11, c22;
};

static int read_extrinsic_parameters( const char* fname, struct fet_extrinsics * p );
static void remove_fet_extrinsics( struct fet_extrinsics p, NetworkParams* data );

/*---------------------------------------------------------------------------*/
int main( int argc, char** argv )
{
   char files[256];
   char str[256];
   char endfile[256];
   char ext[16];
   const char **listing;
   struct fet_extrinsics p;
   int i, e;
   Touchstone *touch;
   NetworkParams *data;

   printf( "[S] parameter files?\n" );
   fgets( files, 255, stdin );
   files[strlen(files)-1]='\0';

   printf( "Extrinsic parameters file (.end file)?\n" );
   fgets( str, 255, stdin );
   sscanf( str, "%255s", endfile );

   printf( "Extension for output files?\n" );
   fgets( str, 255, stdin );
   sscanf( str, "%15s", ext );

   // read .end file
   if( read_extrinsic_parameters( endfile, &p ) ) {
      fprintf( stderr, "Failed to read file: %s\n", endfile );
      return -1;
   }

   // read file listing
   listing = get_file_listing( files );
   if( !listing ) {
      fprintf( stderr, "No files found!\n" );
      return -1;
   }

   // iterate through all of the files
   for( i=0; listing[i]; ++i )
   {
      // generate the output file name
      strcpy( str, listing[i] );
      strip_extension( str );
      strcat( str, ext );

      // read the file
      e = read_touchstone_file( listing[i], &touch, &data );
      if( e ) {
         fprintf( stderr, "Warning: read of file %s failed.\n", listing[i] );
         free_touchstone_file_data( touch );
         free_network_parameter_data( data );
         continue;
      }
      else if( data->n_ports != 2 ) {
         fprintf( stderr, "Warning: file %s is not S2P data.\n", listing[i] );
         free_touchstone_file_data( touch );
         free_network_parameter_data( data );
         continue;
      }

      // remove the extrinsics from the S2P data
      remove_fet_extrinsics( p, data ); 

      // write the modified data
      touch->num_format = FP_scientific;
      touch->precision = 5;
      e = write_touchstone_file( str, touch, data );
      if( e ) {
         fprintf( stderr, "Warning: write of file %s failed.\n", str );
      }

      free_touchstone_file_data( touch );
      free_network_parameter_data( data );
   }

   free_file_listing( listing );

   return 0;
}
/*---------------------------------------------------------------------------*/
static int read_extrinsic_parameters( const char* fname, struct fet_extrinsics * p )
{
   MODEL_PARAMS *parms;
   OPT_PARAMETER op;

   if( read_model_parameters_from_file( fname, &parms, NULL ) )
      return -1;

   p->rg = p->rd = p->rs = 1.e-4;
   p->lg = p->ld = p->ls = 0.;
   p->cpg = p->cpd = p->c11 = p->c22 = 0.;

   if( !get_parameter_value("rg",parms,&op) ) p->rg = op.nom; else printf( "Warning: rg not found\n" );
   if( !get_parameter_value("rd",parms,&op) ) p->rd = op.nom; else printf( "Warning: rd not found\n" );
   if( !get_parameter_value("rs",parms,&op) ) p->rs = op.nom; else printf( "Warning: rs not found\n" );
   if( !get_parameter_value("b1",parms,&op) ) p->lg = op.nom; else printf( "Warning: lg not found\n" );
   if( !get_parameter_value("b2",parms,&op) ) p->ld = op.nom; else printf( "Warning: ld not found\n" );
   if( !get_parameter_value("ls",parms,&op) ) p->ls = op.nom; else printf( "Warning: ls not found\n" );
   if( !get_parameter_value("c1",parms,&op) ) p->cpg = op.nom; else printf( "Warning: cpg not found\n" );
   if( !get_parameter_value("c2",parms,&op) ) p->cpd = op.nom; else printf( "Warning: cpd not found\n" );
   if( !get_parameter_value("c11",parms,&op) ) p->c11 = op.nom; else printf( "Warning: c11 not found\n" );
   if( !get_parameter_value("c22",parms,&op) ) p->c22 = op.nom; else printf( "Warning: c22 not found\n" );

   free_model_parameters( parms );
   return 0;
}
/*---------------------------------------------------------------------------*/
static void remove_fet_extrinsics( struct fet_extrinsics p, NetworkParams* data )
{
   int i;
   double w;
   COMPLEX z[4], y[4], t;
   const double z0 = 50.;

   for( i=0; i<data->n_freqs; ++i )
   {
      w = 2. * M_PI * data->frequency[i];
      // convert [S] to [Y] and remove CPG (C1) and CPD (C2)
      s2y( (COMPLEX*)data->data[i], y, z0 );
      y[0] = Csub( y[0], Cnum(0.,w*p.cpg) );
      y[3] = Csub( y[3], Cnum(0.,w*p.cpd) );

      // convert [Y] to [Z] and remove LG and LD
      y2z( y, z );
      z[0] = Csub( z[0], Cnum(0.,w*p.lg) );
      z[3] = Csub( z[3], Cnum(0.,w*p.ld) );

      // convert [Z] to [Y] and remove C11 and C22
      z2y( z, y );
      y[0] = Csub( y[0], Cnum(0.,w*p.c11) );
      y[3] = Csub( y[3], Cnum(0.,w*p.c22) );

      // convert [Y] to [Z] and remove RG, RD, RS, and LS
      y2z( y, z );
      t = Cnum( p.rs, w*p.ls );
      z[0] = Csub( z[0], Cadd( t, Cnum(p.rg,0.) ) );
      z[1] = Csub( z[1], t );
      z[2] = Csub( z[2], t );
      z[3] = Csub( z[3], Cadd( t, Cnum(p.rd,0.) ) );

      // convert [Z] to [S] and store
      z2s( z, (COMPLEX*)data->data[i], z0 );
   }
}

