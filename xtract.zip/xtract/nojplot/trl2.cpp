#include <iostream>
#include <sstream>
#include <string>
#include "touchstone.hpp"
#include "user_input.hpp"

struct DelayLineData {
   std::string fname;
   double flist[2];
   Touchstone data;
};

static void compute_min_and_max_freq( const double * freqs, const NetworkParamSet& thru, DelayLineData& delay_dat );
static void verify_bottom_frequency( const double * flist, DelayLineData* delays, const int nlines );
static bool compute_fixtures( const double* freqs, const NetworkParamSet& thru, const NetworkParamSet& refl, const DelayLineData *delays, const int nlines,
                            const double& refl_val, bool refl_is_open, NetworkParamSet& fxa, NetworkParamSet& fxb );
static void compute_fxa_fxb( const NetworkParamSet::DataT& tt, const NetworkParamSet::DataT& td, const NetworkParamSet::DataT& reflect,
                            const double& refl_val, bool refl_is_open, const std::complex<double>& z0, const double& freq, const std::string& delay_name,
                            NetworkParamSet::DataT& fxa, NetworkParamSet::DataT& fxb );
static void correct_phase( NetworkParamSet& data, const std::string& fixture_name );

/**********************************************************************************************************************************/
/**********************************************************************************************************************************/

int main( int argc, char **argv )
{
   // read in user input
   std::string thru_name, refl_name, fxa_name, fxb_name, refl_type_str;
   double refl_val;
   double flist[3];
   int nlines;
   Touchstone thru, refl;
   NetworkParamSet fxa, fxb;
   UserInput ui;
   DelayLineData *delay_lines;
   std::ostringstream sstr;
   bool err;
   bool refl_is_open = false;
   const char *refl_q;

   // read input from stdin
   if( !ui.get( "Thru data file name?", thru_name ) ||
      !ui.get( "Reflect data file name?", refl_name ) ||
      !ui.get( "Reflect type, open (o) or short (s)?", refl_type_str ) )
   {
      std::cerr << std::endl << "Error reading input: " << ui.errmsg() << std::endl;
      return 1;
   }

   if( refl_type_str.length() && (refl_type_str.at(0) == 'o' || refl_type_str.at(0) == 'O') )
      refl_is_open = true;

   refl_q = refl_is_open ? "Capacitance of open (fF)?" : "Inductance of short (pH)?";

   if( !ui.get( refl_q, refl_val ) ||
      !ui.get( "FXA output file name?", fxa_name ) ||
      !ui.get( "FXB output file name?", fxb_name ) ||
      !ui.get( "Frequency list for output in GHz (start stop step)?", flist, 3 ) ||
      !ui.get( "Number of delay lines?", nlines )
      )
   {
      std::cerr << std::endl << "Error reading input: " << ui.errmsg() << std::endl;
      return 1;
   }

   if( nlines < 1 )
   {
      std::cerr << "Error: there must be at least 1 delay line." << std::endl;
      return 1;
   }

   delay_lines = new DelayLineData [nlines];

   // scale data
   refl_val *= refl_is_open ? 1.e-15 : 1.e-12;
   flist[0] *= 1.e9;
   flist[1] *= 1.e9;
   flist[2] *= 1.e9;

   err = false;

   // read in delay line data
   for( int i=0; i<nlines; i++ ) {
      sstr.str("");
      sstr << "Delay " << i+1 << " data file name?";
      if( !ui.get( sstr.str().c_str(), delay_lines[i].fname ) )
      {
         std::cerr << std::endl << "Error reading input: " << ui.errmsg() << std::endl;
         err = true;
         break;
      }
   }

   // error checking
   if( err ) {
       delete [] delay_lines;
       return 1;
   }

   try {
       // read in thru data and convert to [T] parameters
       thru.read(thru_name);
       thru.convert_to_t();

       // read in reflect data
       refl.read(refl_name);
       if( refl.ports() != 2 ) {
          std::cerr << "Error: " << refl_name << ": not 2-port data." << std::endl;
          err = true;
       }

       // read in delay line data and convert to [T] parameters
       std::cout << "Line\t\tMin Freq\t\tMax Freq" << std::endl;
       std::cout << "-------------------------------------------------------------------------------" << std::endl;
       for( int i=0; i<nlines; i++ ) {
          delay_lines[i].data.read(delay_lines[i].fname);
          delay_lines[i].data.convert_to_t();

          // compute min and max usable frequency
          compute_min_and_max_freq( flist, thru, delay_lines[i] );
          std::cout << delay_lines[i].fname << "\t" << delay_lines[i].flist[0]*1.e-9 << "\t" << delay_lines[i].flist[1]*1.e-9 << std::endl;
       }

       // error checking
       if( err ) {
           delete [] delay_lines;
           return 1;
       }
       // verify that the bottom of the frequency range is covered
       //  this function will adjust the bottom frequency of the longest delay line
       //  if the bottom end of the frequency range is not covered
       //  it will also print a warning message
       verify_bottom_frequency( flist, delay_lines, nlines );

       // compute fixtures
       std::cout << "Computing fixtures..." << std::endl;
       if( !compute_fixtures( flist, thru, refl, delay_lines, nlines, refl_val, refl_is_open, fxa, fxb ) ) {
          return 1;
       }

       // correct the phase
       correct_phase( fxa, "FXA" );
       correct_phase( fxb, "FXB" );

       // write files
       //  use the format data from the thru file
       thru = fxa;
       thru.set_fp_mode( Touchstone::FPscientific );
       thru.set_fp_precision( 5 );
       thru.write(fxa_name);
       thru = fxb;
       thru.write(fxb_name);
    }
    catch( NetworkParametersError& e ) {
        std::cerr << "NetworkParametersError Exception: " << e.what() << std::endl;
        delete [] delay_lines;
        return 1;
    }
    catch( std::exception& e ) {
        std::cerr << "Exception: " << e.what() << std::endl;
        delete [] delay_lines;
        return 1;
    }

   delete [] delay_lines;

   std::cout << "Done." << std::endl << std::endl;
   return 0;
}

/**********************************************************************************************************************************/
/**********************************************************************************************************************************/

static void compute_min_and_max_freq( const double * freqs, const NetworkParamSet& thru, DelayLineData& delay_dat )
{
   NetworkParamSet::DataT tt, td, tti, tdt;
   double f, ph;
   double minf = -1.;
   double lastf = -1.;

   for( f=freqs[0]; f<=freqs[1]; lastf=f, f+=freqs[2] ) {
      tt = thru.extract( f );
      td = delay_dat.data.extract( f );

      // calculate td * tt(inv)
      tti = matrix::invert( tt );
      tdt = matrix::dot_product(td, tti);

      // compute the insertion phase
      ph = arg( 1. / tdt(1,1) );

      if( f == freqs[0] && (ph > 0. || ph < -M_PI*8./9.) ) {
         // this delay data is useless
         //  the line is too long for the minimum requested frequency
         delay_dat.flist[0] = delay_dat.flist[1] = -1.;
         return;
      }

      if( ph < 0. && ph > -M_PI/9. )
         continue;   // haven't reached a usable frequency yet
      else if( ph > 0. || ph < -M_PI*8./9. ) {
         if( minf > 0. && lastf > 0. ) {
            delay_dat.flist[0] = minf;
            delay_dat.flist[1] = lastf;
         }
         else {
            // no useable data for this delay line
            delay_dat.flist[0] = delay_dat.flist[1] = -1.;
         }
         return;
      }

      // must have reached a usable frequency
      if( minf < 0. ) {
         minf = f;
      }
   }

   if( minf > 0. ) {
      delay_dat.flist[0] = minf;
      delay_dat.flist[1] = freqs[1];
   }
}

/**********************************************************************************************************************************/
/**********************************************************************************************************************************/

static void verify_bottom_frequency( const double * flist, DelayLineData* delays, const int nlines )
{
   int i;
   double minf = delays[0].flist[0];
   int n = 0;

   for( i=1; i<nlines; ++i ) {
      if( delays[i].flist[0] < minf ) {
         n = i;
         minf = delays[i].flist[0];
      }
   }

   if( flist[0] < minf ) {
      delays[n].flist[0] = flist[0];
      std::cout << std::endl << "WARNING: No delay lines cover the bottom end of the requested frequency list." << std::endl;
      std::cout << "WARNING: The minimum frequency of delay line \"" << delays[n].fname << "\" has been" << std::endl;
      std::cout << "WARNING: adjusted to cover the band. The minimum usable frequency of this delay line was" << std::endl;
      std::cout << "WARNING: " << minf * 1.e-9 << " GHz before the adjustment. This adjustment may result in a" << std::endl;
      std::cout << "WARNING: loss in accuracy at frequencies below that value." << std::endl << std::endl;
   }
}

/**********************************************************************************************************************************/
/**********************************************************************************************************************************/
static bool compute_fixtures( const double* freqs, const NetworkParamSet& thru, const NetworkParamSet& refl, const DelayLineData *delays, const int nlines,
                            const double& refl_val, bool refl_is_open, NetworkParamSet& fxa, NetworkParamSet& fxb )
{
   NetworkParamSet::DataT mt, md, mr;
   NetworkParamSet::DataT mi(2,2), mo(2,2), ti(2,2), to(2,2);
   NetworkParamSet::DataT::StorageT z0(50.);
   double f;
   int d_count;

   for( f=freqs[0]; f<=freqs[1]; f+=freqs[2] )
   {
      d_count = 0;

      // extract thru and reflect data from the dataset
      mt = thru.extract( f );
      mr = refl.extract( f );

      // for each delay line that covers the frequency
      //  extract delay data, compute the fixture and average it
      //  with other data points
      ti = NetworkParamSet::DataT::StorageT(0.);
      to = NetworkParamSet::DataT::StorageT(0.);
      for( int i=0; i<nlines; ++i ) {
         if( f >= delays[i].flist[0] && f <= delays[i].flist[1] )
         {
            md = delays[i].data.extract( f );
            // extract this frequency point
            compute_fxa_fxb( mt, md, mr, refl_val, refl_is_open, z0, f, delays[i].fname, mi, mo );

            // prepare to compute averaging
            //  ~180 phase shift is possible
            //  so need to check but only if there has already been a calculation at this frequency
            if( d_count ) {
               if( fabs(std::arg(ti(0,1)/mi(0,1))) > 0.5*M_PI ) {
                  mi(0,1) *= -1.;
                  mi(1,0) *= -1.;
               }
               if( fabs(std::arg(to(0,1)/mo(0,1))) > 0.5*M_PI ) {
                  mo(0,1) *= -1.;
                  mo(1,0) *= -1.;
               }
            }

            ti += mi;
            to += mo;
            ++d_count;
         }
      }

      // check that at least one delay line covered the frequency
      if( !d_count ) {
         std::cerr << "Error: no delay lines cover " << f * 1.e-9 << " GHz." << std::endl;
         return false;
      }

      // compute averaging
      if( d_count > 1 ) {
         ti /= NetworkParamSet::DataT::StorageT(d_count);
         to /= NetworkParamSet::DataT::StorageT(d_count);
      }

      // add the data to fxa and fxb
      fxa.add( f, ti );
      fxb.add( f, to );
   }

   return true;
}

/**********************************************************************************************************************************/
/**********************************************************************************************************************************/

static void compute_fxa_fxb( const NetworkParamSet::DataT& tt, const NetworkParamSet::DataT& td, const NetworkParamSet::DataT& reflect,
                            const double& refl_val, bool refl_is_open, const std::complex<double>& z0, const double& freq, const std::string& delay_name,
                            NetworkParamSet::DataT& fxa, NetworkParamSet::DataT& fxb )
{
   NetworkParamSet::DataT tti, tdt;
   NetworkParamSet::DataT::StorageT v1, v2, s1, s2;
   NetworkParamSet::DataT::StorageT t12a_t22a, t21a_t11a, t21b_t22b, t12b_t11b;
   NetworkParamSet::DataT::StorageT t11a_t22a, refl_gamma, t11b_t22b;
   double s1m, s2m;

   // calculate td * tt(inv)
   tti = matrix::invert( tt );
   tdt = matrix::dot_product(td, tti);

   // calculate parameters
   v1 = tdt(1,1) - tdt(0,0);
   v2 = -v1;
   v1 = sqrt( v1*v1 + 4.0*tdt(0,1)*tdt(1,0) );
   s1 = s2 = 0.5 / tdt(1,0);
   s1 *= v2 + v1;
   s2 *= v2 - v1;

   s1m = abs( s1 );
   s2m = abs( s2 );
   t12a_t22a = ( s1m < s2m ) ? s1 : s2;
   t21a_t11a = ( s1m < s2m ) ? 1. / s2 : 1. / s1;

   t21b_t22b = ( tt(1,0)-tt(0,0)*t21a_t11a ) / ( tt(1,1)-tt(0,1)*t21a_t11a );
   t12b_t11b = ( tt(0,1)-tt(1,1)*t12a_t22a ) / ( tt(0,0)-tt(1,0)*t12a_t22a );



   t11a_t22a = v1 = reflect(0,0) - t12a_t22a;
   t11a_t22a *= 1. + reflect(1,1)*t12b_t11b;
   t11a_t22a *= tt(0,0)-tt(1,0)*t12a_t22a;
   t11a_t22a /= v2 = 1. - reflect(0,0)*t21a_t11a;
   t11a_t22a /= reflect(1,1)+t21b_t22b;
   t11a_t22a /= tt(1,1)-tt(0,1)*t21a_t11a;
   t11a_t22a = sqrt( t11a_t22a );

   // correct for phase (because of sqrt(), 180 degree phase shift is possible)
   //  start by calculating the approximate reflection coeff of the reflect termination
   if( refl_is_open ) {
      NetworkParamSet::DataT::StorageT refl_y(0.,2.*M_PI*freq*refl_val);
      refl_gamma = (1. - refl_y*z0) / (1. + refl_y*z0);
   }
   else {
      NetworkParamSet::DataT::StorageT refl_z(0.,2.*M_PI*freq*refl_val);
      refl_gamma = (refl_z - z0) / (refl_z + z0);
   }
   // the calculation here compares the t11a_t22a value calculated above with a value calculated
   //  via the equation: (reflect(0,0) - t21a_t22a) / (refl_gamma * (1 - reflect(0,0)*t21a_t11a))
   //  the quotient of the 2 values is taken such that the phases are subtracted
   //  if the phase differs by more than +/- 90 degrees, then the sign of t11a_t22a is flipped
   t11a_t22a = (std::abs( std::arg( refl_gamma*t11a_t22a*v2/v1 ) ) > 0.5*M_PI) ? -t11a_t22a : t11a_t22a;

   t11b_t22b = tt(0,0) - tt(1,0)*t12a_t22a;
   t11b_t22b /= tt(1,1) - tt(0,1)*t21a_t11a;
   t11b_t22b /= t11a_t22a;

   // calculate and load the input error box
   fxa(0,0) = t12a_t22a;
   fxa(1,1) = -t11a_t22a * t21a_t11a;
   //fxa(0,1) = std::sqrt( t11a_t22a*(1. - t12a_t22a*t21a_t11a) );
   fxa(0,1) = std::sqrt( t11a_t22a + fxa(0,0)*fxa(1,1) );
   fxa(1,0) = fxa(0,1);

   // calculate and load the output error box
   fxb(0,0) = t12b_t11b*t11b_t22b;
   fxb(1,1) = -t21b_t22b;
   //fxb(0,1) = std::sqrt( (tt(0,0)-tt(1,0)*t21a_t11a*t11a_t22a) / (tt(1,1)*t11a_t22a-tt(0,1)*t12a_t22a) + fxb(0,0)*fxb(1,1) );
   fxb(0,1) = std::sqrt( t11b_t22b + fxb(0,0)*fxb(1,1) );
   fxb(1,0) = fxb(0,1);
}

/*****************************************************************************/

static void correct_phase( NetworkParamSet& data, const std::string& fixture_name )
{
   double *phasev = new double [data.size()];
   double a1, a2;
   int n=0;
   NetworkParamSet::iterator i1, i2;
   double expect, actual;
   double av, err;
   NetworkParamSet::DataT::StorageT j( 0., 1. );

   // calculate the phase velocity bewteen adjacent points
   i1 = data.begin();
   i2 = data.begin();
   ++i2;
   for( ; i2 != data.end(); ++i1, ++i2 )
   {
      a1 = arg( (*i1)(0,1) );
      if( a1 < 0. ) a1 += 2. * M_PI;
      a2 = arg( (*i2)(0,1) );
      if( a2 < 0. ) a2 += 2. * M_PI;

      if( a1 > a2 ) {
         // this should always be the case,
         //  so when it is not it is due to a phase shift
         //  in the fixture
         phasev[n] = (a2 - a1) / ( i2->freq() - i1->freq() );
         n++;
      }
   }

   // sort the calculated phase velocities
   for( int i=0; i<n-1; i++ )
   {
      for( int j=i+1; j<n; j++ )
      {
         if( phasev[j] < phasev[i] )
         {
            a1 = phasev[j];
            phasev[j] = phasev[i];
            phasev[i] = a1;
         }
      }
   }

   // take the median value
   av = phasev[n/2];
   delete [] phasev;

   std::cout << fixture_name << ": approximate free space electrical length: " << fabs(av) * 3.0e10 / (2.*M_PI) << " cm." << std::endl;

   // correct the phase
   for( i1 = data.begin(); i1!=data.end(); ++i1 )
   {
      // calculate expected and actual phase
      //  modify both so that they fall into the
      //  range of [0, 360) degrees
      expect = fmod(av*i1->freq(),2.*M_PI);
      if( expect < 0. ) expect += 2.*M_PI;
      actual = arg((*i1)(0,1));
      if( actual < 0. ) actual += 2.*M_PI;
      // error between the expected and actual
      err = fabs(actual - expect);

      if( err > 0.25 * M_PI && err < 1.75 * M_PI )
      {
         // phase needs to be corrected
         //  error is greater than 45 degrees
         if( err > 0.75 * M_PI && err < 1.25 * M_PI ) {
            // correct by 180 degrees
            (*i1)(0,1) *= -1.;
            (*i1)(1,0) *= -1.;
         }
         else if( err < M_PI ) {
            // phases are within 180 degrees of each other,
            //  determine which way to go by whether
            //  the expected or actual value is greater
            if( expect > actual ) {
               // correct by positive 90 degrees
               (*i1)(0,1) *= j;
               (*i1)(1,0) *= j;
            }
            else {
               // correct by negative 90 degrees
               (*i1)(0,1) *= -j;
               (*i1)(1,0) *= -j;
            }
         }
         else {
            // err > M_PI
            //  phases are on opposite ends of the range [0,360)
            if( expect > actual ) {
               // correct by negative 90 degrees
               (*i1)(0,1) *= -j;
               (*i1)(1,0) *= -j;
            }
            else {
               // correct by positive 90 degrees
               (*i1)(0,1) *= j;
               (*i1)(1,0) *= j;
            }
         }
      }
   }
}


