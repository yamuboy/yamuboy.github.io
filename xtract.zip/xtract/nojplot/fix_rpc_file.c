#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _list_struct
{
double vds;
double vgs;
int line;
struct _list_struct *next;
} SORTING_STRUCT;

int main ()
{
char     string[256];
FILE     *in_file,*out_file;
char     file_name[81],temp_file_name[81];
char     all_lines[2000][256];
double   last_vds;
int      line,line_num,i;
int      header_done,no_changes;
time_t   current_t;
int      error = 0;
SORTING_STRUCT sorting_struct[2000];
SORTING_STRUCT *last_ptr,*list_ptr,*list_ptr2,*begin_sort;

printf ("\nThis program will sort data in \".rpc\" noise files.\n");
printf ("Sorting order is VDS, VGS.  Blank lines are placed between\n");
printf ("each VDS.\n\n");

printf ("Filename of noise data > ");
scanf ("%s",file_name);

sprintf (temp_file_name,"temp_file_%ld",time (&current_t));
system (string);

in_file = (FILE *) NULL;
in_file = fopen (file_name,"r");
if (in_file == (FILE *) NULL)
   {
   printf ("** ERROR ** could not open file named %s\n",file_name);
   exit (-1);
   }
   
out_file = fopen (temp_file_name,"w+");

line = 1;
header_done = 0;
line_num = 0;
while (fgets (string,255,in_file) != NULL)
   {
   if (!header_done)
      {
      if (string[0] == '!')
         {
         fprintf (out_file,"%s",string);
         }
      else
         {
         header_done = 1;
         }
      }
      
   if (header_done)
      {
      for (i = 0; i < 130; ++i)
         {
         if (string[i] == '\0')
            {
            printf ("** warning ** blank, misformed, or incomplete data found @ line %d\n",line);
            error = 1;
            break;
            }
         }
      
      if (!error)
         {
         strcpy (all_lines[line_num],string);
         sscanf (&string[45],"%lf",&sorting_struct[line_num].vds);
         sscanf (&string[71],"%lf",&sorting_struct[line_num].vgs);
         sorting_struct[line_num].line = line_num;
               
         ++line_num;    
         }
      else
         {
         error = 0;
         continue;
         }
         
      if (line_num >= 2000)
         {
         printf ("** error ** file has more than 2000 lines of data\n");
         exit (-1);
         }
      }

   ++line;
   }

fclose (in_file);

/* set up a linked list */
begin_sort = &sorting_struct[0];
sorting_struct[0].next = NULL;
for (i = 1; i < line_num; ++i)
   {
   sorting_struct[i-1].next = &sorting_struct[i];
   sorting_struct[i].next = NULL;
   }
   
/* sorting algorithm */
for (i = 0; i < line_num; ++i)
   {
   no_changes = 1;
   
   list_ptr = begin_sort;
   while (list_ptr->next != NULL)
      {
      list_ptr2 = list_ptr->next;
      if ((list_ptr->vds > list_ptr2->vds) ||
            ((list_ptr->vds == list_ptr2->vds) && (list_ptr->vgs > list_ptr2->vgs)))
         {
         no_changes = 0;
         
         list_ptr->next = list_ptr2->next;
         list_ptr2->next = list_ptr;
         
         if (begin_sort == list_ptr)
            {
            begin_sort = list_ptr2;
            }
         else
            {
            last_ptr->next = list_ptr2;
            }
         
         /* swapped - now increment to next */
         last_ptr = list_ptr2;
         list_ptr2 = list_ptr->next;

         }
      else
         {
         last_ptr = list_ptr;
         list_ptr = list_ptr2;
         list_ptr2 = list_ptr2->next;
         }
      }
    
   if (no_changes)
      {
      break;
      }
   }

list_ptr = begin_sort;
last_vds = list_ptr->vds;
while (list_ptr != NULL)
   {
   if (list_ptr->vds != last_vds)
      {
      fprintf (out_file,"\n%s",all_lines[list_ptr->line]);
      last_vds = list_ptr->vds;
      }
   else
      {
      fprintf (out_file,"%s",all_lines[list_ptr->line]);
      }
   list_ptr = list_ptr->next;
   }

fclose (out_file);

sprintf (string,"mv %s %s",temp_file_name,file_name);
system (string);
}
