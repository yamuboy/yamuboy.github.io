#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define DEG2RAD    0.01745329252

main ()
{
char    string[200],s_file_name[100],rpc_file_name[100],out_file_name[100];
FILE    *sfile,*rpcfile,*outfile;
double  freq,nfmin,gamma_m,gamma_a,rn;
int     found;

printf ("[S] filename?\n> ");
fgets (string,199,stdin);
sscanf (string,"%99s",s_file_name);

printf ("RPC filename?\n> ");
fgets (string,199,stdin);
sscanf (string,"%99s",rpc_file_name);

printf ("Output filename?\n> ");
fgets (string,199,stdin);
sscanf (string,"%99s",out_file_name);

sfile = fopen (s_file_name,"r");
if (!sfile)
   {
   printf ("\n** could not open %s ** \n\n",s_file_name);
   return -1;
   }

rpcfile = fopen (rpc_file_name,"r");
if (!rpcfile)
   {
   printf ("\n** could not open %s ** \n\n",rpc_file_name);
   fclose (sfile);
   return -1;
   }
   
outfile = fopen (out_file_name,"w+");

while (fgets (string,199,sfile))
   {
   if (string[0] == '\n')
      continue;
   fprintf (outfile,"%s",string);
   }
fclose (sfile);

fprintf (outfile,"!           NOISE PARAMETERS\n");
fprintf (outfile,"!   Freq     Nf_Min    Gamma_Opt     Rn\n");
fprintf (outfile,"!   (Hz)      (dB)   (mag) (angle) (ohms)\n");

found = 0;
while (fgets (string,199,rpcfile))
   {
   if (!strncmp(string,"!BIAS",5))
      found = 1;
      
   if (string[0] == '!')
      continue;

   if (found)
      {
      if (sscanf (string,"%lf%lf%lf%lf%lf",&freq,&nfmin,&gamma_m,&gamma_a,&rn) == 5)
         {
         freq *= 1.0e9;
         fprintf (outfile,"%12.5e %6.3f %6.3f %7.2f %6.3f\n",freq,nfmin,gamma_m,gamma_a,rn);
         }
      }
   }
fclose (rpcfile);
fclose (outfile);

return 0;
}
