#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#define MAX_FILES   (500)

void print_usage( char* progname );
int get_xy_site( char* fname, int *x, int *y );
void split_line( char *str, char** data, int *sz, int maxsz );
void free_line( char** data, int sz );


int main (int argc, char *argv[])
{
   FILE *outfile;
   FILE *infile;
   char out_name[256];
   char str[256];
   int x, y;
   int i;
   char* file_list[MAX_FILES];
   int n_files = 0;
   int header_done = 0;
   int dev = 0;
   double periph = 0.;
   int sites = 0;
   int have_ron = 0;
   int have_mamm = 0;

   strcpy( out_name, "summary.dc" );

   if( argc < 2 ) {
      print_usage(argv[0]);
      exit(0);
   }

   // parse the command line 
   for( i=1; i<argc; ++i ) {
      if( argv[i][0] == '-' ) {
         if( !strcmp(argv[i], "-o") || strcmp(argv[i], "-out") ) {
            if( i == argc-1 ) {
               fprintf( stderr, "Error: missing argument for \'-o\'.\n" );
               print_usage(argv[0]);
               exit(1);
            }
            strcpy( out_name, argv[++i] );
         }
         else {
            fprintf( stderr, "Error: unrecognized command line argument \'%s\'.\n", argv[i] );
            print_usage(argv[0]);
            exit(1);
         }
      }
      else {
         if( n_files >= MAX_FILES ) {
            fprintf( stderr, "Warning: MAX_FILES exceeded.\n" );
            break;
         }

         file_list[n_files++] = argv[i];
      }
   }

   if( !n_files ) {
      fprintf( stderr, "Error: no files to summarize.\n" );
      print_usage(argv[0]);
      exit(1);
   }

   outfile = fopen( out_name, "w+" );
   if( ! outfile ) {
      fprintf( stderr, "Error: unable to open output file.\n" );
      exit(1);
   } 

   for( i=0; i<n_files; ++i ) {
      infile = fopen( file_list[i], "r" );
      if( ! infile ) {
         fprintf( stderr, "Warning: unable to open file \'%s\'.\n", file_list[i] );
         continue;
      }

      if( get_xy_site( file_list[i], &x, &y ) ) {
         fprintf( stderr, "Warning: could not determine site location for file \'%s\'.\n", file_list[i] );
         continue;
      }

      while( fgets(str,255,infile) ) {
         if( str[0] == '!' ) {
            if( !header_done ) {
               if( !strncmp(str,"!FILE ",6) ) continue;
               else if( !strncmp(str,"!Vbr",4) ) {
                  dev = 1;
                  header_done = 1;
                  if( strstr(str, "(1mA/mm)") ) have_mamm = 1;
                  if( strstr(str, "Ron") ) have_ron = 1;


                  fprintf( outfile,"! x\t y \t    Vbr    \t    Vbr    \t   Idss    \t    Vpo    \t   Imax    \t    Vpo    \t   Vmax    \t" );
                  if( have_mamm ) fprintf( outfile,"    Vpo    \t" );
                  if( have_ron ) fprintf( outfile,"    Ron    \t" );
                  fprintf( outfile,"   Idss    \t   Imax    \n" );
                  fprintf( outfile,"!  \t   \t(0.1mA/mm) \t (1mA/mm)  \t   (mA)    \t   (3V)    \t   (mA)    \t  (1.5V)   \t   (V)     \t" );
                  if( have_mamm ) fprintf( outfile," (1mA/mm)  \t" );
                  if( have_ron ) fprintf( outfile,"  (ohms)   \t" );
                  fprintf( outfile,"  (mA/mm)  \t  (mA/mm)  \n" );
                  continue;
               }
               else if( !strncmp(str,"!Vb_beo",7) ) {
                  dev = 2;
                  header_done = 1;
                  fprintf( outfile,"! x   y  %s", &str[1] );
                  continue;
               }
               else fprintf( outfile, "%s", str );
            }

            if( !strncmp(str,"!GATE PERIPHERY (um):",21) ) {
               sscanf( &str[21], "%lf", &periph );
            }
            else if( !strncmp(str,"!EMITTER AREA (um^2):",21) ) {
               sscanf( &str[21], "%lf", &periph );
            }
         }
         else {
            // this must be the data line
            //  since it doesn't start with a '!'
            if( ! dev ) {
               fprintf( stderr, "Warning: file \'%s\' device type not known yet.\n", file_list[i] );
            }
            else if( dev == 2 ) {
                  // HBT, no special handling of the line
                  fprintf( outfile, "%3d %3d %s", x, y, str );
                  ++sites;
            }
            else {
               // FET device
               if( periph == 0. ) {
                  fprintf( stderr, "Warning: file \'%s\' periphery not known yet.\n", file_list[i] );
               }
               else {
                  char* data[12];
                  int sz;
                  split_line( str, data, &sz, 12 );
                  if( sz > 6 ) {
                     double idss;
                     double imax;
                     sscanf( data[2], "%lf", &idss );
                     sscanf( data[4], "%lf", &imax );
                     if( ( have_mamm && sz < 8 ) || ( have_ron && sz < 9 ) ) {
                        // yikes, this should never happen!!!
                        fprintf( stderr, "Error: file \'%s\' is corrupted.\n", file_list[i] );
                        exit(1);
                     }

                     fprintf( outfile,"%d\t%d\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t", x, y, data[0], data[1], data[2], data[3], data[4], data[5], data[6] );
                     if( have_mamm ) fprintf( outfile,"%s\t", data[7] );
                     if( have_ron ) fprintf( outfile,"%s\t", data[8] );
                     fprintf( outfile, "%+.4e\t%+.4e\n", idss * 1000. / periph, imax * 1000. / periph );
                     ++sites;
                  }
                  free_line( data, sz );
               }
            }
            break;
         }
      }

      fclose( infile );
   }

   // done
   fclose( outfile );

   printf( "\n\nNumber of sites: %d\n\n", sites );

   // attempt to insert the data into the database
   if( dev == 1 ) {
      char *home = getenv("HOME");
      if( ! home ) {
         fprintf( stderr, "Warning: database insert impossible. HOME is not set.\n" );
      }
      else {
         sprintf( str, "%s/bin/fet_db_insert %s", home, out_name );
         system( str );
      }
   }

   return 0;
}

void print_usage( char* progname )
{
   printf( "\n" );
   printf( "USAGE: %s file1 file2 ... -o outname\n\n", progname );
   printf( "    file1, file2, etc are DC screening data files.\n\n" );
   printf( "    outname is the name for the output file.\n\n" );

   printf( "  This program will also attempt to dump the data\n" );
   printf( "  into the FET DC database if the device is a FET.\n" );

   printf( "\n" );
}

int get_xy_site( char* fname, int *x, int *y )
{
   int i;
   int j;
   
   // scan the filename looking for the first numeric digit
   for( i=0; i<strlen(fname); ++i ) {
      if( fname[i] >= '0' && fname[i] <= '9' ) break;
   }

   // failed - not enough characters left in the filename
   if( i > strlen(fname) - 4 ) return 1;

   // make sure that the next 3 characters are all numeric digits as well
   for( j=i+1; j<i+4; ++j ) {
      // failed - not a numeric digit
      if( fname[j] < '0' && fname[j] > '9' ) return 1;
   }

   // create the x and y values
   *x = (fname[i]-'0')*10 + fname[i+1] - '0';
   *y = (fname[i+2]-'0')*10 + fname[i+3] - '0';

   return 0;
}

void split_line( char *str, char** data, int *sz, int maxsz )
{
   *sz = 0;
   char *ptr;
   const char* sep = " \t\n\r";
   ptr = strtok( str, sep );
   while( ptr ) {
      data[*sz] = strdup( ptr );
      ++(*sz);
      ptr = strtok( NULL, sep );
   }
}

void free_line( char** data, int sz )
{
   int i;
   for( i=0; i<sz; ++i ) free((void*)data[i]);
}

