#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *index ();
int record_compare ();

main ()
{
char  buffer[1025];
char  file_names[80];
FILE  *tmp_file;
FILE  *ps_file;
int   n,flag;

printf ("Postscript files to summarize (must contain wildcard)?\n");
scanf ("%s",file_names);

sprintf (buffer,"cat %s > temp.dat",file_names);
system (buffer);

tmp_file = fopen ("temp.dat","r");
ps_file = fopen("plots.dat","w+");

n = 0;
flag = 0;
while (fgets (buffer,1024,tmp_file) != NULL)
{
   if (flag == 0)
      {
      if (strncmp (buffer,"%%Page:",7) == 0)
        {
        n = 1;
        flag = 1;
        }
      fprintf (ps_file,"%s",buffer);      
      continue;
      }
   if (flag == 1)
   {
   if (strncmp (buffer,"%%Page:",7) == 0)
      {
      n = n + 1;
      fprintf (ps_file,"%%%%Page: %d %d\n",n,n);
      }
   else if (strncmp (buffer,"%",1) == 0)
      {
      continue;
      }
   else if (strncmp (buffer,"/v",2) == 0)
      {
      continue;
      }
   else if (strncmp (buffer,"/t",2) == 0)
      {
      continue;
      }
   else
      {
      fprintf (ps_file,"%s",buffer);      
      }
   }
}
fprintf(ps_file,"%%%%Pages:   %d",n);
fclose (tmp_file);
fclose (ps_file);
system ("rm -f temp.dat");
printf(" Done! File plots.dat created!\n ");
printf("\n");
}
