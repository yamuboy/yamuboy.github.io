#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "cmplxlib.h"
#include "optimize4.h"
#include "fit_tools.h"

#define MAX_FREQS   500
#define MAX_FILES   5

typedef struct
   {
   double vgs,vds,igs,ids;
   } BIAS;

struct z11_data
   {
   COMPLEX *zgate;
   double *w;
   unsigned n;
   };

static int z11_erf (double *p, void *data, double *err, unsigned n);
static unsigned read_s_params (FILE *file, COMPLEX s[][4], double *freqs, unsigned max_f, BIAS *bias);

/***********************************************************************************/
/***********************************************************************************/

int main (int argc, char *argv[])
   {
   unsigned npts,i,j;
   unsigned n_files = 0;
   FILE *file;
   COMPLEX s[MAX_FREQS][4];
   COMPLEX z[4],y[4],zgate[MAX_FREQS];
   double freqs[MAX_FREQS];
   double wl[MAX_FREQS];
   double ls1[MAX_FREQS];
   double ld1[MAX_FREQS];
   BIAS bias;
   double igs[MAX_FILES];
   double Rg[MAX_FILES];
   double Rd[MAX_FILES];
   double Rs[MAX_FILES];
   double Lg[MAX_FILES];
   double Ld[MAX_FILES];
   double Ls[MAX_FILES];
   double Rgf,Rdf,Rsf,Lgf,Ldf,Lsf,c11,c22;
   double m,r_sq,min_freq,max_freq,r_freq;
   double w,rp,cp;
   char file_list[1024];
   char pinchoff_file[256];
   char out_file[256];
   char string[256];
   char *ptr,file_name[256];
   int r_done;
   OPTIMIZE *opt;
   OPT_PARAMETER p[4];
   struct z11_data z11_d;
   int do_cxx = 0;
   
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\n\nUSAGE: %s [options]\n", argv[0]);
         printf ("-------------------------------------------------------\n\n");
         printf ("  options:\n");
         printf ("      -cxx        Perform extraction of C11 and C22 (disabled by default)\n");
         printf ("\n\n");
         
         return 0;
         }
      
      else if (!strncmp (argv[i], "-cxx", 4))
         do_cxx = 1; 
      }

   printf ("Forward-biased S-parameter files?\n");
   printf ("enter on a single line, separated by spaces\n");
   fgets (file_list, 1023, stdin);

   printf ("Below pinch-off S-parameter file?\n");
   fgets (pinchoff_file, 255, stdin);
   pinchoff_file[strlen(pinchoff_file)-1] = 0;

   printf ("Frequency range for cold-FET extraction in GHz (min max)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf%lf", &min_freq, &max_freq);
   min_freq *= 1.0e9;
   max_freq *= 1.0e9;

   printf ("Frequency for resistance extraction in GHz?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &r_freq);
   r_freq *= 1.0e9;

   printf ("Output file name?\n");
   fgets (out_file, 255, stdin);
   out_file[strlen(out_file)-1] = 0;

   ptr = strtok (file_list, " \t\n");
   while (ptr)
      {
      strcpy (file_name, ptr);
      ptr = strtok (NULL, " \t\n");

      if (n_files >= MAX_FILES)
         break;

      file = fopen (file_name, "r");
      if (!file)
         {
         fprintf (stderr, "Warning: file not found - %s\n", file_name);
         continue;
         }

      npts = read_s_params (file, s, freqs, MAX_FREQS, &bias);
      fclose (file);
      if (!npts)
         {
         fprintf (stderr, "Warning: file empty - %s\n", file_name);
         continue;
         }

      igs[n_files] = 1.0 / bias.igs;

      /* use optimization to fit the gate impedance parameters */

      for (i = 0, j = 0; i < npts; ++i)
         {
         if (freqs[i] < min_freq)
            continue;
         else if (freqs[i] > max_freq)
            break;

         wl[j] = 2.0 * acos (-1.0) * freqs[i];
         s2z (s[i], z, 50.0);
         zgate[j] = Csub (z[0], Cmult (Complex(0.5), Cadd (z[1], z[2])));
         ++j;
         }

      z11_d.n = j;
      z11_d.zgate = zgate;
      z11_d.w = wl;

      if (j < 3)
         {
         fprintf (stderr, "Warning: not enough frequency points in file - %s\n", file_name);
         continue;
         }

      /* create starting values for Rg, Rp, Lg, and Cp */

      /* Rg - use the real part of Zgate at the maximum frequency */
      s2z (s[npts-1], z, 50.0);
      p[0].nom = Creal (Csub (z[0], Cmult (Complex(0.5), Cadd (z[1], z[2]))));
      p[0].max = p[0].nom;
      p[0].min = 0.1*p[0].nom;
      p[0].tol = 0.0;
      strcpy (p[0].name, "Rg");
      p[0].optimize = 1;

      /* Rp - use the real part of Zgate minus Rg at the minimum frequency */
      s2z (s[0], z, 50.0);
      p[1].nom = Creal (Csub (z[0], Cmult (Complex(0.5), Cadd (z[1], z[2]))));
      p[1].nom -= p[0].nom;
      p[1].min = p[1].nom;
      p[1].max = 10.0*p[1].nom;
      p[1].tol = 0.0;
      strcpy (p[1].name, "Rp");
      p[1].optimize = 1;

      /* Lg - use the imaginary part of Zgate at the stop frequency */
      p[2].nom = zgate[j-1].i / wl[j-1];
      p[2].min = p[2].nom;
      p[2].max = 2.0*p[2].nom;
      p[2].tol = 0.0;
      strcpy (p[2].name, "Lg");
      p[2].optimize = 1;

      /* Cp - use the imaginary part of Zgate minus w*Lg at the start frequency */
      p[3].nom = -1.0 / ((zgate[0].i - wl[0]*p[2].nom) * wl[0]);
      p[3].max = p[3].nom;
      p[3].min = 0.0;
      p[3].tol = 0.0;
      strcpy (p[3].name, "Cp");
      p[3].optimize = 1;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, p, 4);
      set_cg_error_function (opt, z11_erf, (void *) &z11_d, 1, NULL);
      set_cg_flags (opt, OPT_SINGLE_PARAM);

      if (cg_optimize4 (opt, 200, NULL))
         {
         fprintf (stderr, "%s\n", get_cg_error ());
         continue;
         }

      Rg[n_files] = p[0].nom;
      Lg[n_files] = p[2].nom;
      rp = p[1].nom;
      cp = p[3].nom;

      /* solve for Rd, Rs, Ld, and Ls */

      r_done = 0;
      for (i = 0, j = 0; i < npts; ++i)
         {
         s2z (s[i], z, 50.0);
         w = 2.0 * acos (-1.0) * freqs[i];

         if ((freqs[i] >= r_freq) && !r_done)
            {
            Rs[n_files] = 0.5 * Creal (Cadd (z[1], z[2]));
            Rd[n_files] = z[3].r - Rs[n_files];
            r_done = 1;
            }
         
         if (freqs[i] < min_freq)
            continue;
         else if (freqs[i] > max_freq)
            break;

         wl[j] = w;
         ls1[j] = 0.5 * Cimag (Cadd (z[1], z[2]));
         ld1[j] = z[3].i - ls1[j];
         ++j;
         }

      if (!r_done || (j < 2))
         {
         fprintf (stderr, "Warning: not enough frequency points in file - %s\n", file_name);
         continue;
         }

      linefit_mx0 (wl, ls1, j, &Ls[n_files], &r_sq);
      linefit_mx0 (wl, ld1, j, &Ld[n_files], &r_sq);

      printf ("---- File: %s ----\n", file_name);
      printf ("  Rp = %.3f, Cp = %.3e\n", rp, cp);
      printf ("  Rg = %.3f, Rd = %.3f, Rs = %.3f\n", Rg[n_files], Rd[n_files], Rs[n_files]);
      printf ("  Lg = %.3e, Ld = %.3e, Ls = %.3e\n\n", Lg[n_files], Ld[n_files], Ls[n_files]);

      ++n_files;
      }

   if (!n_files)
      {
      fprintf (stderr, "No valid data for cold FET extraction.\n");
      return 1;
      }
   else if (n_files < 2)
      {
      /* only one data file, use results as is */
      Rgf = Rg[0];
      Rdf = Rd[0];
      Rsf = Rs[0];
      Lgf = Lg[0];
      Ldf = Ld[0];
      Lsf = Ls[0];
      }
   else
      {
      /* more than one gate bias, extrapolate to infinite Igs */
      linefit_mxb (igs, Rg, n_files, &m, &Rgf, &r_sq);
      linefit_mxb (igs, Rd, n_files, &m, &Rdf, &r_sq);
      linefit_mxb (igs, Rs, n_files, &m, &Rsf, &r_sq);
      linefit_mxb (igs, Lg, n_files, &m, &Lgf, &r_sq);
      linefit_mxb (igs, Ld, n_files, &m, &Ldf, &r_sq);
      linefit_mxb (igs, Ls, n_files, &m, &Lsf, &r_sq);
      }

   if (do_cxx)
      {
      /* do the below pinch-off capacitance extraction */
      double cg1[MAX_FREQS];
      double cd1[MAX_FREQS];

      file = fopen (pinchoff_file, "r");
      if (file)
         {
         npts = read_s_params (file, s, freqs, MAX_FREQS, &bias);
         fclose (file);
         }
      else
         npts = 0;

      if (npts)
         {
         for (i = 0, j = 0; i < npts; ++i)
            {
            if (freqs[i] < min_freq)
               continue;
            else if (freqs[i] > max_freq)
               break;

            /* remove the effects of Lg and Ld */

            s2z (s[i], z, 50.0);

            z[0] = Csub (z[0], Cnum (0.0, 2.0 * acos (-1.0) * freqs[i] * Lgf));
            z[3] = Csub (z[3], Cnum (0.0, 2.0 * acos (-1.0) * freqs[i] * Ldf));

            /* calculate the fringing capacitances */

            z2y (z, y);

            cg1[j] = y[0].i + 0.5 * (y[1].i + y[2].i);
            cd1[j] = y[3].i + 0.5 * (y[1].i + y[2].i);
            wl[j] = 2.0 * acos (-1.0) * freqs[i];
            ++j;
            }

         if (j > 1)
            {
            linefit_mx0 (wl, cg1, j, &c11, &r_sq);
            linefit_mx0 (wl, cd1, j, &c22, &r_sq);
            }
         else
            c11 = c22 = 0.0;
         }
      else
         {
         fprintf (stderr, "Warning: file not found - %s\n", pinchoff_file);
         c11 = c22 = 0.0;
         }

      printf ("---- Fringing Capacitances ----\n");
      printf ("  C11 = %.3e, C22 = %.3e\n\n", c11, c22);
      }

   else
      {
      printf ("Extraction of C11 and C22 has been disabled by default.\n");
      printf ("These parameters SHOULD NOT BE USED UNLESS ABSOLUTELY NECESSARY.\n");
      printf ("Several large-signal models do not compensate for these parameters\n");
      printf ("so their existance creates a source of error between SS and LS models.\n");
      printf ("To enable CXX extraction, use the -cxx command-line switch.\n\n");
      
      c11 = c22 = 0.0;  
      }

   /* write the output file */
   
   file = fopen (out_file, "w+");
   if (!file)
      {
      fprintf (stderr, "Unable to write output file.\n");
      return 1;
      }

   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", Rgf, Rgf, Rgf, 0.0, "RG");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", Rsf, Rsf, Rsf, 0.0, "RS");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", Rdf, Rdf, Rdf, 0.0, "RD");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "RI");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "CGS");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "CDG");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "CDS");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "C1");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "C2");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, Lsf, Lsf*4.0, 0.0, "LS");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, Lgf, Lgf*4.0, 0.0, "B1");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, Ldf, Ldf*4.0, 0.0, "B2");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "GGS");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "GDG");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "GM");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "TAU1");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "GDS");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, 0.0, 0.0, 0.0, "TAU2");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, c11, c11*4.0, 0.0, "C11");
   fprintf (file, "%12.4e%12.4e%12.4e%12.4e %s\n", 0.0, c22, c22*4.0, 0.0, "C22");

   fclose (file);

   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/

static int z11_erf (double *p, void *data, double *err, unsigned n)
   {
   struct z11_data *d = (struct z11_data *) data;
   unsigned i;
   COMPLEX zg;
   double den;

   if (n != 1)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      den = 1.0 / (1.0 + d->w[i]*d->w[i]*p[1]*p[1]*p[3]*p[3]);
      zg.r = p[0] + p[1]*den;
      zg.i = d->w[i]*p[2] - d->w[i]*p[1]*p[1]*p[3]*den;
      err[0] += Cmag (Csub (zg, d->zgate[i]));
      }

   err[0] /= (double) d->n;

   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/

static unsigned read_s_params (FILE *file, COMPLEX s[][4], double *freqs, unsigned max_f, BIAS *bias)
   {
   double t[4];
   double freq_mult = 1.0;
   double impedance = 50.0;
   POLAR tmpp[4];
   char string[300];
   int ri_format = 0;
   int db_format = 0;
   unsigned i = 0;
   unsigned j;
   int flag = 0;

   if (bias)
      bias->vgs = bias->vds = bias->ids = bias->igs = 0.0;

   while (fgets (string, 299, file))
      {
      if (!strncmp (string,"!BIAS",5) && bias)
         {
         if (flag)
            break;

         for (j = 0; j < strlen (string); ++j)
            {
            if ((string[j] >= 65) && (string[j] <= 90))
               string[j] += (char) 32;
            }

         if (sscanf (string,"!bias: vds = %lf volts ids = %lf amps vgs = %lf volts igs = %lf amps",&t[0],&t[1],&t[2],&t[3]) == 4)
            {
            bias->vds = t[0];
            bias->ids = t[1];
            bias->vgs = t[2];
            bias->igs = t[3];
            }
         }
      else if (string[0] == '!')
         {
         if (flag)
            break;
         continue;
         }
      else if (string[0] == '#')
         {
         for (j = 0; j < strlen (string); ++j)
            {
            if ((string[j] >= 65) && (string[j] <= 90))
               string[j] += (char) 32;
            }
         sscanf (string,"# %*s %*s %*s %*s %lf",&impedance);

         if (strstr (string, "khz"))
            freq_mult = 1.0e3;
         else if (strstr (string, "mhz"))
            freq_mult = 1.0e6;
         else if (strstr (string, "ghz"))
            freq_mult = 1.0e9;
            
         if (strstr (string, "ri"))
            ri_format = 1;
         else if (strstr (string, "db"))
            db_format = 1;
         }
      
      if (i >= max_f)
         break;

      if (ri_format)
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freqs[i],&s[i][0].r,&s[i][0].i,
            &s[i][2].r,&s[i][2].i,&s[i][1].r,&s[i][1].i,&s[i][3].r,&s[i][3].i) == 9)
            {
            flag = 1;
            freqs[i] *= freq_mult;
            ++i;
            }
         }
      else
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freqs[i],&tmpp[0].m,&tmpp[0].a,
            &tmpp[2].m,&tmpp[2].a,&tmpp[1].m,&tmpp[1].a,&tmpp[3].m,&tmpp[3].a) == 9)
            {
            if (db_format)
               {
               tmpp[0].m = pow (10.0, tmpp[0].m*0.05);
               tmpp[1].m = pow (10.0, tmpp[1].m*0.05);
               tmpp[2].m = pow (10.0, tmpp[2].m*0.05);
               tmpp[3].m = pow (10.0, tmpp[3].m*0.05);
               }
            flag = 1;
            PA2CA (tmpp, s[i], 2, 2);
            freqs[i] *= freq_mult;
            ++i;
            }         
         }
      }

   return i;
   }

