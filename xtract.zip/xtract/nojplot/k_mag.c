#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "cmplxlib.h"

int main (int argc, char *argv[])
   {
   FILE  *files,*infile,*outfile;
   int ri_mode,db_mode,first;
   double k,mag,b,freq,fmult;
   COMPLEX s[4];
   POLAR sp[4];
   char string[256];
   char fname[256];
   char outname[256];
   char data_files[256];
   char extension[40];
   char tmp_file_name[200];
   time_t tbuf;

   printf ("S-Parameter data file(s)?\n");
   fgets (data_files,255,stdin);
   data_files[strlen(data_files)-1] = 0;

   printf ("Output file extension?\n");
   fgets (string,255,stdin);
   sscanf (string,"%39s",extension);

   sprintf (tmp_file_name,"tmp.%d",time(&tbuf));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string,"ls -1 %s > %s",data_files,tmp_file_name);
   system (string);

   files = fopen (tmp_file_name,"r");
   if (!files)
      {
      printf ("** error ** cannot open batch file\n");
      return -1;
      }

   while (fgets (fname,255,files))
      {
      fname[strlen(fname)-1] = 0;
      sscanf (fname,"%[^.]",outname);
      strcat (outname,extension);

      infile = fopen (fname,"r");
      if (!infile)
         continue;
      
      outfile = fopen (outname,"w+");
      if (!outfile)
         {
         fclose (infile);
         printf ("** error ** unable to write output file.\n");
         return -1;
         }
   
      ri_mode = 0;
      db_mode = 0;
      first = 1;
      fmult = 1.0;
   
      while (fgets (string,255,infile))
         {
         if (string[0] == '!')
            fprintf (outfile, "%s", string);
         else if (string[0] == '#')
            {
            if (strstr(string,"RI") || strstr(string,"ri"))
               ri_mode = 1;
         
            if (strstr(string,"DB") || strstr(string,"db"))
               db_mode = 1;
            
            if (strstr(string,"KHZ") || strstr(string,"khz") || strstr(string,"KHz"))
               fmult = 1.0e3;
            else if (strstr(string,"MHZ") || strstr(string,"mhz") || strstr(string,"MHz"))
               fmult = 1.0e6;
            else if (strstr(string,"GHZ") || strstr(string,"ghz") || strstr(string,"GHz"))
               fmult = 1.0e9; 
            }
      
         else if (sscanf(string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].r,&s[0].i,&s[2].r,&s[2].i,&s[1].r,&s[1].i,
            &s[3].r,&s[3].i) == 9)
            {
            freq *= fmult;
                 
            if (!ri_mode)
               {
               if (db_mode)
                  {
                  s[0].r = pow (10.0, s[0].r*0.05);
                  s[1].r = pow (10.0, s[1].r*0.05);
                  s[2].r = pow (10.0, s[2].r*0.05);
                  s[3].r = pow (10.0, s[3].r*0.05);
                  }
               
               sp[0].m = s[0].r;
               sp[0].a = s[0].i;
               sp[1].m = s[1].r;
               sp[1].a = s[1].i;
               sp[2].m = s[2].r;
               sp[2].a = s[2].i;
               sp[3].m = s[3].r;
               sp[3].a = s[3].i;
               
               PA2CA (sp,s,2,2);
               }
            
            if (first)
               {
               fprintf (outfile,"!   Freq    K-Factor MAG/MSG\n");
               fprintf (outfile,"!   (Hz)              (dB)\n");
               first = 0;
               }
            
            k_mag (s, &k, &mag, &b);
            
            fprintf (outfile, "%12.5e %6.3f %6.2f\n", freq, k, mag);
            }
         }
               
      fclose (infile);
      fclose (outfile);
      }

   fclose (files);

   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);

   return 0;
   }

