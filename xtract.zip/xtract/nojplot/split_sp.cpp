#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <sys/stat.h>
#include <stdlib.h>

// struct to hold bias data
struct BiasData
{
   double v1, v2, i1, i2;
};

// struct to hold file name formatting information
struct FileNameFormat
{
   std::string prefix, extension;
   std::string format;
   std::string subdir;
   int precision;
   FileNameFormat() : prefix("s"), extension(".s2p"), format("%1v-%2v"), subdir(""), precision(3) { } 
};

/*********************************************************************************/
static std::string create_bias_str( const double& v, int precision=3 )
{
   double v1 = fabs( v );
   std::string suf, r;
   std::ostringstream os;
   size_t i;

   // adjust the range and determine the range suffix
   if( v1 > 1.e9 ) {
      return std::string( "ILL" );
   }
   else if( v1 >= 1000. ) {
      v1 *= 0.001;
      suf = "k";
   }
   else if( v1 >= 1. ) {
   }
   else if( v1 >= 1.e-3 ) {
      v1 *= 1.e3;
      suf = "m";
   }
  else if( v1 >= 1.e-6 ) {
      v1 *= 1.e6;
      suf = "u";
   }
   else if( v1 >= 1.e-9 ) {
      v1 *= 1.e9;
      suf = "n";
   }
   else if( v1 > 1.e-15 ) {
      v1 *= 1.e12;
      suf = "p";
   }
   else {
      return std::string( "0" );
   }

   // prepend the return string with 'z' if the value is negative
   if( v < 0. )
      os << 'z';

   // round the result off at the specified precision
   os.precision( precision < 2 ? 2 : precision );
   os << v1 << suf;

   // replace the decimal point (if it exists) with 'd'
   r = os.str();
   i = r.find( '.' );
   if( i != std::string::npos )
      r[i] = 'd';

   return r;
}

/*********************************************************************************/
static std::string generate_file_name( const FileNameFormat& fmt, const BiasData& bias )
{
   std::string fname;
   fname += fmt.prefix;
   bool in_seq=false;
   std::string seq_save;

   // parse the format string
   for( std::string::const_iterator i = fmt.format.begin(); i != fmt.format.end(); ++i ) {
      if( *i == '%' ) {
         // the character is a control character
         if( in_seq ) {
            if( seq_save == "%" ) {
               in_seq = false;
               fname += '%';
            }
            else {
               // the last sequence was not a valid control sequence
               //  output it verbatim to the filename
               fname += seq_save;
            }
         }
         else {
            in_seq = true;
            seq_save = *i;
         }
      }
      else {
         // the character is not a special control character
         if( in_seq ) {
            seq_save += *i;
            // check to see if the sequence is valid
            if( seq_save == "%1v" ) {
               fname += create_bias_str( bias.v1, fmt.precision );
               in_seq = false;
            }
            else if( seq_save == "%1i" ) {
               fname += create_bias_str( bias.i1, fmt.precision );
               in_seq = false;
            }
            else if( seq_save == "%2v" ) {
               fname += create_bias_str( bias.v2, fmt.precision );
               in_seq = false;
            }
            else if( seq_save == "%2i" ) {
               fname += create_bias_str( bias.i2, fmt.precision );
               in_seq = false;
            }
         }
         else {
            // output the character verbatim to the filename
            fname += *i;
         }
      }
   }

   fname += fmt.extension;
   return fname;
}

/*********************************************************************************/
static int count_floats( const std::string& s )
{
   std::istringstream ss( s );
   double f;
   int n=0;
   while( 1 ) {
      ss >> f;
      if( ss.fail() ) break;
      ++n;
   }
   return n;
}

/*********************************************************************************/
static int process_file( const char* fname, const FileNameFormat& fname_fmt )
{
   std::string header;
   std::ifstream infile( fname );
   std::ofstream outfile;
   std::string str, ts_line, out_fname, bias_ln;
   std::string subdir;
   std::istringstream ss;
   char first;
   bool have_bias_data = false;
   int lineno=0;
   BiasData bias;

   // make the header storage big enough
   header.reserve(4096);

   // open the file
   if( !infile ) {
      std::cerr << "Error: " << fname << ": file not readable." << std::endl;
      return 1;
   }

   // see if the subdir parameter is set
   if( fname_fmt.subdir.length() ) {
      // check to see if subdirectory already exists
      struct stat st;
      if( stat( fname_fmt.subdir.c_str(), &st ) ) {
         // does not exist
         //  attempt to create it
         if( mkdir( fname_fmt.subdir.c_str(), 0777 ) ) {
            std::cerr << "Error: " << fname_fmt.subdir << ": unable to create directory." << std::endl;
            return 11;
         }
         subdir = fname_fmt.subdir + '/';
      }
      else {
         // exists, make sure it is a directory
         if( S_ISDIR(st.st_mode) ) {
            subdir = fname_fmt.subdir + '/';
         }
         else {
            std::cerr << "Error: " << fname_fmt.subdir << ": exists but is not a directory." << std::endl;
            return 10;
         }
      }
   }

   // start reading the file, grab the header
   while( infile.good() )
   {
      std::getline( infile, str );
      ++lineno;
      if( str.length() ) {
         ss.clear();
         ss.str( str );
         ss >> first;
         if( first == '!' ) {
            // make sure that this is not a bias line
            if( str.substr(0,6) == "!BIAS:" ) break;

            // add the line to the header
            header += str;
            header += "\n";
         }
         else break;
      }
   }

   if( !infile.good() ) {
      std::cerr << "Error: " << fname << ": no data." << std::endl;
      return 2;
   }

   // start processing the data
   while( infile.good() ) {
      ss.clear();
      ss.str( str );
      ss >> first;
      if( first == '!' ) {
         // see if the outfile is open, if so close it
         if( outfile.is_open() ) {
            outfile.close();
            have_bias_data = false;
         }

         // see if this is a bias line
         if( str.substr(0,6) == "!BIAS:" ) {
            // extract the bias data
            if( sscanf( str.c_str(), "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps", &bias.v2, &bias.i2, &bias.v1, &bias.i1 ) == 4 ) {
               have_bias_data = true;
               bias_ln = str;
            }
            else if( sscanf( str.c_str(), "!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps", &bias.v2, &bias.i2, &bias.v1, &bias.i1 ) == 4 ) {
               have_bias_data = true;
               bias_ln = str;
            }
            else
               std::cerr << "Warning: " << fname << ": invalid BIAS line at " << lineno << "." << std::endl;
         }
      }
      else if( first == '#' ) {
         // save this line for use as the touchstone line
         ts_line = str;
      }
      else {
         // try to read 2-port touchstone data
         if( count_floats(str) == 9 ) {
            // if the outfile is not open and there is valid bias data
            //   create a new file name, open the outfile, and write the header
            if( !outfile.is_open() && have_bias_data ) {
               out_fname = subdir + generate_file_name( fname_fmt, bias );
               outfile.open( out_fname.c_str() );
               if( !outfile ) {
                  std::cerr << "Error: " << out_fname << ": could not create file." << std::endl;
                  return 3;
               }

               outfile << header << bias_ln << "\n";
               if( ts_line.length() )
                  // output the touchstone format line
                  outfile << ts_line << "\n";
               else
                  // assume a default touchstone line
                  outfile << "# HZ S MA R 50\n";
               outfile << "!\n";
            }

            // if the outfile is open, write this line
            if( outfile.is_open() ) {
               outfile << str << "\n";
            }
         }
      }
      // read the next line
      std::getline( infile, str );
      ++lineno;
   }

   return 0;
}

/*********************************************************************************/
static void print_usage( const char *progname )
{
   std::cout << "\n\nUSAGE: " << progname << " [options] file1 [file2 ...]\n\n"
   "  This program splits multi-bias S-parameter files into individual files.\n"
   "  Files are named according to the specified options.\n\n"
   "  OPTIONS:\n"
   "   --pre=xx    Use the string xx as file name prefix.\n"
   "                The default string is \"s\"\n\n"
   "   --ext=xx    Use the string xx as the file name extension/suffix\n"
   "                The default string is \".s2p\"\n\n"
   "   --fmt=xx    Set the bias-dependent formatting string\n"
   "               The format string recognizes the following special\n"
   "               sequences:\n"
   "                  %1v   is replaced by the port 1 bias voltage\n"
   "                  %1i   is replaced by the port 1 bias current\n"
   "                  %2v   is replaced by the port 2 bias voltage\n"
   "                  %2i   is replaced by the port 2 bias current\n"
   "               The bias values are encoded as follows:\n"
   "                  - A leading \'z\' indicates that the value is negative\n"
   "                  - The decimal point is replaced by \'d\'\n"
   "                  - A trailing scale specifier may be appended\n"
   "               The scale specifiers are:\n"
   "                  k    kilo (x1000)\n"
   "                  m    milli (x0.001)\n"
   "                  u    micro (x1e-6)\n"
   "                  n    nano (x1e-9)\n"
   "                  p    pico (x1e-12)\n"
   "               The default string is \"%1v-%2v\"\n"
   "                 which, when processed, will create a file name\n"
   "                 consisting of the port 1 bias voltage and then\n"
   "                 the port 2 bias voltage separated by a hyphen.\n\n"
   "   --prec=n    Sets the precision (number of significant digits)\n"
   "                that are used when generating a bias string.\n"
   "                The default value is 3.\n\n"
   "   --subdir=xx Creates the files in a subdirectory named xx.\n"
   "                The directory will be created if it doesn\'t exist.\n"
   "                The default behavior is not to do this.\n\n"
   "\n\n" ;
}

/*********************************************************************************/
int main( int argc, const char **argv )
{
   int i;
   std::string ar;
   FileNameFormat fmt;

   /* parse the command line */

   if (argc < 2)
   {
      print_usage( argv[0] );
      return 0;
   }

   // first grab options
   for( i=1; i<argc; i++ )
   {
      if( *argv[i] != '-' ) break;

      ar = argv[i];
      if( ar.substr(0,6) == "--pre=" ) {
         fmt.prefix = ar.substr(6);
      }
      else if( ar.substr(0,6) == "--ext=" ) {
         fmt.extension = ar.substr(6);
      }
      else if( ar.substr(0,6) == "--fmt=" ) {
         fmt.format = ar.substr(6);
      }
      else if( ar.substr(0,7) == "--prec=" ) {
         int d=0;
         sscanf( ar.substr(7).c_str(), "%d", &d );
         if( d > 0 ) fmt.precision = d;
      }
      else if( ar.substr(0,9) == "--subdir=" ) {
         fmt.subdir = ar.substr(9);
      }
      else {
         print_usage( argv[0] );
         exit(1);
      }
   }

   // next grab and process files
   for( ; i<argc; ++i ) {
      std::cout << "Processing: " << argv[i] << std::endl;
      process_file( argv[i], fmt );
   }

   return 0;
}

