#include <stdio.h>
#include <string.h>

main (int argc, char *argv[])
{
FILE *in_file;
FILE *out_file;
char in_name[100];
char out_name[100];
char buffer[2501];
char *ptr;
unsigned i = 0;
int itmp;
double dtmp;

printf ("input file name?\n");
scanf ("%99s",in_name);

printf ("output file name?\n");
scanf ("%99s",out_name);

in_file = fopen (in_name,"r");
if (!in_file)
   {
   fprintf (stderr, "Error: %s: unable to open file.\n", in_name);
   return 1;
   }

out_file = fopen (out_name,"w+");
if (!out_file)
   {
   fprintf (stderr, "Error: %s: unable to write file.\n", out_name);
   return 1;
   }

while (fgets (buffer,2500,in_file))
   {
   if ((buffer[0] == '!') || (buffer[0] == '%') || (buffer[0] == 'B') || (buffer[0] == 'E'))
      {
      fprintf (out_file, "%s", buffer);
      continue;
      }

   if (sscanf (buffer, "%d%lf", &itmp, &dtmp) == 2)
      {
      unsigned j;
      int found1 = 0;

      /* find the start of the second token in the string */

      for (j = 0; j < strlen (buffer); ++j)
	 {
         if (!found1)
	    {
	    if (buffer[j] != ' ')
	       {
	       for (++j ; j < strlen (buffer); ++j)
		  {
		  if (buffer[j] == ' ')
		     break;
                  }
               found1 = 1;
	       }
            }
         else
	    {
	    if (buffer[j] != ' ')
	       break;
            }
         }

      fprintf (out_file, "%-5u%s", ++i, &buffer[j]);
      }
   }

fclose (in_file);
fclose (out_file);

return 0;
}
