#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main (int argc, char *argv[])
   {
   char tmp_file_name[100];
   char string[1000];
   char command[1100];
   char outname[200];
   char fname[1000];
   char *str;
   int first = 1;
   int counter = 1;
   int i,tmp,done;
   time_t dummy;
   FILE *filelist,*file,*ofile;
   
   sprintf (tmp_file_name,"temp.%d",time (&dummy));
   
   printf ("\nThis program will combine DSCR models that were created using\n");
   printf ("the dscr_new program.  Files will be combined in the order that\n");
   printf ("they are listed.  The order will be alphabetical if wildcards\n");
   printf ("are used.\n\n");
   
   printf ("DSCR model files to combine?\n");
   fgets (string,999,stdin);
   string[strlen(string)-1] = 0;
   
   sprintf (command,"rm -f %s",tmp_file_name);
   system (command);
   
   str = strtok (string," ");
   while (str)
      {
      sprintf (command,"ls -1 %s >> %s",str,tmp_file_name);
      system (command);
      
      str = strtok (NULL," ");
      }
   
   printf ("Output file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%s",outname);
   
   filelist = fopen (tmp_file_name,"r");
   if (!filelist)
      {
      fprintf (stderr,"File not found.\n");
      return -1;
      }

   ofile = fopen (outname,"w+");
   if (!ofile)
      {
      fprintf (stderr,"Invalid permissions.\n");
      return -1;
      }
   
   while (fgets (fname,999,filelist))
      {
      fname[strlen(fname)-1] = 0;
      
      file = fopen (fname,"r");
      if (!file)
         continue;

      done = 0;
      while (fgets (string,999,file))
         {
         if (string[0] != '!')
            break;
         else if (!strncmp(string,"!Model",6))
            {
            if (first)
               fprintf (ofile,"%s",string);

            fgets (string,999,file);
            if (first)
               fprintf (ofile,"%s",string);

            while (fgets (string,999,file))
               {
               if ((string[0] != '!') || (string[1] < 48) || (string[1] > 57))
                  {
                  done = 1; 
                  break;
                  }

               for (i = 0; i < strlen (string); ++i)
                  {
                  if (string[i] == '\t')
                     {
                     ++i;
                     break;
                     }
                  }

               fprintf (ofile,"!%d\t%s",counter,&string[i]);
               }
            }
         else if (done)
            break;
         else if (first)
            fprintf (ofile,"%s",string);
         }

      if (first)
         first = 0;

      ++counter;

      fclose (file);
      }

   fprintf (ofile,"!\n");

   rewind (filelist);

   first = 1;
   counter = 1;
   while (fgets (fname,999,filelist))
      {
      fname[strlen(fname)-1] = 0;

      file = fopen (fname,"r");
      if (!file)
         continue;

      while (fgets (string,999,file))
         {
         if (first)
            {
            if (!strncmp (string,"! FET",5))
               {
               fprintf (ofile,"%s!\n",string);
               continue;
               }
            else if (string[0] == '%')
               {
               fprintf (ofile,"BEGIN DSCRDATA\n",string);
               fprintf (ofile,"%s",string);
               continue;
               }
            }

         if (sscanf (string,"%d",&tmp))
            {
            fprintf (ofile,"%5d    %s",counter,&string[9]);
            ++counter;
            }
         }

      if (first)
         first = 0;

      fclose (file);
      }

   fprintf (ofile,"END DSCRDATA\n");
   
   fclose (ofile);
   fclose (filelist);

   sprintf (command,"rm -f %s",tmp_file_name);
   system (command);

   printf ("Complete.\n");

   return 0;
   }







   



      
      
   
   
   
