#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include "cmplxlib.h"
#include "optimize4.h"
#include "fit_tools.h"

#define MAX_S_IN_FILE   1000
#define MAX_FREQS       200
#define MATRIX_SIZE     9
#define LOG_FILE_NAME   "z_noise.log"

#define T0            290.0
#define BOLTZMANN     1.38066e-23
#define ROOM_TEMP     294.0

// flags
#define BATCH_MODE        (1<<0)
#define IGNORE_WARNINGS   (1<<2)
#define NO_INTERPOLATE    (1<<3)

// maximum delta in gain between measured and calculated
#define MAX_GAIN_DELTA    (0.5)

/*** GLOBAL VARIABLES ***/
static FILE *global_errstream = NULL;
static unsigned global_flags = 0;

/*** PROTOTYPES AND TYPEDEFS ***/
typedef struct {
   char noise_file[256];
   char fxa_file[256];
   char fxb_file[256];
   char s_file[256];
   char end_file[256];
   char ns_file[256];
   char out_file[256];
   double temp;
} NOISE_FIT_IN;

static int batch_main();
static int noise_fit_main( NOISE_FIT_IN *inp );
static int noise_deembed ();

typedef struct {
   double *params;
   double *nf;
   COMPLEX *gamma;
   double *freqs;
   int n_freqs;
   double temperature;
   COMPLEX **y, **yc;
} NOISE_OPT;

typedef struct {
   double vgs,vds,igs,ids;
} BIAS;

typedef struct {
    COMPLEX s[4];
} S_Params_2p;


static void log_error( const char *err_msg );
static void log_warning( const char *err_msg );


static double calculate_ga( COMPLEX gs, COMPLEX *s, COMPLEX *gout );

static int read_noise_data( const char *fname, double *f, double *nf, double *gain,
    unsigned max_pts, unsigned *n, BIAS *bias );
static int read_s_param_data( const char* fname, double* flist, unsigned nf, S_Params_2p* s );
static int read_model_params( const char* fname, double* p );
static int read_and_deembed_noise( const char* noise_file, const char* fxa_file,
    const char* fxb_file, const char* dut_file, const char* ns_file, unsigned max_pts,
    double temperature,
    double* flist, double* nf_d, double* ga_d, COMPLEX* gamma_s, unsigned* n_pts, BIAS* bias );
static void deembed_noise_figure( double nf, double ga, COMPLEX *s_dut, COMPLEX *s_fxa,
    COMPLEX *s_fxb, COMPLEX *s_ns_2port, int use_s22,
    double temperature, double *nf_d, double *ga_d, COMPLEX *gamma_s );
static double calculate_noise_figure( COMPLEX **y, COMPLEX **yc, double *p, double vv, double ii, double temperature,
    COMPLEX gamma_s, double freq, COMPLEX *n_corr, COMPLEX *y_params );
static int optimize_noise_parameters( double *params, double *nf, double *f_list, COMPLEX *gamma,
    unsigned n_freqs, double temperature, double *vv, double *ii );
static double associated_gain( COMPLEX *s, COMPLEX gamma );
static int write_output_file( char *fname, char *hname, double *f_list, double *nf,
    COMPLEX *gamma_s, unsigned n_freq, double *p, double vv,
    double ii, double temperature, BIAS bias );

/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/

int main( int argc, char **argv )
{
   int i;

   // setup the error stream
   global_errstream = stderr;

   // parse the command line
   for( i=1; i<argc; ++i ) {
       if( argv[i][0] == '-' ) {
           if( !strcmp( argv[i], "-b" ) || !strcmp( argv[i], "-batch" ) ||
                !strcmp( argv[i], "--batch" ) )
                global_flags |= BATCH_MODE;
            else if( !strcmp( argv[i], "--nointerp" ) )
                global_flags |= NO_INTERPOLATE;
            else if( !strcmp( argv[i], "-w0" ) || !strcmp( argv[i], "--no-warnings" ) )
                global_flags |= IGNORE_WARNINGS;
            else {
                fprintf( stderr, "Error: unexpected command-line parameter: \'%s\'\n", argv[i] );
                return -99;
            }
       }
       else {
            fprintf( stderr, "Error: unexpected command-line parameter: \'%s\'\n", argv[i] );
            return -99;
       }
   }

   // execute the correct program
   if( strstr(argv[0], "batch") ) {
      global_flags |= BATCH_MODE;
      return batch_main();
   }
   else if( strstr(argv[0], "dmb") || strstr(argv[0], "deembed") ) {
       return noise_deembed();
   }
   else {
      if( global_flags & BATCH_MODE )
         return batch_main();
      else
         return noise_fit_main(NULL);
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static char* zero_pad( int d, int wid )
{
    static char str[32];
    char s[20];
    sprintf( s, "%d", d );
    strcpy( str, "000000000" );
    strcat( str, s );
    return &str[strlen(str)-wid];
}

/*********************************************************************************************/
/*********************************************************************************************/
void get_timestamp( char * ts )
{
    struct timeval tv;
    struct tm t;
    char tmp[32];
    gettimeofday( &tv, NULL );
    localtime_r( &tv.tv_sec, &t );
    ts[0] = '\0';
    sprintf( tmp, "%s/", zero_pad(t.tm_mon+1,2) ); strcat( ts, tmp );
    sprintf( tmp, "%s/", zero_pad(t.tm_mday,2) ); strcat( ts, tmp );
    sprintf( tmp, "%d ", t.tm_year+1900 ); strcat( ts, tmp );
    sprintf( tmp, "%s:", zero_pad(t.tm_hour,2) ); strcat( ts, tmp );
    sprintf( tmp, "%s:", zero_pad(t.tm_min,2) ); strcat( ts, tmp );
    sprintf( tmp, "%s.", zero_pad(t.tm_sec,2) ); strcat( ts, tmp );
    sprintf( tmp, "%s", zero_pad((int) (tv.tv_usec / 1000.),3) ); strcat( ts, tmp );
}

/*********************************************************************************************/
/*********************************************************************************************/
static void log_error( const char *err_msg )
{
    char tstamp[200];
    get_timestamp( tstamp );
    if( global_errstream && ! (global_flags & BATCH_MODE) ) {
      fprintf( global_errstream, "Error: %s: %s\n", tstamp, err_msg );
    }
    else {
      FILE *file = fopen( LOG_FILE_NAME, "a" );
      if (!file) return;
      fprintf( file, "Error: %s: %s\n", tstamp, err_msg );
      fclose (file);
   }
}

/*********************************************************************************************/
/*********************************************************************************************/
static void log_warning( const char *err_msg )
{
    char tstamp[200];
    if( global_flags & IGNORE_WARNINGS ) return;
    get_timestamp( tstamp );
    if( global_errstream && ! (global_flags & BATCH_MODE) ) {
      fprintf( global_errstream, "Warning: %s: %s\n", tstamp, err_msg );
    }
    else {
      FILE *file = fopen( LOG_FILE_NAME, "a" );
      if (!file) return;
      fprintf( file, "Warning: %s: %s\n", tstamp, err_msg );
      fclose (file);
   }
}

/*********************************************************************************************/
/*********************************************************************************************/
static int batch_main (unsigned flags)
{
   NOISE_FIT_IN input;
   char fit_files[256];
   char base_name[256];
   char string[256];
   char ext[31];
   const char** flist;
   const char** fname;
   unsigned i, p;

   printf ("Noise files to fit?\n");
   fgets (fit_files, 255, stdin);
   fit_files[strlen(fit_files)-1] = 0;

   printf ("Input error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", input.fxa_file);

   printf ("Output error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", input.fxb_file);

   printf ("Noise source [S]-parameter file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", input.ns_file);

   printf ("Extension for [S] files?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%30s", ext);

   printf ("Measurement temperature (C)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf", &input.temp))
      input.temp += 273.15;
   else
      input.temp = 294.0;

   // remove old error file (if it exists)
   unlink( LOG_FILE_NAME );

   // create a list of files to batch fit
   flist = get_file_listing( fit_files );

   if( !flist || !*flist ) {
      fprintf( stderr, "Error: no files to fit.\n" );
      return 1;
   }

   // fork into a background process and exit the foreground process
   switch (fork())
   {
   case -1:
      fprintf( stderr, "Error: fork() failed.\n" );
      return 1;
   case 0:
      // this is the child process
      break;
   default:
      // this is the parent process
      return 0;
   }

   for( fname=flist; *fname; ++fname ) {
          strcpy( input.noise_file, *fname );
          strcpy( base_name, *fname );
          strip_extension( base_name );
          // find the last "/" or "\" in the base name
          //  and point to the character after it
          for( p=0, i=0; i<strlen(base_name)-1; ++i ) {
                if( base_name[i] == '/' || base_name[i] == '\\' ) p = i+1;
          }
          strcpy( input.out_file, &base_name[p] );
          strcat( input.out_file, ".rpc" );
          strcpy( input.s_file, base_name );
          strcat( input.s_file, ext );
          input.s_file[p] = 's';
          strcpy( input.end_file, base_name );
          strcat( input.end_file, ".end" );
          input.end_file[p] = 's';

          // run the noise extraction
          noise_fit_main( &input );
   }

   free_file_listing( flist );

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static int noise_fit_main( NOISE_FIT_IN *inp )
{
   char string[256], noise_file[256];
   char fxa_file[256], fxb_file[256];
   char s_file[256], ns_file[256], out_file[256], end_file[256];
   double flist[MAX_FREQS], nf_d[MAX_FREQS], ga_d[MAX_FREQS];
   COMPLEX gamma_s[MAX_FREQS];
   double parms[20];
   unsigned npts;
   double temperature;
   double vv, ii;
   BIAS bias;

   /**** get user input ****/

   if (inp) {
      strcpy (noise_file, inp->noise_file);
      strcpy (fxa_file, inp->fxa_file);
      strcpy (fxb_file, inp->fxb_file);
      strcpy (s_file, inp->s_file);
      strcpy (end_file, inp->end_file);
      strcpy (ns_file, inp->ns_file);
      strcpy (out_file, inp->out_file);
      temperature = inp->temp;
   }
   else {
      printf ("Measured noise figure data file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", noise_file);

      printf ("Input error box file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", fxa_file);

      printf ("Output error box file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", fxb_file);

      printf ("Measured S-parameter data file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", s_file);

      printf ("Model parameter data file (.end file)?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", end_file);

      printf ("Noise source S-parameter file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", ns_file);

      printf ("Output file name?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", out_file);

      printf ("Measurement temperature (C)?\n");
      fgets (string, 255, stdin);
      if (sscanf (string, "%lf", &temperature) == 1)
         temperature += 273.15;
      else
         temperature = 294.0;
   }

   /**** read and deembed noise figure and gain data ****/
   if( read_and_deembed_noise( noise_file, fxa_file, fxb_file, s_file,
        ns_file, MAX_FREQS, ROOM_TEMP, flist, nf_d, ga_d, gamma_s, &npts, &bias ) )
      return 1;

    if( npts < 8 ) {
        sprintf( string, "%s: not enough valid data to fit.", noise_file );
        log_error( string );
        return 1;
    }

   /**** read in the model parameter data ****/
   if( read_model_params( end_file, parms ) )
      return 1;

   /**** optimize <vv*> and <ii*> ****/
   if( optimize_noise_parameters( parms, nf_d, flist, gamma_s, npts, temperature, &vv, &ii ) ) {
        sprintf( string, "%s: optimization failure.", noise_file );
        log_error( string );
      return 1;
   }

   /**** write output file ****/

   if( write_output_file( out_file, noise_file, flist, nf_d, gamma_s, npts, parms, vv, ii, temperature, bias ) )
      return 1;

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static int read_and_deembed_noise( const char* noise_file, const char* fxa_file,
    const char* fxb_file, const char* dut_file, const char* ns_file, unsigned max_pts,
    double temperature,
    double* flist, double* nf_d, double* ga_d, COMPLEX* gamma_s, unsigned* n_pts, BIAS* bias )
{
    S_Params_2p s_fxa[MAX_FREQS];
    S_Params_2p s_fxb[MAX_FREQS];
    S_Params_2p s_dut[MAX_FREQS];
    S_Params_2p s_ns[MAX_FREQS];
    unsigned i, j, pts;
    int use_s22;
    char string[256];

    *n_pts = 0;

    /**** read in the noise data ****/
    if( read_noise_data( noise_file, flist, nf_d, ga_d, max_pts, &pts, bias ) )
        return 1;

    /**** read in S-parameters for the input block, output block, device, and noise source ****/
    if( read_s_param_data( fxa_file, flist, pts, s_fxa ) ||
        read_s_param_data( fxb_file, flist, pts, s_fxb ) ||
        read_s_param_data( dut_file, flist, pts, s_dut ) ||
        read_s_param_data( ns_file, flist, pts, s_ns ) )
        return 1;

   /**** determine wheter to use S11 or S22 of the noise source file ****/
   use_s22 = (Cmag(s_ns[0].s[0]) < Cmag(s_ns[0].s[3])) ? 0 : 1;

   /**** compute the deembeded NF of the DUT and compute the input gamma ****/
   for( i=0, j=0; i<pts; ++i ) {
       if( nf_d[i] > 40. ) continue;  // skip bad data
       deembed_noise_figure( nf_d[i], ga_d[i], s_dut[i].s, s_fxa[i].s, s_fxb[i].s,
            s_ns[i].s, use_s22, temperature, &nf_d[j], &ga_d[j], &gamma_s[j] );
       // verify that the deembedded noise figure is valid
       if( isnan(nf_d[j]) || nf_d[j] <= 0. ) {
           sprintf( string, "%s: noise figure deembedding failed for freq = %g", noise_file, flist[i] );
           log_warning( string );
           continue;
       }
       // verify that the deembedded gain is close enough to the calculated gain
       else if( fabs( 1. - associated_gain( s_dut[i].s, gamma_s[j] ) / ga_d[j] ) > MAX_GAIN_DELTA ) {
           sprintf( string, "%s: deembeding gain verification failed for freq = %g", noise_file, flist[i] );
           log_warning( string );
           continue;
       }
       if( j != i ) flist[j] = flist[i];
       ++j;
   }

   *n_pts = j;
   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static int read_noise_data( const char *fname, double *f, double *nf, double *gain,
    unsigned max_pts, unsigned *n, BIAS *bias )
{
   FILE *file;
   char string[256];
   double f1, g1, n1;

   *n = 0;
   if (bias) bias->vds = bias->vgs = bias->ids = bias->igs = 0.;

   file = fopen( fname, "r" );
   if( !file ) {
       sprintf( string, "%s: unable to open file.", fname );
       log_error( string );
       return 1;
   }

   while( fgets(string, 255, file) ) {
       if( string[0] == '!' ) {
            if( !strncmp( string, "!BIAS:", 6 ) && bias ) {
                sscanf( string, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
                    &bias->vds,&bias->ids, &bias->vgs, &bias->igs );
            }
            continue;
       }

        if( sscanf( string, "%lf%lf%lf", &f1, &g1, &n1 ) == 3 ) {
            if( *n >= max_pts ) {
                sprintf( string, "%s: max points exceeded.", fname );
                log_warning( string );
                break;
            }

            f[*n] = f1;
            gain[*n] = g1;
            nf[*n] = n1;
            ++(*n);
        }
   }

   fclose( file );
   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static void interpolate_s_params( double f, double f_lo, COMPLEX *s_lo, double f_hi, COMPLEX *s_hi, COMPLEX *s )
{
   double factor = (f - f_lo) / (f_hi - f_lo);
   int i;
   POLAR spl, sph, sint;
   double ad;

   for( i=0; i<4; ++i ) {
       spl = C2P( s_lo[i] );
       sph = C2P( s_hi[i] );
       sint.m = spl.m + factor * (sph.m - spl.m);
       ad = sph.a - spl.a;
       if( sph.a <= spl.a && spl.a - sph.a > 180. ) ad += 360.;
       else if( sph.a > spl.a && sph.a - spl.a >= 180. ) ad -= 360.;
       sint.a = spl.a + factor * ad;
       s[i] = P2C( sint );
   }
}

/*********************************************************************************************/
/*********************************************************************************************/
static int read_s_param_data( const char *fname, double *flist, unsigned nf, S_Params_2p *s )
{
   char string[256];
   double f;
   double fmult = 1.0;
   int ma_format = 1;
   int db_format = 0;
   FILE *file;
   COMPLEX sdata[MAX_S_IN_FILE][4];
   double fdata[MAX_S_IN_FILE];
   COMPLEX stmp[4];
   unsigned n = 0;
   unsigned i,j;
   int found;

   if( !strcmp(fname, "ideal") ) {
      for( i=0; i<nf; ++i ) {
         s[i].s[0] = s[i].s[3] = ((COMPLEX) {0.0, 0.0});
         s[i].s[1] = s[i].s[2] = ((COMPLEX) {1.0, 0.0});
      }
      return 0;
   }

   file = fopen( fname, "r" );
   if( !file ) {
      sprintf( string, "%s: unable to open file.", fname );
      log_error( string );
      return 1;
   }

   while( fgets( string, 255, file ) ) {
      if( string[0] == '#' ) {
         // read the touchstone format string
         // this defaults to "# HZ S MA R 50" if none is given

         // convert the string to lowercase
         for (i = 0; i < strlen (string); ++i) {
            if( string[i] >= 'A' && string[i] <= 'Z' )
               string[i] += (char) ('a' - 'A');
         }

         // find the frequency multiplier
         if( strstr(string, "khz") )
            fmult = 1.0e3;
         else if( strstr(string, "mhz") )
            fmult = 1.0e6;
         else if( strstr(string, "ghz") )
            fmult = 1.0e9;

         // determine if the data is in RI format
         if( strstr(string, "ri") )
            ma_format = 0;

         // determine if the data is in DB format
         if( strstr(string, "db") )
            db_format = 1;
      }
      else if( string[0] == '!' )
         continue;

      if( sscanf (string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &f, &stmp[0].r, &stmp[0].i,
         &stmp[2].r, &stmp[2].i, &stmp[1].r, &stmp[1].i, &stmp[3].r, &stmp[3].i) == 9 ) {
            if (n >= MAX_S_IN_FILE) {
                sprintf( string, "%s: max points exceeded.", fname );
                log_warning( string );
                break;
            }

            f *= fmult;

            if (ma_format || db_format) {
                POLAR s_p[4];
                s_p[0].m = stmp[0].r;
                s_p[0].a = stmp[0].i;
                s_p[1].m = stmp[1].r;
                s_p[1].a = stmp[1].i;
                s_p[2].m = stmp[2].r;
                s_p[2].a = stmp[2].i;
                s_p[3].m = stmp[3].r;
                s_p[3].a = stmp[3].i;

                if (db_format) {
                    s_p[0].m = pow( 10.0, s_p[0].m*0.05 );
                    s_p[1].m = pow( 10.0, s_p[1].m*0.05 );
                    s_p[2].m = pow( 10.0, s_p[2].m*0.05 );
                    s_p[3].m = pow( 10.0, s_p[3].m*0.05 );
                }

                PA2CA( s_p, stmp, 2, 2 );
            }

             fdata[n] = f;
             sdata[n][0] = stmp[0];
             sdata[n][1] = stmp[1];
             sdata[n][2] = stmp[2];
             sdata[n][3] = stmp[3];

             ++n;
        }
    }

   fclose (file);

   /**** match up the frequencies, interpolate if necessary/allowed ****/
   for( i=0; i<nf; ++i ) {
       if( flist[i] < fdata[0] || flist[i] > fdata[n-1] ) {
           // error, extrapolation
           sprintf( string, "%s: freq = %g is not available.", fname, flist[i] );
           log_error( string );
           return 1;
       }
       found = 0;
        for( j=0; j<n; ++j ) {
          if( flist[i] == fdata[j] ) {
              s[i].s[0] = sdata[j][0];
              s[i].s[1] = sdata[j][1];
              s[i].s[2] = sdata[j][2];
              s[i].s[3] = sdata[j][3];
              found = 1;
          }
          else if( j < n-1 && flist[i] > fdata[j] && flist[i] < fdata[j+1] ) {
              if( global_flags & NO_INTERPOLATE ) {
                  sprintf( string, "%s: no match for freq = %g and interpolation is disabled.", fname, flist[i] );
                  log_error( string );
                  return 1;
              }
              // interpolate
              interpolate_s_params( flist[i], fdata[j], sdata[j], fdata[j+1], sdata[j+1], s[i].s );
              found = 1;
          }
        }
        if( !found ) {
           // error, extrapolation
           sprintf( string, "%s: BUG! freq = %g was not found but should have been.", fname, flist[i] );
           log_error( string );
           return 1;
        }
   }
   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static int read_model_params( const char *fname, double *p )
{
   FILE *file;
   unsigned i=0;
   char string[256];
   char nm[35];
   double pt;
   static const char* names[] = { "RG", "RS", "RD", "RI", "CGS", "CDG", "CDS", "C1", "C2", "LS",
        "B1", "B2", "GGS", "GDG", "GM", "TAU1", "GDS", "TAU2", "C11", "C22" };

   file = fopen (fname, "r");
   if (!file) {
      sprintf( string, "%s: unable to open file.", fname );
      log_error( string );
      return 1;
   }

   while( fgets(string, 255, file) ) {
      if( i == 20 ) break;

      if( string[0] == '!' || string[0] == '#' )
         continue;

      if( sscanf(string, "%*f%lf%*f%*f%20s", &pt, nm ) == 2 ) {
          if( strcmp( nm, names[i] ) ) {
              fclose (file);
              sprintf( string, "%s: error invalid parameter or parameter order.", fname );
              log_error( string );
              return 1;
          }
          p[i] = pt;
          ++i;
      }
   }

   fclose (file);

   if( i != 20 ) {
      sprintf( string, "%s: missing parameters.", fname );
      log_error( string );
      return 1;
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static double calculate_ga( COMPLEX gs, COMPLEX *s, COMPLEX *gout )
{
    static COMPLEX one = {1.0, 0.0};
    double num, den;
    COMPLEX gam_out;

    gam_out = Cadd(s[3], Cdiv( Cmultx(3, s[1], s[2], gs), Csub(one,Cmult(s[0],gs)) ) );
    num = (1. - Cmag2(gs)) * Cmag2(s[2]);
    den = Cmag2( Csub(one,Cmult(s[0],gs)) ) * ( 1. - Cmag2(gam_out) );

    if( gout ) *gout = gam_out;

    return num / den;
}

/*********************************************************************************************/
/*********************************************************************************************/
static void deembed_noise_figure( double nf, double ga, COMPLEX *s_dut, COMPLEX *s_fxa,
                                  COMPLEX *s_fxb, COMPLEX *s_ns_2port, int use_s22,
                                  double temperature, double *nf_d, double *ga_d, COMPLEX *gamma_s )
{
   /*
   COMPLEX ga, gb, gc;
   COMPLEX one = {1.0, 0.0};
   */
   double g1, g2, g3;
   double f1, f3, ft;
   COMPLEX gam2, s_ns;

   // set of S-params to use for the 1-port noise source (S11 or S22)
   s_ns = use_s22 ? s_ns_2port[3] : s_ns_2port[0];

   // calculate available power gain for all 3 stages
   // this is done vectorally to account for mismatches between stages
   g1 = calculate_ga( s_ns, s_fxa, gamma_s );
   g2 = calculate_ga( *gamma_s, s_dut, &gam2 );
   g3 = calculate_ga( gam2, s_fxb, NULL );

   // calculate noise factors for the passive stages
   //  noise factors for the passive stages are corrected for
   //  the ambient temperature
   f1 = (1./g1 - 1.) * temperature/T0 + 1.;
   f3 = (1./g3 - 1.) * temperature/T0 + 1.;
   // caculate the noise factor for the total system
   ft = pow(10., nf * 0.1);

   // deembed the noise figure for the middle (DUT) stage
   *nf_d = 10. * log10( g1 * ( ft - f1 - (f3 - 1.)/(g1*g2) ) + 1. );
   // deembed the gain
   *ga_d = ga - 10. * log10(g1) - 10. * log10(g3);
}

/*********************************************************************************************/
/*********************************************************************************************/
static double noise_figure( COMPLEX *n_corr, COMPLEX gamma, double z0 )
{
   COMPLEX z0c = Complex(z0);
   COMPLEX ys = Cdiv( Csub( Complex(1.0), gamma ), Cadd( z0c, Cmult( z0c, gamma ) ) );
   double x;

   x = Creal( Caddx( 4, n_corr[3], Cmultx( 3, n_corr[0], ys, Cconj(ys) ),
        Cmult( n_corr[2], Cconj(ys) ), Cmult( n_corr[1], ys ) ) );

   return 10.0 * log10( 1. + x / Creal(ys) );
}

/*********************************************************************************************/
/*********************************************************************************************/
static void noise_parameters( COMPLEX *ca, double z0, double *fmin, double *mag, double *angle, double *rn )
{
   COMPLEX yopt,gamma;
   COMPLEX one = {1.0, 0.0};
   double gopt, bopt;

   *rn = ca[0].r;

   bopt = 0.5 * Cimag( Csub( ca[1], ca[2] ) ) / *rn;
   gopt = sqrt( fabs( Creal( Csub( Cdiv( ca[3], Complex(*rn) ), Complex(bopt*bopt) ) ) ) );
   yopt = Cnum( gopt, bopt );
   gamma = Cdiv( Csub( Complex(1./z0), yopt ), Cadd( Complex(1./z0), yopt ) );

   *mag = Cmag( gamma );
   *angle = Cangle( gamma );
   *fmin = 10.0 * log10( Creal( Caddx( 4, one, ca[1], ca[2], Complex(2. * (*rn) * gopt) ) ) );
}

/*********************************************************************************************/
/*********************************************************************************************/
static void noise_matrix_reduction (COMPLEX **y, COMPLEX **cy, unsigned n, unsigned m)
{
   COMPLEX tmpc;
   COMPLEX denom1,denom2;
   COMPLEX one = {1.0, 0.0};
   double max,tmpd;
   unsigned i,j,k,row,col;

   for (k = n-1; k >= m; --k)
   {
      // find maximum value

      max = 0.0;
      row = k;
      col = k;
      for (i = m; i <= k; ++i)
      {
         for (j = m; j <= k; ++j)
         {
            tmpd = Cmag2 (y[i][j]);
            if (tmpd > max)
            {
               row = i;
               col = j;
               max = tmpd;
            }
         }
      }

      // pivot rows

      if (row != k)
      {
         for (j = 0; j <= k; ++j)
         {
            tmpc = y[k][j];
            y[k][j] = y[row][j];
            y[row][j] = tmpc;

            tmpc = cy[k][j];
            cy[k][j] = cy[row][j];
            cy[row][j] = tmpc;
         }

         for (i = 0; i <= k; ++i)
         {
            tmpc = cy[i][k];
            cy[i][k] = cy[i][row];
            cy[i][row] = tmpc;
         }
      }

      // pivot columns

      if (col != k)
      {
         for (i = 0; i <= k; ++i)
         {
            tmpc = y[i][k];
            y[i][k] = y[i][col];
            y[i][col] = tmpc;
         }
      }

      // perform nodal reduction by one

      denom1 = Cdiv (one, y[k][k]);
      denom2 = Cdiv (one, Cconj(y[k][k]));
      for (i = 0; i < k; ++i)
      {
         for (j = 0; j < k; ++j)
         {
            y[i][j] = Csub (y[i][j], Cmultx (3, y[i][k], y[k][j], denom1));
            cy[i][j] = Csub (cy[i][j], Cmultx (3, y[i][k], cy[k][j], denom1));
            cy[i][j] = Csub (cy[i][j], Cmultx (3, cy[i][k], Cconj(y[j][k]), denom2));
            cy[i][j] = Cadd (cy[i][j], Cmultx (5, cy[k][k], y[i][k], Cconj(y[j][k]), denom1, denom2));
         }
      }
   }
}

/*********************************************************************************************/
/*********************************************************************************************/
static int noise_erf (double *p, void *data, double *error, unsigned n_err)
{
   NOISE_OPT *n = (NOISE_OPT *) data;
   double nf;
   COMPLEX nc[4],yp[4];
   unsigned i;

   if (n_err != 1)
      return -1;

   for (i = 0; i < n->n_freqs; ++i)
   {
      nf = calculate_noise_figure (n->y, n->yc, n->params, p[0], p[1], n->temperature, n->gamma[i], n->freqs[i], nc, yp);
      error[0] += fabs (n->nf[i] - nf); //  * (n->nf[i] - nf);
   }

   error[0] /= (double) n->n_freqs;

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static void add_y (COMPLEX **y, COMPLEX yval, unsigned n1, unsigned n2)
{
   y[n1][n1] = Cadd (y[n1][n1], yval);
   y[n1][n2] = Csub (y[n1][n2], yval);
   y[n2][n1] = Csub (y[n2][n1], yval);
   y[n2][n2] = Cadd (y[n2][n2], yval);
}

/*********************************************************************************************/
/*********************************************************************************************/
static double calculate_noise_figure (COMPLEX **y, COMPLEX **cy, double *p, double vv, double ii, double temperature,
                                      COMPLEX gamma_s, double freq, COMPLEX *n_corr, COMPLEX *y_params)
{
   double T1 = temperature / T0;
   COMPLEX zero = {0.0, 0.0};
   double w = 2.0 * acos (-1.0) * freq;
   double rg   = p[0];
   double rs   = p[1];
   double rd   = p[2];
   double ri   = p[3];
   double cgs  = p[4];
   double cgd  = p[5];
   double cds  = p[6];
   double cpg  = p[7];
   double cpd  = p[8];
   double ls   = p[9];
   double lg   = p[10];
   double ld   = p[11];
   double ggs  = p[12];
   double ggd  = p[13];
   double gm   = p[14];
   double tau  = p[15];
   double gds  = p[16];
   double tau2 = p[17];
   double c11  = p[18];
   double c22  = p[19];
   COMPLEX denom, yval;
   unsigned i,j;

   // zero the y-matrix and noise correlation matrix
   for( i=0; i<MATRIX_SIZE; ++i ) {
      for( j=0; j<MATRIX_SIZE; ++j ) {
         y[i][j] = zero;
         cy[i][j] = zero;
      }
   }

   /**** build the small-signal y-matrix ****/

   // port resistance and inductance
   add_y (y, Cnum (0.0, -1. / (w * lg)), 1, 3);
   add_y (y, Cnum (0.0, -1. / (w * ld)), 2, 4);
   add_y (y, Cnum (1. / rg, 0.), 3, 6);
   add_y (y, Cnum (1. / rd, 0.), 4, 7);
   add_y (y, Cnum (rs/(rs*rs + w*w*ls*ls), -w*ls/(rs*rs + w*w*ls*ls)), 5, 0);

   // fringing caps
   add_y (y, Cnum (0., w * cpg), 1, 0);
   add_y (y, Cnum (0., w * cpd), 2, 0);
   add_y (y, Cnum (0., w * c11), 3, 0);
   add_y (y, Cnum (0., w * c22), 4, 0);

   // gate capacitance/conductance
   add_y (y, Cnum (ggd, w * cgd), 6, 7);
   add_y (y, Cnum (ggs, w * cgs), 6, 8);

   // drain-source capacitance/conductance
   add_y (y, Cnum (gds*cos(w*tau2), w*cds - gds*sin(w*tau2)), 5, 7);

   // Ri and transconductance
   add_y (y, Cnum (1.0 / ri, 0.0), 5, 8);
   yval = Cnum (gm*cos(w*tau), -gm*sin(w*tau));
   y[7][6] = Cadd (y[7][6], yval);
   y[7][8] = Csub (y[7][8], yval);
   y[5][6] = Csub (y[5][6], yval);
   y[5][8] = Cadd (y[5][8], yval);

   /**** build the noise correlation matrix ****/

   add_y (cy, Complex (T1 / rg), 3, 6);
   add_y (cy, Complex (T1 / rd), 4, 7);
   add_y (cy, Complex (T1*rs/(rs*rs + w*w*ls*ls)), 5, 0);
   add_y (cy, Complex (T1 * ggs), 6, 8);
   add_y (cy, Complex (T1 * ggd), 6, 7);
   add_y (cy, Complex (ii), 7, 5);
   add_y (cy, Complex (vv / (ri*ri)), 8, 5);

   /**** Solve for the 2-port noise correlation matrix ****/

   noise_matrix_reduction (y, cy, MATRIX_SIZE, 3);

   denom = Complex (1.0 / Cmag2 (y[2][1]));

   n_corr[0] = Cmult (cy[2][2], denom);
   n_corr[1] = Cmult (Csub (Cmult (cy[2][2], Cconj(y[1][1])), Cmult (cy[2][1], Cconj (y[2][1]))), denom);
   n_corr[2] = Cmult (Csub (Cmult (cy[2][2], y[1][1]), Cmult (cy[1][2], y[2][1])), denom);
   n_corr[3] = Csub (Cmult (cy[1][1], Complex (Cmag2 (y[2][1]))), Cmultx (3, cy[1][2], Cconj (y[1][1]), y[2][1]));
   n_corr[3] = Cadd (n_corr[3], Csub (Cmult (cy[2][2], Complex (Cmag2 (y[1][1]))), Cmultx (3, cy[2][1], y[1][1], Cconj (y[2][1]))));
   n_corr[3] = Cmult (n_corr[3], denom);

   y_params[0] = y[1][1];
   y_params[1] = y[1][2];
   y_params[2] = y[2][1];
   y_params[3] = y[2][2];

   return noise_figure (n_corr, gamma_s, 50.0);
}

/*********************************************************************************************/
/*********************************************************************************************/

static int optimize_noise_parameters (double *params, double *nf, double *f_list, COMPLEX *gamma,
    unsigned n_freqs, double temperature, double *vv, double *ii)
{
   NOISE_OPT noise;
   OPT_PARAMETER p[2];
   OPTIMIZE *opt;
   unsigned oflag = OPT_AUTO;
   unsigned i;

   noise.params = params;
   noise.nf = nf;
   noise.gamma = gamma;
   noise.freqs = f_list;
   noise.n_freqs = n_freqs;
   noise.temperature = temperature;

   noise.y = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   noise.yc = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      noise.y[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
      noise.yc[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
   }

   p[0].min = 0.1;
   p[0].nom = 4.0;
   p[0].max = 20.0;
   p[0].tol = 0.0;
   strcpy (p[0].name, "vv");
   p[0].optimize = TRUE;

   p[1].min = 0.01;
   p[1].nom = 0.1;
   p[1].max = 1.0;
   p[1].tol = 0.0;
   strcpy (p[1].name, "ii");
   p[1].optimize = TRUE;

   opt = initialize_cg_optimizer ();
   set_cg_error_function (opt, noise_erf, (void *) &noise, 1, NULL);
   set_cg_parameters (opt, p, 2);
   set_cg_error_fraction (opt, 1.0e-12, 3);

   if (global_flags & BATCH_MODE)
      set_cg_flags (opt, oflag);
   else
      set_cg_flags (opt, oflag | OPT_VERBOSE);

   if (cg_optimize4 (opt, 200, NULL)) {
      log_error( get_cg_error() );
      return 1;
   }

   free ((void *) opt);

   // free memory for y and yc
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      free ((void *) noise.y[i]);
      free ((void *) noise.yc[i]);
   }
   free ((void *) noise.y);
   free ((void *) noise.yc);

   *vv = p[0].nom;
   *ii = p[1].nom;

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
static double associated_gain( COMPLEX *s, COMPLEX gamma )
{
   return 10.0 * log10( calculate_ga(gamma, s, NULL) );
}

/*********************************************************************************************/
/*********************************************************************************************/
static int write_output_file (char *fname, char *hname, double *f_list, double *nf,
                              COMPLEX *gamma_s, unsigned n_freqs, double *p, double vv,
                              double ii, double temperature, BIAS bias)
{
   FILE *file, *infile;
   char string[256];
   COMPLEX n_corr[4], yparams[4], gam;
   POLAR gam_p;
   double f, nfig, fmin, rn, gain;
   COMPLEX zero = {0.0, 0.0};
   unsigned i;
   COMPLEX **y, **cy;

   file = fopen (fname, "w+");
   if (!file)
   {
      sprintf( string, "%s: unable to open file for writing.", fname );
      log_error( string );
      return 1;
   }

   // write the header
   infile = fopen (hname, "r");
   if (infile)
   {
      while (fgets (string, 255, infile))
      {
         if ((string[0] != '!') || !strncmp (string, "!BIAS", 5))
            break;

         fprintf (file, "%s", string);
      }

      fclose (infile);
   }

   // allocate memory
   y = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   cy = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      y[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
      cy[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
   }

   // write modeled vs measured validation info
   fprintf (file, "! Measured vs. Modeled:\n");
   fprintf (file, "! Freq   NF_meas NF_mod Error\n");
   fprintf (file, "! (GHz)   (dB)   (dB)   (dB)\n");
   //                |    | |    | |    | |    |
   for (i = 0; i < n_freqs; ++i)
   {
      nfig = calculate_noise_figure (y, cy, p, vv, ii, temperature, gamma_s[i], f_list[i], n_corr, yparams);
      fprintf (file, "! %6.3f %6.3f %6.3f %6.3f\n", f_list[i]*1.0e-9, nf[i], nfig, nf[i] - nfig);
   }

   // write the noise parameters from 0.5 to 50 GHz
   fprintf (file, "!\n");
   fprintf (file, "! Freq    Fmin     Gamma_Opt       Rn        Vds           Ids           Vgs           Igs              Noise_Params          Gain\n");
   fprintf (file, "!(GHz)    (dB)     Mag    Ang    (Ohms)    (Volts)        (Amps)       (Volts)        (Amps)      <vv*>/4kT0    <ii*>/4kT0    (dB)\n");
   fprintf (file, "!----------------------------------------------------------------------------------------------------------------------------------\n");
   //              |     | |     | |     | |     | |     | |           | |           | |           | |           | |           | |           | |     |

   for (f = 0.5; f < 50.1; f += 0.5)
   {
      nfig = calculate_noise_figure (y, cy, p, vv, ii, temperature, zero, f*1.0e9, n_corr, yparams);
      noise_parameters (n_corr, 50.0, &fmin, &gam_p.m, &gam_p.a, &rn);

      gam = P2C (gam_p);
      gain = associated_gain (y2s (yparams, yparams, 50.0), gam);

      fprintf (file, "%7.3f %7.3f %7.3f %7.2f %7.3f %13.5e %13.5e %13.5e %13.5e %13.5e %13.5e %7.3f\n",
         f, fmin, gam_p.m, gam_p.a, rn, bias.vds, bias.ids, bias.vgs, bias.igs, vv, ii, gain);
   }

   fclose (file);

   // free memory for y and yc
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      free ((void *) y[i]);
      free ((void *) cy[i]);
   }
   free ((void *) y);
   free ((void *) cy);

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/
static int noise_deembed (unsigned flags)
{
   char string[256], noise_file[256];
   char fxa_file[256], fxb_file[256];
   char s_file[256], ns_file[256], out_file[256];
   double f, nf, ga;
   double flist[MAX_FREQS], nf_d[MAX_FREQS], ga_d[MAX_FREQS];
   COMPLEX gamma_s[MAX_FREQS];
   FILE *infile, *outfile;
   unsigned i, n_pts;
   int found;

   printf ("Measured noise figure data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", noise_file);

   printf ("Measured S-parameter data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", s_file);

   printf ("Input error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fxa_file);

   printf ("Output error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fxb_file);

   printf ("Noise source S-parameter file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", ns_file);

   printf ("Output file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", out_file);


    if( read_and_deembed_noise( noise_file, fxa_file, fxb_file, s_file,
        ns_file, MAX_FREQS, ROOM_TEMP, flist, nf_d, ga_d, gamma_s, &n_pts, NULL ) )
        return 1;

   infile = fopen( noise_file, "r" );
   if( !infile ) {
      sprintf( string, "%s: unable to open file.", noise_file );
      log_error( string );
      return 1;
   }

   outfile = fopen( out_file, "w+" );
   if( !outfile ) {
      sprintf( string, "%s: unable to open file for writing.", out_file );
      log_error( string );
      return 1;
   }

   while( fgets( string, 255, infile ) ) {
      if( string[0] == '!' )
         fprintf( outfile, "%s", string );
      else if( sscanf(string, "%lf%lf%lf", &f, &ga, &nf) == 3 ) {
          found = 0;
          for( i=0; i<n_pts; ++i ) {
              if( f == flist[i] ) {
                  fprintf( outfile, "%.4e %+.4e %+.4e\n", flist[i], ga_d[i], nf_d[i] );
                   found = 1;
                   break;
              }
          }
          if( ! found ) {
              fprintf( outfile, "*%s", string );
          }
      }
   }

   fclose (infile);
   fclose (outfile);

   return 0;
}

