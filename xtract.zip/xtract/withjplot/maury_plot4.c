#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <jplot.h>

#define MAXCOLS        30
#define MAXSWEEPSIZE   100
#define MAXNAMELENGTH  40
#define MAXPOINTS      200

#define SWEEP_PLAN_FILE   1
#define LOAD_PULL_FILE    2
#define SOURCE_PULL_FILE  3

#define RI_get_mag(r,i)    (sqrt((r)*(r) + (i)*(i)))
#define RI_get_ang(r,i)    (atan2(i,r)*180.0/acos(-1.0))

typedef struct
{
   struct
   {
      double real,imag;
   } src,load;
   double data[MAXCOLS];
} LP_DATA;

static int parse_line (char *string, double *lpdata, int num_cols);
static int interpolate_data (double lpdata[][MAXSWEEPSIZE], int npts, int ncols,
                             int type, int col, double value, double *values);
void plot_data (int device, char *fname, LP_DATA *lpdata, int szlpdata, int *cols, char **col_names,
                int szcols, char *header, double freq);

/*********************************************************************************/                
/*********************************************************************************/                

int main (int argc, char *argv[])
{
   char file_name[256],string[256];
   char col_names[MAXCOLS][MAXNAMELENGTH+1];
   char *col_names_ptr[MAXCOLS];
   static char sep_chars[] = " !\n";
   char *ptr;
   char header[1024];
   int num_cols = 0;
   int plot_cols = 0;
   int columns[MAXCOLS];
   int file_type = 0;
   FILE *infile;
   LP_DATA lp_data[MAXPOINTS];
   int lp_data_count = 0;
   double freq = 0.0;
   int i;
   int device = 1;
   char pfname[256];

   file_name[0] = 0;
   pfname[0] = 0;

   // parse the command line

   for (i = 1; i < argc; ++i)
   {
      if (!strcmp (argv[i],"-h"))
      {
         printf ("\n");
         printf ("USAGE:  maury_plot4 [options] [file]\n---------------------------------------------------------------------------\noptions:\n");
         printf ("   -dP    send the plots to a postscript file\n");
         printf ("   -dM    send the plots to metafiles (one per file)\n");
         printf ("\n");
         return 0;
      }
      else if (!strcmp (argv[i],"-dP") || !strcmp (argv[i],"-dp"))
         device = POSTSCRIPT;
      else if (!strcmp (argv[i],"-dM") || !strcmp (argv[i],"-dm"))
         device = METAFILE;
      else if (i == (argc-1))
         strcpy (file_name,argv[i]);
   }

   if (!file_name[0])
   {
      printf ("Maury data file name?\n");
      fgets (string,255,stdin);
      sscanf (string,"%255s",file_name);
   }

   // determine the file type

   if (strstr (file_name,".spl"))
      file_type = SWEEP_PLAN_FILE;
   else if (strstr (file_name,".lp"))
      file_type = LOAD_PULL_FILE;
   else if (strstr (file_name,".sp"))
      file_type = SOURCE_PULL_FILE;
   else
   {
      printf ("Unknown file type!\n");
      return -1;
   }

   if (file_type == SWEEP_PLAN_FILE)
   {
      double data[MAXCOLS][MAXSWEEPSIZE];
      double linedata[MAXCOLS];
      int interp_type = 0;
      int interp_col = -1;
      char *interp_name;
      double interp_value;
      int n_pts = 0;

      printf ("Data interpolation mode:\n");
      printf ("  1 - Available input power\n");
      printf ("  2 - Delivered input power\n");
      printf ("  3 - Output power level\n");
      printf ("  4 - Gain Compression\n");
      fgets (string,255,stdin);
      sscanf (string,"%d",&interp_type);

      switch (interp_type)
      {
      case 1:
         printf ("Available input power level (dBm)?\n");
         fgets (string,255,stdin);
         sscanf (string,"%lf",&interp_value);
         interp_name = "Pin_avail_dBm";
         break;

      case 2:
         printf ("Delivered input power level (dBm)?\n");
         fgets (string,255,stdin);
         sscanf (string,"%lf",&interp_value);
         interp_name = "Pin_deliv_dBm";
         break;

      case 3:
         printf ("Output power level (dBm)?\n");
         fgets (string,255,stdin);
         sscanf (string,"%lf",&interp_value);
         interp_name = "Pout_dBm";
         break;

      case 4:
         printf ("Gain compression (dB)?\n");
         fgets (string,255,stdin);
         sscanf (string,"%lf",&interp_value);

         if (interp_value <= 0.0)
         {
            printf ("Gain compression must be greater than 0!\n");
            return -1;
         }

         printf ("Gain type for compression calculation:\n");
         printf ("  1 - Gt (transducer gain) - default\n");
         printf ("  2 - Gp (power gain)\n");
         fgets (string,255,stdin);
         sscanf (string,"%d",&i);
         if (i == 2)
            interp_name = "Gp_dB";
         else
            interp_name = "Gt_dB";
         break;

      default:
         printf ("Invalid interpolation mode!\n");
         return -1;
      }

      infile = fopen (file_name,"r");
      if (!infile)
      {
         printf ("ERROR: cannot open file \"%s\"\n",file_name);
         return -1;
      }

      printf ("Reading data file...\n");

      while (fgets (string,255,infile))
      {
         if (!strncmp (string,"Frequency range:",16))
            sscanf (string,"Frequency range: %lf",&freq);

         if (!strncmp (string,"Gamma_dut:",10))
         {
            sscanf (strstr (string,"Source"),"Source = (%lf %lf)",
               &lp_data[lp_data_count].src.real,&lp_data[lp_data_count].src.imag);
            sscanf (strstr (string,"Load"),"Load = (%lf %lf)",
               &lp_data[lp_data_count].load.real,&lp_data[lp_data_count].load.imag);

            if (!fgets (string,255,infile))
            {
               printf ("Incomplete file!\n");
               fclose (infile);
               return -1;
            }

            // get the names of all the columns

            ptr = strtok (string,sep_chars);
            do {
               if (num_cols >= MAXCOLS)
                  break;

               strncpy (col_names[num_cols],ptr,MAXNAMELENGTH);
               col_names[num_cols][MAXNAMELENGTH] = 0;

               ++num_cols;
            }
            while (ptr = strtok (NULL,sep_chars));

            break;
         }
      }

      // check for valid columns

      for (i = 0; i < num_cols; ++i)
      {
         if (!strcmp (col_names[i],interp_name))
            interp_col = i;
      }

      if (interp_col < 0)
      {
         printf ("Column \'%s\' is missing!\n",interp_name);
         fclose (infile);
         return -1;
      }

      // read in the data for each sweep and interpolate it

      while (fgets (string,255,infile))
      {
         if (!strncmp (string,"Gamma_dut:",10))
         {
            // do the interpolation
            if (interpolate_data (data, n_pts, num_cols, interp_type, interp_col, interp_value, lp_data[lp_data_count].data))
               ++lp_data_count; 

            // read in the new gammas
            sscanf (strstr (string,"Source"),"Source = (%lf %lf)",
               &lp_data[lp_data_count].src.real,&lp_data[lp_data_count].src.imag);
            sscanf (strstr (string,"Load"),"Load = (%lf %lf)",
               &lp_data[lp_data_count].load.real,&lp_data[lp_data_count].load.imag);

            // reset the data counter
            n_pts = 0;
         }

         if (parse_line (string, linedata, num_cols))
         {
            for (i = 0; i < num_cols; ++i)
               data[i][n_pts] = linedata[i];
            ++n_pts;
         }
      }

      // do the interpolation
      if (interpolate_data (data, n_pts, num_cols, interp_type, interp_col, interp_value, lp_data[lp_data_count].data))
         ++lp_data_count;

      fclose (infile);

      // create the header info

      sprintf (header, "File Name:\n %s\n\n",file_name);

      if ((lp_data[0].load.real != lp_data[1].load.real) || (lp_data[0].load.imag != lp_data[1].load.imag))
      {
         sprintf (string, "Data Type:\n Sweep Plan - Load Pull\n\nSource Gamma:\n R/I - ( %6.3f , %6.3f )\n M/A - ( %6.3f < %6.1f )\n\n",
            lp_data[0].src.real, lp_data[0].src.imag,
            RI_get_mag (lp_data[0].src.real, lp_data[0].src.imag),
            RI_get_ang (lp_data[0].src.real, lp_data[0].src.imag));      
      }
      else
      {
         sprintf (string,"Data Type:\n Sweep Plan - Source Pull\n\nLoad Gamma:\n R/I - ( %6.3f , %6.3f )\n M/A - ( %6.3f < %6.1f )\n\n",
            lp_data[0].load.real, lp_data[0].load.imag,
            RI_get_mag (lp_data[0].load.real, lp_data[0].load.imag),
            RI_get_ang (lp_data[0].load.real, lp_data[0].load.imag));      
      }
      strcat (header, string);

      sprintf (string, "Frequency: %.3f GHz\n", freq);
      strcat (header, string);

      switch (interp_type)
      {
      case 1:
         sprintf (string, "Available Power: %.2f dBm\n", interp_value);
         break;
      case 2:
         sprintf (string, "Delivered Power: %.2f dBm\n", interp_value);
         break;
      case 3:
         sprintf (string, "Output Power: %.2f dBm\n", interp_value);
         break;
      case 4:
         if (!strcmp (interp_name, "Gp_dB"))
            sprintf (string, "Compression (using Gp): %.2f dB\n", interp_value);
         else
            sprintf (string, "Compression (using Gt): %.2f dB\n", interp_value);
         break;
      }
      strcat (header, string);

      sprintf (string, "Data Point Count: %d", lp_data_count);
      strcat (header, string);
   }

   else  // source or load pull data file type
   {
      double fixed_x,fixed_y;
      double data[MAXCOLS];

      printf ("Reading data file...\n");

      infile = fopen (file_name,"r");
      if (!infile)
      {
         printf ("ERROR: cannot open file \"%s\"\n",file_name);
         return -1;
      }

      // read the header information
      while (fgets (string, 255, infile))
      {
         if (!strncmp (string, "Frequency", 9))
            sscanf (string, "Frequency %lf",&freq);
         else if (!strncmp (string, "Pin_avail_src", 13))
         {
            if (file_type == SOURCE_PULL_FILE)
               sscanf (strstr (string, "Gamma_load:"), "Gamma_load: %lf %lf", &fixed_x, &fixed_y);
            else
               sscanf (strstr (string, "Gamma_source:"), "Gamma_source: %lf %lf", &fixed_x, &fixed_y);

            if (!fgets (string,255,infile))
            {
               printf ("Incomplete file!\n");
               fclose (infile);
               return -1;
            }

            // get the names of all the columns

            ptr = strtok (string,sep_chars);
            i = 0;
            do {
               if (num_cols >= MAXCOLS)
                  break;

               if (i > 1)
               {
                  strncpy (col_names[num_cols],ptr,MAXNAMELENGTH);
                  col_names[num_cols][MAXNAMELENGTH] = 0;

                  ++num_cols;
               }

               ++i;
            }
            while (ptr = strtok (NULL,sep_chars));

            break;
         }
      }

      // read in the data

      while (fgets (string,255,infile))
      {
         if (parse_line (string, data, num_cols+2))
         {
            if (file_type == SOURCE_PULL_FILE)
            {
               lp_data[lp_data_count].load.real = fixed_x;
               lp_data[lp_data_count].load.imag = fixed_y;
               lp_data[lp_data_count].src.real = data[0];
               lp_data[lp_data_count].src.imag = data[1];
            }
            else
            {
               lp_data[lp_data_count].src.real = fixed_x;
               lp_data[lp_data_count].src.imag = fixed_y;
               lp_data[lp_data_count].load.real = data[0];
               lp_data[lp_data_count].load.imag = data[1];
            }

            for (i = 2; i < (num_cols+2); ++i)
               lp_data[lp_data_count].data[i-2] = data[i];

            ++lp_data_count;
         }
      }               

      // create the header info

      sprintf (header, "File Name:\n %s\n\n",file_name);

      if (file_type == SOURCE_PULL_FILE)
      {
         sprintf (string,"Data Type:\n Source Pull\n\nLoad Gamma:\n R/I - ( %6.3f , %6.3f )\n M/A - ( %6.3f < %6.1f )\n\n",
            lp_data[0].load.real, lp_data[0].load.imag,
            RI_get_mag (lp_data[0].load.real, lp_data[0].load.imag),
            RI_get_ang (lp_data[0].load.real, lp_data[0].load.imag));      
      }
      else
      {
         sprintf (string, "Data Type:\n Load Pull\n\nSource Gamma:\n R/I - ( %6.3f , %6.3f )\n M/A - ( %6.3f < %6.1f )\n\n",
            lp_data[0].src.real, lp_data[0].src.imag,
            RI_get_mag (lp_data[0].src.real, lp_data[0].src.imag),
            RI_get_ang (lp_data[0].src.real, lp_data[0].src.imag));      
      }
      strcat (header, string);

      sprintf (string, "Frequency: %.3f GHz\nAvailable Input Power: %.2f dBm\nData Point Count: %d",
         freq,lp_data[0].data[2],lp_data_count);
      strcat (header, string);       
   }  

   // do the plots

   if (lp_data_count < 1)
   {
      printf ("No data!\n");
      return -1;
   }

   printf ("Data columns to plot:\n");
   for (i = 0; i < num_cols; ++i)
      printf ("  %-2d - %s\n",i+1,col_names[i]);
   printf ("(separate by spaces)\n");
   fgets (string,255,stdin);

   ptr = strtok (string,sep_chars);
   do {
      if (plot_cols >= MAXCOLS)
         break;

      i = 0;
      sscanf (ptr,"%d",&i);

      if ((i > 0) && (i <= num_cols))
      {
         columns[plot_cols] = i-1;
         col_names_ptr[plot_cols] = col_names[i-1];
         ++plot_cols;
      }
   }
   while (ptr = strtok (NULL, sep_chars));

   if ((device != 1) && !pfname[0])
   {
      printf ("Plot file name?\n");
      fgets (string,255,stdin);
      sscanf (string,"%s",pfname);
   }

   plot_data (device, pfname, lp_data, lp_data_count, columns, col_names_ptr, plot_cols, header, freq);

   return 0;
}

/*********************************************************************************/                
/*********************************************************************************/                

static int parse_line (char *string, double *lpdata, int num_cols)
{
   int       i;
   char      *str,*str1;

   str1 = string;

   for (i = 0; i < num_cols; ++i)
   {
      lpdata[i] = strtod (str1,&str);
      if (str1 == str)
         return 0;

      str1 = str;
   }

   return 1;
}

/*********************************************************************************/                
/*********************************************************************************/                

static int interpolate_data (double lpdata[][MAXSWEEPSIZE], int npts, int ncols,
                             int type, int col, double value, double *values)
{
   int index = 0;
   int i;
   double factor = 0.0;

   if (npts < 1)
      return 0;
   else if (npts == 1)
   {
      if ((lpdata[col][0] == value) && (type != 4))
      {
         for (i = 0; i < ncols; ++i)
            values[i] = lpdata[i][0];
         return 1;
      }
      else
         return 0;
   }

   if (type == 4)  // gain compression interpolation
   {
      double gain;

      // find the maximum gain
      gain = lpdata[col][0];
      for (i = 1; i < npts; ++i)
      {
         if (lpdata[col][i] > gain)
         {
            gain = lpdata[col][i];
            index = i;
         }
      }

      gain -= value;

      // check to see if we can do a valid interpolation
      if (gain < lpdata[col][npts-1])
         return 0;

      // determine the interpolation factor
      for (i = index; i < (npts-1); ++i)
      {
         if ((gain <= lpdata[col][i]) && (gain >= lpdata[col][i+1]))
         {
            index = i;
            factor = (gain - lpdata[col][index]) / (lpdata[col][index+1] - lpdata[col][index]);
            break;
         } 
      }
   }
   else
   {
      // check to see if we can do a valid interpolation
      if ((value < lpdata[col][0]) || (value > lpdata[col][npts-1]))
         return 0;

      // determine the interpolation factor
      for (i = 0; i < (npts-1); ++i)
      {
         if ((value >= lpdata[col][i]) && (value <= lpdata[col][i+1]))
         {
            index = i;
            factor = (value - lpdata[col][index]) / (lpdata[col][index+1] - lpdata[col][index]);
            break;
         } 
      }
   }

   // interpolate the data
   for (i = 0; i < ncols; ++i)
      values[i] = lpdata[i][index] + (lpdata[i][index+1] - lpdata[i][index])*factor;

   // check to make sure we interpolated correctly
   if (type != 4)
   {
      if (fabs (values[col] - value) > 0.001*value)
         return 0;
   }

   return 1; 
}

/*********************************************************************************/                
/*********************************************************************************/                

void plot_data (int device, char *fname, LP_DATA *lpdata, int szlpdata, int *cols, char **col_names,
                int szcols, char *header, double freq)
{
   jPLOT_ITEM *plot;
   double *x,*y,*d;
   int src_pull = 0;
   jHANDLE title,min_block,max_block;
   char max_text[500];
   char min_text[500];
   int min_index, max_index;
   double min,max,real,imag;
   double min_x,min_y,max_x,max_y;
   double y_real,y_imag;
   int i,j;

   if (szlpdata < 2)
   {
      printf ("Not enough data to plot!\n");
      return;
   }
   else if (szcols < 1)
   {
      printf ("No data columns selected!\n");
      return;
   }

   if (!open_graphics_device (device, fname))
   {
      printf ("ERROR: %s\n",get_error_message (ERROR_NUMBER));
      return;
   }

   if ((lpdata[0].load.real != lpdata[1].load.real) || (lpdata[0].load.imag != lpdata[1].load.imag))
      src_pull = 0;
   else
      src_pull = 1;

   // create the smith chart and attach the data vectors   

   x = (double *) malloc (sizeof (double)*szlpdata);
   y = (double *) malloc (sizeof (double)*szlpdata);
   d = (double *) malloc (sizeof (double)*szlpdata);   

   plot = create_plot_item (SmithContour, 3.75, 4.25, 2.75, 0.0);

   // create the page border
   add_line (0.5, 0.5, 0.5, 8.0, LT_SOLID, 2, CLR_BLACK);
   add_line (0.5, 8.0, 10.5, 8.0, LT_SOLID, 2, CLR_BLACK);
   add_line (10.5, 8.0, 10.5, 0.5, LT_SOLID, 2, CLR_BLACK);
   add_line (0.5, 0.5, 10.5, 0.5, LT_SOLID, 2, CLR_BLACK);
   add_line (7.0, 0.5, 7.0, 8.0, LT_SOLID, 1, CLR_BLACK);

   // attach the header information
   add_text (header, 7.1, 7.0, FNT_HELVETICA, 12, LEFT_JUSTIFY, 0.0, CLR_BLACK, NO_STYLE);

   // draw the plots

   for (i = 0; i < szcols; ++i)
   {
      min_index = max_index = 0;
      min = max = lpdata[0].data[cols[i]];
      for (j = 0; j < szlpdata; ++j)
      {
         if (src_pull)
         {
            x[j] = lpdata[j].src.real;
            y[j] = lpdata[j].src.imag;
         }
         else
         {
            x[j] = lpdata[j].load.real;
            y[j] = lpdata[j].load.imag;
         }
         d[j] = lpdata[j].data[cols[i]];

         // find the min and max of the data
         if (lpdata[j].data[cols[i]] < min)
         {
            min = lpdata[j].data[cols[i]];
            min_index = j;
         }
         else if (lpdata[j].data[cols[i]] > max)
         {
            max = lpdata[j].data[cols[i]];
            max_index = j;
         }
      }

      if (src_pull)
      {
         real = lpdata[max_index].src.real;
         imag = lpdata[max_index].src.imag;
      }
      else
      {
         real = lpdata[max_index].load.real;
         imag = lpdata[max_index].load.imag;
      }
      max_x = real;
      max_y = imag;
      y_real = 0.02 * (1.0 - real*real - imag*imag) / ((1.0 + real) * (1.0 + real) + imag*imag);
      y_imag = -0.04 * imag / ((1.0 + real) * (1.0 + real) + imag*imag);

      sprintf (max_text, "Maximum = %.3f\n R/I - ( %6.3f , %6.3f )\n M/A - ( %6.3f < %6.1f )\n Rshunt = %.2f ohms\n Cshunt = %.2f pF",
         max, real, imag, RI_get_mag (real, imag), RI_get_ang (real, imag),
         1.0 / y_real, 500.0 * y_imag / (acos(-1.0) * freq));

      if (src_pull)
      {
         real = lpdata[min_index].src.real;
         imag = lpdata[min_index].src.imag;
      }
      else
      {
         real = lpdata[min_index].load.real;
         imag = lpdata[min_index].load.imag;
      }
      min_x = real;
      min_y = imag;
      y_real = 0.02 * (1.0 - real*real - imag*imag) / ((1.0 + real) * (1.0 + real) + imag*imag);
      y_imag = -0.04 * imag / ((1.0 + real) * (1.0 + real) + imag*imag);

      sprintf (min_text, "Minimum = %.3f\n R/I - ( %6.3f , %6.3f )\n M/A - ( %6.3f < %6.1f )\n Rshunt = %.2f ohms\n Cshunt = %.2f pF",
         min, real, imag, RI_get_mag (real, imag), RI_get_ang (real, imag),
         1.0 / y_real, 500.0 * y_imag / (acos(-1.0) * freq));

      // attach the contour data
      attach_contourdata (plot, x, y, d, szlpdata, LT_SOLID, 2, CLR_RED, PNT_PLUS, CLR_BLACK);

      // attach the min and max data points
      attach_polardata (plot, &max_x, &max_y, 1, PNT_CIRCLE, 4, CLR_BLUE);
      attach_polardata (plot, &min_x, &min_y, 1, PNT_CIRCLE, 4, CLR_DARKGREEN);

      // create the min and max text blocks
      max_block = add_text (max_text, 7.1, 3.0, FNT_HELVETICA, 12, LEFT_JUSTIFY, 0.0, CLR_BLUE, NO_STYLE);
      min_block = add_text (min_text, 7.1, 1.8, FNT_HELVETICA, 12, LEFT_JUSTIFY, 0.0, CLR_DARKGREEN, NO_STYLE);

      // create the plot title
      title = add_text (col_names[i], 8.0, 7.5, FNT_HELVETICA, 16, LEFT_JUSTIFY, 0.0, CLR_BLACK, NO_STYLE); 

      if (!draw_page ())
      {
         printf ("ERROR: %s\n",get_error_message (ERROR_NUMBER));
         free ((void *) x);
         free ((void *) y);
         free ((void *) d);
         return;
      }

      detach_data (plot);
      remove_user_item (title);
      remove_user_item (min_block);
      remove_user_item (max_block);
   }

   free ((void *) x);
   free ((void *) y);
   free ((void *) d);   
   close_graphics_device ();
}
