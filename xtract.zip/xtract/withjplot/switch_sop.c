#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize4.h"
#include "jplot.h"
#include "fit_tools.h"

#define BOLTZ         1.3806226e-23
#define CHARGE        1.6021918e-19
#define STDTEMP       300.0
#define THERMAL_V     ((BOLTZ*STDTEMP)/CHARGE)

#define MAX_BIAS_PTS    200
#define MAX_IV_PTS      1000
#define MAX_DIODE_PTS   50

// gate capactiance options
#define USE_BOTH    0
#define USE_CGD     1
#define USE_CGS     2

// plot definitions
#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_DOTTED
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN
#define PLOT_X        1.25
#define PLOT_Y        1.25
#define PLOT_XSIZE    6.0
#define PLOT_YSIZE    5.5

/* correct for the impact of Rd and Rs on channel conductance */
#define correct_for_contact_resistance
#define R_CONTACT   0.2


/* ----------- STRUCTURE DEFS ------------ */

typedef struct
   {
   double vgs,cgs,cgd;
   } CapacitanceData;

typedef struct
   {
   CapacitanceData *data;
   unsigned n;
   double cgs0;
   int option;
   } CapacitanceOptimize;

typedef struct
   {
   IV_DATA *gds_data, *knee_data;
   unsigned n_gds, n_knee;
   } IVOptimize;

typedef struct
   {
   IV_DATA *data;
   unsigned n;
   } VbrOptimize;

typedef struct
   {
   double rg,rd,rs;
   double lg,ld,ls;
   double area,ugw,ngf;
   double is,n;
   double cgg0,cds;
   double ibr,vbr;
   double ileak,vleak;
   int option;
   } FixedParams;

/* -------- FUNCTION PROTOTYPES ---------- */

static int write_starting_files (char *inname, char *startname);
static int get_model_parameters (char *dscr_file, FixedParams *fixed, CapacitanceData *cap_data, unsigned max_pts, unsigned *cap_pts);
static int write_output_files (char *end_file, char *mod_file, char *head_file, MODEL_PARAMS *p, FixedParams fixed);

static int fit_gate_capacitance (CapacitanceData *data, unsigned npts, MODEL_PARAMS *p, unsigned iter, FixedParams *fixed, jPLOT_ITEM **plot);
static int fit_drain_conductance (char *iv_file, MODEL_PARAMS *p, double max_vds, unsigned iter, FixedParams *fixed, jPLOT_ITEM **gds_plot, jPLOT_ITEM **knee_plot);
static int fit_forward_iv (char *fwd_iv_file, FixedParams *fixed, jPLOT_ITEM **plot);
static int fit_reverse_breakdown (char *vbr_file, unsigned niter, FixedParams *fixed, jPLOT_ITEM **plot);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);
static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

/****************************************************************************/
/****************************************************************************/
/*                                  MAIN                                    */
/****************************************************************************/
/****************************************************************************/

int main (int argc, char *argv[])
   {
   int i;
   unsigned num_cap_pts;
   double max_vds;
   char string[200];
   char dscr_file[100];
   char start_file[100];
   char end_file[100];
   char model_file[100];
   char dc_iv_file[100];
   char fwd_iv_file[100];
   char vbr_iv_file[100];
   MODEL_PARAMS *params;
   CapacitanceData cap_data[MAX_BIAS_PTS];
   FixedParams fixed;
   jPLOT_ITEM *cap_plot = NULL, *gds_plot = NULL, *knee_plot = NULL;
   jPLOT_ITEM *fwd_plot = NULL, *rev_plot = NULL;
   int plot_dev = X_WINDOWS;
   unsigned niter;

   fixed.option = USE_CGS;
   fixed.option = USE_BOTH;

   /************ Parse Command Line ***************/

   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\nThe following command line switches are supported:\n");
         printf ("----------------------------------------------------------------------------------------\n");
         printf ("  -d0       Suppress graphics output.\n");
         printf ("  -dP,-dp   Sets the graphics device to postscript.");
         printf ("  -dM,-dm   Sets the graphics device to metafile.");
         printf ("  -i,-e     Write a default input file named \"switchin\" and a starting values\n");
         printf ("              file named \"switch.start\"\n");
         printf ("\n\n");
         return 0;
         }

      else if (!strncmp (argv[i],"-e",2) || !strncmp (argv[i],"-i",2))
         {
         write_starting_files ("switchin", "switch.start");
         return 0;
         }

      else if (!strncmp (argv[i],"-d",2))
         {
         char ch;
         sscanf (argv[i],"-d%c", &ch);
         if ((ch == 'p') || (ch == 'P'))
            plot_dev = POSTSCRIPT;
         else if ((ch == 'm') || (ch == 'M'))
            plot_dev = METAFILE;
         else if (ch == '0')
            plot_dev = 0;
         }

      else if (!strncmp (argv[i], "-cgs", 4))
         fixed.option = USE_CGS;

      else if (!strncmp (argv[i], "-cgd", 4))
         fixed.option = USE_CGD;

      }

   /************ Get Information ***************/

   printf ("DSCR file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", dscr_file);

   printf ("DC I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", dc_iv_file);

   printf ("Forward I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", fwd_iv_file);

   printf ("Breakdown I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", vbr_iv_file);

   printf ("Start parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", end_file);

   printf ("Output model file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", model_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,199,stdin);
   sscanf (string, "%lf", &max_vds);

   printf ("Maximum number of line searches?\n");
   fgets (string,199,stdin);
   sscanf (string, "%u", &niter);

   /************** Initialization ******************/

   printf ("Initializing...\n");

   if (read_model_parameters_from_file (start_file, &params, NULL))
      return 1;

   if (get_model_parameters (dscr_file, &fixed, cap_data, MAX_BIAS_PTS, &num_cap_pts))
      {
      printf ("Error in get_model_parameters().\n");
      return 1;
      }

   /************ Gate Capacitance fit ****************/

   printf ("Fitting gate capacitance...\n");

   if (fit_gate_capacitance (cap_data, num_cap_pts, params, niter, &fixed, &cap_plot))
      {
      printf ("Error in fit_gate_capacitance().\n");
      return -1;
      }

   /************ Drain Conductance fit ***************/

   printf ("Fitting drain conductance...\n");

   if (fit_drain_conductance (dc_iv_file, params, max_vds, niter, &fixed, &gds_plot, &knee_plot))
      {
      printf ("Error in fit_drain_conductance().\n");
      return -1;
      }

   /************** Forward Diode fit ******************/

   printf ("Fitting forward gate diode...\n");

   if (fit_forward_iv (fwd_iv_file, &fixed, &fwd_plot))
      {
      printf ("Error in fit_forward_iv().\n");
      return 1;
      }

   /************** Reverse Diode Fit ******************/

   printf ("Fitting reverse gate diode...\n");

   if (fit_reverse_breakdown (vbr_iv_file, (niter ? 50 : 0), &fixed, &rev_plot)) {
      printf ("Waring: error in fit_reverse_breakdown(). Breakdown parameters may not be correct.\n");
   }

   /************** Write output files *****************/

   printf ("Writing data to disc...\n");

   if (write_output_files (end_file, model_file, dc_iv_file, params, fixed))
      printf ("Error in write_output_files().\n");

   /***************** Plot data ***********************/

   if (plot_dev)
      {
      jPLOT_ITEM *plot_list[10];
      char plot_head[3000];
      FILE *file;

      printf ("Generating plots...\n");

      plot_head[0] = 0;

      // get the plot header

      file = fopen (fwd_iv_file, "r");
      if (file)
         {
         while (fgets (string, 255, file))
            {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
            }

         fclose (file);
         }

      plot_list[0] = cap_plot;
      plot_list[1] = gds_plot;
      plot_list[2] = knee_plot;
      plot_list[3] = fwd_plot;
      plot_list[4] = rev_plot;

      if (plot_data (plot_dev, plot_head, plot_list, 5))
         return 1;
      }

   printf ("Done.\n\n");

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                              DATA FILE I/O                               */
/****************************************************************************/
/****************************************************************************/

static int write_starting_files (char *inname, char *startname)
   {
   FILE *file;
   unsigned i;
   OPT_PARAMETER p[] = {
      {0.05, 0.1, 0.4, 0.0, "CT0", 0},
      {5.0, 30.0, 100.0, 0.0, "CT1", 0},
      {-1.3, -1.0, -0.8, 0.0, "CT2", 0},
      {0.1, 0.7, 1.0, 0.0, "CE0", 0},
      {1.0, 3.0, 5.0, 0.0, "CE1", 0},
      {-0.6, -0.3, 0.1, 0.0, "CE2", 0},
      {0.1, 0.2, 1.0, 0.0, "IDS0", 0},
      {1.0, 15.0, 30.0, 0.0, "IDS1", 0},
      {-2.0, 0.0, 1.0, 0.0, "IDS2", 0},
      {0.1, 0.2, 1.0, 0.0, "IDS3", 0},
      {1.0, 3.0, 10.0, 0.0, "IDS4", 0}
      };

   if (startname)
      {
      file = fopen (startname, "w+");
      if (!file)
         {
         printf ("Unable to create starting values file.\n");
         return 1;
         }

      fprintf (file, "! auto-generated starting values file\n");

      for (i = 0; i < 11; ++i)
         {
         fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max,
            p[i].tol, p[i].name);
         }
      fclose (file);
      }

   if (inname)
      {
      file = fopen (inname, "w+");
      if (!file)
         {
         printf ("Unable to create input file.\n");
         return 1;
         }

      fprintf (file, "model.dscr              # DSCR file name\n");
      fprintf (file, "sdc.iv                  # DC IV data file name\n");
      fprintf (file, "sfwd.iv                 # Forward IV data file name\n");
      fprintf (file, "svbr.iv                 # Breakdown IV data file name\n");
      fprintf (file, "switch.end              # Starting parameters file name\n");
      fprintf (file, "switch.end              # Finishing parameters file to write\n");
      fprintf (file, "switch.model            # Model file to write\n");
      fprintf (file, "6                       # Maximum Vds for DC IV fit\n");
      fprintf (file, "500                     # Maximum number of optimization line searches\n");

      fclose (file);
      }

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int get_model_parameters (char *dscr_file, FixedParams *fixed, CapacitanceData *cap_data, unsigned max_pts, unsigned *cap_pts)
   {
   FILE *file;
   unsigned i = 0,j;
   char string[400];
   double area,rg,rd,rs,ri,vds,vgs,ids,igs;
   double cgs,cgd,cds,ls,lg,ld,ugw,ngf,c11,c22;
   double last_vgs = 1e6;
   CapacitanceData cap_tmp;
   double cds_diff;

   *cap_pts = 0;

   file = fopen (dscr_file, "r");
   if (!file)
      {
      printf ("Unable to open dscr file - %s\n", dscr_file);
      return -1;
      }

   // read the dscr file

   while (fgets (string, 399, file))
      {
      if (string[0] == '!')
         continue;
      else if (sscanf (string,"%*f%lf%lf%lf%lf%lf%*f%lf%lf%lf%lf%lf%lf%lf%lf%lf%*f%*f%lf%lf%lf%*f%*f%*f%*f%*f%*f%lf%lf",
         &area,&ugw,&ngf,&vds,&ids,&vgs,&igs,&rg,&rs,&rd,&ri,&cgs,&cgd,&cds,&ls,&lg,&ld,&c11,&c22) == 19)
         {
         if (fabs (vds) > 0.001)
            continue;
         else if (vgs < last_vgs)
            {
            last_vgs = vgs;
            fixed->area = area * 1000.0;
            fixed->ugw = ugw;
            fixed->ngf = ngf;
            fixed->rg = rg;
            fixed->rd = rd;
            fixed->rs = rs;
            fixed->ls = ls * 1.0e-12;
            fixed->lg = lg * 1.0e-12;
            fixed->ld = ld * 1.0e-12;
            fixed->cds = (cds + c22) * 1.0e-12;
            }

         if (*cap_pts >= max_pts)
            break;

         cds_diff = cds + c22 - fixed->cds;
         if (cds_diff < 0.0)
            cds_diff = 0.0;

         // turn this off for now
         cds_diff = 0.0;

         cap_data[*cap_pts].cgs = (cgs + c11 + 2.0*cds_diff) * 1.0e-12;
         cap_data[*cap_pts].cgd = (cgd + 2.0*cds_diff) * 1.0e-12;
         cap_data[*cap_pts].vgs = vgs;
         (*cap_pts)++;
         }
      }

   fclose (file);

   // sort the capacitance data for ascending vgs
   for (i = 0; i < (*cap_pts) - 1; ++i)
      {
      for (j = i+1; j < (*cap_pts); ++j)
         {
         if (cap_data[j].vgs < cap_data[i].vgs)
            {
            cap_tmp = cap_data[i];
            cap_data[i] = cap_data[j];
            cap_data[j] = cap_tmp;
            }
         }
      }
   for (i = 0; i < (*cap_pts) ; ++i)
       {
       printf (" Vgs Cgs Cgd: %4e %4e %4e\n", cap_data[i].vgs, cap_data[i].cgs, cap_data[i].cgd);
       }

   // force ls and ld to be symmetric
   fixed->ls = fixed->ld;

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int write_output_files (char *end_file, char *mod_file, char *head_file, MODEL_PARAMS *p, FixedParams fixed)
   {
   FILE *infile,*outfile;
   char string[201];
   char *names[50];
   double values[50];
   unsigned n = 0;
   MODEL_PARAMS *ptr;

   // set up the model parameter list
   names[n] = "area"; values[n] = fixed.area; ++n;
   names[n] = "ugw"; values[n] = fixed.ugw; ++n;
   names[n] = "ngf"; values[n] = fixed.ngf; ++n;
   names[n] = "is"; values[n] = fixed.is; ++n;
   names[n] = "n"; values[n] = fixed.n; ++n;
   names[n] = "ibd"; values[n] = fixed.ibr; ++n;
   names[n] = "vbd"; values[n] = fixed.vbr; ++n;
   names[n] = "ileak"; values[n] = fixed.ileak; ++n;
   names[n] = "vleak"; values[n] = fixed.vleak; ++n;
   names[n] = "rg"; values[n] = fixed.rg; ++n;
   names[n] = "rd"; values[n] = fixed.rd; ++n;
   names[n] = "rs"; values[n] = fixed.rs; ++n;
   names[n] = "lg"; values[n] = fixed.lg; ++n;
   names[n] = "ld"; values[n] = fixed.ld; ++n;
   names[n] = "ls"; values[n] = fixed.ls; ++n;
   names[n] = "cds"; values[n] = fixed.cds; ++n;
   names[n] = "cgg0"; values[n] = fixed.cgg0; ++n;

   for (ptr = p; ptr; ptr = ptr->next)
      {
      names[n] = ptr->name;
      values[n] = ptr->nom;
      ++n;
      }

   // open files
   infile  = fopen (head_file, "r");
   if (!infile)
      {
      printf ("Unable to open header file.\n");
      return 1;
      }
   outfile = fopen (mod_file, "w+");
   if (!outfile)
      {
      printf ("Unable to write to disk.\n");
      return 1;
      }

   // write the header
   while (fgets (string, 200, infile))
      {
      if (string[0] != '!')
         break;
      else if (!strncmp (string,"!Vbr",4))
         {
         fprintf (outfile,"%s",string);
         if (fgets (string, 200, infile))
            fprintf (outfile, "%s", string);
         break;
         }

      fprintf (outfile,"%s",string);
      }
   fclose (infile);

   // write the model parameters
   fprintf (outfile, "VAR model=1\n");
   write_model_param_mdif (outfile, names, values, n, 12, 5);
   fclose (outfile);

   // write the finishing values file
   if (write_model_parameters_to_file (p, end_file))
      return 1;

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                         SWITCH MODEL FUNCTIONS                           */
/****************************************************************************/
/****************************************************************************/

static double switch_cgs (double v, double ct0, double ct1, double ct2, double ce0, double ce1,
                   double ce2, double cgg0)
   {
   return (ct0*0.5*(tanh(ct1*(v - ct2)) + 1.0) + ce0*exp(ce1*ce1*(v - ce2)))*1.0e-12 + cgg0;
   }

/*****************************************************************************/
/*****************************************************************************/

static double switch_gds (double vgs, double vgd, double a, double b, double c, double d, double e)
   {
   double arg1 = b*(vgs - c - sqrt((vgs-c)*(vgs-c) + d*d));
   double arg2 = b*(vgd - c - sqrt((vgd-c)*(vgd-c) + d*d));
   double gds1 = a*exp(arg1);
   double gds2 = a*exp(arg2);

   return b*gds2*(1.0 - (vgd-c)/sqrt((vgd-c)*(vgd-c) + d*d)) * (1.0 + tanh(e*(vgd-vgs)))/(2.0*e) +
      0.5*gds1*(1.0 - tanh(e*(vgs-vgd))*tanh(e*(vgs-vgd))) +
      0.5*gds2*(1.0 - tanh(e*(vgd-vgs))*tanh(e*(vgd-vgs)));
   }

/*****************************************************************************/
/*****************************************************************************/

static double switch_ids (double vgs, double vgd, double a, double b, double c, double d, double e)
   {
   double arg1 = b*(vgs - c - sqrt((vgs-c)*(vgs-c) + d*d));
   double arg2 = b*(vgd - c - sqrt((vgd-c)*(vgd-c) + d*d));
   double gds1 = a*exp(arg1);
   double gds2 = a*exp(arg2);

   return (gds1*(1.0 + tanh(e*(vgs-vgd))) - gds2*(1.0 + tanh(e*(vgd-vgs))))/(2.0*e);
   }

/*****************************************************************************/
/*****************************************************************************/

static double switch_breakdown (double v, double ibr, double vbr, double ileak, double vleak)
   {
   return ibr * (exp (v / vbr) - 1.0) + ileak * (exp (v / vleak) - 1.0);
   }

/****************************************************************************/
/****************************************************************************/
/*                       OPTIMIZATION ERROR FUNCTIONS                       */
/****************************************************************************/
/****************************************************************************/

static int gds_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   unsigned i;
   double ids,err;
   IVOptimize *d = (IVOptimize *) data;

   if (n_errs < 2)
      return 1;

   for (i = 0; i < d->n_gds; ++i)
      {
      ids = switch_gds (d->gds_data[i].vgs, d->gds_data[i].vgs - d->gds_data[i].vds, p[0], p[1], p[2], p[3], p[4]);
      err = ids - d->gds_data[i].ids;
      error[0] += 1.0e6 * err * err;
      }

   for (i = 0; i < d->n_knee; ++i)
      {
      ids = switch_ids (d->knee_data[i].vgs, d->knee_data[i].vgs - d->knee_data[i].vds, p[0], p[1], p[2], p[3], p[4]);
      err = ids - d->knee_data[i].ids;
      error[1] += 1.0e6 * err * err;
      }

   error[0] /= ((double) d->n_gds);
   error[1] /= ((double) d->n_knee);

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int cgs_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   unsigned i;
   double cgs,err;
   CapacitanceOptimize *d = (CapacitanceOptimize *) data;

   for (i = 0; i < d->n; ++i)
      {
      cgs = switch_cgs (d->data[i].vgs, p[0], p[1], p[2], p[3], p[4], p[5], d->cgs0);

      if (d->option == USE_CGD)
         err = (cgs - d->data[i].cgd) / (1.0e12 * d->data[i].cgd);
      else if (d->option == USE_CGS)
         err = (cgs - d->data[i].cgs) / (1.0e12 * d->data[i].cgs);
      else
         err = (cgs - 0.5 * (d->data[i].cgs + d->data[i].cgd)) / (0.5e12 * (d->data[i].cgs + d->data[i].cgd));

      error[0] += err * err * 1.0e24;
      }

   error[0] /= ((double) d->n);

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int vbr_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   unsigned i;
   double ibr,err;
   VbrOptimize *d = (VbrOptimize *) data;

   for (i = 0; i < d->n; ++i)
      {
      ibr = switch_breakdown (d->data[i].vds - d->data[i].vgs, p[0], p[1], p[2], p[3]);
      err = ibr - d->data[i].ids;

      error[0] += log (1.0 + err * err);
      }

   error[0] /= ((double) d->n);

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                            GATE CAPACITANCE                              */
/****************************************************************************/
/****************************************************************************/

static int fit_gate_capacitance (CapacitanceData *data, unsigned npts, MODEL_PARAMS *p, unsigned iter, FixedParams *fixed, jPLOT_ITEM **plot)
   {
   double *vgs,*cmeas,*cmod;
   unsigned i;
   OPT_PARAMETER pp[6];
   char *cap_params[] = {"ct0", "ct1", "ct2", "ce0", "ce1", "ce2"};

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (cap_params, 6, p, pp))
      return 1;

   // set CGG0
   if (fixed->option == USE_CGD)
      fixed->cgg0 = data[0].cgd;
   else if (fixed->option == USE_CGS)
      fixed->cgg0 = data[0].cgs;
   else
      fixed->cgg0 = (data[0].cgs + data[0].cgd) * 0.5;

   if (iter > 0)
      {
      OPTIMIZE *opt;
      CapacitanceOptimize cgs_erf_data;

      cgs_erf_data.data = data;
      cgs_erf_data.n = npts;
      cgs_erf_data.cgs0 = fixed->cgg0;
      cgs_erf_data.option = fixed->option;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, 6);
      set_cg_error_function (opt, cgs_erf, &cgs_erf_data, 1, NULL);
      set_cg_error_fraction (opt, 1.0e-7, 5);
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

      for (i = 0; i < 6; ++i)
         pp[i].optimize = 1;

      if (cg_optimize4 (opt, iter, NULL))
         {
         printf ("Error in cg_optimize4(): %s\n", get_cg_error());
         free ((void *) opt);
         return -1;
         }

      free ((void *) opt);

      if (set_all_parameters (p, pp, 6))
         return 1;
      }

   // create a plot

   vgs = (double *) malloc (sizeof(double) * npts);
   cmeas = (double *) malloc (sizeof(double) * npts);
   cmod = (double *) malloc (sizeof(double) * npts);

   for (i = 0; i < npts; ++i)
      {
      vgs[i] = data[i].vgs;
      cmod[i] = switch_cgs (data[i].vgs, pp[0].nom, pp[1].nom, pp[2].nom, pp[3].nom, pp[4].nom, pp[5].nom, fixed->cgg0) * 1.0e15 / fixed->area;
      if (fixed->option == USE_CGD)
         cmeas[i] = data[i].cgd * 1.0e15 / fixed->area;
      else if (fixed->option == USE_CGS)
         cmeas[i] = data[i].cgs * 1.0e15 / fixed->area;
      else
         cmeas[i] = (data[i].cgs + data[i].cgd) * 0.5e15 / fixed->area;
      }

   create_plot (plot, vgs, cmeas, cmod, npts, "Vgs (volts)", "pF/mm", "Gate Capacitance", 0);

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                        DRAIN CONDUCTANCE AND CURRENT                     */
/****************************************************************************/
/****************************************************************************/

static int fit_drain_conductance (char *iv_file, MODEL_PARAMS *p, double max_vds, unsigned iter, FixedParams *fixed, jPLOT_ITEM **gds_plot, jPLOT_ITEM **knee_plot)
   {
   IV_DATA data[MAX_IV_PTS];
   IV_DATA gds_data[100];
   IV_DATA knee_data[100];
   unsigned i, npts;
   double gate_voltage = -5.0;
   double drain_voltage = 1.0;
   unsigned gds_pts = 0;
   unsigned knee_pts = 0;
   char str[200];
   double *vgsg,*gmeas,*gmod;
   double *vdsk,*kmeas,*kmod;
   OPT_PARAMETER pp[5];
   char *gds_params[] = {"ids0", "ids1", "ids2", "ids3", "ids4"};

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (gds_params, 5, p, pp))
      return 1;

   if (get_iv_data (iv_file, data, MAX_IV_PTS, &npts))
      {
      printf ("ERROR in get_iv_data().\n");
      return -1;
      }

   // determine the gate voltage to use for the knee fit
   //  and the drain voltage to use to calculate conductance

   for (i = 0; i < npts; ++i)
      {
      if ((data[i].vgs > gate_voltage) && (data[i].vgs < 0.91) && (data[i].vds >= 1.5))
         gate_voltage = data[i].vgs;

      if ((data[i].vds > 0.0) && (data[i].vds < drain_voltage))
         drain_voltage = data[i].vds;
      }
   printf ("gate voltage: %e \n", gate_voltage);
   printf ("drain_voltage: %e \n", drain_voltage);
   printf("fix_area: %e \n", fixed->area);
   /* create the gds data and knee data subsets */

   for (i = 0; i < npts; ++i)
      {
      if (data[i].vgs == gate_voltage)
         {
         if ((knee_pts < 100) && (data[i].vds <= max_vds))
            {
            knee_data[knee_pts] = data[i];
#ifdef correct_for_contact_resistance
            knee_data[knee_pts].vds -= (knee_data[knee_pts].ids) * (2.0*R_CONTACT*1000.0/fixed->area);
#endif
            printf ("*****knee corrected_drain_voltage: vds %lf ids %lf \n", knee_data[knee_pts].vds, knee_data[knee_pts].ids);
            knee_pts++;
            }
         }

      if (data[i].vds == drain_voltage)
         {
         if (gds_pts < 100)
            {
            if (data[i].ids > 0.0)
               {
               gds_data[gds_pts] = data[i];
               gds_data[gds_pts].ids /= gds_data[gds_pts].vds;
#ifdef correct_for_contact_resistance
               gds_data[gds_pts].ids = 1.0 / (1.0 / gds_data[gds_pts].ids - 2.0*R_CONTACT*1000.0/fixed->area);
#endif
               printf ("****gds corrected gds data: gds %lf vds: %lf \n", gds_data[gds_pts].ids, gds_data[gds_pts].vds);
               gds_pts++;
               }
            }
         }
      }

   if (gds_pts < 3)
      {
      fprintf (stderr, "Error: not enough data for Gds fit.\n");
      return 1;
      }
   else if (knee_pts < 3)
      {
      fprintf (stderr, "Error: not enougn data for knee current fit.\n");
      return 1;
      }

   if (iter > 0)
      {
      OPTIMIZE *opt;
      IVOptimize gds_erf_data;

      gds_erf_data.gds_data = gds_data;
      gds_erf_data.knee_data = knee_data;
      gds_erf_data.n_gds = gds_pts;
      gds_erf_data.n_knee = knee_pts;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, 5);
      set_cg_error_function (opt, gds_erf, &gds_erf_data, 2, NULL);
      set_cg_error_fraction (opt, 1.0e-12, 10);
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

      for (i = 0; i < 5; ++i)
         pp[i].optimize = 1;

      if (cg_optimize4 (opt, iter, NULL))
         {
         printf ("Error in cg_optimize4(): %s\n", get_cg_error());
         free ((void *) opt);
         return -1;
         }

      free ((void *) opt);

      if (set_all_parameters (p, pp, 5))
         return 1;
      }

   // create plots

   vgsg = (double *) malloc (sizeof(double) * npts);
   gmeas = (double *) malloc (sizeof(double) * npts);
   gmod = (double *) malloc (sizeof(double) * npts);

   vdsk = (double *) malloc (sizeof(double) * npts);
   kmeas = (double *) malloc (sizeof(double) * npts);
   kmod = (double *) malloc (sizeof(double) * npts);

   for (i = 0; i < gds_pts; ++i)
      {
      vgsg[i] = gds_data[i].vgs;
      gmeas[i] = gds_data[i].ids * 1.0e6 / fixed->area;
      gmod[i] = switch_gds (gds_data[i].vgs, gds_data[i].vgs - gds_data[i].vds, pp[0].nom, pp[1].nom, pp[2].nom, pp[3].nom, pp[4].nom) * 1.0e6 / fixed->area;
      }

   for (i = 0; i < knee_pts; ++i)
      {
      vdsk[i] = knee_data[i].vds;
      kmeas[i] = knee_data[i].ids * 1.0e6 / fixed->area;
      kmod[i] = switch_ids (knee_data[i].vgs, knee_data[i].vgs - knee_data[i].vds, pp[0].nom, pp[1].nom, pp[2].nom, pp[3].nom, pp[4].nom) * 1.0e6 / fixed->area;
      }

   create_plot (gds_plot, vgsg, gmeas, gmod, gds_pts, "Vgs (volts)", "mS/mm", "Drain Conductance", 0);
   sprintf (str, "Drain Current @ Vgs = %.3f", gate_voltage);
   create_plot (knee_plot, vdsk, kmeas, kmod, knee_pts, "Vds (volts)", "mA/mm", str, 0);

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                              FORWARD DIODE                               */
/****************************************************************************/
/****************************************************************************/

static int fit_forward_iv (char *fwd_iv_file, FixedParams *fixed, jPLOT_ITEM **plot)
   {
   IV_DATA data[MAX_DIODE_PTS];
   double id[MAX_DIODE_PTS];
   double vd[MAX_DIODE_PTS];
   unsigned i,npts,j;
   double m,b,r2;
   double *vgs,*imeas,*imod;

   if (get_iv_data (fwd_iv_file, data, MAX_DIODE_PTS, &npts))
      {
      printf ("Error in get_iv_data().\n");
      return -1;
      }

   for (i = 0, j = 0; i < npts; ++i)
      {
      if ((data[i].vgs <= 0.0) || (data[i].igs < 0.0) || (data[i].vds != 0.0))
         continue;
      else if ((data[i].igs * 1.0e6 / fixed->area) < 0.05)
         continue;

      id[j] = log (data[i].igs);
      vd[j] = data[i].vgs;
      ++j;
      }

   if (j < 2)
      {
      printf ("Not enough points.\n");
      return 1;
      }

   linefit_mxb (vd, id, j, &m, &b, &r2);
   fixed->is = 0.5 * exp (b);
   fixed->n  = 1.0 / (m * THERMAL_V);

   // create a plot

   vgs = (double *) malloc (sizeof(double) * npts);
   imeas = (double *) malloc (sizeof(double) * npts);
   imod = (double *) malloc (sizeof(double) * npts);

   for (i = 0, j = 0; i < npts; ++i)
      {
      if (data[i].vds != 0.0)
         continue;

      vgs[j] = data[i].vgs;
      imod[j] = 2.0 * fixed->is * (exp (vgs[j] / (fixed->n * THERMAL_V)) - 1.0) * 1.0e6 / fixed->area;
      imeas[j] = data[i].igs * 1.0e6 / fixed->area;
      ++j;
      }

   create_plot (plot, vgs, imeas, imod, j, "Vgs (volts)", "mA/mm", "Forward Diode Current", LogY1);

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                              REVERSE DIODE                               */
/****************************************************************************/
/****************************************************************************/

// do an exponential fit on the last 5 points

static int breakdown_fit (IV_DATA *data, unsigned n, double *ibd, double *vbd)
   {
   double id[5],vd[5];
   double m,b,r2;
   unsigned i;

   if (n < 5)
      {
      printf ("Not enough points.\n");
      return -1;
      }

   for (i = 5; i > 0; --i)
      {
      if (data[n-1].ids <= 0.0)
         {
         printf ("Error: encountered negative Ids value.\n");
         return 1;
         }

      id[i-1] = log (data[n-i].ids);
      vd[i-1] = data[n-i].vds - data[n-i].vgs;
      }

   linefit_mxb (vd, id, 5, &m, &b, &r2);

   *vbd = 1.0 / m;
   *ibd = exp (b);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
// do an exponential fit on points from 25% to 50% of the max value

static int leakage_fit (IV_DATA *data, unsigned n, double *ileak, double *vleak)
   {
   double id[MAX_DIODE_PTS],vd[MAX_DIODE_PTS];
   double m,b,r2;
   double v1;
   double low_lim;
   double hi_lim;
   unsigned i,j = 0;

   if (n < 2)
      {
      printf ("Not enough points.\n");
      return -1;
      }

   low_lim = 0.25 * (data[n-1].vds - data[n-1].vgs);
   hi_lim = 0.5 * (data[n-1].vds - data[n-1].vgs);

   for (i = 0; i < n; ++i)
      {
      if (j >= MAX_DIODE_PTS)
         break;

      v1 = data[i].vds - data[i].vgs;

      if ((v1 >= low_lim) && (v1 <= hi_lim) && (data[i].ids > 0.0))
         {
         id[j] = log (data[i].ids);
         vd[j] = v1;
         ++j;
         }
      }

   if (j < 2) {
      printf ("Not enough points.\n");
      return -1;
   }

   linefit_mxb (vd, id, j, &m, &b, &r2);

   *vleak = 1.0 / m;
   *ileak = exp (b);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
// fit the breakdown and leakage current

static int fit_reverse_breakdown (char *vbr_file, unsigned niter, FixedParams *fixed, jPLOT_ITEM **plot)
   {
   IV_DATA data[MAX_DIODE_PTS];
   double *vdg,*imeas,*imod;
   unsigned i, npts, j;

   if (get_iv_data (vbr_file, data, MAX_DIODE_PTS, &npts))
      {
      printf ("Error in get_iv_data().\n");
      return 1;
      }

   printf ("Breakdown.\n");
   if (breakdown_fit (data, npts, &fixed->ibr, &fixed->vbr)) {
       fixed->ibr = 0.;
       fixed->vbr = 1.;
       fixed->ileak = 0.;
       fixed->vleak = 1.;
      printf ("Error in breakdown_fit().\n");
      return 1;
      }

   printf ("Leakage.\n");
   if (leakage_fit (data, npts, &fixed->ileak, &fixed->vleak)) {
       fixed->ileak = 0.;
       fixed->vleak = 1.;
      printf ("Error in leakage_fit().\n");
      return 1;
   }

   // now we have initial parameter values, time to optimize

   if (niter > 0)
      {
      OPTIMIZE *opt;
      VbrOptimize vbr_erf_data;
      OPT_PARAMETER p[4];

      printf ("Optimizing.\n");

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, p, 4);
      set_cg_error_function (opt, vbr_erf, &vbr_erf_data, 1, NULL);

      p[0].nom = fixed->ibr;
      strcpy (p[0].name, "Ibr");
      p[1].nom = fixed->vbr;
      strcpy (p[1].name, "Vbr");
      p[2].nom = fixed->ileak;
      strcpy (p[2].name, "Ileak");
      p[3].nom = fixed->vleak;
      strcpy (p[3].name, "Vleak");

      for (i = 0; i < 4; ++i)
         {
         p[i].min = 0.05 * p[i].nom;
         p[i].max = 20.0 * p[i].nom;
         p[i].tol = 0.0;
         p[i].optimize = 1;
         }

      vbr_erf_data.data = data;
      vbr_erf_data.n = npts;

      if (cg_optimize4 (opt, niter, NULL))
         {
         printf ("Error in cg_optimize4(): %s\n", get_cg_error());
         free ((void *) opt);
         return -1;
         }

      free ((void *) opt);

      fixed->ibr = p[0].nom;
      fixed->vbr = p[1].nom;
      fixed->ileak = p[2].nom;
      fixed->vleak = p[3].nom;
      }

   // create a plot

   vdg = (double *) malloc (sizeof(double) * npts);
   imeas = (double *) malloc (sizeof(double) * npts);
   imod = (double *) malloc (sizeof(double) * npts);

   for (i = 0, j = 0; i < npts; ++i)
      {
      if (data[i].ids <= 0.0)
         continue;

      vdg[j] = data[i].vds - data[i].vgs;
      imod[j] = switch_breakdown (vdg[j], fixed->ibr, fixed->vbr, fixed->ileak, fixed->vleak) * 1.0e6 / fixed->area;
      imeas[j] = data[i].ids * 1.0e6 / fixed->area;
      ++j;
      }

   create_plot (plot, vdg, imeas, imod, j, "Vdg (volts)", "mA/mm", "Reverse Diode Current", LogY1);

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                                 GRAPHICS                                 */
/****************************************************************************/
/****************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
   {
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);

   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
   }

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
   {
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile = "switch.ps";
   jHANDLE legend, header;
   unsigned i;

   if (!open_graphics_device (dev, plotfile))
      {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
      }

   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
      {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
      }

   // draw all plots
   for (i = 0; i < n; ++i)
      {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
         {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
         }

      plot_list[i]->active = FALSE;
      }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
      {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
      }
   else
      close_graphics_device ();

   return 0;
   }








