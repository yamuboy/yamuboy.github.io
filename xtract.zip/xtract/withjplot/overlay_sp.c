#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <jplot.h>
#include "fit_tools.h"

#define MAX_PTS   500
#define MAX_FILES 10

struct BIAS
{
   double vds,ids,vgs,igs;
   int mode;
};

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts, int db_ret);
double satan2 (double y, double x);

void print_usage( char * progname ) 
{
   printf( "USAGE: %s [options] file1 [file2 ...]\n\n", progname );
   printf( "  Options:\n" );
   printf( "     -wmf, -meta   Set output device to metafile.\n" );
   printf( "     -ps           Set output device to postscript.\n" );
   printf( "     -o name       Set plot file name to \'name\'.\n" );
   printf( "     -db           Plot in dB.\n" );
   printf( "     -np           Disable plotting of phase on the Y2 axis.\n" );
   printf( "\n" );

}

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
{
   FILE *spfile;
   char *file_list[MAX_FILES];
   char plotfile[100];
   jPLOT_ITEM *s11p,*s12p,*s21p,*s22p;
   jPLOT_ATTRIBS attribs1;
   jHANDLE legend1;
   int num_pts[MAX_FILES];
   double freqs[MAX_FILES][MAX_PTS];
   double sp11m[MAX_FILES][MAX_PTS],sp11a[MAX_FILES][MAX_PTS];
   double sp12m[MAX_FILES][MAX_PTS],sp12a[MAX_FILES][MAX_PTS];
   double sp21m[MAX_FILES][MAX_PTS],sp21a[MAX_FILES][MAX_PTS];
   double sp22m[MAX_FILES][MAX_PTS],sp22a[MAX_FILES][MAX_PTS];
   struct BIAS bias;
   static char *legend_t[] = {"Magnitude","Phase"};
   static int  legend_l[] = {LT_SOLID,LT_DASHED};
   static int  legend_l2[] = {LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID,LT_SOLID};
   static int  legend_w[] = {1,1,1,1,1,1,1,1,1,1};
   static int  legend_c[] = {CLR_BLACK,CLR_BLACK};
   static int  clr_idx[] = {2,3,4,5,6,7,8,9,10,11};
   int i;
   int plot_phase=1;
   int db_mode=0;
   int num_files=0;
   int device = X_WINDOWS;

   strcpy(plotfile,"plotfile.ps");

   if( argc < 2 ) {
      print_usage(argv[0]);
      exit(0);
   }

   // parse the command line
   for( i=1; i<argc; ++i ) {
      if( argv[i][0] == '-' ) {
         if( !strcmp(argv[i],"-ps") || !strcmp(argv[i],"-dP") ) device=POSTSCRIPT;
         else if( !strcmp(argv[i],"-wmf") || !strcmp(argv[i],"-dM") || !strcmp(argv[i],"-meta") ) device=METAFILE;
         else if( !strcmp(argv[i],"-o") ) {
            if( i == argc-1 ) {
               fprintf( stderr, "Error: missing parameter to -o option.\n" );
               print_usage(argv[0]);
               exit(1);
            }
            strcpy(plotfile,argv[++i]);
         }
         else if( !strcmp(argv[i],"-db") || !strcmp(argv[i],"-dB") ) db_mode=1; 
         else if( !strcmp(argv[i],"-np") ) plot_phase=0; 
         else {
            fprintf( stderr, "Error: unrecognized command line option: %s\n", argv[i] );
            print_usage(argv[0]);
            exit(1);
         }
      }
      else {
         if (num_files >= MAX_FILES) {
            printf ("**warning** MAX_FILES exceeded.\n");
            break;
         }
         file_list[num_files++] = argv[i];
      }
   }

   if( !num_files ) {
      fprintf( stderr, "Error: no files specified.\n" );
      print_usage(argv[0]);
      exit(1);
   }

   if (!open_graphics_device (device,plotfile)) {
      printf ("Failed to open the graphics device.\n");
      return -1;
   }

   s11p = create_plot_item (DoubleY,1.25,4.70,3.0,2.5);
   s12p = create_plot_item (DoubleY,6.75,4.70,3.0,2.5);
   s21p = create_plot_item (DoubleY,1.25,1.00,3.0,2.5);
   s22p = create_plot_item (DoubleY,6.75,1.00,3.0,2.5);

   if( db_mode ) {
      set_axis_labels (s11p,"Freq (GHz)","dB(S11)","phase(S11)","S11");
      set_axis_labels (s12p,"Freq (GHz)","dB(S12)","phase(S12)","S12");
      set_axis_labels (s21p,"Freq (GHz)","dB(S21)","phase(S21)","S21");
      set_axis_labels (s22p,"Freq (GHz)","dB(S22)","phase(S22)","S22");
   }
   else {
      set_axis_labels (s11p,"Freq (GHz)","mag(S11)","phase(S11)","S11");
      set_axis_labels (s12p,"Freq (GHz)","mag(S12)","phase(S12)","S12");
      set_axis_labels (s21p,"Freq (GHz)","mag(S21)","phase(S21)","S21");
      set_axis_labels (s22p,"Freq (GHz)","mag(S22)","phase(S22)","S22");
   }

   attribs1.xlabel_offset = 0.3;
   attribs1.ylabel_offset = 0.55;
   attribs1.title_offset  = 0.3;

   set_plot_item_attributes (s11p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s12p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s21p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s22p,&attribs1,JPA_LABELOFFSETS);

   legend1 = add_legend (2,4.55,8.1,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);

   for( i=0; i<num_files; ++i) 
   {
      spfile = fopen (file_list[i],"r");
      if (!spfile) {
         printf ("**warning** file not found '%s'\n",file_list[i]);
         continue;
      }

      num_pts[i] = read_s_params (spfile,freqs[i],sp11m[i],sp11a[i],
         sp12m[i],sp12a[i],sp21m[i],sp21a[i],
         sp22m[i],sp22a[i],&bias,MAX_PTS,db_mode);

      fclose(spfile);
      if( ! num_pts[i] ) continue;

      attach_y1data (s11p,freqs[i],sp11m[i],num_pts[i],LT_SOLID,1,clr_idx[i]);
      if( plot_phase ) attach_y2data (s11p,freqs[i],sp11a[i],num_pts[i],LT_DASHED,1,clr_idx[i]);

      attach_y1data (s12p,freqs[i],sp12m[i],num_pts[i],LT_SOLID,1,clr_idx[i]);
      if( plot_phase ) attach_y2data (s12p,freqs[i],sp12a[i],num_pts[i],LT_DASHED,1,clr_idx[i]);

      attach_y1data (s21p,freqs[i],sp21m[i],num_pts[i],LT_SOLID,1,clr_idx[i]);
      if( plot_phase ) attach_y2data (s21p,freqs[i],sp21a[i],num_pts[i],LT_DASHED,1,clr_idx[i]);

      attach_y1data (s22p,freqs[i],sp22m[i],num_pts[i],LT_SOLID,1,clr_idx[i]);
      if( plot_phase ) attach_y2data (s22p,freqs[i],sp21a[i],num_pts[i],LT_DASHED,1,clr_idx[i]);

   }

   add_legend (num_files,4.55,4.5,file_list,FNT_COURIER,11,legend_l2,legend_w,clr_idx);

   if (num_files > 0)
      draw_page ();

   close_graphics_device ();

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts, int db_ret)
{
   char string[256],tmp[6];
   int i = 0;
   int ri_mode = 0;
   int db_mode = 0;
   double fscale = 1.0e-9;
   double rad_to_deg = 180.0/acos(-1.0);
   double dtmp;

   bias->mode = 0;
   while (fgets(string,255,infile))
   {
      if (i >= max_pts)
         break;

      if (!strncmp (string,"!BIAS",5)) {
         if (sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",&bias->vds,&bias->ids,
            &bias->vgs,&bias->igs) == 4)
            bias->mode = 1;
         else if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&bias->vds,&bias->ids,
            &bias->vgs,&bias->igs) == 4)
            bias->mode = 2;
         else
            bias->mode = 0;
      }
      else if (string[0] == '!')
         continue;

      if (sscanf(string,"# %5s %5s",tmp,tmp) == 2)
      {
         for( i=0; i<strlen(string); ++i ) {
            if( string[i] >= 'A' && string[i] <='Z' ) string[i] += (char) ('a' -'A');
         }
         if (strstr(string,"ri"))
            ri_mode = 1;
         if (strstr(string,"db"))
            db_mode = 1;

         if (strstr(string,"ghz"))
            fscale = 1.0;
         else if (strstr(string,"mhz"))
            fscale = 1.0e-3;
         else if (strstr(string,"khz"))
            fscale = 1.0e-6;
      }

      if (sscanf(string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq[i],&s11m[i],&s11a[i],&s21m[i],&s21a[i],&s12m[i],&s12a[i],
         &s22m[i],&s22a[i]) == 9)
      {
         freq[i] *= fscale;

         if (ri_mode) {
            dtmp = s11m[i];
            s11m[i] = sqrt (s11m[i]*s11m[i] + s11a[i]*s11a[i]);
            s11a[i] = rad_to_deg*satan2 (s11a[i],dtmp);

            dtmp = s12m[i];
            s12m[i] = sqrt (s12m[i]*s12m[i] + s12a[i]*s12a[i]);
            s12a[i] = rad_to_deg*satan2 (s12a[i],dtmp);            

            dtmp = s21m[i];
            s21m[i] = sqrt (s21m[i]*s21m[i] + s21a[i]*s21a[i]);
            s21a[i] = rad_to_deg*satan2 (s21a[i],dtmp); 

            dtmp = s22m[i];
            s22m[i] = sqrt (s22m[i]*s22m[i] + s22a[i]*s22a[i]);
            s22a[i] = rad_to_deg*satan2 (s22a[i],dtmp);

            if( db_ret ) {
               // need to convert from mag to dB
               s11m[i] = 20. * log10( s11m[i] );
               s12m[i] = 20. * log10( s12m[i] );
               s21m[i] = 20. * log10( s21m[i] );
               s22m[i] = 20. * log10( s22m[i] );
            }
         }
         else if( db_mode ) {
            if( ! db_ret ) {
               // need to convert from dB to mag
               s11m[i] = pow( 10., 0.05 * s11m[i] );
               s12m[i] = pow( 10., 0.05 * s12m[i] );
               s21m[i] = pow( 10., 0.05 * s21m[i] );
               s22m[i] = pow( 10., 0.05 * s22m[i] );
            }
         }
         else {
            if( db_ret ) {
               // need to convert from mag to dB
               s11m[i] = 20. * log10( s11m[i] );
               s12m[i] = 20. * log10( s12m[i] );
               s21m[i] = 20. * log10( s21m[i] );
               s22m[i] = 20. * log10( s22m[i] );
            }
         }

         ++i;
      }
   }

   return i;
}

/*********************************************************************************************/
/*********************************************************************************************/

double satan2 (double y, double x)
{
   if ((x == 0.0) && (y == 0.0))
      return 0.0;
   else
      return atan2(y,x);
}         





