#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize4.h"
#include "jplot.h"
#include "fit_tools.h"

/****** MACROS AND DEFINITIONS ******/

#define VERSION      2.0

#define sqr(x)    ((x)*(x))
#define cube(x)   ((x)*(x)*(x))

#define MAX_AC_BIAS_PTS    250
#define MAX_DCIV_PTS       1000
#define MAX_DIODE_PTS      100
#define MAX_FWD_IGS        0.5      // in mA/mm
#define MAX_EXP_ARG        30.0
#define MAX_CONV_ITER      500

// ohmic contact resistance per mm
#define OHMIC_R_PER_MM     0.1

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19
#define CTOK          273.15

// plot definitions
#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_DOTTED
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN
#define PLOT_X        1.25
#define PLOT_Y        1.25
#define PLOT_XSIZE    6.0
#define PLOT_YSIZE    5.5

typedef struct
{
   double vgs,vds,igs,ids;
   double cgs,cgd,cds;
   double gm,gds,tau,tau2;
} AC_PARAMETERS;

typedef struct
{
   double area,ugw,ngf;
   double rg,rd,rs,ri;
   double lg,ld,ls;
   double cpg,cpd,c11,c22;
   double tnom;
   double gdsm, gdss, gdsv, gdsmf, gdssf;
} FIXED_PARAMS;

typedef struct
{
   unsigned ndc, nsub;
   IV_DATA *dcdata, *subdata;
   double max_vds;
   double periphery;
   int modnum;
} DCIV_OPT;

typedef struct
{
   unsigned n;
   AC_PARAMETERS *data;
   double max_vds;
   double periphery;
} AC_OPT;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, unsigned max_size);
static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params, FIXED_PARAMS fixed);

static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n);

static int dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int charge_erf (double *p, void *data, double *err, unsigned n_err);
static int vbr_erf (double *p, void *data, double *err, unsigned n_err);
static int ig_erf (double *p, void *data, double *err, unsigned n_err);
static int gds_erf (double *p, void *data, double *err, unsigned n_err);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);
static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

static int fit_diode_curves (char *fwd_iv_file, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot);
static int fit_vbr_curves (char *vbr_file, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                           jPLOT_ITEM **vbr_plot);
static int fit_dc_curves (char *dc_iv_file, MODEL_PARAMS *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot);
static int fit_capacitance_data (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                                 double max_vds, double *weights, jPLOT_ITEM **cgs_plot, jPLOT_ITEM **cgd_plot,
                                 jPLOT_ITEM **cds_plot, jPLOT_ITEM **tau_plot);
static int fit_gds (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, FIXED_PARAMS *fixed_p, double vds_for_gds);

static void write_starting_files (char *input_file, char *param_file);

static double angelov_current (double *p, double Vgs, double Vds, double *Gm, double *Gds);
static void angelov_charge (double *p, double Vgs, double Vgd, double *cgs, double *cgd,
                            double *dqgs_vgd, double *dqgd_vgs);
static double angelov_ig (double vg, double ij, double pg, double vjg, int igmod);
static double angelov_ibr (double vdg, double ibr1, double vbr1, double ibr2, double vbr2);
static double gds_func (double vgs, double gdsm, double gdss, double gdsv, double gdsmf, double gdssf);

static void check_parameter_ranges (MODEL_PARAMS *p, double Vmax, double Vpo);
static void read_vmax_from_file (char *fname, double *vmax, double *vpo);

/* ------------- GLOBAL VARIABLES -------------- */

static char global_warning_msg[5000];

static char *global_iv_param_names[] = {"p1", "p2", "p3", "b1", "b2", "vpks", "dvpks", "vsb2", "alphar", "alphas",
"ipk0", "lambda", "lsb0", "vtr"
};
#define N_IV_PARAMS  14

static char *global_charge_param_names[] = {"p1", "p2", "p3", "b1", "b2", "vpks", "dvpks", "vsb2", "alphar", "alphas",
"ipk0", "lambda", "lsb0", "vtr", "cds", "tau", "p10", "p11", "p20", "p21", "p30", "p31", "p40", "p41",
"p111", "cgspi", "cgs0", "cgdpi", "cgd0"
};
#define N_CHARGE_PARAMS   29

#define CDS_INDEX    14
#define TAU_INDEX    15

static int CHECK_DERIV = 0;
double global_qgs, global_qgd;

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
{
   char string[256];
   char model_summary_file[100], start_file[100], end_file[100];
   char model_file[100], yfit_file[100], dc_iv_file[100];
   char fwd_iv_file[100], breakdown_file[100], header[3000];
   MODEL_PARAMS *params;
   AC_PARAMETERS ac_data[MAX_AC_BIAS_PTS];
   FIXED_PARAMS fixed_params;
   unsigned num_ac_bias_pts, niter;
   double maximum_vds;
   double weights[] = {50.0, 1000.0, 1.0, 0.05};
   jPLOT_ITEM *p_subth = NULL, *p_dciv = NULL, *p_cgs = NULL;
   jPLOT_ITEM *p_cgd = NULL, *p_cds = NULL, *p_tau = NULL, *p_dfwd = NULL, *p_drev = NULL;
   jPLOT_ITEM *p_gm = NULL, *p_gds = NULL;
   int plot_dev = X_WINDOWS;
   int i;
   int no_dc = 0;
   int no_gm = 0;
   int no_cap = 0;
   double vmax, vpo;
   double vds_for_gds = 3.0;

   global_warning_msg[0] = 0;

   /**** parse the command line ****/

   for (i = 1; i < argc; ++i)
   {
      if (!strncmp (argv[i], "-i", 2) || !strncmp (argv[i], "-e", 2))
      {
         write_starting_files ("angelovin", "angelov.start");
         return 0;
      }
      else if (!strncmp (argv[i], "-h", 2))
      {
         printf ("\n\n");

         printf ("Angelov model fitter options:\n");
         printf ("------------------------------------------------------------------\n");
         printf ("  -i, -e    Auto-generate an input file named parkerin and a\n");
         printf ("              starting values file named parker.start.\n");
         printf ("  -dP, -dp  Set plot device to postscript.\n");
         printf ("  -dM, -dm  Set plot device to metafile.\n");
         printf ("  -d0       Disable plotting.\n");
         printf ("  -skipdc   Skip the DC I-V fitting routine.\n");
         printf ("  -skipgm   Skip the transconductance fitting routine.\n");
         printf ("  -skipcap  Skip the capacitance/charge fitting routine.\n");
         printf ("  -gdsv=X   Set the drain voltage for Gds extraction to X.\n");
         printf ("               The default is 3 volts.\n");

         printf ("\n\n");

         return 0;
      }
      else if (!strncmp (argv[i], "-d", 2))
      {
         char ch = 0;
         sscanf (argv[i], "-d%c", &ch);
         if ((ch == 'm') || (ch == 'M'))
            plot_dev = METAFILE;
         else if ((ch == 'p') || (ch == 'P'))
            plot_dev = POSTSCRIPT;
         else if (ch == '0')
            plot_dev = 0;
         else
            printf ("Warning: invalid -d option.\n");
      }
      else if (!strncmp (argv[i], "-skipdc", 7))
         no_dc = 1;
      else if (!strncmp (argv[i], "-skipgm", 7))
         no_gm = 1;
      else if (!strncmp (argv[i], "-skipcap", 8))
         no_cap = 1;
      else if (!strncmp (argv[i], "-x", 2))
         CHECK_DERIV = 1;
      else if (!strncmp (argv[i], "-gdsv=", 6))
         sscanf (argv[i], "-gdsv=%lf", &vds_for_gds);
   }

   /**** get user input ****/

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ugw);

   fixed_params.area = fixed_params.ngf * fixed_params.ugw;

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.tnom);

   printf ("Y-fit end file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",yfit_file);

   printf ("Model summary file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_summary_file);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Forward IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",breakdown_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   printf ("Capacitance fitting weights [cgs cgd cds tau]?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2], &weights[3]);

   /**** get measurement and extraction data ****/

   if (read_model_parameters_from_file (start_file, &params, NULL))
      return 1;

   if (get_ss_parameters (model_summary_file, yfit_file, ac_data, MAX_AC_BIAS_PTS, &fixed_params, &num_ac_bias_pts))
      return 1;

   // read in Vmax, use for VBI model parameter
   read_vmax_from_file (fwd_iv_file, &vmax, &vpo);

   // check for bad starting values or illegal range values 
   //    (i.e. parameters that must be >= 0)
   if (niter > 0)
      check_parameter_ranges (params, vmax, vpo);

   // set rd/rs to an approximate ohmic contact resistance
   fixed_params.rd = fixed_params.rs = OHMIC_R_PER_MM * 1000.0 / fixed_params.area;

   // determine the intrinsic node voltages for ac data
   for (i = 0; i < num_ac_bias_pts; ++i)
   {
      ac_data[i].vds -= fixed_params.rd*ac_data[i].ids +
         fixed_params.rs*(ac_data[i].ids + ac_data[i].igs);
      ac_data[i].vgs -= (fixed_params.rg + fixed_params.ri)*ac_data[i].igs + 
         fixed_params.rs*(ac_data[i].ids + ac_data[i].igs);
   }

   /**** perform various parameter fits ****/

   if (!no_dc)
   {
      if (fit_diode_curves (fwd_iv_file, params, (niter ? 50 : 0), &fixed_params, &p_dfwd))
         return 1;

      if (fit_dc_curves (dc_iv_file, params, maximum_vds, niter, &fixed_params, &p_subth, &p_dciv))
         return 1;

      if (fit_vbr_curves (breakdown_file, params, (niter ? 100 : 0), &fixed_params, &p_drev))
         return 1;
   }

   if( fit_gds (ac_data, num_ac_bias_pts, params, &fixed_params, vds_for_gds ) )
      return 1;

   if (!no_cap)
   {
      if (fit_capacitance_data (ac_data, num_ac_bias_pts, params, niter, &fixed_params, maximum_vds, weights, &p_cgs, &p_cgd, &p_cds, &p_tau))
         return 1;
   }

   /**** Write final data files ****/

   printf ("Writing data files.\n");

   get_file_header (fwd_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, params, fixed_params))
      return 1;

   /***** Generate plots *****/

   if (plot_dev)
   {
      jPLOT_ITEM *plot_list[10];
      char plot_head[1000];
      FILE *file;

      plot_head[0] = 0;

      // get the plot header

      file = fopen (fwd_iv_file, "r");
      if (file)
      {
         while (fgets (string, 255, file))
         {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
         }

         fclose (file);
      }

      plot_list[0] = p_subth;
      plot_list[1] = p_dciv;
      plot_list[2] = p_gm;
      plot_list[3] = p_gds;
      plot_list[4] = p_cgs;
      plot_list[5] = p_cgd;
      plot_list[6] = p_cds;
      plot_list[7] = p_tau;
      plot_list[8] = p_dfwd;
      plot_list[9] = p_drev;

      if (plot_data (plot_dev, plot_head, plot_list, 10))
         return 1;
   }

   if (global_warning_msg[0])
   {
      printf ("\n%s", global_warning_msg);
      printf ("\nModel fitting completed with warnings.\n\n");
   }
   else
      printf ("\n\nModel fitting complete.\n\n");

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_diode_curves (char *fwd_iv_file, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot)
{
   IV_DATA fwd_curves[MAX_DIODE_PTS];
   unsigned n_fwd_pts;
   double v[MAX_DIODE_PTS], i[MAX_DIODE_PTS];
   unsigned j, k;
   double m, b, r2;
   double *vf, *if_meas, *if_mod;
   char *pnames[] = {"ij", "pg"};
   unsigned nump = 2;
   OPT_PARAMETER pp[2];
   int modnum = 2;

   printf ("Forward Diode IV.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (pnames, nump, p, pp))
      return 1;

   if (get_iv_data (fwd_iv_file, fwd_curves, MAX_DIODE_PTS, &n_fwd_pts))
      return 1;

   /* -- NOT DOING THIS, USING A DIFFERENT DIODE EQUATION
   // optimization
   if (niter > 0)
   {
   OPTIMIZE *opt;
   DCIV_OPT ig_data;

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
   {
   if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 1.0e-8*fixed_p->area))
   {
   v[k] = fwd_curves[j].vgs;
   i[k] = log (fwd_curves[j].igs);
   ++k;
   }
   }

   if (k < 2)
   {
   fprintf (stderr, "Error: %s: not enough points.\n", fwd_iv_file);
   return 1;
   }

   linefit_mxb (v, i, k, &m, &b, &r2);

   pp[0].nom = 0.5*exp(b);
   pp[0].min = 0.01*pp[0].nom;
   pp[0].max = 100.0*pp[0].nom;

   pp[1].nom = m;
   pp[1].min = 0.9*m;
   pp[1].max = 1.1*m;

   ig_data.ndc = n_fwd_pts;
   ig_data.dcdata = fwd_curves;
   ig_data.periphery = fixed_p->area;
   ig_data.modnum = modnum;

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, pp, nump);
   set_cg_flags (opt, OPT_SINGLE_PARAM);
   set_cg_error_function (opt, ig_erf, &ig_data, 1, NULL);

   // turn on optimization for appropriate parameters
   pp[0].optimize = TRUE;
   pp[1].optimize = TRUE;

   // optimize
   if (cg_optimize4 (opt, niter, NULL))
   {
   fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
   return -1;
   }

   free ((void *) opt);

   if (set_all_parameters (p, pp, nump))
   return 1;
   }
   */

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
   {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 1.0e-8*fixed_p->area))
      {
         v[k] = fwd_curves[j].vgs;
         i[k] = log (fwd_curves[j].igs);
         ++k;
      }
   }

   if (k < 2)
   {
      fprintf (stderr, "Error: %s: not enough points.\n", fwd_iv_file);
      return 1;
   }

   linefit_mxb (v, i, k, &m, &b, &r2);

   pp[0].nom = 0.5*exp(b);
   pp[0].min = pp[0].max = pp[0].nom;

   pp[1].nom = m;
   pp[1].min = pp[1].max = pp[1].nom;

   if (set_all_parameters (p, pp, nump))
      return 1;

   // create a plot

   vf = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_meas = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_mod = (double *) malloc (sizeof(double)*n_fwd_pts);

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
   {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 0.0))
      {
         vf[k] = fwd_curves[j].vgs;
         if_meas[k] = fwd_curves[j].igs * 1.0e6 / fixed_p->area;
         if_mod[k] = 2.0 * angelov_ig (vf[k], pp[0].nom, pp[1].nom, 0.0, modnum) * 1.0e6 / fixed_p->area;
         ++k;
      }
   }

   create_plot (vf_plot, vf, if_meas, if_mod, k, "Vgs (volts", "Igs (mA/mm)", "Diode Characteristic", LogY1);

   return 0;
}

/****************************************************************************/
/****************************************************************************/

static int breakdown_linefit (IV_DATA *data, unsigned n, double *ibd, double *vbd)
{
   double id[5],vd[5];
   double m,b,r2;
   unsigned i;

   if (n < 5)
   {
      printf ("Not enough points.\n");
      return -1;
   }

   for (i = 5; i > 0; --i)
   {
      if (data[n-1].igs > 0.0)
      {
         printf ("Error: encountered positive Igs value.\n");
         return 1;
      }

      id[i-1] = log (-data[n-i].igs);
      vd[i-1] = data[n-i].vds - data[n-i].vgs;
   }

   linefit_mxb (vd, id, 5, &m, &b, &r2);

   *vbd = m;
   *ibd = exp (b);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
// do an exponential fit on points from 25% to 50% of the max value

static int leakage_linefit (IV_DATA *data, unsigned n, double *ileak, double *vleak)
{
   double id[MAX_DIODE_PTS],vd[MAX_DIODE_PTS];
   double m,b,r2;
   double v1;
   double low_lim;
   double hi_lim;
   unsigned i,j = 0;

   if (n < 2)
   {
      printf ("Not enough points.\n");
      return -1;
   }

   low_lim = 0.25 * (data[n-1].vds - data[n-1].vgs);
   hi_lim = 2.0 * low_lim;

   for (i = 0; i < n; ++i)
   {
      if (j >= MAX_DIODE_PTS)
         break;

      v1 = data[i].vds - data[i].vgs;

      if ((v1 >= low_lim) && (v1 <= hi_lim) && (data[i].igs < 0.0))
      {
         id[j] = log (-data[i].igs);
         vd[j] = v1;
         ++j;
      }
   }

   if (j < 2)
   {
      printf ("Not enough points.\n");
      return -1;
   }

   linefit_mxb (vd, id, j, &m, &b, &r2);

   *vleak = m;
   *ileak = exp (b);

   return 0;   
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_vbr_curves (char *vbr_file, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                           jPLOT_ITEM **vbr_plot)
{
   IV_DATA vbr_curves[MAX_DIODE_PTS];
   unsigned n_pts;
   OPT_PARAMETER pp[N_IV_PARAMS];
   unsigned i, j, k;
   double *v, *i_meas, *i_mod;
   char *vbr_params[] = {"ibd1", "vbd1", "ibd2", "vbd2"};

   printf ("Breakdown.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (vbr_params, 4, p, pp))
      return 1;

   // load the Vbr curve data
   if (get_iv_data (vbr_file, vbr_curves, MAX_DIODE_PTS, &n_pts))
      return 1;

   // optimization
   if (niter > 0)
   {
      OPTIMIZE *opt;
      DCIV_OPT vbr_data;

      // set starting values
      if (breakdown_linefit (vbr_curves, n_pts, &pp[0].nom, &pp[1].nom))
      {
         printf ("Error in breakdown_linefit().\n");
         return 1;
      }

      if (leakage_linefit (vbr_curves, n_pts, &pp[2].nom, &pp[3].nom))
      {
         printf ("Error in leakage_linefit(). Turning off leakage terms.\n");
         pp[2].nom = 0.0;
         pp[3].nom = 1.0;
      }

      if( pp[1].nom < 0. )
      {
         pp[0].nom = 0.;
         pp[1].nom = 1.;
      }

      if( pp[3].nom < 0. )
      {
         pp[2].nom = 0.;
         pp[3].nom = 1.;
      }

      vbr_data.ndc = n_pts;
      vbr_data.dcdata = vbr_curves;
      vbr_data.periphery = fixed_p->area;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, 4);
      set_cg_flags (opt, OPT_SINGLE_PARAM);
      set_cg_error_function (opt, vbr_erf, &vbr_data, 1, NULL);

      // turn on optimization for appropriate parameters
      //  and set optimization ranges
      for (i = 0; i < 4; i += 2)
      {
         pp[i].min = 0.05 * pp[i].nom;
         pp[i].max = 20.0 * pp[i].nom;
         pp[i].tol = 0.0;
         pp[i].optimize = 1;
      }
      for (i = 1; i < 4; i += 2)
      {
         pp[i].min = 0.8 * pp[i].nom;
         pp[i].max = 1.2 * pp[i].nom;
         pp[i].tol = 0.0;
         pp[i].optimize = 1;
      }

      // optimize
      if (cg_optimize4 (opt, niter, NULL))
      {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         // do not return an error
      }

      free ((void *) opt);

      if (set_all_parameters (p, pp, 4))
         return 1;
   }

   // create a plot 

   v = (double *) malloc (sizeof(double)*n_pts);
   i_meas = (double *) malloc (sizeof(double)*n_pts);
   i_mod = (double *) malloc (sizeof(double)*n_pts);

   for (j = 0; j < n_pts; ++j)
   {
      v[j] = vbr_curves[j].vds - vbr_curves[j].vgs;
      i_meas[j] = -vbr_curves[j].igs * 1.0e6 / fixed_p->area;
      i_mod[j] = angelov_ibr (v[j], pp[0].nom, pp[1].nom, pp[2].nom, pp[3].nom) * 1.0e6 / fixed_p->area;
   }

   create_plot (vbr_plot, v, i_meas, i_mod, n_pts, "Vdg (volts)", "Idg (mA/mm)", "Breakdown Characteristic", LogY1);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_dc_curves (char *dc_iv_file, MODEL_PARAMS *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot)
{
   unsigned n_iv_pts, n_subth_pts;
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   IV_DATA subth_data[MAX_DCIV_PTS];
   double *subth_v, *subth_imeas, *subth_imod;
   double *dciv_v, *dciv_imod, *dciv_imeas;
   unsigned i, j;
   double pl[N_IV_PARAMS];
   OPT_PARAMETER pp[N_IV_PARAMS];

   printf ("DC IV data.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (global_iv_param_names, N_IV_PARAMS, p, pp))
      return 1;

   // load the DC I-V curve data
   if (get_iv_data (dc_iv_file, dciv_curves, MAX_DCIV_PTS, &n_iv_pts))
      return 1;

   // create the subthreshold data set
   for (i = 0, n_subth_pts = 0; i < n_iv_pts; ++i)
   {
      if ((dciv_curves[i].vds < 2.0) || (dciv_curves[i].vds > max_vds) || 
         (dciv_curves[i].ids > 100e-6*fixed_p->area) || (dciv_curves[i].ids <= 0.0))
         continue;

      subth_data[n_subth_pts] = dciv_curves[i];
      ++n_subth_pts;
   }

   if (!n_subth_pts)
   {
      printf ("Error: unable to form subthreshold data set.\n");
      return 1;
   }

   // sort the subthreshold data set
   for (i = 0; i < n_subth_pts; ++i)
   {
      for (j = i+1; j < n_subth_pts; ++j)
      {
         if ((subth_data[j].vds < subth_data[i].vds) ||
            ((subth_data[j].vds == subth_data[i].vds) && (subth_data[j].vgs < subth_data[i].vgs)))
         {
            IV_DATA tmp = subth_data[i];
            subth_data[i] = subth_data[j];
            subth_data[j] = tmp;
         }
      }
   }

   // apply port resistances to active region data
   for (i = 0; i < n_iv_pts; ++i)
   {
      if (dciv_curves[i].igs < 0.0)
         dciv_curves[i].vgs -= dciv_curves[i].ids*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;
      else
         dciv_curves[i].vgs -= (dciv_curves[i].ids + dciv_curves[i].igs)*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;

      dciv_curves[i].vds -= (dciv_curves[i].ids + 0.5*dciv_curves[i].igs) * (fixed_p->rs + fixed_p->rd);
   }

   // optimization
   if (niter > 0)
   {
      OPTIMIZE *opt;
      DCIV_OPT dciv_data;
      double wght[] = {10.0, 1.0};

      dciv_data.ndc = n_iv_pts;
      dciv_data.dcdata = dciv_curves;
      dciv_data.nsub = n_subth_pts;
      dciv_data.subdata = subth_data;
      dciv_data.max_vds = max_vds;
      dciv_data.periphery = fixed_p->area;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_IV_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);
      set_cg_error_function (opt, dciv_erf, &dciv_data, 2, wght);
      set_cg_error_fraction (opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for (i = 0; i <= 11; ++i)
         pp[i].optimize = TRUE;
      pp[7].optimize = FALSE;

      if (cg_optimize4 (opt, niter, NULL))
      {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return -1;
      }

      free ((void *) opt);

      if (set_all_parameters (p, pp, N_IV_PARAMS))
         return 1;
   }

   /* create plots */

   subth_v = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imeas = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imod = (double *) malloc (sizeof (double) * n_subth_pts);
   dciv_v = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imeas = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imod = (double *) malloc (sizeof (double) * n_iv_pts);

   for (i = 0; i < N_IV_PARAMS; ++i)
      pl[i] = pp[i].nom;

   for (i = 0; i < n_subth_pts; ++i)
   {
      subth_v[i] = subth_data[i].vgs;
      subth_imeas[i] = subth_data[i].ids * 1.0e6 / fixed_p->area;
      subth_imod[i] = angelov_current (pl, subth_data[i].vgs, subth_data[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
   }

   create_plot (subth_plot, subth_v, subth_imeas, subth_imod, n_subth_pts, "Vgs (volts)", "Ids (mA/mm)", "Sub-Threshold Current", LogY1);

   for (i = 0; i < n_iv_pts; ++i)
   {
      dciv_v[i] = dciv_curves[i].vds;
      dciv_imeas[i] = dciv_curves[i].ids * 1.0e6 / fixed_p->area;
      dciv_imod[i] = angelov_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
   }

   create_plot (dciv_plot, dciv_v, dciv_imeas, dciv_imod, n_iv_pts, "Vds (volts)", "Ids (mA/mm)", "DC I-V Curves", POSITIVE_X | POSITIVE_Y1);

   if (CHECK_DERIV)
   {
      double gm, gds, gm1, gm2, gds1, gds2;
      double del = 1.0e-3;
      FILE *file = fopen ("iv_deriv.txt", "w+");
      if (!file)
         return 1;

      fprintf (file, "! Vgs Vds Gm Gm_num Gds Gds_num\n");
      for (i = 0; i < n_iv_pts; ++i)
      {
         gm1 = angelov_current (pl, dciv_curves[i].vgs+del, dciv_curves[i].vds, NULL, NULL);
         gm2 = angelov_current (pl, dciv_curves[i].vgs-del, dciv_curves[i].vds, NULL, NULL);
         gds1 = angelov_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds+del, NULL, NULL);
         gds2 = angelov_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds-del, NULL, NULL);
         angelov_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds, &gm, &gds);
         fprintf (file, "%.3f %.2f\t\t%.4e %.4e\t\t%.4e %.4e\n", dciv_curves[i].vgs, dciv_curves[i].vds,
            gm, (gm1-gm2) / (2.0*del), gds, (gds1-gds2) / (2.0*del));
      }
      fclose (file);
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_capacitance_data (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                                 double max_vds, double *weights, jPLOT_ITEM **cgs_plot, jPLOT_ITEM **cgd_plot,
                                 jPLOT_ITEM **cds_plot, jPLOT_ITEM **tau_plot)
{
   double *v, *cgs_meas, *cgs_mod, *cgd_meas, *cgd_mod;
   double *cds_meas, *cds_mod, *tau_mod, *tau_meas;
   unsigned i, j;
   double cgs, cgd, qgs_vgd, qgd_vgs, cds, gm, tau;
   OPT_PARAMETER pp[N_CHARGE_PARAMS];
   double pl[N_CHARGE_PARAMS];

   printf ("Gate Charge.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (global_charge_param_names, N_CHARGE_PARAMS, p, pp))
      return 1;

   // optimization
   if (niter > 0)
   {
      double cds_ave = 0.0;
      double tau_ave = 0.0;
      AC_OPT cap_data;
      OPTIMIZE *opt;

      // set starting values for Tau and Cds
      for (i = 0, j = 0; i < n; ++i)
      {
         if ((ac_data[i].vds < 2.0) || (ac_data[i].ids < fixed_p->area*10.0e-6))
            continue;

         cds_ave += ac_data[i].cds;
         tau_ave += ac_data[i].tau;
         ++j;
      }

      if (!j)
         j = 1;

      cds_ave /= (double) j;
      tau_ave /= (double) j;

      pp[CDS_INDEX].nom = cds_ave;
      pp[CDS_INDEX].min = 0.0;
      pp[CDS_INDEX].max = 4.0*cds_ave;

      pp[TAU_INDEX].nom = tau_ave;
      pp[TAU_INDEX].min = 0.0;
      pp[TAU_INDEX].max = 4.0*tau_ave;

      //  prepare for optimization

      cap_data.periphery = fixed_p->area;
      cap_data.max_vds = max_vds;
      cap_data.n = n;
      cap_data.data = ac_data;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_CHARGE_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);

      set_cg_error_function (opt, charge_erf, &cap_data, 4, weights);
      set_cg_error_fraction (opt, 1.0e-12, 5);

      // set the appropriate optimization parameters
      for (i = 14; i <= 28; ++i)
         pp[i].optimize = TRUE;

      if (cg_optimize4 (opt, niter, NULL))
      {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return 1;
      }

      free ((void *) opt);

      if (set_all_parameters (p, pp, N_CHARGE_PARAMS))
         return 1;
   }

   /* create plots */

   for (i = 0; i < N_CHARGE_PARAMS; ++i)
      pl[i] = pp[i].nom;

   v = (double *) malloc (sizeof (double)*n);
   cgs_mod = (double *) malloc (sizeof (double)*n);
   cgs_meas = (double *) malloc (sizeof (double)*n);
   cgd_mod = (double *) malloc (sizeof (double)*n);
   cgd_meas = (double *) malloc (sizeof (double)*n);
   cds_mod = (double *) malloc (sizeof (double)*n);
   cds_meas = (double *) malloc (sizeof (double)*n);
   tau_mod = (double *) malloc (sizeof (double)*n);
   tau_meas = (double *) malloc (sizeof (double)*n);

   cds = pl[CDS_INDEX];
   tau = pl[TAU_INDEX];
   for (i = 0; i < n; ++i)
   {
      angelov_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
      angelov_current (pl, ac_data[i].vgs, ac_data[i].vds, &gm, NULL);

      cgs_mod[i] = (cgs + qgd_vgs) * 1.0e15 / fixed_p->area;
      cgs_meas[i] = ac_data[i].cgs * 1.0e15 / fixed_p->area;

      cgd_mod[i] = (cgd + qgs_vgd) * 1.0e15 / fixed_p->area;
      cgd_meas[i] = ac_data[i].cgd * 1.0e15 / fixed_p->area;

      cds_mod[i] = (cds - qgs_vgd) * 1.0e15 / fixed_p->area;
      cds_meas[i] = (ac_data[i].cds - ac_data[i].gds*ac_data[i].tau2) * 1.0e15 / fixed_p->area;

      tau_mod[i] = (tau + (qgd_vgs-qgs_vgd)/gm) * 1.0e12;
      tau_meas[i] = ac_data[i].tau * 1.0e12;

      v[i] = ac_data[i].vds;
   }

   create_plot (cgs_plot, v, cgs_meas, cgs_mod, n, "Vds (volts)", "pF/mm", "Cgs", 0);
   create_plot (cgd_plot, v, cgd_meas, cgd_mod, n, "Vds (volts)", "pF/mm", "Cgd", 0);
   create_plot (cds_plot, v, cds_meas, cds_mod, n, "Vds (volts)", "pF/mm", "Cds", 0);
   create_plot (tau_plot, v, tau_meas, tau_mod, n, "Vds (volts)", "pS", "Tau", 0);
   set_y1_scale (*tau_plot, 0.0, 10.0, 2.0, 4, 0, "");

   if (CHECK_DERIV)
   {
      double cgs, cgd, dqgs_vgd, dqgd_vgs;
      double cgs1, cgs2, cgd1, cgd2;
      double dqgs1, dqgs2, dqgd1, dqgd2;
      double del = 1.0e-3;
      FILE *file = fopen ("charge_deriv.txt", "w+");
      if (!file)
         return 1;

      fprintf (file, "! Vgs Vds Cgs Cgs_num Cgd Cgd_num dQgs_vgd dQgs_vgd_num dQgd_vgs dQgd_vgs_num\n");
      for (i = 0; i < n; ++i)
      {
         angelov_charge (pl, ac_data[i].vgs+del, ac_data[i].vgs - ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgs1 = global_qgs;
         dqgd1 = global_qgd;
         angelov_charge (pl, ac_data[i].vgs-del, ac_data[i].vgs - ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgs2 = global_qgs;
         dqgd2 = global_qgd;
         angelov_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds + del, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgd1 = global_qgd;
         dqgs1 = global_qgs;
         angelov_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds - del, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgd2 = global_qgd;
         dqgs2 = global_qgs;
         angelov_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds, &cgs, &dqgs_vgd, &cgd, &dqgd_vgs);
         fprintf (file, "%.3f %.2f\t%.4e %.4e\t%.4e %.4e\t%.4e %.4e\t%.4e %.4e\n", ac_data[i].vgs, ac_data[i].vds,
            cgs, (cgs1-cgs2) / (2.0*del), cgd, (cgd1-cgd2) / (2.0*del),
            dqgs_vgd, (dqgs1-dqgs2) / (2.0*del), dqgd_vgs, (dqgd1-dqgd2) / (2.0*del));
      }
      fclose (file);
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_gds (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, FIXED_PARAMS *fixed_p, double vds_for_gds)
{
   FILE *file;
   double pl[N_IV_PARAMS];
   OPT_PARAMETER pp[N_IV_PARAMS];
   AC_PARAMETERS gds_data[MAX_AC_BIAS_PTS];
   double gds;
   unsigned i;
   unsigned niter = 100;

   printf ("RF conductance.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (global_iv_param_names, N_IV_PARAMS, p, pp))
      return 1;

   for (i = 0; i < N_IV_PARAMS; ++i)
      pl[i] = pp[i].nom;

   // calculate/correct the offset in Gds from DC to RF
   for (i = 0; i < n; ++i)
   {
      gds_data[i].vgs = ac_data[i].vgs;
      gds_data[i].vds = ac_data[i].vds;
      angelov_current (pl, gds_data[i].vgs, gds_data[i].vds, NULL, &gds);
      gds_data[i].gds = ac_data[i].gds - gds;
      if (gds_data[i].gds < 0.0)
         gds_data[i].gds = 0.0;
   }

   // set up optimization
   if (niter > 0)
   {
      AC_OPT opt_data;
      OPTIMIZE *opt;
      OPT_PARAMETER xx[] = {
         {0.000001, 0.002, 0.006, 0.0, "gdsm", 1},
         {0.0, 0.002, 0.005, 0.0, "gdss", 1},
         {-1.0, -0.2, 0.5, 0.0, "gdsv", 1},
         {0.05, 0.3, 0.8, 0.0, "gdsmf", 1},
         {1.0, 5.0, 10.0, 0.0, "gdssf", 1}
      };

      //  prepare for optimization

      opt_data.max_vds = vds_for_gds;
      opt_data.n = n;
      opt_data.data = gds_data;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, xx, 5);
      set_cg_flags (opt, OPT_AUTO);
      set_cg_error_function (opt, gds_erf, &opt_data, 1, NULL);

      if (cg_optimize4 (opt, niter, NULL))
      {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return 1;
      }

      free ((void *) opt);

      /*
      file = fopen ("gds.txt", "w+");
      if (!file)
      return 1;

      for (i = 0; i < n; ++i)
      {
      if ((gds_data[i].vds >= vds_for_gds-0.5) && (gds_data[i].vds <= vds_for_gds+0.1))
      {
      fprintf (file, "%.3e\t%.3e\t%.3e\t%.3e\n", gds_data[i].vgs, gds_data[i].vds, gds_data[i].gds,
      gds_func(gds_data[i].vgs, xx[0].nom, xx[1].nom, xx[2].nom, xx[3].nom, xx[4].nom));
      }
      }

      fclose (file);
      */

      fixed_p->gdsm = xx[0].nom;
      fixed_p->gdss = xx[1].nom;
      fixed_p->gdsv = xx[2].nom;
      fixed_p->gdsmf = xx[3].nom;
      fixed_p->gdssf = xx[4].nom;




   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

static double angelov_current (double *p, double Vgs, double Vds, double *Gm, double *Gds)
{
   double P1 = p[0];
   double P2 = p[1];
   double P3 = p[2];
   double B1 = p[3];
   double B2 = p[4];
   double VPKS = p[5];
   double DVPKS = p[6];
   double VSB2 = p[7];
   double ALPHAR = p[8];
   double ALPHAS = p[9];
   double IPK0 = p[10];
   double LAMBDA = p[11];
   double LSB0 = p[12];
   double VTR = p[13];
   double p1m, vpkm, psi, alpha, c1, c2, c3;
   double dp1m_vds, dvpkm_vgs, dvpkm_vds;
   double dpsi_vgs, dpsi_vds, dalpha_vgs, dalpha_vds;
   double dc1_vgs, dc1_vds, dc2_vgs, dc2_vds;
   double dc3_vgs, dc3_vds, Ids;

   p1m = P1 * (1.0 + B1 / sqr(cosh(B2*Vds)));
   dp1m_vds = P1 * B1 * (-2.0) / cube(cosh(B2*Vds)) * sinh(B2*Vds) * B2;

   vpkm = VPKS - DVPKS + DVPKS*tanh(ALPHAS*Vds) - VSB2*sqr(Vds-Vgs-VTR);
   dvpkm_vgs = 2.0*VSB2*(Vds-Vgs-VTR);
   dvpkm_vds = DVPKS/sqr(cosh(ALPHAS*Vds))*ALPHAS - 2.0*VSB2*(Vds-Vgs-VTR);

   psi = p1m*(Vgs-vpkm) + P2*sqr(Vgs-vpkm) + P3*cube(Vgs-vpkm);
   dpsi_vgs = p1m + 2.0*P2*(Vgs-vpkm)*(1.0-dvpkm_vgs) + 3.0*P3*sqr(Vgs-vpkm)*(1.0-dvpkm_vgs);
   dpsi_vds = (Vgs-vpkm)*dp1m_vds - dvpkm_vds*(p1m + 2.0*P2*(Vgs-vpkm) + 3.0*P3*sqr(Vgs-vpkm));

   alpha = ALPHAR + ALPHAS*(1.0 + tanh(psi));
   dalpha_vgs = ALPHAS / sqr(cosh(psi)) * dpsi_vgs;
   dalpha_vds = ALPHAS / sqr(cosh(psi)) * dpsi_vds;

   c1 = IPK0 * (1.0 + tanh(psi));
   dc1_vgs = IPK0 / sqr(cosh(psi)) * dpsi_vgs;
   dc1_vds = IPK0 / sqr(cosh(psi)) * dpsi_vds;

   c2 = tanh(alpha*Vds);
   dc2_vgs = 1.0 / sqr(cosh(alpha*Vds)) * Vds * dalpha_vgs;
   dc2_vds = 1.0 / sqr(cosh(alpha*Vds)) * (alpha + Vds*dalpha_vds);

   c3 = (1.0 + LAMBDA*Vds + LSB0*exp(Vds-Vgs-VTR));
   dc3_vgs = -LSB0*exp(Vds-Vgs-VTR);
   dc3_vds = LAMBDA - dc3_vgs;

   Ids = c1 * c2 * c3;
   if (Gm)
      *Gm = c1*(c2*dc3_vgs + c3*dc2_vgs) + c2*c3*dc1_vgs;
   if (Gds)
      *Gds = c1*(c2*dc3_vds + c3*dc2_vds) + c2*c3*dc1_vds;

   return Ids;
}

/*****************************************************************************/
/*****************************************************************************/

static void angelov_charge (double *p, double Vgs, double Vgd, double *Cgs, double *dQgs_vgd, double *Cgd, double *dQgd_vgs)
{
   double P10 = p[16];
   double P11 = p[17];
   double P20 = p[18];
   double P21 = p[19];
   double P30 = p[20];
   double P31 = p[21];
   double P40 = p[22];
   double P41 = p[23];
   double P111 = p[24];
   double CGSP = p[25];
   double CGS0 = p[26];
   double CGDP = p[27];
   double CGD0 = p[28];
   double phi1, dphi1_vgs, dphi1_vgd;
   double phi2, dphi2_vgs, dphi2_vgd;
   double lc1, dlc1_vgs, dlc1_vgd;
   double lc10, dlc10_vgs, dlc10_vgd;
   double qgs0, dqgs0_vgs, dqgs0_vgd;
   double phi3, dphi3_vgs, dphi3_vgd;
   double phi4, dphi4_vgs, dphi4_vgd;
   double lc4, dlc4_vgs, dlc4_vgd;
   double lc40, dlc40_vgs, dlc40_vgd;
   double qgd0, dqgd0_vgs, dqgd0_vgd;
   double Qgs, Qgd;

   /* calculate Cgs and dQgs/dVgd */

   phi1 = P10 + P11*Vgs + P111*(Vgs-Vgd);
   dphi1_vgs = P11 + P111;
   dphi1_vgd = -P111;

   phi2 = P20 + P21*(Vgs-Vgd);
   dphi2_vgs = P21;
   dphi2_vgd = -P21;

   lc1 = log(cosh(phi1));
   dlc1_vgs = tanh(phi1)*dphi1_vgs;
   dlc1_vgd = tanh(phi1)*dphi1_vgd;

   lc10 = log(cosh(P10 + P111*(Vgs-Vgd)));
   dlc10_vgs = tanh(P10 + P111*(Vgs-Vgd))*P111;
   dlc10_vgd = -dlc10_vgs;

   qgs0 = P10 + P111*(Vgs-Vgd) + lc10;
   dqgs0_vgs = P111 + dlc10_vgs;
   dqgs0_vgd = -P111 + dlc10_vgd;

   Qgs = CGSP*Vgs + CGS0*((phi1+lc1-qgs0)*(1.0-P111+tanh(phi2))/P11 + 2.0*P111*Vgs);
   *Cgs = CGSP + CGS0*(((phi1+lc1-qgs0)*(1.0/sqr(cosh(phi2))*dphi2_vgs) + (1.0-P111+tanh(phi2))*(dphi1_vgs+dlc1_vgs-dqgs0_vgs))/P11 + 2.0*P111);
   *dQgs_vgd = CGS0*(((phi1+lc1-qgs0)*(1.0/sqr(cosh(phi2))*dphi2_vgd) + (1.0-P111+tanh(phi2))*(dphi1_vgd+dlc1_vgd-dqgs0_vgd))/P11);

   /* calculate Cgd and dQgd/dVgs */

   phi3 = P30 + P31*(Vgd-Vgs);
   dphi3_vgs = -P31;
   dphi3_vgd = P31;

   phi4 = P40 + P41*Vgd + P111*(Vgd-Vgs);
   dphi4_vgs = -P111;
   dphi4_vgd = P41 + P111;

   lc4 = log(cosh(phi4));
   dlc4_vgs = tanh(phi4)*dphi4_vgs;
   dlc4_vgd = tanh(phi4)*dphi4_vgd;

   lc40 = log(cosh(P40 + P111*(Vgd-Vgs)));
   dlc40_vgs = -tanh(P40 + P111*(Vgd-Vgs))*P111;
   dlc40_vgd = -dlc40_vgs;

   qgd0 = P40 + P111*(Vgd-Vgs) + lc40;
   dqgd0_vgs = -P111 + dlc40_vgs;
   dqgd0_vgd = P111 + dlc40_vgd;

   Qgd = CGDP*Vgd + CGD0*((phi4+lc4-qgd0)*(1.0-P111+tanh(phi3))/P41 + 2.0*P111*Vgd);
   *Cgd = CGDP + CGD0*(((phi4+lc4-qgd0)*dphi3_vgd/sqr(cosh(phi3)) + (1.0-P111+tanh(phi3))*(dphi4_vgd+dlc4_vgd-dqgd0_vgd))/P41 + 2.0*P111);
   *dQgd_vgs = CGD0*(((phi4+lc4-qgd0)*dphi3_vgs/sqr(cosh(phi3)) + (1.0-P111+tanh(phi3))*(dphi4_vgs+dlc4_vgs-dqgd0_vgs))/P41);

   global_qgs = Qgs;
   global_qgd = Qgd;
}

/*****************************************************************************/
/*****************************************************************************/

static double angelov_ig (double vg, double ij, double pg, double vjg, int igmod)
{
   switch (igmod)
   {
   case 0:
      return ij*(exp(pg*tanh(2.0*(vg-vjg)))) - exp(pg*tanh(-2.0*vjg));
   case 1:
      return ij*(exp(pg*tanh(vg-vjg))-exp(-pg*vjg));
   default:
      return ij*(exp(pg*vg)-1.0);
   }
}

/*****************************************************************************/
/*****************************************************************************/

static double angelov_ibr (double vdg, double ibr1, double vbr1, double ibr2, double vbr2)
{
   return ibr1*(exp(vdg*vbr1)-1.0) + ibr2*(exp(vdg*vbr2)-1.0);
}

/*****************************************************************************/
/*****************************************************************************/

static double gds_func (double vgs, double gdsm, double gdss, double gdsv, double gdsmf, double gdssf)
{
   return gdsm*exp(-sqr(vgs-gdsv)/gdsmf) + gdss*0.5*(1.0+tanh(gdssf*(vgs-gdsv)));
}

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int dciv_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->nsub; ++i)
   {
      diff = log (d->subdata[i].ids) - log (angelov_current (p, d->subdata[i].vgs, d->subdata[i].vds, NULL, NULL) + 1.0e-15);
      err[0] += diff * diff;
   }

   for (i = 0; i < d->ndc; ++i)
   {
      if (d->dcdata[i].vds > d->max_vds)
         continue;

      diff = d->dcdata[i].ids - angelov_current (p, d->dcdata[i].vgs, d->dcdata[i].vds, NULL, NULL);
      err[1] += 1.0e6 * diff * diff;
   }

   err[0] /= (double) d->nsub;
   err[1] /= (double) d->ndc;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int charge_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   AC_OPT *d = (AC_OPT *) data;
   double cgs, cgd, qgs_vgd, qgd_vgs, gm;
   double cds = p[CDS_INDEX];
   double tau = p[TAU_INDEX];

   if (n_err != 4)
      return 1;

   for (i = 0; i < d->n; ++i)
   {
      angelov_charge (p, d->data[i].vgs, d->data[i].vgs - d->data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
      angelov_current (p, d->data[i].vgs, d->data[i].vds, &gm, NULL);

      if (d->data[i].vds >= 1.5)
      {
         err[0] += sqr(1.0e12*(d->data[i].cgs - (cgs + qgd_vgs)));
         err[1] += sqr(1.0e12*(d->data[i].cgd - (cgd + qgs_vgd)));
         err[2] += sqr(1.0e12*((d->data[i].cds - d->data[i].gds*d->data[i].tau2) - (cds - qgs_vgd)));
         if (d->data[i].gm >= (10.0e-6*d->periphery))
            err[3] += sqr(1.0e12*(d->data[i].tau - (tau + (qgd_vgs - qgs_vgd)/gm)) * gm);
      }
   }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;
   err[2] /= (double) d->n;
   err[3] /= (double) d->n;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int vbr_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   double ig;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->ndc; ++i)
   {
      if (d->dcdata[i].igs < 0.0)
      {
         ig = angelov_ibr (d->dcdata[i].vds - d->dcdata[i].vgs, p[0], p[1], p[2], p[3]);
         err[0] += 1.0e6 * sqr(-d->dcdata[i].igs - ig);
      }
   }

   err[0] /= (double) d->ndc;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int ig_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   double ig;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->ndc; ++i)
   {
      if ((d->dcdata[i].igs > 1.0e-8*d->periphery) && (d->dcdata[i].vds == 0.0))
      {
         ig = 2.0 * angelov_ig (d->dcdata[i].vgs, p[0], p[1], 0.0, d->modnum);
         err[0] += 1.0e6 * sqr(d->dcdata[i].igs - ig);
      }
   }

   err[0] /= (double) d->ndc;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int gds_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   double gds;
   AC_OPT *d = (AC_OPT *) data;
   unsigned j = 0;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->n; ++i)
   {
      if ((d->data[i].vds >= d->max_vds-0.5) && (d->data[i].vds <= d->max_vds+0.1))
      {
         gds = gds_func (d->data[i].vgs, p[0], p[1], p[2], p[3], p[4]);
         err[0] += 1.0e6 * sqr(d->data[i].gds - gds);
         ++j;
      }
   }

   if (j < 3)
   {
      printf ("Error: gds_erf(): not enough points.\n");
      return 1;
   }

   err[0] /= (double) j;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n)
{
   FILE *file;
   unsigned m = 0;
   unsigned found = 0;
   unsigned i,j;
   char string[300],pname[20];
   double *Ri;
   double value;
   AC_PARAMETERS tmp;

   *n = 0;

   /* read in bias-dependent device parameters */

   file = fopen (sum_file,"r");
   if (!file)
   {
      printf ("Error: %s: unable to file.\n", sum_file);
      return 1;
   }

   Ri = (double *) malloc (sizeof (double) * max_ac_p);

   while (fgets (string, 299, file))
   {
      if ((m >= max_ac_p) || (*n >= max_ac_p))
      {
         printf ("Warning: %s: too many bias points.\n", sum_file);
         break;
      }

      if (sscanf (&string[28],"%lf%lf%lf%lf%*f%*f%*f%*f%*f%lf%lf%lf%lf%lf%lf%lf%lf",
         &ac_params[*n].vds, &ac_params[*n].ids, &ac_params[*n].vgs, &ac_params[*n].igs,
         &Ri[m], &ac_params[*n].gm, &ac_params[*n].tau, &ac_params[*n].gds, &ac_params[*n].tau2,
         &ac_params[*n].cgs, &ac_params[*n].cds, &ac_params[*n].cgd) == 12)
      {
         ac_params[*n].ids *= 1.0e-3;
         ac_params[*n].igs *= 1.0e-3;
         ac_params[*n].gm  *= 1.0e-3;
         ac_params[*n].gds *= 1.0e-3;
         ac_params[*n].cgs *= 1.0e-12;
         ac_params[*n].cgd *= 1.0e-12;
         ac_params[*n].cds *= 1.0e-12;
         ac_params[*n].tau *= 1.0e-12;
         ac_params[*n].tau2 *= 1.0e-12;

         if ((ac_params[*n].igs <= MAX_FWD_IGS*fixed_params->area*1.0e-6) && (ac_params[*n].vds >= 1.0))
         {
            ++(*n);

            // only fit Ri at points where there is DC drain current
            if (ac_params[*n].ids >= 10.0e-6*fixed_params->area)
               ++m;
         }

      }
   }
   fclose (file);

   // average these parameters, since they are fixed in the LS model

   fixed_params->ri = bubble_average (Ri,m);   
   if (fixed_params->ri < 0.0)
      fixed_params->ri = 0.0;

   free ((void *) Ri);

   if (*n < 1)
   {
      fprintf (stderr, "Error: %s: no data.\n", sum_file);
      return 1;
   }

   /* sort the ac parameters by increasing Vgs then Vds */

   for (i = 0; i < ((*n)-1); ++i)
   {
      for (j = i+1; j < *n; ++j)
      {
         if ((ac_params[j].vgs < ac_params[i].vgs) ||
            ((ac_params[j].vds < ac_params[i].vds) && (ac_params[i].vgs == ac_params[j].vgs)))
         {
            tmp = ac_params[i];
            ac_params[i] = ac_params[j];
            ac_params[j] = tmp;
         }
      }
   }

   /* read in fixed parasitics from the small-signal end file */

   file = fopen (end_file,"r");
   if (!file)
   {
      printf ("Error: %s: unable to open file.\n", end_file);
      return 1;
   }

   while (fgets (string,299,file))
   {
      if (sscanf (string,"%*f%lf%*f%*f%19s",&value,pname) == 2)
      {
         if (!strcmp (pname,"C1"))
         {
            fixed_params->cpg = value;
            ++found;
         }
         else if (!strcmp (pname,"C2"))
         {
            fixed_params->cpd = value;
            ++found;
         }
         else if (!strcmp (pname,"C11"))
         {
            fixed_params->c11 = value;
            ++found;
         }
         else if (!strcmp (pname,"C22"))
         {
            fixed_params->c22 = value;
            ++found;
         }
         else if (!strcmp (pname,"B1"))
         {
            fixed_params->lg = value;
            ++found;
         }
         else if (!strcmp (pname,"B2"))
         {
            fixed_params->ld = value;
            ++found;
         }
         else if (!strcmp (pname,"LS"))
         {
            fixed_params->ls = value;
            ++found;
         }
         else if (!strcmp (pname,"RG"))
         {
            fixed_params->rg = value;
            ++found;
         }
         else if (!strcmp (pname,"RD"))
         {
            fixed_params->rd = value;
            ++found;
         }
         else if (!strcmp (pname,"RS"))
         {
            fixed_params->rs = value;
            ++found;
         }
      }
   }
   fclose (file);

   if (found != 10)
   {
      fprintf (stderr, "Error: %s: missing parameter(s).\n", end_file);
      return 1;
   }

   /* lump fringing caps into the intrinsic caps since they are not supported */ 

   if (fixed_params->cpg != 0.0)
   {
      sprintf (string, "Warning: non-zero C1 has been lumped into Cgs.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cgs += fixed_params->cpg;
   }

   if (fixed_params->c11 != 0.0)
   {
      sprintf (string, "Warning: non-zero C11 has been lumped into Cgs.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cgs += fixed_params->c11;
   }

   if (fixed_params->cpd != 0.0)
   {
      sprintf (string, "Warning: non-zero C2 has been lumped into Cds.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cds += fixed_params->cpd;
   }

   if (fixed_params->c22 != 0.0)
   {
      sprintf (string, "Warning: non-zero C22 has been lumped into Cds.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cds += fixed_params->c22;
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void get_file_header (char *data_file, char *header, unsigned max_size)
{
   FILE *file = fopen (data_file,"r");
   unsigned index = 0, len;
   char string[300];

   if (!header || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
   {
      if (string[0] != '!')
      {
         string[0] = 0;
         break;
      }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
      {
         if ((index + len) < max_size)
         {
            strcat (header, string);
            index += len;
         }
         else
            break;

         fgets (string,299,file);
         break;
      }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
      {
         strcat (header, string);
         index += len;
      }
      else
         break;
   }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if ((len > 0) && (index < max_size))
   {
      if ((index + len) < max_size)
      {
         strcat (header, string);
         index += len;
      }
      else if ((max_size - index) == 1);
      else
      {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
      }
   }
}

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params, FIXED_PARAMS fixed)
{
   FILE *file;
   unsigned i;
   unsigned count = 0;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   unsigned max_str = 0;
   char fmt[30];
   MODEL_PARAMS *ptr;

   /* write final optimization parameter values */

   if (write_model_parameters_to_file (params, end_file))
      return 1;

   /* write the model file */

   names[num_p] = "ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "tnom"; values[num_p] = fixed.tnom; ++num_p;
   // fixed parasitics
   names[num_p] = "rg"; values[num_p] = fixed.rg; ++num_p;
   names[num_p] = "rd"; values[num_p] = fixed.rd; ++num_p;
   names[num_p] = "rs"; values[num_p] = fixed.rs; ++num_p;
   names[num_p] = "ri", values[num_p] = fixed.ri; ++num_p;
   names[num_p] = "rgd", values[num_p] = fixed.ri; ++num_p;
   names[num_p] = "lg"; values[num_p] = fixed.lg; ++num_p;
   names[num_p] = "ld"; values[num_p] = fixed.ld; ++num_p;
   names[num_p] = "ls"; values[num_p] = fixed.ls; ++num_p;
   // forward gate diode parameters
   names[num_p] = "vjg"; values[num_p] = 0.0; ++num_p;
   // RF fitting RC networks
   names[num_p] = "cgdpe"; values[num_p] = 0.0; ++num_p;
   names[num_p] = "crfin"; values[num_p] = 1.0e-6; ++num_p;
   names[num_p] = "rcin"; values[num_p] = 1.0e12; ++num_p;
   names[num_p] = "crf"; values[num_p] = 1.0e-6; ++num_p;
   // GDS parameters
   names[num_p] = "gdsm"; values[num_p] = fixed.gdsm; ++num_p;
   names[num_p] = "gdss"; values[num_p] = fixed.gdss; ++num_p;
   names[num_p] = "gdsv"; values[num_p] = fixed.gdsv; ++num_p;
   names[num_p] = "gdsmf"; values[num_p] = fixed.gdsmf; ++num_p;
   names[num_p] = "gdssf"; values[num_p] = fixed.gdssf; ++num_p;

   // optimized parameters
   for (ptr = params; ptr; ptr = ptr->next)
   {
      names[num_p] = ptr->name;
      values[num_p] = ptr->nom;
      ++num_p;
   }

   file = fopen (model_file, "w+");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", model_file);
      return -1;
   }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");

   write_model_param_mdif (file, names, values, num_p, 12, 5);

   fclose (file);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
{
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);

   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
}

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
{
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile = "angelov.ps";
   jHANDLE legend, header;
   unsigned i;

   if (!open_graphics_device (dev, plotfile))
   {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
   }

   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
   {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
   }

   // draw all plots
   for (i = 0; i < n; ++i)
   {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
      {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
      }

      plot_list[i]->active = FALSE;
   }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
   {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
   }
   else
      close_graphics_device ();

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files (char *inname, char *endname)
{
   FILE *file;
   OPT_PARAMETER p[] = {
      {  0.0000e+00,  1.0000e+00,  5.0000e+00,  0.0000e+00, "p1", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p2", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p3", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "b1", 0 },
      {  1.0000e+00,  3.0000e+00,  5.0000e+00,  0.0000e+00, "b2", 0 },
      { -6.0000e-01,  0.0000e+00,  4.0000e-01,  0.0000e+00, "vpks", 0 },
      {  0.0000e+00,  2.0000e-01,  6.0000e-01,  0.0000e+00, "dvpks", 0 },
      {  0.0000e+00,  1.0000e-01,  1.0000e+00,  0.0000e+00, "alphar", 0 },
      {  0.0000e+00,  1.0000e+00,  2.0000e+00,  0.0000e+00, "alphas", 0 },
      {  0.0000e+00,  5.0000e-02,  2.0000e-01,  0.0000e+00, "ipk0", 0 },
      {  0.0000e+00,  0.0000e+00,  5.0000e-02,  0.0000e+00, "lambda", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "vsb2", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "lsb0", 0 },
      {  8.0000e+00,  1.8000e+01,  2.5000e+01,  0.0000e+00, "vtr", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p10", 0 },
      {  0.0000e+00,  1.0000e+00,  2.0000e+00,  0.0000e+00, "p11", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p20", 0 },
      {  0.0000e+00,  2.0000e-01,  1.0000e+00,  0.0000e+00, "p21", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p30", 0 },
      {  0.0000e+00,  2.0000e-01,  1.0000e+00,  0.0000e+00, "p31", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p40", 0 },
      {  0.0000e+00,  1.0000e+00,  2.0000e+00,  0.0000e+00, "p41", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+00,  0.0000e+00, "p111", 0 },
      {  1.0000e-15,  1.0000e-14,  1.0000e-13,  0.0000e+00, "cgspi", 0 },
      {  1.0000e-14,  1.0000e-13,  1.0000e-12,  0.0000e+00, "cgs0", 0 },
      {  1.0000e-15,  1.0000e-14,  1.0000e-13,  0.0000e+00, "cgdpi", 0 },
      {  1.0000e-14,  1.0000e-13,  1.0000e-12,  0.0000e+00, "cgd0", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "cds", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "tau", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "ij", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "pg", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "ibd1", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "vbd1", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "ibd2", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "vbd2", 0 },
      {  1.0000e+12,  1.0000e+12,  1.0000e+12,  0.0000e+00, "rc", 0 }
   };

   if (inname)
   {
      file = fopen (inname, "w+");
      if (!file)
      {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
      }

      fprintf (file, "6               # number of gate fingers\n");
      fprintf (file, "50              # unit gate width\n");
      fprintf (file, "27              # extraction temperature\n");
      fprintf (file, "s.end           # Y-fit file name\n");
      fprintf (file, "model.summary   # model summary file name\n");
      fprintf (file, "sdc.iv          # DC I-V file name\n");
      fprintf (file, "5               # max drain voltage for I-V fit\n");
      fprintf (file, "sfwd.iv         # forward I-V file name\n");
      fprintf (file, "svbr.iv         # breakdown I-V file name\n");
      fprintf (file, "angelov.start   # starting parameters file name\n");
      fprintf (file, "angelov.end     # finishing parameters file name (output)\n");
      fprintf (file, "angelov.model   # model file name (output)\n");
      fprintf (file, "500             # maximum optimization iterations\n");

      fclose (file);
   }

   if (endname)
   {
      unsigned i;

      file = fopen (endname, "w+");
      if (!file)
      {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
      }

      for (i = 0; i < (sizeof(p) / sizeof(*p)); ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);

      fclose (file);
   }
}

/*****************************************************************************/
/*****************************************************************************/

static void check_parameter_ranges (MODEL_PARAMS *p, double Vmax, double Vpo)
{
   OPT_PARAMETER x;
   MODEL_PARAMS *ptr;

   // set LSB0 to 0 (breakdown parameter)
   get_parameter_value ("lsb0", p, &x);
   x.min = x.nom = x.max = 0.0;
   set_parameter_value (p, x);

   // set VSB2 to 0 (breakdown parameter)
   get_parameter_value ("vsb2", p, &x);
   x.min = x.nom = x.max = 0.0;
   set_parameter_value (p, x);

   /* check to make sure that the nominal values make sense */

   for (ptr = p; ptr; ptr = ptr->next)
   {
      if (ptr->nom < ptr->min)
         ptr->nom = ptr->min;
      else if (ptr->nom > ptr->max)
         ptr->nom = ptr->max;

      if (ptr->min > ptr->max)
         printf ("Warning: check_parameter_ranges(): parameter \'%s\' min is greater than max.\n", ptr->name);
   }
}

/*****************************************************************************/
/*****************************************************************************/

static void read_vmax_from_file (char *fname, double *vmax, double *vpo)
{
   FILE *file;
   char string[256];

   *vmax = 1.0;
   *vpo = -1.0;

   file = fopen (fname, "r");
   if (!file)
      return;

   while (fgets (string, 255, file))
   {
      if (string[0] != '!')
         break;

      if (!strncmp (string, "!Vbr", 4))
      {
         if (fgets (string, 255, file))
            sscanf (string, "!%*f%*f%*f%*f%*f%*f%lf%lf", vmax, vpo);
         break;
      }
   }

   fclose (file);
}

