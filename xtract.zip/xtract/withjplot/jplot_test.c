#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <jplot.h>

int main (int argc, char *argv[])
   {
   jPLOT_ITEM  *pitem,*pitem2;
   double      xdata[300],ydata[300],zdata[300];
   char        *ltxt[] = {"Item 1","Item 2"};
   int         ltype[] = {LT_SOLID,LT_DASHED};
   int         lwdth[] = {2,1};
   int         lclr[]  = {CLR_RED,CLR_ORANGE};
   static double xcoord[] = {1.1,1.1,1.1,3.4,3.4,3.4,6.6,6.6,6.6,8.5};
   static double ycoord[] = {0.2,1.4,5.3,0.4,2.3,4.9,0.1,2.2,6.9,4.4};
   static double values[] = {21.1,22.2,20.5,23.4,25.2,24.1,21.5,24.1,20.1,19.7};
   int         i;
   jHANDLE     legend;

   for (i = 0; i < 201; ++i)
      {
      xdata[i] = (i-50)/100.0;
      ydata[i] = 1.0/(fabs((double) (i-100))+1.0);
      zdata[i] = fabs ((double) (i-100))*fabs ((double) (i-100))/500.0;
      }

   open_graphics_device_stdin (TRUE);

   pitem = create_plot_item (DoubleY,3.0,2.0,6.0,5.0);
   if (pitem == NULL)
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      close_graphics_device ();
      return -1;
      }
         
   attach_y1data (pitem,xdata,ydata,201,LT_SOLID,2,CLR_RED);
   attach_y2data (pitem,xdata,zdata,201,LT_DASHED,1,CLR_ORANGE);

   set_axis_labels (pitem,"This is the X axis.","This is the Y1 axis (log)","This is the Y2 axis (linear)","This is the title");

   set_axis_scaling (pitem,LogY1);

   set_plot_item_flags (pitem,FULL_LOG_YGRID);

   legend = add_legend (2,0.75,7.75,ltxt,FNT_COURIER,12,ltype,lwdth,lclr);

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      return -1;
      }

   deactivate_plot_item (pitem);
   remove_user_item (legend);

   pitem2 = create_plot_item (PolarContour,4.0,4.0,4.0,4.0);
   attach_contourdata (pitem2,xcoord,ycoord,values,10,LT_DASHED,1,CLR_RED,PNT_CIRCLE,CLR_BLUE);
   set_axis_labels (pitem2,"This is the X axis.","This is the Y1 axis (log)","This is the Y2 axis (linear)","This is the title");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      return -1;
      }

   deactivate_plot_item (pitem2);

   add_text ("Black",1.0,8.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Red",1.0,7.7,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_RED,NO_STYLE);
   add_text ("Green",1.0,7.4,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_GREEN,NO_STYLE);
   add_text ("Blue",1.0,7.1,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLUE,NO_STYLE);
   add_text ("Yellow",1.0,6.8,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_YELLOW,NO_STYLE);
   add_text ("Light Grey",1.0,6.5,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_LIGHTGREY,NO_STYLE);
   add_text ("Grey",1.0,6.2,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_GREY,NO_STYLE);
   add_text ("Dark Grey",1.0,5.9,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_DARKGREY,NO_STYLE);
   add_text ("Orange",1.0,5.6,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_ORANGE,NO_STYLE);
   add_text ("Light Blue",1.0,5.3,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_LIGHTBLUE,NO_STYLE);
   add_text ("Dark Green",1.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_DARKGREEN,NO_STYLE);
   add_text ("Brown",1.0,4.7,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BROWN,NO_STYLE);
   add_text ("Maroon",1.0,4.4,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_MAROON,NO_STYLE);
   add_text ("Purple",1.0,4.1,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_PURPLE,NO_STYLE);

   add_text ("Courier 6pt.",1.0,2.0,FNT_COURIER,6,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Courier 12pt.",1.0,1.7,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Courier 18pt.",1.0,1.4,FNT_COURIER,18,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Courier 24pt.",1.0,1.1,FNT_COURIER,24,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);

   add_text ("Times 6pt.",4.0,2.0,FNT_TIMES,6,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Times 12pt.",4.0,1.7,FNT_TIMES,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Times 18pt.",4.0,1.4,FNT_TIMES,18,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Times 24pt.",4.0,1.1,FNT_TIMES,24,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);

   add_text ("Helvetica 6pt.",7.0,2.0,FNT_HELVETICA,6,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Helvetica 12pt.",7.0,1.7,FNT_HELVETICA,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Helvetica 18pt.",7.0,1.4,FNT_HELVETICA,18,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_text ("Helvetica 24pt.",7.0,1.1,FNT_HELVETICA,24,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);

   add_text ("Courier Bold",3.0,8.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_BOLDFACE);
   add_text ("Courier Light",3.0,7.7,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_LIGHT);
   add_text ("Courier Underline",3.0,7.4,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_UNDERLINE);
   add_text ("Courier Italic",3.0,7.1,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_ITALIC);

   add_text ("Times Bold",5.0,8.0,FNT_TIMES,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_BOLDFACE);
   add_text ("Times Light",5.0,7.7,FNT_TIMES,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_LIGHT);
   add_text ("Times Underline",5.0,7.4,FNT_TIMES,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_UNDERLINE);
   add_text ("Times Italic",5.0,7.1,FNT_TIMES,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_ITALIC);

   add_text ("Helvetica Bold",7.0,8.0,FNT_HELVETICA,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_BOLDFACE);
   add_text ("Helvetica Light",7.0,7.7,FNT_HELVETICA,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_LIGHT);
   add_text ("Helvetica Underline",7.0,7.4,FNT_HELVETICA,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_UNDERLINE);
   add_text ("Helvetica Italic",7.0,7.1,FNT_HELVETICA,12,0.0,LEFT_JUSTIFY,CLR_BLACK,TS_ITALIC);

   add_text ("Solid",5.2,6.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (3.0,6.1,5.0,6.1,LT_SOLID,1,CLR_BLACK);

   add_text ("Dotted",5.2,5.7,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (3.0,5.8,5.0,5.8,LT_DOTTED,1,CLR_BLACK);

   add_text ("Dashed",5.2,5.4,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (3.0,5.5,5.0,5.5,LT_DASHED,1,CLR_BLACK);

   add_text ("Dot Dash",5.2,5.1,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (3.0,5.2,5.0,5.2,LT_DOTDASH,1,CLR_BLACK);

   add_text ("Dot Dot Dash",5.2,4.8,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (3.0,4.9,5.0,4.9,LT_DOTDOTDASH,1,CLR_BLACK);

   add_text ("Plus Point",5.2,4.5,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (4.0,4.6,0.0,0.0,PNT_PLUS,1,CLR_BLACK);

   add_text ("X Point",5.2,4.2,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (4.0,4.3,0.0,0.0,PNT_X,1,CLR_BLACK);

   add_text ("Triangle Point",5.2,3.9,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (4.0,4.0,0.0,0.0,PNT_TRIANGLE,1,CLR_BLACK);

   add_text ("Circle Point",5.2,3.6,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (4.0,3.7,0.0,0.0,PNT_CIRCLE,1,CLR_BLACK);

   add_text ("Square Point",5.2,3.3,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (4.0,3.4,0.0,0.0,PNT_SQUARE,1,CLR_BLACK);



   add_text ("Thickness = 1",9.2,6.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (7.0,6.1,9.0,6.1,LT_SOLID,1,CLR_BLACK);

   add_text ("Thickness = 3",9.2,5.7,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (7.0,5.8,9.0,5.8,LT_SOLID,3,CLR_BLACK);

   add_text ("Thickness = 5",9.2,5.4,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (7.0,5.5,9.0,5.5,LT_SOLID,5,CLR_BLACK);

   add_text ("Thickness = 7",9.2,5.1,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_line (7.0,5.2,9.0,5.2,LT_SOLID,7,CLR_BLACK);

   if (!draw_page ())
      {
      printf ("page draw failed.\n");
      return -1;
      }

   close_graphics_device ();

   return 0;
   }
