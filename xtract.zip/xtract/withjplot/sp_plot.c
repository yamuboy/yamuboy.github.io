#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <jplot.h>
#include <cmplxlib.h>

#define MAX_FREQ_PTS   1000

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, int max_pts);
		   
void print_usage( char * progname ) 
{
   printf( "\nUSAGE: %s [options] file\n\n", progname );
   printf( "  Options:\n" );
   printf( "     -wmf, -meta   Set output device to metafile.\n" );
   printf( "     -ps           Set output device to postscript.\n" );
   printf( "     -o name       Set plot file name to \'name\'.\n" );
   printf( "     -db           Plot in dB.\n" );
   printf( "     -np           Disable plotting of phase on the Y2 axis.\n" );
   printf( "\n" );

}

int main (int argc, char *argv[])
   {
   int     i;
   double  freq[MAX_FREQ_PTS];
   double  s11m[MAX_FREQ_PTS];
   double  s11a[MAX_FREQ_PTS];
   double  s12m[MAX_FREQ_PTS];
   double  s12a[MAX_FREQ_PTS];
   double  s21m[MAX_FREQ_PTS];
   double  s21a[MAX_FREQ_PTS];
   double  s22m[MAX_FREQ_PTS];
   double  s22a[MAX_FREQ_PTS];
   double  k_fact[MAX_FREQ_PTS];
   double  MAG[MAX_FREQ_PTS];
   double  h21m[MAX_FREQ_PTS];
   double  h21a[MAX_FREQ_PTS];
   FILE    *infile;
   jPLOT_ITEM *plot1;
   int device = X_WINDOWS;
   char pname[256];
   int db_mode=0;
   int plot_phase=1;
   char file_name[256];
   COMPLEX tmpc[4];
   POLAR tmpp[4];
   double tmpd;
   int num_freq_pts;

   strcpy(pname,"plotfile.ps");
   *file_name = '\0';

   if( argc < 2 ) {
      print_usage(argv[0]);
      return 0;
   }

// parse the command line
for( i=1; i<argc; ++i ) {
   if( argv[i][0] == '-' ) {
      if( !strcmp(argv[i],"-ps") || !strcmp(argv[i],"-dP") ) device=POSTSCRIPT;
      else if( !strcmp(argv[i],"-wmf") || !strcmp(argv[i],"-dM") || !strcmp(argv[i],"-meta") ) device=METAFILE;
      else if( !strcmp(argv[i],"-o") ) {
         if( i == argc-1 ) {
            fprintf( stderr, "Error: missing parameter to -o option.\n" );
            print_usage(argv[0]);
            exit(1);
	 }
	 strcpy(pname,argv[++i]);
      }
      else if( !strcmp(argv[i],"-db") || !strcmp(argv[i],"-dB") ) db_mode=1; 
      else if( !strcmp(argv[i],"-np") ) plot_phase=0; 
      else {
         fprintf( stderr, "Error: unrecognized command line option: %s\n", argv[i] );
	 print_usage(argv[0]);
	 exit(1);
      }
   }
   else {
      strcpy( file_name, argv[i] );
   }
}

   if( ! *file_name ) {
      fprintf( stderr, "Error: no file specified.\n" );
      print_usage(argv[0]);
      exit(1);
   }

   infile = fopen( file_name,"r" );
   if( !infile ) {
      fprintf (stderr, "error: UNABLE TO OPEN FILE - %s\n",file_name);
      return -1;
   }

   // read in the data
   num_freq_pts = read_s_params(infile,freq,s11m,s11a,s12m,s12a,s21m,s21a,s22m,s22a,MAX_FREQ_PTS);

   fclose (infile);

   if( !num_freq_pts ) {
      fprintf( stderr, "Error: file is empty.\n" );
      return -1;
   }

   /* calculate K, MAG, and H-Params */
   for( i=0; i<num_freq_pts; ++i ) {
      tmpp[0].m = s11m[i];
      tmpp[0].a = s11a[i];
      tmpp[1].m = s12m[i];
      tmpp[1].a = s12a[i];
      tmpp[2].m = s21m[i];
      tmpp[2].a = s21a[i];
      tmpp[3].m = s22m[i];
      tmpp[3].a = s22a[i];

      PA2CA (tmpp, tmpc, 2, 2);

      k_mag (tmpc, &k_fact[i], &MAG[i], &tmpd);
      s2h (tmpc, tmpc, 50.0);
      CA2PA (tmpc, tmpp, 2, 2);

      h21m[i] = 20.0*log10 (tmpp[2].m);
      h21a[i] = tmpp[2].a;

      // convert to dB if necessary
      if( db_mode ) {
         s11m[i] = 20. * log10( s11m[i] );
         s12m[i] = 20. * log10( s12m[i] );
         s21m[i] = 20. * log10( s21m[i] );
         s22m[i] = 20. * log10( s22m[i] );
      }
   }

   /* draw the plots */

   if( !open_graphics_device (device,pname) ) {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      return -1;
   }

   plot1 = create_plot_item (DoubleY, 2., 1.5, 7, 5.5);

   for (i = 0; i < 6; ++i)
      {
      switch (i)
         {
         case 0:
            attach_y1data (plot1,freq,s11m,num_freq_pts,LT_SOLID,1,CLR_RED);
            if(plot_phase) attach_y2data (plot1,freq,s11a,num_freq_pts,LT_SOLID,1,CLR_BLUE);
            if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S11)", "phase(S11)", "S11");
            else set_axis_labels (plot1, "Freq (GHz)", "mag(S11)", "phase(S11)", "S11");
            break;
         case 1:
            attach_y1data (plot1,freq,s21m,num_freq_pts,LT_SOLID,1,CLR_RED);
            if(plot_phase) attach_y2data (plot1,freq,s21a,num_freq_pts,LT_SOLID,1,CLR_BLUE);
            if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S21)", "phase(S21)", "S21");
            else set_axis_labels (plot1, "Freq (GHz)", "mag(S21)", "phase(S21)", "S21");
            break;
         case 2:
            attach_y1data (plot1,freq,s12m,num_freq_pts,LT_SOLID,1,CLR_RED);
            if(plot_phase) attach_y2data (plot1,freq,s12a,num_freq_pts,LT_SOLID,1,CLR_BLUE);
            if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S12)", "phase(S12)", "S12");
            else set_axis_labels (plot1, "Freq (GHz)", "mag(S12)", "phase(S12)", "S12");
            break;
         case 3:
            attach_y1data (plot1,freq,s22m,num_freq_pts,LT_SOLID,1,CLR_RED);
            if(plot_phase) attach_y2data (plot1,freq,s22a,num_freq_pts,LT_SOLID,1,CLR_BLUE);
            if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S22)", "phase(S22)", "S22");
            else set_axis_labels (plot1, "Freq (GHz)", "mag(S22)", "phase(S22)", "S22");
            break;
         case 4:
            attach_y1data (plot1,freq,MAG,num_freq_pts,LT_SOLID,1,CLR_RED);
            attach_y2data (plot1,freq,k_fact,num_freq_pts,LT_SOLID,1,CLR_BLUE);
            set_axis_labels (plot1, "Freq (GHz)", "dB(MAG or MSG)", "K-Factor", "K & MAG/MSG");
            break;
         case 5:
            attach_y1data (plot1,freq,h21m,num_freq_pts,LT_SOLID,1,CLR_RED);
            if(plot_phase) attach_y2data (plot1,freq,h21a,num_freq_pts,LT_SOLID,1,CLR_BLUE);
            set_axis_labels (plot1, "Freq (GHz)", "dB(H21)", "phase(H21)", "H21");
            set_axis_scaling (plot1, LogX);
            break;
         }
      
      if (!draw_page ())
         {
         printf ("%s\n",get_error_message (ERROR_NUMBER));
         return -1;
         }

      detach_data (plot1);
      }
            
   close_graphics_device ();

   return 0;
   }


/*********************************************************************************************/
/*********************************************************************************************/

double satan2 (double y, double x)
   {
   if ((x == 0.0) && (y == 0.0))
      return 0.0;
   else
      return atan2(y,x);
   }         
      
/*********************************************************************************************/
/*********************************************************************************************/

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, int max_pts)
   {
   char string[256],tmp[6];
   int i = 0;
   int ri_mode = 0;
   int db_mode = 0;
   double fscale = 1.0e-9;
   double rad_to_deg = 180.0/acos(-1.0);
   double dtmp;
   
   while (fgets(string,255,infile))
   {
      if (i >= max_pts)
         break;
         
      if (string[0] == '!')
         continue;
      
      if (sscanf(string,"# %5s %5s",tmp,tmp) == 2)
      {
         for( i=0; i<strlen(string); ++i ) {
	    if( string[i] >= 'A' && string[i] <='Z' ) string[i] += (char) ('a' -'A');
	 }
         if (strstr(string,"ri"))
            ri_mode = 1;
         if (strstr(string,"db"))
            db_mode = 1;
         
         if (strstr(string,"ghz"))
            fscale = 1.0;
         else if (strstr(string,"mhz"))
            fscale = 1.0e-3;
         else if (strstr(string,"khz"))
            fscale = 1.0e-6;
      }
      
      if (sscanf(string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq[i],&s11m[i],&s11a[i],&s21m[i],&s21a[i],&s12m[i],&s12a[i],
         &s22m[i],&s22a[i]) == 9)
      {
         freq[i] *= fscale;
         
         if (ri_mode) {
            dtmp = s11m[i];
            s11m[i] = sqrt (s11m[i]*s11m[i] + s11a[i]*s11a[i]);
            s11a[i] = rad_to_deg*satan2 (s11a[i],dtmp);
            
            dtmp = s12m[i];
            s12m[i] = sqrt (s12m[i]*s12m[i] + s12a[i]*s12a[i]);
            s12a[i] = rad_to_deg*satan2 (s12a[i],dtmp);            

            dtmp = s21m[i];
            s21m[i] = sqrt (s21m[i]*s21m[i] + s21a[i]*s21a[i]);
            s21a[i] = rad_to_deg*satan2 (s21a[i],dtmp); 
                       
            dtmp = s22m[i];
            s22m[i] = sqrt (s22m[i]*s22m[i] + s22a[i]*s22a[i]);
            s22a[i] = rad_to_deg*satan2 (s22a[i],dtmp);
         }
	 else if( db_mode ) {
	       // need to convert from dB to mag
	       s11m[i] = pow( 10., 0.05 * s11m[i] );
	       s12m[i] = pow( 10., 0.05 * s12m[i] );
	       s21m[i] = pow( 10., 0.05 * s21m[i] );
	       s22m[i] = pow( 10., 0.05 * s22m[i] );
	 }
         
      ++i;
      }
   }
   
   return i;
}
         
      
            
         
         
