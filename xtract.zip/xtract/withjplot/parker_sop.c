#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include "optimize4.h"
#include "jplot.h"
#include "fit_tools.h"

/****** MACROS AND DEFINITIONS ******/

#define VERSION      2.0

#define sqr(x)    ((x)*(x))

#define MAX_AC_BIAS_PTS    250
#define MAX_DCIV_PTS       1000
#define MAX_DIODE_PTS      100
#define MAX_FWD_IGS        0.5      // in mA/mm
#define MAX_EXP_ARG        30.0
#define MAX_CONV_ITER      500

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19
#define CTOK          273.15

// plot definitions
#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_SOLID
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_BLUE
#define MOD2_COLOR    CLR_PURPLE
#define MOD2_COLOR    CLR_YELLOW
#define PLOT_X        2.25
#define PLOT_Y        2.25
#define PLOT_XSIZE    6.0
#define PLOT_YSIZE    5.5

#define TEST_SYSTEM_RESOLUTION   (1.e-6)

typedef struct
{
   double vgs,vds,vgsi,vdsi,igs,ids;
   double cgs,cgd,cds,ri;
   double gm,gds,tau,tau2;
} AC_PARAMETERS;

typedef struct
{
   double area,ugw,ngf;
   double rg,rd,rs,ri;
   double lg,ld,ls;
   double cpg,cpd,c11,c22;
   double is,n,ibd,vbd;
   double vleak, ileak;
   double tnom;
} FIXED_PARAMS;

typedef struct
{
   unsigned n;
   IV_DATA *data;
   int logdata;
} DCIV_OPT;

typedef struct
{
   AC_PARAMETERS *cvgs, *cvds;
   int nvgs, nvds;
} CAP_DATA;

typedef struct
{
   AC_PARAMETERS *cvgs, *cvds;
   int nvgs, nvds;
} GM_DATA;


/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header( char *data_file, char *header, unsigned max_size );
static int write_data_files( char *end_file, char *model_file, char *header, MODEL_PARAMS *params, FIXED_PARAMS fixed );

static int get_ss_parameters( char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n );

static int dciv_erf( double *p, void *data, double *err, unsigned n_err );
static int charge_erf( double *p, void *data, double *err, unsigned n_err );
static int gm_gds_erf( double *p, void *data, double *err, unsigned n_err );

static void create_plot( double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling );
static void create_plot2( double *x, double *y1_meas, double *y1_mod,
                          double *y2_meas, double *y2_mod, unsigned n,
                          char *x_lab, char *y_lab, char *y2_lab, char *title, unsigned scaling );
static int plot_data( int dev, char *head );

static int get_vgs_vds_targets( IV_DATA *d, int npts, double target_vds, double target_ids,
                               double *vds_actual, double *vgs_actual, double *ids_actual, int *idx );

static int fit_diode_curves( char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p );
static int fit_dc_curves( char *dc_iv_file, MODEL_PARAMS *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p );
static int fit_capacitance_data( AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p );
static int fit_gm_gds( AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p );

static double safe_pow( double x, double y );
static void write_starting_files( char *input_file, char *param_file );

static double parker_current( double *p, double Vgs, double Vds, double *Gm, double *Gds );
static void parker_charge( double *p, double Vgs, double Vgd, double *cgs, double *cgd,
                           double *dqgs_vgd, double *dqgd_vgs );

static void check_parameter_ranges( MODEL_PARAMS *p, double Vmax, double Vpo );
static void read_vmax_from_file( char *fname, double *vmax, double *vpo );

/* ------------- GLOBAL VARIABLES -------------- */

static char global_warning_msg[5000];

static const char *global_iv_param_names[] = {"vbi", "beta", "vto", "p", "delta", "q", "vst", "mvst", "xi", "mxi",
"lambda", "z", "lfgam", "lfg1", "lfg2", "tm", "vhr", "mvhr", "vht", "etah", "hfgam", "hfg1", "hfg2",
"hfeta", "hfe1", "hfe2"
};
#define N_IV_PARAMS  26

static const char *global_charge_param_names[] = {"vbi", "beta", "vto", "p", "delta", "q", "vst", "mvst", "xi", "mxi",
"lambda", "z", "lfgam", "lfg1", "lfg2", "tm", "vhr", "mvhr", "vht", "etah", "hfgam", "hfg1", "hfg2",
"hfeta", "hfe1", "hfe2", "cds", "tau", "cgs", "cgd", "fc", "acgam", "xc"
};
#define N_CHARGE_PARAMS   33

#define CDS_INDEX    26
#define TAU_INDEX    27
#define DELTA_INDEX  4

static double target_vds = 3.;
static double target_ids_mamm = 100.;
static double target_ids = 100.;

#define MAX_PLOTS     (20)

static jPLOT_ITEM* plot_list[MAX_PLOTS];
static int current_plot_number = 0;

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
{
   char string[256];
   char model_summary_file[100], start_file[100], end_file[100];
   char model_file[100], yfit_file[100], dc_iv_file[100];
   char fwd_iv_file[100], breakdown_file[100], header[3000];
   MODEL_PARAMS *params;
   AC_PARAMETERS ac_data[MAX_AC_BIAS_PTS];
   FIXED_PARAMS fixed_params;
   unsigned num_ac_bias_pts, niter;
   double maximum_vds;
   int plot_dev = X_WINDOWS;
   int i;
   int no_dc = 0;
   int no_gm = 0;
   int no_cap = 0;
   double vmax, vpo;
   double delta = 0.;
   OPT_PARAMETER x;

   global_warning_msg[0] = 0;

   /**** parse the command line ****/

   for( i = 1; i < argc; ++i ) {
      if( !strncmp( argv[i], "-i", 2 ) || !strncmp( argv[i], "-e", 2 ) ) {
         write_starting_files( "parkerin", "parker.end" );
         return 0;
      }
      else if (!strncmp (argv[i], "-h", 2)) {
         printf ("\n\n");

         printf ("Parker-Skellern model fitter options:\n");
         printf ("------------------------------------------------------------------\n");
         printf ("  -i, -e    Auto-generate an input file named parkerin and a\n");
         printf ("              starting values file named parker.start.\n");
         printf ("  -dP, -dp  Set plot device to postscript.\n");
         printf ("  -dM, -dm  Set plot device to metafile.\n");
         printf ("  -d0       Disable plotting.\n");
         printf ("  -skipdc   Skip the DC I-V fitting routine.\n");
         printf ("  -skipgm   Skip the transconductance fitting routine.\n");
         printf ("  -skipcap  Skip the capacitance/charge fitting routine.\n");

         printf ("\n\n");

         return 0;
      }
      else if( !strncmp(argv[i], "-d", 2) ) {
         char ch = 0;
         sscanf (argv[i], "-d%c", &ch);
         if ((ch == 'm') || (ch == 'M'))
            plot_dev = METAFILE;
         else if ((ch == 'p') || (ch == 'P'))
            plot_dev = POSTSCRIPT;
         else if (ch == '0')
            plot_dev = 0;
         else
            printf ("Warning: invalid -d option.\n");
      }
      else if( !strncmp(argv[i], "-skipdc", 7) ) no_dc = 1;
      else if( !strncmp (argv[i], "-skipgm", 7) ) no_gm = 1;
      else if( !strncmp (argv[i], "-skipcap", 8) ) no_cap = 1;
   }

   /**** get user input ****/

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ugw);

   fixed_params.area = fixed_params.ngf * fixed_params.ugw;

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.tnom);

   printf ("Y-fit end file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",yfit_file);

   printf ("Model summary file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_summary_file);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Forward IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",breakdown_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   printf ("Target Vds and Ids(mA)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf", &target_vds, &target_ids_mamm );

   printf ("Value of DELTA (heating parameter)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf", &delta );


   /**** get measurement and extraction data ****/

   if( read_model_parameters_from_file( start_file, &params, NULL ) ||
       get_ss_parameters( model_summary_file, yfit_file, ac_data, MAX_AC_BIAS_PTS, &fixed_params, &num_ac_bias_pts ) )
      return 1;

    // set the value of delta
    strcpy( x.name, "delta" );
    x.min = x.nom = x.max = delta;
    x.tol = 0.;
    set_parameter_value( params, x );

   // read in Vmax, use for VBI model parameter
   read_vmax_from_file( fwd_iv_file, &vmax, &vpo );

   // compute target_ids given it's ma/mm value and the device periphery
   target_ids = target_ids_mamm * fixed_params.area * 1.e-6;

   // check for bad starting values or illegal range values
   //    (i.e. parameters that must be >= 0)
   if( niter > 0 ) check_parameter_ranges( params, vmax, vpo );

   /**** perform various parameter fits ****/

   if( fit_diode_curves( fwd_iv_file, breakdown_file, &fixed_params ) ) return 1;
   if( !no_dc && fit_dc_curves( dc_iv_file, params, maximum_vds, niter, &fixed_params ) ) return 1;
   if( !no_gm && fit_gm_gds( ac_data, num_ac_bias_pts, params, niter, &fixed_params ) ) return 1;
   if( !no_cap && fit_capacitance_data( ac_data, num_ac_bias_pts, params, niter, &fixed_params ) ) return 1;

   /**** Write final data files ****/

   printf( "Writing data files.\n" );
   get_file_header( fwd_iv_file, header, 3000 );
   if( write_data_files( end_file, model_file, header, params, fixed_params ) ) return 1;

   /***** Generate plots *****/

   if( plot_dev ) {
      char plot_head[1000];
      FILE *file;

      // get the plot header
      plot_head[0] = 0;
      file = fopen (fwd_iv_file, "r");
      if( file ) {
         while (fgets (string, 255, file)) {
            if (string[0] != '!') break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
         }

         fclose (file);
      }

      if( plot_data( plot_dev, plot_head ) ) return 1;
   }

   if (global_warning_msg[0]) {
      printf ("\n%s", global_warning_msg);
      printf ("\nModel fitting completed with warnings.\n\n");
   }
   else
      printf ("\n\nModel fitting complete.\n\n");

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static void post_error_msg( const char *str )
{
   fprintf( stderr, "%s\n", str );
}
/*****************************************************************************/
/*****************************************************************************/
static void post_info_msg( const char *str )
{
   fprintf( stdout, "%s\n", str );
}

/*****************************************************************************/
/*****************************************************************************/
static void log_warning( const char* msg )
{
    strcat( global_warning_msg, msg );
    if( msg[strlen(msg)-1] != '\n' ) strcat( global_warning_msg, "\n" );
}

/*****************************************************************************/
/*****************************************************************************/
static int fit_diode_curves( char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p )
{
   IV_DATA fwd_curves[MAX_DIODE_PTS], vbr_curves[MAX_DIODE_PTS];
   unsigned n_fwd_pts, n_vbr_pts;
   double v[MAX_DIODE_PTS], i[MAX_DIODE_PTS];
   unsigned j, k;
   double m, b, r2;
   double *vr, *ir_meas, *ir_mod;
   double *vf, *if_meas, *if_mod;
   char str[256];

   /***** Forward IV *****/

   printf( "Forward Diode IV.\n" );

   if( get_iv_data( fwd_iv_file, fwd_curves, MAX_DIODE_PTS, &n_fwd_pts ) )
      return 1;

   for( j = 0, k = 0; j < n_fwd_pts; ++j ) {
      if( fwd_curves[j].vds == 0.0 && fwd_curves[j].igs > 1.0e-8*fixed_p->area ) {
         v[k] = fwd_curves[j].vgs;
         i[k] = log (fwd_curves[j].igs);
         ++k;
      }
   }

   if (k < 2) {
      sprintf( str, "fit_diode_curves(): %s: not enough points.\n", fwd_iv_file );
      log_warning( str );
      fixed_p->is = 0.;
      fixed_p->n = 1.;
   }
   else {
       linefit_mxb(v, i, k, &m, &b, &r2);

       fixed_p->is = 0.5 * exp(b);
       fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * (fixed_p->tnom + CTOK));

        // create a plot
        vf = (double *) malloc(sizeof(double)*n_fwd_pts);
        if_meas = (double *) malloc(sizeof(double)*n_fwd_pts);
        if_mod = (double *) malloc(sizeof(double)*n_fwd_pts);
        for (j = 0, k = 0; j < n_fwd_pts; ++j) {
            if( fwd_curves[j].vds == 0.0 && fwd_curves[j].igs > 0.0 ) {
                vf[k] = fwd_curves[j].vgs;
                if_meas[k] = fwd_curves[j].igs * 1.0e6 / fixed_p->area;
                if_mod[k] = 2.0 * fixed_p->is * (exp (vf[k] * Q_ELECTRON / (fixed_p->n * BOLTZMANN * (fixed_p->tnom + CTOK))) - 1.0) * 1.0e6 / fixed_p->area;
                ++k;
            }
        }
        create_plot( vf, if_meas, if_mod, k, "Vgs (volts", "Igs (mA/mm)", "Diode Characteristic", LogY1 );
   }

   /***** Breakdown *****/

   printf( "Reverse Diode Breakdown.\n" );

   if( get_iv_data( vbr_iv_file, vbr_curves, MAX_DIODE_PTS, &n_vbr_pts ) ) return 1;
   if( n_vbr_pts < 2 ) {
      sprintf( str, "fit_diode_curves(): %s: not enough points.\n", vbr_iv_file );
      log_warning( str );
      fixed_p->ibd = 0.;
      fixed_p->vbd = 1.;
   }
   else {
       double vb, vbm;
       // use the last two points for VBR
       v[0] = vbr_curves[n_vbr_pts-2].vds - vbr_curves[n_vbr_pts-2].vgs;
       i[0] = log( -vbr_curves[n_vbr_pts-2].igs );
       v[1] = vbr_curves[n_vbr_pts-1].vds - vbr_curves[n_vbr_pts-1].vgs;
       i[1] = log( -vbr_curves[n_vbr_pts-1].igs );
       linefit_mxb( v, i, 2, &m, &b, &r2 );

       fixed_p->ibd = exp(b);
       fixed_p->vbd = 1. / m;

       // use points between 25% and 50% of breakdown to fit the leakage
        vbm = vbr_curves[n_vbr_pts-1].vds - vbr_curves[n_vbr_pts-1].vgs;
        for( j=0, k=0; j<n_vbr_pts; ++j ) {
            vb = vbr_curves[j].vds - vbr_curves[j].vgs;
            if( vbr_curves[j].igs < 0. && vb >= 0.25*vbm && vb <= 0.5*vbm ) {
                v[k] = vb;
                i[k] = log( -vbr_curves[j].igs );
                ++k;
            }
        }

        if( k < 2 ) {
            sprintf( str, "fit_diode_curves(): leakage fit on %s: not enough points.\n", vbr_iv_file );
            log_warning( str );
            fixed_p->ileak = 0.;
            fixed_p->vleak = 1.;
        }
        else {
            linefit_mxb( v, i, k, &m, &b, &r2 );
            fixed_p->ileak = exp(b);
            fixed_p->vleak = 1. / m;
        }

       // create a plot
          vr = (double *) malloc(sizeof(double)*n_vbr_pts);
          ir_meas = (double *) malloc(sizeof(double)*n_vbr_pts);
          ir_mod = (double *) malloc(sizeof(double)*n_vbr_pts);
          for (j = 0, k = 0; j < n_vbr_pts; ++j) {
             if( vbr_curves[j].igs < 0. ) {
                vr[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
                ir_meas[k] = -vbr_curves[j].igs * 1.0e6 / fixed_p->area;
                ir_mod[k] = ( fixed_p->ibd*(exp(vr[k] / fixed_p->vbd) - 1.) +  fixed_p->ileak*(exp(vr[k] / fixed_p->vleak) - 1.) ) * 1.0e6 / fixed_p->area;
                ++k;
             }
          }
          create_plot( vr, ir_meas, ir_mod, k, "Vdg (volts", "Idg (mA/mm)", "Diode Breakdown", LogY1 );
   }

   printf( "%lg %lg\n",fixed_p->ibd, fixed_p->vbd );

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static IV_DATA apply_port_resistance_and_iso( IV_DATA* dat, FIXED_PARAMS* p, double delta )
{
    IV_DATA ret = *dat;
    if( dat->igs > 0. ) {
        ret.vds -= dat->ids*p->rd + (dat->ids+dat->igs)*p->rs;
        ret.vgs -= dat->igs*p->rg + (dat->ids+dat->igs)*p->rs;
    }
    else {
        ret.vds -= (dat->ids-dat->igs)*p->rd + dat->ids*p->rs;
        ret.vgs -= dat->igs*p->rg + dat->ids*p->rs;
    }

    // do isothermal correction
    ret.ids *= (1. + delta * ret.ids * ret.vds);

    return ret;
}


/*****************************************************************************/
/*****************************************************************************/
static int fit_dc_curves( char *dc_iv_file, MODEL_PARAMS *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p )
{
   unsigned n_raw_iv_pts;
   int n_iv = 0;
   int n_subth = 0;
   IV_DATA raw_dciv[MAX_DCIV_PTS];
   IV_DATA dciv[MAX_DCIV_PTS];
   IV_DATA subth[MAX_DCIV_PTS];
   IV_DATA at_vd[50];
   unsigned i, j;
   OPT_PARAMETER pp[N_IV_PARAMS];
   double delta;
   double vd, id, vg;
   int idx;
   int n_at_vd = 0;
   double *atvd_v, *atvd_imeas, *atvd_imod;
   double *subth_v, *subth_imeas, *subth_imod;
   double *dciv_v, *dciv_imod, *dciv_imeas;
   double pl[N_IV_PARAMS];

   printf( "DC IV data.\n" );

   // load the model parameters and I-V data
   if( get_all_parameters(global_iv_param_names, N_IV_PARAMS, p, pp)
      || get_iv_data(dc_iv_file, raw_dciv, MAX_DCIV_PTS, &n_raw_iv_pts) ) return 1;

   delta = pp[DELTA_INDEX].nom;

    // remove points greater than max_vds
    for( i=0; i<n_raw_iv_pts; ++i ) {
        if( raw_dciv[i].vds <= max_vds ) {
            dciv[n_iv] = raw_dciv[i];
            ++n_iv;
        }
    }

   // find a value for target VDS
   //  and form a set of data at that value of VDS
   //  also correct for port resistances
   if( get_vgs_vds_targets(dciv, n_iv, target_vds, target_ids, &vd, &vg, &id, &idx) ) return 1;
   for( i=0; i<n_iv; ++i ) {
       if( n_at_vd >= 50 ) break;
       else if( dciv[i].vds == vd ) {
           at_vd[n_at_vd] = apply_port_resistance_and_iso( &dciv[i], fixed_p, delta );
           ++n_at_vd;
       }
   }

   // check for a valid data set
   if( n_at_vd < 5 ) {
       fprintf( stderr, "Not enough data for fixed Vds fitting at target Vds of %lg.\n", vd );
       return 1;
   }

   // optimization of fixed Vds curve
   if( niter > 0 ) {
      OPTIMIZE *opt;
      DCIV_OPT opt_data;
      int param_list[] = { 1, 2, 5, 12, 13, 14, 15, 16, 18 };
      int len_params = 9;

      opt_data.n = n_at_vd;
      opt_data.data = at_vd;
      opt_data.logdata = 0;

      opt = initialize_cg_optimizer ();
      set_cg_parameters( opt, pp, N_IV_PARAMS );
      set_cg_flags( opt, OPT_SINGLE_PARAM );
      set_cg_error_function( opt, dciv_erf, &opt_data, 1, NULL );
      set_cg_error_fraction( opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for( i=0; i<len_params; ++i ) pp[param_list[i]].optimize = TRUE;

      if( cg_optimize4(opt, niter, NULL) ) {
         fprintf( stderr, "Error: cg_optimize4(): %s.\n", get_cg_error() );
         return -1;
      }

      // turn off optimization for appropriate parameters
      for( i=0; i<len_params; ++i ) pp[param_list[i]].optimize = FALSE;

      free((void *) opt);
      if( set_all_parameters( p, pp, N_IV_PARAMS ) ) return 1;
   }

   // now that VTO has been optimized, select the sub-threshold data set
   for( i=0; i<n_iv; ++i) {
       if( dciv[i].vds > 0.9 && dciv[i].vgs < pp[2].nom && dciv[i].ids > TEST_SYSTEM_RESOLUTION ) {
           subth[n_subth] = dciv[i];
           ++n_subth;
       }
   }

   // now apply port resistances to the full I-V plane data set
   //  and correct data for isothermal
   for( i=0; i<n_iv; ++i ) dciv[i] = apply_port_resistance_and_iso( &dciv[i], fixed_p, delta );

   // optimize the full I-V plane
   if( niter > 0 ) {
      OPTIMIZE *opt;
      DCIV_OPT opt_data;
      int param_list[] = { 1, 2, 3, 5, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
      int len_params = 15;

      opt_data.n = n_iv;
      opt_data.data = dciv;
      opt_data.logdata = 0;

      opt = initialize_cg_optimizer ();
      set_cg_parameters( opt, pp, N_IV_PARAMS );
      set_cg_flags( opt, OPT_VERBOSE | OPT_SINGLE_PARAM );
      set_cg_error_function( opt, dciv_erf, &opt_data, 1, NULL );
      set_cg_error_fraction( opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for( i=0; i<len_params; ++i ) pp[param_list[i]].optimize = TRUE;

      if( cg_optimize4(opt, niter, NULL) ) {
         fprintf( stderr, "Error: cg_optimize4(): %s.\n", get_cg_error() );
         return -1;
      }

      // turn off optimization for appropriate parameters
      for( i=0; i<len_params; ++i ) pp[param_list[i]].optimize = FALSE;

      free((void *) opt);
      if( set_all_parameters( p, pp, N_IV_PARAMS ) ) return 1;
   }

   if( n_subth < 5 ) {
       // this is not a fatal error
      log_warning( "Warning: unable to form subthreshold data set." );
      return 0;
   }

   // sort and take the log of the the subthreshold data set
   for( i=0; i<n_subth; ++i ) {
      for( j=i+1; j<n_subth; ++j ) {
         if( subth[j].vds < subth[i].vds || ( subth[j].vds == subth[i].vds && subth[j].vgs < subth[i].vgs ) ) {
            IV_DATA tmp = subth[i];
            subth[i] = subth[j];
            subth[j] = tmp;
         }
      }
      subth[i].ids = log( subth[i].ids );
   }

   // lastly, optimize the sub-threshold slope parameters
   if( niter > 0 ) {
      OPTIMIZE *opt;
      DCIV_OPT opt_data;
      int param_list[] = { 6, 7 };
      int len_params = 2;

      opt_data.n = n_subth;
      opt_data.data = subth;
      opt_data.logdata = 1;

      opt = initialize_cg_optimizer ();
      set_cg_parameters( opt, pp, N_IV_PARAMS );
      set_cg_flags( opt, OPT_SINGLE_PARAM );
      set_cg_error_function( opt, dciv_erf, &opt_data, 1, NULL );
      set_cg_error_fraction( opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for( i=0; i<len_params; ++i ) pp[param_list[i]].optimize = TRUE;

      if( cg_optimize4(opt, niter, NULL) ) {
         fprintf( stderr, "Error: cg_optimize4(): %s.\n", get_cg_error() );
         return -1;
      }

      // turn off optimization for appropriate parameters
      for( i=0; i<len_params; ++i ) pp[param_list[i]].optimize = FALSE;

      free((void *) opt);
      if( set_all_parameters( p, pp, N_IV_PARAMS ) ) return 1;
   }

   /* create plots */

    atvd_v = (double *) malloc(sizeof (double) * n_at_vd);
    atvd_imeas = (double *) malloc(sizeof (double) * n_at_vd);
    atvd_imod = (double *) malloc(sizeof (double) * n_at_vd);
    subth_v = (double *) malloc(sizeof (double) * n_subth);
    subth_imeas = (double *) malloc(sizeof (double) * n_subth);
    subth_imod = (double *) malloc(sizeof (double) * n_subth);
    dciv_v = (double *) malloc(sizeof (double) * n_iv);
    dciv_imeas = (double *) malloc(sizeof (double) * n_iv);
    dciv_imod = (double *) malloc(sizeof (double) * n_iv);

    for( i=0; i<N_IV_PARAMS; ++i )  pl[i] = pp[i].nom;

    for( i=0; i<n_at_vd; ++i ) {
        atvd_v[i] = at_vd[i].vgs;
        atvd_imeas[i] = at_vd[i].ids * 1.0e3;
        atvd_imod[i] = parker_current( pl, at_vd[i].vgs, at_vd[i].vds, NULL, NULL ) * 1.0e3;
    }

    create_plot( atvd_v, atvd_imeas, atvd_imod, n_at_vd, "Vgs (volts)", "Ids (mA)", "Constant Vd Curve", 0 );

    for( i=0; i<n_iv; ++i ) {
        dciv_v[i] = dciv[i].vds;
        dciv_imeas[i] = dciv[i].ids * 1.0e3;
        dciv_imod[i] = parker_current( pl, dciv[i].vgs, dciv[i].vds, NULL, NULL ) * 1.0e3;
    }

    create_plot( dciv_v, dciv_imeas, dciv_imod, n_iv, "Vds (volts)", "Ids (mA)", "DC I-V Curves", POSITIVE_X | POSITIVE_Y1 );

    for( i=0; i<n_subth; ++i ) {
        subth_v[i] = subth[i].vgs;
        subth_imeas[i] = exp(subth[i].ids) * 1.0e3;  // correct for the log of the data taken above
        subth_imod[i] = parker_current( pl, subth[i].vgs, subth[i].vds, NULL, NULL ) * 1.0e3;
    }

    create_plot( subth_v, subth_imeas, subth_imod, n_subth, "Vgs (volts)", "Ids (mA)", "Sub-Threshold Current", LogY1 );

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static int exists_in_list( double x, double *lst, int n )
{
   int i;
   for( i=0; i<n; i++ ) {
      if( x == lst[i] ) return 1;
   }
   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static int get_vgs_vds_targets( IV_DATA *d, int npts, double target_vds, double target_ids,
                               double *vds_actual, double *vgs_actual, double *ids_actual, int *idx )
{
   int i,j;
   double vds_list[100], ids_list[100], vgs_list[100];
   int nids=0, nvds=0;

   *vds_actual = -1.;
   *ids_actual = -1.;
   *idx = -1;

   // form a list of available vds values
   for( i=0; i<npts; i++ ) {
      if( !exists_in_list( d[i].vds, vds_list, nvds ) && nvds < 100 ) {
         vds_list[nvds] = d[i].vds;
         nvds++;
      }
   }
   // sort the list by ascending vds
   for( i=0; i<nvds; i++ ) {
      for( j=i; j<nvds; j++ ) {
         if( vds_list[j] < vds_list[i] ) {
            double t = vds_list[i];
            vds_list[i] = vds_list[j];
            vds_list[j] = t;
         }
      }
   }
   if( nvds < 1 ) {
      post_error_msg( "Error: get_vgs_vds_targets(): no Vds values found: data set is empty." );
      return 1;
   }
   // find the appropriate vds value
   for( i=0; i<(nvds-1); i++ ) {
      if( target_vds == vds_list[i] || target_vds == vds_list[i+1] ) {
         *vds_actual = target_vds;
         break;
      }
      else if( target_vds > vds_list[i] && target_vds < vds_list[i+1] ) {
         if( (target_vds-vds_list[i]) < 0.5*(vds_list[i+1] - vds_list[i]) )
            *vds_actual = vds_list[i];
         else
            *vds_actual = vds_list[i+1];
         break;
      }
   }
   if( *vds_actual < 0. ) {
      if( target_vds < vds_list[0] )
         *vds_actual = vds_list[0];
      else
         *vds_actual = vds_list[nvds-1];
   }
   // now form an ids/vgs list of values of the selected vds
   for( i=0; i<npts; i++ ) {
      if( d[i].vds == *vds_actual && nids < 100 ) {
         ids_list[nids] = d[i].ids;
         vgs_list[nids] = d[i].vgs;
         nids++;
      }
   }
   // sort the lists by ascending ids
   for( i=0; i<nids; i++ ) {
      for( j=i; j<nids; j++ ) {
         if( ids_list[j] < ids_list[i] ) {
            double t = ids_list[i];
            ids_list[i] = ids_list[j];
            ids_list[j] = t;
            t = vgs_list[i];
            vgs_list[i] = vgs_list[j];
            vgs_list[j] = t;
         }
      }
   }
   if( nids < 1 ) {
      post_error_msg( "Error: get_vgs_vds_targets(): error finding Ids values." );
      return 1;
   }
   // now find an appropriate vgs value
   for( i=0; i<(nids-1); i++ ) {
      if( target_ids == ids_list[i] ) {
         *ids_actual = ids_list[i];
         *vgs_actual = vgs_list[i];
         break;
      }
      else if( target_ids == ids_list[i+1] ) {
         *ids_actual = ids_list[i+1];
         *vgs_actual = vgs_list[i+1];
         break;
      }
      else if( target_ids > ids_list[i] && target_ids < ids_list[i+1] ) {
         if( (target_ids-ids_list[i]) < 0.5*(ids_list[i+1] - ids_list[i]) ) {
            *ids_actual = ids_list[i];
            *vgs_actual = vgs_list[i];
         }
         else {
            *ids_actual = ids_list[i+1];
            *vgs_actual = vgs_list[i+1];
         }
         break;
      }
   }
   if( *ids_actual < 0. ) {
      if( target_ids < ids_list[0] ) {
         *ids_actual = ids_list[0];
         *vgs_actual = vgs_list[0];
      }
      else {
         *ids_actual = ids_list[nids-1];
         *vgs_actual = vgs_list[nids-1];
      }
   }
   // determine the index of the actual bias point
   for( i=0; i<npts; i++ ) {
      if( *vgs_actual == d[i].vgs && *vds_actual == d[i].vds )
         *idx = i;
   }
   if( *idx < 0 ) {
      post_error_msg( "Error: get_vgs_vds_targets(): algorithm error." );
      return 1;
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static int fit_capacitance_data( AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p )
{
   unsigned i;
   double vds_actual, vgs_actual, ids_actual;
   OPT_PARAMETER pp[N_CHARGE_PARAMS];
   IV_DATA *iv;
   AC_PARAMETERS const_vds[50], const_vgs[50];
   int nvds=0, nvgs=0;
   int idx;
   double pl[N_CHARGE_PARAMS];
   char str[200];
   double *vgs, *vds;
   double *cgs_meas1, *cgs_mod1, *cgd_meas1, *cgd_mod1;
   double *cgs_meas2, *cgs_mod2, *cgd_meas2, *cgd_mod2;
   double cgs, cgd, qgs_vgd, qgd_vgs;
   double ww[2];
   ww[1] = 2;
   ww[2] = 1;

   post_info_msg( "CHARGE FIT: initializing." );

   // load the parameter starting values from the MODEL_PARAMS structure
   if( get_all_parameters( global_charge_param_names, N_CHARGE_PARAMS, p, pp ) ) return 1;

   // determine the appropriate target_vds and target_vgs values
   iv = (IV_DATA*) malloc( sizeof( IV_DATA ) * n );
   for( i=0; i<n; i++ ) {
      iv[i].vds = ac_data[i].vds;
      iv[i].vgs = ac_data[i].vgs;
      iv[i].ids = ac_data[i].ids;
   }
   if( get_vgs_vds_targets( iv, n, target_vds, target_ids, &vds_actual, &vgs_actual, &ids_actual, &idx ) ) {
      free( iv );
      return 1;
   }
   free( iv );

   // post some informational data
   sprintf( str, "CHARGE FIT: Vds_requested: %.3f Vds_actual: %.3f", target_vds, vds_actual );
   post_info_msg( str );
   sprintf( str, "CHARGE FIT: Ids_requested: %.2e Ids_actual: %.2e", target_ids, ids_actual );
   post_info_msg( str );
   sprintf( str, "CHARGE FIT: Vgs_actual: %.3f", vgs_actual );
   post_info_msg( str );

   // create data sets for constant vds and vgs fitting
   for( i=0; i<n; i++ ) {
      if( ac_data[i].vds == vds_actual && nvds < 50 ) {
         const_vds[nvds] = ac_data[i];
         nvds++;
      }
      if( ac_data[i].vgs == vgs_actual && nvgs < 50 ) {
         const_vgs[nvgs] = ac_data[i];
         nvgs++;
      }
   }
   if( nvds < 3 ) {
      post_error_msg( "CHARGE FIT: error: not enough data for constant Vds fitting (5 points minimum)." );
      return 1;
   }
   if( nvgs < 3 ) {
      post_error_msg( "CHARGE FIT: error: not enough data for constant Vgs fitting (3 points minimum)." );
      return 1;
   }

   if( niter > 0 ) {
      OPTIMIZE *opt;
      double cgs, cgd, dqgs_vgd, dqgd_vgs, gm;
      CAP_DATA cap_data;

      //  prepare for optimization
      cap_data.cvgs = const_vgs;
      cap_data.nvgs = nvgs;
      cap_data.cvds = const_vds;
      cap_data.nvds = nvds;
      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_CHARGE_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);
      
      set_cg_error_function (opt, charge_erf, &cap_data, 2, ww );
      set_cg_error_fraction (opt, 1.0e-11, 35);

      // set the appropriate optimization parameters
      for( i=28; i<=32; i++ ) pp[i].optimize = TRUE;
      
      // run optimization
      if( cg_optimize4( opt, niter, NULL ) ) {
         sprintf( str, "CHARGE FIT: error in optimization: %s.", get_opt_error() );
         return 1;
      }
      free( opt );

      // calculate cds and tau at the target bias point
      for( i=0; i<N_CHARGE_PARAMS; i++ )
         pl[i] = pp[i].nom;
      parker_charge( pl, ac_data[idx].vgsi, ac_data[idx].vgsi - ac_data[idx].vdsi, &cgs, &cgd, &dqgs_vgd, &dqgd_vgs );
      parker_current( pl, ac_data[idx].vgsi, ac_data[idx].vdsi, &gm, NULL );
      pp[CDS_INDEX].nom = pp[CDS_INDEX].min = pp[CDS_INDEX].max = ac_data[idx].cds - ac_data[idx].gds*ac_data[idx].tau2 + dqgs_vgd;
      printf ("idx: %i dqgs_vgd: %e, cds: %e , gds: %e , tau2: %e \n", idx,dqgs_vgd, ac_data[idx].cds, ac_data[idx].gds, ac_data[idx].tau2);
      pp[TAU_INDEX].nom = pp[TAU_INDEX].min = pp[TAU_INDEX].max = ac_data[idx].tau - (dqgd_vgs-dqgs_vgd)/gm;
      // use the Ri from this bias point
      fixed_p->ri = ac_data[idx].ri;

      if( set_all_parameters(p, pp, N_CHARGE_PARAMS) ) return 1;
   }

   /* create plots */


      for( i=0 ; i<N_CHARGE_PARAMS; ++i ) pl[i] = pp[i].nom;

      vgs = (double *) malloc (sizeof (double)*nvds);
      cgs_mod1 = (double *) malloc (sizeof (double)*nvds);
      cgs_meas1 = (double *) malloc (sizeof (double)*nvds);
      cgd_mod1 = (double *) malloc (sizeof (double)*nvds);
      cgd_meas1 = (double *) malloc (sizeof (double)*nvds);

      vds = (double *) malloc (sizeof (double)*nvgs);
      cgs_mod2 = (double *) malloc (sizeof (double)*nvgs);
      cgs_meas2 = (double *) malloc (sizeof (double)*nvgs);
      cgd_mod2 = (double *) malloc (sizeof (double)*nvgs);
      cgd_meas2 = (double *) malloc (sizeof (double)*nvgs);

      for( i=0; i<nvds; i++ ) {
         parker_charge( pl, const_vds[i].vgsi, const_vds[i].vgsi - const_vds[i].vdsi, &cgs, &cgd, &qgs_vgd, &qgd_vgs );
         cgs_mod1[i] = (cgs + qgd_vgs) * 1.0e12;
         cgs_meas1[i] = const_vds[i].cgs * 1.0e12;
         cgd_mod1[i] = (cgd + qgs_vgd) * 1.0e12;
         cgd_meas1[i] = const_vds[i].cgd * 1.0e12;
         vgs[i] = const_vds[i].vgsi;
      }

      for( i=0; i<nvgs; i++ ) {
         parker_charge( pl, const_vgs[i].vgsi, const_vgs[i].vgsi - const_vgs[i].vdsi, &cgs, &cgd, &qgs_vgd, &qgd_vgs );
         cgs_mod2[i] = (cgs + qgd_vgs) * 1.0e12;
         cgs_meas2[i] = const_vgs[i].cgs * 1.0e12;
         cgd_mod2[i] = (cgd + qgs_vgd) * 1.0e12;
         cgd_meas2[i] = const_vgs[i].cgd * 1.0e12;
         vds[i] = const_vgs[i].vdsi;
      }

      create_plot2( vgs, cgs_meas1, cgs_mod1, cgd_meas1, cgd_mod1, nvds,
         "Vgs (volts)", "Cgs (pF)", "Cgd (pF)", "Constant Vds", 0);
      create_plot2( vds, cgs_meas2, cgs_mod2, cgd_meas2, cgd_mod2, nvgs,
         "Vds (volts)", "Cgs (pF)", "Cgd (pF)", "Constant Vgs", 0);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static int fit_gm_gds( AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p )
{
   unsigned i;
   OPT_PARAMETER pp[N_IV_PARAMS];
   double pl[N_IV_PARAMS];
   double vds_actual, ids_actual, vgs_actual;
   AC_PARAMETERS const_vds[50], const_vgs[50];
   IV_DATA *iv;
   int nvds=0, nvgs=0;
   int idx;
   char str[200];
      double *vgs, *vds;
      double *gm_meas1, *gm_mod1, *gds_meas1, *gds_mod1;
      double *gm_meas2, *gm_mod2, *gds_meas2, *gds_mod2;
      double gm, gds;

   post_info_msg( "RF CONDUCTANCE: initializing.");

   // load the parameter starting values from the MODEL_PARAMS structure
   if( get_all_parameters( global_iv_param_names, N_IV_PARAMS, p, pp ) ) return 1;

   // determine the appropriate target_vds and target_vgs values
   iv = (IV_DATA*) malloc( sizeof( IV_DATA ) * n );
   for( i=0; i<n; i++ ) {
      iv[i].vds = ac_data[i].vds;
      iv[i].vgs = ac_data[i].vgs;
      iv[i].ids = ac_data[i].ids;
   }
   if( get_vgs_vds_targets( iv, n, target_vds, target_ids, &vds_actual, &vgs_actual, &ids_actual, &idx ) ) {
      free( iv );
      return 1;
   }
   free( iv );

   // post some informational data
   sprintf( str, "RF CONDUCTANCE: Vds_requested: %.3f Vds_actual: %.3f", target_vds, vds_actual );
   post_info_msg( str );
   sprintf( str, "RF CONDUCTANCE: Ids_requested: %.2e Ids_actual: %.2e", target_ids, ids_actual );
   post_info_msg( str );
   sprintf( str, "RF CONDUCTANCE: Vgs_actual: %.3f", vgs_actual );
   post_info_msg( str );

   // create data sets for constant vds and vgs fitting
   for( i=0; i<n; i++ ) {
      if( ac_data[i].vds == vds_actual && nvds < 50 ) {
         const_vds[nvds] = ac_data[i];
         nvds++;
      }
      if( ac_data[i].vgs == vgs_actual && nvgs < 50 ) {
         const_vgs[nvgs] = ac_data[i];
         nvgs++;
      }
   }
   if( nvds < 5 ) {
      post_error_msg( "RF CONDUCTANCE: error: not enough data for constant Vds fitting (5 points minimum)." );
      return 1;
   }
   if( nvgs < 3 ) {
      post_error_msg( "RF CONDUCTANCE: error: not enough data for constant Vgs fitting (3 points minimum)." );
      return 1;
   }

   // optimization
   if (niter > 0) {
      GM_DATA gm_data;
      OPTIMIZE *opt;

      gm_data.cvds = const_vds;
      gm_data.nvds = nvds;
      gm_data.cvgs = const_vgs;
      gm_data.nvgs = nvgs;

      opt = initialize_cg_optimizer();
      set_cg_parameters(opt, pp, N_IV_PARAMS);
      set_cg_flags(opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

      set_cg_error_function(opt, gm_gds_erf, &gm_data, 2, NULL);
      set_cg_error_fraction(opt, 1.0e-15, 10);

      for( i=19; i<=25; i++ ) pp[i].optimize = TRUE;

      if (cg_optimize4(opt, niter, NULL) ) {
         char str[200];
         sprintf( str, "RF CONDUCTANCE: error in optimization: %s.", get_opt_error() );
         post_error_msg( str );
         return 1;
      }

      free( opt );

      if( set_all_parameters(p, pp, N_IV_PARAMS) )
         return 1;
   }

   // create plots


      for( i=0; i<N_CHARGE_PARAMS; ++i ) pl[i] = pp[i].nom;

      vgs = (double *) malloc (sizeof (double)*nvds);
      gm_mod1 = (double *) malloc (sizeof (double)*nvds);
      gm_meas1 = (double *) malloc (sizeof (double)*nvds);
      gds_mod1 = (double *) malloc (sizeof (double)*nvds);
      gds_meas1 = (double *) malloc (sizeof (double)*nvds);

      vds = (double *) malloc (sizeof (double)*nvgs);
      gm_mod2 = (double *) malloc (sizeof (double)*nvgs);
      gm_meas2 = (double *) malloc (sizeof (double)*nvgs);
      gds_mod2 = (double *) malloc (sizeof (double)*nvgs);
      gds_meas2 = (double *) malloc (sizeof (double)*nvgs);

      for( i=0; i<nvds; i++ ) {
         parker_current( pl, const_vds[i].vgsi, const_vds[i].vdsi, &gm, &gds );
         gm_mod1[i] = gm * 1.0e3;
         gm_meas1[i] = const_vds[i].gm * 1.0e3;
         gds_mod1[i] = gds * 1.0e3;
         gds_meas1[i] = const_vds[i].gds * 1.0e3;
         vgs[i] = const_vds[i].vgsi;
      }

      for( i=0; i<nvgs; i++ ) {
         parker_current( pl, const_vgs[i].vgsi, const_vgs[i].vdsi, &gm, &gds );
         gm_mod2[i] = gm * 1.0e3;
         gm_meas2[i] = const_vgs[i].gm * 1.0e3;
         gds_mod2[i] = gds * 1.0e3;
         gds_meas2[i] = const_vgs[i].gds * 1.0e3;
         vds[i] = const_vgs[i].vdsi;
      }

      create_plot2( vgs, gm_meas1, gm_mod1, gds_meas1, gds_mod1, nvds,
         "Vgs (volts)", "Gm (mS)", "Gds (mS)", "Constant Vds", 0);
      create_plot2( vds, gm_meas2, gm_mod2, gds_meas2, gds_mod2, nvgs,
         "Vds (volts)", "Gm (mS)", "Gds (mS)", "Constant Vgs", 0);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

/* this function converges the dissipated power */
/*
static double parker_current (double *p, double Vgs, double Vds, double *Gm, double *Gds)
{
   unsigned n;
   double Pin, Pout, P0, dPout_Pin;
   double DELTA = p[4];
   double Ids, Pnew;

   // calculate P0 with Pin equal to zero
   Pin = 0.0;
   parker_current_raw (p, Vgs, Vds, Pin, &Ids, Gm, Gds);
   P0 = Pout = Vds * Ids;

   for (n = 0; n < MAX_CONV_ITER; ++n) {
      // if model converges to less than 1 mW, we are done
      if( fabs(Pout - Pin) < 1.0e-3 )
         return Ids;

      // calculate the derivative
      dPout_Pin = P0 * DELTA / sqr (1.0 + DELTA * Pin);

      // calculate a new guess for Pin
      Pnew = (Pin * dPout_Pin - Pout) / (dPout_Pin - 1.0);
      if( !((Pnew < 1.e3) && (Pnew > -1.e3)) || (Pnew < 0.) ) Pnew = 0.0;

      Pin = (Pin+Pnew)*0.5;

      // recalculate the returned power
      parker_current_raw( p, Vgs, Vds, Pin, &Ids, Gm, Gds );
      Pout = Vds * Ids;
   }

   // fprintf (stderr, "Warning: convergence failed: Vgs = %.3f, Vds = %.2f, Pin = %.3f, Pout = %.3f\n", Vgs, Vds, Pin, Pout);
   return Ids;
}
*/

/*****************************************************************************/
/*****************************************************************************/
static double parker_current( double *p, double Vgs, double Vds, double *Gm, double *Gds)
{
   double AREA = 1.0;
   double LFGAM = p[12];
   double LFG1 = p[13];
   double LFG2 = p[14];
   double HFGAM = p[20];
   double HFG1 = p[21];
   double HFG2 = p[22];
   double HFETA = p[23];
   double HFE1 = p[24];
   double HFE2 = p[25];
   double VBI = p[0];
   double VTO = p[2];
   double VST = p[6];
   double MVST = p[7];
   double XI = p[8];
   double MXI = p[9];
   double P = p[3];
   double Q = p[5];
   double Z = p[11];
   double BETA = p[1];
   double LAMBDA = p[10];
   // double DELTA = p[4];
   double VBI_MINUS_VTO = VBI - VTO;
   double lfg, hfg, hfn, vgst, vst, vgt, vsat, vdp, vdt;
   double dvgst_vgs, dvgst_vds; // dvgst_vgsa, dvgst_vgda;
   double dvgt_vgs, dvgt_vds; // dvgt_vgsa, dvgt_vgda;
   double dvsat_vgs, dvsat_vds; // dvsat_vgsa, dvsat_vgda;
   double dvdp_vgs, dvdp_vds; // dvdp_vgsa, dvdp_vgda;
   double dvdt_vgs, dvdt_vds; // dvdt_vgsa, dvdt_vgda;
   double c0, c1, c2, c3, c4, dvst_vds, Vgsh_a;

   double Vgs_a = Vgs;
   double Vgd_a = Vgs - Vds;

   // HEMT extensions
   double TM = p[15];
   double VHT = p[18];
   double VHR = p[16];
   double MVHR = p[17];
   double ETAH = p[19];
   double sigma, vgsh, dvgsh_vgs, dvgsh_vds; // dvgsh_vgsa, dvgsh_vgda;

   /*** these are extensions of the model for HEMT devices ***/

   // (Vgs_ae-Vgd_ae) is used in place of an average Vds value, which would require addition of another node
   //   and a whole mess of derivatives
   sigma = VHR * (1.0 + MVHR*(Vgs_a - Vgd_a));
   vgsh = TM * sigma * log(exp((Vgs-VHT)/sigma) + 1.0);
   dvgsh_vgs = TM / (exp((Vgs-VHT)/sigma) + 1.0) * exp((Vgs-VHT)/sigma);
   dvgsh_vds = 0.0;
   Vgsh_a = vgsh;

   lfg = LFGAM - LFG1*Vgs_a + LFG2*Vgd_a;
   hfg = HFGAM - HFG1*Vgs_a + HFG2*Vgd_a;
   hfn = HFETA - HFE1*Vgd_a + HFE2*Vgs_a;

   // vgst and its derivatives are modified by the HEMT extensions (vgsh and ETAH)
   vgst = Vgs - VTO - lfg*Vgd_a - hfg*(Vgs - Vds - Vgd_a) - hfn*(Vgs - Vgs_a) - vgsh + ETAH*(vgsh - Vgsh_a);
   dvgst_vgs = 1.0 - hfg - hfn - dvgsh_vgs + ETAH*dvgsh_vgs;
   dvgst_vds = hfg - dvgsh_vds + ETAH*dvgsh_vds;

   /*** the rest of this is the classic P-S MESFET Model ***/

   vst = VST*(1.0 + MVST*Vds);
   dvst_vds = VST * MVST;

   if (vgst > 30.0*vst) {
      vgt = vgst;
      dvgt_vgs = dvgst_vgs;
      dvgt_vds = dvgst_vds;
   }
   else if (vgst < -30.0*vst) {
      vgt = 0.0;
      dvgt_vgs = dvgt_vds = 0.0;
   }
   else {
      c1 = exp(vgst/vst) + 1.0;
      c2 = c1 - 1.0;
      vgt = vst * log(c1);
      dvgt_vgs = 1. / c1 * c2 * dvgst_vgs;
      dvgt_vds = vst / c1 * c2 * (dvgst_vds * vst - vgst * dvst_vds) / sqr(vst) + log(c1) * dvst_vds;
   }

   c1 = vgt * (1.0 + MXI) + XI*VBI_MINUS_VTO;
   c2 = sqr(vgt)*MXI + vgt*XI*VBI_MINUS_VTO;
   c3 = (c1 * (2.0*vgt*MXI + XI*VBI_MINUS_VTO) - c2 * (1.0 + MXI)) / sqr (c1);
   vsat = c2 / c1;
   dvsat_vgs = dvgt_vgs * c3;
   dvsat_vds = dvgt_vds * c3;

   c1 = P/Q * safe_pow (vgt/VBI_MINUS_VTO, P-Q);
   c2 = P/Q * safe_pow (vgt/VBI_MINUS_VTO, P-Q-1.0);
   vdp = Vds * c1;
   dvdp_vgs = Vds * (P-Q) * c2 * dvgt_vgs / VBI_MINUS_VTO;
   dvdp_vds = Vds * (P-Q) * c2 * dvgt_vds / VBI_MINUS_VTO + c1;

   c1 = sqrt(1.0 + Z);
   c2 = Z * sqr(vsat);
   c3 = sqrt (sqr(vdp * c1 + vsat) + c2);
   c4 = sqrt (sqr(vdp * c1 - vsat) + c2);
   vdt = 0.5 * (c3 - c4);
   dvdt_vgs = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vgs * c1 + dvsat_vgs) + 2.0 * Z * vsat * dvsat_vgs) - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vgs * c1 - dvsat_vgs) + 2.0 * Z * vsat * dvsat_vgs));
   dvdt_vds = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vds * c1 + dvsat_vds) + 2.0 * Z * vsat * dvsat_vds) - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vds * c1 - dvsat_vds) + 2.0 * Z * vsat * dvsat_vds));

   c0 = AREA * BETA;
   c1 = 1.0 + LAMBDA*Vds;
   c2 = Q * safe_pow(vgt, Q-1.0);
   if (vgt > vdt) {
      c3 = Q * safe_pow(vgt-vdt, Q-1.0);
      c4 = safe_pow(vgt, Q) - safe_pow(vgt-vdt, Q);
   }
   else {
      c3 = 0.;
      c4 = safe_pow(vgt, Q);
   }
   /*  -- remove DELTA from the caluclation
   c5 = 1. / (1. + DELTA * P_a / AREA);
   *Ids = c0 * c1 * c4 * c5;
   if(Gm) *Gm = c0 * c1 * c5 * (c2*dvgt_vgs - c3*(dvgt_vgs-dvdt_vgs));
   if(Gds) *Gds = c0 * c5 * (c1 * (c2*dvgt_vds - c3*(dvgt_vds-dvdt_vds)) + c4 * LAMBDA);
   */
   if(Gm) *Gm = c0 * c1 * (c2*dvgt_vgs - c3*(dvgt_vgs-dvdt_vgs));
   if(Gds) *Gds = c0 * (c1 * (c2*dvgt_vds - c3*(dvgt_vds-dvdt_vds)) + c4 * LAMBDA);
   //if((Gm) && (Gds)) printf ("Gm : %f, Gds:%f, c0: %f, c1:%f , c4:%f \n", *Gm, *Gds, c0, c1, c4);
   
   return c0 * c1 * c4;
}

/*****************************************************************************/
/*****************************************************************************/
static void parker_charge( double *p, double Vgs, double Vgd, double *cgs, double *cgd,
                           double *dqgs_vgd, double *dqgd_vgs)
{
   double AREA = 1.0;
   double VBI = p[0];
   double VTO = p[2];
   double XI = p[8];
   double CGS = p[28];
   double CGD = p[29];
   double FC = p[30];
   double XC = p[32];
   double ACGAM = p[31];
   double c1, c2, alpha;
   double Veff1, dVeff1_vgs, dVeff1_vgd;
   double Veff2, dVeff2_vgs, dVeff2_vgd;
   double Vnew, dVnew_vgs, dVnew_vgd;
   double Qgs, dQgs_vgs, dQgs_vgd;
   double Qgd, dQgd_vgs, dQgd_vgd;

   alpha = XI / (XI + 1.0) * 0.5*(VBI - VTO);

   c1 = sqrt(sqr(Vgs-Vgd) + sqr(alpha));
   Veff1 = 0.5 * (Vgs + Vgd + c1) + ACGAM*(Vgs-Vgd);
   dVeff1_vgs = 0.5 * (1.0 + (Vgs-Vgd)/c1) + ACGAM;
   dVeff1_vgd = 0.5 * (1.0 - (Vgs-Vgd)/c1) - ACGAM;
   ///printf ("dVeff1_vgs: %e", dVeff1_vgs);

   Veff2 = 0.5 * (Vgs + Vgd - c1) + ACGAM*(Vgs-Vgd);
   dVeff2_vgs = dVeff1_vgd + 2.0*ACGAM;
   dVeff2_vgd = dVeff1_vgs - 2.0*ACGAM;

   c1 = 0.5*(1.0 - XC);
   c2 = sqrt(sqr(Veff1-VTO) + sqr(0.2/(1.0 - XC)));
   Vnew = Veff1*XC + c1*(Veff1 + VTO + c2);
   dVnew_vgs = dVeff1_vgs*XC + c1*(dVeff1_vgs * (1.0 + (Veff1-VTO)/c2));
   dVnew_vgd = dVeff1_vgd*XC + c1*(dVeff1_vgd * (1.0 + (Veff1-VTO)/c2));
   if (Vnew > FC*VBI) {
      c1 = 1.0 / 4.0*pow(1.0-FC, 1.5);
      c2 = 1.0 / sqrt(1.0-FC);
      Qgs = AREA * CGS * VBI * ( 2.0*(1.0 - sqrt(1.0 - FC)) + sqr(Vnew/VBI - FC)*c1 + (Vnew/VBI - FC)*c2 );
      dQgs_vgs = AREA * CGS * VBI * ( 2.0*(Vnew/VBI - FC)*dVnew_vgs*c1/VBI + dVnew_vgs*c2/VBI );
      dQgs_vgd = AREA * CGS * VBI * ( 2.0*(Vnew/VBI - FC)*dVnew_vgd*c1/VBI + dVnew_vgd*c2/VBI );
   }
   else {
      c1 = sqrt(1.0 - Vnew/VBI);
      Qgs = 2.0 * AREA * CGS * VBI * (1.0 - c1);
      dQgs_vgs = AREA * CGS * dVnew_vgs / c1;
      dQgs_vgd = AREA * CGS * dVnew_vgd / c1;
   }
   Qgd = AREA * CGD * Veff2;
   dQgd_vgs = AREA * CGD * dVeff2_vgs;
   dQgd_vgd = AREA * CGD * dVeff2_vgd;

   *cgs = dQgs_vgs;
   *cgd = dQgd_vgd;
   *dqgs_vgd = dQgs_vgd;
   *dqgd_vgs = dQgd_vgs;
}

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/
static int dciv_erf( double *p, void *data, double *err, unsigned n_err )
{
   unsigned i;
   double diff, ids;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if( n_err < 1 ) return 1;

   for( i=0; i<d->n; ++i ) {
       ids = parker_current( p, d->data[i].vgs, d->data[i].vds, NULL, NULL );
       if( d->logdata ) diff = d->data[i].ids - log(ids);
       else diff = d->data[i].ids - ids;
      err[0] += 1.0e6 * diff * diff;
   }

   err[0] /= (double) d->n;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static int charge_erf( double *p, void *data, double *err, unsigned n_err )
{
   int i;
   CAP_DATA *d = (CAP_DATA *) data;
   double cgs, cgd, qgs_vgd, qgd_vgs;

   if( n_err != 2 ) return 1;

   for( i=0; i<d->nvds; i++ ) {
      parker_charge( p, d->cvds[i].vgsi, d->cvds[i].vgsi - d->cvds[i].vdsi, &cgs, &cgd, &qgs_vgd, &qgd_vgs );
      //err[0] += sqr(1.0e12*(d->cvds[i].cgs - (cgs + qgd_vgs))) + sqr(1.0e13*(d->cvds[i].cgd - (cgd + qgs_vgd)));
      err[0] += sqr(1.0e13*(d->cvds[i].cgs - (cgs + qgd_vgs))) + sqr(1.0e13*(d->cvds[i].cgd - (cgd + qgs_vgd)));
   }
   err[0] /= (double) d->nvds;

   
   for( i=0; i<d->nvgs; i++ ) {
      parker_charge( p, d->cvgs[i].vgsi, d->cvgs[i].vgsi - d->cvgs[i].vdsi, &cgs, &cgd, &qgs_vgd, &qgd_vgs );
      //err[1] += sqr(1.0e12*(d->cvgs[i].cgs - (cgs + qgd_vgs))) + sqr(1.0e13*(d->cvgs[i].cgd - (cgd + qgs_vgd)));
      err[1] += sqr(1.0e13*(d->cvgs[i].cgs - (cgs + qgd_vgs))) + sqr(1.0e13*(d->cvgs[i].cgd - (cgd + qgs_vgd)));
   }
   err[1] /= (double) d->nvgs;
   
   //printf (" err0 :%f, err1: %f ", err[0], err[1]);
   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static int gm_gds_erf( double *p, void *data, double *err, unsigned n_err )
{
   int i;
   GM_DATA *d = (GM_DATA *) data;
   double gm, gds, factor;

   if( n_err < 2 ) return 1;

   for( i=0; i<d->nvds; i++ ) {
      parker_current( p, d->cvds[i].vgsi, d->cvds[i].vdsi, &gm, &gds );
      err[0] += 1.0e6 * sqr(d->cvds[i].gm - gm) + 1.0e7 * sqr(d->cvds[i].gds - gds);
   }
   err[0] /= (double) d->nvds;

   for( i=0; i<d->nvgs; i++ ) {
      factor = 0.5 * (1. + tanh( 2. * (d->cvgs[i].vdsi - 2.)));
      parker_current( p, d->cvgs[i].vgsi, d->cvgs[i].vdsi, &gm, &gds );
      err[1] += 1.0e6 * sqr(d->cvgs[i].gm - gm) + 1.0e7 * sqr((d->cvgs[i].gds - gds)*factor);
   }
   err[1] /= (double) d->nvgs;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/
static int get_ss_parameters( char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n)
{
   FILE *file;
   unsigned found = 0;
   unsigned i,j;
   char string[300],pname[20];
   double value;
   AC_PARAMETERS tmp;

   *n = 0;

   /* read in bias-dependent device parameters */

   file = fopen (sum_file,"r");
   if( !file ) {
      printf ("Error: %s: unable to open file.\n", sum_file);
      return 1;
   }

   while( fgets (string, 299, file) ) {
      if( *n >= max_ac_p ) {
         printf ("Warning: %s: too many bias points.\n", sum_file);
         break;
      }

      if (sscanf (&string[28],"%lf%lf%lf%lf%*f%*f%*f%*f%*f%lf%lf%lf%lf%lf%lf%lf%lf",
         &ac_params[*n].vds, &ac_params[*n].ids, &ac_params[*n].vgs, &ac_params[*n].igs,
         &ac_params[*n].ri, &ac_params[*n].gm, &ac_params[*n].tau, &ac_params[*n].gds, &ac_params[*n].tau2,
         &ac_params[*n].cgs, &ac_params[*n].cds, &ac_params[*n].cgd) == 12) {
         // scale the parameters and increment the counter
         ac_params[*n].ids *= 1.0e-3;
         ac_params[*n].igs *= 1.0e-3;
         ac_params[*n].gm  *= 1.0e-3;
         ac_params[*n].gds *= 1.0e-3;
         ac_params[*n].cgs *= 1.0e-12;
         ac_params[*n].cgd *= 1.0e-12;
         ac_params[*n].cds *= 1.0e-12;
         ac_params[*n].tau *= 1.0e-12;
         ac_params[*n].tau2 *= 1.0e-12;
         (*n)++;
      }
   }
   fclose (file);

   if( *n < 1 ) {
      fprintf (stderr, "Error: %s: no data.\n", sum_file);
      return 1;
   }

   /* sort the ac parameters by increasing Vgs then Vds */
   for( i=0; i<((*n)-1); i++ ) {
      for( j=i+1; j<(*n); j++ ) {
         if( (ac_params[j].vgs < ac_params[i].vgs) ||
            ((ac_params[j].vds < ac_params[i].vds) && (ac_params[i].vgs == ac_params[j].vgs))) {
            tmp = ac_params[i];
            ac_params[i] = ac_params[j];
            ac_params[j] = tmp;
         }
      }
   }

   /* read in fixed parasitics from the small-signal end file */

   file = fopen (end_file,"r");
   if (!file) {
      printf ("Error: %s: unable to open file.\n", end_file);
      return 1;
   }

   while (fgets (string,299,file)) {
      if (sscanf (string,"%*f%lf%*f%*f%19s",&value,pname) == 2) {
         if (!strcmp (pname,"C1")) {
            fixed_params->cpg = value;
            ++found;
         }
         else if (!strcmp (pname,"C2")) {
            fixed_params->cpd = value;
            ++found;
         }
         else if (!strcmp (pname,"C11")) {
            fixed_params->c11 = value;
            ++found;
         }
         else if (!strcmp (pname,"C22")) {
            fixed_params->c22 = value;
            ++found;
         }
         else if (!strcmp (pname,"B1")) {
            fixed_params->lg = value;
            ++found;
         }
         else if (!strcmp (pname,"B2")) {
            fixed_params->ld = value;
            ++found;
         }
         else if (!strcmp (pname,"LS")) {
            fixed_params->ls = value;
            ++found;
         }
         else if (!strcmp (pname,"RG")) {
            fixed_params->rg = value;
            ++found;
         }
         else if (!strcmp (pname,"RD")) {
            fixed_params->rd = value;
            ++found;
         }
         else if (!strcmp (pname,"RS")) {
            fixed_params->rs = value;
            ++found;
         }
      }
   }
   fclose (file);

   if( found != 10 ) {
      fprintf (stderr, "Error: %s: missing parameter(s).\n", end_file);
      return 1;
   }

   /* calculate the internal node voltages for vgs and vds */
   for( i=0; i<(*n); i++ ) {
      if( ac_params[i].igs > 0. ) {
         ac_params[i].vdsi = ac_params[i].vds - ac_params[i].ids*fixed_params->rd - (ac_params[i].ids+ac_params[i].igs)*fixed_params->rs;
         ac_params[i].vgsi = ac_params[i].vgs - ac_params[i].igs*fixed_params->rg - (ac_params[i].ids+ac_params[i].igs)*fixed_params->rs;
      }
      else {
         ac_params[i].vdsi = ac_params[i].vds - (ac_params[i].ids-ac_params[i].igs)*fixed_params->rd - ac_params[i].ids*fixed_params->rs;
         ac_params[i].vgsi = ac_params[i].vgs - ac_params[i].igs*fixed_params->rg - ac_params[i].ids*fixed_params->rs;
      }
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
static void get_file_header (char *data_file, char *header, unsigned max_size)
{
   FILE *file = fopen (data_file,"r");
   unsigned index = 0, len;
   char string[300];

   if( !header || !max_size ) return;

   header[0] = 0;

   if (!file) return;

   while (fgets (string,299,file)) {
      if (string[0] != '!') {
         string[0] = 0;
         break;
      }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12)) {
         if ((index + len) < max_size) {
            strcat (header, string);
            index += len;
         }
         else
            break;

         fgets (string,299,file);
         break;
      }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size) {
         strcat (header, string);
         index += len;
      }
      else
         break;
   }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if ((len > 0) && (index < max_size)) {
      if ((index + len) < max_size) {
         strcat (header, string);
         index += len;
      }
      else if ((max_size - index) == 1);
      else {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
      }
   }
}

/*****************************************************************************/
/*****************************************************************************/
static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params, FIXED_PARAMS fixed )
{
   FILE *file;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   MODEL_PARAMS *ptr;

   /* write final optimization parameter values */

   if( write_model_parameters_to_file (params, end_file ) ) return 1;

   /* write the model file */

   // non-optimized parameters

   names[num_p] = "area"; values[num_p] = fixed.area; ++num_p;
   names[num_p] = "ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "tnom"; values[num_p] = fixed.tnom; ++num_p;
   names[num_p] = "rg"; values[num_p] = fixed.rg; ++num_p;
   names[num_p] = "rd"; values[num_p] = fixed.rd; ++num_p;
   names[num_p] = "rs"; values[num_p] = fixed.rs; ++num_p;
   names[num_p] = "ri", values[num_p] = fixed.ri; ++num_p;
   names[num_p] = "is"; values[num_p] = fixed.is; ++num_p;
   names[num_p] = "n"; values[num_p] = fixed.n; ++num_p;
   names[num_p] = "ibd"; values[num_p] = fixed.ibd; ++num_p;
   names[num_p] = "vbd"; values[num_p] = fixed.vbd; ++num_p;
   names[num_p] = "lg"; values[num_p] = fixed.lg; ++num_p;
   names[num_p] = "ld"; values[num_p] = fixed.ld; ++num_p;
   names[num_p] = "ls"; values[num_p] = fixed.ls; ++num_p;
   names[num_p] = "c11"; values[num_p] = fixed.c11; ++num_p;
   names[num_p] = "c22"; values[num_p] = fixed.c22; ++num_p;
   names[num_p] = "cpg"; values[num_p] = fixed.cpg; ++num_p;
   names[num_p] = "cpd"; values[num_p] = fixed.cpd; ++num_p;
   names[num_p] = "ileak"; values[num_p] = fixed.ileak; ++num_p;
   names[num_p] = "vleak"; values[num_p] = fixed.vleak; ++num_p;
   names[num_p] = "taug"; values[num_p] = 1.e-6; ++num_p;
   names[num_p] = "taud"; values[num_p] = 1.e-5; ++num_p;

   for (ptr = params; ptr; ptr = ptr->next) {
      names[num_p] = ptr->name;
      values[num_p] = ptr->nom;
      ++num_p;
   }

   file = fopen (model_file, "w");
   if (!file) {
      fprintf (stderr, "Error: %s: unable to write file.\n", model_file);
      return -1;
   }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");

   write_model_param_mdif( file, names, values, num_p, 12, 5);

   fclose (file);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void create_plot( double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling )
{
    jPLOT_ITEM* plot;
   if( !n ) return;

   plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if( !plot ) return;

   attach_y1data( plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data( plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);

   set_axis_labels( plot, x_lab, y_lab, "", title);
   set_axis_scaling( (plot), scaling);
   plot->active = FALSE;

   // add the plot to the list
   if( current_plot_number < MAX_PLOTS ) {
       plot_list[current_plot_number] = plot;
       ++current_plot_number;
   }
}

/*****************************************************************************/
/*****************************************************************************/

static void create_plot2( double *x, double *y1_meas, double *y1_mod,
                          double *y2_meas, double *y2_mod, unsigned n,
                          char *x_lab, char *y_lab, char *y2_lab, char *title, unsigned scaling )
{
    jPLOT_ITEM* plot;
   if( !n ) return;

   plot = create_plot_item( DoubleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE );
   if( !plot ) return;

   attach_y1data( plot, x, y1_meas, n, MEAS_LTYPE, 1, MEAS_COLOR );
   attach_y1data( plot, x, y1_mod, n, MOD_LTYPE, 1, MOD_COLOR );

   attach_y2data( plot, x, y2_meas, n, MEAS_LTYPE, 1, MEAS_COLOR );
   attach_y2data( plot, x, y2_mod, n, MOD_LTYPE, 1, MOD_COLOR );

   set_axis_labels( plot, x_lab, y_lab, y2_lab, title );
   set_axis_scaling( (plot), scaling );
   plot->active = FALSE;

   // add the plot to the list
   if( current_plot_number < MAX_PLOTS ) {
       plot_list[current_plot_number] = plot;
       ++current_plot_number;
   }
}

/*****************************************************************************/
/*****************************************************************************/

static int plot_data( int dev, char *head )
{
   static const char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile = "parker.ps";
   jHANDLE legend, header;
   unsigned i;

   if( !open_graphics_device( dev, plotfile ) ) {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
   }

   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // draw all plots
   for( i=0; i<current_plot_number; ++i ) {
      plot_list[i]->active = TRUE;

      if( !draw_page() ) {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
      }
      plot_list[i]->active = FALSE;
   }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if( dev != POSTSCRIPT ) {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item(legend);
      remove_user_item(header);

      plot_data( POSTSCRIPT, head );
   }
   else
      close_graphics_device ();

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files( char *inname, char *endname )
{
   FILE *file;
   OPT_PARAMETER p[] = {
      {  1.0000e+00,  1.0000e+00,  1.0000e+00,  0.0000e+00, "vbi", 0 },
      {  1.0000e-05,  1.2000e-02,  1.0000e+00,  0.0000e+00, "beta", 0 },
      { -3.5000e+00, -1.0000e+00,  5.0000e-01,  0.0000e+00, "vto", 0 },
      {  1.2000e+00,  3.0000e+00,  3.5000e+00,  0.0000e+00, "p", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "delta", 0 },
      {  1.5000e+00,  2.0000e+00,  2.5000e+00,  0.0000e+00, "q", 0 },
      {  2.0000e-02,  1.0000e-01,  3.0000e-01,  0.0000e+00, "vst", 0 },
      {  0.0000e+00,  5.0000e-02,  2.0000e-01,  0.0000e+00, "mvst", 0 },
      {  0.0000e+00,  5.0000e-01,  2.0000e+00,  0.0000e+00, "xi", 0 },
      {  0.0000e+00,  5.0000e-03,  1.0000e-02,  0.0000e+00, "mxi", 0 },
      {  0.0000e+00,  1.0000e-03,  5.0000e-01,  0.0000e+00, "lambda", 0 },
      {  2.0000e-01,  2.0000e+00,  4.0000e+00,  0.0000e+00, "z", 0 },
      {  0.0000e+00,  5.0000e-02,  5.0000e-01,  0.0000e+00, "lfgam", 0 },
      {  0.0000e+00,  2.0000e-03,  5.0000e-01,  0.0000e+00, "lfg1", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "lfg2", 0 },
      { -1.0000e+00,  3.5000e-02,  1.0000e+00,  0.0000e+00, "hfgam", 0 },
      { -1.0000e+00,  1.2778e-03,  1.0000e+00,  0.0000e+00, "hfg1", 0 },
      { -1.0000e+00,  3.0000e-03,  1.0000e+00,  0.0000e+00, "hfg2", 0 },
      { -1.0000e+00, -6.0000e-02,  1.0000e+00,  0.0000e+00, "hfeta", 0 },
      { -1.0000e+00,  1.0000e-03,  1.0000e+00,  0.0000e+00, "hfe1", 0 },
      { -1.0000e+00, -8.0000e-02,  1.0000e+00,  0.0000e+00, "hfe2", 0 },
      {  1.0000e-15,  5.0000e-13,  5.0000e-12,  0.0000e+00, "cgs", 0 },
      {  1.0000e-16,  5.0000e-14,  5.0000e-13,  0.0000e+00, "cgd", 0 },
      {  1.0000e-01,  5.0000e-01,  9.5000e-01,  0.0000e+00, "fc", 0 },
      {  0.0000e+00,  5.0000e-01,  9.9000e-01,  0.0000e+00, "xc", 0 },
      {  0.0000e+00,  2.0000e-01,  1.0000e+00,  0.0000e+00, "acgam", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "cds", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "tau", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "tm", 0 },
      {  1.0000e-03,  1.0000e-01,  5.0000e-01,  0.0000e+00, "vhr", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "mvhr", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "vht", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "etah", 0 }
   };

   if( inname ) {
      file = fopen (inname, "w+");
      if (!file) {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
      }

      fprintf (file, "4               # number of gate fingers\n");
      fprintf (file, "100             # unit gate width\n");
      fprintf (file, "27              # extraction temperature\n");
      fprintf (file, "s.end           # Y-fit file name\n");
      fprintf (file, "model.summary   # model summary file name\n");
      fprintf (file, "sdc.iv          # DC I-V file name\n");
      fprintf (file, "5               # max drain voltage for I-V fit\n");
      fprintf (file, "sfwd.iv         # forward I-V file name\n");
      fprintf (file, "svbr.iv         # breakdown I-V file name\n");
      fprintf (file, "parker.end      # starting parameters file name\n");
      fprintf (file, "parker.end      # finishing parameters file name (output)\n");
      fprintf (file, "parker.model    # model file name (output)\n");
      fprintf (file, "500             # maximum optimization iterations\n");
      fprintf( file, "3 100           # target Vds and target Ids mA/mm\n" );
      fprintf( file, "0.2               # value of DELTA (heating param)\n" );

      fclose (file);
   }

   if (endname) {
      unsigned i;

      file = fopen (endname, "w+");
      if( !file ) {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
      }

      for (i = 0; i < (sizeof(p) / sizeof(*p)); ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);

      fclose (file);
   }
}

/*****************************************************************************/
/*****************************************************************************/

static double safe_pow( double x, double y )
{
   if( x == 0. && y < 0. ) return 1.e100;
   else if( x == 0. ) return 0.;

   return pow(x, y);
}

/*****************************************************************************/
/*****************************************************************************/

static void check_parameter_ranges (MODEL_PARAMS *p, double Vmax, double Vpo)
{
   OPT_PARAMETER x;
   MODEL_PARAMS *ptr;

   /* set VBI to be fixed and equal to Vmax */
   get_parameter_value ("vbi", p, &x);
   x.min = x.nom = x.max = Vmax;
   set_parameter_value (p, x);

   /* set VTO equal to Vpo with a +/- 20% window */
   get_parameter_value ("vto", p, &x);
   x.min = Vpo - fabs(Vpo*0.2);
   x.nom = Vpo;
   x.max = Vpo + fabs(Vpo*0.2);
   set_parameter_value (p, x);

   /* set valid ranges on certain "trouble" parameters */

   // BETA should be >= 0
   get_parameter_value ("beta", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // DELTA must be >= 0
   get_parameter_value ("delta", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // P should be >= 2
   get_parameter_value ("p", p, &x);
   if( x.min < 2. ) x.min = 2.;
   set_parameter_value (p, x);

   // P_MINUS_Q must be > 0
   get_parameter_value ("p_minus_q", p, &x);
   if( x.min < 0.1 ) x.min = 0.1;
   set_parameter_value (p, x);

   // VST must be > 0
   get_parameter_value ("vst", p, &x);
   if( x.min < 1.e-3 ) x.min = 1.e-3;
   set_parameter_value (p, x);

   // MVST must be >= 0
   get_parameter_value ("mvst", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // XI must be >= 0
   get_parameter_value ("xi", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // MXI must be >= 0
   get_parameter_value ("mxi", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // LAMBDA should be >= 0
   get_parameter_value ("lambda", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // Z must be > 0
   get_parameter_value ("z", p, &x);
   if( x.min < 0.1 ) x.min = 0.1;
   set_parameter_value (p, x);

   // force LFG2 to 0, it causes strange IV behavior otherwise
   get_parameter_value ("lfg2", p, &x);
   x.min = x.nom = x.max = 0.;
   set_parameter_value (p, x);

   // CGS must be >= 0
   get_parameter_value ("cgs", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // CGD must be >= 0
   get_parameter_value ("cgd", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // FC should be between 0.3 and 0.95
   // change here
   get_parameter_value ("fc", p, &x);
   if( x.min < 0.1 ) x.min = 0.1;
   if( x.max > 0.95 ) x.max = 0.95;
   set_parameter_value (p, x);

   // XC should be >= 0.0 and must be < 1.0
   get_parameter_value ("xc", p, &x);
   if( x.min < 0. ) x.min = 0.;
   if( x.max > 0.95 ) x.max = 0.95;
   set_parameter_value (p, x);

   // force ETAH to 0 since it is not implemented
   get_parameter_value ("etah", p, &x);
   x.min = x.nom = x.max = 0.;
   set_parameter_value (p, x);

   // VHR must be > 0
   get_parameter_value ("vhr", p, &x);
   if( x.min < 1.0e-3 ) x.min = 1.0e-3;
   set_parameter_value (p, x);

   // MVHR must be >= 0
   get_parameter_value ("mvhr", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   // TM should be >= 0
   get_parameter_value ("tm", p, &x);
   if( x.min < 0. ) x.min = 0.;
   set_parameter_value (p, x);

   /* check to make sure that the nominal values make sense */

   for (ptr = p; ptr; ptr = ptr->next) {
      if (ptr->nom < ptr->min)
         ptr->nom = ptr->min;
      else if (ptr->nom > ptr->max)
         ptr->nom = ptr->max;

      if (ptr->min > ptr->max)
         printf ("Warning: check_parameter_ranges(): parameter \'%s\' min is greater than max.\n", ptr->name);
   }
}

/*****************************************************************************/
/*****************************************************************************/

static void read_vmax_from_file( char *fname, double *vmax, double *vpo )
{
   FILE *file;
   char string[256];

   *vmax = 1.0;
   *vpo = -1.0;

   file = fopen (fname, "r");
   if (!file)
      return;

   while (fgets (string, 255, file)) {
      if( string[0] != '!' ) break;

      if( !strncmp(string, "!Vbr", 4) ) {
         if( fgets(string, 255, file) ) sscanf (string, "!%*f%*f%*f%*f%*f%*f%lf%lf", vmax, vpo);
         break;
      }
   }

   fclose (file);
}

