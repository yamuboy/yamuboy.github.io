#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "cmplxlib.h"
#include "jplot.h"
#include "touchstone.h"

#define MAX_BIAS_POINTS    (1000)


struct bias_line_info
{
   size_t fpos;
   double vds;
   double ids;
   double vgs;
   double igs;
};

int plot_fet_sparams( FILE * f, struct bias_line_info bl, int fmt, char * header, int device );


/********************************************************************************************/

int main( int argc, char **argv )
{
   double target_vds = 3.;
   double target_ids = 100.e-3;
   double periphery = 1000.;
   struct bias_line_info * bl;
   int i, n, target;
   double vds, vgs, ids, igs;
   size_t fpos;
   FILE *f;
   int fmt = 0;
   int dev = X_WINDOWS;
   char * sp_file;
   char header[2000];
   char str[256];

   header[0] = '\0';

   // print usage statement if not enough stuff is on the command line
   if( argc < 2 ) {
      printf( "Usage:   %s [ options ] file\n"
         "  options:\n"
         "    -ps     Output a postscript file\n"
         "    -wmf    Output a Windows metafile\n"
         "    -meta             \"\n"
         "    -db     Plot magnitude in dB\n"
         "    -vds=X  Target Vds of X\n"
         "    -ids=X  Target Ids of X in mA/mm\n", argv[0]
         );
      return 0;
   }

   sp_file = argv[argc-1];

   for( i=0; i<argc-1; ++i ) {
      if( !strcmp(argv[i], "-ps") )
         dev = POSTSCRIPT;
      else if( !strcmp(argv[i], "-wmf") || !strcmp(argv[i], "-meta") )
         dev = METAFILE;
      else if( !strcmp(argv[i], "-db") || !strcmp(argv[i], "-dB") )
         fmt = 1;
      else if( !strncmp(argv[i], "-vds=", 5) ) {
         sscanf( argv[i], "-vds=%lf", &target_vds );
      }
      else if( !strncmp(argv[i], "-ids=", 5) ) {
         sscanf( argv[i], "-ids=%lf", &target_ids );
         target_ids *= 0.001;
      }
   }

   // open the file
   f = fopen( sp_file, "r" );
   if( ! f ) {
      fprintf( stderr, "Error: file not readable (%s)\n", sp_file );
      return 1;
   }

   // allocate memory for storage of bias info
   bl = malloc(sizeof(struct bias_line_info)*MAX_BIAS_POINTS);

   // scan the file for bias lines and read the info into the structure
   i = 0;
   n = 0;
   fpos = ftell(f);
   while( fgets( str, 255, f ) )
   {
      if( str[0] == '!' ) {
         // load the header string
         if( ++i < 15 && strncmp( str, "!COMM", 5 ) ) {
            strcat( header, str );
         }

         sscanf( str, "!GATE PERIPHERY (um): %lf", &periphery );
         if( sscanf( str, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf", &vds, &ids, &vgs, &igs ) == 4 ) {
            bl[n].fpos = fpos;
            bl[n].vds = vds;
            bl[n].vgs = vgs;
            bl[n].ids = ids;
            bl[n].igs = igs;
            ++n;
         }
      } 
      else {
         // stop reading header lines
         i=100;
      }
      fpos = ftell(f);
   }

   if( !n ) {
      // no bias lines found
      fprintf( stderr, "Error: no bias information (%s).\n", sp_file );
      free((void*) bl );
      return 1;
   }

   // correct the target_ids value for the periphery read from the file
   //  or the default (no correction) if none was read
   target_ids *= periphery / 1000.;

   // find the most appropriate point in the file
   target = -1;
   for( i=0; i<n; ++i ) {
      if( fabs(bl[i].vds - target_vds) < 0.1 ) {
         if( target < 0 || fabs(bl[i].ids - target_ids) < fabs(bl[target].ids - target_ids) )
            target = i;
      }
   }

   if( target < 0 ) {
      // nothing found for the specified target Vds
      fprintf( stderr, "Error: no matching Vds (%s).\n", sp_file );
      free((void*) bl );
      return 1;
   }

   // print info
   printf( "File: %s\nBias Points: %d\nTarget Vds: %.1f\nActual Vds: %.1f\nTarget Ids: %g\nActual Ids: %g\n",
      sp_file, n, target_vds, bl[target].vds, target_ids, bl[target].ids );

   // found a target bias, read it in a plot it
   return plot_fet_sparams( f, bl[target], fmt, header, dev );
}

/********************************************************************************************/




#define COMPLEX_CAST(x)   (*((COMPLEX*)&x))


/********************************************************************************************/

int plot_fet_sparams( FILE * f, struct bias_line_info bl, int fmt, char * header, int device )
{
   TSFile * tsf;
   NetworkParams * np;
   Touchstone * ts;
   char *legend_text[] = {"Magnitude", "Phase"};
   int legend_ltypes[] = {LT_SOLID, LT_SOLID};
   int legend_lwidths[] = {1, 1};
   int legend_colors[] = {CLR_RED, CLR_BLUE};
   jHANDLE plegend,pheader,ptitle,pbias;
   jPLOT_ITEM *plot;
   int i, j, e;
   double *freq, *mag, *ang;
   COMPLEX hp[4];
   char biasstr[256];

   // seek the file
   fseek( f, bl.fpos, SEEK_SET );

   tsf = alloc_ts_file( f );
   np = create_network_parameter_data();
   ts = create_touchstone_file_data();

   e = read_ts_file( tsf, ts, np );
   if( e ) {
      fprintf( stderr, "%s\n", get_ts_error_message(e) );
      free_network_parameter_data(np);
      free_touchstone_file_data(ts);
      close_ts_file(tsf);
      return 1;
   }
   else if( np->n_ports != 2 ) {
      fprintf( stderr, "Error: only 2-port data is allowed.\n" );
      free_network_parameter_data(np);
      free_touchstone_file_data(ts);
      close_ts_file(tsf);
      return 1;
   }
   else if( ! np->n_freqs ) {
      fprintf( stderr, "Error: no data.\n" );
      free_network_parameter_data(np);
      free_touchstone_file_data(ts);
      close_ts_file(tsf);
      return 1;
   }

   // open the output device 
   if (!open_graphics_device(device, NULL)) {
      printf ("Error: %s\n",get_error_message(ERROR_NUMBER));
      free_network_parameter_data(np);
      free_touchstone_file_data(ts);
      close_ts_file(tsf);
      return 1;
   }

   // allocate memory
   freq = malloc(sizeof(double)*np->n_freqs);
   mag = malloc(sizeof(double)*np->n_freqs);
   ang = malloc(sizeof(double)*np->n_freqs);

   // create the bias info string
   sprintf( biasstr, "Vds: %.1f\nIds = %g\nVgs = %.3f\nIgs = %g", bl.vds, bl.ids, bl.vgs, bl.igs );
   
   // create the header, legend, and plot
   pheader = add_text( header, 1.0, 8.0, FNT_HELVETICA, 8, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE );
   plegend = add_legend( 2, 8.0, 4.0, legend_text, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors );
   pbias = add_text( biasstr, 8.0, 8.0, FNT_HELVETICA, 10, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE );
   plot = create_plot_item( DoubleY, 1.5, 1.25, 5.0, 5.0 );

   // attach the data arrays to the plot
   attach_y1data( plot, freq, mag, np->n_freqs, LT_SOLID, 1, CLR_RED );
   attach_y2data( plot, freq, ang, np->n_freqs, LT_SOLID, 1, CLR_BLUE );

   // cycle through the different plots
   e = 0;
   for( i=0; i<5; ++i )
   {
      switch (i)
      {
      case 0:  // S11
         // load S11 data into the data arrays
         for( j=0; j<np->n_freqs; ++j ) {
            mag[j] = Cmag( COMPLEX_CAST(np->data[j][0]) );
            if( fmt ) mag[j] = 20. * log10( mag[j] );
            ang[j] = Cangle( COMPLEX_CAST(np->data[j][0]) );
            // load frequency data too, only need to do this once though
            freq[j] = np->frequency[j] * 1.0e-9;
         }
         // set axis labels
         set_axis_labels( plot, "Frequency (GHz)", fmt ? "Mag (dB)" : "Mag", "Phase", "" );
         // set title
         ptitle = add_text( "S11", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 1:  // S21
         // load S21 data into the data arrays
         for( j=0; j<np->n_freqs; ++j ) {
            mag[j] = Cmag( COMPLEX_CAST(np->data[j][2]) );
            if( fmt ) mag[j] = 20. * log10( mag[j] );
            ang[j] = Cangle( COMPLEX_CAST(np->data[j][2]) );
         }
         // set axis labels
         set_axis_labels( plot, "Frequency (GHz)", fmt ? "Mag (dB)" : "Mag", "Phase", "" );
         // set title
         ptitle = add_text( "S21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 2:  // S12
         // load S12 data into the data arrays
         for( j=0; j<np->n_freqs; ++j ) {
            mag[j] = Cmag( COMPLEX_CAST(np->data[j][1]) );
            if( fmt ) mag[j] = 20. * log10( mag[j] );
            ang[j] = Cangle( COMPLEX_CAST(np->data[j][1]) );
         }
         // set axis labels
         set_axis_labels( plot, "Frequency (GHz)", fmt ? "Mag (dB)" : "Mag", "Phase", "" );
         // set title
         ptitle = add_text( "S12", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 3:  // S22
         // load S22 data into the data arrays
         for( j=0; j<np->n_freqs; ++j ) {
            mag[j] = Cmag( COMPLEX_CAST(np->data[j][3]) );
            if( fmt ) mag[j] = 20. * log10( mag[j] );
            ang[j] = Cangle( COMPLEX_CAST(np->data[j][3]) );
         }
         // set axis labels
         set_axis_labels( plot, "Frequency (GHz)", fmt ? "Mag (dB)" : "Mag", "Phase", "" );
         // set title
         ptitle = add_text( "S22", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 4:  // H21
         for( j=0; j<np->n_freqs; ++j ) {
            s2h( (COMPLEX*)np->data[j], hp, 50.0 );
            mag[j] = 20. * log10( Cmag( hp[2] ) );
            ang[j] = Cangle( hp[2] );
         }
         // set axis labels
         set_axis_labels( plot, "Frequency (GHz)", "Mag (dB)", "Phase", "" );
         // set title
         ptitle = add_text( "H21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         // set x-axis scaling to logarithmic
         plot->scaling |= LogX;

         break;
      }

      // draw the plot page
      if (!draw_page()) {
         fprintf ( stderr, "Error: %s\n",get_error_message (ERROR_NUMBER) );
         e = 1;
         break;
      }

      // remove the title so that it can be added again in the next loop
      remove_user_item(ptitle);
   }

   // close the output device
   close_graphics_device ();

   return e;
}
