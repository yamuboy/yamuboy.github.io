#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"
#include "ss_tools2.h"

#define MAX_FREQ_PTS   1000

void print_usage( char * progname ) 
{
   printf( "\nUSAGE: %s [options] meas_file mod_file\n\n", progname );
   printf( "  Options:\n" );
   printf( "     -wmf, -meta   Set output device to metafile.\n" );
   printf( "     -ps           Set output device to postscript.\n" );
   printf( "     -o name       Set plot file name to \'name\'.\n" );
   printf( "     -db           Plot in dB.\n" );
   printf( "\n" );

}

/*********************************************************************************************/
/*********************************************************************************************/
int main (int argc, char *argv[])
{
   S_2PORT s_mod[MAX_FREQ_PTS];
   S_2PORT s_meas[MAX_FREQ_PTS];
   double mod_mag[MAX_FREQ_PTS];
   double mod_ang[MAX_FREQ_PTS];
   double mod_freq[MAX_FREQ_PTS];
   double meas_mag[MAX_FREQ_PTS];
   double meas_ang[MAX_FREQ_PTS];
   double meas_freq[MAX_FREQ_PTS];
   char string[256];
   char meas_name[256];
   char mod_name[256];
   char pname[256];
   char head[5000];
   FILE *file;
   int i;
   unsigned j,n_mod_f,n_meas_f;
   char *legend_text1[] = {"Modeled Magnitude", "Modeled Phase", "Measured Magnitude", "Measured Phase"};
   char *legend_text2[] = {"Modeled MAG/MSG", "Modeled K-Factor", "Measured MAG/MSG", "Measured K-Factor"};
   int legend_ltypes[] = {LT_SOLID, LT_DASHED, LT_SOLID, LT_DASHED};
   int legend_lwidths[] = {1, 1, 1, 1};
   int legend_colors[] = {CLR_RED, CLR_RED, CLR_DARKGREEN, CLR_DARKGREEN};
   jHANDLE legend1,header1,title1;
   jPLOT_ITEM *plot1;
   int device = X_WINDOWS;
   int db_mode=0;

   *meas_name = '\0';
   *mod_name = '\0';
   strcpy(pname,"modplot.ps");

   if( argc < 2 ) {
      print_usage(argv[0]);
      return 0;
   }

   // parse command line
   for( i=1; i<argc; ++i ) {
      if( argv[i][0] == '-' ) {
         if( !strcmp(argv[i],"-ps") || !strcmp(argv[i],"-dP") ) device=POSTSCRIPT;
         else if( !strcmp(argv[i],"-wmf") || !strcmp(argv[i],"-dM") || !strcmp(argv[i],"-meta") ) device=METAFILE;
         else if( !strcmp(argv[i],"-o") ) {
            if( i == argc-1 ) {
               fprintf( stderr, "Error: missing parameter to -o option.\n" );
               print_usage(argv[0]);
               exit(1);
            }
            strcpy(pname,argv[++i]);
         }
         else if( !strcmp(argv[i],"-db") || !strcmp(argv[i],"-dB") ) db_mode=1; 
         else {
            fprintf( stderr, "Error: unrecognized command line option: %s\n", argv[i] );
            print_usage(argv[0]);
            exit(1);
         }
      }
      else {
         if( ! *meas_name ) strcpy( meas_name, argv[i] );
         else if( ! *mod_name ) strcpy( mod_name, argv[i] );
         else {
            fprintf( stderr, "Error: extra arguments on the command line.\n" );
            print_usage(argv[0]);
            exit(1);
         }
      }
   }

   if( ! *meas_name || ! *mod_name ) {
      fprintf( stderr, "Error: missing file argument.\n" );
      print_usage(argv[0]);
      exit(1);
   }

   // load S-parameter data

   n_mod_f = read_s_from_file (mod_name, s_mod, NULL, MAX_FREQ_PTS);
   if (n_mod_f < 1)
   {
      fprintf (stderr, "Unable to read data from file: %s\n", mod_name);
      return -1;
   }

   n_meas_f = read_s_from_file (meas_name, s_meas, NULL, MAX_FREQ_PTS);
   if (n_meas_f < 1)
   {
      fprintf (stderr, "Unable to read data from file: %s\n", meas_name);
      return -1;
   }

   // create the plot header information

   i = 0;
   head[0] = 0;
   file = fopen (mod_name, "r");
   while (fgets (string, 255, file))
   {
      if ((string[0] != '!') || (++i > 20) || !strncmp (string, "!COMMENTS", 9))
         break;

      strcat (head, string);
   }
   fclose (file);

   header1 = add_text (head, 1.0, 8.0, FNT_HELVETICA, 8, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE);

   legend1 = add_legend (4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);  

   // draw the plots 

   if(!open_graphics_device (device, pname))
   {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      return -1;
   }

   plot1 = create_plot_item (DoubleY, 1.5, 1.25, 5.0, 5.0);

   // cycle through the different plots

   for (i = 0; i < 6; ++i)
   {
      switch (i)
      {
      case 0:  // S11
         for (j = 0; j < n_mod_f; ++j) {
            if(db_mode) mod_mag[j] = 20.*log10(Cmag (s_mod[j].s[0]));
            else mod_mag[j] = Cmag(s_mod[j].s[0]);
            mod_ang[j] = Cangle (s_mod[j].s[0]);
            mod_freq[j] = s_mod[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
         attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);

         for (j = 0; j < n_meas_f; ++j) {
            if(db_mode) meas_mag[j] = 20.*log10(Cmag (s_meas[j].s[0]));
            else meas_mag[j] = Cmag (s_meas[j].s[0]);
            meas_ang[j] = Cangle (s_meas[j].s[0]);
            meas_freq[j] = s_meas[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
         attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);

         if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S11)", "phase(S11)", "");
         else set_axis_labels (plot1, "Freq (GHz)", "mag(S11)", "phase(S11)", "");
         title1 = add_text ("S11", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 1:  // S21
         for (j = 0; j < n_mod_f; ++j) {
            if(db_mode) mod_mag[j] = 20.*log10(Cmag (s_mod[j].s[2]));
            else mod_mag[j] = Cmag (s_mod[j].s[2]);
            mod_ang[j] = Cangle (s_mod[j].s[2]);
            mod_freq[j] = s_mod[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
         attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);

         for (j = 0; j < n_meas_f; ++j) {
            if(db_mode) meas_mag[j] = 20.*log10(Cmag (s_meas[j].s[2]));
            else meas_mag[j] = Cmag (s_meas[j].s[2]);
            meas_ang[j] = Cangle (s_meas[j].s[2]);
            meas_freq[j] = s_meas[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
         attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);            
         if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S21)", "phase(S21)", "");
         else set_axis_labels (plot1, "Freq (GHz)", "mag(S21)", "phase(S21)", "");
         title1 = add_text ("S21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 2:  // S12
         for (j = 0; j < n_mod_f; ++j) {
            if(db_mode) mod_mag[j] = 20.*log10(Cmag (s_mod[j].s[1]));
            else mod_mag[j] = Cmag (s_mod[j].s[1]);
            mod_ang[j] = Cangle (s_mod[j].s[1]);
            mod_freq[j] = s_mod[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
         attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);

         for (j = 0; j < n_meas_f; ++j) {
            if(db_mode) meas_mag[j] = 20.*log10(Cmag (s_meas[j].s[1]));
            else meas_mag[j] = Cmag (s_meas[j].s[1]);
            meas_ang[j] = Cangle (s_meas[j].s[1]);
            meas_freq[j] = s_meas[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
         attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
         if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S12)", "phase(S12)", "");
         else set_axis_labels (plot1, "Freq (GHz)", "mag(S12)", "phase(S12)", "");
         title1 = add_text ("S12", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 3:  // S22
         for (j = 0; j < n_mod_f; ++j) {
            if(db_mode) mod_mag[j] = 20.*log10(Cmag (s_mod[j].s[3]));
            else mod_mag[j] = Cmag (s_mod[j].s[3]);
            mod_ang[j] = Cangle (s_mod[j].s[3]);
            mod_freq[j] = s_mod[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
         attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);

         for (j = 0; j < n_meas_f; ++j) {
            if(db_mode) meas_mag[j] = 20.*log10(Cmag (s_meas[j].s[3]));
            else meas_mag[j] = Cmag (s_meas[j].s[3]);
            meas_ang[j] = Cangle (s_meas[j].s[3]);
            meas_freq[j] = s_meas[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
         attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
         if(db_mode) set_axis_labels (plot1, "Freq (GHz)", "dB(S22)", "phase(S22)", "");
         else set_axis_labels (plot1, "Freq (GHz)", "mag(S22)", "phase(S22)", "");
         title1 = add_text ("S22", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 4:  // K and MAG
         for (j = 0; j < n_mod_f; ++j) {
            mod_mag[j] = s_mod[j].MAG;
            mod_ang[j] = s_mod[j].k;
            mod_freq[j] = s_mod[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
         attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);

         for (j = 0; j < n_meas_f; ++j) {
            meas_mag[j] = s_meas[j].MAG;
            meas_ang[j] = s_meas[j].k;
            meas_freq[j] = s_meas[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
         attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);

         set_axis_labels (plot1, "Freq (GHz)", "dB(MAG or MSG)", "K-Factor", "");
         remove_user_item (legend1);
         legend1 = add_legend (4, 8.0, 4.0, legend_text2, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);  
         title1 = add_text ("MAG/MSG\nand\nK-Factor", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 5:  // H21
         for (j = 0; j < n_mod_f; ++j) {
            s2h (s_mod[j].s, s_mod[j].s, 50.0);
            mod_mag[j] = 20.0 * log10 (Cmag (s_mod[j].s[2]));
            mod_ang[j] = Cangle (s_mod[j].s[2]);
            mod_freq[j] = s_mod[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
         attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);

         for (j = 0; j < n_meas_f; ++j) {
            s2h (s_meas[j].s, s_meas[j].s, 50.0);
            meas_mag[j] = 20.0 * log10 (Cmag (s_meas[j].s[2]));
            meas_ang[j] = Cangle (s_meas[j].s[2]);
            meas_freq[j] = s_meas[j].freq * 1.0e-9;
         }
         attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
         attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);

         set_axis_labels (plot1, "Freq (GHz)", "dB(H21)", "phase(H21)", "");
         set_axis_scaling (plot1, LogX);
         remove_user_item (legend1);
         legend1 = add_legend (4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);  
         title1 = add_text ("H21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;
      }

      if (!draw_page ())
      {
         printf ("%s\n",get_error_message (ERROR_NUMBER));
         close_graphics_device ();
         return -1;
      }

      detach_data (plot1);
      remove_user_item (title1);
   }

   close_graphics_device ();
   return 0;
}

