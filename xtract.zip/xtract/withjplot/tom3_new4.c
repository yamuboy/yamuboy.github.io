#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"
#include "optimize4.h"
#include "fit_tools.h"

/****** MACROS AND DEFINITIONS ******/

#define sqr(x)             ((x)*(x))

#define MAX_AC_BIAS_PTS    250
#define MAX_DCIV_PTS       1000
#define MAX_PIV_PTS        2000
#define MAX_DIODE_PTS      100
#define MAX_FWD_IGS        0.8      // in mA/mm
#define MAX_EXP_ARG        30.0

#define NUM_PARAMS    24

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19
#define STDTEMP       300.0

#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_DOTTED
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN

#define PLOT_X         1.25
#define PLOT_Y         1.25
#define PLOT_XSIZE     6.0
#define PLOT_YSIZE     5.5

typedef struct
{
   double vgs,vds,igs,ids;
   double cgs,cgd,cds;
   double gm,gds,tau,tau2;
} AC_PARAMETERS;

typedef struct
{
   unsigned ngf;
   double area,ugw;
   double rg,rd,rs,ri;
   double lg,ld,ls;
   double c1,c2,c11,c22;
   double is,n,ibd,vbd;
   double tnom;
} FIXED_PARAMS;

typedef struct
{
   unsigned ndc, nsub;
   IV_DATA *dcdata, *subdata;
   double max_vds;
   double periphery;
} DCIV_OPT;

typedef struct
{
   unsigned n;
   AC_PARAMETERS *data;
   double periphery;
} AC_OPT;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, unsigned max_size);
static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMS fixed, int capmod);

static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params);
static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n);

static int dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int piv_erf (double *p, void *data, double *err, unsigned n_err);
static int charge_erf (double *p, void *data, double *err, unsigned n_err);
static int gm_erf (double *p, void *data, double *err, unsigned n_err);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);
static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

static double tom3_ids (double *p, double vgs, double vds, double *Gm, double *Gds);
static void tom3_charge_cap (double *p, double vgs, double vds, double *cgs, double *cgs_t, double *cgd, double *cgd_t);
static void tom3_cap (double *p, double vgs, double vds, double *cgs, double *cgd);

static int fit_diode_curves (char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot, jPLOT_ITEM **vr_plot);
static int fit_dc_curves (char *dc_iv_file, OPT_PARAMETER *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot);
static int fit_pulsed_gds (char *piv_file, OPT_PARAMETER *p, double max_vds, FIXED_PARAMS *fixed_p);
static int fit_pulsed_curves (char *piv_file, OPT_PARAMETER *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                              jPLOT_ITEM **piv_plot);
static int fit_charge_data (AC_PARAMETERS *ac_data, unsigned n, OPT_PARAMETER *p, unsigned niter, FIXED_PARAMS *fixed_p,
                            jPLOT_ITEM **c11_plot, jPLOT_ITEM **c12_plot );

static double safe_pow (double x, double y);
static void write_starting_files (char *input_file, char *param_file);
static void read_vmax_from_file (char *fname, double *vmax, double *vpo);

// global variable for warning messages
static char global_warning_message[5000];

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
{
#define SZ_PLOTLIST    (15)
   char string[256];
   char model_summary_file[100], start_file[100], end_file[100];
   char model_file[100], yfit_file[100], dc_iv_file[100], piv_file[100];
   char fwd_iv_file[100], breakdown_file[100], header[3000];
   OPT_PARAMETER params[NUM_PARAMS];
   AC_PARAMETERS ac_data[MAX_AC_BIAS_PTS];
   FIXED_PARAMS fixed_params;
   unsigned num_ac_bias_pts, niter;
   double maximum_vds;
   jPLOT_ITEM *plot_list[SZ_PLOTLIST];
   int plot_dev = X_WINDOWS;
   int i;
   int calc_piv = 1;
   int use_piv = 0;
   int skip_dc = 0;
   int dc_only=0;
   double vmax, vpo;

   global_warning_message[0] = 0;

   for( i=0; i<SZ_PLOTLIST; ++i ) {
      plot_list[i] = NULL;
   }

   /**** parse the command line ****/

   for (i = 1; i < argc; ++i)
   {
      if (!strncmp (argv[i], "-i", 2) || !strncmp (argv[i], "-e", 2))
      {
         write_starting_files ("tom3in", "tom3.start");
         return 0;
      }
      else if (!strncmp (argv[i], "-h", 2))
      {
         printf ("\n\n");

         printf ("TOM3 model fitter options:\n");
         printf ("------------------------------------------------------------------\n");
         printf ("  -i, -e    Auto-generate an input file named tom3in and a\n");
         printf ("              starting values file named tom3.start.\n");
         printf ("  -nopiv    Do not use pulsed I-V data to fit AC drain conductance,\n");
         printf ("              this is helpful if PIV data is not available.\n");
         printf ("  -p        Use pulsed I-V data for the DC I-V curve fitting routine.\n");
         printf ("  -skipdc   Skip the DC curve fitting routines.\n");
         printf ("  -dconly   Only fit DC parameters (skip pulsed I-V and charge fitting).\n");

         printf ("\n\n");

         return 0;
      }
      else if (!strncmp (argv[i], "-nopiv", 6))
         calc_piv = 0;
      else if (!strncmp (argv[i], "-p", 2))
         use_piv = 1;
      else if (!strncmp (argv[i], "-skipdc", 7))
         skip_dc = 1;
      else if (!strncmp (argv[i], "-d0", 3))
         plot_dev = 0;
      else if (!strncmp (argv[i], "-dconly", 7))
         dc_only = 1;
   }

   /**** get user input ****/

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string, "%d", &fixed_params.ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ugw);

   fixed_params.area = fixed_params.ngf * fixed_params.ugw;

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.tnom);

   printf ("Y-fit end file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",yfit_file);

   printf ("Model summary file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_summary_file);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Pulsed IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",piv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Forward IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",breakdown_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   /**** get measurement and extraction data ****/

   if (get_starting_values (start_file, params, NUM_PARAMS))
      return 1;

   // force Kgamma to 0
   params[23].min = params[23].max = params[23].nom = 0.0;

   if (niter > 0)
   {
      // force nominal VTO to be equal to measured pinchoff
      read_vmax_from_file (fwd_iv_file, &vmax, &vpo);
      params[0].nom = vpo;
      params[0].min = vpo - fabs(vpo*0.2);
      params[0].max = vpo + fabs(vpo*0.2);
   }

   /**** perform various parameter fits ****/
   if( dc_only ) 
   {
      fixed_params.rg = fixed_params.rd = fixed_params.rs = 1.0e-3;
      if (fit_diode_curves (fwd_iv_file, breakdown_file, &fixed_params, &plot_list[0], &plot_list[1]))
         return 1;
      if (fit_dc_curves (dc_iv_file, params, maximum_vds, niter, &fixed_params, &plot_list[2], &plot_list[3]))
         return 1;
   }
   else
   {
      if (get_ss_parameters (model_summary_file, yfit_file, ac_data, MAX_AC_BIAS_PTS, &fixed_params, &num_ac_bias_pts))
         return 1;

      // set Rd and Rs to RMIN
      fixed_params.rd = fixed_params.rs = 1.0e-3;

      if( !skip_dc )
      {
         if (fit_diode_curves (fwd_iv_file, breakdown_file, &fixed_params, &plot_list[0], &plot_list[1]))
            return 1;

         if (use_piv)
         {
            if (fit_dc_curves (piv_file, params, maximum_vds, niter, &fixed_params, &plot_list[2], &plot_list[3]))
               return 1;

            params[19].min = params[19].max = params[19].nom = 1.0e-6;
            params[20].min = params[20].max = params[20].nom = 1.0e-16;  

            calc_piv = 0;
         }
         else
         {
            if (fit_dc_curves (dc_iv_file, params, maximum_vds, niter, &fixed_params, &plot_list[2], &plot_list[3]))
               return 1;
         }
      }

      if (calc_piv)
      {
         if (fit_pulsed_gds (piv_file, params, maximum_vds, &fixed_params))
            return 1;
      }

      if (fit_charge_data (ac_data, num_ac_bias_pts, params, niter, &fixed_params, &plot_list[4], &plot_list[5]) )
         return 1;
   }


   /**** Write final data files ****/

   // set the value of Rg equal to Rg+Ri - the model does not have an Ri component
   fixed_params.rg += fixed_params.ri;

   printf ("Writing data files.\n");

   get_file_header (dc_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, params, fixed_params, 2))
      return -1;

   /***** Generate plots *****/

   if (plot_dev)
   {
      char plot_head[1000];
      FILE *file;

      plot_head[0] = 0;

      // get the plot header

      file = fopen (dc_iv_file, "r");
      if (file)
      {
         while (fgets (string, 255, file))
         {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
         }

         fclose (file);
      }

      if (plot_data (plot_dev, plot_head, plot_list, SZ_PLOTLIST))
         return 1;
   }

   if (global_warning_message[0])
   {
      printf ("\n%s", global_warning_message);
      printf ("\nModel fitting completed with warnings.\n\n");
   }
   else
      printf ("\nModel fitting complete.\n\n");

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_diode_curves (char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot, jPLOT_ITEM **vr_plot)
{
   IV_DATA fwd_curves[MAX_DIODE_PTS], vbr_curves[MAX_DIODE_PTS];
   unsigned n_fwd_pts, n_vbr_pts;
   double v[MAX_DIODE_PTS], i[MAX_DIODE_PTS];
   unsigned j, k;
   double m, b, r2;
   double *vf, *if_meas, *if_mod;
   double *vr, *ir_meas, *ir_mod;

   /***** Forward IV *****/

   printf ("Forward Diode IV.\n");

   if (get_iv_data (fwd_iv_file, fwd_curves, MAX_DIODE_PTS, &n_fwd_pts))
      return 1;

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
   {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 1.0e-8*fixed_p->area))
      {
         v[k] = fwd_curves[j].vgs;
         i[k] = log (fwd_curves[j].igs);
         ++k;
      }
   }

   if (k < 2)
   {
      fprintf (stderr, "Error: %s: not enough points.\n", fwd_iv_file);
      return 1;
   }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->is = 0.5 * exp (b);
   // do not scale ideality w.r.t. temperature because of an ADS bug
   // fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * (fixed_p->tnom + 273.15));
   fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * STDTEMP);

   // create a plot

   vf = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_meas = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_mod = (double *) malloc (sizeof(double)*n_fwd_pts);

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
   {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 0.0))
      {
         vf[k] = fwd_curves[j].vgs;
         if_meas[k] = fwd_curves[j].igs * 1.0e6 / fixed_p->area;
         if_mod[k] = 2.0 * fixed_p->is * (exp (vf[k] * Q_ELECTRON / (fixed_p->n * BOLTZMANN * STDTEMP)) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
      }
   }

   create_plot (vf_plot, vf, if_meas, if_mod, k, "Vgs (volts", "Igs (mA/mm)", "Diode Characteristic", LogY1);

   /***** Breakdown *****/

   printf ("Reverse Diode Breakdown.\n");

   if (get_iv_data (vbr_iv_file, vbr_curves, MAX_DIODE_PTS, &n_vbr_pts))
      return 1;

   for (j = n_vbr_pts-5, k = 0; j < n_vbr_pts; ++j)
   {
      if ( vbr_curves[j].igs < 0.0 )
      {
         v[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
         i[k] = log (-vbr_curves[j].igs);
         ++k;
      }
   }

   if (k < 2)
   {
      fprintf (stderr, "Error: %s: not enough points.\n", vbr_iv_file);
      return 1;
   }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->ibd = exp (b);
   fixed_p->vbd = 1.0 / m;

   // create a plot

   vr = (double *) malloc (sizeof(double)*n_vbr_pts);
   ir_meas = (double *) malloc (sizeof(double)*n_vbr_pts);
   ir_mod = (double *) malloc (sizeof(double)*n_vbr_pts);

   for (j = 0, k = 0; j < n_vbr_pts; ++j)
   {
      if (vbr_curves[j].igs < 0.0)
      {
         vr[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
         ir_meas[k] = -vbr_curves[j].igs * 1.0e6 / fixed_p->area;
         ir_mod[k] = fixed_p->ibd * (exp (vr[k] / fixed_p->vbd) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
      }
   }

   create_plot (vr_plot, vr, ir_meas, ir_mod, k, "Vdg (volts", "Idg (mA/mm)", "Diode Breakdown", LogY1);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_dc_curves (char *dc_iv_file, OPT_PARAMETER *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot)
{
   unsigned n_iv_pts, n_subth_pts;
   DCIV_OPT dciv_data;
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   IV_DATA subth_data[MAX_DCIV_PTS];
   IV_DATA tmp;
   double *subth_v, *subth_imeas, *subth_imod;
   double *dciv_v, *dciv_imod, *dciv_imeas;
   unsigned i, j;
   OPTIMIZE *opt;
   double pl[NUM_PARAMS];
   double wght[] = {10.0, 1.0};

   printf ("DC I-V data.\n");

   if (get_iv_data (dc_iv_file, dciv_curves, MAX_DCIV_PTS, &n_iv_pts))
      return 1;

   // create the subthreshold data set
   for (i = 0, n_subth_pts = 0; i < n_iv_pts; ++i)
   {
      if ((dciv_curves[i].vds < 1.0) || (dciv_curves[i].vds > max_vds) || 
         (dciv_curves[i].ids > 50e-6*fixed_p->area) || (dciv_curves[i].ids <= 0.0))
         continue;

      subth_data[n_subth_pts] = dciv_curves[i];
      ++n_subth_pts;
   }

   // sort the subthreshold data set
   for (i = 0; i < n_subth_pts; ++i)
   {
      for (j = i+1; j < n_subth_pts; ++j)
      {
         if ((subth_data[j].vds < subth_data[i].vds) ||
            ((subth_data[j].vds == subth_data[i].vds) && (subth_data[j].vgs < subth_data[i].vgs)))
         {
            tmp = subth_data[i];
            subth_data[i] = subth_data[j];
            subth_data[j] = tmp;
         }
      }
   }

   // apply port resistances to active region data
   for (i = 0; i < n_iv_pts; ++i)
   {
      if (dciv_curves[i].igs < 0.0)
         dciv_curves[i].vgs -= dciv_curves[i].ids*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;
      else
         dciv_curves[i].vgs -= (dciv_curves[i].ids + dciv_curves[i].igs)*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;

      dciv_curves[i].vds -= (dciv_curves[i].ids + 0.5*dciv_curves[i].igs) * (fixed_p->rs + fixed_p->rd);
   }

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, p, NUM_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);
   set_cg_error_function (opt, dciv_erf, &dciv_data, 2, wght);
   set_cg_error_fraction (opt, 1.0e-9, 5);

   dciv_data.ndc = n_iv_pts;
   dciv_data.dcdata = dciv_curves;
   dciv_data.nsub = n_subth_pts;
   dciv_data.subdata = subth_data;
   dciv_data.max_vds = max_vds;
   dciv_data.periphery = fixed_p->area;

   for (i = 0; i <= 8; ++i)
      p[i].optimize = TRUE;

   if (cg_optimize4 (opt, niter, NULL))
   {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      FILE *db = fopen( "debugdump.txt", "w+" );
      if( db ) {
         fprintf( stderr, "Writing debug dump to: debugdump.txt\n" );
         fprintf( db, "ndc: %d\nnsub: %d\narea: %lg\n", dciv_data.ndc, dciv_data.nsub, dciv_data.periphery );
         fprintf( db, "Rg: %lg\nRd: %lg\nRs: %lg\n", fixed_p->rg, fixed_p->rd, fixed_p->rs );
         fprintf( db, "[SUBTHRESHOLD DATA]\n" );
         for( i=0; i<dciv_data.nsub; ++i ) {
            fprintf( db, "%12.4e %12.4e %12.4e %12.4e\n", dciv_data.subdata[i].vds, dciv_data.subdata[i].ids, dciv_data.subdata[i].vgs, dciv_data.subdata[i].igs );
         }
         fprintf( db, "[DC I-V DATA]\n" );
         for( i=0; i<dciv_data.ndc; ++i ) {
            fprintf( db, "%12.4e %12.4e %12.4e %12.4e\n", dciv_data.dcdata[i].vds, dciv_data.dcdata[i].ids, dciv_data.dcdata[i].vgs, dciv_data.dcdata[i].igs );
         }
         fprintf( db, "[MODEL PARAMETERS]\n" );
         for( i=0; i<NUM_PARAMS; ++i ) {
            fprintf( db, "%s = %lg\n", p[i].name, p[i].nom );
         }
         fclose(db);
      }
      return -1;
   }   

   for (i = 0; i <= 8; ++i)
      p[i].optimize = FALSE;

   /* create a plots */ 

   dciv_v = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imeas = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imod = (double *) malloc (sizeof (double) * n_iv_pts);
   subth_v = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imeas = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imod = (double *) malloc (sizeof (double) * n_subth_pts);

   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   for (i = 0; i < n_subth_pts; ++i)
   {
      subth_v[i] = subth_data[i].vgs;
      subth_imeas[i] = subth_data[i].ids * 1.0e6 / fixed_p->area;
      subth_imod[i] = tom3_ids (pl, subth_data[i].vgs, subth_data[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
   }

   create_plot (subth_plot, subth_v, subth_imeas, subth_imod, n_subth_pts, "Vgs (volts)", "Ids (mA/mm)", "Sub-Threshold Current", LogY1);

   for (i = 0; i < n_iv_pts; ++i)
   {
      dciv_v[i] = dciv_curves[i].vds;
      dciv_imeas[i] = dciv_curves[i].ids * 1.0e6 / fixed_p->area;
      dciv_imod[i] = tom3_ids (pl, dciv_curves[i].vgs, dciv_curves[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
   }

   create_plot (dciv_plot, dciv_v, dciv_imeas, dciv_imod, n_iv_pts, "Vds (volts)", "Ids (mA/mm)", "DC I-V Curves", POSITIVE_X | POSITIVE_Y1);

   free ((void *) opt);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_charge_data (AC_PARAMETERS *ac_data, unsigned n, OPT_PARAMETER *p, unsigned niter, FIXED_PARAMS *fixed_p,
                            jPLOT_ITEM **c11_plot, jPLOT_ITEM **c12_plot )
{
   AC_OPT cap_data;
   OPTIMIZE *opt;
   double *v, *cgs_meas, *cgs_mod, *cgd_meas, *cgd_mod;
   double *cds_meas, *cds_mod, *tau_mod, *tau_meas;
   double pl[NUM_PARAMS];
   unsigned i, j;
   double cgs, cgd, qgs_vgd, qgd_vgs, gm;

   printf ("Gate Charge.\n");

   if (niter > 0)
   {
      double *cvals;
      double *tvals;
      int npts;

      //  prepare for optimization
      cap_data.periphery = fixed_p->area;
      cap_data.n = n;
      cap_data.data = ac_data;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, p, NUM_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);

      set_cg_error_function (opt, charge_erf, &cap_data, 2, NULL);
      set_cg_error_fraction (opt, 1.0e-12, 5);

      for (i = 9; i <= 18; ++i)
         p[i].optimize = TRUE;

      // optimize

      if (cg_optimize4 (opt, niter, NULL))
      {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return 1;
      }

      for (i = 9; i <= 18; ++i)
         p[i].optimize = FALSE;

      free ((void *) opt);

      /******** calculate Cds and Tau ************/

      for( i=0; i<NUM_PARAMS; ++i )
         pl[i] = p[i].nom;

      cvals = malloc( sizeof(double)*n );
      tvals = malloc( sizeof(double)*n );
      npts=0;
      for( i=0; i<n; ++i )
      {
         // VDS > 1.1 and IDS > 10 mA/mm
         if( ac_data[i].vds > 1.1 && ac_data[i].ids > 10.e-6 * fixed_p->area ) {
            // calculate the Cds and Tau value for the model
            tom3_charge_cap( pl, ac_data[i].vgs, ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
            tom3_ids( pl, ac_data[i].vgs, ac_data[i].vds, &gm, NULL);
            cvals[npts] = ac_data[i].cds - ac_data[i].gds * ac_data[i].tau2 + qgs_vgd;
            tvals[npts] = ac_data[i].tau - ((qgd_vgs - qgs_vgd) / gm);
/******** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ********/
            tvals[npts] = ac_data[i].tau;
/******** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ********/
            ++npts;
         }
      }

      // do a bubble average to remove extraneous values
      p[21].min = p[21].nom = p[21].max = bubble_average( cvals, npts );   // cds
      p[22].min = p[22].nom = p[22].max = bubble_average( tvals, npts );   // tau

      free((void*)cvals);
      free((void*)tvals);
   }

   // create plots
   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   v = (double *) malloc (sizeof (double)*n);
   cgs_mod = (double *) malloc (sizeof (double)*n);
   cgs_meas = (double *) malloc (sizeof (double)*n);
   cgd_mod = (double *) malloc (sizeof (double)*n);
   cgd_meas = (double *) malloc (sizeof (double)*n);

   for (i = 0; i < n; ++i)
   {
      tom3_charge_cap (pl, ac_data[i].vgs, ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);

      cgs_mod[i] = (cgs + qgd_vgs + cgd + qgs_vgd) * 1.0e15 / fixed_p->area;
      cgs_meas[i] = (ac_data[i].cgs + ac_data[i].cgd) * 1.0e15 / fixed_p->area;

      cgd_mod[i] = (cgd + qgs_vgd) * 1.0e15 / fixed_p->area;
      cgd_meas[i] = ac_data[i].cgd * 1.0e15 / fixed_p->area;

      v[i] = ac_data[i].vds;
   }

   create_plot (c11_plot, v, cgs_meas, cgs_mod, n, "Vds (volts)", "pF/mm", "C11", 0);
   create_plot (c12_plot, v, cgd_meas, cgd_mod, n, "Vds (volts)", "pF/mm", "C12", 0);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_pulsed_curves (char *piv_file, OPT_PARAMETER *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                              jPLOT_ITEM **piv_plot)
{
   DCIV_OPT piv_data;
   IV_DATA piv_curves[MAX_PIV_PTS];
   unsigned n_piv_pts;
   double pl[NUM_PARAMS];
   double *piv_v, *piv_imeas, *piv_imod;
   OPTIMIZE *opt;
   unsigned i;

   printf ("Pulsed IV data.\n");

   if (get_iv_data (piv_file, piv_curves, MAX_PIV_PTS, &n_piv_pts))
      return 1;

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, p, NUM_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

   piv_data.ndc = n_piv_pts;
   piv_data.dcdata = piv_curves;
   piv_data.max_vds = max_vds;
   piv_data.periphery = fixed_p->area;

   set_cg_error_function (opt, piv_erf, &piv_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-9, 20);

   // correct for resistive port losses
   for (i = 0; i < n_piv_pts; ++i)
   {
      // ignore igs, since it is not accurately measured in the system
      piv_curves[i].vgs -= piv_curves[i].ids * fixed_p->rs;
      piv_curves[i].vds -= piv_curves[i].ids * (fixed_p->rs + fixed_p->rd);
   }

   p[0].optimize = FALSE;
   p[7].optimize = FALSE;
   p[8].optimize = FALSE;

   for (i = 1; i <= 6; ++i)
      p[i].optimize = TRUE;

   if (cg_optimize4 (opt, niter, NULL))
   {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      return -1;
   }

   for (i = 1; i <= 6; ++i)
      p[i].optimize = FALSE;

   // create a plot

   piv_v = (double *) malloc (sizeof (double) * n_piv_pts);
   piv_imeas = (double *) malloc (sizeof (double) * n_piv_pts);
   piv_imod = (double *) malloc (sizeof (double) * n_piv_pts);

   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   for (i = 0; i < n_piv_pts; ++i)
   {
      piv_v[i] = piv_curves[i].vds;
      piv_imeas[i] = piv_curves[i].ids * 1.0e6 / fixed_p->area;
      piv_imod[i] = tom3_ids (pl, piv_curves[i].vgs, piv_curves[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
   }

   create_plot (piv_plot, piv_v, piv_imeas, piv_imod, n_piv_pts, "Vds (volts)", "Ids (mA/mm)", "Pulsed I-V Curves", POSITIVE_X | POSITIVE_Y1);

   free ((void *) opt);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int fit_pulsed_gds (char *piv_file, OPT_PARAMETER *p, double max_vds, FIXED_PARAMS *fixed_p)
{
   IV_DATA piv[MAX_PIV_PTS];
   unsigned n_piv_pts;
   unsigned i;
   double gds, gdsm;
   double gds_ave = 0.0;
   unsigned n = 0;
   double pl[NUM_PARAMS];

   printf ("Pulsed IV data.\n");

   if (get_iv_data (piv_file, piv, MAX_PIV_PTS, &n_piv_pts))
      return 1;

   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   // calculate the average deviation in Gds from the DC current
   for (i = 1; i < n_piv_pts; ++i)
   {
      if ((piv[i].ids < 10e-6*fixed_p->area) || (piv[i].vds*piv[i].ids > 1.5e-3*fixed_p->area))
         continue;

      if ((piv[i-1].vds >= 1.5) && (piv[i].vds <= max_vds) && (piv[i].vds > piv[i-1].vds))
      {
         tom3_ids (pl, piv[i].vgs, 0.5 * (piv[i].vds + piv[i-1].vds), NULL, &gds);
         gdsm = (piv[i].ids - piv[i-1].ids) / (piv[i].vds - piv[i-1].vds);
         gds_ave += gdsm - gds;
         ++n;
      }
   }

   // calculate the average additive Gds
   if (n < 1)
      n = 1;

   gds_ave /= (double) n;

   if (gds_ave < 1.0e-10)
      gds_ave = 1.0e-10;

   // set Taugd to 1 microsecond
   p[19].min = p[19].max = p[19].nom = 1.0e-6;

   // calculate Ctau
   p[20].min = p[20].max = p[20].nom = p[19].nom * gds_ave;  

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

#if (0)   
// these functions are not complete

static int fit_gm_gds (AC_PARAMETERS *ac_data, unsigned n, )
{
   OPT_PARAMETER tmp_p[NUM_PARAMS];
   AC_OPT ac_opt;



   printf ("Drain conductance and transconductance.\n");

   // generate pulsed-IV data

   if (generate_piv_data (ac_data, n, vds_target, ids_target, piv_data, &num_piv_pts))
      return 1;

}

/*****************************************************************************/
/*****************************************************************************/

static int generate_piv_data (AC_PARAMETERS *ac_data, unsigned n, double vds_target, double ids_target,
                              IV_DATA *piv_data, unsigned *num_piv_pts)
{
   unsigned index_list[MAX_IV_PTS];
   double ids_list[MAX_IV_PTS];
   unsigned i, j;

   // find the bias point in the dataset

   for (i = 0, j = 0; i < n; ++i)
   {
      if ((ac_data[i].vds > vds_target-0.3) && (ac_data[i].vds < vds_target+0.3))
      {
         index_list[j] = i;
         ids_list[j] = ac_data[i].ids;
         ++j;
      }
   }

   if (j < 3)
   {
      fprintf (stderr, "Error: generate_piv_data(): invalid Vds target value.\n");
      return 1;
   }

   target_index = 0;
   dist = fabs (ids_list[0] - ids_target);
   for (i = 1; i < j; ++i)
   {
      if (fabs (ids_list[i] - ids_target) < dist)
      {
         dist = ids_list[i] - ids_target;
         taret_index = i;
      }
   }

   // create the curves around the bias point







   // interpolate






}

#endif

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

static double tom3_ids (double *p, double vgs, double vds, double *Gm, double *Gds)
{
   double vto    = p[0];
   double alpha  = p[1];
   double beta   = p[2];
   double lambda = p[3];
   double gamma  = p[4];
   double q      = p[5];
   double k      = p[6];
   double vst    = p[7];
   double mst    = p[8];
   double Vst,u,Vg,fk,I0,Ids;
   double dVst_vds, du_vds, du_vgs, dVg_vds, dVg_vgs;
   double dfk_vds, dI0_vds, dI0_vgs;
   int flag = 0;

   if (vds < 0.0)
   {
      vgs = vgs - vds;
      vds = -vds;
      flag = 1;
   }

   Vst = vst * (1.0 + mst*vds);
   dVst_vds = vst * mst;

   u = (vgs - vto + gamma*vds) / (q*Vst);
   du_vgs = 1.0 / (q*Vst);
   du_vds = (q*Vst*gamma - (vgs - vto + gamma*vds)*q*dVst_vds) / sqr(q*Vst);

   if (u > MAX_EXP_ARG)
   {
      Vg = q * Vst * u;
      dVg_vgs = q * Vst * du_vgs;
      dVg_vds = q * (Vst * du_vds + u * dVst_vds);
   }
   else
   {
      Vg = q * Vst * log (1.0 + exp (u));
      dVg_vgs = q * Vst / (1.0 + exp(u)) * exp(u) * du_vgs;
      dVg_vds = q * (Vst/(1.0 + exp(u))*exp(u)*du_vds + log (1.0 + exp(u))*dVst_vds);
   }

   fk = (alpha*vds) / safe_pow (1.0 + safe_pow (alpha*vds, k), 1.0/k);
   dfk_vds = alpha * (pow (1.0 + pow (alpha*vds, k), 1.0/k) - vds * safe_pow (1.0 + safe_pow (alpha*vds, k), 1.0/k - 1.0) * safe_pow (alpha*vds, k-1.0) * alpha) / safe_pow (1.0 + safe_pow (alpha*vds, k), 2.0/k);

   I0 = beta * safe_pow (Vg, q) * fk;
   dI0_vds = beta * (safe_pow (Vg, q) * dfk_vds + fk * q * safe_pow (Vg, q - 1.0) * dVg_vds);
   dI0_vgs = beta * fk * q * safe_pow (Vg, q-1.0) * dVg_vgs;

   Ids = I0 * (1.0 + lambda*vds);

   if (Gds)
      *Gds = I0 * lambda + (1.0 + lambda*vds) * dI0_vds;
   if (Gm)
      *Gm = dI0_vgs * (1.0 + lambda*vds);

   if (flag)
      return -Ids;

   return Ids;
}

/*****************************************************************************/
/*****************************************************************************/

static double tom3_qgg (double *p, double vgs, double vds, double *dQgg_vgs, double *dQgg_vgd)
{
   double qgql = p[9];
   double qgqh = p[10];
   double qgi0 = p[11];
   double qgag = p[12];
   double qgad = p[13];
   double qggb = p[14];
   double qgcl = p[15];
   double qgsh = p[16];
   double qgdh = p[17];
   double qgg0 = p[18];
   double Qgh,Qgl,ft,Qgg;
   double vgd = vgs - vds;
   double gm, gds, v1, dv1_vgs, dv1_vds;
   double dQgh_vgs, dQgh_vds, dQgl_vgs, dQgl_vds;
   double dft_vgs, dft_vds;

   double ids = tom3_ids (p, vgs, vds, &gm, &gds);

   v1 = 2.0*vgs - vds;
   dv1_vgs = 2.0;
   dv1_vds = -1.0;

   Qgh = qgqh*log(1.0+ids/qgi0) + qgsh*vgs + qgdh*(vgs-vds);
   dQgh_vgs = qgqh/(1.0+ids/qgi0)*gm/qgi0 + qgsh + qgdh;
   dQgh_vds = qgqh/(1.0+ids/qgi0)*gds/qgi0 - qgdh;

   Qgl = qgql*exp(qgag*v1)*cosh(qgad*vds) + qgcl*v1;
   dQgl_vgs = qgql*exp(qgag*v1)*qgag*dv1_vgs*cosh(qgad*vds) + qgcl*dv1_vgs;
   dQgl_vds = qgql*( exp(qgag*v1)*sinh(qgad*vds)*qgad + cosh(qgad*vds)*exp(qgag*v1)*qgag*dv1_vds ) + qgcl*dv1_vds;

   ft = exp (-qggb*ids*vds);
   dft_vgs = exp(-qggb*ids*vds) * (-qggb*gm*vds);
   dft_vds = exp(-qggb*ids*vds) * (-qggb*(ids + vds*gds));

   Qgg = Qgl*ft + Qgh*(1.0 - ft) + qgg0*v1;
   if (dQgg_vgs && dQgg_vgd)
   {
      double dQgg_vds;
      *dQgg_vgs = Qgl*dft_vgs + ft*dQgl_vgs - Qgh*dft_vgs + (1.0-ft)*dQgh_vgs + qgg0*dv1_vgs;
      dQgg_vds = Qgl*dft_vds + ft*dQgl_vds - Qgh*dft_vds + (1.0-ft)*dQgh_vds + qgg0*dv1_vds;
      *dQgg_vgd = -dQgg_vds;
   }

   return Qgg;
}

/*****************************************************************************/
/*****************************************************************************/

static void tom3_charge_cap (double *p, double vgs, double vds, double *cgs, double *cgs_t, double *cgd, double *cgd_t)
{
   double dqgg_dvgs, dqgg_dvgd;

   tom3_qgg (p, vgs, vds, &dqgg_dvgs, &dqgg_dvgd);

   // the gate charge Qgg is partitoned into Qgs and Qgd using a 50/50 ratio,
   //  therefore Qgs = 0.5 * Qgg and Qgd = 0.5 * Qgg
   *cgs = *cgd_t = 0.5 * dqgg_dvgs;
   *cgd = *cgs_t = 0.5 * dqgg_dvgd;
}

/*****************************************************************************/
/*****************************************************************************/

static void tom3_cap (double *p, double vgs, double vds, double *cgs, double *cgd)
{
   double dqgg_dvgs, dqgg_dvgd;

   tom3_qgg (p, vgs, vds, &dqgg_dvgs, &dqgg_dvgd);

   *cgs = dqgg_dvgs;
   *cgd = dqgg_dvgd;
}

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int dciv_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->nsub; ++i)
   {
      diff = log (d->subdata[i].ids) - log (tom3_ids (p, d->subdata[i].vgs, d->subdata[i].vds, NULL, NULL) + 1.0e-15);
      err[0] += diff * diff;
   }

   for (i = 0; i < d->ndc; ++i)
   {
      if (d->dcdata[i].vds > d->max_vds)
         continue;

      diff = d->dcdata[i].ids - tom3_ids (p, d->dcdata[i].vgs, d->dcdata[i].vds, NULL, NULL);
      err[1] += 1.0e6 * diff * diff;
   }

   err[0] /= (double) (d->nsub?d->nsub:1.);
   err[1] /= (double) (d->ndc?d->ndc:1.);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int piv_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->ndc; ++i)
   {
      if (d->dcdata[i].vds > d->max_vds)
         continue;

      diff = d->dcdata[i].ids - tom3_ids (p, d->dcdata[i].vgs, d->dcdata[i].vds, NULL, NULL);
      err[0] += 1.0e6 * diff * diff;
   }

   err[0] /= (double) d->ndc;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int charge_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i;
   AC_OPT *d = (AC_OPT *) data;
   double cgs, cgd, qgs_vgd, qgd_vgs, t;

   if (n_err != 2)
      return 1;

   for (i = 0; i < d->n; ++i)
   {      
      tom3_charge_cap (p, d->data[i].vgs, d->data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
      //      tom3_ids (p, d->data[i].vgs, d->data[i].vds, &gm, NULL);

      //      if (d->data[i].vds >= 1.5)
      //         {
      //         err[0] += sqr(1.0e12*(d->data[i].cgs - (cgs + qgd_vgs)));
      //         err[1] += sqr(1.0e12*(d->data[i].cgd - (cgd + qgs_vgd)));
      //         err[2] += sqr(1.0e12*((d->data[i].cds - d->data[i].gds*d->data[i].tau2) - (cds - qgs_vgd)));
      //         err[3] += sqr(1.0e12*(d->data[i].tau - (tau + (qgd_vgs - qgs_vgd)/gm)) * gm);
      //         }

      // error term 0 is Cg (Cgs+Cgd)
      t = d->data[i].cgs + d->data[i].cgd - (cgs + cgd + qgs_vgd + qgd_vgs);
      err[0] += 1.e24 * t * t;
      // error term 1 is Cgd
      t = d->data[i].cgd - (cgd + qgs_vgd);
      err[1] += 1.e24 * t * t;
   }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;
   //   err[2] /= (double) d->n;
   //   err[3] /= (double) d->n;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int gm_erf (double *p, void *data, double *err, unsigned n_err)
{
   unsigned i,j = 0;
   double ids1,ids2,gm,diff;
   AC_OPT *d = (AC_OPT *) data;
   double del = 1.0e-3;

   if (n_err != 1)
      return 1;

   for (i = 0; i < d->n; ++i)
   {
      if ((d->data[i].gm > 1.0e-6*d->periphery) && (d->data[i].vds >= 1.0))
      {
         tom3_ids (p, d->data[i].vgs, d->data[i].vds, &gm, NULL);
         diff = gm - d->data[i].gm;

         err[0] += 1.0e6 * diff * diff;
         ++j;
      }
   }

   if (!j)
      return 1;

   err[0] /= (double) j;

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n)
{
   FILE *file;
   unsigned m = 0;
   unsigned found = 0;
   unsigned i,j;
   char string[300],pname[20];
   double *Ri;
   double value;
   AC_PARAMETERS tmp;

   *n = 0;

   /* read in bias-dependent device parameters */

   file = fopen (sum_file,"r");
   if (!file)
   {
      printf ("Unable to open model summary file - %s\n",sum_file);
      return 1;
   }

   Ri = (double *) malloc (sizeof (double) * max_ac_p);

   while (fgets (string, 299, file))
   {
      if ((m >= max_ac_p) || (*n >= max_ac_p))
      {
         printf ("Warning: %s: too many bias points.\n", sum_file);
         break;
      }

      if (sscanf (&string[28],"%lf%lf%lf%lf%*f%*f%*f%*f%*f%lf%lf%lf%lf%lf%lf%lf%lf",
         &ac_params[*n].vds, &ac_params[*n].ids, &ac_params[*n].vgs, &ac_params[*n].igs,
         &Ri[m], &ac_params[*n].gm, &ac_params[*n].tau, &ac_params[*n].gds, &ac_params[*n].tau2,
         &ac_params[*n].cgs, &ac_params[*n].cds, &ac_params[*n].cgd) == 12)
      {
         ac_params[*n].ids *= 1.0e-3;
         ac_params[*n].igs *= 1.0e-3;
         ac_params[*n].gm  *= 1.0e-3;
         ac_params[*n].gds *= 1.0e-3;
         ac_params[*n].cgs *= 1.0e-12;
         ac_params[*n].cgd *= 1.0e-12;
         ac_params[*n].cds *= 1.0e-12;
         ac_params[*n].tau *= 1.0e-12;
         ac_params[*n].tau2 *= 1.0e-12;

         if (ac_params[*n].igs <= MAX_FWD_IGS*fixed_params->area*1.0e-6)
         {
            ++(*n);

            if ((ac_params[*n].vds >= 1.0) && (ac_params[*n].ids >= 10.0e-6*fixed_params->area))
               ++m;
         }

      }
   }
   fclose (file);

   // average these parameters, since they are fixed in the LS model

   fixed_params->ri = bubble_average (Ri,m);   
   if (fixed_params->ri < 1.0e-3)
      fixed_params->ri = 1.0e-3;

   free ((void *) Ri);

   if (*n < 1)
   {
      fprintf (stderr, "Error: no data in %s.\n",sum_file);
      return 1;
   }

   /* sort the ac parameters by increasing Vgs then Vds */

   for (i = 0; i < ((*n)-1); ++i)
   {
      for (j = i+1; j < *n; ++j)
      {
         if ((ac_params[j].vgs < ac_params[i].vgs) ||
            ((ac_params[j].vds < ac_params[i].vds) && (ac_params[i].vgs == ac_params[j].vgs)))
         {
            tmp = ac_params[i];
            ac_params[i] = ac_params[j];
            ac_params[j] = tmp;
         }
      }
   }

   /* determine the intrinsic node voltages */

   for (i = 0; i < *n; ++i)
   {
      ac_params[i].vds -= fixed_params->rd*ac_params[i].ids +
         fixed_params->rs*(ac_params[i].ids + ac_params[i].igs);
      ac_params[i].vgs -= (fixed_params->rg + fixed_params->ri)*ac_params[i].igs + 
         fixed_params->rs*(ac_params[i].ids + ac_params[i].igs);
   }

   /* read in fixed parasitics from the small-signal end file */

   file = fopen (end_file,"r");
   if (!file)
   {
      printf ("Unable to open file: %s\n",end_file);
      return 1;
   }

   while (fgets (string,299,file))
   {
      if (sscanf (string,"%*f%lf%*f%*f%19s",&value,pname) == 2)
      {
         if (!strcmp (pname,"C1"))
         {
            fixed_params->c1 = value;
            ++found;
         }
         else if (!strcmp (pname,"C2"))
         {
            fixed_params->c2 = value;
            ++found;
         }
         else if (!strcmp (pname,"C11"))
         {
            fixed_params->c11 = value;
            ++found;
         }
         else if (!strcmp (pname,"C22"))
         {
            fixed_params->c22 = value;
            ++found;
         }
         else if (!strcmp (pname,"B1"))
         {
            fixed_params->lg = value;
            ++found;
         }
         else if (!strcmp (pname,"B2"))
         {
            fixed_params->ld = value;
            ++found;
         }
         else if (!strcmp (pname,"LS"))
         {
            fixed_params->ls = value;
            ++found;
         }
         else if (!strcmp (pname,"RG"))
         {
            fixed_params->rg = value;
            ++found;
         }
         else if (!strcmp (pname,"RD"))
         {
            fixed_params->rd = value;
            ++found;
         }
         else if (!strcmp (pname,"RS"))
         {
            fixed_params->rs = value;
            ++found;
         }
      }
   }
   fclose (file);

   if (found != 10)
   {
      fprintf (stderr, "Error: Missing parameter(s) in %s.\n",end_file);
      return 1;
   }

   if (fixed_params->c11 != 0.0)
   {
      for (i = 0; i < *n; ++i)
         ac_params[i].cgs += fixed_params->c11;

      sprintf (string, "Warning: C11 is non-zero.  It has been lumped into the value of Cgs.\n");
      strcat (global_warning_message, string);
   }

   if (fixed_params->c22 != 0.0)
   {
      for (i = 0; i < *n; ++i)
         ac_params[i].cds += fixed_params->c22;

      sprintf (string, "Warning: C22 is non-zero.  It has been lumped into the value of Cds.\n");
      strcat (global_warning_message, string);
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static int get_starting_values (char *fname, OPT_PARAMETER *p, unsigned n_params)
{
   FILE *file;
   char string[200];
   unsigned i = 0;

   /* read in the starting values */

   file = fopen (fname,"r");
   if (!file)
   {
      printf ("Error: %s: unable to open file.\n", fname);
      return 1;
   }

   while (fgets (string, 199, file))
   {
      if (i >= n_params)
         break;

      if (sscanf (string,"%lf%lf%lf%lf%19s", &p[i].min, &p[i].nom,
         &p[i].max, &p[i].tol, p[i].name))
      {
         p[i].optimize = FALSE;
         ++i;
      }
   }
   fclose (file);

   if (i != n_params)
   {
      fprintf (stderr, "Error: %s: missing parameter(s).\n", fname);
      return 1;
   }

   /* check for bad starting values or illegal range values 
   (i.e. parameters that must be >= 0) */

   if (p[1].min < 0.0)  // alpha must be >= 0.0
      p[1].min = 0.0;

   if (p[2].min < 0.0)  // beta must be >= 0.0
      p[2].min = 0.0;

   if (p[3].min < 0.0)  // lambda must be >= 0.0
      p[3].min = 0.0;

   if (p[4].min < 0.0)  // gamma must be >= 0.0
      p[4].min = 0.0;

   /*
   if (p[5].min < 1.0)  // q must be >= 1.0
   p[5].min = 1.0;

   if (p[6].min < 1.0)  // k must be >= 1.0
   p[6].min = 1.0;
   */

   if (p[7].min < 1.0e-6)  // vst must be > 0.0
      p[7].min = 1.0e-6;

   if (p[8].min < 0.0)  // mst must be >= 0.0
      p[8].min = 0.0;

   if (p[11].min < 1.0e-6)  // qgi0 must be > 0.0
      p[11].min = 1.0e-6;

   if (p[14].min < 0.0)  // qggb must be >= 0.0
      p[14].min = 0.0;

   /* set the min, max, and nom values to be legal */

   for (i = 0; i < n_params; ++i)
   {
      if (p[i].nom < p[i].min)
         p[i].nom = p[i].min;
      if (p[i].max < p[i].min)
         p[i].max = p[i].min;
      if (p[i].nom > p[i].max)
         p[i].nom = p[i].max;
   }

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void get_file_header (char *data_file, char *header, unsigned max_size)
{
   FILE *file = fopen (data_file,"r");
   unsigned index = 0, len;
   char string[300];

   if (!header || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
   {
      if (string[0] != '!')
      {
         string[0] = 0;
         break;
      }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
      {
         if ((index + len) < max_size)
         {
            strcat (header, string);
            index += len;
         }
         else
            break;

         fgets (string,299,file);
         break;
      }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
      {
         strcat (header, string);
         index += len;
      }
      else
         break;
   }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if ((len > 0) && (index < max_size))
   {
      if ((index + len) < max_size)
      {
         strcat (header, string);
         index += len;
      }
      else if ((max_size - index) == 1);
      else
      {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
      }
   }
}

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMS fixed, int capmod)
{
   FILE *file;
   unsigned i;
   unsigned count = 0;
   char *names[200];
   double values[200];
   unsigned num_p = 0;

   /* write final optimization parameter values */

   file = fopen (end_file,"w+");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", end_file);
      return -1;
   }

   for (i = 0; i < NUM_PARAMS; ++i)
   {
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
   }
   fclose (file);

   /* write the model parameter file */

   // non-optimized parameters
   names[num_p] = "Ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "Ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "Tnom"; values[num_p] = fixed.tnom; ++num_p;
   names[num_p] = "Rg"; values[num_p] = fixed.rg; ++num_p;  // there is no Ri in the model
   names[num_p] = "Rd"; values[num_p] = fixed.rd; ++num_p;
   names[num_p] = "Rs"; values[num_p] = fixed.rs; ++num_p;
   names[num_p] = "Is"; values[num_p] = fixed.is; ++num_p;
   names[num_p] = "Eta"; values[num_p] = fixed.n; ++num_p;
   names[num_p] = "Ilk"; values[num_p] = fixed.ibd; ++num_p;
   names[num_p] = "Plk"; values[num_p] = fixed.vbd; ++num_p;
   names[num_p] = "Lg"; values[num_p] = fixed.lg; ++num_p;
   names[num_p] = "Ld"; values[num_p] = fixed.ld; ++num_p;
   names[num_p] = "Ls"; values[num_p] = fixed.ls; ++num_p;
   names[num_p] = "Capmod"; values[num_p] = capmod; ++num_p;


   for (i = 0; i < NUM_PARAMS; ++i)
   {
      names[num_p] = params[i].name;
      values[num_p] = params[i].nom;
      ++num_p;
   }

   file = fopen (model_file,"w+");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", model_file);
      return -1;
   }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");

   write_model_param_mdif (file, names, values, num_p, 12, 5);

   fclose (file);

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
{
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);

   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
}

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
{
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile;
   jHANDLE legend, header;
   unsigned i;

   switch (dev)
   {
   case POSTSCRIPT:
      plotfile = "tom3.ps";
      break;

   case METAFILE:
      plotfile = "tom3.wmf";
      break;

   case X_WINDOWS:
      plotfile = NULL;
      break;

   default:
      return 0;
   }

   if (!open_graphics_device (dev, plotfile))
   {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
   }

   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
   {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
   }

   // draw all plots
   for (i = 0; i < n; ++i)
   {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
      {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
      }

      plot_list[i]->active = FALSE;
   }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
   {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
   }
   else
      close_graphics_device ();

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static double safe_pow (double x, double y)
{
   return pow (x, y);
}

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files (char *input_file, char *param_file)
{
   FILE *file;
   OPT_PARAMETER p[] = {
      { -2.5, -0.5, 0.4, 0.0, "Vto", 0},
      { 0.0, 8.0, 30.0, 0.0, "Alpha", 0},
      { 0.0, 0.15, 0.8, 0.0, "Beta", 0},
      { 0.0, 0.001, 0.4, 0.0, "Lambda", 0},
      { 0.0, 0.01, 0.2, 0.0, "Gamma", 0},
      { 0.2, 0.5, 2.0, 0.0, "Q", 0},
      { 1.5, 2.0, 5.0, 0.0, "K", 0},
      { 1.0e-5, 0.15, 0.6, 0.0, "Vst", 0},
      { 0.0, 0.1, 0.5, 0.0, "Mst", 0},
      { 0.0, 3.5e-13, 6e-13, 0.0, "Qgql", 0},
      { 0.0, 9e-14, 1e-12, 0.0, "Qgqh", 0},
      { 1.0e-6, 2.0e-4, 1e-1, 0.0, "Qgi0", 0},
      { 0.2, 0.4, 1.2, 0.0, "Qgag", 0},
      { 2.5e-3, 0.4, 0.95, 0.0, "Qgad", 0},
      { 1e-3, 1.4, 10.0, 0.0, "Qggb", 0},
      { 0.0, 1.5e-14, 5e-13, 0.0, "Qgcl", 0},
      { -5e-13, 1.3e-13, 5e-13, 0.0, "Qgsh", 0},
      { 0.0, 2e-14, 8e-13, 0.0, "Qgdh", 0},
      { -1e-13, 4.5e-14, 1e-13, 0.0, "Qgg0", 0},
      { 1e-6, 1e-6, 1e-6, 0.0, "Taugd", 0},
      { 1e-12, 1e-12, 1e-12, 0.0, "Ctau", 0},
      { 0.0, 1e-13, 1e-12, 0.0, "Cds", 0},
      { 0.0, 4e-12, 8e-12, 0.0, "Tau", 0},
      { 0.0, 0.0, 0.0, 0.0, "Kgamma", 0}
   };

   if (input_file)
   {
      file = fopen (input_file, "w+");
      if (!file)
      {
         printf ("Error: %s: unable to write to disc.\n", input_file);
         return;
      }

      fprintf (file, "6                   # number of gate fingers\n");
      fprintf (file, "50                  # unit gate width (microns)\n");
      fprintf (file, "27                  # measurement temperature\n");
      fprintf (file, "s.end               # small-signal parameter file name\n");
      fprintf (file, "model.summary       # model summary file name\n");
      fprintf (file, "sdc.iv              # DC I-V file name\n");
      fprintf (file, "piv.iv              # pulsed I-V file name\n");
      fprintf (file, "5                   # maximum Vds\n");
      fprintf (file, "sfwd.iv             # forward I-V file name\n");
      fprintf (file, "svbr.iv             # breakdown I-V file name\n");
      fprintf (file, "tom3.start          # model parameter starting values file name\n");
      fprintf (file, "tom3.end            # model parameter finishing values file name (output)\n");
      fprintf (file, "tom3.model          # model file name (output)\n");
      fprintf (file, "250                 # maximum optimization line search iterations\n");

      fclose (file);
   }

   if (param_file)
   {
      unsigned i;

      file = fopen (param_file, "w+");
      if (!file)
      {
         printf ("Error: %s: unable to write to disc.\n", param_file);
         return;
      }

      fprintf (file, "! auto-generated file\n");
      for (i = 0; i < NUM_PARAMS; ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);

      fclose (file);
   }
}

/*****************************************************************************/
/*****************************************************************************/

static void read_vmax_from_file (char *fname, double *vmax, double *vpo)
{
   FILE *file;
   char string[256];

   *vmax = 1.0;
   *vpo = -1.0;

   file = fopen (fname, "r");
   if (!file)
      return;

   while (fgets (string, 255, file))
   {
      if (string[0] != '!')
         break;

      if (!strncmp (string, "!Vbr", 4))
      {
         if (fgets (string, 255, file))
            sscanf (string, "!%*f%*f%*f%*f%*f%*f%lf%lf", vmax, vpo);
         break;
      }
   }

   fclose (file);
}




