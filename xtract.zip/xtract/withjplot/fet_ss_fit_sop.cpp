#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <unistd.h>
#include <sys/time.h>
#include "generic_err.hpp"
#include "logger.hpp"
#include "touchstone.hpp"
#include "fet_ss_model.hpp"
#include "options.hpp"
#include "optimize.hpp"
#include "shell_glob.hpp"
#include "curve_fit.hpp"
#include "file_utils.hpp"
#include "jplot.h"


/***************************************************************************************/
// create an optimization problem class
class FET_SS_OPT : public OptProblem
{
protected:
    FET_SS_Model model_;
    NetworkParamSet yp_;
    NetworkParamSet sp_;
    std::vector<double> kfact_, mag_;
    double ws11_, ws21_, ws12_, ws22_; //S param mag weighting factors 
    double wsp11_, wsp21_, wsp12_, wsp22_; //S param phase weighting factors 
    double wy11_, wy21_, wy12_, wy22_; // y param weighting factors
    double wk_, wmag_;         //k factor /MAG weighting factors
    bool pctmode_;            // pct mode

    virtual double eval_();

public:

    void setParams( const ModelParamSet& parms, const std::string& names ) {
        model_.clearParams();
        model_.bindParams( parms );
        setOptParams( model_.getParams(), names );
    }

    const ModelParamSet& getParams() const { return model_.getParams(); }

    void setData( const NetworkParamSet& np ) {
        double k, mag;
        yp_ = np.copy();
        yp_.convert_to_y();
        sp_ = np.copy();
        sp_.convert_to_s();
	// precompute the K and MAG vectors
	kfact_.clear();
	mag_.clear();
	kfact_.reserve(np.size());
	mag_.reserve(np.size());
	for( NetworkParamSet::const_iterator i = sp_.begin(); i != sp_.end(); ++i ) {
	    compute_k_and_mag( *i, k, mag );
	    kfact_.push_back(k);
	    mag_.push_back(mag);
	}
    }

    void setOptions( const OptionSet& opt ) {
        std::istringstream is;
        is.str( opt.asString("sp_weights") );
        is >> ws11_ >> ws21_ >> ws12_ >> ws22_;
	is.clear();
	is.str( opt.asString("spp_weights") );
	is >> wsp11_ >> wsp21_ >> wsp12_ >> wsp22_;
	is.clear();
        is.str( opt.asString("yp_weights") );
        is >> wy11_ >> wy21_ >> wy12_ >> wy22_;
	pctmode_ = opt.asBool("pct_err_opt");
	wk_ = opt.asDouble("k_weight");
	wmag_ = opt.asDouble("mag_weight");
	if( pctmode_ ) logEvent( DebugEvent, "Using percent error optimization mode." );
    }

    FET_SS_OPT() : ws11_(6.), ws21_(10.), ws12_(2.), ws22_(6.), wsp11_(0.), wsp21_(0.), wsp12_(0.), wsp22_(0.), wy11_(0.), wy21_(0.), wy12_(0.), wy22_(0.), wk_(0.), wmag_(0.), pctmode_(0) {}
    virtual ~FET_SS_OPT() {}
};

/***************************************************************************************/
// create an optimization iteration callback linked to
//  the event logger
class OptIterCB_logger : public OptIterationCB
{
public:
    virtual void initial( const double& err ) {
        EventLogStream s( MessageEvent );
        s << "Optimization Initial Error: " << err;
    }

    virtual void final( const double& err ) {
        EventLogStream s( MessageEvent );
        s << "Optimization Final Error: " << err;
    }

    virtual bool onIter( size_t iter, const double& err ) {
        if( (iter % 5) == 0 ) {
            EventLogStream s( MessageEvent );
            s << "Iter: " << iter << "  ->  " << err;
        }
        return true;
    }

    virtual ~OptIterCB_logger() {}
};

/*******************************************************************************************/
// prototypes

std::string process_fname_pattern( const std::string& fname, const std::string& pattern );

static int fet_coldfet_main( int argc, char** argv, const OptionSet& options );
static void coldfet( Touchstone& np, const OptionSet& options, double& igi, double& rs, double& rd, double& lg, double& ls, double& ld );

static int fet_fit_main( int argc, char** argv, const OptionSet& options );
static int fet_optimization_main( const Touchstone& data, const OptionSet& opt, ModelParamSet& parms );
static int fet_yfit_main( const Touchstone& data, const OptionSet& opt, ModelParamSet& parms );
static NetworkParamSet remove_fet_parasitics( const NetworkParamSet& sp, const ModelParamSet& parms );
static void extract_capacitance( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms, double periph );
static void extract_gm_and_gds( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms, double periph );
static void extract_ri_and_tau( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms, double periph );
static void extract_ggs_and_ggd( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms );
static double ggs_s11_error( const NetworkParamSet& sp, const ModelParamSet& p, double ggs );
static void ggs_s11_fit( const NetworkParamSet& sp, ModelParamSet& p );

/***************************************************************************************/
/***************************************************************************************/
int main( int argc, char **argv )
{
    OptionSet options;
    std::string pname;



    // configure option definitions for auto-processing of command-line
    //   and file-based options
    options.addDef( OptionDef( "cap_min_freq",  // unique option name
            "",              // command line argument format(s)
            "yfit_cap_minf_ghz",   // option file keyword(s)
            option_float,   // option type
            "Minimum frequency for capacitance direct extraction in GHz." ) ); // option description (used in help statement generation)
    options.addDef( OptionDef( "cap_max_freq",
            "",
            "yfit_cap_maxf_ghz",
            option_float,
            "Maximum frequency for capacitance direct extraction in GHz." ) );
    options.addDef( OptionDef( "ritau_min_freq",
            "",
            "yfit_ritau_minf_ghz",
            option_float,
            "Minimum frequency for Ri/Rgd/Tau/Tau2 direct extraction in GHz." ) );
    options.addDef( OptionDef( "ritau_max_freq",
            "",
            "yfit_ritau_maxf_ghz",
            option_float,
            "Maximum frequency for Ri/Rgd/Tau/Tau2 direct extraction in GHz." ) );
    options.addDef( OptionDef( "gmgds_min_freq",
            "",
            "yfit_gmgds_minf_ghz",
            option_float,
            "Minimum frequency for gm/gds direct extraction in GHz." ) );
    options.addDef( OptionDef( "gmgds_max_freq",
            "",
            "yfit_gmgds_maxf_ghz",
            option_float,
            "Maximum frequency for gm/gds direct extraction in GHz." ) );
    options.addDef( OptionDef( "ggsd_min_freq",
            "",
            "yfit_ggsggd_minf_ghz",
            option_float,
            "Minimum frequency for ggs/ggd direct extraction in GHz." ) );
    options.addDef( OptionDef( "ggsd_max_freq",
            "",
            "yfit_ggsggd_maxf_ghz",
            option_float,
            "Maximum frequency for ggs/ggd direct extraction in GHz." ) );
    options.addDef( OptionDef( "batch_mode",
            "-b|--batch",
            "",
            option_boolean,
            "Batch mode (fork to a background process)." ) );
    options.addDef( OptionDef( "verbose",
            "-v|--verbose",
            "",
            option_boolean,
            "Print extra information about what is happening." ) );
    options.addDef( OptionDef( "debug_mode",
            "--debug",
            "",
            option_boolean,
            "Prints lots of debugging information." ) );
    options.addDef( OptionDef( "do_yfit",
            "--yfit",
            "",
            option_boolean,
            "Run the direct extraction routine as part of the fit." ) );
    options.addDef( OptionDef( "do_coldfet",
            "--coldfet",
            "",
            option_boolean,
            "Run coldfet extraction." ) );
    options.addDef( OptionDef( "do_opt",
            "--opt",
            "",
            option_boolean,
            "Optimize the parameters as part of the fit." ) );
    options.addDef( OptionDef( "do_opt",
            "--noopt",
            "",
            option_negative_boolean,
            "Do not optimize the parameters as part of the fit." ) );
    options.addDef( OptionDef( "fix_parasitics",
            "--fix-parasitics|--fix-extrinsics",
            "",
            option_boolean,
            "Do not optimize RG, RS, RD, LG, B1, B2, C11, C22, C1 or C2." ) );
    options.addDef( OptionDef( "extrinsics_file",
            "--extrinsics=?",
            "extrinsics_file",
            option_any,
            "Set the name of the file to read/write extrinsics from/to." ) );
    options.addDef( OptionDef( "parameters_file",
            "-f ?|--params=?",
            "parameters_file",
            option_any,
            "Set the name of the file to read/write model parameters from/to." ) );
    options.addDef( OptionDef( "output_file",
            "-o ?|--out=?",
            "",
            option_any,
            "Set the name of the file to write model parameters to (overrides the -f/--params option)." ) );
    options.addDef( OptionDef( "sp_weights",
            "",
            "sparam_weights",
            option_any,
            "Weighting values for \"s11 s21 s12 s22\" - four numbers separated by whitespace." ) );
    options.addDef( OptionDef( "spp_weights",
            "",
            "sphase_weights",
            option_any,
            "Weighting values for phase \"s11 s21 s12 s22\" - four numbers separated by whitespace." ) );
    options.addDef( OptionDef( "yp_weights",
            "",
            "yparam_weights",
            option_any,
            "Weighting values for \"y11 y21 y12 y22\" - four numbers separated by whitespace." ) );
    options.addDef( OptionDef( "k_weight",
            "",
            "kfactor_weight",
            option_any,
            "Weighting value for K-factor." ) );
    options.addDef( OptionDef( "mag_weight",
            "",
            "maxgain_weight",
            option_any,
            "Weighting value for maximum available gain." ) );
    options.addDef( OptionDef( "pct_err_opt",
            "",
            "use_pct_error",
            option_boolean,
            "Use percent error instead of absolute error for optimization." ) );
    options.addDef( OptionDef( "coldfet_files",
            "",
            "coldfet_files",
            option_any,
            "Files to use for cold-FET fitting." ) );
    options.addDef( OptionDef( "coldfet_minf",
            "",
            "coldfet_minf_ghz",
            option_float,
            "Minimum frequency for cold-FET fitting in GHz." ) );
    options.addDef( OptionDef( "coldfet_maxf",
            "",
            "coldfet_maxf_ghz",
            option_float,
            "Maximum frequency for cold-FET fitting in GHz." ) );
    options.addDef( OptionDef( "coldfet_r_freq",
            "",
            "coldfet_rfreq_ghz",
            option_float,
            "Frequency for extracting cold-FET resistance in GHz." ) );
    options.addDef( OptionDef( "gate_length",
            "",
            "gate_length_um",
            option_float,
            "FET gate length in microns." ) );
    options.addDef( OptionDef( "unit_gate_width",
            "",
            "unit_gate_width_um",
            option_float,
            "FET unit gate width in microns. Setting this overrides any values read from the header of a data file." ) );
    options.addDef( OptionDef( "number_of_gate_fingers",
            "",
            "number_of_gate_fingers",
            option_int,
            "The number of gate fingers. Setting this overrides any values read from the header of a data file." ) );
    options.addDef( OptionDef( "gate_length_factor",
            "",
            "gate_length_factor",
            option_float,
            "Factor used in calculating channel resistance. Default = 1.4." ) );
    options.addDef( OptionDef( "rg_factor",
            "",
            "rg_factor",
            option_float,
            "Factor used in calculaing RG. Default = 0.333." ) );
    options.addDef( OptionDef( "gate_sheetrho",
            "",
            "gate_sheet_r",
            option_float,
            "Sheet resistance of the gate metal in ohms/square." ) );
    options.addDef( OptionDef( "channel_sheetrho",
            "",
            "channel_sheet_r",
            option_float,
            "Sheet resistance of the channel in ohms/square." ) );
    options.addDef( OptionDef( "extract_tau2",
            "-t2|--extract-tau2",
            "extract_tau2",
            option_boolean,
            "Turn on extraction of TAU2. By default it is disabled." ) );
    options.addDef( OptionDef( "extract_cfringe",
            "-cxx|--extract-cxx",
            "extract_cxx",
            option_boolean,
            "Turn on extraction of C11/C22. By default it is disabled." ) );


    // set some default option values
    options.set( "parameters_file", "%(base).end" );
    options.set( "extrinsics_file", "s.end" );
    options.set( "cap_max_freq", "10" );
    options.set( "gmgds_max_freq", "10" );
    options.set( "ggsd_max_freq", "2" );
    options.set( "ritau_min_freq", "15" );
    options.set( "ritau_max_freq", "100" );
    options.set( "OptionsVerbose", "1" );
    options.set( "do_opt", "1" );
    options.set( "coldfet_maxf", "100" );
    options.set( "coldfet_minf", "20" );
    options.set( "coldfet_r_freq", "1" );
    options.set( "gate_length_factor", "1.4" );
    options.set( "rg_factor", "0.333" );

    // process the default option file if it can be found
    options.processFile( "fetmodel.cfg", 3 );

    // process the command line
    try {
        options.processCL( argc, argv );
    }
    catch( OptionError& e ) {
        // this is fatal
        std::cerr << "Fatal error: " << e.what() << std::endl;
        return 127;
    }

    // look for unrecognized command-line switches
    for( int i=1; i<argc; ++i ) {
        if( argv[i][0] == '-' ) {
            std::cerr << "Error: unrecognized command-line option: " << argv[i] << std::endl;
            return 2;
        }
    }

    // set the logging level
    SetLoggingLevel( options.asBool("verbose") ? 3 : 2 );
    if( options.asBool("debug_mode") ) SetLoggingLevel( 10 );

    // examine the invoking name to set additional flags
    //  or directly invoke sub-routines (coldfet, etc.)
    pname = argv[0];
    if( pname.find("batch") != std::string::npos ) {
        options.set( "do_yfit", "1" );
        options.set( "do_opt", "1" );
        options.set( "batch_mode", "1" );
    }
    else if( pname.find("yfit") != std::string::npos ) {
        options.set( "do_yfit", "1" );
        options.set( "do_opt", "0" );
    }
    else if( pname.find("cold") != std::string::npos ) {
        options.set( "do_coldfet", "1" );
    }

    // run either fet fit or coldfet
    if( options.asBool("do_coldfet") )
        return fet_coldfet_main( argc, argv, options );
    else
        return fet_fit_main( argc, argv, options );
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
// coldfet extraction main
static int fet_coldfet_main( int argc, char** argv, const OptionSet& options )
{
    ModelParamSet p;
    double c11 = 0.;
    double c22 = 0.;
    double rg=1.e-4, rd=1.e-4, rs=1.e-4;
    double lg=1.e-18, ld=1.e-18, ls=1.e-18;
    double ugw=0., ngf=0.;
    bool err = false;
    std::vector<std::string> files;

    // determine the file list
    if( argc > 1 ) {
        // use command-line files if they were provided
        for( int i=1; i<argc; ++i ) files.push_back(argv[i]);
    }
    else {
        // no files on the command line
        //  attempt to use the options to read in a pattern
        //  and then use ShellWordExp to expand the pattern
        //  to a listing of files
        ShellWordExp exp;
        std::string pattern = options.asString( "coldfet_files" );
        if( pattern.length() ) {
            exp.exec( pattern.c_str() );
            if( exp.ok() && exp.num_words() ) {
                for( ShellWordExp::iterator f = exp.begin(); f != exp.end(); ++f ) files.push_back( *f );
            }
        }
    }

    if( files.size() > 1 ) {
        // compute coldfet for each file
        Touchstone ts;
        double m, r2;
        double* igiv = new double [ files.size() ];
        double* lgv = new double [ files.size() ];
        double* ldv = new double [ files.size() ];
        double* lsv = new double [ files.size() ];
        double* rdv = new double [ files.size() ];
        double* rsv = new double [ files.size() ];
        size_t n = 0;
        for( std::vector<std::string>::iterator fname = files.begin(); fname != files.end(); ++fname ) {
            try {
                logEvent( MessageEvent, std::string( "Running coldfet() on: " ) + *fname );
                ts.read( *fname );
                if( ts.ports() != 2 ) throw GenericError( "not a 2-port data file." );

                // attempt to read UGW and NGF from the header of the file
                if( !ugw || !ngf ) {
                    std::istringstream is;
                    std::string ln;
                    is.str( ts.header() );
                    while( !is.eof() ) {
                        std::getline( is, ln );
                        if( ln.substr(0,22) == "!UNIT GATE WIDTH (um):" ) {
                            std::istringstream ss;
                            ss.str( ln.substr(22) );
                            ss >> ugw;
                        }
                        else if( ln.substr(0,24) == "!NUMBER OF GATE FINGERS:" ) {
                            std::istringstream ss;
                            ss.str( ln.substr(24) );
                            ss >> ngf;
                        }
                    }

                    if( ugw && ngf ) {
                        EventLogStream s( DebugEvent );
                        s << "Read UGW = " << ugw << ", NGF = " << ngf;
                    }
                }

                coldfet( ts, options, igiv[n], rsv[n], rdv[n], lgv[n], lsv[n], ldv[n] );
                ++n;
            }
            catch( std::exception& e ) {
                logEvent( ErrorEvent, std::string("fet_coldfet_main(): ") + *fname + std::string(": ") + e.what() );
            }
        }

        if( n > 1 ) {
            // do a linefit on the data
            linefit_mxb( igiv, lgv, n, m, lg, r2 );
            linefit_mxb( igiv, ldv, n, m, ld, r2 );
            linefit_mxb( igiv, lsv, n, m, ls, r2 );
            linefit_mxb( igiv, rsv, n, m, rs, r2 );
            linefit_mxb( igiv, rdv, n, m, rd, r2 );
            // correct for "invalid" parameter values
            if( rd < 1.e-4 ) rd = 1.e-4;
            if( rs < 1.e-4 ) rs = 1.e-4;
            if( ls < 1.e-18 ) ls = 1.e-18;
            if( ld < 1.e-18 ) ld = 1.e-18;
            if( lg < 1.e-18 ) lg = 1.e-18;
            // create a warning if inductances seem to be abnormal
            if( lg < 2.e-12 || lg > 100.e-12 ) logEvent( WarningEvent, "fet_coldfet_main(): LG value is abnormal. Possible reference plane issue." );
            if( ld < 2.e-12 || ld > 100.e-12 ) logEvent( WarningEvent, "fet_coldfet_main(): LD value is abnormal. Possible reference plane issue." );
            if( ls > 50.e-12 ) logEvent( WarningEvent, "fet_coldfet_main(): LS value is abnormal. Possible reference plane issue." );
        }
        else {
            logEvent( ErrorEvent, "fet_coldfet_main(): at least 2 files are required for coldfet extraction." );
            err = true;
        }

        delete [] igiv;
        delete [] lgv;
        delete [] ldv;
        delete [] lsv;
        delete [] rdv;
        delete [] rsv;
    }
    else {
        logEvent( ErrorEvent, "fet_coldfet_main(): at least 2 files are required for coldfet extraction." );
        err = true;
    }

    // compute fringing capacitances (c11 and c22)
    if( options.asBool( "extract_cfringe" ) ) {



        // need to figure out how to determine the file name




    }

    // grab override values for ugw and ngf from the options
    ugw = options.asDouble( "unit_gate_width", ugw );
    ngf = options.asDouble( "number_of_gate_fingers", ngf );
    if( ugw && ngf ) {
        EventLogStream s( DebugEvent );
        s << "Using UGW = " << ugw << ", NGF = " << ngf;
    }

    if( ugw && ngf ) {
        double glen = options.asDouble( "gate_length" );
        double rgsh = options.asDouble( "gate_sheetrho" );
        double chsh = options.asDouble( "channel_sheetrho" );
        double rgfact = options.asDouble( "rg_factor" );
        double glfact = options.asDouble( "gate_length_factor" );

        // compute RG
        if( rgsh && glen && rgfact ) rg = rgsh * ugw / glen / ngf * rgfact;
        else {
            err = true;
            logEvent( ErrorEvent, "fet_coldfet_main(): gate_length, gate_sheetrho, and rg_factor must all be defined for RG calculation." );
        }

        // compute RCH (channel resistance)
        //  and correct RD and RS for RCH
        if( glen && chsh && glfact ) {
            double rch = chsh * glen / ugw / ngf * glfact;
            if( rd > 0.5*rch ) rd -= 0.5*rch;
            if( rs > 0.5*rch ) rs -= 0.5*rch;
        }
        else logEvent( WarningEvent, "fet_coldfet_main(): gate_length, channel_sheetrho, and gate_length_factor must all be defined for RS/RD correction." );
    }
    else {
        err = true;
        logEvent( ErrorEvent, "fet_coldfet_main(): unable to determine the unit gate width and/or number of gate fingers." );
    }

    // push model parameters onto the ModelParamSet in the correct order
    //  (to be backward compatible with older software)
    p.push( ModelParam( "RG", rg ) );
    p.push( ModelParam( "RS", rs ) );
    p.push( ModelParam( "RD", rd ) );
    p.push( ModelParam( "RI" ) );
    p.push( ModelParam( "CGS" ) );
    p.push( ModelParam( "CDG" ) );
    p.push( ModelParam( "CDS" ) );
    p.push( ModelParam( "C1" ) );
    p.push( ModelParam( "C2" ) );
    p.push( ModelParam( "LS", ls ) );
    p.push( ModelParam( "B1", lg ) );
    p.push( ModelParam( "B2", ld ) );
    p.push( ModelParam( "GGS" ) );
    p.push( ModelParam( "GDG" ) );
    p.push( ModelParam( "GM" ) );
    p.push( ModelParam( "TAU1" ) );
    p.push( ModelParam( "GDS" ) );
    p.push( ModelParam( "TAU2" ) );
    p.push( ModelParam( "C11", c11 ) );
    p.push( ModelParam( "C22", c22 ) );

    // write the extrinsics file
    std::string fname = options.asString("output_file");
    if( !fname.length() )
        fname = options.asString("extrinsics_file");
    if( !fname.length() )
        fname = "s.end";

    if( !p.write_end_file(fname) ) {
        logEvent( ErrorEvent, std::string("fet_coldfet_main(): failed to write file: ") + fname );
        return 1;
    }

    return err;
}

/***************************************************************************************/
static void coldfet( Touchstone& np, const OptionSet& options, double& igi, double& rs,
    double& rd, double& lg, double& ls, double& ld )
{
    matrix::CMatrix z;
    std::complex<double> zcom;
    double mn = options.asDouble( "coldfet_minf" ) * 1.e9;
    double mx = options.asDouble( "coldfet_maxf" ) * 1.e9;
    double rf = options.asDouble( "coldfet_r_freq" ) * 1.e9;
    int c = 0;
    std::istringstream ss;
    std::string line;
    double w;

    // initialize the inductances and gate current
    lg = ls = ld = 0.;
    igi = 0.;

    // read the gate current from the header
    ss.str( np.header() );
    while( !ss.eof() ) {
        std::getline( ss, line );
        if( line.substr(0,6) == "!Bias:" ) {
            size_t p = line.find( "IGS" );
            if( p != std::string::npos ) {
                ss.clear();
                ss.str( line.substr(p+5) );
                ss >> igi;
                break;
            }
        }
    }
    if( !igi ) throw GenericError( "coldfet(): bias information could not be determined." );
    igi = 1. / igi;


    // calculate the inductances
    np.convert_to_z();
    for( Touchstone::iterator i = np.begin(); i != np.end(); ++i ) {
        if( i->freq() >= mn && i->freq() <= mx ) {
            w = 2. * M_PI * i->freq();
            zcom = 0.5 * ((*i)(0,1) + (*i)(1,0));
            lg += ((*i)(0,0) - zcom).imag() / w;
            ld += ((*i)(1,1) - zcom).imag() / w;
            ls += zcom.imag() / w;
            ++c;
        }
    }

    if( c ) {
        lg /= (double) c;
        ld /= (double) c;
        ls /= (double) c;
    }
    else throw GenericError( "coldfet(): no data available for LG/LD/LS extraction." );

    // extract resistance
    z = np.extract( rf );
    zcom = 0.5 * (z(0,1) + z(1,0));
    rd = (z(1,1) - zcom).real();
    rs = zcom.real();
}

/***************************************************************************************/
static void coldfet_cfringe( const Touchstone& sp, const ModelParamSet& parms, double& c11, double& c22 )
{









}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
static int fet_fit_main( int argc, char** argv, const OptionSet& options )
{
    Touchstone sp;
    ModelParamSet parms;
    std::string fname, pname;
    struct timeval start, stop;
    double sec;

    // make sure that there are still command-line files to work on
    if( argc < 2 ) {
        std::cerr << "Error: no files to process." << std::endl;
        return 1;
    }

    // if working in batch mode:
    //   - set logging target to a log file
    //   - fork to a background process
    if( options.asBool("batch_mode") ) {
        SetLoggingTarget( new FileEventLogger( "z_fetmodel.log" ) );

        switch( fork() ) {
        case -1:
            // fork() failed!!!
            std::cerr << "Fatal error: fork() failed." << std::endl;
            return -1;
        case 0:
            break;  // child (background) process
        default:
            _exit(0); // parent process
        }
    }

    logEvent( MessageEvent, "==========================================================================" );
    logEvent( MessageEvent, std::string("FET fitting routine started at: ") + getTimestamp() );
    logEvent( MessageEvent, "==========================================================================" );

    // start a timer
    gettimeofday( &start, NULL );

    if( options.asString("output_file").length() && argc > 1 ) {
        logEvent( ErrorEvent, "The -o/--out option cannot be used with multiple targets." );
	return -1;
    }

    // loop through the command-line files and do what needs to be done
    for( int i=1; i<argc; ++i ) {
        try {
            fname = argv[i];

            logEvent( MessageEvent, std::string("******** Extracting model for: ") + fname + " ********" );

            // read s-parameters
            sp.read( fname );
            sp.convert_to_s();

            // determine the parameter file name
            pname = options.asString("output_file");
            if( !pname.length() )
                pname = filename_pattern_replace( fname, options.asString("parameters_file") );
            if( !pname.length() ) {
                logEvent( ErrorEvent, fname + ": could not generate a valid parameter file name." );
                continue;
            }

            if( options.asBool("do_yfit") ) {
                // read in the extrinsics
                if( ! parms.read_end_file( options.asString("extrinsics_file"), ModelParamSet::upper_case ) ) {
                    EventLogStream s( ErrorEvent );
                    s << fname << ": extrinsics file \'" << options.asString("extrinsics_file") << "\' not readable.";
                    continue;
                }

                // do the yfit
                if( fet_yfit_main( sp, options, parms ) ) {
                    EventLogStream s( ErrorEvent );
                    s << fname << ": Y-fit failed.";
                    continue;
                }
            }

            if( options.asBool("do_opt") ) {
                if( ! options.asBool("do_yfit") ) {
                    // read model parameters from the parameters file
                    if( ! parms.read_end_file(pname, ModelParamSet::upper_case) ) {
                        EventLogStream s( ErrorEvent );
                        s << fname << ": parameters file \'" << pname << "\' not readable.";
                        continue;
                    }
                }

                // do the optimization
                if( fet_optimization_main(sp,options,parms) ) {
                    EventLogStream s( ErrorEvent );
                    s << fname << ": optimization failed.";
                    continue;
                }
            }

            // write the model parameters to the file
            if( ! parms.write_end_file( pname ) ) {
                EventLogStream s ( ErrorEvent );
                s << fname << ": could not write parameter file \'" << pname << "\'.";
                continue;
            }
            else {
                EventLogStream s( MessageEvent );
                s << "Wrote parameter file \'" << pname << "\'.";
            }

            // generate plots





        }
        catch( NetworkParametersError& e ) {
            EventLogStream s( ErrorEvent );
            s << fname << ": NetworkParametersError: " << e.what();
            continue;
        }
        catch( OptimizeError& e ) {
            EventLogStream s( ErrorEvent );
            s << fname << ": OptimizeError: " << e.what();
            continue;
        }
        catch( std::exception& e ) {
            EventLogStream s( ErrorEvent );
            s << fname << ": Exception: " << e.what();
            continue;
        }
    }

    // stop the timer
    gettimeofday( &stop, NULL );

    // compute and print the elapsed time
    sec = stop.tv_sec - start.tv_sec;
    sec += stop.tv_usec * 1.e-6;
    sec -= start.tv_usec * 1.e-6;

    logEvent( MessageEvent, "==========================================================================" );
    logEvent( MessageEvent, std::string("FET fitting routine finished at: ") + getTimestamp() );
    {
        EventLogStream s( MessageEvent );
        s << "Elapsed time: " << sec << " seconds.";
    }
    logEvent( MessageEvent, "==========================================================================" );

    return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
static int fet_optimization_main( const Touchstone& data, const OptionSet& opt, ModelParamSet& parms )
{
    FET_SS_OPT problem;
    NetworkParamSet data2;
    std::string names = "__ALL__";
    OptimizeEngine engine;
    double fstart = data.begin()->freq();
    double fstop = data.rbegin()->freq();
    double reqfstart = opt.asDouble( "minf_for_opt" );
    double reqfstop = opt.asDouble( "maxf_for_opt", 100.e9 );
    double fstep = 500.e6;
    NetworkParam parm;
    OptIterCB_logger log;

    logEvent( MessageEvent, "Running optimization." );

    // determine what to optimize
    if( opt.asBool("batch_mode") || opt.asBool("fix_parasitics") ) {
        names = "CGS CDG CDS TAU1 TAU2 GGS GDG GM RI GDS";
    }

    // create a reduced data set for optimization
    //  and attach the data to the optimization
    if( reqfstart < fstart ) reqfstart = fstart;
    if( reqfstop > fstop ) reqfstop = fstop;
    for( double f = reqfstart; f <= reqfstop; f += fstep )
        data2.add( data.extract(f) );
    if( data2.rbegin()->freq() != reqfstop )
        data2.add( data.extract(reqfstop) );
    problem.setData( data2 );

    // bind the model parameters to the optimization problem
    //  and define which parameters to optimize
    problem.setParams( parms, names );

    // set problem options
    problem.setOptions( opt );

    // configure the optimization output
    engine.setCallback( &log );

    // configure and start the optimization
    try {
        engine.setMethod( "gradient" );
        engine.optimize( problem, opt );
    }
    catch( OptimizeError& e ) {
        logEvent( ErrorEvent, e.what() );
        return 1;
    }

   return 0;
}

/*******************************************************************************************/
//compute the divisor safely for percent error optimization
inline double safe_mag_divisor( const std::complex<double>& x ) {
    double y = std::abs(x);
    if( y < 1.e-18 ) y = 1.e-18;
    return y;
}

inline double safe_mag_divisor( const double& x ) {
    double y = fabs(x);
    if( y < 1.e-18 ) y = 1.e-18;
    return y;
}
/*******************************************************************************************/
double FET_SS_OPT::eval_()
{
    matrix::CMatrix y;
    matrix::CMatrix s;
    matrix::CVector zref(2);
    NetworkParamSet::iterator ypi, spi;
    double err = 0.;
    std::complex<double> t;
    double td, tt ;
    double w, wp ;
    int j, n, m;

    zref = std::complex<double>(50.);

    for( ypi = yp_.begin(), spi = sp_.begin(), j=0; ypi != yp_.end(); ++ypi, ++spi, ++j ) {
        // compute the model
        y = model_.compute_y( ypi->freq() );
        s = YtoS_( y, zref );

        if( pctmode_ ) {
            // compute the [S] errors
            for( int i=0; i<4; ++i ) {
                switch(i) {
                default:
                case 0:
                    w = ws11_; wp = wsp11_; n=0; m=0; break;
                case 1:
                    w = ws21_; wp = wsp21_; n=1; m=0; break;
                case 2:
                    w = ws12_; wp = wsp12_; n=0; m=1; break;  //add s12
                case 3:
                    w = ws22_; wp = wsp22_; n=1; m=1; break;
                }

                if( w > 0. || wp > 0.) {
                    //t = (s(n,m) - (*spi)(n,m)) / safe_mag_divisor((*spi)(n,m));
                    //err += w * (t * std::conj(t)).real();
                    td = (std::abs(s(n,m)) - std::abs((*spi)(n,m))) / safe_mag_divisor((*spi)(n,m));
		    tt =(std::arg(s(n,m))- std::arg((*spi)(n,m)))/std::arg(s(n,m));
                    err += w * td * td + wp * tt * tt;
                }
            }
            // compute magnitude only for S12
            //if( ws12_ > 0. ) {
            //    td = (std::abs(s(0,1)) - std::abs((*spi)(0,1))) / safe_mag_divisor((*spi)(0,1));
            //    err += ws12_ * td * td;
            //}

            // compute the [Y] errors
            for( int i=0; i<4; ++i ) {
                switch(i) {
                default:
                case 0:
                    w = wy11_; n=0; m=0; break;
                case 1:
                    w = wy21_; n=1; m=0; break;
                case 2:
                    w = wy12_; n=0; m=1; break;
                case 3:
                    w = wy22_; n=1; m=1; break;
                }

                if( w > 0. ) {
                    t = (y(n,m) - (*ypi)(n,m)) / safe_mag_divisor((*ypi)(n,m));
                    err += w * (t * std::conj(t)).real();
                }
            }
            // compute magnitude only for Y12
            //if( ws12_ > 0. ) {
            //    td = (std::abs(y(0,1)) - std::abs((*ypi)(0,1))) / safe_mag_divisor((*ypi)(0,1));
            //    err += wy12_ * td * td;
            //}

            // compute K/MAG errors
            if( wk_ > 0. || wmag_ > 0. ) {
	        double k, mag;
	        compute_k_and_mag( *spi, k, mag );

		td = (k - kfact_[j]) / safe_mag_divisor(kfact_[j]);
		err += wk_ * td * td;

		td = (mag - mag_[j]) / safe_mag_divisor(mag_[j]);
		err += wmag_ * td * td;
            }
	}
	else {
            // compute the [S] errors
            for( int i=0; i<4; ++i ) {
                switch(i) {
                default:
                case 0:
                    w = ws11_; n=0; m=0; break;
                case 1:
                    w = ws21_; n=1; m=0; break;
                case 2:
                    w = ws12_; n=0; m=1; break;
                case 3:
                    w = ws22_; n=1; m=1; break;
                }

                if( w > 0. ) {
                    t = s(n,m) - (*spi)(n,m);
                    err += w * (t * std::conj(t)).real();
                }
            }
            // change: move the s12 back to the loop, calculate both mag and phase
            // compute magnitude only for S12
            //if( ws12_ > 0. ) {
            //    td = std::abs(s(0,1)) - std::abs((*spi)(0,1));
            //    err += ws12_ * td * td;
            //}

            // compute the [Y] errors
            for( int i=0; i<3; ++i ) {
                switch(i) {
                default:
                case 0:
                    w = wy11_; n=0; m=0; break;
                case 1:
                    w = wy21_; n=1; m=0; break;
                case 2:
                    w = wy22_; n=1; m=1; break;
                }

                if( w > 0. ) {
                    t = y(n,m) - (*ypi)(n,m);
                    err += w * (t * std::conj(t)).real();
                }
            }
            // compute magnitude only for Y12
            if( wy12_ > 0. ) {
                td = std::abs(y(0,1)) - std::abs((*ypi)(0,1));
                err += wy12_ * td * td;
            }

            // compute K/MAG errors
            if( wk_ > 0. || wmag_ > 0. ) {
	        double k, mag;
	        compute_k_and_mag( *spi, k, mag );

		td = k - kfact_[j];
		err += wk_ * td * td;

		td = mag - mag_[j];
		err += wmag_ * td * td;
            }
        }
    }
    return err;
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
static int fet_yfit_main( const Touchstone& data, const OptionSet& opt, ModelParamSet& parms )
{
    NetworkParamSet yp;
    std::istringstream is;
    std::string line;
    double periph = 0.;

    logEvent( MessageEvent, "Running Y-fit." );

    // deembed the fixed parasitics
    yp = remove_fet_parasitics( data, parms );

    // grab the periphery from the header
    is.str( data.header() );
    while( ! is.eof() ) {
        std::getline( is, line );
        if( line.substr(0,21) == "!GATE PERIPHERY (um):" ) {
            is.str( line.substr(21) );
            is >> periph;
            periph *= 1.e-3;
            break;
        }
    }

    // check the periphery, if it is invalid log a warning
    //  then use the default periphery of 200 um
    if( ! periph ) {
        // log a warning message
        EventLogStream s( WarningEvent );
        periph = 0.2;
        s << "GATE PERIPHERY header was not found. Setting periphery to " << periph << " mm.";
    }

    // do the y-fit
    try {
        extract_capacitance( yp, opt, parms, periph );
        extract_gm_and_gds( yp, opt, parms, periph );
        extract_ri_and_tau( yp, opt, parms, periph );
        extract_ggs_and_ggd( yp, opt, parms );
    }
    catch( std::exception& e ) {
        // log the error somehow
        EventLogStream s( ErrorEvent );
        s << e.what();
        return 1;
    }

    return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/
static NetworkParamSet remove_fet_parasitics( const NetworkParamSet& sp, const ModelParamSet& parms )
{
    NetworkParamSet yp_dmb( sp.copy() );
    double w;
    double cpg = parms["C1"].value();
    double cpd = parms["C2"].value();
    double c11 = parms["C11"].value();
    double c22 = parms["C22"].value();
    double rg = parms["RG"].value();
    double rd = parms["RD"].value();
    double rs = parms["RS"].value();
    double lg = parms["B1"].value();
    double ld = parms["B2"].value();
    double ls = parms["LS"].value();
    matrix::CMatrix p;
    std::complex<double> zcom;

    // start in [Y]
    yp_dmb.convert_to_y();

    for( NetworkParamSet::iterator i = yp_dmb.begin(); i != yp_dmb.end(); ++i ) {
        w = 2. * M_PI * i->freq();
        p = (matrix::CMatrix) *i;
        // remove C1 and C2 (Cpg and Cpd)
        p(0,0) -= std::complex<double>( 0., w * cpg );
        p(1,1) -= std::complex<double>( 0., w * cpd );
        // convert to [Z]
        p = YtoZ_( p );
        // remove B1 and B2 (Lg and Ld)
        //  and LS / RS
        zcom = std::complex<double>( rs, w*ls );
        p(0,0) -= std::complex<double>( 0., w * lg ) + zcom;
        p(1,1) -= std::complex<double>( 0., w * ld ) + zcom;
        p(0,1) -= zcom;
        p(1,0) -= zcom;
        // convert to [Y]
        p = ZtoY_( p );
        // remove C11 and C22
        p(0,0) -= std::complex<double>( 0., w * c11 );
        p(1,1) -= std::complex<double>( 0., w * c22 );
        // convert to [Z]
        p = YtoZ_( p );
        // remove RG and RD
        p(0,0) -= rg;
        p(1,1) -= rd;
        // convert to [Y]
        p = ZtoY_( p );
        // store the intrinsic [Y] matrix
        *i = p;
    }
    return yp_dmb;
}

/******************************************************************************************/
/******************************************************************************************/
static void extract_capacitance( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms, double periph )
{
    double cmn = opt.asDouble("cap_min_freq") * 1.e9;
    double cmx = opt.asDouble("cap_max_freq") * 1.e9;
    int n = 0;
    double cgs = 0.;
    double cgd = 0.;
    double cds = 0.;
    double w;
    EventLogStream log( MessageEvent );

    log << "capacitance minimum frequency: " << cmn;
    log.flush();
    log << "capacitance maximum frequency: " << cmx;
    log.flush();

    for( NetworkParamSet::const_iterator i = yp.begin(); i != yp.end(); ++i ) {
        if( cmn <= i->freq() && i->freq() <= cmx ) {
            w = 2. * M_PI * i->freq();
            cgs += -1. / ( w * ( 1. / ( (*i)(0,0) + (*i)(0,1) ) ).imag() );
            cgd -= (*i)(0,1).imag() / w;
            cds += ( (*i)(1,1) + (*i)(0,1) ).imag() / w;
            ++n;
        }
    }

    if( n ) {
        cgs /= (double) n;
        cgd /= (double) n;
        cds /= (double) n;
    }
    else throw GenericError( "extract_capacitance(): no data available for Cgs/Cgd/Cds direct extraction." );

    // adjust for out of range values,
    // set the values in the ModelParamSet,
    //  and the optimization ranges
    if( cgs < 0. ) {
        parms["CGS"].setValue(0.);
        parms["CGS"].setOptBoth(0.,1.e-12*periph);
    }
    else {
        parms["CGS"].setValue(cgs);
        parms["CGS"].setOptBoth(cgs*0.6,cgs*1.4);
    }
    if( cgd < 0. ) {
        parms["CDG"].setValue(0.);
        parms["CDG"].setOptBoth(0.,8.e-13*periph); //tune to fit S12, default 2e-13*periph
    }
    else {
        parms["CDG"].setValue(cgd);
        parms["CDG"].setOptBoth(cgd*0.6,cgd*4.4); //tune to fit S12, default is 1.4
    }
    if( cds < 0. ) {
        parms["CDS"].setValue(0.);
        parms["CDS"].setOptBoth(0.,5.e-13*periph);
    }
    else {
        parms["CDS"].setValue(cds);
        parms["CDS"].setOptBoth(cds*0.6,cds*1.4);
    }
}

/******************************************************************************************/
/******************************************************************************************/
static void extract_gm_and_gds( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms, double periph )
{
    double mn = opt.asDouble("gmgds_min_freq") * 1.e9;
    double mx = opt.asDouble("gmgds_max_freq") * 1.e9;
    int c = 0;
    double gm = 0.;
    double gds = 0.;
    double cgs = parms["CGS"].value();
    double gdsmax;
    EventLogStream log( MessageEvent );

    log << "gm/gds minimum frequency: " << mn;
    log.flush();
    log << "gm/gds maximum frequency: " << mx;
    log.flush();

    for( NetworkParamSet::const_iterator i = yp.begin(); i != yp.end(); ++i ) {
        if( mn <= i->freq() && i->freq() <= mx ) {
            gm += abs( ( (*i)(1,0) - (*i)(0,1)) / ( (*i)(0,0) + (*i)(0,1) ) *
                std::complex<double>(0., 2.*M_PI*i->freq()*cgs) );
            gds += ( (*i)(1,1) + (*i)(0,1) ).real();
            ++c;
        }
    }

    if( c ) {
        gm /= (double) c;
        gds /= (double) c;
    }
    else throw GenericError( "extract_gm_and_gds(): no data available for gm/gds direct extraction." );

    // adjust for out of range values
    if( gm < 0. ) gm = 0.;
    if( gds < 0. ) gds = 0.;

    // set the values in the ModelParamSet
    //  and the optimization ranges
    parms["GM"].setValue(gm);
    if( gm < 0.2e-3*periph ) parms["GM"].setOptBoth(0.,0.5e-3*periph);
    else parms["GM"].setOptBoth(gm*0.75,gm*1.25);
    parms["GDS"].setValue(gds);
    gdsmax = gds * 1.5;
    if( gdsmax < 2.e-3 * periph ) gdsmax = 5.e-3 * periph;
    parms["GDS"].setOptBoth(gds*0.5,gdsmax);
}

/******************************************************************************************/
/******************************************************************************************/
static void extract_ri_and_tau( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms, double periph )
{
    double mn = opt.asDouble("ritau_min_freq") * 1.e9;
    double mx = opt.asDouble("ritau_max_freq") * 1.e9;
    int c = 0;
    double ri = 0.;
    double rgd = 0.;
    double tau = 0.;
    double tau2 = 0.;
    double w;
    double taumax, tau2max;
    EventLogStream log( MessageEvent );
    double gm = parms["GM"].value();
    double gds = parms["GDS"].value();
    bool extract_tau2 = opt.asBool( "extract_tau2" );

    log << "ri/tau minimum frequency: " << mn;
    log.flush();
    log << "ri/tau maximum frequency: " << mx;
    log.flush();

    for( NetworkParamSet::const_iterator i = yp.begin(); i != yp.end(); ++i ) {
        if( mn <= i->freq() && i->freq() <= mx ) {
            w = 2. * M_PI * i->freq();
            ri += (1. / ( (*i)(0,0) + (*i)(0,1) ) ).real();
            rgd += -( 1. / (*i)(0,1) ).real();
            tau += -1. / ( w * ( 1. / ( (*i)(0,0) + (*i)(0,1)) ).imag() );
            tau2 += -(*i)(0,1).imag();
            ++c;
        }
    }

    if( c ) {
        ri /= (double) c;
        rgd /= (double) c;
        tau /= (double) c;
        tau2 /= (double) c;
        //printf ("tau: %1.4e tau2: %1.4e ri: %1.4e rgd: %1.4e",  tau, tau2, ri, rgd);
    }
    else throw GenericError( "extract_ri_and_tau(): no data available for Ri/Rgd/Tau/Tau2 direct extraction." );

    // adjust for out of range values
    if( ri < 1.e-4 ) ri = 2.e-4;
    if( rgd < 1.e-4 ) rgd = 1.e-4;

    // adjust tau
    if( gm < 0.05e-3*periph ) {
        tau = 0.; taumax = 0.;
    }
    else {
        if( tau < 1.e-12 ) tau = 1.e-12;
        else if( tau > 2.e-11 ) tau = 2.e-11;
        taumax = 1.5 * tau;
        if( taumax < 5.e-12 ) taumax = 5.e-12;
    }

    if( gds < 0.01e-3*periph || !extract_tau2 ) {
        tau2 = 0.; tau2max = 0.;
    }
    else {
        if( tau2 < 1.e-12 ) tau2 = 1.e-12;
        else if( tau2 > 1.e-11 ) tau2 = 1.e-11;
        tau2max = 1.5 * tau2;
        if( tau2max < 5.e-12 ) tau2max = 5.e-12;
    }


    // set the values in the ModelParamSet
    //  and the optimization ranges
    parms["RI"].setValue(ri);
    parms["RI"].setOptBoth(ri*0.5,ri*2.5);
    parms["TAU1"].setValue(tau);
    parms["TAU1"].setOptBoth(0.,taumax);
    parms["TAU2"].setValue(tau2);
    parms["TAU2"].setOptBoth(0.,tau2max);
}


/******************************************************************************************/
/******************************************************************************************/
static void extract_ggs_and_ggd( const NetworkParamSet& yp, const OptionSet& opt, ModelParamSet& parms )
{
    double mn = opt.asDouble("ggsd_min_freq") * 1.e9;
    double mx = opt.asDouble("ggsd_max_freq") * 1.e9;
    int c = 0;
    double ggd = 0.;
    NetworkParamSet ggs_sp;
    EventLogStream log( MessageEvent );

    log << "ggs/ggd minimum frequency: " << mn;
    log.flush();
    log << "ggs/ggd maximum frequency: " << mx;
    log.flush();

    for( NetworkParamSet::const_iterator i = yp.begin(); i != yp.end(); ++i ) {
        if( mn <= i->freq() && i->freq() <= mx ) {
            ggd -= ((*i)(0,1)).real();
            ggs_sp.add( *i );
            ++c;
        }
    }

    if( c ) {
        ggd /= (double) c;
    }
    else throw GenericError( "extract_ggs_and_ggd(): no data available for ggs/ggd direct extraction." );

    // set ggd
    if( ggd < 0. ) ggd = 0.;
    parms["GDG"].setValue(ggd);
    parms["GDG"].setOptBoth(0.,ggd*10.);

    // extract ggs
    ggs_sp.convert_to_s();
    ggs_s11_fit( ggs_sp, parms );
}

/******************************************************************************************/
/******************************************************************************************/
static double ggs_s11_error( const NetworkParamSet& sp, const ModelParamSet& p, double ggs )
{
    typedef std::complex<double> C;
    double err = 0.;
    double smod11, smeas11;
    matrix::CMatrix y(2,2), s;
    matrix::CVector zref(2);
    double ggd = p["GDG"].value();
    double cgd = p["CDG"].value();
    double cgs = p["CGS"].value();
    double cds = p["CDS"].value();
    double ri = p["RI"].value();
    double tau = p["TAU1"].value();
    double tau2 = p["TAU2"].value();
    double gm = p["GM"].value();
    double gds = p["GDS"].value();
    double w;

    zref = C(50.);
    for( NetworkParamSet::const_iterator i = sp.begin(); i != sp.end(); ++i ) {
        w = 2. * M_PI * i->freq();
        y(0,1) = C( -ggd, -w * cgd );
        y(0,0) = 1. / (ri + 1. / C(ggs, w * cgs)) - y(0,1);
        y(1,1) = gds*std::exp(C(0.,-w*tau2)) + C(0.,w*cds) - y(0,1);
        y(1,0) = gm*std::exp(C(0.,-w*tau)) * (y(0,0) + y(0,1)) / C(ggs,w*cgs) + y(0,1);
        s = YtoS_(y, zref);

        smod11 = std::abs( s(0,0) );
        smeas11 = std::abs( (*i)(0,0) );

        if( smod11 < smeas11 ) return -1.;
        err += smod11 - smeas11;
   }

   return err;
}

/******************************************************************************************/
/******************************************************************************************/
static void ggs_s11_fit( const NetworkParamSet& sp, ModelParamSet& p )
{
    double last = 0.;
    double err;
    double inc = 1.e-6;
    double ggs = 0.;

    for( int i=0; i<5000; ++i ) {
        err = ggs_s11_error( sp, p, ggs );
        if( err < 0. || (i && err > last) ) {
            ggs -= inc;
            break;
        }
        last = err;
    }

    if( ggs < 0. ) ggs = 0.;
    p["GGS"].setValue(ggs);
    p["GGS"].setOptBoth(0.,ggs*5.);
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

#if 0   /*** remove this section for now ***/

static int plot_s2p_model( const Touchstone& sp, const OptionSet& opt, const ModelParamSet& parms )
{





   // determine if the model should be plotted
   if( opt.asBool("no_plots") ) return 0;


   // create a reduced data set




   // determine the plot device(s)
   //  and generate plots






    return 0;
}

/*******************************************************************************************/
static int create_s2p_model_plot( const Touchstone& sp, const ModelParamSet& p, int device, const std::string& fname, bool in_db )
{
    const char *legend_text1[] = {"Modeled Magnitude", "Modeled Phase", "Measured Magnitude", "Measured Phase"};
    const char *legend_text2[] = {"Modeled MAG/MSG", "Modeled K-Factor", "Measured MAG/MSG", "Measured K-Factor"};
    int legend_ltypes[] = {LT_SOLID, LT_DASHED, LT_SOLID, LT_DASHED};
    int legend_lwidths[] = {1, 1, 1, 1};
    int legend_colors[] = {CLR_RED, CLR_RED, CLR_DARKGREEN, CLR_DARKGREEN};
    jHANDLE legend1, header1, title1, header2;
    jPLOT_ITEM *plot1;

    std::istringstream is;
    std::ostringstream os;
    std::string head, head2, line;
    bool addline = true;


   // create the plot header information
    head.reserve(4096);
    is.str( sp.header() );
    while( !is.eof() ) {
        std::getline( is, line );
        if( line.length() ) {
            if( line.substr(0,8) == "!COMMENT" ) addline=false;
            else if( line.substr(0,5) == "!BIAS" ) {
                head += "\n";
                head += line.substr(1);
                break;
            }
            if( addline ) head += line.substr(1) + "\n";
        }
    }

    os << std::scientific << std::setprecision(3);
    os << "RG  = " << p["RG"].value();
    os << "RD  = " << p["RD"].value();
    os << "RS  = " << p["RS"].value();
    os << "C1  = " << p["C1"].value() << "\n";
    os << "LG  = " << p["B1"].value();
    os << "LD  = " << p["B2"].value();
    os << "LS  = " << p["LS"].value();
    os << "C2  = " << p["C2"].value() << "\n";
    os << "C11 = " << p["C11"].value();
    os << "C22 = " << p["C22"].value();
    os << "GGS = " << p["GGS"].value();
    os << "GGD = " << p["GDG"].value() << "\n";
    os << "CGS = " << p["CGS"].value();
    os << "CGD = " << p["CDG"].value();
    os << "CDS = " << p["CDS"].value();
    os << "RI  = " << p["RI"].value() << "\n";
    os << "GM  = " << p["GM"].value();
    os << "TAU = " << p["TAU1"].value();
    os << "GDS = " << p["GDS"].value();
    os << "TAU2= " << p["TAU2"].value() << "\n";

    head2 = os.str();

    header1 = add_text( head.c_str(), 1.0, 8.0, FNT_HELVETICA, 9, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE );
    header2 = add_text( head2.c_str(), 4.0, 8.0, FNT_COURIER, 10, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE );
    legend1 = add_legend( 4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors );

    // draw the plots
    if( !open_graphics_device(device, fname.c_str()) ) {




        return 1;
    }

    plot1 = create_plot_item( DoubleY, 1.5, 1.25, 5.0, 4.0 );
    set_axis_labels( plot1, "Frequency (GHz)", "Magnitude", "Phase", "" );

   // cycle through the different plots
   for( int i=0; i<6; ++i ) {
      switch(i) {
      case 0:  // S11







         title1 = add_text( "S11", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 1:  // S21





         title1 = add_text( "S21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 2:  // S12





         title1 = add_text( "S12", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 3:  // S22




         title1 = add_text( "S22", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 4:  // K and MAG




         set_axis_labels( plot1, "Frequency (GHz)", "MAG/MSG (dB)", "K-Factor", "" );
         remove_user_item( legend1 );
         legend1 = add_legend( 4, 8.0, 4.0, legend_text2, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors );
         title1 = add_text( "MAG/MSG\nand\nK-Factor", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;

      case 5:  // H21




         set_axis_labels( plot1, "Frequency (GHz)", "Magnitude (dB)", "Angle", "" );
         set_axis_scaling( plot1, LogX );
         remove_user_item( legend1 );
         legend1 = add_legend( 4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors );
         title1 = add_text( "H21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD );
         break;
      }

/*
      attach_y1data( plot1, freq, mod_mag, n_meas_f, LT_SOLID, 1, CLR_RED );
      attach_y2data( plot1, freq, mod_ang, n_meas_f, LT_DASHED, 1, CLR_RED );
      attach_y1data( plot1, freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN );
      attach_y2data( plot1, freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN );
*/

      if( !draw_page() ) {





         close_graphics_device();
         return 1;
      }

      detach_data( plot1 );
      remove_user_item( title1 );
   }

   close_graphics_device();
   return 0;
}


#endif  /*** end of removed section ***/


