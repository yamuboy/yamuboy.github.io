#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"
#include "optimize4.h"
#include "fit_tools.h"

/****** MACROS AND DEFINITIONS ******/

#define sqr(x)             ((x)*(x))

#define MAX_DCIV_PTS       1000
#define MAX_PIV_PTS        2000
#define MAX_DIODE_PTS      100
#define MAX_FWD_IGS        0.8      // in mA/mm
#define MAX_EXP_ARG        30.0
#define MIN_CURRENT        1.0e-7

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19
#define STDTEMP       300.0

#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_DOTTED
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN

#define PLOT_X         1.25
#define PLOT_Y         1.25
#define PLOT_XSIZE     6.0
#define PLOT_YSIZE     5.5

typedef struct
   {
   unsigned n;
   IV_DATA *data;
   } DCIV_OPT;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, unsigned max_size);
static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params);

static int logiv_erf (double *p, void *data, double *err, unsigned n_err);
static int liniv_erf (double *p, void *data, double *err, unsigned n_err);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);
static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

static double tom3_ids (double *p, double vgs, double vds, double *Gm, double *Gds);

#if(0)
static int fit_diode_curves (char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot, jPLOT_ITEM **vr_plot);
#endif
static int fit_dc_curves (char *dc_iv_file, MODEL_PARAMS *p, unsigned niter, int refit, jPLOT_ITEM **p1,
                          jPLOT_ITEM **p2, jPLOT_ITEM **p3);

static double safe_pow (double x, double y);
static void write_starting_files (char *input_file, char *param_file);
static void read_vmax_from_file (char *fname, double *vmax, double *vpo);

// global variable for warning messages
static char global_warning_message[5000];
static double global_ngf, global_ugw, global_tnom, global_per_mm;

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   char string[256];
   char start_file[100], end_file[100];
   char model_file[100], dc_iv_file[100];
   char header[3000];
   unsigned niter;
   int plot_dev = X_WINDOWS;
   int refit = 0;
   int i;
   MODEL_PARAMS *params;
   jPLOT_ITEM *p1 = NULL;
   jPLOT_ITEM *p2 = NULL;
   jPLOT_ITEM *p3 = NULL;

   global_warning_message[0] = 0;

   /**** parse the command line ****/

   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-i", 2) || !strncmp (argv[i], "-e", 2))
         {
         write_starting_files ("tom3in", "tom3.start");
         return 0;
         }
      else if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\n\n");

         printf ("TOM3 model fitter options:\n");
         printf ("------------------------------------------------------------------\n");
         printf ("  -i, -e    Auto-generate an input file named tom3in and a\n");
         printf ("              starting values file named tom3.start.\n");
         printf ("  -r        Re-fit mode.\n");

         printf ("\n\n");

         return 0;
         }
      else if (!strncmp (argv[i], "-d0", 3))
         plot_dev = 0;
      else if (!strncmp (argv[i], "-r", 2))
         refit = 1;
      }

   /**** get user input ****/

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &global_ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &global_ugw);

   global_per_mm = 1.0e3 / (global_ngf * global_ugw);

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &global_tnom);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   /**** get measurement and extraction data ****/

   if (read_model_parameters_from_file (start_file, &params, NULL))
      return 1;

   /**** perform various parameter fits ****/


   if (fit_dc_curves (dc_iv_file, params, niter, refit, &p1, &p2, &p3))
      return 1;


   printf ("Writing data files.\n");

   get_file_header (dc_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, params))
      return -1;

   /***** Generate plots *****/

   if (plot_dev)
      {
      jPLOT_ITEM *plot_list[11];
      char plot_head[1000];
      FILE *file;

      plot_head[0] = 0;

      // get the plot header

      file = fopen (dc_iv_file, "r");
      if (file)
         {
         while (fgets (string, 255, file))
            {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
            }

         fclose (file);
         }

      plot_list[0] = p1;
      plot_list[1] = p2;
      plot_list[2] = p3;

      if (plot_data (plot_dev, plot_head, plot_list, 3))
         return 1;
      }

   if (global_warning_message[0])
      {
      printf ("\n%s", global_warning_message);
      printf ("\nModel fitting completed with warnings.\n\n");
      }
   else
      printf ("\nModel fitting complete.\n\n");

   return 0;
   }
  
/*****************************************************************************/
/*****************************************************************************/
#if (0)

static int fit_diode_curves (char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot, jPLOT_ITEM **vr_plot)
   {
   IV_DATA fwd_curves[MAX_DIODE_PTS], vbr_curves[MAX_DIODE_PTS];
   unsigned n_fwd_pts, n_vbr_pts;
   double v[MAX_DIODE_PTS], i[MAX_DIODE_PTS];
   unsigned j, k;
   double m, b, r2;
   double *vf, *if_meas, *if_mod;
   double *vr, *ir_meas, *ir_mod;

   /***** Forward IV *****/
   
   printf ("Forward Diode IV.\n");
   
   if (get_iv_data (fwd_iv_file, fwd_curves, MAX_DIODE_PTS, &n_fwd_pts))
      return 1;

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
      {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 1.0e-8*fixed_p->area))
         {
         v[k] = fwd_curves[j].vgs;
         i[k] = log (fwd_curves[j].igs);
         ++k;
         }
      }

   if (k < 2)
      {
      fprintf (stderr, "Error: %s: not enough points.\n", fwd_iv_file);
      return 1;
      }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->is = 0.5 * exp (b);
   // do not scale ideality w.r.t. temperature because of an ADS bug
   // fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * (fixed_p->tnom + 273.15));
   fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * STDTEMP);

   // create a plot

   vf = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_meas = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_mod = (double *) malloc (sizeof(double)*n_fwd_pts);

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
      {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 0.0))
         {
         vf[k] = fwd_curves[j].vgs;
         if_meas[k] = fwd_curves[j].igs * 1.0e6 / fixed_p->area;
         if_mod[k] = 2.0 * fixed_p->is * (exp (vf[k] * Q_ELECTRON / (fixed_p->n * BOLTZMANN * STDTEMP)) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
         }
      }

   create_plot (vf_plot, vf, if_meas, if_mod, k, "Vgs (volts", "Igs (mA/mm)", "Diode Characteristic", LogY1);

   /***** Breakdown *****/

   printf ("Reverse Diode Breakdown.\n");
   
   if (get_iv_data (vbr_iv_file, vbr_curves, MAX_DIODE_PTS, &n_vbr_pts))
      return 1;

   for (j = 0, k = 0; j < n_vbr_pts; ++j)
      {
      if ((vbr_curves[j].igs < 0.0) && (vbr_curves[j].vds - vbr_curves[j].vgs > 0.5*(vbr_curves[n_vbr_pts-1].vds - vbr_curves[n_vbr_pts-1].vgs)))
         {
         v[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
         i[k] = log (-vbr_curves[j].igs);
         ++k;
         }
      }

   if (k < 2)
      {
      fprintf (stderr, "Error: %s: not enough points.\n", vbr_iv_file);
      return 1;
      }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->ibd = exp (b);
   fixed_p->vbd = 1.0 / m;

   // create a plot

   vr = (double *) malloc (sizeof(double)*n_vbr_pts);
   ir_meas = (double *) malloc (sizeof(double)*n_vbr_pts);
   ir_mod = (double *) malloc (sizeof(double)*n_vbr_pts);

   for (j = 0, k = 0; j < n_vbr_pts; ++j)
      {
      if (vbr_curves[j].igs < 0.0)
         {
         vr[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
         ir_meas[k] = -vbr_curves[j].igs * 1.0e6 / fixed_p->area;
         ir_mod[k] = fixed_p->ibd * (exp (vr[k] / fixed_p->vbd) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
         }
      }

   create_plot (vr_plot, vr, ir_meas, ir_mod, k, "Vdg (volts", "Idg (mA/mm)", "Diode Breakdown", LogY1);

   return 0;
   }

#endif

/*****************************************************************************/
/*****************************************************************************/

static int fit_dc_curves (char *dc_iv_file, MODEL_PARAMS *parms, unsigned niter, int refit,
                          jPLOT_ITEM **p1, jPLOT_ITEM **p2, jPLOT_ITEM **p3)
   {
   unsigned n_iv_pts, n_pts;
   DCIV_OPT iv_opt;
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   IV_DATA data[MAX_DCIV_PTS];
   unsigned i, j;
   OPTIMIZE *opt;
   OPT_PARAMETER p[10], p_alpha, p_k;
   OPT_PARAMETER t_alpha = {5.0, 5.0, 5.0, 0.0, "Alpha", 0};
   OPT_PARAMETER t_k = {3.0, 3.0, 3.0, 0.0, "K", 0}; 
   char *iv_params[] = {"vto", "alpha", "beta", "lambda", "gamma", "q", "k", "vst", "mst", "kgamma"};
   int plot_flag = 1;


   if (get_all_parameters (iv_params, 10, parms, p))
      return 1;

   if( !refit )
      {
      /* force Kgamma to zero */
      p[9].nom = p[9].min = p[9].max = 0.0;

      /* start Q at 2.0 */
      p[5].min = 1.5;
      p[5].nom = 2.0;
      p[5].max = 2.5;
      }

   if (get_iv_data (dc_iv_file, dciv_curves, MAX_DCIV_PTS, &n_iv_pts))
      return 1;

   /* initialize the optimization data */
   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, p, 9);
   set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);
   set_cg_error_fraction (opt, 1.0e-12, 5);
   for (i = 0; i <= 8; ++i)
      p[i].optimize = FALSE;

   /***** create/optimize the log domain data set ******/
   printf ("Log Domain.\n");

   for (i = 0, n_pts = 0; i < n_iv_pts; ++i)
      {
      if ((dciv_curves[i].vds < 1.0) || (dciv_curves[i].ids <= MIN_CURRENT))
         continue;

      data[n_pts] = dciv_curves[i];
      ++n_pts;
      }

   /* sort the data set */
   for (i = 0; i < n_pts-1; ++i)
      {
      for (j = i+1; j < n_pts; ++j)
         {
         if ((data[j].vds < data[i].vds) || ((data[j].vds == data[i].vds) && (data[j].vgs < data[i].vgs)))
            {
            IV_DATA tmp = data[i];
            data[i] = data[j];
            data[j] = tmp;
            }
         }
      }

   if( !refit )
      {
      /* set the value of VST */
      p[7].nom = log(data[1].ids/data[0].ids)*(data[1].vgs-data[0].vgs) / p[5].nom;
      p[7].min = 0.7*p[7].nom;
      p[7].max = 1.1*p[7].nom;
      }

   p[0].optimize = 1;
   p[2].optimize = 1;
   p[3].optimize = 1;
   p[4].optimize = 1;
   p[5].optimize = 1;
   p[7].optimize = 1;
   p[8].optimize = 1;

   p_alpha = p[1];
   p_k = p[6];
   p[1] = t_alpha;
   p[6] = t_k;

   set_cg_error_function (opt, logiv_erf, &iv_opt, 1, NULL);
   iv_opt.n = n_pts;
   iv_opt.data = data;

   if (cg_optimize4 (opt, niter, NULL))
      {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      return 1;
      }   
 
   if( plot_flag )
      {
      double *v = (double *) malloc (sizeof (double) * n_pts);
      double *imeas = (double *) malloc (sizeof (double) * n_pts);
      double *imod = (double *) malloc (sizeof (double) * n_pts);
      double pl[9];

      for (i = 0; i < 9; ++i)
         pl[i] = p[i].nom;

      for (i = 0; i < n_pts; ++i)
         {
         v[i] = data[i].vgs;
         imeas[i] = data[i].ids * 1.0e3 * global_per_mm;
         imod[i] = tom3_ids (pl, data[i].vgs, data[i].vds, NULL, NULL) * 1.0e3 * global_per_mm;
         }

      create_plot (p1, v, imeas, imod, n_pts, "Vgs (volts)", "Ids (mA/mm)", "Log Domain Current", LogY1);
      }

   /**** optimize the same dataset in the linear domain ****/
   printf ("Linear Domain.\n");

   /* sort the data set */
   for (i = 0; i < n_pts-1; ++i)
      {
      for (j = i+1; j < n_pts; ++j)
         {
         if ((data[j].vgs < data[i].vgs) || ((data[j].vgs == data[i].vgs) && (data[j].vds < data[i].vds)))
            {
            IV_DATA tmp = data[i];
            data[i] = data[j];
            data[j] = tmp;
            }
         }
      }

   p[0].optimize = 0;
   p[7].optimize = 0;
   p[8].optimize = 0;

   set_cg_error_function (opt, liniv_erf, &iv_opt, 1, NULL);

   if (cg_optimize4 (opt, niter, NULL))
      {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      return 1;
      }

   if( plot_flag )
      {
      double *v = (double *) malloc (sizeof (double) * n_pts);
      double *imeas = (double *) malloc (sizeof (double) * n_pts);
      double *imod = (double *) malloc (sizeof (double) * n_pts);
      double pl[9];

      for (i = 0; i < 9; ++i)
         pl[i] = p[i].nom;

      for (i = 0; i < n_pts; ++i)
         {
         v[i] = data[i].vds;
         imeas[i] = data[i].ids * 1.0e3 * global_per_mm;
         imod[i] = tom3_ids (pl, data[i].vgs, data[i].vds, NULL, NULL) * 1.0e3 * global_per_mm;
         }

      create_plot (p2, v, imeas, imod, n_pts, "Vds (volts)", "Ids (mA/mm)", "Linear Domain Current", 0);
      }

   /**** optimize the total dataset to fit the knee region ****/
   printf ("Linear Domain.\n");

   for (i = 0, n_pts = 0; i < n_iv_pts; ++i)
      {
      data[n_pts] = dciv_curves[i];
      ++n_pts;
      }

   p[1] = p_alpha;
   p[6] = p_k;

   p[1].optimize = 1;
   p[3].optimize = 0;
   p[4].optimize = 0;
   p[5].optimize = 0;
   p[6].optimize = 1;

   set_cg_error_function (opt, liniv_erf, &iv_opt, 1, NULL);
   iv_opt.n = n_pts;

   if (cg_optimize4 (opt, niter, NULL))
      {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      return 1;
      }

   if( plot_flag )
      {
      double *v = (double *) malloc (sizeof (double) * n_pts);
      double *imeas = (double *) malloc (sizeof (double) * n_pts);
      double *imod = (double *) malloc (sizeof (double) * n_pts);
      double pl[9];

      for (i = 0; i < 9; ++i)
         pl[i] = p[i].nom;

      for (i = 0; i < n_pts; ++i)
         {
         v[i] = data[i].vds;
         imeas[i] = data[i].ids * 1.0e3 * global_per_mm;
         imod[i] = tom3_ids (pl, data[i].vgs, data[i].vds, NULL, NULL) * 1.0e3 * global_per_mm;
         }

      create_plot (p3, v, imeas, imod, n_pts, "Vds (volts)", "Ids (mA/mm)", "I-V Curves", 0);
      }

   if (set_all_parameters (parms, p, 10))
      return 1;

   free ((void *) opt);

   return 0;
   }


/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

static double tom3_ids (double *p, double vgs, double vds, double *Gm, double *Gds)
   {
   double vto    = p[0];
   double alpha  = p[1];
   double beta   = p[2];
   double lambda = p[3];
   double gamma  = p[4];
   double q      = p[5];
   double k      = p[6];
   double vst    = p[7];
   double mst    = p[8];
   double Vst,u,Vg,fk,I0,Ids;
   double dVst_vds, du_vds, du_vgs, dVg_vds, dVg_vgs;
   double dfk_vds, dI0_vds, dI0_vgs;
   int flag = 0;

   if (vds < 0.0)
      {
      vgs = vgs - vds;
      vds = -vds;
      flag = 1;
      }

   Vst = vst * (1.0 + mst*vds);
   dVst_vds = vst * mst;

   u = (vgs - vto + gamma*vds) / (q*Vst);
   du_vgs = 1.0 / (q*Vst);
   du_vds = (q*Vst*gamma - (vgs - vto + gamma*vds)*q*dVst_vds) / sqr(q*Vst);

   if (u > MAX_EXP_ARG)
      {
      Vg = q * Vst * u;
      dVg_vgs = q * Vst * du_vgs;
      dVg_vds = q * (Vst * du_vds + u * dVst_vds);
      }
   else
      {
      Vg = q * Vst * log (1.0 + exp (u));
      dVg_vgs = q * Vst / (1.0 + exp(u)) * exp(u) * du_vgs;
      dVg_vds = q * (Vst/(1.0 + exp(u))*exp(u)*du_vds + log (1.0 + exp(u))*dVst_vds);
      }

   fk = (alpha*vds) / safe_pow (1.0 + pow (alpha*vds, k), 1.0/k);
   dfk_vds = alpha * (pow (1.0 + pow (alpha*vds, k), 1.0/k) - vds * pow (1.0 + pow (alpha*vds, k), 1.0/k - 1.0) * pow (alpha*vds, k-1.0) * alpha) / pow (1.0 + pow (alpha*vds, k), 2.0/k);
   
   I0 = beta * pow (Vg, q) * fk;
   dI0_vds = beta * (safe_pow (Vg, q) * dfk_vds + fk * q * safe_pow (Vg, q - 1.0) * dVg_vds);
   dI0_vgs = beta * fk * q * safe_pow (Vg, q-1.0) * dVg_vgs;

   Ids = I0 * (1.0 + lambda*vds);

   if (Gds)
      *Gds = I0 * lambda + (1.0 + lambda*vds) * dI0_vds;
   if (Gm)
      *Gm = dI0_vgs * (1.0 + lambda*vds);

   if (flag)
      return -Ids;

   return Ids;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int logiv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   for (i = 0; i < d->n; ++i)
      {
      diff = log10(d->data[i].ids) - log10(tom3_ids (p, d->data[i].vgs, d->data[i].vds, NULL, NULL) + 1.0e-18);
      err[0] += diff * diff;
      }

   err[0] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int liniv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   for (i = 0; i < d->n; ++i)
      {
      diff = d->data[i].ids - tom3_ids (p, d->data[i].vgs, d->data[i].vds, NULL, NULL);
      err[0] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static void get_file_header (char *data_file, char *header, unsigned max_size)
   {
   FILE *file = fopen (data_file,"r");
   unsigned index = 0, len;
   char string[300];

   if (!header || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
      {
      if (string[0] != '!')
         {
         string[0] = 0;
         break;
         }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         if ((index + len) < max_size)
            {
            strcat (header, string);
            index += len;
            }
         else
            break;

         fgets (string,299,file);
         break;
         }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else
         break;
      }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if ((len > 0) && (index < max_size))
      {
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else if ((max_size - index) == 1);
      else
         {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
         }
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params)
   {
   FILE *file;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   MODEL_PARAMS *p;
   
   /* write final optimization parameter values */

   if (write_model_parameters_to_file (params, end_file))
      return 1;

   /* write the model parameter file */

   // non-optimized parameters
   names[num_p] = "Ugw"; values[num_p] = global_ugw; ++num_p;
   names[num_p] = "Ngf"; values[num_p] = global_ngf; ++num_p;
   names[num_p] = "Tnom"; values[num_p] = global_tnom; ++num_p;

   for (p = params; p; p = p->next)
      {
      names[num_p] = p->name;
      values[num_p] = p->nom;
      ++num_p;
      }

   file = fopen (model_file,"w+");
   if (!file)
      {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", model_file);
      return -1;
      }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");

   write_model_param_mdif (file, names, values, num_p, 12, 5);
   
   fclose (file);
      
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
   {
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);
      
   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
   }

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
   {
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile;
   jHANDLE legend, header;
   unsigned i;
      
   switch (dev)
      {
      case POSTSCRIPT:
         plotfile = "tom3iv.ps";
         break;
      
      case METAFILE:
         plotfile = "tom3iv.wmf";
         break;
      
      case X_WINDOWS:
         plotfile = NULL;
         break;

      default:
         return 0;
      }
   
   if (!open_graphics_device (dev, plotfile))
      {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
      }
   
   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
      {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
      }

   // draw all plots
   for (i = 0; i < n; ++i)
      {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
         {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
         }

      plot_list[i]->active = FALSE;
      }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
      {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
      }
   else
      close_graphics_device ();
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static double safe_pow (double x, double y)
   {
   if ((x == 0.0) && (y < 0.0))
      return 1.e100;

   return pow (x, y);
   }

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files (char *input_file, char *param_file)
   {
   FILE *file;
   OPT_PARAMETER p[] = {
      { -2.5, -0.5, 0.4, 0.0, "Vto", 0},
      { 0.0, 8.0, 30.0, 0.0, "Alpha", 0},
      { 0.0, 0.15, 0.8, 0.0, "Beta", 0},
      { 0.0, 0.001, 0.4, 0.0, "Lambda", 0},
      { 0.0, 0.01, 0.2, 0.0, "Gamma", 0},
      { 0.2, 0.5, 2.0, 0.0, "Q", 0},
      { 1.5, 2.0, 5.0, 0.0, "K", 0},
      { 1.0e-5, 0.15, 0.6, 0.0, "Vst", 0},
      { 0.0, 0.1, 0.5, 0.0, "Mst", 0},
      { 0.0, 0.0, 0.0, 0.0, "Kgamma", 0}
      };

   if (input_file)
      {
      file = fopen (input_file, "w+");
      if (!file)
         {
         printf ("Error: %s: unable to write to disc.\n", input_file);
         return;
         }

      fprintf (file, "6                   # number of gate fingers\n");
      fprintf (file, "50                  # unit gate width (microns)\n");
      fprintf (file, "27                  # measurement temperature\n");
      fprintf (file, "sdc.iv              # DC I-V file name\n");
      fprintf (file, "tom3iv.start        # model parameter starting values file name\n");
      fprintf (file, "tom3iv.end          # model parameter finishing values file name (output)\n");
      fprintf (file, "tom3iv.model        # model file name (output)\n");
      fprintf (file, "250                 # maximum optimization line search iterations\n");

      fclose (file);
      }

   if (param_file)
      {
      unsigned i;

      file = fopen (param_file, "w+");
      if (!file)
         {
         printf ("Error: %s: unable to write to disc.\n", param_file);
         return;
         }

      fprintf (file, "! auto-generated file\n");
      for (i = 0; i < 10; ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);

      fclose (file);
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static void read_vmax_from_file (char *fname, double *vmax, double *vpo)
   {
   FILE *file;
   char string[256];

   *vmax = 1.0;
   *vpo = -1.0;

   file = fopen (fname, "r");
   if (!file)
      return;

   while (fgets (string, 255, file))
      {
      if (string[0] != '!')
         break;

      if (!strncmp (string, "!Vbr", 4))
         {
         if (fgets (string, 255, file))
            sscanf (string, "!%*f%*f%*f%*f%*f%*f%lf%lf", vmax, vpo);
         break;
         }
      }

   fclose (file);
   }




