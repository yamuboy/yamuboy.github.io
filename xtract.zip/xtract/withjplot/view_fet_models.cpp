#include <iostream>
#include <sstream>
#include "jplot.h"
#include "modelparam.hpp"
#include "fet_ss_model.hpp"
#include "touchstone.hpp"

#define MAX_PTS   500

std::string get_bias_line( const std::string& header );

void print_usage( char * progname )
{
   printf( "\nUSAGE: %s [options] file1 [file2 ...]\n\n", progname );
   printf( "  file1 [file2 ...] are the measured S2P files.\n\n" );
   printf( "  Options:\n" );
   printf( "     -wmf, -meta   Set output device to metafile.\n" );
   printf( "     -ps           Set output device to postscript.\n" );
   printf( "     -o name       Set plot file name to \'name\'.\n" );
   printf( "     -db           Plot in dB.\n" );
   printf( "     -np           Disable plotting of phase on the Y2 axis.\n" );
   printf( "     -ext=xx       Set the extension for model parameter files (default = \'.end\').\n" );

   printf( "\n" );
}

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
{
   jPLOT_ITEM *s11p,*s12p,*s21p,*s22p;
   jPLOT_ATTRIBS attribs1;
   jHANDLE legend1,bias_line;

   double measfreq[MAX_PTS];
   double mod11m[MAX_PTS],mod11a[MAX_PTS];
   double mod12m[MAX_PTS],mod12a[MAX_PTS];
   double mod21m[MAX_PTS],mod21a[MAX_PTS];
   double mod22m[MAX_PTS],mod22a[MAX_PTS];
   double meas11m[MAX_PTS],meas11a[MAX_PTS];
   double meas12m[MAX_PTS],meas12a[MAX_PTS];
   double meas21m[MAX_PTS],meas21a[MAX_PTS];
   double meas22m[MAX_PTS],meas22a[MAX_PTS];
   int pts;

   static const char *legend_t[] = {"Modeled Magnitude","Measured Magnitude","Modeled Phase","Measured Phase"};
   static int  legend_l[] = {LT_SOLID,LT_DASHED,LT_SOLID,LT_DASHED};
   static int  legend_w[] = {1,1,1,1};
   static int  legend_c[] = {CLR_RED,CLR_BLUE,CLR_ORANGE,CLR_GREEN};
   int pdevice = X_WINDOWS;
   int db_mode=0;

   Touchstone ts, tsmod;
   size_t pos;
   std::string arg, pf, bias, dbg;
   std::string pname = "fetmodels.ps";
   std::string extension = ".end";
   std::list< std::string > file_list;
   FET_SS_Model model;
   matrix::CMatrix mod;
   ModelParamSet params;
   bool ypars = false;

   if( argc < 2 ) {
      print_usage(argv[0]);
      return 0;
   }

   // parse the command line
   for( int i=1; i<argc; ++i )
   {
       arg = argv[i];
       if( arg[0] == '-' ) {
         if( arg == "-ps" || arg == "-dP" ) pdevice = POSTSCRIPT;
         else if( arg == "-meta" || arg == "-wmf" || arg == "-dM" ) pdevice = METAFILE;
         else if( arg == "-db" || arg == "-dB" ) db_mode=1;
         else if( arg == "-o" ) {
            if( i == argc-1 ) {
               std::cerr << "Error: missing parameter for -o option." << std::endl;
               print_usage( argv[0] );
               return -1;
            }
            pname = argv[++i];
         }
         else if( arg.substr(0,6) == "--ext=" ) {
            extension = arg.substr(6);
         }
         else if( arg.substr(0,5) == "-ext=" ) {
            extension = arg.substr(5);
         }
         else if( arg == "-y" ) {
            ypars = true;
         }
         else {
            std::cerr << "Error: invalid option: %s" << std::endl;
            print_usage( argv[0] );
            return -1;
         }
      }
      else file_list.push_back( arg );
   }

   if( file_list.empty() ) {
      std::cerr <<  "Error: no files to plot." << std::endl;
      print_usage( argv[0] );
      return -1;
   }

   if( !open_graphics_device( pdevice, pname.c_str() ) ) {
      std::cerr << "Failed to open the graphics device." << std::endl;
      return -1;
   }

   s11p = create_plot_item(DoubleY,1.25,4.70,3.0,2.5);
   s12p = create_plot_item(DoubleY,6.75,4.70,3.0,2.5);
   s21p = create_plot_item(DoubleY,1.25,1.00,3.0,2.5);
   s22p = create_plot_item(DoubleY,6.75,1.00,3.0,2.5);

   if( db_mode ) {
      set_axis_labels(s11p,"Frequency (GHz)","dB(S11)","phase(S11)","S11");
      set_axis_labels(s12p,"Frequency (GHz)","dB(S12)","phase(S12)","S12");
      set_axis_labels(s21p,"Frequency (GHz)","dB(S21)","phase(S21)","S21");
      set_axis_labels(s22p,"Frequency (GHz)","dB(S22)","phase(S22)","S22");
   }
   else {
      set_axis_labels(s11p,"Frequency (GHz)","mag(S11)","phase(S11)","S11");
      set_axis_labels(s12p,"Frequency (GHz)","mag(S12)","phase(S12)","S12");
      set_axis_labels(s21p,"Frequency (GHz)","mag(S21)","phase(S21)","S21");
      set_axis_labels(s22p,"Frequency (GHz)","mag(S22)","phase(S22)","S22");
   }

   attribs1.xlabel_offset = 0.3;
   attribs1.ylabel_offset = 0.55;
   attribs1.title_offset  = 0.3;

   set_plot_item_attributes (s11p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s12p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s21p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s22p,&attribs1,JPA_LABELOFFSETS);

   legend1 = add_legend (4,4.55,8.1,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);

   for( std::list<std::string>::iterator f = file_list.begin(); f != file_list.end(); ++f )
   {
       tsmod.clear();
        try {
            pf = *f;
            pos = pf.find_last_of( ".\\/" );
            if( pos != std::string::npos ) {
                if( pf[pos] == '.' ) {
                    pf = pf.substr(0,pos) + extension;
                    dbg = pf.substr(0,pos) + ".dbg";
                }
                else {
                    dbg = pf + ".dbg";
                    pf += extension;
                }
            }

            if( !params.read_end_file( pf, ModelParamSet::upper_case ) ) {
                std::cerr << "Warning: parameter file \'" << pf << "\' not readable." << std::endl;
                continue;
            }
            ts.read( *f );
            model.reset();
            model.bindParams( params );

            if( !ts.size() ) {
                std::cerr << "Warning: no data in file: " << *f << std::endl;
                continue;
            }
            else if( ts.ports() != 2 ) {
                std::cerr << "Warning: not an S2P file: " << *f << std::endl;
                continue;
            }

            if( ypars ) ts.convert_to_y();

            pts = 0;
            for( Touchstone::iterator i = ts.begin(); i != ts.end(); ++i, ++pts ) {
                if( pts >= MAX_PTS ) break;
                measfreq[pts] = i->freq() * 1.e-9;
                meas11m[pts] = db_mode ? 20. * std::log10( std::abs( (*i)(0,0) ) ) : std::abs( (*i)(0,0) );
                meas12m[pts] = db_mode ? 20. * std::log10( std::abs( (*i)(0,1) ) ) : std::abs( (*i)(0,1) );
                meas21m[pts] = db_mode ? 20. * std::log10( std::abs( (*i)(1,0) ) ) : std::abs( (*i)(1,0) );
                meas22m[pts] = db_mode ? 20. * std::log10( std::abs( (*i)(1,1) ) ) : std::abs( (*i)(1,1) );
                meas11a[pts] = std::arg( (*i)(0,0) ) * 180. / M_PI;
                meas12a[pts] = std::arg( (*i)(0,1) ) * 180. / M_PI;
                meas21a[pts] = std::arg( (*i)(1,0) ) * 180. / M_PI;
                meas22a[pts] = std::arg( (*i)(1,1) ) * 180. / M_PI;

                mod = ypars ? model.compute_y( i->freq() ) : model.compute_s( i->freq() );
                // tsmod.add( i->freq(), mod );

                mod11m[pts] = db_mode ? 20. * std::log10( std::abs( mod(0,0) ) ) : std::abs( mod(0,0) );
                mod12m[pts] = db_mode ? 20. * std::log10( std::abs( mod(0,1) ) ) : std::abs( mod(0,1) );
                mod21m[pts] = db_mode ? 20. * std::log10( std::abs( mod(1,0) ) ) : std::abs( mod(1,0) );
                mod22m[pts] = db_mode ? 20. * std::log10( std::abs( mod(1,1) ) ) : std::abs( mod(1,1) );
                mod11a[pts] = std::arg( mod(0,0) ) * 180. / M_PI;
                mod12a[pts] = std::arg( mod(0,1) ) * 180. / M_PI;
                mod21a[pts] = std::arg( mod(1,0) ) * 180. / M_PI;
                mod22a[pts] = std::arg( mod(1,1) ) * 180. / M_PI;
            }

            // tsmod.write( dbg );
        }
        catch( TouchstoneError& e ) {
            std::cerr << "Warning: " << e.what() << std::endl;
            continue;
        }
        catch( ModelParamException& e ) {
            std::cerr << "Warning: " << e.what() << std::endl;
            continue;
        }
        catch( std::exception& e ) {
            std::cerr << "Error: " << e.what() << std::endl;
            return -1;
        }

        bias = get_bias_line( ts.header() );
        bias_line = add_text( bias.c_str(),4.8,4.45,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);

      attach_y1data (s11p,measfreq,mod11m,pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s11p,measfreq,meas11m,pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s11p,measfreq,mod11a,pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s11p,measfreq,meas11a,pts,LT_DASHED,1,CLR_GREEN);

      attach_y1data (s12p,measfreq,mod12m,pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s12p,measfreq,meas12m,pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s12p,measfreq,mod12a,pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s12p,measfreq,meas12a,pts,LT_DASHED,1,CLR_GREEN);

      attach_y1data (s21p,measfreq,mod21m,pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s21p,measfreq,meas21m,pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s21p,measfreq,mod21a,pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s21p,measfreq,meas21a,pts,LT_DASHED,1,CLR_GREEN);

      attach_y1data (s22p,measfreq,mod22m,pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s22p,measfreq,meas22m,pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s22p,measfreq,mod22a,pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s22p,measfreq,meas22a,pts,LT_DASHED,1,CLR_GREEN);

      draw_page();

      detach_data(s11p);
      detach_data(s12p);
      detach_data(s21p);
      detach_data(s22p);
      remove_user_item(bias_line);

   }

   close_graphics_device();

   return 0;
}

/***********************************************************************************/
std::string get_bias_line( const std::string& header )
{
    std::istringstream ss( header );
    std::string ret = "Bias information\nnot found.";
    std::string line, tmp;
    double vds, vgs, igs, ids;

    while( !ss.eof() ) {
        std::getline( ss, line );
        if( line.substr(0,6) == "!BIAS:" ) {
            std::ostringstream os;
            ss.clear();
            ss.str( line );
            ss >> tmp >> tmp >> tmp >> vds;
            ss >> tmp >> tmp >> tmp >> ids;
            ss >> tmp >> tmp >> tmp >> vgs;
            ss >> tmp >> tmp >> tmp >> igs;
            os << "Vds = " << vds << "\nVgs = " << vgs << "\nIds = ";
            os << (ids * 1000.) << "\nIgs = " << (igs * 1000.) << "\n";
            ret = os.str();
            break;
        }
    }

    return ret;
}
