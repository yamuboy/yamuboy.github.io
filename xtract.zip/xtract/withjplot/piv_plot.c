#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jplot.h>
#include <math.h>

#define MAX_FILES  5

static int ltype[] = {0,0,0,0,0};
static int lwidth[] = {2,2,2,2,2};
static int lcolor[] = {CLR_RED,CLR_BLUE,CLR_GREEN,CLR_PURPLE,CLR_LIGHTBLUE};
static int ptype[] = {PNT_PLUS,PNT_SQUARE,PNT_CIRCLE,PNT_X,PNT_TRIANGLE};
static int pwidth[] = {2,2,2,2,2};
static int pcolor[] = {CLR_BLACK,CLR_BLACK,CLR_BLACK,CLR_BLACK,CLR_BLACK};

void usage(char *progname)
{
      printf ("\nUSAGE:   %s [options] file1 [file2 ...]\n\n", progname);
      printf ("    options\n    ---------------\n");
      printf ("      -dW     set the graphics device to Win32 GDI (default)\n");
      printf ("      -dM     set the graphics device to Metafile output\n");
      printf ("      -dP     set the graphics device to Postscript output\n");
      printf ("      -pNAME  set the plot file name to NAME, default is \"plot.ps\"\n\n");
}

int main(int argc, char *argv[])
   {
   char string[200];
   char ltext1[MAX_FILES][256];
   char ltext2[MAX_FILES][256];
   const char *pltext1[MAX_FILES];
   const char *pltext2[MAX_FILES];
   char *fname[MAX_FILES];
   double t1, ofs;
   double *vds[MAX_FILES];
   double *ids[MAX_FILES];
   double vdsq[MAX_FILES];
   double idsq[MAX_FILES];
   double tp[MAX_FILES];
   double tq[MAX_FILES];
   int npts[MAX_FILES];
   int i,j,nofs,filecount = 0;
   int validfiles = 0;
   int gdevice = 1;
   int adjustdata = 0;
   char gfile[80];
   FILE *file;
   jPLOT_ITEM *plot1;

   strcpy (gfile,"plot.ps");

   /* parse the command line */
   for (i = 1; i < argc; ++i)
      {
      if (argv[i][0] == '-')
         {
         if (!strcmp (argv[i],"-dW"))
            gdevice = 1;
         else if (!strcmp (argv[i],"-dM"))
            gdevice = 2;
         else if (!strcmp (argv[i],"-dP"))
            gdevice = 3;
         else if (!strcmp (argv[i],"-a"))
            adjustdata = 1;
         else if (!strncmp (argv[i],"-p",2))
            sscanf (argv[i],"-p%79s",gfile);
         else {
            fprintf(stderr, "error: unrecognized option \"%s\"\n",argv[i]);
            return 1;
	    }
         }
      else
         {
         if (filecount >= MAX_FILES)
            {
            fprintf (stderr, "error: MAX_FILES exceeded.\n");
            return 1;
            }
	 fname[filecount] = argv[i];
	 ++filecount;
         }
      }

   if( filecount < 1 )
      {
      usage(argv[0]);
      return 0;
      }

   /* read data from the data files */

   for (i = 0; i < filecount; ++i)
      {
      file = fopen (fname[i],"r");
      if (!file)
         {
         fprintf (stderr, "error: file not found - \"%s\"\n",fname[i]);
         return 2;
         }

      // parse the header
      for (j = 1; j < 8; ++j)
         {
         if (!fgets (string,199,file))
            {
            printf ("warning: incomplete data file - \"%s\"\n",fname[i]);
            fclose (file);
            npts[i] = 0;
            break;
            }
         else if (j == 4)
            sscanf (string,"\\t_q= %lf, t_p= %lf",&tq[i],&tp[i]);
         else if (j == 5)
            sscanf (string,"\\Qpt: %lf %lf %lf %lf",&t1,&vdsq[i],&idsq[i],&t1);
         else if (j == 7)
            sscanf (string,"\\%d lines",&npts[i]);
         }

      idsq[i] *= 1000.0;

      if(npts[i] < 1) {
         vds[i] = NULL;
	 ids[i] = NULL;
         continue;
	 }

      // allocate memory
      vds[i] = (double *) malloc (sizeof(double)*npts[i]);
      ids[i] = (double *) malloc (sizeof(double)*npts[i]);

      // read in the data
      j = 0;
      while (fgets (string,199,file))
         {
         if (sscanf (string,"%lf%lf%lf%lf",&t1,&vds[i][j],
            &ids[i][j],&t1) == 4)
            {
            ids[i][j] *= 1000.0;
            ++j;
            }
         }

      fclose (file);
      }

   /* adjust the data */

   if( adjustdata ) {
      for (i = 0; i < filecount; ++i) {
          if(npts[i]) {
	     // figure out the 0 offset
   	     ofs = 0.0;
	     nofs = 0;
	     for( j=0; j<npts[i]; ++j ) {
                if( fabs(vds[i][j]) < 0.01 ) {
		   ofs += ids[i][j];
		   ++nofs;
		   }
	     }
	     if( nofs > 1 )
	        ofs /= (double) nofs;

	     // apply the 0 offset to the data
	     for( j=0; j<npts[i]; ++j ) {
	        ids[i][j] -= ofs;
	     }
	  }
      }
   }

   /* plot the data */

   if (!open_graphics_device (gdevice,gfile))
      {
      fprintf (stderr,"error: failed to open the graphics device.\n");
      for (i = 0; i < filecount; ++i)
         {
         free ((void *) vds[i]);
         free ((void *) ids[i]);
         }
      return -1;
      }

   plot1 = create_plot_item (SingleY,2.25,1.25,6.5,5.25);
   plot1->attribs.label_font = FNT_HELVETICA;
   plot1->attribs.title_font = FNT_HELVETICA;
   plot1->attribs.axis_font = FNT_HELVETICA;
   plot1->attribs.label_tsize = 16;
   plot1->attribs.title_tsize = 16;
   plot1->attribs.axis_tsize = 14;

   for (i = 0; i < filecount; ++i)
      {
      if( npts[i] > 0 ) {
         attach_y1data (plot1,vds[i],ids[i],npts[i],ltype[i],lwidth[i],lcolor[i]);
         attach_y1data (plot1,&vdsq[i],&idsq[i],1,ptype[i],pwidth[i],pcolor[i]);

         sprintf (ltext1[i],"%s : Tp = %.2e sec, Tq = %.2e sec",fname[i],tp[i],tq[i]);
         sprintf (ltext2[i],"Vds_q = %.2f V, Ids_q = %.1f mA",vdsq[i],idsq[i]);
         pltext1[validfiles] = ltext1[i];
         pltext2[validfiles] = ltext2[i];
	 ++validfiles;
	 }
      }

   set_axis_labels (plot1,"Pulsed Drain Voltage (volts)","Pulsed Drain Current (mA)",
      NULL,"Pulsed-IV Characteristic");
   
   set_axis_scaling (plot1,POSITIVE_X | POSITIVE_Y1);

   add_legend (validfiles,0.6,8.2,pltext1,FNT_HELVETICA,14,ltype,lwidth,lcolor);
   add_legend (validfiles,6.75,8.2,pltext2,FNT_HELVETICA,14,ptype,pwidth,pcolor);

   draw_page ();

   close_graphics_device ();

   for (i = 0; i < filecount; ++i)
      {
      free ((void *) vds[i]);
      free ((void *) ids[i]);
      }

   return 0;
   }



