#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"
#include "optimize4.h"
#include "fit_tools.h"

/****** MACROS AND DEFINITIONS ******/

#define sqr(x)             ((x)*(x))

#define MAX_DCIV_PTS       (1000)

#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    PNT_CIRCLE
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN

#define PLOT_X           (1.25)
#define PLOT_Y           (1.25)
#define PLOT_XSIZE       (6.0)
#define PLOT_YSIZE       (5.5)
#define SZ_PLOT_LIST     (5)

typedef struct
{
   unsigned n;
   IV_DATA *dcdata;
   double maxv;
} DCIV_OPT;

/* -------- FUNCTION PROTOTYPES ---------- */


static double tom_ids( double *p, double vgs, double vds );

static int dciv_erf (double *p, void *data, double *err, unsigned n_err);

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);

static int fit_dc_curves( char *dc_iv_file, MODEL_PARAMS *parms, unsigned niter, int plotting_on, jPLOT_ITEM **dciv_plot, int swap_order, double max_vds );

static void write_starting_files();

void change_extension( const char * fname, const char * ext, char * new_fname );


/**********************************************************************************/
/*                                   MAIN                                         */
/**********************************************************************************/

int main( int argc, char **argv )
{
   char string[256];
   char dc_iv_file[100], param_file[100], backup_file[120];
   unsigned niter;
   jPLOT_ITEM *plot_list[SZ_PLOT_LIST];
   int plot_dev = X_WINDOWS;
   int i;
   MODEL_PARAMS *params;
   int swap_order=0;
   double max_vds;

   // initialize the plot list
   for( i=0; i<SZ_PLOT_LIST; ++i )
      plot_list[i] = NULL;

   /**** parse the command line ****/

   for( i=1; i<argc; ++i )
   {
      if( !strncmp(argv[i], "-c", 2) )
      {
         write_starting_files ();
         return 0;
      }
      else if( !strncmp (argv[i], "-h", 2) )
      {
         printf ("\n\n");

         printf( "USAGE: %s [options]\n", argv[0] );
         printf( "------------------------------------------------------------------\n" );
         printf( "Options:\n\n" );
         printf( "  -c        Auto-generate a parameter file\n" );
         printf( "  -d0       Disable plotting\n" );
         printf( "  -swap     Swap I-V file order.\n" );
         printf( "              Normal order is:  Vds Ids Vgs Igs\n" );
         printf( "              Swapped order is: Vgs Igs Vds Ids\n" );
         printf ("\n\n");

         return 0;
      }
      else if( !strncmp(argv[i], "-d0", 3) )
         plot_dev = 0;
      else if( !strncmp(argv[i], "-swap", 5) )
         swap_order=1;
      else
      {
         fprintf( stderr, "Error: unrecognized command-line parameter: \'%s\'\n", argv[i] );
         fprintf( stderr, "  type \'%s -h\' for a list of command-line switches.\n", argv[0] );
         return 1;
      }
   }

   /**** get user input ****/

   printf( "DC IV data file name?\n" );
   fgets(string,255,stdin);
   sscanf(string,"%99s",dc_iv_file);

   printf( "Parameter file name?\n" );
   fgets(string,255,stdin);
   sscanf(string,"%99s",param_file);

   printf( "Maximum number of line searches?\n" );
   fgets(string,255,stdin);
   sscanf(string,"%d",&niter);

   printf( "Maximum Vds?\n" );
   fgets(string,255,stdin);
   sscanf(string,"%lf",&max_vds);

   // get parameter starting valueS
   if( read_model_parameters_from_file( param_file, &params, NULL ) )
      return 1;

   // create the backup file name
   change_extension( param_file, ".old", backup_file );

   // save a backup copy of the parameter values
   if( write_model_parameters_to_file( params, backup_file ) )
      return 1;

   // perform I-V curve fitting
   if( fit_dc_curves( dc_iv_file, params, niter, plot_dev, &plot_list[0], swap_order, max_vds ) )
      return 1;

   // save the final parameter values
   if( write_model_parameters_to_file( params, param_file ) )
      return 1;

   // generate plots
   if( plot_dev )
   {
      char plot_head[1000];
      FILE *file;

      // get the plot header
      plot_head[0] = 0;
      file = fopen( dc_iv_file, "r" );
      if (file)
      {
         while (fgets (string, 255, file))
         {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
         }

         fclose (file);
      }

      if( plot_data(plot_dev, plot_head, plot_list, SZ_PLOT_LIST) )
         return 1;
   }

   printf ("\nModel fitting complete.\n\n");

   return 0;
}

/**********************************************************************************/

void change_extension( const char * fname, const char * ext, char * new_fname )
{
   char * base = strdup( fname );
   int i;
   for( i=strlen(fname)-1; i>0; --i )
   {
      if( base[i] == '/' )
         break;
      else if( base[i] == '.' ) {
         base[i]='\0'; break; }
   }

   strcpy( new_fname, base );
   if( ext )
      strcat( new_fname, ext );

   if( strcmp( fname, new_fname ) == 0 )
   {
      strcpy( new_fname, base );
      strcat( new_fname, "1" );
      if( ext )
         strcat( new_fname, ext );
   }

   free((void*)base);
}

/**********************************************************************************/

static int fit_dc_curves( char *dc_iv_file, MODEL_PARAMS *parms, unsigned niter, int plotting_on, jPLOT_ITEM **dciv_plot, int swap_order, double max_vds )
{
   unsigned n_iv_pts;
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   unsigned i;
   OPT_PARAMETER p[6];
   OPT_PARAMETER r[2];
   double rd, rs, t;
   static char *iv_param_names[] = { "vto", "alpha", "beta", "tqdelta", "tqgamma", "q" };
   static char *r_param_names[] = { "rd", "rs" };

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (iv_param_names, 6, parms, p))
      return 1;
   if (get_all_parameters (r_param_names, 2, parms, r))
      return 1;
   rd = r[0].nom;
   rs = r[1].nom;

   // load the DC I-V curve data
   if( get_iv_data(dc_iv_file, dciv_curves, MAX_DCIV_PTS, &n_iv_pts) )
      return 1;

   // apply port resistances to active region data
   for( i=0; i<n_iv_pts; ++i )
   {
      if( swap_order )
      {
         // swap the I-V data, it is in opposite order
         t = dciv_curves[i].vds;
         dciv_curves[i].vds = dciv_curves[i].vgs;
         dciv_curves[i].vgs = t;
         t = dciv_curves[i].ids;
         dciv_curves[i].ids = dciv_curves[i].igs;
         dciv_curves[i].igs = t;
      }

      dciv_curves[i].vds -= dciv_curves[i].ids * ( rd + rs );
      dciv_curves[i].vgs -= dciv_curves[i].ids * rs;
   }

   // optimization
   if( niter > 0 )
   {
      OPTIMIZE *opt;
      DCIV_OPT dciv_data;

      dciv_data.n = n_iv_pts;
      dciv_data.dcdata = dciv_curves;
      dciv_data.maxv = max_vds;

      opt = initialize_cg_optimizer();
      set_cg_parameters(opt, p, 6);
      set_cg_flags(opt, OPT_VERBOSE | OPT_AUTO);
      set_cg_error_function(opt, dciv_erf, &dciv_data, 1, NULL);
      set_cg_error_fraction(opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for( i=0; i<6; ++i )
         p[i].optimize = TRUE;

      if( cg_optimize4(opt, niter, NULL) )
      {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         free((void *)opt);
         return -1;
      }

      free((void *) opt);
      if( set_all_parameters(parms, p, 6) )
         return 1;
   }

   /* create plots */

   if( plotting_on )
   {
      double *dciv_v, *dciv_imod, *dciv_imeas;
      double pl[6];

      dciv_v = (double *) malloc (sizeof (double) * n_iv_pts);
      dciv_imeas = (double *) malloc (sizeof (double) * n_iv_pts);
      dciv_imod = (double *) malloc (sizeof (double) * n_iv_pts);

      for( i=0; i<6; ++i )
         pl[i] = p[i].nom;

      for( i=0; i<n_iv_pts; ++i )
      {
         dciv_v[i] = dciv_curves[i].vds;
         dciv_imeas[i] = dciv_curves[i].ids * 1.0e3;
         dciv_imod[i] = tom_ids( pl, dciv_curves[i].vgs, dciv_curves[i].vds ) * 1.0e3;
      }

      create_plot (dciv_plot, dciv_v, dciv_imeas, dciv_imod, n_iv_pts, "Vds (volts)", "Ids (mA)", "DC I-V Curves", POSITIVE_X | POSITIVE_Y1);
   }

   return 0;
}

/**********************************************************************************/
/*                              MODEL FUNCTIONS                                   */
/**********************************************************************************/

static double tom_ids( double *p, double Vgs, double Vds )
{
   double vto     = p[0];
   double alpha   = p[1];
   double beta    = p[2];
   double tqdelta = p[3];
   double tqgamma = p[4];
   double q       = p[5];
   int flag = 0;

   double Vt, Ids0, Ids;

   if( Vds < 0. )
   {
      Vgs = Vgs - Vds;
      Vds = -Vds;
      flag = 1;
   }

   Vt = vto - tqgamma * Vds;
   if( Vgs < Vt )
      return 0.;
   else
   {
      Ids0 = beta * pow( Vgs - Vt, q ); 
      if( Vds < 3. / alpha )
      {
         double t = 1. - alpha * Vds / 3.;
         Ids0 *= 1. - t * t * t;
      }
      Ids = Ids0 / (1. + tqdelta*Ids0*Vds);
      return (flag ? -Ids : Ids);
   }
}

/**********************************************************************************/
/*                            OPTIMIZER FUNCTIONS                                 */
/**********************************************************************************/

static int dciv_erf( double *p, void *data, double *err, unsigned n_err )
{
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   for( i=0; i<d->n; ++i )
   {
      // check if Vds is greater than maximum allowed
      if( d->dcdata[i].vds > d->maxv ) continue;

      diff = d->dcdata[i].ids - tom_ids( p, d->dcdata[i].vgs, d->dcdata[i].vds );
      err[0] += 1.0e6 * diff * diff;
   }

   return 0;
}

/**********************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
{
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 2, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 2, MOD_COLOR);

   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
}

/**********************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
{
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile;
   jHANDLE legend, header;
   unsigned i;

   switch (dev)
   {
   case POSTSCRIPT:
      plotfile = "tom.ps";
      break;

   case METAFILE:
      plotfile = "tom.wmf";
      break;

   case X_WINDOWS:
      plotfile = NULL;
      break;

   default:
      return 0;
   }

   if (!open_graphics_device (dev, plotfile))
   {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
   }

   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
   {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
   }

   // draw all plots
   for (i = 0; i < n; ++i)
   {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
      {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
      }

      plot_list[i]->active = FALSE;
   }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
   {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
   }
   else
      close_graphics_device ();

   return 0;
}

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files()
{
   FILE *file;
   unsigned i;
   OPT_PARAMETER p[] = {
      { -0.8, -0.4, -0.3, 0.0, "Vto", 0},
      { 2.5, 3.5, 5.0, 0.0, "Alpha", 0},
      { 0.002, 0.006, 0.01, 0.0, "Beta", 0},
      { 0.01, 0.02, 0.03, 0.0, "Tqgamma", 0},
      { 0.0, 0.001, 0.005, 0.0, "Tqdelta", 0},
      { 2.5, 3.0, 3.5, 0.0, "Q", 0},
      { 98.0, 98.0, 98.0, 0.0, "Rd", 0},
      { 98.0, 98.0, 98.0, 0.0, "Rs", 0}
   };

   file = fopen( "tom.prm", "w+" );
   if (!file)
   {
      fprintf(stderr, "Error: %s: unable to write to disc.\n", "tom3.prm" );
      return;
   }

   fprintf( file, "! auto-generated file\n" );
   for( i=0; i<8; ++i)
      fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);
   fclose (file);
}



