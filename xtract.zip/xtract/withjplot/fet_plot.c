#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"

void print_usage( char* progname )
{
   printf( "\nUSAGE: %s [options] filename\n\n", progname);
   printf( "  Options:\n" );
   printf( "    -dM, -wmf, -meta    Set the output device to metafile.\n");
   printf( "    -dP, -ps            Set the output device to postscript.\n");
   printf( "    -o name             Sets \'name\' as the output filename.\n"); 
   printf( "\n" );
}

int main (int argc, char *argv[])
{
   int     i,device;
   char    file_name[80],out_name[80],string[256];
   char    head1[2048],head2[2048],head3[512];
   double  t1,t2,xdata[2000],y1data[2000],y2data[2000];
   FILE    *infile;
   jPLOT_ITEM *plot1;

   file_name[0] = 0;
   strcpy( out_name, "fetplot.ps" );
   device = X_WINDOWS;

   if( argc < 2 ) {
      print_usage(argv[0]);
      exit(0);
   }

   // parse command line
   for (i = 1; i < argc; ++i)
   {
      if( !strncmp(argv[i],"-dP",3) || !strncmp(argv[i],"-ps",3) ) {
         device = POSTSCRIPT;
      }
      else if( !strncmp(argv[i],"-dM",3) || !strncmp(argv[i],"-wmf",4) || !strncmp(argv[i],"-meta",5) ) {
         device = METAFILE;
      }
      else if( !strcmp(argv[i],"-o") ) {
         if( i == argc-1 ) {
            fprintf( stderr, "Error: missing parameter for -o option.\n" );
            print_usage(argv[0]);
            exit(1);
         }
         strcpy( out_name, argv[++i] );
      }
      else if( argv[i][0] == '-' ) {
         fprintf( stderr, "Error: unrecognized option: %s\n", argv[i] );
         print_usage(argv[0]);
         exit(1);
      }
      else { 
         strcpy( file_name, argv[i] ); 
      }
   }

   if( ! strlen(file_name) ) {
      fprintf( stderr, "Error: no file specified.\n" );
      print_usage(argv[0]);
      exit(1);
   }

   infile = fopen (file_name,"r");
   if (!infile)
   {
      printf ("UNABLE TO OPEN FILE - %s\n",file_name);
      return -1;
   }

   if (!open_graphics_device (device,out_name))
   {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
   }

   plot1 = create_plot_item (SingleY,2.75,1.25,5.5,4.5);
   plot1->attribs.title_offset = 0.3;

   /*****************  HEADER  ******************/

   head1[0] = head2[0] = head3[0] = 0;
   for (i = 0; i < 7; ++i)
   {
      fgets (string,255,infile);
      strcat (head1,&string[1]);
   }

   for (i = 0; i < 6; ++i)
   {
      fgets (string,255,infile);
      strcat (head2,&string[1]);
   }

   while (fgets (string,255,infile))
   {
      if (strstr (string,"DC FET PARAMETERS"))
      {
         fgets (string,255,infile);
         strcat (head3,&string[1]);
         fgets (string,255,infile);
         strcat (head3,string);
         break;
      }
   }

   add_text (head1,2.0,7.9,FNT_COURIER,10,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
   add_text (head2,6.0,7.9,FNT_COURIER,10,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
   add_text (head3,1.75,6.6,FNT_COURIER,10,0.0,LEFT_JUSTIFY,CLR_BLACK,0);

   /*****************  IV CURVES  ******************/

   while (fgets (string,255,infile))
   {
      if (strstr (string,"DC IV-CURVES"))
      {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
      }
   }

   i = 0;
   while (fgets (string,255,infile))
   {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&xdata[i],&y1data[i],&t1,&y2data[i]) == 4)
      {
         y1data[i] *= 1000.0;
         y2data[i] *= 1000.0;
         ++i;
      }
   }

   if (i > 0)
   {
      attach_y1data (plot1,xdata,y1data,i,LT_SOLID,1,CLR_RED);

      set_axis_scaling (plot1,POSITIVE_X | POSITIVE_Y1);

      set_axis_labels (plot1,"Vds (volts)","Ids (mA)",NULL,"I-V Curves");

      if (!draw_page ())
      {
         printf ("%s\n",get_error_message (ERROR_NUMBER));
         fclose (infile);
         return -1;
      }

      /*****************  Igs VS Vds  ******************/

      detach_data (plot1);

      attach_y1data (plot1,xdata,y2data,i,LT_SOLID,1,CLR_RED);

      set_axis_scaling (plot1,POSITIVE_X);

      set_axis_labels (plot1,"Vds (volts)","Igs (mA)",NULL,"Gate Current vs. Drain Voltage");

      if (!draw_page ())
      {
         printf ("%s\n",get_error_message (ERROR_NUMBER));
         fclose (infile);
         return -1;
      }
   }

   /*****************  REV breakdown ******************/

   rewind (infile);
   detach_data (plot1);

   while (fgets (string,255,infile))
   {
      if (strstr (string,"BREAKDOWN IV-CURVES"))
      {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
      }
   }

   i = 0;
   while (fgets (string,255,infile))
   {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&t1,&t2,&xdata[i],&y1data[i]) == 4)
      {
         xdata[i] = t1 - xdata[i];
         y1data[i] *= -1000.0;
         if(y1data[i] <= 0.0)
            continue;
         ++i;
      }
   }

   if (i > 0)
   {
      attach_y1data (plot1,xdata,y1data,i,LT_SOLID,1,CLR_RED);

      set_axis_scaling (plot1,LogY1);

      set_axis_labels (plot1,"Vdg (volts)","Igd (mA)",NULL,"Breakdown Curves");

      if (!draw_page ())
      {
         printf ("%s\n",get_error_message (ERROR_NUMBER));
         fclose (infile);
         return -1;
      }
   }

   /*****************  DONE PLOTS  ******************/

   close_graphics_device ();
   fclose (infile);

   return 0;
}

