#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/stat.h>
#include "ss_tools2.h"
#include "jplot.h"
#include "fit_tools.h"

/* definitions */

#define ERROR_FILE_NAME      "zzzBatchFitErrors.txt"

typedef struct
{
   char fname[256];
   char start_val[256];
   char finish_val[256];
   double cgs_fmin, cgs_fmax;
   double ri_fmin, ri_fmax;
   double ggs_fmin, ggs_fmax;
} YFITV500_INPUTS;

typedef struct
{
   char fname[256];
   char start_val[256];
   char finish_val[256];
   char mod_name[256];
   double fmin, fmax;
   double weights[6];
   unsigned maxiter;
} FITV500_INPUTS;

// common defs
#define MAX_FREQS         (500)
#define n_fet_params      (20)

// flags
#define NO_PLOTTING        (1<<0)
#define EXTRACT_TAU2       (1<<3)
#define FIXED_L            (1<<5)
#define FIXED_R            (1<<6)
#define NO_CXX             (1<<7)
#define DO_RERANGE         (1<<8)
#define ASYMMETRIC         (1<<9)
#define ALWAYS_FIT_GGS     (1<<10)
#define SET_RG             (1<<16)
#define SET_RS             (1<<17)
#define SET_RD             (1<<18)
#define SET_LG             (1<<19)
#define SET_LS             (1<<20)
#define SET_LD             (1<<21)
#define SET_C1             (1<<22)
#define SET_C2             (1<<23)
#define SET_C11            (1<<24)
#define SET_C22            (1<<25)

// indexes for each parameter
#define INDEX_RG           (0)
#define INDEX_RS           (1)
#define INDEX_RD           (2)
#define INDEX_RI           (3)
#define INDEX_CGS          (4)
#define INDEX_CGD          (5)
#define INDEX_CDS          (6)
#define INDEX_C1           (7)
#define INDEX_C2           (8)
#define INDEX_LS           (9)
#define INDEX_LG           (10)
#define INDEX_LD           (11)
#define INDEX_GGS          (12)
#define INDEX_GGD          (13)
#define INDEX_GM           (14)
#define INDEX_TAU1         (15)
#define INDEX_GDS          (16)
#define INDEX_TAU2         (17)
#define INDEX_C11          (18)
#define INDEX_C22          (19)

/* global variables */

static const char *global_fet_params[] = {"RG", "RS", "RD", "RI", "CGS", "CDG", "CDS", "C1", "C2", "LS",
"B1", "B2", "GGS", "GDG", "GM", "TAU1", "GDS", "TAU2", "C11", "C22"};
static double global_param_values[20];
static FILE *global_errstream = NULL;

/* function prototypes */

static int find_in_list( const char *str, const char *lst );
static int cmdline_setvalue( char *arg, char *parm, int plen, double *val );
static int fet_batch_fit_main (unsigned flags);
static int fitv500_main (FITV500_INPUTS *inp, unsigned flags);
static int yfitv500_main (YFITV500_INPUTS *inp, unsigned flags);
static void error_msg( const char *fmt, ... );


void debug_print_params( OPT_PARAMETER* p, const char* fname )
{
    /*
    FILE* f = fopen( fname, "a" );

    if( !f ) return;

    fprintf( f, "GDS = %.4e\n", p[INDEX_GDS].nom );
    fprintf( f, "GGD = %.4e\n", p[INDEX_GGD].nom );
    fprintf( f, "-----\n" );

    fclose( f );
    */
}


/***************************************************************************************/
/***************************************************************************************/

int main (int argc, char *argv[])
{
   char *name = argv[0];
   unsigned flags = 0;
   int i;
   double v;
   int mode = 0;

   global_errstream = stderr;

   // the main function is a wrapper that calls other sections of the program
   //  this depends on the name with which it is invoked


   /*-- parse the command line --*/

   for (i = 1; i < argc; ++i)
   {
      // printf( "%s\n", argv[i] );

      if( !strncmp(argv[i], "-h", 2) )
      {
         printf ("\n\nUSAGE: %s [options]\n", argv[0]);
         printf ("----------------------------------------\n");
         printf ("  options:\n");
         printf ("      -b        Run in batch mode (same as invoking fet_batch_fit).\n");
         printf ("      -d0       Do not generate plots - plots are not generated when in batch mode.\n");
         printf ("      -t2       Extract TAU2 during the Y-fit procedure.\n");
         printf ("      -asym     Gate is shifted toward the source, favor GGS during Y-Fit.\n");
         printf ("      -fixl     Do not optimize inductances (default in batch mode).\n");
         printf ("      -fixr     Do not optimize resistances (default in batch mode).\n");
         printf ("      -nocxx    Do not use C11 or C22.\n");
         printf ("      -ggs      Always fit GGS (leaky devices).\n");
         printf ("      -RG=x     Set RG to the value of x.\n");
         printf ("      -LG=x     Set LG to the value of x.\n");
         printf ("      -RD=x     Set RD to the value of x.\n");
         printf ("      -LD=x     Set LD to the value of x.\n");
         printf ("      -RS=x     Set RS to the value of x.\n");
         printf ("      -LS=x     Set LS to the value of x.\n");
         printf ("      -C11=x    Set C11 to the value of x.\n");
         printf ("      -C22=x    Set C22 to the value of x.\n");
         printf ("      -C1=x     Set C1 to the value of x.\n");
         printf ("      -C2=x     Set C2 to the value of x.\n");
         printf ("      -rr1      Set optimization ranges to +/- 50%% of nominal.\n");
         return 0;
      }
      else if( !strncmp (argv[i], "-d0", 3)) flags |= NO_PLOTTING;
      else if( !strncmp (argv[i], "-t2", 3)) flags |= EXTRACT_TAU2;
      else if( !strncmp (argv[i], "-fixl", 5)) flags |= FIXED_L;
      else if( !strncmp (argv[i], "-fixr", 5)) flags |= FIXED_R;
      else if( !strncmp (argv[i], "-nocx", 5)) flags |= NO_CXX;
      else if( !strncmp (argv[i], "-b", 2) || !strncmp(argv[i], "-batch", 6) || !strncmp (argv[i], "--batch", 7) ) mode = 3;
      else if( !strncmp (argv[i], "-rr1", 4)) flags |= DO_RERANGE;
      else if( !strncmp (argv[i], "-asym", 5))flags |= ASYMMETRIC;
      else if( !strncmp (argv[i], "-ggs", 4)) flags |= ALWAYS_FIT_GGS;
      else if( !strncmp (argv[i], "-yfit", 5) || !strncmp (argv[i], "--yfit", 6) ) mode = 1;
      else if( !strncmp (argv[i], "-opt", 4) || !strncmp (argv[i], "--opt", 5) ) mode = 2;
      else if( cmdline_setvalue( argv[i], "-RG=", 4, &v ) ) {
         global_param_values[INDEX_RG] = v;
         flags |= SET_RG;
      }
      else if ( cmdline_setvalue( argv[i], "-RD=", 4, &v ) ) {
         global_param_values[INDEX_RD] = v;
         flags |= SET_RD;
      }
      else if ( cmdline_setvalue( argv[i], "-RS=", 4, &v ) ) {
         global_param_values[INDEX_RS] = v;
         flags |= SET_RS;
      }
      else if ( cmdline_setvalue( argv[i], "-LG=", 4, &v ) ) {
         global_param_values[INDEX_LG] = v;
         flags |= SET_LG;
      }
      else if ( cmdline_setvalue( argv[i], "-LD=", 4, &v ) ) {
         global_param_values[INDEX_LD] = v;
         flags |= SET_LD;
      }
      else if ( cmdline_setvalue( argv[i], "-LS=", 4, &v ) ) {
         global_param_values[INDEX_LS] = v;
         flags |= SET_LS;
      }
      else if ( cmdline_setvalue( argv[i], "-C1=", 4, &v ) ) {
         global_param_values[INDEX_C1] = v;
         flags |= SET_C1;
      }
      else if ( cmdline_setvalue( argv[i], "-C2=", 4, &v ) ) {
         global_param_values[INDEX_C2] = v;
         flags |= SET_C2;
      }
      else if ( cmdline_setvalue( argv[i], "-C11=", 5, &v ) ) {
         global_param_values[INDEX_C11] = v;
         flags |= SET_C11;
      }
      else if ( cmdline_setvalue( argv[i], "-C22=", 5, &v ) ) {
         global_param_values[INDEX_C22] = v;
         flags |= SET_C22;
      }
      else {
         error_msg( "Error: \'%s\': unrecognized command line parameter.", argv[i] );
         return 1;
      }
   }

   /*-- execute the appropriate tool --*/
   if( !mode ) {
        if ( find_in_list( name, "fitv500 fet_fit fetfit fetopt" )  ) mode = 2;
        else if( find_in_list( name, "yfit yfitv500 fet_y fet_yfit fetyfit" ) ) mode = 1;
        else if( find_in_list( name, "fet_ss_fit fet_batch_fit batch_fit" ) ) mode = 3;
        else {
            fprintf( stderr, "Error: %s: could not determine the desired operation.\n\n", name );
            return 1;
        }
   }

   switch( mode ) {
       case 1:
            return yfitv500_main( NULL, flags );
       case 2:
            return fitv500_main( NULL, flags );
       case 3:
            return fet_batch_fit_main( flags );
       default:
            fprintf( stderr, "Error: %s: could not determine the desired operation.\n\n", name );
            return 1;
   }

   return 0;
}

/***************************************************************************************/
/***************************************************************************************/

static int find_in_list( const char *str, const char *lst )
{
   char *lst2 = strdup( lst );
   const char *sep = " \t\n,:;";
   char *ptr = strtok( lst2, sep );

   while( ptr )
   {
      if( !strcmp( str, ptr ) )
      {
         free( lst2 );
         return 1;
      }
      ptr = strtok( NULL, sep );
   }
   free( lst2 );
   return 0;
}

/***************************************************************************************/
/***************************************************************************************/

static int cmdline_setvalue( char *arg, char *parm, int plen, double *val )
{
   if( !strncmp( arg, parm, plen ) )
   {
      *val=0.;
      sscanf( &arg[plen], "%lf", val );
      return 1;
   }
   return 0;
}

/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/
/***************************************************************************************/

static int fet_batch_fit_main (unsigned flags)
{
   FITV500_INPUTS fitin;
   YFITV500_INPUTS yfitin;
   char fit_files[256];
   char base_name[256];
   char string[256];
   const char ** flist;
   const char ** fname;

   printf ("Files to Fit?\n");
   fgets (fit_files, 255, stdin);
   fit_files[strlen(fit_files)-1] = 0;

   printf ("Starting values file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", yfitin.start_val);

   printf ("Frequency range for Cgs, Cgd, Cds, Gm and Gds calculations in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &yfitin.cgs_fmin, &yfitin.cgs_fmax) != 2)
   {
      error_msg( "Error: fet_batch_fit(): failed to read frequency range." );
      return 1;
   }
   yfitin.cgs_fmin *= 1.0e9;
   yfitin.cgs_fmax *= 1.0e9;

   printf ("Frequency range for Ri and Tau calculations in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &yfitin.ri_fmin, &yfitin.ri_fmax) != 2)
   {
      error_msg( "Error: fet_batch_fit(): failed to read frequency range." );
      return 1;
   }
   yfitin.ri_fmin *= 1.0e9;
   yfitin.ri_fmax *= 1.0e9;

   printf ("Frequency range for Ggs and Ggd calculations in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &yfitin.ggs_fmin, &yfitin.ggs_fmax) != 2)
   {
      error_msg( "Error: fet_batch_fit(): failed to read frequency range." );
      return 1;
   }
   yfitin.ggs_fmin *= 1.0e9;
   yfitin.ggs_fmax *= 1.0e9;

   printf ("Frequency range for optimization in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fitin.fmin, &fitin.fmax) != 2)
   {
      error_msg( "Error: fet_batch_fit(): failed to read frequency range." );
      return 1;
   }
   fitin.fmin *= 1.0e9;
   fitin.fmax *= 1.0e9;

   printf ("Optimization weights (S11 S21 S12 S22 K MAG)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf%lf%lf%lf%lf", &fitin.weights[0], &fitin.weights[1], &fitin.weights[2],
      &fitin.weights[3], &fitin.weights[4], &fitin.weights[5]) != 6)
   {
      error_msg( "Error: fet_batch_fit(): failed to read optimization weights." );
      return 1;
   }

   printf ("Maximum number of line searches?\n");
   fgets (string, 255, stdin);
   if (!sscanf (string, "%u", &fitin.maxiter))
   {
      error_msg( "Error: fet_batch_fit(): failed to read line search count." );
      return 1;
   }

   flist = get_file_listing( fit_files );
   if( !flist || ! *flist ) {
      error_msg( "Error: fet_batch_fit(): no files match pattern \'%s\'.", fit_files );
      return 1;
   }

   // fork into a background process and exit the foreground process
   switch (fork())
   {
   case -1:
      error_msg( "Error: fet_batch_fit(): fork() failed." );
      return 1;

   case 0:
      // this is the child process
      break;

   default:
      // this is the parent process
      _exit(0);
   }

   // set the global error stream to NULL to force error messages to be written to the error message file
   remove( ERROR_FILE_NAME );
   global_errstream = NULL;

   for( fname = flist; *fname ; ++fname )
   {
      strcpy( base_name, *fname );
      strip_extension( base_name );


      strcpy( yfitin.fname, *fname );
      strcpy( fitin.fname, *fname );

      strcpy( yfitin.finish_val, base_name );
      strcat( yfitin.finish_val, ".end" );
      strcpy( fitin.start_val, yfitin.finish_val );
      strcpy( fitin.finish_val, fitin.start_val );

      strcpy( fitin.mod_name, base_name );
      strcat( fitin.mod_name, ".mod" );

      // run the Y-fit, then the optimization
      if( yfitv500_main( &yfitin, flags ) || fitv500_main( &fitin, flags ) ) {
            error_msg( "%s: extraction failed,", *fname );
      }
   }

   // free memory
   free_file_listing( flist );

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static void set_parm( OPT_PARAMETER *p, int idx, double nom, double mult_lo, double mult_hi, double min_lo, double min_hi )
{
    double n = ( nom < min_lo ) ? min_lo : nom;

   p[idx].min = n*mult_lo;
   p[idx].nom = n;
   p[idx].max = n*mult_hi;

   if( p[idx].min < min_lo )
      p[idx].min = min_lo;
   if( p[idx].max < min_hi )
      p[idx].max = min_hi;
}

/*******************************************************************************************/
/*******************************************************************************************/

static void remove_fet_parasitics( S_2PORT *sp, unsigned n_sp, OPT_PARAMETER *p )
{
   unsigned i;
   double w;
   COMPLEX y[4], z[4];

   for (i = 0; i < n_sp; ++i)
   {
      w = 2.0 * PI * sp[i].freq;
      s2y( sp[i].s, y, 50.0 );

      // remove C1 and C2
      y[0].i -= w * p[INDEX_C1].nom;
      y[3].i -= w * p[INDEX_C2].nom;

      // remove B1 and B2
      y2z (y, z);
      z[0].i -= w * p[INDEX_LG].nom;
      z[3].i -= w * p[INDEX_LD].nom;

      // remove C11 and C22
      z2y (z, y);
      y[0].i -= w * p[INDEX_C11].nom;
      y[3].i -= w * p[INDEX_C22].nom;

      // remove RG, RD, RS, and LS
      y2z (y, z);
      z[0] = Csub( z[0], Cnum(p[INDEX_RG].nom + p[INDEX_RS].nom, w * p[INDEX_LS].nom) );
      z[1] = Csub( z[1], Cnum(p[INDEX_RS].nom, w * p[INDEX_LS].nom));
      z[2] = Csub( z[2], Cnum(p[INDEX_RS].nom, w * p[INDEX_LS].nom));
      z[3] = Csub( z[3], Cnum(p[INDEX_RD].nom + p[INDEX_RS].nom, w * p[INDEX_LS].nom) );

      z2s (z, sp[i].s, 50.0);
   }
}

/*******************************************************************************************/
/*******************************************************************************************/

static void correct_parameters( OPT_PARAMETER *p, unsigned flags )
{
   if( flags & SET_RG )
      set_parm( p, INDEX_RG, global_param_values[INDEX_RG], 1., 1., 0., 0. );
   if( flags & SET_RS )
      set_parm( p, INDEX_RS, global_param_values[INDEX_RS], 1., 1., 0., 0. );
   if( flags & SET_RD )
      set_parm( p, INDEX_RD, global_param_values[INDEX_RD], 1., 1., 0., 0. );

   if( flags & SET_LS )
      set_parm( p, INDEX_LS, global_param_values[INDEX_LS], 1., 1., 0., 0. );
   if( flags & SET_LG )
      set_parm( p, INDEX_LG, global_param_values[INDEX_LG], 1., 1., 0., 0. );
   if( flags & SET_LD )
      set_parm( p, INDEX_LD, global_param_values[INDEX_LD], 1., 1., 0., 0. );

   if( flags & SET_C1 )
      set_parm( p, INDEX_C1, global_param_values[INDEX_C1], 1., 1., 0., 0. );
   if( flags & SET_C2 )
      set_parm( p, INDEX_C2, global_param_values[INDEX_C2], 1., 1., 0., 0. );

   if( flags & SET_C11 )
      set_parm( p, INDEX_C11, global_param_values[INDEX_C11], 1., 1., 0., 0. );
   if( flags & SET_C22 )
      set_parm( p, INDEX_C22, global_param_values[INDEX_C22], 1., 1., 0., 0. );

   if( flags & NO_CXX )
   {
      set_parm( p, INDEX_C11, 0., 0., 0., 0., 0. );
      set_parm( p, INDEX_C22, 0., 0., 0., 0., 0. );
   }
}

/*******************************************************************************************/
/*******************************************************************************************/
/*
static void re_range_params( OPT_PARAMETER *p, double periph_sf )
{
   int i;

   for( i=0; i<n_fet_params; i++ )
   {
      if( p[i].nom != 0. )
      {
         p[i].min = p[i].nom - fabs(p[i].nom)*0.5;
         p[i].max = p[i].nom + fabs(p[i].nom)*0.5;
      }
      else
      {
         p[i].min = 0.;
         switch( i )
         {
         case INDEX_RG:
         case INDEX_RD:
         case INDEX_RS:
            p[i].min = 1.e-3;
            p[i].max = 2. / periph_sf;
            break;

         case INDEX_RI:
            p[i].min = 1.e-3;
            p[i].max = 5. / periph_sf;
            break;

         case INDEX_CGS:
         case INDEX_CGD:
         case INDEX_CDS:
            p[i].max = 5.e-13 * periph_sf; break;

         case INDEX_C1:
         case INDEX_C2:
            p[i].max = 0.; break;

         case INDEX_LS:
            p[i].max = 5.e-12; break;

         case INDEX_LG:
         case INDEX_LD:
            p[i].max = 1.e-11; break;

         case INDEX_GGS:
            p[i].max = 2.e-3 * periph_sf; break;

         case INDEX_GGD:
            p[i].max = 1.e-4 * periph_sf; break;

         case INDEX_GM:
            p[i].max = 1.e-4 * periph_sf; break;
         case INDEX_TAU1:
            p[i].max = 5.e-12; break;

         case INDEX_GDS:
            p[i].max = 1.e-3 * periph_sf; break;
         case INDEX_TAU2:
            p[i].max = 5.e-12; break;

         case INDEX_C11:
         case INDEX_C22:
            p[i].max = 0.; break;

         default:
            break;
         }
      }
   }
}
*/

/*******************************************************************************************/
/*******************************************************************************************/

static int read_sp_data_file( char *name, char *head, int sz_head, double minf, double maxf, double *flist, int sz_flist, S_2PORT *sp, int sz_sp, int *numf, int *nflist, double *periph_sf );
static int full_fet_optimization( S_2PORT *sp, int numf, OPT_PARAMETER *p, double *weights, int max_iter, unsigned opt_flags, double *err_ret );
static int batch_fet_optimization( S_2PORT *sp, int numf, OPT_PARAMETER *p, double *weights, int max_iter, unsigned opt_flags, double *err_ret );
static int plot_meas_vs_model( char *meas_name, OPT_PARAMETER *p, int device );

/*******************************************************************************************/
/*******************************************************************************************/

static int fitv500_main( FITV500_INPUTS *inp, unsigned flags )
{
   char s_measured_name[256], starting_values[256];
   char finishing_values[256], mod_out_name[256];
   char string[256], head[3000];
   int i, maxiter, e, numf, numflist;
   double weights[6], fmin, fmax, err_ret[6];
   double flist[MAX_FREQS], periph_sf;
   MODEL_PARAMS *params;
   OPT_PARAMETER p[n_fet_params];
   S_2PORT sp[MAX_FREQS];
   unsigned opt_flags = OPT_SINGLE_PARAM;


   if (inp)  // if this is not NULL, we are doing a batch fit
   {
      // copy parameters
      strcpy (s_measured_name, inp->fname);
      fmin = inp->fmin;
      fmax = inp->fmax;
      for (i = 0; i < 6; ++i)
         weights[i] = inp->weights[i];
      strcpy (starting_values, inp->start_val);
      strcpy (finishing_values, inp->finish_val);
      strcpy (mod_out_name, inp->mod_name);
      maxiter = inp->maxiter;
   }

   else  // otherwise, we are running standalone and need user inputs
   {
      printf ("Measured data file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", s_measured_name);

      printf ("Frequency range for optimization in GHz (min max)?\n");
      fgets (string, 255, stdin);
      if (sscanf (string, "%lf%lf", &fmin, &fmax) != 2)
      {
         error_msg( "Error reading min/max frequencies." );
         return -1;
      }
      fmin *= 1.0e9;
      fmax *= 1.0e9;

      printf ("Optimization weights (S11 S21 S12 S22 K MAG)?\n");
      fgets (string, 255, stdin);
      if (sscanf (string, "%lf%lf%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2],
         &weights[3], &weights[4], &weights[5]) != 6)
      {
         error_msg( "Error reading optimization weights." );
         return -1;
      }

      printf ("Initial parameters file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", starting_values);

      printf ("Final parameters file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", finishing_values);

      printf ("Model output file name?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", mod_out_name);

      printf ("Maximum number of line searches?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%u", &maxiter);
   }

   // read in starting parameter values
   if( read_model_parameters_from_file (starting_values, &params, NULL) ||
       get_all_parameters (global_fet_params, n_fet_params, params, p) )
      return 1;

   debug_print_params( p, "in-fit-main.dbg" );


   // read in the measured data
   if( read_sp_data_file( s_measured_name, head, 3000, fmin, fmax, flist, MAX_FREQS, sp, MAX_FREQS, &numf, &numflist, &periph_sf ) )
      return 1;

   // replace parameters based on cmdline inputs
   correct_parameters( p, flags );
   /*
   if( flags & DO_RERANGE )
      re_range_params( p, periph_sf );
    */

   // turn on optimization on all parameters
   for( i=0; i<n_fet_params; i++ )
      p[i].optimize = TRUE;

   // turn off optimization on some parameters, based on command-line flags
   if( flags & FIXED_R )
      p[INDEX_RG].optimize = p[INDEX_RD].optimize = p[INDEX_RS].optimize = FALSE;
   if (flags & FIXED_L)
      p[INDEX_LG].optimize = p[INDEX_LD].optimize = p[INDEX_LS].optimize = FALSE;
   if (!(flags & EXTRACT_TAU2))
      p[INDEX_TAU2].optimize = FALSE;

   // perform the small-signal fit
   if( inp )
      e = batch_fet_optimization( sp, numf, p, weights, maxiter, opt_flags, err_ret );
   else
      e = full_fet_optimization( sp, numf, p, weights, maxiter, opt_flags, err_ret );

   if( e ) {
      error_msg( "%s: optimization error: %s", s_measured_name, get_opt_error() );
      return 1;
   }

   // write the final parameter values
   if( set_all_parameters(params, p, n_fet_params) || write_model_parameters_to_file(params, finishing_values) )
      return 1;

   // plot the results
   if( !inp ) {
      if( plot_meas_vs_model( s_measured_name, p, POSTSCRIPT ) )
         return 1;
      if( ! (flags & NO_PLOTTING) ) {
          if( plot_meas_vs_model( s_measured_name, p, X_WINDOWS ) ) return 1;
      }
   }

   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

static int read_sp_data_file( char *name, char *head, int sz_head, double minf, double maxf, double *flist, int sz_flist, S_2PORT *sp, int sz_sp, int *numf, int *nflist, double *periph_sf )
{
   *numf = 0;
   *nflist = 0;
   *periph_sf = 1.;

   // read the model file header
   if( head && sz_head > 0 )
   {
      FILE *file;
      char str[256];

      head[0] = '\0';
      file = fopen( name, "r" );
      if( !file )
      {
         error_msg( "%s: file not found.", name );
         return 1;
      }

      while( fgets(str, 255, file) )
      {
         if( str[0] != '!' )
            break;

         // calculate the periphery scale factor
         if( !strncmp( str, "!GATE PERIPHERY (um):", 21 ) )
            sscanf( str, "!GATE PERIPHERY (um): %lf", periph_sf );
         *periph_sf *= 1.e-3;

         if( strlen(head) + strlen(str) < sz_head-1 )
            strcat( head, str );
         else break;
      }
      fclose (file);
   }

   if( sp && sz_sp > 0 )
   {
      S_2PORT spt[MAX_FREQS];
      int i, n;

      n = read_s_from_file( name, spt, NULL, MAX_FREQS );
      if( n < 0 )
      {
         error_msg( "%s: file not found.", name );
         return 1;
      }
      else if( n == 0 )
      {
         error_msg( "%s: file read error. No data.", name );
         return 1;
      }

      // load the return structures
      for( i=0; i<n; i++ )
      {
         if( spt[i].freq >= minf && spt[i].freq < maxf && *numf < sz_sp )
         {
            sp[*numf] = spt[i];
            (*numf)++;
         }

         if( *nflist < sz_flist )
         {
            flist[*nflist] = spt[i].freq;
            (*nflist)++;
         }
      }
   }
   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

static int full_fet_optimization( S_2PORT *sp, int numf, OPT_PARAMETER *p, double *weights, int max_iter, unsigned opt_flags, double *err_ret )
{
   NETLIST *netlist[20],*nlist;
   double dummy = 0.0;

   // create the netlist
   netlist[0]  = netlist_component( Netlist_R, dummy, 3, 4, INDEX_RG );
   netlist[1]  = netlist_component( Netlist_R, dummy, 7, 8, INDEX_RD );
   netlist[2]  = netlist_component( Netlist_L, dummy, 1, 3, INDEX_LG );
   netlist[3]  = netlist_component( Netlist_L, dummy, 8, 2, INDEX_LD );
   netlist[4]  = netlist_component( Netlist_SRL, dummy, dummy, 6, 0, INDEX_RS, INDEX_LS );
   netlist[5]  = netlist_component( Netlist_C, dummy, 1, 0, INDEX_C1 );
   netlist[6]  = netlist_component( Netlist_C, dummy, 2, 0, INDEX_C2 );
   netlist[7]  = netlist_component( Netlist_C, dummy, 3, 6, INDEX_C11 );
   netlist[8]  = netlist_component( Netlist_C, dummy, 8, 6, INDEX_C22 );
   netlist[9]  = netlist_component( Netlist_C, dummy, 4, 5, INDEX_CGS );
   netlist[10] = netlist_component( Netlist_C, dummy, 4, 7, INDEX_CGD );
   netlist[11] = netlist_component( Netlist_C, dummy, 6, 7, INDEX_CDS );
   netlist[12] = netlist_component( Netlist_R, dummy, 5, 6, INDEX_RI );
   netlist[13] = netlist_component( Netlist_G, dummy, 4, 5, INDEX_GGS );
   netlist[14] = netlist_component( Netlist_G, dummy, 4, 7, INDEX_GGD );
   netlist[15] = netlist_component( Netlist_VCCS, dummy, dummy, 4, 5, 7, 6, INDEX_GM, INDEX_TAU1 );
   netlist[16] = netlist_component( Netlist_VCCS, dummy, dummy, 7, 6, 7, 6, INDEX_GDS, INDEX_TAU2 );
   nlist = prepare_netlist( netlist, 17 );

   // optimize
   opt_flags |= OPT_VERBOSE;
   if( small_signal_optimizer( nlist, p, n_fet_params, sp, numf, max_iter, weights, opt_flags, err_ret ) )
      return 1;

   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

static int batch_fet_optimization( S_2PORT *sp, int numf, OPT_PARAMETER *p, double *weights, int max_iter, unsigned opt_flags, double *err_ret )
{
   NETLIST *netlist[10],*nlist;
   double dummy = 0.0;

   // remove the fixed parasitics
   remove_fet_parasitics( sp, numf, p );

   p[INDEX_RG].optimize = 0;
   p[INDEX_RD].optimize = 0;
   p[INDEX_RS].optimize = 0;
   p[INDEX_LG].optimize = 0;
   p[INDEX_LD].optimize = 0;
   p[INDEX_LS].optimize = 0;
   p[INDEX_C11].optimize = 0;
   p[INDEX_C22].optimize = 0;
   p[INDEX_C1].optimize = 0;
   p[INDEX_C2].optimize = 0;

   // create the netlist
   netlist[0] = netlist_component( Netlist_C, dummy, 1, 3, INDEX_CGS );
   netlist[1] = netlist_component( Netlist_C, dummy, 1, 2, INDEX_CGD );
   netlist[2] = netlist_component( Netlist_C, dummy, 2, 0, INDEX_CDS );
   netlist[3] = netlist_component( Netlist_R, dummy, 3, 0, INDEX_RI );
   netlist[4] = netlist_component( Netlist_G, dummy, 1, 3, INDEX_GGS );
   netlist[5] = netlist_component( Netlist_G, dummy, 1, 2, INDEX_GGD );
   netlist[6] = netlist_component( Netlist_VCCS, dummy, dummy, 1, 3, 2, 0, INDEX_GM, INDEX_TAU1 );
   netlist[7] = netlist_component( Netlist_VCCS, dummy, dummy, 2, 0, 2, 0, INDEX_GDS, INDEX_TAU2 );
   nlist = prepare_netlist( netlist, 8 );

   debug_print_params( p, "before-opt.dbg" );

   // optimize
   if( small_signal_optimizer( nlist, p, n_fet_params, sp, numf, max_iter, weights, opt_flags, err_ret ) )
      return 1;

   debug_print_params( p, "after-opt.dbg" );

   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

static int plot_meas_vs_model( char *meas_name, OPT_PARAMETER *p, int device )
{
   S_2PORT s_mod[MAX_FREQS];
   S_2PORT s_meas[MAX_FREQS];
   double freq[MAX_FREQS];
   double meas_mag[MAX_FREQS];
   double meas_ang[MAX_FREQS];
   double mod_mag[MAX_FREQS];
   double mod_ang[MAX_FREQS];
   NETLIST *netlist[20], *nlist;
   FILE *file;
   COMPLEX s[4];
   char string[256];
   char head[5000],head2[5000];
   int i,j;
   int n_meas_f;
   char *legend_text1[] = {"Modeled Magnitude", "Modeled Phase", "Measured Magnitude", "Measured Phase"};
   char *legend_text2[] = {"Modeled MAG/MSG", "Modeled K-Factor", "Measured MAG/MSG", "Measured K-Factor"};
   int legend_ltypes[] = {LT_SOLID, LT_DASHED, LT_SOLID, LT_DASHED};
   int legend_lwidths[] = {1, 1, 1, 1};
   int legend_colors[] = {CLR_RED, CLR_RED, CLR_DARKGREEN, CLR_DARKGREEN};
   jHANDLE legend1,header1,title1,header2;
   jPLOT_ITEM *plot1;

   // create the netlist
   netlist[0]  = netlist_component( Netlist_R, p[INDEX_RG].nom, 3, 4, STATIC_COMPONENT );
   netlist[1]  = netlist_component( Netlist_R, p[INDEX_RD].nom, 7, 8, STATIC_COMPONENT );
   netlist[2]  = netlist_component( Netlist_L, p[INDEX_LG].nom, 1, 3, STATIC_COMPONENT );
   netlist[3]  = netlist_component( Netlist_L, p[INDEX_LD].nom, 8, 2, STATIC_COMPONENT );
   netlist[4]  = netlist_component( Netlist_SRL, p[INDEX_RS].nom, p[INDEX_LS].nom, 6, 0, STATIC_COMPONENT, STATIC_COMPONENT );
   netlist[5]  = netlist_component( Netlist_C, p[INDEX_C1].nom, 1, 0, STATIC_COMPONENT );
   netlist[6]  = netlist_component( Netlist_C, p[INDEX_C2].nom, 2, 0, STATIC_COMPONENT );
   netlist[7]  = netlist_component( Netlist_C, p[INDEX_C11].nom, 3, 6, STATIC_COMPONENT );
   netlist[8]  = netlist_component( Netlist_C, p[INDEX_C22].nom, 8, 6, STATIC_COMPONENT );
   netlist[9]  = netlist_component( Netlist_C, p[INDEX_CGS].nom, 4, 5, STATIC_COMPONENT );
   netlist[10] = netlist_component( Netlist_C, p[INDEX_CGD].nom, 4, 7, STATIC_COMPONENT );
   netlist[11] = netlist_component( Netlist_C, p[INDEX_CDS].nom, 6, 7, STATIC_COMPONENT );
   netlist[12] = netlist_component( Netlist_R, p[INDEX_RI].nom, 5, 6, STATIC_COMPONENT );
   netlist[13] = netlist_component( Netlist_G, p[INDEX_GGS].nom, 4, 5, STATIC_COMPONENT );
   netlist[14] = netlist_component( Netlist_G, p[INDEX_GGD].nom, 4, 7, STATIC_COMPONENT );
   netlist[15] = netlist_component( Netlist_VCCS, p[INDEX_GM].nom, p[INDEX_TAU1].nom, 4, 5, 7, 6, STATIC_COMPONENT, STATIC_COMPONENT );
   netlist[16] = netlist_component( Netlist_VCCS, p[INDEX_GDS].nom, p[INDEX_TAU2].nom, 7, 6, 7, 6, STATIC_COMPONENT, STATIC_COMPONENT );
   nlist = prepare_netlist( netlist, 17 );

   // load S-parameter data
   n_meas_f = read_s_from_file (meas_name, s_meas, NULL, MAX_FREQS);
   if( n_meas_f < 0 ) {
      error_msg( "%s: file not found.", meas_name);
      return -1;
   }
   else if( n_meas_f < 1 ) {
      error_msg( "%s: file read error. No data.", meas_name);
      return -1;
   }

    // create modeled data
   for( i=0; i<n_meas_f; ++i ) {
      freq[i] = s_meas[i].freq * 1.0e-9;
      s_mod[i].freq = s_meas[i].freq;
      small_signal_model( nlist, s_meas[i].freq, s );
      s_mod[i].s[0] = s[0];
      s_mod[i].s[1] = s[1];
      s_mod[i].s[2] = s[2];
      s_mod[i].s[3] = s[3];
      k_mag(s_mod[i].s, &s_mod[i].k, &s_mod[i].MAG, &s_mod[i].b);
   }

   // create the plot header information
   i = 0;
   head[0] = 0;
   file = fopen (meas_name, "r");
   while (fgets (string, 255, file))
   {
      if ((string[0] != '!') || (++i > 20) || !strncmp (string, "!COMMENTS", 9))
         break;
      strcat (head, &string[1]);
   }
   while (fgets (string, 255, file))
   {
      if (string[0] != '!')
         break;
      else if (!strncmp (string, "!BIAS", 5)) {
         strcat( head, "\n" );
         strcat (head, &string[1]);
         break;
      }
   }
   fclose (file);

   head2[0] = 0;
   sprintf( string, "RG  = %.3e    RD  = %.3e    RS  = %.3e    C1  = %.3e\n", p[INDEX_RG].nom, p[INDEX_RD].nom, p[INDEX_RS].nom, p[INDEX_C1].nom );
   strcat( head2, string );
   sprintf( string, "LG  = %.3e    LD  = %.3e    LS  = %.3e    C2  = %.3e\n", p[INDEX_LG].nom, p[INDEX_LD].nom, p[INDEX_LS].nom, p[INDEX_C2].nom );
   strcat( head2, string );
   sprintf( string, "C11 = %.3e    C22 = %.3e    GGS = %.3e    GDG = %.3e\n", p[INDEX_C11].nom, p[INDEX_C22].nom, p[INDEX_GGS].nom, p[INDEX_GGD].nom );
   strcat( head2, string );
   sprintf( string, "CGS = %.3e    CDG = %.3e    CDS = %.3e    RI  = %.3e\n", p[INDEX_CGS].nom, p[INDEX_CGD].nom, p[INDEX_CDS].nom, p[INDEX_RI].nom );
   strcat( head2, string );
   sprintf( string, "GM  = %.3e    TAU = %.3e    GDS = %.3e    TAU2= %.3e\n", p[INDEX_GM].nom, p[INDEX_TAU1].nom, p[INDEX_GDS].nom, p[INDEX_TAU2].nom );
   strcat( head2, string );

   header1 = add_text (head, 1.0, 8.0, FNT_HELVETICA, 9, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE);
   header2 = add_text (head2, 4.0, 8.0, FNT_COURIER, 10, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE);
   legend1 = add_legend (4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);

   // draw the plots
   if (!open_graphics_device (device, "fetmodel.ps")) {
      error_msg( "jPlot error: %s", get_error_message(ERROR_NUMBER) );
      return -1;
   }

   plot1 = create_plot_item (DoubleY, 1.5, 1.25, 5.0, 4.0);
   set_axis_labels (plot1, "Frequency (GHz)", "Magnitude", "Phase", "");

   // cycle through the different plots

   for( i=0; i<6; ++i ){
      switch (i)
      {
      case 0:  // S11
         for( j=0; j < n_meas_f; ++j ) {
            mod_mag[j] = Cmag (s_mod[j].s[0]);
            mod_ang[j] = Cangle (s_mod[j].s[0]);
            meas_mag[j] = Cmag (s_meas[j].s[0]);
            meas_ang[j] = Cangle (s_meas[j].s[0]);
         }
         title1 = add_text ("S11", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 1:  // S21
         for( j=0; j < n_meas_f; ++j ) {
            mod_mag[j] = Cmag (s_mod[j].s[2]);
            mod_ang[j] = Cangle (s_mod[j].s[2]);
            meas_mag[j] = Cmag (s_meas[j].s[2]);
            meas_ang[j] = Cangle (s_meas[j].s[2]);
         }
         title1 = add_text ("S21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 2:  // S12
         for( j=0; j < n_meas_f; ++j ) {
            mod_mag[j] = Cmag (s_mod[j].s[1]);
            mod_ang[j] = Cangle (s_mod[j].s[1]);
            meas_mag[j] = Cmag (s_meas[j].s[1]);
            meas_ang[j] = Cangle (s_meas[j].s[1]);
         }
         title1 = add_text ("S12", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 3:  // S22
         for( j=0; j < n_meas_f; ++j ) {
            mod_mag[j] = Cmag (s_mod[j].s[3]);
            mod_ang[j] = Cangle (s_mod[j].s[3]);
            meas_mag[j] = Cmag (s_meas[j].s[3]);
            meas_ang[j] = Cangle (s_meas[j].s[3]);
         }
         title1 = add_text ("S22", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 4:  // K and MAG
         for( j=0; j < n_meas_f; ++j ) {
            mod_mag[j] = s_mod[j].MAG;
            mod_ang[j] = s_mod[j].k;
            meas_mag[j] = s_meas[j].MAG;
            meas_ang[j] = s_meas[j].k;
         }
         set_axis_labels (plot1, "Frequency (GHz)", "MAG/MSG (dB)", "K-Factor", "");
         remove_user_item (legend1);
         legend1 = add_legend (4, 8.0, 4.0, legend_text2, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);
         title1 = add_text ("MAG/MSG\nand\nK-Factor", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;

      case 5:  // H21
         for( j=0; j < n_meas_f; ++j ) {
            s2h (s_mod[j].s, s_mod[j].s, 50.0);
            mod_mag[j] = 20.0 * log10 (Cmag (s_mod[j].s[2]));
            mod_ang[j] = Cangle (s_mod[j].s[2]);
            s2h (s_meas[j].s, s_meas[j].s, 50.0);
            meas_mag[j] = 20.0 * log10 (Cmag (s_meas[j].s[2]));
            meas_ang[j] = Cangle (s_meas[j].s[2]);
         }
         set_axis_labels (plot1, "Frequency (GHz)", "Magnitude (dB)", "Angle", "");
         set_axis_scaling (plot1, LogX);
         remove_user_item (legend1);
         legend1 = add_legend (4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);
         title1 = add_text ("H21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
         break;
      }

      attach_y1data (plot1, freq, mod_mag, n_meas_f, LT_SOLID, 1, CLR_RED);
      attach_y2data (plot1, freq, mod_ang, n_meas_f, LT_DASHED, 1, CLR_RED);
      attach_y1data (plot1, freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
      attach_y2data (plot1, freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);

      if (!draw_page ()) {
         error_msg( "jPlot error: %s", get_error_message(ERROR_NUMBER) );
         close_graphics_device ();
         return -1;
      }

      detach_data (plot1);
      remove_user_item (title1);
   }

   close_graphics_device ();
   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

static void print_direct_values( COMPLEX y[][4], double *freq, int szy );
static int yfit_capacitance( COMPLEX y[][4], double *freq, int szy, OPT_PARAMETER* p,
    double cgs_fmin, double cgs_fmax, double periph_sf );
static int yfit_ri_and_tau( COMPLEX y[][4], double *freq, int szy, OPT_PARAMETER *p,
    double ri_fmin, double ri_fmax, double periph_sf );
static int yfit_ggs_ggd( COMPLEX y[][4], double *freq, int szy, OPT_PARAMETER *p,
    double ggs_fmin, double ggs_fmax );
static void ggs_s11_fit( double *w, double *s11, int n, OPT_PARAMETER *p, double *ggs );


/*******************************************************************************************/
/*******************************************************************************************/
static int yfitv500_main( YFITV500_INPUTS *inp, unsigned flags )
{
   char string[256];
   char file_name[256];
   char starting_vals[256];
   char finishing_vals[256];
   int i, numf;
   double flist[MAX_FREQS];
   double cgs_fmin, cgs_fmax, ri_fmin, ri_fmax, ggs_fmin, ggs_fmax, sf;
   COMPLEX yparms[MAX_FREQS][4];
   S_2PORT sparams[MAX_FREQS];
   OPT_PARAMETER p[n_fet_params];
   S_BIAS bias;
   MODEL_PARAMS *params;
   FILE *f;

   if (inp){
      strcpy( file_name, inp->fname );
      strcpy( starting_vals, inp->start_val );
      strcpy( finishing_vals, inp->finish_val );
   }
   else {
      printf ("File to Y-Fit?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", file_name);

      printf ("Starting values file name?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", starting_vals);

      printf ("Finishing values file name?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", finishing_vals);
   }

   // read in the S-params
   numf = read_s_from_file( file_name, sparams, &bias, MAX_FREQS );
   if( numf < 0 ) {
      error_msg( "%s: file not found.", file_name );
      return -1;
   }
   else if( numf == 0 ) {
      error_msg( "%s: file read error. No data.", file_name );
      return -1;
   }

   // get the periphery
   sf = 1.;
   f = fopen( file_name, "r" );
   if( f ){
      while( fgets( string, 255, f ) ) {
         if( string[0] != '!' )
            break;

         // calculate the periphery scale factor
         if( !strncmp( string, "!GATE PERIPHERY (um):", 21 ) ) {
            sscanf( string, "!GATE PERIPHERY (um): %lf", &sf );
            sf *= 1.e-3;
            break;
         }
      }
      fclose(f);
   }

   // read in starting parameter values
   if( read_model_parameters_from_file(starting_vals, &params, NULL) )
      return 1;
   if( get_all_parameters(global_fet_params, n_fet_params, params, p) )
      return 1;

   // replace parameters based on cmdline inputs
   correct_parameters( p, flags );

   // deembed the fixed parasitics
   remove_fet_parasitics( sparams, numf, p );

   // create the Y-parameter array
   for( i=0; i<numf; i++ ) {
      s2y( sparams[i].s, yparms[i], 50. );
      flist[i] = sparams[i].freq;
   }

   if( !inp ) {
      // print directly extracted values
      print_direct_values( yparms, flist, numf );

      // get frequency ranges
      printf ("Frequency range for Cgs, Cgd, Cds, Gm and Gds calculations in GHz (min max)?\n");
      fgets (string, 255, stdin);
      if( sscanf(string, "%lf%lf", &cgs_fmin, &cgs_fmax) != 2 )
      {
         error_msg( "Failed to read CGS Y-fit frequency range." );
         return -1;
      }
      cgs_fmin *= 1.0e9;
      cgs_fmax *= 1.0e9;

      printf ("Frequency range for Ri and Tau calculations in GHz (min max)?\n");
      fgets (string, 255, stdin);
      if (sscanf (string, "%lf%lf", &ri_fmin, &ri_fmax) != 2)
      {
         error_msg( "Failed to read RI Y-fit frequency range." );
         return -1;
      }
      ri_fmin *= 1.0e9;
      ri_fmax *= 1.0e9;

      printf ("Frequency range for Ggs and Ggd calculations in GHz (min max)?\n");
      fgets (string, 255, stdin);
      if (sscanf (string, "%lf%lf", &ggs_fmin, &ggs_fmax) != 2)
      {
         error_msg( "Failed to read GGS Y-fit frequency range." );
         return -1;
      }
      ggs_fmin *= 1.0e9;
      ggs_fmax *= 1.0e9;
   }
   else {
      cgs_fmin = inp->cgs_fmin;
      cgs_fmax = inp->cgs_fmax;
      ri_fmin = inp->ri_fmin;
      ri_fmax = inp->ri_fmax;
      ggs_fmin = inp->ggs_fmin;
      ggs_fmax = inp->ggs_fmax;
   }

    // do the y-fits
    if( yfit_capacitance( yparms, flist, numf, p, cgs_fmin, cgs_fmax, sf ) ||
        yfit_ri_and_tau( yparms, flist, numf, p, ri_fmin, ri_fmax, sf ) ||
        yfit_ggs_ggd( yparms, flist, numf, p, ggs_fmin, ggs_fmax ) )
        return 1;

    if( !(flags & EXTRACT_TAU2) ) {
        // set tau2 to 0
        set_parm( p, INDEX_TAU2, 0., 0., 0., 0., 0. );
    }


   // print the final values to the screen
   if (!inp) {
      printf ("\n");
      printf (" Cgs     Gds    Cds    Cgd     Ri      Gm      T1      Ggd     T2      Ggs\n");
      printf (" (pF)    (mS)   (pF)   (pF)   (ohm)    (mS)    (ps)    (mS)    (ps)    (mS)\n");
      printf ("----------------------------------------------------------------------------\n");
      //       |    | |     | |    | |    | |     | |     | |     | |     | |     | |     |

      printf ("%6.3f %7.2f %6.3f %6.3f %7.3f %7.2f %7.2f %7.2f %7.2f %7.2f\n",
         p[INDEX_CGS].nom*1.0e12, p[INDEX_GDS].nom*1.0e3, p[INDEX_CDS].nom*1.0e12,
         p[INDEX_CGD].nom*1.0e12, p[INDEX_RI].nom, p[INDEX_GM].nom*1.0e3,
         p[INDEX_TAU1].nom*1.0e12, p[INDEX_GGD].nom*1.0e3, p[INDEX_TAU2].nom*1.0e12,
         p[INDEX_GGS].nom*1.0e3);
   }

   debug_print_params( p, "after-yfit.dbg" );


    // write the final parameter values
    if( set_all_parameters (params, p, n_fet_params) ||
        write_model_parameters_to_file (params, finishing_vals) )
        return 1;

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static void print_direct_values( COMPLEX y[][4], double *freq, int szy ) {
   int i;
   double w, cgs, gds, cds, cgd, ggd, ri, t1, gm;
   COMPLEX x;
   int inc = 1;

   // set a decent increment so that there is not 17 pages of data
   //  printed to the terminal
   while( szy / inc > 40 ) ++inc;

   // print the values of direct parameter extraction to the terminal

   printf ("\n");
   printf (" Freq   Cgs     Gds    Cds    Cgd     Ri      Gm      T1      Ggd\n");
   printf (" (GHz)  (pF)    (mS)   (pF)   (pF)   (ohm)    (mS)    (ps)    (mS)\n");
   printf ("-------------------------------------------------------------------\n");
   //       |    | |    | |     | |    | |    | |     | |     | |     | |     |

   for( i=0; i<szy; i += inc ) {
      w = 2.0 * M_PI * freq[i];

      cgs = -1.0 / ( w * Cimag( Cdiv( Complex(1.0), Cadd( y[i][0], y[i][1] ) ) ) );
      gds = y[i][3].r + y[i][1].r;
      cds = (y[i][3].i + y[i][1].i) / w;
      cgd = -y[i][1].i / w;
      ggd = -y[i][1].r;
      ri = Creal( Cdiv( Complex(1.0), Cadd( y[i][0], y[i][1] ) ) );
      x = Cdiv( Csub( y[i][2], y[i][1] ), Cadd( y[i][0], y[i][1] ) );
      x = Cmult( x, Cnum( 0., w * cgs ) );
      gm = Cmag(x);
      t1 = -atan2( x.i, x.r ) / w;

      printf ("%6.3f %6.3f %7.2f %6.3f %6.3f %7.3f %7.2f %7.2f %7.2f\n",
         freq[i]*1.0e-9, cgs*1.0e12, gds*1.0e3, cds*1.0e12,
         cgd*1.0e12, ri, gm*1.0e3, t1*1.0e12, ggd*1.0e3);
   }

   printf ("\n");
}

/******************************************************************************************/
/******************************************************************************************/
static int yfit_capacitance( COMPLEX y[][4], double *freq, int szy, OPT_PARAMETER* p,
    double cgs_fmin, double cgs_fmax, double periph_sf )
{
   double w;
   double cgsl = 0.;
   double cgdl = 0.;
   double cdsl = 0.;
   double gdsl = 0.;
   double gml = 0.;
   int i, n;
   /*
   double x1 = 0.;
   double x2 = 0.;
   double x3 = 0.;
   double x4 = 0.;
   COMPLEX x;
   */


   /******* y-fit of gds, cgs, cgd, and cds ******/
   for( i=0, n=0; i<szy; i++ ) {
      if( freq[i] < cgs_fmin )
         continue;
      else if( freq[i] > cgs_fmax )
         break;

      w = 2.0 * M_PI * freq[i];
      cgdl += -y[i][1].i / w;
      cdsl += Cimag( Cadd(y[i][3],y[i][1]) ) / w;
      cgsl += -1 / ( w * Cimag( Cdiv( Complex(1.), Cadd(y[i][0],y[i][1]) ) ) );
      gdsl += Creal( Cadd(y[i][3],y[i][1]) );
      ++n;
   }

   if( !n ) {
      error_msg( "Invalid frequency range for CGS/CGD/CDS/GM/GDS fit." );
      return 1;
   }

   cgdl /= (double) n;
   cgsl /= (double) n;
   cdsl /= (double) n;
   gdsl /= (double) n;

   /******* y-fit of gm (needed Cgs before it could be computed) ******/
   for( i=0, n=0; i<szy; i++ ) {
      if( freq[i] < cgs_fmin )
         continue;
      else if( freq[i] > cgs_fmax )
         break;

      w = 2.0 * PI * freq[i];
      gml += Cmag( Cmult( Cdiv( Csub(y[i][2],y[i][1]), Cadd(y[i][0],y[i][1]) ), Cnum(0.,w*cgsl) ) );
      /*
      x = Cdiv (Cadd (y[i][0], y[i][1]), Csub (y[i][2], y[i][1]));
      tmpd = Cmag2( Csub(y[i][2], y[i][1]) );
      w2 = wl[n] * wl[n];
      x1 += tmpd;
      x2 += tmpd * tmpd * w2 * w2;
      x3 += tmpd * w2;
      x4 += tmpd * tmpd * w2;
      */
      ++n;
   }

   gml /= (double) n;

   // gm = sqrt( fabs(x1*x2 - x3*x4) / ( ((double) n)*x2 - x3*x3 ) );

   set_parm( p, INDEX_GM, gml, 0.5, 1.5, 0., 0. );
   set_parm( p, INDEX_CGD, cgdl, 0.8, 1.2, 0., 0. );
   set_parm( p, INDEX_CDS, cdsl, 0.8, 1.2, 0., 0. );
   set_parm( p, INDEX_CGS, cgsl, 0.8, 1.2, 0., 0. );
   set_parm( p, INDEX_GDS, gdsl, 0., 4., 0., 5.e-4*periph_sf );

   return 0;
}

/******************************************************************************************/
/******************************************************************************************/
static int yfit_ri_and_tau( COMPLEX y[][4], double *freq, int szy, OPT_PARAMETER *p,
    double ri_fmin, double ri_fmax, double periph_sf )
{
    int i, n;
    double ri = 0.;
    double tau  = 0.;
    double tau2 = 0.;
    double w;
    COMPLEX x;

    /******* y-fit of ri and tau ******/
    for( i=0, n=0; i<szy; i++ ) {
        if( freq[i] < ri_fmin )
            continue;
        else if( freq[i] > ri_fmax )
            break;

        w = 2. * M_PI * freq[i];
        ri += Creal( Cdiv( Complex(1.), Cadd (y[i][0], y[i][1]) ) );
        x = Cmult( Cdiv( Csub(y[i][2],y[i][1]), Cadd(y[i][0],y[i][1]) ), Cnum(0.,w*p[INDEX_CGS].nom) );
        tau -= atan2(x.i, x.r) / w;
        x = Csub( Cadd(y[i][3],y[i][1]), Cnum(0.,w*p[INDEX_CDS].nom) );
        tau2 -= atan2(x.i, x.r) / w;
        /*
        d1 = -1.0/(wl[n] * Cimag( Cdiv (Complex (1.0), Cadd(y[i][0],y[i][1])) ));
        c1 = Cmult (Cdiv (Csub (y[i][2], y[i][1]), Cadd (y[i][0], y[i][1])), Cnum (0.0, wl[n] * d1));
        taul[n] = -atan2( c1.i, c1.r );
        */
        ++n;
    }

    if( !n ) {
        error_msg( "Invalid frequency range for RI/TAU y-fit." );
        return 1;
    }

    ri /= (double) n;
    tau /= (double) n;
    tau2 /= (double) n;

    set_parm( p, INDEX_RI, ri, 0.5, 1.5, 1.e-3, 0. );

    if( p[INDEX_GM].nom > 1.e-4*periph_sf )
        set_parm( p, INDEX_TAU1, tau, 0.7, 1.3, 0., 0. );
    else set_parm( p, INDEX_TAU1, 0., 0., 0., 0., 0. );

    if( p[INDEX_GDS].nom > 1.e-5*periph_sf )
         set_parm( p, INDEX_TAU2, tau2, 0.5, 1.5, 0., 0. );
    else set_parm( p, INDEX_TAU2, 0., 0., 0., 0., 0. );

    return 0;
}

/******************************************************************************************/
/******************************************************************************************/

static int yfit_ggs_ggd( COMPLEX y[][4], double *freq, int szy, OPT_PARAMETER *p,
    double ggs_fmin, double ggs_fmax )
{
    int i, n, m;
    COMPLEX s[4];
    double s11m[20];
    double wl[20];
    double ggd = 0.;
    double ggs = 0.;

    /******* fit of ggd *******/
    for( i=0, n=0, m=0; i<szy; i++ ) {
        if( freq[i] < ggs_fmin )
            continue;
        else if( freq[i] > ggs_fmax )
            break;

        ggd -= y[i][1].r;

        if( m < 20 ) {
            wl[m] = 2. * PI * freq[i];
            y2s( y[i], s, 50.0 );
            s11m[m] = Cmag(s[0]);
            ++m;
        }
        ++n;
    }

    if( !n ) {
        error_msg( "Invalid frequency range for GGS/GGD y-fit." );
        return 1;
    }

    ggd /= (double) n;
    set_parm( p, INDEX_GGD, ggd, 0., 5., 0., 0. );

    /******* fit of ggs *******/
    ggs_s11_fit( wl, s11m, m, p, &ggs );
    set_parm( p, INDEX_GGS, ggs, 0., 5., 0., 0. );

    return 0;
}


/******************************************************************************************/
/******************************************************************************************/

static double get_s11_error( double *w, double *s11, unsigned n, OPT_PARAMETER *p, double ggs )
{
   unsigned i;
   COMPLEX y[4], s[4];
   double err = 0.0;
   double s11mod;

   for( i=0; i<n; i++ ) {
      y[1].r = -p[INDEX_GGD].nom;
      y[1].i = -w[i] * p[INDEX_CGD].nom;

      y[0] = Csub (Cdiv (Complex (1.0), Cadd (Complex (p[INDEX_RI].nom), Cdiv (Complex (1.0), Cnum (ggs, w[i] * p[INDEX_CGS].nom)))), y[1]);

      y[3] = Csub (Cadd (Cnum (p[INDEX_GDS].nom * cos (-w[i] * p[INDEX_TAU2].nom), p[INDEX_GDS].nom * sin (-w[i] * p[INDEX_TAU2].nom)), Cnum (0.0, w[i] * p[INDEX_CDS].nom)), y[1]);

      y[2] = Cmult (Cnum (p[INDEX_GM].nom * cos (-w[i] * p[INDEX_TAU1].nom), p[INDEX_GM].nom * sin (-w[i] * p[INDEX_TAU1].nom)), Cadd (y[0], y[1]));
      y[2] = Cadd (Cdiv (y[2], Cnum (ggs, w[i] * p[INDEX_CGS].nom)), y[1]);

      y2s (y, s, 50.0);
      s11mod = Cmag(s[0]);

      if( s11mod < s11[i] ) return -1.;

      err += s11mod - s11[i];
   }

   return err;
}

/******************************************************************************************/
/******************************************************************************************/

static void ggs_s11_fit( double *w, double *s11, int n, OPT_PARAMETER *p, double *ggs )
{
   double last;
   double err;
   double ggs_inc = 1.e-5;
   int i = 0;

   *ggs = 0.;

   if( n < 1 )
      return;

   err = get_s11_error (w, s11, n, p, *ggs );
   do {
      ++i;
      last = err;
      *ggs += ggs_inc;
      err = get_s11_error (w, s11, n, p, *ggs );
   }
   while( err > 0. && err <= last && i < 1000 );
   *ggs -= ggs_inc;
}

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

static void error_msg( const char *fmt, ... )
{
   va_list arg;
   FILE *f;

   if( global_errstream == stderr )
      f = global_errstream;
   else
      f = fopen( ERROR_FILE_NAME, "a" );

   if( f )
   {
      va_start( arg, fmt );
      vfprintf( f, fmt, arg );
      va_end( arg );

      fputc( '\n', f );
      fflush( f );
      if( f != stderr )
         fclose( f );
   }
}

