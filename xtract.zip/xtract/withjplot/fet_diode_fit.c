#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"

#define BOLTZ         1.3806226e-23
#define CHARGE        1.6021918e-19
#define STDTEMP       300.0

#define MAX_IV_PTS    1000

/*****************************************************************************/
/*****************************************************************************/

static int a_x_b (double *a, double *x, double *b, int n)
   {
   double   y[50];
   double   z[50][50];
   double   tempd;
   double   tempd2;
   double   max;
   int      pointer[50];
   int      tempi;
   int      i,j,k;
   int      col,row;
   
   for (i = 0; i < n; ++i)
      {
      y[i] = b[i];
      pointer[i] = i;
      for (j = 0; j < n; ++j)
         z[i][j] = a[i*n+j];
      }
   
   /* invert the matrix */
   for (k = 0; k < n-1; ++k)
      {
      /* find max */
      max = 0.0;
      for (i = k; i < n; ++i)
         {
         for (j = k; j < n; ++j)
            {
            if (fabs (z[i][j]) > max)
               {
               row = i;
               col = j;
               max = fabs (z[i][j]);
               }
            }
         }
      
      /* rotate rows */
      if (row != k)
         {
         for (j = 0; j < n; ++j)
            {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
            }
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
         }
      
      /* rotate columns */ 
      if (col != k)
         {
         for (i = 0; i < n; ++i)
            {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
            }
         tempi = pointer[k];
         pointer[k] = pointer[col];
         pointer[col] = tempi;
         }
      
      /* gaussian elimination */
      tempd = z[k][k];
      for (i = k+1; i < n; ++i)
         {
         tempd2 = z[i][k]/tempd;
         y[i] -= tempd2*y[k];
         for (j = k; j < n; ++j)
            {
            z[i][j] -= tempd2*z[k][j];
            }
         }
      }  
   
   if (fabs (z[n-1][n-1]) < 1.0e-24)
      return -1;
   
   /* back substitution */
   x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
   for (k = n-2; k > -1; --k)
      {
      tempd = y[k];
      for (i = n-1; i > k; --i)
         tempd -= z[k][i]*x[pointer[i]];
      
      x[pointer[k]] = tempd/z[k][k];
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_fit (double *vd, double *id, int k, double *is, double *n, double *rd)
   {
   double   a1[3][MAX_IV_PTS];
   double   a2[MAX_IV_PTS][3];
   double   b1[MAX_IV_PTS];
   double   a[3][3];
   double   b[3];
   double   x[3];
   double   sum;
   int      i,j;
   int      npts;

   j = 0;
   for (i = 0; i < k; ++i)
      {
      if( vd[i] < 0.5 )
         continue;
      
      a2[j][0] = log (id[i]);
      a2[j][1] = -1.0;
      a2[j][2] = id[i];
      a1[0][j] = a2[j][0];
      a1[1][j] = a2[j][1];
      a1[2][j] = a2[j][2];
      b1[j] = vd[i];
      ++j;
      }
   
   if (j < 3)
      {
      fprintf (stderr,"Not enough points for diode fit.\n");
      return -1;
      }
   
   npts = j;
   
   for (i = 0; i < 3; ++i)
      {
      for (j = 0; j < 3; ++j)
         {
         sum = 0.0;
         for (k = 0; k < npts; ++k)
            sum += a1[i][k]*a2[k][j];
         
         a[i][j] = sum;
         }
      }
   
   for (i = 0; i < 3; ++i)
      {
      sum = 0.0;
      for (j = 0; j < npts; ++j)
         sum += a1[i][j]*b1[j];
      
      b[i] = sum;
      }
   
   if (a_x_b ((double *)a,x,b,3) < 0)
      {
      fprintf (stderr,"Singular matrix in diode fit.\n");
      return -1;
      }
   
   *n = x[0]*CHARGE/(BOLTZ*STDTEMP);
   *is = exp (x[1]/x[0]);
   *rd = x[2];
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

int main ()
   {
   FILE   *infile;
   char   filename[200];
   char   string[200];
   int    i;
   double is,n,rd,v1,v2,i1,i2;
   double vd[1000],id[1000];
   double linex[2],liney[2];
   jPLOT_ITEM *plot1;
   
   printf ("Diode file to fit?\n> ");
   fgets (string,199,stdin);
   sscanf (string,"%s",filename);
   
   infile = fopen (filename,"r");
   if (!infile)
      {
      printf ("Unable to open file %s\n",filename);
      return -1;
      }
      
   i = 0;
   while (fgets (string,199,infile))
   {
      if (string[0] == '!')
         continue;
      
      if (sscanf (string,"%lf%lf%lf%lf",&v1,&i1,&v2,&i2) == 4)
      {
	 if( v1 == 0. ) {
            vd[i] = v2;
            id[i] = i2;
            ++i;
	 }
      }
   }
   fclose (infile);
   
   diode_fit (vd,id,i,&is,&n,&rd);
   
   printf ("Is  = %.4e\n",is);
   printf ("n   = %.3f\n",n);
   printf ("Rd  = %.3f\n",rd);
   
   open_graphics_device (X_WINDOWS,"");
   
   plot1 = create_plot_item (SingleY,2.5,1.75,6.0,6.0);
   
   attach_y1data (plot1,vd,id,i,LT_SOLID,2,CLR_RED);
   set_axis_scaling (plot1,LogY1);
   
   set_axis_labels (plot1,"Vd (volts)","Id (amps)","","Diode Characteristic");
   
   linex[0] = vd[0];
   linex[1] = vd[i-1];
   liney[0] = is*(exp (vd[0]*CHARGE/(BOLTZ*n*STDTEMP))-1.);
   liney[1] = is*(exp (vd[i-1]*CHARGE/(BOLTZ*n*STDTEMP))-1.0);

   attach_y1data (plot1,linex,liney,2,LT_DASHED,1,CLR_GREEN);
   
   draw_page ();
   
   close_graphics_device ();
   
   return 0;
   }    
         





