#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "jplot.h"

#define MAX_PTS   900
#define MAX_FILES  1000

struct BIAS
{
   double vds,ids,vgs,igs;
   int mode;
};

static int read_s_params( FILE *infile, double *flist, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                         double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts, int *n, int dbret );
static double satan2( double y, double x );

void print_usage( char * progname ) 
{
   printf( "\nUSAGE: %s [options] file1 [file2 ...]\n\n", progname );
   printf( "  Options:\n" );
   printf( "     -wmf, -meta   Set output device to metafile.\n" );
   printf( "     -ps           Set output device to postscript.\n" );
   printf( "     -o name       Set plot file name to \'name\'.\n" );
   printf( "     -db           Plot in dB.\n" );
   printf( "\n" );

}

/*********************************************************************************************/
/*********************************************************************************************/

int main( int argc, char *argv[] )
{
   FILE *file;
   jPLOT_ITEM *plot11, *plot12, *plot21, *plot22;
   jPLOT_ATTRIBS attribs1;
   jHANDLE legend1, bias_line, filename;
   int npts, i;
   char string[200];
   int pdevice = X_WINDOWS;
   int no_phase = 0;
   int db_mode = 0;
   double flist[MAX_PTS];
   double s11m[MAX_PTS];
   double s12m[MAX_PTS];
   double s21m[MAX_PTS];
   double s22m[MAX_PTS];
   double s11a[MAX_PTS];
   double s12a[MAX_PTS];
   double s21a[MAX_PTS];
   double s22a[MAX_PTS];
   struct BIAS bias;
   static char *legend_tdb[] = { "[S] (dB)", "[S] Phase" };
   static char *legend_t[] = { "[S] Mag", "[S] Phase" };
   static int legend_l[] = { LT_SOLID, LT_DASHED };
   static int legend_w[] = { 1, 1 };
   static int legend_c[] = { CLR_RED, CLR_BLUE };
   char pname[256];
   char *file_list[MAX_FILES];
   int fcount=0;

   strcpy(pname,"plotfile.ps");

   if( argc < 2 ) {
      print_usage(argv[0]);
      exit(0);
   }

   /* parse the command line */
   for( i=1; i<argc; ++i ) {
      if( argv[i][0] == '-' ) {
         if( !strcmp(argv[i],"-ps") || !strcmp(argv[i],"-dP") ) pdevice = POSTSCRIPT; 
         else if( !strcmp( argv[i],"-meta") || !strcmp(argv[i],"-wmf") || !strcmp(argv[i],"-dM") ) pdevice = METAFILE;
         else if( !strcmp(argv[i],"-db") || !strcmp(argv[i],"-dB") ) db_mode = 1;
         else if( !strcmp(argv[i],"-np") ) no_phase = 1;
         else if( !strcmp(argv[i],"-o") ) {
            if( i==argc-1 ) {
               fprintf(stderr,"Error: missing parameter for -o option.\n" );
               print_usage(argv[0]);
               exit(1);
            }
            strcpy(pname,argv[++i]);
         }
         else {
            fprintf(stderr,"Error: illegal option: %s\n", argv[i] );
            print_usage(argv[0]);
            exit(1);
         }
      }
      else {
         if( fcount >= MAX_FILES ) {
            fprintf( stderr, "Warning: MAX_FILES exceeded.\n" );
            continue;
         }
         file_list[fcount++] = argv[i];
      }
   }

   if( !open_graphics_device( pdevice, pname ) ) {
      printf( "Error: failed to open the graphics device.\n" );
      return 1;
   }

   if( no_phase )
   {
      plot11 = create_plot_item( SingleY, 1.2, 4.70, 3.5, 2.75 );
      plot12 = create_plot_item( SingleY, 6.3, 4.70, 3.5, 2.75 );
      plot21 = create_plot_item( SingleY, 1.2, 1.00, 3.5, 2.75 );
      plot22 = create_plot_item( SingleY, 6.3, 1.00, 3.5, 2.75 );
      if( db_mode )
      {
         set_axis_labels( plot11, "Freq (GHz)", "dB(S11)", "", "S11" );
         set_axis_labels( plot12, "Freq (GHz)", "dB(S12)", "", "S12" );
         set_axis_labels( plot21, "Freq (GHz)", "dB(S21)", "", "S21" );
         set_axis_labels( plot22, "Freq (GHz)", "dB(S22)", "", "S22" );
         legend1 = add_legend( 1, 0.5, 8.1, legend_tdb, FNT_HELVETICA, 12, legend_l, legend_w, legend_c );
      }
      else
      {
         set_axis_labels( plot11, "Freq (GHz)", "mag(S11)", "", "S11" );
         set_axis_labels( plot12, "Freq (GHz)", "mag(S12)", "", "S12" );
         set_axis_labels( plot21, "Freq (GHz)", "mag(S21)", "", "S21" );
         set_axis_labels( plot22, "Freq (GHz)", "mag(S22)", "", "S22" );
         legend1 = add_legend( 1, 0.5, 8.1, legend_t, FNT_HELVETICA, 12, legend_l, legend_w, legend_c );
      }
   }
   else
   {
      plot11 = create_plot_item( DoubleY, 1.2, 4.70, 3.5, 2.75 );
      plot12 = create_plot_item( DoubleY, 6.3, 4.70, 3.5, 2.75 );
      plot21 = create_plot_item( DoubleY, 1.2, 1.00, 3.5, 2.75 );
      plot22 = create_plot_item( DoubleY, 6.3, 1.00, 3.5, 2.75 );
      if( db_mode )
      {
         set_axis_labels( plot11, "Freq (GHz)", "dB(S11)", "phase(S11)", "S11" );
         set_axis_labels( plot12, "Freq (GHz)", "dB(S12)", "phase(S12)", "S12" );
         set_axis_labels( plot21, "Freq (GHz)", "dB(S21)", "phase(S21)", "S21" );
         set_axis_labels( plot22, "Freq (GHz)", "dB(S22)", "phase(S22)", "S22" );
         legend1 = add_legend( 2, 0.5, 8.1, legend_tdb, FNT_HELVETICA, 12, legend_l, legend_w, legend_c );
      }
      else
      {
         set_axis_labels( plot11, "Freq (GHz)", "mag(S11)", "phase(S11)", "S11" );
         set_axis_labels( plot12, "Freq (GHz)", "mag(S12)", "phase(S12)", "S12" );
         set_axis_labels( plot21, "Freq (GHz)", "mag(S21)", "phase(S21)", "S21" );
         set_axis_labels( plot22, "Freq (GHz)", "mag(S22)", "phase(S22)", "S22" );
         legend1 = add_legend( 2, 0.5, 8.1, legend_t, FNT_HELVETICA, 12, legend_l, legend_w, legend_c );
      }
   }

   attribs1.xlabel_offset = 0.3;
   attribs1.ylabel_offset = 0.55;
   attribs1.title_offset = 0.15;
   attribs1.label_tsize = 12;
   attribs1.title_tsize = 16;
   attribs1.axis_tsize = 10;
   attribs1.label_font = FNT_HELVETICA;
   attribs1.title_font = FNT_HELVETICA;
   attribs1.axis_font = FNT_HELVETICA;
   set_plot_item_attributes( plot11, &attribs1, JPA_LABELOFFSETS | JPA_FONTS | JPA_TEXTSIZE );
   set_plot_item_attributes( plot12, &attribs1, JPA_LABELOFFSETS | JPA_FONTS | JPA_TEXTSIZE );
   set_plot_item_attributes( plot21, &attribs1, JPA_LABELOFFSETS | JPA_FONTS | JPA_TEXTSIZE );
   set_plot_item_attributes( plot22, &attribs1, JPA_LABELOFFSETS | JPA_FONTS | JPA_TEXTSIZE );

   for( i=0; i<fcount; ++i ) {
      file = fopen( file_list[i], "r" );
      if( !file ) {
         printf( "Warning: %s: file not found.\n", file_list[i] );
         continue;
      }

      sprintf( string, "File: %s", file_list[i] );
      filename = add_text( string, 0.5, 0.35, FNT_HELVETICA, 8, 0.0, LEFT_JUSTIFY, CLR_BLACK, 0 );

      do {
         read_s_params( file, flist, s11m, s11a, s12m, s12a, s21m, s21a, s22m, s22a, &bias, MAX_PTS, &npts, db_mode );

         if( ! npts ) break;

         /* add the bias information line */         
         if (bias.mode == 1)
            sprintf( string, "Vds(V)=%8.2f  |  Ids(mA)=%8.1f  |  Vgs(V)=%8.3f  |  Igs(mA)=%8.3f",
            bias.vds, bias.ids*1.0e3, bias.vgs, bias.igs*1.0e3 );
         else if (bias.mode == 2)
            sprintf( string, "Vce(V)=%8.2f  |  Ice(mA)=%8.1f  |  Vbe(V)=%8.3f  |  Ibe(mA)=%8.3f",
            bias.vds, bias.ids*1.0e3, bias.vgs, bias.igs*1.0e3 );
         else
            string[0] = '\0';
         bias_line = add_text( string, 3.0, 7.95, FNT_HELVETICA, 12, 0.0, LEFT_JUSTIFY, CLR_BLACK, 0 );

         /* add the plot data */
         attach_y1data( plot11, flist, s11m, npts, LT_SOLID, 1, CLR_RED );
         attach_y1data( plot12, flist, s12m, npts, LT_SOLID, 1, CLR_RED );
         attach_y1data( plot21, flist, s21m, npts, LT_SOLID, 1, CLR_RED );
         attach_y1data( plot22, flist, s22m, npts, LT_SOLID, 1, CLR_RED );

         if( !no_phase ) {
            attach_y2data( plot11, flist, s11a, npts, LT_DASHED, 1, CLR_BLUE );
            attach_y2data( plot12, flist, s12a, npts, LT_DASHED, 1, CLR_BLUE );
            attach_y2data( plot21, flist, s21a, npts, LT_DASHED, 1, CLR_BLUE );
            attach_y2data( plot22, flist, s22a, npts, LT_DASHED, 1, CLR_BLUE );
         }

         /* draw the page */
         draw_page ();

         /* prepare for the next iteration - remove stuff that has already been plotted */
         detach_data( plot11 );
         detach_data( plot12 );
         detach_data( plot21 );
         detach_data( plot22 );
         remove_user_item( bias_line );
      }
      while( npts );

      remove_user_item( filename );
      fclose(file);
   }

   close_graphics_device();

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static int read_s_params( FILE *infile, double *flist, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                         double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts, int *n, int dbret )
{
   char string[256];
   double rad_to_deg = 180.0/acos(-1.0);
   double f, m11, m12, m21, m22;
   double a11, a12, a21, a22;

   /* these values are persistent */
   static int ri_mode = 0;
   static int db_mode = 0;
   static double fscale = 1.0e-9;

   bias->mode = 0;
   *n = 0;

   while( fgets(string, 255, infile) )
   {
      if( string[0] == '!' || string[0] == '#' )
      {
         if( *n )
         {
            /* need to back up the file pointer */
            long dist = strlen( string );
            fseek( infile, -dist, SEEK_CUR );
            /* done */ 
            return (*n);
         }

         if ( !strncmp(string,"!BIAS:",6) )
         {
            if( sscanf( string, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
               &bias->vds, &bias->ids, &bias->vgs, &bias->igs) == 4 )
               bias->mode = 1;
            else if( sscanf( string, "!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",
               &bias->vds, &bias->ids, &bias->vgs, &bias->igs) == 4 )
               bias->mode = 2;
         }
         else if( string[0] == '#' )
         {
            /* convert to lowercase */
            int j;
            for( j=0; j<strlen(string); j++ )
            {
               if( string[j] >= 'A' && string[j] <= 'Z' )
                  string[j] += (char) 32;
            }

            if( strstr(string, "ri") )
               ri_mode = 1;
            else if( strstr(string, "db") )
               db_mode = 1;

            if( strstr(string, "ghz") )
               fscale = 1.0;
            else if( strstr(string, "mhz") )
               fscale = 1.0e-3;
            else if( strstr(string, "khz") )
               fscale = 1.0e-6;
         }
      }

      else
      {
         if( sscanf( string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf",
            &f, &m11, &a11, &m21, &a21, &m12, &a12, &m22, &a22 ) == 9)
         {
            if( *n >= max_pts)
               continue;

            flist[*n] = f * fscale;

            if( ri_mode ) {
               s11m[*n] = sqrt( m11*m11 + a11*a11 );
               s11a[*n] = rad_to_deg * satan2( a11, m11 );

               s12m[*n] = sqrt( m12*m12 + a12*a12 );
               s12a[*n] = rad_to_deg * satan2( a12, m12 );

               s21m[*n] = sqrt( m21*m21 + a21*a21 );
               s21a[*n] = rad_to_deg * satan2( a21, m21 );

               s22m[*n] = sqrt( m22*m22 + a22*a22 );
               s22a[*n] = rad_to_deg * satan2( a22, m22 );

               if( dbret ) {
                  s11m[*n] = 20.*log10(s11m[*n]);
                  s12m[*n] = 20.*log10(s12m[*n]);
                  s21m[*n] = 20.*log10(s21m[*n]);
                  s22m[*n] = 20.*log10(s22m[*n]);
               }
            }
            else if( db_mode ) {
               if( dbret ) {
                  s11m[*n] = m11;
                  s11a[*n] = a11;

                  s12m[*n] = m12;
                  s12a[*n] = a12;

                  s21m[*n] = m21;
                  s21a[*n] = a21;

                  s22m[*n] = m22;
                  s22a[*n] = a22;
               }
               else {
                  s11m[*n] = pow( 10.0, m11*0.05 );
                  s11a[*n] = a11;

                  s12m[*n] = pow( 10.0, m12*0.05 );
                  s12a[*n] = a12;

                  s21m[*n] = pow( 10.0, m21*0.05 );
                  s21a[*n] = a21;

                  s22m[*n] = pow( 10.0, m22*0.05 );
                  s22a[*n] = a22;
               }
            }
            else {
               s11m[*n] = m11;
               s11a[*n] = a11;

               s12m[*n] = m12;
               s12a[*n] = a12;

               s21m[*n] = m21;
               s21a[*n] = a21;

               s22m[*n] = m22;
               s22a[*n] = a22;

               if( dbret ) {
                  s11m[*n] = 20.*log10(s11m[*n]);
                  s12m[*n] = 20.*log10(s12m[*n]);
                  s21m[*n] = 20.*log10(s21m[*n]);
                  s22m[*n] = 20.*log10(s22m[*n]);
               }
            }

            (*n)++;
         }
      }
   }

   return (*n);
}

/*********************************************************************************************/
/*********************************************************************************************/

static double satan2( double y, double x )
{
   if ((x == 0.0) && (y == 0.0))
      return 0.0;
   else
      return atan2(y,x);
}         





