#ifndef JPLOT_DRIVER_INFO_H
#define JPLOT_DRIVER_INFO_H

#include <jplot.h>
#include <metafile.h>
#include <postscript.h>
#ifdef WIN32
#include <win32drv.h>
#else
#include <xwindows.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

// driver definition structure
struct _drv_definition
   {
   // id must be a unique positive (non-zero) integer
   // it is used to select the driver in open_graphics_device()
   int id;
   char *name;
   char *description;
   char *version;
   int  szErrors;
   ERROR_NAMES *errors;
   // these functions are required
   BOOL (*open_driver)(DRIVER_INFO *);
   void (*close_driver)(void);
   BOOL (*draw_line)(double, double, double, double, int, int, int);
   BOOL (*draw_polyline)(double *, double *, int, int, int, int);
   BOOL (*draw_text)(const char *, double, double, int, int, double, int, int, int);
   // these functions are optional and should be set to NULL if not used
   BOOL (*open_file)(void);
   void (*close_file)(void);
   int  (*draw_handler)(BOOL (*)(void));
   BOOL (*draw_rectangle)(double, double, double, double, double, int, int, int);
   BOOL (*draw_arc)(double, double, double, double, double, int, int, int);
   BOOL (*draw_circle)(double, double, double, int, int, int);
   };

// driver definition array - order is not important
// NUMBER_OF_INSTALLED_DRIVERS must be set to the number of definitions in the array
#define NUMBER_OF_INSTALLED_DRIVERS  3

static struct _drv_definition DRIVERS[] =
   {
#ifdef WIN32
      {1,"WIN32","Graphics driver for the Windows 32-bit GDI.","2.0.0",
         NUM_WIN32_ERRORS,
         WIN32_ERRORS,
         win32_open_device,
         win32_close_device,
         win32_draw_line,
         win32_draw_polyline,
         win32_draw_text,
         NULL,
         NULL,
         win32_draw_handler,
         NULL,
         NULL,
         NULL
      },
#else
      {1,"X-WINDOWS","Graphics driver for the X-Windows GUI.","2.0.0",
      NUM_XWINDOWS_ERRORS,
      XWINDOWS_ERRORS,
      x_open_device,
      x_close_device,
      x_draw_line,
      x_draw_polyline,
      x_draw_text,
      NULL,
      NULL,
      x_draw_handler,
      NULL,
      NULL, // arc-drawing routine written but not used, very inefficient and prone to angle issues
      x_draw_circle
      },
#endif
      {2,"METAFILE","Windows 16-bit metafile output.","2.0.0",
      NUM_METAFILE_ERRORS,
      METAFILE_ERRORS,
      wmf_open_device,
      wmf_close_device,
      wmf_draw_line,
      wmf_draw_polyline,
      wmf_draw_text,
      wmf_open_file,
      wmf_close_file,
      NULL,
      NULL,
      NULL,
      NULL
      },
      {3,"POSTSCRIPT","Adobe postscript output.","2.0.0",
      NUM_POSTSCRIPT_ERRORS,
      POSTSCRIPT_ERRORS,
      ps_open_device,
      ps_close_device,
      ps_draw_line,
      ps_draw_polyline,
      ps_draw_text,
      ps_new_page,
      ps_end_page,
      NULL,
      NULL,
      NULL,
      NULL
      }
   };

#ifdef __cplusplus
}
#endif


#endif /* JPLOT_DRIVER_INFO_H */

