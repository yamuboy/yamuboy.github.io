#ifndef JPLOT_METAFILE_H
#define JPLOT_METAFILE_H

#ifdef __cplusplus
extern "C" {
#endif

/* function prototypes */
extern BOOL wmf_open_device (DRIVER_INFO *);
extern void wmf_close_device (void);
extern BOOL wmf_draw_line (double, double, double, double, int, int, int);
extern BOOL wmf_draw_text (const char *, double, double, int, int, double, int, int, int);
extern BOOL wmf_draw_polyline (double *, double *, int, int, int, int);
extern BOOL wmf_open_file (void);
extern void wmf_close_file (void);

/* error list */
static ERROR_NAMES METAFILE_ERRORS[] = {
   {0,"METAFILE: None defined."}
   };

#define NUM_METAFILE_ERRORS  0

#ifdef __cplusplus
}
#endif

#endif /* JPLOT_METAFILE_H */

