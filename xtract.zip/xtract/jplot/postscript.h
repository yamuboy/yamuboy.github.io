#ifndef JPLOT_POSTSCRIPT_H
#define JPLOT_POSTSCRIPT_H

#ifdef __cplusplus
extern "C" {
#endif

/* function prototypes */
extern BOOL ps_open_device (DRIVER_INFO *);
extern void ps_close_device (void);
extern BOOL ps_draw_line (double, double, double, double, int, int, int);
extern BOOL ps_draw_text (const char *, double, double, int, int, double, int, int, int);
extern BOOL ps_draw_polyline (double *, double *, int, int, int, int);
extern BOOL ps_new_page (void);
extern void ps_end_page (void);

/* error list */
static ERROR_NAMES POSTSCRIPT_ERRORS[] = {
   {0,"POSTSCRIPT: None defined."}
   };

#define NUM_POSTSCRIPT_ERRORS  0

#ifdef __cplusplus
}
#endif

#endif /* JPLOT_POSTSCRIPT_H */

