#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>
#include <windowsx.h>
//#include <commctrl.h>
#include <jplot.h>

// user-defined window messages
#define NEXT_PAGE_NOTIFY      0x0401
#define PAGE_DRAW_FAILED      0x0402

// this is needed for type compatibility in the internalRegisterClass function
typedef ATOM (WINAPI* REGISTERCLASSEXPROC)(const LPWNDCLASSEX lpwcex);

#define ClassName  "jPlot Plotting Utility Main Window Class"
#define Title      "jPlot Plotting Utility - Win32"

// GLOBAL VARIABLES
static HINSTANCE  hInst = NULL;
static HWND       hWnd  = NULL;
static HPEN       hPen  = NULL, hPen_stock = NULL;
static HFONT      hFont = NULL;
static HDC        hdc1  = NULL;
static BOOL       (*draw_ptr)(void) = NULL;
static int        current_lt    = 0;
static int        current_lw    = 0;
static int        current_lc    = 0;
static int        current_font  = 0;
static int        current_ps    = 0;
static int        current_style = 0;
static double     current_ang   = 0.0;
static double     page_height   = 0.0;
static double     page_width    = 0.0;

extern int ERROR_NUMBER;

// internal function prototypes
LRESULT CALLBACK mainFrameWndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
static ATOM internalRegisterClass (const LPWNDCLASSEX lpwcex);
static COLORREF get_color (int color);
static void set_pen_properties (int ltype, int lwidth, int lcolor);

/******************************************************************************/
/******************************************************************************/

BOOL win32_open_device (DRIVER_INFO *dData)
   {
   WNDCLASSEX  wcex;
   RECT        rect;

   page_height = dData->page_height_in;
   page_width  = dData->page_width_in;

   // need to get a handle to this process
   hInst = GetModuleHandle (NULL);

   // register the main window class
   wcex.cbSize        = sizeof (WNDCLASSEX);
   wcex.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS | CS_OWNDC;
   wcex.lpfnWndProc   = mainFrameWndProc;
   wcex.cbClsExtra    = 0;
   wcex.cbWndExtra    = 0;
   wcex.hInstance     = hInst;
   wcex.hIcon         = LoadIcon (NULL,MAKEINTRESOURCE(IDI_APPLICATION));
   wcex.hCursor       = LoadCursor (NULL,IDC_ARROW);
   wcex.hbrBackground = (HBRUSH) (COLOR_WINDOW+1);

   wcex.lpszMenuName  = NULL;
   wcex.lpszClassName = ClassName;
   wcex.hIconSm       = NULL;

   if (!internalRegisterClass (&wcex))
      {
      ERROR_NUMBER = 301;
      return FALSE;
      }

   // Initialize the Common Controls DLL
   // InitCommonControls ();

   // create the main frame window
   hWnd = CreateWindowEx (0,  // Extended window styles
      ClassName,              // Address of registered class name
      Title,                  // Address of window name
      WS_OVERLAPPEDWINDOW,    // Window style
      CW_USEDEFAULT,          // Horizontal position of window
      0,                      // Vertical position of window
      CW_USEDEFAULT,          // Window width
      0,                      // Window height
      NULL,                   // Handle of parent or owner window
      NULL,                   // Handle of menu for this window
      hInst,                  // Handle of application instance
      NULL);                  // Address of window-creation data

   if (!hWnd)
      {
      ERROR_NUMBER = 302;
      return FALSE;
      }

   ShowWindow (hWnd,SW_SHOWDEFAULT);
   SetForegroundWindow (hWnd);
   GetClientRect (hWnd,&rect);

   hdc1 = GetDC(hWnd);

   SetMapMode(hdc1,MM_ISOTROPIC);
   SetBkMode(hdc1,TRANSPARENT);

   SetViewportOrgEx(hdc1,rect.right/2,rect.bottom/2,NULL);
   SetViewportExtEx(hdc1,rect.right,-rect.bottom,NULL);
   SetWindowExtEx(hdc1,(int) (page_width*1000.0),(int) (page_height*1000.0),NULL);

   hPen_stock = GetStockObject(WHITE_PEN);

   ReleaseDC (hWnd,hdc1);

   ShowWindow (hWnd,SW_SHOWMAXIMIZED);

   return TRUE;
   }

/******************************************************************************/
/******************************************************************************/

void win32_close_device (void)
   {
   MSG    msg;

   // delete the custom pen, if exists
   if (hPen)
      DeletePen (hPen);
   hPen = NULL;

   // delete the font, if exists
   if (hFont)
      DeleteFont (hFont);
   hFont = NULL;

   // send a destroy message
   if (IsWindow(hWnd))
      {
      DestroyWindow (hWnd);

      // wait for the destroy notification
      while (GetMessage (&msg, NULL, 0, 0))
         {
         TranslateMessage (&msg);
         DispatchMessage (&msg);
         }
      }

   // do any other cleanup
   hInst = NULL;
   hWnd  = NULL;
   }

/******************************************************************************/
/******************************************************************************/

int win32_draw_handler (BOOL (*draw_fnct_ptr)(void))
   {
   MSG     msg;
   HACCEL  haccel = NULL;
   RECT    rect;

   // initialize the error number
   ERROR_NUMBER = 0;

   draw_ptr = draw_fnct_ptr;

   UpdateWindow(hWnd);

   while (GetMessage (&msg, NULL, 0, 0))
      {
      if (!TranslateAccelerator (msg.hwnd, haccel, &msg))
         {
         if (msg.message == NEXT_PAGE_NOTIFY)
            {
            GetClientRect (hWnd,&rect);
            InvalidateRect(hWnd,&rect,TRUE);
            return TRUE;
            }
         else if (msg.message == PAGE_DRAW_FAILED)
            return FALSE;

         TranslateMessage (&msg);
         DispatchMessage (&msg);
         }
      }

   /* FORCED TERMINATION - user has X'd the window */

   // delete the custom pen, if exists
   if (hPen)
      DeletePen (hPen);
   hPen = NULL;

   // delete the font, if exists
   if (hFont)
      DeleteFont (hFont);
   hFont = NULL;

   // do any other cleanup
   hInst = NULL;
   hWnd  = NULL;

   return DRIVER_EXIT;
   }

/******************************************************************************/
/******************************************************************************/

BOOL win32_draw_line (double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor)
   {
   BOOL status;

   set_pen_properties (ltype,lwidth,lcolor);

   if (!hPen)
      {
      ERROR_NUMBER = 303;
      return FALSE;
      }

   SelectPen (hdc1,hPen);

   MoveToEx (hdc1,(int) (x1*1000.0 - 500.0*page_width),(int) (y1*1000.0 - 500.0*page_height),NULL);
   status = LineTo (hdc1,(int) (x2*1000.0 - 500.0*page_width),(int) (y2*1000.0 - 500.0*page_height));

   // revert back to the stock pen
   SelectPen (hdc1,hPen_stock);

   if (!status)
      ERROR_NUMBER = 305;

   return status;
   }

/******************************************************************************/
/******************************************************************************/

BOOL win32_draw_polyline (double *xdata, double *ydata, int n, int ltype, int lwidth, int lcolor)
   {
   int          i;
   POINT        *pnts;
   BOOL         status;

   if (n < 2)
      return TRUE;
   else if (n < 3)
      return win32_draw_line (xdata[0],ydata[0],xdata[1],ydata[1],ltype,lwidth,lcolor);

   set_pen_properties (ltype,lwidth,lcolor);

   if (!hPen)
      {
      ERROR_NUMBER = 303;
      return FALSE;
      }

   SelectPen (hdc1,hPen);

   pnts = (POINT *) malloc (sizeof(POINT)*n);
   if (!pnts)
      {
      ERROR_NUMBER = 308;
      return FALSE;
      }

   for (i = 0; i < n; ++i)
      {
      pnts[i].x = (long) (xdata[i]*1000.0 - 500.0*page_width);
      pnts[i].y = (long) (ydata[i]*1000.0 - 500.0*page_height);
      }

   status = Polyline (hdc1,pnts,n);

   free ((void *) pnts);

   // revert back to the stock pen
   SelectPen (hdc1,hPen_stock);

   if (!status)
      ERROR_NUMBER = 307;

   return status;
   }

/******************************************************************************/
/******************************************************************************/

BOOL win32_draw_text (const char *string, double x, double y, int font, int psize, double angle, int justify, int color, int style)
   {
   int          theight,weight;
   char         *fname;
   BOOL         status;

   if ((font != current_font) || (psize != current_ps) || (style != current_style) ||
      (fabs(angle-current_ang) > 0.1) || !hFont)
      {
      theight = (int) (((double)psize)*(1000.0/72.0));

      if (style & TS_BOLDFACE)
         weight = FW_BOLD;
      else
         weight = FW_NORMAL;

      switch (font)
         {
         case FNT_TIMES:
            fname = "Times New Roman";
            break;
         case FNT_HELVETICA:
            fname = "Helvetica";
            break;
         default:
         case FNT_COURIER:
            fname = "Courier New";
            break;
         }

      // delete the old font, if exists
      if (hFont)
         DeleteFont (hFont);

      hFont = CreateFont(theight,0,(int)(-angle*10.0),(int)(-angle*10.0),weight,style & TS_ITALIC,
         style & TS_UNDERLINE,0,ANSI_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,0,fname);

      if (!hFont)
         {
         ERROR_NUMBER = 304;
         return FALSE;
         }

      current_font  = font;
      current_ps    = psize;
      current_ang   = angle;
      current_style = style;
      }

   SelectFont (hdc1,hFont);

   // set text color
   SetTextColor (hdc1,get_color (color));

   // set text alignment
   switch (justify)
      {
      case CENTER_JUSTIFY:
         SetTextAlign (hdc1,TA_BASELINE | TA_CENTER);
         break;
      case RIGHT_JUSTIFY:
         SetTextAlign (hdc1,TA_BASELINE | TA_RIGHT);
         break;
      default:
      case LEFT_JUSTIFY:
         SetTextAlign (hdc1,TA_BASELINE | TA_LEFT);
         break;
      }

   status = TextOut(hdc1,(int) (x*1000.0 - 500.0*page_width),(int) (y*1000.0 - 500.0*page_height),string,strlen(string));

   // revert back to the stock pen
   SelectPen (hdc1,hPen_stock);

   if (!status)
      ERROR_NUMBER = 306;

   return status;
   }

/******************************************************************************/
/******************************************************************************/

static ATOM internalRegisterClass (const LPWNDCLASSEX lpwcex)
   {
   WNDCLASS wc;

   // Get the module handle of the 32-bit USER DLL
   HANDLE hModule = GetModuleHandle ("USER32");

   if (hModule) // we're running win32
      {
      REGISTERCLASSEXPROC proc = (REGISTERCLASSEXPROC) GetProcAddress (hModule, "RegisterClassExA");

      if (proc)
         return (*proc) (lpwcex);
      }

   // Else, need to use the old 16-bit version of class registration
   // Convert the WNDCLASSEX structure to a WNDCLASS structure
   wc.style         = lpwcex->style;
   wc.lpfnWndProc   = lpwcex->lpfnWndProc;
   wc.cbClsExtra    = lpwcex->cbClsExtra;
   wc.cbWndExtra    = lpwcex->cbWndExtra;
   wc.hInstance     = lpwcex->hInstance;
   wc.hIcon         = lpwcex->hIcon;
   wc.hCursor       = lpwcex->hCursor;
   wc.hbrBackground = lpwcex->hbrBackground;
   wc.lpszMenuName  = lpwcex->lpszMenuName;
   wc.lpszClassName = lpwcex->lpszClassName;

   return RegisterClass (&wc) ;
   }

/******************************************************************************/
/******************************************************************************/

static void mainFrame_OnKey (HWND hwnd, UINT vk, BOOL down, int repeat, UINT flags)
   {
   if ((vk == VK_SPACE) || (vk == VK_RETURN) || (vk == VK_ESCAPE))
      {
      if (down)
         PostMessage(hWnd,NEXT_PAGE_NOTIFY,(WPARAM) 0,(LPARAM) 0);
      }

   if (down)
      FORWARD_WM_KEYDOWN (hwnd, vk, repeat, flags, DefWindowProc);
   else
      FORWARD_WM_KEYUP (hwnd, vk, repeat, flags, DefWindowProc);
   }

/******************************************************************************/
/******************************************************************************/

static void mainFrame_OnSize (HWND hwnd, UINT state, int cx, int cy)
   {
   RECT         rect;

   GetClientRect (hwnd,&rect);

   hdc1 = GetDC(hwnd);
   SetViewportOrgEx(hdc1,rect.right/2,rect.bottom/2,NULL);
   SetViewportExtEx(hdc1,rect.right,-rect.bottom,NULL);
   ReleaseDC (hwnd,hdc1);

   FORWARD_WM_SIZE (hwnd, state, cx, cy, DefWindowProc);
   }

/******************************************************************************/
/******************************************************************************/

static void mainFrame_OnPaint (HWND hwnd)
   {
   PAINTSTRUCT ps;

   hdc1 = BeginPaint(hwnd,&ps);
   if (draw_ptr != NULL)
      {
      if (!(*draw_ptr) ())
         PostMessage(hWnd,PAGE_DRAW_FAILED,(WPARAM)0,(LPARAM)0);
      }
   EndPaint(hwnd,&ps);
   }

/******************************************************************************/
/******************************************************************************/

static void mainFrame_OnDestroy (HWND hwnd)
   {
   hwnd; // prevents "unused formal parameter" compiler warnings
   PostQuitMessage (0);
   }

/******************************************************************************/
/******************************************************************************/

LRESULT CALLBACK mainFrameWndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
   {
   switch (message)
      {
      case WM_KEYDOWN:
         return HANDLE_WM_KEYDOWN (hwnd, wParam, lParam, mainFrame_OnKey);

      case WM_KEYUP:
         return HANDLE_WM_KEYUP (hwnd, wParam, lParam, mainFrame_OnKey);

      case WM_DESTROY:
         return HANDLE_WM_DESTROY (hwnd, wParam, lParam, mainFrame_OnDestroy);

      case WM_SIZE:
         return HANDLE_WM_SIZE (hwnd, wParam, lParam, mainFrame_OnSize);

      case WM_PAINT:
         return HANDLE_WM_PAINT (hwnd, wParam, lParam, mainFrame_OnPaint) ;

      default:
         return DefWindowProc (hwnd, message, wParam, lParam);
      }
   }

/******************************************************************************/
/******************************************************************************/

static COLORREF get_color (int color)
   {
   switch (color)
      {
      case CLR_RED:
         return RGB(255,10,10);
      case CLR_GREEN:
         return RGB(10,255,10);
      case CLR_BLUE:
         return RGB(10,10,255);
      case CLR_YELLOW:
         return RGB(255,255,10);
      case CLR_LIGHTGREY:
         return RGB(220,220,220);
      case CLR_GREY:
         return RGB(160,160,160);
      case CLR_DARKGREY:
         return RGB(80,80,80);
      case CLR_ORANGE:
         return RGB(255,128,10);
      case CLR_LIGHTBLUE:
         return RGB(80,240,255);
      case CLR_DARKGREEN:
         return RGB(0,128,16);
      case CLR_BROWN:
         return RGB(100,70,70);
      case CLR_PURPLE:
         return RGB(150,20,225);
      case CLR_MAROON:
         return RGB(215,10,0);
      default:
      case CLR_BLACK:
         return RGB(0,0,0);
      }
   }

/******************************************************************************/
/******************************************************************************/

static void set_pen_properties (int ltype, int lwidth, int lcolor)
   {
   int style;

   if ((ltype != current_lt) || (lwidth != current_lw) || (lcolor != current_lc) || !hPen)
      {
      switch (ltype)
         {
         case LT_DOTTED:
            style = PS_DOT;
            break;
         case LT_DASHED:
            style = PS_DASH;
            break;
         case LT_DOTDASH:
            style = PS_DASHDOT;
            break;
         case LT_DOTDOTDASH:
            style = PS_DASHDOTDOT;
            break;
         default:
         case LT_SOLID:
            style = PS_SOLID;
            break;
         }

      // delete the old pen, if exists
      if (hPen)
         DeletePen (hPen);

      hPen = CreatePen (style,(int)(((double)lwidth)*1000.0/72.0),get_color(lcolor));

      current_lt = ltype;
      current_lw = lwidth;
      current_lc = lcolor;
      }
   }
