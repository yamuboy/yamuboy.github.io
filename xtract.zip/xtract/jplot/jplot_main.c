#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include "jplot.h"
#include "driver_info.h"

/**** Error Number (externally accessible global variable) ****/
int ERROR_NUMBER;

/**** GLOBAL VARIABLES (internal) ****/
static int driver_num = -1;
static jPLOT_ITEM *pPlotItems = NULL;
static jPLOT_USER *pUserItems = NULL;
static double x_origin = 0.0;
static double y_origin = 0.0;
static double global_rotate = 0.0;

/***** MACRO DEFINITIONS ******/
// guarantees a NULL terminated string when using strncpy, this is not the case with all C implementations
#define my_strncpy(str1,str2,n)   do { strncpy(str1,str2,n); str1[(strlen(str2) < n) ? strlen(str2) : n] = 0; } while (0)
// fixes angle x to be: -180 < x <= +180
#define fix_angle(x)              do { while ((x) <= -180.0) (x) += 360.0; while ((x) > 180.0) (x) -= 360.0; } while (0)
// returns the magnitude of an (x,y) coordinate point
#define pmag(x,y)                 (sqrt((x)*(x)+(y)*(y)))
#define sqr(x)                    ((x)*(x))

/**** INTERNAL FUNCTION PROTOTYPES ****/
static void translate1 (double, double, double, double *, double *);
static jPLOT_USER *add_user_item (int);
static BOOL draw_all_active_items (void);
static BOOL draw_plot_item (jPLOT_ITEM *);
static BOOL draw_user_item (jPLOT_USER *);
static BOOL draw_rect_axes (jPLOT_ITEM *);
static BOOL draw_linear_rect_axis (jPLOT_ITEM *, int);
static BOOL draw_log_rect_axis (jPLOT_ITEM *, int);
static BOOL draw_rect_data (jPLOT_ITEM *);
static BOOL draw_polar_axes (jPLOT_ITEM *);
static BOOL draw_smith_axes (jPLOT_ITEM *);
static BOOL draw_polar_data (jPLOT_ITEM *);
static BOOL draw_contour_data (jPLOT_ITEM *);
static void autoscale (jPLOT_ITEM *);
static LINE_SEG *calculate_contour_intersections (jPLOT_DATA *, int *);
static BOOL is_triangle (struct point_list, struct point_list, LINE_SEG *, int);

/******************************************************************************/
/******************************************************************************/
/******                                                                  ******/
/******                  EXTERNALLY ACCESSIBLE FUNCTIONS                 ******/
/******                                                                  ******/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

BOOL open_graphics_device (int driver, const char *filename)
{
   int    i;
   DRIVER_INFO  dData;

   ERROR_NUMBER = 0;

   // check to see if a driver is already open and close it
   if (driver_num > -1)
   {
      DRIVERS[driver_num].close_driver ();
      driver_num = -1;
   }

   // find the requested driver
   for (i = 0; i < NUMBER_OF_INSTALLED_DRIVERS; ++i)
   {
      if (DRIVERS[i].id == driver)
      {
         driver_num = i;
         break;
      }
   }

   if (driver_num < 0)
   {
      ERROR_NUMBER = 101;
      return FALSE;
   }

   if (filename)
      my_strncpy( dData.filename, filename, MAX_FILENAME_LENGTH );
   else
      dData.filename[0] = 0;
   dData.page_width_in = 11.0;
   dData.page_height_in = 8.5;
   dData.orientation = ORIENT_LANDSCAPE;

   if (!DRIVERS[driver_num].open_driver(&dData)) {
      driver_num = -1;
      ERROR_NUMBER = 201;
      return FALSE;
   }

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

void close_graphics_device (void)
{
   ERROR_NUMBER = 0;

   cleanup_resources ();

   x_origin = 0.0;
   y_origin = 0.0;
   global_rotate = 0.0;

   if (driver_num > -1)
      DRIVERS[driver_num].close_driver ();

   driver_num = -1;
}

/******************************************************************************/
/******************************************************************************/

BOOL draw_page (void)
{
   int result;

   ERROR_NUMBER = 0;

   if (driver_num < 0)
   {
      ERROR_NUMBER = 102;
      return FALSE;
   }

   // open plot file
   if (DRIVERS[driver_num].open_file != NULL)
      if (!DRIVERS[driver_num].open_file ())
      {
         ERROR_NUMBER = 202;
         return FALSE;
      }

      // draw everything
      if (DRIVERS[driver_num].draw_handler != NULL)
      {
         result = DRIVERS[driver_num].draw_handler(&draw_all_active_items);
         if (!result)
         {
            if (ERROR_NUMBER == 0)
               ERROR_NUMBER = 103;
            return FALSE;
         }
         else if (result == DRIVER_EXIT)
         {
            if (ERROR_NUMBER == 0)
               ERROR_NUMBER = 203;
            driver_num = -1;
            return FALSE;
         }
      }
      else
      {
         if (!draw_all_active_items())
         {
            if (ERROR_NUMBER == 0)
               ERROR_NUMBER = 103;
            return FALSE;
         }
      }

      // close plot file
      if (DRIVERS[driver_num].close_file != NULL)
         DRIVERS[driver_num].close_file ();

      return TRUE;
}

/******************************************************************************/
/******************************************************************************/

jPLOT_ITEM *create_plot_item (int ptype, double x, double y, double xsize, double ysize)
{
   jPLOT_ITEM  *plot_item,*ptr;
   double x1,y1;

   plot_item = (jPLOT_ITEM *) malloc (sizeof (jPLOT_ITEM));

   if (plot_item == NULL)
   {
      ERROR_NUMBER = 104;
      return NULL;
   }

   plot_item->next = NULL;

   // set up the linked list
   if (pPlotItems == NULL)
      pPlotItems = plot_item;
   else
   {
      ptr = pPlotItems;
      while (ptr->next != NULL)
         ptr = ptr->next;

      ptr->next = plot_item;
   }

   plot_item->plot_type = ptype;

   translate1 (x,y,global_rotate,&x1,&y1);
   plot_item->x_frame_pos = x_origin + x1;
   plot_item->y_frame_pos = y_origin + y1;
   plot_item->x_frame_size = xsize;
   plot_item->y_frame_size = ysize;

   // defaults
   plot_item->x_label[0] = 0;
   plot_item->y1_label[0] = 0;
   plot_item->y2_label[0] = 0;
   plot_item->title[0] = 0;
   plot_item->active = TRUE;
   plot_item->angle = global_rotate;
   plot_item->scaling = 0;
   plot_item->flags = 0;
   plot_item->data = NULL;

   // attrib defaults
   plot_item->attribs.label_font = FNT_HELVETICA;
   plot_item->attribs.title_font = FNT_HELVETICA;
   plot_item->attribs.axis_font = FNT_HELVETICA;
   plot_item->attribs.label_tsize = 14;
   plot_item->attribs.title_tsize = 16;
   plot_item->attribs.axis_tsize = 10;
   plot_item->attribs.xlabel_offset = 0.4;
   plot_item->attribs.ylabel_offset = 0.8;
   plot_item->attribs.xnum_offset = 0.1;
   plot_item->attribs.ynum_offset = 0.1;
   plot_item->attribs.title_offset = 0.5;
   plot_item->attribs.major_tick = 0.25;
   plot_item->attribs.minor_tick = 0.125;

   return plot_item;
}

/******************************************************************************/
/******************************************************************************/

void remove_plot_item (jPLOT_ITEM *plot_item)
{
   jPLOT_ITEM *ptr = pPlotItems;

   if (ptr == NULL)
      return;
   else if (ptr == plot_item)
      pPlotItems = ptr->next;
   else
   {
      while (ptr->next != NULL)
      {
         if (ptr->next == plot_item)
         {
            // "jumps" the plot item to be removed in the linked-list
            ptr->next = ptr->next->next;
            break;
         }
         ptr = ptr->next;
      }
   }

   // removes any data items linked to the plot item
   detach_data (plot_item);

   // free the plot item memory
   free ((void *) plot_item);
}

/******************************************************************************/
/******************************************************************************/

void remove_all_plot_items (void)
{
   jPLOT_ITEM *ptr = pPlotItems,*tptr;

   while (ptr != NULL)
   {
      tptr = ptr;
      ptr = ptr->next;

      detach_data (tptr);
      free ((void *) tptr);
   }

   pPlotItems = NULL;
}

/******************************************************************************/
/******************************************************************************/

BOOL attach_data (jPLOT_ITEM *pitem, int type, double *xdata, double *y1data, double *y2data, int n_pts,
                  int y1_ltype, int y1_width, int y1_clr, int y2_ltype, int y2_width, int y2_clr)
{
   jPLOT_DATA   *ditem,*ptr;

   if (pitem == NULL)
   {
      ERROR_NUMBER = 105;
      return FALSE;
   }
   else if (xdata == NULL)
   {
      ERROR_NUMBER = 106;
      return FALSE;
   }
   else if ((y1data == NULL) && (y2data == NULL) && (type == XY_DATA))
   {
      ERROR_NUMBER = 106;
      return FALSE;
   }
   else if ((y1data == NULL) && (type == POLAR_DATA))
   {
      ERROR_NUMBER = 106;
      return FALSE;
   }
   else if (((y1data == NULL) || (y2data == NULL)) && (type == CONTOUR_DATA))
   {
      ERROR_NUMBER = 106;
      return FALSE;
   }

   ditem = (jPLOT_DATA *) malloc (sizeof (jPLOT_DATA));
   if (!ditem)
   {
      ERROR_NUMBER = 104;
      return FALSE;
   }

   ditem->next = NULL;

   if (pitem->data == NULL)
      pitem->data = ditem;
   else
   {
      ptr = pitem->data;
      while (ptr->next != NULL)
         ptr = ptr->next;

      ptr->next = ditem;
   }

   ditem->x_data = xdata;
   ditem->n_pts  = n_pts;
   ditem->type   = 0;

   switch (type)
   {
   case POLAR_DATA:
      ditem->y1_data   = y1data;
      ditem->y1_ltype  = y1_ltype;
      ditem->y1_lwidth = y1_width;
      ditem->y1_color  = y1_clr;
      ditem->type      = POLAR_DATA;
      break;

   case CONTOUR_DATA:
      ditem->y1_data   = y1data;
      ditem->y2_data   = y2data;
      ditem->y1_ltype  = y1_ltype;
      ditem->y1_lwidth = y1_width;
      ditem->y1_color  = y1_clr;
      ditem->y2_ltype  = y2_ltype;
      ditem->y2_color  = y2_clr;
      ditem->type      = CONTOUR_DATA;
      break;

   default:
   case XY_DATA:
      if (y1data != NULL)
      {
         ditem->y1_data   = y1data;
         ditem->y1_ltype  = y1_ltype;
         ditem->y1_lwidth = y1_width;
         ditem->y1_color  = y1_clr;
         ditem->type     |= Y1_DATA;
      }

      if (y2data != NULL)
      {
         ditem->y2_data   = y2data;
         ditem->y2_ltype  = y2_ltype;
         ditem->y2_lwidth = y2_width;
         ditem->y2_color  = y2_clr;
         ditem->type     |= Y2_DATA;

         // added y2 data to the plot item, automatically switch the plot type
         // to DoubleY if it is a SingleY type plot
         if (pitem->plot_type == SingleY)
            pitem->plot_type = DoubleY;
      }
      break;
   }

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

void detach_data (jPLOT_ITEM *pitem)
{
   jPLOT_DATA *dptr = pitem->data,*tptr;

   while (dptr != NULL)
   {
      tptr = dptr;
      dptr = dptr->next;

      free ((void *) tptr);
   }

   pitem->data = NULL;
}

/******************************************************************************/
/******************************************************************************/

void remove_user_item (jHANDLE handle)
{
   jPLOT_USER *ptr = pUserItems,*tptr = NULL;

   if (ptr == NULL)
      return;
   else if (ptr->handle == handle)
   {
      pUserItems = ptr->next;
      tptr = ptr;
   }
   else
   {
      while (ptr->next != NULL)
      {
         if (ptr->next->handle == handle)
         {
            // "jumps" the user item to be removed in the linked-list
            tptr = ptr->next;
            ptr->next = ptr->next->next;
            break;
         }
         ptr = ptr->next;
      }
   }

   if (tptr != NULL)
   {
      // free any item specific memory
      switch (tptr->type)
      {
      case USER_TEXT:
         free ((void *) tptr->ptr[0].strg);
         free ((void *) tptr->ptr[1].dVal);
         free ((void *) tptr->ptr[2].iVal);
         break;
      case USER_LINE:
         free ((void *) tptr->ptr[0].dVal);
         free ((void *) tptr->ptr[1].iVal);
         break;
      case USER_POLYLINE:
         free ((void *) tptr->ptr[0].dVal);
         free ((void *) tptr->ptr[1].dVal);
         free ((void *) tptr->ptr[2].iVal);
         break;
      case USER_CIRCLE:
         free ((void *) tptr->ptr[0].dVal);
         free ((void *) tptr->ptr[1].iVal);
         break;
      case USER_ARC:
         free ((void *) tptr->ptr[0].dVal);
         free ((void *) tptr->ptr[1].iVal);
         break;
      case USER_LEGEND:
         free ((void *) tptr->ptr[0].strg);
         free ((void *) tptr->ptr[1].dVal);
         free ((void *) tptr->ptr[2].iVal);
         break;
      default:
         break;
      }

      free ((void *) tptr);
   }
}

/******************************************************************************/
/******************************************************************************/

void remove_all_user_items (void)
{
   jPLOT_USER *ptr = pUserItems;

   while (ptr != NULL)
   {
      remove_user_item (ptr->handle);
      ptr = pUserItems;
   }
}

/******************************************************************************/
/******************************************************************************/

jHANDLE adduser_text ( const char *txt, double x, double y, int font, int psize, double angle, int justify, int color, int style)
{
   jPLOT_USER *item;
   double     *dVals;
   int        *iVals;
   double     x1,y1;

   if (strlen (txt) == 0)
   {
      ERROR_NUMBER = 106;
      return USERITEM_ERROR;
   }

   item = add_user_item (USER_TEXT);
   if (!item)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   // allocate memory
   dVals = (double *) malloc (sizeof(double)*3);
   iVals = (int *) malloc (sizeof(int)*4);
   if (!dVals || !iVals) {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   translate1 (x,y,global_rotate,&x1,&y1);
   dVals[0] = x_origin + x1;
   dVals[1] = y_origin + y1;
   dVals[2] = angle + global_rotate;
   iVals[0] = font;
   iVals[1] = psize;
   iVals[2] = justify;
   iVals[3] = style;

   item->color = color;
   item->ptr[0].strg = strdup(txt);
   item->ptr[1].dVal = dVals;
   item->ptr[2].iVal = iVals;

   return item->handle;
}

/******************************************************************************/
/******************************************************************************/

jHANDLE adduser_line (double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor)
{
   jPLOT_USER  *item;
   double      *dVals;
   int         *iVals;

   item = add_user_item (USER_LINE);
   if (!item)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   // allocate memory
   dVals = (double *) malloc (sizeof(double)*4);
   iVals = (int *) malloc (sizeof(int)*2);
   if (!dVals || !iVals)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   translate1 (x1,y1,global_rotate,&dVals[0],&dVals[1]);
   dVals[0] += x_origin;
   dVals[1] += y_origin;
   translate1 (x2,y2,global_rotate,&dVals[2],&dVals[3]);
   dVals[2] += x_origin;
   dVals[3] += y_origin;
   iVals[0] = ltype;
   iVals[1] = lwidth;

   item->color = lcolor;
   item->ptr[0].dVal = dVals;
   item->ptr[1].iVal = iVals;

   return item->handle;
}

/******************************************************************************/
/******************************************************************************/

jHANDLE adduser_polyline (double *x, double *y, int n, int ltype, int lwidth, int lcolor)
{
   jPLOT_USER   *item;
   int          i,*iVals;
   double       *xx,*yy;

   item = add_user_item (USER_POLYLINE);
   if (!item)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   xx = (double *) malloc (sizeof(double)*n);
   yy = (double *) malloc (sizeof(double)*n);
   iVals = (int *) malloc (sizeof(int)*3);
   if (!iVals || !xx || !yy)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   iVals[0] = n;
   iVals[1] = ltype;
   iVals[2] = lwidth;

   for (i = 0; i < n; ++i)
   {
      translate1 (x[i],y[i],global_rotate,&xx[i],&yy[i]);
      xx[i] += x_origin;
      yy[i] += y_origin;
   }

   item->color = lcolor;
   item->ptr[0].dVal = xx;
   item->ptr[1].dVal = yy;
   item->ptr[2].iVal = iVals;

   return item->handle;
}

/******************************************************************************/
/******************************************************************************/

jHANDLE adduser_arc (double x, double y, double rad, double astart, double astop, int ltype, int lwidth, int lcolor)
{
   jPLOT_USER  *item;
   double      *dVals;
   int         *iVals;

   item = add_user_item (USER_ARC);
   if (!item)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   // allocate memory
   dVals = (double *) malloc (sizeof(double)*5);
   iVals = (int *) malloc (sizeof(int)*2);
   if (!dVals || !iVals)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   translate1 (x,y,global_rotate,&dVals[0],&dVals[1]);
   dVals[0] += x_origin;
   dVals[1] += y_origin;
   dVals[2] = rad;
   dVals[3] = astart + global_rotate;
   dVals[4] = astop  + global_rotate;
   iVals[0] = ltype;
   iVals[1] = lwidth;

   item->color = lcolor;
   item->ptr[0].dVal = dVals;
   item->ptr[1].iVal = iVals;

   return item->handle;
}

/******************************************************************************/
/******************************************************************************/

jHANDLE adduser_circle (double x, double y, double rad, int ltype, int lwidth, int lcolor)
{
   jPLOT_USER  *item;
   double      *dVals;
   int         *iVals;

   item = add_user_item (USER_CIRCLE);
   if (!item)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   // allocate memory
   dVals = (double *) malloc (sizeof(double)*3);
   iVals = (int *) malloc (sizeof(int)*2);
   if (!dVals || !iVals)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   translate1 (x,y,global_rotate,&dVals[0],&dVals[1]);
   dVals[0] += x_origin;
   dVals[1] += y_origin;
   dVals[2] = rad;
   iVals[0] = ltype;
   iVals[1] = lwidth;

   item->color = lcolor;
   item->ptr[0].dVal = dVals;
   item->ptr[1].iVal = iVals;

   return item->handle;
}

/******************************************************************************/
/******************************************************************************/

jHANDLE adduser_legend (int num_items, double x, double y, const char *txt[], int font, int psize, int ltype[], int lwidth[], int lcolor[])
{
   jPLOT_USER  *item;
   char   *strg;
   double *pos;
   int    i,*ints;
   unsigned char_count = 0;

   item = add_user_item (USER_LEGEND);
   if (!item)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   // determine the total size for the string
   for (i = 0; i < num_items; ++i)
      char_count += strlen(txt[i]) + 1;

   strg = (char *) malloc (sizeof(char)*char_count + 1);
   pos  = (double *) malloc (sizeof(double)*3);
   ints = (int *) malloc (sizeof(int)*(num_items*3 + 3));
   if (!pos || !ints || !strg)
   {
      ERROR_NUMBER = 104;
      return USERITEM_ERROR;
   }

   translate1 (x,y,global_rotate,&pos[0],&pos[1]);
   pos[0] += x_origin;
   pos[1] += y_origin;
   pos[2]  = global_rotate;
   ints[0] = num_items;
   ints[1] = font;
   ints[2] = psize;

   strg[0] = 0;
   for (i = 0; i < num_items; ++i)
   {
      strcat (strg,txt[i]);
      strcat (strg,"\n");
      ints[i*3+3] = ltype[i];
      ints[i*3+4] = lwidth[i];
      ints[i*3+5] = lcolor[i];
   }

   item->ptr[0].strg = strg;
   item->ptr[1].dVal = pos;
   item->ptr[2].iVal = ints;

   return item->handle;
}

/******************************************************************************/
/******************************************************************************/

void cleanup_resources (void)
{
   remove_all_plot_items ();
   remove_all_user_items ();
}

/******************************************************************************/
/******************************************************************************/

void set_page_origin (double x, double y, double angle)
{
   x_origin = x;
   y_origin = y;
   fix_angle(angle);
   global_rotate = angle;
}

/******************************************************************************/
/******************************************************************************/

void set_axis_scales (jPLOT_ITEM *pitem, jPLOT_SCALE *scale, unsigned int scaling)
{
   if (pitem == NULL)
      return;

   // sets everything but Manual axis options in case (scale == NULL)
   pitem->scaling = scaling & 0xFFF8;

   if (scale == NULL)
      return;

   if (scaling & ManualX)
   {
      pitem->scaling |= ManualX;
      pitem->scales.xmin = scale->xmin;
      pitem->scales.xmax = scale->xmax;
      pitem->scales.xstep = scale->xstep;
      pitem->scales.xtick = scale->xtick;
      if (strlen (scale->xformat) > 0)
         my_strncpy (pitem->scales.xformat,scale->xformat,MAX_FORMAT_LENGTH);
   }

   if (scaling & ManualY1)
   {
      pitem->scaling |= ManualY1;
      pitem->scales.y1min = scale->y1min;
      pitem->scales.y1max = scale->y1max;
      pitem->scales.y1step = scale->y1step;
      pitem->scales.y1tick = scale->y1tick;
      if (strlen (scale->y1format) > 0)
         my_strncpy (pitem->scales.y1format,scale->y1format,MAX_FORMAT_LENGTH);
   }

   if (scaling & ManualY2)
   {
      pitem->scaling |= ManualY2;
      pitem->scales.y2min = scale->y2min;
      pitem->scales.y2max = scale->y2max;
      pitem->scales.y2step = scale->y2step;
      pitem->scales.y2tick = scale->y2tick;
      if (strlen (scale->y2format) > 0)
         my_strncpy (pitem->scales.y2format,scale->y2format,MAX_FORMAT_LENGTH);
   }
}

/******************************************************************************/
/******************************************************************************/

void set_x_scale (jPLOT_ITEM *pitem, double start, double stop, double step, int tick, BOOL islog, const char *format)
{
   if (pitem == NULL)
      return;

   pitem->scales.xmin  = start;
   pitem->scales.xmax  = stop;
   pitem->scales.xstep = step;
   pitem->scales.xtick = tick;
   pitem->scaling     |= ManualX;
   if (islog)
      pitem->scaling |= LogX;

   if (strlen (format) > 0)
      my_strncpy (pitem->scales.xformat,format,MAX_FORMAT_LENGTH);
}

/******************************************************************************/
/******************************************************************************/

void set_y1_scale (jPLOT_ITEM *pitem, double start, double stop, double step, int tick, BOOL islog, const char *format)
{
   if (pitem == NULL)
      return;

   pitem->scales.y1min  = start;
   pitem->scales.y1max  = stop;
   pitem->scales.y1step = step;
   pitem->scales.y1tick = tick;
   pitem->scaling      |= ManualY1;
   if (islog)
      pitem->scaling |= LogY1;

   if (strlen (format) > 0)
      my_strncpy (pitem->scales.y1format,format,MAX_FORMAT_LENGTH);
}

/******************************************************************************/
/******************************************************************************/

void set_y2_scale (jPLOT_ITEM *pitem, double start, double stop, double step, int tick, BOOL islog, const char *format)
{
   if (pitem == NULL)
      return;

   pitem->scales.y2min  = start;
   pitem->scales.y2max  = stop;
   pitem->scales.y2step = step;
   pitem->scales.y2tick = tick;
   pitem->scaling      |= ManualY2;
   if (islog)
      pitem->scaling |= LogY2;

   if (strlen (format) > 0)
      my_strncpy (pitem->scales.y2format,format,MAX_FORMAT_LENGTH);
}

/******************************************************************************/
/******************************************************************************/

void set_axis_labels (jPLOT_ITEM *pitem, const char *xlab, const char *y1lab, const char *y2lab, const char *title)
{
   if (pitem == NULL)
      return;

   if (xlab != NULL)
      my_strncpy (pitem->x_label,xlab,MAX_LABEL_LENGTH);
   else
      pitem->x_label[0] = 0;

   if (y1lab != NULL)
      my_strncpy (pitem->y1_label,y1lab,MAX_LABEL_LENGTH);
   else
      pitem->y1_label[0] = 0;

   if (y2lab != NULL)
      my_strncpy (pitem->y2_label,y2lab,MAX_LABEL_LENGTH);
   else
      pitem->y2_label[0] = 0;

   if (title != NULL)
      my_strncpy (pitem->title,title,MAX_LABEL_LENGTH);
   else
      pitem->title[0] = 0;
}

/******************************************************************************/
/******************************************************************************/

void set_plot_item_attributes (jPLOT_ITEM *pitem, jPLOT_ATTRIBS *attribs, unsigned int mask)
{
   if (pitem == NULL)
      return;
   else if (attribs == NULL)
      return;

   if (mask & JPA_FONTS)
   {
      pitem->attribs.label_font = attribs->label_font;
      pitem->attribs.title_font = attribs->title_font;
      pitem->attribs.axis_font  = attribs->axis_font;
   }

   if (mask & JPA_TEXTSIZE)
   {
      pitem->attribs.label_tsize = attribs->label_tsize;
      pitem->attribs.title_tsize = attribs->title_tsize;
      pitem->attribs.axis_tsize  = attribs->axis_tsize;
   }

   if (mask & JPA_LABELOFFSETS)
   {
      pitem->attribs.xlabel_offset = attribs->xlabel_offset;
      pitem->attribs.ylabel_offset = attribs->ylabel_offset;
      pitem->attribs.title_offset  = attribs->title_offset;
   }

   if (mask & JPA_AXISOFFSETS)
   {
      pitem->attribs.xnum_offset = attribs->xnum_offset;
      pitem->attribs.ynum_offset = attribs->ynum_offset;
   }

   if (mask & JPA_TICKSIZE)
   {
      pitem->attribs.major_tick = attribs->major_tick;
      pitem->attribs.minor_tick = attribs->minor_tick;
   }
}

/******************************************************************************/
/******************************************************************************/

void list_installed_drivers (BOOL full_info)
{
   int i;

   fprintf (stderr,"\n");

   if (full_info)
   {
      fprintf (stderr,"  # : NAME : DESCRIPTION : VERSION\n");
      fprintf (stderr,"------------------------------------\n");
   }
   else
   {
      fprintf (stderr,"  # : NAME\n");
      fprintf (stderr,"------------\n");
   }

   for (i = 0; i < NUMBER_OF_INSTALLED_DRIVERS; ++i)
   {
      fprintf (stderr," %2d : %s",DRIVERS[i].id,DRIVERS[i].name);
      if (full_info)
         fprintf (stderr," : %s : %s\n",DRIVERS[i].description,DRIVERS[i].version);
      else
         fprintf (stderr,"\n");
   }

   fprintf (stderr,"\n");
}

/******************************************************************************/
/******************************************************************************/

BOOL open_graphics_device_stdin (BOOL full_info)
{
   char string[MAX_FILENAME_LENGTH+1];
   char filename[MAX_FILENAME_LENGTH+1];
   int flag,dnum;

   list_installed_drivers (full_info);
   fprintf (stderr,"Driver Number?\n");

   do {
      string[0] = 0;
      fgets (string,MAX_FILENAME_LENGTH,stdin);
      if ((string[0] < 48) || (string[0] > 57))
         flag = 0;
      else
         flag = sscanf (string,"%d",&dnum);
   }
   while (!flag);

   fprintf (stderr,"Plot File Name?\n");
   fgets (string,MAX_FILENAME_LENGTH,stdin);
   sscanf (string,"%s",filename);

   return open_graphics_device (dnum,filename);
}

/******************************************************************************/
/******************************************************************************/

const char *get_error_message (int error_num)
{
   static ERROR_NAMES errors[] = {
      {0,  "No errors have been logged."},
      {101,"Invalid driver ID."},
      {102,"No open graphics driver."},
      {103,"Execution of page draw failed."},
      {104,"Memory allocation failed."},
      {105,"Invalid plot item address."},
      {106,"Invalid parameter."},
      {201,"Graphics driver failed to open."},
      {202,"Failed to open output file."},
      {203,"Abnormal driver termination."}};

#define NERRS  10

      static char *unknown = "Unknown error.";
      int  i = 0;

      for (i = 0; i < NERRS; ++i)
      {
         if (error_num == errors[i].errno)
            return errors[i].desc;
      }

      if (driver_num > -1)
      {
         if (DRIVERS[driver_num].errors != NULL)
         {
            for (i = 0; i < DRIVERS[driver_num].szErrors; ++i)
            {
               if (error_num == DRIVERS[driver_num].errors[i].errno)
                  return DRIVERS[driver_num].errors[i].desc;
            }
         }
      }

      return unknown;
}

/******************************************************************************/
/******************************************************************************/
/*****                                                                    *****/
/*****                      INTERNAL FUNCTIONS                            *****/
/*****                                                                    *****/
/******************************************************************************/
/******************************************************************************/

static BOOL draw_all_active_items (void)
{
   jPLOT_ITEM *ptr  = pPlotItems;
   jPLOT_USER *uptr = pUserItems;

   // draw all active plot items
   while (ptr != NULL)
   {
      if (ptr->active)
         if (!draw_plot_item (ptr))
            return FALSE;
      ptr = ptr->next;
   }

   // draws all user items (lines, text, etc.)
   while (uptr != NULL)
   {
      if (!draw_user_item (uptr))
         return FALSE;
      uptr = uptr->next;
   }

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

static void translate1 (double x, double y, double ang, double *xp, double *yp)
{
   double d,phi;

   // get ang into the correct range
   fix_angle (ang);

   // translate the coords - with some tolerance
   if ((ang > -0.1) && (ang < 0.1))
   {
      *xp = x;
      *yp = y;
   }
   else if ((ang > 89.9) && (ang < 90.1))
   {
      *xp = -y;
      *yp = x;
   }
   else if ((ang > 179.9) || (ang < -179.9))
   {
      *xp = -x;
      *yp = -y;
   }
   else if ((ang > -90.1) && (ang < -89.9))
   {
      *xp = y;
      *yp = -x;
   }
   else if ((x == 0.0) && (y == 0.0))
   {
      *xp = x;
      *yp = y;
   }
   else
   {
      d = sqrt (x*x + y*y);
      phi = ang + RAD2DEG * atan2(y,x);
      *xp = d*cos (phi*DEG2RAD);
      *yp = d*sin (phi*DEG2RAD);
   }
}

/******************************************************************************/
/******************************************************************************/

static double safelog (double x)
{
   if (x < 1.0e-25)
      return log10 (1.0e-25);
   else
      return log10 (x);
}

/******************************************************************************/
/******************************************************************************/

static jPLOT_USER *add_user_item (int type)
{
   jPLOT_USER  *item,*ptr;
   static jHANDLE last_handle = 0L;

   item = (jPLOT_USER *) malloc (sizeof(jPLOT_USER));
   if (!item)
      return NULL;

   item->next = NULL;

   if (pUserItems == NULL)
      pUserItems = item;
   else
   {
      ptr = pUserItems;
      while (ptr->next != NULL)
         ptr = ptr->next;

      ptr->next = item;
   }

   ++last_handle;
   item->handle = last_handle;
   item->type = type;

   return item;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_line(double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor)
{
   return DRIVERS[driver_num].draw_line(x1,y1,x2,y2,ltype,lwidth,lcolor);
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_polyline(double *x, double *y, int n, int ltype, int lwidth, int lcolor)
{
   int    i;
   BOOL   status = TRUE;

   if (DRIVERS[driver_num].draw_polyline != NULL)
      return DRIVERS[driver_num].draw_polyline(x,y,n,ltype,lwidth,lcolor);

   for (i = 1; i < n; ++i)
      status = DRIVERS[driver_num].draw_line(x[i-1],y[i-1],x[i],y[i],ltype,lwidth,lcolor) && status;

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_text(char *strng, double x, double y, int font, int size, double angle, int justify,int color, int style)
{
   return (strlen (strng) < 1) ? TRUE : DRIVERS[driver_num].draw_text(strng,x,y,font,size,angle,justify,color,style);
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_para_text (const char *strng, double x, double y, int font, int size, double angle, int justify, int color, int style)
{
   int    i,j,len;
   BOOL   flag = FALSE;
   char   *tmps;
   double x1,y1,xoff,yoff;

   len = strlen (strng);
   if (len < 1)
      return TRUE;

   for (i = 0; i < (len-1); ++i)
   {
      if (strng[i] == '\n')
         flag = TRUE;
   }

   if (flag)
   {
      tmps = (char *) malloc (sizeof(char)*(len+1));
      x1 = x;
      y1 = y;
      translate1 (0.0,-(paragraph_aspect*((double) size)/72.0),angle,&xoff,&yoff);
      for (i = 0, j = 0; i <= len; ++i, ++j)
      {
         if ((strng[i] == '\n') || (i == len))
         {
            tmps[j] = 0;
            if (strlen (tmps) > 0)
               flag = DRIVERS[driver_num].draw_text (tmps,x1,y1,font,size,angle,justify,color,style) && flag;
            x1 += xoff;
            y1 += yoff;
            j = -1;
         }
         else
            tmps[j] = strng[i];
      }

      free ((void *) tmps);
      return flag;
   }
   else
      return DRIVERS[driver_num].draw_text (strng,x,y,font,size,angle,justify,color,style);
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_rectangle (double x1, double y1, double xsz, double ysz, double angle, int ltype, int lwidth, int lcolor)
{
   double xf[5],yf[5];
   double x,y;

   if (DRIVERS[driver_num].draw_rectangle != NULL)
      return DRIVERS[driver_num].draw_rectangle (x1,y1,xsz,ysz,angle,ltype,lwidth,lcolor);

   xf[0] = xf[4] = x1;
   yf[0] = yf[4] = y1;
   translate1 (0.0,ysz,angle,&x,&y);
   xf[1] = x1+x;
   yf[1] = y1+y;
   translate1 (xsz,ysz,angle,&x,&y);
   xf[2] = x1+x;
   yf[2] = y1+y;
   translate1 (xsz,0.0,angle,&x,&y);
   xf[3] = x1+x;
   yf[3] = y1+y;

   return draw_polyline (xf,yf,5,ltype,lwidth,lcolor);
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_circle (double x, double y, double rad, int ltype, int lwidth, int lcolor)
{
   int     i,nsegs;
   double  ainc,ang = 0.0,*xx,*yy;
   double  MAX_ARCSEG_LENGTH;
   BOOL    status;

   if (DRIVERS[driver_num].draw_circle != NULL)
      return DRIVERS[driver_num].draw_circle (x,y,rad,ltype,lwidth,lcolor);

   if (rad < 0.005)
      return FALSE;

   if (rad < 0.1)
      MAX_ARCSEG_LENGTH = 0.02;
   else if (rad < 1.0)
      MAX_ARCSEG_LENGTH = 0.05;
   else if (rad < 5.0)
      MAX_ARCSEG_LENGTH = 0.1;
   else if (rad < 10.0)
      MAX_ARCSEG_LENGTH = 0.5;
   else
      MAX_ARCSEG_LENGTH = 1.0;

   nsegs = ((int)(2.0*PI*rad/MAX_ARCSEG_LENGTH)) + 1;
   if (nsegs < 8)
      nsegs = 8;

   ainc = 360.0/((double) nsegs);

   xx = (double *) malloc (sizeof(double)*(nsegs+1));
   yy = (double *) malloc (sizeof(double)*(nsegs+1));

   xx[0] = x + rad*cos(ang*DEG2RAD);
   yy[0] = y + rad*sin(ang*DEG2RAD);
   for (i = 1; i <= nsegs; ++i)
   {
      ang += ainc;
      xx[i] = x + rad*cos(ang*DEG2RAD);
      yy[i] = y + rad*sin(ang*DEG2RAD);
   }

   status = draw_polyline (xx,yy,nsegs+1,ltype,lwidth,lcolor);

   free ((void *) xx);
   free ((void *) yy);

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_arc (double x, double y, double rad, double astart, double aend, int ltype, int lwidth, int lcolor)
{
   int     i = 1,nsegs,finished = 0,zero_cross = 0;
   double  ainc,ang,*xx,*yy;
   double  MAX_ARCSEG_LENGTH;
   BOOL    status;

   if (rad < 0.005)
      return FALSE;
   else if (astart == aend)
      return draw_circle (x,y,rad,ltype,lwidth,lcolor);

   if (DRIVERS[driver_num].draw_arc != NULL)
      return DRIVERS[driver_num].draw_arc (x,y,rad,astart,aend,ltype,lwidth,lcolor);

   if (rad < 0.1)
      MAX_ARCSEG_LENGTH = 0.02;
   else if (rad < 1.0)
      MAX_ARCSEG_LENGTH = 0.05;
   else if (rad < 5.0)
      MAX_ARCSEG_LENGTH = 0.1;
   else if (rad < 10.0)
      MAX_ARCSEG_LENGTH = 0.5;
   else
      MAX_ARCSEG_LENGTH = 1.0;

   nsegs = ((int)(2.0*PI*rad/MAX_ARCSEG_LENGTH)) + 1;
   if (nsegs < 5)
      nsegs = 5;

   ainc = 360.0/((double) nsegs);

   xx = (double *) malloc (sizeof(double)*(nsegs+2));
   yy = (double *) malloc (sizeof(double)*(nsegs+2));

   fix_angle (astart);
   fix_angle (aend);

   // start angle is positive, end angle is negative
   if (astart > aend)
      zero_cross = 1;

   xx[0] = x + rad*cos(astart*DEG2RAD);
   yy[0] = y + rad*sin(astart*DEG2RAD);
   ang = astart;
   while (!finished)
   {
      ang += ainc;
      if ((ang > 180.0) && zero_cross)
      {
         ang -= 360.0;
         zero_cross = 0;
      }

      if ((ang >= aend) && !zero_cross)
      {
         ang = aend;
         finished = 1;
      }

      xx[i] = x + rad*cos(ang*DEG2RAD);
      yy[i] = y + rad*sin(ang*DEG2RAD);
      ++i;
   }

   status = draw_polyline (xx,yy,i,ltype,lwidth,lcolor);

   free ((void *) xx);
   free ((void *) yy);

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_scatter_point (double x, double y, int ptype, int lwidth, int color)
{
   BOOL status = TRUE;

   switch (ptype)
   {
   case PNT_X:
      status = draw_line (x-0.025,y-0.025,x+0.025,y+0.025,LT_SOLID,lwidth,color) && status;
      status = draw_line (x-0.025,y+0.025,x+0.025,y-0.025,LT_SOLID,lwidth,color) && status;
      break;

   case PNT_TRIANGLE:
      status = draw_line (x-0.025,y-0.025,x+0.025,y-0.025,LT_SOLID,lwidth,color) && status;
      status = draw_line (x-0.025,y-0.025,x,y+0.025,LT_SOLID,lwidth,color) && status;
      status = draw_line (x+0.025,y-0.025,x,y+0.025,LT_SOLID,lwidth,color) && status;
      break;

   case PNT_CIRCLE:
      status = draw_circle (x,y,0.025,LT_SOLID,lwidth,color) && status;
      break;

   case PNT_SQUARE:
      status = draw_rectangle (x-0.025,y-0.025,0.05,0.05,0.0,LT_SOLID,lwidth,color) && status;
      break;

   default:
   case PNT_PLUS:
      status = draw_line (x-0.025,y,x+0.025,y,LT_SOLID,lwidth,color) && status;
      status = draw_line (x,y-0.025,x,y+0.025,LT_SOLID,lwidth,color) && status;
      break;
   }

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_polypoints (double *x, double *y, int n, int ptype, int lwidth, int lcolor)
{
   int i;
   BOOL status = TRUE;

   for (i = 0; i < n; ++i)
      status = draw_scatter_point (x[i],y[i],ptype,lwidth,lcolor) && status;

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_legend (jPLOT_USER *item)
{
   double x   = item->ptr[1].dVal[0];
   double y   = item->ptr[1].dVal[1];
   double ang = item->ptr[1].dVal[2];
   double xoffset = 0.5;
   double yoffset,inc,theight;
   double x1,y1,x2,y2;
   int    i;
   BOOL   status = TRUE;

   theight = item->ptr[2].iVal[2]/72.0;
   yoffset = theight*0.5;
   inc = theight*paragraph_aspect;

   for (i = 0; i < item->ptr[2].iVal[0]; ++i)
   {
      if (item->ptr[2].iVal[3*i+3] > MAX_LINETYPE)
      {
         translate1 (x+xoffset/2.0,y-yoffset-inc*i,ang,&x1,&y1);
         status = draw_scatter_point (x1,y1,item->ptr[2].iVal[3*i+3],item->ptr[2].iVal[3*i+4],
            item->ptr[2].iVal[3*i+5]) && status;
      }
      else
      {
         translate1(x,y-yoffset-inc*i,ang,&x1,&y1);
         translate1(x+xoffset,y-yoffset-inc*i,ang,&x2,&y2);
         status = draw_line (x1,y1,x2,y2,item->ptr[2].iVal[3*i+3],item->ptr[2].iVal[3*i+4],
            item->ptr[2].iVal[3*i+5]) && status;
      }
   }

   translate1(x+xoffset+0.1,y-theight,ang,&x1,&y1);
   status = draw_para_text (item->ptr[0].strg,x1,y1,item->ptr[2].iVal[1],item->ptr[2].iVal[2],ang,
      LEFT_JUSTIFY,CLR_BLACK,NO_STYLE) && status;

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_plot_item (jPLOT_ITEM *pitem)
{
   BOOL status = TRUE;

   // checks scales for validity/autoscales
   autoscale (pitem);

   switch (pitem->plot_type)
   {
   case SingleY:
   case DoubleY:
   case XYContour:
      status = draw_rect_axes (pitem) && status;
      status = draw_rect_data (pitem) && status;
      status = draw_contour_data (pitem) && status;
      break;
   case SmithChart:
   case SmithContour:
      status = draw_smith_axes (pitem) && status;
      status = draw_polar_data (pitem) && status;
      status = draw_contour_data (pitem) && status;
      break;
   case PolarChart:
   case PolarContour:
      status = draw_polar_axes (pitem) && status;
      status = draw_polar_data (pitem) && status;
      status = draw_contour_data (pitem) && status;
      break;
   }

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_user_item (jPLOT_USER *uitem)
{
   switch (uitem->type)
   {
   case USER_LINE:
      if (uitem->ptr[1].iVal[0] > MAX_LINETYPE)
         return draw_scatter_point (uitem->ptr[0].dVal[0],uitem->ptr[0].dVal[1],
         uitem->ptr[1].iVal[0],uitem->ptr[1].iVal[1],uitem->color);
      else
         return draw_line (uitem->ptr[0].dVal[0],uitem->ptr[0].dVal[1],uitem->ptr[0].dVal[2],
         uitem->ptr[0].dVal[3],uitem->ptr[1].iVal[0],uitem->ptr[1].iVal[1],uitem->color);
   case USER_POLYLINE:
      if (uitem->ptr[2].iVal[1] > MAX_LINETYPE)
         return draw_polypoints (uitem->ptr[0].dVal,uitem->ptr[1].dVal,uitem->ptr[2].iVal[0],
         uitem->ptr[2].iVal[1],uitem->ptr[2].iVal[2],uitem->color);
      else
         return draw_polyline (uitem->ptr[0].dVal,uitem->ptr[1].dVal,uitem->ptr[2].iVal[0],
         uitem->ptr[2].iVal[1],uitem->ptr[2].iVal[2],uitem->color);
   case USER_TEXT:
      return draw_para_text (uitem->ptr[0].strg,uitem->ptr[1].dVal[0],uitem->ptr[1].dVal[1],
         uitem->ptr[2].iVal[0],uitem->ptr[2].iVal[1],uitem->ptr[1].dVal[2],
         uitem->ptr[2].iVal[2],uitem->color,uitem->ptr[2].iVal[3]);
   case USER_LEGEND:
      return draw_legend (uitem);
   case USER_CIRCLE:
      return draw_circle(uitem->ptr[0].dVal[0],uitem->ptr[0].dVal[1],uitem->ptr[0].dVal[2],
         uitem->ptr[1].iVal[0],uitem->ptr[1].iVal[1],uitem->color);
   case USER_ARC:
      return draw_arc (uitem->ptr[0].dVal[0],uitem->ptr[0].dVal[1],uitem->ptr[0].dVal[2],
         uitem->ptr[0].dVal[3],uitem->ptr[0].dVal[4],uitem->ptr[1].iVal[0],uitem->ptr[1].iVal[1],
         uitem->color);
   default:
      break;
   }

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_rect_axes (jPLOT_ITEM *pitem)
{
   double   x1,y1,x,y;
   double   ang,txoff,tyoff,ftsz;
   int      tsz,tfont;
   BOOL     status = TRUE;

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;
   ang = pitem->angle;

   txoff = pitem->attribs.xlabel_offset;
   tyoff = pitem->attribs.ylabel_offset;
   tsz   = pitem->attribs.label_tsize;
   tfont = pitem->attribs.label_font;
   ftsz  = ((double) tsz)/72.0;

   // draw the frame
   status = draw_rectangle (x1,y1,pitem->x_frame_size,pitem->y_frame_size,ang,LT_SOLID,LW_MEDIUM,CLR_BLACK) && status;

   // draw the x-axis
   if ((pitem->scaling & LogX) && (pitem->plot_type != XYContour))
      status = draw_log_rect_axis (pitem,Xaxis) && status;
   else
      status = draw_linear_rect_axis (pitem,Xaxis) && status;

   translate1 (pitem->x_frame_size/2.0,-(txoff+ftsz),ang,&x,&y);
   status = draw_text (pitem->x_label,x1+x,y1+y,tfont,tsz,ang,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE) && status;

   // draw the y1-axis
   if ((pitem->scaling & LogY1) && (pitem->plot_type != XYContour))
      status = draw_log_rect_axis (pitem,Y1axis) && status;
   else
      status = draw_linear_rect_axis (pitem,Y1axis) && status;

   translate1 (-tyoff,pitem->y_frame_size/2.0,ang,&x,&y);
   status = draw_text (pitem->y1_label,x1+x,y1+y,tfont,tsz,ang+90.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE) && status;

   // draw the y2-axis
   if (pitem->plot_type == DoubleY)
   {
      if (pitem->scaling & LogY2)
         status = draw_log_rect_axis (pitem,Y2axis) && status;
      else
         status = draw_linear_rect_axis (pitem,Y2axis) && status;

      translate1 (pitem->x_frame_size+tyoff,pitem->y_frame_size/2.0,ang,&x,&y);
      status = draw_text (pitem->y2_label,x1+x,y1+y,tfont,tsz,ang-90.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE) && status;
   }

   // draw the title
   translate1 (pitem->x_frame_size/2.0,pitem->y_frame_size+pitem->attribs.title_offset,ang,&x,&y);
   status = draw_text (pitem->title,x1+x,y1+y,pitem->attribs.title_font,pitem->attribs.title_tsize,ang,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE) && status;

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_linear_rect_axis (jPLOT_ITEM *pitem, int axis)
{
   double   amin,amax,astep;
   double   nsteps,moff,toff;
   double   x1,y1,x,y;
   double   step_scale,tick_scale,asize,ftsz;
   double   matickx,maticky,mitickx,miticky;
   double   textx,texty,gridx,gridy,ang;
   int      ndivs,atick,grid;
   int      i,j;
   char     string[20];
   BOOL     status = TRUE;

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;
   ang = pitem->angle;
   ftsz = ((double) pitem->attribs.axis_tsize)/72.0;

   switch (axis)
   {
   case Xaxis:
      amin = pitem->scales.xmin;
      amax = pitem->scales.xmax;
      astep = pitem->scales.xstep;
      atick = pitem->scales.xtick;
      asize = pitem->x_frame_size;

      if (pitem->flags & NO_XGRID)
         grid = 0;
      else
         grid = 1;

      // calculate offsets for faster drawing (less translation math)
      translate1 (0.0,pitem->attribs.major_tick,ang,&matickx,&maticky);
      translate1 (0.0,pitem->attribs.minor_tick,ang,&mitickx,&miticky);
      translate1 (0.0,pitem->y_frame_size,ang,&gridx,&gridy);
      translate1 (0.0,-(pitem->attribs.xnum_offset + ftsz),ang,&textx,&texty);
      break;
   case Y1axis:
      amin = pitem->scales.y1min;
      amax = pitem->scales.y1max;
      astep = pitem->scales.y1step;
      atick = pitem->scales.y1tick;
      asize = pitem->y_frame_size;

      if (pitem->flags & NO_YGRID)
         grid = 0;
      else
         grid = 1;

      // calculate offsets for faster drawing (less translation math)
      translate1 (pitem->attribs.major_tick,0.0,ang,&matickx,&maticky);
      translate1 (pitem->attribs.minor_tick,0.0,ang,&mitickx,&miticky);
      translate1 (pitem->x_frame_size,0.0,ang,&gridx,&gridy);
      translate1 (-pitem->attribs.ynum_offset,-ftsz/2.0,ang,&textx,&texty);
      break;
   case Y2axis:
      amin = pitem->scales.y2min;
      amax = pitem->scales.y2max;
      astep = pitem->scales.y2step;
      atick = pitem->scales.y2tick;
      asize = pitem->y_frame_size;

      grid = 0;

      // calculate offsets for faster drawing (less translation math)
      translate1 (-pitem->attribs.major_tick,0.0,ang,&matickx,&maticky);
      translate1 (-pitem->attribs.minor_tick,0.0,ang,&mitickx,&miticky);
      translate1 (-pitem->x_frame_size,0.0,ang,&gridx,&gridy);
      translate1 (pitem->attribs.ynum_offset,-ftsz/2.0,ang,&textx,&texty);

      // axis origin is not the same as X and Y1 axes
      translate1 (pitem->x_frame_size,0.0,ang,&x,&y);
      x1 += x;
      y1 += y;
      break;
   default:
      return TRUE;
   }

   nsteps = (amax-amin)/astep;
   if (nsteps < 1.0)
      astep = (amax-amin);
   else if (fmod ((amax-amin),astep) != 0.0)
   {
      astep = (amax-amin)/floor(nsteps+0.5);
      nsteps = (amax-amin)/astep;
   }

   ndivs = (int) (nsteps+0.1);
   if (ndivs < 1)
   {
      ndivs = 1;
      astep = amax-amin;
   }

   if (atick < 1)
      atick = 1;

   step_scale = asize/((double) ndivs);
   tick_scale = step_scale/((double) atick);

   // draw the major and minor axis ticks and the grid
   for (i = 0; i < ndivs; ++i)
   {
      moff = ((double) i)*step_scale;

      for (j = 1; j < atick; ++j)
      {
         toff = moff + tick_scale*((double) j);
         if (axis == Xaxis)
         {
            translate1 (toff,0.0,ang,&x,&y);
            status = draw_line (x1+x,y1+y,x1+x+mitickx,y1+y+miticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
         }
         else
         {
            translate1 (0.0,toff,ang,&x,&y);
            status = draw_line (x1+x,y1+y,x1+x+mitickx,y1+y+miticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
         }
      }

      if (i == 0)
         continue;

      if (axis == Xaxis)
      {
         translate1 (moff,0.0,ang,&x,&y);
         status = draw_line (x1+x,y1+y,x1+x+matickx,y1+y+maticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
         if (grid)
            status = draw_line (x1+x,y1+y,x1+x+gridx,y1+y+gridy,LT_DOTTED,LW_THIN,CLR_BLACK) && status;
      }
      else
      {
         translate1 (0.0,moff,ang,&x,&y);
         status = draw_line (x1+x,y1+y,x1+x+matickx,y1+y+maticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
         if (grid)
            status = draw_line (x1+x,y1+y,x1+x+gridx,y1+y+gridy,LT_DOTTED,LW_THIN,CLR_BLACK) && status;
      }
   }

   // draw the axis text
   for (i = 0; i <= ndivs; ++i)
   {
      switch (axis)
      {
      case Xaxis:
         sprintf (string,pitem->scales.xformat,amin+astep*((double) i));
         moff = ((double) i)*step_scale;
         translate1 (moff,0.0,ang,&x,&y);
         status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,CENTER_JUSTIFY,CLR_BLACK,0) && status;
         break;
      case Y1axis:
         sprintf (string,pitem->scales.y1format,amin+astep*((double) i));
         moff = ((double) i)*step_scale;
         translate1 (0.0,moff,ang,&x,&y);
         status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,RIGHT_JUSTIFY,CLR_BLACK,0) && status;
         break;
      case Y2axis:
         sprintf (string,pitem->scales.y2format,amin+astep*((double) i));
         moff = ((double) i)*step_scale;
         translate1 (0.0,moff,ang,&x,&y);
         status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,LEFT_JUSTIFY,CLR_BLACK,0) && status;
         break;
      }
   }

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_log_rect_axis (jPLOT_ITEM *pitem, int axis)
{
   double   amin,amax,astep;
   double   nsteps,moff,toff;
   double   x1,y1,x,y;
   double   step_scale,asize,ftsz;
   double   matickx,maticky,mitickx,miticky;
   double   textx,texty,gridx,gridy,ang;
   int      atick,grid,minor_grid;
   int      i,j;
   char     string[20];
   BOOL     status = TRUE;

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;
   ang = pitem->angle;
   ftsz = ((double) pitem->attribs.axis_tsize)/72.0;

   switch (axis)
   {
   case Xaxis:
      amin = pitem->scales.xmin;
      amax = pitem->scales.xmax;
      astep = pitem->scales.xstep;
      atick = pitem->scales.xtick;
      asize = pitem->x_frame_size;

      if (pitem->flags & NO_XGRID)
         grid = 0;
      else
         grid = 1;

      if (pitem->flags & FULL_LOG_XGRID)
         minor_grid = 1;
      else
         minor_grid = 0;

      // calculate offsets for faster drawing (less translation math)
      translate1 (0.0,pitem->attribs.major_tick,ang,&matickx,&maticky);
      translate1 (0.0,pitem->attribs.minor_tick,ang,&mitickx,&miticky);
      translate1 (0.0,pitem->y_frame_size,ang,&gridx,&gridy);
      translate1 (0.0,-(pitem->attribs.xnum_offset + ftsz),ang,&textx,&texty);
      break;
   case Y1axis:
      amin = pitem->scales.y1min;
      amax = pitem->scales.y1max;
      astep = pitem->scales.y1step;
      atick = pitem->scales.y1tick;
      asize = pitem->y_frame_size;

      if (pitem->flags & NO_YGRID)
         grid = 0;
      else
         grid = 1;

      if (pitem->flags & FULL_LOG_YGRID)
         minor_grid = 1;
      else
         minor_grid = 0;

      // calculate offsets for faster drawing (less translation math)
      translate1 (pitem->attribs.major_tick,0.0,ang,&matickx,&maticky);
      translate1 (pitem->attribs.minor_tick,0.0,ang,&mitickx,&miticky);
      translate1 (pitem->x_frame_size,0.0,ang,&gridx,&gridy);
      translate1 (-pitem->attribs.ynum_offset,0.0,ang,&textx,&texty);
      break;
   case Y2axis:
      amin = pitem->scales.y2min;
      amax = pitem->scales.y2max;
      astep = pitem->scales.y2step;
      atick = pitem->scales.y2tick;
      asize = pitem->y_frame_size;

      grid = 0;
      minor_grid = 0;

      // calculate offsets for faster drawing (less translation math)
      translate1 (-pitem->attribs.major_tick,0.0,ang,&matickx,&maticky);
      translate1 (-pitem->attribs.minor_tick,0.0,ang,&mitickx,&miticky);
      translate1 (-pitem->x_frame_size,0.0,ang,&gridx,&gridy);
      translate1 (pitem->attribs.ynum_offset,0.0,ang,&textx,&texty);

      // axis origin is not the same as X and Y1 axes
      translate1 (pitem->x_frame_size,0.0,ang,&x,&y);
      x1 += x;
      y1 += y;
      break;
   default:
      return TRUE;
   }

   nsteps = safelog (amax/amin);

   if (nsteps < 1.0)
   {
      atick = 1;
      astep = 10.0;
      minor_grid = grid;
      nsteps = 0.1;
   }
   else if (astep == 100.0)
   {
      nsteps = nsteps/2.0;
      atick = 0;
      minor_grid = 0;
   }
   else if (astep == 1000.0)
   {
      nsteps = nsteps/3.0;
      atick = 0;
      minor_grid = 0;
   }

   step_scale = asize/nsteps;

   i = 1;
   do {
      moff = ((double) (i-1))*step_scale;

      if (atick)
      {
         for (j = 2; j < 10; ++j)
         {
            toff = moff + step_scale * log10 ((double) j);
            if (toff >= asize)
               break;

            if (axis == Xaxis)
            {
               translate1 (toff,0.0,ang,&x,&y);
               status = draw_line (x1+x,y1+y,x1+x+mitickx,y1+y+miticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
               if (minor_grid)
                  status = draw_line (x1+x,y1+y,x1+x+gridx,y1+y+gridy,LT_DOTTED,LW_THIN,CLR_BLACK) && status;
            }
            else
            {
               translate1 (0.0,toff,ang,&x,&y);
               status = draw_line (x1+x,y1+y,x1+x+mitickx,y1+y+miticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
               if (minor_grid)
                  status = draw_line (x1+x,y1+y,x1+x+gridx,y1+y+gridy,LT_DOTTED,LW_THIN,CLR_BLACK) && status;
            }
         }
      }

      if ((i != 1) && (moff < asize))
      {
         if (axis == Xaxis)
         {
            translate1 (moff,0.0,ang,&x,&y);
            status = draw_line (x1+x,y1+y,x1+x+matickx,y1+y+maticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
            if (grid)
               status = draw_line (x1+x,y1+y,x1+x+gridx,y1+y+gridy,LT_DOTTED,LW_THIN,CLR_BLACK) && status;
         }
         else
         {
            translate1 (0.0,moff,ang,&x,&y);
            status = draw_line (x1+x,y1+y,x1+x+matickx,y1+y+maticky,LT_SOLID,LW_THIN,CLR_BLACK) && status;
            if (grid)
               status = draw_line (x1+x,y1+y,x1+x+gridx,y1+y+gridy,LT_DOTTED,LW_THIN,CLR_BLACK) && status;
         }

         switch (axis)
         {
         case Xaxis:
            sprintf (string,pitem->scales.xformat,amin*pow (astep,(double) (i-1)));
            translate1 (moff,0.0,ang,&x,&y);
            status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,CENTER_JUSTIFY,CLR_BLACK,0) && status;
            break;
         case Y1axis:
            sprintf (string,pitem->scales.y1format,amin*pow (astep,(double) (i-1)));
            translate1 (0.0,moff-ftsz/2.0,ang,&x,&y);
            status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,RIGHT_JUSTIFY,CLR_BLACK,0) && status;
            break;
         case Y2axis:
            sprintf (string,pitem->scales.y2format,amin*pow (astep,(double) (i-1)));
            translate1 (0.0,moff-ftsz/2.0,ang,&x,&y);
            status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,LEFT_JUSTIFY,CLR_BLACK,0) && status;
            break;
         }
      }

      ++i;
   }
   while (moff < asize);

   // draw the min and max text
   switch (axis)
   {
   case Xaxis:
      sprintf (string,pitem->scales.xformat,amin);
      x = y = 0.0;
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,CENTER_JUSTIFY,CLR_BLACK,0) && status;
      sprintf (string,pitem->scales.xformat,amax);
      translate1 (asize,0.0,ang,&x,&y);
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,CENTER_JUSTIFY,CLR_BLACK,0) && status;
      break;
   case Y1axis:
      sprintf (string,pitem->scales.y1format,amin);
      translate1 (0.0,-ftsz/2.0,ang,&x,&y);
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,RIGHT_JUSTIFY,CLR_BLACK,0) && status;
      sprintf (string,pitem->scales.y1format,amax);
      translate1 (0.0,asize-ftsz/2.0,ang,&x,&y);
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,RIGHT_JUSTIFY,CLR_BLACK,0) && status;
      break;
   case Y2axis:
      sprintf (string,pitem->scales.y2format,amin);
      translate1 (0.0,-ftsz/2.0,ang,&x,&y);
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,LEFT_JUSTIFY,CLR_BLACK,0) && status;
      sprintf (string,pitem->scales.y2format,amax);
      translate1 (0.0,asize-ftsz/2.0,ang,&x,&y);
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang+0.0,LEFT_JUSTIFY,CLR_BLACK,0) && status;
      break;
   }

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_rect_data (jPLOT_ITEM *pitem)
{
   int        j,count,max_pts;
   int        x_log,y1_log,y2_log;
   double     *xdata,*ydata;
   double     xtemp = 0.0,ytemp = 0.0;
   double     x1,y1,x,y;
   double     xmin,y1min,y2min;
   double     xmax,y1max,y2max;
   double     xscal,y1scal,y2scal;
   double     lastx,lasty;
   jPLOT_DATA *dptr;
   BOOL       status = TRUE;

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;

   // find the maximum number of data points
   max_pts = 0;
   dptr = pitem->data;
   while (dptr != NULL)
   {
      if ((dptr->n_pts > max_pts) && ((dptr->type & Y1_DATA) || (dptr->type & Y2_DATA)))
         max_pts = dptr->n_pts;
      dptr = dptr->next;
   }

   if (max_pts < 1)
      return TRUE;

   // allocate vectors of that size
   xdata = (double *) malloc (sizeof (double)*max_pts);
   ydata = (double *) malloc (sizeof (double)*max_pts);

   if (pitem->scaling & LogX)
   {
      xmin = log10 (pitem->scales.xmin);
      xmax = log10 (pitem->scales.xmax);
      xscal = pitem->x_frame_size/(xmax-xmin);
      x_log = 1;
   }
   else
   {
      xmin = pitem->scales.xmin;
      xmax = pitem->scales.xmax;
      xscal = pitem->x_frame_size/(xmax-xmin);
      x_log = 0;
   }

   if (pitem->scaling & LogY1)
   {
      y1min = log10 (pitem->scales.y1min);
      y1max = log10 (pitem->scales.y1max);
      y1scal = pitem->y_frame_size/(y1max-y1min);
      y1_log = 1;
   }
   else
   {
      y1min = pitem->scales.y1min;
      y1max = pitem->scales.y1max;
      y1scal = pitem->y_frame_size/(y1max-y1min);
      y1_log = 0;
   }

   if( pitem->plot_type == DoubleY ) {
      if (pitem->scaling & LogY2)
      {
         y2min = log10 (pitem->scales.y2min);
         y2max = log10 (pitem->scales.y2max);
         y2scal = pitem->y_frame_size/(y2max-y2min);
         y2_log = 1;
      }
      else
      {
         y2min = pitem->scales.y2min;
         y2max = pitem->scales.y2max;
         y2scal = pitem->y_frame_size/(y2max-y2min);
         y2_log = 0;
      }
   }
   else {
      y2min = 0.;
      y2max = 1.;
      y2scal = 1.;
      y2_log = 0;
   }


   dptr = pitem->data;
   while (dptr != NULL)
   {
      // draw Y1 data
      if (dptr->type & Y1_DATA)
      {
         count = 0;
         for (j = 0; j < dptr->n_pts; ++j)
         {
            lastx = xtemp;
            lasty = ytemp;

            if (x_log)
               xtemp = safelog (dptr->x_data[j]);
            else
               xtemp = dptr->x_data[j];

            if (y1_log)
               ytemp = safelog (dptr->y1_data[j]);
            else
               ytemp = dptr->y1_data[j];

            if ((j != 0) && !(pitem->flags & RETRACE) && (dptr->y1_ltype <= MAX_LINETYPE))
            {
               if ((xtemp < lastx) || ((xtemp == lastx) && (ytemp != lasty)))
               {
                  status = draw_polyline (xdata,ydata,count,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
                  count = 0;
               }
            }

            // check for values out of the range of the plot
            if (xtemp < xmin)
               xtemp = xmin;
            else if (xtemp > xmax)
               xtemp = xmax;

            if (ytemp < y1min)
               ytemp = y1min;
            else if (ytemp > y1max)
               ytemp = y1max;

            translate1 ((xtemp-xmin)*xscal,(ytemp-y1min)*y1scal,pitem->angle,&x,&y);

            if (dptr->y1_ltype > MAX_LINETYPE)
               status = draw_scatter_point (x1+x,y1+y,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
            else
            {
               xdata[count] = x1+x;
               ydata[count] = y1+y;
               ++count;
            }
         }

         if (count > 1)
            status = draw_polyline (xdata,ydata,count,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
      }

      // draw Y2 data
      if ((dptr->type & Y2_DATA) && (pitem->plot_type == DoubleY))
      {
         count = 0;
         for (j = 0; j < dptr->n_pts; ++j)
         {
            lastx = xtemp;
            lasty = ytemp;

            if (x_log)
               xtemp = safelog (dptr->x_data[j]);
            else
               xtemp = dptr->x_data[j];

            if (y2_log)
               ytemp = safelog (dptr->y2_data[j]);
            else
               ytemp = dptr->y2_data[j];

            if ((j != 0) && !(pitem->flags & RETRACE) && (dptr->y2_ltype <= MAX_LINETYPE))
            {
               if ((xtemp < lastx) || ((xtemp == lastx) && (ytemp != lasty)))
               {
                  status = draw_polyline (xdata,ydata,count,dptr->y2_ltype,dptr->y2_lwidth,dptr->y2_color) && status;
                  count = 0;
               }
            }

            // check for values out of the range of the plot
            if (xtemp < xmin)
               xtemp = xmin;
            else if (xtemp > xmax)
               xtemp = xmax;

            if (ytemp < y2min)
               ytemp = y2min;
            else if (ytemp > y2max)
               ytemp = y2max;

            translate1 ((xtemp-xmin)*xscal,(ytemp-y2min)*y2scal,pitem->angle,&x,&y);

            if (dptr->y2_ltype > MAX_LINETYPE)
               status = draw_scatter_point (x1+x,y1+y,dptr->y2_ltype,dptr->y2_lwidth,dptr->y2_color) && status;
            else
            {
               xdata[count] = x1+x;
               ydata[count] = y1+y;
               ++count;
            }
         }

         if (count > 1)
            status = draw_polyline (xdata,ydata,count,dptr->y2_ltype,dptr->y2_lwidth,dptr->y2_color) && status;
      }

      dptr = dptr->next;
   }

   free ((void *) xdata);
   free ((void *) ydata);

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_polar_axes (jPLOT_ITEM *pitem)
{
   double   amin,amax,astep;
   double   nsteps,moff,toff;
   double   x1,y1,x,y;
   double   step_scale,tick_scale,asize,ftsz;
   double   vtickx,vticky,htickx,hticky;
   double   textx,texty,ang;
   int      ndivs,atick;
   int      i,j;
   char     string[20];
   BOOL     status = TRUE;

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;
   ang = pitem->angle;
   ftsz = ((double) pitem->attribs.axis_tsize)/72.0;

   amin  = 0.0;
   amax  = pitem->scales.xmax;
   astep = pitem->scales.xstep;
   atick = pitem->scales.xtick;
   asize = pitem->x_frame_size;

   // draw the axes
   translate1 (pitem->x_frame_size,0.0,ang,&x,&y);
   status = draw_line (x1-x,y1-y,x1+x,y1+y,LT_SOLID,LW_MEDIUM,CLR_BLACK) && status;
   status = draw_line (x1-y,y1-x,x1+y,y1+x,LT_SOLID,LW_MEDIUM,CLR_BLACK) && status;
   status = draw_circle (x1,y1,asize,LT_DASHED,LW_THIN,CLR_BLACK) && status;

   // calculate offsets for faster drawing (less translation math)
   translate1 (0.0,pitem->attribs.minor_tick/2.0,ang,&vtickx,&vticky);
   translate1 (pitem->attribs.minor_tick/2.0,0.0,ang,&htickx,&hticky);
   translate1 (0.05,-pitem->attribs.xnum_offset,ang,&textx,&texty);

   nsteps = (amax-amin)/astep;
   if (nsteps < 1.0)
      astep = (amax-amin);
   else if (fmod ((amax-amin),astep) != 0.0)
   {
      astep = (amax-amin)/floor(nsteps+0.5);
      nsteps = (amax-amin)/astep;
   }

   ndivs = (int) (nsteps+0.1);
   if (ndivs < 1)
   {
      ndivs = 1;
      astep = amax-amin;
   }

   if (atick < 1)
      atick = 1;

   step_scale = asize/((double) ndivs);
   tick_scale = step_scale/((double) atick);

   // draw the major and minor axis ticks and the grid
   for (i = 0; i < ndivs; ++i)
   {
      moff = ((double) i)*step_scale;

      for (j = 1; j < atick; ++j)
      {
         toff = moff + tick_scale*((double) j);
         translate1 (toff,0.0,ang,&x,&y);
         status = draw_line (x1+(x-vtickx),y1+(y-vticky),x1+(x+vtickx),y1+(y+vticky),LT_SOLID,LW_THIN,CLR_BLACK) && status;
         status = draw_line (x1-(x-vtickx),y1-(y-vticky),x1-(x+vtickx),y1-(y+vticky),LT_SOLID,LW_THIN,CLR_BLACK) && status;
         translate1 (0.0,toff,ang,&x,&y);
         status = draw_line (x1+(x-htickx),y1+(y-hticky),x1+(x+htickx),y1+(y+hticky),LT_SOLID,LW_THIN,CLR_BLACK) && status;
         status = draw_line (x1-(x-htickx),y1-(y-hticky),x1-(x+htickx),y1-(y+hticky),LT_SOLID,LW_THIN,CLR_BLACK) && status;
      }

      if (i == 0)
         continue;

      status = draw_circle (x1,y1,moff,LT_DASHED,LW_THIN,CLR_BLACK) && status;
   }

   // draw the axis text
   for (i = 1; i <= ndivs; ++i)
   {
      sprintf (string,pitem->scales.xformat,amin+astep*((double) i));
      moff = ((double) i)*step_scale;
      translate1 (moff,0.0,ang,&x,&y);
      status = draw_text (string,x1+x+textx,y1+y+texty,pitem->attribs.axis_font,pitem->attribs.axis_tsize,ang-90.0,LEFT_JUSTIFY,CLR_BLACK,0) && status;
   }

   // draw the title
   translate1 (0.0,pitem->x_frame_size+pitem->attribs.title_offset,ang,&x,&y);
   status = draw_text (pitem->title,x1+x,y1+y,pitem->attribs.title_font,pitem->attribs.title_tsize,ang,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE) && status;

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_smith_axes (jPLOT_ITEM *pitem)
{
   double   x1,y1,x,y,asize;
   double   ftsz,ang;
   double   x0,y0,r,phi1,phi2,xx,yy;
   int      i,itsz,itsz2;
   char     string[20];
   BOOL     status = TRUE;

   static double rl[]  = {0.1,0.2,0.3,0.4,0.5,0.5,0.5,0.6,0.7,0.8,0.9,1.2,1.4,1.5,1.5,1.6,1.8,2.0,2.5,3.0,4.0,5.0,10.0,20.0};
   static double xl1[] = {1.0,2.0,1.0,2.0,1.0,5.0,-2.0,2.0,1.0,2.0,1.0,2.0,2.0,5.0,-2.0,2.0,2.0,5.0,10.0,5.0,5.0,10.0,20.0,20.0};
   static double xl2[] = {-1.0,-2.0,-1.0,-2.0,-1.0,2.0,-5.0,-2.0,-1.0,-2.0,-1.0,-2.0,-2.0,2.0,-5.0,-2.0,-2.0,-5.0,-10.0,-5.0,-5.0,-10.0,-20.0,-20.0};
   static double xl[]  = {0.1,0.2,0.3,0.4,0.5,0.5,0.6,0.7,0.8,0.9,1.2,1.4,1.5,1.6,1.8,2.0,2.5,3.0,4.0,5.0,10.0,20.0};
   static double rl1[] = {0.0,0.0,0.0,0.0,0.0,2.0,0.0,0.0,0.0,0.0,0.0,0.0,2.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
   static double rl2[] = {1.0,2.0,1.0,2.0,1.0,5.0,2.0,1.0,2.0,1.0,2.0,2.0,5.0,2.0,2.0,5.0,10.0,5.0,5.0,10.0,20.0,20.0};
   static double rll[] = {0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.2,1.4,1.6,1.8,2.0,2.5,3.0,4.0,5.0,10.0,20.0};

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;
   ang = pitem->angle;

   asize = pitem->x_frame_size;
   itsz  = (int) (asize*3.5);
   itsz2 = (int) (itsz*0.6);
   ftsz = itsz/72.0;

   // draw the axes
   translate1 (asize,0.0,ang,&x,&y);
   status = draw_line (x1-x,y1-y,x1+x,y1+y,LT_SOLID,2,CLR_BLACK) && status;
   status = draw_circle (x1,y1,asize,LT_SOLID,LW_MEDIUM,CLR_BLACK) && status;

   status = draw_circle (x1,y1,asize+pitem->attribs.xnum_offset+ftsz+0.05,LT_SOLID,LW_THIN,CLR_BLACK);

   translate1 (asize*0.5,0.0,ang,&x,&y);
   status = draw_circle (x1+x,y1+y,asize*0.5,LT_SOLID,1,CLR_BLACK) && status;

   translate1 (asize,asize,ang,&x,&y);
   status = draw_arc (x1+x,y1+y,asize,180.0+ang,-90.0+ang,LT_SOLID,1,CLR_BLACK) && status;
   translate1 (asize,-asize,ang,&x,&y);
   status = draw_arc (x1+x,y1+y,asize,90.0+ang,180.0+ang,LT_SOLID,1,CLR_BLACK) && status;

   for (i = 0; i < 24; ++i)
   {
      r = 1.0/(1.0 + rl[i]);
      x0 = 1.0-r;
      y0 = 0.0;

      x = (rl[i]*rl[i] + xl1[i]*xl1[i] - 1.0) / ((rl[i] + 1.0)*(rl[i] + 1.0) + xl1[i]*xl1[i]) - x0;
      y = 2.0*xl1[i]/((rl[i]+1.0)*(rl[i]+1.0) + xl1[i]*xl1[i]) - y0;
      if ((x == 0.0) && (y == 0.0))
         phi1 = 0.0;
      else
         phi1 = RAD2DEG*atan2 (y,x);

      x = (rl[i]*rl[i] + xl2[i]*xl2[i] - 1.0) / ((rl[i] + 1.0)*(rl[i] + 1.0) + xl2[i]*xl2[i]) - x0;
      y = 2.0*xl2[i]/((rl[i]+1.0)*(rl[i]+1.0) + xl2[i]*xl2[i]) - y0;
      if ((x == 0.0) && (y == 0.0))
         phi2 = 0.0;
      else
         phi2 = RAD2DEG*atan2 (y,x);

      translate1 (x0*asize,y0*asize,ang,&x,&y);
      draw_arc (x+x1,y+y1,r*asize,phi1+ang,phi2+ang,LT_DOTTED,LW_THIN,CLR_BLACK);
   }

   for (i = 0; i < 22; ++i)
   {
      r  = 1.0/xl[i];
      x0 = 1.0;
      y0 = r;

      x = (rl1[i]*rl1[i] + xl[i]*xl[i] - 1.0) / ((rl1[i] + 1.0)*(rl1[i] + 1.0) + xl[i]*xl[i]) - x0;
      y = 2.0*xl[i]/((rl1[i]+1.0)*(rl1[i]+1.0) + xl[i]*xl[i]) - y0;
      if ((x == 0.0) && (y == 0.0))
         phi1 = 0.0;
      else
         phi1 = RAD2DEG*atan2 (y,x);

      x = (rl2[i]*rl2[i] + xl[i]*xl[i] - 1.0) / ((rl2[i] + 1.0)*(rl2[i] + 1.0) + xl[i]*xl[i]) - x0;
      y = 2.0*xl[i]/((rl2[i]+1.0)*(rl2[i]+1.0) + xl[i]*xl[i]) - y0;
      if ((x == 0.0) && (y == 0.0))
         phi2 = 0.0;
      else
         phi2 = RAD2DEG*atan2 (y,x);

      translate1 (x0*asize,y0*asize,ang,&x,&y);
      draw_arc (x+x1,y+y1,r*asize,phi1+ang,phi2+ang,LT_DOTTED,LW_THIN,CLR_BLACK);
      translate1 (x0*asize,-y0*asize,ang,&x,&y);
      draw_arc (x+x1,y+y1,r*asize,-phi2+ang,-phi1+ang,LT_DOTTED,LW_THIN,CLR_BLACK);
   }

   for (phi1 = -170.0; phi1 < 180.1; phi1 += 10.0)
   {
      sprintf (string,"%d",(int) phi1);
      x = (asize+pitem->attribs.xnum_offset+0.05)*cos (phi1*DEG2RAD);
      y = (asize+pitem->attribs.xnum_offset+0.05)*sin (phi1*DEG2RAD);
      translate1 (x,y,ang,&xx,&yy);
      draw_text (string,x1+xx,y1+yy,FNT_HELVETICA,itsz,ang+phi1-90.0,CENTER_JUSTIFY,CLR_BLACK,0);

      x = asize*cos (phi1*DEG2RAD);
      y = asize*sin (phi1*DEG2RAD);
      translate1 (x,y,ang,&xx,&yy);
      x = (asize+pitem->attribs.xnum_offset)*cos (phi1*DEG2RAD);
      y = (asize+pitem->attribs.xnum_offset)*sin (phi1*DEG2RAD);
      translate1 (x,y,ang,&x0,&y0);
      draw_line (x1+xx,y1+yy,x1+x0,y1+y0,LT_SOLID,LW_THIN,CLR_BLACK);
   }

   for (i = 0; i < 21; ++i)
   {
      sprintf (string,"%.1f",rll[i]);
      x = asize*(rll[i] - 1.0)/(rll[i] + 1.0) - 0.05;
      y = 0.05;
      translate1 (x,y,ang,&x0,&y0);
      draw_text (string,x1+x0,y1+y0,FNT_HELVETICA,itsz2,90.0+ang,LEFT_JUSTIFY,CLR_BLACK,0);
   }

   for (i = 0; i < 21; ++i)
   {
      x = (rll[i]*rll[i] - 1.0)/(rll[i]*rll[i] + 1.0);
      y = 2.0*rll[i]/(rll[i]*rll[i] + 1.0);

      if ((x == 0.0) && (y == 0.0))
      {
         phi1 = 0.01745;
         phi2 = -0.01745;
      }
      else
      {
         phi1 = atan2 (y,x) + 0.01745;
         phi2 = atan2 (-y,x) - 0.01745;
      }

      x = cos (phi1);
      y = sin (phi1);

      sprintf (string,"%.1f",rll[i]);
      x0 = (asize - 0.05)*cos (phi1);
      y0 = (asize - 0.05)*sin (phi1);
      translate1 (x0,y0,ang,&x,&y);
      draw_text (string,x1+x,y1+y,FNT_HELVETICA,itsz2,RAD2DEG*phi1+ang,RIGHT_JUSTIFY,CLR_BLACK,0);
      translate1 (x0,-y0,ang,&x,&y);
      draw_text (string,x1+x,y1+y,FNT_HELVETICA,itsz2,RAD2DEG*phi2+ang-180.0,LEFT_JUSTIFY,CLR_BLACK,0);
   }

   // draw the title
   translate1 (0.0,pitem->x_frame_size+pitem->attribs.title_offset+pitem->attribs.xnum_offset+ftsz+0.05,ang,&x,&y);
   status = draw_text (pitem->title,x1+x,y1+y,pitem->attribs.title_font,pitem->attribs.title_tsize,ang,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE) && status;

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_polar_data (jPLOT_ITEM *pitem)
{
   int        j,count,max_pts;
   double     *xdata,*ydata;
   double     xtemp = 0.0,ytemp = 0.0;
   double     x1,y1,x,y;
   double     scal,amax;
   jPLOT_DATA *dptr;
   BOOL       status = TRUE;

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;

   // find the maximum number of data points
   max_pts = 0;
   dptr = pitem->data;
   while (dptr != NULL)
   {
      if ((dptr->n_pts > max_pts) && (dptr->type & POLAR_DATA))
         max_pts = dptr->n_pts;
      dptr = dptr->next;
   }

   if (max_pts < 1)
      return TRUE;

   amax = pitem->scales.xmax;
   scal = pitem->x_frame_size/amax;

   // allocate vectors of that size
   xdata = (double *) malloc (sizeof (double)*max_pts);
   ydata = (double *) malloc (sizeof (double)*max_pts);

   dptr = pitem->data;
   while (dptr != NULL)
   {
      // draw Y1 data
      if (dptr->type & POLAR_DATA)
      {
         count = 0;
         for (j = 0; j < dptr->n_pts; ++j)
         {
            xtemp = dptr->x_data[j];
            ytemp = dptr->y1_data[j];

            // check for values out of the range of the plot
            if (pmag(xtemp,ytemp) > amax)
            {
               xtemp = amax*cos (atan2 (ytemp,xtemp));
               ytemp = amax*sin (atan2 (ytemp,xtemp));
            }

            translate1 (xtemp*scal,ytemp*scal,pitem->angle,&x,&y);

            if (dptr->y1_ltype > MAX_LINETYPE)
               status = draw_scatter_point (x1+x,y1+y,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
            else
            {
               xdata[count] = x1+x;
               ydata[count] = y1+y;
               ++count;
            }
         }

         if (count > 1)
            status = draw_polyline (xdata,ydata,count,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
      }

      dptr = dptr->next;
   }

   free ((void *) xdata);
   free ((void *) ydata);

   return status;
}

/******************************************************************************/
/******************************************************************************/

static BOOL draw_contour_data (jPLOT_ITEM *pitem)
{
   int        j,k,n,npts,index,pointer,startp,count,drawlabel;
   double     x1,y1,x,y,x0,y0;
   double     xscal,yscal,xmax,xmin,ymax,ymin;
   double     cval,vmin,vmax,vstep,factor,xval;
   double     *xdata,*ydata,textx,texty,texta;
   LINE_SEG   *segs;
   jPLOT_DATA *dptr;
   struct point_list *cplist,tmpl,lastp,firstp,ls_last,ls_first;
   BOOL       status = TRUE;
   char       string[20];

   x1 = pitem->x_frame_pos;
   y1 = pitem->y_frame_pos;

   xmin = pitem->scales.xmin;
   xmax = pitem->scales.xmax;
   xscal = pitem->x_frame_size/(xmax-xmin);

   if (pitem->plot_type == XYContour)
   {
      ymin = pitem->scales.y1min;
      ymax = pitem->scales.y1max;
      yscal = pitem->y_frame_size/(ymax-ymin);
   }
   else
   {
      xmin = ymin = 0.0;
      ymax = xmax;
      yscal = xscal;
   }

   vmin = pitem->scales.y2min;
   vmax = pitem->scales.y2max;
   vstep = pitem->scales.y2step;

   dptr = pitem->data;
   while (dptr != NULL)
   {
      // draw Y1 data
      if (dptr->type & CONTOUR_DATA)
      {
         // calculate the contour line segments
         segs = calculate_contour_intersections (dptr,&n);
         for (j = 0,k = 0; j < n; ++j)
         {
            if (!segs[j].ignore)
               ++k;
         }

         cplist = (struct point_list *) malloc (sizeof(struct point_list)*k);
         xdata  = (double *) malloc (sizeof(double)*(k+1));
         ydata  = (double *) malloc (sizeof(double)*(k+1));

         // draw the points
         if (dptr->y2_ltype > MAX_LINETYPE)
         {
            for (j = 0; j < dptr->n_pts; ++j)
            {
               translate1 ((dptr->x_data[j]-xmin)*xscal,(dptr->y1_data[j]-ymin)*yscal,pitem->angle,&x,&y);
               status = draw_scatter_point (x1+x,y1+y,dptr->y2_ltype,2,dptr->y2_color) && status;
            }
         }

         // draw the contours
         for (cval = vmin; cval < (vmax+0.5*vstep); cval += vstep)
         {
            npts = 0;
            for (j = 0; j < n; ++j)
            {
               // create the list of contour data points
               if (!segs[j].ignore)
               {
                  if (((cval <  dptr->y2_data[segs[j].pnt1]) && (cval >= dptr->y2_data[segs[j].pnt2])) ||
                     ((cval >= dptr->y2_data[segs[j].pnt1]) && (cval <  dptr->y2_data[segs[j].pnt2])))
                  {
                     factor = (cval - dptr->y2_data[segs[j].pnt2]) /
                        (dptr->y2_data[segs[j].pnt1] - dptr->y2_data[segs[j].pnt2]);
                     cplist[npts].x = dptr->x_data[segs[j].pnt2] +
                        (dptr->x_data[segs[j].pnt1] - dptr->x_data[segs[j].pnt2])*factor;
                     cplist[npts].y = dptr->y1_data[segs[j].pnt2] +
                        (dptr->y1_data[segs[j].pnt1] - dptr->y1_data[segs[j].pnt2])*factor;
                     cplist[npts].p1 = segs[j].pnt1;
                     cplist[npts].p2 = segs[j].pnt2;
                     ++npts;
                  }
               }
            }

            if (npts < 2)
               continue;

            // find the leftmost point and move to the start of the list
            xval = cplist[0].x;
            index = 0;
            for (j = 1; j < npts; ++j)
            {
               if (cplist[j].x < xval)
               {
                  xval = cplist[j].x;
                  index = j;
               }
            }
            tmpl = cplist[0];
            cplist[0] = cplist[index];
            cplist[index] = tmpl;
            count  = 1;
            startp = 0;
            firstp = lastp = cplist[0];

            drawlabel = 0;
            for (pointer = 1; pointer < npts; ++pointer)
            {
               // find a segment that shares a triangle with the last point
               index = -1;
               for (j = pointer; j < npts; ++j)
               {
                  if (is_triangle (cplist[j],lastp,segs,n))
                  {
                     index = j;
                     break;
                  }
               }

               if (index > -1)
               {
                  tmpl = cplist[j];
                  cplist[j] = cplist[pointer];
                  cplist[pointer] = tmpl;
                  ++count;
                  lastp = cplist[pointer];
                  if (pointer == 1)
                  {
                     texta = RAD2DEG*atan2 (lastp.y - firstp.y,lastp.x - firstp.x);
                     textx = (lastp.x + firstp.x)*0.5;
                     texty = (lastp.y + firstp.y)*0.5;
                     drawlabel = 1;
                  }
               }
               else
               {
                  if (count > 1)
                  {
                     for (j = 0; j < count; ++j)
                     {
                        translate1 ((cplist[j+startp].x-xmin)*xscal,(cplist[j+startp].y-ymin)*yscal,pitem->angle,&x,&y);
                        xdata[j] = x1 + x;
                        ydata[j] = y1 + y;
                     }
                     status = draw_polyline (xdata,ydata,count,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
                  }

                  // find the leftmost point
                  xval = cplist[pointer].x;
                  index = pointer;
                  for (j = pointer; j < npts; ++j)
                  {
                     if (cplist[j].x < xval)
                     {
                        xval = cplist[j].x;
                        index = j;
                     }
                  }
                  tmpl = cplist[pointer];
                  cplist[pointer] = cplist[index];
                  cplist[index] = tmpl;
                  count  = 1;

                  if (is_triangle (cplist[pointer],firstp,segs,n))
                  {
                     translate1 ((cplist[pointer].x-xmin)*xscal,(cplist[pointer].y-ymin)*yscal,pitem->angle,&x,&y);
                     translate1 ((firstp.x-xmin)*xscal,(firstp.y-ymin)*yscal,pitem->angle,&x0,&y0);
                     status = draw_line (x1+x,y1+y,x1+x0,y1+y0,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
                  }

                  ls_last = lastp;
                  ls_first = firstp;
                  firstp = lastp = cplist[pointer];
                  startp = pointer;
               }
            }

            if (count > 1)
            {
               for (j = 0; j < count; ++j)
               {
                  translate1 ((cplist[j+startp].x-xmin)*xscal,(cplist[j+startp].y-ymin)*yscal,pitem->angle,&x,&y);
                  xdata[j] = x1 + x;
                  ydata[j] = y1 + y;
               }
               status = draw_polyline (xdata,ydata,count,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;

               // determine if points should be joined
               if (startp > 0)
               {
                  if (is_triangle (lastp,ls_last,segs,n))
                  {
                     translate1 ((ls_last.x-xmin)*xscal,(ls_last.y-ymin)*yscal,pitem->angle,&x,&y);
                     translate1 ((lastp.x-xmin)*xscal,(lastp.y-ymin)*yscal,pitem->angle,&x0,&y0);
                     status = draw_line (x1+x,y1+y,x1+x0,y1+y0,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
                  }
                  else if (is_triangle (lastp,ls_first,segs,n))
                  {
                     translate1 ((ls_first.x-xmin)*xscal,(ls_first.y-ymin)*yscal,pitem->angle,&x,&y);
                     translate1 ((lastp.x-xmin)*xscal,(lastp.y-ymin)*yscal,pitem->angle,&x0,&y0);
                     status = draw_line (x1+x,y1+y,x1+x0,y1+y0,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
                  }
               }
               else
               {
                  if (is_triangle (firstp,lastp,segs,n))
                  {
                     translate1 ((firstp.x-xmin)*xscal,(firstp.y-ymin)*yscal,pitem->angle,&x,&y);
                     translate1 ((lastp.x-xmin)*xscal,(lastp.y-ymin)*yscal,pitem->angle,&x0,&y0);
                     status = draw_line (x1+x,y1+y,x1+x0,y1+y0,dptr->y1_ltype,dptr->y1_lwidth,dptr->y1_color) && status;
                  }
               }
            }

            // draw the label
            if (drawlabel)
            {
               translate1 ((textx-xmin)*xscal,(texty-ymin)*yscal,pitem->angle,&x,&y);
               translate1 (0.0,0.05,texta+90.0,&x0,&y0);
               if ((texta < 0.0) || (texta > 180.0))
                  x0 = -x0;

               sprintf (string,pitem->scales.y2format,cval);
               status = draw_text (string,x1+x+x0,y1+y+y0,pitem->attribs.axis_font,pitem->attribs.axis_tsize,pitem->angle+texta,CENTER_JUSTIFY,CLR_BLACK,0) && status;
               drawlabel = 0;
            }
         }

         free ((void *) segs);
         free ((void *) cplist);
         free ((void *) xdata);
         free ((void *) ydata);
      }

      dptr = dptr->next;
   }

   return status;
}

/******************************************************************************/
/******************************************************************************/

static void check_scales (jPLOT_ITEM *pitem, int axis)
{
   jPLOT_SCALE  *scale = &pitem->scales;
   double       *min,*max,*step,tmp;
   int          *tick,use_log;
   char         *fmt;

#define LOGMIN  1.0e-24

   switch (axis)
   {
   case Xaxis:
      if (pitem->scaling & LogX)
         use_log = 1;
      else
         use_log = 0;

      min = &scale->xmin;
      max = &scale->xmax;
      step = &scale->xstep;
      tick = &scale->xtick;
      fmt = scale->xformat;
      break;
   case Y1axis:
      if (pitem->scaling & LogY1)
         use_log = 1;
      else
         use_log = 0;

      min = &scale->y1min;
      max = &scale->y1max;
      step = &scale->y1step;
      tick = &scale->y1tick;
      fmt = scale->y1format;
      break;
   case Y2axis:
      if (pitem->scaling & LogY2)
         use_log = 1;
      else
         use_log = 0;

      min = &scale->y2min;
      max = &scale->y2max;
      step = &scale->y2step;
      tick = &scale->y2tick;
      fmt = scale->y2format;
      break;
   default:
      return;
   }

   if (use_log)
   {
      if (*min < LOGMIN)
         *min = LOGMIN;

      if (*max < LOGMIN)
         *max = LOGMIN;

      if (*min > *max)
      {
         tmp = *min;
         *min = *max;
         *max = tmp;
      }

      if (*min == *max)
         *max = *min*2.0;

      if ((*max / *min) <= 1.0e10)
         *step = 10.0;
      else if ((*max / *min) <= 1.0e20)
         *step = 100.0;
      else
         *step = 1000.0;

      if (*step != 10.0)
         *tick = 0;

      if (strlen (fmt) < 1)
         strcpy (fmt,"%.1e");
   }

   else
   {
      if (*min > *max)
      {
         tmp = *min;
         *min = *max;
         *max = tmp;
      }

      if (*step > (*max - *min))
         *step = *max - *min;

      if (*tick < 1)
         *tick = 1;
      else if (*tick > 10)
         *tick = 10;

      if (strlen (fmt) < 1)
         strcpy (fmt,"%.1f");
   }
}

/******************************************************************************/
/******************************************************************************/

static double scale_autodata (double x)
{
   double sf = 1.0;
   double tmp = sf*x;

   if (tmp == 0.0)
      return 1.0;

   while ((tmp < 1.0) || (tmp >= 10.0))
   {
      if (tmp < 1.0)
         sf *= 10.0;
      else if (tmp >= 10.0)
         sf *= 0.1;

      tmp = sf*x;
   }

   return sf;
}

/******************************************************************************/
/******************************************************************************/

static void find_limits (double x, double *value, double *step)
{
   int i;
   double y;
   static double   sdata[] = {1.0, 1.2, 1.25,  1.5, 1.6, 1.8, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 8.0, 10.0};
   static double   sstep[] = {0.2, 0.2, 0.25, 0.25, 0.4, 0.3, 0.5, 0.5, 0.5, 0.5, 1.0, 1.0, 1.0, 2.0,  2.0};
#define NUM_VALUES  15

   y = fabs (x);

   if (y == 0.0)
   {
      *value = 0.0001;
      *step = 0.0001;
      return;
   }

   for (i = 0; i < NUM_VALUES; ++i)
   {
      if (y <= sdata[i])
      {
         *value = sdata[i];
         *step  = sstep[i];
         return;
      }
   }

   *value = 1.0;
   *step  = 0.1;
}

/******************************************************************************/
/******************************************************************************/

static void autoscale_log (double min, double max, double *start, double *stop, double *step, char *format)
{
   double ratio,tmp,sf;

   if ((min < 0.0) && (max < 0.0))
   {
      tmp = max;
      max = -min;
      min = -tmp;
   }

   if (min < 1.0e-24)
      min = 1.0e-24;

   if (max < 1.0e-24)
      max = 1.0e-24;

   if (min == max)
      max = min * 2.0;

   if (max > 1.0e24)
      max = 1.0e24;

   ratio = max/min;

   if (ratio < 10.0)
   {
      sf = scale_autodata (min);
      *start = floor (sf*min)/sf;
      *stop  = ceil (sf*max)/sf;
      *step = 10.0;
      strcpy (format,"%.1e");
   }
   else
   {
      sf = scale_autodata (min);
      *start = 1.0/sf;

      sf = scale_autodata (max);
      if (max <= (1.0/sf))
         *stop = 1.0/sf;
      else if (max <= (2.0/sf))
         *stop = 2.0/sf;
      else if (max <= (5.0/sf))
         *stop = 5.0/sf;
      else
         *stop = 10.0/sf;

      if (ratio > 1.0e24)
      {
         *step = 1000.0;
         strcpy (format,"%.0e");
      }
      else if (ratio > 1.0e12)
      {
         *step = 100.0;
         strcpy (format,"%.0e");
      }
      else
      {
         *step = 10.0;
         strcpy (format,"%.1e");
      }
   }
}

/******************************************************************************/
/******************************************************************************/

static void autoscale_linear (double min, double max, int pos_only, double *start, double *stop,
                              double *step, int *tick, char *format)
{
   double smax,sstep,tmp;
   double range,sf;
   int    i;

   if (min > 1.0e24)
      min = 1.0e24;
   else if (min < -1.0e24)
      min = -1.0e24;

   if (max > 1.0e24)
      max = 1.0e24;
   else if (max < -1.0e24)
      max = -1.0e24;

   if ((min < 0.0) && (max > 0.0) && !pos_only)
   {
      if (0.2*fabs (min) > max)
      {
         sf = scale_autodata (-min);

         find_limits (-sf*min,&smax,&sstep);

         *start = -smax/sf;
         *step = sstep/sf;

         tmp = 0.0;
         while (tmp < max) tmp += *step;
         *stop = tmp;
      }

      else if (0.2*max > fabs (min))
      {
         sf = scale_autodata (max);

         find_limits (sf*max,&smax,&sstep);

         *stop = smax/sf;
         *step = sstep/sf;

         tmp = 0.0;
         while (tmp > min)
         {
            tmp -= *step;
         }
         *start = tmp;
      }

      else
      {
         if (fabs (min) > max)
         {
            sf = scale_autodata (-min);
            find_limits (-sf*min,&smax,&sstep);

            *start = -smax/sf;
            *step = sstep/sf;

            i = 0;
            tmp = *start;
            while (tmp < max)
            {
               tmp += *step;
               ++i;
            }

            if (i > 7)   // too many steps, increase the step magnitude
            {
               i = (int) floor (-(*start)/(*step*2.0));
               *step = -(*start)/i;
               sstep = *step*sf;
            }

            tmp = *start;
            while (tmp < max)
               tmp += *step;

            *stop = tmp;
         }
         else
         {
            sf = scale_autodata (max);
            find_limits (sf*max,&smax,&sstep);

            *stop = smax/sf;
            *step = sstep/sf;

            i = 0;
            tmp = *stop;
            while (tmp > min)
            {
               tmp -= *step;
               ++i;
            }

            if (i > 7)  // too many steps, increase the step magnitude
            {
               i = (int) floor ((*stop)/(*step*2.0));
               *step = (*stop)/i;
               sstep = *step*sf;
            }

            tmp = *stop;
            while (tmp > min)
               tmp -= *step;

            *start = tmp;
         }
      }
   }

   else if ((min < 0.0) && (max <= 0.0))
   {
      if (fabs (max) < fabs (min*0.2))
      {
         *stop = 0.0;

         sf = scale_autodata (-min);

         find_limits (-sf*min,&smax,&sstep);

         *start = -smax/sf;
         *step = sstep/sf;
      }

      else
      {
         tmp = max - min;

         sf = scale_autodata (tmp);
         *start = floor (min*sf)/sf;

         find_limits (tmp*sf,&smax,&sstep);
         *step = sstep/sf;
         *stop = *start + *step;
         while (*stop < max)
            *stop += *step;
      }

   }

   else
   {
      if (min < (max*0.2))
      {
         *start = 0.0;

         sf = scale_autodata (max);

         find_limits (sf*max,&smax,&sstep);

         *stop = smax/sf;
         *step = sstep/sf;
      }

      else
      {
         tmp = max - min;

         sf = scale_autodata (tmp);
         *start = floor (min*sf)/sf;

         find_limits (tmp*sf,&smax,&sstep);
         *step = sstep/sf;
         *stop = *start + *step;
         while (*stop < max)
            *stop += *step;
      }
   }

   if (sstep == 0.25)
      *tick = 5;
   else if (sstep == 0.3)
      *tick = 6;
   else if (sstep == 0.5)
      *tick = 5;
   else if (sstep == 1.0)
      *tick = 5;
   else
      *tick = 4;

   range = max-min;
   if (range > 500.0)
      strcpy (format,"%.2e");
   else if (range > 50.0)
      strcpy (format,"%.0f");
   else if (range > 5.0)
      strcpy (format,"%.1f");
   else if (range > 0.5)
      strcpy (format,"%.2f");
   else if (range > 0.05)
      strcpy (format,"%.3f");
   else
      strcpy (format,"%.4f");

   return;
}

/******************************************************************************/
/******************************************************************************/

static void autoscale_axis (jPLOT_ITEM *pitem, int axis)
{
   jPLOT_SCALE  *scale = &pitem->scales;
   jPLOT_DATA   *dptr;
   double  gmin,gmax,gstep;
   double  min,max;
   int     i,gtick,use_log = 0;
   int     min_max_set = 0,pos = 0;
   char    gformat[20];

   switch (axis)
   {
   case Xaxis:
      if (pitem->scaling & LogX)
         use_log = 1;
      if (pitem->scaling & POSITIVE_X)
         pos = 1;

      dptr = pitem->data;
      while (dptr != NULL)
      {
         if ((dptr->type & Y1_DATA) || (dptr->type & Y2_DATA) || (dptr->type & CONTOUR_DATA))
         {
            if (!min_max_set)
            {
               min = max = dptr->x_data[0];
               min_max_set = 1;
            }
            for (i = 0; i < dptr->n_pts; ++i)
            {
               if (dptr->x_data[i] > max)
                  max = dptr->x_data[i];
               if (dptr->x_data[i] < min)
                  min = dptr->x_data[i];
            }
         }
         dptr = dptr->next;
      }

      if (!min_max_set)
         return;
      break;

   case Y1axis:
      if (pitem->scaling & LogY1)
         use_log = 1;
      if (pitem->scaling & POSITIVE_Y1)
         pos = 1;

      dptr = pitem->data;
      while (dptr != NULL)
      {
         if ((dptr->type & Y1_DATA) || (dptr->type & CONTOUR_DATA))
         {
            if (!min_max_set)
            {
               min = max = dptr->y1_data[0];
               min_max_set = 1;
            }
            for (i = 0; i < dptr->n_pts; ++i)
            {
               if (dptr->y1_data[i] > max)
                  max = dptr->y1_data[i];
               if (dptr->y1_data[i] < min)
                  min = dptr->y1_data[i];
            }
         }
         dptr = dptr->next;
      }

      if (!min_max_set)
         return;
      break;

   case Y2axis:
      if (pitem->scaling & LogY2)
         use_log = 1;
      if (pitem->scaling & POSITIVE_Y2)
         pos = 1;

      dptr = pitem->data;
      while (dptr != NULL)
      {
         if ((dptr->type & Y2_DATA) || (dptr->type & CONTOUR_DATA))
         {
            if (!min_max_set)
            {
               min = max = dptr->y2_data[0];
               min_max_set = 1;
            }
            for (i = 0; i < dptr->n_pts; ++i)
            {
               if (dptr->y2_data[i] > max)
                  max = dptr->y2_data[i];
               if (dptr->y2_data[i] < min)
                  min = dptr->y2_data[i];
            }
         }
         dptr = dptr->next;
      }

      if (!min_max_set)
         return;
      break;

   default:
      return;
   }

   if ((use_log) && (pitem->plot_type <= DoubleY))
   {
      autoscale_log (min,max,&gmin,&gmax,&gstep,gformat);
      if (gstep == 10.0)
         gtick = 1;
      else
         gtick = 0;
   }
   else
      autoscale_linear (min,max,pos,&gmin,&gmax,&gstep,&gtick,gformat);

   // copy the scaling data back to the scale structure
   switch (axis)
   {
   case Xaxis:
      scale->xmin = gmin;
      scale->xmax = gmax;
      scale->xstep = gstep;
      scale->xtick = gtick;
      strcpy (scale->xformat,gformat);
      break;
   case Y1axis:
      scale->y1min = gmin;
      scale->y1max = gmax;
      scale->y1step = gstep;
      scale->y1tick = gtick;
      strcpy (scale->y1format,gformat);
      break;
   case Y2axis:
      scale->y2min = gmin;
      scale->y2max = gmax;
      scale->y2step = gstep;
      scale->y2tick = gtick;
      strcpy (scale->y2format,gformat);
      break;
   }
}

/******************************************************************************/
/******************************************************************************/

static void autoscale_polar (jPLOT_ITEM *pitem)
{
   jPLOT_SCALE  *scale = &pitem->scales;
   jPLOT_DATA   *dptr;
   double  gmax,gstep;
   double  max = 0.0,mag,sf;
   int     i,gtick;
   char    gformat[20];

   dptr = pitem->data;
   while (dptr != NULL)
   {
      if ((dptr->type & POLAR_DATA) || (dptr->type & CONTOUR_DATA))
      {
         for (i = 0; i < dptr->n_pts; ++i)
         {
            mag = pmag (dptr->x_data[i],dptr->y1_data[i]);
            if (mag > max)
               max = mag;
         }
      }
      dptr = dptr->next;
   }

   sf = scale_autodata (max);
   find_limits (sf*max,&gmax,&gstep);

   if (gstep == 0.25)
      gtick = 5;
   else if (gstep == 0.3)
      gtick = 6;
   else if (gstep == 0.5)
      gtick = 5;
   else if (gstep == 1.0)
      gtick = 5;
   else
      gtick = 4;

   if (max > 1000.0)
      strcpy (gformat,"%.2e");
   else if (max > 10.0)
      strcpy (gformat,"%.0f");
   else if (max > 1.0)
      strcpy (gformat,"%.1f");
   else if (max > 0.1)
      strcpy (gformat,"%.2f");
   else if (max > 0.01)
      strcpy (gformat,"%.3f");
   else
      strcpy (gformat,"%.4f");

   scale->xmin  = 0.0;
   scale->xmax  = gmax/sf;
   scale->xstep = gstep/sf;
   scale->xtick = gtick;
   strcpy (scale->xformat,gformat);
}

/******************************************************************************/
/******************************************************************************/

static void autoscale (jPLOT_ITEM *pitem)
{
   switch (pitem->plot_type)
   {
   case DoubleY:
      if (pitem->scaling & ManualY2)
         check_scales (pitem,Y2axis);
      else
         autoscale_axis (pitem,Y2axis);
   case SingleY:
      if (pitem->scaling & ManualX)
         check_scales (pitem,Xaxis);
      else
         autoscale_axis (pitem,Xaxis);

      if (pitem->scaling & ManualY1)
         check_scales (pitem,Y1axis);
      else
         autoscale_axis (pitem,Y1axis);
      break;

   case PolarChart:
      if (pitem->scaling & ManualX)
      {
         pitem->scales.xmin = 0.0;
         check_scales (pitem,Xaxis);
      }
      else
         autoscale_polar (pitem);
      break;

   case SmithChart:
      pitem->scales.xmin  = 0.0;
      pitem->scales.xmax  = 1.0;
      pitem->scales.xstep = 1.0;
      pitem->scales.xtick = 1;
      strcpy (pitem->scales.xformat,"%.1f");
      break;

   case XYContour:
      autoscale_axis (pitem,Xaxis);
      autoscale_axis (pitem,Y1axis);
      if (pitem->scaling & ManualY2)
         check_scales (pitem,Y2axis);
      else
      {
         autoscale_axis (pitem,Y2axis);
         pitem->scales.y2step *= 0.5;
      }
      break;

   case PolarContour:
      autoscale_polar (pitem);
      if (pitem->scaling & ManualY2)
         check_scales (pitem,Y2axis);
      else
      {
         autoscale_axis (pitem,Y2axis);
         pitem->scales.y2step *= 0.5;
      }
      break;

   case SmithContour:
      pitem->scales.xmin  = 0.0;
      pitem->scales.xmax  = 1.0;
      pitem->scales.xstep = 1.0;
      pitem->scales.xtick = 1;
      strcpy (pitem->scales.xformat,"%.1f");

      if (pitem->scaling & ManualY2)
         check_scales (pitem,Y2axis);
      else
      {
         autoscale_axis (pitem,Y2axis);
         pitem->scales.y2step *= 0.5;
      }
      break;
   }
}

/******************************************************************************/
/******************************************************************************/

static LINE_SEG *calculate_contour_intersections (jPLOT_DATA *ditem, int *n_segments)
{
   int npts = ditem->n_pts;
   double *xdata = ditem->x_data;
   double *y1data = ditem->y1_data;
   double *y2data = ditem->y2_data;
   struct point_info *point,tmp;
   struct dist_info  *dist,dtmp;
   LINE_SEG *line_seg;
   int      seg_counter,nsegs;
   int      i,j,k,n;
   double   angles[6],y1,y2,y1ref,y2ref;

   point = (struct point_info *) malloc (sizeof (struct point_info)*npts);
   dist  = (struct dist_info *)  malloc (sizeof (struct dist_info)*npts);

   line_seg = (LINE_SEG *) malloc (sizeof (LINE_SEG)*npts*6);
   seg_counter = 0;

   // load the point structure
   for (i = 0; i < npts; ++i)
   {
      point[i].x = xdata[i];
      point[i].y = y1data[i];
      point[i].index = i;
   }

   // sort the point structure by increasing x value
   for (i = 0; i < (npts-1); ++i)
   {
      for (j = i+1; j < npts; ++j)
      {
         if (point[j].x < point[i].x)
         {
            tmp = point[j];
            point[j] = point[i];
            point[i] = tmp;
         }
      }
   }

   for (i = 0; i < (npts-1); ++i)
   {
      // load the distance table
      for (j = i+1; j < npts; ++j)
      {
         dist[j].index = point[j].index;
         dist[j].d = sqr(point[j].x-point[i].x) + sqr(point[j].y-point[i].y);
         if (point[j].x == point[i].x)
            if (point[j].y > point[i].y)
               dist[j].a = 90.0;
            else
               dist[j].a = -90.0;
         else
            dist[j].a = RAD2DEG*atan ((point[j].y-point[i].y)/(point[j].x-point[i].x));
      }

      // sort the distance table
      for (j = i+1; j < (npts-1); ++j)
      {
         for (k = j+1; k < npts; ++k)
         {
            if (dist[k].d < dist[j].d)
            {
               dtmp = dist[k];
               dist[k] = dist[j];
               dist[j] = dtmp;
            }
         }
      }


      // calculate line segments
      line_seg[seg_counter].pnt1 = point[i].index;   // always use the closest point
      line_seg[seg_counter].pnt2 = dist[i+1].index;
      line_seg[seg_counter].ignore = FALSE;
      angles[0] = dist[i+1].a;
      ++seg_counter;
      nsegs = 1;
      for (j = i+2; j < ((npts < i+20) ? npts : i+11); ++j)
      {
         // check to see if the angle is g.t. 10 degrees from already established segments
         for (k = 0, n = 0; k < nsegs; ++k)
         {
            if (fabs (dist[j].a-angles[k]) > 10.0)
               ++n;
         }

         // passed the angle exclusion test
         if (n == nsegs)
         {
            line_seg[seg_counter].pnt1 = point[i].index;
            line_seg[seg_counter].pnt2 = dist[j].index;
            line_seg[seg_counter].ignore = FALSE;
            angles[nsegs] = dist[j].a;
            ++seg_counter;
            ++nsegs;
         }

         // allow a maximum of 6 line segments to be added per point
         if (nsegs > 5)
            break;
      }
   }

   *n_segments = seg_counter;

   // set the ignore flags on any segments that cross shorter segments
   for (i = 0; i < (seg_counter-1); ++i)
   {
      for (j = i+1; j < seg_counter; ++j)
      {
         // segment has already been removed
         if (line_seg[i].ignore)
            break;

         // segment has already been removed
         if (line_seg[j].ignore)
            continue;

         // segments share a common endpoint, so they can't cross
         if ((line_seg[i].pnt1 == line_seg[j].pnt1) || (line_seg[i].pnt1 == line_seg[j].pnt2) ||
            (line_seg[i].pnt2 == line_seg[j].pnt1) || (line_seg[i].pnt2 == line_seg[j].pnt2))
            continue;

         // segments do not cross in X, so they can't in Y
         if (ditem->x_data[line_seg[i].pnt2] <= ditem->x_data[line_seg[j].pnt1])
            continue;

         y1 = y1data[line_seg[j].pnt1];
         y1ref = (y1data[line_seg[i].pnt1] - y1data[line_seg[i].pnt2]) /
            (xdata[line_seg[i].pnt1] - xdata[line_seg[i].pnt2]) *
            (xdata[line_seg[j].pnt1] - xdata[line_seg[i].pnt1]) + y1data[line_seg[i].pnt1];

         if (xdata[line_seg[i].pnt2] < xdata[line_seg[j].pnt2])
         {
            y2 = (y1data[line_seg[j].pnt1] - y1data[line_seg[j].pnt2]) /
               (xdata[line_seg[j].pnt1] - xdata[line_seg[j].pnt2]) *
               (xdata[line_seg[i].pnt2] - xdata[line_seg[j].pnt1]) + y1data[line_seg[j].pnt1];
            y2ref = y1data[line_seg[i].pnt2];
         }
         else
         {
            y2 = y1data[line_seg[j].pnt2];
            y2ref = (y1data[line_seg[i].pnt1] - y1data[line_seg[i].pnt2]) /
               (xdata[line_seg[i].pnt1] - xdata[line_seg[i].pnt2]) *
               (xdata[line_seg[j].pnt2] - xdata[line_seg[i].pnt1]) + y1data[line_seg[i].pnt1];
         }

         if (((y1 > y1ref) && (y2 < y2ref)) || ((y1 < y1ref) && (y2 > y2ref)))
         {
            y1 = sqr(y1data[line_seg[i].pnt2] - y1data[line_seg[i].pnt1]) +
               sqr(xdata[line_seg[i].pnt2] - xdata[line_seg[i].pnt1]);
            y2 = sqr(y1data[line_seg[j].pnt2] - y1data[line_seg[j].pnt1]) +
               sqr(xdata[line_seg[j].pnt2] - xdata[line_seg[j].pnt1]);

            if (y1 > y2)
               line_seg[i].ignore = TRUE;
            else
               line_seg[j].ignore = TRUE;
         }
      }
   }

   return line_seg;
}

/******************************************************************************/
/******************************************************************************/

static BOOL is_triangle (struct point_list pl1, struct point_list pl2, LINE_SEG *segs, int nsegs)
{
   int  k;

   if ((pl1.p1 == pl2.p1) && (pl1.p2 == pl2.p2))
      return FALSE;

   if (pl1.p1 == pl2.p1)
   {
      for (k = 0; k < nsegs; ++k)
      {
         if (!segs[k].ignore)
            if (((segs[k].pnt1 == pl1.p2) && (segs[k].pnt2 == pl2.p2)) ||
               ((segs[k].pnt2 == pl1.p2) && (segs[k].pnt1 == pl2.p2)))
               return TRUE;
      }
   }
   else if (pl1.p1 == pl2.p2)
   {
      for (k = 0; k < nsegs; ++k)
      {
         if (!segs[k].ignore)
            if (((segs[k].pnt1 == pl1.p2) && (segs[k].pnt2 == pl2.p1)) ||
               ((segs[k].pnt2 == pl1.p2) && (segs[k].pnt1 == pl2.p1)))
               return TRUE;
      }
   }
   else if (pl1.p2 == pl2.p1)
   {
      for (k = 0; k < nsegs; ++k)
      {
         if (!segs[k].ignore)
            if (((segs[k].pnt1 == pl1.p1) && (segs[k].pnt2 == pl2.p2)) ||
               ((segs[k].pnt2 == pl1.p1) && (segs[k].pnt1 == pl2.p2)))
               return TRUE;
      }
   }
   else if (pl1.p2 == pl2.p2)
   {
      for (k = 0; k < nsegs; ++k)
      {
         if (!segs[k].ignore)
            if (((segs[k].pnt1 == pl1.p1) && (segs[k].pnt2 == pl2.p1)) ||
               ((segs[k].pnt2 == pl1.p1) && (segs[k].pnt1 == pl2.p1)))
               return TRUE;
      }
   }

   return FALSE;
}

/******************************************************************************/
/******************************************************************************/





