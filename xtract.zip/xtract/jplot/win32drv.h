#ifndef JPLOT_WIN32_H
#define JPLOT_WIN32_H

#ifdef __cplusplus
extern "C" {
#endif

/* function prototypes */
extern BOOL win32_open_device (DRIVER_INFO *);
extern void win32_close_device (void);
extern BOOL win32_draw_line (double, double, double, double, int, int, int);
extern BOOL win32_draw_text (const char *, double, double, int, int, double, int, int, int);
extern BOOL win32_draw_polyline (double *, double *, int, int, int, int);
extern int  win32_draw_handler (BOOL (*)(void));

/* error list */

static ERROR_NAMES WIN32_ERRORS[] = {
   {301,"WIN32: Failed to register the main window class."},
   {302,"WIN32: Failed to initialize the main window."},
   {303,"WIN32: Pen creation failed."},
   {304,"WIN32: Font creation failed."},
   {305,"WIN32: Line draw failed."},
   {306,"WIN32: Text draw failed."},
   {307,"WIN32: Polyline draw failed."},
   {308,"WIN32: Memory allocation failed."}
   };

#define NUM_WIN32_ERRORS 8

#ifdef __cplusplus
}
#endif

#endif /* JPLOT_WIN32_H */

