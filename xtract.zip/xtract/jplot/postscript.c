#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "jplot.h"

static int    page_number = 1;
static int    landscape   = 0;
static int    current_lt,current_lw;
static int    current_ts,current_font,current_ps;
static int    current_color;
static double scale_factor;
static FILE   *ps_file;

static void set_color (int);
static char *get_the_time (char *);

/****************************************************************************/
/****************************************************************************/

BOOL ps_open_device (DRIVER_INFO *dData)
   {
   double tscale;
   char   string[100];
   char   *fname;

   page_number = 1;

   if ((strlen (dData->filename) < 1) || (dData->filename[0] < 21))
      fname = "plotfile.ps";
   else
      fname = dData->filename;

   ps_file = fopen (fname,"w+");
   if (!ps_file)
      return FALSE;

   // write header info
   fprintf (ps_file,"%%!PS-Adobe-1.0\n");
   fprintf (ps_file,"%%%%Creator: jPlot Plotting Utility - Postscript\n");
   fprintf (ps_file,"%%%%Version: 2.0.1\n");
   fprintf (ps_file,"%%%%Title: None\n");
   fprintf (ps_file,"%%%%CreationDate: %s\n", get_the_time (string));
   fprintf (ps_file,"%%%%Pages: (atend)\n");
   fprintf (ps_file,"%%%%BoundingBox: 0 0 612 792\n");
   if (dData->orientation == ORIENT_PORTRAIT)
      {
      fprintf (ps_file,"%%%%Orientation: Portrait\n");
      scale_factor = 792.0/dData->page_height_in;
      tscale = 612.0/dData->page_width_in;
      landscape = 0;
      }
   else
      {
      fprintf (ps_file,"%%%%Orientation: Landscape\n");
      scale_factor = 612.0/dData->page_height_in;
      tscale = 792.0/dData->page_width_in;
      landscape = 1;
      }

   if (scale_factor > tscale)
      scale_factor = tscale;

   fprintf (ps_file,"%%%%DocumentFonts: (atend)\n");
   fprintf (ps_file,"%%%%EndComments\n");

   // create definitions for drawing lines and text
   fprintf (ps_file,"/s {stroke} def\n");
   fprintf (ps_file,"/n {newpath} def\n");
   fprintf (ps_file,"/m {moveto} def\n");
   fprintf (ps_file,"/v {lineto} def\n");
   fprintf (ps_file,"/r {rotate} def\n");
   fprintf (ps_file,"/ljt {show} def\n");
   fprintf (ps_file,"/cjt {dup stringwidth pop -0.5 mul 0.0 rmoveto show} def\n");
   fprintf (ps_file,"/rjt {dup stringwidth pop -1.0 mul 0.0 rmoveto show} def\n");

   // end prolog, now ready to start drawing stuff
   fprintf (ps_file,"%%%%EndProlog\n");

   return TRUE;
   }

/****************************************************************************/
/****************************************************************************/

void ps_close_device (void)
   {
   fclose (ps_file);
   }

/****************************************************************************/
/****************************************************************************/

BOOL ps_new_page (void)
   {
   fprintf (ps_file,"%%%%Page: %d %d\n",page_number,page_number);

   if (landscape)
      {
      //fprintf (ps_file,"0.0 792.0 translate\n");
      //fprintf (ps_file,"-90.0 rotate\n");
      fprintf (ps_file,"612.0 0.0 translate\n");
      fprintf (ps_file,"90.0 rotate\n");
      }

   fprintf (ps_file,"0 setlinecap\n");      // set line cap to butt
   fprintf (ps_file,"1 setlinejoin\n");     // set line join to round
   fprintf (ps_file,"0.5 setlinewidth\n");  // set line width
   fprintf (ps_file,"[] 0 setdash\n");      // set line type to solid
   set_color (CLR_BLACK);

   current_color = CLR_BLACK;
   current_lt = LT_SOLID;
   current_lw = 1;
   current_font = -1;
   current_ps = 0;
   current_ts = 0;

   return TRUE;
   }

/****************************************************************************/
/****************************************************************************/

void ps_end_page (void)
   {
   fprintf (ps_file,"showpage\n");
   ++page_number;
   }

/****************************************************************************/
/****************************************************************************/

BOOL ps_draw_polyline (double *x, double *y, int n, int ltype, int lwidth, int lcolor)
   {
   int     i;

   if (lcolor != current_color)
      {
      set_color (lcolor);
      current_color = lcolor;
      }

   if (lwidth != current_lw)
      {
      fprintf (ps_file,"%.1f setlinewidth\n",((double) lwidth)*0.5);
      current_lw = lwidth;
      }

   if (ltype != current_lt)
      {
      switch (ltype)
         {
         case LT_DOTTED:
            fprintf (ps_file,"[2] 0 setdash\n");
            break;
         case LT_DASHED:
            fprintf (ps_file,"[6 2] 0 setdash\n");
            break;
         case LT_DOTDASH:
            fprintf (ps_file,"[6 2 2 2] 0 setdash\n");
            break;
         case LT_DOTDOTDASH:
            fprintf (ps_file,"[6 2 2 2 2 2] 0 setdash\n");
            break;
         default:
         case LT_SOLID:
            fprintf (ps_file,"[] 0 setdash\n");
            break;
         }

      current_lt = ltype;
      }

   fprintf (ps_file,"n %.1f %.1f m\n",x[0]*scale_factor,y[0]*scale_factor);
   for (i = 1; i < (n-1); ++i)
      fprintf (ps_file,"%.1f %.1f v\n",x[i]*scale_factor,y[i]*scale_factor);
   fprintf (ps_file,"%.1f %.1f v s\n",x[n-1]*scale_factor,y[n-1]*scale_factor);

   return TRUE;
   }

/****************************************************************************/
/****************************************************************************/

BOOL ps_draw_line (double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor)
   {
   double  x[2],y[2];

   x[0] = x1;
   x[1] = x2;
   y[0] = y1;
   y[1] = y2;

   return ps_draw_polyline (x,y,2,ltype,lwidth,lcolor);
   }

/****************************************************************************/
/****************************************************************************/

BOOL ps_draw_text (const char *string, double x, double y, int font, int psize, double angle, int justify, int tcolor, int style)
   {
   int     i;

   if (current_color != tcolor)
      {
      set_color (tcolor);
      current_color = tcolor;
      }

   if ((font != current_font) || (style != current_ts) || (psize != current_ps))
      {
      switch (font)
         {
         case FNT_HELVETICA:
            if ((style & TS_BOLDFACE) && (style & TS_ITALIC))
               fprintf (ps_file,"/Helvetica-BoldOblique findfont %d scalefont setfont\n",psize);
            else if (style & TS_BOLDFACE)
               fprintf (ps_file,"/Helvetica-Bold findfont %d scalefont setfont\n",psize);
            else if (style & TS_ITALIC)
               fprintf (ps_file,"/Helvetica-Oblique findfont %d scalefont setfont\n",psize);
            else
               fprintf (ps_file,"/Helvetica findfont %d scalefont setfont\n",psize);
            break;

         case FNT_TIMES:
            if ((style & TS_BOLDFACE) && (style & TS_ITALIC))
               fprintf (ps_file,"/Times-BoldItalic findfont %d scalefont setfont\n",psize);
            else if (style & TS_BOLDFACE)
               fprintf (ps_file,"/Times-Bold findfont %d scalefont setfont\n",psize);
            else if (style & TS_ITALIC)
               fprintf (ps_file,"/Times-Italic findfont %d scalefont setfont\n",psize);
            else
               fprintf (ps_file,"/Times-Roman findfont %d scalefont setfont\n",psize);
            break;

         default:
         case FNT_COURIER:
            if ((style & TS_BOLDFACE) && (style & TS_ITALIC))
               fprintf (ps_file,"/Courier-BoldOblique findfont %d scalefont setfont\n",psize);
            else if (style & TS_BOLDFACE)
               fprintf (ps_file,"/Courier-Bold findfont %d scalefont setfont\n",psize);
            else if (style & TS_ITALIC)
               fprintf (ps_file,"/Courier-Oblique findfont %d scalefont setfont\n",psize);
            else
               fprintf (ps_file,"/Courier findfont %d scalefont setfont\n",psize);
            break;
         }

      current_ps   = psize;
      current_ts   = style;
      current_font = font;
      }

   // move to the right place
   fprintf (ps_file,"%.1f %.1f m\n",x*scale_factor,y*scale_factor);

   // check angle
   if (angle != 0.0)
      fprintf (ps_file,"%.1f r\n",angle);

   // write the string
   // need to check for invalid characters....
   fputc ('(',ps_file);
   for (i = 0; i < ((int) strlen (string)); ++i)
      {
      if ((string[i] == '(') || (string[i] == ')') || (string[i] == '\\'))
         fputc ('\\',ps_file);

      // might need to add file line length restriction here

      fputc (string[i],ps_file);
      }
   fprintf (ps_file,") ");

   switch (justify)
      {
      case CENTER_JUSTIFY:
         fprintf (ps_file,"cjt\n");
         break;
      case RIGHT_JUSTIFY:
         fprintf (ps_file,"rjt\n");
         break;
      default:
      case LEFT_JUSTIFY:
         fprintf (ps_file,"ljt\n");
         break;
      }

   // reset angle
   if (angle != 0.0)
      fprintf (ps_file,"%.1f r\n",-angle);

   return TRUE;
   }

/****************************************************************************/
/****************************************************************************/

static void set_color (int color)
   {
   double   r,g,b;

   switch (color)
      {
      case CLR_RED:
         r = 1.0;
         g = 0.0;
         b = 0.0;
         break;
      case CLR_GREEN:
         r = 0.0;
         g = 1.0;
         b = 0.0;
         break;
      case CLR_BLUE:
         r = 0.0;
         g = 0.0;
         b = 1.0;
         break;
      case CLR_YELLOW:
         r = 1.0;
         g = 1.0;
         b = 0.0;
         break;
      case CLR_LIGHTGREY:
         r = 0.75;
         g = 0.75;
         b = 0.75;
         break;
      case CLR_GREY:
         r = 0.5;
         g = 0.5;
         b = 0.5;
         break;
      case CLR_DARKGREY:
         r = 0.25;
         g = 0.25;
         b = 0.25;
         break;
      case CLR_ORANGE:
         r = 1.0;
         g = 0.5;
         b = 0.0;
         break;
      case CLR_LIGHTBLUE:
         r = 0.2;
         g = 0.9;
         b = 1.0;
         break;
      case CLR_DARKGREEN:
         r = 0.0;
         g = 0.6;
         b = 0.1;
         break;
      case CLR_BROWN:
         r = 0.4;
         g = 0.3;
         b = 0.3;
         break;
      case CLR_PURPLE:
         r = 0.7;
         g = 0.1;
         b = 0.4;
         break;
      case CLR_MAROON:
         r = 0.85;
         g = 0.0;
         b = 0.0;
         break;
      default:
      case CLR_BLACK:
         r = 0.0;
         g = 0.0;
         b = 0.0;
         break;
      }

   fprintf (ps_file,"%.4f %.4f %.4f setrgbcolor\n",r,g,b);
   }

/****************************************************************************/
/****************************************************************************/

static char *get_the_time (char *string)
   {
   time_t clock;
   char  *pointer;
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];

   time (&clock);
   pointer = asctime (localtime (&clock));

   sscanf (pointer+8,"%2s",s_day);
   sscanf (pointer+4,"%3s",s_month);
   sscanf (pointer+20,"%4s",s_year);
   sscanf (pointer+11,"%8s",s_time);

   sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

   return string;
   }
