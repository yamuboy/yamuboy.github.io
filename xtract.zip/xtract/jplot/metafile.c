/* ------------------------------------------------------------------------- */
/*                                                                           */
/*                          WINDOWS METAFILE ROUTINES                        */
/*                                                                           */
/*                                                                           */
/*     These routines will write a binary output file in 16-bit Windows      */
/*                 metafile format (vector-based graphics)                   */
/*                                                                           */
/*                          Author: Jay Barrett                              */
/*                           December 23, 2002                               */
/*                            Revision 2.00.00                               */
/* ------------------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <jplot.h>

// define the resolution of the metafile
#define META_UNITS_PER_INCH    576

#define MAX_OBJECTS   3

/* ------- global variables ------- */
static int           page_number;
static FILE          *wmf_file = NULL;
static double        text_angle;
static int           text_size,text_color,text_font,text_style,text_justify;
static int           line_color,line_type,line_width;
static char          wmf_basename[MAX_FILENAME_LENGTH];
static unsigned long largest_object;
static unsigned long file_size;
static unsigned int  object_count;
static unsigned int  line_object,text_object,base_brush;
static unsigned int  *global_parameter_array;
static unsigned int  parameter_array_length;
static unsigned int  current_object_number;
static int           objects[MAX_OBJECTS];
static double        page_height,page_width;

/* ------ static prototypes ------- */
static void write_wmf_record (unsigned int,unsigned int *,unsigned int);
static void write_word (unsigned int,FILE *);
static void write_dword (unsigned long,FILE *);
static void set_color (int,unsigned int *,unsigned int *);
static unsigned int find_object_number (void);
static int add_text_as_integers (const char *,unsigned int *);

/*******************************************************************************/
/*******************************************************************************/

BOOL wmf_open_device (DRIVER_INFO *dData)
   {
   int      i;
   unsigned len;

   len = strlen (dData->filename);
   if (len > (MAX_FILENAME_LENGTH-7))
      len = MAX_FILENAME_LENGTH-7;

   for (i = len-1; i > 0; --i)
      {
      if (dData->filename[i] == '.')
         {
         len = i;
         break;
         }
      else if ((dData->filename[i] == '/') || (dData->filename[i] == '\\'))
         break;
      }

   if (len < 1)
      strcpy (wmf_basename,"plotfile");
   else
      {
      strncpy (wmf_basename,dData->filename,len);
      wmf_basename[(strlen (dData->filename) < len) ? strlen (dData->filename) : len] = 0;
      }

   // need to allocate a parameter vector, start with a size of 200
   global_parameter_array = (unsigned int *) malloc (sizeof (unsigned int)*200);
   parameter_array_length = 200;

   page_height = dData->page_height_in;
   page_width = dData->page_width_in;

   // set some shit here
   page_number = 1;

   if (wmf_file != NULL)
      fclose (wmf_file);

   return TRUE;
   }

/*******************************************************************************/
/*******************************************************************************/

void wmf_close_device (void)
   {
   // free the parameter array memory
   free ((void *) global_parameter_array);
   global_parameter_array = NULL;

   if (wmf_file != NULL)
      fclose (wmf_file);
   }

/*******************************************************************************/
/*******************************************************************************/

BOOL wmf_open_file (void)
   {
   char          file_name[MAX_FILENAME_LENGTH];
   int           i;
   unsigned int  *params;
   unsigned int  checksum,iword;
   unsigned int  x_extent,y_extent;

   sprintf (file_name,"%s-%d.wmf",wmf_basename,page_number);
   wmf_file = fopen (file_name,"wb+");
   if (!wmf_file)
      return FALSE;

   params = global_parameter_array;
   if (params == NULL)
      return FALSE;

   // set anything that we need to set here
   text_object  = 0;
   line_object  = 0;
   object_count = 0;

   // initialize object array
   for (i = 0; i < MAX_OBJECTS; ++i)
      objects[i] = 0;

   /* placeable metafile header - 11 words (22 bytes) */

   /* sets the magic number (0x9ac6cdd7), the handle (0x0000), and the origin to be in the */
   /* upper left corner of the graphic  */
   write_word (0xcdd7,wmf_file);
   write_word (0x9ac6,wmf_file);
   write_word (0x0000,wmf_file);
   write_word (0x0000,wmf_file);
   write_word (0x0000,wmf_file);

   checksum = 0x5711;

   /* set the metafile width in metafile units */
   iword = (unsigned int) (((double) META_UNITS_PER_INCH)*page_width);
   x_extent = iword;
   write_word (iword,wmf_file);
   checksum ^= iword;

   /* set the metafile height in metafile units */
   iword = (unsigned int) (((double) META_UNITS_PER_INCH)*page_height);
   y_extent = iword;
   write_word (iword,wmf_file);
   checksum ^= iword;

   /* set the metafile units per inch */
   iword = (unsigned int) META_UNITS_PER_INCH;
   write_word (iword,wmf_file);
   checksum ^= iword;

   /* set the reserved word to 0x00000000 */
   write_dword (0x00000000,wmf_file);

   /* write the checksum */
   write_word (checksum,wmf_file);

   //              standard metafile header - 9 words (18 bytes)
   // set the file type to disk (0x0001), the header size (0x0009), the windows version (0x0300)
   // for 16-bit compatibility, the file size (0x00000000 - placeholder will change later), the
   // number of objects (another placeholder - 0x0000), the max record size (again a
   // placeholder to be set later - 0x00000000), and the last field is unused and must be set to 0x0000

   write_word (0x0001,wmf_file);
   write_word (0x0009,wmf_file);
   write_word (0x0300,wmf_file);
   write_dword (0x00000000,wmf_file);
   write_dword (0x00000000,wmf_file);
   write_dword (0x00000000,wmf_file);

   // now that the header is done, reset the filesize counter and largest record size
   file_size = 9L;  // 9 words, placeable header doesn't count toward file size
   largest_object = 0L; // no objects yet, write_wmf_record() keeps track of the largest

   // set up the basic drawable and brush/pen styles
   params[0] = 8;
   write_wmf_record (0x0103,params,1);  /* META_SETMAPMODE - set the mapping mode to anisotropic */

   params[0] = 0;
   params[1] = 0;
   write_wmf_record (0x020b,params,2);  /* META_SETWINDOWORG - map window origin to (0,0) */

   params[0] = y_extent;
   params[1] = x_extent;
   write_wmf_record (0x020c,params,2);  /* META_SETWINDOWEXT - set the window extents */

   params[0] = 1;
   write_wmf_record (0x0102,params,1);  /* META_SETBKMODE - background mode (transparent) */

   params[0] = 0xffff;
   params[1] = 0x00ff;
   write_wmf_record (0x0201,params,2);  /* META_SETBKCOLOR - background color (white) */

   params[0] = 24;
   write_wmf_record (0x012e,params,1);  /* META_SETTEXTALIGN */
   text_justify = LEFT_JUSTIFY;

   params[0] = 0x000d;
   params[1] = 0x0000;
   write_wmf_record (0x0104,params,2);  /* META_SETROP2 - GC in X windows (copy pen) */

   params[0] = 0x0000;
   params[1] = 0x0000;
   write_wmf_record (0x0209,params,2);  /* META_SETTEXTCOLOR */
   text_color = CLR_BLACK;

   params[0] = 0x0000;
   params[1] = 0x0000;
   params[2] = 0x0000;
   params[3] = 0x0000;
   write_wmf_record (0x02fc,params,4);  /* META_CREATEBRUSHINDIRECT - create a base brush object */
   base_brush = find_object_number ();

   params[0] = base_brush;
   write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT (select the brush we created) */
   current_object_number = base_brush;

   params[0] = 0x0000;  // style (solid, endcap round, join round)
   params[1] = 1*META_UNITS_PER_INCH/72;       // width in points
   params[2] = 0x0000;  // ???
   params[3] = 0x0000;  // color (black)
   params[4] = 0x0000;  // color cont'd
   write_wmf_record (0x02fa,params,5);  /* META_CREATEPENINDIRECT - initial pen */
   line_object = find_object_number ();

   line_color = CLR_BLACK;
   line_type  = LT_SOLID;
   line_width = 1;

   params[0] = line_object;
   write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT (select the pen we created) */
   current_object_number = line_object;

   return TRUE;
   }

/*******************************************************************************/
/*******************************************************************************/

void wmf_close_file (void)
   {
   unsigned int  *params;

   params = global_parameter_array;

   params[0] = base_brush;
   write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - base brush */
   current_object_number = base_brush;

   if (text_object > 0)
      {
      params[0] = text_object;
      write_wmf_record (0x01f0,params,1);  /* META_DELETEOBJECT */
      objects[text_object] = 0;
      }

   if (line_object > 0)
      {
      params[0] = line_object;
      write_wmf_record (0x01f0,params,1);  /* META_DELETEOBJECT */
      objects[line_object] = 0;
      }

   params[0] = 0;
   write_wmf_record (0x012d,params,1);  /* META_SETTEXTALIGN - dummy instruction */

   /* write the terminating string */
   write_wmf_record (0x0000,params,0);

   /* write the wmf file size (in words not bytes) */
   fseek (wmf_file,28L,SEEK_SET);
   write_dword (file_size,wmf_file);

   // write the number of objects in the file
   write_word ((unsigned) (object_count + 1),wmf_file);

   // write the largest record size
   write_dword (largest_object,wmf_file);

   fclose (wmf_file);
   wmf_file = NULL;

   // increment the page counter
   ++page_number;
   }

/*******************************************************************************/
/*******************************************************************************/

BOOL wmf_draw_polyline (double *x, double *y, int n, int ltype, int lwidth, int lcolor)
   {
   unsigned int   *params,vsize;
   int            i,j;

   // check to make sure the parameter vector is big enough
   // if not, allocate a larger vector
   vsize = 2*n+1;
   if (parameter_array_length < vsize)
      {
      free ((void *) global_parameter_array);
      global_parameter_array = (unsigned int *) malloc (sizeof(unsigned int)*vsize);
      parameter_array_length = vsize;
      }
   params = global_parameter_array;

   // need to check to see if lwidth, ltype, or lcolor changes
   // metafiles requires us to create a new pen if these change
   if ((ltype != line_type) || (lwidth != line_width) || (lcolor != line_color) || (line_object < 1))
      {
      params[0] = base_brush;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - base brush */
      current_object_number = base_brush;

      // delete old line object if it exists
      if (line_object > 0)
         {
         params[0] = line_object;
         write_wmf_record (0x01f0,params,1);  /* META_DELETEOBJECT */
         objects[line_object] = 0;
         }

      // set the line type (also set join round and endcap flat)
      switch (ltype)
         {
         case LT_DASHED:
            params[0] = 0x0001;
            break;
         case LT_DOTTED:
            params[0] = 0x0002;
            break;
         case LT_DOTDASH:
            params[0] = 0x0003;
            break;
         case LT_DOTDOTDASH:
            params[0] = 0x0004;
            break;
         default:
         case LT_SOLID:
            params[0] = 0x0000;
            break;
         }

      params[1] = lwidth*META_UNITS_PER_INCH/72;     // set line width in points
      params[2] = 0x0000;                       // don't know what this does
      set_color (lcolor,&params[3],&params[4]); // set the line color
      write_wmf_record (0x02fa,params,5);       /* META_CREATEPENINDIRECT */

      // find the new object number for the text object
      i = find_object_number ();

      params[0] = line_object;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT (select the pen we created) */
      current_object_number = line_object;

      line_color = lcolor;
      line_type = ltype;
      line_width = lwidth;
      }

   if (current_object_number != line_object)
      {
      params[0] = line_object;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT -  select the pen */
      current_object_number = line_object;
      }

   params[0] = n; /* number of points */
   j = 1;
   for (i = 0; i < n; ++i)
      {
      params[j] = (unsigned int) (x[i]*((double) META_UNITS_PER_INCH));
      params[j+1] = (unsigned int) ((page_height-y[i])*((double) META_UNITS_PER_INCH));
      j += 2;
      }
   write_wmf_record (0x0325,params,2*n+1);  /* META_POLYLINE */

   return TRUE;
   }

/*******************************************************************************/
/*******************************************************************************/

BOOL wmf_draw_line (double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor)
   {
   double  x[2],y[2];

   x[0] = x1;
   x[1] = x2;
   y[0] = y1;
   y[1] = y2;

   return wmf_draw_polyline (x,y,2,ltype,lwidth,lcolor);
   }

/*******************************************************************************/
/*******************************************************************************/

BOOL wmf_draw_text (const char *string, double x, double y, int font, int size, double angle, int justify, int color, int style)
   {
   unsigned int   *params,vsize;
   int            i,n,len;

   len = strlen (string);
   vsize = len/2 + 27;

   // check to make sure the parameter vector is large enough
   // if not, allocate a larger vector
   if (parameter_array_length < vsize)
      {
      free ((void *) global_parameter_array);
      global_parameter_array = (unsigned int *) malloc (sizeof(unsigned int)*vsize);
      parameter_array_length = vsize;
      }
   params = global_parameter_array;

   // need to check if font, angle, style or size has changed
   // metafiles require that a new object be created each time any attribute changes
   if ((font != text_font) || (fabs(angle-text_angle)>0.1) || (size != text_size)
      || (style != text_style) || (text_object < 1))
      {
      params[0] = base_brush;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - base brush */
      current_object_number = base_brush;

      // delete old text object if exists
      if (text_object > 0)
         {
         params[0] = text_object;
         write_wmf_record (0x01f0,params,1);  /* META_DELETEOBJECT */
         objects[text_object] = 0;
         }

      params[0] = ((unsigned int) 0xFFFF) - META_UNITS_PER_INCH/72*size;  // text height
      params[1] = 0;               // text width (0 sets proportional to height)
      if (angle < 0.0)
         angle += 360.0;
      params[2] = ((unsigned int) angle)*10;  // text angle in 10*degrees
      params[3] = ((unsigned int) angle)*10;

      // set font weight
      if (style & TS_BOLDFACE)
         params[4] = 700;
      else if (style & TS_LIGHT)
         params[4] = 200;
      else
         params[4] = 400;

      // italics = 0x0001, underline = 0x0400
      params[5] = 0;
      if (style & TS_ITALIC)
         params[5] |= 0x0001;
      if (style & TS_UNDERLINE)
         params[5] |= 0x0400;

      params[6] = 0;       // ???
      params[7] = 0x0203;  // ??? - always set to 0x0203 for all fonts

      switch (font)
         {
         case FNT_HELVETICA:
            params[8] = 0x2200;    // font ID number (???)
            n = add_text_as_integers ("Helvetica",&params[9]);
            for (i = 9+n; i < 25; ++i)
               params[i] = 0;
            break;

         case FNT_TIMES:
            params[8] = 0x1200;    // font ID number (???)
            n = add_text_as_integers ("Times New Roman",&params[9]);
            for (i = 9+n; i < 25; ++i)
               params[i] = 0;
            break;

         default:
         case FNT_COURIER:
            params[8] = 0x3100;    // font ID number (???)
            n = add_text_as_integers ("Courier New",&params[9]);
            for (i = 9+n; i < 25; ++i)
               params[i] = 0;
            break;
         }

      write_wmf_record (0x02fb,params,25);  /* META_CREATEFONTINDIRECT - create a font */

      // find the new object number for the text object
      text_object = find_object_number ();

      params[0] = text_object;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - select the font object */
      current_object_number = text_object;

      text_size = size;
      text_font = font;
      text_angle = angle;
      text_style = style;

      params[0] = 0x0000;
      params[1] = 0x0000;
      write_wmf_record (0x0209,params,2);  /* META_SETTEXTCOLOR */
      text_color = CLR_BLACK;
      }

   // select the text object
   if (current_object_number != text_object)
      {
      params[0] = text_object;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT */
      current_object_number = text_object;
      }

   // set color
   if (color != text_color)
      {
      set_color (color,&params[0],&params[1]);
      write_wmf_record (0x0209,params,2);  /* META_SETTEXTCOLOR */
      text_color = color;
      }

   // set justification
   if (justify != text_justify)
      {
      switch (justify)
         {
         case RIGHT_JUSTIFY:
            params[0] = 26;
            break;
         case CENTER_JUSTIFY:
            params[0] = 30;
            break;
         default:
         case LEFT_JUSTIFY:
            params[0] = 24;
            break;
         }
      write_wmf_record (0x012e,params,1);  /* META_SETTEXTALIGN */
      text_justify = justify;
      }

   // write the text object
   params[0] = (unsigned int) ((page_height-y)*((double) META_UNITS_PER_INCH));
   params[1] = (unsigned int) (x*((double) META_UNITS_PER_INCH));
   params[2] = len;
   params[3] = 0;  // don't know
   i = add_text_as_integers (string,&params[4]);

   write_wmf_record (0x0a32,params,i+4);  /* META_EXTTEXTOUT - write text */

   return TRUE;
   }

/*******************************************************************************/
/*******************************************************************************/

static void write_wmf_record (unsigned function, unsigned *params, unsigned num_params)
   {
   unsigned long  rec_size;
   unsigned int   i;

   rec_size = ((unsigned long) num_params) + 3L;
   file_size += rec_size;
   if (rec_size > largest_object)
      largest_object = rec_size;

   /* write the record size */
   write_dword (rec_size,wmf_file);

   /* write the function number */
   write_word (function,wmf_file);

   /* write the parameters */
   for (i = 0; i < num_params; ++i)
      write_word (params[i],wmf_file);
   }

/*******************************************************************************/
/*******************************************************************************/

static void write_word (unsigned iword, FILE *file1)
   {
   unsigned char  bytes[2];

   bytes[0] = (char) (iword & 0xFF);
   bytes[1] = (char) ((iword >> 8) & 0xFF);

   fwrite ((void *) bytes,1,2,file1);
   }

/*******************************************************************************/
/*******************************************************************************/

static void write_dword (unsigned long dword, FILE *file1)
   {
   unsigned char  bytes[4];

   bytes[0] = (char) (dword & 0xFF);
   bytes[1] = (char) ((dword >> 8) & 0xFF);
   bytes[2] = (char) ((dword >> 16) & 0xFF);
   bytes[3] = (char) ((dword >> 24) & 0xFF);

   fwrite ((void *) bytes,1,4,file1);
   }

/*******************************************************************************/
/*******************************************************************************/

static void set_color (int color, unsigned *lowbyte, unsigned *highbyte)
   {
   switch (color)
      {
      case CLR_RED:
         *lowbyte = 0x07ff;
         *highbyte = 0x0005;
         break;
      case CLR_GREEN:
         *lowbyte = 0xfc27;
         *highbyte = 0x0020;
         break;
      case CLR_BLUE:
         *lowbyte = 0x0000;
         *highbyte = 0x00d4;
         break;
      case CLR_YELLOW:
         *lowbyte = 0xf3fc;
         *highbyte = 0x0005;
         break;
      case CLR_LIGHTGREY:
         *lowbyte = 0xdede;
         *highbyte = 0x00de;
         break;
      case CLR_GREY:
         *lowbyte = 0xa4a4;
         *highbyte = 0x00a4;
         break;
      case CLR_DARKGREY:
         *lowbyte = 0x5050;
         *highbyte = 0x0050;
         break;
      case CLR_ORANGE:
         *lowbyte = 0x8bff;
         *highbyte = 0x001a;
         break;
      case CLR_LIGHTBLUE:
         *lowbyte = 0xee4e;
         *highbyte = 0x00ff;
         break;
      case CLR_DARKGREEN:
         *lowbyte = 0x8000;
         *highbyte = 0x0011;
         break;
      case CLR_BROWN:
         *lowbyte = 0x4b65;
         *highbyte = 0x0044;
         break;
      case CLR_PURPLE:
         *lowbyte = 0x1698;
         *highbyte = 0x00d4;
         break;
      case CLR_MAROON:
         *lowbyte = 0x05c3;
         *highbyte = 0x0001;
         break;
      default:
      case CLR_BLACK:
         *lowbyte = 0x0000;
         *highbyte = 0x0000;
         break;
      }
   }

/*******************************************************************************/
/*******************************************************************************/

static unsigned int find_object_number ()
   {
   unsigned int  i;

   for (i = 0; i < MAX_OBJECTS; ++i)
      {
      if (!objects[i])
         {
         objects[i] = 1;
         break;
         }
      }

   if (i > object_count)
      object_count = i;

   if (i == MAX_OBJECTS)
      {
      fprintf (stderr,"Internal problem in metafile driver.\nObject overflow.\n");
      return 0;
      }

   return i;
   }

/*******************************************************************************/
/*******************************************************************************/

static int add_text_as_integers (const char *string, unsigned *vctr)
   {
   int          i,j,len;

   len = strlen (string);

   j = 0;
   for (i = 0; i < len; i += 2)
      {
      vctr[j] = (unsigned int) string[i];
      if ((i+1) < len)
         {
         vctr[j] += (((unsigned int) string[i+1]) << 8);
         }
      ++j;
      }

   return j;
   }
