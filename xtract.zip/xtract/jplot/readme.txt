************************************************************************************
--                                                                                --
********************************   jPlot v2.0   ************************************
--                                                                                --
************************************************************************************
                (the 1.0 release was revamped almost immediately)

Author:            Jay Barrett
Completeion Date:  never really finished (mostly complete as of 1/12/03)
License:           what??

Included files:
------------------------------------------------------------------------------------

compiling_instructions.txt:
  Instructions for compiling and creating a library on Win32, HPUX, and Linux
systems.

driver_info.h:
  Header file contains necessary information and function prototypes/linking for all
of the driver definition source files.  Provides an easy way to add new drivers
without rewriting ANY of the main source code.  This header is used only during
creation of the library and is not needed by any executables compiling using the
library.

jplot.h:
  Header file that contains all function prototypes and macro definitions necessary
to develop executables utilizing this plotting library.

jplot_bitmap:
  X-Windows bitmap file, needed to compile xwindows.c.

jplot_main.c:
  Main routines, all user functions and internal functions exist in this source
module.  Pretty much all bugs have been fixed.

jplot_test.c:
  Test program that utilizes several features of the plotting library.

jplot_types.h:
  Header file that contains structure and constant definitions.  Included in
jplot.h.

known_bugs.txt:
  Known bugs with drivers and such.

metafile.c:
  Metafile graphics driver.

postscript.c:
  Postscript graphics driver.

win32drv.c:
  Windows 32-bit GDI/GUI driver (also works on most 16-bit GDI systems, i.e. Win 
95/98/Me, untested on Win 3.1/3.51).

xwindows.c:
  X-Windows GUI driver.

Notes:
------------------------------------------------------------------------------------

1. A graphics device does not need to be open to create/modify plot items, text,
lines and other stuff.  A call the open_graphics_device (or
open_graphics_device_stdin()) is only necessary before calling draw_page().

2. Failure to call close_graphics_device() before exiting may cause all kinds of
problems on various operating systems, including memory leaks and segmentation/
access violations (especially on 16-bit GDI Windows systems).

3. Addition of lines, text, etc. using the add_userXXXXX/add_XXXXX functions cause
these items to remain as part of the page until removed.

4. Rotation of plot items in non-90 degree increments may cause skewing, due to
axis scaling differences.

5. The countour plotting routines are newly added to the library, so there may still
be bugs.

6. Plot items and user items are handled using certain internal structures as part
of linked lists within the main source code, modification of these routines (in
order to add functionality and such) may have grave consequences as the
relationships between these items are very complex.

7. Although I think the autoscaling functions are now bug free, they have been the
most troublesome functions in development of this library.  If plot item drawing
issues are occuring, try using the manual scaling options.  This should be a last
resort though, since autoscaling makes things very easy, and the routines are
quite robust at this point.






