#ifndef JPLOT_XWINDOWS_H
#define JPLOT_XWINDOWS_H

#ifdef __cplusplus
extern "C" {
#endif

/* function prototypes */
extern BOOL x_open_device (DRIVER_INFO *);
extern void x_close_device (void);
extern BOOL x_draw_line (double, double, double, double, int, int, int);
extern BOOL x_draw_text (const char *, double, double, int, int, double, int, int, int);
extern BOOL x_draw_polyline (double *, double *, int, int, int, int);
extern BOOL x_draw_arc (double, double, double, double, double, int, int, int);
extern BOOL x_draw_circle (double, double, double, int, int, int);
extern int  x_draw_handler (BOOL (*)(void));

/* error list */

static ERROR_NAMES XWINDOWS_ERRORS[] = {
   {0,"XWINDOWS: None defined."}
   };

#define NUM_XWINDOWS_ERRORS  0

#ifdef __cplusplus
}
#endif

#endif /* JPLOT_XWINDOWS_H */

