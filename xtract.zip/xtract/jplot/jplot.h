#ifndef JPLOT_TYPES_INCLUDED  // wrapper to make sure we don't include more than once
#define JPLOT_TYPES_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

// create TRUE and FALSE defs
#ifndef TRUE
#define TRUE    1
#endif
#ifndef FALSE
#define FALSE   0
#endif

// not used at this time
#define ORIENT_PORTRAIT    1
#define ORIENT_LANDSCAPE   2

typedef int BOOL;
typedef unsigned long int jHANDLE;

#define MAX_LABEL_LENGTH     100
#define MAX_FORMAT_LENGTH    20
#define MAX_FILENAME_LENGTH  260

// returned by adduser_xxxx functions when an error occurs
#define USERITEM_ERROR    ((jHANDLE) 0xFFFFFFFF)

// line types
#define LT_SOLID         0
#define LT_DASHED        1
#define LT_DOTDASH       2
#define LT_DOTTED        3
#define LT_DOTDOTDASH    4
// internally used to determine whether to draw lines or points
#define MAX_LINETYPE     4
// point styles for scatter plots
#define PNT_PLUS         5
#define PNT_X            6
#define PNT_TRIANGLE     7
#define PNT_CIRCLE       8
#define PNT_SQUARE       9
#define MAX_POINTTYPE    9

// line widths (any integer g.t. 0 can be used, these are for convenience)
#define LW_THIN     1
#define LW_MEDIUM   3
#define LW_THICK    5

// prevents a compiler warning caused by the common controls library
#ifdef WIN32
#ifdef CLR_DEFAULT
#undef CLR_DEFAULT
#endif
#endif

// colors
#define CLR_DEFAULT       1
#define CLR_BLACK         1
#define CLR_RED           2
#define CLR_GREEN         3
#define CLR_BLUE          4
#define CLR_YELLOW        5
#define CLR_LIGHTGREY     6
#define CLR_LIGHTGRAY     6
#define CLR_GREY          7
#define CLR_GRAY          7
#define CLR_DARKGREY      8
#define CLR_DARKGRAY      8
#define CLR_ORANGE        9
#define CLR_LIGHTBLUE     10
#define CLR_DARKGREEN     11
#define CLR_BROWN         12
#define CLR_MAROON        13
#define CLR_PURPLE        14
#define MAX_CLR_INDEX     14

// text fonts
#define FNT_DEFAULT      1
#define FNT_COURIER      1
#define FNT_TIMES        2
#define FNT_HELVETICA    3

// text justification
#define LEFT_JUSTIFY     0   // legacy definition
#define JUST_LEFT        0
#define CENTER_JUSTIFY   1   // legacy definition
#define JUST_CENTER      1
#define RIGHT_JUSTIFY    2   // legacy definition
#define JUST_RIGHT       2

// text styles (not supported in all drivers)
#define NO_STYLE         0    // legacy definition
#define TS_NONE          0
#define TS_BOLDFACE      1
#define TS_BOLD          1
#define TS_LIGHT         2
#define TS_ITALIC        4
#define TS_UNDERLINE     8

// data types (for attach_data() function)
#define XY_DATA       1
#define POLAR_DATA    8
#define CONTOUR_DATA  16

/******* definitions used in jPLOT_ITEM **********/

/* plot types */
#define SingleY        0
#define DoubleY        1
#define PolarChart     2
#define SmithChart     3
#define XYContour      8
#define PolarContour   9
#define SmithContour   10
/* scaling options - these should be OR'ed to get the desired scaling options */
/* default scaling is (LinearAll | AutoscaleAll) = 0 */
#define AutoscaleAll   0
#define ManualX        1
#define ManualY1       2
#define ManualY2       4
#define ManualAll      7
#define LinearAll      0
#define LogX           8
#define LogY1          16
#define LogY2          32
#define LogAll         56
#define POSITIVE_X     64      // these options force the autoscale routine to allow only
#define POSITIVE_Y1    128     //   positive min and max axis values
#define POSITIVE_Y2    256
/* flags - should be OR'ed */
#define NO_XGRID        1   // suppress the vertical (x-axis) gridlines
#define NO_YGRID        2   // suppress the horizontal (y-axis) gridlines
#define RETRACE         8   // connect all graph points, even when (x_current < x_previous)
#define FULL_LOG_XGRID  16  // draw the full log grid for the x-axis
#define FULL_LOG_YGRID  32  // draw the full log grid for the y-axis

/***** OR'ed to form the mask argument when calling set_plot_item_attributes ****/

#define JPA_FONTS              1    // change label_font, title_font, and axis_font
#define JPA_TEXTSIZE           2    // change label_tsize, title_tsize, and axis_tsize
#define JPA_LABELOFFSETS       4    // change xlabel_offset, ylabel_offset, and title_offset
#define JPA_AXISOFFSETS        8    // change xnum_offset and ynum_offset
#define JPA_TICKSIZE           16   // change major_tick and minor_tick

/********** Structure Definitions ************/

// this structure should only be used internally
typedef struct _jplot_data {
   int type;
   double *x_data;
   double *y1_data,*y2_data;
   int n_pts;
   int y1_ltype,y1_lwidth,y1_color;
   int y2_ltype,y2_lwidth,y2_color;
   struct _jplot_data *next;
} jPLOT_DATA;

typedef struct _jplot_scale {
   double xmin,xmax,xstep;
   int    xtick;
   char   xformat[MAX_FORMAT_LENGTH+1];
   double y1min,y1max,y1step;
   int    y1tick;
   char   y1format[MAX_FORMAT_LENGTH+1];
   double y2min,y2max,y2step;
   int    y2tick;
   char   y2format[MAX_FORMAT_LENGTH+1];
} jPLOT_SCALE;

typedef struct _jplot_attribs {
   int    label_font;
   int    title_font;
   int    axis_font;
   int    label_tsize;
   int    title_tsize;
   int    axis_tsize;
   double xlabel_offset;
   double ylabel_offset;
   double title_offset;
   double xnum_offset;
   double ynum_offset;
   double major_tick;
   double minor_tick;
} jPLOT_ATTRIBS;

typedef struct _jplot_item {
   int     plot_type;
   BOOL    active;
   double  angle;
   double  x_frame_size;
   double  y_frame_size;
   double  x_frame_pos;
   double  y_frame_pos;
   char    x_label[MAX_LABEL_LENGTH+1];
   char    y1_label[MAX_LABEL_LENGTH+1];
   char    y2_label[MAX_LABEL_LENGTH+1];
   char    title[MAX_LABEL_LENGTH+1];
   unsigned int scaling;
   unsigned int flags;
   jPLOT_SCALE   scales;
   jPLOT_ATTRIBS attribs;
   jPLOT_DATA    *data;
   struct _jplot_item *next;
} jPLOT_ITEM;

/****************************************/
/* ******** internal usage only ******* */
/****************************************/

// returned by the draw_handler function of the driver in the case of an abnormal exit
// (internal use, will not be returned by any external function)
#define DRIVER_EXIT    -1

// internal axis selection for drawing of XY plots
#define Xaxis    0
#define Y1axis   1
#define Y2axis   2

// internal type arguments for jPLOT_DATA structures
#define Y1_DATA       2
#define Y2_DATA       4

// internal type arguments for user items
#define USER_LINE       0
#define USER_POLYLINE   1
#define USER_TEXT       2
#define USER_CIRCLE     3
#define USER_ARC        4
#define USER_LEGEND     5

// some constants
#define PI        3.141592653
#define DEG2RAD   (PI/180.0)
#define RAD2DEG   (180.0/PI)

// line-to-line spacing ratio for multi-line text outputs
#define paragraph_aspect    1.15

typedef struct _jplot_user_item {
   int     type;
   jHANDLE handle;
   int     color;
   union // generic pointer union
      {
      double *dVal;
      int    *iVal;
      char   *strg;
      void   *pVal;
      } ptr[5];
   struct _jplot_user_item *next;
} jPLOT_USER;

typedef struct _driver_info {
   char    filename[MAX_FILENAME_LENGTH+1];
   double  page_width_in;
   double  page_height_in;
   int     orientation;
} DRIVER_INFO;

typedef struct _error_names {
   int   errno;
   char  *desc;
} ERROR_NAMES;

struct point_info { double x,y; int index; };
struct point_list { double x,y; int p1,p2; };
struct dist_info  { int index; double d,a; };

typedef struct _line_seg {
   int pnt1,pnt2;
   BOOL ignore;
} LINE_SEG;

/****************************************************************************************/
/****************************************************************************************/
/*   ----                               Functions                                 ----  */
/****************************************************************************************/
/****************************************************************************************/

// error number, only valid when a non-void function returns an error condition
// an error message corresponding to the error number can be retrieved with a call to
// get_error_message
extern int ERROR_NUMBER;

// returns a pointer to a static character string detailing the error
const char *get_error_message( int error_num );

// definitions for driver id's in driver_info.h
#define X_WINDOWS     1
#define WINDOWS       1
#define METAFILE      2
#define POSTSCRIPT    3

// open or switch graphics output devices - in the case of switching the previous driver
// is automatically closed
BOOL open_graphics_device( int driver, const char *filename );

// a call to this function will perform a full cleanup of all resources and then close
// the graphics driver - see cleanup_resources() below
void close_graphics_device(void);

// called to "show" the current page
// should be called after all plot items and user items have been created
// this function will return FALSE if: 1. there is no open graphics device,
// 2. the page draw fails (a draw_XXXXX primitive returns FALSE), or
// 3. the graphics device terminates during the draw_handler routine (this occurs
// when the main GUI window is X'ed in the Win32 and X-Windows drivers)
BOOL draw_page(void);

// plot item stuff
jPLOT_ITEM *create_plot_item( int ptype, double x, double y, double xsize, double ysize );
void remove_plot_item( jPLOT_ITEM *plot_item );
void remove_all_plot_items(void);

// plot items default to being active when they are created
#define activate_plot_item(pitem)      pitem->active=TRUE
#define deactivate_plot_item(pitem)    pitem->active=FALSE

// attach/detach data vectors to a plot item, data vectors are attached by address
// no local copy of the data is kept internal to jPlot at this time (possibly an option in the future)
BOOL attach_data( jPLOT_ITEM *pitem, int type, double *xdata, double *y1data, double *y2data, int n_pts,
                         int y1_ltype, int y1_width, int y1_clr, int y2_ltype, int y2_width, int y2_clr );
void detach_data( jPLOT_ITEM *pitem );

// some macros for attaching data
#define attach_y1data(pitem,xdata,ydata,npts,ltype,width,color)   \
            attach_data(pitem,XY_DATA,xdata,ydata,NULL,npts,ltype,width,color,0,0,0)
#define attach_y2data(pitem,xdata,ydata,npts,ltype,width,color)   \
            attach_data(pitem,XY_DATA,xdata,NULL,ydata,npts,0,0,0,ltype,width,color)
#define attach_polardata(pitem,xdata,ydata,npts,ltype,width,color)      \
            attach_data(pitem,POLAR_DATA,xdata,ydata,NULL,npts,ltype,width,color,0,0,0)

#define attach_contourdata(pitem,xdata,ydata,vdata,npts,ltype,width,lcolor,ptype,pcolor)      \
            attach_data(pitem,CONTOUR_DATA,xdata,ydata,vdata,npts,ltype,width,lcolor,ptype,0,pcolor)

// add items to the plot window, these user items remain until removed with a call to remove_user_item()
// all return USERITEM_ERROR on failure
jHANDLE adduser_text( const char *txt, double x, double y, int font, int psize, double angle, int justify, int color, int style );
jHANDLE adduser_line( double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor );
jHANDLE adduser_polyline( double *x, double *y, int n, int ltype, int lwidth, int lcolor );
jHANDLE adduser_arc( double x, double y, double rad, double astart, double astop, int ltype, int lwidth, int lcolor );
jHANDLE adduser_circle( double x, double y, double rad, int ltype, int lwidth, int lcolor );
jHANDLE adduser_legend( int num_items, double x, double y, const char *txt[], int font, int psize, int ltype[], int lwidth[], int lcolor[] );

// macros to make the adduser_xxxx functions simpler
#define add_text       adduser_text
#define add_line       adduser_line
#define add_polyline   adduser_polyline
#define add_arc        adduser_arc
#define add_circle     adduser_circle
#define add_legend     adduser_legend

// remove user items
void remove_user_item( jHANDLE handle );
void remove_all_user_items(void);

// cleans up all allocated memory, mostly used internally, but can be used to force a full reset
// all returned jHANDLE's and jPLOT_ITEM's become invalid and should no longer be used
// after a call to this function or a call to close_graphics_device()
void cleanup_resources(void);

// sets a new origin and rotation angle for the page, funny things with angles can happen when the angle is not
// changed in increments of 90 degrees due to differences in the x and y scales in certain drivers
// that are not compensated for at this time
void set_page_origin( double x, double y, double angle );

// set the axes' scales manually
void set_axis_scales( jPLOT_ITEM *pitem, jPLOT_SCALE *scale, unsigned int scaling );
void set_x_scale( jPLOT_ITEM *pitem, double start, double stop, double step, int tick, BOOL islog, const char *format );
void set_y1_scale( jPLOT_ITEM *pitem, double start, double stop, double step, int tick, BOOL islog, const char *format );
void set_y2_scale( jPLOT_ITEM *pitem, double start, double stop, double step, int tick, BOOL islog, const char *format );

// set scaling options, equivalent to calling set_axis_scales with the jPLOT_SCALE == NULL
// but implemented in a macro for speed
#define set_axis_scaling(pitem,scalef)  pitem->scaling=(scalef) & 0xFFF8

// sets the axis labels
void set_axis_labels( jPLOT_ITEM *pitem, const char *xlab, const char *y1lab, const char *y2lab, const char *title );

// set plot item flags
#define set_plot_item_flags(pitem,flgs)    pitem->flags=(flgs)

// set plot item attributes
void set_plot_item_attributes( jPLOT_ITEM *pitem, jPLOT_ATTRIBS *attribs, unsigned int mask );

// stuff for command line driver selection, these write to stderr and read from stdin
void list_installed_drivers( BOOL full_info );
BOOL open_graphics_device_stdin( BOOL full_info );

#ifdef __cplusplus
}
#endif

#endif // JPLOT_TYPES_INCLUDED

