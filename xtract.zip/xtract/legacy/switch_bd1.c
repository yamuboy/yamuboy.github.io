#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize3.h"
#include "jplot.h"

#define NUM_PARAMS  5
#define MAX_IV_PTS  500

#define BOLTZ         1.3806226e-23
#define CHARGE        1.6021918e-19
#define STDTEMP       300.0

double *vbr_erf (double *);
double switch_breakdown (double, double, double, double, double, double);
int plot_data (PARAM_STRUCT *p);

double igsiv[MAX_IV_PTS];
double vgsiv[MAX_IV_PTS];
int    num_iv_pts = 0;
double area = 0.0;

main (int argc, char *argv[])
   {
   char vbr_iv_file[100];
   char start_file[100];
   char end_file[100];
   char model_file[100];
   char string[200];
   int  niter,i;
   int  begin_read = 0;
   double weights = 1.0;
   double lastv = 0.0;
   double vds,ids;
   double rg,rd;
   FILE *file,*ifile;
   OPT_STRUCT  opt;   
   PARAM_STRUCT params[NUM_PARAMS];
   
   /************ Get Information ***************/
   
   printf ("Breakdown I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",vbr_iv_file);

   printf ("Gate and Drain Resistance in ohms?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&rg,&rd);

   printf ("Start parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,199,stdin);
   sscanf (string,"%d",&niter);
   
   /************ read in the model data *************/

   file = fopen (vbr_iv_file,"r");
   if (!file)
      {
      printf ("Unable to open IV file - %s\n",vbr_iv_file);
      return -1;
      }

   i = 0;
   while (fgets (string,199,file))
      {
      if (i >= MAX_IV_PTS)
         {
         printf ("WARNING: Max IV points exceeded.\n");
         break;
         }

      if (string[0] == '!')
         {
         if (!strncmp (string,"!GATE PERIPHERY (um):",21))
            sscanf (string,"!GATE PERIPHERY (um):%lf",&area);
         else if (strstr (string,"BREAKDOWN IV-CURVES"))
            {
            fgets (string,199,file);
            fgets (string,199,file);
            begin_read = 1;
            }
            
         continue;
         }

      if (begin_read)
         {
         if (string[0] == '!')
            break;
            
         if (sscanf (string,"%lf%lf%lf%lf",&vds,&ids,&vgsiv[i],&igsiv[i]) == 4)
            {
            vgsiv[i] = (vds - ids*rd) - (vgsiv[i] - igsiv[i]*rg);
            igsiv[i] = -igsiv[i];

            if (vgsiv[i] < lastv)
               break;
               
            lastv = vgsiv[i];
            ++i;
            }
         }
      }
   num_iv_pts = i;

   fclose (file);      

   if (num_iv_pts < 4)
      {
      printf ("ERROR: not enough points in file - %s\n",vbr_iv_file);
      return -1;
      }
   
   /************ read in the starting values **************/
   
   file = fopen (start_file,"r");
   if (!file)
      {
      printf ("ERROR: Unable to open starting values file - %s\n",start_file);
      return -1;
      }
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (!fgets (string,199,file))
         {
         printf ("ERROR: incomplete starting values file.\n");
         fclose (file);
         return -1;
         }
      
      sscanf (string,"%lf%lf%lf%lf%s",&params[i].min,&params[i].nom,&params[i].max,
         &params[i].tol,params[i].name);
      params[i].units[0] = 0;
      params[i].optimize = TRUE;
      
      if (params[i].min > params[i].max)
         {
         printf ("WARNING in parameter \"%s\": MIN > MAX, range reset.\n",params[i].name);
         params[i].max = params[i].min;
         }

      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      else if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;

      if (params[i].tol < 0.0)
         params[i].tol = -params[i].tol;
      }
      
   fclose (file);
   
   /************ optimize the breakdown fit ************/
   
   initialize_optimizer (&opt, NUM_PARAMS, 1, &weights, niter, &vbr_erf);
   opt.err_fraction = 1.0e-9;
   
   if (cg_optimize (opt,params) < 0)
      {
      printf ("ERROR in cg_optimize().\n");
      return -1;
      }
   
   /************* write the results **************/
   
   // write the finishing values file
    
   file = fopen (end_file,"w+");
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (file);
   
   // write the model file
   
   file = fopen (model_file,"w+");
   ifile = fopen (vbr_iv_file,"r");

   i = 0;
   while (++i < 31)
      {
      if (!fgets (string,199,ifile))
         break;

      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         fprintf (file,"%s",string);
         break;
         }
      
      fprintf (file,"%s",string);
      }
   if (fgets (string,199,ifile))
      fprintf (file,"%s",string);
   fclose (ifile);

   fprintf (file,"!\n");
   fprintf (file,"model  =   1\n");
   fprintf (file,"i1     =  %11.4e\n",params[0].nom/area);
   fprintf (file,"n1     =  %11.4e\n",params[1].nom);
   fprintf (file,"ibr    =  %11.4e\n",params[2].nom/area);
   fprintf (file,"nbr    =  %11.4e\n",params[3].nom);
   fprintf (file,"vbr    =  %11.4e\n",params[4].nom);
   fprintf (file,"!\n");
   
   fclose (file);

   /************* plot the results **************/

   plot_data (params);
   
   return 0;
   } 
   
/*******************************************************************************************/
/*******************************************************************************************/

double *vbr_erf (double *p)
   {
   int i;
   double ibr,logval;
   static double error;

   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      ibr = switch_breakdown (vgsiv[i],p[0],p[1],p[2],p[3],p[4]);
      logval = log10 (fabs(ibr/igsiv[i]));
      error += logval*logval*1.0e6;
      }

   error /= ((double) num_iv_pts);

   return &error;
   }
   
/*****************************************************************************/
/*****************************************************************************/

double switch_breakdown (double v, double is, double n, double ip, double np, double vp)
   {
   return is*(exp (v*CHARGE/(BOLTZ*STDTEMP*n)) - 1.0) + ip*pow(v/vp,np);
   }

/*****************************************************************************/
/*****************************************************************************/

int plot_data (PARAM_STRUCT *p)
   {
   jPLOT_ITEM   *plot1;
   int          i;
   double       x1data[MAX_IV_PTS];
   double       y1data[MAX_IV_PTS];
   double       y2data[MAX_IV_PTS];
   double       per_mm = 1000.0/area;
   static char  *legend_t[] = {"Modeled","Measured"};
   static int   legend_l[] = {LT_SOLID,LT_DASHED};
   static int   legend_w[] = {1,1};
   static int   legend_c[] = {CLR_RED,CLR_DARKGREEN};   

   if (!open_graphics_device (X_WINDOWS,NULL))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }
   
   plot1 = create_plot_item (SingleY,2.0,1.25,7.0,6.0);
      
   add_legend (2,9.0,7.75,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);   

   for (i = 0; i < num_iv_pts; ++i)
      {
      x1data[i] = vgsiv[i];
      y1data[i] = switch_breakdown (vgsiv[i],p[0].nom,p[1].nom,p[2].nom,p[3].nom,p[4].nom)*per_mm;
      y2data[i] = igsiv[i]*per_mm;
      }
   
   attach_y1data (plot1,x1data,y1data,num_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,num_iv_pts,LT_DASHED,1,CLR_DARKGREEN);

   set_axis_scaling (plot1,LogY1);

   set_axis_labels (plot1,"Vdg (volts)","Idg (A/mm)","","Breakdown Characteristic");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   close_graphics_device ();
   
   return 0;
   }
