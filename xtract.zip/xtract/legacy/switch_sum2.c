#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MAX_MODELS     50

struct model_head
{
char   device[20];
char   mask[20];
char   process[20];
char   name[20];
char   directory[20];
char   g2gspace[20];
char   wafer[20];
double s2dspace;
double temperature;
double p[15];
};

int main (int argc, char *argv[])
   {
   FILE  *file_list;
   FILE  *sum_file;
   char  buffer[2500];
   char  string[80];
   char  tmp_name[256];
   char  file_names[256];
   char  out_name[256];
   char  *string_pointer;
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];
   unsigned i,j,n,counter;
   time_t mytime;
   struct model_head head[MAX_MODELS];

   printf ("\n");

   printf ("Switch Model files to summarize?\n");
   fgets (file_names, 255, stdin);
   file_names[strlen(file_names)-1] = 0;

   printf ("Summary file name?\n");
   fgets (out_name, 255, stdin);
   out_name[strlen(out_name)-1] = 0;

   sprintf (tmp_name,"tmp.%d",time(&mytime));
   sprintf (buffer,"rm -f %s",tmp_name);
   system (buffer);
   sprintf (buffer,"cat %s > %s",file_names,tmp_name);
   system (buffer);

   file_list = fopen (tmp_name,"r");
   if (!file_list)
      {
      printf ("ERROR opening temporary file.\n");
      return -1;
      }

   sum_file = fopen (out_name, "w+");
   if (!sum_file)
      {
      printf ("ERROR opening summary file for writing.\n");
      return -1;
      }

   string_pointer = asctime (localtime (&mytime));
   sscanf (string_pointer+8,"%s",s_day);
   sscanf (string_pointer+4,"%s",s_month);
   sscanf (string_pointer+20,"%s",s_year);
   sscanf (string_pointer+11,"%s",s_time);

   fprintf (sum_file,"!\n");
   fprintf (sum_file,"! FET SWITCH MODEL SUMMARY PROGRAM VERSION 2.00 %s-%s-%s %s\n", s_day, s_month, s_year, s_time);
   fprintf (sum_file,"!\n");

   // read in the device header information
   
   n = 0;
   while (fgets (buffer, 255, file_list))
      {
      if (!strncmp (buffer, "!FILE NAME:", 11))
         sscanf (buffer, "!FILE NAME: %19s", head[n].device);
      else if (!strncmp (buffer, "!MASK NAME:", 11))
         sscanf (buffer, "!MASK NAME: %4s", head[n].mask);
      else if (!strncmp (buffer, "!PROCESS NAME:", 14))
         sscanf (buffer, "!PROCESS NAME: %19s", head[n].process);
      else if (!strncmp (buffer, "!WAFER NUMBER:", 14))
         sscanf (buffer, "!WAFER NUMBER: %15s", head[n].wafer);
      else if (!strncmp (buffer, "!DEVICE NAME:", 13))
         sscanf (buffer, "!DEVICE NAME: %19s", head[n].name);
      else if (!strncmp (buffer, "!GATE PERIPHERY (um):", 21))
         sscanf (buffer, "!GATE PERIPHERY (um): %lf", &head[n].p[0]);
      else if (!strncmp (buffer, "!GATE LENGTH (um):", 18))
         sscanf (buffer, "!GATE LENGTH (um): %lf", &head[n].p[3]);
      else if (!strncmp (buffer, "!UNIT GATE WIDTH (um):", 22))
         sscanf (buffer, "!UNIT GATE WIDTH (um): %lf", &head[n].p[1]);
      else if (!strncmp (buffer, "!NUMBER OF GATE FINGERS:", 24))
         sscanf (buffer, "!NUMBER OF GATE FINGERS: %lf", &head[n].p[2]);
      else if (!strncmp (buffer, "!GATE TO GATE SPACING (um):", 27))
         sscanf (buffer, "!GATE TO GATE SPACING (um): %19s", head[n].g2gspace);
      else if (!strncmp (buffer, "!SOURCE-DRAIN SPACING (um):", 27))
         sscanf (buffer, "!SOURCE-DRAIN SPACING (um): %lf", &head[n].s2dspace);
      else if (!strncmp (buffer, "!TEMPERATURE (C):", 17))
         sscanf (buffer, "!TEMPERATURE (C): %lf", &head[n].temperature);
      else if (!strncmp (buffer, "!Vbr", 4))
         {
         fgets (buffer, 255, file_list);
         sscanf (buffer, "!%lf%lf%lf%lf%lf%lf%lf%lf",&head[n].p[4], &head[n].p[5], &head[n].p[6], &head[n].p[7],
            &head[n].p[8], &head[n].p[9], &head[n].p[10], &head[n].p[11]);
         head[n].p[6] *= 1.0e6 / head[n].p[0];
         head[n].p[8] *= 1.0e6 / head[n].p[0];
         ++n;
         }
      }
   
   if (!n)
      {
      printf ("ERROR no data.\n");
      sprintf (buffer,"rm -f %s", tmp_name);
      system (buffer);
      return -1;
      }

   // write the file header info
      
   fprintf (sum_file, "!PROCESS NAME: %s\n", head[0].process);
   fprintf (sum_file, "!DEVICE NAME: %s\n", head[0].name);
   fprintf (sum_file, "!GATE PERIPHERY (um): %.1f\n", head[0].p[0]);
   fprintf (sum_file, "!GATE LENGTH (um): %.3f\n", head[0].p[3]);
   fprintf (sum_file, "!UNIT GATE WIDTH (um): %.1f\n", head[0].p[1]);
   fprintf (sum_file, "!NUMBER OF GATE FINGERS: %.0f\n", head[0].p[2]);
   fprintf (sum_file, "!GATE TO GATE SPACING (um): %s\n", head[0].g2gspace);
   fprintf (sum_file, "!SOURCE-DRAIN SPACING (um): %.1f\n", head[0].s2dspace);
   fprintf (sum_file, "!\n");

   // write the device header info

   //                  ! |       | |      | |             | |   | |         | |         | |         | |         | |         | |         | |         | |         |
   fprintf (sum_file, "! Model Dev Mask     Wafer           Temp   Vbr(.1mA)    Vbr(1mA)    Idss(3V)    Vpo(3V)   Imax(1.5V)   Vpo(1.5V)  Vmax(1.5V)  Vpo(1mA/mm)\n");
   fprintf (sum_file, "!                                     (C)      (V)         (V)       (mA/mm)       (V)      (mA/mm)        (V)        (V)          (V)\n");
   for(counter = 0;counter < n; ++counter)
      {                       
      fprintf (sum_file,"! %-5d%c%c%c%c %-8s %-15s %-5.1f", counter + 1, head[counter].device[1], 
         head[counter].device[2], head[counter].device[3], head[counter].device[4], head[counter].mask,
         head[counter].wafer, head[counter].temperature);

      for (j = 4; j < 12; ++j)
         fprintf (sum_file," %11.3e", head[counter].p[j]);
      fprintf (sum_file,"\n");
      }
   fprintf (sum_file, "!\n");
   fprintf (sum_file, "! ****************************************************************************************\n");
   fprintf (sum_file, "!\n");
   fflush (sum_file);
   
   // write the model data
   
   counter = 1;
   rewind (file_list);
   while (fgets (buffer,1024,file_list))
      {
      if (sscanf (buffer,"model = %d",&j))
         {
         for (j = strlen(buffer); j >= 0; --j)
            {
            if (buffer[j] == '=')
               break;
            }
         
         for (i = 0; i <= j; ++i)
             string[i] = buffer[i];
         
         string[i] = 0;
        
         fprintf (sum_file,"%s  %d\n",string,counter);
         ++counter;
         }
      else
         fprintf (sum_file,"%s",buffer);
      }

   fclose (file_list);
   fclose (sum_file);
   
   // remove the temporary file
   
   sprintf (buffer,"rm -f %s",tmp_name);
   system (buffer);   

   printf("Complete!\n");
   }
