#include <stdio.h>
#include <string.h>
#include <math.h>


#define MAXPTS     (1000)

int string_index ();

main ()
{
FILE  *in_file;
FILE  *out_file;
FILE  *tmp;
FILE  *ri_file;
char  ri_name[201];
char  out_name[100];
char  buffer[1025];
char  param[201];
int   n,j,flag;
char  system_command[201];
double rd,nn,is,area,k3;
double min,nom,max,last,zero,f0,vbr,gmax;
double ig0,r0,alfg,ugw,ngf,rs;
double cgs0,cgs1,acgs,vcgs,ri;
double idss,vpo,gama,e,ke,sl,ss,kg;
double idss_rf,vpo_rf,gama_rf,e_rf,ke_rf,sl_rf,ss_rf,kg_rf;
double lg,ld,ls,rg,cgs,cdg,cds,tau1,c11,c22;
double vdd[MAXPTS];
double vgg[MAXPTS];
double idd[MAXPTS];
double igg[MAXPTS];


zero = (double) 0.0;
printf("End File for Ri, Tau1, Cds?\n");
scanf("%s",ri_name);
printf("Output File Name?\n");
scanf("%s",out_name);

in_file = (FILE*) NULL;
in_file = fopen ("diodemtk","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named diodemtk for read");
     exit(1);
 }
out_file = (FILE*) NULL;
out_file = fopen (out_name,"w+");

while (fgets (buffer,1024,in_file) != NULL) 
  {
  if (buffer[0]=='!') 
    {
    continue;
    }
  else
    {
    sscanf(buffer,"%lf %lf %lf",&nn,&is,&rd);
    }
}
fclose(in_file);

ig0 = is;
alfg = ((double) 1.602180e-19)/(((double) 1.3800660e-23)*((double) 300.0)*nn);

in_file = (FILE*) NULL;
in_file = fopen ("sdc.iv","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named sdc.iv for read");
     exit(1);
 }
flag = 0; 
while (fgets (buffer,1024,in_file) != NULL)
  {
  if ((buffer[0]=='!') && (flag == 0)) 
    {
    if (string_index (buffer,"DC IV-CURVES") > 0)
	{
	flag = 1;
	continue;
	}
    fprintf(out_file,"%s",buffer);
    if (strncmp (buffer,"!GATE PERIPHERY (um):",21) == 0)
	{
	sscanf (buffer,"!GATE PERIPHERY (um): %lf",&area);
	}
    else if (strncmp (buffer,"!NUMBER OF GATE FINGERS:",24) == 0)
	{
	sscanf (buffer,"!NUMBER OF GATE FINGERS: %lf",&ngf);
	}
    else if (strncmp (buffer,"!UNIT GATE WIDTH (um):",22) == 0)
	{
	sscanf (buffer,"!UNIT GATE WIDTH (um): %lf",&ugw);
	}
    else if (strncmp (buffer,"!Vbr",4) == 0)
	{
	fgets (buffer,1024,in_file);
        fprintf(out_file,"%s",buffer);
	sscanf (buffer,"!%lf %lf",&vbr,&vbr);
	}
    }
 }
fclose(in_file);

f0 = (double) 5.0e6;
gmax = ((double) 1.0e-3)*area/((double) 1.0e3);
in_file = fopen ("cgs_mtk.end","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named cgs_mtk.end for read");
     exit(1);
 }
while (fgets (buffer,200,in_file) != NULL)
   {
   sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
   if (strcmp(param,"CGS0") == 0)
	{
	cgs0 = nom*((double) 1.0e-12);
	}
   else if (strcmp(param,"CGS1") == 0)
	{
	cgs1 = nom*((double) 1.0e-12);
	}
   else if (strcmp(param,"ACGS") == 0)
	{
	acgs = nom;
	}
   else if (strcmp(param,"VCGS") == 0)
	{
	vcgs = nom;
	}
   }
fclose(in_file);

in_file = fopen ("materka.end","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named materka.end for read");
     exit(1);
 }
while (fgets (buffer,200,in_file) != NULL)
   {
   sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
   if (strcmp(param,"IDSS") == 0)
	{
	idss = nom;
	}
   else if (strcmp(param,"VPO") == 0)
	{
	vpo = nom;
	}
   else if (strcmp(param,"GAMA") == 0)
	{
	gama = nom;
	}
   else if (strcmp(param,"E") == 0)
	{
	e = nom;
	}
   else if (strcmp(param,"KE") == 0)
	{
	ke = nom;
	}
   else if (strcmp(param,"SL") == 0)
	{
	sl = nom;
	}
    else if (strcmp(param,"KG") == 0)
	{
	kg = nom;
	}
   else if (strcmp(param,"SS") == 0)
	{
	ss = nom;
	}
  }
fclose(in_file);
in_file = fopen ("pulsed.end","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named pulsed.end for read");
     exit(1);
 }
while (fgets (buffer,200,in_file) != NULL)
   {
   sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
   if (strcmp(param,"IDSS") == 0)
	{
	idss_rf = nom;
	}
   else if (strcmp(param,"VPO") == 0)
	{
	vpo_rf = nom;
	}
   else if (strcmp(param,"GAMA") == 0)
	{
	gama_rf = nom;
	}
   else if (strcmp(param,"E") == 0)
	{
	e_rf = nom;
	}
   else if (strcmp(param,"KE") == 0)
	{
	ke_rf = nom;
	}
   else if (strcmp(param,"SL") == 0)
	{
	sl_rf = nom;
	}
    else if (strcmp(param,"KG") == 0)
	{
	kg_rf = nom;
	}
   else if (strcmp(param,"SS") == 0)
	{
	ss_rf = nom;
	}
  }
fclose(in_file);
in_file = fopen ("s.end","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named s.end for read");
     exit(1);
 }
while (fgets (buffer,200,in_file) != NULL)
       {
	sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
	if (strcmp(param,"RG") == 0)
	    {
	    rg = nom;
	    }
        else if (strcmp(param,"RD") == 0)
	    {
	    rd = nom;
	    }
        else if (strcmp(param,"RS") == 0)
	    {
	    rs = nom;
	    }
        else if (strcmp(param,"LS") == 0)
	    {
	    ls = nom;
	    }
        else if (strcmp(param,"B1") == 0)
	    {
	    lg = nom;
	    }
        else if (strcmp(param,"B2") == 0)
	    {
	    ld = nom;
	    }
        else if (strcmp(param,"C11") == 0)
	    {
	    c11 = nom;
	    }
        else if (strcmp(param,"C22") == 0)
	    {
	    c22 = nom;
	    }
       }
fclose(in_file);
rg = rg*((double) 3.0)*ngf/ugw;

ri_file = fopen (ri_name,"r");
if (ri_file == (FILE*) NULL) {
     printf  ("can't open file named %s for read", ri_name);
     exit(1);
 }
while (fgets (buffer,200,ri_file) != NULL)
   {
   sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
   if (strcmp(param,"RI") == 0)
	{
	ri = nom;
	}
   else if (strcmp(param,"TAU1") == 0)
	{
	tau1 = nom;
	}
   else if (strcmp(param,"CDS") == 0)
	{
	cds = nom;
	}
   }
fclose(ri_file);
k3 = (double) 1.0e-1;

fprintf(out_file,"model   =   1\n");
fprintf(out_file,"!\n");
fprintf(out_file,"area    = %12.4e\n",area);
fprintf(out_file,"idss_dc = %12.4e\n",idss);
fprintf(out_file,"vpo_dc  = %12.4e\n",vpo);
fprintf(out_file,"gama_dc = %12.4e\n",gama);
fprintf(out_file,"ee_dc   = %12.4e\n",e);
fprintf(out_file,"ke_dc   = %12.4e\n",ke);
fprintf(out_file,"sl_dc   = %12.4e\n",sl);
fprintf(out_file,"kg_dc   = %12.4e\n",kg);
fprintf(out_file,"ss_dc   = %12.4e\n",ss);
fprintf(out_file,"idss_rf = %12.4e\n",idss_rf);
fprintf(out_file,"vpo_rf  = %12.4e\n",vpo_rf);
fprintf(out_file,"gama_rf = %12.4e\n",gama_rf);
fprintf(out_file,"ee_rf   = %12.4e\n",e_rf);
fprintf(out_file,"ke_rf   = %12.4e\n",ke_rf);
fprintf(out_file,"sl_rf   = %12.4e\n",sl_rf);
fprintf(out_file,"kg_rf   = %12.4e\n",kg_rf);
fprintf(out_file,"ss_rf   = %12.4e\n",ss_rf);
fprintf(out_file,"f0      = %12.4e\n",f0);
fprintf(out_file,"ig0     = %12.4e\n",ig0);
fprintf(out_file,"alfg    = %12.4e\n",alfg);
fprintf(out_file,"cgs0    = %12.4e\n",cgs0);
fprintf(out_file,"cgs1    = %12.4e\n",cgs1);
fprintf(out_file,"acgs    = %12.4e\n",acgs);
fprintf(out_file,"vcgs    = %12.4e\n",vcgs);
fprintf(out_file,"rg     = %12.4e\n",rg);
fprintf(out_file,"rd     = %12.4e\n",rd);
fprintf(out_file,"rs     = %12.4e\n",rs);
fprintf(out_file,"ri     = %12.4e\n",ri);
fprintf(out_file,"rj     = %12.4e\n",zero);
fprintf(out_file,"lg     = %12.4e\n",lg);
fprintf(out_file,"ld     = %12.4e\n",ld);
fprintf(out_file,"ls     = %12.4e\n",ls);
fprintf(out_file,"c11    = %12.4e\n",c11);
fprintf(out_file,"c22    = %12.4e\n",c22);
fprintf(out_file,"cds    = %12.4e\n",cds);
fprintf(out_file,"tau1   = %12.4e\n",tau1);
fprintf(out_file,"gmax   = %12.4e\n",gmax);
fprintf(out_file,"vbr    = %12.4e\n",vbr);
fprintf(out_file,"k1     = %12.4e\n",zero);
fprintf(out_file,"k2     = %12.4e\n",zero);
fprintf(out_file,"k3     = %12.4e\n",k3);
fprintf(out_file,"!\n");
fclose(out_file);
}  

    
int string_index (string1,string2)
char   string1[];
char   string2[];

{
int    n1;
int    n2;
int    i;

n1 = strlen (string1);
n2 = strlen (string2);

for (i = 0; i <= (n1-n2); ++i)
   {
   if (strncmp (&(string1[i]),string2,n2) == 0)
      {
      return (i);
      }
   }

return (-1);

}















