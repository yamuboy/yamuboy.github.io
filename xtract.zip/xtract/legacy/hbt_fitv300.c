#include <stdio.h>
#include <string.h>
#include <time.h>

void get_the_time ();
int string_index ();

main ()
{
  FILE  *batch_job_file;
  FILE  *tmp_file;
  FILE  *dm2_file;
  FILE  *begin_file;
  FILE  *junk_file;
  int   i,temp_found,d;
  char  buffer[201];
  char  current_time[80];
  char  batch_job_file_name[201];
  char  batch_log_file_name[201];
  char  yfit_tmp_file_name[201];
  char  dmb_file[201];
  char  mod_file[201];
  char  end_file[201];
  char  old_file[201];
  char  system_command[201];
  char  files_to_fit[201];
  char  in_file[201];
  char  out_file[201];
  char  direct_freq[201];
  char  direct_out[201];
  char  direct_start[201];
  char  ta_start[201];
  char  ce_freq[201];
  char  cbc_freq[201];
  char  rbi_freq[201];
  int   s_fit_ranges,flag;
  char  s_freqs[20][201];
  char  s_out_freqs[201];
  char  weights[201];
  char  max_searches[201];
  char  start_file[16];
  char  param[201];
  double min,nom,max,last;
 
  printf ("File names to fit (file name must contain wildcards)?\n");
  gets (files_to_fit);
  
  printf ("BASE PAD FILE?\n");
  gets (in_file);
  
  printf ("COLLECTOR PAD FILE?\n");
  gets (out_file);

  printf("FREQ FOR DIRECT EXTRACTION (START STOP STEP in GHZ)?\n");
  gets (direct_freq);
    
  printf("TA START VALUES (PSEC)?\n");
  gets (ta_start);

  printf("CE MIN & MAX FREQ RANGE (GHZ)?\n");
  gets (ce_freq);

  printf("CBC MIN & MAX FREQ RANGE (GHZ)?\n");
  gets (cbc_freq);

  printf("RBI MIN & MAX FREQ RANGE (GHZ)?\n");
  gets (rbi_freq);
  
  printf ("HOW MANY (START STOP STEP) RANGES FOR FIT?\n");
  gets (buffer);
  sscanf (buffer,"%d",&s_fit_ranges);
  
  for (i = 0; i < s_fit_ranges; ++i)
    {
      printf ("FREQUENCY LIST FOR FIT? (START STOP STEP (GHZ))\n");
      gets (s_freqs[i]);
    }

  printf ("FREQUENCY LIST FOR OUTPUT FILE? (START STOP STEP (GHZ))\n");
  gets (s_out_freqs);

  printf ("FITTING WEIGHTS (S11 S21 S12 S22 K MAG)?\n");
  gets (weights);

  printf ("MAXIMUM NUMBER OF LINE SEARCHES?\n");
  gets (max_searches);

  get_the_time (current_time);
  sprintf (yfit_tmp_file_name,"yfit_tmp_file.%s",current_time);
  sprintf (batch_job_file_name,"batch_job_file.%s",current_time);
  sprintf (batch_log_file_name,"batch_log_file.%s",current_time);

  sprintf (system_command,"rm -f %s",yfit_tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1 %s > %s",files_to_fit,yfit_tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",yfit_tmp_file_name);
  system (system_command);

  tmp_file = (FILE*) NULL;
  batch_job_file = (FILE*) NULL;

  tmp_file = fopen (yfit_tmp_file_name,"r");
  if ( tmp_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s\n",yfit_tmp_file_name);
      exit (1);
    }

  batch_job_file = fopen (batch_job_file_name,"w+");
  if ( batch_job_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s\n",batch_job_file_name);
      exit (1);
    }   
    
  flag = 0;
  strcpy (end_file,"junk");
  while (fgets (dmb_file,200,tmp_file) != NULL)
    {
      strcpy (old_file,end_file);
      sscanf (dmb_file,"%[^.]",mod_file);
      strcat (mod_file,".mod");
      sscanf (dmb_file,"%[^.]",end_file);
      strcat (end_file,".end");
      sscanf (dmb_file,"%[^.]",direct_start);
      strcat (direct_start,".start");
      dmb_file[strlen (dmb_file)-1] = '\0';
      if (flag == 0)
      {
      fprintf (batch_job_file,"~ma052839/PROGRAMS/hbt_startfiles_v1 << input2 >> %s\n",batch_log_file_name);
      fprintf (batch_job_file,"%s\n",dmb_file);
      fprintf (batch_job_file,"%s\n",direct_start);
      fprintf (batch_job_file,"input2\n");
      fprintf (batch_job_file,"~ma052839/PROGRAMS/insert_re << input2 >> %s\n",batch_log_file_name);
      fprintf (batch_job_file,"%s\n",dmb_file);
      fprintf (batch_job_file,"%s\n",direct_start);
      fprintf (batch_job_file,"input2\n");
      flag = 1;
      }  
      else
      {
      fprintf (batch_job_file,"cp %s %s\n",old_file,direct_start);
      fprintf (batch_job_file,"~ma052839/PROGRAMS/insert_re << input2 >> %s\n",batch_log_file_name);
      fprintf (batch_job_file,"%s\n",dmb_file);
      fprintf (batch_job_file,"%s\n",direct_start);
      fprintf (batch_job_file,"input2\n");
      }
      fprintf (batch_job_file,"~ma052839/PROGRAMS/hbtzfit_v1 << input >> %s\n",batch_log_file_name);
      fprintf (batch_job_file,"%s\n",dmb_file);
      fprintf (batch_job_file,"%s\n",in_file);
      fprintf (batch_job_file,"%s\n",out_file);
      fprintf (batch_job_file,"%s\n",direct_freq);
      fprintf (batch_job_file,"%s\n",direct_start);
      fprintf (batch_job_file,"%s\n",direct_start);
      fprintf (batch_job_file,"%s\n",ta_start);
      fprintf (batch_job_file,"%s\n",ce_freq);
      fprintf (batch_job_file,"%s\n",cbc_freq);
      fprintf (batch_job_file,"%s\n",rbi_freq);
      fprintf (batch_job_file,"input\n");

      fprintf (batch_job_file,"~wms/fortran/hbtv500 << input >> %s\n",batch_log_file_name);
      fprintf (batch_job_file,"%s\n",dmb_file);
      fprintf (batch_job_file,"%s\n",mod_file);
      fprintf (batch_job_file,"%s\n",in_file);
      fprintf (batch_job_file,"%s\n",out_file);
      fprintf (batch_job_file,"%d\n",s_fit_ranges);
      for (i = 0; i < s_fit_ranges; ++i)
	{
	  fprintf (batch_job_file,"%s\n",s_freqs[i]);
	}
      fprintf (batch_job_file,"%s\n",s_out_freqs);
      fprintf (batch_job_file,"%s\n",weights);
      fprintf (batch_job_file,"%s\n",max_searches);
      fprintf (batch_job_file,"%s\n",direct_start);
      fprintf (batch_job_file,"%s\n",end_file);
      fprintf (batch_job_file,"input\n");
    }

  fprintf (batch_job_file,"rm -f %s\n",batch_job_file_name);
  
  fclose (batch_job_file);
  fclose (tmp_file);
  
  sprintf (system_command,"rm -f %s",yfit_tmp_file_name);
  system (system_command);
  
  sprintf (system_command,"chmod +x %s",batch_job_file_name);
  system (system_command);
  
  sprintf (system_command,"%s &",batch_job_file_name);
  system (system_command); 

}

/*                                                                   */
/*--- Function string_index -----------------------------------------*/
/*                                                                   */

int string_index (string1,string2)
char   string1[];
char   string2[];

{
int    n1;
int    n2;
int    i;

n1 = strlen (string1);
n2 = strlen (string2);

for (i = 0; i <= (n1-n2); ++i)
   {
   if (strncmp (&(string1[i]),string2,n2) == 0)
      {
      return (i);
      }
   }

return (-1);

}
/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);

return;

}
