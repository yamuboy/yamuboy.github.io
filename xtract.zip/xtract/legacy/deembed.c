#include <stdio.h>
#include <string.h>
#include <time.h>

void get_the_time ();

main ()
{
FILE  *batch_job_file;
FILE  *tmp_file;
int   i;
char  buffer[201];
char  current_time[80];
char  batch_job_file_name[201];
char  batch_log_file_name[201];
char  yfit_tmp_file_name[201];
char  dmb_file[201];
char  mod_file[201];
char  end_file[201];
char  extension[81];
char  system_command[201];
char  files_to_deembed[201];
char  in_file[201];
char  out_file[201];

printf ("File names to deembed?\n");
gets (files_to_deembed);

printf ("Input error box?\n");
gets (in_file);

printf ("Output error box?\n");
gets (out_file);

printf ("Extension for output files?\n");
gets (extension);

get_the_time (current_time);
sprintf (yfit_tmp_file_name,"yfit_tmp_file.%s",current_time);
sprintf (batch_job_file_name,"batch_job_file.%s",current_time);
sprintf (batch_log_file_name,"batch_log_file.%s",current_time);

sprintf (system_command,"rm -f %s",yfit_tmp_file_name);
system (system_command);
sprintf (system_command,"ls -1 %s > %s",files_to_deembed,yfit_tmp_file_name);
system (system_command);

tmp_file = (FILE*) NULL;
batch_job_file = (FILE*) NULL;

tmp_file = fopen (yfit_tmp_file_name,"r");
if ( tmp_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",yfit_tmp_file_name);
   exit (1);
   }

batch_job_file = fopen (batch_job_file_name,"w+");
if ( batch_job_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",batch_job_file_name);
   exit (1);
   }

while (fgets (dmb_file,200,tmp_file) != NULL)
   {
   sscanf (dmb_file,"%[^.]",mod_file);
   strcat (mod_file,extension);
   fprintf (batch_job_file,"~software/xtract/deembed_f << input >> %s\n",batch_log_file_name);
   fprintf (batch_job_file,"%s",dmb_file);
   fprintf (batch_job_file,"%s\n",in_file);
   fprintf (batch_job_file,"%s\n",out_file);
   fprintf (batch_job_file,"%s\n",mod_file);
   fprintf (batch_job_file,"m\n");
   fprintf (batch_job_file,"input\n");
   }

fprintf (batch_job_file,"rm -f %s\n",batch_job_file_name);

fclose (batch_job_file);
fclose (tmp_file);

sprintf (system_command,"rm -f %s",yfit_tmp_file_name);
system (system_command);

sprintf (system_command,"chmod +x %s",batch_job_file_name);
system (system_command);

sprintf (system_command,"%s &",batch_job_file_name);
system (system_command);

}

/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);

return;

}
