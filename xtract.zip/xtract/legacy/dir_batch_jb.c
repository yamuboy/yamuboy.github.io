#include <stdio.h>
#include <string.h>
#include <time.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *lfile, *tmp;
   char dname[256];
   char fit_files[256];
   char dirs[256];
   char string[256];
   char opt_frange[51];
   char opt_wgt[51];
   char tmp_file_name[256];
   char cwd[256];
   double rg;
   char *ext;
   time_t tbuf;
   
   printf ("Directories to batch fit?\n");
   fgets (dirs, 255, stdin);
   dirs[strlen(dirs)-1] = 0;
   
   printf ("Files to fit?\n");
   fgets (fit_files, 255, stdin);

   printf ("Gate resistance?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &rg);
   
   printf ("Optimization freq range in GHz (min max)?\n");
   fgets (opt_frange, 50, stdin);
   
   printf ("Optimization weights (S11 S21 S12 S22 K MAG)?\n");
   fgets (opt_wgt, 50, stdin);
   
   if (!getcwd (cwd, 256))
      {
      printf ("Unable to get working directory.\n");
      return 1;
      }

   /**** create and open the file list ****/

   sprintf (tmp_file_name, "tmp.%d", time(&tbuf));
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);
   sprintf (string, "ls -1d %s > %s", dirs, tmp_file_name);
   system (string);

   lfile = fopen (tmp_file_name,"r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }
   
   /**** loop through the directory list ****/

   while (fgets (dname, 255, lfile))
      {
      dname[strlen(dname)-1] = 0;

      if (chdir (dname))
         {
         printf ("%s: Failed to change directory.\n", dname);
         continue;
         }
            
      tmp = fopen ("yyytmp", "w+");
      if (!tmp)
         {
         printf ("Failed to write to disc.\n");
         return 1;
         }
         
      fprintf (tmp, "%s", fit_files);
      fprintf (tmp, "s.end\n");
      fprintf (tmp, "5 15\n");
      fprintf (tmp, "2 8\n");
      fprintf (tmp, "1 4\n");
      fprintf (tmp, "%s", opt_frange);
      fprintf (tmp, "%s", opt_wgt);
      fprintf (tmp, "50\n");
      fclose (tmp);
      
      sprintf (string, "fet_batch_fit -RG=%.3f < yyytmp", rg);
      system (string);
      
      sprintf (string, "rm -f yyytmp");
      system (string);
      
      if (chdir (cwd))
         {
         printf ("%s: Failed to change directory.\n", cwd);
         return 1;
         }
         
      }   

   fclose (lfile);

   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   return 0;
   }
   
