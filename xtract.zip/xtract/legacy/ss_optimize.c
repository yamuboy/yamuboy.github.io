#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ss_tools.h>
#ifdef WIN32
#include <microsuck.h>
#endif

#define PROG_NAME       "ss_optimize"
#define PROG_VERSION    "1.00 (build 8/25/03)"
#define MAX_FREQS       1000
#define MAX_COMPONENTS  200
#define MAX_PARAMETERS  200

static int run_ss_opt (char *sp_file_name, char *netlist_file_name, char *parameter_file_name,
                char *finish_parameter_file_name, char *model_file_name,
                double *fitting_weights, double minf, double maxf, int max_iter);
static char *string_to_lower (char *string);
static unsigned find_param_index (PARAM_STRUCT *p, char *param, unsigned num_params);

/******************************************************************************************/
/******************************************************************************************/

int main (int argc, char *argv[])
   {
   int batch_mode = 0;
   char string[500];
   char sp_file_name[100];
   char netlist_file_name[100];
   char param_file_name[100];
   char opt_param_file_name[100];
   char sp_out_file_name[100];
   double weights[6];
   double minf,maxf;
   int maxiter;
   int no_sp_out = 0;
   int i,err;

   /* parse the command line */
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-b",2) || !strncmp (argv[i],"-B",2))
         batch_mode = 1;
      else if (!strncmp (argv[i],"-h",2) || !strncmp (argv[i],"-H",2))
         {
         printf ("\n\nUSAGE: %s [options]\n\n",PROG_NAME);
         printf ("   options\n---------------------------------------------------\n");
         printf ("   -b,-B    Run in batch mode (multiple small-signal fits\n");
         printf ("            one after another). A common set of starting\n");
         printf ("            parameters is used, as well as common minimum\n");
         printf ("            and maximum frequencies, maximum optimizer\n");
         printf ("            iterations and fitting weights.\n\n\n");
         return 0;
         }
      else
         printf ("Warning: unrecognized option \'%s\'.\n",argv[i]);
      }

   if (batch_mode)
      {
      printf ("Batch mode is not yet implemented.\n");
      return -1;
      }

   else
      {
      printf ("[S]-Parameter file to fit?\n> ");
      fgets (string,499,stdin);
      sscanf (string,"%99s",sp_file_name);

      printf ("Frequency range for fit in GHz (min max)?\n> ");
      fgets (string,499,stdin);
      if (sscanf (string,"%lf%lf",&minf,&maxf) != 2)
         {
         printf ("Error reading frequencies.\n");
         return -1;
         }
      minf *= 1.0e9;
      maxf *= 1.0e9;

      printf ("Netlist file?\n> ");
      fgets (string,499,stdin);
      sscanf (string,"%99s",netlist_file_name);

      printf ("Parameter file?\n> ");
      fgets (string,499,stdin);
      sscanf (string,"%99s",param_file_name);

      printf ("Fitting weights (S11 S21 S12 S22 K MAG)?\n> ");
      fgets (string,499,stdin);
      if (sscanf (string,"%lf%lf%lf%lf%lf%lf",&weights[0],&weights[1],
         &weights[2],&weights[3],&weights[4],&weights[5]) != 6)
         {
         printf ("Error reading fitting weights.\n");
         return -1;
         }

      printf ("Maximum optimizer line searches?\n> ");
      fgets (string,499,stdin);
      if (sscanf (string,"%d",&maxiter) != 1)
         {
         printf ("Error reading max iterations.\n");
         return -1;
         }

      printf ("File name for storing optimized parameters?\n> ");
      fgets (string,499,stdin);
      sscanf (string,"%99s",opt_param_file_name);

      printf ("File name for storing modeled [S]-parameters (CR for none)?\n> ");
      fgets (string,499,stdin);
      if (string[0] == '\n')
         no_sp_out = 1;
      else
         sscanf (string,"%99s",sp_out_file_name);

      if (no_sp_out)
         err = run_ss_opt (sp_file_name, netlist_file_name, param_file_name,
                opt_param_file_name, NULL, weights, minf, maxf, maxiter);
      else
         err = run_ss_opt (sp_file_name, netlist_file_name, param_file_name,
                opt_param_file_name, sp_out_file_name, weights, minf, maxf, maxiter);

      if (err)
         {
         printf ("Errors occured.\n");
         return -1;
         }
      }

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int run_ss_opt (char *sp_file_name, char *netlist_file_name, char *parameter_file_name,
                char *finish_parameter_file_name, char *model_file_name,
                double *fitting_weights, double minf, double maxf, int max_iter)
   {
   FILE *file;
   S_2PORT sp[MAX_FREQS],*sp_point = NULL;
   int error = 0;
   char type[10];
   char name[10];
   char param[20];
   char string[300];
   char *ptr;
   NETLIST *netlist[MAX_COMPONENTS];
   NETLIST *nlist;
   PARAM_STRUCT  p[MAX_PARAMETERS];
   COMPLEX **yp;
   COMPLEX *sp1;
   POLAR   spp[4];
   unsigned i,n;
   unsigned n1,n2,n3,n4;
   unsigned index,index2;
   unsigned num_s = 0;
   unsigned num_params = 0;
   unsigned line_count = 0;
   unsigned num_comp = 0;
   unsigned ysize;
   double value,value2;

   /* read [S] parameter file */

   if ((n = read_s_from_file (sp_file_name, sp, NULL, MAX_FREQS)) < 1)
      {
      fprintf (stderr,"Error reading [S] file \'%s\'.\n",sp_file_name);
      return -1;
      }

   /* set sp_point and determine the number of points that meet the minf and maxf constraints */

   for (i = 0; i < n; ++i)
      {
      if (sp[i].freq < minf)
         continue;
      else if (sp[i].freq > maxf)
         break;
      else if (!sp_point)
         sp_point = &sp[i];

      if (sp_point)
         ++num_s;
      }
      
   if (num_s < 1)
      {
      fprintf (stderr,"Invalid frequency range.\n");
      return -1;
      }

   /* read in the parameter file */

   file = fopen (parameter_file_name,"r");
   if (!file)
      {
      fprintf (stderr,"Error reading parameter file \'%s\'.\n",parameter_file_name);
      return -1;
      }

   while (fgets (string,299,file))
      {
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (num_params >= MAX_PARAMETERS)
         break;

      if (sscanf (string,"%lf%lf%lf%lf%19s",&p[num_params].min,&p[num_params].nom,
         &p[num_params].max,&p[num_params].tol,p[num_params].name) == 5)
         {
         p[num_params].optimize = TRUE;
         ++num_params;
         }
      }
   fclose (file);

   /* read in and parse the netlist file (this will take some work) */

   file = fopen (netlist_file_name,"r");
   if (!file)
      {
      fprintf (stderr,"Error reading netlist file \'%s\'.\n",netlist_file_name);
      return -1;
      }

   while (fgets (string,299,file))
      {
      ++line_count;

      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (sscanf (string,"%9s%9s",type,name) == 2)
         {
         value = value2 = 0.0;
         index = index2 = STATIC_COMPONENT;

         if (num_comp >= MAX_COMPONENTS)
            break;

         string_to_lower (string);

         if (!strcasecmp (type,"res"))
            {
            if (sscanf (string,"%9s%9s%u%u",type,name,&n1,&n2) != 4)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"val="))
               {
               sscanf (ptr,"val=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"param="))
               {
               sscanf (ptr,"param=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'val=\' or \'param=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_R, value, n1, n2, index, NULL);
            }

         else if (!strcasecmp (type,"ind"))
            {
            if (sscanf (string,"%9s%9s%u%u",type,name,&n1,&n2) != 4)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"val="))
               {
               sscanf (ptr,"val=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"param="))
               {
               sscanf (ptr,"param=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'val=\' or \'param=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_L, value, n1, n2, index, NULL);
            }

         else if (!strcasecmp (type,"cap"))
            {
            if (sscanf (string,"%9s%9s%u%u",type,name,&n1,&n2) != 4)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"val="))
               {
               sscanf (ptr,"val=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"param="))
               {
               sscanf (ptr,"param=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'val=\' or \'param=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_C, value, n1, n2, index, NULL); 
            }

         else if (!strcasecmp (type,"cond"))
            {
            if (sscanf (string,"%9s%9s%u%u",type,name,&n1,&n2) != 4)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"val="))
               {
               sscanf (ptr,"val=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"param="))
               {
               sscanf (ptr,"param=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'val=\' or \'param=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_G, value, n1, n2, index, NULL);            
            }

         else if (!strcasecmp (type,"vccs"))
            {
            if (sscanf (string,"%9s%9s%u%u%u%u",type,name,&n1,&n2,&n3,&n4) != 6)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"gval="))
               {
               sscanf (ptr,"gval=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"gparam="))
               {
               sscanf (ptr,"gparam=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'gval=\' or \'gparam=\' statement.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"tval="))
               {
               sscanf (ptr,"tval=%lf",&value2);
               index2 = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"tparam="))
               {
               sscanf (ptr,"tparam=%19s",param);
               if ((index2 = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'tval=\' or \'tparam=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            if (index2 != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index2].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_VCCS, value, value2, n1, n2, n3, n4, index, index2, NULL);
            }

         else if (!strcasecmp (type,"tcap"))
            {
            if (sscanf (string,"%9s%9s%u%u%u%u",type,name,&n1,&n2,&n3,&n4) != 6)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"val="))
               {
               sscanf (ptr,"val=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"param="))
               {
               sscanf (ptr,"param=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'val=\' or \'param=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_TCAP, value, n1, n2, n3, n4, index, NULL);
            }

         else if (!strcasecmp (type,"srl"))
            {
            if (sscanf (string,"%9s%9s%u%u",type,name,&n1,&n2) != 4)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"rval="))
               {
               sscanf (ptr,"rval=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"rparam="))
               {
               sscanf (ptr,"rparam=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'rval=\' or \'rparam=\' statement.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"lval="))
               {
               sscanf (ptr,"lval=%lf",&value2);
               index2 = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"lparam="))
               {
               sscanf (ptr,"lparam=%19s",param);
               if ((index2 = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'lval=\' or \'lparam=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            if (index2 != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index2].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_SRL, value, value2, n1, n2, index, index2, NULL);
            }

         else if (!strcasecmp (type,"src"))
            {
            if (sscanf (string,"%9s%9s%u%u",type,name,&n1,&n2) != 4)
               {
               fprintf (stderr,"Netlist error (%d): %s : missing node number.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"rval="))
               {
               sscanf (ptr,"rval=%lf",&value);
               index = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"rparam="))
               {
               sscanf (ptr,"rparam=%19s",param);
               if ((index = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'rval=\' or \'rparam=\' statement.\n",line_count,name);
               error = 1;
               }

            if (ptr = strstr (string,"cval="))
               {
               sscanf (ptr,"cval=%lf",&value2);
               index2 = STATIC_COMPONENT;
               }
            else if (ptr = strstr (string,"cparam="))
               {
               sscanf (ptr,"cparam=%19s",param);
               if ((index2 = find_param_index (p,param,num_params)) == STATIC_COMPONENT)
                  {
                  fprintf (stderr,"Netlist error (%d): %s : parameter \'%s\' not found.\n",line_count,name,param);
                  error = 1;
                  }
               }
            else
               {
               fprintf (stderr,"Netlist error (%d): %s : no \'cval=\' or \'cparam=\' statement.\n",line_count,name);
               error = 1;
               }

            if (index != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index].optimize = FALSE;
               }

            if (index2 != STATIC_COMPONENT)
               {
               if (strstr (string,"optimize=false"))
                  p[index2].optimize = FALSE;
               }

            netlist[num_comp] = netlist_component (Netlist_SRC, value, value2, n1, n2, index, index2, NULL);
            }

         else
            {
            fprintf (stderr,"Netlist error (%d): unknown component.\n",line_count);
            error = 1;
            }

         ++num_comp;
         }
      }
   fclose (file);

   if (error)
      return -1;

   /* generate the linked-list netlist */

   nlist = generate_netlist (netlist,num_comp);

      /*
      {
      NETLIST *ptr;

      for (ptr = nlist; ptr; ptr = ptr->next)
         {
         switch (ptr->type)
            {
            case Netlist_VCCS:
               printf ("VCCS %d %d %d %d p1=%d p2=%d\n",
                  ptr->nodes[0],ptr->nodes[1],ptr->nodes[2],ptr->nodes[3],
                  ptr->index[0],ptr->index[1]);
               break;

            case Netlist_TCAP:
               printf ("TCAP %d %d %d %d p=%d\n",
                  ptr->nodes[0],ptr->nodes[1],ptr->nodes[2],ptr->nodes[3],
                  ptr->index[0]);
               break;
               
            case Netlist_R:
               printf ("R %d %d p=%d\n",
                  ptr->nodes[0],ptr->nodes[1],
                  ptr->index[0]);
               break;

            case Netlist_C:
               printf ("C %d %d p=%d\n",
                  ptr->nodes[0],ptr->nodes[1],
                  ptr->index[0]);
               break;

            case Netlist_G:
               printf ("G %d %d p=%d\n",
                  ptr->nodes[0],ptr->nodes[1],
                  ptr->index[0]);
               break;

            case Netlist_L:
               printf ("L %d %d p=%d\n",
                  ptr->nodes[0],ptr->nodes[1],
                  ptr->index[0]);
               break;

            case Netlist_SRL:
               printf ("SRL %d %d p1=%d p2=%d\n",
                  ptr->nodes[0],ptr->nodes[1],
                  ptr->index[0],ptr->index[1]);
               break;

            case Netlist_SRC:
               printf ("SRC %d %d p1=%d p2=%d\n",
                  ptr->nodes[0],ptr->nodes[1],
                  ptr->index[0],ptr->index[1]);
               break;
            }
         }
      }
      */

   /* run the optimization */

   if (small_signal_optimizer (nlist, p, num_params, sp_point, num_s, max_iter, fitting_weights))
      {
      fprintf (stderr,"Small signal optimizer error.\n");
      return -1;
      }

   /* write output files */

   file = fopen (finish_parameter_file_name, "w+");
   for (i = 0; i < num_params; ++i)
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n",p[i].min,p[i].nom,p[i].max,p[i].tol,p[i].name);
   fclose (file);

   if (model_file_name)
      {
      file = fopen (model_file_name,"w+");

      fprintf (file,"! Modeled [S]-parameter file auto-generated by %s %s\n",PROG_NAME,PROG_VERSION);
      fprintf (file,"! Model parameter file: %s\n",finish_parameter_file_name);
      fprintf (file,"! Fitting weights: S11=%.2f S21=%.2f S12=%.2f S22=%.2f K=%.2f MAG=%.2f\n!\n",
         fitting_weights[0],fitting_weights[1],fitting_weights[2],fitting_weights[3],
         fitting_weights[4],fitting_weights[5]);
      fprintf (file,"# HZ S MA R 50\n");

      // create a matrix for the SS simulator
      ysize = determine_y_size (nlist);
      yp = allocate_2d_complex_matrix (ysize);

      for (i = 0; i < num_s; ++i)
         {
         sp1 = small_signal_model (nlist, yp, ysize, sp_point[i].freq);
         CA2PA (sp1, spp, 2, 2);
         fprintf (file,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
            sp_point[i].freq,spp[0].m,spp[0].a,spp[2].m,spp[2].a,
            spp[1].m,spp[1].a,spp[3].m,spp[3].a);
         }

      free_matrix (yp, ysize);
      }

   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

static char *string_to_lower (char *string)
   {
   unsigned i;

   for (i = 0; i < strlen (string); ++i)
      {
      if ((string[i] > (char) 64) && (string[i] < (char) 91))
         string[i] += (char) 32;
      }

   return string;
   }

/********************************************************************************************/
/********************************************************************************************/

static unsigned find_param_index (PARAM_STRUCT *p, char *param, unsigned num_params)
   {
   unsigned i;

   for (i = 0; i < num_params; ++i)
      {
      if (!strcasecmp (param,p[i].name))
         return i;
      }

   return STATIC_COMPONENT;
   }












