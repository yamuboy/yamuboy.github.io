#include <stdio.h>
#include <string.h>
#include <time.h>

void get_the_time ();

main ()
{
FILE  *batch_job_file;
FILE  *tmp_file;
int   i;
int   plot_all;
char  buffer[201];
char  current_time[80];
char  plot_file_name[201];
char  log_file_name[201];
char  tmp_file_name[201];
char  mod_file[201];
char  meas_file[201];
char  extension[81];
char  system_command[201];
char  model_files[201];
char  junk[201];

printf ("Model Files?\n");
scanf ("%s%[^\n]",model_files,junk);

printf ("Measured data extension?\n");
scanf ("%s%[^\n]",extension,junk);

printf ("Measured vs. modelled data to plot? (default 1)\n");
printf ("    1. Plot all\n    2. Prompt\n");
fflush (stdin);
scanf ("%s",junk);

if (junk[0] == 0)
   {
   plot_all = 1;
   }
else
   {
   sscanf (junk,"%d",&plot_all);
   }

get_the_time (current_time);
sprintf (plot_file_name,"plot_file.%s",current_time);
sprintf (log_file_name,"log_file.%s",current_time);
sprintf (tmp_file_name,"tmp_file.%s",current_time);

sprintf (system_command,"rm -f %s",tmp_file_name);
system (system_command);
sprintf (system_command,"ls -1 %s > %s",model_files,tmp_file_name);
system (system_command);

tmp_file = (FILE*) NULL;
tmp_file = fopen (tmp_file_name,"r");
if (tmp_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",tmp_file_name);
   exit (1);
   }

batch_job_file = fopen (plot_file_name,"w+");

fprintf (batch_job_file,"bplotv302 << input >> %s\n",log_file_name);

while (fgets (mod_file,200,tmp_file) != NULL)
   {
   mod_file[strlen (mod_file)-1] = '\0';
   if (plot_all == 1)
      {
      sscanf (mod_file,"%[^.]",meas_file);
      strcat (meas_file,extension);
      fprintf (batch_job_file,"%s\n",mod_file);
      fprintf (batch_job_file,"%s\n",meas_file);
      }
   else
      {
      printf ("Plot %s?\n",mod_file);
      fflush (stdin);
      scanf ("%s",junk);
      if ((junk[0] == 'y') || (junk[0] == 'Y') || (junk[0] == 0))
         {
         sscanf (mod_file,"%[^.]",meas_file);
         strcat (meas_file,extension);
         fprintf (batch_job_file,"%s\n",mod_file);
         fprintf (batch_job_file,"%s\n",meas_file);
         }
      }
   }
fclose (tmp_file);

fprintf (batch_job_file,"end\n");
fprintf (batch_job_file,"input\n");
fprintf (batch_job_file,"rm -f %s\n",log_file_name);
fprintf (batch_job_file,"rm -f %s\n",plot_file_name);

fclose (batch_job_file);

sprintf (system_command,"rm -f %s",tmp_file_name);
system (system_command);

sprintf (system_command,"chmod +x %s",plot_file_name);
system (system_command);

sprintf (system_command,"%s",plot_file_name);
system (system_command);

return (0);
}

/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);

return;

}
