#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include "jplot_types.h"
#include "jplot_bitmap"

#define window_name  "jPlot Plotting Utility - X-Windows"
#define icon_name    "jPlot"

// GLOBAL VARIABLES
static Display      *display = NULL;
static Window       window;
static GC           gc;
static XFontStruct  *font_info = NULL;
static Atom         KILL_WIN;
static int          window_height;
static double       page_height,page_width;
static double       scale;
static int          resolution;
static int          current_lt,current_lw;
static int          current_font,current_ps,current_style;
static int          current_color;
static XPoint       *points = NULL;
static int          num_Xpoints = 0;
const static int    default_font = FNT_HELVETICA;

// internal function prototypes
static unsigned long get_color_pixel (int);
static void set_line_properties (int, int, int);

/******************************************************************************/
/******************************************************************************/

BOOL x_open_device (DRIVER_INFO *dData)
{
   XEvent            report;
   XSizeHints        size_hints;
   XGCValues         values;
   Pixmap            icon_pixmap;
   XWindowAttributes attribs;
   unsigned long     vmask;
   unsigned int      width,height;
   unsigned int      display_width,display_height;
   double            display_widthIN,display_heightIN;
   int               screen;

   page_height = dData->page_height_in;
   page_width  = dData->page_width_in; 

   // open the display
   if ((display = XOpenDisplay (NULL)) == NULL)
   {
      fprintf (stderr,"X server refused connection.\n");
      return FALSE;
   }
   screen = DefaultScreen (display);

   // set display properties and determine window size
   display_width = DisplayWidth (display,screen);
   display_height = DisplayHeight (display,screen);
   display_widthIN  = DisplayWidthMM (display,screen)/25.4;
   display_heightIN = DisplayHeightMM (display,screen)/25.4;
   resolution = (int) (((double) display_height)/display_heightIN);
   if (resolution < 90)
      resolution = 75;
   else
      resolution = 100;
   width = (unsigned int) (((double) display_width)*0.8);
   height = (unsigned int) (((double) width)*page_height/page_width);

   // create the main window
   window = XCreateSimpleWindow (display,RootWindow (display,screen),0,0,width,height,1,BlackPixel (display,screen),WhitePixel (display,screen));

   // set the window properties
   icon_pixmap = XCreateBitmapFromData (display,window,jplot_bitmap_bits,jplot_bitmap_width,jplot_bitmap_height);
   size_hints.flags = PAspect;
   size_hints.min_aspect.x = 110;
   size_hints.min_aspect.y = 85;
   size_hints.max_aspect.x = 110;
   size_hints.max_aspect.y = 85;
   XSetStandardProperties (display,window,window_name,icon_name,icon_pixmap,NULL,0,&size_hints);

   // create a GC
   vmask = (GCFunction | GCForeground | GCBackground | GCLineWidth | GCLineStyle | GCCapStyle | GCJoinStyle);
   values.function   = GXcopy;
   values.foreground = BlackPixel (display,screen);
   values.background = WhitePixel (display,screen);
   values.line_width = 1;
   values.line_style = LineSolid;
   values.cap_style  = CapButt;
   values.join_style = JoinRound;
   gc = XCreateGC (display,window,vmask,&values);

   // set the current line properties (based on the GC we created)
   current_lt = LT_SOLID;
   current_lw = 1;
   current_color = CLR_BLACK;

   // force window manager to use a ClientMessage to request a window kill
   KILL_WIN = XInternAtom (display,"WM_DELETE_WINDOW",True);
   XSetWMProtocols (display,window,&KILL_WIN,1);

   // select XEvent notifications
   XSelectInput (display,window,ExposureMask | KeyPressMask | StructureNotifyMask);

   // map the window
   XMapRaised (display,window);

   while (1)
   {
      XNextEvent (display,&report);
      if (report.type == Expose)
      {
         XGetWindowAttributes (display,window,&attribs);
         scale = ((double) attribs.width)/page_width;
         if (scale > (((double) attribs.height)/page_height))
            scale = ((double) attribs.height)/page_height;
         window_height = attribs.height;
         return TRUE;
      }
   }
}

/******************************************************************************/
/******************************************************************************/

void x_close_device (void)
{
   if (font_info)
      XUnloadFont (display,font_info->fid);

   font_info = NULL;

   if (points)
      free ((void *) points);

   points = NULL;

   if (display)
   {
      XFreeGC (display,gc);
      XDestroyWindow (display,window);
      XCloseDisplay (display);
      display = NULL;
   }
}

/******************************************************************************/
/******************************************************************************/

int x_draw_handler (BOOL (*draw_ptr)())
{
   XEvent            report;
   XWindowAttributes attribs;

   if (!(*draw_ptr)())
      return FALSE;

   while (1)
   {
      XNextEvent (display,&report);

      switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XClearWindow (display,window);
         if (!(*draw_ptr)())
            return FALSE;
         break;

      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         XGetWindowAttributes (display,window,&attribs);
         scale = ((double) attribs.width)/page_width;
         if (scale > (((double) attribs.height)/page_height))
            scale = ((double) attribs.height)/page_height;
         window_height = attribs.height;
         break;

         // user has X'ed the window
      case ClientMessage:
         if (report.xclient.data.l[0] == KILL_WIN)
         {
            x_close_device ();
            return DRIVER_EXIT;
         }
         break;

      case KeyPress:
         XClearWindow (display,window);
         return TRUE;

      default:
         break;
      }
   }
}

/******************************************************************************/
/******************************************************************************/

BOOL x_draw_polyline (double *xdata, double *ydata, int n, int ltype, int lwidth, int lcolor)
{
   int  i;

   set_line_properties (ltype,lwidth,lcolor);

   if ((!points) || (n > num_Xpoints))
   {
      if (points)
         free ((void *) points);

      points = (XPoint *) malloc (sizeof (XPoint)*n);
      if (!points)
         return FALSE;

      num_Xpoints = n;
   }

   for (i = 0; i < n; ++i)
   {
      points[i].x = (int) (xdata[i]*scale);
      points[i].y = window_height - ((int) (ydata[i]*scale));
   }

   XDrawLines (display,window,gc,points,n,CoordModeOrigin);

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

BOOL x_draw_line (double x1, double y1, double x2, double y2, int ltype, int lwidth, int lcolor)
{
   set_line_properties (ltype,lwidth,lcolor);

   XDrawLine (display,window,gc,(int) (x1*scale),window_height - ((int) (y1*scale)),
      (int) (x2*scale),window_height - ((int) (y2*scale)));

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

BOOL x_draw_arc (double x, double y, double rad, double astart, double aend, int ltype, int lwidth, int lcolor)
{
   double tmp;

   set_line_properties (ltype,lwidth,lcolor);

   while (astart < 0.0)
      astart += 360.0;
   while (astart >= 360.0)
      astart -= 360.0;

   while (aend < 0.0)
      aend += 360.0;
   while (aend > 360.0)
      aend -= 360.0;

   if (aend < astart)
   {
      tmp = aend;
      aend = astart;
      astart = tmp;
   }

   XDrawArc (display,window,gc,(int) ((x-rad)*scale),window_height - ((int) ((y+rad)*scale)),
      (int) (2.0*rad*scale),(int) (2.0*rad*scale),(int) (astart*64.0), (int) (aend*64.0));

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

BOOL x_draw_circle (double x, double y, double rad, int ltype, int lwidth, int lcolor)
{
   return x_draw_arc (x,y,rad,0.0,360.0,ltype,lwidth,lcolor);
}

/******************************************************************************/
/******************************************************************************/
static BOOL x_load_font( int font, int ps, int style )
{
   static const char * helv_aliases[] = { "helvetica", "arial", "charter", "clearlyu", "luxi sans", NULL };
   static const char * courier_aliases[] = { "courier", NULL };
   static const char * times_aliases[] = { "times", "serif", "roman", "utopia", "luxi serif", NULL };
   const char ** aliases;
   char * weight;
   char slant;
   char font_name[128];
   int i;

   switch (font)
   {
   case FNT_TIMES:
      aliases = times_aliases;
      break;
   case FNT_COURIER:
      aliases = courier_aliases;
      break;
   default:
   case FNT_HELVETICA:
      aliases = helv_aliases;
      break;
   }

   if (style & TS_BOLDFACE)
      weight = "bold";
   else
      weight = "medium";

   if (style & TS_ITALIC)
      slant = 'i';
   else
      slant = 'r';

   // unload the old font
   if(font_info) XUnloadFont(display,font_info->fid);
   font_info = NULL;

   // load the new font
   for( i=0; aliases[i]; ++i ) {
      sprintf(font_name,"-*-%s-%s-%c-normal--*-%d-%d-%d-*-*-*-*",aliases[i],weight,slant,ps*10,resolution,resolution);
      font_info = XLoadQueryFont(display,font_name);
      if( font_info ) break;
   }

   if( !font_info ) {
      if( font == default_font ) return FALSE;
      // call recursively with the default font
      else return x_load_font( default_font, ps, style );
   }

   // set the font
   XSetFont (display,gc,font_info->fid);
   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

BOOL x_draw_text (char *string, double x, double y, int font, int psize, double angle, int justify, int color, int style)
{
   XGCValues       values;
   GC              bitmap_gc;
   Pixmap          bitmap;
   XImage          *image;
   unsigned long   vmask;
   double          r,theta;
   int             point_size,length,width,height;
   int             x_offset,y_offset,x_prime,y_prime;
   int             x1,y1,x_pix,y_pix;

   point_size = (int) (((double) psize)*scale/((double) resolution));

   if ((point_size != current_ps) || (font != current_font) || (style != current_style) || (font_info == NULL))
   {
      if( !x_load_font( font, point_size, style ) ) return FALSE; 
      current_font = font;
      current_ps = point_size;
      current_style = style;
   }

   if (color != current_color)
   {
      XSetForeground (display,gc,get_color_pixel (color));
      current_color = color;
   }

   length = strlen (string);
   width  = XTextWidth (font_info,string,length);
   height = font_info->ascent + font_info->descent;

   x1 = (int) (x*scale);
   y1 = window_height - ((int) (y*scale));

   if (fabs (angle) < 0.1)
   {
      switch (justify)
      {
      case RIGHT_JUSTIFY:
         XDrawString (display,window,gc,x1-width,y1,string,length);
         break;
      case CENTER_JUSTIFY:
         XDrawString (display,window,gc,x1-(width/2),y1,string,length);
         break;
      case LEFT_JUSTIFY:
      default:
         XDrawString (display,window,gc,x1,y1,string,length);
         break;
      }

      return TRUE;
   }

   bitmap = XCreatePixmap (display,window,(unsigned int) width,(unsigned int) height,1);

   vmask = (GCFunction | GCForeground | GCBackground);
   values.function   = GXcopy;
   values.foreground = 0L;
   values.background = 1L;
   bitmap_gc = XCreateGC (display,bitmap,vmask,&values);

   XFillRectangle (display,bitmap,bitmap_gc,0,0,(unsigned int) width,(unsigned int) height);
   XSetForeground (display,bitmap_gc,1L);
   XSetBackground (display,bitmap_gc,0L);

   XSetFont (display,bitmap_gc,font_info->fid);

   XDrawString (display,bitmap,bitmap_gc,0,font_info->ascent,string,length);

   image = XGetImage (display,bitmap,0,0,(unsigned int) width,(unsigned int) height,AllPlanes,XYPixmap);

   switch (justify)
   {
   case RIGHT_JUSTIFY:
      x_offset = width;
      break;
   case CENTER_JUSTIFY:
      x_offset = width/2;
      break;
   case LEFT_JUSTIFY:
   default:
      x_offset = 0;
      break;
   }

   y_offset = font_info->ascent;

   for (y_pix = 0; y_pix < height; ++y_pix)
   {
      for (x_pix = 0; x_pix < width; ++x_pix)
      {
         if (XGetPixel (image,x_pix,y_pix))
         {
            r = sqrt (((double) (x_pix-x_offset))*((double) (x_pix-x_offset)) + ((double) (y_pix-y_offset))*((double) (y_pix-y_offset)));
            if ((x_pix == x_offset) && (y_pix == y_offset))
               theta = 0.0;
            else
               theta = atan2 ((double) (y_pix-y_offset),(double) (x_pix-x_offset));
            x_prime = ((int) (r*cos (theta - angle*DEG2RAD) + 0.1)) + x1;
            y_prime = ((int) (r*sin (theta - angle*DEG2RAD) + 0.1)) + y1;
            XDrawPoint (display,window,gc,x_prime,y_prime);
         }
      }
   }

   XFreePixmap (display,bitmap);
   XFreeGC (display,bitmap_gc);
   XDestroyImage (image);

   return TRUE;
}

/******************************************************************************/
/******************************************************************************/

static unsigned long get_color_pixel (int color)
{
   Colormap  cmap = DefaultColormap (display,DefaultScreen (display));
   XColor    color_def,dummy;

   switch (color)
   {
   case CLR_RED:
      XAllocNamedColor (display,cmap,"red",&color_def,&dummy);
      break;
   case CLR_GREEN:
      XAllocNamedColor (display,cmap,"green",&color_def,&dummy);
      break;
   case CLR_BLUE:
      XAllocNamedColor (display,cmap,"blue",&color_def,&dummy);
      break;
   case CLR_YELLOW:
      XAllocNamedColor (display,cmap,"yellow",&color_def,&dummy);
      break;
   case CLR_LIGHTGREY:
      XAllocNamedColor (display,cmap,"light grey",&color_def,&dummy);
      break;
   case CLR_GREY:
      XAllocNamedColor (display,cmap,"grey",&color_def,&dummy);
      break;
   case CLR_DARKGREY:
      XAllocNamedColor (display,cmap,"dark grey",&color_def,&dummy);
      break;
   case CLR_ORANGE:
      XAllocNamedColor (display,cmap,"orange",&color_def,&dummy);
      break;
   case CLR_LIGHTBLUE:
      XAllocNamedColor (display,cmap,"light blue",&color_def,&dummy);
      break;
   case CLR_DARKGREEN:
      XAllocNamedColor (display,cmap,"dark green",&color_def,&dummy);
      break;
   case CLR_BROWN:
      XAllocNamedColor (display,cmap,"brown",&color_def,&dummy);
      break;
   case CLR_PURPLE:
      XAllocNamedColor (display,cmap,"purple",&color_def,&dummy);
      break;
   case CLR_MAROON:
      XAllocNamedColor (display,cmap,"maroon",&color_def,&dummy);
      break;
   default:
   case CLR_BLACK:
      color_def.pixel = BlackPixel (display,DefaultScreen (display));
      break;
   }

   return color_def.pixel;
}

/******************************************************************************/
/******************************************************************************/

static void set_line_properties (int ltype, int lwidth, int lcolor)
{
   XGCValues      values;
   unsigned long  vmask = 0L;
   char           dash_list[6];

   if (ltype != current_lt)
   {
      vmask |= GCLineStyle;
      switch (ltype)
      {
      case LT_DOTTED:
         values.line_style = LineOnOffDash;
         dash_list[0] = 2;
         dash_list[1] = 2;
         XSetDashes (display,gc,0,dash_list,2);
         break;
      case LT_DASHED:
         values.line_style = LineOnOffDash;
         dash_list[0] = 6;
         dash_list[1] = 2;
         XSetDashes (display,gc,0,dash_list,2);
         break;
      case LT_DOTDASH:
         values.line_style = LineOnOffDash;
         dash_list[0] = 6;
         dash_list[1] = 2;
         dash_list[2] = 2;
         dash_list[3] = 2;
         XSetDashes (display,gc,0,dash_list,4);
         break;
      case LT_DOTDOTDASH:
         values.line_style = LineOnOffDash;
         dash_list[0] = 6;
         dash_list[1] = 2;
         dash_list[2] = 2;
         dash_list[3] = 2;
         dash_list[4] = 2;
         dash_list[5] = 2;
         XSetDashes (display,gc,0,dash_list,6);
         break;
      default:
      case LT_SOLID:
         values.line_style = LineSolid;
         break;
      }
      current_lt = ltype;
   }

   if (lwidth != current_lw)
   {
      vmask |= GCLineWidth;
      values.line_width = lwidth;
      current_lw = lwidth;
   }

   if (lcolor != current_color)
   {
      vmask |= GCForeground;
      values.foreground = get_color_pixel (lcolor);
      current_color = lcolor;
   }

   if (vmask)
      XChangeGC (display,gc,vmask,&values);
}

