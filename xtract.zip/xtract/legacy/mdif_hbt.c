#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *index ();
void bubble_sort ();
int record_compare ();

#define MAX_PARAMETERS   (56)
#define MAX_MODELS     (1000)

struct fet_model
{
char   device[20];
double p[MAX_PARAMETERS];
};

static struct fet_model model[MAX_MODELS];
static struct fet_model *model_pointer[MAX_MODELS];

main ()
{
double rbe,rce,ree,b1,b2,le;
double factor[MAX_PARAMETERS];
char   label[MAX_PARAMETERS][13];
time_t time_location;
FILE  *file_list;
FILE  *sum_file;
FILE  *dmb_file;
FILE  *end_file;
char  dmb_name[100];
char  end_name[100];
char  ivend_name[100];
char  mdif_name[100];
char  buffer[2500];
char  string[80];
char  *pointer;
char  *string_pointer;
char  input_line[80];
char  file_names[80];
char  new_line;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];
int   order[MAX_PARAMETERS];
int   i,j,k,n,m;

strcpy (label[0],"    KMOD    ");
strcpy (label[1],"    KVER    ");
strcpy (label[2],"    Cjc     ");
strcpy (label[3],"    Vjc     ");
strcpy (label[4],"    Mjc     ");
strcpy (label[5],"   Cof1     ");
strcpy (label[6],"    Cje     ");
strcpy (label[7],"    Vje     ");
strcpy (label[8],"    Mje     ");
strcpy (label[9],"   Cof2     ");
strcpy (label[10],"     Tf     ");
strcpy (label[11],"    Ibif    ");
strcpy (label[12],"    Nbf     ");
strcpy (label[13],"    Isf     ");
strcpy (label[14],"     Nf     ");
strcpy (label[15],"    Ibir    ");
strcpy (label[16],"    Nbr     ");
strcpy (label[17],"    Isr     ");
strcpy (label[18],"     Nr     ");
strcpy (label[19],"    Ikf     ");
strcpy (label[20],"    Isc     ");
strcpy (label[21],"     Nc     ");
strcpy (label[22],"    Ise     ");
strcpy (label[23],"     Ne     ");
strcpy (label[24],"    Ikr     ");
strcpy (label[25],"    Tamb    ");
strcpy (label[26],"    Var     ");
strcpy (label[27],"    Vaf     ");
strcpy (label[28],"     Tr     ");
strcpy (label[29],"     Fc     ");
strcpy (label[30],"    Xtf     ");
strcpy (label[31],"    Vtf     ");
strcpy (label[32],"    Itf     ");
strcpy (label[33],"     Lb     ");
strcpy (label[34],"     Lc     ");
strcpy (label[35],"     Le     ");
strcpy (label[36],"    Cxbc    ");
strcpy (label[37],"    Cxbe    ");
strcpy (label[38],"    Cxce    ");
strcpy (label[39],"     Rb     ");
strcpy (label[40],"     Rc     ");
strcpy (label[41],"     Re     ");

for (i=0;i<42;++i)
{
factor[i]  = (double) 1.0e+00;
}
factor[2] = (double) 1.0e-12;
factor[5] = (double) 1.0e-12;
factor[6] = (double) 1.0e-12;
factor[9] = (double) 1.0e-12;

printf ("\n");
printf ("Parasitic & Capacitance end file?\n");
scanf ("%s",end_name);

printf ("IV end file?\n");
scanf ("%s",ivend_name);

printf ("Model filename (must have .mdif extension)?\n");
scanf ("%s",mdif_name);
printf ("\n");
printf ("\n");

sprintf (buffer,"cat %s %s > tmp.end",end_name,ivend_name);
system (buffer);

time (&time_location);
string_pointer = asctime (localtime (&time_location));
sscanf (string_pointer+8,"%s",s_day);
sscanf (string_pointer+4,"%s",s_month);
sscanf (string_pointer+20,"%s",s_year);
sscanf (string_pointer+11,"%s",s_time);
sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

sum_file = fopen (mdif_name,"w+");

fprintf (sum_file,"!\n");
fprintf (sum_file,"! HBT EEBJT2 MODEL PROGRAM VERSION 1.00 %s\n",string);
fprintf (sum_file,"!\n");
fprintf (sum_file,"BEGIN BDTA\n");
fprintf (sum_file,"%% ");

n = 0;

end_file = fopen ("tmp.end","r");
fgets (buffer,1024,end_file);
sscanf (buffer,"%*f %lf",&rbe);
fgets (buffer,1024,end_file);
sscanf (buffer,"%*f %lf",&b1);
fgets (buffer,1024,end_file);
sscanf (buffer,"%*f %lf",&rce);
fgets (buffer,1024,end_file);
sscanf (buffer,"%*f %lf",&b2);
fgets (buffer,1024,end_file);
sscanf (buffer,"%*f %lf",&ree);
fgets (buffer,1024,end_file);
sscanf (buffer,"%*f %lf",&le);
   for (i = 2; i < 26; ++i)
      {
      fgets (buffer,1024,end_file);
      sscanf (buffer,"%*f %lf",&model[n].p[i]);
      model[n].p[i] *= factor[i];
      if (i==25)
      {
      model[n].p[i] = model[n].p[i]-((double) 273.15);
      }
      }
   for (i = 26; i < 42; ++i)
      {
      model[n].p[i] = ((double) 0.0);
      if (i==29)
        {
        model[n].p[i] = ((double) 0.9);
        }
      }
   model[n].p[0] = ((int) 402);
   model[n].p[1] = ((int) 1100);
   fclose (end_file);

  for (i = 0; i < 2; ++i)
   {
   fprintf (sum_file," %s\t",label[i]);
   }
  fprintf (sum_file,"\n");
  for (i = 0; i < 2; ++i)
   {
   fprintf (sum_file," %8.0f",model[j].p[i]);
   }
  fprintf (sum_file,"\n");

  for (k = 0; k < 6; ++k)
  {
    fprintf (sum_file,"%% ");
    for (i = (2+k*6); i < (2+(k+1)*6); ++i)
     {
     fprintf (sum_file," %s\t",label[i]);
     }
    fprintf (sum_file,"\n");
    for (i = (2+k*6); i < (2+(k+1)*6); ++i)
     {
     fprintf (sum_file," %15.4e",model[j].p[i]);
     }
    fprintf (sum_file,"\n");
  }
  
  fprintf (sum_file,"%% ");
  for (i = 38; i < 42; ++i)
   {
   fprintf (sum_file," %s\t",label[i]);
   }
  fprintf (sum_file,"\n");
  for (i = 38; i < 42; ++i)
   {
   fprintf (sum_file," %15.4e",model[j].p[i]);
   }
  fprintf (sum_file,"\n");
  fprintf (sum_file,"END BDTA");

fclose (sum_file);

system ("rm -f tmp.end");

}

char *index (buffer,string)
char buffer[];
char string[];
{
char *pointer;
int  length;

length = strlen (string);
pointer = buffer;

while (strncmp (pointer,string,length) != 0)
   {
   pointer = strchr (pointer+1,string[0]);
   if (pointer == NULL)
      {
      return (pointer);
      /*
      printf (" can't find string %s\n",string);
      exit (1);
      */
      }
   }

return (pointer);

}
 
void bubble_sort (array,n,order,m)
struct fet_model *array[];
int   n;
int   order[];
int   m;
{
char  *temp;
int   i;
int   j;

for (i = 0; i < n - 1; ++i)
   {
   for (j = i + 1; j < n; ++j)
      {
      if (record_compare (array[i],array[j],order,m) >= 0)
         {
         temp     = array[i];
         array[i] = array[j];
         array[j] = temp;
         }
      }
   }

return;

}
 
int record_compare (record1,record2,order,n)
struct fet_model *record1;
struct fet_model *record2;
int   order[];
int   n;
{
int   value;
int   i;

i = -1;

do
   {
   ++i;
   switch (abs (order[i]))
      {
      case 1:
         if (strcmp (record1->device,record2->device) > 0)
            {
            value = 1;
            }
         else if (strcmp (record1->device,record2->device) < 0)
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      case 3:
         if (record1->p[1] > (record2->p[1]+((double) 0.05)))
            {
            value = 1;
            }
         else if (record1->p[1] < (record2->p[1]-((double) 0.05)))
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      case 6:
         if (record1->p[4] > (record2->p[4]+((double) 0.002)))
            {
            value = 1;
            }
         else if (record1->p[4] < (record2->p[4]-((double) 0.002)))
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      default:
         if (record1->p[abs(order[i])-1] > record2->p[abs(order[i])-1])
            {
            value = 1;
            }
         else if (record1->p[abs(order[i])-1] < record2->p[abs(order[i])-1])
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      }
   if (order[i] < 0)
      {
      value = -value;
      }
   }
while (i < n - 1 && value == 0);

return (value);

}
