#include <stdio.h>
#include <string.h>
#include <math.h>


main ()
{
double vds,ids,vgs,igs;
FILE  *in_file;
FILE  *out_file;
FILE  *out_file2;
char  in_name[201];
char  header[50][201];
char  buffer[201];
int   header_done;
int   i,n,j,num1,num2;
double vbr0[100][4];
double vbr2[100][4];

printf ("vbr file name?\n");
scanf ("%200s",in_name);
n=0;
header_done = 0;
in_file  = (FILE*) NULL;
out_file = (FILE*) NULL;
out_file2 = (FILE*) NULL;

in_file = fopen (in_name,"r");
if ( in_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",in_name);
   }
out_file = fopen ("vbr_vds0.citi","w+");
out_file2 = fopen ("vbr_vds2.citi","w+");
if ( out_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file vbr_vds0.citi\n");
   fclose (in_file);
   }
if ( out_file2 == (FILE*) NULL)
   {
   printf ("** error ** cannot open file vbr_vds2.citi\n");
   fclose (in_file);
   }

i = 0;
j = 0;
while (fgets (buffer,200,in_file) != NULL)
   {
   if ((header_done != 1) && (buffer[0] == '!'))
      {
      strcpy (header[n],buffer);
      ++n;
      }
   else 
   {
	  header_done = 1;
      sscanf (buffer,"%lf%lf%lf%lf",&vds,&ids,&vgs,&igs);


	 if (vds == (double) 0.0)
		  {
			  vbr0[i][0] = vds;
			  vbr0[i][1] = ids;
			  vbr0[i][2] = vgs;
			  vbr0[i][3] = igs;
			  i=i+1;
	 }
		  else if (vds == (double) 2.0)
		  {
			  vbr2[j][0] = vds;
			  vbr2[j][1] = ids;
			  vbr2[j][2] = vgs;
			  vbr2[j][3] = igs;
			  j=j+1;
		  }
   }
}
num1 = i;
num2 = j;
for (i = 0; i < n; ++i)
    {
     fprintf (out_file,"# %s",header[i]);
     fprintf (out_file2,"# %s",header[i]);
     }
fprintf(out_file,"CITIFILE A.01.00\n");
fprintf(out_file,"NAME MEAS_DATA\n");
fprintf(out_file,"VAR X MAG %d\n",num1);
fprintf(out_file2,"CITIFILE A.01.00\n");
fprintf(out_file2,"NAME MEAS_DATA\n");
fprintf(out_file2,"VAR X MAG %d\n",num2);


fprintf(out_file,"DATA VDS MA\n");
fprintf(out_file,"DATA IDS MA\n");
fprintf(out_file,"DATA VGS MA\n");
fprintf(out_file,"DATA IGS MA\n");

fprintf(out_file2,"DATA VDS MA\n");
fprintf(out_file2,"DATA IDS MA\n");
fprintf(out_file2,"DATA VGS MA\n");
fprintf(out_file2,"DATA IGS MA\n");

fprintf(out_file,"VAR_LIST_BEGIN\n");
for (i=0;i<num1;i++) {
fprintf(out_file, "%+.4e\n", vbr0[i][2]);
}
fprintf(out_file,"VAR_LIST_END\n");

for (j=0;j<4;j++) {
  fprintf(out_file,"BEGIN\n");
  for (i=0;i<num1;i++) {
    fprintf(out_file, "%+.4e\n", vbr0[i][j]);
    }
  fprintf(out_file,"END\n");
}

fprintf(out_file2,"VAR_LIST_BEGIN\n");
for (i=0;i<num2;i++) {
fprintf(out_file2, "%+.4e\n", vbr2[i][2]);
}
fprintf(out_file2,"VAR_LIST_END\n");

for (j=0;j<4;j++) {
  fprintf(out_file2,"BEGIN\n");
  for (i=0;i<num2;i++) {
    fprintf(out_file2, "%+.4e\n", vbr2[i][j]);
    }
  fprintf(out_file2,"END\n");
}
fclose(out_file);
fclose(out_file2);
}

