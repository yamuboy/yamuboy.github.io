#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize.h"
#include "jmbplot.h"

#define TRUE          (1)
#define FALSE         (0)
#define OK            (0)
#define ERR           (-1)

#define DC_IV_CURVES   (0)
#define AC_IV_CURVES   (1)
#define VDS0_CAP       (2)
#define CAPACITANCE    (3)
#define BREAKDOWN      (4)

#define PI            ((double) 3.14159265359)
#define NUM_PARAMS    (39)
#define MAX_IV_PTS    (1500)
#define MAX_BIAS_PTS  (500)

/* -------- FUNCTION PROTOTYPES ---------- */

int get_starting_values ();
int fit_parasitics ();
int get_iv_data ();
int plot_data ();
void write_output_files ();

double *eehemt_opt_function ();
double ids_function ();
double vds0_cap_function ();
double *cgs_cgd_function ();
double *ac_iv_function ();
double breakdown_function ();

void eehemt_ids_gm_gds ();
void eehemt_capacitance ();
double eehemt_breakdown ();

double bubble_average ();
int diode_fit ();
int a_x_b ();
void find_min_max ();
double tanh_protect ();
void tanh_integ_protect ();

/* ---------- GLOBAL VARIABLES ----------- */

OPT_STRUCT     opt = {0,0,NULL,0L,0,1.0e-6,eehemt_opt_function};
PARAM_STRUCT   params[NUM_PARAMS];
double         fixed_params[30];
double         vgsiv[MAX_IV_PTS];
double         vdsiv[MAX_IV_PTS];
double         igsiv[MAX_IV_PTS];
double         idsiv[MAX_IV_PTS];
double         mvds[MAX_BIAS_PTS];
double         mvgs[MAX_BIAS_PTS];
double         mcgs[MAX_BIAS_PTS];
double         mcgd[MAX_BIAS_PTS];
double         mgm[MAX_BIAS_PTS];
double         mgds[MAX_BIAS_PTS];
double         maximum_vds;
double         area;
double         ugw;
double         Vds0;
int            ngf;
int            num_iv_pts;
int            num_ac_iv_pts;
int            mode_flag;


/****************************************************************************/
/*                                  MAIN                                    */
/****************************************************************************/

main (argc,argv)
int    argc;
char   *argv[];

{
int         i;
int         n,do_fits;
int         ids_fit,gm_fit,cgs_fit,vbr_fit;
double      weights[5];
double      eff_gl,eff_dl;
double      temp;
char        string[1024];
char        model_summary_file[100];
char        start_file[100];
char        end_file[100];
char        model_file[100];
char        yfit_file[100];
char        iv_curve_file[100];
char        fwd_iv_file[100];
char        vbr_iv_file[100];
char        junk[100];

fflush (stdin);
printf ("Number of gate fingers?\n");
scanf ("%d",&ngf);
printf ("Unit gate width? (um)\n");
scanf ("%lf",&ugw);
printf ("Effective Gate and Drain Lengths? (um)\n");
scanf ("%lf %lf",&eff_gl,&eff_dl);
printf ("Maximum drain voltage for IV fit?\n");
scanf ("%lf",&maximum_vds);
printf ("Drain voltage for Vds0?\n");
scanf ("%lf",&Vds0);
printf ("Y-fit start file name?\n");
scanf ("%s",yfit_file);
printf ("Model summary file name?\n");
scanf ("%s",model_summary_file);
printf ("DC IV data file name?\n");
scanf ("%s",iv_curve_file);
printf ("Forward IV data file name?\n");
scanf ("%s",fwd_iv_file);
printf ("Breakdown IV data file name?\n");
scanf ("%s",vbr_iv_file);
printf ("Start parameters file name?\n");
scanf ("%s",start_file);
printf ("Finish parameters file name?\n");
scanf ("%s",end_file);
printf ("Output model file name?\n");
scanf ("%s",model_file);
printf ("Maximum number of line searches?\n");
scanf ("%d",&opt.max_iterations);
printf ("Optimization fits to perform?\n");
printf ("    1. All (default)\n    2. Ids only\n    3. Gm/Gds only\n    4. Capacitance only\n    5. Breakdown only\n\n"
);
scanf ("%s",junk);
if (sscanf (junk,"%d",&do_fits) != 1)
   {
   do_fits = 1;
   }

switch (do_fits)
   {
   case 0:
      printf ("error reading fits to perform.\n");
      return (-1);
   case 2:
      ids_fit = 1;
      gm_fit = 0;
      cgs_fit = 0;
      vbr_fit = 0;
      break;
   case 3:
      ids_fit = 0;
      gm_fit = 1;
      cgs_fit = 0;
      vbr_fit = 0;
      break;
   case 4:
      ids_fit = 0;
      gm_fit = 0;
      cgs_fit = 1;
      vbr_fit = 0;
      break;
   case 5:
      ids_fit = 0;
      gm_fit = 0;
      cgs_fit = 0;
      vbr_fit = 1;
      break;
   default:
      ids_fit = 1;
      gm_fit = 1;
      cgs_fit = 1;
      vbr_fit = 1;
      break;
   }

area = ugw*((double) ngf);

/* read in and scale the starting values */
if (get_starting_values (start_file) < 0)
   {
   printf ("ERROR in get_starting_values().\n");
   return (-1);
   }

/**************** fit parasitcs ************************/
if (fit_parasitics (yfit_file,model_summary_file,eff_gl,eff_dl) < 0)
   {
   printf ("ERROR in fit_parasitics().\n");
   return (-1);
   }

/***************** DC IV curve fit *********************/
printf ("Fitting DC IV curves.....\n");
num_iv_pts = get_iv_data (iv_curve_file,0);
if (num_iv_pts < 1)
   {
   printf ("ERROR in get_iv_data().\n");
   return (-1);
   }

for (i = 0; i < 15; ++i)
   {
   params[i].optimize = TRUE;
   }

opt.num_of_params = NUM_PARAMS;
opt.num_of_criteria = 1;
opt.weights = &weights[0];
opt.flags = OPT_VERBOSE;
weights[0] = (double) 1.0;
mode_flag = DC_IV_CURVES;
opt.err_fraction = (double) 1.0e-9;

if (ids_fit)
   {
   if (cg_optimize (opt,params,string) < 0)
      {
      printf ("ERROR in cg_optimize():\n");
      printf ("%s\n",string);
      return (-1);
      }
   }
printf ("Done.\n");

/**************** AC parameter fit ***********************/

/* copy dc to ac starting values */
if (ids_fit)
   {
   params[15].min = params[0].min; /* vto -> vtoac */
   params[15].nom = params[0].nom;
   params[15].max = params[0].max;
   params[16].min = params[1].min; /* gamma ->  gammaac */
   params[16].nom = params[1].nom;
   params[16].max = params[1].max;
   params[17].min = params[4].min; /* gmmax ->  gmmaxac */
   params[17].nom = params[4].nom;
   params[17].max = params[4].max;
   params[18].min = params[6].min; /* kapa ->  kapaac */
   params[18].nom = params[6].nom;
   params[18].max = params[6].max;
   params[19].min = params[7].min; /* peff ->  peffac */
   params[19].nom = params[7].nom;
   params[19].max = params[7].max;
   params[20].min = params[8].min; /* vtso ->  vtsoac */
   params[20].nom = params[8].nom;
   params[20].max = params[8].max;
   params[21].min = params[13].min; /* deltgm ->  deltgmac */
   params[21].nom = params[13].nom;
   params[21].max = params[13].max;
   }

/* call the optimizer to optimize AC IV curves (gm, gds, and dispersion current) */
printf ("Fitting AC IV parameters .....\n");
opt.num_of_criteria = 2;
weights[0] = (double) 1.0;
weights[1] = (double) 50.0;
mode_flag = AC_IV_CURVES;

for (i = 0; i < NUM_PARAMS; ++i)
   {
   params[i].optimize = FALSE;
   }
for (i = 15; i < 25; ++i)
   {
   params[i].optimize = TRUE;
   }

if (gm_fit)
   {
   if (cg_optimize (opt,params,string) < 0)
      {
      printf ("ERROR in cg_optimize():\n");
      printf ("%s\n",string);
      return (-1);
      }
   }
printf ("Done.\n");

/******************* C11 fit @ Vdso **********************/

/* call the optimizer to optimize capacitance curves */
printf ("Fitting C11 @ Vds0.....\n");
opt.num_of_criteria = 1;
weights[0] = (double) 1.0;
mode_flag = VDS0_CAP;
opt.err_fraction = (double) 1.0e-8;

for (i = 0; i < NUM_PARAMS; ++i)
   {
   params[i].optimize = FALSE;
   }

params[25].optimize = TRUE;  /* c11o */
params[26].optimize = FALSE; /* c11th */
params[27].optimize = TRUE;  /* vinfl */
params[28].optimize = TRUE;  /* deltgs */

params[26].nom = params[26].max;
for (i = 0; i < num_ac_iv_pts; ++i)
   {
   if (mvds[i] == Vds0)
      {
      temp = mcgs[i]+mcgd[i];
      if (temp < params[26].nom)
         {
         params[26].nom = temp;
         }
      }
   }

// store deltds and set it to 0.01 for C11 optimization
//temp = params[29].nom;
//params[29].nom = (double) 0.01;

if (cgs_fit)
   {
   if (cg_optimize (opt,params,string) < 0)
      {
      printf ("ERROR in cg_optimize():\n");
      printf ("%s\n",string);
      return (-1); 
      }
   }
printf ("Done.\n");

params[25].optimize = FALSE;  /* c11o */
params[26].optimize = FALSE;  /* c11th */
params[27].optimize = FALSE;  /* vinfl */
params[28].optimize = FALSE;  /* deltgs */

// reset deltds
//params[29].nom = temp;

/****************** C11 & C12 fit vs. Vds ********************/

printf ("Fitting C11 and C12 vs. Vds.....\n");
mode_flag = CAPACITANCE;
opt.num_of_criteria = 2;
weights[0] = (double) 1.0;
weights[1] = (double) 1.0;
opt.err_fraction = (double) 1.0e-8;

params[29].optimize = TRUE;  /* deltds */
params[30].optimize = TRUE;  /* lambda */
params[31].optimize = TRUE;  /* c12sat */
params[32].optimize = TRUE;  /* cgdsat */

if (cgs_fit)
   {
   if (cg_optimize (opt,params,string) < 0)
      {
      printf ("ERROR in cg_optimize():\n");
      printf ("%s\n",string);
      return (-1); 
      }
   }
printf ("Done.\n");

/****************** diode fit ****************************/
printf ("Fitting Forward IV curves.....\n");
n = get_iv_data (fwd_iv_file,1);
if (n < 3)
   {
   printf ("ERROR in get_iv_data() during diode fit.\n");
   return (-1);
   }
else
   {
   diode_fit (vgsiv,igsiv,n,area,&fixed_params[16],&fixed_params[17],&fixed_params[18]);
   fixed_params[16] = fixed_params[16]*((double) 0.5);
   fixed_params[18] = fixed_params[18];
   }
printf ("Done.\n");
   
/***************** breakdown fit **************************/
printf ("Fitting Reverse Breakdown curves.....\n");
num_iv_pts = get_iv_data (vbr_iv_file,2);
if (num_iv_pts < 1)
   {
   printf ("ERROR in get_iv_data() during breakdown fit.\n");
   return (-1);
   }

opt.num_of_criteria = 1;
weights[0] = (double) 1.0;
mode_flag = BREAKDOWN;

for (i = 0; i < 36; ++i)
   {
   params[i].optimize = FALSE;
   }
params[33].optimize = TRUE;
params[34].optimize = TRUE;
params[35].optimize = TRUE;
params[36].optimize = TRUE;

if (vbr_fit)
   {
   if (cg_optimize (opt,params,string) < 0)
      {
      printf ("ERROR in cg_optimize():\n");
      printf ("%s\n",string);
      return (-1);
      }
   }

printf ("Done.\n");

/******************* plot the data *************************/
plot_data (iv_curve_file,vbr_iv_file,fwd_iv_file);

/************** write the output files *********************/
write_output_files (end_file,model_file,iv_curve_file);

return (0);
}


/*                                                                          */
/* ----------- get_starting_values() -------------------------------------- */
/*                                                                          */

int get_starting_values (fname)
char   *fname;

{
FILE        *file1;
char        string[201];
double      inv_area;
int         i;
static int p[] = {4,7,13,17,19,21,22,25,26,31,32,33,36,37};

inv_area = ((double) 1.0)/area;

file1 = fopen (fname,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("ERROR: Unable to open starting values file - %s\n",fname);
   return (-1);
   }

for (i = 0; i < NUM_PARAMS; ++i)
   {
   if (fgets (string,200,file1) == NULL)
      {
      printf ("ERROR: Incomplete starting values file - %s\n",fname);
      fclose (file1);
      return (-1);
      }

   sscanf (string,"%lf %lf %lf %lf %s",&params[i].min,&params[i].nom,&params[i].max,
                                       &params[i].tol,params[i].name);
   strcpy (params[i].units,"");
   params[i].optimize = FALSE;

   if (params[i].min > params[i].max)
      {
      printf ("ERROR in parameter \"%s\": MIN is greater than MAX.\n",params[i].name);
      fclose (file1);
      return (-1);
      }
   else if ((params[i].nom < params[i].min) || (params[i].nom > params[i].max))
      {
      printf ("ERROR in parameter \"%s\": NOMINAL is outside MIN/MAX range.\n",params[i].name);
      fclose (file1);
      return (-1);
      }
   else if (params[i].tol < (double) 0.0)
      {
      params[i].tol = fabs (params[i].tol);
      }
   }
fclose (file1);

/* scale starting values */
for (i = 0; i < 14; ++i)
   {
   params[p[i]].min *= area;
   params[p[i]].max *= area;
   params[p[i]].nom *= area;
   params[p[i]].tol *= area;
   }
params[23].min *= inv_area; /* kdb */
params[23].max *= inv_area;
params[23].nom *= inv_area;
params[23].tol *= inv_area;
   
return (0);
}


/*                                                                          */
/* ----------- fit_parasitics() ------------------------------------------- */
/*                                                                          */

int fit_parasitics (yfit_file,mod_sum_file,eff_gl,eff_dl)
char    *yfit_file;
char    *mod_sum_file;
double  eff_gl;
double  eff_dl;

{
FILE     *file1;
int      i,j;
int      found;
char     string[301];
char     pname[80];
double   igs[MAX_BIAS_PTS];
double   ids[MAX_BIAS_PTS];
double   Ri[MAX_BIAS_PTS];
double   tau[MAX_BIAS_PTS];
double   cds[MAX_BIAS_PTS];
double   temp1[MAX_BIAS_PTS];
double   temp2[MAX_BIAS_PTS];
double   temp3[MAX_BIAS_PTS];
double   Rd,Rg,Rs,Ls;
double   value,lpd,lpg,ri1;
double   cpg,cpd,c11,c22;

file1 = fopen (mod_sum_file,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("Unable to open model summary file - %s\n",mod_sum_file);
   return (-1);
   }

i = 0;
while (fgets (string,300,file1) != NULL)
   {
   if (sscanf (&string[28],"%lf %lf %lf %lf %*f %*f %*f %*f %*f %lf %lf %lf %lf %*f %lf %lf %lf",
               &mvds[i],&ids[i],&mvgs[i],&igs[i],&Ri[i],&mgm[i],&tau[i],&mgds[i],
               &mcgs[i],&cds[i],&mcgd[i]) == 11)
      {
      if ((igs[i]*((double) 1.0e-3)/area) < (double) 5.0e-8)
         {
         igs[i] *= ((double) 1.0e-3);
         ids[i] *= ((double) 1.0e-3);
         mgm[i] *= ((double) 1.0e-3);
         mgds[i] *= ((double) 1.0e-3);
         mcgs[i] *= ((double) 1.0e-12);
         mcgd[i] *= ((double) 1.0e-12);
         cds[i] *= ((double) 1.0e-12);
         tau[i] *= ((double) 1.0e-12);
         ++i;
         }
      }
   }
fclose (file1);
num_ac_iv_pts = i;

file1 = fopen (yfit_file,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("Unable to open yfit file - %s\n",yfit_file);
   return (-1);
   }

found = 0;
while (fgets (string,300,file1) != NULL)
   {
   sscanf (string,"%*f %lf %*f %*f %s",&value,pname);
   if (!strcmp (pname,"C1"))
      {
      cpg = value;
      ++found;
      }
   else if (!strcmp (pname,"C2"))
      {
      cpd = value;
      ++found;
      }
   else if (!strcmp (pname,"C11"))
      {
      c11 = value;
      ++found;
      }
   else if (!strcmp (pname,"C22"))
      {
      c22 = value;
      ++found;
      }
   else if (!strcmp (pname,"B1"))
      {
      lpg = value;
      ++found;
      }
   else if (!strcmp (pname,"B2"))
      {
      lpd = value;
      ++found;
      }
   else if (!strcmp (pname,"RG"))
      {
      Rg = value;
      ++found;
      }
   else if (!strcmp (pname,"RD"))
      {
      Rd = value;
      ++found;
      }
   else if (!strcmp (pname,"RS"))
      {
      Rs = value;
      ++found;
      }
   else if (!strcmp (pname,"LS"))
      {
      Ls = value;
      ++found;
      }

   }
fclose (file1);

if (found != 10)
   {
   printf ("Yfit file problem.  Incorrect number of parameters found.\n");
   return (-1);
   }

fixed_params[0] = Rg;
fixed_params[1] = Rd;
fixed_params[2] = Rs;

j = 0;
for (i = 0; i < num_ac_iv_pts; ++i)
   {
   if (mvds[i] == Vds0)
      {
      temp1[j] = Ri[i];
      temp2[j] = cds[i];
      temp3[j] = tau[i];
      ++j;
      }
   }
if (j < 5)
   {
   printf ("Not enough bias pts found matching Vds0 = %.2f volts\n",Vds0);
   return (-1);
   }

fixed_params[3] = bubble_average (temp1,j)*((double) 0.5);
fixed_params[4] = fixed_params[3];
fixed_params[5] = bubble_average (temp2,j);
fixed_params[6] = bubble_average (temp3,j);

// don't really need to do this any more
params[37].nom = fixed_params[5];
params[38].nom = fixed_params[6];
params[37].min = params[37].nom*((double) 0.2);
params[38].min = params[38].nom*((double) 0.2);
params[37].max = params[37].nom*((double) 5.0);
params[38].max = params[38].nom*((double) 5.0);

fixed_params[7] = Ls;
fixed_params[8] = cpg;
fixed_params[9] = cpd;
fixed_params[10] = c11;
fixed_params[11] = c22;
fixed_params[12] = lpg;
fixed_params[13] = lpd;
fixed_params[14] = (double) 1.0;
fixed_params[15] = (double) 1.0;

fixed_params[19] = ((double) 1.0e-6); /* dummy values for Rg, Rd and Rs */
fixed_params[20] = ((double) 1.0e-6);
fixed_params[21] = ((double) 1.0e-6);

return (0);
}


/*                                                                        */
/* ----------- get_iv_data() -------------------------------------------- */
/*                                                                        */

int get_iv_data (fname,mode)
char  *fname;
int   mode;

{
FILE     *file1;
char     string[201];
int      i = 0;
double   rs,rd,rg,ri;

file1 = fopen (fname,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("Unable to open IV file - %s\n",fname);
   return (-1);
   }

rg = fixed_params[0];
rd = fixed_params[1];
rs = fixed_params[2];
ri = fixed_params[3]*((double) 2.0);

while (fgets (string,200,file1) != NULL)
   {
   if (sscanf (string,"%lf %lf %lf %lf",&vdsiv[i],&idsiv[i],&vgsiv[i],&igsiv[i]) == 4)
      {
      switch (mode)
         {
         case 0:   /* DC IV file */
            if ((igsiv[i]/area) >= (double) 5.0e-8)
               {
               continue;
               }
            else if (vdsiv[i] > maximum_vds)
               {
               continue;
               }
            else
               {
               vdsiv[i] = vdsiv[i]-rd*idsiv[i]-rs*(igsiv[i]+idsiv[i]);
               vgsiv[i] = vgsiv[i]-(rg+ri)*igsiv[i]-rs*(igsiv[i]+idsiv[i]);
               ++i;
               }
            break;

         case 1:   /* forward IV file */
            if (vdsiv[i] != (double) 0.0)
               {
               continue;
               }
            else
               {
               ++i;
               }
            break;

         case 2:   /* breakdown IV file */
            if (vdsiv[i] != (double) 0.0)
               {
               continue;
               }
            vgsiv[i] = (vgsiv[i]-igsiv[i]*(rg+ri))-(vdsiv[i]-idsiv[i]*rd);
            ++i;
            break;
         
         default:
            break;
         }
      }
   }
fclose (file1);

return (i);
}


/*                                                                        */
/* ----------- plot_data() ---------------------------------------------- */
/*                                                                        */

int plot_data (iv_file,vbr_file,fwd_iv_file)
char   *iv_file;
char   *vbr_file;
char   *fwd_iv_file;

{
double          p_list[NUM_PARAMS];
JMBPLOT_ITEM    pitem[2];
JMBPLOT_DATA    pdata1[2];
JMBPLOT_DATA    pdata2[2];
JMBPLOT_SCALE   scales1;
JMBPLOT_SCALE   scales2;
int             i,j,k;
int             n;
float           xdata[MAX_IV_PTS];
float           y1data[MAX_IV_PTS];
float           y2data[MAX_IV_PTS];
float           y3data[MAX_IV_PTS];
float           y4data[MAX_IV_PTS];
float           min,max,temp;
double          per_mm;
double          gm,gds,ids;
double          Is,vdiode,ndiode,rdiode;
double          cgs,cgd,cgst,cgdt;
char            string[1024];

pitem[0].type = singleY;
pitem[0].font = 0;
pitem[0].scaling = manualX | manualY1 | manualY2;
pitem[0].scales = &scales1;
pitem[0].data = pdata1;
pitem[0].num_data_items = 2;
pitem[0].flags = DRAW_XGRID | DRAW_YGRID;
pitem[1].type = singleY;
pitem[1].font = 0;
pitem[1].scaling = manualX | manualY1 | manualY2;
pitem[1].scales = &scales2;
pitem[1].data = pdata2;
pitem[1].num_data_items = 2;
pitem[1].flags = DRAW_XGRID | DRAW_YGRID;

pdata1[0].x1_data = xdata;
pdata1[1].x1_data = xdata;
pdata2[0].x1_data = xdata;
pdata2[1].x1_data = xdata;

pdata1[0].y1_data = y1data;
pdata1[1].y1_data = y2data;
pdata2[0].y1_data = y3data;
pdata2[1].y1_data = y4data;

pdata1[0].curve1_linetype = LT_DASHED;
pdata1[0].curve1_linewidth = 1;
pdata1[1].curve1_linetype = LT_SOLID;
pdata1[1].curve1_linewidth = 1;

pdata2[0].curve1_linetype = LT_DASHED;
pdata2[0].curve1_linewidth = 1;
pdata2[1].curve1_linetype = LT_SOLID;
pdata2[1].curve1_linewidth = 1;

for (i = 0; i < NUM_PARAMS; ++i)
   {
   p_list[i] = params[i].nom;
   }

per_mm = ((double) 1.0e3)/area;

if (jmbplot_open_device (X_WINDOWS,"",string) < 0)
   {
   printf ("%s\n",string);
   return (-1);
   }

/************ plot IV curves ****************/

n = get_iv_data (iv_file,0);

for (i = 0; i < n; ++i)
   {
   xdata[i] = (float) vdsiv[i];
   y1data[i] = (float) (idsiv[i]*per_mm*((double) 1.0e3));
   eehemt_ids_gm_gds (p_list,vgsiv[i],vdsiv[i],&ids,&gm,&gds,0);
   y2data[i] = (float) (per_mm*((double) 1.0e3)*ids);
   }

pdata1[0].curve1_pts = n;
pdata1[1].curve1_pts = n;

find_min_max (xdata,n,&min,&max);

scales1.xmin = scales2.xmin = 0.0;

if (max <= 4.0)
   {
   scales1.xmax = scales2.xmax = 4.0;
   scales1.xstep = scales2.xstep = 1.0;
   scales1.xtick = scales2.xtick = 5;
   }
else if (max <= 5.0)
   {
   scales1.xmax = scales2.xmax = 5.0;
   scales1.xstep = scales2.xstep = 1.0;
   scales1.xtick = scales2.xtick = 5;
   }
else if (max <= 6.0)
   {
   scales1.xmax = scales2.xmax = 6.0;
   scales1.xstep = scales2.xstep = 1.0;
   scales1.xtick = scales2.xtick = 5;
   }
else if (max <= 8.0)
   {
   scales1.xmax = scales2.xmax = 8.0;
   scales1.xstep = scales2.xstep = 2.0;
   scales1.xtick = scales2.xtick = 4;
   }
else if (max <= 10.0)
   {
   scales1.xmax = scales2.xmax = 10.0;
   scales1.xstep = scales2.xstep = 2.0;
   scales1.xtick = scales2.xtick = 4;
   }
else   
   {
   scales1.xmax = scales2.xmax = 12.0;
   scales1.xstep = scales2.xstep = 2.0;
   scales1.xtick = scales2.xtick = 4;
   }

find_min_max (y1data,n,&min,&max);
scales1.y1min = 0.0;

if (max <= 100.0)
   {
   scales1.y1max = 100.0;
   scales1.y1step = 20.0;
   scales1.y1tick = 5;
   }
else if (max <= 150.0)
   {
   scales1.y1max = 150.0;
   scales1.y1step = 30.0;
   scales1.y1tick = 6;
   }
else if (max <= 200.0)
   {
   scales1.y1max = 200.0;
   scales1.y1step = 40.0;
   scales1.y1tick = 4;
   }
else if (max <= 300.0)
   {
   scales1.y1max = 300.0;
   scales1.y1step = 50.0;
   scales1.y1tick = 5;
   }
else if (max <= 500.0)
   {
   scales1.y1max = 500.0;
   scales1.y1step = 100.0;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 800.0;
   scales1.y1step = 200.0;
   scales1.y1tick = 4;
   }

sprintf (pitem[0].x_label,"Vds (volts)");
sprintf (pitem[1].x_label,"Vds (volts)");
sprintf (pitem[0].y1_label,"Ids (mA/mm)");
sprintf (pitem[0].title,"Ids vs. Vds");

if (jmbplot_draw_plot (pitem,1,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }   

/************ plot C11 vs. Vgs *******************/

for (i = 0,j = 0; i < num_ac_iv_pts; ++i)
   {
   if (mvds[i] == Vds0)
      {
      xdata[j] = (float) mvgs[i];
      y1data[j] = (float) (mcgs[i]+mcgd[i])*per_mm*((double) 1.0e12);
      eehemt_capacitance (p_list,mvgs[i],mvds[i],&cgs,&cgst,&cgd,&cgdt);
      y2data[j] = (float) (cgs+cgd+cgst+cgdt)*per_mm*((double) 1.0e12);
      ++j;
      }
   }

pdata1[0].curve1_pts = j;
pdata1[1].curve1_pts = j;

// sort the data
for (i = 0; i < j-1; ++i)
   {
   for (k = i+1; k < j; ++k)
      {
      if (xdata[k] < xdata[i])
         {
         temp = xdata[i];
         xdata[i] = xdata[k];
         xdata[k] = temp;
         temp = y1data[i];
         y1data[i] = y1data[k];
         y1data[k] = temp;
         temp = y2data[i];
         y2data[i] = y2data[k];
         y2data[k] = temp;
         }
      }
   }

// find the scales
find_min_max (xdata,j,&min,&max);
if (max < 1.0)
   scales1.xmax = 1.0;
else
   scales1.xmax = 1.5;

if (min > 0.0)
   {
   scales1.xmin = 0.0;
   scales1.xstep = 0.2;
   scales1.xtick = 4;
   }
else if (min > -1.0)
   {
   scales1.xmin = -1.0;
   scales1.xstep = 0.5;
   scales1.xtick = 5;
   }
else if (min > -2.0)
   {
   scales1.xmin = -2.0;
   scales1.xstep = 0.5;
   scales1.xtick = 5;
   }
else
   {
   scales1.xmin = -3.0;
   scales1.xstep = 0.5;
   scales1.xtick = 5;
   }

find_min_max (y1data,j,&min,&max);
scales1.y1min = 0.0;

if (max <= 1.0)
   {
   scales1.y1max = 1.0;
   scales1.y1step = 0.2;
   scales1.y1tick = 4;
   }
else if (max <= 2.0)
   {
   scales1.y1max = 2.0;
   scales1.y1step = 0.5;
   scales1.y1tick = 5;
   }
else if (max <= 4.0)
   {
   scales1.y1max = 4.0;
   scales1.y1step = 1.0;
   scales1.y1tick = 5;
   }
else if (max <= 6.0)
   {
   scales1.y1max = 6.0;
   scales1.y1step = 1.0;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 8.0;
   scales1.y1step = 2.0;
   scales1.y1tick = 4;
   }

sprintf (pitem[0].x_label,"Vgs (volts)");
sprintf (pitem[0].y1_label,"C11 (pF/mm)");
sprintf (pitem[0].title,"C11 vs. Vgs @ Vds = VDS0");

if (jmbplot_draw_plot (pitem,1,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }  

/************ plot C11 and C12 vs. Vds *******************/

for (i = 0; i < num_ac_iv_pts; ++i)
   {
   xdata[i] = (float) mvds[i];
   y1data[i] = (float) (mcgs[i]+mcgd[i])*per_mm*((double) 1.0e12);
   y3data[i] = (float) (mcgd[i])*per_mm*((double) 1.0e12);
   eehemt_capacitance (p_list,mvgs[i],mvds[i],&cgs,&cgst,&cgd,&cgdt);
   y2data[i] = (float) (cgs+cgd+cgst+cgdt)*per_mm*((double) 1.0e12);
   y4data[i] = (float) (cgd+cgst)*per_mm*((double) 1.0e12);
   }

pdata1[0].curve1_pts = num_ac_iv_pts;
pdata1[1].curve1_pts = num_ac_iv_pts;
pdata2[0].curve1_pts = num_ac_iv_pts;
pdata2[1].curve1_pts = num_ac_iv_pts;

scales1.xmin = scales2.xmin;
scales1.xmax = scales2.xmax;
scales1.xstep = scales2.xstep;
scales1.xtick = scales2.xtick;

// find scales
find_min_max (y1data,num_ac_iv_pts,&min,&max);
scales1.y1min = 0.0;

if (max <= 1.0)
   {
   scales1.y1max = 1.0;
   scales1.y1step = 0.2;
   scales1.y1tick = 4;
   }
else if (max <= 2.0)
   {
   scales1.y1max = 2.0;
   scales1.y1step = 0.5;
   scales1.y1tick = 5;
   }
else if (max <= 4.0)
   {
   scales1.y1max = 4.0;
   scales1.y1step = 1.0;
   scales1.y1tick = 5;
   }
else if (max <= 6.0)
   {
   scales1.y1max = 6.0;
   scales1.y1step = 1.0;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 8.0;
   scales1.y1step = 2.0;
   scales1.y1tick = 4;
   }

find_min_max (y3data,num_ac_iv_pts,&min,&max);
scales2.y1min = 0.0;

if (max <= 0.1)
   {
   scales2.y1max = 0.1;
   scales2.y1step = 0.025;
   scales2.y1tick = 5;
   }
else if (max <= 0.2)
   {
   scales2.y1max = 0.2;
   scales2.y1step = 0.05;
   scales2.y1tick = 5;
   }
else if (max <= 0.5)
   {
   scales2.y1max = 0.5;
   scales2.y1step = 0.1;
   scales2.y1tick = 5;
   }
else if (max <= 1.0)
   {
   scales2.y1max = 1.0;
   scales2.y1step = 0.2;
   scales2.y1tick = 4;
   }
else if (max <= 2.0) 
   {
   scales2.y1max = 2.0;
   scales2.y1step = 0.5;
   scales2.y1tick = 5;
   }
else
   {
   scales2.y1max = 4.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }

sprintf (pitem[0].x_label,"Vds (volts)");
sprintf (pitem[0].y1_label,"C11 (pF/mm)");
sprintf (pitem[0].title,"C11 vs. Vds");
sprintf (pitem[1].x_label,"Vds (volts)");
sprintf (pitem[1].y1_label,"C12 (pF/mm)");
sprintf (pitem[1].title,"C12 vs. Vds");

if (jmbplot_draw_plot (pitem,2,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }  

/************ plot gm and gds ****************/

for (i = 0; i < num_ac_iv_pts; ++i)
   {
   y1data[i] = (float) (mgm[i]*per_mm*((double) 1.0e3));
   y3data[i] = (float) (mgds[i]*per_mm*((double) 1.0e3));
   eehemt_ids_gm_gds (p_list,mvgs[i],mvds[i],&ids,&gm,&gds,1);
   y2data[i] = (float) (gm*per_mm*((double) 1.0e3));
   y4data[i] = (float) (gds*per_mm*((double) 1.0e3));
   }

find_min_max (y1data,num_ac_iv_pts,&min,&max);
scales1.y1min = 0.0;

if (max <= 50.0)
   {
   scales1.y1max = 50.0;
   scales1.y1step = 10.0;
   scales1.y1tick = 5;
   }
else if (max <= 100.0)
   {
   scales1.y1max = 100.0;
   scales1.y1step = 20.0;
   scales1.y1tick = 5;
   }
else if (max <= 200.0)
   {
   scales1.y1max = 200.0;
   scales1.y1step = 40.0;
   scales1.y1tick = 4;
   }
else if (max <= 300.0)
   {
   scales1.y1max = 300.0;
   scales1.y1step = 50.0;
   scales1.y1tick = 5;
   }
else if (max <= 500.0)
   {
   scales1.y1max = 500.0;
   scales1.y1step = 100.0;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 800.0;
   scales1.y1step = 200.0;
   scales1.y1tick = 4;
   }

find_min_max (y3data,num_ac_iv_pts,&min,&max);
scales2.y1min = 0.0;

if (max <= 0.1)
   {
   scales2.y1max = 0.1;
   scales2.y1step = 0.025;
   scales2.y1tick = 5;
   }
else if (max <= 0.5)
   {
   scales2.y1max = 0.5;
   scales2.y1step = 0.1;
   scales2.y1tick = 5;
   }
else if (max <= 1.0)
   {
   scales2.y1max = 1.0;
   scales2.y1step = 0.2;
   scales2.y1tick = 4;
   }
else if (max <= 3.0)
   {
   scales2.y1max = 3.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }
else if (max <= 5.0) 
   {
   scales2.y1max = 5.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }
else if (max <= 10.0) 
   {
   scales2.y1max = 10.0;
   scales2.y1step = 2.0;
   scales2.y1tick = 4;
   }
else if (max <= 30.0) 
   {
   scales2.y1max = 30.0;
   scales2.y1step = 5.0;
   scales2.y1tick = 5;
   }
else
   {
   scales2.y1max = 50.0;
   scales2.y1step = 10.0;
   scales2.y1tick = 5;
   }

sprintf (pitem[0].y1_label,"Gm (mS/mm)");
sprintf (pitem[0].title,"Gm vs. Vds");
sprintf (pitem[1].y1_label,"Gds (mS/mm)");
sprintf (pitem[1].title,"Gds vs. Vds");

if (jmbplot_draw_plot (pitem,2,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }  

/************ plot diode fit ****************/

n = get_iv_data (fwd_iv_file,1);

Is = fixed_params[16];
ndiode = fixed_params[17];
rdiode = fixed_params[18];

for (i = 0; i < n; ++i)
   {
   vdiode = vgsiv[i]-igsiv[i]*rdiode;
   xdata[i] = (float) vdiode;
   y1data[i] = (float) (igsiv[i]*per_mm*((double) 1.0e3));
   y2data[i] = (float) (per_mm*((double) 2.0e3)*Is*(exp (vdiode/ndiode*((double) 38.6981492189))-((double) 1.0)));
   }

pdata1[0].curve1_pts = n;
pdata1[1].curve1_pts = n;

scales1.xmin = scales2.xmin = 0.4;
scales1.xmax = scales2.xmax = 1.2;
scales1.xstep = scales2.xstep = 0.2;
scales1.xtick = scales2.xtick = 4;
scales1.y1min = 0.0;
scales1.y1max = 2.0;
scales1.y1step = 0.5;
scales1.y1tick = 5;

sprintf (pitem[0].y1_label,"Igs (mA/mm)");
sprintf (pitem[0].title,"Diode Characteristic");

if (jmbplot_draw_plot (pitem,1,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }   

/************ plot breakdown curves ****************/

n = get_iv_data (vbr_file,2);

for (i = 0; i < n; ++i)
   {
   xdata[i] = (float) -vgsiv[i];
   y1data[i] = (float) (-igsiv[i]*per_mm*((double) 1.0e3));
   y2data[i] = (float) (-eehemt_breakdown (p_list,(vgsiv[i]-vdsiv[i]),vdsiv[i])*per_mm*((double) 1.0e3));
   }

pdata1[0].curve1_pts = n;
pdata1[1].curve1_pts = n;

find_min_max (xdata,n,&min,&max);
scales1.xmin = 0.0;

if (max <= 10.0)
   {
   scales1.xmax = 10.0;
   scales1.xstep = 2.0;
   scales1.xtick = 4;
   }
else if (max <= 15.0)
   {
   scales1.xmax = 15.0;
   scales1.xstep = 5.0;
   scales1.xtick = 5;
   }
else if (max <= 20.0)
   {
   scales1.xmax = 20.0;
   scales1.xstep = 5.0;
   scales1.xtick = 5;
   }
else if (max <= 25.0)
   {
   scales1.xmax = 25.0;
   scales1.xstep = 5.0;
   scales1.xtick = 5;
   }
else   
   {
   scales1.xmax = 30.0;
   scales1.xstep = 5.0;
   scales1.xtick = 5;
   }

scales1.y1min = 0.0;
scales1.y1max = 2.0;
scales1.y1step = 0.5;
scales1.y1tick = 5;

sprintf (pitem[0].y1_label,"Igs (mA/mm)");
sprintf (pitem[0].title,"Breakdown Characteristic");

if (jmbplot_draw_plot (pitem,1,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }   

jmbplot_close_device ();

return (0);
}


/*                                                                        */
/* ----------- write_output_files() ------------------------------------- */
/*                                                                        */

void write_output_files (end_file,mod_file,iv_file)
char   *end_file;
char   *mod_file;
char   *iv_file;

{
FILE       *file1;
FILE       *file2;
double     inv_area;
int        i,j,k;
static int p[] = {4,7,13,17,19,21,22,25,26,31,32,33,36,37};
char       string[201];
static char *names[] = {"Rg1","Rd1","Rs1","Ris","Rid","Cdso","Tau","Ls",
                        "Cpg","Cpd","Cipg","Cipd","Lpg","Lpd","Effgl","Effdl",
                        "Is","N","Rser","Rg","Rd","Rs"};

inv_area = ((double) 1.0)/area;

file1 = fopen (mod_file,"w+");
file2 = fopen (iv_file,"r");

i = 0;
while (1)
   {
   fgets (string,201,file2);
   if (!strncmp (string,"!Vbr (.1mA) ",12))
      {
      fprintf (file1,"%s",string);
      break;
      }
   else if (++i > 30)
      {
      break;
      }
   fprintf (file1,"%s",string);
   }
fgets (string,201,file2);
fprintf (file1,"%s",string);
fclose (file2);

fprintf (file1,"!\n");
fprintf (file1,"VAR model=1\n");
fprintf (file1,"BEGIN BDTA\n");
fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s\n","Ngf","Ugw","Kmod","Kver");
fprintf (file1,"     %-11d     %+.4e     %-11d     %-11d\n",ngf,ugw,104,2);

i = 0;
while (i < NUM_PARAMS)
   {
   fprintf (file1,"%%");
   k = i;
   for (j = 0; j < 6; ++j)
      {
      fprintf (file1,"     %-11s",params[i].name);
      ++i;
      if (i >= NUM_PARAMS)
         {
         break;
         }
      }
   fprintf (file1,"\n");
   i = k;
   for (j = 0; j < 6; ++j)
      {
      fprintf (file1,"     %+.4e",params[i].nom);
      ++i;
      if (i >= NUM_PARAMS)
         {
         break;
         }
      }
   fprintf (file1,"\n");   
   }

fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
         names[0],names[1],names[2],names[3],names[4]);
fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
         fixed_params[0],fixed_params[1],fixed_params[2],fixed_params[3],fixed_params[4]);

fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
         names[7],names[8],names[9],names[10],names[11]);
fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
         fixed_params[7],fixed_params[8],fixed_params[9],fixed_params[10],fixed_params[11]);

fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
         names[12],names[13],names[14],names[15],names[16]);
fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
         fixed_params[12],fixed_params[13],fixed_params[14],fixed_params[15],fixed_params[16]);

fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
         names[17],names[19],names[20],names[21],"Vdso");
fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
         fixed_params[17],fixed_params[19],fixed_params[20],fixed_params[21],Vds0);

fprintf (file1,"END BDTA\n");

fclose (file1);

// write finishing values file

/* scale starting values */
for (i = 0; i < 14; ++i)
   {
   params[p[i]].min *= inv_area;
   params[p[i]].max *= inv_area;
   params[p[i]].nom *= inv_area;
   params[p[i]].tol *= inv_area;
   }
params[23].min *= area; /* kdb */
params[23].max *= area;
params[23].nom *= area;
params[23].tol *= area;

file1 = fopen (end_file,"w+");
for (i = 0; i < NUM_PARAMS; ++i)
   {
   fprintf (file1,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
                                                     params[i].tol,params[i].name);
   }
fclose (file1);

return;
}


/****************************************************************************/
/*                       OPTIMIZATION ERROR FUNCTIONS                       */
/****************************************************************************/

/*                                                                 */
/* ----------- eehemt_opt_function() ----------------------------- */
/*                                                                 */

double *eehemt_opt_function (p_list)
double   *p_list;

{
static double  result[5];
double         *error;

switch (mode_flag)
   {
   case DC_IV_CURVES:
      result[0] = ids_function (p_list);
      break;
   case CAPACITANCE:
      error = cgs_cgd_function (p_list);
      result[0] = error[0];
      result[1] = error[1];
      break;
   case VDS0_CAP:
      result[0] = vds0_cap_function (p_list);
      break;
   case AC_IV_CURVES:
      error = ac_iv_function (p_list);
      result[0] = error[0];
      result[1] = error[1];
      break;
   case BREAKDOWN:
      result[0] = breakdown_function (p_list);
      break;
   default:
      result[0] = (double) 0.0;
      result[1] = (double) 0.0;
      result[2] = (double) 0.0;
      result[3] = (double) 0.0;
      result[4] = (double) 0.0;
      break;
   }

return (result);
}


/*                                                                          */
/* ----------- ids_function() --------------------------------------------- */
/*                                                                          */

double ids_function (p_list)
double  *p_list;

{
int      i;
double   ids,gm,gds;
double   error;

error = (double) 0.0;
for (i = 0; i < num_iv_pts; ++i)
   {
   eehemt_ids_gm_gds (p_list,vgsiv[i],vdsiv[i],&ids,&gm,&gds,0);
   if ((fabs (vdsiv[i]) <= (double) 2.0) && ((idsiv[i]/area) <= (double) 0.1))
      {
      error += pow ((((double) 5000.0)*(idsiv[i]-ids)),((double) 2.0));
      }
   else
      {
      error += pow ((((double) 1000.0)*(idsiv[i]-ids)),((double) 2.0));
      }
   }

return (error/((double) num_iv_pts));
}


/*                                                                          */
/* ----------- vds0_cap_function() ---------------------------------------- */
/*                                                                          */

double vds0_cap_function (p_list)
double  *p_list;

{
int      i,j;
double   cgs,cgst,cgd,cgdt;
double   c11mod,c11meas;
double   error;

error = (double) 0.0;
for (i = 0,j = 0; i < num_ac_iv_pts; ++i)
   {
   if (mvds[i] == Vds0)
      {
      eehemt_capacitance (p_list,mvgs[i],mvds[i],&cgs,&cgst,&cgd,&cgdt);
      c11mod = cgs+cgd+cgst+cgdt;
      c11meas = mcgs[i]+mcgd[i];
      error += pow (((double) 1.0e12)*(c11mod-c11meas),(double) 2.0);
      ++j;
      }
   }

if (j == 0)
   return (double) 0.0;

return (error/((double) j));
}

/*                                                                          */
/* ----------- cgs_cgd_function() ----------------------------------------- */
/*                                                                          */

double *cgs_cgd_function (p_list)
double  *p_list;

{
int      i;
double   cgs,cgst,cgd,cgdt;
double   c11mod,c12mod,c11meas;
double   error[2];

error[0] = (double) 0.0;
error[1] = (double) 0.0;
for (i = 0; i < num_ac_iv_pts; ++i)
   {
   eehemt_capacitance (p_list,mvgs[i],mvds[i],&cgs,&cgst,&cgd,&cgdt);
   c11mod = cgs+cgd+cgst+cgdt;
   c12mod = cgd+cgst;
   c11meas = mcgs[i]+mcgd[i];
   error[0] += pow (((double) 1.0e12)*(c11mod-c11meas),(double) 2.0);
   error[1] += pow (((double) 1.0e12)*(c12mod-mcgd[i]),(double) 2.0);
   }

error[0] = error[0]/((double) num_ac_iv_pts);
error[1] = error[1]/((double) num_ac_iv_pts);

return (error);
}

/*                                                                          */
/* ----------- ac_iv_function() ------------------------------------------- */
/*                                                                          */

double *ac_iv_function (p_list)
double   *p_list;

{
int      i;
double   ids,gm,gds;
double   error[2];

error[0] = (double) 0.0;
error[1] = (double) 0.0;
for (i = 0; i < num_ac_iv_pts; ++i)
   {
   eehemt_ids_gm_gds (p_list,mvgs[i],mvds[i],&ids,&gm,&gds,1);
   error[0] += pow (((double) 1.0e3)*(gm-mgm[i]),(double) 2.0);
   error[1] += pow (((double) 1.0e3)*(gds-mgds[i]),(double) 2.0);
   }

error[0] = error[0]/((double) num_ac_iv_pts);
error[1] = error[1]/((double) num_ac_iv_pts);

return (error);
}

/*                                                                          */
/* ----------- breakdown_function() --------------------------------------- */
/*                                                                          */

double breakdown_function (p_list)
double  *p_list;

{
int      i;
double   igs,vgd;
double   error;

error = (double) 0.0;
for (i = 0; i < num_iv_pts; ++i)
   {
   vgd = vgsiv[i]-vdsiv[i];
   igs = eehemt_breakdown (p_list,vgd,vdsiv[i]);
   error += pow (((double) 1000.0)*(igsiv[i]-igs),((double) 2.0))*tanh (((double) 3.0e6)/area*fabs (igsiv[i]));
   }

return (error/((double) num_iv_pts));
}

/****************************************************************************/
/*                         EEHEMT1 MODEL FUNCTIONS                          */
/****************************************************************************/

/*                                                                 */
/* --------- eehemt_ids_gm_gds ----------------------------------- */
/*                                                                 */

void eehemt_ids_gm_gds (p_list,Vgs,Vds,I_ds,G_m,G_ds,mode)
double   *p_list;
double   Vgs;
double   Vds;
double   *I_ds;
double   *G_m;
double   *G_ds;
int      mode;

{
/* model parameters */
double    vgo,vch,gamma,vdso;
double    vto,gmmax,vco,mu;
double    vbc,vba,alpha,deltgm;
double    kapa,peff,vsat,vtso;
double    gdbm,vdsm,kdb;
/* local variables */
double    V_g,V_t,x1,x2;
double    V_x,G_mo,I_dso,G_dso;
double    gmoff,Va,Vb,Vc;
double    Gmv,Idsv,Gdsv,a,b;
double    G_moc,I_dsoc,G_dsoc;
double    gm_prime,ids_prime;
double    gds_prime,Pdiss;
double    Vgs1,Vds1,Vts,Gdbp;

 /* ac gm, gds, and iv curves */
if (mode)
   {
   vto     = p_list[15];
   gamma   = p_list[16];
   vgo     = p_list[2];
   vch     = p_list[3];
   gmmax   = p_list[17];
   vdso    = Vds0;
   vsat    = p_list[5];
   kapa    = p_list[18];
   peff    = p_list[19];
   vtso    = p_list[20];
   vco     = p_list[9];
   vba     = p_list[10];
   vbc     = p_list[11];
   mu      = p_list[12];
   deltgm  = p_list[21];
   alpha   = p_list[14];
   }

 /* dc gm, gds, and iv curves */
else
   {   
   vto     = p_list[0];
   gamma   = p_list[1];
   vgo     = p_list[2];
   vch     = p_list[3];
   gmmax   = p_list[4];
   vdso    = Vds0;
   vsat    = p_list[5];
   kapa    = p_list[6];
   peff    = p_list[7];
   vtso    = p_list[8];
   vco     = p_list[9];
   vba     = p_list[10];
   vbc     = p_list[11];
   mu      = p_list[12];
   deltgm  = p_list[13];
   alpha   = p_list[14];
   }

gdbm   = p_list[22];
kdb    = p_list[23];
vdsm   = p_list[24];

if (Vds < (double) 0.0)
   {
   Vds1 = -Vds;
   Vgs1 = Vgs-Vds;
   }
else
   {
   Vds1 = Vds;
   Vgs1 = Vgs;
   }

x1 = ((double) 1.0)+gamma*(vdso-Vds1);
V_x = (Vgs1-vch)*x1;

V_g = (vgo-vch)/x1+vch;
V_t = (vto-vch)/x1+vch;
Vts = (vtso-vch)/x1+vch;

if ((Vgs1 < Vts) && (vtso > vto))
   {
   Vgs1 = Vts;
   }

if (Vgs1 >= V_g)
   {  
   I_dso = gmmax*(V_x-(vgo+vto)/((double) 2.0)+vch);
   G_mo = gmmax*x1;
   G_dso = -gmmax*gamma*(Vgs1-vch);
   }
else if (Vgs1 <= V_t)
   {
   G_mo = (double) 0.0;
   I_dso = (double) 0.0;
   G_dso = (double) 0.0;
   }
else
   {
   x2 = PI*(V_x-(vgo-vch))/(vto-vgo);
   I_dso = gmmax/((double) 2.0)*((vto-vgo)/PI*sin (x2)+V_x-(vto-vch));
   G_mo = gmmax/((double) 2.0)*x1*(cos (x2)+((double) 1.0));
   G_dso = -gmmax/((double) 2.0)*gamma*(Vgs1-vch)*(cos (x2)+((double) 1.0));
   }

if (vco >= vgo)
   {  
   gmoff = gmmax;
   }
else if (vco <= vto)
   {
   gmoff = (double) 0.0;
   }
else
   {
   x2 = PI*(vco-vgo)/(vto-vgo);
   gmoff = gmmax/((double) 2.0)*(cos (x2)+((double) 1.0));
   }

Vc = vco+mu*(vdso-Vds1);
Vb = vbc+Vc;
Va = Vb-vba;

x1 = sqrt (alpha*alpha+vbc*vbc);
Gmv = deltgm*(x1-alpha);
b = vbc*vba*deltgm/((Gmv-gmoff)*x1);

if (Vgs1 > Vc)
   {
   if (Vgs1 < Vb)
      {
      x2 = Vgs1-Vc;
      x1 = sqrt (alpha*alpha+x2*x2);
      Idsv = deltgm*(((double) 0.5)*(x2*x1-alpha*alpha*log10 ((x2+x1)/alpha))-alpha*x2);
      Gmv = deltgm*(x1-alpha);
      Gdsv = deltgm*mu*(((double) 0.5)*(((x2*x2*((double) 2.0)+alpha*alpha)/x1)+
                 alpha*alpha/(x2+x1)*(((double) 1.0)+x2/x1))-alpha);
      I_dsoc = I_dso-Idsv;
      G_moc = G_mo-Gmv;
      G_dsoc = G_dso-Gdsv;
      }
   else if ((Vgs1 >= Vb) && (b != ((double) -1.0)))
      {
      a = (Gmv-gmoff)/pow (vba,b);
      x2 = a*pow ((Vgs1-Va),b)+gmoff;
      Idsv = deltgm*(((double) 0.5)*(vbc*x1-alpha*alpha*log10 ((vbc+x1)/alpha))-alpha*vbc);
      Gdsv = deltgm*mu*(((double) 0.5)*(((vbc*vbc*((double) 2.0)+alpha*alpha)/x1)+
                 alpha*alpha/(vbc+x1)*(((double) 1.0)+vbc/x1))-alpha);   
      I_dsoc = I_dso-a/(b+((double) 1.0))*(pow ((Vgs1-Va),(b+((double) 1.0)))-pow (vba,(b+((double) 1.0))))-
                     gmoff*(Vgs1-Vb)-Idsv;
      G_moc = G_mo-x2;
      G_dsoc = G_dso-mu*x2-Gdsv;
      }
   else
      {
      a = (Gmv-gmoff)/pow (vba,b);
      Idsv = deltgm*(((double) 0.5)*(vbc*x1-alpha*alpha*log10 ((vbc+x1)/alpha))-alpha*vbc);
      Gdsv = deltgm*mu*(((double) 0.5)*(((vbc*vbc*((double) 2.0)+alpha*alpha)/x1)+
                 alpha*alpha/(vbc+x1)*(((double) 1.0)+vbc/x1))-alpha);  
      I_dsoc = I_dso-a*(log10 (Vgs1-Va)-log10 (vba))-gmoff*(Vgs1-Vb)-Idsv;  
      G_moc = G_mo-(a*pow ((Vgs1-Va),b)+gmoff);
      G_dsoc = G_dso-mu*a/(Vgs1-Va)-mu*gmoff-Gdsv;
      }   
   }
else
   {
   G_moc = G_mo;
   I_dsoc = I_dso;
   G_dsoc = G_dso;
   }

if (I_dsoc != (double) 0.0)
   {
   if ((Vgs1 < Vts) && (vtso > vto) && ((G_moc/I_dsoc) > (double) 0.0))
      {
      x1 = exp (-(G_moc/I_dsoc)*(Vts-Vgs1));
      I_dsoc *= x1;
      G_moc *= x1;
      G_dsoc *= x1;
      }
   }
      
x1 = tanh (((double) 3.0)*Vds1/vsat);
x2 = cosh (((double) 3.0)*Vds1/vsat);

ids_prime = I_dsoc*(((double) 1.0)+kapa*Vds1)*x1;
gm_prime = G_moc*(((double) 1.0)+kapa*Vds1)*x1;
gds_prime = (G_dsoc*(((double) 1.0)+kapa*Vds1)+I_dsoc*kapa)*x1+
                I_dsoc*((double) 3.0)*(((double) 1.0)+kapa*Vds1)/(vsat*x2*x2);

Pdiss = fabs (ids_prime*Vds1);
x1 = (((double) 1.0)+Pdiss/peff);

if (Vds < (double) 0.0)
   {
   *I_ds = -ids_prime/x1;
   }
else
   {
   *I_ds = ids_prime/x1;
   }

*G_m = gm_prime/(x1*x1);
*G_ds = (gds_prime-ids_prime*ids_prime/peff)/(x1*x1);

/* do dispersion current output conductance calculation for ac case */
if (mode)
   {
   if ((Vds1 > vdsm) && (kdb != (double) 0.0))
      {
      Gdbp = gdbm/(kdb*(gdbm*(Vds1-vdsm)*(Vds1-vdsm)+((double) 1.0)));
      }
   else if ((Vds1 <= vdsm) && (kdb != (double) 0.0))
      {
      Gdbp = gdbm/(kdb*(gdbm*(Vds1+vdsm)*(Vds1+vdsm)+((double) 1.0)));
      }
   else
      {
      Gdbp = gdbm;
      }
   
   *G_ds += Gdbp;
   *I_ds += Vds*Gdbp;
   }

return;
}

#if 0

// this is the old capacitance function

/*                                                                 */
/* --------- eehemt_capacitance ---------------------------------- */
/*                                                                 */

void eehemt_capacitance (p_list,Vgs,Vds,Cgs,Cgst,Cgd,Cgdt)
double   *p_list;
double   Vgs;
double   Vds;
double   *Cgs;
double   *Cgst;
double   *Cgd;
double   *Cgdt;

{
/* model parameters */
double    deltds,deltgs,vinfl;
double    c11o,c11th,lambda,vdso;
double    c12sat,cgdsat;
/* local variables */
double    qg,g,x1,f1,f2,Vgd;
double    dqgdvgc,dqgdvgy,dgdvgc;
double    df1dvgc,df1dvgy,df2dvgc,df2dvgy;
double    cggy,cggc;

vdso    = Vds0;
c11o    = p_list[25];
c11th   = p_list[26];
vinfl   = p_list[27];
deltgs  = p_list[28];
deltds  = p_list[29];
lambda  = p_list[30];
c12sat  = p_list[31];
cgdsat  = p_list[32];

Vgd = Vgs-Vds;

g = Vgs-vinfl+deltgs/((double) 3.0)*log (cosh (((double) 3.0)/deltgs*(Vgs-vinfl)));
dgdvgc = ((double) 1.0)+tanh (((double) 3.0)/deltgs*(Vgs-vinfl));
x1 = (c11o-c11th)*((double) 0.5)*g+c11th*(Vgs-vinfl);
qg = x1*(((double) 1.0)+lambda*(Vds-vdso))-c12sat*Vds;
dqgdvgy = -x1*lambda+c12sat;
dqgdvgc = x1*lambda+(((double) 1.0)+lambda*(Vds-vdso))*((c11o-c11th)*((double) 0.5)*dgdvgc+c11th)-c12sat;

x1 = tanh (((double) 3.0)/deltds*Vds);
f1 = ((double) 0.5)*(((double) 1.0)+x1);
f2 = ((double) 0.5)*(((double) 1.0)-x1);
x1 = ((double) 1.0)/pow (cosh (((double) 3.0)*Vds/deltds),(double) 2.0);
df1dvgc = df2dvgy = ((double) 3.0)/(((double) 2.0)*deltds)*x1;
df2dvgc = df1dvgy = -df1dvgc;

*Cgs = (qg-cgdsat*Vgd)*df1dvgc+f1*dqgdvgc+cgdsat*(Vgs*df2dvgc+f2);
*Cgd = (qg-cgdsat*Vgs)*df2dvgy+f2*dqgdvgy+cgdsat*(Vgd*df1dvgy+f1);
*Cgst = (qg-cgdsat*Vgd)*df1dvgy+f1*(dqgdvgy-cgdsat)+cgdsat*Vgs*df2dvgy;
*Cgdt = (qg-cgdsat*Vgs)*df2dvgc+f2*(dqgdvgc-cgdsat)+cgdsat*Vgd*df1dvgc;

return;
}

#endif

/*                                                                 */
/* --------- eehemt_capacitance ---------------------------------- */
/*                                                                 */

// this function was taken from the agilent eefet3 source code

void eehemt_capacitance (p_list,Vgc,Vyc,pCgc,pdQgc_dVgy,pCgy,pdQgy_dVgc)
double *p_list;
double Vgc,Vyc;
double *pCgc,*pdQgc_dVgy;
double *pCgy,*pdQgy_dVgc;
   {
   // variables
   double Vgy,sqrterm,vjx,vo,dvjxdvds,dvodvds;
   double f2vds,tanhgs,inttanhgs,fvgs,intfvgs;
   double qjo,gvds,gpvds,qj,dv;
   double cjx,co,cjo,alpha,tanhfunc,f1,f2;
   double df1dvgc,df1dvgy,df2dvgc,df2dvgy;
   double cggy,cggc,qterm;
   
   // need to be set
   double Vinfl,Deltds,Deltgs,C11o,C11th;
   double C12sat,Lambda,Cgdsat,Vdso;

   // dummy return variables
   double tmp1,tmp2;
   double *pQgc = &tmp1;
   double *pQgy = &tmp2;

   Vdso    = Vds0;
   C11o    = p_list[25];
   C11th   = p_list[26];
   Vinfl   = p_list[27];
   Deltgs  = p_list[28];
   Deltds  = p_list[29];
   Lambda  = p_list[30];
   C12sat  = p_list[31];
   Cgdsat  = p_list[32];
   
//   Vyc = Vgc - Vgy;
   Vgy = Vgc - Vyc;

   sqrterm = sqrt(Vyc*Vyc + Deltds*Deltds);
   vjx = 0.5*(2.0*Vgc - Vyc + sqrterm);
   vo = sqrterm;
   dvjxdvds = 0.5*(Vyc/sqrterm - 1.0);
   dvodvds = Vyc/sqrterm;
   dv = vjx - Vinfl;
   f2vds = 1 + Lambda*(vo - Vdso);
   
   tanh_integ_protect(3.0/Deltgs, dv, &tanhgs, &inttanhgs);
   
   fvgs = 1 + tanhgs;
   intfvgs = dv + inttanhgs;
   
   qjo = (C11o - C11th)*0.5*intfvgs + C11th*dv;
   gvds = -C12sat*vo;
   gpvds = -C12sat;
   qj = qjo*f2vds + gvds;
   
   cjx = ( (C11o - C11th)*0.5*fvgs + C11th )*f2vds;
   co = qjo*Lambda + gpvds;
   cjo = cjx*dvjxdvds + co*dvodvds;
   
   alpha = 3.0 / Deltds;
   vo = Vgc - Vgy;
   
   tanhfunc = tanh_protect( alpha*vo );
   
   /* smoothing functions */
   f1 = 0.5*(1.0 + tanhfunc);
   f2 = 0.5*(1.0 - tanhfunc);
   
   /* derivatives of smoothing functions wrt vgc and vgy */
   df1dvgc = 0.5*alpha*(1.0 - tanhfunc*tanhfunc);
   df1dvgy = -df1dvgc;
   df2dvgc = -0.5*alpha*(1.0 - tanhfunc*tanhfunc);
   df2dvgy = -df2dvgc;
   
   /* apply chain rule to convert derivatives to functions of Vgc, Vgy */
   cggy = -cjo;
   cggc = cjx + cjo;
   
   /* gate drain charge and its derivatives */
   qterm = qj - Cgdsat*Vgc;
   *pQgy = Cgdsat*Vgy*f1 + qterm*f2;
   *pCgy = Cgdsat*(Vgy*df1dvgy + f1) + qterm*df2dvgy + f2*cggy;
   *pdQgy_dVgc = Cgdsat*Vgy*df1dvgc + qterm*df2dvgc + f2*(cggc - Cgdsat);
   
   /* gate source charge and its derivatives */
   qterm = qj - Cgdsat*Vgy;
   *pQgc = qterm*f1 + Cgdsat*Vgc*f2;
   *pCgc = qterm*df1dvgc + f1*cggc + Cgdsat*(Vgc*df2dvgc + f2);
   *pdQgc_dVgy = qterm*df1dvgy + f1*(cggy - Cgdsat) + Cgdsat*Vgc*df2dvgy;
   }

/*                                                                 */
/* --------- eehemt_breakdown ------------------------------------ */
/*                                                                 */

double eehemt_breakdown (p_list,Vgd,Vds)
double   *p_list;
double   Vgd;
double   Vds;

{
double    kbk,idsoc,vbr,nbr;
double    Vgs,ids,gm,gds;

kbk   = p_list[33];
vbr   = p_list[34];
nbr   = p_list[35];
idsoc = p_list[36];

Vgs = Vds+Vgd;

if (-Vgd <= vbr)
   {
   return ((double) 0.0);
   }
else
   {
   eehemt_ids_gm_gds (p_list,Vgs,Vds,&ids,&gm,&gds,0);
   return (-kbk*(((double) 1.0)-ids/idsoc)*pow ((-Vgd-vbr),nbr));
   }

}


/****************************************************************************/
/*                                UTILITIES                                 */
/****************************************************************************/

/*                                                                          */
/* ----------- bubble_average() ------------------------------------------- */
/*                                                                          */

double bubble_average (values,n)
double   *values;
int      n;

{
int     i,j;
double  temp;
double  delta;

for (i = 0; i < n-1; ++i)
   {
   for (j = i+1; j < n; ++j)
      {
      if (values[j] < values[i])
         {
         temp = values[i];
         values[i] = values[j];
         values[j] = temp;
         }
      }
   }

i = 0;
temp = (double) 0.0;
delta = fabs (values[n/2])*((double) 0.25);
for (j = 0; j < n; ++j)
   {
   if (fabs (values[j]-values[n/2]) < delta)
      {
      ++i;
      temp += values[j];
      }
   }
temp = temp/((double) i);

return (temp);
}


/*                                                                          */
/* ----------- diode_fit() ------------------------------------------------ */
/*                                                                          */

int diode_fit (vd,id,k,darea,is,n,rd)
double   *vd;
double   *id;
int      k;
double   darea;
double   *is;
double   *n;
double   *rd;

{
double   a1[3][MAX_IV_PTS];
double   a2[MAX_IV_PTS][3];
double   b1[MAX_IV_PTS];
double   a[3][3];
double   b[3];
double   x[3];
double   sum;
int      i,j;
int      npts;

j = 0;
for (i = 0; i < k; ++i)
   {
   if ((vd[i] <= (double) 0.0) || (id[i] <= (((double) 1.0e-7)*darea)))
      {
      continue;
      }
   a2[j][0] = log (id[i]);
   a2[j][1] = (double) -1.0;
   a2[j][2] = id[i];
   a1[0][j] = a2[j][0];
   a1[1][j] = a2[j][1];
   a1[2][j] = a2[j][2];
   b1[j] = vd[i];
   ++j;
   }

if (j < 3)
   {
   printf ("Not enough points for diode fit.\n");
   return (-1);
   }

npts = j;

for (i = 0; i < 3; ++i)
   {
   for (j = 0; j < 3; ++j)
      {
      sum = (double) 0.0;
      for (k = 0; k < npts; ++k)
         {
         sum += a1[i][k]*a2[k][j];
         }
      a[i][j] = sum;
      }
   }

for (i = 0; i < 3; ++i)
   {
   sum = (double) 0.0;
   for (j = 0; j < npts; ++j)
      {
      sum += a1[i][j]*b1[j];
      }
   b[i] = sum;
   }

if (a_x_b (a,x,b,3) == -1)
   {
   printf ("Un-invertable matrix in diode fit.\n");
   return (-1);
   }
  
*n = x[0]*((double) 38.6981492189);
*is = exp (x[1]/x[0]);
*rd = x[2];

return (0);
}


/*                                                                          */
/* ----------- a_x_b() ---------------------------------------------------- */
/*                                                                          */

int a_x_b (a,x,b,n)
double   *a;
double   *x;
double   *b;
int      n;

{
double   y[50];
double   z[50][50];
double   tempd;
double   tempd2;
double   max;
int      pointer[50];
int      tempi;
int      i,j,k;
int      col,row;


if (n > 50)
   {
   printf ("a_x_b () - Matrix is too large.\n");
   return (-1);
   }

for (i = 0; i < n; ++i)
   {
   y[i] = b[i];
   pointer[i] = i;
   for (j = 0; j < n; ++j)
      {
      z[i][j] = a[i*n+j];
      }
   }

/* invert the matrix */
for (k = 0; k < n-1; ++k)
   {
   /* find max */
   max = (double) 0.0;
   for (i = k; i < n; ++i)
      {
      for (j = k; j < n; ++j)
         {
         if (fabs (z[i][j]) > max)
            {
            row = i;
            col = j;
            max = fabs (z[i][j]);
            }
         }
      }

   /* rotate rows */
   if (row != k)
      {
      for (j = 0; j < n; ++j)
         {
         tempd = z[k][j];
         z[k][j] = z[row][j];
         z[row][j] = tempd;
         }
      tempd = y[k];
      y[k] = y[row];
      y[row] = tempd;
      }

   /* rotate columns */ 
   if (col != k)
      {
      for (i = 0; i < n; ++i)
         {
         tempd = z[i][k];
         z[i][k] = z[i][col];
         z[i][col] = tempd;
         }
      tempi = pointer[k];
      pointer[k] = pointer[col];
      pointer[col] = tempi;
      }

   /* gaussian elimination */
   tempd = z[k][k];
   for (i = k+1; i < n; ++i)
      {
      tempd2 = z[i][k]/tempd;
      y[i] -= tempd2*y[k];
      for (j = k; j < n; ++j)
         {
         z[i][j] -= tempd2*z[k][j];
         }
      }
   }  

if (fabs (z[n-1][n-1]) < (double) 1.0e-34)
   {
   return (-1);
   }

/* back substitution */
x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
for (k = n-2; k > -1; --k)
   {
   tempd = y[k];
   for (i = n-1; i > k; --i)
      {
      tempd -= z[k][i]*x[pointer[i]];
      }
   x[pointer[k]] = tempd/z[k][k];
   }

return (0);
}

/*                                                                          */
/* ----------- find_min_max() --------------------------------------------- */
/*                                                                          */

void find_min_max (data,n,min,max)
float  *data;
int    n;
float  *min,*max;

{
int i;

*min = data[0];
*max = data[0];
for (i = 1; i < n; ++i)
   {
   if (data[i] > *max)
      {
      *max = data[i];
      }
   if (data[i] < *min)
      {
      *min = data[i];
      }
   }

return;
}

/*******************************************************************************************/
/*******************************************************************************************/

double tanh_protect (arg)
double arg;
   {
   if (arg < -700.0)
      return (-1.0);
   else if (arg > 700.0)
      return (1.0);
   else
      return (tanh(arg));
   }

/*******************************************************************************************/
/*******************************************************************************************/

void tanh_integ_protect (alpha,voltage,tanhfunc,integral)
double alpha,voltage;
double *tanhfunc,*integral;
   {
   double vlin, tanhsqr;
   double varg, integ_at_vlin;
   double tanharg, sech2arg, logcosh;
   
#define MAXARG   12.0
   
   vlin = MAXARG/alpha;
   if ( (voltage >= -vlin) && (voltage <= vlin) )
      {
      *tanhfunc = tanh(alpha*voltage);
      tanhsqr = (*tanhfunc)*(*tanhfunc);
      *integral = -0.5*log(1.0 - tanhsqr) / alpha;
      }
   else if (voltage > vlin)
      {
      tanharg = tanh(MAXARG);
      sech2arg = 1.0 - tanharg*tanharg;
      logcosh = -0.5*log(sech2arg);
      varg = voltage - vlin;
      integ_at_vlin = logcosh / alpha;
      *tanhfunc = alpha*sech2arg*varg + tanharg;
      *integral = alpha*sech2arg*varg*varg / 2.0 + tanharg*varg
         + integ_at_vlin;
      }
   else /* voltage < -vlin */
      {
      tanharg = tanh(MAXARG);
      sech2arg = 1.0 - tanharg*tanharg;
      logcosh = -0.5*log(sech2arg);
      varg = voltage + vlin;
      integ_at_vlin = logcosh / alpha;
      *tanhfunc = alpha*sech2arg*varg - tanharg;
      *integral = alpha*sech2arg*varg*varg / 2.0 - tanharg*varg
         + integ_at_vlin;
      }
   
   return;
}

