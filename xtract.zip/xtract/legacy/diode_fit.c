#include <stdio.h>
#include <math.h>
// #include "optimize4.h"
// #include "jplot.h"
#include "fit_tools.h"

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19

int main( int argc, char **argv )
   {
   char string[256], fname[256];
   IV_DATA diode_data[500];
   double vd[500];
   double id[500];
   unsigned i, j, npts;
   double a1[3], a2[3], a3[3];
   double *aa[] = {a1, a2, a3};
   double xx[3];
   double bb[3];
   double vt, temper;

   printf( "Data file?\n" );
   fgets( string, 255, stdin );
   sscanf( string, "%s", fname );

   printf( "Temperature (C)?\n" );
   fgets( string, 255, stdin );
   sscanf( string, "%lf", &temper );

   // read the data from the data file
   if( get_iv_data( fname, diode_data, 500, &npts ) )
      {
      fprintf( stderr, "Error reading data.\n" );
      return 1;
      }

   // get the data sub-set
   for( i=0,j=0; i<npts; i++ )
      {
      if( diode_data[i].vds == 0.0 && diode_data[i].vgs > 0.4 && diode_data[i].igs > 0.0 )
         {
         vd[j] = diode_data[i].vgs;
         id[j] = diode_data[i].igs;
         j++;
         }
      }

   if( j < 3 )
      {
      fprintf( stderr, "Error: not enough points.\n" );
      return 1;
      }

   npts = j;

   fprintf( stderr, "      Is          n       R\n" );
   fprintf( stderr, "-------------------------------\n" );

   // perform sub-fits for each set of 3 points
   vt = BOLTZMANN*(273.15+temper)/Q_ELECTRON;
   for( i=0; i<npts-3; i++ )
      {
      for( j=0; j<3; j++ )
         {
         aa[j][0] = 1.0;
         aa[j][1] = vd[i+j] / vt;
         aa[j][2] = -id[i+j];
         bb[j] = log( id[i+j] );
         }

      if( solve_linear_system( aa, bb, xx, 3 ) )
         {
         fprintf( stderr, "Error: matrix is singular.\n" );
         return 1;
         }

      fprintf( stderr, "%13.4e %7.3f %9.3f\n", exp( xx[0] ), 1.0 / xx[1], xx[2] );
      }

   return 0;
   }

