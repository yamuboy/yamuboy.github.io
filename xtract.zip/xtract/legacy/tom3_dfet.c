#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"
#include "optimize4.h"

/****** MACROS AND DEFINITIONS ******/

#define MAX_AC_BIAS_PTS    250
#define MAX_DCIV_PTS       1000
#define MAX_FWDIV_PTS      100
#define MAX_BREAKDOWN_PTS  100
#define MAX_FWD_IGS        0.8    // in mA/mm

#define NUM_PARAMS  21

#define BOLTZ     1.380066e-23
#define CHARGE    1.60218e-19
#define STDTEMP   300.0

#define DC_IV_FILE       1
#define FWD_IV_FILE      2
#define BREAKDOWN_FILE   3

#define OPTIMIZE_DCIV         1
#define OPTIMIZE_CAPACITANCE  2

typedef struct
   {
   double vgs,vds,igs,ids;
   } IV_DATA;

typedef struct
   {
   double vgs,vds,igs,ids;
   double cgs,cgd;
   double gm,gds;
   } AC_PARAMETERS;

typedef struct
   {
   unsigned ngf;
   double area,ugw;
   double rg,rd,rs,ri;
   double lg,ld,ls;
   double c1,c2,c11,c22;
   double is,n,ibd,vbd;
   double tau,tau2,cds;
   double tnom;
   } FIXED_PARAMETERS;

typedef struct
   {
   unsigned n;
   IV_DATA *data;
   double max_vds;
   double periphery;
   } DC_DATA;

typedef struct
   {
   unsigned n;
   AC_PARAMETERS *data;
   } AC_DATA;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, int max_size);
static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMETERS fixed);
static void write_model_param_mdif (FILE *file, char *names[], double *values, unsigned n, unsigned width, unsigned cols);

static unsigned get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p, FIXED_PARAMETERS *fixed_params);
static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params);
static unsigned get_iv_curves (char *fname, int type, IV_DATA *d, unsigned max_pts, FIXED_PARAMETERS fixed_params);
static int diode_fit (IV_DATA *iv, int k, double *is, double *n, double *rd);
static int diode_fit_no_rd (IV_DATA *iv, int k, double *is, double *n);

static int subth_dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int capacitance_erf (double *p, void *data, double *err, unsigned n_err);

static int plot_data (int dev, double periph, IV_DATA *dc, unsigned n_dc, AC_PARAMETERS *ac, unsigned n_ac,
                      OPT_PARAMETER *params, IV_DATA *fwd, unsigned n_fwd, IV_DATA *vbr, unsigned n_vbr,
                      FIXED_PARAMETERS fixed);


/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   unsigned i,niter;
   char string[256];
   char model_summary_file[100],start_file[100],end_file[100];
   char model_file[100],yfit_file[100],dc_iv_file[100];
   char fwd_iv_file[100],breakdown_file[100],header[3000];
   double tmpd;
   OPTIMIZE *opt;
   OPT_PARAMETER params[NUM_PARAMS];
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   IV_DATA fwdiv_curves[MAX_FWDIV_PTS];
   IV_DATA breakdown_curves[MAX_BREAKDOWN_PTS];
   AC_PARAMETERS ac_data[MAX_AC_BIAS_PTS];
   FIXED_PARAMETERS fixed_params;
   unsigned num_ac_bias_pts,num_dciv_pts,num_fwdiv_pts,num_breakdown_pts;
   DC_DATA dciv_data;
   AC_DATA ac_opt_data;
   unsigned optimization_fits = OPTIMIZE_DCIV | OPTIMIZE_CAPACITANCE;
   double maximum_vds;

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&fixed_params.ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.ugw);

   fixed_params.area = fixed_params.ngf * fixed_params.ugw;

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.tnom);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Forward IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",breakdown_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   /* get measurement and extraction data */
   
   if (get_starting_values (start_file, params, NUM_PARAMS))
      return -1;

   fixed_params.rg = fixed_params.rd = fixed_params.rs = fixed_params.ri = 0.0;

   if (!(num_dciv_pts = get_iv_curves (dc_iv_file, DC_IV_FILE, dciv_curves, MAX_DCIV_PTS, fixed_params)))
      return -1;

   if (!(num_fwdiv_pts = get_iv_curves (fwd_iv_file, FWD_IV_FILE, fwdiv_curves, MAX_FWDIV_PTS, fixed_params)))
      return -1;

   if (!(num_breakdown_pts = get_iv_curves (breakdown_file, BREAKDOWN_FILE, breakdown_curves, MAX_BREAKDOWN_PTS, fixed_params)))
      return -1;

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, params, NUM_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

   /******************** DC IV, Forward IV, and Breakdown *******************/
   
   printf ("****** Fitting DC Data ******\n");

   // forward diode IV

   printf ("Forward Diode IV.\n");
   
   if (diode_fit_no_rd (fwdiv_curves, num_fwdiv_pts, &fixed_params.is, &fixed_params.n))
      return -1;

   fixed_params.is *= 0.5;
   fixed_params.n *= STDTEMP / (fixed_params.tnom + 273.0);

   // reverse diode breakdown/leakage

   printf ("Reverse Diode Leakage.\n");
   
   if (diode_fit_no_rd (breakdown_curves, num_breakdown_pts, &fixed_params.ibd, &fixed_params.vbd))
      return -1;

   fixed_params.vbd *= BOLTZ*STDTEMP/CHARGE;
   
   // DC IV curves
   
   printf ("Optimizing DC IV data.\n");

   dciv_data.n = num_dciv_pts;
   dciv_data.data = dciv_curves;
   dciv_data.max_vds = maximum_vds;
   dciv_data.periphery = fixed_params.area;

   printf (" Subthreshold...\n");
   
   set_cg_error_function (opt, subth_dciv_erf, &dciv_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-9, 5);

   params[0].optimize = TRUE;
   params[7].optimize = TRUE;
   params[8].optimize = TRUE;
         
   if (optimization_fits & OPTIMIZE_DCIV)
      {
      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Gradient optimizer encountered an error:\n  %s\n", get_cg_error());
         return -1;
         }
      }

   params[0].optimize = FALSE;
   params[7].optimize = FALSE;
   params[8].optimize = FALSE;   

   printf (" Active...\n");

   set_cg_error_function (opt, dciv_erf, &dciv_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-9, 5);

   for (i = 1; i <= 6; ++i)
      params[i].optimize = TRUE;
         
   if (optimization_fits & OPTIMIZE_DCIV)
      {
      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Gradient optimizer encountered an error:\n  %s\n", get_cg_error());
         return -1;
         }
      }
   
   for (i = 1; i <= 6; ++i)
      params[i].optimize = FALSE;

   /***** Write final data files *****/
   
   printf ("Writing data files.\n");

   get_file_header (dc_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, params, fixed_params))
      return -1;

   /***** Generate plots *****/
   
   printf ("Generating plots.\n");
   
   plot_data (X_WINDOWS, fixed_params.area, dciv_curves, num_dciv_pts, ac_data, num_ac_bias_pts, params,
      fwdiv_curves, num_fwdiv_pts, breakdown_curves, num_breakdown_pts, fixed_params);
   plot_data (POSTSCRIPT, fixed_params.area, dciv_curves, num_dciv_pts, ac_data, num_ac_bias_pts, params,
      fwdiv_curves, num_fwdiv_pts, breakdown_curves, num_breakdown_pts, fixed_params);

   printf ("Model fitting complete.\n");

   return 0;
   }
  
/*****************************************************************************/
/*****************************************************************************/
   
static void get_file_header (char *data_file, char *header, int max_size)
   {
   FILE *file = fopen (data_file,"r");
   int index = 0,len;
   char string[300];

   if (!header || !data_file || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
      {
      if (string[0] != '!')
         {
         string[0] = 0;
         break;
         }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         if ((index + len) < max_size)
            {
            strcat (header, string);
            index += len;
            }
         else
            break;

         fgets (string,299,file);
         break;
         }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else
         break;
      }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if (len > 0)
      {
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else if ((max_size - index) == 1);
      else
         {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
         }
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMETERS fixed)
   {
   FILE *file;
   unsigned i;
   unsigned count = 0;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   
   /* write final optimization parameter values */

   file = fopen (end_file,"w+");
   if (!file)
      {
      fprintf (stderr, "Error: unable to open file for writing.\n");
      return -1;
      }

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (file);

   /* write the model parameter file */

   // non-optimized parameters
   names[num_p] = "Ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "Ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "Tnom"; values[num_p] = fixed.tnom; ++num_p;
   names[num_p] = "Is"; values[num_p] = fixed.is; ++num_p;
   names[num_p] = "Eta"; values[num_p] = fixed.n; ++num_p;
   names[num_p] = "Ilk"; values[num_p] = fixed.ibd; ++num_p;
   names[num_p] = "Plk"; values[num_p] = fixed.vbd; ++num_p;

   for (i = 0; i < 9; ++i)
      {
      names[num_p] = params[i].name;
      values[num_p] = params[i].nom;
      ++num_p;
      }

   file = fopen (model_file,"w+");
   if (!file)
      {
      fprintf (stderr, "Error: unable to open file for writing.\n");
      return -1;
      }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");

   write_model_param_mdif (file, names, values, num_p, 12, 5);
   
   fclose (file);
      
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void write_model_param_mdif (FILE *file, char *names[], double *values, unsigned n, unsigned width, unsigned cols)
   {
   unsigned i = 0;
   unsigned j;
   unsigned tmp;
   char txt_fmt[20];
   char num_fmt[20];

   if (!file || !n || !cols || !width)
      return;

   sprintf (txt_fmt, "%%-%ds ", width);
   sprintf (num_fmt, "%%-%d.3e ", width);

   fprintf (file, "BEGIN BDTA\n");

   while (i < n)
      {
      tmp = i;

      fprintf (file, "%%\t");
      for (j = 0; j < cols; ++j, ++i)
         {
         if (i >= n)
            break;

         fprintf (file, txt_fmt, names[i]);
         }
      fprintf (file, "\n");

      fprintf (file, "\t");
      for (j = 0, i = tmp; j < cols; ++j, ++i)
         {
         if (i >= n)
            break;

         fprintf (file, num_fmt, values[i]);
         }
      fprintf (file, "\n");
      }

   fprintf (file, "END\n");
   }

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

static double tom3_ids (double *p, double vgs, double vds)
   {
   double vto    = p[0];
   double alpha  = p[1];
   double beta   = p[2];
   double lambda = p[3];
   double gamma  = p[4];
   double q      = p[5];
   double k      = p[6];
   double vst    = p[7];
   double mst   = p[8];
   double Vst,u,Vg,fk,I0,Ids;
   int flag = 0;

   if (vds < 0.0)
      {
      vgs = vgs - vds;
      vds = -vds;
      flag = 1;
      }

   Vst = vst * (1.0 + mst*vds);
   u = (vgs - vto + gamma*vds) / (q*Vst);
   Vg = q * Vst * log (1.0 + exp (u));
   fk = (alpha*vds) / pow (1.0 + pow (alpha*vds, k), 1.0/k);
   I0 = beta * pow (Vg, q) * fk;
   Ids = I0 * (1.0 + lambda*vds);

   if (flag)
      return -Ids;

   return Ids;
   }

/*****************************************************************************/
/*****************************************************************************/

static double tom3_qgg (double *p, double vgs, double vds)
   {
   double qgql = p[9];
   double qgqh = p[10];
   double qgi0 = p[11];
   double qgag = p[12];
   double qgad = p[13];
   double qggb = p[14];
   double qgcl = p[15];
   double qgsh = p[16];
   double qgdh = p[17];
   double qgg0 = p[18];
   double Qgh,Qgl,ft,Qgg;
   double vgd = vgs - vds;
   double ids = tom3_ids (p, vgs, vds);

   Qgh = (qgqh * log (1.0 + ids/qgi0) + qgsh*vgs) + qgdh*vgd;
   Qgl = qgql * exp (qgag * (vgs + vgd)) * cosh (qgad*vds) + qgcl * (vgs + vgd);
   ft = exp (-qggb * ids * vds);
   Qgg = Qgl*ft + Qgh*(1.0 - ft) + qgg0*(vgs + vgd);

   return Qgg;
   }

/*****************************************************************************/
/*****************************************************************************/

static double tom3_cgs (double *p, double vgs, double vds)
   {
   double qgg_hi,qgg_lo;
   double delta = 1.0e-4;

   qgg_hi = tom3_qgg (p, vgs + delta, vds + delta);
   qgg_lo = tom3_qgg (p, vgs - delta, vds - delta);

   return 0.5*(qgg_hi - qgg_lo)/delta;
   }

/*****************************************************************************/
/*****************************************************************************/

static double tom3_cgd (double *p, double vgs, double vds)
   {
   double qgg_hi,qgg_lo;
   double delta = 1.0e-4;

   qgg_hi = tom3_qgg (p, vgs, vds - delta);
   qgg_lo = tom3_qgg (p, vgs, vds + delta);

   return 0.5*(qgg_hi - qgg_lo)/delta;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int subth_dciv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DC_DATA *d = (DC_DATA *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      if ((d->data[i].vds > d->max_vds) ||
         (d->data[i].vds < 1.0) || 
         (d->data[i].ids <= 0.0) ||
         (d->data[i].ids > 5.0e-6 * d->periphery))
         continue;

      diff = log (d->data[i].ids) - log (tom3_ids (p, d->data[i].vgs, d->data[i].vds));
      err[0] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int dciv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DC_DATA *d = (DC_DATA *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      if (d->data[i].vds > d->max_vds)
         continue;

      diff = d->data[i].ids - tom3_ids (p, d->data[i].vgs, d->data[i].vds);
      err[0] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int capacitance_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double cgs_diff,cgd_diff;
   AC_DATA *d = (AC_DATA *) data;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      cgs_diff = d->data[i].cgs - tom3_cgs (p, d->data[i].vgs, d->data[i].vds);
      cgd_diff = d->data[i].cgd - tom3_cgd (p, d->data[i].vgs, d->data[i].vds);

      err[0] += 1.0e24 * cgs_diff * cgs_diff;
      err[1] += 1.0e24 * cgd_diff * cgd_diff;
      }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static double bubble_average (double *values, unsigned n)
   {
   unsigned i,j;
   double temp;
   double delta;

   if (!n)
      return 0.0;
   else if (n == 1)
      return values[0];
   
   for (i = 0; i < n-1; ++i)
      {
      for (j = i+1; j < n; ++j)
         {
         if (values[j] < values[i])
            {
            temp = values[i];
            values[i] = values[j];
            values[j] = temp;
            }
         }
      }
   
   i = 0;
   temp = 0.0;
   delta = fabs (values[n/2])*0.25;
   for (j = 0; j < n; ++j)
      {
      if (fabs (values[j]-values[n/2]) < delta)
         {
         ++i;
         temp += values[j];
         }
      }
   
   if (temp)
      return temp / ((double) i);
   
   return 0.0;
   }



/*****************************************************************************/
/*****************************************************************************/

static unsigned get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p, FIXED_PARAMETERS *fixed_params)
   {
   FILE *file;
   unsigned n = 0;
   unsigned m = 0;
   unsigned found = 0;
   unsigned i;
   char string[300],pname[20];
   double *Ri,*Tau,*Tau2,*Cds;
   double value;
   
   /* read in bias-dependent device parameters */

   file = fopen (sum_file,"r");
   if (!file)
      {
      printf ("Unable to open model summary file - %s\n",sum_file);
      return 0;
      }
   
   Ri = (double *) malloc (sizeof (double) * max_ac_p);
   Tau = (double *) malloc (sizeof (double) * max_ac_p);
   Tau2 = (double *) malloc (sizeof (double) * max_ac_p);
   Cds = (double *) malloc (sizeof (double) * max_ac_p);

   while (fgets (string,299,file))
      {
      if (m >= max_ac_p)
         {
         printf ("WARNING: too many bias points in model summary file.\n");
         break;
         }
         
      if (sscanf (&string[28],"%lf%lf%lf%lf%*f%*f%*f%*f%*f%lf%lf%lf%lf%lf%lf%lf%lf",
         &ac_params[n].vds,&ac_params[n].ids,&ac_params[n].vgs,&ac_params[n].igs,
         &Ri[m],&ac_params[n].gm,&Tau[m],&ac_params[n].gds,&Tau2[m],
         &ac_params[n].cgs,&Cds[m],&ac_params[n].cgd) == 12)
         {
         ++m;

         ac_params[n].ids *= 1.0e-3;
         ac_params[n].igs *= 1.0e-3;
         ac_params[n].gm  *= 1.0e-3;
         ac_params[n].gds *= 1.0e-3;
         ac_params[n].cgs *= 1.0e-12;
         ac_params[n].cgd *= 1.0e-12;
         
         if ((1.0e6*ac_params[n].igs/fixed_params->area) <= MAX_FWD_IGS)
            ++n;
         }
      }
   fclose (file);

   // average these parameters, since they are fixed in the LS model

   fixed_params->ri   = bubble_average (Ri,m);
   fixed_params->tau  = bubble_average (Tau,m)*1.0e-12;
   fixed_params->tau2 = bubble_average (Tau2,m)*1.0e-12;
   fixed_params->cds  = bubble_average (Cds,m)*1.0e-12;
   
   if (fixed_params->ri < 1.0e-3)
      fixed_params->ri = 1.0e-3;
   if (fixed_params->tau < 0.0)
      fixed_params->tau = 0.0;
   if (fixed_params->tau2 < 0.0)
      fixed_params->tau2 = 0.0;
   if (fixed_params->cds < 0.0)
      fixed_params->cds = 0.0;

   free ((void *) Ri);
   free ((void *) Tau);
   free ((void *) Tau2);
   free ((void *) Cds);

   if (n < 1)
      {
      fprintf (stderr, "Error: no data in %s.\n",sum_file);
      return 0;
      }

   /* determine the intrinsic node voltages */
      
   for (i = 0; i < n; ++i)
      {
      ac_params[i].vds -= fixed_params->rd*ac_params[i].ids +
         fixed_params->rs*(ac_params[i].ids + ac_params[i].igs);
      ac_params[i].vgs -= (fixed_params->rg + fixed_params->ri)*ac_params[i].igs + 
         fixed_params->rs*(ac_params[i].ids + ac_params[i].igs);
      }

   /* read in fixed parasitics from the small-signal end file */

   file = fopen (end_file,"r");
   if (!file)
      {
      printf ("Unable to open file: %s\n",end_file);
      return 0;
      }
   
   while (fgets (string,299,file))
      {
      if (sscanf (string,"%*f%lf%*f%*f%19s",&value,pname) == 2)
         {
         if (!strcmp (pname,"C1"))
            {
            fixed_params->c1 = value;
            ++found;
            }
         else if (!strcmp (pname,"C2"))
            {
            fixed_params->c2 = value;
            ++found;
            }
         else if (!strcmp (pname,"C11"))
            {
            fixed_params->c11 = value;
            ++found;
            }
         else if (!strcmp (pname,"C22"))
            {
            fixed_params->c22 = value;
            ++found;
            }
         else if (!strcmp (pname,"B1"))
            {
            fixed_params->lg = value;
            ++found;
            }
         else if (!strcmp (pname,"B2"))
            {
            fixed_params->ld = value;
            ++found;
            }
         else if (!strcmp (pname,"LS"))
            {
            fixed_params->ls = value;
            ++found;
            }
         else if (!strcmp (pname,"RG"))
            {
            fixed_params->rg = value;
            ++found;
            }
         else if (!strcmp (pname,"RD"))
            {
            fixed_params->rd = value;
            ++found;
            }
         else if (!strcmp (pname,"RS"))
            {
            fixed_params->rs = value;
            ++found;
            }
         }
      }
   fclose (file);

   if (found != 10)
      {
      fprintf (stderr, "Error: Missing parameter(s) in %s.\n",end_file);
      return 0;
      }
   
   return n;
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params)
   {
   FILE *file;
   char string[200];
   int i = 0;

   /* read in the starting values */

   file = fopen (fname,"r");
   if (!file)
      {
      printf ("Error: Unable to open file %s.\n",fname);
      return -1;
      }
   
   while (fgets (string,199,file))
      {
      if (i >= n_params)
         break;

      if (sscanf (string,"%lf%lf%lf%lf%19s",&params[i].min,&params[i].nom,
         &params[i].max,&params[i].tol,params[i].name))
         {
         params[i].optimize = FALSE;
         ++i;
         }
      }
   fclose (file);

   if (i != n_params)
      {
      fprintf (stderr, "Error: missing parameter(s) in %s.\n",fname);
      return -1;
      }

   /* check for bad starting values or illegal range values 
      (i.e. parameters that must be >= 0) */


   




   /* set the min, max, and nom values to be legal */

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      if (params[i].max < params[i].min)
         params[i].max = params[i].min;
      if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static unsigned get_iv_curves (char *fname, int type, IV_DATA *d, unsigned max_pts, FIXED_PARAMETERS fixed_params)
   {
   FILE *file;
   char string[200];
   double vgs,vds,igs,ids;
   unsigned i = 0;
   
   file = fopen (fname,"r");
   if (!file)
      {
      fprintf (stderr, "Error: Unable to open file %s.\n",fname);
      return 0;
      }
      
   while (fgets (string,199,file))
      {      
      if (sscanf (string,"%lf%lf%lf%lf",&vds,&ids,&vgs,&igs) == 4)
         {
         if (i >= max_pts)
            {
            fprintf (stderr, "WARNING: too many data points in file %s.\n",fname);
            break;
            }
         
         switch (type)
            {
            case DC_IV_FILE:
               if ((1.0e6*igs/fixed_params.area) > MAX_FWD_IGS)
                  continue;

               d[i].vds = vds - fixed_params.rd*ids -
                  fixed_params.rs*(igs + ids);
               d[i].vgs = vgs - (fixed_params.rg + fixed_params.ri)*igs -
                  fixed_params.rs*(igs + ids);
               d[i].ids = ids;
               d[i].igs = igs;
               ++i;
               break;
               
            case FWD_IV_FILE:
               if (vds != 0.0)
                  continue;

               d[i].vgs = vgs;
               d[i].igs = igs;
               ++i;
               break;
               
            case BREAKDOWN_FILE:
               d[i].igs = -igs;
               d[i].vgs = (vds - ids*fixed_params.rd) -
                  (vgs - igs*fixed_params.rg);
               ++i;
               break;
               
            default:
               break;
            }
         }
      }
   fclose (file);
   
   return i;
   }

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, double periph, IV_DATA *dc, unsigned n_dc, AC_PARAMETERS *ac, unsigned n_ac,
                      OPT_PARAMETER *params, IV_DATA *fwd, unsigned n_fwd, IV_DATA *vbr, unsigned n_vbr,
                      FIXED_PARAMETERS fixed)
   {
   jPLOT_ITEM *plot1,*plot2,*plot3;
   unsigned i,j;
   static char *legend_t[] = {"Modeled","Measured"};
   static int  legend_l[] = {LT_SOLID,LT_DASHED};
   static int  legend_w[] = {1,1};
   static int  legend_c[] = {CLR_RED,CLR_BLUE};
   double p_list[NUM_PARAMS];
   char *plotfile;
   double *xdata1,*xdata2,*ymeas1,*ymeas2,*ymod1,*ymod2;   
   unsigned option_flags = 0;
   double vds;
   
   plot1 = create_plot_item (SingleY,2.5,1.1,5.5,4.5);
   plot2 = create_plot_item (SingleY,1.3,1.1,3.7,3.7);
   plot3 = create_plot_item (SingleY,6.3,1.1,3.7,3.7);
   
   deactivate_plot_item (plot2);
   deactivate_plot_item (plot3);
   
   set_axis_scales (plot1,NULL,POSITIVE_X | POSITIVE_Y1);
   set_axis_scales (plot2,NULL,POSITIVE_X | POSITIVE_Y1);
   set_axis_scales (plot3,NULL,POSITIVE_X | POSITIVE_Y1);
   
   plot2->attribs.ylabel_offset = 0.6;
   plot3->attribs.ylabel_offset = 0.6;
      
   for (i = 0; i < NUM_PARAMS; ++i)
      p_list[i] = params[i].nom;
   
   switch (dev)
      {
      case POSTSCRIPT:
         plotfile = "tom3.ps";
         break;
      
      case METAFILE:
         plotfile = "tom3.wmf";
         break;
      
      default:
         plotfile = NULL;   
      }

   // add_text (header,5.5,7.9,FNT_TIMES,12,0.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_legend (2,8.0,6.5,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);
   
   if (!open_graphics_device (dev, plotfile))
      {
      printf ("open_graphics_device() failed\n");
      return -1;
      }
   
   /************ plot IV curves ****************/
   
   xdata1 = (double *) malloc (sizeof (double) * n_dc);
   ymeas1 = (double *) malloc (sizeof (double) * n_dc);
   ymod1  = (double *) malloc (sizeof (double) * n_dc);
   
   for (i = 0; i < n_dc; ++i)
      {
      xdata1[i] = dc[i].vds;
      ymeas1[i] = dc[i].ids * 1.0e6 / periph;
      ymod1[i] = tom3_ids (p_list, dc[i].vgs, dc[i].vds) * 1.0e6 / periph;
      }
   
   attach_y1data (plot1, xdata1, ymod1, n_dc, LT_SOLID, 1, CLR_RED);
   attach_y1data (plot1, xdata1, ymeas1, n_dc, LT_DASHED, 1, CLR_BLUE);
   
   set_axis_labels (plot1, "Vds (volts)", "Ids (mA/mm)", "", "IV Curves");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   detach_data (plot1);
   
   free ((void *) xdata1);
   free ((void *) ymeas1);   
   free ((void *) ymod1);
   
   /************ plot sub-threshold current *******/

   xdata1 = (double *) malloc (sizeof (double) * n_dc);
   ymeas1 = (double *) malloc (sizeof (double) * n_dc);
   ymod1  = (double *) malloc (sizeof (double) * n_dc);
   
   for (j = 0, vds = 1.0; vds < 10.1; vds += 1.0)
      {
      for (i = 0; i < n_dc; ++i)
         {
         if ((fabs (dc[i].vds - vds) < 0.09) && (dc[i].ids > 0.0) && (dc[i].ids < 5.0e-6*periph))
            {
            xdata1[j] = dc[i].vgs;
            ymeas1[j] = dc[i].ids * 1.0e6 / periph;
            ymod1[j] = tom3_ids (p_list, dc[i].vgs, dc[i].vds) * 1.0e6 / periph;
            ++j;
            }
         }
      }
   
   attach_y1data (plot1, xdata1, ymod1, j, LT_SOLID, 1, CLR_RED);
   attach_y1data (plot1, xdata1, ymeas1, j, LT_DASHED, 1, CLR_BLUE);
   
   set_axis_labels (plot1, "Vgs (volts)", "Ids (mA/mm)", "", "Subthreshold Curves");
   set_axis_scaling (plot1, LogY1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   deactivate_plot_item (plot1);
   
   free ((void *) xdata1);
   free ((void *) ymeas1);   
   free ((void *) ymod1);   
   
   /************ plot diode curves ****************/

   activate_plot_item (plot2);
   activate_plot_item (plot3);
   
   xdata1 = (double *) malloc (sizeof (double) * n_fwd);
   ymeas1 = (double *) malloc (sizeof (double) * n_fwd);
   ymod1  = (double *) malloc (sizeof (double) * n_fwd);
   xdata2 = (double *) malloc (sizeof (double) * n_vbr);
   ymeas2 = (double *) malloc (sizeof (double) * n_vbr);
   ymod2  = (double *) malloc (sizeof (double) * n_vbr);
   
   for (i = 0; i < n_fwd; ++i)
      {
      xdata1[i] = fwd[i].vgs;
      ymeas1[i] = fwd[i].igs * 1.0e6 / periph;
      ymod1[i] =  2.0 * fixed.is * (exp (fwd[i].vgs * CHARGE / (fixed.n * BOLTZ * (fixed.tnom + 273.0))) - 1.0) * 1.0e6 / periph;
      }

   for (i = 0; i < n_vbr; ++i)
      {
      xdata2[i] = vbr[i].vgs;
      ymeas2[i] = vbr[i].igs * 1.0e6 / periph;
      ymod2[i] =  fixed.ibd * (exp (vbr[i].vgs / fixed.vbd) - 1.0) * 1.0e6 / periph;
      }
         
   attach_y1data (plot2, xdata1, ymod1, n_fwd, LT_SOLID, 1, CLR_RED);
   attach_y1data (plot2, xdata1, ymeas1, n_fwd, LT_DASHED, 1, CLR_BLUE);
   attach_y1data (plot3, xdata2, ymod2, n_vbr, LT_SOLID, 1, CLR_RED);
   attach_y1data (plot3, xdata2, ymeas2, n_vbr, LT_DASHED, 1, CLR_BLUE);
      
   set_axis_labels (plot2, "Vg (volts)", "Ig (mA/mm)", "", "Gate Forward");
   set_axis_labels (plot3, "Vdg (volts)", "Idg (mA/mm)", "", "Gate-Drain Breakdown");
   
   set_axis_scaling (plot2, LogY1);
   set_axis_scaling (plot3, LogY1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed\n");
      close_graphics_device ();
      return -1;
      }  
   
   free ((void *) xdata1);
   free ((void *) ymeas1);   
   free ((void *) ymod1);
   free ((void *) xdata2);
   free ((void *) ymeas2);   
   free ((void *) ymod2);
   
   /*************** done ****************/
   
   close_graphics_device ();
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int a_x_b (double *a, double *x, double *b, int n)
   {
   double y[10];
   double z[10][10];
   double tempd;
   double tempd2;
   double max;
   int pointer[10];
   int tempi;
   int i,j,k;
   int col,row;
   
   if (n > 10)
      {
      fprintf (stderr, "Error: a_x_b () - matrix is too large.\n");
      return -1;
      }
   
   for (i = 0; i < n; ++i)
      {
      y[i] = b[i];
      pointer[i] = i;
      for (j = 0; j < n; ++j)
         z[i][j] = a[i*n+j];
      }
   
   /* invert the matrix */
   for (k = 0; k < n-1; ++k)
      {
      /* find max */
      max = 0.0;
      for (i = k; i < n; ++i)
         {
         for (j = k; j < n; ++j)
            {
            if (fabs (z[i][j]) > max)
               {
               row = i;
               col = j;
               max = fabs (z[i][j]);
               }
            }
         }
      
      /* rotate rows */
      if (row != k)
         {
         for (j = 0; j < n; ++j)
            {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
            }
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
         }
      
      /* rotate columns */ 
      if (col != k)
         {
         for (i = 0; i < n; ++i)
            {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
            }
         tempi = pointer[k];
         pointer[k] = pointer[col];
         pointer[col] = tempi;
         }
      
      /* gaussian elimination */
      tempd = z[k][k];
      for (i = k+1; i < n; ++i)
         {
         tempd2 = z[i][k]/tempd;
         y[i] -= tempd2*y[k];
         for (j = k; j < n; ++j)
            {
            z[i][j] -= tempd2*z[k][j];
            }
         }
      }  
   
   if (fabs (z[n-1][n-1]) < 1.0e-24)
      {
      fprintf (stderr, "Error: a_x_b () - singular matrix during inversion.\n");
      return -1;
      }
   
   /* back substitution */
   x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
   for (k = n-2; k > -1; --k)
      {
      tempd = y[k];
      for (i = n-1; i > k; --i)
         {
         tempd -= z[k][i]*x[pointer[i]];
         }
      x[pointer[k]] = tempd/z[k][k];
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_fit (IV_DATA *iv, int k, double *is, double *n, double *rd)
   {
#define MAX_DIODE_SIZE   100
   double a1[3][MAX_DIODE_SIZE];
   double a2[MAX_DIODE_SIZE][3];
   double b1[MAX_DIODE_SIZE];
   double a[3][3];
   double b[3];
   double x[3];
   double sum;
   int i,j;
   int npts = 0;

   for (i = 0; i < k; ++i)
      {
      if ((iv[i].vgs <= 0.0) || (iv[i].igs <= 0.0))
         continue;

      if (i >= MAX_DIODE_SIZE)
         break;
      
      a2[npts][0] = log (iv[i].igs);
      a2[npts][1] = -1.0;
      a2[npts][2] = iv[i].igs;
      b1[npts] = iv[i].vgs;
      a1[0][npts] = a2[npts][0];
      a1[1][npts] = a2[npts][1];
      a1[2][npts] = a2[npts][2];
      ++npts;
      }
   
   if (npts < 3)
      {
      fprintf (stderr, "Error: not enough points for diode fit.\n");
      return -1;
      }
      
   for (i = 0; i < 3; ++i)
      {
      for (j = 0; j < 3; ++j)
         {
         sum = 0.0;
         for (k = 0; k < npts; ++k)
            sum += a1[i][k]*a2[k][j];
         
         a[i][j] = sum;
         }

      sum = 0.0;
      for (j = 0; j < npts; ++j)
         sum += a1[i][j]*b1[j];
      
      b[i] = sum;
      }
      
   if (a_x_b ((double *) a, x, b, 3))
      return -1;
   
   *n = x[0]*CHARGE/(BOLTZ*STDTEMP);
   *is = exp (x[1]/x[0]);
   *rd = x[2];
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2)
   {
   int i;
   double xsum = 0.0;
   double ysum = 0.0;
   double xxsum = 0.0;
   double yysum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 1)
      {
      *m = 0.0;
      *b = 0.0;
      *r2 = 0.0;
      return;
      }

   for (i = 0; i < n; ++i)
      {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
      }

   *m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
   *b  = (xxsum*ysum - xysum*xsum) / (xxsum*((double) n) - xsum*xsum);
   // *r2 = xysum*xysum / (xxsum*yysum);

   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] + (*b) - y[i])*((*m)*x[i] + (*b) - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_fit_no_rd (IV_DATA *iv, int k, double *is, double *n)
   {
#define MAX_DIODE_SIZE   100
   double vd[MAX_DIODE_SIZE];
   double id[MAX_DIODE_SIZE];
   double x[3];
   double m,b,rsq;
   int i;
   int npts = 0;

   for (i = 0; i < k; ++i)
      {
      if ((iv[i].vgs <= 0.0) || (iv[i].igs <= 0.0))
         continue;
      else if (iv[i].vgs < 0.5*iv[k-1].vgs)
         continue;

      if (i >= MAX_DIODE_SIZE)
         break;
         
      vd[npts] = iv[i].vgs;
      id[npts] = log (iv[i].igs);
      
      ++npts;
      }
   
   if (npts < 2)
      {
      fprintf (stderr, "Error: not enough points for diode fit.\n");
      return -1;
      }
   
   linefit_mxb (vd, id, npts, &m, &b, &rsq);
   
   *n = CHARGE/(m*BOLTZ*STDTEMP);
   *is = exp (b);
   
   return 0;
   }
   
   
   
   
