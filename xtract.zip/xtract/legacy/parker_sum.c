#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MAX_PARAMETERS   (12)
#define MAX_MODELS       (50)

struct model_head
{
char   device[20];
char   mask[20];
char   process[20];
char   name[20];
char   directory[20];
char   g2gspace[20];
char   wafer[20];
double s2dspace;
double temperature;
double p[MAX_PARAMETERS];
};

static struct model_head head[MAX_MODELS];

main ()
   {
   FILE  *file_list;
   FILE  *sum_file;
   char  buffer[2500];
   char  string[80];
   char  tmp_name[256];
   char  *pointer;
   char  *string_pointer;
   char  file_names[80];
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];
   char  junk;
   int   i,j,n,counter;
   time_t mytime;

   printf ("\n");
   printf ("Parker Model files to summarize?\n");
   scanf ("%79s",file_names);
   
   sprintf (tmp_name,"tmp.%d",time(&mytime));
   sprintf (buffer,"rm -f %s",tmp_name);
   system (buffer);
   sprintf (buffer,"cat %s > %s",file_names,tmp_name);
   system (buffer);

   sum_file = fopen ("model.parker","w+");

   string_pointer = asctime (localtime (&mytime));
   sscanf (string_pointer+8,"%s",s_day);
   sscanf (string_pointer+4,"%s",s_month);
   sscanf (string_pointer+20,"%s",s_year);
   sscanf (string_pointer+11,"%s",s_time);
   sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

   fprintf (sum_file,"!\n");
   fprintf (sum_file,"! FET PARKER MODEL PROGRAM VERSION 1.00 %s\n",string);
   fprintf (sum_file,"!\n");

   file_list = fopen (tmp_name,"r");

   n = 0;
   while (fgets (buffer,1024,file_list) != NULL)
      {
      if (strncmp (buffer,"!FILE NAME:",11) == 0)
         sscanf (buffer,"!FILE NAME: %19s",head[n].device);
      else if (strncmp (buffer,"!MASK NAME:",11) == 0)
         sscanf (buffer,"!MASK NAME: %19s",head[n].mask);
      else if (strncmp (buffer,"!PROCESS NAME:",14) == 0)
         sscanf (buffer,"!PROCESS NAME: %19s",head[n].process);
      else if (strncmp (buffer,"!WAFER NUMBER:",14) == 0)
         sscanf (buffer,"!WAFER NUMBER: %19s",head[n].wafer);
      else if (strncmp (buffer,"!DEVICE NAME:",13) == 0)
         sscanf (buffer,"!DEVICE NAME: %19s",head[n].name);
      else if (strncmp (buffer,"!GATE PERIPHERY (um):",21) == 0)
         sscanf (buffer,"!GATE PERIPHERY (um): %lf",&head[n].p[0]);
      else if (strncmp (buffer,"!GATE LENGTH (um):",18) == 0)
         sscanf (buffer,"!GATE LENGTH (um): %lf",&head[n].p[3]);
      else if (strncmp (buffer,"!UNIT GATE WIDTH (um):",22) == 0)
         sscanf (buffer,"!UNIT GATE WIDTH (um): %lf",&head[n].p[1]);
      else if (strncmp (buffer,"!NUMBER OF GATE FINGERS:",24) == 0)
         sscanf (buffer,"!NUMBER OF GATE FINGERS: %lf",&head[n].p[2]);
      else if (strncmp (buffer,"!GATE TO GATE SPACING (um):",27) == 0)
         sscanf (buffer,"!GATE TO GATE SPACING (um): %19s",head[n].g2gspace);
      else if (strncmp (buffer,"!SOURCE-DRAIN SPACING (um):",27) == 0)
         sscanf (buffer,"!SOURCE-DRAIN SPACING (um): %lf",&head[n].s2dspace);
      else if (strncmp (buffer,"!TEMPERATURE (C):",17) == 0)
         sscanf (buffer,"!TEMPERATURE (C): %lf",&head[n].temperature);
      else if (strncmp (buffer,"!Vbr",4) == 0)
         {
         fgets (buffer,1024,file_list);
         sscanf (buffer, "%c%lf%lf%lf%lf%lf%lf%lf",&junk,&head[n].p[4],&head[n].p[5],&head[n].p[6],&head[n].p[7],&head[n].p[8],&head[n].p[9],&head[n].p[10]);
         head[n].p[6] = head[n].p[6]*((double) 1.0e3)/(head[n].p[0]*((double) 1.0e-3));
         head[n].p[8] = head[n].p[8]*((double) 1.0e3)/(head[n].p[0]*((double) 1.0e-3));
         ++n;
         }
      }
      
   fprintf (sum_file,"!PROCESS NAME: %s\n",head[n-1].process);
   fprintf (sum_file,"!DEVICE NAME: %s\n",head[n-1].name);
   fprintf (sum_file,"!GATE PERIPHERY (um): %.1f\n",head[n-1].p[0]);
   fprintf (sum_file,"!GATE LENGTH (um): %.3f\n",head[n-1].p[3]);
   fprintf (sum_file,"!UNIT GATE WIDTH (um): %.1f\n",head[n-1].p[1]);
   fprintf (sum_file,"!NUMBER OF GATE FINGERS: %.0f\n",head[n-1].p[2]);
   fprintf (sum_file,"!GATE TO GATE SPACING (um): %s\n",head[n-1].g2gspace);
   fprintf (sum_file,"!SOURCE-DRAIN SPACING (um): %.1f\n",head[n-1].s2dspace);
   fprintf (sum_file,"!TEMPERATURE (C): %.1f\n",head[n-1].temperature);
   fprintf (sum_file,"!Model\tDev\tmask\tlot\tTemp\tVbr(.1mA)\tVbr(1mA)\tIdss(3V)\tVpo(3V)\t\tImax(1.5V)\tVpo(1.5V)\tVmax(1.5V)\n");
   fprintf (sum_file,"!\t\t\t\t(C)\t(V)\t\t(V)\t\t(mA/mm)\t\t(V)\t\t(mA/mm)\t\t(V)\t\t(V)\n");

   for(counter = 0;counter < n; ++counter)
      {
      fprintf (sum_file,"!%d\t%c%c%c%c\t%s\t%s\t%.1f\t",counter+1,head[counter].device[1],head[counter].device[2],head[counter].device[3],head[counter].device[4],head[counter].mask,head[counter].wafer,head[counter].temperature);
      for (j = 4; j < 11; ++j)
         {
         fprintf (sum_file,"%.3f\t\t",head[counter].p[j]);
         }
      fprintf (sum_file,"\n");
      }
   fprintf (sum_file,"!\n");

   fflush (sum_file);
   
   counter = 1;
   rewind (file_list);
   while (fgets (buffer,1024,file_list) != NULL)
      {
      if (sscanf (buffer,"model = %d",&j) == 1)
         {
         for (j = strlen(buffer); j > -1; --j)
            {
            if (buffer[j] == '=')
               break;
            }
         
         for (i = 0; i <= j; ++i)
             string[i] = buffer[i];
         
         string[j+1] = 0;
        
         fprintf (sum_file,"%s  %d\n",string,counter);
         ++counter;
         }
      else
         fprintf (sum_file,"%s",buffer);
      }

   fclose (file_list);
   fclose (sum_file);
   
   sprintf (buffer,"rm -f %s",tmp_name);
   system (buffer);   

   system ("wait");
   printf("Complete!\n");
   }
