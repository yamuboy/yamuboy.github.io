#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "cmplxlib.h"
#include "ss_tools2.h"
#include "fit_tools.h"

#define N_FREQS     1000
#define PI          3.141592653589

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *lfile, *ofile;
   char files[256];
   char string[256];
   char tmpfile_name[256];
   char outfile_name[256];
   char fname[256];
   double start, stop;
   time_t tbuf;
   S_2PORT s2p[N_FREQS];
   unsigned nsp, i, j;
   COMPLEX yp[4];
   double y[N_FREQS], w[N_FREQS];
   double cval, r2;
   
   printf ("Files?\n");
   fgets (files, 255, stdin);
   files[strlen(files)-1] = 0;
   
   printf ("Frequency range in GHz (start stop)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf%lf", &start, &stop);
   start *= 1.0e9;
   stop *= 1.0e9;
   
   printf ("Output file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", outfile_name);
   
   /**** create and open the file list ****/

   sprintf (tmpfile_name, "tmp.%d", time(&tbuf));
   sprintf (string, "rm -f %s", tmpfile_name);
   system (string);
   sprintf (string, "ls -1d %s > %s", files, tmpfile_name);
   system (string);

   lfile = fopen (tmpfile_name, "r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }
   
   /* open the output file */
   ofile = fopen (outfile_name, "w+");
   if (!ofile)
      {
      printf ("Error: unable to write to disc.\n");
      return 1;
      }
   
   getcwd (string, 255);
   fprintf (ofile, "! Directory: %s\n!\n", string);
   fprintf (ofile, "!Filename            C(pF)     R^2\n");
   
   /**** loop through the directory list ****/

   while (fgets (fname, 255, lfile))
      {
      fname[strlen(fname)-1] = 0;
      
      nsp = read_s_from_file (fname, s2p, NULL, N_FREQS);
      if (nsp < 1)
         {
         printf ("%s :error reading file.\n", fname);
         continue;
         }
         
      for (i = 0, j = 0; i < nsp; ++i)
         {
         if (s2p[i].freq < start)
            continue;
         else if (s2p[i].freq > stop)
            break;
      
         s2y(s2p[i].s, yp, 50.0);
         w[j] = 2.0*PI*s2p[i].freq;
         y[j] = -0.5*(yp[1].i + yp[2].i);
         ++j;
         }
      
      if (j < 1)
         {
         printf ("%s: not enough points.\n", fname);
         continue;
         }
         
      linefit_mx0 (w, y, j, &cval, &r2);
      
      fprintf (ofile, "%-20s %6.3f %6.4f\n", fname, cval*1.0e12, r2);
      }
      

   fclose (lfile);

   sprintf (string, "rm -f %s", tmpfile_name);
   system (string);

   return 0;
   }
   
