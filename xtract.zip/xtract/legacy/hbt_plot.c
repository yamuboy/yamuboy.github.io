#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"

main (int argc, char *argv[])
   {
   int     i,device;
   char    file_name[80],out_name[80],string[256];
   char    head1[2048],head2[2048],head3[512];
   double  t1,t2,xdata[2000],y1data[2000],y2data[2000];
   FILE    *infile;
   jPLOT_ITEM *plot1;

   file_name[0] = 0;
   out_name[0]  = 0;
   device = 0;

   // parse command line
   for (i = 1; i < argc; ++i)
      {
      }

   if (!file_name[0])
      {
      printf ("Filename?\n> ");
      fgets (string,255,stdin);
      sscanf (string,"%79s",file_name);
      }

   if (device < 1)
      {
      printf ("Graphics Device?\n 1: X-Windows\n 2: Postscript\n 3: Metafile\n\n> ");
      fgets (string,255,stdin);
      if (sscanf (string,"%lf%lf",&t1,&t2) == 2)
         {
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         sscanf (string,"%79s",out_name);
         fgets (string,255,stdin);
         i = 0;
         sscanf (string,"%d",&i);
         if (i == 10)
            device = 2;
         else if (i == 11)
            device = 1;
         else if (i == 12)
            device = 3;
         }
      else
         sscanf (string,"%d",&device);
      }

   if ((device < 1) || (device > 3))
      {
      printf ("INVALID GRAPHICS DEVICE.\n");
      return -1;
      }

   if ((device != 1) && !out_name[0])
      {
      printf ("Plot file name?\n> ");
      fgets (string,255,stdin);
      sscanf (string,"%79s",out_name);
      }

   infile = fopen (file_name,"r");
   if (!infile)
      {
      printf ("UNABLE TO OPEN FILE - %s\n",file_name);
      return -1;
      }

   if (!open_graphics_device (device,out_name))
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   plot1 = create_plot_item (SingleY,3.0,1.5,5.0,4.0);

   /*****************  HEADER  ******************/

   head1[0] = head2[0] = head3[0] = 0;
   for (i = 0; i < 6; ++i)
      {
      fgets (string,255,infile);
      strcat (head1,&string[1]);
      }

   for (i = 0; i < 5; ++i)
      {
      fgets (string,255,infile);
      strcat (head2,&string[1]);
      }

   while (fgets (string,255,infile))
      {
      if (strstr (string,"DC BJT PARAMETERS"))
         {
         fgets (string,255,infile);
         strcat (head3,&string[1]);
         fgets (string,255,infile);
         strcat (head3,string);
         }
      }

   add_text (head1,2.5,7.8,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
   add_text (head2,7.0,7.8,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
   add_text (head3,1.5,5.5,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);

   /*****************  IV CURVES  ******************/
   
   while (fgets (string,255,infile))
      {
      if (strstr (string,"DC IV-CURVES"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&xdata[i],&y1data[i],&t1,&t2) == 4)
         {
         y1data[i] *= 1000.0;
         ++i;
         }
      }

   attach_y1data (plot1,xdata,y1data,i,LT_SOLID,2,CLR_RED);

   set_axis_scaling (plot1,POSITIVE_X | POSITIVE_Y1);

   set_axis_labels (plot1,"Vce (volts)","Ice (mA)",NULL,"I-V Curves");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  FWD GUMMELS  ******************/

   detach_data (plot1);
   rewind (infile);

   while (fgets (string,255,infile))
      {
      if (strstr (string,"FORWARD GUMMEL CURVES"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&xdata[i],&y1data[i],&t1,&y2data[i]) == 4)
         {
         y1data[i] = fabs (y1data[i]);
         y2data[i] = fabs (y2data[i]);
         ++i;
         }
      }

   attach_y1data (plot1,xdata,y1data,i,LT_SOLID,2,CLR_RED);
   attach_y1data (plot1,xdata,y2data,i,LT_SOLID,2,CLR_RED);

   set_axis_scaling (plot1,LogY1);

   set_axis_labels (plot1,"Vbe/Vce (volts)","Ibe/Ice (mA)",NULL,"Forward Gummel Curves");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  REV GUMMELS  ******************/

   detach_data (plot1);
    
   do {
      if (strstr (string,"REVERSE GUMMEL CURVES"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }
   while (fgets (string,255,infile));

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&xdata[i],&y1data[i],&t1,&y2data[i]) == 4)
         {
         xdata[i]  = -xdata[i];
         y1data[i] = fabs (y1data[i]);
         y2data[i] = fabs (y2data[i]);
         ++i;
         }
      }

   attach_y1data (plot1,xdata,y1data,i,LT_SOLID,2,CLR_RED);
   attach_y1data (plot1,xdata,y2data,i,LT_SOLID,2,CLR_RED);

   set_axis_labels (plot1,"Vbc/Vec (volts)","Ibc/Iec (mA)",NULL,"Reverse Gummel Curves");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  EMITTER RES  ******************/

   detach_data (plot1);
   set_axis_scaling (plot1,LinearAll);

   do {
      if (strstr (string,"RE FLYBACK CURVE"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }
   while (fgets (string,255,infile));

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&y1data[i],&t1,&t2,&xdata[i]) == 4)
         {
         xdata[i] *= 1000.0;
         ++i;
         }
      }

   attach_y1data (plot1,xdata,y1data,i,LT_SOLID,2,CLR_RED);

   set_axis_labels (plot1,"Ibe (mA)","Vce (volts)",NULL,"Emitter Resistance Flyback");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  DONE PLOTS  ******************/

   close_graphics_device ();
   fclose (infile);

   return 0;
   }



