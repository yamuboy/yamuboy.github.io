#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <jbsort.h>

#define NUM_PARAMETERS  30

struct header_def
   {
   char site_num[10];
   char mask[50],wafer[50];
   double periphery,ugw,ngf,temperature;
   double vbrlo,vbrhi,idss,vpo1,imax,vpo2,vmax,vpo3;
   };

static char *get_the_time (char *str);

/*******************************************************************************************/
/*******************************************************************************************/

int main (int argc, char *argv[])
   {
   double **param;
   char **site_num,**device_order;
   struct header_def head[50];
   FILE *file_list,*file,*s_file,*end_file,*rpc_file;
   char buffer[256],string[256],s_filename[256],last_file[256],rpc_filename[256];
   char end_filename[256],process[50],device[50],g2g_spacing[50];
   double gate_length,sd_spacing;

   int new_device_flag = 0; 
   int n = 0;
   int mem_sz = 0;
   int num_devices = 0;
   int first = 1;
   int i,j;

   // parameter stuff
   static char *labels[] = {"  Periphery ", "     ugw    ", "     ngf    ", "     Vds    ", "     Ids    ",
                            "    mA_mm   ", "     Vgs    ", "     Igs    ", "     Rg     ", "     Rs     ",
                            "     Rd     ", "     Ri     ", "     Cgs    ", "     Cdg    ", "     Cds    ",
                            "     C1     ", "     C2     ", "     Ls     ", "     Lg     ", "     Ld     ",
                            "     Ggs    ", "     Gdg    ", "     Gm     ", "     T1     ", "     Gds    ",
                            "     T2     ", "     C11    ", "     C22    ", "     vv     ", "     ii     "};
   static double factors[] = {1.0e-03, 1.0e+00, 1.0e+00, 1.0e+00, 1.0e+03,
                              1.0e+06, 1.0e+00, 1.0e+03, 1.0e+00, 1.0e+00,
                              1.0e+00, 1.0e+00, 1.0e+12, 1.0e+12, 1.0e+12,
                              1.0e+12, 1.0e+12, 1.0e+12, 1.0e+12, 1.0e+12,
                              1.0e+03, 1.0e+03, 1.0e+03, 1.0e+12, 1.0e+03,
                              1.0e+12, 1.0e+12, 1.0e+12, 1.0e+00, 1.0e+00};
   // sorting stuff
   static int order[] = {1,2,3};
   static int types[] = {STRING_TYPE, DOUBLE_TYPE, DOUBLE_TYPE};
   JB_SORT_VALUES sort_val[3];
   JB_SORT_STRUCT *sort = NULL, *ptr;

   printf ("\n");
   printf ("S-Parameter files to summarize?\n");
   fgets (string,255,stdin);
   string[strlen(string)-1] = 0;

   sprintf (buffer, "ls -1 %s > model_files.list",string);
   system (buffer);

   file_list = fopen ("model_files.list","r");
   if (!file_list)
      {
      printf ("Error opening file list.\n");
      return -1;
      }

   /* determine the number of data files and allocate memory */

   while (fgets (buffer,255,file_list))
      ++mem_sz;

   if (mem_sz < 1)
      {
      fprintf (stderr,"ERROR: no matching files were found.\n");
      return -1;
      }

   param = (double **) malloc (sizeof (double *) * mem_sz);
   for (i = 0; i < mem_sz; ++i)
      param[i] = (double *) malloc (sizeof (double) * NUM_PARAMETERS);
   site_num = (char **) malloc (sizeof (char *) * mem_sz);
   rewind (file_list);

   /* read in all the data */

   last_file[0] = 0;
   while (fgets (s_filename,255,file_list))
      {
      s_filename[strlen (s_filename)-1] = 0;
      sscanf (s_filename,"%[^.]",end_filename);
      strcpy (rpc_filename,end_filename);
      strcat (end_filename,".end");
      strcat (rpc_filename,".rpc");

      s_file = fopen (s_filename,"r");
      if (!s_file)
         continue;

      end_file = fopen (end_filename,"r");
      if (!end_file)
         {
         fclose (s_file);
         continue;
         }

      rpc_file = fopen (rpc_filename,"r");
      if (!rpc_file)
         {
         fclose (s_file);
         fclose (end_file);
         continue;
         }

      while (fgets (buffer,255,s_file))
         {
         if (sscanf (buffer,"!FILE NAME: %255s",string) == 1)
            {
            if (strcmp (string,last_file))
               {
               sprintf (head[num_devices].site_num,"%c%c%c%c",string[1],string[2],string[3],string[4]);
               printf ("Device %s ....\n",head[num_devices].site_num);

               new_device_flag = 1;
               strcpy (last_file,string);
               ++num_devices;
               }
            }
         else if (!strncmp (buffer,"!BIAS:",6))
            {
            sscanf (buffer,
               "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
               &param[n][3],&param[n][4],&param[n][6],&param[n][7]);

            break;
            }
         }

      // only need to read the rest of the stuff in the file if it is a new device
      if (new_device_flag)
         {
         rewind (s_file);

         while (fgets (buffer,255,s_file))
            {
            if (!strncmp (buffer,"!MASK NAME:",11))
               sscanf (buffer,"!MASK NAME: %49s",head[num_devices-1].mask);
            else if (!strncmp (buffer,"!WAFER NUMBER:",14))
               sscanf (buffer,"!WAFER NUMBER: %49s",head[num_devices-1].wafer);
            else if (!strncmp (buffer,"!GATE PERIPHERY (um):",21))
               sscanf (buffer,"!GATE PERIPHERY (um): %lf",&head[num_devices-1].periphery);
            else if (!strncmp (buffer,"!UNIT GATE WIDTH (um):",22))
               sscanf (buffer,"!UNIT GATE WIDTH (um): %lf",&head[num_devices-1].ugw);
            else if (!strncmp (buffer,"!NUMBER OF GATE FINGERS:",24))
               sscanf (buffer,"!NUMBER OF GATE FINGERS: %lf",&head[num_devices-1].ngf);
            else if (!strncmp (buffer,"!TEMPERATURE (C):",17))
               sscanf (buffer,"!TEMPERATURE (C): %lf",&head[num_devices-1].temperature);
            else if (!strncmp (buffer,"!Vbr",4))
               {
               fgets (buffer,255,s_file);
               sscanf (buffer, "!%lf%lf%lf%lf%lf%lf%lf%lf",
                  &head[num_devices-1].vbrlo,&head[num_devices-1].vbrhi,
                  &head[num_devices-1].idss,&head[num_devices-1].vpo1,
                  &head[num_devices-1].imax,&head[num_devices-1].vpo2,
                  &head[num_devices-1].vmax,&head[num_devices-1].vpo3);

               // scale to mA/mm
               head[num_devices-1].idss *= 1.0e6/head[num_devices-1].periphery;
               head[num_devices-1].imax *= 1.0e6/head[num_devices-1].periphery;
               break;
               }

            // only need to read these values once
            if (first)
               {
               if (!strncmp (buffer,"!PROCESS NAME:",14))
                  sscanf (buffer,"!PROCESS NAME: %49s",process);
               else if (!strncmp (buffer,"!DEVICE NAME:",13))
                  sscanf (buffer,"!DEVICE NAME: %49s",device);
               else if (!strncmp (buffer,"!GATE LENGTH (um):",18))
                  sscanf (buffer,"!GATE LENGTH (um): %lf",&gate_length);
               else if (!strncmp (buffer,"!GATE TO GATE SPACING (um):",27))
                  sscanf (buffer,"!GATE TO GATE SPACING (um): %49s",g2g_spacing);
               else if (!strncmp (buffer,"!SOURCE-DRAIN SPACING (um):",27))
                  sscanf (buffer,"!SOURCE-DRAIN SPACING (um): %lf",&sd_spacing);
               }
            }

         new_device_flag = 0;
         first = 0;
         }

      site_num[n] = head[num_devices-1].site_num;
      param[n][0] = head[num_devices-1].periphery;
      param[n][1] = head[num_devices-1].ugw;
      param[n][2] = head[num_devices-1].ngf;
      param[n][5] = param[n][4]/param[n][0];  // Ids in mA/mm

      // read in parameter values from the END file
      for (i = 8; i < NUM_PARAMETERS-2; ++i)
         {
         fgets (buffer,255,end_file);
         sscanf (buffer,"%*f %lf",&param[n][i]);
         }

      // read in noise parameters from the RPC file
      while (fgets (buffer,255,rpc_file))
         {
         if (sscanf (buffer, "%*f %*f %*f %*f %*f %*f %*f %*f %*f %lf %lf,
            &params[n][28], &params[n][29]) == 2)
            break;
         }

      // scale all of the parameters
      for (i = 0; i < NUM_PARAMETERS; ++i)
         param[n][i] *= factors[i];

      // increment the parameter counter
      ++n;

      fclose (s_file);
      fclose (end_file);
      fclose (rpc_file);
      }

   fclose (file_list);
   system ("rm -f model_files.list");

   if ((n < 1) || (num_devices < 1))
      {
      fprintf (stderr,"ERROR: no data.\n");
      for (i = 0; i < mem_sz; ++i)
         free ((void *) param[i]);
      free ((void *) param);
      free ((void *) site_num);
      }

   /* set up the sorting list */

   for (i = 0; i < n; ++i)
      {
      sort_val[0].strg = site_num[i];
      sort_val[1].dval = &param[i][3];
      sort_val[2].dval = &param[i][6];

      sort = append_sorting_list (3, types, i, sort, sort_val);
      }

   /* perform the sorting procedure */

   sort = sort_data (sort, order, types, 3);

   /* write the sorted DSCR data to the file */

   file = fopen ("model.dscr","w+");

   fprintf (file,"!PROCESS NAME: %s\n",process);
   fprintf (file,"!DEVICE NAME: %s\n",device);
   fprintf (file,"!GATE PERIPHERY (um): %.1f\n",head[0].periphery);
   fprintf (file,"!GATE LENGTH (um): %.3f\n",gate_length);
   fprintf (file,"!UNIT GATE WIDTH (um): %.1f\n",head[0].ugw);
   fprintf (file,"!NUMBER OF GATE FINGERS: %.0f\n",head[0].ngf);
   fprintf (file,"!GATE TO GATE SPACING (um): %s\n",g2g_spacing);
   fprintf (file,"!SOURCE-DRAIN SPACING (um): %.1f\n",sd_spacing);
   fprintf (file,"!TEMPERATURE (C): %.1f\n!\n",head[0].temperature);
   fprintf (file,"!Model Dev  Mask     Lot              Temp  Periphery UGW   NGF Vbr(.1mA) Vbr(1mA) Idss(3V) Vpo(3V) Imax(1.5V) Vpo(1.5V) Vmax(1.5V) Vpo(1mA/mm)\n");
   fprintf (file,"!                                     (C)     (um)    (um)         (V)      (V)    (mA/mm)   (V)     (mA/mm)      (V)       (V)        (V)\n");

   device_order = (char **) malloc (sizeof (char *)*num_devices);
   device_order[0] = site_num[sort->position];
   i = 1;
   for (ptr = sort; ptr; ptr = ptr->next)
      {
      if (strcmp (site_num[ptr->position],device_order[i-1]))
         {
         device_order[i] = site_num[ptr->position];
         ++i;
         }
      }

   if (i > num_devices)
      printf ("error in header write.\n");

   for (i = 0; i < num_devices; ++i)
      {
      for (j = 0; j < num_devices; ++j)
         {
         if (!strcmp (device_order[i],head[j].site_num))
            {
            fprintf (file,"!%-5d %s %-8s %-15s %5.1f   %6.1f %6.2f %3d   %7.3f  %7.3f   %6.1f  %6.3f   %6.1f    %6.3f     %6.3f     %6.3f\n",
               i+1, head[i].site_num, head[i].mask, head[i].wafer, head[i].temperature,
               head[i].periphery, head[i].ugw, (int) head[i].ngf, head[i].vbrlo,
               head[i].vbrhi, head[i].idss, head[i].vpo1, head[i].imax, head[i].vpo2,
               head[i].vmax, head[i].vpo3);
            }
         }
      }

   free ((void *) device_order);

   fprintf (file,"!\n");
   fprintf (file,"! FET MODEL DSCR PROGRAM VERSION 2.00 %s\n",get_the_time (string));
   fprintf (file,"!\n");
   fprintf (file,"BEGIN DSCRDATA\n");
   fprintf (file,"%% index ");
   for (i = 0; i < NUM_PARAMETERS; ++i)
      fprintf (file,"%s",labels[i]);
   fprintf (file,"\n");

   for (ptr = sort, i = 1; ptr; ptr = ptr->next, ++i)
      {
      fprintf (file," %4d   ",i);
      for (j = 0; j < NUM_PARAMETERS; ++j)
         fprintf (file," %+.4e",param[ptr->position][j]);
      fprintf (file,"\n");
      }
   fprintf (file,"END DSCRDATA\n");

   fclose (file);

   /* free allocated memory */

   free_sorting_list (sort);
   for (i = 0; i < mem_sz; ++i)
      free ((void *) param[i]);
   free ((void *) param);
   free ((void *) site_num);

   printf("Complete!\n");

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static char *get_the_time (char *str)
   {
   char *ptr;
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];
   time_t now;

   time (&now);
   ptr = asctime (localtime (&now));
   sscanf (ptr+8,"%s",s_day);
   sscanf (ptr+4,"%s",s_month);
   sscanf (ptr+20,"%s",s_year);
   sscanf (ptr+11,"%s",s_time);
   sprintf (str,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

   return str;
   }

