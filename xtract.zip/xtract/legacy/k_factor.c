#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "microwave_utilities.h"

#define RAD_TO_DEGREE ((double) 57.2957795131)

main ()
{
POLAR   s11,s12,s21,s22,det_s,s12_s21;
double  k_factor,ma[4],an[4],freq,MAG;
char    batch_file_name[81];
char    string[256],filenames[81],filename[81],out_name[81];
char    mag_msg[80],s_params[80];
FILE    *file1,*file2,*batch_file;
time_t  current_t;

printf ("Filename(s)?\n> ");
fgets (string,255,stdin);
sscanf (string,"%s",filenames);
printf ("Calculate MAG/MSG? (y or n)\n> ");
fgets (string,255,stdin);
sscanf (string,"%s",mag_msg);
printf ("Include S-parameters in output file? (y or n)\n> ");
fgets (string,255,stdin);
sscanf (string,"%s",s_params);

sprintf (batch_file_name,"batch_%d",time (&current_t));
sprintf (string,"ls -1 %s > %s",filenames,batch_file_name);
system (string);

batch_file = fopen (batch_file_name,"r");

while (fgets (filename,80,batch_file) != NULL)
   {
   filename[strlen (filename)-1] = '\0';

   file1 = fopen (filename,"r");
   if (!file1)
      {
      printf ("\n** could not open %s ** \n\n",filename);
      continue;
      }

   sscanf (filename,"%[^.]",out_name);
   strcat (out_name,".kmag");

   file2 = fopen (out_name,"w+");

   while (fgets (string,255,file1) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",&freq,&ma[0],&an[0],
                          &ma[1],&an[1],&ma[2],&an[2],&ma[3],&an[3]) == 9)
         {
         s11.mag = ma[0];
         s11.ang = an[0];
         s12.mag = ma[2];
         s12.ang = an[2];
         s21.mag = ma[1];
         s21.ang = an[1];
         s22.mag = ma[3];
         s22.ang = an[3];
      
         s12_s21 = polar_mult (s12,s21);
         det_s = polar_sub (polar_mult (s11,s22),s12_s21);         
               
         k_factor = (((double) 1.0)-(s11.mag)*(s11.mag)-(s22.mag)*(s22.mag)+(det_s.mag)*(det_s.mag)) / (((double) 2.0)*(s12_s21.mag));
         if ((mag_msg[0] == 'y') || (mag_msg[0] == 'Y'))
            {
            MAG = s21.mag/s12.mag;
            if (k_factor > (double) 1.0)
               MAG = MAG*(k_factor-sqrt (k_factor*k_factor - 1.0));
            MAG = ((double) 10.0)*log10 (MAG);
            }
          
         fprintf (file2,"%.5e ",freq);
         if ((s_params[0] == 'y') || (s_params[0] == 'Y'))
            fprintf (file2,"%.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e ",
                        ma[0],an[0],ma[1],an[1],ma[2],an[2],ma[3],an[3]);
         
         if ((mag_msg[0] == 'y') || (mag_msg[0] == 'Y'))
            fprintf (file2,"%.4f %.2f\n",k_factor,MAG);
         else
            fprintf (file2,"%.4f\n",k_factor);
         }
      else
         fprintf (file2,"%s",string);
      }

   fclose (file1);
   fclose (file2);
   }
fclose (batch_file);

sprintf (string,"rm -f %s",batch_file_name);
system (string);
}
