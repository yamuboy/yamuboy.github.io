#include <stdio.h>
#include <string.h>
#include <time.h>

void get_the_time ();
int string_index ();

main ()
{
  FILE  *ot_file;
  FILE  *tmp;
  FILE  *i_file;
  int   i,tmp_found,d;
  char  buffer[201];
  char  i_name[201];
  char  ot_name[201];
  char  tmp_name[201];
  char  system_command[201];

  char  param[201];
  double vce,ice,vbe,ibe,k,temperature,q,min,nom,max,last,zero,re;
 
  zero = ((double) 0.0);
  k = ((double) 1.38066244e-23);
  q = ((double) 1.60217733e-19);
  printf ("Dmb file name\n");
  gets (i_name);
  printf ("End file name\n");
  gets (ot_name);
  
  
      i_file = fopen (i_name,"r");
      if ( i_file == (FILE*) NULL)
	{
	  printf ("** error ** cannot open file %s\n",i_name);
	  exit (1);
	}
      while (fgets (buffer,1024,i_file) != NULL)
	{
          tmp_found = 0;
          if (strncmp (buffer,"!TEMPERATURE (C):",17) == 0)
	    {
	      tmp_found = 1;
	      sscanf (buffer,"!TEMPERATURE (C): %lf",&temperature);
	    }
	  if (string_index (buffer,"BIAS: VCE =") > 0)
	    {            
	      sscanf (&(buffer[7]),"VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&vce,&ice,&vbe,&ibe);
	      re = (temperature + ((double) 273.15))*k/(q*(ice+ibe));
            }
	}
      fclose(i_file);
      ot_file = fopen (ot_name,"r");
      tmp = fopen ("junk2","w+");
      while (fgets (buffer,200,ot_file) != NULL)
	{
	  sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
	  if (strcmp(param,"Re") != 0)
	    {
	      fprintf(tmp,"%s",buffer);
	    }
	  else if (strcmp(param,"Re") == 0)
	    { 
	      min = (double) 0.0;
	      max = re*((double) 4.0);
	      fprintf(tmp,"%12.4e%12.4e%12.4e%12.4e %s\n",min,re,max,zero,param);
	    }
	}
      fclose(tmp);
      fclose(ot_file);
      sprintf (system_command,"mv junk2 %s",ot_name);
      system (system_command); 
}
/*                                                                   */
/*--- Function string_index -----------------------------------------*/
/*                                                                   */

int string_index (string1,string2)
char   string1[];
char   string2[];

{
int    n1;
int    n2;
int    i;

n1 = strlen (string1);
n2 = strlen (string2);

for (i = 0; i <= (n1-n2); ++i)
   {
   if (strncmp (&(string1[i]),string2,n2) == 0)
      {
      return (i);
      }
   }

return (-1);

}
/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);

return;

}
