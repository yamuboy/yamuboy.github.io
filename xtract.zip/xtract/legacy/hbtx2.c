#include <stdio.h>
#include <string.h>
#include <time.h>

#define HOT_HBT_PROGRAM_NAME       "hot_hbt_v4"
#define GUMMEL_FIT_PROGRAM_NAME    "gummel_fit_v1"
#define CBC_FIT_PROGRAM_NAME       "cbc_fit_v4"
#define CBE_FIT_PROGRAM_NAME       "cbe_fit_v4"
#define TF_PROGRAM_NAME            "calc_tf_v2"
#define PS_PROGRAM_NAME            "cat_ps"

/*****************************************************************************************/
/*****************************************************************************************/

void get_the_time (string)
char  *string;
   {
   time_t clock;
   char  *pointer;
   char  s_day[3];
   char  s_month[4];
   char  s_year[5];
   char  s_time[9];
   
   time (&clock);
   
   pointer = asctime (localtime (&clock));
   
   sscanf (pointer+8,"%2s",s_day);
   sscanf (pointer+4,"%3s",s_month);
   sscanf (pointer+20,"%4s",s_year);
   sscanf (pointer+11,"%8s",s_time);
   
   sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);
   
   return;
   }

/*****************************************************************************************/
/*****************************************************************************************/

int main (argc,argv)
int argc;
char *argv[];
   {
   FILE  *batch_job_file,*tmp_file,*in_file;
   char  buffer[200],current_time[80];
   char  batch_job_file_name[200],tmp_file_name[200],system_command[200];
   char  opt_in_file[200],opt_out_file[200],iv_out_file[200];
   char  frange[100],temperature[20],extension[20];
   char  para_irange[100],para_rrange[100],para_lrange[100];
   char  cbc_crange[100],cbc_vrange[100],cbe_crange[100],cbe_vrange[100];
   char  cap_max_searches[20];
   char  gummel_fwd_file[200],gummel_rev_file[200];
   char  gummel_fwd_vbe[100],gummel_rev_vbc[100];
   char  gummel_fwd_vrange[100],gummel_fwd_irange[100];
   char  gummel_rev_vrange[100],gummel_rev_irange[100];
   char  tf_files[200],tf_vce[20],tf_irange[100],tf_ftrange[100];
   int   extract_para = 0,extract_gummel = 0,extract_capacitance = 0, extract_tf = 0;
   int   i,n,t[4],graphics_device;

   if (argc > 1)
      {
      in_file = fopen (argv[1],"r");
      if (in_file == (FILE *) NULL)
         {
         printf ("** error ** unable to open file %s.\n",argv[1]);
         return -1;
         }

      if (argc > 2)
         {
         strncpy (extension,argv[2],19);
         }
      else
         {
         strcpy (extension,".dm2");
         }

      printf ("PERFORM WHICH EXTRACTIONS? (separate by spaces, CR for all)\n  1. HOT HBT (parasitics)\n  2. GUMMEL CURVES\n  3. CAPACITANCES\n  4. TRANSIT TIME\n\n");  
      fgets (buffer,199,stdin);
      n = sscanf (buffer,"%d%d%d%d",&t[0],&t[1],&t[2],&t[3]);
      if (n < 1)
         {
         extract_para = 1;
         extract_gummel = 1;
         extract_capacitance = 1;
         extract_tf = 1;
         }
      else
         {
         for (i = 0; i < n; ++i)
            {
            if (t[i] == 1)
               extract_para = 1;
            else if (t[i] == 2)
               extract_gummel = 1;
            else if (t[i] == 3)
               extract_capacitance = 1;
            else if (t[i] == 4)
               extract_tf = 1;
            }
         }

      printf ("GRAPHICS DEVICE?\n  10. Postscript\n  11. X-Windows\n  12. Metafile\n\n");
      fgets (buffer,199,stdin);
      sscanf (buffer,"%d",&graphics_device);
      if ((graphics_device < 10) || (graphics_device > 12))
         {
         printf ("** error ** invalid graphics device.\n");
         return -1;
         }
      }
   else
      {
      in_file = stdin;
      graphics_device = 10;
      extract_para = 1;
      extract_gummel = 1;
      extract_capacitance = 1;
      extract_tf = 1;
      strcpy (extension,".dm2");
      }

   printf ("START PARA. & CAP PARAMETERS FILE?\n");
   fgets (opt_in_file,199,in_file);
   printf ("FINISH PARA. & CAP. PARAMETERS FILE?\n");
   fgets (opt_out_file,199,in_file);
   printf ("FINISH IV PARAMETERS FILE?\n");
   fgets (iv_out_file,199,in_file);

   printf ("MEASUREMENT & EXTRACTION TEMPERATURE?\n");
   fgets (temperature,19,in_file);
   printf("1/IBE(A) RANGE FOR PARA. (START STOP STEP TICK)?\n");
   fgets (para_irange,99,in_file);
   printf("R(OHM) RANGE FOR PARA. (START STOP STEP TICK)?\n");
   fgets (para_rrange,99,in_file);
   printf("L(pH) RANGE FOR PARA. (START STOP STEP TICK)?\n");
   fgets (para_lrange,99,in_file);
   printf("FREQ FOR PARA. & CAP. EXTRACTION (MIN & MAX in GHZ)?\n");
   fgets (frange,99,in_file);

   printf ("MAXIMUM NUMBER OF CAP. LINE SEARCHES?\n");
   fgets (cap_max_searches,19,in_file);
   printf("VBC RANGE FOR CBC (START STOP STEP TICK)?\n");
   fgets (cbc_vrange,99,in_file);
   printf("CBC(pF) RANGE (START STOP STEP TICK)?\n");
   fgets (cbc_crange,99,in_file);
   printf("VBE RANGE FOR CBE (START STOP STEP TICK)?\n");
   fgets (cbe_vrange,99,in_file);
   printf("CBE(pF) RANGE (START STOP STEP TICK)?\n");
   fgets (cbe_crange,99,in_file);
   printf ("SPAR FILE NAMES FOR FT (must contain wildcards)?\n");
   fgets (tf_files,199,in_file);
   tf_files[strlen(tf_files)-1] = 0;

   printf("VCE FOR TF EXTRACTION?\n");
   fgets (tf_vce,19,in_file);
   printf("1/ICE(A) RANGE FOR TF (START STOP STEP TICK)?\n");
   fgets (tf_irange,99,in_file);
   printf("1/FT(GHZ) RANGE (START STOP STEP TICK)?\n");
   fgets (tf_ftrange,99,in_file);

   printf ("FWD GUMMEL FILE?\n");
   fgets (gummel_fwd_file,199,in_file);
   printf ("REV GUMMEL FILE?\n");
   fgets (gummel_rev_file,199,in_file);
   printf ("VCE FOR FWD IV EXTRACTION? (MIN MAX)\n");
   fgets (gummel_fwd_vbe,99,in_file);
   printf ("VBC FOR REV IV EXTRACTION? (MIN MAX)\n");
   fgets (gummel_rev_vbc,99,in_file);
   printf("VCE RANGE FOR FWD (START STOP STEP TICK)?\n");
   fgets (gummel_fwd_vrange,99,in_file);
   printf("VBC RANGE FOR REV (START STOP STEP TICK)?\n");
   fgets (gummel_rev_vrange,99,in_file);
   printf("ICE & IBE(A) RANGE FOR FWD (START STOP TICK)?\n");
   fgets (gummel_fwd_irange,99,in_file);
   printf("ICE & IBC(A) RANGE FOR REV (START STOP TICK)?\n");
   fgets (gummel_rev_irange,99,in_file);
   
   get_the_time (current_time);
   
   sprintf (batch_job_file_name,"batch_job_file.%s",current_time);
   sprintf (tmp_file_name,"tmp_file.%s",current_time);

   sprintf (system_command,"rm -f *.ps");
   system (system_command);
   sprintf (system_command,"rm -f *.out");
   system (system_command);
   sprintf (system_command,"rm -f %s",tmp_file_name);
   system (system_command);

   batch_job_file = fopen (batch_job_file_name,"w+");

   /* START PARASITIC EXTRACTION */
   if (extract_para)
      {
      sprintf (system_command,"ls -1 c00*%s > %s",extension,tmp_file_name);
      system (system_command);

      fprintf (batch_job_file,"%s << input\n",HOT_HBT_PROGRAM_NAME);
      fprintf (batch_job_file,"%s",opt_in_file);
      fprintf (batch_job_file,"%s",opt_in_file);
      fprintf (batch_job_file,"%s",para_irange);
      fprintf (batch_job_file,"%s",para_rrange);
      fprintf (batch_job_file,"%s",para_lrange);

      tmp_file = fopen (tmp_file_name,"r");
      if (tmp_file == (FILE*) NULL)
         {
         printf ("** internal error ** cannot open file %s\n",tmp_file_name);
         fclose (batch_job_file);
         sprintf (system_command,"rm -f %s",batch_job_file_name);
         system (system_command);
         return -1;
         }

      for (i = 0; i < 3; ++i)
         {
         if (fgets (buffer,200,tmp_file) != NULL)
            {
            fprintf (batch_job_file,"%s",buffer);
            }
         else
            {
            printf ("** error ** Only %d files found for parasitic extraction.\n",i);
            fclose (batch_job_file);
            fclose (tmp_file);
            sprintf (system_command,"rm -f %s",batch_job_file_name);
            system (system_command);
            sprintf (system_command,"rm -f %s",tmp_file_name);
            system (system_command);
            return -1;
            }
         }
      fclose(tmp_file);
      sprintf (system_command,"rm -f %s",tmp_file_name);
      system (system_command);

      fprintf (batch_job_file,"%s",frange);
      fprintf (batch_job_file,"%d\n",graphics_device);
      fprintf (batch_job_file,"input\n");
      if (graphics_device == 10)
         {
         fprintf (batch_job_file,"mv postscript.dat para.ps\n");
         }
      else if (graphics_device == 12)
         {
         fprintf (batch_job_file,"mv wmfplot-1.wmf res.wmf\n");
         fprintf (batch_job_file,"mv wmfplot-2.wmf ind.wmf\n");
         }
      }
   
   /* START GUMMEL EXTRACTION */
   if (extract_gummel)
      {
      fprintf (batch_job_file,"%s << input\n",GUMMEL_FIT_PROGRAM_NAME);
      fprintf (batch_job_file,"%s",gummel_fwd_file);
      fprintf (batch_job_file,"%s",gummel_rev_file);
      fprintf (batch_job_file,"%s",opt_in_file);
      fprintf (batch_job_file,"%s",iv_out_file);
      fprintf (batch_job_file,"%s",temperature);
      fprintf (batch_job_file,"%s",gummel_fwd_vbe);
      fprintf (batch_job_file,"%s",gummel_rev_vbc);
      fprintf (batch_job_file,"%s",gummel_fwd_vrange);
      fprintf (batch_job_file,"%s",gummel_rev_vrange);
      fprintf (batch_job_file,"%s",gummel_fwd_irange);
      fprintf (batch_job_file,"%s",gummel_rev_irange);
      fprintf (batch_job_file,"%d\n",graphics_device);
      fprintf (batch_job_file,"input\n");
      if (graphics_device == 10)
         {
         fprintf (batch_job_file,"mv postscript.dat gummel.ps\n");
         }
      else if (graphics_device == 12)
         {
         fprintf (batch_job_file,"mv wmfplot-1.wmf fwdgummel.wmf\n");
         fprintf (batch_job_file,"mv wmfplot-2.wmf revgummel.wmf\n");
         }
      }
   
   /* START CAPACITANCE EXTRACTION */
   if (extract_capacitance)
      {
      fprintf (batch_job_file,"%s << input\n",CBC_FIT_PROGRAM_NAME);
      fprintf (batch_job_file,"%s",opt_in_file);
      fprintf (batch_job_file,"%s",opt_out_file);
      fprintf (batch_job_file,"%s",frange);
      fprintf (batch_job_file,"%s",cap_max_searches);
      fprintf (batch_job_file,"%s",cbc_vrange);
      fprintf (batch_job_file,"%s",cbc_crange);

      sprintf (system_command,"ls -1r cbcm*%s > %s",extension,tmp_file_name);
      system (system_command);
      tmp_file = fopen (tmp_file_name,"r");
      if (tmp_file == (FILE*) NULL)
         {
         printf ("** internal error ** cannot open file %s\n",tmp_file_name);
         fclose (batch_job_file);
         sprintf (system_command,"rm -f %s",batch_job_file_name);
         system (system_command);
         return -1;
         }
      while (fgets (buffer,1024,tmp_file) != NULL)
         {
         fprintf (batch_job_file,"%s",buffer);
         }
      fclose(tmp_file);
      sprintf (system_command,"rm -f %s",tmp_file_name);
      system (system_command);

      sprintf (system_command,"ls -1 cbcp*%s > %s",extension,tmp_file_name);
      system (system_command);
      tmp_file = fopen (tmp_file_name,"r");
      if (tmp_file == (FILE*) NULL)
         {
         printf ("** internal error ** cannot open file %s",tmp_file_name);
         fclose (batch_job_file);
         sprintf (system_command,"rm -f %s",batch_job_file_name);
         system (system_command);
         return -1;
         }
      while (fgets (buffer,1024,tmp_file) != NULL)
         {
         fprintf (batch_job_file,"%s",buffer);
         }
      fclose(tmp_file);

      fprintf (batch_job_file,"STOP\n");  
      fprintf (batch_job_file,"%d\n",graphics_device);  
      fprintf (batch_job_file,"input\n");
      if (graphics_device == 10)
         {
         fprintf (batch_job_file,"mv postscript.dat cbc.ps\n");
         }
      else if (graphics_device == 12)
         {
         fprintf (batch_job_file,"mv wmfplot-1.wmf cbc.wmf\n");
         }

      fprintf (batch_job_file,"%s << input\n",CBE_FIT_PROGRAM_NAME);
      fprintf (batch_job_file,"%s",opt_in_file);
      fprintf (batch_job_file,"%s",opt_out_file);
      fprintf (batch_job_file,"%s",frange);
      fprintf (batch_job_file,"%s",cap_max_searches);
      fprintf (batch_job_file,"%s",cbe_vrange);
      fprintf (batch_job_file,"%s",cbe_crange);
      sprintf (system_command,"rm -f %s",tmp_file_name);
      system (system_command);

      sprintf (system_command,"ls -1r cbem*%s > %s",extension,tmp_file_name);
      system (system_command);
      tmp_file = fopen (tmp_file_name,"r");
      if (tmp_file == (FILE*) NULL)
         {
         printf ("** internal error ** cannot open file %s\n",tmp_file_name);
         fclose (batch_job_file);
         sprintf (system_command,"rm -f %s",batch_job_file_name);
         system (system_command);
         return -1;
         }
      while (fgets (buffer,1024,tmp_file) != NULL)
         {
         fprintf (batch_job_file,"%s",buffer);
         }
      fclose(tmp_file);
      sprintf (system_command,"rm -f %s",tmp_file_name);
      system (system_command);

      sprintf (system_command,"ls -1 cbep*%s > %s",extension,tmp_file_name);
      system (system_command);
      tmp_file = fopen (tmp_file_name,"r");
      if (tmp_file == (FILE*) NULL)
         {
         printf ("** internal error ** cannot open file %s",tmp_file_name);
         fclose (batch_job_file);
         sprintf (system_command,"rm -f %s",batch_job_file_name);
         system (system_command);
         return -1;
         }
      while (fgets (buffer,1024,tmp_file) != NULL)
         {
         fprintf (batch_job_file,"%s",buffer);
         }
      fclose(tmp_file);
      sprintf (system_command,"rm -f %s",tmp_file_name);
      system (system_command);

      fprintf (batch_job_file,"STOP\n");
      fprintf (batch_job_file,"%d\n",graphics_device);  
      fprintf (batch_job_file,"input\n");
      if (graphics_device == 10)
         {
         fprintf (batch_job_file,"mv postscript.dat cbe.ps\n");
         }
      else if (graphics_device == 12)
         {
         fprintf (batch_job_file,"mv wmfplot-1.wmf cbe.wmf\n");
         }
      }
      
   /* START TF EXTRACTION */
   if (extract_tf)
      {
      sprintf (system_command,"ls -1 %s > %s",tf_files,tmp_file_name);
      system (system_command);
      fprintf (batch_job_file,"%s << input\n",TF_PROGRAM_NAME);
      fprintf (batch_job_file,"%s\n",tmp_file_name);  
      fprintf (batch_job_file,"%s\n","ft.out");
      fprintf (batch_job_file,"%s",opt_out_file);
      fprintf (batch_job_file,"%s",tf_vce);
      fprintf (batch_job_file,"%s",tf_irange);
      fprintf (batch_job_file,"%s",tf_ftrange);
      fprintf (batch_job_file,"%d\n",graphics_device);
      fprintf (batch_job_file,"input\n");
      fprintf (batch_job_file,"rm -f %s\n",tmp_file_name);
      if (graphics_device == 10)
         {
         fprintf (batch_job_file,"mv postscript.dat tf.ps\n");
         }
      else if (graphics_device == 12)
         {
         fprintf (batch_job_file,"mv wmfplot-1.wmf tf.wmf\n");
         }
      }

   if (graphics_device == 10)
      {
      fprintf (batch_job_file,"%s << input\n",PS_PROGRAM_NAME);
      fprintf (batch_job_file,"*.ps\n");  
      fprintf (batch_job_file,"input\n");
      if (extract_para)
         {
         fprintf (batch_job_file,"rm -f para.ps\n");
         }
      if (extract_gummel)
         {
         fprintf (batch_job_file,"rm -f gummel.ps\n");
         }
      if (extract_capacitance)
         {
         fprintf (batch_job_file,"rm -f cbc.ps\n");
         fprintf (batch_job_file,"rm -f cbe.ps\n");
         }
      if (extract_tf)
         {
         fprintf (batch_job_file,"rm -f tf.ps\n");
         }
      }
   
   fprintf (batch_job_file,"rm -f %s\n",batch_job_file_name);  
   fclose (batch_job_file);
   
   sprintf (system_command,"chmod +x %s",batch_job_file_name);
   system (system_command);
   
   sprintf (system_command,"%s &",batch_job_file_name);
   system (system_command);

   return 0;
   }

