#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "icon_bitmap"
#include "eventnames.h"
#include "adobefonts.h"

#define LEFT_JUSTIFY      0
#define RIGHT_JUSTIFY     1
#define CENTER_JUSTIFY    2

#define DEG2RAD           ((double) 0.01745329252)

#define mod(x,y)           (x-int(x/y)*y)

/* 7.5x10, using std. units per inch */
#define WMF_HEIGHT          (4320)
#define WMF_WIDTH           (5760) 
#define WMF_UNITS_PER_INCH  (576)


Display       *display;
Window        window;
int           screen;
GC            gc;
char          *argv[] = {"wplot",""};
int           argc = 1;
unsigned int  win_width;
unsigned int  win_height;
float         wplot_scale;

/* windows metafile routine global variables */
int           wmf_font;
int           wmf_obj_num;
int           wmf_txt_obj;
float         wmf_ptsize;
float         wmf_angle;
FILE          *wmf_file;
unsigned long wmf_file_size;
unsigned long wmf_largest;
static float  wmf_xscale_factor = ((float) 1.0);
static float  wmf_yscale_factor = ((float) 1.0);


/*                                                                            */
/*--- function xfsize_ -------------------------------------------------------*/
/*                                                                            */

xfsize (display_width,display_height,display_width_mm,display_height_mm)
unsigned int *display_width;
unsigned int *display_height;
float        *display_width_mm;
float        *display_height_mm;
{
float        scale;
char         buffer[100];
char         *display_name = NULL;

if ((display = XOpenDisplay (display_name)) == NULL)
   {
   printf ("cannot connect to X server %s\n",XDisplayName (display_name));
   exit (-1);
   }

screen = DefaultScreen (display);

*display_width = DisplayWidth (display,screen);
*display_height = DisplayHeight (display,screen);
*display_width_mm = (float) DisplayWidthMM (display,screen);
*display_height_mm = (float) DisplayHeightMM (display,screen);

sprintf (buffer,"%s",getenv ("WPLOT_SIZE"));

if (sscanf (buffer,"%f",&scale) != 1)
   {
   scale = 1.0;
   }

*display_width = *display_width*scale;
*display_height = *display_height*scale;
/*
*display_width_mm = *display_width_mm*scale;
*display_height_mm = *display_height_mm*scale;
*/

}

/*                                                                            */
/*--- function xfopen_ -------------------------------------------------------*/
/*                                                                            */

xfopen (desired_width_mm,desired_height_mm,actual_width_mm,actual_height_mm)
float *desired_width_mm;
float *desired_height_mm;
float *actual_width_mm;
float *actual_height_mm;
{
unsigned int border_width = 0;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;
unsigned int one_cm_wide;
unsigned int one_cm_high;
unsigned int width;
unsigned int height;
XSizeHints   size_hints;
XEvent       report;
Pixmap       icon_pixmap;
Cursor       cursor;
float        scale;
char         buffer[100];
char         *window_name = "Wplot v1.00";
char         *display_name = NULL;
char         *icon_name = "Wplot";
int          window_size = 1;
int          x = 0;
int          y = 0;
Window       root;
unsigned int border;
unsigned int depth;

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

sprintf (buffer,"%s",getenv ("WPLOT_SIZE"));

if (sscanf (buffer,"%f",&scale) != 1)
   {
   scale = 1.0;
   }

wplot_scale = scale;

display_width = display_width*scale;
display_height = display_height*scale;
/*
display_width_mm = display_width_mm*scale;
display_height_mm = display_height_mm*scale;
*/

width = (unsigned int) (*desired_width_mm*((float) display_width)/((float) display_width_mm));
height = (unsigned int) (*desired_height_mm*((float) display_height)/((float) display_height_mm));

one_cm_wide = (unsigned int) (((float) display_width)/((float) display_width_mm));
one_cm_high = (unsigned int) (((float) display_height)/((float) display_height_mm));

if ((width > display_width-one_cm_wide) && (height < display_height-one_cm_high))
   {
   height = (unsigned int) (((float) height)*((float) (display_width-one_cm_wide))/((float) width));
   width = display_width-one_cm_wide;
   }
else if ((width < display_width-one_cm_wide) && (height > display_height-one_cm_high))
   {
   width = (unsigned int) (((float) width)*((float) (display_height-one_cm_high))/((float) height));
   height = display_height-one_cm_high;
   }

window = XCreateSimpleWindow (display,RootWindow (display,screen),x,y,width,height,border_width,BlackPixel (display,screen),WhitePixel (display,screen));

icon_pixmap = XCreateBitmapFromData (display,window,icon_bitmap_bits,icon_bitmap_width,icon_bitmap_height);

size_hints.flags = PPosition | PSize | PMinSize | PMaxSize | PAspect;
size_hints.x = x;
size_hints.y = y;
size_hints.width = width;
size_hints.height = height;
size_hints.min_width = 1;
size_hints.min_height = 1;
size_hints.max_width = width;
size_hints.max_height = height;
size_hints.min_aspect.x = 914;
size_hints.min_aspect.y = 706;
size_hints.max_aspect.x = 914;
size_hints.max_aspect.y = 706;

XSetStandardProperties (display,window,window_name,icon_name,icon_pixmap,argv,argc,&size_hints);

XSelectInput (display,window,ExposureMask | KeyPressMask | ButtonPressMask | StructureNotifyMask);

get_gc ();

XMapRaised (display,window);

/* Main Event Loop */

while (1)
   {
   XNextEvent (display,&report);
/*
   printf ("%s\n",event_names[report.type]);
*/
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XGetGeometry (display,window,&root,&x,&y,&win_width,&win_height,&border,&depth);
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         return;
      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         win_width = report.xconfigure.width;
         win_height = report.xconfigure.height;
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         break;
      case ButtonPress:
         break;
      case KeyPress:
         XCloseDisplay (display);
         return;
      default:
         break;
      }
   }

}

/*                                                                            */
/*--- function xfclose_ ------------------------------------------------------*/
/*                                                                            */

xfclose (status,actual_width_mm,actual_height_mm)
int   *status;
float *actual_width_mm;
float *actual_height_mm;
{
XEvent       report;
Window       root;
int          x;
int          y;
unsigned int border;
unsigned int depth;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;
float        scale;
char         buffer[100];

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

sprintf (buffer,"%s",getenv ("WPLOT_SIZE"));

if (sscanf (buffer,"%f",&scale) != 1)
   {
   scale = 1.0;
   }

display_width = display_width*scale;
display_height = display_height*scale;
/*
display_width_mm = display_width_mm*scale;
display_height_mm = display_height_mm*scale;
*/

while (1)
   {
   XNextEvent (display,&report);
/*
   printf ("%s\n",event_names[report.type]);
*/
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XGetGeometry (display,window,&root,&x,&y,&win_width,&win_height,&border,&depth);
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         return;
      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         win_width = report.xconfigure.width;
         win_height = report.xconfigure.height;
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         break;
      case ButtonPress:
         break;
      case KeyPress:
         XCloseDisplay (display);
         *status = 0;
         return;
      default:
         break;
      }
   }

}

/*                                                                            */
/*--- function xfpause_ ------------------------------------------------------*/
/*                                                                            */

xfpause (status,actual_width_mm,actual_height_mm)
int *status;
float *actual_width_mm;
float *actual_height_mm;
{
XEvent       report;
Window       root;
int          x;
int          y;
unsigned int border;
unsigned int depth;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;
float        scale;
char         buffer[100];

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

sprintf (buffer,"%s",getenv ("WPLOT_SIZE"));

if (sscanf (buffer,"%f",&scale) != 1)
   {
   scale = 1.0;
   }

display_width = display_width*scale;
display_height = display_height*scale;
/*
display_width_mm = display_width_mm*scale;
display_height_mm = display_height_mm*scale;
*/

while (1)
   {
   XNextEvent (display,&report);
/*
   printf ("%s\n",event_names[report.type]);
*/
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XGetGeometry (display,window,&root,&x,&y,&win_width,&win_height,&border,&depth);
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         return;
      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         win_width = report.xconfigure.width;
         win_height = report.xconfigure.height;
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         break;
      case ButtonPress:
         break;
      case KeyPress:
         XClearWindow (display,window);
         *status = 0;
         return;
      default:
         break;
      }
   }

}

/*                                                                            */
/*--- function xfdline_ ------------------------------------------------------*/
/*                                                                            */

xfdline (x1,y1,x2,y2)
int *x1;
int *y1;
int *x2;
int *y2;
{

XDrawLine (display,window,gc,*x1,((int) win_height)-(*y1),*x2,((int) win_height)-(*y2));

}

/*                                                                            */
/*--- function xfdtext_ ------------------------------------------------------*/
/*                                                                            */

xfdtext (x,y,angle,size,string,n,font)
int   *x;
int   *y;
float *angle;
float *size;
char  string[];
int   *n;
int   *font;
{
double ang;
float  point_size;
int    adobe_font_id;

ang = (double) *angle;

/*
string[*n] = '\0';
*/

point_size = *size*wplot_scale;

switch (*font)
   {
   case 2:
      if (point_size <= 9.0)
         {
         adobe_font_id = HELVETICA_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = HELVETICA_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = HELVETICA_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = HELVETICA_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = HELVETICA_18;
         }
      else
         {
         adobe_font_id = HELVETICA_24;
         }
      break;
   case 3:
      if (point_size <= 9.0)
         {
         adobe_font_id = TIMES_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = TIMES_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = TIMES_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = TIMES_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = TIMES_18;
         }
      else
         {
         adobe_font_id = TIMES_24;
         }
      break;
   default:
      if (point_size <= 9.0)
         {
         adobe_font_id = COURIER_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = COURIER_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = COURIER_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = COURIER_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = COURIER_18;
         }
      else
         {
         adobe_font_id = COURIER_24;
         }
      break;
   }

draw_text (string,*n,*x,((int) win_height)-(*y),ang,adobe_font_id,LEFT_JUSTIFY);

}

/*                                                                            */
/*--- function draw_text -----------------------------------------------------*/
/*                                                                            */

draw_text (string,n,x,y,angle,font,justification)
char         string[];
int          n;
int          x;
int          y;
double       angle;
unsigned int font;
unsigned int justification;
{
static unsigned long valuemask;
XFontStruct          *font_info;
static XGCValues     values;
Pixmap               bitmap;
XImage               *image;
XPoint               points[4];
double               r;
double               theta;
int                  length;
int                  width;
int                  height;
int                  x_offset;
int                  y_offset;
int                  x1_prime;
int                  y1_prime;
int                  x2_prime;
int                  y2_prime;
int                  x_pix;
int                  y_pix;
int                  last;
int                  i;
GC                   bitmap_gc;

if ((font_info = XLoadQueryFont (display,adobe_fonts[font])) == NULL)
   {
   printf ("Wplot: cannot open font\n%s\n",adobe_fonts[font]);
   exit (-1);
   }

XSetFont (display,gc,font_info->fid);

length = n;
width  = XTextWidth (font_info,string,length);
height = font_info->ascent+font_info->descent;

if (angle == (double) 0.0)
   {
   switch (justification)
      {
      case RIGHT_JUSTIFY:
         XDrawString (display,window,gc,x-width,y,string,length);
         break;
      case CENTER_JUSTIFY:
         XDrawString (display,window,gc,x-(width/2),y,string,length);
         break;
      case LEFT_JUSTIFY:
      default:
         XDrawString (display,window,gc,x,y,string,length);
         break;
      }
   return;
   }

bitmap = XCreatePixmap (display,window,(unsigned int) width,(unsigned int) height,1);

valuemask = (GCFunction | GCForeground | GCBackground | GCLineWidth | GCLineStyle |
            GCCapStyle | GCJoinStyle);

values.function   = GXcopy;
values.foreground = 0L;
values.background = 1L;
values.line_width = 1;
values.line_style = LineSolid;
values.cap_style  = CapButt;
values.join_style = JoinRound;

bitmap_gc = XCreateGC (display,bitmap,valuemask,&values);

XSetFont (display,bitmap_gc,font_info->fid);

XFillRectangle (display,bitmap,bitmap_gc,0,0,(unsigned int) width,(unsigned int) height);

XSetForeground (display,bitmap_gc,1L);
XSetBackground (display,bitmap_gc,0L);
XDrawString (display,bitmap,bitmap_gc,0,font_info->ascent,string,length);

image = XGetImage (display,bitmap,0,0,(unsigned int) width,(unsigned int) height,AllPlanes,XYPixmap);

switch (justification)
   {
   case RIGHT_JUSTIFY:
      x_offset = width;
      break;
   case CENTER_JUSTIFY:
      x_offset = width/2;
      break;
   case LEFT_JUSTIFY:
   default:
      x_offset = 0;
      break;
   }

y_offset = font_info->ascent;
/*
for (y_pix = 0; y_pix < height; ++y_pix)
   {
   last = 0;
   for (x_pix = 0; x_pix < width; ++x_pix)
      {
      if (XGetPixel (image,x_pix,y_pix) && (last == 0))
         {
         last = 1;
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x1_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y1_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         }
      else if ((XGetPixel (image,x_pix,y_pix) == 0) && last)
         {
         last = 0;
         r = sqrt (((double) x_pix-x_offset-1)*((double) x_pix-x_offset-1)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix-1 == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset-1));
            }
         x2_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y2_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         XDrawLine (display,window,gc,x1_prime,y1_prime,x2_prime,y2_prime);
         }
      else if (XGetPixel (image,x_pix,y_pix) && (x_pix == width-1))
         {
         last = 0;
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x2_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y2_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         XDrawLine (display,window,gc,x1_prime,y1_prime,x2_prime,y2_prime);
         }
      }
   }
*/
for (y_pix = 0; y_pix < height; ++y_pix)
   {
   for (x_pix = 0; x_pix < width; ++x_pix)
      {
      if (XGetPixel (image,x_pix,y_pix))
         {
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x1_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y1_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         }
         XDrawPoint (display,window,gc,x1_prime,y1_prime);
      }
   }

XFreePixmap (display,bitmap);
XFreeGC (display,bitmap_gc);
XDestroyImage (image);

}

/*                                                                            */
/*--- function get_gc --------------------------------------------------------*/
/*                                                                            */

get_gc ()
{
static unsigned long valuemask;
static XGCValues     values;

valuemask = (GCFunction | GCForeground | GCBackground | GCLineWidth |
             GCLineStyle | GCCapStyle | GCJoinStyle);

values.function   = GXcopy;
values.foreground = BlackPixel (display,screen);
values.background = WhitePixel (display,screen);
values.line_width = 1;
values.line_style = LineSolid;
values.cap_style  = CapButt;
values.join_style = JoinRound;

gc = XCreateGC (display,window,valuemask,&values);

}

/*                                                                            */
/*--- function wait_cursor ---------------------------------------------------*/
/*                                                                            */

wait_cursor (win,cursor)
Window win;
Cursor *cursor;
{

*cursor = XCreateFontCursor (display,XC_watch);

XDefineCursor(display,win,*cursor);

XFlush (display);

}

/*                                                                            */
/*--- function pointer_cursor ------------------------------------------------*/
/*                                                                            */

pointer_cursor (win,cursor)
Window win;
Cursor *cursor;
{

*cursor = XCreateFontCursor (display,XC_top_left_arrow);

XDefineCursor(display,win,*cursor);

XFlush (display);

}



/* ------------------------------------------------------------------------- */
/*                                                                           */
/*                          WINDOWS METAFILE ROUTINES                        */
/*                                                                           */
/*                                                                           */
/*     these routines will write a binary output file in 16-bit Windows      */
/*                 metafile format (vector-based graphics)                   */
/*                                                                           */
/*                          written by Jay Barrett                           */
/* ------------------------------------------------------------------------- */

/*                                                                            */
/*--- function wmfopen -------------------------------------------------------*/
/*                                                                            */

wmfopen (basename,page,width,height)
char    *basename;
int     *page;
int     *width;
int     *height;

{
char        header[41];
char        file_name[80];
char        string[80];
char        lowb,highb;
char        lchecksum,hchecksum;
int         meta_u,i;
int         params[10];
static char wmf_basename[81];

if (*page == 1)
   {
   i = 0;
   while ((basename[i] != ' ') && (basename[i] != '\0') && (basename[i] != '.'))
      {
      ++i;
      }
   strncpy (wmf_basename,basename,i);    
   }

sprintf (file_name,"%s-%d.wmf",wmf_basename,*page);

wmf_file = fopen (file_name,"w+");

wmf_xscale_factor = ((float) WMF_WIDTH)/((float) *width);
wmf_yscale_factor = ((float) WMF_HEIGHT)/((float) *height);

/* placeable metafile header - 11 words (22 bytes) */

/* sets the magic number (0x9ac6cdd7), the handle (0x0000), and the origin to be in the */
/* upper left corner of the graphic  */
fprintf (wmf_file,"%c%c%c%c%c%c%c%c%c%c",0xd7,0xcd,0xc6,0x9a,0x00,0x00,0x00,0x00,0x00,0x00);

lchecksum = ((char) 0x11);
hchecksum = ((char) 0x57);

/* set the metafile width in metafile units */
meta_u = WMF_WIDTH;
lowb = (char) meta_u;
highb = (char) (meta_u >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);
lchecksum ^= lowb;
hchecksum ^= highb;

/* set the metafile height in metafile units */
meta_u = WMF_HEIGHT;
lowb = (char) meta_u;
highb = (char) (meta_u >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);
lchecksum ^= lowb;
hchecksum ^= highb;

/* set the metafile units per inch */
meta_u = WMF_UNITS_PER_INCH;
lowb = (char) meta_u;
highb = (char) (meta_u >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);
lchecksum ^= lowb;
hchecksum ^= highb;

/* set the reserved word to 0x00000000 */
fprintf (wmf_file,"%c%c%c%c",0x00,0x00,0x00,0x00);

/* write the checksum */
fprintf (wmf_file,"%c%c",lchecksum,hchecksum);

/* standard metafile header - 9 words (18 bytes) */

/* set the file type to disk (0x0001), the header size (0x0009), the windows version (0x0300)    */
/* for 16-bit compatibility, the file size (0x00000000 - placeholder will change later), the     */
/* number of objects (we will have four for all files - 0x0004), the max record size (again a    */
/* placeholder to be set later - 0x00000000), and the last field is unused and must be set to 0  */
fprintf (wmf_file,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",0x01,0x00,0x09,0x00,0x00,0x03,
                   0x00,0x00,0x00,0x00,0x04,0x00,0x00,0x00,0x00,0x00,0x00,0x00);
 
/* now that the header is done, reset the filesize counter, largest record, and font variables and */
/* set up the basic drawable and brush/pen styles                                                  */

wmf_file_size = 9L;
wmf_largest = 0L;

params[0] = 0;
params[1] = 0;
write_wmf_record (0x020b,params,2);  /* META_SETWINDOWORG - map window origin to (0,0) */

params[0] = 4320;
params[1] = 5760;
write_wmf_record (0x020c,params,2);  /* MEAT_SETWINDOWEXT - set the window extents */

params[0] = 1;
write_wmf_record (0x0102,params,1);  /* META_SETBKMODE - background mode (transparent) */

params[0] = 0x000d;
params[1] = 0x0000;
write_wmf_record (0x0104,params,2);  /* META_SETROP2 - GC in X windows (copy pen) */

params[0] = 0xffff;
params[1] = 0x00ff;
write_wmf_record (0x0201,params,2);  /* META_SETBKCOLOR - background color (white) */

params[0] = 0x0000;
params[1] = 0x0000;
params[2] = 0x0000;
params[3] = 0x0000;
write_wmf_record (0x02fc,params,4);  /* META_CREATEBRUSHINDIRECT - create a base brush object */

params[0] = 0;
write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT (select the brush we created) */
wmf_obj_num = 0;

params[0] = 0x0000;  /* style (solid, endcap round, join round) */
params[1] = 2;  /* width in points */
params[2] = 0x0000; /* color (black) */
params[3] = 0x0000; /* color continued */
params[4] = 0x0000;
write_wmf_record (0x02fa,params,5);  /* META_CREATEPENINDIRECT */

params[0] = 1;
write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT (select the pen we created) */
wmf_obj_num = 1;

params[0] = 0;
write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT (select the brush we created) */
wmf_obj_num = 0;

wmf_font = -1;
wmf_ptsize = 0;
wmf_angle = 0;
wmf_txt_obj = -1;

return;

}


/*                                                                            */
/*--- function wmfclose ------------------------------------------------------*/
/*                                                                            */

wmfclose ()

{
int params;
char lowb,highb;

/* write the terminating string */
write_wmf_record (0x0000,&params,0);

/* write the wmf file size (in 16-bit words) */
fseek (wmf_file,28L,SEEK_SET);

lowb = (char) wmf_file_size;
highb = (char) (wmf_file_size >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);
lowb = (char) (wmf_file_size >> 16);
highb = (char) (wmf_file_size >> 24);
fprintf (wmf_file,"%c%c",lowb,highb);

/* write the largest record size */
fseek (wmf_file,34L,SEEK_SET);

lowb = (char) wmf_largest;
highb = (char) (wmf_largest >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);
lowb = (char) (wmf_largest >> 16);
highb = (char) (wmf_largest >> 24);
fprintf (wmf_file,"%c%c",lowb,highb);

fclose (wmf_file);

return;

}


/*                                                                            */
/*--- function wmfvctr -------------------------------------------------------*/
/*                                                                            */

wmfvctr (x1,y1,x2,y2)
int *x1,*y1,*x2,*y2;

{
int params[5];

if (wmf_obj_num != 1)
   {
   params[0] = 1;
   write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT -  select the pen */
   wmf_obj_num = 1;
   }
   
params[0] = 2; /* number of points */
params[1] = ((int) ((float) *x1)*wmf_xscale_factor);
params[2] = WMF_HEIGHT - ((int) ((float) *y1)*wmf_yscale_factor);
params[3] = ((int) ((float) *x2)*wmf_xscale_factor);
params[4] = WMF_HEIGHT - ((int) ((float) *y2)*wmf_yscale_factor);
write_wmf_record (0x0325,params,5);  /* META_POLYLINE */

return;

}


/*                                                                            */
/*--- function wmftext -------------------------------------------------------*/
/*                                                                            */

wmftext (x,y,angle,ptsize,string,n,font)
int    *x,*y;
float  *angle;
float  *ptsize;
char   *string;
int    *n,*font;

{
int params[200];
int i,j;

if ((*font != wmf_font) || (*angle != wmf_angle) || (*ptsize != wmf_ptsize))
   {
   params[0] = 0 - ((int) (*ptsize)*wmf_xscale_factor*((float) 10.0));  /* point size - fudged */
   params[1] = 0;
   params[2] = ((int) *angle)*10;  /* text angle in 10*degrees */
   params[3] = 0;
   params[4] = 0x0190;    /* attributes - std. weight set */
   params[5] = 0;
   params[6] = 0;
   params[7] = 0x0203;  /* don't know - always set to 0x0203 for all fonts */
   
   switch (*font)
      {
      case 1: /* courier new */
         params[8] = 0x3100;
         params[9] = ((int) 'C') + (((int) 'o') << 8);
         params[10] = ((int) 'u') + (((int) 'r') << 8);
         params[11] = ((int) 'i') + (((int) 'e') << 8);
         params[12] = ((int) 'r') + (((int) ' ') << 8);
         params[13] = ((int) 'N') + (((int) 'e') << 8);
         params[14] = ((int) 'w');
         params[15] = 0;
         params[16] = 0;
         params[17] = 0;
         params[18] = 0;
         params[19] = 0;
         params[20] = 0;
         params[21] = 0;
         params[22] = 0;
         params[23] = 0;
         params[24] = 0;
         break;
      case 2: /* helvetica */
         params[8] = 0x2200;
         params[9] = ((int) 'H') + (((int) 'e') << 8);
         params[10] = ((int) 'l') + (((int) 'v') << 8);
         params[11] = ((int) 'e') + (((int) 't') << 8);
         params[12] = ((int) 'i') + (((int) 'c') << 8);
         params[13] = ((int) 'a');
         params[14] = 0;
         params[15] = 0;
         params[16] = 0;
         params[17] = 0;
         params[18] = 0;
         params[19] = 0;
         params[20] = 0;
         params[21] = 0;
         params[22] = 0;
         params[23] = 0;
         params[24] = 0;
         break;
      case 3:
      default: /* times new roman */
         params[8] = 0x1200;
         params[9] = ((int) 'T') + (((int) 'i') << 8);
         params[10] = ((int) 'm') + (((int) 'e') << 8);
         params[11] = ((int) 's') + (((int) ' ') << 8);
         params[12] = ((int) 'N') + (((int) 'e') << 8);
         params[13] = ((int) 'w') + (((int) ' ') << 8);
         params[14] = ((int) 'R') + (((int) 'o') << 8);
         params[15] = ((int) 'm') + (((int) 'a') << 8);
         params[16] = ((int) 'n');
         params[17] = 0;
         params[18] = 0;
         params[19] = 0;
         params[20] = 0;
         params[21] = 0;
         params[22] = 0;
         params[23] = 0;
         params[24] = 0;
         break;
      }
               
   wmf_ptsize = *ptsize;
   wmf_font = *font;
   wmf_angle = *angle;

   write_wmf_record (0x02fb,params,25);  /* META_CREATEFONTINDIRECT - create a font */

   if (wmf_txt_obj == 2)
      {
      params[0] = 3;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - select the font object */
      wmf_obj_num = 3;
      wmf_txt_obj = 3;
      
      params[0] = 2;
      write_wmf_record (0x01f0,params,1);  /* META_DELETEOBJECT - old font */
      }      
   else if (wmf_txt_obj == 3)
      {
      params[0] = 2;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - select the font object */
      wmf_obj_num = 2;
      wmf_txt_obj = 2;
      
      params[0] = 3;
      write_wmf_record (0x01f0,params,1);  /* META_DELETEOBJECT - old font */
      }
   else /* first instance of create font */
      {
      params[0] = 2;
      write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - select the font object */
      wmf_obj_num = 2;
      wmf_txt_obj = 2;
      }

   params[0] = 0;
   params[1] = 0;
   write_wmf_record (0x0209,params,2);  /* META_SETTEXTCOLOR - text color (black) */

   params[0] = 24;
   write_wmf_record (0x012e,params,1);  /* META_SETTEXTALIGN -  text alignment (baseline) */
   }

if (wmf_obj_num != wmf_txt_obj)
   {
   params[0] = wmf_txt_obj;
   write_wmf_record (0x012d,params,1);  /* META_SELECTOBJECT - select the font object */
   wmf_obj_num = wmf_txt_obj;
   }
 
params[0] = WMF_HEIGHT - ((int) ((float) *y)*wmf_yscale_factor);
params[1] = ((int) ((float) *x)*wmf_xscale_factor);
params[2] = *n;
params[3] = 0;

j = 4;
for (i = 0; i < *n; i += 2)
   {
   params[j] = (int) string[i];
   if ((i+1) < *n)
      {
      params[j] += (((int) string[i+1]) << 8);
      }
   ++j;
   }
write_wmf_record (0x0a32,params,j);  /* META_EXTTEXTOUT - write text */

return;

}


/*                                                                            */
/*--- function write_wmf_record ----------------------------------------------*/
/*                                                                            */

write_wmf_record (function,params,num_params)
int    function;
int    *params;
int    num_params;

{
unsigned long rec_size;
char     lowb,highb;
int      i;

rec_size = ((long) num_params + 3);
wmf_file_size += rec_size;
if (rec_size > wmf_largest)
   {
   wmf_largest = rec_size;
   }

/* write the record size */
lowb = (char) rec_size;
highb = (char) (rec_size >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);
lowb = (char) (rec_size >> 16);
highb = (char) (rec_size >> 24);
fprintf (wmf_file,"%c%c",lowb,highb);

/* write the function number */
lowb = (char) function;
highb = (char) (function >> 8);
fprintf (wmf_file,"%c%c",lowb,highb);

/* write the parameters */
for (i = 0; i < num_params; ++i)
   { 
   lowb = (char) params[i];
   highb = (char) (params[i] >> 8);
   fprintf (wmf_file,"%c%c",lowb,highb);
   }

return;

}

