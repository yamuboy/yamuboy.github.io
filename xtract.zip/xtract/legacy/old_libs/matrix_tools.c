#include <math.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include "cmplxlib.h"
#include "matrix_types.h"
#include "optimize3.h"

#define EPS         1.0e-12
#define PI          3.14519265359
#define MAX_NODES   100

static NETLIST   *global_netlist_pointer;
static double    *global_gradient_pointer;
static S_2PORT   *global_sp_pointer;
static int       number_of_frequencies;
static int       netlist_size;
static int       number_of_parameters;

//#define DEBUGR
//#define DEBUGA
//#define DEBUGG

/********************************************************************************************/
/********************************************************************************************/

int mindex (int row, int col, int ncols)
   {
   return (row*ncols+col);
   }

/********************************************************************************************/
/********************************************************************************************/

void complex_matrix_reduction (COMPLEX *y,int msize,int rsize)
   {
   COMPLEX temp;
   COMPLEX denom;
   static COMPLEX neg_one = {-1.0,0.0};
   double  max,tmax;
   int     i,j,k;
   int     row,col;

#ifdef DEBUGR
   int     l,m;
   FILE    *debug;

   debug = fopen ("debug.txt","w+");

   for (l = 0; l < msize; ++l)
      {
      for (m = 0; m < msize; ++m)
         fprintf (debug,"(%10.3e,%10.3e) ",y[mindex(l,m,msize)].r,y[mindex(l,m,msize)].i);
      fprintf (debug,"\n");
      }
   fprintf (debug,"\n");
#endif

   // perform reduction with full pivoting

   for (k = (msize-1); k > (rsize-1); --k)
      {

      // find largest element
      max = 0.0;
      row = k;
      col = k;
      for (i = rsize; i <= k; ++i)
         {
         for (j = rsize; j <= k; ++j)
            {
            tmax = Cmag (y[mindex(i,j,msize)]);
            if (tmax > max)
               {
               row = i;
               col = j;
               max = tmax;
               }
            }
         }
      
      // pivot rows
      if (row != k)
         {
         for (j = 0; j <= k; ++j)
            {
            temp = y[mindex(k,j,msize)];
            y[mindex(k,j,msize)] = y[mindex(row,j,msize)];
            y[mindex(row,j,msize)] = temp;
            }
         }
      
      // pivot columns
      if (col != k)
         {
         for (i = 0; i <= k; ++i)
            {
            temp = y[mindex(i,k,msize)];
            y[mindex(i,k,msize)] = y[mindex(i,col,msize)];
            y[mindex(i,col,msize)] = temp;
            }
         }
      
      // perform nodal reduction      
      denom = Cdiv (neg_one,y[mindex(k,k,msize)]);
      for (i = 0; i < k; ++i)
         {
         temp = Cmult (y[mindex(i,k,msize)],denom);
         for (j = 0; j <= k; ++j)
            y[mindex(i,j,msize)] = Cadd (y[mindex(i,j,msize)],Cmult (y[mindex(k,j,msize)],temp));
         }

#ifdef DEBUGR
      for (l = 0; l < msize; ++l)
         {
         for (m = 0; m < msize; ++m)
            fprintf (debug,"(%10.3e,%10.3e) ",y[mindex(l,m,msize)].r,y[mindex(l,m,msize)].i);
         fprintf (debug,"\n");
         }
      fprintf (debug,"\n");
#endif

      }  // finished nodal reduction

#ifdef DEBUGR   
   fclose (debug);
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

void solve_y_for_2port_s (COMPLEX *y, COMPLEX *s, int ysize)
   {
   COMPLEX yp[4];

   complex_matrix_reduction (y, ysize, 3);

   yp[0] = Ccopy (y[mindex(1,1,ysize)]);
   yp[1] = Ccopy (y[mindex(1,2,ysize)]);
   yp[2] = Ccopy (y[mindex(2,1,ysize)]);
   yp[3] = Ccopy (y[mindex(2,2,ysize)]);

   y2s (yp,s,50.0);
   }

/********************************************************************************************/
/********************************************************************************************/

void twoport_adjoint_solution (COMPLEX *y, COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, int msize)
   {
   COMPLEX temp;
   COMPLEX denom;
   static COMPLEX one     = {1.0,0.0};
   static COMPLEX neg_one = {-1.0,0.0};
   static COMPLEX zero    = {0.0,0.0};
   double  max,tmax;
   int     i,j,k;
   int     row;
   int     pointer[MAX_NODES];

#ifdef DEBUGA
   int     l,m;
   FILE    *debug;

   debug = fopen ("debug.txt","w+");

   for (l = 0; l < msize; ++l)
      {
      for (m = 0; m < msize; ++m)
         fprintf (debug,"(%10.3e,%10.3e) ",y[mindex(l,m,msize)].r,y[mindex(l,m,msize)].i);
      fprintf (debug,"\n");
      }
   fprintf (debug,"\n");
#endif

   // initialize the node pointer
   for (i = 0; i < msize; ++i)
      pointer[i] = i;

   // perform reduction with diagonal pivoting
   for (k = (msize-1); k > 2; --k)
      {
      // find largest diagonal element
      max = 0.0;
      row = k;
      for (i = 3; i < k; ++i)
         {
         tmax = Cmag2 (y[mindex(i,i,msize)]);
         if (tmax > max)
            {
            row = i;
            max = tmax;
            }
         }
      
      // pivot rows, columns and node pointer
      if (row != k)
         {
         for (j = 0; j < msize; ++j) // rows
            {
            temp = y[mindex(k,j,msize)];
            y[mindex(k,j,msize)] = y[mindex(row,j,msize)];
            y[mindex(row,j,msize)] = temp;
            }

         for (i = 0; i < msize; ++i) // columns
            {
            temp = y[mindex(i,k,msize)];
            y[mindex(i,k,msize)] = y[mindex(i,row,msize)];
            y[mindex(i,row,msize)] = temp;
            }

         i = pointer[k];
         pointer[k] = pointer[row];
         pointer[row] = i;
         }

      // perform nodal reduction 
      denom = Cdiv (neg_one,y[mindex(k,k,msize)]);
      for (i = 1; i < k; ++i)
         {
         y[mindex(i,k,msize)] = Cmult (y[mindex(i,k,msize)],denom);
         for (j = 1; j < k; ++j)
            y[mindex(i,j,msize)] = Cadd (y[mindex(i,j,msize)],Cmult (y[mindex(k,j,msize)],y[mindex(i,k,msize)]));
         }
         
      for (j = 1; j < k; ++j)
         y[mindex(k,j,msize)] = Cmult (y[mindex(k,j,msize)],denom);

#ifdef DEBUGA
      for (l = 0; l < msize; ++l)
         {
         for (m = 0; m < msize; ++m)
            fprintf (debug,"(%10.3e,%10.3e) ",y[mindex(l,m,msize)].r,y[mindex(l,m,msize)].i);
         fprintf (debug,"\n");
         }
      fprintf (debug,"\n");
#endif

      }  // finished nodal reduction

   // solve for two-port voltages: p[] = solution with port 2 o.c., q[] = solution with port 1 o.c.
   //   pa[]  and qa[] are the solutions for the adjoint network where Y = YT (transpose)
   p[0]  = zero;
   q[0]  = zero;
   pa[0] = zero;
   qa[0] = zero;

   denom = Csub (Cmult (y[mindex(1,1,msize)],y[mindex(2,2,msize)]),Cmult (y[mindex(1,2,msize)],y[mindex(2,1,msize)]));
   denom = Cdiv (one,denom);

   p[1] = Cmult (y[mindex(2,2,msize)],denom);
   p[2] = Cdiv (Cmult (Cneg (p[1]),y[mindex(2,1,msize)]),y[mindex(2,2,msize)]);
   q[1] = Cmult (Cneg (y[mindex(1,2,msize)]),denom);
   q[2] = Cdiv (Cmult (Cneg (q[1]),y[mindex(1,1,msize)]),y[mindex(1,2,msize)]);

   pa[1] = p[1];
   pa[2] = Cdiv (Cmult (Cneg (pa[1]),y[mindex(1,2,msize)]),y[mindex(2,2,msize)]);
   qa[1] = Cmult (Cneg (y[mindex(2,1,msize)]),denom);
   qa[2] = Cdiv (Cmult (Cneg (qa[1]),y[mindex(1,1,msize)]),y[mindex(2,1,msize)]);

   // solve for internal node voltages, since internal node rows have been normalized to -y[row][row]
   //  already in matrix reduction step, no need to divide solution by -y[row][row]
   for (i = 3; i < msize; ++i)
      {
      p[pointer[i]]  = zero;
      q[pointer[i]]  = zero;
      pa[pointer[i]] = zero;
      qa[pointer[i]] = zero;
      for (j = 1; j < i; ++j)
         {
         p[pointer[i]] = Cadd (p[pointer[i]],Cmult (y[mindex(i,j,msize)],p[pointer[j]]));
         q[pointer[i]] = Cadd (q[pointer[i]],Cmult (y[mindex(i,j,msize)],q[pointer[j]]));
         pa[pointer[i]] = Cadd (pa[pointer[i]],Cmult (y[mindex(j,i,msize)],pa[pointer[j]]));
         qa[pointer[i]] = Cadd (qa[pointer[i]],Cmult (y[mindex(j,i,msize)],qa[pointer[j]]));
         }
      }

#ifdef DEBUGA      

   fprintf (debug,"\n\n----------NODE VOLTAGE VECTORS-----------\n\n");
   for (i = 0; i < msize; ++i)
      fprintf (debug,"(%10.3e,%10.3e) (%10.3e,%10.3e) (%10.3e,%10.3e) (%10.3e,%10.3e)\n",
               p[i].r,p[i].i,q[i].r,q[i].i,pa[i].r,pa[i].i,qa[i].r,qa[i].i);

   fclose (debug);
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

static void s_k_mag_deriv (COMPLEX yderiv, COMPLEX *ysens, S_2PORT sp, COMPLEX *derv)
   {
   COMPLEX  s11,s12,s21,s22;
   COMPLEX  s11c,s12c,s21c,s22c;
   COMPLEX  t11,t12,t21,t22;
   COMPLEX  del,delc,tmp;
   static COMPLEX one  = {1.0,0.0};
   static COMPLEX norm = {0.01,0.0};

   s11 = Csub (one,sp.s[0]);
   s12 = sp.s[1];
   s21 = sp.s[2];
   s22 = Csub (one,sp.s[3]);

   t11 = Csub (Cmult (ysens[0],s11),Cmult (ysens[1],s21));
   t12 = Csub (Cmult (ysens[1],s22),Cmult (ysens[0],s12));
   t21 = Csub (Cmult (ysens[2],s11),Cmult (ysens[3],s21));
   t22 = Csub (Cmult (ysens[3],s22),Cmult (ysens[2],s12));

   derv[0] = Cmultx (3,Csub (Cmult (s11,t11),Cmult (s12,t21)),norm,yderiv);
   derv[1] = Cmultx (3,Csub (Cmult (s11,t12),Cmult (s12,t22)),norm,yderiv);
   derv[2] = Cmultx (3,Csub (Cmult (s22,t21),Cmult (s21,t11)),norm,yderiv);
   derv[3] = Cmultx (3,Csub (Cmult (s22,t22),Cmult (s21,t12)),norm,yderiv);

   // now calculate K and MAG sensistivities from [S]
   s11 = sp.s[0];
   s22 = sp.s[3];
   s11c = Cconj (s11);
   s12c = Cconj (s12);
   s21c = Cconj (s21);
   s22c = Cconj (s22);
   del = Csub (Cmult (s11,s22),Cmult (s12,s21));
   delc = Cconj (del);

   // sensitivity w.r.t. K
   derv[4] = Cmult( delc,Caddx( 4,Cmult(s22,derv[4]),Cmult(s11,derv[3]),Cneg(Cmult(s21,derv[1])),Cneg(Cmult(s12,derv[2])) ) );
   derv[4] = Cdiv( Caddx( 3,derv[4],Cneg(Cmult(s11c,derv[0])),Cneg(Cmult(s22c,derv[3])) ),Ccmag(Cmult(s12,s21)) );
   tmp = Cdiv( Cmultx( 4,Complex (sp.k),s12c,s21c,Cadd(Cmult(derv[2],s12),Cmult(derv[1],s21)) ),Complex(Cmag2(Cmult(s12,s21))) );
   derv[4] = Csub (derv[4],tmp);
   derv[4].i = 0.0;

/*
      TEMP = (10.0D+0,0.0D+0)*DLOG10(DEXP(1.0D+0))
      P(6) = TEMP*(P(3)/S21-P(2)/S12)
C
      IF(B.GE.0.0D+0.AND.K.GT.1.0D+0)THEN
       P(6) = P(6)-TEMP*P(5)/DSQRT(K*K-1.0D+0)
      ELSEIF(B.LT.0.0D+0.AND.K.GT.1.0D+0)THEN
       P(6) = P(6)+TEMP*P(5)/DSQRT(K*K-1.0D+0)
      ENDIF
C
      P(6) = DREAL(P(6))*(1.0D+0,0.0D+0)
*/

   // sensistivity w.r.t. MAG/MSG
   tmp = Complex (10.0*log10 (exp (1.0)));
   derv[5] = Cmult (tmp,Csub (Cdiv (derv[2],s21),Cdiv (derv[1],s12)));
   if (sp.k > 1.0)
      {
      tmp = Cdiv (Cmult (tmp,derv[4]),Complex (sqrt (sp.k*sp.k-1.0)));
      if (sp.MAG >= 0.0)
         derv[5] = Csub (derv[5],tmp);
      else
         derv[5] = Cadd (derv[5],tmp);
      }
   derv[5].i = 0.0;
   }

/********************************************************************************************/
/********************************************************************************************/

void add_ybranch (COMPLEX x, int n1, int n2, COMPLEX *y, int msize)
   {
   y[mindex(n1,n1,msize)] = Cadd (y[mindex(n1,n1,msize)],x);
   y[mindex(n2,n2,msize)] = Cadd (y[mindex(n2,n2,msize)],x);
   y[mindex(n1,n2,msize)] = Csub (y[mindex(n1,n2,msize)],x);
   y[mindex(n2,n1,msize)] = Csub (y[mindex(n2,n1,msize)],x);
   }

/********************************************************************************************/
/********************************************************************************************/

void add_yvccs (COMPLEX x, int vp, int vm, int cm, int cp, COMPLEX *y, int msize)
   {
   y[mindex(cm,vp,msize)] = Cadd (y[mindex(cm,vp,msize)],x);
   y[mindex(cp,vm,msize)] = Cadd (y[mindex(cp,vm,msize)],x);
   y[mindex(cp,vp,msize)] = Csub (y[mindex(cp,vp,msize)],x);
   y[mindex(cm,vm,msize)] = Csub (y[mindex(cm,vm,msize)],x);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_resistance (double r, int n1, int n2, COMPLEX *y, int msize)
   {
   COMPLEX x;

   if (fabs (r) < EPS)
      r = EPS;

   x.r = 1.0/r;
   x.i = 0.0;

   add_ybranch (x,n1,n2,y,msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_resistance (double r, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                        COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   // parameter derivative
   if (fabs (r) < EPS*EPS)
      r = EPS*EPS;

   x.r = -1.0/(r*r);
   x.i = 0.0;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_capacitance (double c, double f, int n1, int n2, COMPLEX *y, int msize)
   {
   COMPLEX x;

   x.r = 0.0;
   x.i = 2.0*PI*f*c;

   add_ybranch (x,n1,n2,y,msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_capacitance (double c, double f, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                         COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   x.r = 0.0;
   x.i = 2.0*PI*f;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_inductance (double l, double f, int n1, int n2, COMPLEX *y, int msize)
   {
   COMPLEX x;
   double tmp;

   tmp = 2.0*PI*f*l;
   if (fabs (tmp) < EPS)
      tmp = EPS;

   x.r = 0.0;
   x.i = -1.0/tmp;

   add_ybranch (x,n1,n2,y,msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_inductance (double l, double f, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                        COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];
   double tmp;

   tmp = 2.0*PI*f*l*l;
   if (fabs (tmp) < EPS)
      tmp = -EPS;

   x.r = 0.0;
   x.i = 1.0/tmp;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_conductance (double g, int n1, int n2, COMPLEX *y, int msize)
   {
   COMPLEX x;

   x.r = g;
   x.i = 0.0;

   add_ybranch (x,n1,n2,y,msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_conductance (double g, int n1, int n2, S_2PORT sp, COMPLEX *p, COMPLEX *q,
                         COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   x.r = 1.0;
   x.i = 0.0;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));
   
   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_series_rl (double r, double l, double f, int n1, int n2, COMPLEX *y, int msize)
   {
   COMPLEX x;
   double denom,w;

   w = 2.0*PI*f;
   denom = r*r+w*w*l*l;
   if (fabs (denom) < EPS)
      denom = EPS;

   x.r = r/denom;
   x.i = -w*l/denom;

   add_ybranch (x, n1, n2, y, msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_series_rl (double r, double l, double f, int n1, int n2, S_2PORT sp, COMPLEX *p,
                       COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr, COMPLEX *dervl)
   {
   COMPLEX x1,x2;
   COMPLEX ysens[4];
   double denom,denom2,w;

   w = 2.0*PI*f;
   denom = r*r+w*w*l*l;
   if (fabs (denom) < EPS)
      denom = EPS;

   denom2 = 1.0/(denom*denom);

   x1.r = (denom-2.0*r*r)*denom2;
   x1.i = 2.0*w*r*l*denom2;
   x2.r = -2.0*w*w*r*l*denom2;
   x2.i = w*(2.0*w*w*l*l-denom)*denom2;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));

   s_k_mag_deriv (x1, ysens, sp, dervr);
   s_k_mag_deriv (x2, ysens, sp, dervl);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_series_rc (double r, double c, double f, int n1, int n2, COMPLEX *y, int msize)
   {
   COMPLEX x;
   double denom,w,tmp;

   w = 2.0*PI*f;
   denom = 1.0 + w*w*r*r*c*c;
   if (fabs (denom) < EPS)
      denom = EPS;

   tmp = w*r*c;
   x.r = tmp*tmp/denom;
   x.i = tmp/denom;

   add_ybranch (x, n1, n2, y, msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_series_rc (double r, double c, double f, int n1, int n2, S_2PORT sp, COMPLEX *p,
                       COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervr, COMPLEX *dervc)
   {
   COMPLEX x1,x2;
   COMPLEX ysens[4];
   double denom,denom2,w;

   w = 2.0*PI*f;
   denom = 1.0 + w*w*r*r*c*c;
   if (fabs (denom) < EPS)
      denom = EPS;

   denom2 = 1.0/(denom*denom);

   x1.r = 2.0*(denom*w*w*c*c*r-w*w*w*w*r*r*r*c*c*c*c)*denom2;
   x1.i = (w*c*denom-2.0*r*r*w*w*w*c*c*c)*denom2;
   x2.r = 2.0*(denom*w*w*r*r*c-w*w*w*w*r*r*r*r*c*c*c)*denom2;
   x2.i = (w*r*denom-2.0*r*r*r*w*w*w*c*c)*denom2;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[n2],pa[n1]),Csub (p[n1],p[n2]));
   ysens[1] = Cmult (Csub (pa[n2],pa[n1]),Csub (q[n1],q[n2]));
   ysens[2] = Cmult (Csub (qa[n2],qa[n1]),Csub (p[n1],p[n2]));
   ysens[3] = Cmult (Csub (qa[n2],qa[n1]),Csub (q[n1],q[n2]));

   s_k_mag_deriv (x1, ysens, sp, dervr);
   s_k_mag_deriv (x2, ysens, sp, dervc);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_trans_cap (double c, double f, int vp, int vm, int cm, int cp,
                     COMPLEX *y, int msize)
   {
   COMPLEX x;

   x.r = 0.0;
   x.i = 2.0*PI*f*c;
 
   add_yvccs (x,vp,vm,cm,cp,y,msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_trans_cap (double c, double f, int vp, int vm, int cm, int cp, S_2PORT sp,
                       COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *derv)
   {
   COMPLEX x;
   COMPLEX ysens[4];

   x.r = 0.0;
   x.i = 2.0*PI*f;

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[cp],pa[cm]),Csub (p[vp],p[vm]));
   ysens[1] = Cmult (Csub (pa[cp],pa[cm]),Csub (q[vp],q[vm]));
   ysens[2] = Cmult (Csub (qa[cp],qa[cm]),Csub (p[vp],p[vm]));
   ysens[3] = Cmult (Csub (qa[cp],qa[cm]),Csub (q[vp],q[vm]));

   s_k_mag_deriv (x, ysens, sp, derv);
   }

/********************************************************************************************/
/********************************************************************************************/

void addy_delayed_vccs (double g, double t, double f, int vp, int vm, int cm, int cp,
                        COMPLEX *y, int msize)
   {
   COMPLEX x;
   double arg;

   arg = -2.0*PI*f*t;
   x.r = g*cos (arg);
   x.i = g*sin (arg);
 
   add_yvccs (x,vp,vm,cm,cp,y,msize);
   }

/********************************************************************************************/
/********************************************************************************************/

void derivy_delayed_vccs (double g, double t, double f, int vp, int vm, int cm, int cp, S_2PORT sp,
                          COMPLEX *p, COMPLEX *q, COMPLEX *pa, COMPLEX *qa, COMPLEX *dervg, COMPLEX *dervt)
   {
   COMPLEX x1,x2;
   COMPLEX ysens[4];
   double arg;

   arg = -2.0*PI*f*t;
   x1.r = cos (arg);
   x1.i = sin (arg);
   x2.r = 2.0*PI*f*g*cos (arg);
   x2.i = 2.0*PI*f*g*sin (arg);

   // sensitivities w.r.t. port voltages
   ysens[0] = Cmult (Csub (pa[cp],pa[cm]),Csub (p[vp],p[vm]));
   ysens[1] = Cmult (Csub (pa[cp],pa[cm]),Csub (q[vp],q[vm]));
   ysens[2] = Cmult (Csub (qa[cp],qa[cm]),Csub (p[vp],p[vm]));
   ysens[3] = Cmult (Csub (qa[cp],qa[cm]),Csub (q[vp],q[vm]));   

   s_k_mag_deriv (x1, ysens, sp, dervg);
   s_k_mag_deriv (x2, ysens, sp, dervt);
   }

/********************************************************************************************/
/********************************************************************************************/

int create_y (NETLIST *nlist, int nelem, double freq, COMPLEX *y, int max)
   {
   int i;
   int largest = 0;
   int msize;
   static COMPLEX zero = {0.0,0.0};

   // need to find largest node number
   for (i = 0; i < nelem; ++i)
      {
      switch (nlist[i].type)
         {
         case Netlist_R:
         case Netlist_C:
         case Netlist_G:
         case Netlist_L:
         case Netlist_SRL:
         case Netlist_SRC:
            if (nlist[i].nodes[0] > largest)
               largest = nlist[i].nodes[0];
            if (nlist[i].nodes[1] > largest)
               largest = nlist[i].nodes[1];
            break;
         case Netlist_VCCS:
         case Netlist_TCAP:
            if (nlist[i].nodes[0] > largest)
               largest = nlist[i].nodes[0];
            if (nlist[i].nodes[1] > largest)
               largest = nlist[i].nodes[1];
            if (nlist[i].nodes[2] > largest)
               largest = nlist[i].nodes[2];
            if (nlist[i].nodes[3] > largest)
               largest = nlist[i].nodes[3];
            break;
         default:
            break;
         }
      }

   msize = largest+1;
   if (msize > max)
      return -1;
   
   // zero the [Y] matrix
   for (i = 0; i < msize*msize; ++i)
      y[i] = zero;

   // load the elements
   for (i = 0; i < nelem; ++i)
      {
      switch (nlist[i].type)
         {
         case Netlist_R:
            addy_resistance (nlist[i].value[0],nlist[i].nodes[0],nlist[i].nodes[1],y,msize);
            break;
         case Netlist_G:
            addy_conductance (nlist[i].value[0],nlist[i].nodes[0],nlist[i].nodes[1],y,msize);
            break;
         case Netlist_C:
            addy_capacitance (nlist[i].value[0],freq,nlist[i].nodes[0],nlist[i].nodes[1],y,msize);
            break;
         case Netlist_L:
            addy_inductance (nlist[i].value[0],freq,nlist[i].nodes[0],nlist[i].nodes[1],y,msize);
            break;
         case Netlist_SRL:
            addy_series_rl (nlist[i].value[0],nlist[i].value[1],freq,nlist[i].nodes[0],nlist[i].nodes[1],y,msize);
            break;
         case Netlist_SRC:
            addy_series_rc (nlist[i].value[0],nlist[i].value[1],freq,nlist[i].nodes[0],nlist[i].nodes[1],y,msize);
            break;
         case Netlist_VCCS:
            addy_delayed_vccs (nlist[i].value[0],nlist[i].value[1],freq,nlist[i].nodes[0],nlist[i].nodes[1],nlist[i].nodes[2],nlist[i].nodes[3],y,msize);
            break;
         case Netlist_TCAP:
            addy_trans_cap (nlist[i].value[0],freq,nlist[i].nodes[0],nlist[i].nodes[1],nlist[i].nodes[2],nlist[i].nodes[3],y,msize);
            break;
         default:
            break;
         }
      }

   return msize;
   }

/********************************************************************************************/
/********************************************************************************************/

static void gradient_1value (NETLIST nlist, S_2PORT sp, double freq, COMPLEX *p, COMPLEX *q,
                      COMPLEX *pa, COMPLEX *qa, COMPLEX *grad)
   {
   switch (nlist.type)
      {
      case Netlist_R:
         derivy_resistance (nlist.value[0],nlist.nodes[0],nlist.nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_G:
         derivy_conductance (nlist.value[0],nlist.nodes[0],nlist.nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_C:
         derivy_capacitance (nlist.value[0],freq,nlist.nodes[0],nlist.nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_L:
         derivy_inductance (nlist.value[0],freq,nlist.nodes[0],nlist.nodes[1],sp,p,q,pa,qa,grad);
         break;
      case Netlist_TCAP:
         derivy_trans_cap (nlist.value[0],freq,nlist.nodes[0],nlist.nodes[1],nlist.nodes[2],nlist.nodes[3],sp,p,q,pa,qa,grad);
         break;
      default:
         break;
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static void gradient_2value (NETLIST nlist, S_2PORT sp, double freq, COMPLEX *p, COMPLEX *q,
                      COMPLEX *pa, COMPLEX *qa, COMPLEX *grad1, COMPLEX *grad2)
   {
   switch (nlist.type)
      {
      case Netlist_SRL:
         derivy_series_rl (nlist.value[0],nlist.value[1],freq,nlist.nodes[0],nlist.nodes[1],sp,p,q,pa,qa,grad1,grad2);
         break;
      case Netlist_SRC:
         derivy_series_rc (nlist.value[0],nlist.value[1],freq,nlist.nodes[0],nlist.nodes[1],sp,p,q,pa,qa,grad1,grad2);
         break;
      case Netlist_VCCS:
         derivy_delayed_vccs (nlist.value[0],nlist.value[1],freq,nlist.nodes[0],nlist.nodes[1],nlist.nodes[2],nlist.nodes[3],sp,p,q,pa,qa,grad1,grad2);
         break;
      default:
         break;
      }
   }

/********************************************************************************************/
/********************************************************************************************/

void compute_s_grads (NETLIST *nlist, int nelem, S_2PORT *sMeas, int numf, double *grads, int ngrads)
   {
   int      i,j,n;
   COMPLEX  y[10000];
   COMPLEX  p[100],q[100];
   COMPLEX  pa[100],qa[100];
   COMPLEX  grad1[6],grad2[6];
   COMPLEX  yp[4],sdiff[4];
   double   kdiff,magdiff,tmp;
   S_2PORT  sp;

#ifdef DEBUGG
   FILE *debug;
   int  m;
   
   debug = fopen ("debug.txt","w+");
#endif

   for (j = 0; j < ngrads*6; ++j)
      grads[j] = 0.0;

   for (i = 0; i < numf; ++i)
      {
      if ((n = create_y (nlist, nelem, sMeas[i].freq, y, 100)) < 0)
         {
         fprintf (stderr,"NETLIST ERROR: maximum node number is 100.\n");
         return;
         }

      // solve the Y matrix and adjoint matrix, compute s-params, k, and MAG
      twoport_adjoint_solution (y, p, q, pa, qa, n);

      yp[0] = Ccopy (y[mindex(1,1,n)]);
      yp[1] = Ccopy (y[mindex(1,2,n)]);
      yp[2] = Ccopy (y[mindex(2,1,n)]);
      yp[3] = Ccopy (y[mindex(2,2,n)]);
      y2s (yp,sp.s,50.0);
      k_mag (sp.s,&sp.k,&sp.MAG,&sp.b);
      
      // measured vs. modeled differences
      CAsub (sMeas[i].s,sp.s,sdiff,2,2);
      kdiff    = sMeas[i].k-sp.k;
      if (kdiff < 0.0)
         kdiff = -1.0;
      else
         kdiff = 1.0;

      magdiff  = sMeas[i].MAG-sp.MAG;
      if (magdiff < 0.0)
         magdiff = -1.0;
      else
         magdiff = 1.0;

      for (j = 0; j < nelem; ++j)
         {
         switch (nlist[j].type)
            {
            case Netlist_R:
            case Netlist_C:
            case Netlist_G:
            case Netlist_L:
            case Netlist_TCAP:
               // check for valid index
               if ((nlist[j].index[0] < 0) || (nlist[j].index[0] >= ngrads))
                  continue;
               // compute the gradient for the element
               gradient_1value (nlist[j], sp, sMeas[i].freq, p, q, pa, qa, grad1);
               grads[mindex(nlist[j].index[0],0,6)] -= Creal (Cmult (Cconj (sdiff[0]),grad1[0]))/Cmag (sdiff[0]);
               grads[mindex(nlist[j].index[0],1,6)] -= Creal (Cmult (Cconj (sdiff[1]),grad1[1]))/Cmag (sdiff[1]);
               grads[mindex(nlist[j].index[0],2,6)] -= Creal (Cmult (Cconj (sdiff[2]),grad1[2]))/Cmag (sdiff[2]);
               grads[mindex(nlist[j].index[0],3,6)] -= Creal (Cmult (Cconj (sdiff[3]),grad1[3]))/Cmag (sdiff[3]);
               grads[mindex(nlist[j].index[0],4,6)] -= kdiff*Creal (grad1[4]);
               grads[mindex(nlist[j].index[0],5,6)] -= magdiff*Creal (grad1[5]);
               break;
            case Netlist_SRL:
            case Netlist_SRC:
            case Netlist_VCCS:
               // compute the gradients for the element
               gradient_2value (nlist[j], sp, sMeas[i].freq, p, q, pa, qa, grad1, grad2);
               if ((nlist[j].index[0] >= 0) && (nlist[j].index[0] < ngrads))
                  {
                  grads[mindex(nlist[j].index[0],0,6)] -= Creal (Cmult (Cconj (sdiff[0]),grad1[0]))/Cmag (sdiff[0]);
                  grads[mindex(nlist[j].index[0],1,6)] -= Creal (Cmult (Cconj (sdiff[1]),grad1[1]))/Cmag (sdiff[1]);
                  grads[mindex(nlist[j].index[0],2,6)] -= Creal (Cmult (Cconj (sdiff[2]),grad1[2]))/Cmag (sdiff[2]);
                  grads[mindex(nlist[j].index[0],3,6)] -= Creal (Cmult (Cconj (sdiff[3]),grad1[3]))/Cmag (sdiff[3]);
                  grads[mindex(nlist[j].index[0],4,6)] -= kdiff*Creal (grad1[4]);
                  grads[mindex(nlist[j].index[0],5,6)] -= magdiff*Creal (grad1[5]);
                  }
               if ((nlist[j].index[1] >= 0) && (nlist[j].index[1] < ngrads))
                  {
                  grads[mindex(nlist[j].index[1],0,6)] -= Creal (Cmult (Cconj (sdiff[0]),grad2[0]))/Cmag (sdiff[0]);
                  grads[mindex(nlist[j].index[1],1,6)] -= Creal (Cmult (Cconj (sdiff[1]),grad2[1]))/Cmag (sdiff[1]);
                  grads[mindex(nlist[j].index[1],2,6)] -= Creal (Cmult (Cconj (sdiff[2]),grad2[2]))/Cmag (sdiff[2]);
                  grads[mindex(nlist[j].index[1],3,6)] -= Creal (Cmult (Cconj (sdiff[3]),grad2[3]))/Cmag (sdiff[3]);
                  grads[mindex(nlist[j].index[1],4,6)] -= kdiff*Creal (grad2[4]);
                  grads[mindex(nlist[j].index[1],5,6)] -= magdiff*Creal (grad2[5]);
                  }
               break;
            default:
               break;
            }
         }
      }

   // divide by number of frequency points
   tmp = 1.0/((double) numf);
   for (j = 0; j < ngrads*6; ++j)
      grads[j] *= tmp;

#ifdef DEBUGG
   for (m = 0; m < ngrads; ++m)
      fprintf (debug," %11.4e %11.4e %11.4e %11.4e %11.4e %11.4e\n",grads[mindex(m,0,6)],grads[mindex(m,1,6)],
            grads[mindex(m,2,6)],grads[mindex(m,3,6)],grads[mindex(m,4,6)],grads[mindex(m,5,6)]);
   fclose (debug);
#endif
   }

/********************************************************************************************/
/********************************************************************************************/

void compute_s_error (NETLIST *nlist, int nelem, S_2PORT *sMeas, int numf, double *error)
   {
   int i,n;
   COMPLEX  y[MAX_NODES*MAX_NODES];
   COMPLEX  yp[4];
   double   tmp;
   S_2PORT  sp;
   
   for (i = 0; i < 6; ++i)
      error[i] = 0.0;

   for (i = 0; i < numf; ++i)
      {
      if ((n = create_y (nlist, nelem, sMeas[i].freq, y, 100)) < 0)
         {
         fprintf (stderr,"NETLIST ERROR: maximum node number is 100.\n");
         return;
         }

      complex_matrix_reduction (y, n, 3);

      yp[0] = Ccopy (y[mindex(1,1,n)]);
      yp[1] = Ccopy (y[mindex(1,2,n)]);
      yp[2] = Ccopy (y[mindex(2,1,n)]);
      yp[3] = Ccopy (y[mindex(2,2,n)]);
      y2s (yp,sp.s,50.0);
      k_mag (sp.s,&sp.k,&sp.MAG,&sp.b);

      error[0] += Cmag (Csub (sp.s[0],sMeas[i].s[0]));
      error[1] += Cmag (Csub (sp.s[1],sMeas[i].s[1]));
      error[2] += Cmag (Csub (sp.s[2],sMeas[i].s[2]));
      error[3] += Cmag (Csub (sp.s[3],sMeas[i].s[3]));
      error[4] += fabs (sMeas[i].k - sp.k);
      error[5] += fabs (sMeas[i].MAG - sp.MAG);
      }

   tmp = 1.0/((double) numf);
   for (i = 0; i < 6; ++i)
      error[i] *= tmp;
   }

/********************************************************************************************/
/********************************************************************************************/

static void load_netlist (double *p_list, NETLIST *nlist, int nsize)
   {
   int  i;

   for (i = 0; i < nsize; ++i)
      {
      switch (nlist[i].type)
         {
         case Netlist_R:
         case Netlist_C:
         case Netlist_G:
         case Netlist_L:
         case Netlist_TCAP:
            nlist[i].value[0] = p_list[nlist[i].index[0]];
            break;
         case Netlist_SRL:
         case Netlist_SRC:
         case Netlist_VCCS:
            nlist[i].value[0] = p_list[nlist[i].index[0]];
            nlist[i].value[1] = p_list[nlist[i].index[1]];
            break;
         default:
            break;
         }
      }
   }

/********************************************************************************************/
/********************************************************************************************/

static double *ss_error_interface (double *p_list)
   {
   NETLIST  *netlist = global_netlist_pointer;
   S_2PORT  *sp = global_sp_pointer;
   static double error[6];

   // update the netlist values
   load_netlist (p_list, netlist, netlist_size);

   // compute the error function
   compute_s_error (netlist, netlist_size, sp, number_of_frequencies, error);

   return error;
   }

/********************************************************************************************/
/********************************************************************************************/

static double *ss_gradient_interface (double *p_list, int *mapping, int np)
   {
   int      i,j;
   NETLIST  *netlist = global_netlist_pointer;
   S_2PORT  *sp = global_sp_pointer;
   double   *grads = global_gradient_pointer;

   // update the netlist values
   load_netlist (p_list, netlist, netlist_size);

   // compute the error function
   compute_s_grads (netlist, netlist_size, sp, number_of_frequencies, grads, number_of_parameters);

   // re-map the gradients
   // this can be done in this fashion since the mapping values are always 
   // in increasing order
   for (i = 0; i < np; ++i)
      {
      if (i != mapping[i])
         {
         for (j = 0; j < 6; ++j)
            grads[mindex(i,j,6)] = grads[mindex(mapping[i],j,6)];
         }
      }

   return grads;
   }

/********************************************************************************************/
/********************************************************************************************/

int small_signal_optimizer (NETLIST *nlist, int nelem, PARAM_STRUCT *p, int n_params, S_2PORT *sp,
                            int numf, int max_iter, double *weights)
   {
   OPT_STRUCT   opt;

   // check that the netlist is valid and that all parameters and netlist values match up


   // make the netlist and measured S-parameters available globally
   global_netlist_pointer = nlist;
   netlist_size = nelem;
   global_sp_pointer = sp;
   number_of_frequencies = numf;
   number_of_parameters = n_params;

   // allocate memory to store the gradients in
   global_gradient_pointer = (double *) malloc (sizeof (double)*n_params*6);

   // set up the optimization structure
   initialize_optimizer (&opt,n_params,6,weights,max_iter,&ss_error_interface);
   opt.err_fraction = 1.0e-6;
   opt.gradients = &ss_gradient_interface;
   strcpy (opt.pformat,"%.4e");

   if (cg_optimize (opt,p) < 0)
      {
      free ((void *) global_gradient_pointer);
      return -1;
      }

   free ((void *) global_gradient_pointer);
   return 0;
   }

/********************************************************************************************/
/********************************************************************************************/

void netlist_component (NETLIST *nlist, int type, ...)
   {
   va_list    ap;

   va_start (ap, type);

   nlist->type = type;
   switch (type)
      {
      case Netlist_R:
      case Netlist_C:
      case Netlist_G:
      case Netlist_L:
         nlist->value[0] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, int);
         nlist->nodes[1] = va_arg (ap, int);
         nlist->index[0] = va_arg (ap, int);
         break;
      case Netlist_TCAP:
         nlist->value[0] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, int);
         nlist->nodes[1] = va_arg (ap, int);
         nlist->nodes[2] = va_arg (ap, int);
         nlist->nodes[3] = va_arg (ap, int);
         nlist->index[0] = va_arg (ap, int);
         break;
      case Netlist_SRL:
      case Netlist_SRC:
         nlist->value[0] = va_arg (ap, double);
         nlist->value[1] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, int);
         nlist->nodes[1] = va_arg (ap, int);
         nlist->index[0] = va_arg (ap, int);
         nlist->index[1] = va_arg (ap, int);
         break;
      case Netlist_VCCS:
         nlist->value[0] = va_arg (ap, double);
         nlist->value[1] = va_arg (ap, double);
         nlist->nodes[0] = va_arg (ap, int);
         nlist->nodes[1] = va_arg (ap, int);
         nlist->nodes[2] = va_arg (ap, int);
         nlist->nodes[3] = va_arg (ap, int);
         nlist->index[0] = va_arg (ap, int);
         nlist->index[1] = va_arg (ap, int);
         break;
      default:
         break;
      }

   va_end (ap);
   }

/********************************************************************************************/
/********************************************************************************************/

static char *string_to_upper (char *string)
   {
   unsigned int i;

   for (i = 0; i < strlen (string); ++i)
      {
      if ((string[i] > (char) 96) && (string[i] < (char) 123))
         string[i] -= (char) 32;
      }

   return string;
   }

/********************************************************************************************/
/********************************************************************************************/

int read_s_from_file (char *filename, S_2PORT *s, S_BIAS *bias, int sizeofs)
   {
   FILE    *infile;
   double  fscale = 1.0;
   double  t[4];
   POLAR   sp[4];
   char    string[300];
   char    ts[6];
   int     flag = 1;
   int     rimode = 0;
   int     count = 0;

   infile = fopen (filename,"r");
   if (!infile)
      return -1;

   bias->vgs = bias->vds = bias->ids = bias->igs = 0.0;

   while (fgets (string,299,infile) != NULL)
      {
      if (!strncmp (string,"!BIAS",5))
         {
         string_to_upper (string);
         if (sscanf (string,"!BIAS: VCE = %lf VOLTS ICE = %lf AMPS VBE = %lf VOLTS IBE = %lf AMPS",&t[0],&t[1],&t[2],&t[3]) == 4)
            {
            bias->vds = t[0];
            bias->ids = t[1];
            bias->vgs = t[2];
            bias->igs = t[3];
            }
         else if (sscanf (string,"!BIAS: VDS = %lf VOLTS IDS = %lf AMPS VGS = %lf VOLTS IGS = %lf AMPS",&t[0],&t[1],&t[2],&t[3]) == 4)
            {
            bias->vds = t[0];
            bias->ids = t[1];
            bias->vgs = t[2];
            bias->igs = t[3];
            }
         }
      else if (string[0] == '!')
         continue;

      if (flag)
         {
         if (sscanf (string,"#%5s",ts,ts) == 2)
            {
            string_to_upper (string);
            if (strstr (string,"KHZ"))
               fscale = 1.0e3;
            else if (strstr (string,"MHZ"))
               fscale = 1.0e6;
            else if (strstr (string,"GHZ"))
               fscale = 1.0e9;

            if (!strstr (string,"MA"))
               rimode = 1;

            flag = 0;
            }
         }

      if (rimode)
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&s[count].freq,
                     &s[count].s[0].r,&s[count].s[0].i,
                     &s[count].s[2].r,&s[count].s[2].i,
                     &s[count].s[1].r,&s[count].s[1].i,
                     &s[count].s[3].r,&s[count].s[3].i) == 9)
            {
            s[count].freq *= fscale;
            k_mag (s[count].s,&s[count].k,&s[count].MAG,&s[count].b);
            ++count;
            flag = 0;
            }
         }
      else
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&s[count].freq,
                     &sp[0].m,&sp[0].a,&sp[2].m,&sp[2].a,
                     &sp[1].m,&sp[1].a,&sp[3].m,&sp[3].a) == 9)
            {
            s[count].freq *= fscale;
            PA2CA (sp,s[count].s,2,2);
            k_mag (s[count].s,&s[count].k,&s[count].MAG,&s[count].b);
            ++count;
            flag = 0;
            }
         }

      if (count >= sizeofs)
         break;
      }

   fclose (infile);

   return count;
   }










