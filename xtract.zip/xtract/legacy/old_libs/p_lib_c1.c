#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "icon_bitmap"
#include "eventnames.h"
#include "adobefonts.h"

#define LEFT_JUSTIFY      0
#define RIGHT_JUSTIFY     1
#define CENTER_JUSTIFY    2

#define DEG2RAD           ((double) 0.01745329252)

Display       *display;
Window        window;
int           screen;
GC            gc;
char          *argv[] = {"wplot",""};
int           argc = 1;
unsigned int  win_width;
unsigned int  win_height;

/*                                                                            */
/*--- function xfsize_ -------------------------------------------------------*/
/*                                                                            */

xfsize (display_width,display_height,display_width_mm,display_height_mm)
unsigned int *display_width;
unsigned int *display_height;
float        *display_width_mm;
float        *display_height_mm;
{
char         *display_name = NULL;

if ((display = XOpenDisplay (display_name)) == NULL)
   {
   printf ("cannot connect to X server %s\n",XDisplayName (display_name));
   exit (-1);
   }

screen = DefaultScreen (display);

*display_width = DisplayWidth (display,screen);
*display_height = DisplayHeight (display,screen);
*display_width_mm = (float) DisplayWidthMM (display,screen);
*display_height_mm = (float) DisplayHeightMM (display,screen);

}

/*                                                                            */
/*--- function xfopen_ -------------------------------------------------------*/
/*                                                                            */

xfopen (desired_width_mm,desired_height_mm,actual_width_mm,actual_height_mm)
float *desired_width_mm;
float *desired_height_mm;
float *actual_width_mm;
float *actual_height_mm;
{
unsigned int border_width = 0;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;
unsigned int one_cm_wide;
unsigned int one_cm_high;
unsigned int width;
unsigned int height;
XSizeHints   size_hints;
XEvent       report;
Pixmap       icon_pixmap;
Cursor       cursor;
char         *window_name = "Wplot v1.00";
char         *display_name = NULL;
char         *icon_name = "Wplot";
int          window_size = 1;
int          x = 0;
int          y = 0;
Window       root;
unsigned int border;
unsigned int depth;

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

width = (unsigned int) (*desired_width_mm*((float) display_width)/((float) display_width_mm));
height = (unsigned int) (*desired_height_mm*((float) display_height)/((float) display_height_mm));

one_cm_wide = (unsigned int) (((float) display_width)/((float) display_width_mm));
one_cm_high = (unsigned int) (((float) display_height)/((float) display_height_mm));

if ((width > display_width-one_cm_wide) && (height < display_height-one_cm_high))
   {
   height = (unsigned int) (((float) height)*((float) (display_width-one_cm_wide))/((float) width));
   width = display_width-one_cm_wide;
   }
else if ((width < display_width-one_cm_wide) && (height > display_height-one_cm_high))
   {
   width = (unsigned int) (((float) width)*((float) (display_height-one_cm_high))/((float) height));
   height = display_height-one_cm_high;
   }

window = XCreateSimpleWindow (display,RootWindow (display,screen),x,y,width,height,border_width,BlackPixel (display,screen),WhitePixel (display,screen));

icon_pixmap = XCreateBitmapFromData (display,window,icon_bitmap_bits,icon_bitmap_width,icon_bitmap_height);

size_hints.flags = PPosition | PSize | PMinSize | PMaxSize | PAspect;
size_hints.x = x;
size_hints.y = y;
size_hints.width = width;
size_hints.height = height;
size_hints.min_width = 1;
size_hints.min_height = 1;
size_hints.max_width = width;
size_hints.max_height = height;
size_hints.min_aspect.x = 914;
size_hints.min_aspect.y = 706;
size_hints.max_aspect.x = 914;
size_hints.max_aspect.y = 706;

XSetStandardProperties (display,window,window_name,icon_name,icon_pixmap,argv,argc,&size_hints);

XSelectInput (display,window,ExposureMask | KeyPressMask | ButtonPressMask | StructureNotifyMask);

get_gc ();

XMapRaised (display,window);

/* Main Event Loop */

while (1)
   {
   XNextEvent (display,&report);
/*
   printf ("%s\n",event_names[report.type]);
*/
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XGetGeometry (display,window,&root,&x,&y,&win_width,&win_height,&border,&depth);
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         return;
      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         win_width = report.xconfigure.width;
         win_height = report.xconfigure.height;
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         break;
      case ButtonPress:
         break;
      case KeyPress:
         XCloseDisplay (display);
         return;
      default:
         break;
      }
   }

}

/*                                                                            */
/*--- function xfclose_ ------------------------------------------------------*/
/*                                                                            */

xfclose (status,actual_width_mm,actual_height_mm)
int   *status;
float *actual_width_mm;
float *actual_height_mm;
{
XEvent       report;
Window       root;
int          x;
int          y;
unsigned int border;
unsigned int depth;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

while (1)
   {
   XNextEvent (display,&report);
/*
   printf ("%s\n",event_names[report.type]);
*/
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XGetGeometry (display,window,&root,&x,&y,&win_width,&win_height,&border,&depth);
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         return;
      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         win_width = report.xconfigure.width;
         win_height = report.xconfigure.height;
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         break;
      case ButtonPress:
         break;
      case KeyPress:
         XCloseDisplay (display);
         *status = 0;
         return;
      default:
         break;
      }
   }

}

/*                                                                            */
/*--- function xfpause_ ------------------------------------------------------*/
/*                                                                            */

xfpause (status,actual_width_mm,actual_height_mm)
int *status;
float *actual_width_mm;
float *actual_height_mm;
{
XEvent       report;
Window       root;
int          x;
int          y;
unsigned int border;
unsigned int depth;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

while (1)
   {
   XNextEvent (display,&report);
/*
   printf ("%s\n",event_names[report.type]);
*/
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         XGetGeometry (display,window,&root,&x,&y,&win_width,&win_height,&border,&depth);
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         return;
      case ConfigureNotify:
         while (XCheckTypedEvent (display,ConfigureNotify,&report));
         win_width = report.xconfigure.width;
         win_height = report.xconfigure.height;
         *actual_width_mm = ((float) win_width)*((float) display_width_mm)/((float) display_width);
         *actual_height_mm = ((float) win_height)*((float) display_height_mm)/((float) display_height);
         *status = 1;
         break;
      case ButtonPress:
         break;
      case KeyPress:
         XClearWindow (display,window);
         *status = 0;
         return;
      default:
         break;
      }
   }

}

/*                                                                            */
/*--- function xfdline_ ------------------------------------------------------*/
/*                                                                            */

xfdline (x1,y1,x2,y2)
int *x1;
int *y1;
int *x2;
int *y2;
{

XDrawLine (display,window,gc,*x1,((int) win_height)-(*y1),*x2,((int) win_height)-(*y2));

}

/*                                                                            */
/*--- function xfdtext_ ------------------------------------------------------*/
/*                                                                            */

xfdtext (x,y,angle,size,string,n,font)
int   *x;
int   *y;
float *angle;
float *size;
char  string[];
int   *n;
int   *font;
{
double ang;
float  point_size;
int    adobe_font_id;

ang = (double) *angle;

/*
string[*n] = '\0';
*/

point_size = *size;

switch (*font)
   {
   case 2:
      if (point_size <= 9.0)
         {
         adobe_font_id = HELVETICA_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = HELVETICA_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = HELVETICA_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = HELVETICA_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = HELVETICA_18;
         }
      else
         {
         adobe_font_id = HELVETICA_24;
         }
      break;
   case 3:
      if (point_size <= 9.0)
         {
         adobe_font_id = TIMES_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = TIMES_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = TIMES_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = TIMES_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = TIMES_18;
         }
      else
         {
         adobe_font_id = TIMES_24;
         }
      break;
   default:
      if (point_size <= 9.0)
         {
         adobe_font_id = COURIER_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = COURIER_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = COURIER_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = COURIER_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = COURIER_18;
         }
      else
         {
         adobe_font_id = COURIER_24;
         }
      break;
   }

draw_text (string,*n,*x,((int) win_height)-(*y),ang,adobe_font_id,LEFT_JUSTIFY);

}

/*                                                                            */
/*--- function draw_text -----------------------------------------------------*/
/*                                                                            */

draw_text (string,n,x,y,angle,font,justification)
char         string[];
int          n;
int          x;
int          y;
double       angle;
unsigned int font;
unsigned int justification;
{
static unsigned long valuemask;
XFontStruct          *font_info;
static XGCValues     values;
Pixmap               bitmap;
XImage               *image;
XPoint               points[4];
double               r;
double               theta;
int                  length;
int                  width;
int                  height;
int                  x_offset;
int                  y_offset;
int                  x1_prime;
int                  y1_prime;
int                  x2_prime;
int                  y2_prime;
int                  x_pix;
int                  y_pix;
int                  last;
int                  i;
GC                   bitmap_gc;

if ((font_info = XLoadQueryFont (display,adobe_fonts[font])) == NULL)
   {
   printf ("Wplot: cannot open font\n%s\n",adobe_fonts[font]);
   exit (-1);
   }

XSetFont (display,gc,font_info->fid);

length = n;
width  = XTextWidth (font_info,string,length);
height = font_info->ascent+font_info->descent;

if (angle == (double) 0.0)
   {
   switch (justification)
      {
      case RIGHT_JUSTIFY:
         XDrawString (display,window,gc,x-width,y,string,length);
         break;
      case CENTER_JUSTIFY:
         XDrawString (display,window,gc,x-(width/2),y,string,length);
         break;
      case LEFT_JUSTIFY:
      default:
         XDrawString (display,window,gc,x,y,string,length);
         break;
      }
   return;
   }

bitmap = XCreatePixmap (display,window,(unsigned int) width,(unsigned int) height,1);

valuemask = (GCFunction | GCForeground | GCBackground | GCLineWidth | GCLineStyle |
            GCCapStyle | GCJoinStyle);

values.function   = GXcopy;
values.foreground = 0L;
values.background = 1L;
values.line_width = 1;
values.line_style = LineSolid;
values.cap_style  = CapButt;
values.join_style = JoinRound;

bitmap_gc = XCreateGC (display,bitmap,valuemask,&values);

XSetFont (display,bitmap_gc,font_info->fid);

XFillRectangle (display,bitmap,bitmap_gc,0,0,(unsigned int) width,(unsigned int) height);

XSetForeground (display,bitmap_gc,1L);
XSetBackground (display,bitmap_gc,0L);
XDrawString (display,bitmap,bitmap_gc,0,font_info->ascent,string,length);

image = XGetImage (display,bitmap,0,0,(unsigned int) width,(unsigned int) height,AllPlanes,XYPixmap);

switch (justification)
   {
   case RIGHT_JUSTIFY:
      x_offset = width;
      break;
   case CENTER_JUSTIFY:
      x_offset = width/2;
      break;
   case LEFT_JUSTIFY:
   default:
      x_offset = 0;
      break;
   }

y_offset = font_info->ascent;
/*
for (y_pix = 0; y_pix < height; ++y_pix)
   {
   last = 0;
   for (x_pix = 0; x_pix < width; ++x_pix)
      {
      if (XGetPixel (image,x_pix,y_pix) && (last == 0))
         {
         last = 1;
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x1_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y1_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         }
      else if ((XGetPixel (image,x_pix,y_pix) == 0) && last)
         {
         last = 0;
         r = sqrt (((double) x_pix-x_offset-1)*((double) x_pix-x_offset-1)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix-1 == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset-1));
            }
         x2_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y2_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         XDrawLine (display,window,gc,x1_prime,y1_prime,x2_prime,y2_prime);
         }
      else if (XGetPixel (image,x_pix,y_pix) && (x_pix == width-1))
         {
         last = 0;
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x2_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y2_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         XDrawLine (display,window,gc,x1_prime,y1_prime,x2_prime,y2_prime);
         }
      }
   }
*/
for (y_pix = 0; y_pix < height; ++y_pix)
   {
   for (x_pix = 0; x_pix < width; ++x_pix)
      {
      if (XGetPixel (image,x_pix,y_pix))
         {
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x1_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y1_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         }
         XDrawPoint (display,window,gc,x1_prime,y1_prime);
      }
   }

XFreePixmap (display,bitmap);
XFreeGC (display,bitmap_gc);
XDestroyImage (image);

}

/*                                                                            */
/*--- function get_gc --------------------------------------------------------*/
/*                                                                            */

get_gc ()
{
static unsigned long valuemask;
static XGCValues     values;

valuemask = (GCFunction | GCForeground | GCBackground | GCLineWidth |
             GCLineStyle | GCCapStyle | GCJoinStyle);

values.function   = GXcopy;
values.foreground = BlackPixel (display,screen);
values.background = WhitePixel (display,screen);
values.line_width = 1;
values.line_style = LineSolid;
values.cap_style  = CapButt;
values.join_style = JoinRound;

gc = XCreateGC (display,window,valuemask,&values);

}

/*                                                                            */
/*--- function wait_cursor ---------------------------------------------------*/
/*                                                                            */

wait_cursor (win,cursor)
Window win;
Cursor *cursor;
{

*cursor = XCreateFontCursor (display,XC_watch);

XDefineCursor(display,win,*cursor);

XFlush (display);

}

/*                                                                            */
/*--- function pointer_cursor ------------------------------------------------*/
/*                                                                            */

pointer_cursor (win,cursor)
Window win;
Cursor *cursor;
{

*cursor = XCreateFontCursor (display,XC_top_left_arrow);

XDefineCursor(display,win,*cursor);

XFlush (display);

}
