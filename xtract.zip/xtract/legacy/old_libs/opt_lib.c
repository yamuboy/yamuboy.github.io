#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include "optimize.h"

/* DECLARATIONS AND FUNCTION PROTOTYPES */

typedef struct _opt_mem_alloc
{
double    *old_err;
double    *cur_err;
double    *error1;
double    *error2;
double    *p_list;
int       *mapping;
double    *mp_list;
double    *tp_list;
double    *op_list;
double    *mfactor;
double    *offset;
double    *tol;
double    *s_dirs;
double    *grads;
double    *old_grads;
int       success;
} OPT_MEM_ALLOC;

int cg_optimize ();
int compute_gradients ();
int perform_cgsearch ();
double opt_function ();
OPT_MEM_ALLOC *cg_malloc ();
double tan_hyp ();
double arctan_hyp ();
double map_parameter ();
double unmap_parameter ();


/****************************************************************************/
/*                          OPTIMIZATION ROUTINES                           */
/****************************************************************************/

/*                                                                          */
/* ----------- cg_optimize() ---------------------------------------------- */
/*                                                                          */

/* This is the main routine.  All other routines are called from this function */

int cg_optimize (opt,params,error_string)
OPT_STRUCT     opt;
PARAM_STRUCT   *params;
char           *error_string;

{
OPT_MEM_ALLOC    *mem1;
double           *current_error;
double           *old_error;
double           weight_factor;
double           offset;
double           mfactor;
double           err_delta;
double           my_err;
double           tol;
int              i,j,k;
int              exit_flag;
int              count;
int              p_to_opt;

if (opt.num_of_params < 1)
   {
   sprintf (error_string,"CG optimize ERROR: Number of Parameters cannot be less than 1.");
   return (-1);
   }
else if (opt.num_of_criteria < 1)
   {
   sprintf (error_string,"CG optimize ERROR: Number of Optimization Criteria cannot be less than 1.");
   return (-1);
   }

mem1 = cg_malloc (opt.num_of_params,opt.num_of_criteria,1);
if (!mem1->success)
   {
   sprintf (error_string,"CG optimize ERROR: Unable to allocate memory.");
   return (-1);
   }

current_error = mem1->cur_err;
old_error = mem1->old_err;

k = 0;
for (j = 0; j < opt.num_of_params; ++j)
   {    
   mem1->p_list[j] = params[j].nom;
   if (params[j].optimize)
      {
      if (params[j].min >= params[j].max)
         {
         params[j].optimize = 0;
         }
      else
         {
         mem1->mapping[k] = j;
         mem1->mp_list[k] = map_parameter (params[j],&offset,&mfactor,&tol);
         mem1->offset[k] = offset;
         mem1->mfactor[k] = mfactor;
	 mem1->op_list[k] = mem1->mp_list[k];
	 mem1->tol[k] = tol;
         ++k;
         }
      }
   }
p_to_opt = k;

weight_factor = (double) 0.0;
for (j = 0; j < opt.num_of_criteria; ++j)
   {
   weight_factor += opt.weights[j];
   }

if (weight_factor == (double) 0.0)
   {
   sprintf (error_string,"CG optimize ERROR: All weights are zero.");
   return (-1);
   }
   
my_err = opt_function (opt,mem1,mem1->mp_list,p_to_opt);

if (opt.max_iterations < 2)
   {
   if (opt.flags & OPT_VERBOSE)
      {
      fprintf (stderr,"%-4d ",1);
      for (j = 0; j < opt.num_of_criteria; ++j)
         {
         fprintf (stderr,"%.8e  ",current_error[j]*opt.weights[j]/weight_factor);
         }
      fprintf (stderr,"\n");
      }

   cg_malloc (0,0,-1);
   return (0);
   }

count = 0;
/* main optimization loop */
for (i = 1; i <= opt.max_iterations; ++i)
   {
   for (j = 0; j < opt.num_of_criteria; ++j)
      {
      old_error[j] = current_error[j];
      }

   if (compute_gradients (opt,mem1,p_to_opt,error_string) < 0)
      {
      cg_malloc (0,0,-1);
      return (-1);
      }
      
   if (perform_cgsearch (opt,mem1,p_to_opt,i,error_string) < 0)
      {
      cg_malloc (0,0,-1);
      return (-1);
      }   

   if (opt.flags & OPT_VERBOSE)
      {
      fprintf (stderr,"%-4d ",i);
      for (j = 0; j < opt.num_of_criteria; ++j)
         {
         fprintf (stderr,"%.8e  ",current_error[j]*opt.weights[j]/weight_factor);
         }
      fprintf (stderr,"\n");
      }

   /* do checks for completed optimization */
   exit_flag = 0;
   for (j = 0; j < opt.num_of_criteria; ++j)
      {
      err_delta = fabs (old_error[j]-current_error[j])*opt.weights[j];
      if (err_delta > opt.err_fraction*fabs (current_error[j]))
         {
         ++exit_flag;
         }
      }

   if (exit_flag == 0)
      {
      if (count < 4)
         {
         ++count;
         }
      else
         {
         break;
         }
      }
   else
      {
      count = 0;
      }

   k = 0;
   for (j = 0; j < p_to_opt; ++j)
      {
      if (fabs (mem1->op_list[k]-mem1->mp_list[k]) < mem1->tol[k])
	 {
	 ++k;
	 }
      mem1->op_list[k] = mem1->mp_list[k];
      }
   if (k == p_to_opt)
      {
      break;
      }
   }

for (j = 0; j < p_to_opt; ++j)
   {
   mem1->p_list[mem1->mapping[j]] = unmap_parameter (mem1->mp_list[j],mem1->offset[j],mem1->mfactor[j]);
   }

for (j = 0; j < opt.num_of_params; ++j)
   {
   params[j].nom = mem1->p_list[j];
   }

/* frees all allocated memory */
cg_malloc (0,0,-1);

if (opt.flags & OPT_VERBOSE)
   {
   fprintf (stderr,"Optimization Complete.\n");
   }

return (0);
}


/*                                                                          */
/* ----------- compute_gradients() ---------------------------------------- */
/*                                                                          */

static int compute_gradients (opt,mem1,np,err_str)
OPT_STRUCT       *opt;
OPT_MEM_ALLOC    *mem1;
int              np;
char             *err_str;

{
double         *grads;
double         *error1;
double         *error2;
double         *pl,*mpl;
double         my_err;
double         delta;
double         temp1,temp2;
int            i,j;
int            nc;

nc = opt->num_of_criteria;
pl = mem1->p_list;
mpl = mem1->mp_list;
error1 = mem1->error1;
error2 = mem1->error2;
grads = mem1->grads;

/* copy the current gradients for memory */
for (i = 0; i < nc*np; ++i)
   {
   mem1->old_grads[i] = grads[i];
   }
   
for (i = 0; i < np; ++i)
   {
   if (fabs (mpl[i]) >= (double) 8.0)
      {
      delta = (double) 0.5;
      }
   else
      {
      delta = fabs (mpl[i])*((double) 1.0e-4);
      if (delta < (double) 1.0e-8)
         {
         delta = (double) 1.0e-8;
         }
      }

   temp1 = mpl[i];  
   temp2 = pl[mem1->mapping[i]];
   
   mpl[i] = temp1+delta;
   my_err = opt_function (opt,mem1,mpl,np);
   if (isnan (my_err))
      {
      for (j = 0; j < nc; ++j)
         {
         error1[j] = mem1->old_err[j];
         fprintf (stderr,"WARNING: NaN encountered in gradient.\n");
         }
      }
   else
      {
      for (j = 0; j < nc; ++j)
         {
         error1[j] = mem1->cur_err[j];
         }
      }
      
   mpl[i] = temp1-delta;
   my_err = opt_function (opt,mem1,mpl,np);
   if (isnan (my_err))
      {
      for (j = 0; j < nc; ++j)
         {
         error2[j] = mem1->old_err[j];
         fprintf (stderr,"WARNING: NaN encountered in gradient.\n");
         }
      }
   else
      {
      for (j = 0; j < nc; ++j)
         {
         error2[j] = mem1->cur_err[j];
         }
      }

   mpl[i] = temp1;
   pl[mem1->mapping[i]] = temp2;

   for (j = 0; j < nc; ++j)
      {
      /* use negative gradient */
      grads[i*nc+j] = (error2[j]-error1[j])*((double) 0.5)/delta;

      if (isnan (grads[i*nc+j]))
         {
         grads[i*nc+j] = (double) 0.0;
         fprintf (stderr,"WARNING: NaN encountered in gradient.\n");
         }

      /* don't allow gradients to point outside of min/max range */
      if ((mpl[i] >= (double) 10.0) && (grads[i*nc+j] > (double) 0.0))
         {
         grads[i*nc+j] = (double) 0.0;
         }
      else if ((mpl[i] <= (double) -10.0) && (grads[i*nc+j] < (double) 0.0))
         {
         grads[i*nc+j] = (double) 0.0;
         }
      }
   }

return (0);
}


/*                                                                          */
/* ----------- perform_cgsearch() ----------------------------------------- */
/*                                                                          */

static int perform_cgsearch (opt,mem1,np,iter,err_str)
OPT_STRUCT       *opt;
OPT_MEM_ALLOC    *mem1;
int              np;
int              iter;
char             *err_str;

{
double         *grads;
double         *old_grads;
double         *s_dir;
double         *pl,*mpl,*tp;
static double  last_error;
double         alpha;
double         beta;
double         last_alpha;
double         x1,x2,x3,y1,y2,y3,z1;
int            repeat;
int            i,j,k;
int            nc;

nc = opt->num_of_criteria;
pl = mem1->p_list;
mpl = mem1->mp_list;
tp = mem1->tp_list;
s_dir = mem1->s_dirs;
grads = mem1->grads;
old_grads = mem1->old_grads;

if (iter == 1)
   {
   last_error = (double) 0.0;
   x1 = (double) 0.0;
   for (j = 0; j < nc; ++j)
      {
      last_error += mem1->old_err[j]*opt->weights[j];
      x1 += opt->weights[j];
      }
   last_error = last_error/x1;

   for (i = 0; i < np; ++i)
      {
      s_dir[i] = (double) 0.0;
      }
   }

/* compute beta (search direction memory parameter) */
if (iter > 1)
   {
   x1 = (double) 0.0;
   x2 = (double) 0.0;
   for (i = 0; i < np; ++i)
      {
      x3 = (double) 0.0;
      y1 = (double) 0.0;
      for (j = 0; j < nc; ++j)
         {
         x3 += old_grads[i*nc+j]*opt->weights[j];
         y1 += grads[i*nc+j]*opt->weights[j];
         }
      x1 += x3*x3;
      x2 += y1*y1;
      }

   if (x1 < (double) 1.0e-24)
      {
      beta = (double) 0.0;
      }
   else 
      {
      beta = x2/x1;
      }

   if (beta > (double) 10.0)
      {
      beta = (double) 0.0;
      }
   }
else
   {
   beta = (double) 0.0;
   }

/* compute the search direction */
for (i = 0; i < np; ++i)
   {
   x1 = (double) 0.0;
   x2 = (double) 0.0;
   for (j = 0; j < nc; ++j)
      {
      x1 += grads[i*nc+j]*opt->weights[j];
      x2 += opt->weights[j];
      }
   s_dir[i] = s_dir[i]*beta + x1/x2;
   }

/* find a new alpha based on the maximum gradient */
x1 = (double) 0.0;
for (i = 0; i < np; ++i)
   {
   if (fabs (s_dir[i]) > fabs (x1))
      {
      x1 = s_dir[i];
      }
   }
if (x1 == (double) 0.0)
   {
   sprintf (err_str,"CG search ERROR: All gradients are zero, function cannot be optimized.");
   return (-1);
   }
alpha = ((double) 0.5)/fabs (x1);

/* find the best approximate step size (alpha) */
y1 = last_error;
x1 = (double) 0.0;
last_alpha = alpha;
repeat = 1;
do {
   for (i = 0; i < np; ++i)
      {
      tp[i] = mpl[i]+alpha*s_dir[i];
      }
   y2 = opt_function (opt,mem1,tp,np);

   if ((y2 > y1) || (isnan (y2)))
      {
      alpha *= (double) 0.5;
      }
   if ((alpha < ((double) 1.0e-5)*last_alpha) && repeat)
      {
      alpha = last_alpha*((double) 3.0);
      repeat = 0;
      }
   if (alpha < (double) 1.0e-50)
      {
      for (j = 0; j < nc; ++j)
         { 
         mem1->cur_err[j] = mem1->old_err[j];
         }
      return (0);
      }
   }
while (y2 > y1);

/* perform the line search */
x1 = (double) 0.0;
x2 = alpha;
k = 0;
do {
   repeat = 0;
   x3 = x2+alpha;
   for (i = 0; i < np; ++i)
      {
      tp[i] = mpl[i]+x3*s_dir[i];
      }
   y3 = opt_function (opt,mem1,tp,np);

   for (i = 0; i < np; ++i)
      {
      tp[i] = mpl[i]+x2*s_dir[i];
      }
   y2 = opt_function (opt,mem1,tp,np);

   if (isnan (y3))
      {
      break;
      }

   if ((y3 < y2) && (++k < 10))
      {
      y1 = y2;
      x1 = x2;
      y2 = y3;
      x2 = x3;
      repeat = 1;
      }
   }
while (repeat);

/* now the local minimum is bounded between alpha=x1 and alpha=x3 */
/* do a quadratic fit to find the optimum alpha */
alpha = ((double) 0.5)*(x1+x2+(y1-y2)*(x3-x1)*(x3-x2)/(x1*(y2-y3)+x2*(y3-y1)+x3*(y2-y1)));
if ((alpha <= x1) || (alpha >= x3) || isnan (alpha))
   {
   for (i = 0; i < np; ++i)
      {
      mpl[i] = mpl[i]+x2*s_dir[i];
      }
   last_error = y2;
   return (0);
   }

for (i = 0; i < np; ++i)
   {
   tp[i] = mpl[i]+alpha*s_dir[i];
   }
z1 = opt_function (opt,mem1,tp,np);

if (isnan (z1) || (y2 < z1))
   {
   for (i = 0; i < np; ++i)
      {
      mpl[i] = mpl[i]+x2*s_dir[i];
      }
   last_error = opt_function (opt,mem1,mpl,np);
   }
else
   {
   for (i = 0; i < np; ++i)
      {
      mpl[i] = mpl[i]+alpha*s_dir[i];
      }
   last_error = z1;
   }

return (0);
}


/*                                                                          */
/* ----------- opt_function() --------------------------------------------- */
/*                                                                          */

static double opt_function (opt,mem1,mpl,np)
OPT_STRUCT       *opt;
OPT_MEM_ALLOC    *mem1;
double           *mpl;
int              np;

{
double   *err1;
double   x1;
double   x2;
int      i;

for (i = 0; i < np; ++i)
   {
   mem1->p_list[mem1->mapping[i]] = unmap_parameter (mpl[i],mem1->offset[i],mem1->mfactor[i]);
   }
err1 = opt->function (mem1->p_list);

x1 = (double) 0.0;
x2 = (double) 0.0;
for (i = 0; i < opt->num_of_criteria; ++i)
   {
   x1 += err1[i]*opt->weights[i];
   x2 += opt->weights[i];
   mem1->cur_err[i] = err1[i]; 
   }
x1 = x1/x2;

return (x1);
}


/*                                                                          */
/* ----------- map_parameter() -------------------------------------------- */
/*                                                                          */

static double map_parameter (p,offset,mag,tol)
PARAM_STRUCT  *p;
double        *offset;
double        *mag;
double        *tol;

{
*mag = ((double) 2.0)/(p->max-p->min);
*offset = (p->max+p->min)*((double) 0.5);
*tol = arctan_hyp (p->tol*(*mag));

return (arctan_hyp ((*mag)*(p->nom-(*offset))));
}

/*                                                                          */
/* ----------- unmap_parameter() ------------------------------------------ */
/*                                                                          */

static double unmap_parameter (mparam,offset,mag)
double mparam;
double offset;
double mag;

{
return (tan_hyp (mparam)/mag+offset);
}

/*                                                                          */
/* ----------- tan_hyp() -------------------------------------------------- */
/*                                                                          */

static double tan_hyp (x)
double x;

{
double y;

if (x >= (double) 70.0)
   {
   y = (double) 1.0;
   }
else if (x <= (double) -70.0)
   {
   y = (double) -1.0;
   }
else
   {
   y = (exp (x) - exp (-x))/(exp (x) + exp (-x));
   }

return (y);
}


/*                                                                          */
/* ----------- arctan_hyp() ----------------------------------------------- */
/*                                                                          */

static double arctan_hyp (x)
double x;

{
double y;

if (x >= (double) 1.0)
   {
   y = (double) 70.0;
   }
else if (x <= (double) -1.0)
   {
   y = (double) -70.0;
   }
else
   {
   y = ((double) 0.5)*log ((((double) 1.0)+x)/(((double) 1.0)-x));
   }

return (y);
}


/*                                                                          */
/* ----------- cg_malloc() ------------------------------------------------ */
/*                                                                          */

static OPT_MEM_ALLOC *cg_malloc (np,nc,mode)
int  np;
int  nc;
int  mode;

{
static OPT_MEM_ALLOC   mem1;

switch (mode)
   {
   case 1:
      mem1.old_err = (double *) malloc (sizeof (double)*nc);
      mem1.cur_err = (double *) malloc (sizeof (double)*nc);
      mem1.error1 = (double *) malloc (sizeof (double)*nc);
      mem1.error2 = (double *) malloc (sizeof (double)*nc);
      mem1.p_list = (double *) malloc (sizeof (double)*np);
      mem1.mp_list = (double *) malloc (sizeof (double)*np);
      mem1.tp_list = (double *) malloc (sizeof (double)*np);
      mem1.op_list = (double *) malloc (sizeof (double)*np);
      mem1.mapping = (int *) malloc (sizeof (int)*np);
      mem1.mfactor = (double *) malloc (sizeof (double)*np);
      mem1.offset = (double *) malloc (sizeof (double)*np);
      mem1.tol = (double *) malloc (sizeof (double)*np);
      mem1.s_dirs = (double *) malloc (sizeof (double)*np);
      mem1.grads = (double *) malloc (sizeof (double)*np*nc);
      mem1.old_grads = (double *) malloc (sizeof (double)*np*nc);

      if ((mem1.old_err == NULL) || (mem1.cur_err == NULL) || (mem1.error1 == NULL) ||
          (mem1.error2 == NULL) || (mem1.p_list == NULL) || (mem1.mapping == NULL) ||
          (mem1.mp_list == NULL) || (mem1.tp_list == NULL) || (mem1.mfactor == NULL) ||
          (mem1.offset == NULL) || (mem1.s_dirs == NULL) || (mem1.grads == NULL) ||
          (mem1.old_grads == NULL) || (mem1.tol == NULL) || (mem1.op_list == NULL))
         {
         free ((char *) mem1.old_err);
         free ((char *) mem1.cur_err);
         free ((char *) mem1.error1);
         free ((char *) mem1.error2);
         free ((char *) mem1.p_list);
         free ((char *) mem1.mapping);
         free ((char *) mem1.mp_list);
         free ((char *) mem1.tp_list);
	 free ((char *) mem1.op_list);
         free ((char *) mem1.mfactor);
         free ((char *) mem1.offset);
	 free ((char *) mem1.tol);
         free ((char *) mem1.s_dirs);
         free ((char *) mem1.grads);
         free ((char *) mem1.old_grads);
         mem1.success = 0;
         }
      else
         {
         mem1.success = 1;
         }
      break;

   case -1:
      free ((char *) mem1.old_err);
      free ((char *) mem1.cur_err);
      free ((char *) mem1.error1);
      free ((char *) mem1.error2);
      free ((char *) mem1.p_list);
      free ((char *) mem1.mapping);
      free ((char *) mem1.mp_list);
      free ((char *) mem1.tp_list);
      free ((char *) mem1.op_list);
      free ((char *) mem1.mfactor);
      free ((char *) mem1.offset);
      free ((char *) mem1.tol);
      free ((char *) mem1.s_dirs);
      free ((char *) mem1.grads);
      free ((char *) mem1.old_grads);
      mem1.success = 0;
      break;

   case 0:
   default:
      break;
   }

return (&mem1);
}
