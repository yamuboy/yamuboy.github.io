#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "icon_bitmap"
#include "eventnames.h"
#include "adobefonts.h"

#define LEFT_JUSTIFY      0
#define RIGHT_JUSTIFY     1
#define CENTER_JUSTIFY    2

#define DEG2RAD           ((double) 0.01745329252)

Display      *display;
Window       window;
int          screen;
GC           gc;
unsigned int win_width;
unsigned int win_height;
char         *argv[] = {"wplot",""};
int          argc = 1;

xfopen_ ()
{
unsigned int width;
unsigned int height;
unsigned int border_width = 0;
unsigned int display_width;
unsigned int display_height;
unsigned int display_width_mm;
unsigned int display_height_mm;
XSizeHints   size_hints;
XEvent       report;
Pixmap       icon_pixmap;
Cursor       cursor;
char         *window_name = "Wplot v1.00";
char         *display_name = NULL;
char         *icon_name = "Wplot";
int          window_size = 1;
int          x = 0;
int          y = 0;

if ((display = XOpenDisplay (display_name)) == NULL)
   {
   printf ("cannot connect to X server %s\n",XDisplayName (display_name));
   exit (-1);
   }

screen = DefaultScreen (display);

display_width = DisplayWidth (display,screen);
display_height = DisplayHeight (display,screen);
display_width_mm = DisplayWidthMM (display,screen);
display_height_mm = DisplayHeightMM (display,screen);

width = (unsigned int) (11.0*25.4*((float) display_width)/((float) display_width_mm));
height = (unsigned int) (8.5*25.4*((float) display_height)/((float) display_height_mm));

if ((width > display_width-10) || (height > display_height-10))
   {
   width = display_width-10;
   height = display_height-10;
   }

printf ("%d %d test\n",width,height);

win_width = width;
win_height = height;

window = XCreateSimpleWindow (display,RootWindow (display,screen),x,y,width,height,border_width,BlackPixel (display,screen),WhitePixel (display,screen));

icon_pixmap = XCreateBitmapFromData (display,window,icon_bitmap_bits,icon_bitmap_width,icon_bitmap_height);

size_hints.flags = PPosition | PSize | PMinSize | PMaxSize;
size_hints.x = x;
size_hints.y = y;
size_hints.width = width;
size_hints.height = height;
size_hints.min_width = 10;
size_hints.min_height = 10;
size_hints.max_width = (int) (11.0*25.4*((float) display_width)/((float) display_width_mm));
size_hints.max_height = (int) (8.5*25.4*((float) display_height)/((float) display_height_mm));

XSetStandardProperties (display,window,window_name,icon_name,icon_pixmap,argv,argc,&size_hints);

XSelectInput (display,window,ExposureMask | KeyPressMask | ButtonPressMask | StructureNotifyMask);

get_gc ();

XMapWindow (display,window);

/* Main Event Loop */

while (1)
   {
   XNextEvent (display,&report);
   printf ("%s\n",event_names[report.type]);
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         return;
         break;
      case ConfigureNotify:
         width = report.xconfigure.width;
         height = report.xconfigure.height;
         printf ("%d %d\n",width,height);
         if ((width < size_hints.min_width) || (height < size_hints.min_height))
            {
            window_size = 1;
            }
         else
            {
            window_size = 0;
            }
         break;
      case ButtonPress:
      case KeyPress:
         XCloseDisplay (display);
         return;
      default:
         break;
      }
   }

}

xfclose_ (status)
int *status;
{
XEvent       report;

XFlush (display);

while (1)
   {
   XNextEvent (display,&report);
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         *status = 1;
         return;
      case ConfigureNotify:
         break;
      case ButtonPress:
      case KeyPress:
         XCloseDisplay (display);
         *status = 0;
         return;
      default:
         break;
      }
   }

}

xfpause_ (status)
int *status;
{
XEvent report;

XFlush (display);

while (1)
   {
   XNextEvent (display,&report);
   switch (report.type)
      {
      case Expose:
         while (XCheckTypedEvent (display,Expose,&report));
         *status = 1;
         return;
      case ConfigureNotify:
         break;
      case ButtonPress:
      case KeyPress:
         XClearWindow (display,window);
         *status = 0;
         return;
      default:
         break;
      }
   }

}

xfdline_ (x1,y1,x2,y2)
int *x1;
int *y1;
int *x2;
int *y2;
{

XDrawLine (display,window,gc,*x1,win_height - *y1,*x2,win_height - *y2);

}

xfdtext_ (x,y,angle,size,string,n,font)
int   *x;
int   *y;
float *angle;
float *size;
char  *string;
int   *n;
int   *font;
{
double ang;
float  point_size;
int    adobe_font_id;

ang = (double) *angle;
string[*n] = '\0';

point_size = *size * 1.85;

switch (*font)
   {
   case 2:
      if (point_size <= 9.0)
         {
         adobe_font_id = HELVETICA_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = HELVETICA_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = HELVETICA_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = HELVETICA_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = HELVETICA_18;
         }
      else
         {
         adobe_font_id = HELVETICA_24;
         }
      break;
   case 3:
      if (point_size <= 9.0)
         {
         adobe_font_id = TIMES_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = TIMES_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = TIMES_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = TIMES_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = TIMES_18;
         }
      else
         {
         adobe_font_id = TIMES_24;
         }
      break;
   default:
      if (point_size <= 9.0)
         {
         adobe_font_id = COURIER_8;
         }
      else if (point_size <= 11.0)
         {
         adobe_font_id = COURIER_10;
         }
      else if (point_size <= 13.0)
         {
         adobe_font_id = COURIER_12;
         }
      else if (point_size <= 16.0)
         {
         adobe_font_id = COURIER_14;
         }
      else if (point_size <= 21.0)
         {
         adobe_font_id = COURIER_18;
         }
      else
         {
         adobe_font_id = COURIER_24;
         }
      break;
   }

draw_text (string,*x,win_height - *y,ang,adobe_font_id,LEFT_JUSTIFY);

}

draw_text (string,x,y,angle,font,justification)
char         *string;
unsigned int x;
unsigned int y;
double       angle;
unsigned int font;
unsigned int justification;
{
XFontStruct  *font_info;
XGCValues     values;
Pixmap        bitmap;
XImage        *image;
XPoint        points[4];
double        r;
double        theta;
int           length;
int           width;
int           height;
int           x_offset;
int           y_offset;
int           x_prime;
int           y_prime;
int           x_pix;
int           y_pix;
int           i;
GC            bitmap_gc;

if ((font_info = XLoadQueryFont (display,adobe_fonts[font])) == NULL)
   {
   printf ("Wplot: cannot open font\n%s\n",adobe_fonts[font]);
   exit (-1);
   }

XSetFont (display,gc,font_info->fid);

length = strlen (string);
width  = XTextWidth (font_info,string,length);
height = font_info->ascent+font_info->descent;

if (angle == (double) 0.0)
   {
   switch (justification)
      {
      case RIGHT_JUSTIFY:
         XDrawString (display,window,gc,x-width,y,string,length);
         break;
      case CENTER_JUSTIFY:
         XDrawString (display,window,gc,x-(width/2),y,string,length);
         break;
      case LEFT_JUSTIFY:
      default:
         XDrawString (display,window,gc,x,y,string,length);
         break;
      }
   return;
   }

bitmap = XCreatePixmap (display,window,width,height,1);

bitmap_gc = XCreateGC (display,bitmap,0,&values);

XSetFont (display,bitmap_gc,font_info->fid);

XSetForeground (display,bitmap_gc,WhitePixel (display,screen));
XFillRectangle (display,bitmap,bitmap_gc,0,0,width,height);

XSetForeground (display,bitmap_gc,BlackPixel (display,screen));
XDrawString (display,bitmap,bitmap_gc,0,font_info->ascent,string,length);

image = XGetImage (display,bitmap,0,0,width,height,AllPlanes,XYPixmap);

switch (justification)
   {
   case RIGHT_JUSTIFY:
      x_offset = width;
      break;
   case CENTER_JUSTIFY:
      x_offset = width/2;
      break;
   case LEFT_JUSTIFY:
   default:
      x_offset = 0;
      break;
   }

y_offset = font_info->ascent;

for (x_pix = 0; x_pix < width; ++x_pix)
   {
   for (y_pix = 0; y_pix < height; ++y_pix)
      {
      if (XGetPixel (image,x_pix,y_pix))
         {
         r = sqrt (((double) x_pix-x_offset)*((double) x_pix-x_offset)+((double) y_pix-y_offset)*((double) y_pix-y_offset));
         if ((x_pix == x_offset) && (y_pix == y_offset))
            {
            theta = (double) 0.0;
            }
         else
            {
            theta = atan2 (((double) y_pix-y_offset),((double) x_pix-x_offset));
            }
         x_prime = ((int) (r*cos (theta-angle*DEG2RAD)+0.5))+x;
         y_prime = ((int) (r*sin (theta-angle*DEG2RAD)+0.5))+y;
         XDrawPoint (display,window,gc,x_prime,y_prime);
         }
      }
   }

XFreePixmap (display,bitmap);
XFreeGC (display,bitmap_gc);
XDestroyImage (image);

}

get_gc ()
{

gc = DefaultGC (display,screen);

XSetLineAttributes (display,gc,0,LineSolid,CapButt,JoinRound);

XSetFunction (display,gc,GXor);

XSetBackground (display,gc,WhitePixel (display,screen));

XSetForeground (display,gc,BlackPixel (display,screen));

}

wait_cursor (win,cursor)
Window win;
Cursor *cursor;
{

*cursor = XCreateFontCursor (display,XC_watch);

XDefineCursor(display,win,*cursor);

XFlush (display);

}

pointer_cursor (win,cursor)
Window win;
Cursor *cursor;
{

*cursor = XCreateFontCursor (display,XC_top_left_arrow);

XDefineCursor(display,win,*cursor);

XFlush (display);

}
