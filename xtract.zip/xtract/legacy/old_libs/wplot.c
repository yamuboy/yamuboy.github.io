#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include <time.h>

/*--- define driver types ---*/

#define PROMPT         -1
#define POSTSCRIPT      0
#define XWINDOWS        1

/*--- define font types ---*/

#define COURIER                0
#define COURIER_OBLIQUE        1
#define COURIER_BOLD           2
#define COURIER_BOLDOBLIQUE    3
#define HELVETICA              4
#define HELVETICA_OBLIQUE      5
#define HELVETICA_BOLD         6
#define HELVETICA_BOLDOBLIQUE  7
#define TIMES_ROMAN            8
#define TIMES_ITALIC           9
#define TIMES_BOLD            10
#define TIMES_BOLDITALIC      11
#define SYMBOL                12

/*--- define text justification types ---*/

#define LEFT_JUSTIFY    0
#define RIGHT_JUSTIFY   1
#define CENTER_JUSTIFY  2

/*--- define wplot objects ---*/

struct wplot_text   /*- text object -*/
{
int               fg_r;
int               fg_g;
int               fg_b;
int               font;
int               justification;
char              *text;
float             x;
float             y;
float             angle;
float             point_size;
struct wplot_text *next;
struct wplot_text *previous;
};

struct wplot_last   /*- object for last color, font, etc used -*/
{
int               fg_r;
int               fg_g;
int               fg_b;
int               font;
int               page_number;
float             point_size;
};

/*--- wplot function definitions ---*/

void select_device_driver ();
void open_device_driver ();
void plot_text_object ();
void close_device_driver ();

/*--- wplot global variables ---*/

int               device_driver = PROMPT;
char              plot_file_name[512];
FILE              *plot_file;
struct wplot_last last;

main ()
{
struct wplot_text t1;
struct wplot_text t2;
struct wplot_text t3;
char              b1[80];
char              b2[80];
char              b3[80];

strcpy (b1,"this \\is a test 1");
strcpy (b2,"this (is a test 2");
strcpy (b3,"this )is a test 3");

t1.fg_r          =   0;
t1.fg_g          =   0;
t1.fg_b          =   0;
t1.font          = TIMES_BOLD;
t1.justification = RIGHT_JUSTIFY;
t1.text          = b1;
t1.x             = 200.0;
t1.y             = 200.0;
t1.angle         = -45.0;
t1.point_size    = 24.0;

t2.fg_r          = 255;
t2.fg_g          =   0;
t2.fg_b          =   0;
t2.font          = HELVETICA_BOLDOBLIQUE;
t2.justification = LEFT_JUSTIFY;
t2.text          = b2;
t2.x             = 200.0;
t2.y             = 300.0;
t2.angle         = 45.0;
t2.point_size    = 24.0;

t3.fg_r          =   0;
t3.fg_g          =   0;
t3.fg_b          = 255;
t3.font          = SYMBOL;
t3.justification = CENTER_JUSTIFY;
t3.text          = b3;
t3.x             = 200.0;
t3.y             = 400.0;
t3.angle         = 5.0;
t3.point_size    = 24.0;

select_device_driver ("prompt");
open_device_driver ();
plot_text_object (&(t1));
plot_text_object (&(t2));
plot_text_object (&(t3));
close_device_driver ();

}

/*                                                                            */
/*--- function select_device_driver ------------------------------------------*/
/*                                                                            */

void select_device_driver (type)
char type[];
{

strcpy (plot_file_name,"postscript.dat");

if (strcmp (type,"postscript") == 0)
   {
   device_driver = 0;
   last.fg_r = 0;
   last.fg_g = 0;
   last.fg_b = 0;
   last.point_size = 0.0;
   last.font = -1;
   }
else if (strcmp (type,"xwindows") == 0)
   {
   device_driver = 1;
   }
else
   {
   loop:
   printf ("\n");
   printf ("graphics device driver?\n");
   printf ("\n");
   printf ("     0 = Postscript Printer File\n");
   printf ("     1 = X-Windows\n");
   printf ("\n");
   printf ("enter your choice > ");
   scanf ("%d",&device_driver);
   if ((device_driver < 0) || (device_driver > 1))
      {
      printf ("\n");
      printf ("** error ** enter a number from 0 - 1\n");
      goto loop;
      }
   }

}

/*                                                                            */
/*--- function open_device_driver --------------------------------------------*/
/*                                                                            */

void open_device_driver ()
{
time_t time_location;

switch (device_driver)
   {
   case POSTSCRIPT:
      plot_file = (FILE *) NULL;
      plot_file = fopen (plot_file_name,"w+");
      if (plot_file == (FILE *) NULL)
         {
         printf ("can't open file %s for write\n",plot_file_name);
         exit (1);
         }
      time (&time_location);
      fprintf (plot_file,"%%!PS-Adobe-1.0\n");
      fprintf (plot_file,"%%%%Creator: Wplot postscript plot driver\n");
      fprintf (plot_file,"%%%%Title: None\n");
      fprintf (plot_file,"%%%%CreationDate: %s",asctime (localtime (&time_location)));
      fprintf (plot_file,"%%%%Pages: (atend)\n");
      fprintf (plot_file,"%%%%DocumentFonts: (atend)\n");
      fprintf (plot_file,"%%%%BoundingBox: (atend)\n");
      fprintf (plot_file,"%%%%EndComments\n");
      fprintf (plot_file,"/v   {newpath moveto lineto stroke} def\n");
      fprintf (plot_file,"/tl  {moveto show} def\n");
      fprintf (plot_file,"/tr  {moveto dup stringwidth neg exch neg exch rmoveto show} def\n");
      fprintf (plot_file,"/tc  {moveto dup stringwidth neg 2 div exch neg 2 div exch rmoveto show} def\n");
      fprintf (plot_file,"/tlr {gsave moveto rotate show grestore} def\n");
      fprintf (plot_file,"/trr {gsave moveto rotate dup stringwidth neg exch neg exch rmoveto show grestore} def\n");
      fprintf (plot_file,"/tcr {gsave moveto rotate dup stringwidth neg 2 div exch neg 2 div exch rmoveto show grestore} def\n");
      fprintf (plot_file,"%%%%EndProlog\n");
      fprintf (plot_file,"%%%%Page: 1 1\n");
      fprintf (plot_file,"2 setlinecap\n");
      fprintf (plot_file,"0.5 setlinewidth\n");
      last.page_number = 1;
      last.fg_r = 0;
      last.fg_g = 0;
      last.fg_b = 0;
      break;
   case XWINDOWS:
      break;
   default:
      printf ("** error in open_device_driver ** unknown device driver\n");
      break;
   }
}

/*                                                                            */
/*--- function close_device_driver -------------------------------------------*/
/*                                                                            */

void close_device_driver ()
{

switch (device_driver)
   {
   case POSTSCRIPT:
      fprintf (plot_file,"showpage\n");
      fprintf (plot_file,"%%%%Pages: %d\n",last.page_number);
      fclose (plot_file);
      break;
   case XWINDOWS:
      break;
   default:
      printf ("** error in close_device_driver ** unknown device driver\n");
      break;
   }
}

/*                                                                            */
/*--- function plot_text_object ----------------------------------------------*/
/*                                                                            */

void plot_text_object (text_object)
struct wplot_text *text_object;
{
char *ptr;

switch (device_driver)
   {
   case POSTSCRIPT:

/*- set new color if needed -*/

      if ((text_object->fg_r != last.fg_r) ||
          (text_object->fg_g != last.fg_g) ||
          (text_object->fg_b != last.fg_b))
         {
         fprintf (plot_file,"%.5f %.5f %.5f setrgbcolor\n",
         text_object->fg_r/255.0,text_object->fg_g/255.0,text_object->fg_b/255.0);
         last.fg_r = text_object->fg_r;
         last.fg_g = text_object->fg_g;
         last.fg_b = text_object->fg_b;
         }

/*- set new font if needed -*/

      if ((text_object->font != last.font) ||
          (text_object->point_size != last.point_size))
         {
         switch (text_object->font)
            {
            case COURIER:
               fprintf (plot_file,"/Courier findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case COURIER_OBLIQUE:
               fprintf (plot_file,"/Courier-Oblique findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case COURIER_BOLD:
               fprintf (plot_file,"/Courier-Bold findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case COURIER_BOLDOBLIQUE:
               fprintf (plot_file,"/Courier-BoldOblique findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case HELVETICA:
               fprintf (plot_file,"/Helvetica findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case HELVETICA_OBLIQUE:
               fprintf (plot_file,"/Helvetica-Oblique findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case HELVETICA_BOLD:
               fprintf (plot_file,"/Helvetica-Bold findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case HELVETICA_BOLDOBLIQUE:
               fprintf (plot_file,"/Helvetica-BoldOblique findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case TIMES_ROMAN:
               fprintf (plot_file,"/Times-Roman findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case TIMES_ITALIC:
               fprintf (plot_file,"/Times-Italic findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case TIMES_BOLD:
               fprintf (plot_file,"/Times-Bold findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case TIMES_BOLDITALIC:
               fprintf (plot_file,"/Times-BoldItalic findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            case SYMBOL:
               fprintf (plot_file,"/Symbol findfont %.1f scalefont setfont\n",
               text_object->point_size);
               break;
            }
         last.font = text_object->font;
         last.point_size = text_object->point_size;
         }

/*- translate text into postscript text -*/

      ptr = text_object->text;

      if (*ptr != '\0')
         {
         fprintf (plot_file,"(");
         }
      else
         {
         return;
         }

      while (*ptr != '\0')
         {
         if (*ptr == '\\')
            {
            fprintf (plot_file,"\\\\");
            }
         else if (*ptr == '(')
            {
            fprintf (plot_file,"\\(");
            }
         else if (*ptr == ')')
            {
            fprintf (plot_file,"\\)");
            }
         else
            {
            fprintf (plot_file,"%c",*ptr);
            }
         ++ptr;
         }

      fprintf (plot_file,")");

      if (text_object->angle == 0.0)
         {
         fprintf (plot_file," %.1f %.1f",text_object->x,text_object->y);
         switch (text_object->justification)
            {
            case RIGHT_JUSTIFY:
               fprintf (plot_file," tr\n");
               break;
            case CENTER_JUSTIFY:
               fprintf (plot_file," tc\n");
               break;
            default:
               fprintf (plot_file," tl\n");
               break;
            }
         }
      else
         {
         fprintf (plot_file," %.1f %.1f %.1f",text_object->angle,text_object->x,text_object->y);
         switch (text_object->justification)
            {
            case RIGHT_JUSTIFY:
               fprintf (plot_file," trr\n");
               break;
            case CENTER_JUSTIFY:
               fprintf (plot_file," tcr\n");
               break;
            default:
               fprintf (plot_file," tlr\n");
               break;
            }
         }
      fflush (plot_file);
      break;
   case XWINDOWS:
      break;
   default:
      printf ("** error in plot_text ** unknown device driver\n");
      break;
   }

}
