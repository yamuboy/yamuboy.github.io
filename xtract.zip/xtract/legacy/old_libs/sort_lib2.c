#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

union sort_types
   {
   double *dbl;
   int *intv;
   char *strg;
   };

typedef struct _sorting_struct
{
union sort_types *value; 
unsigned long position;
struct _sorting_struct *next;
} SORT_STRUCT;

#define INT      10
#define DOUBLE   12
#define STRING   14

/***********************************************************************************/
/***********************************************************************************/

static int do_sort (SORT_STRUCT *ptr1, SORT_STRUCT *ptr2, int order[], int types[], int p, int n)
   {
   int i,strtst;
   
   if (p >= n)
      return 0;
   
   i = abs (order[p]) - 1;

   switch (types[i])
      {
      case INT:
         if (*(ptr1->value[i].intv) == *(ptr2->value[i].intv))
            // go one level deeper...
            return do_sort (ptr1,ptr2,order,types,p+1,n);
         else if ((order[p] < 0) && (*(ptr1->value[i].intv) < *(ptr2->value[i].intv)))
            return 1;
         else if ((order[p] > 0) && (*(ptr1->value[i].intv) > *(ptr2->value[i].intv)))
            return 1;
         break;

      case DOUBLE:
         if (*(ptr1->value[i].dbl) == *(ptr2->value[i].dbl))
            // go one level deeper...
            return do_sort (ptr1,ptr2,order,types,p+1,n);
         else if ((order[p] < 0) && (*(ptr1->value[i].dbl) < *(ptr2->value[i].dbl)))
            return 1;
         else if ((order[p] > 0) && (*(ptr1->value[i].dbl) > *(ptr2->value[i].dbl)))
            return 1;
         break;

      case STRING:
         strtst = strcasecmp (ptr1->value[i].strg,ptr2->value[i].strg);
         if (!strtst)
            // go one level deeper
            return do_sort (ptr1,ptr2,order,types,p+1,n);
         else if ((order[p] < 0) && (strtst < 0))
            return 1;
         else if ((order[p] > 0) && (strtst > 0))
            return 1;
         break;

      default: // invalid type specification, go one level deeper
         return do_sort (ptr1,ptr2,order,types,p+1,n);
      }
   
   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/

SORT_STRUCT *sort_data (SORT_STRUCT *sort_struct, int order[], int types[], int n)
{
SORT_STRUCT  *begin_sort,*list_ptr;
SORT_STRUCT  *tmp,*last;
int          changed,swap,i,j;

/* error checking */
if (!sort_struct || !sort_struct->next)
   {
   printf ("\nERROR: No sorting data sent to sort_data(), or\n");
   printf ("badly formed linked list\n");
   return NULL;
   }
else if (n < 1)
   {
   printf ("\nERROR: Number of sorting parameters cannot be 0\n");
   return NULL;
   }

for (i = 0; i < n-1; ++i)
   {
   for (j = i+1; j < n; ++j)
      {
      if (order[i] == order[j])
         {
         printf ("\nERROR: Column %d appears more than once in the sorting order.\n",abs (order[i]));
         return NULL;
         }
      else if (!order[i] || !order[j])
         {
         printf ("\nERROR: Column 0 does not exist.\n");
         return NULL;
         }
      }
   }

/* initial starting point */
begin_sort = sort_struct;

do {
   changed = 0;
   list_ptr = begin_sort;
   while (list_ptr->next != NULL)   
      {
      swap = do_sort (list_ptr,list_ptr->next,order,types,0,n);
   
      if (swap)
         {
         tmp = list_ptr->next;
         /* now swap */
         list_ptr->next = tmp->next;
         tmp->next = list_ptr;
         if (list_ptr == begin_sort)
            begin_sort = tmp;
         else
            last->next = tmp;
         last = tmp;
         changed = 1;
         }
      else
         {
         last = list_ptr;
         list_ptr = list_ptr->next;
         }
      }
   }
while (changed);

/* done sorting, now return new begining point */
return begin_sort;
}

/***********************************************************************************/
/***********************************************************************************/

SORT_STRUCT *create_sorting_structure (int nparams, int types[], unsigned long position,
                                       SORT_STRUCT *prev, ...)
   {
   SORT_STRUCT       *s;
   union sort_types  *t;
   va_list           ap;
   int               i;

   if (nparams < 1)
      return NULL;

   s = (SORT_STRUCT *) malloc (sizeof (SORT_STRUCT));
   if (!s)
      return NULL;

   t = (union sort_types *) malloc (sizeof (union sort_types)*nparams);
   if (!t)
      {
      free ((void *) s);
      return NULL;
      }

   s->value = t;
   s->position = position;
   s->next = NULL;

   if (prev)
      prev->next = s;

   va_start (ap,nparams);

   for (i = 0; i < nparams; ++i)
      {
      switch (types[i])
         {
         case INT:
            t[i].intv = va_arg (ap,int *);
            break;
         case DOUBLE:
            t[i].dbl  = va_arg (ap,double *);
            break;
         case STRING:
            t[i].strg = va_arg (ap,char *);
            break;
         default:
            free ((void *) s);
            free ((void *) t);
            va_end (ap);
            return NULL;
         }
      }

   va_end (ap);

   return s;
   }

/***********************************************************************************/
/***********************************************************************************/

void free_sorting_structure (SORT_STRUCT *s)
   {
   free ((void *) s->value);
   free ((void *) s);
   }

/***********************************************************************************/
/***********************************************************************************/

void free_sorting_list (SORT_STRUCT *s)
   {
   SORT_STRUCT *tmp;

   while (s != NULL)
      {
      tmp = s;
      s = s->next;
      free ((void *) tmp->value);
      free ((void *) tmp);
      }
   }


            









