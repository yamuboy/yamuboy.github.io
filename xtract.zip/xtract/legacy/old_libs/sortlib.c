#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct _sorting_struct
{
double *params;
unsigned long position;
struct _sorting_struct *next;
} SORT_S;

typedef struct _sort_order
{
int param;
int descending;
} SORT_ORDER;

/*                                                                                      */
/* ------- Function sort_data --------------------------------------------------------- */
/*                                                                                      */

SORT_S *sort_data (sort_struct,sort_order,n)
SORT_S       *sort_struct;
SORT_ORDER   *sort_order;
int          n;

{
SORT_S    *begin_sort;
SORT_S    *list_ptr;
SORT_S    *list_ptr2;
SORT_S    *last_ptr;
int       changed;
int       swap;
int       i,j;

/* error checking */
if ((sort_struct == NULL) || (sort_struct->next == NULL))
   {
   printf ("\nERROR: No sorting data sent to sort_data(), or\n");
   printf ("badly formed linked list\n");
   exit (-1);
   }
else if (n == 0)
   {
   printf ("\nERROR: Number of sorting parameters cannot be 0\n");
   exit (-1);
   }
for (i = 0; i < n-1; ++i)
   {
   for (j = i+1; j < n; ++j)
      {
      if (sort_order[i].param == sort_order[j].param)
         {
         printf ("\nERROR: Param %d appears more than once in the sorting order\n",sort_order[i].param);
         exit (-1);
         }
      }
   }

/* initial starting point */
begin_sort = sort_struct;

do {
   changed = 0;
   list_ptr = begin_sort;
   while (list_ptr->next != NULL)   
      {
      swap = do_sort (list_ptr,list_ptr->next,sort_order,0,n);
   
      if (swap)
         {
         list_ptr2 = list_ptr->next;
         /* now swap */
         list_ptr->next = list_ptr2->next;
         list_ptr2->next = list_ptr;
         if (list_ptr == begin_sort)
            {
            begin_sort = list_ptr2;
            }
         else
            {
            last_ptr->next = list_ptr2;
            }
         last_ptr = list_ptr2;
         changed = 1;
         }
      else
         {
         last_ptr = list_ptr;
         list_ptr = list_ptr->next;
         }
      }
   }
while (changed);

/* done sorting, now return new begining point */
return (begin_sort);
}


/*                                                                                      */
/* ------- Function do_sort ----------------------------------------------------------- */
/*                                                                                      */

int do_sort (ptr1,ptr2,sort_order,p,n)
SORT_S      *ptr1,*ptr2;
SORT_ORDER  *sort_order;
int         p,n;

{
int i;
int swap;

if (p >= n)
   {
   return (0);
   }

i = sort_order[p].param;

if (ptr1->params[i] == ptr2->params[i])
   {
   swap = do_sort (ptr1,ptr2,sort_order,p+1,n);
   return (swap);
   }
else
   {
   if ((sort_order[p].descending) && (ptr1->params[i] < ptr2->params[i]))
      {
      return (1);
      }
   else if ((!sort_order[p].descending) && (ptr1->params[i] > ptr2->params[i]))
      {
      return (1);
      }
   }

return (0);
}

