#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *lfile, *infile, *outfile;
   char files[256];
   char tmp_file_name[256];
   char extension[40];
   char fname[256];
   char new_name[256];
   char string[256];
   time_t tbuf;
   double start, stop;
   unsigned npts;
   double s11m, s11a, s21m, s21a;
   double s12m, s12a, s22m, s22a;
   double freq, new_freq, freq_inc;

   printf ("Files to change frequency in?\n");
   fgets (files, 255, stdin);
   files[strlen(files)-1] = 0;

   printf ("New file extension?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%39s", extension);

   printf ("Frequency: Start Stop Npts (GHz GHz integer)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf%lf%u", &start, &stop, &npts);

   start *= 1.0e9;
   stop *= 1.0e9;
   if (npts < 2)
      {
      printf ("Error: invalid value for Npts.\n");
      return 1;
      }
   if (stop <= start)
      {
      printf ("Error: stop cannot be <= start.\n");
      return 1;
      }

   freq_inc = (stop - start) / ((double) (npts - 1));
   new_freq = start;

   /**** create and open the file list ****/

   sprintf (tmp_file_name,"tmp.%d",time(&tbuf));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string, "ls -1 %s > %s", files, tmp_file_name);
   system (string);

   lfile = fopen (tmp_file_name,"r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }

   /**** loop through the file list ****/

   while (fgets (fname, 255, lfile))
      {
      fname[strlen(fname)-1] = 0;
      sscanf (fname, "%[^.]", new_name);
      strcat (new_name, extension);

      if (!strcmp (fname, new_name))
         {
         printf ("Warning: old and new file names cannot be the same.\n");
         continue;
         }

      infile = fopen (fname,"r");
      if (!infile)
         {
         printf ("Warning: unable to open file: %s\n", fname);   
         continue;
         }

      outfile = fopen (new_name, "w+");
      if (!outfile)
         {
         printf ("Warning: unable to write to disc.\n");
         continue;
         }

      /**** scan through the input file and write fixed results to the output file ****/

      while (fgets (string, 255, infile))
         {
         if (string[0] == '!')
            {
            fprintf (outfile, "%s", string);
            new_freq = start;
            }
         else if (sscanf (string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &freq, &s11m, &s11a, &s21m, &s21a,
            &s12m, &s12a, &s22m, &s22a) == 9)
            {
            if (new_freq > (stop + 0.5*freq_inc))
               printf ("Warning: frequency overrun: %.5e\n", new_freq);

            fprintf (outfile, "%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n", new_freq,
               s11m, s11a, s21m, s21a, s12m, s12a, s22m, s22a);
            new_freq += freq_inc;
            }
         else
            fprintf (outfile, "%s", string);
         }

      fclose (infile);
      fclose (outfile);
      }

   fclose (lfile);

   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   return 0;
   }

