#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize4.h"
#include "jplot.h"

/****** MACROS AND DEFINITIONS ******/

#define VERSION      2.0

#define sqr(x)    ((x)*(x))

#define MAX_AC_BIAS_PTS    250
#define MAX_DCIV_PTS       1000
#define MAX_DIODE_PTS      100
#define MAX_FWD_IGS        0.5      // in mA/mm
#define MAX_EXP_ARG        30.0
#define CHARGE_FIT_FREQ    5.0e9
#define MAX_CONV_ITER      500

#define NUM_PARAMS    30

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19
#define CTOK          273.15

// plot definitions
#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_DOTTED
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN
#define PLOT_X        1.25
#define PLOT_Y        1.25
#define PLOT_XSIZE    6.0
#define PLOT_YSIZE    5.5

typedef struct
   {
   double vgs,vds,igs,ids;
   } IV_DATA;

typedef struct
   {
   double vgs,vds,igs,ids;
   double cgs,cgd,cds;
   double gm,gds,tau,tau2;
   } AC_PARAMETERS;

typedef struct
   {
   double area,ugw,ngf;
   double rg,rd,rs,ri;
   double lg,ld,ls;
   double cpg,cpd,c11,c22;
   double is,n,ibd,vbd;
   double tnom;
   double deltads;
   } FIXED_PARAMS;

typedef struct
   {
   unsigned ndc, nsub;
   IV_DATA *dcdata, *subdata;
   double max_vds;
   double periphery;
   } DCIV_OPT;

typedef struct
   {
   unsigned n;
   AC_PARAMETERS *data;
   double max_vds;
   double periphery;
   int cap_mod;
   double deltads;
   } AC_OPT;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, unsigned max_size);
static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMS fixed, int cap_mod);

static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params);
static int get_iv_data (char *fname, IV_DATA *d, unsigned max_pts, unsigned *n);
static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                                   FIXED_PARAMS *fixed_params, unsigned *n);

static int dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int charge_erf (double *p, void *data, double *err, unsigned n_err);
static int gm_gds_erf (double *p, void *data, double *err, unsigned n_err);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);
static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

static int fit_diode_curves (char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot, jPLOT_ITEM **vr_plot);
static int fit_dc_curves (char *dc_iv_file, OPT_PARAMETER *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot);
static int fit_capacitance_data (AC_PARAMETERS *ac_data, unsigned n, OPT_PARAMETER *p, unsigned niter, FIXED_PARAMS *fixed_p,
                                 double max_vds, double *weights, int cap_mod, jPLOT_ITEM **y11_plot, jPLOT_ITEM **y12_plot,
                                 jPLOT_ITEM **y21_plot, jPLOT_ITEM **y22_plot);
static int fit_gm_gds (AC_PARAMETERS *ac_data, unsigned n, OPT_PARAMETER *p, unsigned niter, FIXED_PARAMS *fixed_p,
                       jPLOT_ITEM **gm_plot, jPLOT_ITEM **gds_plot);

static double safe_pow (double x, double y);
static void write_starting_files (char *input_file, char *param_file);

static double parker_current (double *p, double Vgs, double Vds, double *Gm, double *Gds);
static void parker_current_raw (double *p, double Vgs, double Vds, double P_a,
                                double *Ids, double *Gm, double *Gds);
static void parker_charge (double *p, double Vgs, double Vgd, double deltads, double *cgs, double *cgd,
                           double *dqgs_vgd, double *dqgd_vgs);
static void statz_charge (double *p, double Vgs, double Vgd, double deltads, double *cgs, double *cgd,
                          double *dqgs_vgd, double *dqgd_vgs);

static void check_parameter_ranges (OPT_PARAMETER *p, double Vmax, double Vpo);
static void read_vmax_from_file (char *fname, double *vmax, double *vpo);

/* ------------- GLOBAL VARIABLES -------------- */

char global_warning_msg[5000];

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   char string[256];
   char model_summary_file[100], start_file[100], end_file[100];
   char model_file[100], yfit_file[100], dc_iv_file[100];
   char fwd_iv_file[100], breakdown_file[100], header[3000];
   OPT_PARAMETER params[NUM_PARAMS];
   AC_PARAMETERS ac_data[MAX_AC_BIAS_PTS];
   FIXED_PARAMS fixed_params;
   unsigned num_ac_bias_pts, niter;
   double maximum_vds;
   double weights[] = {50.0, 500.0, 1.0, 0.05};
   jPLOT_ITEM *p_subth = NULL, *p_dciv = NULL, *p_y11 = NULL;
   jPLOT_ITEM *p_y12 = NULL, *p_y21 = NULL, *p_y22 = NULL, *p_dfwd = NULL, *p_drev = NULL;
   jPLOT_ITEM *p_gm = NULL, *p_gds = NULL;
   int plot_dev = X_WINDOWS;
   int i;
   int no_dc = 0;
   int no_gm = 0;
   int no_cap = 0;
   double vmax, vpo;
   int cap_mod = 2;

   global_warning_msg[0] = 0;

   /**** parse the command line ****/

   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-i", 2) || !strncmp (argv[i], "-e", 2))
         {
         write_starting_files ("parkerin", "parker.start");
         return 0;
         }
      else if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\n\n");

         printf ("Parker-Skellern model fitter options:\n");
         printf ("------------------------------------------------------------------\n");
         printf ("  -i, -e   Auto-generate an input file named parkerin and a\n");
         printf ("              starting values file named parker.start.\n");
         printf ("  -dP, -dp  Set plot device to postscript.\n");
         printf ("  -dM, -dm  Set plot device to metafile.\n");
         printf ("  -d0       Disable plotting.\n");
         printf ("  -skipdc   Skip the DC I-V fitting routine.\n");
         printf ("  -skipgm   Skip the transconductance fitting routine.\n");
         printf ("  -skipcap  Skip the capacitance/charge fitting routine.\n");
         printf ("  -statz    Use the Statz charge model instead of the Parker charge model.\n");

         printf ("\n\n");

         return 0;
         }
      else if (!strncmp (argv[i], "-d", 2))
         {
         char ch = 0;
         sscanf (argv[i], "-d%c", &ch);
         if ((ch == 'm') || (ch == 'M'))
            plot_dev = METAFILE;
         else if ((ch == 'p') || (ch == 'P'))
            plot_dev = POSTSCRIPT;
         else if (ch == '0')
            plot_dev = 0;
         else
            printf ("Warning: invalid -d option.\n");
         }
      else if (!strncmp (argv[i], "-skipdc", 7))
         no_dc = 1;
      else if (!strncmp (argv[i], "-skipgm", 7))
         no_gm = 1;
      else if (!strncmp (argv[i], "-skipcap", 8))
         no_cap = 1;
      else if (!strncmp (argv[i], "-statz", 6))
         cap_mod = 1;
      }

   /**** get user input ****/

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ugw);

   fixed_params.area = fixed_params.ngf * fixed_params.ugw;

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.tnom);

   printf ("Y-fit end file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",yfit_file);

   printf ("Model summary file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_summary_file);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Forward IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",breakdown_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   printf ("Capacitance fitting weights [y11 y12 y21 y22]?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2], &weights[3]);

   /**** get measurement and extraction data ****/

   if (get_starting_values (start_file, params, NUM_PARAMS))
      return 1;

   if (get_ss_parameters (model_summary_file, yfit_file, ac_data, MAX_AC_BIAS_PTS, &fixed_params, &num_ac_bias_pts))
      return 1;

   // read in Vmax, use for VBI model parameter
   read_vmax_from_file (fwd_iv_file, &vmax, &vpo);

   // check for bad starting values or illegal range values 
   //    (i.e. parameters that must be >= 0)
   check_parameter_ranges (params, vmax, vpo);

   // set the min, max, and nom values to be legal
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      if (params[i].max < params[i].min)
         params[i].max = params[i].min;
      if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;
      }

   /* set rd/rs to RMIN */
   fixed_params.rd = fixed_params.rs = 1.0e-6;

   /**** perform various parameter fits ****/

   if (fit_diode_curves (fwd_iv_file, breakdown_file, &fixed_params, &p_dfwd, &p_drev))
      return 1;

   if (!no_dc)
      {
      if (fit_dc_curves (dc_iv_file, params, maximum_vds, niter, &fixed_params, &p_subth, &p_dciv))
         return 1;
      }

   if (!no_gm)
      {
      if (fit_gm_gds (ac_data, num_ac_bias_pts, params, niter, &fixed_params, &p_gm, &p_gds))
         return 1;
      }

   if (!no_cap)
      {
      if (fit_capacitance_data (ac_data, num_ac_bias_pts, params, niter, &fixed_params, maximum_vds, weights, cap_mod, &p_y11, &p_y12, &p_y21, &p_y22))
         return 1;
      }

   /**** Write final data files ****/
   
   printf ("Writing data files.\n");

   get_file_header (fwd_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, params, fixed_params, cap_mod))
      return 1;

   /***** Generate plots *****/

   if (plot_dev)
      {
      jPLOT_ITEM *plot_list[10];
      char plot_head[1000];
      FILE *file;

      plot_head[0] = 0;

      // get the plot header

      file = fopen (fwd_iv_file, "r");
      if (file)
         {
         while (fgets (string, 255, file))
            {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
            }

         fclose (file);
         }

      plot_list[0] = p_subth;
      plot_list[1] = p_dciv;
      plot_list[2] = p_gm;
      plot_list[3] = p_gds;
      plot_list[4] = p_y11;
      plot_list[5] = p_y12;
      plot_list[6] = p_y21;
      plot_list[7] = p_y22;
      plot_list[8] = p_dfwd;
      plot_list[9] = p_drev;

      if (plot_data (plot_dev, plot_head, plot_list, 10))
         return 1;
      }

   if (global_warning_msg[0])
      {
      printf ("\n%s", global_warning_msg);
      printf ("\nModel fitting completed with warnings.\n\n");
      }
   else
      printf ("\n\nModel fitting complete.\n\n");

   return 0;
   }
  
/*****************************************************************************/
/*****************************************************************************/

static int fit_diode_curves (char *fwd_iv_file, char *vbr_iv_file, FIXED_PARAMS *fixed_p,
                             jPLOT_ITEM **vf_plot, jPLOT_ITEM **vr_plot)
   {
   IV_DATA fwd_curves[MAX_DIODE_PTS], vbr_curves[MAX_DIODE_PTS];
   unsigned n_fwd_pts, n_vbr_pts;
   double v[MAX_DIODE_PTS], i[MAX_DIODE_PTS];
   unsigned j, k;
   double m, b, r2;
   double *vf, *if_meas, *if_mod;
   double *vr, *ir_meas, *ir_mod;

   /***** Forward IV *****/
   
   printf ("Forward Diode IV.\n");
   
   if (get_iv_data (fwd_iv_file, fwd_curves, MAX_DIODE_PTS, &n_fwd_pts))
      return 1;

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
      {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 1.0e-8*fixed_p->area))
         {
         v[k] = fwd_curves[j].vgs;
         i[k] = log (fwd_curves[j].igs);
         ++k;
         }
      }

   if (k < 2)
      {
      fprintf (stderr, "Error: %s: not enough points.\n", fwd_iv_file);
      return 1;
      }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->is = 0.5 * exp (b);
   fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * (fixed_p->tnom + CTOK));

   // create a plot

   vf = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_meas = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_mod = (double *) malloc (sizeof(double)*n_fwd_pts);

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
      {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 0.0))
         {
         vf[k] = fwd_curves[j].vgs;
         if_meas[k] = fwd_curves[j].igs * 1.0e6 / fixed_p->area;
         if_mod[k] = 2.0 * fixed_p->is * (exp (vf[k] * Q_ELECTRON / (fixed_p->n * BOLTZMANN * (fixed_p->tnom + CTOK))) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
         }
      }

   create_plot (vf_plot, vf, if_meas, if_mod, k, "Vgs (volts", "Igs (mA/mm)", "Diode Characteristic", LogY1);

   /***** Breakdown *****/

   printf ("Reverse Diode Breakdown.\n");
   
   if (get_iv_data (vbr_iv_file, vbr_curves, MAX_DIODE_PTS, &n_vbr_pts))
      return 1;

   for (j = 0, k = 0; j < n_vbr_pts; ++j)
      {
      if ((vbr_curves[j].igs < 0.0) && (vbr_curves[j].vds - vbr_curves[j].vgs > 0.5*(vbr_curves[n_vbr_pts-1].vds - vbr_curves[n_vbr_pts-1].vgs)))
         {
         v[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
         i[k] = log (-vbr_curves[j].igs);
         ++k;
         }
      }

   if (k < 2)
      {
      fprintf (stderr, "Error: %s: not enough points.\n", vbr_iv_file);
      return 1;
      }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->ibd = exp (b);
   fixed_p->vbd = 1.0 / m;

   // create a plot

   vr = (double *) malloc (sizeof(double)*n_vbr_pts);
   ir_meas = (double *) malloc (sizeof(double)*n_vbr_pts);
   ir_mod = (double *) malloc (sizeof(double)*n_vbr_pts);

   for (j = 0, k = 0; j < n_vbr_pts; ++j)
      {
      if (vbr_curves[j].igs < 0.0)
         {
         vr[k] = vbr_curves[j].vds - vbr_curves[j].vgs;
         ir_meas[k] = -vbr_curves[j].igs * 1.0e6 / fixed_p->area;
         ir_mod[k] = fixed_p->ibd * (exp (vr[k] / fixed_p->vbd) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
         }
      }

   create_plot (vr_plot, vr, ir_meas, ir_mod, k, "Vdg (volts", "Idg (mA/mm)", "Diode Breakdown", LogY1);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_dc_curves (char *dc_iv_file, OPT_PARAMETER *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot)
   {
   unsigned n_iv_pts, n_subth_pts;
   DCIV_OPT dciv_data;
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   IV_DATA subth_data[MAX_DCIV_PTS];
   IV_DATA tmp;
   double *subth_v, *subth_imeas, *subth_imod;
   double *dciv_v, *dciv_imod, *dciv_imeas;
   unsigned i, j;
   OPTIMIZE *opt;
   double pl[NUM_PARAMS];
   double wght[] = {10.0, 1.0};

   printf ("DC IV data.\n");

   if (get_iv_data (dc_iv_file, dciv_curves, MAX_DCIV_PTS, &n_iv_pts))
      return 1;

   // create the subthreshold data set
   for (i = 0, n_subth_pts = 0; i < n_iv_pts; ++i)
      {
      if ((dciv_curves[i].vds < 2.0) || (dciv_curves[i].vds > max_vds) || 
         (dciv_curves[i].ids > 100e-6*fixed_p->area) || (dciv_curves[i].ids <= 0.0))
         continue;

      subth_data[n_subth_pts] = dciv_curves[i];
      ++n_subth_pts;
      }

   if (!n_subth_pts)
      {
      printf ("Error: unable to form subthreshold data set.\n");
      return 1;
      }

   // sort the subthreshold data set
   for (i = 0; i < n_subth_pts; ++i)
      {
      for (j = i+1; j < n_subth_pts; ++j)
         {
         if ((subth_data[j].vds < subth_data[i].vds) ||
            ((subth_data[j].vds == subth_data[i].vds) && (subth_data[j].vgs < subth_data[i].vgs)))
            {
            tmp = subth_data[i];
            subth_data[i] = subth_data[j];
            subth_data[j] = tmp;
            }
         }
      }

   // apply port resistances to active region data
   for (i = 0; i < n_iv_pts; ++i)
      {
      if (dciv_curves[i].igs < 0.0)
         dciv_curves[i].vgs -= dciv_curves[i].ids*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;
      else
         dciv_curves[i].vgs -= (dciv_curves[i].ids + dciv_curves[i].igs)*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;

      dciv_curves[i].vds -= (dciv_curves[i].ids + 0.5*dciv_curves[i].igs) * (fixed_p->rs + fixed_p->rd);
      }

   dciv_data.ndc = n_iv_pts;
   dciv_data.dcdata = dciv_curves;
   dciv_data.nsub = n_subth_pts;
   dciv_data.subdata = subth_data;
   dciv_data.max_vds = max_vds;
   dciv_data.periphery = fixed_p->area;

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, p, NUM_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);
   set_cg_error_function (opt, dciv_erf, &dciv_data, 2, wght);
   set_cg_error_fraction (opt, 1.0e-9, 20);

   for (i = 0; i <= 14; ++i)
      p[i].optimize = TRUE;

   if (cg_optimize4 (opt, niter, NULL))
      {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      return -1;
      }
   
   for (i = 0; i <= 14; ++i)
      p[i].optimize = FALSE;

   /* create plots */

   subth_v = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imeas = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imod = (double *) malloc (sizeof (double) * n_subth_pts);
   dciv_v = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imeas = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imod = (double *) malloc (sizeof (double) * n_iv_pts);

   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   for (i = 0; i < n_subth_pts; ++i)
      {
      subth_v[i] = subth_data[i].vgs;
      subth_imeas[i] = subth_data[i].ids * 1.0e6 / fixed_p->area;
      subth_imod[i] = parker_current (pl, subth_data[i].vgs, subth_data[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
      }

   create_plot (subth_plot, subth_v, subth_imeas, subth_imod, n_subth_pts, "Vgs (volts)", "Ids (mA/mm)", "Sub-Threshold Current", LogY1);

   for (i = 0; i < n_iv_pts; ++i)
      {
      dciv_v[i] = dciv_curves[i].vds;
      dciv_imeas[i] = dciv_curves[i].ids * 1.0e6 / fixed_p->area;
      dciv_imod[i] = parker_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
      }

   create_plot (dciv_plot, dciv_v, dciv_imeas, dciv_imod, n_iv_pts, "Vds (volts)", "Ids (mA/mm)", "DC I-V Curves", POSITIVE_X | POSITIVE_Y1);

   free ((void *) opt);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_capacitance_data (AC_PARAMETERS *ac_data, unsigned n, OPT_PARAMETER *p, unsigned niter, FIXED_PARAMS *fixed_p,
                                 double max_vds, double *weights, int cap_mod, jPLOT_ITEM **cgs_plot, jPLOT_ITEM **cgd_plot,
                                 jPLOT_ITEM **cds_plot, jPLOT_ITEM **tau_plot)
   {
   AC_OPT cap_data;
   OPTIMIZE *opt;
   double *v, *cgs_meas, *cgs_mod, *cgd_meas, *cgd_mod;
   double *cds_meas, *cds_mod, *tau_mod, *tau_meas;
   double pl[NUM_PARAMS];
   unsigned i, j;
   double cgs, cgd, qgs_vgd, qgd_vgs, cds, gm, tau;
   double cds_ave = 0.0;
   double tau_ave = 0.0;

   printf ("Gate Charge.\n");

   // fix DELTADS at 0.2
   fixed_p->deltads = 0.2;

   if (niter > 0)
      {
      // set starting values for Tau and Cds

      for (i = 0, j = 0; i < n; ++i)
         {
         if ((ac_data[i].vds < 2.0) || (ac_data[i].ids < fixed_p->area*10.0e-6))
            continue;

         cds_ave += ac_data[i].cds;
         tau_ave += ac_data[i].tau;
         ++j;
         }

      if (!j)
         j = 1;

      cds_ave /= (double) j;
      tau_ave /= (double) j;

      p[28].nom = cds_ave;
      p[28].min = 0.0;
      p[28].max = 4.0*cds_ave;

      p[29].nom = tau_ave;
      p[29].min = 0.0;
      p[29].max = 4.0*tau_ave;

      //  prepare for optimization

      cap_data.periphery = fixed_p->area;
      cap_data.max_vds = max_vds;
      cap_data.n = n;
      cap_data.data = ac_data;
      cap_data.cap_mod = cap_mod;
      cap_data.deltads = fixed_p->deltads;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, p, NUM_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);

      set_cg_error_function (opt, charge_erf, &cap_data, 4, weights);
      set_cg_error_fraction (opt, 1.0e-12, 5);

      for (i = 21; i <= 29; ++i)
         p[i].optimize = TRUE;

      // optimize

      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return 1;
         }

      for (i = 21; i <= 29; ++i)
         p[i].optimize = FALSE;

      free ((void *) opt);
      }

   /* create plots */

   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   v = (double *) malloc (sizeof (double)*n);
   cgs_mod = (double *) malloc (sizeof (double)*n);
   cgs_meas = (double *) malloc (sizeof (double)*n);
   cgd_mod = (double *) malloc (sizeof (double)*n);
   cgd_meas = (double *) malloc (sizeof (double)*n);
   cds_mod = (double *) malloc (sizeof (double)*n);
   cds_meas = (double *) malloc (sizeof (double)*n);
   tau_mod = (double *) malloc (sizeof (double)*n);
   tau_meas = (double *) malloc (sizeof (double)*n);

   cds = pl[28];
   tau = pl[29];
   for (i = 0; i < n; ++i)
      {
      if (cap_mod == 1)
         statz_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds, fixed_p->deltads, &cgs, &cgd, &qgs_vgd, &qgd_vgs);
      else
         parker_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds, fixed_p->deltads, &cgs, &cgd, &qgs_vgd, &qgd_vgs);
      
      parker_current (pl, ac_data[i].vgs, ac_data[i].vds, &gm, NULL);

      cgs_mod[i] = (cgs + qgd_vgs) * 1.0e15 / fixed_p->area;
      cgs_meas[i] = ac_data[i].cgs * 1.0e15 / fixed_p->area;

      cgd_mod[i] = (cgd + qgs_vgd) * 1.0e15 / fixed_p->area;
      cgd_meas[i] = ac_data[i].cgd * 1.0e15 / fixed_p->area;
      
      cds_mod[i] = (cds - qgs_vgd) * 1.0e15 / fixed_p->area;
      cds_meas[i] = (ac_data[i].cds - ac_data[i].gds*ac_data[i].tau2) * 1.0e15 / fixed_p->area;

      tau_mod[i] = (tau + (qgd_vgs-qgs_vgd)/gm) * 1.0e12;
      tau_meas[i] = ac_data[i].tau * 1.0e12;

      v[i] = ac_data[i].vds;
      }

   create_plot (cgs_plot, v, cgs_meas, cgs_mod, n, "Vds (volts)", "pF/mm", "Cgs", 0);
   create_plot (cgd_plot, v, cgd_meas, cgd_mod, n, "Vds (volts)", "pF/mm", "Cgd", 0);
   create_plot (cds_plot, v, cds_meas, cds_mod, n, "Vds (volts)", "pF/mm", "Cds", 0);
   create_plot (tau_plot, v, tau_meas, tau_mod, n, "Vds (volts)", "pS", "Tau", 0);
   set_y1_scale (*tau_plot, 0.0, 10.0, 2.0, 4, 0, "");

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_gm_gds (AC_PARAMETERS *ac_data, unsigned n, OPT_PARAMETER *p, unsigned niter, FIXED_PARAMS *fixed_p,
                       jPLOT_ITEM **gm_plot, jPLOT_ITEM **gds_plot)
   {
   AC_OPT gm_data;
   OPTIMIZE *opt;
   double pl[NUM_PARAMS];
   unsigned i;
   double gm, gds;
   double *v, *gm_meas, *gm_mod, *gds_meas, *gds_mod;
   double wght[] = {0.1, 10.0};
  
   printf ("RF conductances.\n");

   //  prepare for optimization

   gm_data.periphery = fixed_p->area;
   gm_data.n = n;
   gm_data.data = ac_data;

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, p, NUM_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

   set_cg_error_function (opt, gm_gds_erf, &gm_data, 2, wght);
   set_cg_error_fraction (opt, 1.0e-12, 5);

   // optimize

   for (i = 15; i <= 20; ++i)
      p[i].optimize = TRUE;

   if (cg_optimize4 (opt, niter, NULL))
      {
      fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
      return 1;
      }
   
   for (i = 15; i <= 20; ++i)
      p[i].optimize = FALSE;

   // create plots

   for (i = 0; i < NUM_PARAMS; ++i)
      pl[i] = p[i].nom;

   v = (double *) malloc (sizeof (double)*n);
   gm_mod = (double *) malloc (sizeof (double)*n);
   gm_meas = (double *) malloc (sizeof (double)*n);
   gds_mod = (double *) malloc (sizeof (double)*n);
   gds_meas = (double *) malloc (sizeof (double)*n);

   for (i = 0; i < n; ++i)
      {
      parker_current (pl, ac_data[i].vgs, ac_data[i].vds, &gm, &gds);
      gm_mod[i] = gm * 1.0e6 / fixed_p->area;
      gm_meas[i] = ac_data[i].gm * 1.0e6 / fixed_p->area;
      gds_mod[i] = gds * 1.0e6 / fixed_p->area;
      gds_meas[i] = ac_data[i].gds * 1.0e6 / fixed_p->area;
      v[i] = ac_data[i].vds;

      if (0)
         {
         double lo, hi, del = 1.0e-6;
         double gmc, gdsc;
         lo = parker_current (pl, ac_data[i].vgs - del, ac_data[i].vds, NULL, NULL);
         hi = parker_current (pl, ac_data[i].vgs + del, ac_data[i].vds, NULL, NULL);
         gmc = (hi - lo) / (2.0*del);
         lo = parker_current (pl, ac_data[i].vgs, ac_data[i].vds - del, NULL, NULL);
         hi = parker_current (pl, ac_data[i].vgs, ac_data[i].vds + del, NULL, NULL);
         gdsc = (hi - lo) / (2.0*del);

         printf ("%.3f\t%.2f\t%.3f\t%.3f\t%.3f\t%.3f\n", ac_data[i].vgs, ac_data[i].vds, gm, gmc, gds, gdsc);
         }
      }

   create_plot (gm_plot, v, gm_meas, gm_mod, n, "Vds (volts)", "Gm (mS/mm)", "Transconductance", 0);
   create_plot (gds_plot, v, gds_meas, gds_mod, n, "Vds (volts)", "Gds (mS/mm)", "Drain Conductance", 0);

   free ((void *) opt);
   }

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

/* this function converges the dissipated power */
static double parker_current (double *p, double Vgs, double Vds, double *Gm, double *Gds)
   {
   unsigned n;
   double Pin, Pout, P0, dPout_Pin;
   double DELTA = p[4];
   double Ids, Pnew;

   // calculate P0 with Pin equal to zero
   Pin = 0.0;
   parker_current_raw (p, Vgs, Vds, Pin, &Ids, Gm, Gds);
   P0 = Pout = Vds * Ids;

   for (n = 0; n < MAX_CONV_ITER; ++n)
      {
      // if model converges to less than 1 mW, we are done
      if (fabs (Pout - Pin) < 1.0e-3)
         return Ids;

      // calculate the derivative
      dPout_Pin = P0 * DELTA / sqr (1.0 + DELTA * Pin);

      // calculate a new guess for Pin
      Pnew = (Pin * dPout_Pin - Pout) / (dPout_Pin - 1.0);
      if (!((Pnew < MAXFLOAT) && (Pnew > -MAXFLOAT)) || (Pnew < 0.0))
         Pnew = 0.0;

      Pin = (Pin+Pnew)*0.5;

      // recalculate the returned power
      parker_current_raw (p, Vgs, Vds, Pin, &Ids, Gm, Gds);
      Pout = Vds * Ids;
      }

   // fprintf (stderr, "Warning: convergence failed: Vgs = %.3f, Vds = %.2f, Pin = %.3f, Pout = %.3f\n", Vgs, Vds, Pin, Pout);
   return Ids;
   }

/*****************************************************************************/
/*****************************************************************************/

static void parker_current_raw (double *p, double Vgs, double Vds, double P_a,
                                double *Ids, double *Gm, double *Gds)
   {
   double AREA = 1.0;
   double LFGAM = p[12];
   double LFG1 = p[13];
   double LFG2 = p[14];
   double HFGAM = p[15];
   double HFG1 = p[16];
   double HFG2 = p[17];
   double HFETA = p[18];
   double HFE1 = p[19];
   double HFE2 = p[20];
   double VBI = p[0];
   double VTO = p[2];
   double VST = p[6];
   double MVST = p[7];
   double XI = p[8];
   double MXI = p[9];
   double P = p[3];
   double Q = p[3] - p[5];
   double Z = p[11];
   double BETA = p[1];
   double LAMBDA = p[10];
   double DELTA = p[4];
   double VBI_MINUS_VTO = VBI - VTO;
   double lfg, hfg, hfn, vgst, vst, vgt, vsat, vdp, vdt;
   double dvgst_vgs, dvgst_vds; // dvgst_vgsa, dvgst_vgda;
   double dvgt_vgs, dvgt_vds; // dvgt_vgsa, dvgt_vgda;
   double dvsat_vgs, dvsat_vds; // dvsat_vgsa, dvsat_vgda;
   double dvdp_vgs, dvdp_vds; // dvdp_vgsa, dvdp_vgda;
   double dvdt_vgs, dvdt_vds; // dvdt_vgsa, dvdt_vgda;
   double c0, c1, c2, c3, c4, c5, dvst_vds;

   double Vgs_a = Vgs;
   double Vgd_a = Vgs - Vds;

   /**** calculate drain current and derivatives ****/

   lfg = LFGAM - LFG1*Vgs_a + LFG2*Vgd_a;
   hfg = HFGAM - HFG1*Vgs_a + HFG2*Vgd_a;
   hfn = HFETA - HFE1*Vgd_a + HFE2*Vgs_a;
   
   vgst = Vgs - VTO - lfg*Vgd_a - hfg*(Vgs - Vds - Vgd_a) - hfn*(Vgs - Vgs_a);
   dvgst_vgs = 1.0 - hfg - hfn;
   dvgst_vds = hfg;
   // dvgst_vgsa = LFG1*Vgd_a + HFG1*(Vgs - Vds - Vgd_a) - (HFE2*(Vgs - Vgs_a) - hfn);
   // dvgst_vgda = -(LFG2*Vgd_a + lfg) - (HFG2*(Vgs - Vds - Vgd_a) - hfg) + HFE1*(Vgs - Vgs_a);

   vst = VST*(1.0 + MVST*Vds);
   dvst_vds = VST * MVST;

   if (vgst > 30.0*vst)
      {
      vgt = vgst;
      dvgt_vgs = dvgst_vgs;
      dvgt_vds = dvgst_vds;
      // dvgt_vgsa = dvgst_vgsa;
      // dvgt_vgda = dvgst_vgda;
      }
   else if (vgst < -30.0*vst)
      {
      vgt = 0.0;
      dvgt_vgs = dvgt_vds = 0.0; // dvgt_vgsa = dvgt_vgda = 0.0;
      }
   else
      {
      c1 = exp(vgst/vst) + 1.0;
      c2 = c1 - 1.0;
      vgt = vst * log(c1);
      dvgt_vgs = vst / c1 * c2 * dvgst_vgs / vst;
      dvgt_vds = vst / c1 * c2 * (dvgst_vds * vst - vgst * dvst_vds) / sqr(vst) + log(c1) * dvst_vds;
      // dvgt_vgsa = vst / c1 * c2 * dvgst_vgsa / vst;
      // dvgt_vgda = vst / c1 * c2 * dvgst_vgda / vst;
      }

   c1 = vgt * (1.0 + MXI) + XI*VBI_MINUS_VTO;
   c2 = sqr(vgt)*MXI + vgt*XI*VBI_MINUS_VTO;
   c3 = (c1 * (2.0*vgt*MXI + XI*VBI_MINUS_VTO) - c2 * (1.0 + MXI)) / sqr (c1);
   vsat = c2 / c1;
   dvsat_vgs = dvgt_vgs * c3;
   dvsat_vds = dvgt_vds * c3;
   // dvsat_vgsa = dvgt_vgsa * c3;
   // dvsat_vgda = dvgt_vgda * c3;
   
   c1 = P/Q * safe_pow (vgt/VBI_MINUS_VTO, P-Q);
   c2 = P/Q * safe_pow (vgt/VBI_MINUS_VTO, P-Q-1.0);
   vdp = Vds * c1;
   dvdp_vgs = Vds * (P-Q) * c2 * dvgt_vgs / VBI_MINUS_VTO;
   dvdp_vds = Vds * (P-Q) * c2 * dvgt_vds / VBI_MINUS_VTO + c1;
   // dvdp_vgsa = Vds * (P-Q) * c2 * dvgt_vgsa / VBI_MINUS_VTO;
   // dvdp_vgda = Vds * (P-Q) * c2 * dvgt_vgda / VBI_MINUS_VTO;

   c1 = sqrt(1.0 + Z);
   c2 = Z * sqr(vsat);
   c3 = sqrt (sqr(vdp * c1 + vsat) + c2);
   c4 = sqrt (sqr(vdp * c1 - vsat) + c2);
   vdt = 0.5 * (c3 - c4);
   dvdt_vgs = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vgs * c1 + dvsat_vgs) + 2.0 * Z * vsat * dvsat_vgs) - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vgs * c1 - dvsat_vgs) + 2.0 * Z * vsat * dvsat_vgs));
   dvdt_vds = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vds * c1 + dvsat_vds) + 2.0 * Z * vsat * dvsat_vds) - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vds * c1 - dvsat_vds) + 2.0 * Z * vsat * dvsat_vds));
   // dvdt_vgsa = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vgsa * c1 + dvsat_vgsa) + 2.0 * Z * vsat * dvsat_vgsa) - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vgsa * c1 - dvsat_vgsa) + 2.0 * Z * vsat * dvsat_vgsa));
   // dvdt_vgda = 0.5 * (0.5 / c3 * (2.0 * (vdp * c1 + vsat) * (dvdp_vgda * c1 + dvsat_vgda) + 2.0 * Z * vsat * dvsat_vgda) - 0.5 / c4 * (2.0 * (vdp * c1 - vsat) * (dvdp_vgda * c1 - dvsat_vgda) + 2.0 * Z * vsat * dvsat_vgda));
   
   c0 = AREA * BETA;
   c1 = 1.0 + LAMBDA*Vds;
   c2 = Q * safe_pow(vgt, Q-1.0);
   if (vgt >= vdt)
      {
      c3 = Q * safe_pow(vgt-vdt, Q-1.0);
      c4 = safe_pow(vgt, Q) - safe_pow(vgt-vdt, Q);
      }
   else
      {
      c3 = 0.0;
      c4 = safe_pow(vgt, Q);
      }
   c5 = 1.0 / (1.0 + DELTA * P_a / AREA);
   *Ids = c0 * c1 * c4 * c5;
   if (Gm)
      *Gm = c0 * c1 * c5 * (c2*dvgt_vgs - c3*(dvgt_vgs-dvdt_vgs));
   if (Gds)
      *Gds = c0 * c5 * (c1 * (c2*dvgt_vds - c3*(dvgt_vds-dvdt_vds)) + c4 * LAMBDA);
   // *dIds_vgsa = c0 * c1 * c5 * (c2*dvgt_vgsa - c3*(dvgt_vgsa-dvdt_vgsa));
   // *dIds_vgda = c0 * c1 * c5 * (c2*dvgt_vgda - c3*(dvgt_vgda-dvdt_vgda));      
   // *dIds_pave = -c0 * c1 * c4 * sqr(c5) * DELTA / AREA;
   /*
   if (isnan(*Ids) || (Gm && isnan(*Gm)) || (Gds && isnan(*Gds)) || (*Ids > 1.0e6))
      {
      printf ("Vgs = %.3f, Vds = %.2f, Pave = %.3e, Vgst = %.3e, Vgt = %.3e, Vsat = %.3e, Vdp = %.3e, Vdt = %.3e, Ids = %.3e\n",
         Vgs, Vds, P_a, vgst, vgt, vsat, vdp, vdt, *Ids);
      printf ("Gm = %.3e, Gds = %.3e, c0 = %.3e, c1 = %.3e, c4 = %.3e, c5 = %.3e\n",
         Gm ? *Gm : 0.0, Gds ? *Gds : 0.0, c0, c1, c4, c5); 
      }
      */
   }

/*****************************************************************************/
/*****************************************************************************/

static void statz_charge (double *p, double Vgs, double Vgd, double deltads, double *cgs, double *cgd,
                          double *dqgs_vgd, double *dqgd_vgs)
   {
   double AREA = 1.0;
   double VBI = p[0];
   double VTO = p[2];
   double CGS = p[21];
   double CGD = p[22];
   double FC = p[23];
   double DELTA1 = p[24];
   double DELTA2 = p[25];
   double DELTADS = deltads;
   double veff1, veff2, vnew;
   double dveff1_vgs, dveff1_vgd;
   double dveff2_vgs, dveff2_vgd;
   double dvnew_vgs, dvnew_vgd;
   double Qgs, dQgs_vgs, dQgs_vgd;
   double Qgd, dQgd_vgs, dQgd_vgd;
   double f1, df1_vgs, df1_vgd;
   double f2, df2_vgs, df2_vgd;

   veff1 = 0.5 * (Vgs + Vgd + sqrt (sqr(Vgs - Vgd) + sqr(DELTA1)));
   dveff1_vgs = 0.5 * (1.0 + 0.5 / sqrt (sqr(Vgs - Vgd) + sqr(DELTA1)) * 2.0 * (Vgs - Vgd));
   dveff1_vgd = 0.5 * (1.0 - 0.5 / sqrt (sqr(Vgs - Vgd) + sqr(DELTA1)) * 2.0 * (Vgs - Vgd));

   veff2 = 0.5 * (Vgs + Vgd - sqrt (sqr(Vgs - Vgd) + sqr(DELTA1)));
   dveff2_vgs = dveff1_vgd;
   dveff2_vgd = dveff1_vgs;

   vnew = 0.5 * (veff1 + VTO + sqrt (sqr(veff1 - VTO) + sqr(DELTA2)));
   dvnew_vgs = 0.5 * (dveff1_vgs + 0.5 / sqrt (sqr(veff1 - VTO) + sqr(DELTA2)) * 2.0 * (veff1 - VTO) * dveff1_vgs);
   dvnew_vgd = 0.5 * (dveff1_vgd + 0.5 / sqrt (sqr(veff1 - VTO) + sqr(DELTA2)) * 2.0 * (veff1 - VTO) * dveff1_vgd);

   if (vnew <= FC*VBI)
      {
      Qgs = AREA * CGS * 2.0 * VBI * (1.0 - sqrt (1.0 - vnew / VBI));
      dQgs_vgs = AREA * CGS * 2.0 * VBI * 0.5 / sqrt (1.0 - vnew / VBI) * dvnew_vgs / VBI;
      dQgs_vgd = AREA * CGS * 2.0 * VBI * 0.5 / sqrt (1.0 - vnew / VBI) * dvnew_vgd / VBI;
      }
   else
      {
      Qgs = AREA * CGS * (2.0 * VBI * (1.0 - sqrt (1.0 - FC)) + (vnew - FC*VBI) / sqrt (1.0 - FC));
      dQgs_vgs = AREA * CGS * dvnew_vgs / sqrt (1.0 - FC);
      dQgs_vgd = AREA * CGS * dvnew_vgd / sqrt (1.0 - FC);
      }

   Qgd = AREA * CGD * veff2;
   dQgd_vgd = AREA * CGD * dveff2_vgd;
   dQgd_vgs = AREA * CGD * dveff2_vgs;

   /* use smoothing functions to handle the case where Vds is less than 0,
        this causes Qgs and Qgd to swap roles */

   f1 = 0.5 * (1.0 + tanh(3.0 / DELTADS * (Vgs - Vgd)));
   df1_vgs = 1.5 / (DELTADS * sqr(cosh(3.0 / DELTADS * (Vgs - Vgd))));
   df1_vgd = -df1_vgs;

   f2 = 0.5 * (1.0 + tanh(3.0 / DELTADS * (Vgd - Vgs)));
   df2_vgs = df1_vgd;
   df2_vgd = df1_vgs;

   // *qgs = Qgs*f1 + Qgd*f2;
   *cgs = Qgs*df1_vgs + f1*dQgs_vgs + Qgd*df2_vgs + f2*dQgd_vgs;
   *dqgs_vgd = Qgs*df1_vgd + f1*dQgs_vgd + Qgd*df2_vgd + f2*dQgd_vgd;
   
   // *qgd = Qgs*f2 + Qgd*f1;
   *cgd = Qgs*df2_vgd + f2*dQgs_vgd + Qgd*df1_vgd + f1*dQgd_vgd;
   *dqgd_vgs = Qgs*df2_vgs + f2*dQgs_vgs + Qgd*df1_vgs + f1*dQgd_vgs;
   }

/*****************************************************************************/
/*****************************************************************************/

static void parker_charge (double *p, double Vgs, double Vgd, double deltads, double *cgs, double *cgd,
                           double *dqgs_vgd, double *dqgd_vgs)
   {
   double AREA = 1.0;
   double VBI = p[0];
   double VTO = p[2];
   double XI = p[8];
   double CGS = p[21];
   double CGD = p[22];
   double FC = p[23];
   double XC = p[26];
   double ACGAM = p[27];
   double DELTADS = deltads;
   double c1, c2, alpha;
   double Veff1, dVeff1_vgs, dVeff1_vgd;
   double Veff2, dVeff2_vgs, dVeff2_vgd;
   double Vnew, dVnew_vgs, dVnew_vgd;
   double Qgs, dQgs_vgs, dQgs_vgd;
   double Qgd, dQgd_vgs, dQgd_vgd;
   double f1, df1_vgs, df1_vgd;
   double f2, df2_vgs, df2_vgd;

   alpha = XI / (XI + 1.0) * 0.5*(VBI - VTO);

   c1 = sqrt(sqr(Vgs-Vgd) + sqr(alpha));
   Veff1 = 0.5 * (Vgs + Vgd + c1) + ACGAM*(Vgs-Vgd);
   dVeff1_vgs = 0.5 * (1.0 + (Vgs-Vgd)/c1) + ACGAM;
   dVeff1_vgd = 0.5 * (1.0 - (Vgs-Vgd)/c1) - ACGAM;
   
   Veff2 = 0.5 * (Vgs + Vgd - c1) + ACGAM*(Vgs-Vgd);
   dVeff2_vgs = dVeff1_vgd + 2.0*ACGAM;
   dVeff2_vgd = dVeff1_vgs - 2.0*ACGAM;
   
   c1 = 0.5*(1.0 - XC);
   c2 = sqrt(sqr(Veff1-VTO) + sqr(0.2/(1.0 - XC)));
   Vnew = Veff1*XC + c1*(Veff1 + VTO + c2);
   dVnew_vgs = dVeff1_vgs*XC + c1*(dVeff1_vgs * (1.0 + (Veff1-VTO)/c2));
   dVnew_vgd = dVeff1_vgd*XC + c1*(dVeff1_vgd * (1.0 + (Veff1-VTO)/c2));

   if (Vnew > FC*VBI)
      {
      c1 = 1.0 / 4.0*pow(1.0-FC, 1.5);
      c2 = 1.0 / sqrt(1.0-FC);
      Qgs = AREA * CGS * VBI * ( 2.0*(1.0 - sqrt(1.0 - FC)) + sqr(Vnew/VBI - FC)*c1 + (Vnew/VBI - FC)*c2 );
      dQgs_vgs = AREA * CGS * VBI * ( 2.0*(Vnew/VBI - FC)*dVnew_vgs*c1/VBI + dVnew_vgs*c2/VBI );
      dQgs_vgd = AREA * CGS * VBI * ( 2.0*(Vnew/VBI - FC)*dVnew_vgd*c1/VBI + dVnew_vgd*c2/VBI );
      }
   else
      {
      c1 = sqrt(1.0 - Vnew/VBI);
      Qgs = 2.0 * AREA * CGS * VBI * (1.0 - c1);
      dQgs_vgs = AREA * CGS * dVnew_vgs / c1;
      dQgs_vgd = AREA * CGS * dVnew_vgd / c1;
      }

   Qgd = AREA * CGD * Veff2;
   dQgd_vgs = AREA * CGD * dVeff2_vgs;
   dQgd_vgd = AREA * CGD * dVeff2_vgd;

   /* use smoothing functions to handle the transition between forward and reverse,
        this causes Qgs and Qgd to swap roles */

   f1 = 0.5 * (1.0 + tanh(3.0 / DELTADS * (Vgs - Vgd)));
   df1_vgs = 1.5 / (DELTADS * sqr(cosh(3.0 / DELTADS * (Vgs - Vgd))));
   df1_vgd = -df1_vgs;

   f2 = 0.5 * (1.0 + tanh(3.0 / DELTADS * (Vgd - Vgs)));
   df2_vgs = df1_vgd;
   df2_vgd = df1_vgs;

   // *qgs = Qgs*f1 + Qgd*f2;
   *cgs = Qgs*df1_vgs + f1*dQgs_vgs + Qgd*df2_vgs + f2*dQgd_vgs;
   *dqgs_vgd = Qgs*df1_vgd + f1*dQgs_vgd + Qgd*df2_vgd + f2*dQgd_vgd;
   
   // *qgd = Qgs*f2 + Qgd*f1;
   *cgd = Qgs*df2_vgd + f2*dQgs_vgd + Qgd*df1_vgd + f1*dQgd_vgd;
   *dqgd_vgs = Qgs*df2_vgs + f2*dQgs_vgs + Qgd*df1_vgs + f1*dQgd_vgs;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int dciv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->nsub; ++i)
      {
      diff = log (d->subdata[i].ids) - log (parker_current (p, d->subdata[i].vgs, d->subdata[i].vds, NULL, NULL) + 1.0e-15);
      err[0] += diff * diff;
      }

   for (i = 0; i < d->ndc; ++i)
      {
      if (d->dcdata[i].vds > d->max_vds)
         continue;

      diff = d->dcdata[i].ids - parker_current (p, d->dcdata[i].vgs, d->dcdata[i].vds, NULL, NULL);
      err[1] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->nsub;
   err[1] /= (double) d->ndc;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int charge_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   AC_OPT *d = (AC_OPT *) data;
   double cgs, cgd, qgs_vgd, qgd_vgs, gm;
   double cds = p[28];
   double tau = p[29];
   double factor;

   if (n_err != 4)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      if (d->cap_mod == 1)
         statz_charge (p, d->data[i].vgs, d->data[i].vgs - d->data[i].vds, d->deltads, &cgs, &cgd, &qgs_vgd, &qgd_vgs);
      else
         parker_charge (p, d->data[i].vgs, d->data[i].vgs - d->data[i].vds, d->deltads, &cgs, &cgd, &qgs_vgd, &qgd_vgs);

      parker_current (p, d->data[i].vgs, d->data[i].vds, &gm, NULL);

      if (d->data[i].vds >= 1.5)
         {
         err[0] += sqr(1.0e12*(d->data[i].cgs - (cgs + qgd_vgs)));
         err[1] += sqr(1.0e12*(d->data[i].cgd - (cgd + qgs_vgd)));
         err[2] += sqr(1.0e12*((d->data[i].cds - d->data[i].gds*d->data[i].tau2) - (cds - qgs_vgd)));
         if (d->data[i].gm >= (10.0e-6*d->periphery))
            err[3] += sqr(1.0e12*(d->data[i].tau - (tau + (qgd_vgs - qgs_vgd)/gm)) * gm);
         }
      }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;
   err[2] /= (double) d->n;
   err[3] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int gm_gds_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   AC_OPT *d = (AC_OPT *) data;
   double gm, gds;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      parker_current (p, d->data[i].vgs, d->data[i].vds, &gm, &gds);
      err[0] += 1.0e6 * sqr(d->data[i].gm - gm);
      err[1] += 1.0e6 * sqr((d->data[i].gds - gds) * 0.5 * (1.0 + tanh (3.0*(d->data[i].vds - 2.5))));
      }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static double bubble_average (double *values, unsigned n)
   {
   unsigned i,j;
   double temp;
   double delta;

   if (!n)
      return 0.0;
   else if (n == 1)
      return values[0];
   
   // sort the values vector in ascending order
   for (i = 0; i < n-1; ++i)
      {
      for (j = i+1; j < n; ++j)
         {
         if (values[j] < values[i])
            {
            temp = values[i];
            values[i] = values[j];
            values[j] = temp;
            }
         }
      }
   
   // take the average of all the values within 25% of the median value of the vector
   delta = fabs (values[n/2]) * 0.25;
   for (j = 0, i = 0, temp = 0.0; j < n; ++j)
      {
      if (fabs (values[j]-values[n/2]) <= delta)
         {
         ++i;
         temp += values[j];
         }
      }

   if (!i)
      i = 1;
   
   return temp / ((double) i);
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n)
   {
   FILE *file;
   unsigned m = 0;
   unsigned found = 0;
   unsigned i,j;
   char string[300],pname[20];
   double *Ri;
   double value;
   AC_PARAMETERS tmp;

   *n = 0;

   /* read in bias-dependent device parameters */

   file = fopen (sum_file,"r");
   if (!file)
      {
      printf ("Error: %s: unable to file.\n", sum_file);
      return 1;
      }
   
   Ri = (double *) malloc (sizeof (double) * max_ac_p);

   while (fgets (string, 299, file))
      {
      if ((m >= max_ac_p) || (*n >= max_ac_p))
         {
         printf ("Warning: %s: too many bias points.\n", sum_file);
         break;
         }
         
      if (sscanf (&string[28],"%lf%lf%lf%lf%*f%*f%*f%*f%*f%lf%lf%lf%lf%lf%lf%lf%lf",
         &ac_params[*n].vds, &ac_params[*n].ids, &ac_params[*n].vgs, &ac_params[*n].igs,
         &Ri[m], &ac_params[*n].gm, &ac_params[*n].tau, &ac_params[*n].gds, &ac_params[*n].tau2,
         &ac_params[*n].cgs, &ac_params[*n].cds, &ac_params[*n].cgd) == 12)
         {
         ac_params[*n].ids *= 1.0e-3;
         ac_params[*n].igs *= 1.0e-3;
         ac_params[*n].gm  *= 1.0e-3;
         ac_params[*n].gds *= 1.0e-3;
         ac_params[*n].cgs *= 1.0e-12;
         ac_params[*n].cgd *= 1.0e-12;
         ac_params[*n].cds *= 1.0e-12;
         ac_params[*n].tau *= 1.0e-12;
         ac_params[*n].tau2 *= 1.0e-12;
         
         if ((ac_params[*n].igs <= MAX_FWD_IGS*fixed_params->area*1.0e-6) && (ac_params[*n].vds >= 1.0))
            {
            ++(*n);

            // only fit Ri at points where there is DC drain current
            if (ac_params[*n].ids >= 10.0e-6*fixed_params->area)
               ++m;
            }

         }
      }
   fclose (file);

   // average these parameters, since they are fixed in the LS model

   fixed_params->ri = bubble_average (Ri,m);   
   if (fixed_params->ri < 0.0)
      fixed_params->ri = 0.0;

   free ((void *) Ri);

   if (*n < 1)
      {
      fprintf (stderr, "Error: %s: no data.\n", sum_file);
      return 1;
      }

   /* sort the ac parameters by increasing Vgs then Vds */
   
   for (i = 0; i < ((*n)-1); ++i)
      {
      for (j = i+1; j < *n; ++j)
         {
         if ((ac_params[j].vgs < ac_params[i].vgs) ||
            ((ac_params[j].vds < ac_params[i].vds) && (ac_params[i].vgs == ac_params[j].vgs)))
            {
            tmp = ac_params[i];
            ac_params[i] = ac_params[j];
            ac_params[j] = tmp;
            }
         }
      }
   
   /* determine the intrinsic node voltages */
      
   for (i = 0; i < *n; ++i)
      {
      ac_params[i].vds -= fixed_params->rd*ac_params[i].ids +
         fixed_params->rs*(ac_params[i].ids + ac_params[i].igs);
      ac_params[i].vgs -= (fixed_params->rg + fixed_params->ri)*ac_params[i].igs + 
         fixed_params->rs*(ac_params[i].ids + ac_params[i].igs);
      }

   /* read in fixed parasitics from the small-signal end file */

   file = fopen (end_file,"r");
   if (!file)
      {
      printf ("Error: %s: unable to open file.\n", end_file);
      return 1;
      }
   
   while (fgets (string,299,file))
      {
      if (sscanf (string,"%*f%lf%*f%*f%19s",&value,pname) == 2)
         {
         if (!strcmp (pname,"C1"))
            {
            fixed_params->cpg = value;
            ++found;
            }
         else if (!strcmp (pname,"C2"))
            {
            fixed_params->cpd = value;
            ++found;
            }
         else if (!strcmp (pname,"C11"))
            {
            fixed_params->c11 = value;
            ++found;
            }
         else if (!strcmp (pname,"C22"))
            {
            fixed_params->c22 = value;
            ++found;
            }
         else if (!strcmp (pname,"B1"))
            {
            fixed_params->lg = value;
            ++found;
            }
         else if (!strcmp (pname,"B2"))
            {
            fixed_params->ld = value;
            ++found;
            }
         else if (!strcmp (pname,"LS"))
            {
            fixed_params->ls = value;
            ++found;
            }
         else if (!strcmp (pname,"RG"))
            {
            fixed_params->rg = value;
            ++found;
            }
         else if (!strcmp (pname,"RD"))
            {
            fixed_params->rd = value;
            ++found;
            }
         else if (!strcmp (pname,"RS"))
            {
            fixed_params->rs = value;
            ++found;
            }
         }
      }
   fclose (file);

   if (found != 10)
      {
      fprintf (stderr, "Error: %s: missing parameter(s).\n", end_file);
      return 1;
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_starting_values (char *fname, OPT_PARAMETER *p, unsigned n_params)
   {
   FILE *file;
   char string[200];
   unsigned i = 0;

   /* read in the starting values */

   file = fopen (fname,"r");
   if (!file)
      {
      printf ("Error: %s: unable to open file.\n", fname);
      return 1;
      }
   
   while (fgets (string, 199, file))
      {
      if (i >= n_params)
         break;

      if (sscanf (string,"%lf%lf%lf%lf%19s", &p[i].min, &p[i].nom,
         &p[i].max, &p[i].tol, p[i].name))
         {
         p[i].optimize = FALSE;
         ++i;
         }
      }
   fclose (file);

   if (i != n_params)
      {
      fprintf (stderr, "Error: %s: missing parameter(s).\n", fname);
      return 1;
      }

   /* set the min, max, and nom values to be legal */
   for (i = 0; i < n_params; ++i)
      {
      if (p[i].nom < p[i].min)
         p[i].nom = p[i].min;
      if (p[i].max < p[i].min)
         p[i].max = p[i].min;
      if (p[i].nom > p[i].max)
         p[i].nom = p[i].max;
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_iv_data (char *fname, IV_DATA *d, unsigned max_pts, unsigned *n)
   {
   FILE *file;
   char string[256];
   double vgs,vds,igs,ids;
   int first = 1;
   int piv_file = 0;
   
   *n = 0;

   file = fopen (fname, "r");
   if (!file)
      {
      fprintf (stderr, "Error: %s: unable to open file.\n", fname);
      return 1;
      }

   while (fgets (string, 255, file))
      {
      if (first)
         {
         if (string[0] == '\\')
            piv_file = 1;

         first = 0;
         continue;
         }

      if ((string[0] != '!') && (string[0] != '\\') && (sscanf (string, "%lf%lf%lf%lf", &vds, &ids, &vgs, &igs) == 4))
         {
         if (*n >= max_pts)
            {
            fprintf (stderr, "Warning: %s: too many data points in file.\n", fname);
            break;
            }
         
         if (piv_file)
            {
            // data fields are in a different order in PIV files
            d[*n].vgs = vds;
            d[*n].vds = ids;
            d[*n].ids = vgs;
            d[*n].igs = igs;
            }
         else
            {
            d[*n].vds = vds;
            d[*n].ids = ids;
            d[*n].vgs = vgs;
            d[*n].igs = igs;
            }

         ++(*n);
         }
      }

   fclose (file);
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void get_file_header (char *data_file, char *header, unsigned max_size)
   {
   FILE *file = fopen (data_file,"r");
   unsigned index = 0, len;
   char string[300];

   if (!header || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
      {
      if (string[0] != '!')
         {
         string[0] = 0;
         break;
         }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         if ((index + len) < max_size)
            {
            strcat (header, string);
            index += len;
            }
         else
            break;

         fgets (string,299,file);
         break;
         }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else
         break;
      }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if ((len > 0) && (index < max_size))
      {
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else if ((max_size - index) == 1);
      else
         {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
         }
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMS fixed,
                             int cap_mod)
   {
   FILE *file;
   unsigned i;
   unsigned count = 0;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   unsigned max_str = 0;
   char fmt[30];
   
   /* write final optimization parameter values */

   file = fopen (end_file, "w+");
   if (!file)
      {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", end_file);
      return -1;
      }

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (file);

   /* write the model parameter file */

   // non-optimized parameters
   
   names[num_p] = "version"; values[num_p] = cap_mod; ++num_p;
   names[num_p] = "ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "tnom"; values[num_p] = fixed.tnom; ++num_p;
   names[num_p] = "rg"; values[num_p] = fixed.rg; ++num_p;
   names[num_p] = "rd"; values[num_p] = fixed.rd; ++num_p;
   names[num_p] = "rs"; values[num_p] = fixed.rs; ++num_p;
   names[num_p] = "ri", values[num_p] = fixed.ri; ++num_p;
   names[num_p] = "is"; values[num_p] = fixed.is; ++num_p;
   names[num_p] = "n"; values[num_p] = fixed.n; ++num_p;
   names[num_p] = "ibd"; values[num_p] = fixed.ibd; ++num_p;
   names[num_p] = "vbd"; values[num_p] = fixed.vbd; ++num_p;
   names[num_p] = "lg"; values[num_p] = fixed.lg; ++num_p;
   names[num_p] = "ld"; values[num_p] = fixed.ld; ++num_p;
   names[num_p] = "ls"; values[num_p] = fixed.ls; ++num_p;
   names[num_p] = "c11"; values[num_p] = fixed.c11; ++num_p;
   names[num_p] = "c22"; values[num_p] = fixed.c22; ++num_p;
   names[num_p] = "cpg"; values[num_p] = fixed.cpg; ++num_p;
   names[num_p] = "cpd"; values[num_p] = fixed.cpd; ++num_p;
   names[num_p] = "deltads"; values[num_p] = fixed.deltads; ++num_p;

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      names[num_p] = params[i].name;
      values[num_p] = params[i].nom;
      ++num_p;
      }

   file = fopen (model_file, "w+");
   if (!file)
      {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", model_file);
      return -1;
      }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   //fprintf (file, "VAR model = 1\n");

   // write_model_param_mdif (file, names, values, num_p, 12, 5);

   for (i = 0; i < num_p; ++i)
      {
      if (strlen (names[i]) > max_str)
         max_str = strlen (names[i]);
      }

   sprintf (fmt, "%%-%ds = %%.4e\n", max_str); 

   fprintf (file, fmt, "model", 1.0);
   for (i = 0; i < num_p; ++i)
      fprintf (file, fmt, names[i], values[i]);
   
   fclose (file);
      
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
   {
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);
      
   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
   }

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
   {
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile = "parker.ps";
   jHANDLE legend, header;
   unsigned i;
   
   if (!open_graphics_device (dev, plotfile))
      {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
      }
   
   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
      {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
      }

   // draw all plots
   for (i = 0; i < n; ++i)
      {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
         {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
         }

      plot_list[i]->active = FALSE;
      }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
      {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
      }
   else
      close_graphics_device ();
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files (char *inname, char *endname)
   {
   FILE *file;
   OPT_PARAMETER p[] = {
      {  1.0000e+00,  1.0000e+00,  1.0000e+00,  0.0000e+00, "vbi", 0 },
      {  1.0000e-05,  1.2000e-02,  1.0000e+00,  0.0000e+00, "beta", 0 },
      { -3.5000e+00, -1.0000e+00,  5.0000e-01,  0.0000e+00, "vto", 0 },
      {  2.1000e+00,  2.5000e+00,  3.5000e+00,  0.0000e+00, "p", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "delta", 0 },
      {  2.0000e-01,  5.0000e-01,  8.0000e-01,  0.0000e+00, "p_minus_q", 0 },
      {  1.0000e-03,  8.0000e-02,  5.0000e-01,  0.0000e+00, "vst", 0 },
      {  0.0000e+00,  1.0000e-02,  5.0000e-01,  0.0000e+00, "mvst", 0 },
      {  0.0000e+00,  5.0000e-01,  2.0000e+00,  0.0000e+00, "xi", 0 },
      {  0.0000e+00,  6.0000e-05,  5.0000e-02,  0.0000e+00, "mxi", 0 },
      {  0.0000e+00,  1.0000e-04,  5.0000e-01,  0.0000e+00, "lambda", 0 },
      {  1.0000e-01,  2.0000e+00,  4.0000e+00,  0.0000e+00, "z", 0 },
      {  0.0000e+00,  5.0000e-02,  5.0000e-01,  0.0000e+00, "lfgam", 0 },
      {  0.0000e+00,  2.0000e-03,  5.0000e-01,  0.0000e+00, "lfg1", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "lfg2", 0 },
      { -1.0000e+00,  3.5000e-02,  1.0000e+00,  0.0000e+00, "hfgam", 0 },
      { -1.0000e+00,  1.2778e-03,  1.0000e+00,  0.0000e+00, "hfg1", 0 },
      { -1.0000e+00,  3.0000e-03,  1.0000e+00,  0.0000e+00, "hfg2", 0 },
      { -1.0000e+00, -6.0000e-02,  1.0000e+00,  0.0000e+00, "hfeta", 0 },
      { -1.0000e+00,  1.0000e-03,  1.0000e+00,  0.0000e+00, "hfe1", 0 },
      { -1.0000e+00, -8.0000e-02,  1.0000e+00,  0.0000e+00, "hfe2", 0 },
      {  1.0000e-15,  5.0000e-13,  5.0000e-12,  0.0000e+00, "cgs", 0 },
      {  1.0000e-16,  5.0000e-14,  5.0000e-13,  0.0000e+00, "cgd", 0 },
      {  3.0000e-01,  5.0000e-01,  9.5000e-01,  0.0000e+00, "fc", 0 },
      {  1.0000e-01,  5.0000e-01,  1.0000e+01,  0.0000e+00, "delta1", 0 },
      {  0.0000e+00,  5.0000e-01,  1.0000e+00,  0.0000e+00, "delta2", 0 },
      {  0.0000e+00,  5.0000e-01,  9.9000e-01,  0.0000e+00, "xc", 0 },
      {  0.0000e+00,  2.0000e-01,  1.0000e+00,  0.0000e+00, "acgam", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "cds", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "tau", 0 }
   };

   if (inname)
      {
      file = fopen (inname, "w+");
      if (!file)
         {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
         }

      fprintf (file, "2               # number of gate fingers\n");
      fprintf (file, "100             # unit gate width\n");
      fprintf (file, "27              # extraction temperature\n");
      fprintf (file, "s.end           # Y-fit file name\n");
      fprintf (file, "model.summary   # model summary file name\n");
      fprintf (file, "sdc.iv          # DC I-V file name\n");
      fprintf (file, "5               # max drain voltage for I-V fit\n");
      fprintf (file, "sfwd.iv         # forward I-V file name\n");
      fprintf (file, "svbr.iv         # breakdown I-V file name\n");
      fprintf (file, "parker.start    # starting parameters file name\n");
      fprintf (file, "parker.end      # finishing parameters file name (output)\n");
      fprintf (file, "parker.model    # model file name (output)\n");
      fprintf (file, "500             # maximum optimization iterations\n");
      
      fclose (file);
      }
   
   if (endname)
      {
      unsigned i;
      
      file = fopen (endname, "w+");
      if (!file)
         {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
         }
      
      for (i = 0; i < (sizeof(p) / sizeof(*p)); ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);
            
      fclose (file);
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static double safe_pow (double x, double y)
   {
   if ((x == 0.0) && (y < 0.0))
      return MAXFLOAT;
   else if (x == 0.0)
      return 0.0;

   return pow (x, y);
   }

/*****************************************************************************/
/*****************************************************************************/

static void check_parameter_ranges (OPT_PARAMETER *p, double Vmax, double Vpo)
   {
  
   /* set VBI to be fixed and equal to Vmax */

   p[0].min = p[0].nom = p[0].max = Vmax;

   /* set VTO to be fixed and equal to Vpo */

   p[2].min = p[2].nom = p[2].max = Vpo;
  
   /* set valid ranges on certain "trouble" parameters */

   if (p[1].min < 0.0)  // BETA should be >= 0
      p[1].min = 0.0;
   
   if (p[4].min < 0.0)  // DELTA must be >= 0
      p[4].min = 0.0;
      
   if (p[6].min < 1.0e-6)  // VST must be > 0
      p[6].min = 1.0e-6;
   
   if (p[7].min < 0.0)  // MVST must be >= 0
      p[7].min = 0.0;
   
   if (p[8].min < 0.0)  // XI must be >= 0
      p[8].min = 0.0;
   
   if (p[9].min < 0.0)  // MXI must be >= 0
      p[9].min = 0.0;

   if (p[10].min < 0.0)  // LAMBDA should be >= 0
      p[10].min = 0.0;

   if (p[11].min < 0.001)  // Z must be > 0
      p[11].min = 0.001;

   // force LFG2 to 0, it causes strange IV behavior otherwise
   p[14].min = p[14].nom = p[14].max = 0.0;
   
   if (p[21].min < 0.0)  // CGS must be >= 0
      p[21].min = 0.0;
   
   if (p[22].min < 0.0)  // CGD must be >= 0
      p[22].min = 0.0;

   if (p[23].min < 0.1)  // FC should be >= 0.1
      p[23].min = 0.1;
   if (p[23].max > 0.95)  // FC must be < 1.0
      p[23].max = 0.95;

   if (p[26].min < 0.0)  // XC should be >= 0.0
      p[26].min = 0.0;
   if (p[26].max > 0.95)  // XC must be < 1.0
      p[26].max = 0.95;
   }

/*****************************************************************************/
/*****************************************************************************/

static void read_vmax_from_file (char *fname, double *vmax, double *vpo)
   {
   FILE *file;
   char string[256];

   *vmax = 1.0;
   *vpo = -1.0;

   file = fopen (fname, "r");
   if (!file)
      return;

   while (fgets (string, 255, file))
      {
      if (string[0] != '!')
         break;

      if (!strncmp (string, "!Vbr", 4))
         {
         if (fgets (string, 255, file))
            sscanf (string, "!%*f%*f%*f%*f%*f%*f%lf%lf", vmax, vpo);
         break;
         }
      }

   fclose (file);
   }

