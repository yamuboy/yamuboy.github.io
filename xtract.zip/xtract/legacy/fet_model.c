#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmplxlib.h"

typedef struct {
   double rg, rd, rs, ri;
   double lg, ld, ls;
   double c1, c2, c11, c22;
   double cgs, cgd, cds;
   double ggs, ggd, gds;
   double gm, tau, tau2;
   double vv, ii;
   } FET_PARAMS;

#define LMIN    (1.e-18)
#define RMIN    (1.e-6)
#define TWOPI   (6.283185307179586476)

static int calculate_fet_model( char *s_file, char *end_file, char *rpc_file, char *out_file, double fstart,
                                double fstop, double fstep, double temperature );
static void write_fet_2port_sparams( FILE *file, FET_PARAMS *d, double w, double temp, int doNoise );

int main( int argc, char** argv )
   {
   char s_file[256], end_file[256], out_file[256];
   char rpc_file[256], str[256];
   double fstart, fstop, fstep, temperature;

   if( argc > 1 )
      {
      int i, j;
      char out_ext[24];
      char end_ext[24];
      char rpc_ext[24];

      fstart = 0.5e9;
      fstop = 26.5e9;
      fstep = 0.25e9;
      temperature = 298.15; /* 25 C */
      strcpy( out_ext, ".s2p" );
      strcpy( rpc_ext, ".rpc" );
      strcpy( end_ext, ".end" );

      for( i=1; i<argc; i++ )
         {
         if( *argv[i] != '-' )
            continue;

         if( !strncmp( argv[i], "--fstart=", 9 ) )
            {
            if( sscanf( &argv[i][9], "%lf", &fstart ) )
               fstart *= 1.e9;
            }
         else if( !strncmp( argv[i], "--fstop=", 8 ) )
            {
            if( sscanf( &argv[i][8], "%lf", &fstop ) )
               fstop *= 1.e9;
            }
         else if( !strncmp( argv[i], "--fstep=", 8 ) )
            {
            if( sscanf( &argv[i][8], "%lf", &fstep ) )
               fstep *= 1.e9;
            }
         else if( !strncmp( argv[i], "--temp=", 7 ) )
            {
            if( sscanf( &argv[i][7], "%lf", &temperature ) )
               temperature += 273.15;
            }
         else if( !strncmp( argv[i], "--out=", 6 ) )
            {
            sscanf( &argv[i][6], "%19s", out_ext );
            }
         else if( !strncmp( argv[i], "--rpc=", 6 ) )
            {
            sscanf( &argv[i][6], "%19s", rpc_ext );
            }
         else if( !strncmp( argv[i], "--end=", 6 ) )
            {
            sscanf( &argv[i][6], "%19s", end_ext );
            }
         }

      /* make sure file extensions start with a period */
      if( *out_ext != '.' )
         {
         sprintf( str, ".%s", out_ext );
         strcpy( out_ext, str );
         }
      if( *rpc_ext != '.' )
         {
         sprintf( str, ".%s", rpc_ext );
         strcpy( rpc_ext, str );
         }
      if( *end_ext != '.' )
         {
         sprintf( str, ".%s", end_ext );
         strcpy( end_ext, str );
         }

      /* compute the models */
      for( i=1; i<argc; i++ )
         {
         if( *argv[i] != '-' )
            {

            /* assume this is a s-parameter file name */
            strcpy( s_file, argv[i] );

            /* strip the extension */
            strcpy( end_file, s_file );
            for( j=strlen(end_file)-1; j>0; j-- )
               {
               if( end_file[j] == '.' )
                  {
                  end_file[j] = '\0';
                  break;
                  }
               else if( end_file[j] == '/' )
                  break;
               }
            strcpy( rpc_file, end_file );
            strcpy( out_file, end_file );

            /* add the file extensions */
            strcat( rpc_file, rpc_ext );
            strcat( end_file, end_ext );
            strcat( out_file, out_ext );

            /* replace the first character of the rpc file with an 'n' */
            for( j=strlen(rpc_file)-1; j>0; j-- )
               {
               if( rpc_file[j] == '/' )
                  {
                  j++;
                  break;
                  }
               }
            rpc_file[j] = 'n';

            if( calculate_fet_model( s_file, end_file, rpc_file, out_file, fstart, fstop, fstep, temperature ) )
               {
               fprintf( stderr, "Warning: %s: file not created.\n", out_file );
               }
            }
         }
      }
   else
      {
      printf( "S-parameter file name?\n" );
      fgets( str, 255, stdin );
      sscanf( str, "%s", s_file );

      printf( "Parameter file name?\n" );
      fgets( str, 255, stdin );
      sscanf( str, "%s", end_file );

      printf( "Noise model file name?\n" );
      fgets( str, 255, stdin );
      sscanf( str, "%s", rpc_file );

      printf( "Output file name?\n" );
      fgets( str, 255, stdin );
      sscanf( str, "%s", out_file );

      printf( "Frequency list in GHz (start stop step)?\n" );
      fgets( str, 255, stdin );
      sscanf( str, "%lf%lf%lf", &fstart, &fstop, &fstep );
      fstart *= 1.0e9;
      fstop *= 1.0e9;
      fstep *= 1.0e9;

      printf( "Temperature in C?\n" );
      fgets( str, 255, stdin );
      sscanf( str, "%lf", &temperature );
      temperature += 273.15;

      return calculate_fet_model( s_file, end_file, rpc_file, out_file, fstart, fstop, fstep, temperature );
      }

   return 0;
   }

/***************************************************************************/
/***************************************************************************/

static int calculate_fet_model( char *s_file, char *end_file, char *rpc_file, char *out_file, double fstart,
                                double fstop, double fstep, double temperature )
   {
   int have_noise = 0;
   double f, val;
   char name[20], str[256];
   FET_PARAMS params = { 0. };  
   FILE *file;
   char header[3000];

   /* read header from S-param file */
   *header = '\0';
   file = fopen( s_file, "r" );
   if( file )
      {
      while( fgets( str, 255, file ) )
         {
         if( *str != '!' )
            break;

         strcat( header, str );
         }
      fclose( file );
      }
   else
      {
      fprintf( stderr, "Warning: %s: file not found.\n", s_file );
      }

   /* read .end file */
   file = fopen( end_file, "r" );
   if( !file )
      {
      fprintf( stderr, "Error: %s: file not found.\n", end_file );
      return -1;
      }
   while( fgets( str, 255, file ) )
      {
      if( sscanf( str, "%*f%lf%*f%*f%19s", &val, name ) == 2 )
         {
         if( !strcasecmp( name, "rg" ) )
            params.rg = val;
         else if( !strcasecmp( name, "rd" ) )
            params.rd = val;
         else if( !strcasecmp( name, "rs" ) )
            params.rs = val;
         else if( !strcasecmp( name, "ri" ) )
            params.ri = val;
         else if( !strcasecmp( name, "ls" ) )
            params.ls = val;
         else if( !strcasecmp( name, "b1" ) )
            params.lg = val;
         else if( !strcasecmp( name, "b2" ) )
            params.ld = val;
         else if( !strcasecmp( name, "cgs" ) )
            params.cgs = val;
         else if( !strcasecmp( name, "cdg" ) )
            params.cgd = val;
         else if( !strcasecmp( name, "cds" ) )
            params.cds = val;
         else if( !strcasecmp( name, "c1" ) )
            params.c1 = val;
         else if( !strcasecmp( name, "c2" ) )
            params.c2 = val;
         else if( !strcasecmp( name, "c11" ) )
            params.c11 = val;
         else if( !strcasecmp( name, "c22" ) )
            params.c22 = val;
         else if( !strcasecmp( name, "gm" ) )
            params.gm = val;
         else if( !strcasecmp( name, "tau1" ) )
            params.tau = val;
         else if( !strcasecmp( name, "gds" ) )
            params.gds = val;
         else if( !strcasecmp( name, "tau2" ) )
            params.tau2 = val;
         else if( !strcasecmp( name, "ggs" ) )
            params.ggs = val;
         else if( !strcasecmp( name, "gdg" ) )
            params.ggd = val;
         }
      }
   fclose( file );

   if( params.rg < RMIN )
      params.rg = RMIN;
   if( params.rd < RMIN )
      params.rd = RMIN;
   if( params.rs < RMIN )
      params.rs = RMIN;
   if( params.ri < RMIN )
      params.ri = RMIN;


   /* read .rpc file */
   if( rpc_file && *rpc_file )
      {
      file = fopen( rpc_file, "r" );
      if( file )
         {
         double val2;
         while( fgets( str, 255, file ) )
            {
            if( sscanf( str, "%*f%*f%*f%*f%*f%*f%*f%*f%*f%lf%lf", &val, &val2 ) == 2 )
               {
               params.vv = val;
               params.ii = val2;
               have_noise = 1;
               break;
               }
            }
         fclose( file );
         }
      else
         {
         fprintf( stderr, "Warning: %s: file not found.\n", rpc_file );
         }
      }

   file = fopen( out_file, "w+" );
   if( !file )
      {
      fprintf( stderr, "Error: %s: unable to write file.\n", out_file );
      return -1;
      }

   /* write header */
   fprintf( file, "%s", header );
   fprintf( file, "# HZ S MA R 50\n" );

   /* write S-params */
   for( f=fstart; f<=fstop; f+=fstep )
      {
      write_fet_2port_sparams( file, &params, f*TWOPI, temperature, 0 );
      }

   /* write noise params */
   if( have_noise )
      {
      fprintf( file, "! Noise Data\n" );
      fprintf( file, "! Frequency    Fmin     Gamma_mag    Gamma_ang      Rn\n" );
      for( f=fstart; f<=fstop; f+=fstep )
         {
         write_fet_2port_sparams( file, &params, f*TWOPI, temperature, 1 );
         }
      }
   fclose( file );

   return 0;
   }

/***************************************************************************/
/***************************************************************************/
/* perform nodal reduction on both the [Y] and [CY] matrices simultaneously */

static void gaussian_reduce( COMPLEX **y, COMPLEX **cy, int n, int m )
   {
   COMPLEX temp1, denom;
   static COMPLEX neg_one = {-1.0, 0.0};
   double max, tmax;
   int i, j, k, row, col;
      
   for( k=n-1; k>=m; k-- )
      {      
      /* find the largest value */
      for( i=m, row=k, col=k, max=0.0; i<=k; i++ )
         {
         for( j=m; j<=k; j++ )
            {
            tmax = Cmag2( y[i][j] );
            if( tmax > max )
               {
               row = i;
               col = j;
               max = tmax;
               }
            }
         }
      
      /* pivot rows */
      if( row != k )
         {
         for( j=0; j<=k; j++ )
            {
            temp1 = y[k][j];
            y[k][j] = y[row][j];
            y[row][j] = temp1;
            if( cy )
               {
               temp1 = cy[k][j];
               cy[k][j] = cy[row][j];
               cy[row][j] = temp1;
               }
            }
      
         if( cy )
            {
            for( i=0; i<=k; i++ )
               {
               temp1 = cy[i][k];
               cy[i][k] = cy[i][row];
               cy[i][row] = temp1;            
               }
            }
         }

      /* pivot columns */
      if( col != k )
         {
         for( i=0; i<=k; i++ )
            {
            temp1 = y[i][k];
            y[i][k] = y[i][col];
            y[i][col] = temp1;
            }
         }
      

      /* perform nodal reduction by one */
      if( cy )
         {
         COMPLEX temp2, denom2;
         COMPLEX factor1, factor2, factor3a, factor3;

         denom = Cdiv( neg_one, y[k][k] );
         denom2 = Cdiv( neg_one, Cconj( y[k][k] ) );
         for( i=0; i<k; i++ )
            {
            for( j=0; j<k; j++ )
               {
               temp1 = Cmult( y[i][k], denom );
               temp2 = Cmult( Cconj( y[j][k] ), denom2 );            
               factor1 = Cadd( cy[i][j], Cmult( cy[k][j], temp1 ) );
               factor2 = Cmult( cy[i][k], temp2 );
               factor3a = Cmult( temp1, temp2 );
               factor3 = Cmult( cy[k][k], factor3a );
               cy[i][j] = Caddx( 3, factor1, factor2, factor3 );
               y[i][j] = Cadd( y[i][j], Cmult( y[k][j], temp1 ) );
               }
            }
         }
      else
         {
         denom = Cdiv( neg_one, y[k][k] );
         for( i=0; i<k; i++ )
            {
            if( y[i][k].r != 0.0 || y[i][k].i != 0.0 )
               {
               y[i][k] = Cmult( y[i][k], denom );
               for( j=0; j<k; j++ )
                  y[i][j] = Cadd( y[i][j], Cmult( y[k][j], y[i][k] ) );
               }
            }
         }
      } 
   }

/***************************************************************************/
/***************************************************************************/

static void addmatrix_cpx( COMPLEX **m, int n1, int n2, COMPLEX val )
   {
   m[n1][n1].r += val.r;
   m[n1][n1].i += val.i;
   m[n2][n2].r += val.r;
   m[n2][n2].i += val.i;
   m[n2][n1].r -= val.r;
   m[n2][n1].i -= val.i;
   m[n1][n2].r -= val.r;
   m[n1][n2].i -= val.i;
   }

/***************************************************************************/
/***************************************************************************/

static void addmatrix_real( COMPLEX **m, int n1, int n2, double val )
   {
   m[n1][n1].r += val;
   m[n2][n2].r += val;
   m[n1][n2].r -= val;
   m[n2][n1].r -= val;
   }

/***************************************************************************/
/***************************************************************************/

static void addmatrix_imag( COMPLEX **m, int n1, int n2, double val )
   {
   m[n1][n1].i += val;
   m[n2][n2].i += val;
   m[n1][n2].i -= val;
   m[n2][n1].i -= val;
   }

/***************************************************************************/
/***************************************************************************/

static void addmatrix_vccs( COMPLEX **m, int vp, int vm, int cm, int cp, COMPLEX val )
   {
   m[cm][vp].r += val.r;
   m[cm][vp].i += val.i;
   m[cp][vm].r += val.r;
   m[cp][vm].i += val.i;
   m[cp][vp].r -= val.r;
   m[cp][vp].i -= val.i;
   m[cm][vm].r -= val.r;
   m[cm][vm].i -= val.i;
   }

/***************************************************************************/
/***************************************************************************/

static COMPLEX **load_fet_y_matrix( FET_PARAMS *d, double w )
   {
   static COMPLEX y1[9], y2[9], y3[9];
   static COMPLEX y4[9], y5[9], y6[9];
   static COMPLEX y7[9], y8[9], y9[9];
   static COMPLEX *y[] = { y1, y2, y3, y4, y5, y6, y7, y8, y9 };
   static COMPLEX zero = {0.0, 0.0};
   static double sc = 1.0e12;  /* short circuit */
   COMPLEX cval;
   double den;
   int i, j;

   /* zero the matrix */
   for( i=0; i<9; i++ )
      {
      for( j=0; j<9; j++ )
         y[i][j] = zero;
      }

   /* LG and LD */
   /* replace the inductors with short circuits at w=0 or if their values are less than LMIN */
   (w == 0.0 || fabs(d->lg) < LMIN) ? addmatrix_real( y, 1, 7, sc ) : addmatrix_imag( y, 1, 7, -1.0/(w*d->lg) );
   (w == 0.0 || fabs(d->ld) < LMIN) ? addmatrix_real( y, 2, 8, sc ) : addmatrix_imag( y, 2, 8, -1.0/(w*d->ld) );

   /* RG and RD */
   addmatrix_real( y, 3, 7, 1.0/d->rg );
   addmatrix_real( y, 4, 8, 1.0/d->rd );

   /* RS and LS */
   den = 1.0 / (d->rs*d->rs + w*w*d->ls*d->ls);
   cval.r = d->rs*den;
   cval.i = -w*d->ls*den;
   addmatrix_cpx( y, 5, 0, cval );

   /* C11 and C22 */
   y[1][1].i += w*d->c1;
   y[2][2].i += w*d->c2;

   /* C1 and C2 */
   addmatrix_imag( y, 7, 0, w*d->c11 );
   addmatrix_imag( y, 8, 0, w*d->c22 );

   /* GGS, GGD, RI, CGS, CGD, and CDS */
   addmatrix_real( y, 3, 6, d->ggs );
   addmatrix_real( y, 3, 4, d->ggd );
   addmatrix_real( y, 5, 6, 1.0/d->ri );
   addmatrix_imag( y, 3, 6, w*d->cgs );
   addmatrix_imag( y, 3, 4, w*d->cgd );
   addmatrix_imag( y, 4, 5, w*d->cds );

   /* GM and GDS */
   cval.r = d->gm*cos( w*d->tau );
   cval.i = -d->gm*sin( w*d->tau );
   addmatrix_vccs( y, 3, 6, 4, 5, cval );
   cval.r = d->gds*cos( w*d->tau2 );
   cval.i = -d->gds*sin( w*d->tau2 );
   addmatrix_vccs( y, 4, 5, 4, 5, cval );

   return y;
   }

/***************************************************************************/
/***************************************************************************/

static COMPLEX **load_fet_cy_matrix( FET_PARAMS *d, double w, double TS )
   {
   static COMPLEX cy1[9], cy2[9], cy3[9];
   static COMPLEX cy4[9], cy5[9], cy6[9];
   static COMPLEX cy7[9], cy8[9], cy9[9];
   static COMPLEX *cy[] = { cy1, cy2, cy3, cy4, cy5, cy6, cy7, cy8, cy9 };
   static COMPLEX zero = {0.0, 0.0};
   int i, j;

   /* zero the matrix */
   for( i=0; i<9; i++ )
      {
      for( j=0; j<9; j++ )
         cy[i][j] = zero;
      }

   /* RG, RD, and RS noise */
   addmatrix_real( cy, 3, 7, TS/d->rg );
   addmatrix_real( cy, 4, 8, TS/d->rd );
   addmatrix_real( cy, 5, 0, TS*d->rs/(d->rs*d->rs + w*w*d->ls*d->ls) );

   /* GGS and GGD noise */
   addmatrix_real( cy, 3, 6, TS*d->ggs );
   addmatrix_real( cy, 3, 4, TS*d->ggd );

   /* active noise sources */
   addmatrix_real( cy, 4, 5, d->ii );
   addmatrix_real( cy, 6, 5, d->vv/(d->ri*d->ri) );

   return cy;
   }

/*********************************************************************************************/
/*********************************************************************************************/

static void noise_parameters( COMPLEX **y, COMPLEX **cy, double z0, double *fmin, double *mag, double *angle, double *rn )
   {
   COMPLEX ca[4], yopt, gamma, denom;
   COMPLEX one = {1.0, 0.0};
   double gopt, bopt;

   /* convert to chain representation */
   denom = Complex( 1.0 / Cmag2(y[2][1]) ); 
   ca[0] = Cmult( cy[2][2], denom );
   ca[1] = Cmult( Csub( Cmult( cy[2][2], Cconj(y[1][1]) ), Cmult( cy[2][1], Cconj(y[2][1]) ) ), denom );
   ca[2] = Cmult( Csub( Cmult( cy[2][2], y[1][1] ), Cmult( cy[1][2], y[2][1] ) ), denom );
   ca[3] = Csub( Cmult( cy[1][1], Complex(Cmag2( y[2][1] )) ), Cmultx( 3, cy[1][2], Cconj(y[1][1]), y[2][1] ) );
   ca[3] = Cadd( ca[3], Csub( Cmult( cy[2][2], Complex(Cmag2( y[1][1] )) ), Cmultx( 3, cy[2][1], y[1][1], Cconj(y[2][1]) ) ) );
   ca[3] = Cmult( ca[3], denom );

   *rn = ca[0].r;

   bopt = 0.5 * Cimag( Csub( ca[1], ca[2] ) ) / *rn;
   gopt = sqrt( fabs( Creal( Csub( Cdiv (ca[3], Complex(*rn) ), Complex(bopt*bopt) ) ) ) );
   yopt = Cnum( gopt, bopt );
   gamma = Cdiv( Csub( Complex(1.0 / z0), yopt ), Cadd( Complex (1.0 / z0), yopt ) );

   *mag = Cmag( gamma );
   *angle = Cangle( gamma );
   *fmin = 10.0 * log10( Creal( Caddx( 4, one, ca[1], ca[2], Complex(2.0 * (*rn) * gopt) ) ) );
   }

/***************************************************************************/
/***************************************************************************/

static void write_fet_2port_sparams( FILE *file, FET_PARAMS *d, double w, double temp, int doNoise )
   {
   COMPLEX **y;
   static double Z0 = 50.0;

   /* load the [Y] matrix */
   y = load_fet_y_matrix( d, w );

   if( doNoise )
      {
      COMPLEX **cy;
      double fmin, mag, angle, rn;
      /* temperature scale factor */
      double TS = temp / 290.0;

      /* load the [CY] (noise correlation) matrix */
      cy = load_fet_cy_matrix( d, w, TS );

      /* the [Y] and [CY] matrices need to be reduced to 3x3 (indicies 0-2) */
      gaussian_reduce( y, cy, 9, 3 );

      /* calculate noise parameters */
      noise_parameters( y, cy, Z0, &fmin, &mag, &angle, &rn );

      /* write noise parameters */
      fprintf( file, "%.5e %.5e %.5e %+.5e %.5e\n", w / TWOPI,
         fmin, mag, angle, rn/Z0 );
      }
   else
      {
      COMPLEX yt[4], s[4];
      POLAR sp[4];

      /* the [Y] and matrix needs to be reduced to 3x3 (indicies 0-2) */
      gaussian_reduce( y, NULL, 9, 3 );

      /* convert to S */
      yt[0] = y[1][1];
      yt[1] = y[1][2];
      yt[2] = y[2][1];
      yt[3] = y[2][2];
      y2s( yt, s, Z0 );
      CA2PA( s, sp, 2, 2 ); 

      /* write S-parameters */
      fprintf( file, "%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n", w / TWOPI,
         sp[0].m, sp[0].a, sp[2].m, sp[2].a, sp[1].m, sp[1].a, sp[3].m, sp[3].a );
      }
   }

