#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "ss_tools2.h"

typedef struct
   {
   S_2PORT *sMeas;
   unsigned sz_s;
   } IND_DATA;

#define MAX_FREQS   500
#define N_PARAMS    5
#define Q_FREQ      1.0e9

static int inductor_erf (double *pl, void *data, double *err, unsigned n_err);
static void inductor_model (double *pl, COMPLEX *sp, double freq);
static void linefit_mx0 (double *x, double *y, unsigned n, double *m, double *r2);

/******************************************************************************/
/******************************************************************************/

main (int argc, char *argv[]) 
   {
   IND_DATA ind_data;
   char s_measured[256];
   char string[256];
   char fname[256];
   char out_name[256];
   char starting_values[256];
   char extension[20];
   char *batch_name;
   unsigned maxiter = 0;
   double weights[4];
   S_2PORT sp[MAX_FREQS];
   COMPLEX zp[4];
   OPT_PARAMETER p[N_PARAMS];
   OPTIMIZE *opt;
   double fmin,fmax,fmin_direct,fmax_direct;
   double fr[MAX_FREQS];
   double z21[MAX_FREQS];
   double m,r2,l_val;
   unsigned i,findex,numf,num_z;
   FILE *batch_file,*file;
   double pl[N_PARAMS];
   COMPLEX sMod[4];
   POLAR sModp[4];


   printf ("Measured data file(s)?\n");
   fgets (s_measured, 255, stdin);
   s_measured[strlen(s_measured)-1] = 0;
   
   printf ("Frequency range for optimization in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fmin, &fmax) != 2)
      {
      fprintf (stderr, "Error reading min/max frequencies\n");
      return -1;
      }
   fmin *= 1.0e9;
   fmax *= 1.0e9;

   printf ("Frequency range for direct extraction in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fmin_direct, &fmax_direct) != 2)
      {
      fprintf (stderr, "Error reading frequency.\n");
      return -1;
      }
   fmin_direct *= 1.0e9;
   fmax_direct *= 1.0e9;

   printf ("Optimization weights (S11 S21 S12 S22)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2],
      &weights[3]) != 4)
      {
      fprintf (stderr, "Error reading optimization weights.\n");
      return -1;
      }

   printf ("Output file extension?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%9s", extension);

   printf ("Initial parameters file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", starting_values);

   printf ("Maximum number of line searches?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%u", &maxiter);

   // initialize the optimizer

   opt = initialize_cg_optimizer ();
   set_cg_error_function (opt, inductor_erf, &ind_data, 4, weights);
   set_cg_parameters (opt, p, N_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE);
   set_cg_error_fraction (opt, 1.0e-10, 5);

   // get the file list

   batch_name = "temp_list_file";

   sprintf (string, "rm -f %s", batch_name);
   system (string);
   sprintf (string, "ls -1 %s > %s", s_measured, batch_name);
   system (string);

   batch_file  = fopen (batch_name, "r");
   if (!batch_file)
      {
      fprintf (stderr, "Cannot read file list.\n");
      return -1;
      }

   // start the loop

   while (fgets (fname, 255, batch_file))
      {
      fname[strlen(fname)-1] = 0;

      // read the starting values

      file = fopen (starting_values, "r");
      if (!file)
         {
         fprintf (stderr, "Starting values cannot be read.\n");
         return -1;
         }

      i = 0;
      while (fgets (string, 255, file))
         {
         if (string[0] == '!')
            continue;
         else if (i >= N_PARAMS)
            break;
         else if (sscanf (string, "%lf%lf%lf%lf%19s", &p[i].min, &p[i].nom,
            &p[i].max, &p[i].tol, p[i].name) == 5)
            {
            p[i].optimize = TRUE;
            ++i;
            }
         }
      fclose (file);

      if (i != N_PARAMS)
         {
         fprintf (stderr, "Starting values file incomplete.\n");
         return -1;
         }

      // read in s-parameters
      
      numf = read_s_from_file (fname, sp, NULL, MAX_FREQS);
      if (numf < 1)
         {
         fprintf (stderr, "No data in %s; or file not found.\n",fname);
         continue;
         }
      
      // determine the start and stop indexes
      
      findex = numf;
      for (i = 0; i < numf; ++i)
         {
         if (sp[i].freq >= fmin)
            {
            findex = i;
            break;
            }
         }

      ind_data.sMeas = &sp[findex];
      ind_data.sz_s = 0;

      for (i = findex; i < numf; ++i)
         {
         if (sp[i].freq <= fmax)
            ++ind_data.sz_s;
         }
      
      if (ind_data.sz_s < 1)
         {
         fprintf (stderr, "No measured data within specified frequency range.\n");
         continue;
         }

      // do direct extraction of inductance

      /*
      num_z = 0;
      for (i = 0; i < numf; ++i)
         {
         if (sp[i].freq < fmin_direct)
            continue;
         else if (sp[i].freq > fmax_direct)
            break;

         s2z (sp[i].s, zp, 50.0);
         fr[num_z] = sp[i].freq;
         z21[num_z] = (zp[0].i + zp[3].i) * 0.5;
         ++num_z;
         }

      if (num_z > 0)
         {
         linefit_mx0 (fr, z21, num_z, &m, &r2);
         l_val = m / (2.0 * acos (-1.0));
         p[0].nom = fabs (l_val);
         p[0].min = 0.0;
         p[0].max = fabs (l_val)*5.0;
         }
      */

      // optimize

      if (cg_optimize4 (opt, maxiter, NULL))
         {
         fprintf (stderr, "Error: %s\n", get_cg_error ());
         continue;
         }

      // write the model file

      sscanf (fname, "%[^.]", out_name);
      strcat (out_name, extension);
      
      file = fopen (out_name, "w+");
      if (!file)
         {
         fprintf (stderr, "Error writing output.\n");
         continue;
         }

      fprintf (file, "!FILE: %s\n!\n", fname);
      fprintf (file, "!L  = %.4e H\n", p[0].nom);
      fprintf (file, "!Q  = %.4e\n", p[1].nom);
      fprintf (file, "!Cp = %.4e F\n", p[2].nom);
      fprintf (file, "!C1 = %.4e F\n", p[3].nom);
      fprintf (file, "!C2 = %.4e F\n!\n", p[4].nom);
      fprintf (file,"# S HZ MA R 50\n");

      pl[0] = p[0].nom;
      pl[1] = p[1].nom;
      pl[2] = p[2].nom;
      pl[3] = p[3].nom;
      pl[4] = p[4].nom;

      for (i = 0; i < numf; ++i)
         {
         inductor_model (pl, sMod, sp[i].freq);

         CA2PA (sMod, sModp, 2, 2);

         fprintf (file, "%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
            sp[i].freq, sModp[0].m, sModp[0].a, sModp[2].m, sModp[2].a,
            sModp[1].m, sModp[1].a, sModp[3].m, sModp[3].a);
         }
      fclose (file);

      // write final parameter values

      sscanf (fname, "%[^.]", out_name);
      strcat (out_name, ".end");

      file = fopen (out_name, "w+");
      if (!file)
         {
         fprintf (stderr, "Error writing output.\n");
         continue;
         }

      for (i = 0; i < N_PARAMS; ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);

      fclose (file);

      printf ("File %s complete.\n", fname);
      }
   fclose (batch_file);

   sprintf (string, "rm -f %s", batch_name);
   system (string);

   return 0;
   }

/******************************************************************************/
/******************************************************************************/

static int inductor_erf (double *pl, void *data, double *err, unsigned n_err)
   {
   IND_DATA *d = (IND_DATA *) data;
   COMPLEX s[4];
   COMPLEX zmeas[4],zmod[4];
   unsigned i;

   if ((n_err < 4) || !data)
      return 1;

   // zero the error vector
   for (i = 0; i < n_err; ++i)
      err[i] = 0.0;

   // for each frequency,
   //  load the y-matrix
   //  calculate 2-port s-parameters
   //  calculate the L1 error vs measured data
   for (i = 0; i < d->sz_s; ++i)
      {
      inductor_model (pl, s, d->sMeas[i].freq);
      s2z (s, zmod, 50.0);
      s2z (d->sMeas[i].s, zmeas, 50.0);

      err[0] += Cmag2 (Csub (zmeas[0], zmod[0]));
      err[1] += Cmag2 (Csub (zmeas[2], zmod[2]));
      err[2] += Cmag2 (Csub (zmeas[1], zmod[1]));
      err[3] += Cmag2 (Csub (zmeas[3], zmod[3]));
      }

   // divide by the number of frequencies
   err[0] /= (double) d->sz_s;
   err[1] /= (double) d->sz_s;
   err[2] /= (double) d->sz_s;
   err[3] /= (double) d->sz_s;

   return 0;
   }

/******************************************************************************/
/******************************************************************************/

static void inductor_model (double *pl, COMPLEX *sp, double freq)
   {
   double w = 2.0 * acos (-1.0) * freq;
   double r,indr,indi;
   COMPLEX y[4];
   double l  = pl[0];
   double q  = pl[1];
   double cp = pl[2];
   double c1 = pl[3];
   double c2 = pl[4];

   r = 2.0 * acos (-1.0) * Q_FREQ * l / q;
   r = r * sqrt (freq / Q_FREQ);
   if (r < 1.0e-6)
      r = 1.0e-6;

   indr = r/(r*r + w*w*l*l);
   indi = -w*l/(r*r + w*w*l*l);
   
   y[0].r = indr;
   y[0].i = w*c1 + w*cp + indi;
   
   y[1].r = -indr;
   y[1].i = -w*cp - indi;
   
   y[2].r = -indr;
   y[2].i = -w*cp - indi;
   
   y[3].r = indr;
   y[3].i = w*c2 + w*cp + indi;
   
   y2s (y, sp, 50.0);
   }

/******************************************************************************/
/******************************************************************************/

static void linefit_mx0 (double *x, double *y, unsigned n, double *m, double *r2)
   {
   unsigned i;
   double ysum = 0.0;
   double xxsum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   for (i = 0; i < n; ++i)
      {
      ysum  += y[i];
      xxsum += x[i]*x[i];
      xysum += x[i]*y[i];
      }

   *m = xysum / xxsum;
   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] - y[i])*((*m)*x[i] - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }




