#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "cmplxlib.h"

#define MAX_FREQS (1000)

#ifdef WIN32
#define DEL_COMMAND    "del /f"
#define LIST_COMMAND   "dir /b"
#else
#define DEL_COMMAND    "rm -f"
#define LIST_COMMAND   "ls -1"
#endif

main ()
{
POLAR   s[4];
COMPLEX fxa[MAX_FREQS][4],fxb[MAX_FREQS][4],s_rect[4],s_abcd[4];
static  COMPLEX ideal[4] = {{1.0,0.0},{0.0,0.0},{0.0,0.0},{1.0,0.0}};
double  freq,freq_p1[MAX_FREQS],freq_p2[MAX_FREQS],last_freq,tmp;
char    string[256],str[6];
char    s_file_name[256],out_file_name[256],batch_file_name[100];
char    files[256],in_file[100],out_file[100],extension[10];
FILE    *port,*s_file,*dmb_file,*batch_file;
int     num_port1_pts,num_port2_pts;
int     i,j,k,num_files,num_biases;
int     ri_format,db_format;
int     port1_ideal = 0;
int     port2_ideal = 0;
int     embed_s = 0;
time_t  dummy;

printf ("[S] file name(s)?\n> ");
fgets (files,255,stdin);
files[strlen(files)-1] = 0;

printf ("Input error box?\n> ");
fgets (string,255,stdin);
sscanf (string,"%99s",in_file);

printf ("Output error box?\n> ");
fgets (string,255,stdin);
sscanf (string,"%99s",out_file);

printf ("Extension for output files?\n> ");
fgets (string,255,stdin);
sscanf (string,"%9s",extension);

sprintf (batch_file_name,"batch.%d",time(&dummy));
sprintf (string,"%s %s > %s",LIST_COMMAND,files_to_deembed,batch_file_name);
system (string);

if (!strcmp (in_file,"ideal") || !strcmp (in_file,"IDEAL"))
   port1_ideal = 1;

if (!strcmp (out_file,"ideal") || !strcmp (out_file,"IDEAL"))
   port2_ideal = 1;

batch_file = fopen (batch_file_name,"r");
if (!batch_file)
   {
   printf ("** error ** cannot open batch file\n");
   exit (1);
   }

if (!port1_ideal)
   {
   port = fopen (in_file,"r");
   if (!port)
      {
      printf ("** error ** cannot open input error box file - %s\n",in_file);
      fclose (batch_file);
      sprintf (string,"%s %s",DEL_COMMAND,batch_file_name);
      system (string);
      exit (1);
      }

   i = 0;
   db_format = 0;
   ri_format = 0;
   while (fgets (string,255,port))
      {
      if (string[0] == '!')
         continue;

      if (i >= MAX_FREQS)
         {
         printf ("** warning ** %s contains more than %d frequencies, first %d read.",in_file,MAX_FREQS,MAX_FREQS);
         break;
         }
         
      if (sscanf (string,"#%5s%5s%5s%5s%lf",str,str,str,str,&tmp) == 5)
         {
         if (strstr(string,"RI") || strstr(string,"ri"))
            ri_format = 1;
         else if (strstr(string,"DB") || strstr(string,"db"))
            db_format = 1;
         }

      if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq_p1[i],&s[0].m,&s[0].a,
          &s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
         {
         if (db_format)
            {
            s[0].m = pow (10.0,s[0].m*0.05);
            s[1].m = pow (10.0,s[1].m*0.05);
            s[2].m = pow (10.0,s[2].m*0.05);
            s[3].m = pow (10.0,s[3].m*0.05);
            PA2CA (s,s_rect,2,2);
            }
         else if (ri_format)
            {
            s_rect[0].r = s[0].m;
            s_rect[0].i = s[0].a;
            s_rect[1].r = s[1].m;
            s_rect[1].i = s[1].a;
            s_rect[2].r = s[2].m;
            s_rect[2].i = s[2].a;
            s_rect[3].r = s[3].m;
            s_rect[3].i = s[3].a;
            }
         else   
            PA2CA (s,s_rect,2,2);
            
         s2abcd (s_rect,fxa[i],50.0);
         ++i;
         }
      }
   num_port1_pts = i;
   fclose (port1);
   }

if (!port2_ideal)
   {
   port = fopen (out_file,"r");
   if (!port)
      {
      printf ("** error ** cannot open output error box file - %s\n",out_file);
      fclose (batch_file);
      sprintf (string,"%s %s",DEL_COMMAND,batch_file_name);
      system (string);
      exit (1);
      }
   
   i = 0;
   db_format = 0;
   ri_format = 0;
   while (fgets (string,255,port))
      {
      if (string[0] == '!')
         continue;

      if (i >= MAX_FREQS)
         {
         printf ("** warning ** %s contains more than %d frequencies, first %d read.",in_file,MAX_FREQS,MAX_FREQS);
         break;
         }
         
      if (sscanf (string,"#%5s%5s%5s%5s%lf",str,str,str,str,&tmp) == 5)
         {
         if (strstr(string,"RI") || strstr(string,"ri"))
            ri_format = 1;
         else if (strstr(string,"DB") || strstr(string,"db"))
            db_format = 1;
         }

      if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq_p1[i],&s[0].m,&s[0].a,
          &s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
         {
         if (db_format)
            {
            s[0].m = pow (10.0,s[0].m*0.05);
            s[1].m = pow (10.0,s[1].m*0.05);
            s[2].m = pow (10.0,s[2].m*0.05);
            s[3].m = pow (10.0,s[3].m*0.05);
            PA2CA (s,s_rect,2,2);
            }
         else if (ri_format)
            {
            s_rect[0].r = s[0].m;
            s_rect[0].i = s[0].a;
            s_rect[1].r = s[1].m;
            s_rect[1].i = s[1].a;
            s_rect[2].r = s[2].m;
            s_rect[2].i = s[2].a;
            s_rect[3].r = s[3].m;
            s_rect[3].i = s[3].a;
            }
         else   
            PA2CA (s,s_rect,2,2);
            
         s2abcd (s_rect,fxb[i],50.0);
         ++i;
         }
      }
   num_port2_pts = i;
   fclose (port);
   }

printf ("\ncascading");

num_biases = 0;
num_files = 0;
while (fgets (s_file_name,80,batch_file))
   {
   s_file_name[strlen(s_file_name)-1] = 0;
   sscanf (s_file_name,"%[^.]",out_file_name);
   strcat (out_file_name,extension);

   s_file = fopen (s_file_name,"r");
   if (!s_file)
      continue;
   dmb_file = fopen (out_file_name,"w+");
   ++num_files;
   printf (".");

   i = 0;
   j = 0;
   ri_format = 0;
   db_format = 0;
   last_freq = 0.0;
   while (fgets (string,255,s_file))
      {
      if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].m,&s[0].a,&s[2].m,&s[2].a,
             &s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
         {
         if (db_format)
            {
            s[0].m = pow (10.0,s[0].m*0.05);
            s[1].m = pow (10.0,s[1].m*0.05);
            s[2].m = pow (10.0,s[2].m*0.05);
            s[3].m = pow (10.0,s[3].m*0.05);
            PA2CA (s,s_rect,2,2);
            }
         else if (ri_format)
            {
            s_rect[0].r = s[0].m;
            s_rect[0].i = s[0].a;
            s_rect[1].r = s[1].m;
            s_rect[1].i = s[1].a;
            s_rect[2].r = s[2].m;
            s_rect[2].i = s[2].a;
            s_rect[3].r = s[3].m;
            s_rect[3].i = s[3].a;
            }
         else   
            PA2CA (s,s_rect,2,2);
            
         s2abcd (s_rect,s_abcd,50.0);            

         if (freq < last_freq)
            {
            ++num_biases;
            i = 0;
            j = 0;
            }
         last_freq = freq;
         
         if (!port1_ideal)
            {
            while (freq_p1[i] < (freq - 1.0e3))
               {
               ++i;
               if (i >= num_port1_pts)
                  break;
               }
            if (freq_p1[i] > (freq + 1.0e3))
               continue;
            }
         
         if (!port2_ideal)
            {
            while (freq_p2[j] < (freq - 1.0e3))
               {
               ++j;
               if (j >= num_port2_pts)
                  break;
               }
            if (freq_p2[j] > (freq + 1.0e3))
               continue;
            }

         if (emded_s)
            {
            if (port1_ideal && port2_ideal)
               CSembed (ideal,s_abcd,ideal,s_abcd);
            else if (port1_ideal)
               CSembed (ideal,s_abcd,fxb[j],s_abcd);
            else if (port2_ideal)
               CSembed (fxa[i],s_abcd,ideal,s_abcd);
            else
               CSembed (fxa[i],s_abcd,fxb[j],s_abcd);
            }
         else
            {
            if (port1_ideal && port2_ideal)
               CSdeembed (ideal,s_abcd,ideal,s_abcd);
            else if (port1_ideal)
               CSdeembed (ideal,s_abcd,fxb[j],s_abcd);
            else if (port2_ideal)
               CSdeembed (fxa[i],s_abcd,ideal,s_abcd);
            else
               CSdeembed (fxa[i],s_abcd,fxb[j],s_abcd);
            }            

         abcd2s (s_abcd,s_rect,50.0);
         
         if (ri_format)
            {
            s[0].m = s_rect[0].r;
            s[0].a = s_rect[0].i;
            s[1].m = s_rect[1].r;
            s[1].a = s_rect[1].i;
            s[2].m = s_rect[2].r;
            s[2].a = s_rect[2].i;
            s[3].m = s_rect[3].r;
            s[3].a = s_rect[3].i;            
            }
         else if (db_format)
            {
            CA2PA (s_rect,s,2,2);
            s[0].m = 20.0*log10 (s[0].m);
            s[1].m = 20.0*log10 (s[1].m);
            s[2].m = 20.0*log10 (s[2].m);    
            s[3].m = 20.0*log10 (s[3].m);            
            }
         else
            CA2PA (s_rect,s,2,2);

         if (!ri_format)
            {
            /* fix any angles that don't fall into +/- 180 degrees */
            for (k = 0; k < 4; ++k)
               {
               while (s[k].a <= -180.0)
                  s[k].a += 360.0;
               while (s[k].a > 180.0)
                  s[k].ang -= 360.0;
               }
            }

         if (ri_format || db_format)
            fprintf (dmb_file,"%.5e %+.5e %+.5e %+.5e %+.5e %+.5e %+.5e %+.5e %+.5e\n",freq,
               s[0].m,s[0].a,s[2].m,s[2].a,s[1].m,s[1].a,s[3].m,s[3].a);         
         else
            fprintf (dmb_file,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",freq,
               s[0].m,s[0].a,s[2].m,s[2].a,s[1].m,s[1].a,s[3].m,s[3].a);
         }
      else if (!strncmp (string,"!BIAS",5))
         {
         ++num_biases;
         i = 0;
         j = 0;
         last_freq = 0.0;
         fprintf (dmb_file,"%s",string);
         }
      else
         fprintf (dmb_file,"%s",string);
      }
   fclose (s_file);
   fclose (dmb_file);
   }

fclose (batch_file);

sprintf (string,"%s %s",DEL_COMMAND,batch_file_name);
system (string);

printf ("\n\n%d files (%d bias points) successfully embeded.\n",num_files,num_biases);

exit (0);
}
