#include <stdio.h>
#include <string.h>
#include <math.h>

#define DIEL_CONST     ((double) 6.6178)
#define LIGHT_SPEED    ((double) 2.9979e8) 

int main ()
{
double    line_len,start_f,stop_f,step_f,angle,freq;
char      file_base[80],fname1[85],fname2[85],string[256];
FILE      *file1,*file2;

printf ("Line length in microns?\n");
scanf ("%lf",&line_len);

printf ("Frequency range\nstart stop step (GHz)\n");
scanf ("%lf %lf %lf",&start_f,&stop_f,&step_f);

if ((start_f > stop_f) && (step_f > (double) 0.0))
   {
   printf ("** error ** start is greater than stop and step is positive\n");
   exit (1);
   }
else if ((start_f < stop_f) && (step_f < (double) 0.0))
   {
   printf ("** error ** start is less than stop and step is negative\n");
   exit (1);
   }
else if (step_f == (double) 0.0)
   {
   printf ("** error ** step must be non-zero\n");
   exit (1);
   }

printf ("Output file name?\n");
scanf ("%s",string);
sscanf (string,"%[^.]",file_base);

sprintf (fname1,"%s.fxa",file_base);
sprintf (fname2,"%s.fxb",file_base);

file1 = fopen (fname1,"w+");
file2 = fopen (fname2,"w+");

fprintf (file1,"! ideal port extension file, vp = %.4e m/s, line length = %.1f microns\n",LIGHT_SPEED/sqrt (DIEL_CONST),line_len);
fprintf (file2,"! ideal port extension file, vp = %.4e m/s, line length = %.1f microns\n",LIGHT_SPEED/sqrt (DIEL_CONST),line_len);
fprintf (file1,"# HZ S MA R 50\n");
fprintf (file2,"# HZ S MA R 50\n");
fprintf (file1,"! start = %.3f GHz, stop = %.3f GHz, step = %.3f GHz\n",start_f,stop_f,step_f);
fprintf (file2,"! start = %.3f GHz, stop = %.3f GHz, step = %.3f GHz\n",start_f,stop_f,step_f);

start_f *= (double) 1.0e9;
stop_f *= (double) 1.0e9;
step_f *= (double) 1.0e9;
line_len *= (double) 1.0e-6;

for (freq = start_f; freq < stop_f+((double) 1.0e3); freq += step_f)
   {
   angle = -((sqrt (DIEL_CONST))*((double) 360.0)*line_len*freq)/LIGHT_SPEED;
   if (angle < (double) -180.0)
      {
      angle += (double) 360.0;
      }
   
   fprintf (file1," %.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
                  freq,(double) 0.0,(double) 0.0,(double) 1.0,angle,
                  (double) 1.0,angle,(double) 0.0,(double) 0.0);

   fprintf (file2," %.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
                  freq,(double) 0.0,(double) 0.0,(double) 1.0,angle,
                  (double) 1.0,angle,(double) 0.0,(double) 0.0);

   }

fclose (file1);
fclose (file2);

}
