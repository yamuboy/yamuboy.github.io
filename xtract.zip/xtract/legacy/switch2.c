#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize3.h"
#include "jplot.h"

#define OK            0
#define ERR           -1

#define BOLTZ         1.3806226e-23
#define CHARGE        1.6021918e-19
#define STDTEMP       300.0

#define NUM_PARAMS    17
#define MAX_IV_PTS    1500
#define MAX_BIAS_PTS  500

#define SUPPRESS_GRAPHS   1
#define USE_POSTSCRIPT    2
#define USE_METAFILE      4

#define DCIV     1
#define FWDIV    2
#define VBRIV    3

/* -------- FUNCTION PROTOTYPES ---------- */

int get_starting_values (char *);
int fit_parasitics (char *);
int get_iv_data (char *, int);
int plot_data (char *, char *, char *);
void write_output_files (char *, char *, char *);

double *cgs_erf (double *);
double *gds_erf (double *);
double *vbr_erf (double *);

double switch_gds (double, double, double, double, double, double, double);
double switch_ids (double, double, double, double, double, double, double);
double switch_cgs (double, double, double, double, double, double, double, double);
double switch_breakdown (double, double, double, double, double, double);

static int diode_fit (double *, double *, int, double *, double *, double *);
static int diode_line_fit (double *, double *, int, double *, double *);

/* ---------- GLOBAL VARIABLES ----------- */

PARAM_STRUCT   params[NUM_PARAMS];
double         para[20];
double         cgsm[MAX_BIAS_PTS];
double         cgdm[MAX_BIAS_PTS];
double         vgsm[MAX_BIAS_PTS];
double         vgsiv[MAX_IV_PTS];
double         vdsiv[MAX_IV_PTS];
double         igsiv[MAX_IV_PTS];
double         idsiv[MAX_IV_PTS];
double         area,max_vds;
double         gate_knee_voltage,drain_voltage;
int            num_iv_pts,num_cap_pts;
int            option_flags;

/****************************************************************************/
/*                                  MAIN                                    */
/****************************************************************************/

main (int argc, char *argv[])
   {
   int         i,niter,flag,index;
   double      weights[2];
   double      is,n,rd;
   char        string[200];
   char        dscr_file[100],ch;
   char        start_file[100];
   char        end_file[100];
   char        model_file[100];
   char        iv_curve_file[100];
   char        fwd_iv_file[100];
   char        vbr_iv_file[100];
   OPT_STRUCT  opt;
   
   // check command line for a help request
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-h",2))
         {
         printf ("\n\nUSAGE: switch_fit [-s -h -in -da -fx]\n-------------------------------------------\n");
         printf ("  -s    Suppress graphics output.\n");
         printf ("  -h    Brings up this dialog.\n");
         printf ("  -iN   Integer N sets the number of optimizer iterations (overrides stdin).\n");      
         printf ("  -dA   Sets the graphics device, where A is one of \'X\' (default), \'P\', or \'M\',\n");      
         printf ("         which indicate X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("\n\n");
         return 0;
         }
      }     

   /************ Get Information ***************/
   
   printf ("DSCR file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",dscr_file);

   printf ("DC I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",iv_curve_file);

   printf ("Forward I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",vbr_iv_file);

   printf ("Start parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf",&max_vds);

   printf ("Maximum number of line searches?\n");
   fgets (string,199,stdin);
   sscanf (string,"%d",&niter);
   
   /************ Parse Command Line ***************/

   option_flags = 0;
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-s",2))
         option_flags |= SUPPRESS_GRAPHS;
      else if (!strncmp (argv[i],"-i",2))
         sscanf (argv[i],"-i%d",&niter);
      else if (!strncmp (argv[i],"-d",2))
         {
         sscanf (argv[i],"-d%c",&ch);
         if ((ch == 'p') || (ch == 'P'))
            option_flags |= USE_POSTSCRIPT;
         else if ((ch == 'm') || (ch == 'M'))
            option_flags |= USE_METAFILE;
         }
      }     
   
   /************** Initialization ******************/
   
   if (get_starting_values (start_file) < 0)
      {
      printf ("ERROR: in get_starting_values().\n");
      return -1;
      }
   
   if (fit_parasitics (dscr_file) < 0)
      {
      printf ("ERROR in fit_parasitics().\n");
      return -1;
      }

   initialize_optimizer (&opt, NUM_PARAMS, 1, weights, niter, &cgs_erf);
   weights[0] = 1.0;
   weights[1] = 1.0;

   /***************** Cgs fit *********************/
   
   printf ("Fitting gate capacitance.....\n");

   for (i = 0; i < 6; ++i)
      params[i].optimize = TRUE;

   opt.err_fraction = 1.0e-6;

   if (cg_optimize (opt,params) < 0)
      {
      printf ("ERROR in cg_optimize().\n");
      return -1;
      }

   /***************** I-V fit *********************/
 
   printf ("Fitting I-V curves.....\n");

   if ((num_iv_pts = get_iv_data (iv_curve_file,DCIV)) < 1)
      {
      printf ("ERROR in get_iv_data().\n");
      return -1;
      }

   for (i = 0; i < 6; ++i)
      params[i].optimize = FALSE;
   for (i = 7; i < 12; ++i)
      params[i].optimize = TRUE;

   opt.function = &gds_erf;
   opt.err_fraction = 1.0e-9;
   
   if (cg_optimize (opt,params) < 0)
      {
      printf ("ERROR in cg_optimize().\n");
      return -1;
      }

   for (i = 7; i < 12; ++i)
      params[i].optimize = FALSE;

   /**************** Forward Diode fit ******************/
      
   printf ("Fitting forward gate diode.....\n");

   if ((num_iv_pts = get_iv_data (fwd_iv_file,FWDIV)) < 3)
      {
      printf ("ERROR in get_iv_data().\n");
      return -1;
      }

   if (diode_fit (vgsiv,igsiv,num_iv_pts,&is,&n,&rd) < 0)
      {
      printf ("ERROR in diode_fit().\n");
      return -1;
      }

   para[10] = is;
   para[11] = n;
   para[12] = rd-para[1];

   /**************** Reverse Diode fit ******************/

   printf ("Fitting reverse gate diode.....\n");

   if ((num_iv_pts = get_iv_data (vbr_iv_file,VBRIV)) < 3)
      {
      printf ("ERROR in get_iv_data().\n");
      return -1;
      }

   index = 0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      if (vgsiv[i] >= vgsiv[num_iv_pts-1]*0.5)
         {
         index = i;
         break;
         }
      }

   if (diode_line_fit (&vgsiv[index],&igsiv[index],num_iv_pts-index,&is,&n) < 0)
      {
      printf ("ERROR in diode_line_fit().\n");
      return -1;
      }

   params[12].nom = is;
   params[12].min = is*0.9;
   params[12].max = is*1.1;
   params[13].nom = n;
   params[13].min = n*0.95;
   params[13].max = n*1.05;

   para[15] = 0.0;

   params[12].optimize = TRUE;
   params[13].optimize = TRUE;
   params[14].optimize = TRUE;
   params[15].optimize = TRUE;
   params[16].optimize = TRUE;

   opt.function = &vbr_erf;
   opt.err_fraction = 1.0e-9;
   
   if (cg_optimize (opt,params) < 0)
      {
      printf ("ERROR in cg_optimize().\n");
      return -1;
      }

   params[12].optimize = FALSE;
   params[13].optimize = FALSE;
   params[14].optimize = FALSE;
   params[15].optimize = FALSE;
   params[16].optimize = FALSE;

   /***************** Plot data ***********************/
   
   if (!(option_flags & SUPPRESS_GRAPHS))
      {
      printf ("Generating plots.....\n");
      plot_data (iv_curve_file,vbr_iv_file,fwd_iv_file);
      
      if (!(option_flags & USE_POSTSCRIPT))
         {
         option_flags |= USE_POSTSCRIPT;
         plot_data (iv_curve_file,vbr_iv_file,fwd_iv_file);
         } 
      }
   
   /************** Write output files *****************/
   
   write_output_files (end_file,model_file,iv_curve_file);

   printf ("Switch Model Fitting Complete!\n\n");
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int get_starting_values (char *fname)
   {
   FILE        *file1;
   char        string[201];
   int         i;
      
   file1 = fopen (fname,"r");
   if (!file1)
      {
      printf ("ERROR: Unable to open starting values file - %s\n",fname);
      return -1;
      }
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (!fgets (string,200,file1))
         {
         if (i < 12)
            {
            printf ("ERROR: Incomplete starting values file.\n");
            fclose (file1);
            return -1;
            }
         else
            {
            strcpy (params[12].name,"IBR1");
            strcpy (params[13].name,"NBR1");
            strcpy (params[14].name,"IBR2");
            strcpy (params[15].name,"NBR2");
            strcpy (params[16].name,"VBR");

            params[12].min = 1.0e-20;
            params[12].nom = 1.0e-15;
            params[12].max = 1.0e-12;
            params[12].tol = 0.0;

            params[13].min = 1.0;
            params[13].nom = 20.0;
            params[13].max = 50.0;
            params[13].tol = 0.0;

            params[14].min = 1.0e-12;
            params[14].nom = 1.0e-8;
            params[14].max = 1.0e-5;
            params[14].tol = 0.0;

            params[15].min = 0.2;
            params[15].nom = 2.0;
            params[15].max = 4.0;
            params[15].tol = 0.0;

            params[16].min = 5.0;
            params[16].nom = 20.0;
            params[16].max = 40.0;
            params[16].tol = 0.0;
            }
         break;
         }
      
      sscanf (string,"%lf%lf%lf%lf%s",&params[i].min,&params[i].nom,&params[i].max,
         &params[i].tol,params[i].name);
      params[i].units[0] = 0;
      params[i].optimize = FALSE;
      
      if (params[i].min > params[i].max)
         {
         printf ("WARNING in parameter \"%s\": MIN > MAX, range reset.\n",params[i].name);
         params[i].max = params[i].min;
         }

      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      else if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;

      if (params[i].tol < 0.0)
         params[i].tol = -params[i].tol;
      }
   fclose (file1);

   /* check parameter ranges for validity */
   
   
    
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int fit_parasitics (char *dscr_file)
   {
   FILE     *file1;
   int      i,j;
   char     string[301];
   double   vgs_min,tmp;
   double   rg,rd,rs,ri,vds,vgs,ids,igs;
   double   cgs,cgd,cds,ls,lg,ld;
   
   file1 = fopen (dscr_file,"r");
   if (!file1)
      {
      printf ("Unable to open dscr file - %s\n",dscr_file);
      return -1;
      }

   // find the minimum vgs value
   vgs_min = 0.0;
   while (fgets (string,300,file1))
      {
      if (sscanf (string,"%*f%*f%*f%*f%lf%*f%*f%lf",&vds,&vgs) == 2)
         {
         if ((vds == 0.0) && (vgs < vgs_min))
            vgs_min = vgs;
         }
      }
   rewind (file1);

   // read the dscr file
   i = 0;
   while (fgets (string,300,file1))
      {
      if (string[0] == '!')
         continue;

      if (sscanf (string,"%*f%lf%*f%*f%lf%lf%*f%lf%lf%lf%lf%lf%lf%lf%lf%lf%*f%*f%lf%lf%lf",
         &tmp,&vds,&ids,&vgs,&igs,&rg,&rs,&rd,&ri,&cgs,&cgd,&cds,&ls,&lg,&ld) == 15)
         {
         if ((vds == 0.0) && (vgs == vgs_min))
            {
            area    = tmp*1000.0;
            para[0] = rg;
            para[1] = rd;
            para[2] = rs;
            para[3] = ri;
            para[4] = cgs*1.0e-12;
            para[5] = cgd*1.0e-12;
            para[6] = ls*1.0e-12;
            para[7] = lg*1.0e-12;
            para[8] = ld*1.0e-12;
            para[9] = cds*1.0e-12;
            }

         if (vds == 0.0)
            {
            cgsm[i] = cgs*1.0e-12;
            cgdm[i] = cgd*1.0e-12;
            vgsm[i] = vgs;
            ++i;
            }
         }
      }
   fclose (file1);
   num_cap_pts = i;

   if (num_cap_pts < 3)
      {
      printf ("Not enough points for capacitance fitting.\n");
      return -1;
      }

   // sort the model summary data for ascending vgs
   for (i = 0; i < (num_cap_pts-1); ++i)
      {
      for (j = i+1; j < num_cap_pts; ++j)
         {
         if (vgsm[j] < vgsm[i])
            {
            tmp = vgsm[i];
            vgsm[i] = vgsm[j];
            vgsm[j] = tmp;
            
            tmp = cgsm[i];
            cgsm[i] = cgsm[j];
            cgsm[j] = tmp;
            
            tmp = cgdm[i];
            cgdm[i] = cgdm[j];
            cgdm[j] = tmp;            
            }
         }
      }
      
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int get_iv_data (char *fname, int mode)
   {
   FILE     *file1;
   char     string[201];
   int      i = 0;
   double   rs,rd,rg,ri,vds,vgs;
   double   lastv = 0.0;
   
   file1 = fopen (fname,"r");
   if (!file1)
      {
      printf ("Unable to open IV file - %s\n",fname);
      return -1;
      }
   
   rg = para[0];
   rd = para[1];
   rs = para[2];
   ri = para[3];

   // find the highest gate voltage for current knee fitting
   // and the smallest drain voltage > 0.0 for drain conductance
   if (mode == DCIV)
      {
      gate_knee_voltage = -10.0;
      drain_voltage = 1.0;
      while (fgets (string,200,file1))
         {
         if (sscanf (string,"%lf%*f%lf",&vds,&vgs) == 2)
            {
            if ((vgs > gate_knee_voltage) && (vds >= 1.5))
               gate_knee_voltage = vgs;

            if ((vds > 0.0) && (vds < drain_voltage))
               drain_voltage = vds;
            }
         }
      rewind (file1);
      }

   while (fgets (string,200,file1))
      {
      if (i >= MAX_IV_PTS)
         {
         printf ("WARNING: Max IV points exceeded.\n");
         break;
         }

      if (string[0] == '!')
         continue;

      if (sscanf (string,"%lf%lf%lf%lf",&vdsiv[i],&idsiv[i],&vgsiv[i],&igsiv[i]) == 4)
         {
         switch (mode)
            {
            case DCIV:   /* DC IV file */
               if (vdsiv[i] == drain_voltage)
                  {
                  idsiv[i] = idsiv[i]/vdsiv[i];
                  ++i;
                  }
               else if (vgsiv[i] == gate_knee_voltage)
                  if (vdsiv[i] <= max_vds)
                     ++i;
               break;
               
            case FWDIV:   /* forward IV file */
               if (vdsiv[i] != 0.0)
                  continue;
               else if (igsiv[i] < 1.0e-9*area)
                  continue;

               vgsiv[i] -= rs*(igsiv[i] + idsiv[i]);
               
               ++i;
               break;
               
            case VBRIV:   /* breakdown IV file */
               vgsiv[i] = (vdsiv[i] - idsiv[i]*rd) - (vgsiv[i] - igsiv[i]*rg);
               igsiv[i] = -igsiv[i];

               if (vgsiv[i] < lastv)
                  continue;

               lastv = vgsiv[i];
               ++i;
               break;
               
            default:
               break;
            }
         }
      }
   fclose (file1);
   
   return i;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int plot_data (char *iv_file, char *vbr_file, char *fwd_iv_file)
   {
   jPLOT_ITEM      *plot1;
   int             i,j,n,pdevice,flag;
   char            pname[100];
   double          p[NUM_PARAMS];
   double          x1data[MAX_IV_PTS];
   double          y1data[MAX_IV_PTS];
   double          y2data[MAX_IV_PTS];
   double          per_mm,vd;
   static char     *legend_t[] = {"Modeled","Measured"};
   static int      legend_l[] = {LT_SOLID,LT_DASHED};
   static int      legend_w[] = {1,1};
   static int      legend_c[] = {CLR_RED,CLR_BLUE};
   
   for (i = 0; i < NUM_PARAMS; ++i)
      p[i] = params[i].nom;
   
   per_mm = 1.0e3/area;
   
   pdevice = X_WINDOWS;
   pname[0] = 0;
   if (option_flags & USE_POSTSCRIPT)
      {
      pdevice = POSTSCRIPT;
      strcpy (pname,"switch.ps");
      }
   else if (option_flags & USE_METAFILE)
      {
      pdevice = METAFILE;
      strcpy (pname,"switch.wmf");
      }
   
   if (!open_graphics_device (pdevice,pname))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }
   
   plot1 = create_plot_item (SingleY,2.0,1.25,7.0,6.0);
      
   add_legend (2,9.0,7.75,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);

   /************ plot capacitance **************/
 
   for (i = 0; i < num_cap_pts; ++i)
      {
      x1data[i] = vgsm[i];
      y1data[i] = switch_cgs(vgsm[i],p[0],p[1],p[2],p[3],p[4],p[5],para[4])*per_mm*1.0e12;
      y2data[i] = cgsm[i]*per_mm*1.0e12;
      }

   attach_y1data (plot1,x1data,y1data,num_cap_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,num_cap_pts,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot1,"Vgs (volts)","Cgs (pF/mm)","","Gate Capacitance");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   detach_data (plot1);

   /************ plot IV curves ****************/
   
   n = get_iv_data (iv_file,DCIV);
   
   for (i = 0,j = 0; i < n; ++i)
      {
      if (vdsiv[i] == drain_voltage)
         {
         x1data[j] = vgsiv[i];
         y1data[j] = switch_gds(vgsiv[i],vgsiv[i]-vdsiv[i],p[7],p[8],p[9],p[10],p[11])*per_mm*1.0e3;
         y2data[j] = idsiv[i]*per_mm*1.0e3;
         ++j;
         }
      }
   
   attach_y1data (plot1,x1data,y1data,j,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,j,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot1,"Vgs (volts)","Gds (mS/mm)","","Drain Conductance");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   detach_data (plot1);

   for (i = 0,j = 0; i < n; ++i)
      {
      if (vdsiv[i] != drain_voltage)
         {
         x1data[j] = vdsiv[i];
         y1data[j] = switch_ids(vgsiv[i],vgsiv[i]-vdsiv[i],p[7],p[8],p[9],p[10],p[11])*per_mm*1.0e3;
         y2data[j] = idsiv[i]*per_mm*1.0e3;
         ++j;
         }
      }
   
   attach_y1data (plot1,x1data,y1data,j,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,j,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot1,"Vds (volts)","Ids (mA/mm)","","Knee Current Fit");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   detach_data (plot1);   

   /********* plot forward diode curve *************/
   
   n = get_iv_data (fwd_iv_file,FWDIV);
      
   for (i = 0; i < n; ++i)
      {
      vd = vgsiv[i] - igsiv[i]*(para[12]+para[1]);
      x1data[i] = vd;
      y1data[i] = para[10]*(exp (vd*CHARGE/(BOLTZ*STDTEMP*para[11])) - 1.0)*per_mm*1.0e3;
      y2data[i] = igsiv[i]*per_mm*1.0e3;
      }
   
   attach_y1data (plot1,x1data,y1data,n,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);

   set_axis_labels (plot1,"Vgs (volts)","Igs (mA/mm)","","Forward Diode Characteristic");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   

   detach_data (plot1);

   /********* plot reverse diode curve *************/
   
   n = get_iv_data (vbr_file,VBRIV);

   for (i = 0; i < n; ++i)
      {
      x1data[i] = vgsiv[i];
      y1data[i] = switch_breakdown (vgsiv[i],p[12],p[13],p[14],p[15],p[16])*per_mm*1.0e3;
      y2data[i] = igsiv[i]*per_mm*1.0e3;
      }
   
   attach_y1data (plot1,x1data,y1data,n,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);

   set_axis_scaling (plot1,LogY1);

   set_axis_labels (plot1,"Vdg (volts)","Idg (mA/mm)","","Reverse Diode Characteristic");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   close_graphics_device ();
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

void write_output_files (char *end_file, char *mod_file, char *head_file)
   {
   FILE       *infile,*outfile;
   int        i;
   char       string[201];

   outfile = fopen (mod_file,"w+");
   infile  = fopen (head_file,"r");

   // write the header
   i = 0;
   while (++i < 31)
      {
      if (!fgets (string,200,infile))
         break;

      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         fprintf (outfile,"%s",string);
         break;
         }
      
      fprintf (outfile,"%s",string);
      }
   if (fgets (string,200,infile))
      fprintf (outfile,"%s",string);
   fclose (infile);

   // write the model parameters
   fprintf (outfile,"!\n");
   fprintf (outfile,"model  =   1\n");
   fprintf (outfile,"area   =  %11.4e\n",area);
   fprintf (outfile,"cg     =  %11.4e\n",0.0);
   fprintf (outfile,"cd     =  %11.4e\n",0.0);
   fprintf (outfile,"cs     =  %11.4e\n",0.0);
   fprintf (outfile,"cds    =  %11.4e\n",para[9]);
   fprintf (outfile,"lg     =  %11.4e\n",para[7]);
   fprintf (outfile,"ld     =  %11.4e\n",para[8]);
   fprintf (outfile,"ls     =  %11.4e\n",para[6]);
   fprintf (outfile,"rg     =  %11.4e\n",para[0]);
   fprintf (outfile,"c0     =  %11.4e\n",0.0);
   fprintf (outfile,"c1     =  %11.4e\n",0.0);
   fprintf (outfile,"c2     =  %11.4e\n",0.0);
   fprintf (outfile,"c3     =  %11.4e\n",0.0);
   fprintf (outfile,"c4     =  %11.4e\n",0.0);
   fprintf (outfile,"c5     =  %11.4e\n",0.0);
   fprintf (outfile,"c6     =  %11.4e\n",params[0].nom*1.0e-12);
   fprintf (outfile,"c7     =  %11.4e\n",params[1].nom);
   fprintf (outfile,"c8     =  %11.4e\n",params[2].nom);
   fprintf (outfile,"c9     =  %11.4e\n",params[3].nom*1.0e-12);
   fprintf (outfile,"c10    =  %11.4e\n",params[4].nom);
   fprintf (outfile,"c11    =  %11.4e\n",params[5].nom);
   fprintf (outfile,"cgs    =  %11.4e\n",para[4]);
   fprintf (outfile,"cgd    =  %11.4e\n",para[5]);
   fprintf (outfile,"i0     =  %11.4e\n",para[10]);
   fprintf (outfile,"n0     =  %11.4e\n",para[11]);
   fprintf (outfile,"r0     =  %11.4e\n",para[12]);
   fprintf (outfile,"i1     =  %11.4e\n",params[12].nom);
   fprintf (outfile,"n1     =  %11.4e\n",params[13].nom);
   fprintf (outfile,"r1     =  %11.4e\n",para[15]);
   fprintf (outfile,"ids0   =  %11.4e\n",params[7].nom);
   fprintf (outfile,"ids1   =  %11.4e\n",params[8].nom);
   fprintf (outfile,"ids2   =  %11.4e\n",params[9].nom);
   fprintf (outfile,"ids3   =  %11.4e\n",params[10].nom);
   fprintf (outfile,"ids4   =  %11.4e\n",params[11].nom);
   fprintf (outfile,"ibr    =  %11.4e\n",params[14].nom);
   fprintf (outfile,"nbr    =  %11.4e\n",params[15].nom);
   fprintf (outfile,"vbr    =  %11.4e\n",params[16].nom);
   fprintf (outfile,"!\n");
   fclose (outfile);
   
   // write the finishing values file  
   outfile = fopen (end_file,"w+");
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (outfile,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (outfile);
   }

/****************************************************************************/
/****************************************************************************/
/*                       OPTIMIZATION ERROR FUNCTIONS                       */
/****************************************************************************/
/****************************************************************************/

double *gds_erf (double *p)
   {
   int           i;
   double        ids;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      if (vdsiv[i] == drain_voltage)
         {
         ids = switch_gds (vgsiv[i],vgsiv[i]-vdsiv[i],p[7],p[8],p[9],p[10],p[11]);
         error += 1.0e6*(ids - idsiv[i])*(ids - idsiv[i]);
         }
      else
         {
         ids = switch_ids (vgsiv[i],vgsiv[i]-vdsiv[i],p[7],p[8],p[9],p[10],p[11]);
         error += 1.0e5*(ids - idsiv[i])*(ids - idsiv[i]);
         }
      }
   
   error /= ((double) num_iv_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *cgs_erf (double *p)
   {
   int           i;
   double        cgs;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_cap_pts; ++i)
      {
      cgs = switch_cgs (vgsm[i],p[0],p[1],p[2],p[3],p[4],p[5],para[4]);
      error += (cgs - cgsm[i])*(cgs - cgsm[i])*1.0e24;
      }
      
   error /= ((double) num_cap_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *vbr_erf (double *p)
   {
   int i;
   double ibr,logval;
   static double error;

   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      ibr = switch_breakdown (vgsiv[i],p[12],p[13],p[14],p[15],p[16]);
      logval = log10 (fabs(ibr/igsiv[i]));
      error += logval*logval*1.0e6;
      }

   error /= ((double) num_iv_pts);

   return &error;
   }

/****************************************************************************/
/****************************************************************************/
/*                         SWITCH MODEL FUNCTIONS                           */
/****************************************************************************/
/****************************************************************************/

double switch_cgs (double v, double c0, double c1, double c2, double c3, double c4,
                   double c5, double cgs0)
   {
   double arg1 = c1*(v - c2);
   double arg2 = c4*c4*(v - c5);
   
   return (c0*0.5*(tanh(arg1) + 1.0) + c3*exp(arg2))*1.0e-12 + cgs0;
   }

/*****************************************************************************/
/*****************************************************************************/

double switch_gds (double vgs, double vgd, double a, double b, double c, double d, double e)
   {
   double arg1 = b*(vgs - c - sqrt((vgs-c)*(vgs-c) + d*d));
   double arg2 = b*(vgd - c - sqrt((vgd-c)*(vgd-c) + d*d));   
   double gds1 = a*exp(arg1);
   double gds2 = a*exp(arg2);
   
   return b*gds2*(1.0 - (vgd-c)/sqrt((vgd-c)*(vgd-c) + d*d)) * (1.0 + tanh(e*(vgd-vgs)))/(2.0*e) +
      0.5*gds1*(1.0 - tanh(e*(vgs-vgd))*tanh(e*(vgs-vgd))) +
      0.5*gds2*(1.0 - tanh(e*(vgd-vgs))*tanh(e*(vgd-vgs)));
   }

/*****************************************************************************/
/*****************************************************************************/

double switch_ids (double vgs, double vgd, double a, double b, double c, double d, double e)
   {
   double arg1 = b*(vgs - c - sqrt((vgs-c)*(vgs-c) + d*d));
   double arg2 = b*(vgd - c - sqrt((vgd-c)*(vgd-c) + d*d));
   double gds1 = a*exp(arg1);
   double gds2 = a*exp(arg2);
   
   return (gds1*(1.0 + tanh(e*(vgs-vgd))) - gds2*(1.0 + tanh(e*(vgd-vgs))))/(2.0*e);
   }

/*****************************************************************************/
/*****************************************************************************/

double switch_breakdown (double v, double is, double n, double ip, double np, double vp)
   {
   return is*(exp (v*CHARGE/(BOLTZ*STDTEMP*n)) - 1.0) + ip*pow(v/vp,np);
   }

/****************************************************************************/
/****************************************************************************/
/*                                UTILITIES                                 */
/****************************************************************************/
/****************************************************************************/

static int a_x_b (double *a, double *x, double *b, int n)
   {
   double   y[50];
   double   z[50][50];
   double   tempd;
   double   tempd2;
   double   max;
   int      pointer[50];
   int      tempi;
   int      i,j,k;
   int      col,row;
   
   for (i = 0; i < n; ++i)
      {
      y[i] = b[i];
      pointer[i] = i;
      for (j = 0; j < n; ++j)
         z[i][j] = a[i*n+j];
      }
   
   /* invert the matrix */
   for (k = 0; k < n-1; ++k)
      {
      /* find max */
      max = 0.0;
      for (i = k; i < n; ++i)
         {
         for (j = k; j < n; ++j)
            {
            if (fabs (z[i][j]) > max)
               {
               row = i;
               col = j;
               max = fabs (z[i][j]);
               }
            }
         }
      
      /* rotate rows */
      if (row != k)
         {
         for (j = 0; j < n; ++j)
            {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
            }
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
         }
      
      /* rotate columns */ 
      if (col != k)
         {
         for (i = 0; i < n; ++i)
            {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
            }
         tempi = pointer[k];
         pointer[k] = pointer[col];
         pointer[col] = tempi;
         }
      
      /* gaussian elimination */
      tempd = z[k][k];
      for (i = k+1; i < n; ++i)
         {
         tempd2 = z[i][k]/tempd;
         y[i] -= tempd2*y[k];
         for (j = k; j < n; ++j)
            {
            z[i][j] -= tempd2*z[k][j];
            }
         }
      }  
   
   if (fabs (z[n-1][n-1]) < 1.0e-24)
      return -1;
   
   /* back substitution */
   x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
   for (k = n-2; k > -1; --k)
      {
      tempd = y[k];
      for (i = n-1; i > k; --i)
         tempd -= z[k][i]*x[pointer[i]];
      
      x[pointer[k]] = tempd/z[k][k];
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_fit (double *vd, double *id, int k, double *is, double *n, double *rd)
   {
   double   a1[3][MAX_IV_PTS];
   double   a2[MAX_IV_PTS][3];
   double   b1[MAX_IV_PTS];
   double   a[3][3];
   double   b[3];
   double   x[3];
   double   sum;
   int      i,j;
   int      npts;

   j = 0;
   for (i = 0; i < k; ++i)
      {
      if (vd[i] <= 0.0)
         continue;
      
      a2[j][0] = log (id[i]);
      a2[j][1] = -1.0;
      a2[j][2] = id[i];
      a1[0][j] = a2[j][0];
      a1[1][j] = a2[j][1];
      a1[2][j] = a2[j][2];
      b1[j] = vd[i];
      ++j;
      }
   
   if (j < 3)
      {
      fprintf (stderr,"Not enough points for diode fit.\n");
      return -1;
      }
   
   npts = j;
   
   for (i = 0; i < 3; ++i)
      {
      for (j = 0; j < 3; ++j)
         {
         sum = 0.0;
         for (k = 0; k < npts; ++k)
            sum += a1[i][k]*a2[k][j];
         
         a[i][j] = sum;
         }
      }
   
   for (i = 0; i < 3; ++i)
      {
      sum = 0.0;
      for (j = 0; j < npts; ++j)
         sum += a1[i][j]*b1[j];
      
      b[i] = sum;
      }
   
   if (a_x_b ((double *)a,x,b,3) < 0)
      {
      fprintf (stderr,"Singular matrix in diode fit.\n");
      return -1;
      }
   
   *n = x[0]*CHARGE/(BOLTZ*STDTEMP);
   *is = exp (x[1]/x[0]);
   *rd = x[2];
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2)
   {
   int i;
   double xsum = 0.0;
   double ysum = 0.0;
   double xxsum = 0.0;
   double yysum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 1)
      {
      *m = 0.0;
      *b = 0.0;
      *r2 = 0.0;
      return;
      }

   for (i = 0; i < n; ++i)
      {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
      }

   *m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
   *b  = (xxsum*ysum - xysum*xsum) / (xxsum*((double) n) - xsum*xsum);
   // *r2 = xysum*xysum / (xxsum*yysum);

   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] + (*b) - y[i])*((*m)*x[i] + (*b) - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_line_fit (double *vd, double *id, int k, double *is, double *n)
   {
   double log_id[MAX_IV_PTS];
   double m,b,r;
   int i;
   
   if (k < 2)
      {
      fprintf (stderr,"Not enough points for diode fit.\n");
      return -1;
      }
   
   for (i = 0; i < k; ++i)
      log_id[i] = log (id[i]);
      
   linefit_mxb (vd, log_id, k, &m, &b, &r);
   
   *n = CHARGE/(BOLTZ*STDTEMP*m);
   *is = exp (b);
   
   return 0;
   }
