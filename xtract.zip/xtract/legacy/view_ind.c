#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "jplot.h"

#define MAX_PTS   500

struct BIAS
   {
   double vds,ids,vgs,igs;
   int mode;
   };

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts);
double satan2 (double y, double x);

/*********************************************************************************************/
/*********************************************************************************************/

main (int argc, char *argv[])
{
FILE  *files,*modfile,*measfile;
char  string[256],tmp_file_name[100];
char  modname[256],measname[256];
char  extension[40],model_files[256];
char pname[100];
time_t tbuf;
jPLOT_ITEM *s11p,*s12p,*s21p,*s22p;
jPLOT_ATTRIBS attribs1;
jHANDLE legend1,bias_line;
int mod_pts,meas_pts,i;
int pdevice = X_WINDOWS;
double modfreq[MAX_PTS],measfreq[MAX_PTS];
double mod11m[MAX_PTS],mod11a[MAX_PTS];
double mod12m[MAX_PTS],mod12a[MAX_PTS];
double mod21m[MAX_PTS],mod21a[MAX_PTS];
double mod22m[MAX_PTS],mod22a[MAX_PTS];
double meas11m[MAX_PTS],meas11a[MAX_PTS];
double meas12m[MAX_PTS],meas12a[MAX_PTS];
double meas21m[MAX_PTS],meas21a[MAX_PTS];
double meas22m[MAX_PTS],meas22a[MAX_PTS];
struct BIAS bias;
static char *legend_t[] = {"Modeled Magnitude","Measured Magnitude","Modeled Phase","Measured Phase"};
static int  legend_l[] = {LT_SOLID,LT_DASHED,LT_SOLID,LT_DASHED};
static int  legend_w[] = {1,1,1,1};
static int  legend_c[] = {CLR_RED,CLR_BLUE,CLR_ORANGE,CLR_GREEN};

// parse the command line
for (i = 1; i < argc; ++i)
   {
   if (!strcmp (argv[i],"-ps"))
      pdevice = POSTSCRIPT;
   else if (!strcmp (argv[i],"-meta"))
      pdevice = METAFILE;
   }
   
pname[0] = 0;

printf ("Model files to plot?\n");
fgets (model_files,255,stdin);
model_files[strlen(model_files)-1] = 0;

printf ("Measured data extension?\n");
fgets (string,255,stdin);
sscanf (string,"%39s",extension);

if (pdevice != X_WINDOWS)
   {
   printf ("Plot file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",pname);
   }

sprintf (tmp_file_name,"tmp.%d",time(&tbuf));
sprintf (string,"rm -f %s",tmp_file_name);
system (string);
sprintf (string,"ls -1 %s > %s",model_files,tmp_file_name);
system (string);

files = fopen (tmp_file_name,"r");
if (!files)
   {
   printf ("** error ** cannot open batch file\n");
   return -1;
   }

if (!open_graphics_device (pdevice,pname))
   {
   printf ("Failed to open the graphics device.\n");
   fclose (files);
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   return -1;
   }

s11p = create_plot_item (DoubleY,1.25,4.70,3.0,2.5);
s12p = create_plot_item (DoubleY,6.75,4.70,3.0,2.5);
s21p = create_plot_item (DoubleY,1.25,1.00,3.0,2.5);
s22p = create_plot_item (DoubleY,6.75,1.00,3.0,2.5);

set_axis_labels (s11p,"Frequency (GHz)","S11 Magnitude","S11 Phase","S11");
set_axis_labels (s12p,"Frequency (GHz)","S12 Magnitude","S12 Phase","S12");
set_axis_labels (s21p,"Frequency (GHz)","S21 Magnitude","S21 Phase","S21");
set_axis_labels (s22p,"Frequency (GHz)","S22 Magnitude","S22 Phase","S22");

attribs1.xlabel_offset = 0.3;
attribs1.ylabel_offset = 0.55;
attribs1.title_offset  = 0.3;

set_plot_item_attributes (s11p,&attribs1,JPA_LABELOFFSETS);
set_plot_item_attributes (s12p,&attribs1,JPA_LABELOFFSETS);
set_plot_item_attributes (s21p,&attribs1,JPA_LABELOFFSETS);
set_plot_item_attributes (s22p,&attribs1,JPA_LABELOFFSETS);

legend1 = add_legend (4,4.55,8.1,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);
   
while (fgets (modname,255,files))
   {
   modname[strlen(modname)-1] = 0;
   sscanf (modname,"%[^.]",measname);
   strcat (measname,extension);

   measfile = fopen (measname,"r");
   if (!measfile)
      continue;
   
   modfile = fopen (modname,"r");
   if (!modfile)
      {
      fclose (measfile);   
      continue;
      }
   
      mod_pts = read_s_params (modfile,modfreq,mod11m,mod11a,mod12m,mod12a,mod21m,mod21a,mod22m,mod22a,&bias,MAX_PTS);
      meas_pts = read_s_params (measfile,measfreq,meas11m,meas11a,meas12m,meas12a,meas21m,meas21a,meas22m,meas22a,&bias,MAX_PTS);
      
      if ((mod_pts < 1) && (meas_pts < 1))
         {
         fclose (modfile);
         fclose (measfile);
         continue;
         }
      
      sprintf (string, "File: %s", modname);
      
      bias_line = add_text (string,5.5,4.15,FNT_COURIER,12,0.0,CENTER_JUSTIFY,CLR_BLACK,0);
      
      attach_y1data (s11p,modfreq,mod11m,mod_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s11p,measfreq,meas11m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s11p,modfreq,mod11a,mod_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s11p,measfreq,meas11a,meas_pts,LT_DASHED,1,CLR_GREEN);
      
      attach_y1data (s12p,modfreq,mod12m,mod_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s12p,measfreq,meas12m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s12p,modfreq,mod12a,mod_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s12p,measfreq,meas12a,meas_pts,LT_DASHED,1,CLR_GREEN);      

      attach_y1data (s21p,modfreq,mod21m,mod_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s21p,measfreq,meas21m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s21p,modfreq,mod21a,mod_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s21p,measfreq,meas21a,meas_pts,LT_DASHED,1,CLR_GREEN);      

      attach_y1data (s22p,modfreq,mod22m,mod_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s22p,measfreq,meas22m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s22p,modfreq,mod22a,mod_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s22p,measfreq,meas22a,meas_pts,LT_DASHED,1,CLR_GREEN);
      
      draw_page ();

      detach_data (s11p);
      detach_data (s12p);
      detach_data (s21p);
      detach_data (s22p);
      remove_user_item (bias_line);
   
   fclose (modfile);
   fclose (measfile);
   }

fclose (files);

close_graphics_device ();

sprintf (string,"rm -f %s",tmp_file_name);
system (string);

return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts)
   {
   char string[256],tmp[6];
   int i = 0;
   int ri_mode = 0;
   double fscale = 1.0e-9;
   double rad_to_deg = 180.0/acos(-1.0);
   double dtmp;
   
   bias->mode = 0;
   while (fgets(string,255,infile))
      {
      if (i >= max_pts)
         break;
         
      if (!strncmp (string,"!BIAS",5))
         {
         if (sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",&bias->vds,&bias->ids,
            &bias->vgs,&bias->igs) == 4)
            bias->mode = 1;
         else if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&bias->vds,&bias->ids,
            &bias->vgs,&bias->igs) == 4)
            bias->mode = 2;
         else
            bias->mode = 0;
         }
      else if (string[0] == '!')
         continue;
      
      if (sscanf(string,"# %5s %5s",tmp,tmp) == 2)
         {
         if (strstr(string,"RI") || strstr(string,"ri"))
            ri_mode = 1;
         
         if (strstr(string,"GHZ") || strstr(string,"ghz") || strstr(string,"GHz"))
            fscale = 1.0;
         else if (strstr(string,"MHZ") || strstr(string,"mhz") || strstr(string,"MHz"))
            fscale = 1.0e-3;
         else if (strstr(string,"KHZ") || strstr(string,"khz") || strstr(string,"kHz"))
            fscale = 1.0e-6;
         }
      
      if (sscanf(string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq[i],&s11m[i],&s11a[i],&s21m[i],&s21a[i],&s12m[i],&s12a[i],
         &s22m[i],&s22a[i]) == 9)
         {
         freq[i] *= fscale;
         
         if (ri_mode)
            {
            dtmp = s11m[i];
            s11m[i] = sqrt (s11m[i]*s11m[i] + s11a[i]*s11a[i]);
            s11a[i] = rad_to_deg*satan2 (s11a[i],dtmp);
            
            dtmp = s12m[i];
            s12m[i] = sqrt (s12m[i]*s12m[i] + s12a[i]*s12a[i]);
            s12a[i] = rad_to_deg*satan2 (s12a[i],dtmp);            

            dtmp = s21m[i];
            s21m[i] = sqrt (s21m[i]*s21m[i] + s21a[i]*s21a[i]);
            s21a[i] = rad_to_deg*satan2 (s21a[i],dtmp); 
                       
            dtmp = s22m[i];
            s22m[i] = sqrt (s22m[i]*s22m[i] + s22a[i]*s22a[i]);
            s22a[i] = rad_to_deg*satan2 (s22a[i],dtmp);
            }
         
         ++i;
         }
      }
   
   return i;
   }
         
/*********************************************************************************************/
/*********************************************************************************************/

double satan2 (double y, double x)
   {
   if ((x == 0.0) && (y == 0.0))
      return 0.0;
   else
      return atan2(y,x);
   }         
      
      
            
         
         
