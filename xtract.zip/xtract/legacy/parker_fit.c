#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jmbplot.h"
#include "optimize.h"

#define NUM_PARAMS      (44)
#define MAX_IV_PTS      (1000)
#define MAX_BIAS_PTS    (500)

#define MAX_FWD_IGS     ((double) 5.0e-8)

#define TRUE            (1)
#define FALSE           (0)
#define ERR             (-1)
#define OK              (0)


/* -------- FUNCTION PROTOTYPES ---------- */

int fit_parasitics ();
int get_starting_values ();
int get_iv_curves ();
int plot_data ();

double *parker_opt ();
double ids_function ();
double cgs_cgd_function ();
double gm_gds_function ();
double parker_ids ();
double parker_ac_ids ();
void parker_capacitance ();

double bubble_average ();
int diode_fit ();
int a_x_b ();
void find_min_max ();

/* ------------ EXTERNAL FUNCTIONS ------------- */

extern int jmbplot_open_device ();
extern int jmbplot_draw_plot ();
extern void jmbplot_close_device ();
extern int cg_optimize ();

/* ------------- GLOBAL VARIABLES -------------- */

PARAM_STRUCT        params[NUM_PARAMS];
OPT_STRUCT          opt = {0,0,NULL,0L,0,parker_opt};
double              vgsi[MAX_IV_PTS];
double              vdsi[MAX_IV_PTS];
double              igsi[MAX_IV_PTS];
double              idsi[MAX_IV_PTS];
double              vds_c[MAX_BIAS_PTS];
double              vgs_c[MAX_BIAS_PTS];
double              cgsm[MAX_BIAS_PTS];
double              cgdm[MAX_BIAS_PTS];
double              gmm[MAX_BIAS_PTS];
double              gdsm[MAX_BIAS_PTS];
double              lp_gate;
double              lp_drain;
double              eff_gl;
double              eff_dl;
double              maximum_vds;
int                 num_cap_iv_pts;
int                 num_iv_pts;
int                 mode_flag;

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/
main (argc,argv)
int   argc;
char  *argv[];

{
int         i,n;
FILE        *out_file;
FILE        *in_file;
double      weights[2];
char        string[1024];
char        model_summary_file[100];
char        start_file[100];
char        end_file[100];
char        model_file[100];
char        yfit_file[100];
char        iv_curve_file[100];
char        fwd_iv_file[100];
char        vbr_iv_file[100];
char        junk[100];

fflush (stdin);
printf ("Y-fit start file name?\n");
scanf ("%s%[^\n]",yfit_file,junk);
printf ("Effective Gate and Drain Lengths? (um)\n");
scanf ("%lf %lf%[^\n]",&eff_gl,&eff_dl,junk);
printf ("Model summary file name?\n");
scanf ("%s%[^\n]",model_summary_file,junk);
printf ("DC IV data file name?\n");
scanf ("%s%[^\n]",iv_curve_file,junk);
printf ("Maximum drain voltage for IV fit?\n");
scanf ("%lf%[^\n]",&maximum_vds,junk);
printf ("Forward IV data file name?\n");
scanf ("%s%[^\n]",fwd_iv_file,junk);
printf ("Breakdown IV data file name?\n");
scanf ("%s%[^\n]",vbr_iv_file,junk);
printf ("Start parameters file name?\n");
scanf ("%s%[^\n]",start_file,junk);
printf ("Finish parameters file name?\n");
scanf ("%s%[^\n]",end_file,junk);
printf ("Output model file name?\n");
scanf ("%s%[^\n]",model_file,junk);
/* model number was here - not used */
printf ("Maximum number of line searches?\n");
scanf ("%d%[^\n]",&opt.max_iterations,junk);
/* drain voltage start stop step tick */
/* drain current start stop step tick */
/* cgs start stop step tick */
/* gm start stop step tick */
/* device */

if (get_starting_values (start_file) == ERR)
   {
   exit(-1);
   }

/************************************************************************/

printf ("\n\nFITTING PARASITICS.....\n");
if (fit_parasitics (model_summary_file,yfit_file) == ERR)
   {
   exit (-1);
   }
printf ("Done.\n");

/************************************************************************/

printf ("FITTING IV-CURVES AND CAPACITANCE.....\n");
num_iv_pts = get_iv_curves (iv_curve_file,0);
if (num_iv_pts < 0)
   {
   exit (-1);
   }
else if (num_iv_pts == 0)
   {
   printf ("No data found in IV file - %s\n",iv_curve_file);
   exit (-1);
   }

params[0].optimize = FALSE;
for (i = 1; i < 21; ++i)
   {
   params[i].optimize = TRUE;
   }
for (i = 21; i < NUM_PARAMS; ++i)
   {
   params[i].optimize = FALSE;
   }

/* call gradient optimizer */
opt.num_of_params = NUM_PARAMS;
opt.num_of_criteria = 2;
opt.weights = &weights[0];
opt.flags = OPT_VERBOSE;
weights[0] = (double) 1.0;
weights[1] = (double) 1.0;
mode_flag = 0;

if (cg_optimize (opt,params,NUM_PARAMS,string) < 0)
   {
   printf ("Conjugate Gradient Optimizer returned the following error:\n");
   printf ("%s\n",string);
   exit (-1);
   }

printf ("Done.\n");

/************************************************************************/

printf ("FITTING GM AND GDS.....\n");

for (i = 1; i < 21; ++i)
   {
   params[i].optimize = FALSE;
   }
for (i = 21; i < 27; ++i)
   {
   params[i].optimize = TRUE;
   }

opt.num_of_criteria = 1;
weights[0] = (double) 1.0;
mode_flag = 3;

if (cg_optimize (opt,params,NUM_PARAMS,string) < 0)
   {
   printf ("Conjugate Gradient Optimizer returned the following error:\n");
   printf ("%s\n",string);
   exit (-1);
   }

printf ("Done.\n");

/************************************************************************/

printf ("FITTING IS AND N.....\n");
n = get_iv_curves (fwd_iv_file,1);
if (n < 1)
   {
   printf ("No data, skipping.....\n");
   params[40].nom = (double) 2.0e-14;
   params[41].nom = (double) 1.0;
   }
else
   {
   if (diode_fit (vgsi,igsi,n,params[0].nom,&params[40].nom,&params[41].nom) == ERR)
      {
      printf ("Error in diode_fit(), setting Is and n to defaults.\n");
      params[40].nom = (double) 2.0e-14;
      params[41].nom = (double) 1.0;
      }
   }
params[40].nom *= ((double) 0.5)/params[0].nom;
printf ("Done.\n");

/************************************************************************/

printf ("FITTING VBD AND IBD.....\n");
n = get_iv_curves (vbr_iv_file,2);
if (n < 1)
   {
   printf ("No data, skipping.....\n");
   params[42].nom = (double) 1.0e-14;
   params[43].nom = (double) 99.0;
   }
else
   {
   if (diode_fit (vgsi,igsi,n,params[0].nom/((double) 10.0),&params[42].nom,&params[43].nom) == ERR)
      {
      printf ("Error in vbr_fit(), setting Ibd and Vbd to defaults.\n");
      params[42].nom = (double) 1.0e-14;
      params[43].nom = (double) 99.0;
      }
   }
params[42].nom *= ((double) 1.0)/params[0].nom;
params[43].nom *= ((double) 25.8410291e-3);
printf ("Done.\n");

/************************************************************************/

printf ("PLOTTING DATA.....\n");

/* reload DC IV curves */

num_iv_pts = get_iv_curves (iv_curve_file,0); 

if (plot_data () == ERR)
   {
   printf ("ERROR in plot_data(), continuing...\n");
   }

/************************************************************************/

printf ("WRITING DATA TO FILE.....\n");

for (i = 40; i < NUM_PARAMS; ++i)
   {
   params[i].min = params[i].max = params[i].nom;
   }

out_file = fopen (end_file,"w+");
for (i = 0; i < NUM_PARAMS; ++i)
   {
   fprintf (out_file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
                                                        params[i].tol,params[i].name);
   }
fclose (out_file);

out_file = fopen (model_file,"w+");
in_file = fopen (iv_curve_file,"r");

i = 0;
while (1)
   {
   fgets (string,201,in_file);
   if (!strncmp (string,"!Vbr (.1mA) ",12))
      {
      fprintf (out_file,"%s",string);
      break;
      }
   else if (++i > 30)
      {
      break;
      }
   fprintf (out_file,"%s",string);
   }
fgets (string,201,in_file);
fclose (in_file);
fprintf (out_file,"%s",string);
fprintf (out_file,"!\n");
fprintf (out_file,"model  =  1\n");

fprintf (out_file,"%s =  %.4e\n",params[0].name,((double) 1.0));
for (i = 1; i < NUM_PARAMS; ++i)
   {
   fprintf (out_file,"%s =  %.4e\n",params[i].name,params[i].nom);
   }

fprintf (out_file,"taud   =  1.0000e-04\n");
fprintf (out_file,"taug   =  1.0000e-06\n");
fprintf (out_file,"tnom   =  2.7000e+01\n");
fprintf (out_file,"!\n");
fprintf (out_file,"af     =  1.0000e+00\n");
fprintf (out_file,"kf     =  0.0000e+00\n");
fprintf (out_file,"lpg    =  %.4e\n",lp_gate);
fprintf (out_file,"lpd    =  %.4e\n",lp_drain);
fprintf (out_file,"egl    =  %.4e\n",eff_gl);
fprintf (out_file,"edl    =  %.4e\n",eff_dl);
fprintf (out_file,"cgsp   =  0.0000e+00\n");
fprintf (out_file,"cgdp   =  0.0000e+00\n");
fprintf (out_file,"cdsp   =  0.0000e+00\n");
fprintf (out_file,"!\n");

fclose (out_file);

printf ("Parker Fit Complete!\n");
return (0);
}

/*                                                                          */
/* ----------- plot_data() ------------------------------------------------ */
/*                                                                          */

int plot_data ()

{
double          p_list[NUM_PARAMS];
JMBPLOT_ITEM    pitem[2];
JMBPLOT_DATA    pdata1[2];
JMBPLOT_DATA    pdata2[2];
JMBPLOT_SCALE   scales1;
JMBPLOT_SCALE   scales2;
int             i;
float           xdata[MAX_IV_PTS];
float           y1data[MAX_IV_PTS];
float           y2data[MAX_IV_PTS];
float           y3data[MAX_IV_PTS];
float           y4data[MAX_IV_PTS];
float           min,max;
double          per_mm;
double          cgs,cgd;
double          del,gm,gds,ids1,ids2,p_ave,vgd;
char            string[1024];

pitem[0].type = singleY;
pitem[0].font = 0;
pitem[0].scaling = manualX | manualY1 | manualY2;
pitem[0].scales = &scales1;
pitem[0].data = pdata1;
pitem[0].num_data_items = 2;
pitem[0].flags = DRAW_XGRID | DRAW_YGRID;
pitem[1].type = singleY;
pitem[1].font = 0;
pitem[1].scaling = manualX | manualY1 | manualY2;
pitem[1].scales = &scales2;
pitem[1].data = pdata2;
pitem[1].num_data_items = 2;
pitem[1].flags = DRAW_XGRID | DRAW_YGRID;


pdata1[0].x1_data = xdata;
pdata1[1].x1_data = xdata;
pdata2[0].x1_data = xdata;
pdata2[1].x1_data = xdata;

pdata1[0].y1_data = y1data;
pdata1[1].y1_data = y2data;
pdata2[0].y1_data = y3data;
pdata2[1].y1_data = y4data;

pdata1[0].curve1_linetype = LT_DASHED;
pdata1[0].curve1_linewidth = 1;
pdata1[1].curve1_linetype = LT_SOLID;
pdata1[1].curve1_linewidth = 1;

pdata2[0].curve1_linetype = LT_DASHED;
pdata2[0].curve1_linewidth = 1;
pdata2[1].curve1_linetype = LT_SOLID;
pdata2[1].curve1_linewidth = 1;

for (i = 0; i < NUM_PARAMS; ++i)
   {
   p_list[i] = params[i].nom;
   }

per_mm = ((double) 1.0e3)/p_list[0];

if (jmbplot_open_device (X_WINDOWS,"",string) < 0)
   {
   printf ("%s\n",string);
   return (-1);
   }

/************ plot IV curves ****************/

for (i = 0; i < num_iv_pts; ++i)
   {
   xdata[i] = (float) vdsi[i];
   y1data[i] = (float) (idsi[i]*per_mm*((double) 1.0e3));
   y2data[i] = (float) (parker_ids (p_list,vdsi[i],vgsi[i])*per_mm*((double) 1.0e3));
   }

pdata1[0].curve1_pts = num_iv_pts;
pdata1[1].curve1_pts = num_iv_pts;

find_min_max (xdata,num_iv_pts,&min,&max);

scales1.xmin = scales2.xmin = 0.0;

if (max <= 4.0)
   {
   scales1.xmax = scales2.xmax = 4.0;
   scales1.xstep = scales2.xstep = 1.0;
   scales1.xtick = scales2.xtick = 5;
   }
else if (max <= 5.0)
   {
   scales1.xmax = scales2.xmax = 5.0;
   scales1.xstep = scales2.xstep = 1.0;
   scales1.xtick = scales2.xtick = 5;
   }
else if (max <= 6.0)
   {
   scales1.xmax = scales2.xmax = 6.0;
   scales1.xstep = scales2.xstep = 1.0;
   scales1.xtick = scales2.xtick = 5;
   }
else if (max <= 8.0)
   {
   scales1.xmax = scales2.xmax = 8.0;
   scales1.xstep = scales2.xstep = 2.0;
   scales1.xtick = scales2.xtick = 4;
   }
else if (max <= 10.0)
   {
   scales1.xmax = scales2.xmax = 10.0;
   scales1.xstep = scales2.xstep = 2.0;
   scales1.xtick = scales2.xtick = 4;
   }
else   
   {
   scales1.xmax = scales2.xmax = 12.0;
   scales1.xstep = scales2.xstep = 2.0;
   scales1.xtick = scales2.xtick = 4;
   }

find_min_max (y1data,num_iv_pts,&min,&max);
scales1.y1min = 0.0;

if (max <= 100.0)
   {
   scales1.y1max = 100.0;
   scales1.y1step = 20.0;
   scales1.y1tick = 5;
   }
else if (max <= 150.0)
   {
   scales1.y1max = 150.0;
   scales1.y1step = 30.0;
   scales1.y1tick = 6;
   }
else if (max <= 200.0)
   {
   scales1.y1max = 200.0;
   scales1.y1step = 40.0;
   scales1.y1tick = 4;
   }
else if (max <= 300.0)
   {
   scales1.y1max = 300.0;
   scales1.y1step = 50.0;
   scales1.y1tick = 5;
   }
else if (max <= 500.0)
   {
   scales1.y1max = 500.0;
   scales1.y1step = 100.0;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 800.0;
   scales1.y1step = 200.0;
   scales1.y1tick = 4;
   }


sprintf (pitem[0].x_label,"Vds (volts)");
sprintf (pitem[1].x_label,"Vds (volts)");
sprintf (pitem[0].y1_label,"Ids (mA/mm)");
sprintf (pitem[0].title,"Ids vs. Vds");

if (jmbplot_draw_plot (pitem,1,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }   

/************ plot capacitance ****************/

for (i = 0; i < num_cap_iv_pts; ++i)
   {
   xdata[i] = (float) vds_c[i];
   y1data[i] = (float) (cgsm[i]*per_mm*((double) 1.0e12));
   y3data[i] = (float) (cgdm[i]*per_mm*((double) 1.0e12));
   parker_capacitance (p_list,vds_c[i],vgs_c[i],&cgd,&cgs);
   y2data[i] = (float) (cgs*per_mm*((double) 1.0e12));
   y4data[i] = (float) (cgd*per_mm*((double) 1.0e12));
   }

pdata1[0].curve1_pts = num_cap_iv_pts;
pdata1[1].curve1_pts = num_cap_iv_pts;
pdata2[0].curve1_pts = num_cap_iv_pts;
pdata2[1].curve1_pts = num_cap_iv_pts;

find_min_max (y1data,num_cap_iv_pts,&min,&max);
scales1.y1min = 0.0;

if (max <= 0.1)
   {
   scales1.y1max = 0.1;
   scales1.y1step = 0.025;
   scales1.y1tick = 5;
   }
else if (max <= 0.3)
   {
   scales1.y1max = 0.3;
   scales1.y1step = 0.05;
   scales1.y1tick = 5;
   }
else if (max <= 0.5)
   {
   scales1.y1max = 0.5;
   scales1.y1step = 0.1;
   scales1.y1tick = 5;
   }
else if (max <= 1.0)
   {
   scales1.y1max = 1.0;
   scales1.y1step = 0.2;
   scales1.y1tick = 4;
   }
else if (max <= 3.0)
   {
   scales1.y1max = 3.0;
   scales1.y1step = 0.5;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 5.0;
   scales1.y1step = 1.0;
   scales1.y1tick = 5;
   }

find_min_max (y3data,num_cap_iv_pts,&min,&max);
scales2.y1min = 0.0;

if (max <= 0.05)
   {
   scales2.y1max = 0.05;
   scales2.y1step = 0.01;
   scales2.y1tick = 5;
   }
else if (max <= 0.1)
   {
   scales2.y1max = 0.1;
   scales2.y1step = 0.025;
   scales2.y1tick = 5;
   }
else if (max <= 0.3)
   {
   scales2.y1max = 0.3;
   scales2.y1step = 0.05;
   scales2.y1tick = 5;
   }
else if (max <= 0.6)
   {
   scales2.y1max = 0.6;
   scales2.y1step = 0.1;
   scales2.y1tick = 5;
   }
else if (max <= 1.0)
   {
   scales2.y1max = 1.0;
   scales2.y1step = 0.2;
   scales2.y1tick = 4;
   }
else if (max <= 3.0)
   {
   scales2.y1max = 3.0;
   scales2.y1step = 0.5;
   scales2.y1tick = 5;
   }
else if (max <= 5.0)
   {
   scales2.y1max = 3.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }
else 
   {
   scales2.y1max = 5.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }

sprintf (pitem[0].y1_label,"Cgs (pF/mm)");
sprintf (pitem[0].title,"Cgs vs. Vds");
sprintf (pitem[1].y1_label,"Cgd (pF/mm)");
sprintf (pitem[1].title,"Cgd vs. Vds");
   
if (jmbplot_draw_plot (pitem,2,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }  

/************ plot gm and gds ****************/

del = (double) 1.0e-9;
for (i = 0; i < num_cap_iv_pts; ++i)
   {
   vgd = vgs_c[i]-vds_c[i];
   ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i],vgd,vgs_c[i],vgd,(double) 0.0);
   p_ave = fabs (ids1*vds_c[i]);
   ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]+del,vgd+del,vgs_c[i],vgd,p_ave);
   ids2 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]-del,vgd-del,vgs_c[i],vgd,p_ave);
   gm = (ids1-ids2)*((double) 0.5)/del;
   ids1 = parker_ac_ids (p_list,vds_c[i]+del,vgs_c[i],vgd-del,vgs_c[i],vgd,p_ave);
   ids2 = parker_ac_ids (p_list,vds_c[i]-del,vgs_c[i],vgd+del,vgs_c[i],vgd,p_ave);
   gds = (ids1-ids2)*((double) 0.5)/del;

   y1data[i] = (float) (gmm[i]*per_mm*((double) 1.0e3));
   y3data[i] = (float) (gdsm[i]*per_mm*((double) 1.0e3));
   y2data[i] = (float) (gm*per_mm*((double) 1.0e3));
   y4data[i] = (float) (gds*per_mm*((double) 1.0e3));   
   }
   
find_min_max (y1data,num_cap_iv_pts,&min,&max);
scales1.y1min = 0.0;

if (max <= 50.0)
   {
   scales1.y1max = 50.0;
   scales1.y1step = 10.0;
   scales1.y1tick = 5;
   }
else if (max <= 100.0)
   {
   scales1.y1max = 100.0;
   scales1.y1step = 20.0;
   scales1.y1tick = 5;
   }
else if (max <= 200.0)
   {
   scales1.y1max = 200.0;
   scales1.y1step = 40.0;
   scales1.y1tick = 4;
   }
else if (max <= 300.0)
   {
   scales1.y1max = 300.0;
   scales1.y1step = 50.0;
   scales1.y1tick = 5;
   }
else if (max <= 500.0)
   {
   scales1.y1max = 500.0;
   scales1.y1step = 100.0;
   scales1.y1tick = 5;
   }
else   
   {
   scales1.y1max = 800.0;
   scales1.y1step = 200.0;
   scales1.y1tick = 4;
   }

find_min_max (y3data,num_cap_iv_pts,&min,&max);
scales2.y1min = 0.0;

if (max <= 0.1)
   {
   scales2.y1max = 0.1;
   scales2.y1step = 0.025;
   scales2.y1tick = 5;
   }
else if (max <= 0.5)
   {
   scales2.y1max = 0.5;
   scales2.y1step = 0.1;
   scales2.y1tick = 5;
   }
else if (max <= 1.0)
   {
   scales2.y1max = 1.0;
   scales2.y1step = 0.2;
   scales2.y1tick = 4;
   }
else if (max <= 3.0)
   {
   scales2.y1max = 3.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }
else if (max <= 5.0) 
   {
   scales2.y1max = 5.0;
   scales2.y1step = 1.0;
   scales2.y1tick = 5;
   }
else if (max <= 10.0) 
   {
   scales2.y1max = 10.0;
   scales2.y1step = 2.0;
   scales2.y1tick = 4;
   }
else if (max <= 30.0) 
   {
   scales2.y1max = 30.0;
   scales2.y1step = 5.0;
   scales2.y1tick = 5;
   }
else
   {
   scales2.y1max = 50.0;
   scales2.y1step = 10.0;
   scales2.y1tick = 5;
   }

sprintf (pitem[0].y1_label,"Gm (mS/mm)");
sprintf (pitem[0].title,"Gm vs. Vds");
sprintf (pitem[1].y1_label,"Gds (mS/mm)");
sprintf (pitem[1].title,"Gds vs. Vds");

if (jmbplot_draw_plot (pitem,2,0,string) < 0)
   {
   printf ("%s\n",string);
   jmbplot_close_device ();
   return (-1);
   }  

jmbplot_close_device ();

return (OK);
}


/*                                                                          */
/* ----------- fit_parasitics() ------------------------------------------- */
/*                                                                          */

int fit_parasitics (fname1,fname2)
char    *fname1;
char    *fname2;

{
FILE     *file1;
int      n = 0;
int      m = 0;
int      i;
char     string[301];
char     pname[80];
double   idd[MAX_BIAS_PTS];
double   igg[MAX_BIAS_PTS];
double   Rg[MAX_BIAS_PTS];
double   Rd[MAX_BIAS_PTS];
double   Rs[MAX_BIAS_PTS];
double   Ri[MAX_BIAS_PTS];
double   Tau[MAX_BIAS_PTS];
double   Cds[MAX_BIAS_PTS];
double   Ls[MAX_BIAS_PTS];
double   rg1,rd1,rs1,ri1;
double   value,area,ugw,ngf;
double   cpg,cpd,c11,c22;

ngf = params[39].nom;
ugw = params[38].nom;
area = params[0].nom;

file1 = (FILE *) NULL;
file1 = fopen (fname1,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("Unable to open model summary file - %s\n",fname1);
   return (ERR);
   }

while (fgets (string,300,file1) != NULL)
   {
   if (sscanf (&string[28],"%lf %lf %lf %lf %*f %*f %lf %lf %lf %lf %lf %lf %lf %*f %lf %lf %lf %*f %lf",
               &vds_c[n],&idd[n],&vgs_c[n],&igg[n],
               &Rg[m],&Rs[m],&Rd[m],&Ri[m],&gmm[n],&Tau[m],&gdsm[n],
               &cgsm[n],&Cds[m],&cgdm[n],&Ls[m]) == 15)
      {
      ++m;

      if ((igg[n]*((double) 1.0e-3)/area) < MAX_FWD_IGS)
         {
         igg[n] *= ((double) 1.0e-3);
         idd[n] *= ((double) 1.0e-3);
         gmm[n] *= ((double) 1.0e-3);
         gdsm[n] *= ((double) 1.0e-3);
         cgsm[n] *= ((double) 1.0e-12);
         cgdm[n] *= ((double) 1.0e-12);
         ++n;
         }
      }
   }
fclose (file1);
num_cap_iv_pts = n;

file1 = (FILE *) NULL;
file1 = fopen (fname2,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("Unable to open yfit file - %s\n",fname2);
   return (ERR);
   }

while (fgets (string,300,file1) != NULL)
   {
   sscanf (string,"%*f %lf %*f %*f %s",&value,pname);
   if (!strcmp (pname,"C1"))
      {
      cpg = value;
      }
   else if (!strcmp (pname,"C2"))
      {
      cpd = value;
      }
   else if (!strcmp (pname,"C11"))
      {
      c11 = value;
      }
   else if (!strcmp (pname,"C22"))
      {
      c22 = value;
      }
   else if (!strcmp (pname,"B1"))
      {
      lp_gate = value;
      }
   else if (!strcmp (pname,"B2"))
      {
      lp_drain = value;
      }
   }
fclose (file1);

params[27].nom = bubble_average (Rg,m)*((double) 3.0)*ngf/ugw;
params[28].nom = bubble_average (Rs,m)*area;
params[29].nom = bubble_average (Rd,m)*area;
params[30].nom = bubble_average (Ri,m)*area/((double) 2.0);
params[31].nom = bubble_average (Tau,m)*((double) 1.0e-12);
params[32].nom = bubble_average (Cds,m)*((double) 1.0e-12)/area;
params[33].nom = cpg/area;
params[34].nom = bubble_average (Ls,m)*((double) 1.0e-12);
params[35].nom = cpd/area;
params[36].nom = c11/area;
params[37].nom = c22/area;

lp_gate = ngf*(lp_gate-((double) 2.0e-13)*ugw*(log (ugw/eff_gl)+((double) 0.498232))/(((double) 3.0)*ngf));
lp_drain = ngf*(lp_drain-((double) 2.0e-13)*ugw*(log (ugw/eff_dl)+((double) 0.498232))/(((double) 1.5)*ngf));

rg1 = params[27].nom*ugw/(ngf*((double) 3.0));
rd1 = params[29].nom/area;
rs1 = params[28].nom/area;
ri1 = params[30].nom/area;

for (i = 0; i < num_cap_iv_pts; ++i)
   {
   vds_c[i] = vds_c[i]-rd1*idd[i]-rs1*(igg[i]+idd[i]);
   vgs_c[i] = vgs_c[i]-(rg1+ri1)*igg[i]-rs1*(igg[i]+idd[i]);
   }

for (i = 27; i < NUM_PARAMS; ++i)
   {
   params[i].tol = (double) 0.0;
   params[i].max = params[i].min = params[i].nom;
   params[i].optimize = FALSE;
   }

params[0].tol = (double) 0.0;
params[0].max = params[0].min = params[0].nom;
params[0].optimize = FALSE;

return (OK);
}


/*                                                                          */
/* ----------- get_starting_values() -------------------------------------- */
/*                                                                          */

int get_starting_values (fname)
char   *fname;

{
FILE   *file1;
char   string[201];
int    i;

strcpy (params[0].name,"area  ");
strcpy (params[1].name,"vbi   ");
strcpy (params[2].name,"beta  ");
strcpy (params[3].name,"vto   ");
strcpy (params[4].name,"p     ");
strcpy (params[5].name,"delta ");
strcpy (params[6].name,"q     ");
strcpy (params[7].name,"vst   ");
strcpy (params[8].name,"mvst  ");
strcpy (params[9].name,"xi    ");
strcpy (params[10].name,"mxi   ");
strcpy (params[11].name,"lambda");
strcpy (params[12].name,"z     ");
strcpy (params[13].name,"lfgam ");
strcpy (params[14].name,"lfg1  ");
strcpy (params[15].name,"lfg2  ");
strcpy (params[16].name,"cgs   ");
strcpy (params[17].name,"cgd   ");
strcpy (params[18].name,"acgam ");
strcpy (params[19].name,"xc    ");
strcpy (params[20].name,"fc    ");
strcpy (params[21].name,"hfeta ");
strcpy (params[22].name,"hfe1  ");
strcpy (params[23].name,"hfe2  ");
strcpy (params[24].name,"hfgam ");
strcpy (params[25].name,"hfg1  ");
strcpy (params[26].name,"hfg2  ");
strcpy (params[27].name,"rg    ");
strcpy (params[28].name,"rs    ");
strcpy (params[29].name,"rd    ");
strcpy (params[30].name,"ri    ");
strcpy (params[31].name,"tau   ");
strcpy (params[32].name,"cds   ");
strcpy (params[33].name,"cpg   ");
strcpy (params[34].name,"ls    ");
strcpy (params[35].name,"cpd   ");
strcpy (params[36].name,"c11   ");
strcpy (params[37].name,"c22   ");
strcpy (params[38].name,"ugw   ");
strcpy (params[39].name,"ngf   ");
strcpy (params[40].name,"is    ");
strcpy (params[41].name,"n     ");
strcpy (params[42].name,"ibd   ");
strcpy (params[43].name,"vbd   ");

strcpy (params[0].units,"um");
strcpy (params[1].units,"V");
strcpy (params[2].units,"A/V^2");
strcpy (params[3].units,"V");
strcpy (params[4].units,"");
strcpy (params[5].units,"1/W");
strcpy (params[6].units,"");
strcpy (params[7].units,"V");
strcpy (params[8].units,"1/V");
strcpy (params[9].units,"");
strcpy (params[10].units,"");
strcpy (params[11].units,"1/V");
strcpy (params[12].units,"");
strcpy (params[13].units,"");
strcpy (params[14].units,"1/V");
strcpy (params[15].units,"1/V");
strcpy (params[16].units,"F");
strcpy (params[17].units,"F");
strcpy (params[18].units,"");
strcpy (params[19].units,"");
strcpy (params[20].units,"");
strcpy (params[21].units,"");
strcpy (params[22].units,"");
strcpy (params[23].units,"");
strcpy (params[24].units,"");
strcpy (params[25].units,"");
strcpy (params[26].units,"");
strcpy (params[27].units,"ohms/um");
strcpy (params[28].units,"ohm-um");
strcpy (params[29].units,"ohm-um");
strcpy (params[30].units,"ohm-um");
strcpy (params[31].units,"S");
strcpy (params[32].units,"F/um");
strcpy (params[33].units,"F/um");
strcpy (params[34].units,"pH");
strcpy (params[35].units,"F/um");
strcpy (params[36].units,"F/um");
strcpy (params[37].units,"F/um");
strcpy (params[38].units,"um");
strcpy (params[39].units,"");
strcpy (params[40].units,"A/um");
strcpy (params[41].units,"");
strcpy (params[42].units,"A/um");
strcpy (params[43].units,"V");

file1 = (FILE *) NULL;
file1 = fopen (fname,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("unable to open starting values file - %s\n",fname);
   return (ERR);
   }

for (i = 0; i < NUM_PARAMS; ++i)
   {
   if (fgets (string,200,file1) == NULL)
      {
      printf ("INCOMPLETE starting values file - %s\n",fname);
      fclose (file1);
      return (ERR);
      }

   sscanf (string,"%lf %lf %lf %lf",&params[i].min,&params[i].nom,&params[i].max,&params[i].tol);
   params[i].optimize = TRUE;

   if (params[i].min > params[i].max)
      {
      printf ("ERROR: parameter \"%s\" MIN is greater than MAX.\n",params[i].name);
      fclose (file1);
      return (ERR);
      }
   else if ((params[i].nom < params[i].min) || (params[i].nom > params[i].max))
      {
      printf ("ERROR: parameter \"%s\" is outside min/max range.\n",params[i].name);
      fclose (file1);
      return (ERR);
      }
   }
fclose (file1);

return (OK);
}


/*                                                                          */
/* ----------- get_iv_curves() -------------------------------------------- */
/*                                                                          */

int get_iv_curves (fname,mode)
char  *fname;
int   mode;

{
FILE     *file1;
char     string[201];
int      i = 0;
double   rs,rd,rg,ri;

file1 = (FILE *) NULL;
file1 = fopen (fname,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("Unable to open IV file - %s\n",fname);
   return (ERR);
   }

rg = params[27].nom*params[38].nom/(params[39].nom*((double) 3.0));
rd = params[29].nom/params[0].nom;
rs = params[28].nom/params[0].nom;
ri = params[30].nom/params[0].nom;

while (fgets (string,200,file1) != NULL)
   {
   if (sscanf (string,"%lf %lf %lf %lf",&vdsi[i],&idsi[i],&vgsi[i],&igsi[i]) == 4)
      {
      switch (mode)
         {
         case 0:
            if ((igsi[i]/params[0].nom) >= MAX_FWD_IGS)
               {
               continue;
               }
            else if (vdsi[i] > maximum_vds)
               {
               continue;
               }
            else
               {
               vdsi[i] = vdsi[i]-rd*idsi[i]-rs*(igsi[i]+idsi[i]);
               vgsi[i] = vgsi[i]-(rg+ri)*igsi[i]-rs*(igsi[i]+idsi[i]);
               ++i;
               }
            break;

         case 1:
            if (vdsi[i] != (double) 0.0)
               {
               continue;
               }
            else
               {
               ++i;
               }
            break;

         case 2:
            igsi[i] = -igsi[i];
            vgsi[i] = (vdsi[i]-idsi[i]*rd)-(vgsi[i]+igsi[i]*rg);
            ++i;
            break;
         
         default:
            break;
         }
      }
   }
fclose (file1);

return (i);
}

/****************************************************************************/
/*                          PARKER MODEL FUNCTIONS                          */
/****************************************************************************/

/*                                                                          */
/* ----------- parker_opt() ----------------------------------------------- */
/*                                                                          */

double *parker_opt (p_list)
double   *p_list;

{
static double  result[2];

if (mode_flag == 0)
   {
   result[0] = ids_function (p_list);
   result[1] = cgs_cgd_function (p_list);
   }
else
   {
   result[0] = gm_gds_function (p_list);
   }

return (&result[0]);
}


/*                                                                          */
/* ----------- ids_function() --------------------------------------------- */
/*                                                                          */

double ids_function (p_list)
double  *p_list;

{
int      i;
double   pids;
double   error;

error = (double) 0.0;
for (i = 0; i < num_iv_pts; ++i)
   {
   pids = parker_ids (p_list,vdsi[i],vgsi[i]);
   if ((fabs (vdsi[i]) <= (double) 2.0) && ((idsi[i]/params[0].nom) <= (double) 0.1))
      {
      error += pow ((((double) 5000.0)*(idsi[i]-pids)),((double) 2.0));
      }
   else
      {
      error += pow ((((double) 1000.0)*(idsi[i]-pids)),((double) 2.0));
      }
   }

return (error/((double) num_iv_pts));
}

/*                                                                          */
/* ----------- cgs_cgd_function() ----------------------------------------- */
/*                                                                          */

double cgs_cgd_function (p_list)
double  *p_list;

{
int      i;
double   cgs,cgd;
double   error;

error = (double) 0.0;
for (i = 0; i < num_cap_iv_pts; ++i)
   {
   parker_capacitance (p_list,vds_c[i],vgs_c[i],&cgd,&cgs);
   error += pow (((double) 1.0e12)*(cgsm[i]-cgs),(double) 2.0)+
                (((double) 4.5)*tanh (((double) 2.0)*vds_c[i]-((double) 0.5))+((double) 5.5))*
                pow (((double) 1.0e12)*(cgdm[i]-cgd),(double) 2.0);
   }

return (error/((double) num_cap_iv_pts));
}


/*                                                                          */
/* ----------- gm_gds_function() ------------------------------------------ */
/*                                                                          */

double gm_gds_function (p_list)
double   *p_list;

{
int     i;
double  gm,gds;
double  del;
double  ids1,ids2;
double  p_ave,vgd;
double  error;

del = (double) 1.0e-9;

error = (double) 0.0;
for (i = 0; i < num_cap_iv_pts; ++i)
   {
   vgd = vgs_c[i]-vds_c[i];
   ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i],vgd,vgs_c[i],vgd,(double) 0.0);
   p_ave = fabs (ids1*vds_c[i]);

   ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]+del,vgd+del,vgs_c[i],vgd,p_ave);
   ids2 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]-del,vgd-del,vgs_c[i],vgd,p_ave);
   gm = (ids1-ids2)*((double) 0.5)/del;
   ids1 = parker_ac_ids (p_list,vds_c[i]+del,vgs_c[i],vgd-del,vgs_c[i],vgd,p_ave);
   ids2 = parker_ac_ids (p_list,vds_c[i]-del,vgs_c[i],vgd+del,vgs_c[i],vgd,p_ave);
   gds = (ids1-ids2)*((double) 0.5)/del;

   error += pow (((double) 1.0e3)*(gmm[i]-gm),(double) 2.0)+
             (((double) 2.0)*tanh (((double) 2.0)*vds_c[i]-((double) 0.5))+((double) 3.0))*
             pow (((double) 1.0e3)*(gdsm[i]-gds),(double) 2.0);
   }

return (error/((double) num_cap_iv_pts));
}


/*                                                                          */
/* ----------- parker_ids() ----------------------------------------------- */
/*                                                                          */

double parker_ids (p_list,V_ds,V_gs)
double  *p_list;
double  V_ds;
double  V_gs;

{
double  delta,area,vst,mvst;
double  lfgam,lfg1,lfg2;
double  p,q,z,lambda,beta;
double  xi,mxi,vbi,vto;
double  lfgamma;
double  V_gst,V_gt,V_st,V_dt,V_dp;
double  V_ds1,V_gs1,V_gd1,V_sat,I_d,I_ds;
double  V_gd,P_ave;
double  Vtemp;

area   = p_list[0];
vbi    = p_list[1];
beta   = p_list[2];
vto    = p_list[3];
p      = p_list[4];
delta  = p_list[5];
q      = p_list[6];
vst    = p_list[7];
mvst   = p_list[8];
xi     = p_list[9];
mxi    = p_list[10];
lambda = p_list[11];
z      = p_list[12];
lfgam  = p_list[13];
lfg1   = p_list[14];
lfg2   = p_list[15];

V_gd = V_gs-V_ds;

if (V_ds >= (double) 0.0)
   {
   V_gs1 = V_gs;
   V_gd1 = V_gd;
   V_ds1 = V_ds;
   }
else
   {
   V_gs1 = V_gd;
   V_gd1 = V_gs;
   V_ds1 = -V_ds;
   }

lfgamma = lfgam-lfg1*V_gs1+lfg2*V_gd1;

V_gst = V_gs1-vto-lfgamma*V_gd1;

V_st = vst*(((double) 1.0)+mvst*V_ds1);

if (V_gst <= ((double) -40.0)*V_st)
   {
   V_gt = V_st*log (exp ((double) -40.0)+((double) 1.0));
   }
else if (V_gst >= ((double) 40.0)*V_st)
   {
   V_gt = V_st*log (exp ((double) 40.0)+((double) 1.0));
   }
else
   {
   V_gt = V_st*(((double) 1.0e-15)+log (exp (V_gst/V_st)+((double) 1.0)));
   }

V_sat = V_gt*(V_gt*mxi+xi*(vbi-vto))/(V_gt+V_gt*mxi+xi*(vbi-vto));
V_dp = V_ds1*(p/q)*pow ((V_gt/(vbi-vto)),(p-q));


V_dt = ((double) 0.5)*sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)+V_sat),(double) 2.0)+z*V_sat*V_sat)-
       ((double) 0.5)*sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)-V_sat),(double) 2.0)+z*V_sat*V_sat);

/*
Vtemp = V_sat*V_sat;
V_dt = (sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)/Vtemp+((double) 1.0)),((double) 2.0))+z)-
        sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)/Vtemp-((double) 1.0)),((double) 2.0))+z))*((double) 0.5)*V_sat;
*/

I_d = area*beta*(((double) 1.0)+lambda*V_ds1)*(pow (V_gt,q)-pow (fabs (V_gt-V_dt),q));
P_ave = fabs (I_d*V_ds);
I_ds = I_d/(((double) 1.0)+delta*P_ave/area);

if (V_ds < (double) 0.0)
   {
   I_ds = -I_ds;
   }

return (I_ds);
}


/*                                                                          */
/* ----------- parker_ac_ids() -------------------------------------------- */
/*                                                                          */

double parker_ac_ids (p_list,V_ds,V_gs,V_gd,dV_gs,dV_gd,P_ave)
double  *p_list;
double  V_ds;
double  V_gs;
double  V_gd;
double  dV_gs;
double  dV_gd;
double  P_ave;

{
double  delta,area,vst,mvst;
double  lfgam,lfg1,lfg2;
double  p,q,z,lambda,beta;
double  xi,mxi,vbi,vto;
double  lfgamma;
double  hfgam,hfg1,hfg2,hfeta,hfe1,hfe2;
double  V_gst,V_gt,V_st,V_dt,V_dp;
double  V_ds1,V_gs1,V_gd1,V_sat,I_d,I_ds;
double  dV_gd1,dV_gs1,hfgamma,hf_eta;
double  Vtemp;

area   = p_list[0];
vbi    = p_list[1];
beta   = p_list[2];
vto    = p_list[3];
p      = p_list[4];
delta  = p_list[5];
q      = p_list[6];
vst    = p_list[7];
mvst   = p_list[8];
xi     = p_list[9];
mxi    = p_list[10];
lambda = p_list[11];
z      = p_list[12];
lfgam  = p_list[13];
lfg1   = p_list[14];
lfg2   = p_list[15];
hfeta  = p_list[21];
hfe1   = p_list[22];
hfe2   = p_list[23];
hfgam  = p_list[24];
hfg1   = p_list[25];
hfg2   = p_list[26];

if (V_ds >= (double) 0.0)
   {
   V_gs1 = V_gs;
   V_gd1 = V_gd;
   V_ds1 = V_ds;
   dV_gs1 = dV_gs;
   dV_gd1 = dV_gd;
   }
else
   {
   V_gs1 = V_gd;
   V_gd1 = V_gs;
   V_ds1 = -V_ds;
   dV_gs1 = dV_gd;
   dV_gd1 = dV_gs;
   }

lfgamma = lfgam-lfg1*dV_gs1+lfg2*dV_gd1;

hfgamma = hfgam-hfg1*dV_gs1+hfg2*dV_gd1;
hf_eta  = hfeta-hfe1*dV_gd1+hfe2*dV_gs1;

V_gst = V_gs1-vto-lfgamma*V_gd1-hfgamma*(V_gd1-dV_gd1)-hf_eta*(V_gs1-dV_gs1);

V_st = vst*(((double) 1.0)+mvst*V_ds1);

if (V_gst <= ((double) -40.0)*V_st)
   {
   V_gt = V_st*log (exp ((double) -40.0)+((double) 1.0));
   }
else if (V_gst >= ((double) 40.0)*V_st)
   {
   V_gt = V_st*log (exp ((double) 40.0)+((double) 1.0));
   }
else
   {
   V_gt = V_st*(((double) 1.0e-15)+log (exp (V_gst/V_st)+((double) 1.0)));
   }

V_sat = V_gt*(V_gt*mxi+xi*(vbi-vto))/(V_gt+V_gt*mxi+xi*(vbi-vto));
V_dp = V_ds1*(p/q)*pow ((V_gt/(vbi-vto)),(p-q));


V_dt = ((double) 0.5)*sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)+V_sat),(double) 2.0)+z*V_sat*V_sat)-
       ((double) 0.5)*sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)-V_sat),(double) 2.0)+z*V_sat*V_sat);

/*
Vtemp = V_sat*V_sat;
V_dt = (sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)/Vtemp+((double) 1.0)),((double) 2.0))+z)-
        sqrt (pow ((V_dp*sqrt (((double) 1.0)+z)/Vtemp-((double) 1.0)),((double) 2.0))+z))*((double) 0.5)*V_sat;
*/

I_d = area*beta*(((double) 1.0)+lambda*V_ds1)*(pow (V_gt,q)-pow (fabs (V_gt-V_dt),q));
I_ds = I_d/(((double) 1.0)+delta*P_ave/area);

if (V_ds < (double) 0.0)
   {
   I_ds = -I_ds;
   }

return (I_ds);
}


/*                                                                          */
/* ----------- parker_capacitance() --------------------------------------- */
/*                                                                          */

void parker_capacitance (p_list,vds,vgs,Cgd,Cgs)
double   *p_list;
double   vds;
double   vgs;
double   *Cgd;
double   *Cgs;

{
double    area,vbi,vto,xi;
double    cgs,cgd,acgam,xc,fc;
double    alpha,cgs0,cgd0;
double    Veff,Vert,Vx,Vnew;
double    Vnr,Vnrt,Ext,Qrt,Par;
double    c_plus,c_minus;
double    vgd;

area   = p_list[0];
vbi    = p_list[1];
vto    = p_list[3];
xi     = p_list[9];
cgs    = p_list[16];
cgd    = p_list[17];
acgam  = p_list[18];
xc     = p_list[19];
fc     = p_list[20];

vgd = vgs-vds;

alpha = xi*(vbi-vto)*((double) 0.5)/(((double) 1.0)+xi);

Vert = sqrt (vds*vds+alpha*alpha);
Veff = ((double) 0.5)*(vgs+vgd+Vert)+acgam*vds;
Vnr = (((double) 1.0)-xc)*(Veff-vto);
Vnrt = sqrt (Vnr*Vnr+((double) 0.04));
Vnew = Veff+((double) 0.5)*(Vnrt-Vnr);

if (Vnew < fc)
   {
   Ext = (double) 0.0;
   Qrt = sqrt (((double) 1.0)-Vnew/vbi);
   cgs0 = ((double) 0.5)*cgs*area*(((double) 1.0)+xc+(((double) 1.0)-xc)*Vnr/Vnrt)/Qrt;
   }
else
   {
   Vx = ((double) 0.5)*(Vnew-fc);
   Par = ((double) 1.0)+Vx/(vbi-fc);
   Qrt = sqrt (((double) 1.0)-fc/vbi);
   cgs0 = ((double) 0.5)*cgs*area*(((double) 1.0)+xc+(((double) 1.0)-xc)*Vnr/Vnrt)*Par/Qrt;
   }

c_plus = ((double) 0.5)*(((double) 1.0)+vds/Vert);
c_minus = c_plus-vds/Vert;

cgd0 = cgd*area;

*Cgs = cgs0*(c_plus+acgam)+cgd0*(c_minus+acgam);
*Cgd = cgs0*(c_minus-acgam)+cgd0*(c_plus-acgam);

return;
}

/****************************************************************************/
/*                                UTILITIES                                 */
/****************************************************************************/

/*                                                                          */
/* ----------- bubble_average() ------------------------------------------- */
/*                                                                          */

double bubble_average (values,n)
double   *values;
int      n;

{
int     i,j;
double  temp;
double  delta;

for (i = 0; i < n-1; ++i)
   {
   for (j = i+1; j < n; ++j)
      {
      if (values[j] < values[i])
         {
         temp = values[i];
         values[i] = values[j];
         values[j] = temp;
         }
      }
   }

i = 0;
temp = (double) 0.0;
delta = fabs (values[n/2])*((double) 0.25);
for (j = 0; j < n; ++j)
   {
   if (fabs (values[j]-values[n/2]) < delta)
      {
      ++i;
      temp += values[j];
      }
   }
temp = temp/((double) i);

return (temp);
}


/*                                                                          */
/* ----------- diode_fit() ------------------------------------------------ */
/*                                                                          */

int diode_fit (vd,id,k,area,is,n)
double   *vd;
double   *id;
int      k;
double   area;
double   *is;
double   *n;

{
double   a1[3][MAX_IV_PTS];
double   a2[MAX_IV_PTS][3];
double   b1[MAX_IV_PTS];
double   a[3][3];
double   b[3];
double   x[3];
double   sum;
double   Rd;
int      i,j;
int      npts;

j = 0;
for (i = 0; i < k; ++i)
   {
   if ((vd[i] <= (double) 0.0) || (id[i] <= (((double) 1.0e-7)*area)))
      {
      continue;
      }
   a2[j][0] = log (id[i]);
   a2[j][1] = (double) -1.0;
   a2[j][2] = id[i];
   a1[0][j] = a2[j][0];
   a1[1][j] = a2[j][1];
   a1[2][j] = a2[j][2];
   b1[j] = vd[i];
   ++j;
   }

if (j < 3)
   {
   printf ("Not enough points for diode fit.\n");
   return (-1);
   }

npts = j;

for (i = 0; i < 3; ++i)
   {
   for (j = 0; j < 3; ++j)
      {
      sum = (double) 0.0;
      for (k = 0; k < npts; ++k)
         {
         sum += a1[i][k]*a2[k][j];
         }
      a[i][j] = sum;
      }
   }

for (i = 0; i < 3; ++i)
   {
   sum = (double) 0.0;
   for (j = 0; j < npts; ++j)
      {
      sum += a1[i][j]*b1[j];
      }
   b[i] = sum;
   }

if (a_x_b (a,x,b,3) == -1)
   {
   printf ("Un-invertable matrix in diode fit.\n");
   return (-1);
   }
  
*n = x[0]*((double) 38.6981492189);
*is = exp (x[1]/x[0]);
Rd = x[2];

return (0);
}


/*                                                                          */
/* ----------- a_x_b() ---------------------------------------------------- */
/*                                                                          */

int a_x_b (a,x,b,n)
double   *a;
double   *x;
double   *b;
int      n;

{
double   y[50];
double   z[50][50];
double   tempd;
double   tempd2;
double   max;
int      pointer[50];
int      tempi;
int      i,j,k;
int      col,row;


if (n > 50)
   {
   printf ("a_x_b () - Matrix is too large.\n");
   return (-1);
   }

for (i = 0; i < n; ++i)
   {
   y[i] = b[i];
   pointer[i] = i;
   for (j = 0; j < n; ++j)
      {
      z[i][j] = a[i*n+j];
      }
   }

/* invert the matrix */
for (k = 0; k < n-1; ++k)
   {
   /* find max */
   max = (double) 0.0;
   for (i = k; i < n; ++i)
      {
      for (j = k; j < n; ++j)
         {
         if (fabs (z[i][j]) > max)
            {
            row = i;
            col = j;
            max = fabs (z[i][j]);
            }
         }
      }

   /* rotate rows */
   if (row != k)
      {
      for (j = 0; j < n; ++j)
         {
         tempd = z[k][j];
         z[k][j] = z[row][j];
         z[row][j] = tempd;
         }
      tempd = y[k];
      y[k] = y[row];
      y[row] = tempd;
      }

   /* rotate columns */ 
   if (col != k)
      {
      for (i = 0; i < n; ++i)
         {
         tempd = z[i][k];
         z[i][k] = z[i][col];
         z[i][col] = tempd;
         }
      tempi = pointer[k];
      pointer[k] = pointer[col];
      pointer[col] = tempi;
      }

   /* gaussian elimination */
   tempd = z[k][k];
   for (i = k+1; i < n; ++i)
      {
      tempd2 = z[i][k]/tempd;
      y[i] -= tempd2*y[k];
      for (j = k; j < n; ++j)
         {
         z[i][j] -= tempd2*z[k][j];
         }
      }
   }  

if (fabs (z[n-1][n-1]) < (double) 1.0e-34)
   {
   return (-1);
   }

/* back substitution */
x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
for (k = n-2; k > -1; --k)
   {
   tempd = y[k];
   for (i = n-1; i > k; --i)
      {
      tempd -= z[k][i]*x[pointer[i]];
      }
   x[pointer[k]] = tempd/z[k][k];
   }

return (0);
}

/*********************************************************************/

void find_min_max (data,n,min,max)
float  *data;
int    n;
float  *min,*max;

{
int i;

*min = data[0];
*max = data[0];
for (i = 1; i < n; ++i)
   {
   if (data[i] > *max)
      {
      *max = data[i];
      }
   if (data[i] < *min)
      {
      *min = data[i];
      }
   }

return;
}

