#include <string.h>

/* 
replacement function (sort of) for strcasecmp since Microsuck didn't feel the need to 
provide it in their compiler libraries for Visual Studio

simply returns a non-zero integer for str1 != str2, not a element-by-element difference
like the STDC function
*/

int strcasecmp (char *str1, char *str2)
   {
   unsigned i;

   if (strlen (str1) > strlen (str2))
      return 1;
   else if (strlen (str1) < strlen (str2))
      return -1;
   else
      {
      for (i = 0; i < strlen (str1); ++i)
         {
         if (
             (str1[i] != str2[i]) &&
             (
              !((str1[i] > (char)64) && (str1[i] < (char)91) && (str1[i] == (str2[i]-32))) &&
              !((str2[i] > (char)64) && (str2[i] < (char)91) && (str2[i] == (str1[i]-32)))
             )
            )
            return 1;
         }

      return 0;
      }
   }





