#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"
#include "optimize4.h"

/****** MACROS AND DEFINITIONS ******/

#define MAX_DCIV_PTS     2000

#define BOLTZ     1.380066e-23
#define CHARGE    1.60218e-19
#define STDTEMP   300.0

typedef struct
   {
   double vgs,vds,igs,ids;
   } IV_DATA;

typedef struct
   {
   unsigned n;
   IV_DATA *data;
   double max_vds;
   double periphery;
   } DC_DATA;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, int max_size);
static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMETERS fixed);
static void write_model_param_mdif (FILE *file, char *names[], double *values, unsigned n, unsigned width, unsigned cols);

static unsigned get_iv_curves (char *fname, int type, IV_DATA *d, unsigned max_pts, FIXED_PARAMETERS fixed_params);

static int subth_dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int dciv_erf (double *p, void *data, double *err, unsigned n_err);

static int plot_data (int dev, double periph, IV_DATA *dc, unsigned n_dc, AC_PARAMETERS *ac, unsigned n_ac,
                      OPT_PARAMETER *params, IV_DATA *fwd, unsigned n_fwd, IV_DATA *vbr, unsigned n_vbr,
                      FIXED_PARAMETERS fixed);

static double tom3_ids (double *p, double vgs, double vds);

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   unsigned i,niter;
   char string[256];
   char start_file[100],end_file[100];
   char dc_iv_file[100];
   char header[3000];
   double tmpd;
   OPTIMIZE *opt;
   OPT_PARAMETER params[NUM_PARAMS],tmp_params[NUM_PARAMS];
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   unsigned num_dciv_pts;
   DC_DATA dciv_data;
   double maximum_vds;
   
   // parse the command line
   
   

   printf ("DC IV data file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%99s", dc_iv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &maximum_vds);

   printf ("Start parameters file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%99s", start_file);

   printf ("Finish parameters file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%99s", end_file);

   printf ("Maximum number of line searches?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%d", &niter);


   if (!(num_dciv_pts = get_iv_curves (dc_iv_file, dciv_curves, MAX_DCIV_PTS, fixed_params)))
      return -1;

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, params, NUM_PARAMS);
   set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);

   dciv_data.n = num_dciv_pts;
   dciv_data.data = dciv_curves;
   dciv_data.max_vds = maximum_vds;
   dciv_data.periphery = fixed_params.area;

   printf (" Subthreshold...\n");
   
   set_cg_error_function (opt, subth_dciv_erf, &dciv_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-9, 5);

   params[0].optimize = TRUE;
   params[7].optimize = TRUE;
   params[8].optimize = TRUE;
         
   if (optimization_fits & OPTIMIZE_DCIV)
      {
      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Gradient optimizer encountered an error:\n  %s\n", get_cg_error());
         return -1;
         }
      }

   params[0].optimize = FALSE;
   params[7].optimize = FALSE;
   params[8].optimize = FALSE;   

   printf (" Active...\n");

   set_cg_error_function (opt, dciv_erf, &dciv_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-9, 5);

   for (i = 1; i <= 6; ++i)
      params[i].optimize = TRUE;
         
   if (optimization_fits & OPTIMIZE_DCIV)
      {
      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Gradient optimizer encountered an error:\n  %s\n", get_cg_error());
         return -1;
         }
      }
   
   for (i = 1; i <= 6; ++i)
      params[i].optimize = FALSE;
      
   get_file_header (dc_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, tmp_params, fixed_params))
      return -1;

   /***** Generate plots *****/
   
   printf ("Generating plots.\n");
   
   plot_data (X_WINDOWS, fixed_params.area, dciv_curves, num_dciv_pts, ac_data, num_ac_bias_pts, tmp_params,
      fwdiv_curves, num_fwdiv_pts, breakdown_curves, num_breakdown_pts, fixed_params);
   plot_data (POSTSCRIPT, fixed_params.area, dciv_curves, num_dciv_pts, ac_data, num_ac_bias_pts, tmp_params,
      fwdiv_curves, num_fwdiv_pts, breakdown_curves, num_breakdown_pts, fixed_params);

   return 0;
   }
  
/*****************************************************************************/
/*****************************************************************************/
   
static void get_file_header (char *data_file, char *header, int max_size)
   {
   FILE *file = fopen (data_file,"r");
   int index = 0,len;
   char string[300];

   if (!header || !data_file || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
      {
      if (string[0] != '!')
         {
         string[0] = 0;
         break;
         }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         if ((index + len) < max_size)
            {
            strcat (header, string);
            index += len;
            }
         else
            break;

         fgets (string,299,file);
         break;
         }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else
         break;
      }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if (len > 0)
      {
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else if ((max_size - index) == 1);
      else
         {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
         }
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, OPT_PARAMETER *params, FIXED_PARAMETERS fixed)
   {
   FILE *file;
   unsigned i;
   unsigned count = 0;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   
   /* write final optimization parameter values */

   file = fopen (end_file,"w+");
   if (!file)
      {
      fprintf (stderr, "Error: unable to open file for writing.\n");
      return -1;
      }

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (file);

   /* write the model parameter file */

   // non-optimized parameters
   names[num_p] = "Ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "Ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "Tnom"; values[num_p] = fixed.tnom; ++num_p;
   names[num_p] = "Rg"; values[num_p] = fixed.rg + fixed.ri; ++num_p;  // there is no Ri in the model
   names[num_p] = "Rd"; values[num_p] = fixed.rd; ++num_p;
   names[num_p] = "Rs"; values[num_p] = fixed.rs; ++num_p;
   names[num_p] = "Cds"; values[num_p] = fixed.cds; ++num_p;
   names[num_p] = "Tau"; values[num_p] = fixed.tau; ++num_p;
   names[num_p] = "Is"; values[num_p] = fixed.is; ++num_p;
   names[num_p] = "Eta"; values[num_p] = fixed.n; ++num_p;
   names[num_p] = "Ilk"; values[num_p] = fixed.ibd; ++num_p;
   names[num_p] = "Plk"; values[num_p] = fixed.vbd; ++num_p;
   names[num_p] = "Lg"; values[num_p] = fixed.lg; ++num_p;
   names[num_p] = "Ld"; values[num_p] = fixed.ld; ++num_p;
   names[num_p] = "Ls"; values[num_p] = fixed.ls; ++num_p;
   // extra fixed parasitics (not part of the TOM3 model) - Tau2 is not used
   /*
   names[num_p] = "C1"; values[num_p] = fixed.c1; ++num_p;
   names[num_p] = "C2"; values[num_p] = fixed.c2; ++num_p;
   names[num_p] = "C11"; values[num_p] = fixed.c11; ++num_p;
   names[num_p] = "C22"; values[num_p] = fixed.c22; ++num_p;
   */

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      names[num_p] = params[i].name;
      values[num_p] = params[i].nom;
      ++num_p;
      }

   file = fopen (model_file,"w+");
   if (!file)
      {
      fprintf (stderr, "Error: unable to open file for writing.\n");
      return -1;
      }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");

   write_model_param_mdif (file, names, values, num_p, 12, 5);
   
   fclose (file);
      
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void write_model_param_mdif (FILE *file, char *names[], double *values, unsigned n, unsigned width, unsigned cols)
   {
   unsigned i = 0;
   unsigned j;
   unsigned tmp;
   char txt_fmt[20];
   char num_fmt[20];

   if (!file || !n || !cols || !width)
      return;

   sprintf (txt_fmt, "%%-%ds ", width);
   sprintf (num_fmt, "%%-%d.3e ", width);

   fprintf (file, "BEGIN BDTA\n");

   while (i < n)
      {
      tmp = i;

      fprintf (file, "%%\t");
      for (j = 0; j < cols; ++j, ++i)
         {
         if (i >= n)
            break;

         fprintf (file, txt_fmt, names[i]);
         }
      fprintf (file, "\n");

      fprintf (file, "\t");
      for (j = 0, i = tmp; j < cols; ++j, ++i)
         {
         if (i >= n)
            break;

         fprintf (file, num_fmt, values[i]);
         }
      fprintf (file, "\n");
      }

   fprintf (file, "END\n");
   }

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

static double tom3_ids (double *p, double vgs, double vds)
   {
   double vto    = p[0];
   double alpha  = p[1];
   double beta   = p[2];
   double lambda = p[3];
   double gamma  = p[4];
   double q      = p[5];
   double k      = p[6];
   double vst    = p[7];
   double mst    = p[8];
   double Vst,u,Vg,fk,I0,Ids;
   int flag = 0;

   if (vds < 0.0)
      {
      vgs = vgs - vds;
      vds = -vds;
      flag = 1;
      }

   Vst = vst * (1.0 + mst*vds);
   u = (vgs - vto + gamma*vds) / (q*Vst);
   Vg = q * Vst * log (1.0 + exp (u));
   fk = (alpha*vds) / pow (1.0 + pow (alpha*vds, k), 1.0/k);
   I0 = beta * pow (Vg, q) * fk;
   Ids = I0 * (1.0 + lambda*vds);

   if (flag)
      return -Ids;

   return Ids;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int subth_dciv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DC_DATA *d = (DC_DATA *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      if ((d->data[i].vds > 5.0) ||
         (d->data[i].vds < 0.1) || 
         (d->data[i].ids <= 0.0) ||
         (d->data[i].ids > 5.0e-6 * d->periphery))
         continue;

      diff = log (d->data[i].ids) - log (tom3_ids (p, d->data[i].vgs, d->data[i].vds));
      err[0] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int dciv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DC_DATA *d = (DC_DATA *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      if (d->data[i].vds > d->max_vds)
         continue;

      diff = d->data[i].ids - tom3_ids (p, d->data[i].vgs, d->data[i].vds);
      err[0] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static double bubble_average (double *values, unsigned n)
   {
   unsigned i,j;
   double temp;
   double delta;

   if (!n)
      return 0.0;
   else if (n == 1)
      return values[0];
   
   for (i = 0; i < n-1; ++i)
      {
      for (j = i+1; j < n; ++j)
         {
         if (values[j] < values[i])
            {
            temp = values[i];
            values[i] = values[j];
            values[j] = temp;
            }
         }
      }
   
   i = 0;
   temp = 0.0;
   delta = fabs (values[n/2])*0.25;
   for (j = 0; j < n; ++j)
      {
      if (fabs (values[j]-values[n/2]) < delta)
         {
         ++i;
         temp += values[j];
         }
      }
   
   return temp / ((double) i);
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params)
   {
   FILE *file;
   char string[200];
   int i = 0;

   /* read in the starting values */

   file = fopen (fname,"r");
   if (!file)
      {
      printf ("Error: Unable to open file %s.\n",fname);
      return -1;
      }
   
   while (fgets (string,199,file))
      {
      if (i >= n_params)
         break;

      if (sscanf (string,"%lf%lf%lf%lf%19s",&params[i].min,&params[i].nom,
         &params[i].max,&params[i].tol,params[i].name))
         {
         params[i].optimize = FALSE;
         ++i;
         }
      }
   fclose (file);

   if (i != n_params)
      {
      fprintf (stderr, "Error: missing parameter(s) in %s.\n",fname);
      return -1;
      }

   /* check for bad starting values or illegal range values 
      (i.e. parameters that must be >= 0) */


   




   /* set the min, max, and nom values to be legal */

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      if (params[i].max < params[i].min)
         params[i].max = params[i].min;
      if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static unsigned get_iv_curves (char *fname, int type, IV_DATA *d, unsigned max_pts, FIXED_PARAMETERS fixed_params)
   {
   FILE *file;
   char string[200];
   double vgs,vds,igs,ids;
   unsigned i = 0;
   
   file = fopen (fname,"r");
   if (!file)
      {
      fprintf (stderr, "Error: Unable to open file %s.\n",fname);
      return 0;
      }
      
   while (fgets (string,199,file))
      {      
      if (sscanf (string,"%lf%lf%lf%lf",&vds,&ids,&vgs,&igs) == 4)
         {
         if (i >= max_pts)
            {
            fprintf (stderr, "WARNING: too many data points in file %s.\n",fname);
            break;
            }
         
         switch (type)
            {
            case DC_IV_FILE:
               if ((1.0e6*igs/fixed_params.area) > MAX_FWD_IGS)
                  continue;

               d[i].vds = vds - fixed_params.rd*ids -
                  fixed_params.rs*(igs + ids);
               d[i].vgs = vgs - (fixed_params.rg + fixed_params.ri)*igs -
                  fixed_params.rs*(igs + ids);
               d[i].ids = ids;
               d[i].igs = igs;
               ++i;
               break;
               
            case FWD_IV_FILE:
               if (vds != 0.0)
                  continue;

               d[i].vgs = vgs;
               d[i].igs = igs;
               ++i;
               break;
               
            case BREAKDOWN_FILE:
               d[i].igs = -igs;
               d[i].vgs = (vds - ids*fixed_params.rd) -
                  (vgs - igs*fixed_params.rg);
               ++i;
               break;
               
            default:
               break;
            }
         }
      }
   fclose (file);
   
   return i;
   }

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, double periph, IV_DATA *dc, unsigned n_dc, AC_PARAMETERS *ac, unsigned n_ac,
                      OPT_PARAMETER *params, IV_DATA *fwd, unsigned n_fwd, IV_DATA *vbr, unsigned n_vbr,
                      FIXED_PARAMETERS fixed)
   {
   jPLOT_ITEM *plot1,*plot2,*plot3;
   unsigned i,j;
   static char *legend_t[] = {"Modeled","Measured"};
   static int  legend_l[] = {LT_SOLID,LT_DASHED};
   static int  legend_w[] = {1,1};
   static int  legend_c[] = {CLR_RED,CLR_BLUE};
   double p_list[NUM_PARAMS];
   char *plotfile;
   double *xdata1,*xdata2,*ymeas1,*ymeas2,*ymod1,*ymod2;   
   unsigned option_flags = 0;
   double vds;
   
   plot1 = create_plot_item (SingleY,2.5,1.1,5.5,4.5);
   plot2 = create_plot_item (SingleY,1.3,1.1,3.7,3.7);
   plot3 = create_plot_item (SingleY,6.3,1.1,3.7,3.7);
   
   deactivate_plot_item (plot2);
   deactivate_plot_item (plot3);
   
   set_axis_scales (plot1,NULL,POSITIVE_X | POSITIVE_Y1);
   set_axis_scales (plot2,NULL,POSITIVE_X | POSITIVE_Y1);
   set_axis_scales (plot3,NULL,POSITIVE_X | POSITIVE_Y1);
   
   plot2->attribs.ylabel_offset = 0.6;
   plot3->attribs.ylabel_offset = 0.6;
      
   for (i = 0; i < NUM_PARAMS; ++i)
      p_list[i] = params[i].nom;
   
   switch (dev)
      {
      case POSTSCRIPT:
         plotfile = "tom3.ps";
         break;
      
      case METAFILE:
         plotfile = "tom3.wmf";
         break;
      
      default:
         plotfile = NULL;   
      }

   // add_text (header,5.5,7.9,FNT_TIMES,12,0.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_legend (2,8.0,6.5,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);
   
   if (!open_graphics_device (dev, plotfile))
      {
      printf ("open_graphics_device() failed\n");
      return -1;
      }
   
   /************ plot sub-threshold current *******/

   xdata1 = (double *) malloc (sizeof (double) * n_dc);
   ymeas1 = (double *) malloc (sizeof (double) * n_dc);
   ymod1  = (double *) malloc (sizeof (double) * n_dc);
   
   for (j = 0, vds = 1.0; vds < 5.1; vds += 1.0)
      {
      for (i = 0; i < n_dc; ++i)
         {
         if ((fabs (dc[i].vds - vds) < 0.09) && (dc[i].ids > 0.0) && (dc[i].ids < 5.0e-6*periph))
            {
            xdata1[j] = dc[i].vgs;
            ymeas1[j] = dc[i].ids * 1.0e6 / periph;
            ymod1[j] = tom3_ids (p_list, dc[i].vgs, dc[i].vds) * 1.0e6 / periph;
            ++j;
            }
         }
      }
   
   attach_y1data (plot1, xdata1, ymod1, j, LT_SOLID, 1, CLR_RED);
   attach_y1data (plot1, xdata1, ymeas1, j, LT_DASHED, 1, CLR_BLUE);
   
   set_axis_labels (plot1, "Vgs (volts)", "Ids (mA/mm)", "", "Subthreshold Curves");
   set_axis_scaling (plot1, LogY1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
      
   free ((void *) xdata1);
   free ((void *) ymeas1);   
   free ((void *) ymod1);   

   /************ plot IV curves ****************/
   
   xdata1 = (double *) malloc (sizeof (double) * n_dc);
   ymeas1 = (double *) malloc (sizeof (double) * n_dc);
   ymod1  = (double *) malloc (sizeof (double) * n_dc);
   
   for (i = 0; i < n_dc; ++i)
      {
      xdata1[i] = dc[i].vds;
      ymeas1[i] = dc[i].ids * 1.0e6 / periph;
      ymod1[i] = tom3_ids (p_list, dc[i].vgs, dc[i].vds) * 1.0e6 / periph;
      }
   
   attach_y1data (plot1, xdata1, ymod1, n_dc, LT_SOLID, 1, CLR_RED);
   attach_y1data (plot1, xdata1, ymeas1, n_dc, LT_DASHED, 1, CLR_BLUE);
   
   set_axis_labels (plot1, "Vds (volts)", "Ids (mA/mm)", "", "IV Curves");
   set_axis_scales (plot1,NULL,POSITIVE_X | POSITIVE_Y1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   deactivate_plot_item (plot1);
   
   free ((void *) xdata1);
   free ((void *) ymeas1);   
   free ((void *) ymod1);
   
   /*************** done ****************/
   
   close_graphics_device ();
   
   return 0;
   }


