#include <stdio.h>
#include <string.h>
#include <time.h>

void get_the_time ();
int string_index ();

main ()
{
  FILE  *batch_job_file;
  FILE  *tmp_file;
  char  buffer[201];
  char  current_time[80];
  char  batch_job_file_name[201];
  char  batch_log_file_name[201];
  char  tmp_file_name[201];
  char  system_command[201];
  char  files_to_fit[201];
  char  in_file[201];
  char  out_file[201];
  char  out_file2[201];
  char  direct_freq[201];
  char  ibe_range[201];
  char  r_range[201];
  char  l_range[201];
  char  cbc_range[201];
  char  cbc_volt[201];
  char  cbe_range[201];
  char  cbe_volt[201];
  char  vce_tf[201];
  char  tf_ice[201];
  char  tf_range[201];
  char  cmax_searches[201];
  char  fwd_file[201];
  char  fwd_vce[201];
  char  fwd_volt[201];
  char  fwd_range[201];
  char  rev_file[120];
  char  rev_vbc[120];
  char  rev_volt[20];
  char  rev_range[20];
  char  temperature[20];
 
  printf ("START PARA. & CAP PARAMETERS FILE?\n");
  gets (in_file);

  printf ("FINISH PARA. & CAP. PARAMETERS FILE?\n");
  gets (out_file);

  printf ("FINISH IV PARAMETERS FILE?\n");
  gets (out_file2);

  printf ("MEASUREMENT & EXTRACTION TEMPERATURE?\n");
  gets (temperature);

  printf("1/IBE(A) RANGE FOR PARA. (START STOP STEP TICK)?\n");
  gets (ibe_range);

  printf("R(OHM) RANGE FOR PARA. (START STOP STEP TICK)?\n");
  gets (r_range);

  printf("L(pH) RANGE FOR PARA. (START STOP STEP TICK)?\n");
  gets (l_range);

  printf("FREQ FOR PARA. & CAP. EXTRACTION (MIN & MAX in GHZ)?\n");
  gets (direct_freq);

  printf ("MAXIMUM NUMBER OF CAP. LINE SEARCHES?\n");
  gets (cmax_searches);

  printf("VBC RANGE FOR CBC (START STOP STEP TICK)?\n");
  gets (cbc_volt);

  printf("CBC(pF) RANGE (START STOP STEP TICK)?\n");
  gets (cbc_range);

  printf("VBE RANGE FOR CBE (START STOP STEP TICK)?\n");
  gets (cbe_volt);

  printf("CBE(pF) RANGE (START STOP STEP TICK)?\n");
  gets (cbe_range);

  printf ("SPAR FILE NAMES FOR FT (must contain wildcards)?\n");
  gets (files_to_fit);

  printf("VCE FOR TF EXTRACTION?\n");
  gets (vce_tf);
  
  printf("1/ICE(A) RANGE FOR TF (START STOP STEP TICK)?\n");
  gets (tf_ice);
  
  printf("1/FT(GHZ) RANGE (START STOP STEP TICK)?\n");
  gets (tf_range);
  
  printf ("FWD GUMMEL FILE?\n");
  gets (fwd_file);

  printf ("REV GUMMEL FILE?\n");
  gets (rev_file);

  printf ("VCE FOR FWD IV EXTRACTION? (MIN MAX)\n");
  gets (fwd_vce);

  printf ("VBC FOR REV IV EXTRACTION? (MIN MAX)\n");
  gets (rev_vbc);

  printf("VCE RANGE FOR FWD (START STOP STEP TICK)?\n");
  gets (fwd_volt);

  printf("VBC RANGE FOR REV (START STOP STEP TICK)?\n");
  gets (rev_volt);

  printf("ICE & IBE(A) RANGE FOR FWD (START STOP TICK)?\n");
  gets (fwd_range);

  printf("ICE & IBC(A) RANGE FOR REV (START STOP TICK)?\n");
  gets (rev_range);

  get_the_time (current_time);

  sprintf (batch_job_file_name,"batch_job_file.%s",current_time);
  sprintf (batch_log_file_name,"batch_log_file.%s",current_time);
  sprintf (tmp_file_name,"tmp_file.%s",current_time);

  sprintf (system_command,"rm -f %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1 c00*.dm2 > %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",tmp_file_name);
  system (system_command);

  batch_job_file = (FILE*) NULL;
  batch_job_file = fopen (batch_job_file_name,"w+");
  if ( batch_job_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s\n",batch_job_file_name);
      exit (1);
    }   
/* START PARASITIC EXTRACTION */
  fprintf (batch_job_file,"hot_hbt_v4 << input\n");
  fprintf (batch_job_file,"%s\n",in_file);
  fprintf (batch_job_file,"%s\n",out_file);
  fprintf (batch_job_file,"%s\n",ibe_range);
  fprintf (batch_job_file,"%s\n",r_range);
  fprintf (batch_job_file,"%s\n",l_range);
  tmp_file = (FILE*) NULL;
  tmp_file = fopen (tmp_file_name,"r");
  if ( tmp_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s\n",tmp_file_name);
      exit (1);
    }
  while (fgets (buffer,1024,tmp_file) != NULL)
    {
    fprintf (batch_job_file,"%s",buffer);
    }
  fclose(tmp_file);
  fprintf (batch_job_file,"%s\n",direct_freq);
  fprintf (batch_job_file,"10\n");  
  fprintf (batch_job_file,"input\n");
  fprintf (batch_job_file,"mv postscript.dat para.ps\n");
/* STOP PARASITIC EXTRACTION */

/* START GUMMEL EXTRACTION */
  fprintf (batch_job_file,"gummel_fit_v2 << input\n");
  fprintf (batch_job_file,"%s\n",fwd_file);
  fprintf (batch_job_file,"%s\n",rev_file);
  fprintf (batch_job_file,"para.out\n");
  fprintf (batch_job_file,"%s\n",out_file2);
  fprintf (batch_job_file,"%s\n",temperature);
  fprintf (batch_job_file,"%s\n",fwd_vce);
  fprintf (batch_job_file,"%s\n",rev_vbc);
  fprintf (batch_job_file,"%s\n",fwd_volt);
  fprintf (batch_job_file,"%s\n",rev_volt);
  fprintf (batch_job_file,"%s\n",fwd_range);
  fprintf (batch_job_file,"%s\n",rev_range);
  fprintf (batch_job_file,"10\n");
  fprintf (batch_job_file,"input\n");
  fprintf (batch_job_file,"mv postscript.dat gummel.ps\n");
/* STOP GUMMEL EXTRACTION */

/* START CAPACITANCE EXTRACTION */  
  fprintf (batch_job_file,"cbc_fit_v3 << input\n");
  fprintf (batch_job_file,"para.out\n");
  fprintf (batch_job_file,"%s\n",in_file);
  fprintf (batch_job_file,"%s\n",out_file);
  fprintf (batch_job_file,"%s\n",direct_freq);
  fprintf (batch_job_file,"%s\n",cmax_searches);
  fprintf (batch_job_file,"%s\n",cbc_volt);
  fprintf (batch_job_file,"%s\n",cbc_range);
  sprintf (system_command,"rm -f %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1r cbcm*.dm2 > %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",tmp_file_name);
  system (system_command);
  tmp_file = (FILE*) NULL;
  tmp_file = fopen (tmp_file_name,"r");
  if ( tmp_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s\n",tmp_file_name);
      exit (1);
    }
  while (fgets (buffer,1024,tmp_file) != NULL)
    {
    fprintf (batch_job_file,"%s",buffer);
    }
  fclose(tmp_file);
  sprintf (system_command,"rm -f %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1 cbcp*.dm2 > %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",tmp_file_name);
  system (system_command);
  tmp_file = (FILE*) NULL;
  tmp_file = fopen (tmp_file_name,"r");
  if ( tmp_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s",tmp_file_name);
      exit (1);
    }
  while (fgets (buffer,1024,tmp_file) != NULL)
    {
    fprintf (batch_job_file,"%s",buffer);
    }
  fclose(tmp_file);
  fprintf (batch_job_file,"STOP\n");  
  fprintf (batch_job_file,"10\n");  
  fprintf (batch_job_file,"input\n");
  fprintf (batch_job_file,"mv postscript.dat cbc.ps\n");

  fprintf (batch_job_file,"cbe_fit_v3 << input\n");
  fprintf (batch_job_file,"para.out\n");
  fprintf (batch_job_file,"%s\n",in_file);
  fprintf (batch_job_file,"%s\n",out_file);
  fprintf (batch_job_file,"%s\n",direct_freq);
  fprintf (batch_job_file,"%s\n",cmax_searches);
  fprintf (batch_job_file,"%s\n",cbe_volt);
  fprintf (batch_job_file,"%s\n",cbe_range);
  sprintf (system_command,"rm -f %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1r cbem*.dm2 > %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",tmp_file_name);
  system (system_command);
  tmp_file = (FILE*) NULL;
  tmp_file = fopen (tmp_file_name,"r");
  if ( tmp_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s\n",tmp_file_name);
      exit (1);
    }
  while (fgets (buffer,1024,tmp_file) != NULL)
    {
    fprintf (batch_job_file,"%s",buffer);
    }
  fclose(tmp_file);
  sprintf (system_command,"rm -f %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1 cbep*.dm2 > %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",tmp_file_name);
  system (system_command);
  tmp_file = (FILE*) NULL;
  tmp_file = fopen (tmp_file_name,"r");
  if ( tmp_file == (FILE*) NULL)
    {
      printf ("** error ** cannot open file %s",tmp_file_name);
      exit (1);
    }
  while (fgets (buffer,1024,tmp_file) != NULL)
    {
    fprintf (batch_job_file,"%s",buffer);
    }
  fclose(tmp_file);
  fprintf (batch_job_file,"STOP\n");  
  fprintf (batch_job_file,"10\n");  
  fprintf (batch_job_file,"input\n");
  fprintf (batch_job_file,"mv postscript.dat cbe.ps\n");
/* STOP CAPACITANCE EXTRACTION */

/* START TF EXTRACTION */  
  sprintf (system_command,"rm -f %s",tmp_file_name);
  system (system_command);
  sprintf (system_command,"ls -1 %s > %s",files_to_fit,tmp_file_name);
  system (system_command);
  sprintf (system_command,"chmod 777 %s",tmp_file_name);
  system (system_command);
  fprintf (batch_job_file,"calc_tf_v2 << input\n");
  fprintf (batch_job_file,"%s\n",tmp_file_name);  
  fprintf (batch_job_file,"ft.out\n");
  fprintf (batch_job_file,"%s\n",out_file);
  fprintf (batch_job_file,"%s\n",vce_tf);
  fprintf (batch_job_file,"%s\n",tf_ice);
  fprintf (batch_job_file,"%s\n",tf_range);
  fprintf (batch_job_file,"10\n");
  fprintf (batch_job_file,"input\n");
  fprintf (batch_job_file,"mv postscript.dat tf.ps\n");
/* STOP TF EXTRACTION */

  fprintf (batch_job_file,"cat_ps << input\n");
  fprintf (batch_job_file,"*.ps\n");  
  fprintf (batch_job_file,"input\n");

  fprintf (batch_job_file,"rm -f %s\n",batch_job_file_name);  
  fclose (batch_job_file);

  sprintf (system_command,"chmod +x %s",batch_job_file_name);
  system (system_command);
  
  sprintf (system_command,"%s &",batch_job_file_name);
  system (system_command); 
}

/*                                                                   */
/*--- Function string_index -----------------------------------------*/
/*                                                                   */

int string_index (string1,string2)
char   string1[];
char   string2[];

{
int    n1;
int    n2;
int    i;

n1 = strlen (string1);
n2 = strlen (string2);

for (i = 0; i <= (n1-n2); ++i)
   {
   if (strncmp (&(string1[i]),string2,n2) == 0)
      {
      return (i);
      }
   }

return (-1);

}
/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);

return;

}
