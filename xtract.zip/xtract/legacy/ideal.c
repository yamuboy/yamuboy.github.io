#include <stdio.h>
#include <stdlib.h>

int main ()
{
FILE *outfile;
char out_name[200];
double start,stop,step;
double f,m1,a1,m2,a2,m3,a3,m4,a4;

printf ("start stop step (GHz)? >");
scanf ("%lf %lf %lf",&start,&stop,&step);

printf ("output file name? >");
scanf ("%s",out_name);

m1 = (double) 0.0;
a1 = (double) 0.0;
m2 = (double) 1.0;
a2 = (double) 0.0;
m3 = (double) 1.0;
a3 = (double) 0.0;
m4 = (double) 0.0;
a4 = (double) 0.0;

outfile = fopen (out_name,"w+");

for (f = start; f < (stop+((double) 0.5)*step); f += step)
   {
   fprintf (outfile,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",((double) 1.0e+9)*f,m4,a4,m3,a3,m2,a2,m1,a1);
   }

fclose (outfile);

exit (0);

}
