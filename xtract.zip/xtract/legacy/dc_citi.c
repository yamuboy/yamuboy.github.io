#include <stdio.h>
#include <string.h>
#include <math.h>

int find_index ();
void bubble_sort ();
main ()
{
double vds,ids,vgs,igs;
FILE  *in_file;
FILE  *out_file;
char  in_name[201];
char  header[50][201];
char  buffer[201];
int   header_done,total,num_lines;
int   i,n,j,k,num_vg,num_vd,counter;
double vd[64];
double vg[64];
int tt[64][64];
double z[3200][4];
double t[3200][4];

printf ("dc iv file name?\n");
scanf ("%200s",in_name);
n=0;
header_done = 0;
in_file  = (FILE*) NULL;
out_file = (FILE*) NULL;

in_file = fopen (in_name,"r");
if ( in_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",in_name);
   }
out_file = fopen ("dciv.citi","w+");

if ( out_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file dciv.citi\n");
   fclose (in_file);
   }

for (i=0;i<64;i=i+1)
	  {
		  for (j=0;j<64;j=j+1)
		  {
			  tt[i][j] = 0;
		  }
	  }
i=0;
j=0;
k=0;
while (fgets (buffer,200,in_file) != NULL)
   {
   if ((header_done != 1) && (buffer[0] == '!'))
      {
      strcpy (header[n],buffer);
      ++n;
      }
   else 
   {
	  header_done = 1;
      sscanf (buffer,"%lf%lf%lf%lf",&vds,&ids,&vgs,&igs);
	  z[k][0] = vds;
	  z[k][1] = ids;
	  z[k][2] = vgs;
	  z[k][3] = igs;
      k = k+1;
      if ((find_index(vds,vd,i) == -1) && (find_index(vgs,vg,j) == -1))
	  {
		  tt[i][j] = 1;
		  vd[i] = vds;
		  vg[j] = vgs;
		  i=i+1;
		  j=j+1;
	  }
	  else if ((find_index(vds,vd,i) == -1) && (find_index(vgs,vg,j) != -1))
	  {
		  tt[i][find_index(vgs,vg,j)] = 1;
		  vd[i] = vds;
		  i = i+1;
	  }
	  else if ((find_index(vds,vd,i) != -1) && (find_index(vgs,vg,j) == -1))
	  {
		  tt[find_index(vds,vd,i)][j] = 1;
		  vg[j] = vgs;
		  j = j+1;
	  }
	  else
	  {
		  tt[find_index(vds,vd,i)][find_index(vgs,vg,j)] = 1;
	  }
   }
}
   num_lines = k;
   num_vg = j;
   num_vd = i;
   counter = 0;
   for (i=0;i<num_vd;i++)
   {
		for (j=0;j<num_vg;j++)
		{
			if (tt[i][j] == 0)
			{
				vg[j] = (double) 100.0;
			}
		}
   }
   bubble_sort(vd,num_vd);
   bubble_sort(vg,num_vg);
   for (i=0;i<num_vg;i++)
   {
	   if (vg[i] != (double) 100.0)
	   {
		   counter = counter + 1;
	   }
   }
num_vg = counter;
total = 0;
for (i=0;i<num_lines;i++)
{
for (j=0;j<num_vg;j++)
{
	if (z[i][2] == vg[j]) {
		t[i][0] = z[i][0];
		t[i][1] = z[i][1];
		t[i][2] = z[i][2];
		t[i][3] = z[i][3];
		total = total+1;
	}
}
}
/* for (i=0;i<total;i++)
{
	fprintf(out_file,"%+.4e\t%+.4e\t%+.4e\t%+.4e\n",t[i][0],t[i][1],t[i][2],t[i][3]);
}
*/
for (i = 0; i < n; ++i)
    {
     fprintf (out_file,"# %s",header[i]);
     }
fprintf(out_file,"CITIFILE A.01.00\n");
fprintf(out_file,"NAME MEAS_DATA\n");
fprintf(out_file,"VAR X MAG %d\n",num_vg);
fprintf(out_file,"VAR X1 MAG %d\n",num_vd);

fprintf(out_file,"DATA VDS MA\n");
fprintf(out_file,"DATA IDS MA\n");
fprintf(out_file,"DATA VGS MA\n");
fprintf(out_file,"DATA IGS MA\n");

fprintf(out_file,"VAR_LIST_BEGIN\n");
for (i=0;i<num_vg;i++) {
fprintf(out_file, "%+.4e\n", vg[i]);
}
fprintf(out_file,"VAR_LIST_END\n");
fprintf(out_file,"VAR_LIST_BEGIN\n");
for (i=0;i<num_vd;i++) {
fprintf(out_file, "%+.4e\n", vd[i]);
}
fprintf(out_file,"VAR_LIST_END\n");
for (j=0;j<4;j++) {
  fprintf(out_file,"BEGIN\n");
  for (i=0;i<total;i++) {
    fprintf(out_file, "%+.4e\n", t[i][j]);
    }
  fprintf(out_file,"END\n");
}

fclose(out_file);
}

int find_index (v,vs,k)
double v;
double   vs[];
int k;
{
int    i;

for (i=0;i<k;++i)
   {
   if (vs[i] == v)
      {
      return (i);
      }
   }

return (-1);

}

void bubble_sort (array,n)
double array[];
int   n;
{
int   i;
int   j;
double temp;

for (i = 0; i < n - 1; i++)
   {
   for (j = i + 1; j < n; j++)
      {
      if (array[i] > array[j])
         {
         temp     = array[i];
         array[i] = array[j];
         array[j] = temp;
         }
      }
   }

return;

}
