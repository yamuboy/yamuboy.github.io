#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "jplot.h"

#define MAX_DEVICES  24
#define MAX_IV_PTS  100

#define BOLTZ         1.3806226e-23
#define CHARGE        1.6021918e-19
#define STDTEMP       300.0

main (int argc, char *argv[])
   {
   char string[200];
   char gfile[100];
   char filename[256];
   char fname[MAX_DEVICES][40];
   char mname[MAX_DEVICES][40];
   char wname[MAX_DEVICES][40];
   char legtext[MAX_DEVICES][256];
   char *plegtext[MAX_DEVICES];
   int modelnum[MAX_DEVICES];
   int i,j,n,gdevice;
   double vgsiv[MAX_IV_PTS];
   double igsiv[MAX_DEVICES][MAX_IV_PTS];
   double i1[MAX_DEVICES];
   double n1[MAX_DEVICES];
   double ibr[MAX_DEVICES];
   double nbr[MAX_DEVICES];
   double vbr[MAX_DEVICES];
   double v,vstart,vstop,vstep;  
   FILE *file; 
   jPLOT_ITEM *plot1;

   static int linetypes[] = {0,0,0,0,0,0,1,1,1,1,1,1,2,2,2,2,2,2,3,3,3,3,3,3};
   static int linecolors[] = {2,3,4,6,10,14,2,3,4,6,10,14,2,3,4,6,10,14,2,3,4,6,10,14};
   static int linewidths[] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
   
   /************ get information ***************/
   
   printf ("Breakdown profile file?\n");
   fgets (string,199,stdin);
   sscanf (string,"%255s",filename);

   printf ("Voltage Start Stop Step?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf%lf",&vstart,&vstop,&vstep);
   
   printf ("Graphics device?\n");
   printf ("   1 : X-WINDOWS\n");
   printf ("   2 : METAFILE\n");
   printf ("   3 : POSTSCRIPT\n> ");
   fgets (string,199,stdin);
   sscanf (string,"%d",&gdevice);
   
   if ((gdevice < 1) || (gdevice > 3))
      gdevice = 1;
   
   gfile[0] = 0;
   if (gdevice != 1)
      {
      printf ("Graphics output file name?\n");
      fgets (string,199,stdin);
      sscanf (string,"%99s",gfile);
      }
   
   /************ read data from file ***********/
   
   file = fopen (filename,"r");
   if (!file)
      {
      printf ("ERROR: file does not exist.\n");
      return -1;
      }

   i = -1;      
   while (fgets (string,199,file))
      {
      if (!strncmp (string,"!FILE NAME:",11))
         {
         ++i;
         
         if (i >= MAX_DEVICES)
            {
            printf ("Warning: MAX_DEVICES reached.\n");
            --i;
            break;
            }
            
         sscanf (string,"!FILE NAME:%39s",fname[i]);
         }
      else if (!strncmp (string,"!MASK NAME:",11))
         sscanf (string,"!MASK NAME:%39s",mname[i]);
      else if (!strncmp (string,"!WAFER NUMBER:",14))
         sscanf (string,"!WAFER NUMBER:%39s",wname[i]);
      else if (!strncmp (string,"model",5))
         sscanf (string,"model =%d",&modelnum[i]);
      else if (!strncmp (string,"i1",2))
         sscanf (string,"i1 =%lf",&i1[i]);
      else if (!strncmp (string,"n1",2))
         sscanf (string,"n1 =%lf",&n1[i]);
      else if (!strncmp (string,"ibr",3))
         sscanf (string,"ibr =%lf",&ibr[i]);
      else if (!strncmp (string,"nbr",3))
         sscanf (string,"nbr =%lf",&nbr[i]);
      else if (!strncmp (string,"vbr",3))
         sscanf (string,"vbr =%lf",&vbr[i]); 
      }

   n = i+1;
   fclose (file);
   
   /*********** time to plot ************/

   if (!open_graphics_device (gdevice,gfile))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }
   
   plot1 = create_plot_item (SingleY,1.25,1.25,8.5,6.0);
      
   for (i = 0; i < n; ++i)
      {
      for (v = vstart, j = 0; v <= vstop; v += vstep, ++j)
         {
         if (j >= MAX_IV_PTS)
            {
            printf ("Error: too many voltage points - MAX_IV_PTS exceeded.\n");
            exit (-1);
            }
            
         igsiv[i][j] = i1[i] * ( exp(CHARGE*v/(BOLTZ*STDTEMP*n1[i])) - 1.0) + ibr[i] * pow (v/vbr[i],nbr[i]);
         igsiv[i][j] *= 1000.0;
         vgsiv[j] = v;
         }
         
      attach_y1data (plot1,vgsiv,igsiv[i],j,linetypes[i],linewidths[i],linecolors[i]);
      }

   set_axis_scaling (plot1,LogY1);

   set_axis_labels (plot1,"Vdg (volts)","Idg (A/mm)","","Breakdown Characteristics");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }
   
   deactivate_plot_item (plot1);
   
   for (i = 0; i < n; ++i)
      {
      sprintf (legtext[i],"%d  %s  %s  %s",modelnum[i],mname[i],wname[i],fname[i]);
      plegtext[i] = legtext[i];
      }
   
   add_legend (n,1.5,7.75,plegtext,FNT_COURIER,12,linetypes,linewidths,linecolors);
   add_text ("Legend",2.0,7.9,FNT_COURIER,16,0.0,JUST_LEFT,CLR_BLACK,TS_NONE);

   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   close_graphics_device ();
   
   return 0;
   }
