#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main ()

{
double   vlow,vhigh,ilow,ihigh;
double   rg,rd,area;
double   vgs,vds,ids,igs;
double   vbd[1000],ibd[1000];
double   Vt,Is;
double   value;
int      i;
int      first;
char     string[201];
char     file_name[201];
char     file_name2[201];
FILE     *file1;
FILE     *file2;

printf ("Vbr File > ");
scanf ("%s",file_name);

printf ("Parker model file > ");
scanf ("%s",file_name2);

printf ("Device Area > ");
scanf ("%lf",&area);

file1 = fopen (file_name2,"r");
if (file1 == NULL)
   {
   printf ("ERROR: unable to open model file.\n");
   return (0);
   }

file2 = fopen ("tmp_11223344","w+");

i = 0;
while (fgets (string,200,file1) != NULL)
   {
   if (sscanf (string,"rg = %lf",&value) == 1)
      {
      rg = value;
      ++i;
      }
   else if (sscanf (string,"rd = %lf",&value) == 1)
      {
      rd = value;
      ++i;
      }
   else if (sscanf (string,"ibd = %lf",&value) == 1)
      {
      break;
      }
   fprintf (file2,"%s",string);
   }
fclose (file1);

if (i != 2)
   {
   printf ("ERROR: incomplete starting values file.\n");
   fclose (file2);
   sprintf (string,"rm -f tmp_11223344");
   system (string);
   return (0);
   }

file1 = fopen (file_name,"r");
if (file1 == NULL)
   {
   printf ("ERROR: unable to open vbr file\n");
   return (0);
   }

i = 0;
while (fgets (string,200,file1) != NULL)
   {
   if (string[0] != '!')
      {
      if (sscanf (string,"%lf %lf %lf %lf",&vds,&ids,&vgs,&igs) == 4)
         {
         if (vds != (double) 0.0)
            {
            continue;
            }
	 else if (fabs (igs) <= ((double) 1.0e-8)*area)
	    {
	    continue;
	    }
         vbd[i] = -vgs+rg*igs-rd*ids;
         ibd[i] = -igs;
         ++i;
         }
      }
   }
fclose (file1);

if (i < 2)
   {
   printf ("ERROR: not enough points.\n");
   fclose (file2);
   sprintf (string,"rm -f tmp_11223344");
   system (string);
   return (0);
   }

vhigh = vbd[i-1];
ihigh = ibd[i-1];

i = 0;
while (vbd[i] <= ((double) 0.6)*vhigh)
   {
   ++i;
   }

vlow = vbd[i];
ilow = ibd[i];
if (vlow == vhigh)
   {
   vlow = vbd[i-1];
   ilow = ibd[i-1];
   }

Is = exp ((vhigh*log (ilow)-vlow*log(ihigh))/(vhigh-vlow));
Vt = ((double) 1.0)/((log (ihigh)-log (ilow))/(vhigh-vlow));

fprintf (file2,"ibd    =  %.4e\n",Is/area*((double) 0.5));
fprintf (file2,"vbd    =  %.4e\n",Vt);

file1 = fopen (file_name2,"r");
first = 0;
while (fgets (string,200,file1) != NULL)
   {
   if (sscanf (string,"vbd = %lf",&value) == 1)
      {
      first = 1;
      }
   else if (first)
      {
      fprintf (file2,"%s",string);
      }
   }
fclose (file1);
fclose (file2);

sprintf (string,"mv tmp_11223344 %s",file_name2);
system (string);

printf ("Ibd = %.5e\n",Is/area*((double) 0.5));
printf ("Vbd = %.5e\n",Vt);

return (0);

}
