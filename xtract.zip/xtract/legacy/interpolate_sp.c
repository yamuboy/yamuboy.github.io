#include <stdio.h>
#include <string.h>
#include <time.h>

int main ()
{
char     string[256],extension[21];
FILE     *file1,*file2,*batch1;
char     file_name[81],filenames[81],batch_file_name[81],Format[10],output_file_name[81];
double   freq[1000],sp[1000][8],f_low,f_high,s_result[8],freq_list[1000];
double   start_f,stop_f,step_f,freq1,angle_high,angle_low;
time_t   current_t;
int      i,j,found,extrap,ptr_inc;
int      num_f,num_f_file;
double   *s_low,*s_high,*s_base;

s_base = sp;
ptr_inc = 8;

printf ("WARNING: This program requires 2-port S-parameter data in MAG/ANGLE format\n");
printf ("The frequency specification in the file(s) must be in HZ.\n");
printf ("NO CHECK OF THIS IS DONE!!!!\n\n"); 

printf ("File(s) to interpolate?\n");
gets (string);
sscanf (string,"%80s",filenames);

printf ("Frequency List - Start Stop Step (GHz)?\n");
gets (string);
if (sscanf (string,"%lf %lf %lf",&start_f,&stop_f,&step_f) != 3)
   {
   printf ("** error ** could not read start,stop,step values\n");
   exit (1);
   }

printf ("Extension for output file(s)?\n");
gets (string);
sscanf (string,"%20s",extension);

start_f *= (double) 1.0e9;
stop_f *= (double) 1.0e9;
step_f *= (double) 1.0e9;

num_f = 0;
for (freq1 = start_f; freq1 < stop_f + ((double) 1.0e4); freq1 += step_f)
   {
   freq_list[num_f] = freq1;
   ++num_f;
   
   if (num_f > 999)
      {
      printf ("** error ** more than 1000 frequencies selected for output\n");
      exit (1);
      }
   }

sprintf (batch_file_name,"batch-%ld",time (current_t));

sprintf (string,"ls -1 %s > %s",filenames,batch_file_name);
system (string);

batch1 = fopen (batch_file_name,"r");

while (fgets (file_name,80,batch1) != NULL)
   {
   file_name[strlen (file_name)-1] = '\0';
   
   file1 = (FILE *) NULL;
   file1 = fopen (file_name,"r");
   if (file1 == (FILE *) NULL)
      {
      printf ("** error ** unable to open file - %s\n",file_name);
      continue;
      }
      
   i = 0;      
   while (fgets (string,255,file1) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",
                          &freq[i],&sp[i][0],&sp[i][1],&sp[i][2],&sp[i][3],
                          &sp[i][4],&sp[i][5],&sp[i][6],&sp[i][7]) == 9)
         {
         ++i;
         
         if (i > 999)
            {
            printf ("** warning ** reached maximum 1000 frequency points in file %s, some points may be skipped\n",file_name);
            break;
            }
         }
      }
   num_f_file = i;
   fclose (file1);
      
   for (i = 0; i < strlen (file_name); ++i)
      {
      if (file_name[i] == '.')
         {
         break;
         }
      }
   if (i+1 == strlen (file_name))
      {
      sprintf (Format,"%%s%%s");
      }
   else
      {
      sprintf (Format,"%%.%ds%%s",i);
      }
      
   sprintf (output_file_name,Format,file_name,extension);
   file2 = fopen (output_file_name,"w+");
   
   fprintf (file2,"! Frequency interpolation from %.3e GHz to %.3e GHz\n",start_f*((double) 1.0e-9),stop_f*((double) 1.0e-9));
   fprintf (file2,"! Data from file: %s\n",file_name);
   fprintf (file2,"# HZ S MA R 50\n");

   for (i = 0; i < num_f; ++i)
      {
      extrap = 0;
      found = 0;

      /* parse freq list */
      for (j = 0; j < num_f_file; ++j)
         {
         if (freq_list[i] <= freq[j])
            {
            if (!j) /* desired freq interpolation is less than or equal to min freq in file */
               {
               extrap = -1;
               found = 1;
               }
            else
               {
               s_low = s_base+(j-1)*ptr_inc;
               s_high = s_base+j*ptr_inc;
               f_low = freq[j-1];
               f_high = freq[j];
               found = 1;
               }
            
            break;
            }
         }
      
      if (!found)
         {
         extrap = 1;
         }
      
      switch (extrap)
         {
         case 0: /* standard interpolation */
            break;
         case 1: /* high side extrapolation */
            printf ("** warning ** %.3e GHz is outside %s data range - using linear extrapolation\n",freq_list[i]*((double) 1.0e-9),file_name);
            s_low = s_base+(num_f_file-2)*ptr_inc;
            s_high = s_base+(num_f_file-1)*ptr_inc;
            f_low = freq[num_f_file-2];
            f_high = freq[num_f_file-1];
            break;
         case -1: /* low side extrapolation */
            printf ("** warning ** %.3e GHz is outside %s data range - using linear extrapolation\n",freq_list[i]*((double) 1.0e-9),file_name);
            s_low = s_base;
            s_high = s_base+ptr_inc;
            f_low = freq[0];
            f_high = freq[1];            
            break;
         default:
            break;
         }                        
            
      /* now do interpolation/extrapolation */
      
      for (j = 0; j < 8; ++j)
         {
         switch (j)
            {
            case 0:
            case 2:
            case 4:
            case 6:
               s_result[j] = (*(s_high+j)-*(s_low+j))*((freq_list[i]-f_low)/(f_high-f_low))+*(s_low+j);
               
               /* mag can't be less than zero */
               if (s_result[j] < (double) 0.0)
                  {
                  printf ("** warning ** %.3e GHz - magnitude was negative, changed to zero\n",freq_list[i]*((double) 1.0e-9));
                  s_result[j] = (double) 0.0;
                  }
               break;
            default:
               if ((*(s_high+j) < (double) 0.0)||(*(s_low+j) < (double) 0.0))
                  {
                  angle_high = ((double) 360.0)+*(s_high+j);
                  angle_low = ((double) 360.0)+*(s_low+j);
                  }
               else
                  {
                  angle_high = *(s_high+j);
                  angle_low = *(s_low+j);
                  }
               s_result[j] = (angle_high-angle_low)*((freq_list[i]-f_low)/(f_high-f_low))+angle_low;              
               
               /* reset angle to within +/-180 degrees */
               while (s_result[j] > (double) 180.0)
                  {
                  s_result[j] -= (double) 360.0;
                  }
               while (s_result[j] < (double) -180.0)
                  {
                  s_result[j] += (double) 360.0;
                  }
               break;
            }
         }
         
      fprintf (file2," %.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
                     freq_list[i],s_result[0],s_result[1],s_result[2],s_result[3],
                     s_result[4],s_result[5],s_result[6],s_result[7]);
      
      }
   
   fclose (file2);   
   }

sprintf (string,"rm %s",batch_file_name);
system (string);

}
