#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *index ();
void bubble_sort ();
int record_compare ();

main ()
{
time_t time_location;
float periphery;
FILE  *file_list;
FILE  *sum_file;
FILE  *mod_file;
char  mod_name[100];
char  buffer[2500];
char  string[80];
char  filenames[81];
char  *pointer;
char  *string_pointer;
char  *model_pointer[1000];
char  model[1000][197];
char  input_line[200];
char  new_line;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];
int   order[23];
int   i,j,n;

printf ("\n");
printf ("Model files to summarize?\n");
fgets (input_line,199,stdin);
input_line[strlen(input_line)-1] = 0;

sprintf (buffer,"ls -1 %s > model_files.list",input_line);
system (buffer);

printf ("Order for sorting precedence?   Choices are:\n");
printf ("\n");
printf ("    1. WAFER    7. IG      13. RI      19. CDS        \n");
printf ("    2. PROCESS  8. GGS     14. GM      20. CDG        \n");
printf ("    3. SIZE     9. GDG     15. T1      21. C11        \n");
printf ("    4. VDS     10. RG      16. GDS     22. LS         \n");
printf ("    5. IDS     11. RS      17. T2      23. C22        \n");
printf ("    6. VGS     12. RD      18. CGS                    \n");
printf ("\n");
printf ("Enter a negative value if you want to reverse the sort order.\n");
printf ("For example, -4 will sort VDS from high to low instead of\n");
printf ("low to high\n");
printf ("\n");
printf ("Default sort order is:    1 2 4 6 3\n");

fgets (input_line,199,stdin);
if ((input_line[0] == 0) || (input_line[0] == '\n'))
   strcpy (input_line,"1 2 4 6 3");

n = sscanf (input_line,
            "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
            &order[0],&order[1],&order[2],&order[3],&order[4],&order[5],
            &order[6],&order[7],&order[8],&order[9],&order[10],&order[11],
            &order[12],&order[13],&order[14],&order[15],&order[16],&order[17],
            &order[18],&order[19],&order[20],&order[21],&order[22]);

printf ("\n");
printf ("Separation lines every?   Choices are:\n");
printf ("\n");
printf ("    1. WAFER    7. IG      13. RI      19. CDS        \n");
printf ("    2. PROCESS  8. GGS     14. GM      20. CDG        \n");
printf ("    3. SIZE     9. GDG     15. T1      21. C11        \n");
printf ("    4. VDS     10. RG      16. GDS     22. LS         \n");
printf ("    5. IDS     11. RS      17. T2      23. C22        \n");
printf ("    6. VGS     12. RD      18. CGS                    \n");
printf ("\n");
printf ("<CR> = none\n");

new_line = 0;
fgets (input_line,199,stdin);
if (!(input_line[0] == 0) && !(input_line[0] == '\n'))
   sscanf (input_line,"%d",&new_line);

i = -1;

sum_file = fopen ("model.summary","w+");
time (&time_location);
string_pointer = asctime (localtime (&time_location));
sscanf (string_pointer+8,"%s",s_day);
sscanf (string_pointer+4,"%s",s_month);
sscanf (string_pointer+20,"%s",s_year);
sscanf (string_pointer+11,"%s",s_time);
sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);
fprintf (sum_file,"*\n");
fprintf (sum_file,
         "*    FET MODEL SUMMARY PROGRAM VERSION 3.05        %s\n",
         string);
fprintf (sum_file,"*\n");
fprintf (sum_file,"*                Periphery    Vds    Ids      Vgs      Ig     Ggs     Gdg     Rg     Rs     Rd     Ri      Gm     T1     Gds     T2     Cgs     Cds     Cdg     C11     Ls      C22\n");
fprintf (sum_file,"* Wafer  Process   (mm)     (volts)  (mA)   (volts)   (mA)    (mS)    (mS)  (Ohms) (Ohms) (Ohms) (Ohms)   (mS)   (pS)    (mS)   (pS)    (pF)    (pF)    (pF)    (pF)   (pH)     (pF)\n");

file_list = fopen ("model_files.list","r");
if (file_list == NULL)
   {
   printf ("ERROR: filelist not found\n");
   sprintf (buffer,"rm -f model_files.list");
   system (buffer);
   exit (-1);
   }
   
/*
!  MODEL FILE = wa0105090m200.mod         DATA FILE = wa0105090m200.dmb         
!  [S] IN = ideal                         [S] OUT = ideal                       
!  INPUT BOND =   26.25pH   OUTPUT BOND =   30.56pH
!  INPUT CAP  =   .0122pF   OUTPUT CAP  =   .0278pF
!
!    FET FITTING PROGRAM VERSION 3.05
!
!MASK NAME: pv43                                                                
!WAFER NUMBER: 40508                                                            
!PROCESS NAME: si1                                                              
!DEVICE NAME: 212                                                               
!GATE PERIPHERY (um): 200.0                                                     
!GATE LENGTH (um): 1.000                                                        
!UNIT GATE WIDTH (um): 100.0                                                    
!NUMBER OF GATE FINGERS: 2                                                      
!GATE TO GATE SPACING (um): 29/29                                               
!SOURCE-DRAIN SPACING (um): 3.0                                                 
!TEMPERATURE (C): 27.0                                                          
!DATE AND TIME: 18-Mar-1996 15:34:58                                            
!COMMENTS:                                                                      
!Vbr (.1mA)  Vbr (1mA)   Idss (3V)   Vpo (3V)   Imax (1.5V)  Vpo (1.5V) Vmax (1.5V)                 
!-1.0670e+01 -1.5945e+01 +3.7092e-02 -1.8451e+00 +6.3040e-02 -1.7984e+00 +7.9605e-01                
!
!  S11ERR=  .00 S21ERR=  .00 S12ERR=  .00 S22ERR=  .00 KERR=  .00 MAGERR=  .00
!
!    Vds    Ids     Vgs       Ig     Ggs     Gdg     Rg     Rs     Rd     Ri
!  (volts)  (mA)   (volts)   (mA)    (mS)    (mS)  (Ohms) (Ohms) (Ohms) (Ohms)
!   9.000    1.54  -2.000   -.003     .000    .000    .40   5.85   5.92  18.25
!
!    Gm     T1     Gds     T2     Cgs     Cds     Cdg     C11     Ls     C22
!   (mS)   (pS)    (mS)   (pS)    (pF)    (pF)    (pF)    (pF)   (pH)    (pF)
!    8.16  6.02     .835   .00   .1331   .0041   .0313   .0000    3.13   .0000
!
*/

while (fgets (mod_name,99,file_list) != NULL)
   {
   mod_name[strlen (mod_name)-1] = '\0';
   mod_file = fopen (mod_name,"r");

   if (mod_file == NULL)
      {
      continue;
      }

   ++i;
   string_pointer = model[i];

   fread (buffer,sizeof (char),2500,mod_file);
   fclose (mod_file);

   pointer = index (buffer,"WAFER NUMBER:") + 13;
   sscanf (pointer,"%s",string);
   sprintf (string_pointer,"  %-8.*s",strlen (string),string);
   string_pointer = string_pointer + 10;

   pointer = index (buffer,"PROCESS NAME:") + 13;
   sscanf (pointer,"%s",string);
   sprintf (string_pointer," %-8.*s",strlen (string),string);
   string_pointer = string_pointer + 9;

   pointer = index (buffer,"GATE PERIPHERY (um):") + 21;
   sscanf (pointer,"%f",&periphery);
   sprintf (string_pointer," %-6.3f",periphery*0.001);
   string_pointer = string_pointer + 7;

   pointer = index (buffer,"!  (volts)  (mA)")+1;
   pointer = index (pointer,"!")+2;
   sprintf (string_pointer," %.76s",pointer);
   string_pointer = string_pointer + 77;

   pointer = index (buffer,"!   (mS)   (pS)")+1;
   pointer = index (pointer,"!")+2;
   sprintf (string_pointer," %.76s\n",pointer);
   string_pointer = string_pointer + 78;
   }
fclose (file_list);

sprintf (buffer,"rm -f model_files.list");
system (buffer);

for (j = 0; j <= i; ++j)
   {
   model_pointer[j] = model[j];
   }

bubble_sort (model_pointer,i+1,order,n);

fprintf (sum_file,"%s",model_pointer[0]);

if (input_line[0] == '\0')
   {
   for (j = 1; j <= i; ++j)
      {
      fprintf (sum_file,"%s",model_pointer[j]);
      }
   }
else
   {
   sscanf (input_line,"%d",&order[0]);
   for (j = 1; j <= i; ++j)
      {
      if (record_compare (model_pointer[j],model_pointer[j-1],order,1) != 0)
         {
         fprintf (sum_file,"*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
         }
      fprintf (sum_file,"%s",model_pointer[j]);
      }
   }

fclose (sum_file);
}

/****************************************************************************************************/
/****************************************************************************************************/

char *index (buffer,string)
char buffer[];
char string[];
{
char *pointer;
int  length;

length = strlen (string);
pointer = buffer;

while (strncmp (pointer,string,length) != 0)
   {
   pointer = strchr (pointer+1,string[0]);
   if (pointer == NULL)
      {
      return (pointer);
      /*
      printf (" can't find string %s\n",string);
      exit (1);
      */
      }
   }

return (pointer);

}
 
/****************************************************************************************************/
/****************************************************************************************************/
 
void bubble_sort (array,n,order,m)
char  *array[];
int   n;
int   order[];
int   m;
{
char  *temp;
int   i;
int   j;

for (i = 0; i < n - 1; ++i)
   {
   for (j = i + 1; j < n; ++j)
      {
      if (record_compare (array[i],array[j],order,m) >= 0)
         {
         temp     = array[i];
         array[i] = array[j];
         array[j] = temp;
         }
      }
   }

return;

}

/****************************************************************************************************/
/****************************************************************************************************/

int record_compare (record1,record2,order,n)
char  *record1;
char  *record2;
int   order[];
int   n;
{
char  s1[3][20];
char  s2[3][20];
float v1[21];
float v2[21];
int   value;
int   i;

sscanf (record1,"%s %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",
        s1[0],s1[1],s1[2],&v1[1],&v1[2],&v1[3],&v1[4],&v1[5],&v1[6],&v1[7],
        &v1[8],&v1[9],&v1[10],&v1[11],&v1[12],&v1[13],&v1[14],&v1[15],&v1[16],
        &v1[17],&v1[18],&v1[19],&v1[20]);
sscanf (record2,"%s %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f",
        s2[0],s2[1],s2[2],&v2[1],&v2[2],&v2[3],&v2[4],&v2[5],&v2[6],&v2[7],
        &v2[8],&v2[9],&v2[10],&v2[11],&v2[12],&v2[13],&v2[14],&v2[15],&v2[16],
        &v2[17],&v2[18],&v2[19],&v2[20]);

i = -1;

do
   {
   ++i;
   switch (abs (order[i]))
      {
      case 1:
         value = strncmp (s1[0],s2[0],strlen (s1[0]));
         break;
      case 2:
         value = strncmp (s1[1],s2[1],strlen (s1[1]));
         break;
      case 3:
         value = strncmp (s1[2],s2[2],strlen (s1[2]));
         break;
      case 4:
         if (v1[1] > v2[1] + 0.05)
            {
            value = 1;
            }
         else if ( v1[1] < v2[1] - 0.05)
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      case 5:
         if (v1[2] > v2[2])
            {
            value = -1;
            }
         else if ( v1[2] < v2[2])
            {
            value = 1;
            }
         else
            {
            value = 0;
            }
         break;
      case 6:
         if (v1[3] > v2[3] + 0.02)
            {
            value = -1;
            }
         else if ( v1[3] < v2[3] - 0.02)
            {
            value = 1;
            }
         else
            {
            value = 0;
            }
         break;
      default:
         if (v1[abs (order[i])-3] > v2[abs (order[i])-3])
            {
            value = 1;
            }
         else if ( v1[abs (order[i])-3] < v2[abs (order[i])-3])
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      }
   if (order[i] < 0)
      {
      value = -value;
      }
   }
while (i < n - 1 && value == 0);

return (value);

}
