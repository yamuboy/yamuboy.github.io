#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize4.h"
#include "jplot.h"
#include "fit_tools.h"

#define BOLTZMANN        1.3806226e-23
#define QELECTRON        1.6021918e-19
#define STDTEMP          300.0
#define THERMAL_V       ((BOLTZMANN*STDTEMP)/QELECTRON)
#define LOGMIN           1.0e-12

#define MAX_BIAS_PTS    200
#define NUM_PARAMS      13
#define IDS_ERR_FACTOR  0.05

// flags
#define SUPPRESS_GRAPHS   1
#define USE_POSTSCRIPT    2
#define USE_METAFILE      4

/* ----------- STRUCTURE DEFS ------------ */

typedef struct
   {
   double vg,ig,cg,gds;   
   } ACData;

typedef struct
   {
   double vgs,vds,ids,igs;   
   } IVData;

typedef struct
   {
   ACData *data;
   unsigned n;
   double cg0;
   double rg;
   } CapacitanceOptimize;

typedef struct
   {
   ACData *acdata;
   IVData *dcdata;
   unsigned n_ac,n_dc;
   double knee_voltage;
   double rg,rd,rs,area;
   } GdsOptimize;

typedef struct
   {
   IVData *data;
   unsigned n;
   } VbrOptimize;

typedef struct
   {
   double rg,rd,rs;
   double lg,ld,ls;
   double area,ugw;
   int ngf;
   double is,n;
   double cg0,cds;
   double c11,c22;
   double ibi,vbi;
   double ibn,vbn;
   } FixedParams;

/* -------- FUNCTION PROTOTYPES ---------- */

static int write_starting_files (int type);
static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params);
static int get_fixed_params (char *fname, FixedParams *f, char *iv_fname);
static int get_ac_data (char *fname, ACData *ac_data, unsigned max_pts, unsigned *ac_pts);
static int write_output_files (char *end_file, char *mod_file, char *head_file, OPT_PARAMETER *p, unsigned np, FixedParams fixed);

static int fit_drain_conductance (ACData *ac_data, unsigned n_ac_pts, char *iv_file, OPT_PARAMETER *p,
                                  FixedParams *fixed, unsigned iter, jPLOT_ITEM **gds_plot, jPLOT_ITEM **knee_plot,
                                  jPLOT_ITEM **subth_plot);
static int fit_gate_capacitance (ACData *data, unsigned npts, OPT_PARAMETER *p, FixedParams *fixed,
                                 unsigned iter, jPLOT_ITEM **plot);
static int fit_forward_iv (char *fwd_iv_file, FixedParams *fixed, jPLOT_ITEM **plot);
static int fit_reverse_breakdown (char *vbr_file, FixedParams *fixed, double vbi_start, double vbi_stop,
                                  double vbn_start, double vbn_stop, jPLOT_ITEM **plot);

static int plot_data (char *dc_iv_file, jPLOT_ITEM *cap_plot, jPLOT_ITEM *gds_plot, jPLOT_ITEM *knee_plot,
                      jPLOT_ITEM *fwd_plot, jPLOT_ITEM *rev_plot, jPLOT_ITEM *subth_plot, unsigned flags);

unsigned global_show_optimization_flag = 1;

/****************************************************************************/
/****************************************************************************/
/*                                  MAIN                                    */
/****************************************************************************/
/****************************************************************************/

int main (int argc, char *argv[])
   {
   int i;
   char string[200];
   char fixed_param_file[100];
   char ac_data_file[100];
   char start_file[100];
   char end_file[100];
   char model_file[100];
   char dc_iv_file[100];
   char fwd_iv_file[100];
   char vbr_iv_file[100];
   OPT_PARAMETER params[NUM_PARAMS];
   ACData ac_data[MAX_BIAS_PTS];
   FixedParams fixed;
   jPLOT_ITEM *cap_plot,*gds_plot,*knee_plot;
   jPLOT_ITEM *fwd_plot,*rev_plot, *subth_plot;
   unsigned num_ac_pts;
   int flags = 0;
   unsigned niter = 0;
   double vbi_start,vbi_stop,vbn_start,vbn_stop;
   
   /************ Parse Command Line ***************/

   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\n\nThe following command line switches are supported:\n");
         printf ("----------------------------------------------------------------------------------------\n");
         printf ("  -h    Brings up this dialog.\n");
         printf ("  -s    Suppress graphics output.\n");
         printf ("  -dA   Sets the graphics device, where A is one of \'X\' (default), \'P\', or \'M\',\n");      
         printf ("         which indicate X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("  -i    Write a default input file named \"switchin\"\n");
         printf ("  -e    Write a default starting values file named \"switch_jb.end\"\n");
         printf ("\n\n");
         return 0;
         }

      else if (!strncmp (argv[i],"-e",2) || !strncmp (argv[i],"-i",2))
         {
         int type = 0;

         for (i = 1; i < argc; ++i)
            {
            if (!strncmp (argv[i],"-e",2))
               type |= 0x01;

            if (!strncmp (argv[i],"-i",2))
               type |= 0x02;
            }

         write_starting_files (type);
         return 0;
         }

      else if (!strncmp (argv[i],"-s",2))
         flags |= SUPPRESS_GRAPHS;
                  
      else if (!strncmp (argv[i],"-d",2))
         {
         char ch;

         sscanf (argv[i],"-d%c",&ch);
         if ((ch == 'p') || (ch == 'P'))
            flags |= USE_POSTSCRIPT;
         else if ((ch == 'm') || (ch == 'M'))
            flags |= USE_METAFILE;
         }
      }
   
   /************ Get Information ***************/

   printf ("Fixed parameter data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", fixed_param_file);

   printf ("Cg/Gds data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", ac_data_file);

   printf ("DC I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", dc_iv_file);

   printf ("Forward I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", fwd_iv_file);

   printf ("Breakdown I-V data file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", vbr_iv_file);

   printf ("Start parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", end_file);

   printf ("Output model file name?\n");
   fgets (string,199,stdin);
   sscanf (string, "%99s", model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,199,stdin);
   if (!niter)
      sscanf (string, "%u", &niter);
      
   /************** Initialization ******************/
   
   printf ("Initializing...\n");

   if (get_starting_values (start_file, params, NUM_PARAMS))
      {
      printf ("Error in get_starting_values().\n");
      return -1;
      }

   if (get_fixed_params (fixed_param_file, &fixed, fwd_iv_file))
      {
      printf ("Error in get_fixed_params().\n");
      return -1;
      }

   if (get_ac_data (ac_data_file, ac_data, MAX_BIAS_PTS, &num_ac_pts))
      {
      printf ("Error in get_ac_data().\n");
      return -1;
      }

   /************ Gate Capacitance fit ****************/

   printf ("Fitting gate capacitance...\n");
   
   if (fit_gate_capacitance (ac_data, num_ac_pts, &params[0], &fixed, niter, &cap_plot))
      {
      printf ("Error in fit_gate_capacitance().\n");
      return -1;
      }
   
   /************ Drain Conductance fit ***************/

   printf ("Fitting drain conductance...\n");

   if (fit_drain_conductance (ac_data, num_ac_pts, dc_iv_file, &params[4], &fixed, niter, &gds_plot, &knee_plot, &subth_plot))
      {
      printf ("Error in fit_drain_conductance().\n");
      return -1;
      }

   /************** Forward Diode fit ******************/

   printf ("Fitting forward gate diode...\n");
   
   if (fit_forward_iv (fwd_iv_file, &fixed, &fwd_plot))
      {
      printf ("Error in fit_forward_iv().\n");
      return 1;
      }      
   
   /************** Reverse Diode Fit ******************/

   printf ("Fitting reverse gate diode...\n");

   // hard code these for now
   vbi_start = 10.0;
   vbi_stop = 15.0;
   vbn_start = 5.0;
   vbn_stop = 10.0;

   if (fit_reverse_breakdown (vbr_iv_file, &fixed, vbi_start, vbi_stop, vbn_start, vbn_stop, &rev_plot))
      {
      printf ("Error in fit_reverse_breakdown().\n");
      return 1;
      }

   /************** Write output files *****************/
   
   printf ("Writing data to disc...\n");

   if (write_output_files (end_file, model_file, fwd_iv_file, params, NUM_PARAMS, fixed))
      printf ("Error in write_output_files().\n");

   /***************** Plot data ***********************/
   
   printf ("Generating plots...\n");

   if (plot_data (dc_iv_file, cap_plot, gds_plot, knee_plot, fwd_plot, rev_plot, subth_plot, flags))
      printf ("Error in plot_data().\n");

   printf ("Done.\n\n");
   
   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                              DATA FILE I/O                               */
/****************************************************************************/
/****************************************************************************/

static int write_starting_files (int type)
   {
   FILE *file;
   unsigned i;
   OPT_PARAMETER p[] = {
      {0.0, 1.0, 10.0, 0.0, "CF", 0},
      {-2.0, 0.0, 0.5, 0.0, "CTH", 0},
      {0.0, 0.2, 1.0, 0.0, "CS1", 0},
      {0.0, 0.2, 1.0, 0.0, "CS2", 0},
      {-3.0, -0.5, 0.5, 0.0, "VTO", 0},
      {0.0, 1.5, 10.0, 0.0, "ALPHA", 0},
      {0.0, 0.05, 0.3, 0.0, "BETA", 0},
      {0.0, 0.0, 0.0, 0.0, "LAMBDA", 0},
      {0.0, 0.001, 0.02, 0.0, "GAMMA", 0},
      {0.0, 1.3, 2.50, 0.0, "Q", 0},
      {0.0, 2.2, 4.0, 0.0, "K", 0},
      {0.0, 0.01, 0.1, 0.0, "VST", 0},
      {0.0, 0.01, 0.1, 0.0, "MVST", 0}
      };

   if (type | 0x01)
      {
      file = fopen ("switch_jb.end", "w+");

      if (!file)
         {
         printf ("Unable to create starting values file.\n");
         return 1;
         }

      fprintf (file, "! auto-generated starting values file\n");

      for (i = 0; i < 13; ++i)
         {
         fprintf (file,"%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max,
            p[i].tol, p[i].name);
         }
      fclose (file);
      }

   if (type | 0x02)
      {
      file = fopen ("switchin", "w+");

      if (!file)
         {
         printf ("Unable to create input file.\n");
         return 1;
         }

      fprintf (file, "fixed.dat               # Fixed parameter data file name\n");
      fprintf (file, "ac.data                 # Cg/Gds data file name\n");
      fprintf (file, "sdc.iv                  # DC IV data file name\n");
      fprintf (file, "sfwd.iv                 # Forward IV data file name\n");
      fprintf (file, "svbr.iv                 # Breakdown IV data file name\n");
      fprintf (file, "switch_jb.end           # Starting parameters file name\n");
      fprintf (file, "switch_jb.end           # Finishing parameters file to write\n");
      fprintf (file, "switch_jb.model         # Model file to write\n");
      fprintf (file, "500                     # Maximum number of optimization line searches\n");

      fclose (file);
      }

   return 0;
   }

/****************************************************************************/
/****************************************************************************/

static int get_starting_values (char *fname, OPT_PARAMETER *params, unsigned n_params)
   {
   FILE *file;
   char string[201];
   unsigned i = 0;
      
   file = fopen (fname,"r");
   if (!file)
      {
      printf ("ERROR: Unable to open starting values file - %s\n", fname);
      return -1;
      }
   
   while (fgets (string, 200, file))
      {
      if (string[0] == '#' || string[0] == '!')
         continue;
      
      if (i >= n_params)
         break;
         
      sscanf (string,"%lf%lf%lf%lf%19s", &params[i].min, &params[i].nom, &params[i].max,
         &params[i].tol, params[i].name);
      params[i].optimize = TRUE;
      
      if (params[i].min > params[i].max)
         {
         printf ("WARNING in parameter \"%s\": MIN > MAX, range reset.\n",params[i].name);
         params[i].max = params[i].min;
         }

      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      else if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;

      if (params[i].tol < 0.0)
         params[i].tol = -params[i].tol;
         
      ++i;
      }
   fclose (file);

   if (i < n_params)      
      {
      printf ("Error: Incomplete starting values file.\n");
      return -1;
      }

   // force lambda equal to zero
   params[7].min = params[7].nom = params[7].max = params[7].tol = 0.0;

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int get_fixed_params (char *fname, FixedParams *f, char *iv_fname)
   {
   FILE *file;
   char string[256];
   int err = 0;
   char pname[30];
   double pval;
   unsigned i;
   struct parm_struct {char *name; double *ptr; int found;} parms[] = {
      {"lg", &f->lg, 0},
      {"rg", &f->rg, 0},
      {"ld", &f->ld, 0},
      {"rd", &f->rd, 0},
      {"ls", &f->ls, 0},
      {"rs", &f->rs, 0},
      {"c11", &f->c11, 0},
      {"c22", &f->c22, 0},
      {"cds", &f->cds, 0}
      };
   unsigned sz_parms = sizeof(parms)/sizeof(*parms);

   /* open the IV data file to read in the unit gate width and number of fingers */

   f->ugw = -1.0;
   f->ngf = -1;

   file = fopen (iv_fname, "r");
   if (!file)
      {
      printf ("Error opening file: %s\n", iv_fname);
      return 1;
      }

   while (fgets (string, 255, file))
      {
      if (sscanf (string, "!UNIT GATE WIDTH (um): %lf", &f->ugw))
         continue;

      if (sscanf (string, "!NUMBER OF GATE FINGERS: %d", &f->ngf) || (string[0] != '!'))
         break;
      }

   fclose (file);

   if (f->ugw <= 0.0)
      {
      printf ("Error reading UGW from file: %s\n", iv_fname);
      return 1;
      }
   else if (f->ngf < 0)
      {
      printf ("Error reading NGF from file: %s\n", iv_fname);
      return 1;
      }

   f->area = f->ugw * f->ngf;

   /* open the fixed parameter file for reading */

   file = fopen (fname, "r");
   if (!file)
      {
      printf ("Error opening file: %s\n", fname);
      return 1;
      }

   /* scan through the file and read in parameter values */

   while (fgets (string, 255, file))
      {
      /* skip comment lines */
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (sscanf (string, "%29s %lf", pname, &pval) == 2)
         {
         pname[29] = 0;

         /* find the parameter in the list */
         for (i = 0; i < sz_parms; ++i)
            {
            if (!strcmp (pname, parms[i].name))
               {
               *(parms[i].ptr) = pval;
               parms[i].found = 1;
               break;
               }
            }
         }
      }

   fclose (file);

   /* check for missing paramters */

   for (i = 0; i < sz_parms; ++i)
      {
      if (!parms[i].found)
         {
         printf ("Error: missing parameter \'%s\' in file - %s\n", parms[i].name, fname);
         err = 1;
         }
      }

   return err;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int get_ac_data (char *fname, ACData *ac_data, unsigned max_pts, unsigned *ac_pts)
   {
   FILE *file;
   unsigned i,j;
   char string[256];
   ACData ac_tmp;
   
   *ac_pts = 0;

   file = fopen (fname, "r");
   if (!file)
      {
      printf ("Unable to open AC data file: %s\n", fname);
      return -1;
      }

   // read the data file
   
   while (fgets (string, 255, file))
      {
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (sscanf (string, "%lf%lf%lf%lf", &ac_data[*ac_pts].vg, &ac_data[*ac_pts].ig,
         &ac_data[*ac_pts].gds, &ac_data[*ac_pts].cg) == 4)
         (*ac_pts)++;
      }

   fclose (file);

   // sort the data for ascending vgs

   for (i = 0; i < (*ac_pts) - 1; ++i)
      {
      for (j = i+1; j < (*ac_pts); ++j)
         {
         if (ac_data[j].vg < ac_data[i].vg)
            {
            ac_tmp = ac_data[i];
            ac_data[i] = ac_data[j];
            ac_data[j] = ac_tmp;
            }
         }
      }

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int get_iv_data (char *fname, IVData *data, unsigned max_pts, unsigned *npts)
   {
   FILE *file;
   char string[201];
   
   *npts = 0;
   
   file = fopen (fname, "r");
   if (!file)
      {
      printf ("Unable to open IV file: %s\n", fname);
      return -1;
      }

   while (fgets (string, 200, file))
      {
      if ((*npts) >= max_pts)
         break;
      else if (string[0] == '!')
         continue;
      else if (sscanf (string,"%lf%lf%lf%lf",&data[*npts].vds,&data[*npts].ids,&data[*npts].vgs,&data[*npts].igs) == 4)
         (*npts)++;
      }
   fclose (file);
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int write_output_files (char *end_file, char *mod_file, char *head_file, OPT_PARAMETER *p, unsigned np, FixedParams fixed)
   {
   FILE *infile,*outfile;
   unsigned i;
   char string[201];
   char *names[50];
   double values[50];

   infile  = fopen (head_file, "r");
   if (!infile)
      {
      printf ("Unable to open header file.\n");
      return 1;
      }

   outfile = fopen (mod_file, "w+");
   if (!outfile)
      {
      printf ("Unable to write to disk.\n");
      return 1;
      }

   // write the header
   
   while (fgets (string, 200, infile))
      {
      if (string[0] != '!')
         break;
      else if (!strncmp (string,"!Vbr",4))
         {
         fprintf (outfile,"%s",string);
         if (fgets (string, 200, infile))
            fprintf (outfile, "%s", string);
         break;
         }
      
      fprintf (outfile,"%s",string);
      }
   fclose (infile);

   // write the model parameters

   names[0] = "area";      values[0] = fixed.area;
   names[1] = "is";        values[1] = fixed.is;
   names[2] = "n";         values[2] = fixed.n;
   names[3] = "ibi";       values[3] = fixed.ibi;
   names[4] = "vbi";       values[4] = fixed.vbi;
   names[5] = "ibn";       values[5] = fixed.ibn;
   names[6] = "vbn";       values[6] = fixed.vbn;
   names[7] = "rd";        values[7] = fixed.rd;
   names[8] = "rs";        values[8] = fixed.rs;
   names[9] = "ld";        values[9] = fixed.ld;
   names[10] = "ls";       values[10] = fixed.ls;
   names[11] = "cds";      values[11] = fixed.cds;
   names[12] = "c11";      values[12] = fixed.c11;
   names[13] = "c22";      values[13] = fixed.c22;
   names[14] = "cg0";      values[14] = fixed.cg0;
   names[15] = "cf";       values[15] = p[0].nom;
   names[16] = "cth";      values[16] = p[1].nom;
   names[17] = "cs1";      values[17] = p[2].nom;
   names[18] = "cs2";      values[18] = p[3].nom;
   names[19] = "vto";      values[19] = p[4].nom;
   names[20] = "alpha";    values[20] = p[5].nom;
   names[21] = "beta";     values[21] = p[6].nom;
   names[22] = "lambda";   values[22] = p[7].nom;
   names[23] = "gamma";    values[23] = p[8].nom;
   names[24] = "q";        values[24] = p[9].nom;
   names[25] = "k";        values[25] = p[10].nom;
   names[26] = "vst";      values[26] = p[11].nom;
   names[27] = "mvst";     values[27] = p[12].nom;
   names[28] = "ugw";      values[28] = fixed.ugw;
   names[29] = "ngf";      values[29] = fixed.ngf;

   fprintf (outfile, "VAR model=1\n");

   write_model_param_mdif (outfile, names, values, 30, 12, 5); 
   
   fclose (outfile);
   
   // write the finishing values file  
   
   outfile = fopen (end_file,"w+");
   if (!outfile)
      {
      printf ("Unable to write to disc.\n");
      return 1;
      }

   for (i = 0; i < np; ++i)
      {
      fprintf (outfile,"%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max,
         p[i].tol, p[i].name);
      }
   fclose (outfile);

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                         SWITCH MODEL FUNCTIONS                           */
/****************************************************************************/
/****************************************************************************/

static double switch_cg (double vg, double cg0, double cf, double cth, double cs1, double cs2)
   {
   double x1 = vg - cth - cs1;
   double sqrtf = sqrt (x1*x1 + cs2*cs2);

   return cg0 + 1.0e-12*exp (cf*(vg - cth - sqrtf)) * (cf*(1.0 - x1 / sqrtf));
   }

/*****************************************************************************/
/*****************************************************************************/

static double switch_ids (double *p, double vgs, double vds)
   {
   double vto    = p[0];
   double alpha  = p[1];
   double beta   = p[2];
   double lambda = p[3];
   double gamma  = p[4];
   double q      = p[5];
   double k      = p[6];
   double vst    = p[7];
   double mvst   = p[8];
   double Vst,u,Vg,fk,I0,Ids;
   int flag = 0;

   if (vds < 0.0)
      {
      vgs = vgs - vds;
      vds = -vds;
      flag = 1;
      }

   Vst = vst * (1.0 + mvst*vds);
   u = (vgs - vto + gamma*vds) / (q*Vst);
   if (u > 30.0)
      Vg = q * Vst * u;
   else
      Vg = q * Vst * log (1.0 + exp (u));
   fk = (alpha*vds) / pow (1.0 + pow (alpha*vds, k), 1.0/k);
   I0 = beta * pow (Vg, q) * fk;
   Ids = I0 * (1.0 + lambda*vds);

   if (flag)
      return -Ids;

   return Ids;
   }

/*****************************************************************************/
/*****************************************************************************/

static double switch_gds (double *p, double vgs, double vds)
   {
   double vto    = p[0];
   double alpha  = p[1];
   double beta   = p[2];
   double lambda = p[3];
   double gamma  = p[4];
   double q      = p[5];
   double k      = p[6];
   double vst    = p[7];
   double mvst   = p[8];
   double Vst, u, Vg, fk, I0, Ids;
   double d_Vst, d_u, d_Vg, d_fk, d_I0, Gds;

   if (vds < 0.0)
      {
      vgs = vgs - vds;
      vds = -vds;
      }

   Vst = vst * (1.0 + mvst*vds);
   d_Vst = vst * mvst;

   u = (vgs - vto + gamma*vds) / (q*Vst);
   d_u = (Vst*gamma - (vgs - vto + gamma*vds)*d_Vst) / (q*Vst*Vst);

   if (u > 30.0)  // traps numerical overflows when the argument to the exp() function becomes large 
      {
      Vg = q * Vst * u;
      d_Vg = q * (Vst * d_u + u * d_Vst);
      }
   else
      {
      Vg = q * Vst * log (1.0 + exp (u));
      d_Vg = q * (Vst/(1.0 + exp(u))*exp(u)*d_u + log (1.0 + exp(u))*d_Vst);
      }
   
   fk = (alpha*vds) / pow (1.0 + pow (alpha*vds, k), 1.0/k);
   if ((vds == 0.0) && (k < 1.0))  // trap to prevent NaN error for vds == 0 and k < 1
      d_fk = alpha;
   else
      d_fk = alpha * (pow (1.0 + pow (alpha*vds, k), 1.0/k) - vds * pow (1.0 + pow (alpha*vds, k), 1.0/k - 1.0) * pow (alpha*vds, k-1.0) * alpha) / pow (1.0 + pow (alpha*vds, k), 2.0/k);
   
   I0 = beta * pow (Vg, q) * fk;
   if ((Vg == 0.0) && (q < 1.0))  // trap to prevent NaN error for Vg == 0 and q < 1
      d_I0 = 0.0;
   else
      d_I0 = beta * (pow (Vg, q) * d_fk + fk * q * pow (Vg, q - 1.0) * d_Vg);
   
   Ids = I0 * (1.0 + lambda*vds);
   Gds = I0 * lambda + (1.0 + lambda*vds) * d_I0;

   // printf ("%.2f %.2e %.2e %.2e %.2e %.2e %.2e %.2e %.2e %.2e %.2e %.2e %.2e\n", vgs, Vst, d_Vst, u, d_u, Vg, d_Vg, fk, d_fk, I0, d_I0, Ids, Gds);

   return Gds;
   }

/*****************************************************************************/
/*****************************************************************************/

static double switch_breakdown (double v, double ibi, double vbi, double ibn, double vbn)
   {
   return ibi * (exp (v / vbi) - 1.0) + ibn * (exp (v / vbn) - 1.0);
   }

/****************************************************************************/
/****************************************************************************/
/*                       OPTIMIZATION ERROR FUNCTIONS                       */
/****************************************************************************/
/****************************************************************************/

static int subth_dciv_erf (double *p, void *data, double *error, unsigned n_err)
   {
   unsigned i;
   double err;
   GdsOptimize *d = (GdsOptimize *) data;
   unsigned m = 0;

   if (n_err != 1)
      return 1;

   for (i = 0; i < d->n_dc; ++i)
      {
      err = log (d->dcdata[i].ids) - log (switch_ids (p, d->dcdata[i].vgs, d->dcdata[i].vds) + 1.0e-15);
      error[0] += 1.0e6 * err * err;
      ++m;
      }

   if (!m)
      m = 1;

   error[0] /= (double) m;

   return 0;
   }

/****************************************************************************/
/****************************************************************************/

static int gds_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   unsigned i;
   unsigned n = 0;
   unsigned n2 = 0;
   double ids,gds,err,vg,vd;
   GdsOptimize *d = (GdsOptimize *) data;
   double gds_err = 0.0;
   double ids_err = 0.0;
   
   if (n_errs != 2)
      return 1;

   for (i = 0; i < d->n_ac; ++i)
      {
      if ((d->acdata[i].gds*1.0e3/d->area) < 1.0e-4)
         continue;

      vg = d->acdata[i].vg - d->acdata[i].ig * d->rg;
      gds = switch_gds (p, vg, 0.0);
      err = gds - d->acdata[i].gds;
      error[0] += 1.0e6 * err * err;
      ++n2;
      }

   if (!n2)
      n2 = 1;

   error[0] /= (double) n2;

   for (i = 0; i < d->n_dc; ++i)
      {
      if (d->dcdata[i].vgs == d->knee_voltage)
         {
         vg = d->dcdata[i].vgs - d->dcdata[i].igs * d->rg - (d->dcdata[i].igs + d->dcdata[i].ids) * d->rs;
         vd = d->dcdata[i].vds - d->dcdata[i].ids * d->rd - (d->dcdata[i].igs + d->dcdata[i].ids) * d->rs;
         ids = switch_ids (p, vg, vd);
         err = ids - d->dcdata[i].ids;
         error[1] += IDS_ERR_FACTOR * 1.0e6 * err * err;
         ++n;
         }
      }
   
   if (!n)
      n = 1;

   error[1] /= (double) n;

   error[1] = 0.0;

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int cgs_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   unsigned i;
   double cg, err;
   CapacitanceOptimize *d = (CapacitanceOptimize *) data;
   
   for (i = 0; i < d->n; ++i)
      {
      cg = switch_cg (d->data[i].vg - d->data[i].ig * d->rg, d->cg0, p[0], p[1], p[2], p[3]);
      err = cg - d->data[i].cg;
      error[0] += err * err * 1.0e24;
      }
      
   error[0] /= (double) d->n;
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int vbr_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   unsigned i;
   double ibr,err;
   VbrOptimize *d = (VbrOptimize *) data;

   for (i = 0; i < d->n; ++i)
      {
      ibr = switch_breakdown (d->data[i].vds - d->data[i].vgs, p[0], p[1], p[2], p[3]);
      err = ibr - d->data[i].ids;
       
      error[0] += log (1.0 + err * err);
      }

   error[0] /= (double) d->n;

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                            GATE CAPACITANCE                              */
/****************************************************************************/
/****************************************************************************/

static int fit_gate_capacitance (ACData *data, unsigned npts, OPT_PARAMETER *p, FixedParams *fixed,
                                 unsigned iter, jPLOT_ITEM **plot)
   {
   OPTIMIZE *opt;
   CapacitanceOptimize cgs_erf_data;
   double *vgs,*cmeas,*cmod;
   unsigned i;

   fixed->cg0 = data[0].cg;

   cgs_erf_data.data = data;
   cgs_erf_data.n = npts;
   cgs_erf_data.rg = fixed->rg;
   cgs_erf_data.cg0 = fixed->cg0;

   opt = initialize_cg_optimizer ();   
   set_cg_parameters (opt, p, 4);
   set_cg_error_function (opt, cgs_erf, &cgs_erf_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-7, 5);
   if (global_show_optimization_flag)
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);
   else
      set_cg_flags (opt, OPT_SINGLE_PARAM);

   if (cg_optimize4 (opt, iter, NULL))
      {
      printf ("Error in cg_optimize4(): %s\n", get_cg_error());
      free ((void *) opt);
      return -1;
      }

   free ((void *) opt);

   // create the graphical plot

   *plot = create_plot_item (SingleY, 2.0, 1.25, 7.0, 6.0);

   vgs = (double *) malloc (sizeof(double) * npts);
   cmeas = (double *) malloc (sizeof(double) * npts);
   cmod = (double *) malloc (sizeof(double) * npts);

   for (i = 0; i < npts; ++i)
      {
      vgs[i] = data[i].vg;
      cmod[i] = switch_cg (data[i].vg - data[i].ig * fixed->rg, fixed->cg0, p[0].nom, p[1].nom, p[2].nom, p[3].nom) * 1.0e15 / fixed->area;
      cmeas[i] = data[i].cg * 1.0e15 / fixed->area;
      }
   
   attach_y1data (*plot, vgs, cmod, npts, LT_SOLID, 1, CLR_RED);
   attach_y1data (*plot, vgs, cmeas, npts, LT_DASHED, 1, CLR_BLUE);

   set_axis_labels (*plot, "Vg (volts)", "Cg (pF/mm)", "", "Gate Capacitance");
   (*plot)->active = FALSE;

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                        DRAIN CONDUCTANCE AND CURRENT                     */
/****************************************************************************/
/****************************************************************************/

static int fit_drain_conductance (ACData *ac_data, unsigned n_ac_pts, char *iv_file, OPT_PARAMETER *p,
                                  FixedParams *fixed, unsigned iter, jPLOT_ITEM **gds_plot, jPLOT_ITEM **knee_plot,
                                  jPLOT_ITEM **subth_plot)
   {
#define MAX_DC_PTS   1000
   IVData dc_data[MAX_DC_PTS];
   IVData subth_data[MAX_DC_PTS];
   IVData tmp;
   unsigned i, n_dc_pts, n_subth_pts;
   unsigned j = 0, k = 0;
   double gate_voltage = -5.0;
   OPTIMIZE *opt;
   GdsOptimize gds_erf_data;
   char str[200];
   double *vgsg,*gmeas,*gmod;
   double *vdsk,*kmeas,*kmod;
   double vg,vd;
   double p_list[9];
   double *subth_v, *subth_imeas, *subth_imod;

   if (get_iv_data (iv_file, dc_data, MAX_DC_PTS, &n_dc_pts))
      {
      printf ("ERROR in get_iv_data().\n");
      return -1;
      }

   gds_erf_data.acdata = ac_data;
   gds_erf_data.n_ac = n_ac_pts;
   gds_erf_data.rg = fixed->rg;
   gds_erf_data.rs = fixed->rs;
   gds_erf_data.rd = fixed->rd;
   gds_erf_data.area = fixed->area;

   // pull subthreshold data out of the dc data

   for (i = 0, n_subth_pts = 0; i < n_dc_pts; ++i)
      {
      if ((dc_data[i].vds < 1.0) || (dc_data[i].vds > 5.0) || (dc_data[i].ids <= 0.0) || (dc_data[i].ids > 10e-6 * fixed->area))
         continue;

      subth_data[n_subth_pts] = dc_data[i];
      ++n_subth_pts;
      }

   if (n_subth_pts < 5)
      {
      printf ("Error: not enough subthreshold points.\n");
      return 1;
      }

   // sort subthreshold data

   for (i = 0; i < n_subth_pts; ++i)
      {
      for (j = i+1; j < n_subth_pts; ++j)
         {
         if ((subth_data[j].vds < subth_data[i].vds) || 
            ((subth_data[j].vds == subth_data[i].vds) && (subth_data[j].vgs < subth_data[i].vgs)))
            {
            tmp = subth_data[j];
            subth_data[j] = subth_data[i];
            subth_data[i] = tmp;
            }
         }
      }

   opt = initialize_cg_optimizer ();   

   /**** sub-threshold fit ****/

   gds_erf_data.dcdata = subth_data;
   gds_erf_data.n_dc = n_subth_pts;

   p[0].optimize = TRUE;
   p[7].optimize = TRUE;
   p[8].optimize = TRUE;
   for (i = 0; i < 9; ++i)
      p[i].optimize = TRUE;

   set_cg_parameters (opt, p, 9);
   set_cg_error_function (opt, subth_dciv_erf, &gds_erf_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-9, 5);
   if (global_show_optimization_flag)
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);
   else
      set_cg_flags (opt, OPT_SINGLE_PARAM);

   if (cg_optimize4 (opt, iter, NULL))
      {
      fprintf (stderr, "Error in cg_optimize4(): %s\n", get_cg_error());
      return -1;
      }

   p[0].optimize = FALSE;
   p[7].optimize = FALSE;
   p[8].optimize = FALSE;
   for (i = 0; i < 9; ++i)
      p[i].optimize = FALSE;

   /**** active area fit ****/

   // determine the gate voltage to use for the knee fit

   for (i = 0; i < n_dc_pts; ++i)
      {
      if ((dc_data[i].vgs > gate_voltage) && (dc_data[i].vgs < 0.91) && (dc_data[i].vds >= 1.5))      
         gate_voltage = dc_data[i].vgs;
      }
   gds_erf_data.knee_voltage = gate_voltage;
   gds_erf_data.dcdata = dc_data;
   gds_erf_data.n_dc = n_dc_pts;

   for (i = 1; i < 7; ++i)
      p[i].optimize = TRUE;

   set_cg_error_function (opt, gds_erf, &gds_erf_data, 2, NULL);
   set_cg_error_fraction (opt, 1.0e-12, 20);
   
   if (cg_optimize4 (opt, iter, NULL))
      {
      printf ("Error in cg_optimize4(): %s\n", get_cg_error());
      free ((void *) opt);
      return -1;
      }

   free ((void *) opt);

   for (i = 1; i < 7; ++i)
      p[i].optimize = FALSE;

   /**** create plots ****/

   for (i = 0; i < 9; ++i)
      p_list[i] = p[i].nom;

   *gds_plot = create_plot_item (SingleY, 2.0, 1.25, 7.0, 6.0);

   vgsg = (double *) malloc (sizeof(double) * n_ac_pts);
   gmeas = (double *) malloc (sizeof(double) * n_ac_pts);
   gmod = (double *) malloc (sizeof(double) * n_ac_pts);

   for (i = 0; i < n_ac_pts; ++i)
      {
      vgsg[i] = ac_data[i].vg - ac_data[i].ig * fixed->rg;
      gmeas[i] = ac_data[i].gds * 1.0e6 / fixed->area;
      gmod[i] = switch_gds (p_list, vgsg[i], 0.0) * 1.0e6 / fixed->area;
      }

   attach_y1data (*gds_plot, vgsg, gmod, n_ac_pts, LT_SOLID, 1, CLR_RED);
   attach_y1data (*gds_plot, vgsg, gmeas, n_ac_pts, LT_DASHED, 1, CLR_BLUE);
   set_axis_labels (*gds_plot, "Vg (volts)", "Gds (mS/mm)", "", "Drain Conductance");

   (*gds_plot)->active = FALSE;

   // drain current knee

   *knee_plot = create_plot_item (SingleY, 2.0, 1.25, 7.0, 6.0);

   for (i = 0, j = 0; i < n_dc_pts; ++i)
      {
      if (dc_data[i].vgs == gate_voltage)
         ++j;
      }

   vdsk = (double *) malloc (sizeof(double) * j);
   kmeas = (double *) malloc (sizeof(double) * j);
   kmod = (double *) malloc (sizeof(double) * j);


   for (i = 0; i < n_dc_pts; ++i)
      {
      if (dc_data[i].vgs == gate_voltage)
         {
         vg = dc_data[i].vgs - dc_data[i].igs * fixed->rg - (dc_data[i].igs + dc_data[i].ids) * fixed->rs;
         vd = dc_data[i].vds - dc_data[i].ids * fixed->rd - (dc_data[i].igs + dc_data[i].ids) * fixed->rs;
         vdsk[k] = vd;
         kmeas[k] = dc_data[i].ids * 1.0e6 / fixed->area;
         kmod[k] = switch_ids (p_list, vg, vd) * 1.0e6 / fixed->area;
         ++k;
         }
      }
   
   attach_y1data (*knee_plot, vdsk, kmod, k, LT_SOLID, 1, CLR_RED);
   attach_y1data (*knee_plot, vdsk, kmeas, k, LT_DASHED, 1, CLR_BLUE);

   sprintf (str, "Drain Current @ Vgs = %.3f", gate_voltage);
   set_axis_labels (*knee_plot, "Vds (volts)", "Ids (mA/mm)", "", str);

   (*knee_plot)->active = FALSE;

   // subthreshold

   *subth_plot = create_plot_item (SingleY, 2.0, 1.25, 7.0, 6.0);

   subth_v = (double *) malloc (sizeof(double) * n_subth_pts);
   subth_imeas = (double *) malloc (sizeof(double) * n_subth_pts);
   subth_imod = (double *) malloc (sizeof(double) * n_subth_pts);

   for (i = 0; i < n_subth_pts; ++i)
      {
      subth_v[i] = subth_data[i].vgs;
      subth_imeas[i] = subth_data[i].ids * 1.0e6 / fixed->area;
      subth_imod[i] = switch_ids (p_list, subth_v[i], subth_data[i].vds) * 1.0e6 / fixed->area;
      }

   attach_y1data (*subth_plot, subth_v, subth_imod, n_subth_pts, LT_SOLID, 1, CLR_RED);
   attach_y1data (*subth_plot, subth_v, subth_imeas, n_subth_pts, LT_DASHED, 1, CLR_BLUE);
   set_axis_labels (*subth_plot, "Vg (volts)", "Ids (mA/mm)", "", "Subthreshold Current");
   set_axis_scaling ((*subth_plot), LogY1);

   (*subth_plot)->active = FALSE;

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                              FORWARD DIODE                               */
/****************************************************************************/
/****************************************************************************/

static int fit_forward_iv (char *fwd_iv_file, FixedParams *fixed, jPLOT_ITEM **plot)
   {
#define MAX_FWD_PTS  50
   IVData data[MAX_FWD_PTS];
   double id[MAX_FWD_PTS];
   double vd[MAX_FWD_PTS];
   unsigned i,npts,j;
   double m,b,r2;
   double *vgs,*imeas,*imod;
   double r0;
   
   if (get_iv_data (fwd_iv_file, data, MAX_FWD_PTS, &npts))
      {
      printf ("Error in get_iv_data().\n");
      return -1;
      }

   for (i = 0, j = 0; i < npts; ++i)
      {
      if ((data[i].vgs <= 0.0) || (data[i].igs < 0.0) || (data[i].vds != 0.0))
         continue;
      else if ((data[i].igs * 1.0e6 / fixed->area) < 0.05)
         continue;

      id[j] = log (data[i].igs);
      vd[j] = data[i].vgs - data[i].igs * (fixed->rg + 0.5*(fixed->rs+fixed->rd));
      ++j;
      }

   if (j < 2)
      {
      printf ("Not enough points.\n");
      return 1;
      }

   linefit_mxb (vd, id, j, &m, &b, &r2);
   fixed->is = 0.5 * exp (b);
   fixed->n  = 1.0 / (m * THERMAL_V); 

   // create the graphical plot

   *plot = create_plot_item (SingleY, 2.0, 1.25, 7.0, 6.0);

   vgs = (double *) malloc (sizeof(double) * npts);
   imeas = (double *) malloc (sizeof(double) * npts);
   imod = (double *) malloc (sizeof(double) * npts);

   for (i = 0, j = 0; i < npts; ++i)
      {
      if (data[i].vds != 0.0)
         continue;

      vgs[j] = data[i].vgs - data[i].igs * fixed->rg;
      imod[j] = 2.0 * fixed->is * (exp (vgs[j] / (fixed->n * THERMAL_V)) - 1.0) * 1.0e6 / fixed->area;
      imeas[j] = data[i].igs * 1.0e6 / fixed->area;
      ++j;
      }
   
   attach_y1data (*plot, vgs, imod, j, LT_SOLID, 1, CLR_RED);
   attach_y1data (*plot, vgs, imeas, j, LT_DASHED, 1, CLR_BLUE);

   set_axis_scaling ((*plot), LogY1);
   set_axis_labels (*plot, "Vgs (volts)", "Igs (mA/mm)", "", "Forward Diode Characteristic");
   (*plot)->active = FALSE;

   return 0;   
   }
 
/****************************************************************************/
/****************************************************************************/
/*                              REVERSE DIODE                               */
/****************************************************************************/
/****************************************************************************/
   
// do an exponential fit on the last 5 points

static int breakdown_fit (IVData *data, unsigned n, double start, double stop, double *ibd, double *vbd)
   {
   double *id,*vd;
   double m,b,r2;
   unsigned i, count, index;
   double v;
   
   for (i = 0, count = 0, index = 0; i < n; ++i)
      {
      v = data[i].vds - data[i].vgs;
      if ((v >= start) && !index && (data[i].ids > 0.0))
         index = i;

      if (index && (v <= stop))
         ++count;
      }

   if (count < 2)
      {
      printf ("Not enough points.\n");
      return -1;
      }
   else if (!index)
      {
      printf ("Invalid start value.\n");
      return -1;
      }
      
   id = (double *) malloc (sizeof(double)*count);
   vd = (double *) malloc (sizeof(double)*count);

   for (i = 0; i < count; ++i)
      {
      id[i] = log (data[index+i].ids);
      vd[i] = data[index+i].vds - data[index+i].vgs;
      }
      
   linefit_mxb (vd, id, count, &m, &b, &r2);
   
   *vbd = 1.0 / m;
   *ibd = exp (b);

   free ((void *) id);
   free ((void *) vd);
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
// do an exponential fit on points from 25% to 50% of the max value

static int leakage_fit (IVData *data, unsigned n, double low_lim, double hi_lim, double *ileak, double *vleak)
   {
#define MAX_REV_PTS  50
   double id[MAX_REV_PTS],vd[MAX_REV_PTS];
   double m,b,r2;
   double v1;
   unsigned i,j = 0;

   if (n < 2)
      {
      printf ("Not enough points.\n");
      return -1;
      }

   // low_lim = 0.1 * (data[n-1].vds - data[n-1].vgs);
   // hi_lim = 0.5 * (data[n-1].vds - data[n-1].vgs);
   
   for (i = 0; i < n; ++i)
      {
      if (j >= MAX_REV_PTS)
         break;
      
      v1 = data[i].vds - data[i].vgs;
      
      if ((v1 >= low_lim) && (v1 <= hi_lim))
         {
         id[j] = log (data[i].ids);
         vd[j] = v1;
         ++j;
         }
      }
   
   if (j < 2)
      {
      printf ("Not enough points.\n");
      return -1;
      }
   
   linefit_mxb (vd, id, j, &m, &b, &r2);
   
   *vleak = 1.0 / m;
   *ileak = exp (b);
   
   return 0;   
   }
   
/*****************************************************************************/
/*****************************************************************************/
// fit the breakdown and leakage current

static int fit_reverse_breakdown (char *vbr_file, FixedParams *fixed, double vbi_start, double vbi_stop,
                                  double vbn_start, double vbn_stop, jPLOT_ITEM **plot)
   {
#define MAX_VBR_PTS   100
   IVData data[MAX_VBR_PTS];
   OPT_PARAMETER p[4];
   OPTIMIZE *opt;
   VbrOptimize vbr_erf_data;
   double *vdg,*imeas,*imod;
   unsigned i,npts,j;
   
   if (get_iv_data (vbr_file, data, MAX_VBR_PTS, &npts))
      {
      printf ("Error in get_iv_data().\n");
      return 1;
      }

   // remove the effects of Rg and Rd
   for (i = 0; i < npts; ++i)
      data[i].vgs -= data[i].ids * (fixed->rg + fixed->rd);

   printf ("Breakdown.\n");   
   if (breakdown_fit (data, npts, vbi_start, vbi_stop, &fixed->ibi, &fixed->vbi))
      {
      printf ("Error in breakdown_fit().\n");
      return 1;
      }
   
   printf ("Leakage.\n");
   if (leakage_fit (data, npts, vbn_start, vbn_stop, &fixed->ibn, &fixed->vbn))
      {
      printf ("Error in leakage_fit().\n");
      return 1;
      }
   
   // now we have initial parameter values, time to optimize
   
   printf ("Optimizing.\n");
   
   opt = initialize_cg_optimizer ();   
   set_cg_parameters (opt, p, 4);
   set_cg_error_function (opt, vbr_erf, &vbr_erf_data, 1, NULL);
   set_cg_error_fraction (opt, 1.0e-12, 5);
   if (global_show_optimization_flag)
      set_cg_flags (opt, OPT_VERBOSE);

   p[0].nom = fixed->ibi;
   strcpy (p[0].name, "Ibi");
   p[1].nom = fixed->vbi;
   strcpy (p[1].name, "Vbi");
   p[2].nom = fixed->ibn;
   strcpy (p[2].name, "Ibn");
   p[3].nom = fixed->vbn;
   strcpy (p[3].name, "Vbn");
   
   for (i = 0; i < 4; ++i)
      {
      p[i].min = 0.05 * p[i].nom;
      p[i].max = 20.0 * p[i].nom;
      p[i].tol = 0.0;
      p[i].optimize = TRUE;
      }

   vbr_erf_data.data = data;
   vbr_erf_data.n = npts;

   if (cg_optimize4 (opt, 25, NULL))
      {
      printf ("Error in cg_optimize4(): %s\n", get_cg_error());
      free ((void *) opt);
      return -1;
      }

   free ((void *) opt);
   
   fixed->ibi = p[0].nom;
   fixed->vbi = p[1].nom;
   fixed->ibn = p[2].nom;
   fixed->vbn = p[3].nom;

   // create the graphical plot

   *plot = create_plot_item (SingleY, 2.0, 1.25, 7.0, 6.0);

   vdg = (double *) malloc (sizeof(double) * npts);
   imeas = (double *) malloc (sizeof(double) * npts);
   imod = (double *) malloc (sizeof(double) * npts);

   for (i = 0, j = 0; i < npts; ++i)
      {
      if (data[i].ids <= 0.0)
         continue;

      vdg[j] = data[i].vds - data[i].vgs;
      imod[j] = switch_breakdown (vdg[j], fixed->ibi, fixed->vbi, fixed->ibn, fixed->vbn) * 1.0e6 / fixed->area;
      imeas[j] = data[i].ids * 1.0e6 / fixed->area;
      ++j;
      }
   
   attach_y1data (*plot, vdg, imod, j, LT_SOLID, 1, CLR_RED);
   attach_y1data (*plot, vdg, imeas, j, LT_DASHED, 1, CLR_BLUE);

   set_axis_scaling ((*plot), LogY1);
   set_axis_labels (*plot, "Vdg (volts)", "Idg (mA/mm)", "", "Reverse Diode Characteristic");
   (*plot)->active = FALSE;

   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                                 GRAPHICS                                 */
/****************************************************************************/
/****************************************************************************/

static int plot_data (char *dc_iv_file, jPLOT_ITEM *cap_plot, jPLOT_ITEM *gds_plot, jPLOT_ITEM *knee_plot,
                      jPLOT_ITEM *fwd_plot, jPLOT_ITEM *rev_plot, jPLOT_ITEM *subth_plot, unsigned flags)
   {
   int pdevice;
   char *pname;
   static char *legend_t[] = {"Modeled", "Measured"};
   static int legend_l[] = {LT_SOLID, LT_DASHED};
   static int legend_w[] = {1, 1};
   static int legend_c[] = {CLR_RED, CLR_BLUE};
   jHANDLE header,legend;
   char string[256],head[5000];
   FILE *file;
      
   pdevice = X_WINDOWS;
   pname = "switch.ps";
   if (flags & USE_POSTSCRIPT)
      pdevice = POSTSCRIPT;
   else if (flags & USE_METAFILE)
      pdevice = METAFILE;
   
   if (!open_graphics_device (pdevice, pname))
      {
      printf ("Error in open_graphics_device().\n");
      return -1;
      }
   
   // create the legend
   legend = add_legend (2, 9.0, 8.0, legend_t, FNT_HELVETICA, 11, legend_l, legend_w, legend_c);

   // create the header
   head[0] = 0;
   file = fopen (dc_iv_file, "r");
   if (file)
      {
      while (fgets (string, 255, file))
         {
         if (!strncmp (string, "!FILE", 5) || !strncmp (string, "!MASK", 5) || !strncmp (string, "!WAFER", 6) ||
            !strncmp (string, "!TEMP", 5) || !strncmp (string, "!DATE", 5) || !strncmp (string, "!DEVICE", 7))
            strcat (head, &string[1]);
         else if (string[0] != '!')
            break;
         }
      fclose (file);
      }
   header = add_text (head, 0.5, 8.25, FNT_HELVETICA, 10.0, 0.0, JUST_LEFT, CLR_BLACK, TS_NONE);

   /* draw all of the plots */

   // gate capacitance

   cap_plot->active = TRUE;
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   cap_plot->active = FALSE;

   // subthreshold current

   subth_plot->active = TRUE;
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   subth_plot->active = FALSE;

   // drain conductance

   gds_plot->active = TRUE;
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   gds_plot->active = FALSE;

   // drain current @ knee

   knee_plot->active = TRUE;
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   knee_plot->active = FALSE;

   // forward gate conduction

   fwd_plot->active = TRUE;
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   fwd_plot->active = FALSE;

   // reverse gate leakage

   rev_plot->active = TRUE;
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   rev_plot->active = FALSE;
   
   // if we did not write a postscript file, recursively call the function to do so
   if (!(flags & USE_POSTSCRIPT))
      {
      // remove these items b/c they are created a second time during a recursive call
      remove_user_item (header);
      remove_user_item (legend);

      flags |= USE_POSTSCRIPT;
      return plot_data (dc_iv_file, cap_plot, gds_plot, knee_plot, fwd_plot, rev_plot, subth_plot, flags);
      }

   close_graphics_device ();
   
   return 0;
   }








