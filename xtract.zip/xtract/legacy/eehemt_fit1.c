#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize4.h"
#include "jplot.h"
#include "fit_tools.h"

/****** MACROS AND DEFINITIONS ******/

#define CHECK_DERIV   0

#define VERSION      2.0

#define sqr(x)      ((x)*(x))
#define sech2(x)    (1.0-sqr(tanh(x)))

#define MAX_AC_BIAS_PTS    250
#define MAX_DCIV_PTS       1000
#define MAX_DIODE_PTS      100
#define MAX_FWD_IGS        0.5      // in mA/mm
#define MAX_EXP_ARG        30.0

// ohmic contact resistance per mm
#define OHMIC_R_PER_MM     0.1

#define BOLTZMANN     1.380066e-23
#define Q_ELECTRON    1.60218e-19
#define CTOK          273.15

// plot definitions
#define MOD_LTYPE     LT_SOLID
#define MEAS_LTYPE    LT_DOTTED
#define MOD_COLOR     CLR_RED
#define MEAS_COLOR    CLR_DARKGREEN
#define PLOT_X        1.25
#define PLOT_Y        1.25
#define PLOT_XSIZE    6.0
#define PLOT_YSIZE    5.5

typedef struct
   {
   double vgs,vds,igs,ids;
   double cgs,cgd,cds;
   double gm,gds,tau,tau2;
   } AC_PARAMETERS;

typedef struct
   {
   double area,ugw,ngf;
   double rg,rd,rs,ri;
   double lg,ld,ls;
   double cpg,cpd,c11,c22;
   double is,n;
   double tnom;
   } FIXED_PARAMS;

typedef struct
   {
   unsigned ndc, nsub;
   IV_DATA *dcdata, *subdata;
   double max_vds;
   double periphery;
   } DCIV_OPT;

typedef struct
   {
   unsigned n;
   AC_PARAMETERS *data;
   double max_vds;
   double periphery;
   } AC_OPT;

/* -------- FUNCTION PROTOTYPES ---------- */

static void get_file_header (char *data_file, char *header, unsigned max_size);
static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params, FIXED_PARAMS fixed);

static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                                   FIXED_PARAMS *fixed_params, unsigned *n);

static int dciv_erf (double *p, void *data, double *err, unsigned n_err);
static int charge_erf (double *p, void *data, double *err, unsigned n_err);
static int gm_gds_erf (double *p, void *data, double *err, unsigned n_err);
static int vbr_erf (double *p, void *data, double *err, unsigned n_err);

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling);
static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n);

static int fit_diode_curves (char *fwd_iv_file, FIXED_PARAMS *fixed_p, jPLOT_ITEM **vf_plot);
static int fit_vbr_curves (char *vbr_file, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                           jPLOT_ITEM **vbr_plot);
static int fit_dc_curves (char *dc_iv_file, MODEL_PARAMS *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot);
static int fit_capacitance_data (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                                 double max_vds, double *weights, jPLOT_ITEM **y11_plot, jPLOT_ITEM **y12_plot,
                                 jPLOT_ITEM **y21_plot, jPLOT_ITEM **y22_plot);
static int fit_gm_gds (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                       jPLOT_ITEM **gm_plot, jPLOT_ITEM **gds_plot);

static double safe_pow (double x, double y);
static void write_starting_files (char *input_file, char *param_file);

static void check_parameter_ranges (MODEL_PARAMS *p, double Vmax, double Vpo);
static void read_vmax_from_file (char *fname, double *vmax, double *vpo);

static double eehemt_current (double *p, double Vgs, double Vds, double *Gm, double *Gds);
static void eehemt_charge (double *p, double Vgs, double Vgd, double *Cgs, double *dQgs_vgd, 
                           double *Cgd, double *dQgd_vgs);
static double eehemt_breakdown (double *p, double Vgs, double Vds);


/* ------------- GLOBAL VARIABLES -------------- */

char global_warning_msg[5000];

char *global_dciv_param_names[] = {"vto", "gamma", "vgo", "vch", "gmmax", "vsat", "kapa", "peff",
   "vtso", "vco", "vba", "vbc", "mu", "deltgm", "alpha", "vdso", "gdbm", "kdb", "vdsm"
   };
char *global_aciv_param_names[] = {"vtoac", "gammaac", "vgo", "vch", "gmmaxac", "vsat", "kapaac", "peffac",
   "vtsoac", "vco", "vba", "vbc", "mu", "deltgm", "alpha", "vdso", "gdbm", "kdb", "vdsm"
   };
#define N_IV_PARAMS  19

#define GDBM_INDEX   16

char *global_charge_param_names[] = {"vtoac", "gammaac", "vgo", "vch", "gmmaxac", "vsat", "kapaac", "peffac",
   "vtsoac", "vco", "vba", "vbc", "mu", "deltgm", "alpha", "vdso", "gdbm", "kdb", "vdsm",
   "cdso", "tau", "c11o", "c11th", "c12sat", "cgdsat", "vinfl", "deltgs", "deltds", "lambda"
   };
#define N_CHARGE_PARAMS   29

#define CDS_INDEX    19
#define TAU_INDEX    20

char *global_vbr_param_names[] = {"vto", "gamma", "vgo", "vch", "gmmax", "vsat", "kapa", "peff",
   "vtso", "vco", "vba", "vbc", "mu", "deltgm", "alpha", "vdso", "gdbm", "kdb", "vdsm",
   "vbr", "nbr", "kbk", "idsoc"
   };
#define N_VBR_PARAMS    23

double global_qgs, global_qgd;


/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   char string[256];
   char model_summary_file[100], start_file[100], end_file[100];
   char model_file[100], yfit_file[100], dc_iv_file[100];
   char fwd_iv_file[100], breakdown_file[100], header[3000];
   MODEL_PARAMS *params;
   AC_PARAMETERS ac_data[MAX_AC_BIAS_PTS];
   FIXED_PARAMS fixed_params;
   unsigned num_ac_bias_pts, niter;
   double maximum_vds;
   double weights[] = {50.0, 1000.0, 1.0, 0.05};
   jPLOT_ITEM *p_subth = NULL, *p_dciv = NULL, *p_cgs = NULL;
   jPLOT_ITEM *p_cgd = NULL, *p_cds = NULL, *p_tau = NULL, *p_dfwd = NULL, *p_drev = NULL;
   jPLOT_ITEM *p_gm = NULL, *p_gds = NULL;
   int plot_dev = X_WINDOWS;
   int i;
   int no_dc = 0;
   int no_gm = 0;
   int no_cap = 0;
   int no_fix = 0;
   double vmax, vpo;

   global_warning_msg[0] = 0;

   /**** parse the command line ****/

   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i], "-i", 2) || !strncmp (argv[i], "-e", 2))
         {
         write_starting_files ("eehemtin", "eehemt.start");
         return 0;
         }
      else if (!strncmp (argv[i], "-h", 2))
         {
         printf ("\n\n");

         printf ("EEHEMT1 model fitter options:\n");
         printf ("------------------------------------------------------------------\n");
         printf ("  -i, -e    Auto-generate an input file named parkerin and a\n");
         printf ("              starting values file named parker.start.\n");
         printf ("  -dP, -dp  Set plot device to postscript.\n");
         printf ("  -dM, -dm  Set plot device to metafile.\n");
         printf ("  -d0       Disable plotting.\n");
         printf ("  -skipdc   Skip the DC I-V fitting routine.\n");
         printf ("  -skipgm   Skip the transconductance fitting routine.\n");
         printf ("  -skipcap  Skip the capacitance/charge fitting routine.\n");
         printf ("  -nofix    Do not reset parameter ranges for certain parameters.\n");

         printf ("\n\n");

         return 0;
         }
      else if (!strncmp (argv[i], "-d", 2))
         {
         char ch = 0;
         sscanf (argv[i], "-d%c", &ch);
         if ((ch == 'm') || (ch == 'M'))
            plot_dev = METAFILE;
         else if ((ch == 'p') || (ch == 'P'))
            plot_dev = POSTSCRIPT;
         else if (ch == '0')
            plot_dev = 0;
         else
            printf ("Warning: invalid -d option.\n");
         }
      else if (!strncmp (argv[i], "-skipdc", 7))
         no_dc = 1;
      else if (!strncmp (argv[i], "-skipgm", 7))
         no_gm = 1;
      else if (!strncmp (argv[i], "-skipcap", 8))
         no_cap = 1;
      else if (!strncmp (argv[i], "-nofix", 6))
         no_fix = 1;
      }

   /**** get user input ****/

   printf ("Number of gate fingers?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ngf);

   printf ("Unit gate width?\n");
   fgets (string,255,stdin);
   sscanf (string, "%lf", &fixed_params.ugw);

   fixed_params.area = fixed_params.ngf * fixed_params.ugw;

   printf ("Measurement temperature?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&fixed_params.tnom);

   printf ("Y-fit end file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",yfit_file);

   printf ("Model summary file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_summary_file);

   printf ("DC IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Forward IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",breakdown_file);

   printf ("Start parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string,255,stdin);
   sscanf (string,"%d",&niter);

   printf ("Capacitance fitting weights [y11 y12 y21 y22]?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2], &weights[3]);

   /**** get measurement and extraction data ****/

   if (read_model_parameters_from_file (start_file, &params, NULL))
      return 1;

   if (get_ss_parameters (model_summary_file, yfit_file, ac_data, MAX_AC_BIAS_PTS, &fixed_params, &num_ac_bias_pts))
      return 1;

   // read in Vmax, use for VBI model parameter
   read_vmax_from_file (fwd_iv_file, &vmax, &vpo);

   // check for bad starting values or illegal range values 
   //    (i.e. parameters that must be >= 0)
   if ((niter > 0) && !no_fix)
      check_parameter_ranges (params, vmax, vpo);

   // set rd/rs to an approximate ohmic contact resistance
   fixed_params.rd = fixed_params.rs = OHMIC_R_PER_MM * 1000.0 / fixed_params.area;

   // determine the intrinsic node voltages for the ac parameters    
   for (i = 0; i < num_ac_bias_pts; ++i)
      {
      ac_data[i].vds -= fixed_params.rd*ac_data[i].ids +
         fixed_params.rs*(ac_data[i].ids + ac_data[i].igs);
      ac_data[i].vgs -= (fixed_params.rg + fixed_params.ri)*ac_data[i].igs + 
         fixed_params.rs*(ac_data[i].ids + ac_data[i].igs);
      }

   /**** perform various parameter fits ****/

   if (fit_diode_curves (fwd_iv_file, &fixed_params, &p_dfwd))
      return 1;

   if (!no_dc)
      {
      if (fit_dc_curves (dc_iv_file, params, maximum_vds, niter, &fixed_params, &p_subth, &p_dciv))
         return 1;

      if (fit_vbr_curves (breakdown_file, params, (niter ? 50 : 0), &fixed_params, &p_drev))
         return 1;
      }

   if (!no_gm)
      {
      if ((niter > 0) && !no_fix)
         {
         OPT_PARAMETER x;
         
         // copy VTO to VTOAC 
         get_parameter_value ("vto", params, &x);
         sprintf (x.name, "vtoac");
         set_parameter_value (params, x);

         // copy VTSO to VTSOAC
         get_parameter_value ("vtso", params, &x);
         sprintf (x.name, "vtsoac");
         set_parameter_value (params, x);
         }

      if (fit_gm_gds (ac_data, num_ac_bias_pts, params, niter, &fixed_params, &p_gm, &p_gds))
         return 1;
      }

   if (!no_cap)
      {
      if (fit_capacitance_data (ac_data, num_ac_bias_pts, params, niter, &fixed_params, maximum_vds, weights, &p_cgs, &p_cgd, &p_cds, &p_tau))
         return 1;
      }

   /**** Write final data files ****/
   
   printf ("Writing data files.\n");

   get_file_header (fwd_iv_file, header, 3000);

   if (write_data_files (end_file, model_file, header, params, fixed_params))
      return 1;

   /***** Generate plots *****/

   if (plot_dev)
      {
      jPLOT_ITEM *plot_list[10];
      char plot_head[1000];
      FILE *file;

      plot_head[0] = 0;

      // get the plot header

      file = fopen (fwd_iv_file, "r");
      if (file)
         {
         while (fgets (string, 255, file))
            {
            if (string[0] != '!')
               break;

            if (!strncmp (string, "!MASK", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!WAFER", 6))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DEVICE", 7))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!TEMP", 5))
               strcat (plot_head, &string[1]);
            else if (!strncmp (string, "!DATE", 5))
               strcat (plot_head, &string[1]);
            }

         fclose (file);
         }

      plot_list[0] = p_subth;
      plot_list[1] = p_dciv;
      plot_list[2] = p_gm;
      plot_list[3] = p_gds;
      plot_list[4] = p_cgs;
      plot_list[5] = p_cgd;
      plot_list[6] = p_cds;
      plot_list[7] = p_tau;
      plot_list[8] = p_dfwd;
      plot_list[9] = p_drev;

      if (plot_data (plot_dev, plot_head, plot_list, 10))
         return 1;
      }

   if (global_warning_msg[0])
      {
      printf ("\n%s", global_warning_msg);
      printf ("\nModel fitting completed with warnings.\n\n");
      }
   else
      printf ("\n\nModel fitting complete.\n\n");

   return 0;
   }
  
/*****************************************************************************/
/*****************************************************************************/

static int fit_diode_curves (char *fwd_iv_file, FIXED_PARAMS *fixed_p, jPLOT_ITEM **vf_plot)
   {
   IV_DATA fwd_curves[MAX_DIODE_PTS];
   unsigned n_fwd_pts;
   double v[MAX_DIODE_PTS], i[MAX_DIODE_PTS];
   unsigned j, k;
   double m, b, r2;
   double *vf, *if_meas, *if_mod;

   /***** Forward IV *****/
   
   printf ("Forward Diode IV.\n");
   
   if (get_iv_data (fwd_iv_file, fwd_curves, MAX_DIODE_PTS, &n_fwd_pts))
      return 1;

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
      {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 1.0e-8*fixed_p->area))
         {
         v[k] = fwd_curves[j].vgs;
         i[k] = log (fwd_curves[j].igs);
         ++k;
         }
      }

   if (k < 2)
      {
      fprintf (stderr, "Error: %s: not enough points.\n", fwd_iv_file);
      return 1;
      }

   linefit_mxb (v, i, k, &m, &b, &r2);

   fixed_p->is = 0.5 * exp (b);
   fixed_p->n = Q_ELECTRON / (m * BOLTZMANN * (fixed_p->tnom + CTOK));

   // create a plot

   vf = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_meas = (double *) malloc (sizeof(double)*n_fwd_pts);
   if_mod = (double *) malloc (sizeof(double)*n_fwd_pts);

   for (j = 0, k = 0; j < n_fwd_pts; ++j)
      {
      if ((fwd_curves[j].vds == 0.0) && (fwd_curves[j].igs > 0.0))
         {
         vf[k] = fwd_curves[j].vgs;
         if_meas[k] = fwd_curves[j].igs * 1.0e6 / fixed_p->area;
         if_mod[k] = 2.0 * fixed_p->is * (exp (vf[k] * Q_ELECTRON / (fixed_p->n * BOLTZMANN * (fixed_p->tnom + CTOK))) - 1.0) * 1.0e6 / fixed_p->area;
         ++k;
         }
      }

   create_plot (vf_plot, vf, if_meas, if_mod, k, "Vgs (volts)", "Igs (mA/mm)", "Diode Characteristic", LogY1);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_vbr_curves (char *vbr_file, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                           jPLOT_ITEM **vbr_plot)
   {
   IV_DATA vbr_curves[MAX_DIODE_PTS], vbr2[MAX_DIODE_PTS];
   unsigned n_pts, n;
   OPT_PARAMETER pp[N_VBR_PARAMS];
   double pl[N_VBR_PARAMS];
   unsigned j, k;
   double *v, *i_meas, *i_mod;
   double midpt;

   printf ("Breakdown.\n");

   // load the parameter starting values from the MODEL_PARAMS structure

   if (get_all_parameters (global_vbr_param_names, N_VBR_PARAMS, p, pp))
      return 1;

   // load the Vbr curve data
   if (get_iv_data (vbr_file, vbr_curves, MAX_DIODE_PTS, &n_pts))
      return 1;

   // determine the half breakdown value
   midpt = 0.5 * (vbr_curves[n_pts-1].vds - vbr_curves[n_pts-1].vgs);

   // create a sub-set of the breakdown data
   for (j = 0, n = 0; j < n_pts; ++j)
      {
      if ((vbr_curves[j].vds - vbr_curves[j].vgs) >= midpt)
         {
         vbr2[n] = vbr_curves[j];
         ++n;
         }
      }

   // optimization
   if (niter > 0)
      {
      OPTIMIZE *opt;
      DCIV_OPT vbr_data;
      OPT_PARAMETER tmp;

      // set the value of VBR
      pp[19].min = midpt - 2.0;
      pp[19].nom = midpt;
      pp[19].max = midpt + 1.0;

      vbr_data.ndc = n;
      vbr_data.dcdata = vbr2;
      vbr_data.periphery = fixed_p->area;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_VBR_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);
      set_cg_error_function (opt, vbr_erf, &vbr_data, 1, NULL);
      set_cg_error_fraction (opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for (j = 19; j <= 21; ++j)
         pp[j].optimize = TRUE;

      // set GDBM to 0 (turns off dispersion source calculation)
      tmp = pp[GDBM_INDEX];
      pp[GDBM_INDEX].min = pp[GDBM_INDEX].nom = pp[GDBM_INDEX].max = 0.0;

      // optimize
      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return -1;
         }

      // restore the value of GDBM
      pp[GDBM_INDEX] = tmp;

      free ((void *) opt);

      if (set_all_parameters (p, pp, N_VBR_PARAMS))
         return 1;
      }

   // create a plot 

   for (j = 0; j < N_VBR_PARAMS; ++j)
      pl[j] = pp[j].nom;

   v = (double *) malloc (sizeof(double)*n);
   i_meas = (double *) malloc (sizeof(double)*n);
   i_mod = (double *) malloc (sizeof(double)*n);

   for (j = 0, k = 0; j < n; ++j)
      {
      if (eehemt_breakdown (pl, vbr2[j].vgs, vbr2[j].vds) > 0.0)
         {
         v[k] = vbr2[j].vds - vbr2[j].vgs;
         i_meas[k] = -vbr2[j].igs * 1.0e6 / fixed_p->area;
         i_mod[k] = eehemt_breakdown (pl, vbr2[j].vgs, vbr2[j].vds) * 1.0e6 / fixed_p->area;
         ++k;
         }
      }

   create_plot (vbr_plot, v, i_meas, i_mod, k, "Vdg (volts)", "Idg (mA/mm)", "Breakdown Characteristic", LogY1);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_dc_curves (char *dc_iv_file, MODEL_PARAMS *p, double max_vds, unsigned niter, FIXED_PARAMS *fixed_p,
                          jPLOT_ITEM **subth_plot, jPLOT_ITEM **dciv_plot)
   {
   unsigned n_iv_pts, n_subth_pts;
   IV_DATA dciv_curves[MAX_DCIV_PTS];
   IV_DATA subth_data[MAX_DCIV_PTS];
   double *subth_v, *subth_imeas, *subth_imod;
   double *dciv_v, *dciv_imod, *dciv_imeas;
   unsigned i, j;
   double pl[N_IV_PARAMS];
   OPT_PARAMETER pp[N_IV_PARAMS];

   printf ("DC IV data.\n");

   // load the parameter starting values from the MODEL_PARAMS structure

   if (get_all_parameters (global_dciv_param_names, N_IV_PARAMS, p, pp))
      return 1;

   // load the DC I-V curve data

   if (get_iv_data (dc_iv_file, dciv_curves, MAX_DCIV_PTS, &n_iv_pts))
      return 1;

   // create the subthreshold data set
   for (i = 0, n_subth_pts = 0; i < n_iv_pts; ++i)
      {
      if ((dciv_curves[i].vds < 2.0) || (dciv_curves[i].vds > max_vds) || 
         (dciv_curves[i].ids > 100e-6*fixed_p->area) || (dciv_curves[i].ids <= 0.0))
         continue;

      subth_data[n_subth_pts] = dciv_curves[i];
      ++n_subth_pts;
      }

   if (!n_subth_pts)
      {
      printf ("Error: unable to form subthreshold data set.\n");
      return 1;
      }

   // sort the subthreshold data set
   for (i = 0; i < n_subth_pts; ++i)
      {
      for (j = i+1; j < n_subth_pts; ++j)
         {
         if ((subth_data[j].vds < subth_data[i].vds) ||
            ((subth_data[j].vds == subth_data[i].vds) && (subth_data[j].vgs < subth_data[i].vgs)))
            {
            IV_DATA tmp = subth_data[i];
            subth_data[i] = subth_data[j];
            subth_data[j] = tmp;
            }
         }
      }

   // apply port resistances to active region data
   for (i = 0; i < n_iv_pts; ++i)
      {
      if (dciv_curves[i].igs < 0.0)
         dciv_curves[i].vgs -= dciv_curves[i].ids*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;
      else
         dciv_curves[i].vgs -= (dciv_curves[i].ids + dciv_curves[i].igs)*fixed_p->rs + dciv_curves[i].igs*fixed_p->rg;

      dciv_curves[i].vds -= (dciv_curves[i].ids + 0.5*dciv_curves[i].igs) * (fixed_p->rs + fixed_p->rd);
      }

   // optimization
   if (niter > 0)
      {
      OPTIMIZE *opt;
      DCIV_OPT dciv_data;
      double wght[] = {10.0, 1.0};
      OPT_PARAMETER tmp;

      dciv_data.ndc = n_iv_pts;
      dciv_data.dcdata = dciv_curves;
      dciv_data.nsub = n_subth_pts;
      dciv_data.subdata = subth_data;
      dciv_data.max_vds = max_vds;
      dciv_data.periphery = fixed_p->area;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_IV_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_AUTO);
      set_cg_error_function (opt, dciv_erf, &dciv_data, 2, wght);
      set_cg_error_fraction (opt, 1.0e-9, 5);

      // turn on optimization for appropriate parameters
      for (i = 0; i <= 14; ++i)
         pp[i].optimize = TRUE;

      // set GDBM to 0 (turns off dispersion source calculation)
      tmp = pp[GDBM_INDEX];
      pp[GDBM_INDEX].min = pp[GDBM_INDEX].nom = pp[GDBM_INDEX].max = 0.0;

      // optimize
      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return -1;
         }

      // restore the value of GDBM
      pp[GDBM_INDEX] = tmp;

      free ((void *) opt);

      if (set_all_parameters (p, pp, N_IV_PARAMS))
         return 1;
      }

   /* create plots */

   subth_v = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imeas = (double *) malloc (sizeof (double) * n_subth_pts);
   subth_imod = (double *) malloc (sizeof (double) * n_subth_pts);
   dciv_v = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imeas = (double *) malloc (sizeof (double) * n_iv_pts);
   dciv_imod = (double *) malloc (sizeof (double) * n_iv_pts);

   for (i = 0; i < N_IV_PARAMS; ++i)
      pl[i] = pp[i].nom;

   for (i = 0; i < n_subth_pts; ++i)
      {
      subth_v[i] = subth_data[i].vgs;
      subth_imeas[i] = subth_data[i].ids * 1.0e6 / fixed_p->area;
      subth_imod[i] = eehemt_current (pl, subth_data[i].vgs, subth_data[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
      }

   create_plot (subth_plot, subth_v, subth_imeas, subth_imod, n_subth_pts, "Vgs (volts)", "Ids (mA/mm)", "Sub-Threshold Current", LogY1);

   for (i = 0; i < n_iv_pts; ++i)
      {
      dciv_v[i] = dciv_curves[i].vds;
      dciv_imeas[i] = dciv_curves[i].ids * 1.0e6 / fixed_p->area;
      dciv_imod[i] = eehemt_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds, NULL, NULL) * 1.0e6 / fixed_p->area;
      }

   create_plot (dciv_plot, dciv_v, dciv_imeas, dciv_imod, n_iv_pts, "Vds (volts)", "Ids (mA/mm)", "DC I-V Curves", POSITIVE_X | POSITIVE_Y1);

   if (CHECK_DERIV)
      {
      double gm, gds, gm1, gm2, gds1, gds2;
      double del = 1.0e-3;
      FILE *file = fopen ("iv_deriv.txt", "w+");
      if (!file)
         return 0;

      fprintf (file, "! Vgs Vds Gm Gm_num Gds Gds_num\n");
      for (i = 0; i < n_iv_pts; ++i)
         {
         gm1 = eehemt_current (pl, dciv_curves[i].vgs+del, dciv_curves[i].vds, NULL, NULL);
         gm2 = eehemt_current (pl, dciv_curves[i].vgs-del, dciv_curves[i].vds, NULL, NULL);
         gds1 = eehemt_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds+del, NULL, NULL);
         gds2 = eehemt_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds-del, NULL, NULL);
         eehemt_current (pl, dciv_curves[i].vgs, dciv_curves[i].vds, &gm, &gds);
         fprintf (file, "%.3f %.2f\t\t%.4e %.4e\t\t%.4e %.4e\n", dciv_curves[i].vgs, dciv_curves[i].vds,
            gm, (gm1-gm2) / (2.0*del), gds, (gds1-gds2) / (2.0*del));
         }
      fclose (file);
      }

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_capacitance_data (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                                 double max_vds, double *weights, jPLOT_ITEM **cgs_plot, jPLOT_ITEM **cgd_plot,
                                 jPLOT_ITEM **cds_plot, jPLOT_ITEM **tau_plot)
   {
   double *v, *cgs_meas, *cgs_mod, *cgd_meas, *cgd_mod;
   double *cds_meas, *cds_mod, *tau_mod, *tau_meas;
   unsigned i, j;
   double cgs, cgd, qgs_vgd, qgd_vgs, cds, gm, tau;
   OPT_PARAMETER pp[N_CHARGE_PARAMS];
   double pl[N_CHARGE_PARAMS];

   printf ("Gate Charge.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (global_charge_param_names, N_CHARGE_PARAMS, p, pp))
      return 1;

   // optimization
   if (niter > 0)
      {
      double cds_ave = 0.0;
      double tau_ave = 0.0;
      AC_OPT cap_data;
      OPTIMIZE *opt;

      // set starting values for Tau and Cds
      for (i = 0, j = 0; i < n; ++i)
         {
         if ((ac_data[i].vds < 2.0) || (ac_data[i].ids < fixed_p->area*10.0e-6))
            continue;

         cds_ave += ac_data[i].cds;
         tau_ave += ac_data[i].tau;
         ++j;
         }

      if (!j)
         j = 1;

      cds_ave /= (double) j;
      tau_ave /= (double) j;

      pp[CDS_INDEX].nom = cds_ave;
      pp[CDS_INDEX].min = 0.0;
      pp[CDS_INDEX].max = 4.0*cds_ave;

      pp[TAU_INDEX].nom = tau_ave;
      pp[TAU_INDEX].min = 0.0;
      pp[TAU_INDEX].max = 4.0*tau_ave;

      //  prepare for optimization

      cap_data.periphery = fixed_p->area;
      cap_data.max_vds = max_vds;
      cap_data.n = n;
      cap_data.data = ac_data;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_CHARGE_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

      set_cg_error_function (opt, charge_erf, &cap_data, 4, weights);
      set_cg_error_fraction (opt, 1.0e-12, 5);

      // set the appropriate optimization parameters
      for (i = 19; i <= 28; ++i)
         pp[i].optimize = TRUE;
      pp[27].optimize = FALSE;  // turn off DELTDS

      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return 1;
         }

      free ((void *) opt);

      if (set_all_parameters (p, pp, N_CHARGE_PARAMS))
         return 1;

      if (0)
         {
         for (i = 0; i < N_CHARGE_PARAMS; ++i)
            printf ("%s\t%.4e\t%.4e\t%.4e\t%s\n", pp[i].name, pp[i].min, pp[i].nom, pp[i].max, (pp[i].optimize ? "TRUE" : "FALSE"));
         }

      if (0)
         {
         double err1[4], err2[4], errt[4], errx, tmp, del;
         unsigned j;

         for (i = 0; i < N_CHARGE_PARAMS; ++i)
            pl[i] = pp[i].nom;

         for (i = 19; i <= 28; ++i)
            {
            for (j = 0; j < 4; ++j)
               err1[j] = err2[j] = 0.0;

            del = (pp[i].max - pp[i].min)*1.0e-3;
            if (del < 1.0e-15)
               del = 1.0e-15;
            tmp = pl[i];
            pl[i] = tmp + del;
            charge_erf (pl, (void *) &cap_data, err1, 4);
            pl[i] = tmp - del;
            charge_erf (pl, (void *) &cap_data, err2, 4);
            pl[i] = tmp;

            errx = 0.0;
            for (j = 0; j < 4; ++j)
               {
               errt[j] = (err1[j] - err2[j]) / (2.0*del);
               errx += errt[j]*weights[j];
               }

            printf ("%s\t%.3e\t%.3e\t%.3e\t%.3e\t=\t%.3e\n", pp[i].name, errt[0], errt[1], errt[2], errt[3], errx);
            }
         }
      }

   /* create plots */

   for (i = 0; i < N_CHARGE_PARAMS; ++i)
      pl[i] = pp[i].nom;

   v = (double *) malloc (sizeof (double)*n);
   cgs_mod = (double *) malloc (sizeof (double)*n);
   cgs_meas = (double *) malloc (sizeof (double)*n);
   cgd_mod = (double *) malloc (sizeof (double)*n);
   cgd_meas = (double *) malloc (sizeof (double)*n);
   cds_mod = (double *) malloc (sizeof (double)*n);
   cds_meas = (double *) malloc (sizeof (double)*n);
   tau_mod = (double *) malloc (sizeof (double)*n);
   tau_meas = (double *) malloc (sizeof (double)*n);

   cds = pl[CDS_INDEX];
   tau = pl[TAU_INDEX];
   for (i = 0; i < n; ++i)
      {
      eehemt_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);      
      eehemt_current (pl, ac_data[i].vgs, ac_data[i].vds, &gm, NULL);

      cgs_mod[i] = (cgs + qgd_vgs) * 1.0e15 / fixed_p->area;
      cgs_meas[i] = ac_data[i].cgs * 1.0e15 / fixed_p->area;

      cgd_mod[i] = (cgd + qgs_vgd) * 1.0e15 / fixed_p->area;
      cgd_meas[i] = ac_data[i].cgd * 1.0e15 / fixed_p->area;
      
      cds_mod[i] = (cds - qgs_vgd) * 1.0e15 / fixed_p->area;
      cds_meas[i] = (ac_data[i].cds - ac_data[i].gds*ac_data[i].tau2) * 1.0e15 / fixed_p->area;

      tau_mod[i] = (tau + (qgd_vgs-qgs_vgd)/gm) * 1.0e12;
      tau_meas[i] = ac_data[i].tau * 1.0e12;

      v[i] = ac_data[i].vds;
      }

   create_plot (cgs_plot, v, cgs_meas, cgs_mod, n, "Vds (volts)", "pF/mm", "Cgs", 0);
   create_plot (cgd_plot, v, cgd_meas, cgd_mod, n, "Vds (volts)", "pF/mm", "Cgd", 0);
   create_plot (cds_plot, v, cds_meas, cds_mod, n, "Vds (volts)", "pF/mm", "Cds", 0);
   create_plot (tau_plot, v, tau_meas, tau_mod, n, "Vds (volts)", "pS", "Tau", 0);
   set_y1_scale (*tau_plot, 0.0, 10.0, 2.0, 4, 0, "");

   if (CHECK_DERIV)
      {
      double cgs, cgd, dqgs_vgd, dqgd_vgs;
      double cgs1, cgs2, cgd1, cgd2;
      double dqgs1, dqgs2, dqgd1, dqgd2;
      double del = 1.0e-3;
      FILE *file = fopen ("charge_deriv.txt", "w+");
      if (!file)
         return 0;

      fprintf (file, "! Vgs Vds Cgs Cgs_num Cgd Cgd_num dQgs_vgd dQgs_vgd_num dQgd_vgs dQgd_vgs_num\n");
      for (i = 0; i < n; ++i)
         {
         eehemt_charge (pl, ac_data[i].vgs+del, ac_data[i].vgs - ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgs1 = global_qgs;
         dqgd1 = global_qgd;
         eehemt_charge (pl, ac_data[i].vgs-del, ac_data[i].vgs - ac_data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgs2 = global_qgs;
         dqgd2 = global_qgd;
         eehemt_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds + del, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgd1 = global_qgd;
         dqgs1 = global_qgs;
         eehemt_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds - del, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
         cgd2 = global_qgd;
         dqgs2 = global_qgs;
         eehemt_charge (pl, ac_data[i].vgs, ac_data[i].vgs - ac_data[i].vds, &cgs, &dqgs_vgd, &cgd, &dqgd_vgs);
         fprintf (file, "%.3f %.2f\t%.4e %.4e\t%.4e %.4e\t%.4e %.4e\t%.4e %.4e\n", ac_data[i].vgs, ac_data[i].vds,
            cgs, (cgs1-cgs2) / (2.0*del), cgd, (cgd1-cgd2) / (2.0*del),
            dqgs_vgd, (dqgs1-dqgs2) / (2.0*del), dqgd_vgs, (dqgd1-dqgd2) / (2.0*del));
         }
      fclose (file);
      }

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int fit_gm_gds (AC_PARAMETERS *ac_data, unsigned n, MODEL_PARAMS *p, unsigned niter, FIXED_PARAMS *fixed_p,
                       jPLOT_ITEM **gm_plot, jPLOT_ITEM **gds_plot)
   {
   unsigned i;
   double gm, gds;
   double *v, *gm_meas, *gm_mod, *gds_meas, *gds_mod;
   OPT_PARAMETER pp[N_IV_PARAMS];
   double pl[N_IV_PARAMS];
  
   printf ("RF conductances.\n");

   // load the parameter starting values from the MODEL_PARAMS structure
   if (get_all_parameters (global_aciv_param_names, N_IV_PARAMS, p, pp))
      return 1;

   // optimization
   if (niter > 0)
      {
      AC_OPT gm_data;
      OPTIMIZE *opt;
      double wght[] = {0.1, 10.0};

      gm_data.periphery = fixed_p->area;
      gm_data.n = n;
      gm_data.data = ac_data;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, pp, N_IV_PARAMS);
      set_cg_flags (opt, OPT_VERBOSE | OPT_SINGLE_PARAM);

      set_cg_error_function (opt, gm_gds_erf, &gm_data, 2, wght);
      set_cg_error_fraction (opt, 1.0e-12, 5);

      pp[0].optimize = TRUE;
      pp[1].optimize = TRUE;
      pp[4].optimize = TRUE;
      pp[6].optimize = TRUE;
      pp[7].optimize = TRUE;
      pp[8].optimize = TRUE;
      for (i = 16; i <= 18; ++i)
         pp[i].optimize = TRUE;

      if (cg_optimize4 (opt, niter, NULL))
         {
         fprintf (stderr, "Error: cg_optimize4(): %s.\n", get_cg_error ());
         return 1;
         }

      free ((void *) opt);

      if (set_all_parameters (p, pp, N_IV_PARAMS))
         return 1;
      }
   
   // create plots

   for (i = 0; i < N_IV_PARAMS; ++i)
      pl[i] = pp[i].nom;

   v = (double *) malloc (sizeof (double)*n);
   gm_mod = (double *) malloc (sizeof (double)*n);
   gm_meas = (double *) malloc (sizeof (double)*n);
   gds_mod = (double *) malloc (sizeof (double)*n);
   gds_meas = (double *) malloc (sizeof (double)*n);

   for (i = 0; i < n; ++i)
      {
      eehemt_current (pl, ac_data[i].vgs, ac_data[i].vds, &gm, &gds);
      gm_mod[i] = gm * 1.0e6 / fixed_p->area;
      gm_meas[i] = ac_data[i].gm * 1.0e6 / fixed_p->area;
      gds_mod[i] = gds * 1.0e6 / fixed_p->area;
      gds_meas[i] = ac_data[i].gds * 1.0e6 / fixed_p->area;
      v[i] = ac_data[i].vds;
      }

   create_plot (gm_plot, v, gm_meas, gm_mod, n, "Vds (volts)", "Gm (mS/mm)", "Transconductance", 0);
   create_plot (gds_plot, v, gds_meas, gds_mod, n, "Vds (volts)", "Gds (mS/mm)", "Drain Conductance", 0);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                              MODEL FUNCTIONS                              */
/*****************************************************************************/
/*****************************************************************************/

// this function was taken from the Agilent eefet3 source code (and modified)
static double eehemt_current (double *p, double Vgs, double Vds, double *Gm, double *Gds)
   {
   double VTO = p[0];
   double GAMMA = p[1];
   double VGO = p[2];
   double VCH = p[3];
   double GMMAX = p[4];
   double VSAT = p[5];
   double KAPA = p[6];
   double PEFF = p[7];
   double VTSO = p[8];
   double VCO = p[9];
   double VBA = p[10];
   double VBC = p[11];
   double MU = p[12];
   double DELTGM = p[13];
   double ALPHA = p[14];
   double VDS0 = p[15];
   double GDBM = p[16];
   double KDB = p[17];
   double VDSM = p[18];
   double gmoff, dvo, dvj, vt, vts, vjx, vg, v1, vc, vb, va;
   double ids1, gds1, gmgs, Ids;

   if (VCO >= VGO)
      gmoff = GMMAX;
   else if (VCO <= VTO)
      gmoff = 0.0;
   else
      gmoff = 0.5*GMMAX*(cos(PI*(VCO-VGO)/(VTO-VGO)) + 1.0);

   dvo = VDS0 - Vds;
   dvj = 1.0 + GAMMA*dvo;
   if (dvj < 1.0e-6)   /* don't let dvj go to 0 (used in denominator later on) */
      dvj = 1.0e-6;
      
   /* if junction voltage is below threshold onset,  and */
   /* vtso > vto evaluate equations at vts.              */

   vts = (VTSO-VCH)/dvj + VCH;
   if ((Vgs < vts) && (VTSO > VTO))
      vjx = vts;
   else
      vjx = Vgs;
   
   vt = (VTO - VCH)/dvj + VCH;
   vg = (VGO - VCH)/dvj + VCH;
   v1 = (vjx - VCH)*dvj;
   
   if (vjx >= vg) /* fix transconductance at vjx = vgo */
      { 
      gmgs = GMMAX*dvj;
      ids1 = GMMAX*(v1 - (VGO + VTO)*0.5 + VCH); 
      gds1 = (-GMMAX)*GAMMA*(vjx - VCH);
      }
   else if (vjx <= vt) /* fix current at 0 (where transconductance is 0) */
      {
      gmgs = 0.0;
      ids1 = 0.0;
      gds1 = 0.0;
      }
   else /* ((vjx > vt) && (vjx < vg)) */
      {
      double dvd = VTO - VGO;    
      double dv = v1 - (VGO - VCH);     
      double arg = PI*dv/dvd;
      double cosarg = cos(arg);
      double sinarg = sin(arg);
      double stuff = dvd*sinarg/PI + v1 - (VTO - VCH);
      gmgs = GMMAX * dvj * (cosarg + 1.0) * 0.5; 
      ids1 = GMMAX * stuff * 0.5;
      gds1 = (-GMMAX) * GAMMA * (vjx - VCH) * (cosarg + 1.0) * 0.5;
      }
   
   vc = VCO + MU*dvo; 
   vb = VBC + vc;
   va = vb - VBA;
   
   /* transconductance compression for (vjx > vc) */

   if (vjx > vc)
      { 
      if (vjx < vb)
         {
         double dv = vjx-vc;
         double dv2 = dv*dv;
         double alpha2 = ALPHA*ALPHA;
         double dvd = sqrt(dv2 + alpha2);
         gmgs += DELTGM*(ALPHA - dvd);
         ids1 += DELTGM*(ALPHA*dv - (dv*dvd + alpha2*log((dv+dvd)/ALPHA))/2.0);
         gds1 += DELTGM*(ALPHA*MU - (MU/2.0)*((2*dv2+alpha2)/dvd + (1.0+dv/dvd)*alpha2/(dv+dvd)));
         }
      else /* (vjx > vb) */
         {
         double dv2 = VBC*VBC;
         double alpha2 = ALPHA*ALPHA;
         double dvd = sqrt(dv2 + alpha2);
         double Svbp = VBC/dvd;
         double Gmvbp = dvd - ALPHA;
         double Idvbp = (VBC*dvd + alpha2*log((VBC+dvd)/ALPHA))*0.5 - ALPHA*VBC;
         double Gdvbp = 0.5*MU*((2.0*dv2 + alpha2)/dvd + (1.0 + VBC/dvd)*alpha2/(VBC + dvd)) - ALPHA*MU;
         double svb =  DELTGM*Svbp;
         double gmvb = DELTGM*Gmvbp;
         double idvb = DELTGM*Idvbp;
         double gdvb = DELTGM*Gdvbp;    
         double dv = VBA;
         double b = svb*dv/(gmvb-gmoff);

         if (fabs(b + 1.0) > 1.0e-6)
            {
            double a = (gmvb-gmoff)/pow(dv,b);
            gmgs -= a*pow((vjx - va),b) + gmoff;
            ids1 -= a*(pow((vjx - va),b+1.0) - pow(dv,b+1.0))/(b+1.0) + gmoff*(vjx - vb) + idvb;
            gds1 -= MU*a*pow((vjx - va),b) + MU * gmoff + gdvb;
            }
         else
            {
            double a = (gmvb-gmoff)*dv;
            gmgs -= a/(vjx - va) + gmoff;
            ids1 -= a*(log(vjx - va) - log(dv)) + gmoff*(vjx - vb) + idvb;
            gds1 -= MU*a/(vjx - va) + MU*gmoff + gdvb;
            }
         }
      }

   /* If junction voltage drops below onset of subthreshold (vts), current  */ 
   /* and conductances are modified to decay exponentially from their value */
   /* at Vgs = vts.                                                          */
      
   if (ids1 > 0.0)
      {
      double ratio = gmgs / ids1;
      if ((Vgs < vts) && (VTSO > VTO) && (ratio > 0.0))
         {
         double arg2 = -ratio * (vts - Vgs);
         if (arg2 < -70.0)
            arg2 = -70.0;
         ids1 *= exp(arg2);
         gmgs *= exp(arg2);
         gds1 *= exp(arg2); 
         }
      } 
   
   /* Added output conductance terms to I-V equations */
   
   if (1)
      {
      double alpha = 3.0 / VSAT;
      double tanhfunc = tanh (alpha * Vds); 
      double sech2 = 1.0 - sqr(tanhfunc); 
      double dv = 1.0 + KAPA*Vds;
      if (Gm)
         *Gm = gmgs*dv*tanhfunc;
      if (Gds)
         *Gds = (gds1*dv + ids1*KAPA)*tanhfunc + ids1*dv*sech2*alpha;
      Ids = ids1*dv*tanhfunc;
      }
      
   /* The quantities idso, gmo, and gdso defined above account for the       */
   /* "basic" drain current model outlined in section 2.1.1 of tm910060.doc. */
   /* The negative resistance effect is added below.                         */
   
   if (PEFF != 0.0)
      {
      double pdiss = Vds * Ids;
      double denom = 1.0 + pdiss/PEFF;
      double facdc = 1.0 / (denom*denom); 
      if (Gm)
         *Gm *= facdc;
      if (Gds)
         *Gds = (*Gds - sqr(Ids) / PEFF) * facdc;
      Ids /= denom;
      }

   /* Dispersion Source Vds current. */

   if (GDBM != 0.0)
      {
      double idbp, gdsp;
      if ((Vds > VDSM) && (KDB != 0.0))
         { 
         double arg = Vds - VDSM;
         double sqrterm = sqrt(KDB*GDBM);
         gdsp = GDBM / (GDBM*KDB*arg*arg + 1.0);
         idbp = sqrterm*atan(arg*sqrterm)/KDB + GDBM*VDSM;
         }
      else if ((Vds < -VDSM) && (KDB != 0.0))
         {
         double arg = Vds + VDSM;
         double sqrterm = sqrt(KDB*GDBM);
         gdsp = GDBM / (GDBM*KDB*arg*arg + 1.0);
         idbp = sqrterm*atan(arg*sqrterm)/KDB - GDBM*VDSM;
         }
      else    /* -Vdsm <= Vds <= Vdsm or Kdb = 0.0 */
         {
         gdsp = GDBM;
         idbp = GDBM * Vds;
         }
      Ids += idbp;
      if (Gds)
         *Gds += gdsp;
      }

   return Ids;
   }

/*******************************************************************************************/
/*******************************************************************************************/

   static double ln_of_cosh (double x)
   {
   double y = fabs (x);

   if (y > 40.0)
      return y + log(0.5);

   return log(cosh(x));
   }

/*******************************************************************************************/
/*******************************************************************************************/

static void eehemt_charge (double *p, double Vgs, double Vgd, double *Cgs, double *dQgs_vgd, 
                           double *Cgd, double *dQgd_vgs)
   {
   double C11O = p[21];
   double C11TH = p[22];
   double C12SAT = p[23];
   double CGDSAT = p[24];
   double VINFL = p[25];
   double DELTGS = p[26];
   double DELTDS = p[27];
   double LAMBDA = p[28];
   double VDS0 = p[15];
   double vo, dvo_vgs, dvo_vgd;
   double vj, dvj_vgs, dvj_vgd;
   double g, dg_vgs, dg_vgd;
   double q, dq_vgs, dq_vgd;
   double f1, df1_vgs, df1_vgd;
   double f2, df2_vgs, df2_vgd;
   double Qgs, Qgd;

   vo = sqrt(sqr(Vgs-Vgd) + sqr(DELTDS));
   dvo_vgs = 1.0 / vo * (Vgs-Vgd);
   dvo_vgd = -dvo_vgs;

   vj = 0.5*(Vgs + Vgd + vo);
   dvj_vgs = 0.5*(1.0 + dvo_vgs);
   dvj_vgd = 0.5*(1.0 + dvo_vgd);

   g = vj - VINFL + DELTGS*ln_of_cosh(3.0/DELTGS*(vj-VINFL));
   dg_vgs = dvj_vgs + DELTGS*tanh(3.0/DELTGS*(vj-VINFL))*(3.0/DELTGS*dvj_vgs);
   dg_vgd = dvj_vgd + DELTGS*tanh(3.0/DELTGS*(vj-VINFL))*(3.0/DELTGS*dvj_vgd);

   q = (0.5*(C11O-C11TH)*g+C11TH*(vj-VINFL))*(1.0+LAMBDA*(vo-VDS0)) - C12SAT*vo;
   dq_vgs = (0.5*(C11O-C11TH)*g+C11TH*(vj-VINFL))*(LAMBDA*dvo_vgs) + (1.0+LAMBDA*(vo-VDS0))*(0.5*(C11O-C11TH)*dg_vgs+C11TH*dvj_vgs) - C12SAT*dvo_vgs;
   dq_vgd = (0.5*(C11O-C11TH)*g+C11TH*(vj-VINFL))*(LAMBDA*dvo_vgd) + (1.0+LAMBDA*(vo-VDS0))*(0.5*(C11O-C11TH)*dg_vgd+C11TH*dvj_vgd) - C12SAT*dvo_vgd;

   f1 = 0.5*(1.0+tanh(3.0/DELTDS*(Vgs-Vgd)));
   df1_vgs = 0.5*sech2(3.0/DELTDS*(Vgs-Vgd));
   df1_vgd = -df1_vgs;

   f2 = 0.5*(1.0+tanh(3.0/DELTDS*(Vgd-Vgs)));
   df2_vgs = df1_vgd;
   df2_vgd = df1_vgs;

   Qgs = (q-CGDSAT*Vgd)*f1 + CGDSAT*Vgs*f2;
   *Cgs = (q-CGDSAT*Vgd)*df1_vgs + f1*(dq_vgs) + CGDSAT*(Vgs*df2_vgs+f2);
   *dQgs_vgd = (q-CGDSAT*Vgd)*df1_vgd + f1*(dq_vgd-CGDSAT) + CGDSAT*Vgs*df2_vgd;

   Qgd = (q-CGDSAT*Vgs)*f2 + CGDSAT*Vgd*f1;
   *Cgd = (q-CGDSAT*Vgs)*df2_vgd + f2*(dq_vgd) + CGDSAT*(Vgd*df1_vgd+f1);
   *dQgd_vgs = (q-CGDSAT*Vgs)*df2_vgs + f2*(dq_vgs-CGDSAT) + CGDSAT*Vgd*df1_vgs;

   global_qgs = Qgs;
   global_qgd = Qgd;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static double eehemt_breakdown (double *p, double Vgs, double Vds)
   {
   double VBR = p[19];
   double NBR = p[20];
   double KBK = p[21];
   double IDSOC = p[22];
   double Vdg = Vds - Vgs;
   
   if (Vdg <= VBR)
      return 0.0;
   else
      {
      double ids = eehemt_current (p, Vgs, Vds, NULL, NULL);
      return KBK*(1.0 - ids/IDSOC) * pow((Vdg-VBR),NBR);
      }
   }

/*****************************************************************************/
/*****************************************************************************/
/*                            OPTIMIZER FUNCTIONS                            */
/*****************************************************************************/
/*****************************************************************************/

static int dciv_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double diff;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->nsub; ++i)
      {
      diff = log (d->subdata[i].ids) - log (eehemt_current (p, d->subdata[i].vgs, d->subdata[i].vds, NULL, NULL) + 1.0e-15);
      err[0] += diff * diff;
      }

   for (i = 0; i < d->ndc; ++i)
      {
      if (d->dcdata[i].vds > d->max_vds)
         continue;

      diff = d->dcdata[i].ids - eehemt_current (p, d->dcdata[i].vgs, d->dcdata[i].vds, NULL, NULL);
      err[1] += 1.0e6 * diff * diff;
      }

   err[0] /= (double) d->nsub;
   err[1] /= (double) d->ndc;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int charge_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   AC_OPT *d = (AC_OPT *) data;
   double cgs, cgd, qgs_vgd, qgd_vgs, gm;
   double cds = p[CDS_INDEX];
   double tau = p[TAU_INDEX];
   double factor;

   if (n_err != 4)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      eehemt_charge (p, d->data[i].vgs, d->data[i].vgs - d->data[i].vds, &cgs, &qgs_vgd, &cgd, &qgd_vgs);
      eehemt_current (p, d->data[i].vgs, d->data[i].vds, &gm, NULL);

      factor = 0.5 * (1.0 + tanh (2.0*(d->data[i].vds - 2.5)));
      err[0] += sqr(1.0e12*(d->data[i].cgs - (cgs + qgd_vgs)));
      err[1] += sqr(1.0e12*(d->data[i].cgd - (cgd + qgs_vgd))) * factor;
      err[2] += sqr(1.0e12*((d->data[i].cds - d->data[i].gds*d->data[i].tau2) - (cds - qgs_vgd)));
      if ((d->data[i].gm >= (10.0e-6*d->periphery)) && (gm >= (10.0e-6*d->periphery)))
         err[3] += sqr(1.0e12*(d->data[i].tau - (tau + (qgd_vgs - qgs_vgd)/gm)) * gm);
      }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;
   err[2] /= (double) d->n;
   err[3] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int vbr_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   double ig;
   DCIV_OPT *d = (DCIV_OPT *) data;

   if (n_err < 1)
      return 1;

   for (i = 0; i < d->ndc; ++i)
      {
      if (d->dcdata[i].igs < 0.0)
         {
         ig = eehemt_breakdown (p, d->dcdata[i].vgs, d->dcdata[i].vds);
         err[0] += 1.0e6 * sqr(-d->dcdata[i].igs - ig);
         }
      }

   err[0] /= (double) d->ndc;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int gm_gds_erf (double *p, void *data, double *err, unsigned n_err)
   {
   unsigned i;
   AC_OPT *d = (AC_OPT *) data;
   double gm, gds;

   if (n_err < 2)
      return 1;

   for (i = 0; i < d->n; ++i)
      {
      eehemt_current (p, d->data[i].vgs, d->data[i].vds, &gm, &gds);
      err[0] += 1.0e6 * sqr(d->data[i].gm - gm);
      err[1] += 1.0e6 * sqr((d->data[i].gds - gds) * 0.5 * (1.0 + tanh (3.0*(d->data[i].vds - 2.5))));
      }

   err[0] /= (double) d->n;
   err[1] /= (double) d->n;

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static int get_ss_parameters (char *sum_file, char *end_file, AC_PARAMETERS *ac_params, unsigned max_ac_p,
                              FIXED_PARAMS *fixed_params, unsigned *n)
   {
   FILE *file;
   unsigned m = 0;
   unsigned found = 0;
   unsigned i,j;
   char string[300],pname[20];
   double *Ri;
   double value;
   AC_PARAMETERS tmp;

   *n = 0;

   /* read in bias-dependent device parameters */

   file = fopen (sum_file,"r");
   if (!file)
      {
      printf ("Error: %s: unable to file.\n", sum_file);
      return 1;
      }
   
   Ri = (double *) malloc (sizeof (double) * max_ac_p);

   while (fgets (string, 299, file))
      {
      if ((m >= max_ac_p) || (*n >= max_ac_p))
         {
         printf ("Warning: %s: too many bias points.\n", sum_file);
         break;
         }
         
      if (sscanf (&string[28],"%lf%lf%lf%lf%*f%*f%*f%*f%*f%lf%lf%lf%lf%lf%lf%lf%lf",
         &ac_params[*n].vds, &ac_params[*n].ids, &ac_params[*n].vgs, &ac_params[*n].igs,
         &Ri[m], &ac_params[*n].gm, &ac_params[*n].tau, &ac_params[*n].gds, &ac_params[*n].tau2,
         &ac_params[*n].cgs, &ac_params[*n].cds, &ac_params[*n].cgd) == 12)
         {
         ac_params[*n].ids *= 1.0e-3;
         ac_params[*n].igs *= 1.0e-3;
         ac_params[*n].gm  *= 1.0e-3;
         ac_params[*n].gds *= 1.0e-3;
         ac_params[*n].cgs *= 1.0e-12;
         ac_params[*n].cgd *= 1.0e-12;
         ac_params[*n].cds *= 1.0e-12;
         ac_params[*n].tau *= 1.0e-12;
         ac_params[*n].tau2 *= 1.0e-12;
         
         if ((ac_params[*n].igs <= MAX_FWD_IGS*fixed_params->area*1.0e-6) && (ac_params[*n].vds >= 1.0))
            {
            ++(*n);

            // only fit Ri at points where there is DC drain current
            if (ac_params[*n].ids >= 10.0e-6*fixed_params->area)
               ++m;
            }

         }
      }
   fclose (file);

   // average these parameters, since they are fixed in the LS model

   fixed_params->ri = bubble_average (Ri,m);   
   if (fixed_params->ri < 0.0)
      fixed_params->ri = 0.0;

   free ((void *) Ri);

   if (*n < 1)
      {
      fprintf (stderr, "Error: %s: no data.\n", sum_file);
      return 1;
      }

   /* sort the ac parameters by increasing Vgs then Vds */
   
   for (i = 0; i < ((*n)-1); ++i)
      {
      for (j = i+1; j < *n; ++j)
         {
         if ((ac_params[j].vgs < ac_params[i].vgs) ||
            ((ac_params[j].vds < ac_params[i].vds) && (ac_params[i].vgs == ac_params[j].vgs)))
            {
            tmp = ac_params[i];
            ac_params[i] = ac_params[j];
            ac_params[j] = tmp;
            }
         }
      }
   
   /* read in fixed parasitics from the small-signal end file */

   file = fopen (end_file,"r");
   if (!file)
      {
      printf ("Error: %s: unable to open file.\n", end_file);
      return 1;
      }
   
   while (fgets (string,299,file))
      {
      if (sscanf (string,"%*f%lf%*f%*f%19s",&value,pname) == 2)
         {
         if (!strcmp (pname,"C1"))
            {
            fixed_params->cpg = value;
            ++found;
            }
         else if (!strcmp (pname,"C2"))
            {
            fixed_params->cpd = value;
            ++found;
            }
         else if (!strcmp (pname,"C11"))
            {
            fixed_params->c11 = value;
            ++found;
            }
         else if (!strcmp (pname,"C22"))
            {
            fixed_params->c22 = value;
            ++found;
            }
         else if (!strcmp (pname,"B1"))
            {
            fixed_params->lg = value;
            ++found;
            }
         else if (!strcmp (pname,"B2"))
            {
            fixed_params->ld = value;
            ++found;
            }
         else if (!strcmp (pname,"LS"))
            {
            fixed_params->ls = value;
            ++found;
            }
         else if (!strcmp (pname,"RG"))
            {
            fixed_params->rg = value;
            ++found;
            }
         else if (!strcmp (pname,"RD"))
            {
            fixed_params->rd = value;
            ++found;
            }
         else if (!strcmp (pname,"RS"))
            {
            fixed_params->rs = value;
            ++found;
            }
         }
      }
   fclose (file);

   if (found != 10)
      {
      fprintf (stderr, "Error: %s: missing parameter(s).\n", end_file);
      return 1;
      }
   
   if (fixed_params->cpg != 0.0)
      {
      sprintf (string, "Warning: non-zero C1 has been lumped into Cgs.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cgs += fixed_params->cpg;
      }

   if (fixed_params->c11 != 0.0)
      {
      sprintf (string, "Warning: non-zero C11 has been lumped into Cgs.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cgs += fixed_params->c11;
      }

   if (fixed_params->cpd != 0.0)
      {
      sprintf (string, "Warning: non-zero C2 has been lumped into Cds.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cds += fixed_params->cpd;
      }

   if (fixed_params->c22 != 0.0)
      {
      sprintf (string, "Warning: non-zero C22 has been lumped into Cds.\n");
      strcat (global_warning_msg, string);

      for (i = 0; i < *n; ++i)
         ac_params[i].cds += fixed_params->c22;
      }

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void get_file_header (char *data_file, char *header, unsigned max_size)
   {
   FILE *file = fopen (data_file,"r");
   unsigned index = 0, len;
   char string[300];

   if (!header || !max_size)
      return;

   header[0] = 0;

   if (!file)
      return;

   while (fgets (string,299,file))
      {
      if (string[0] != '!')
         {
         string[0] = 0;
         break;
         }

      len = strlen (string);

      // check for the end of the header
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         if ((index + len) < max_size)
            {
            strcat (header, string);
            index += len;
            }
         else
            break;

         fgets (string,299,file);
         break;
         }

      // make sure that this string will fit in the header string
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else
         break;
      }

   fclose (file);

   // add anything left in the line to the header
   // this bit of code also truncates the string with "\n\0"
   // if it is too long to fit into the remaining space in
   // the header string

   len = strlen (string);
   if ((len > 0) && (index < max_size))
      {
      if ((index + len) < max_size)
         {
         strcat (header, string);
         index += len;
         }
      else if ((max_size - index) == 1);
      else
         {
         string[max_size-index-2] = '\n';
         string[max_size-index-1] = 0;
         strcat (header, string);
         index = max_size - 1;
         }
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static int write_data_files (char *end_file, char *model_file, char *header, MODEL_PARAMS *params, FIXED_PARAMS fixed)
   {
   FILE *file;
   unsigned i;
   unsigned count = 0;
   char *names[200];
   double values[200];
   unsigned num_p = 0;
   unsigned max_str = 0;
   char fmt[30];
   MODEL_PARAMS *ptr;
   
   /* write final optimization parameter values */

   if (write_model_parameters_to_file (params, end_file))
      return 1;

   /* write the model file */

   // non-optimized parameters
   
   names[num_p] = "ugw"; values[num_p] = fixed.ugw; ++num_p;
   names[num_p] = "ngf"; values[num_p] = fixed.ngf; ++num_p;
   names[num_p] = "tnom"; values[num_p] = fixed.tnom; ++num_p;
   names[num_p] = "rg"; values[num_p] = fixed.rg; ++num_p;
   names[num_p] = "rd"; values[num_p] = fixed.rd; ++num_p;
   names[num_p] = "rs"; values[num_p] = fixed.rs; ++num_p;
   names[num_p] = "ris", values[num_p] = fixed.ri; ++num_p;
   names[num_p] = "rid", values[num_p] = fixed.ri; ++num_p;
   names[num_p] = "is"; values[num_p] = fixed.is; ++num_p;
   names[num_p] = "n"; values[num_p] = fixed.n; ++num_p;
   names[num_p] = "lg"; values[num_p] = fixed.lg; ++num_p;
   names[num_p] = "ld"; values[num_p] = fixed.ld; ++num_p;
   names[num_p] = "ls"; values[num_p] = fixed.ls; ++num_p;

   for (ptr = params; ptr; ptr = ptr->next)
      {
      names[num_p] = ptr->name;
      values[num_p] = ptr->nom;
      ++num_p;
      }

   file = fopen (model_file, "w+");
   if (!file)
      {
      fprintf (stderr, "Error: %s: unable to write to disc.\n", model_file);
      return -1;
      }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");
   fprintf (file, "VAR model = 1\n");
   write_model_param_mdif (file, names, values, num_p, 12, 5);
   fclose (file);
      
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void create_plot (jPLOT_ITEM **plot, double *x, double *y_meas, double *y_mod, unsigned n,
                         char *x_lab, char *y_lab, char *title, unsigned scaling)
   {
   if (!n)
      return;

   *plot = create_plot_item (SingleY, PLOT_X, PLOT_Y, PLOT_XSIZE, PLOT_YSIZE);

   if (!(*plot))
      return;

   attach_y1data (*plot, x, y_meas, n, MEAS_LTYPE, 1, MEAS_COLOR);
   attach_y1data (*plot, x, y_mod, n, MOD_LTYPE, 1, MOD_COLOR);
      
   set_axis_labels (*plot, x_lab, y_lab, "", title);
   set_axis_scaling ((*plot), scaling);
   }

/*****************************************************************************/
/*****************************************************************************/

static int plot_data (int dev, char *head, jPLOT_ITEM *plot_list[], unsigned n)
   {
   static char *legend_t[] = {"Modeled", "Measured"};
   static int  legend_l[] = {MOD_LTYPE, MEAS_LTYPE};
   static int  legend_w[] = {1, 1};
   static int  legend_c[] = {MOD_COLOR, MEAS_COLOR};
   char *plotfile = "parker.ps";
   jHANDLE legend, header;
   unsigned i;
   
   if (!open_graphics_device (dev, plotfile))
      {
      fprintf (stderr, "Error: open_graphics_device() failed.\n");
      return 1;
      }
   
   header = add_text (head, 6.5, 8.1, FNT_TIMES, 10, 0.0, LEFT_JUSTIFY, CLR_BLACK, NO_STYLE);
   legend = add_legend (2, 8.0, 6.5, legend_t, FNT_TIMES, 12, legend_l, legend_w, legend_c);

   // deactivate all plot items
   for (i = 0; i < n; ++i)
      {
      if (plot_list[i])
         plot_list[i]->active = FALSE;
      }

   // draw all plots
   for (i = 0; i < n; ++i)
      {
      if (!plot_list[i])
         continue;

      plot_list[i]->active = TRUE;

      if (!draw_page ())
         {
         printf ("Error: draw_page() failed.\n");
         close_graphics_device ();
         return 1;
         }

      plot_list[i]->active = FALSE;
      }

   // if the plot device is not POSTSCRIPT, recursively call the function to create a postscript output file
   if (dev != POSTSCRIPT)
      {
      // remove these items since they will get re-created during a recursive function call
      remove_user_item (legend);
      remove_user_item (header);

      plot_data (POSTSCRIPT, head, plot_list, n);
      }
   else
      close_graphics_device ();
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void write_starting_files (char *inname, char *endname)
   {
   FILE *file;
   OPT_PARAMETER p[] = {
      { -5.0000e+00, -2.0000e+00, -5.0000e-01,  0.0000e+00, "vto", 0 },
      {  0.0000e+00,  5.0000e-02,  1.0000e-01,  0.0000e+00, "gamma", 0 },
      { -5.0000e-01,  0.0000e+00,  5.0000e-01,  0.0000e+00, "vgo", 0 },
      {  0.0000e+00,  7.0000e-01,  1.0000e+00,  0.0000e+00, "vco", 0 },
      {  0.0000e+00,  3.0000e-01,  1.0000e+00,  0.0000e+00, "vbc", 0 },
      {  0.0000e+00,  3.0000e-01,  1.0000e+00,  0.0000e+00, "vba", 0 },
      {  8.0000e-01,  1.0000e+00,  2.0000e+00,  0.0000e+00, "vch", 0 },
      {  2.0000e-02,  8.0000e-02,  2.0000e-01,  0.0000e+00, "gmmax", 0 },
      {  5.0000e-01,  1.0000e+00,  1.5000e+00,  0.0000e+00, "vsat", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e-00,  0.0000e+00, "kapa", 0 },
      {  1.0000e-01,  5.0000e+00,  2.0000e+01,  0.0000e+00, "peff", 0 },
      { -2.0000e+00, -1.0000e+00,  5.0000e-01,  0.0000e+00, "vtso", 0 },
      {  1.0000e-05,  1.0000e-03,  5.0000e-02,  0.0000e+00, "alpha", 0 },
      {  5.0000e-03,  2.0000e-02,  5.0000e-02,  0.0000e+00, "deltgm", 0 },
      {  1.0000e+00,  1.0000e+00,  1.0000e+00,  0.0000e+00, "mu", 0 },
      {  3.0000e+00,  3.0000e+00,  3.0000e+00,  0.0000e+00, "vdso", 0 },

      { -5.0000e+00, -2.0000e+00, -5.0000e-01,  0.0000e+00, "vtoac", 0 },
      {  0.0000e+00,  5.0000e-02,  1.0000e-01,  0.0000e+00, "gammaac", 0 },
      {  2.0000e-02,  8.0000e-02,  2.0000e-01,  0.0000e+00, "gmmaxac", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e-00,  0.0000e+00, "kapaac", 0 },
      {  1.0000e-01,  5.0000e+00,  2.0000e+01,  0.0000e+00, "peffac", 0 },
      { -2.0000e+00, -1.0000e+00,  5.0000e-01,  0.0000e+00, "vtsoac", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e-02,  0.0000e+00, "gdbm", 0 },
      {  0.0000e+00,  0.0000e+00,  1.0000e+01,  0.0000e+00, "kdb", 0 },
      {  0.0000e+00,  1.0000e+00,  2.0000e+00,  0.0000e+00, "vdsm", 0 },

      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "cdso", 0 },
      {  0.0000e+00,  0.0000e+00,  0.0000e+00,  0.0000e+00, "tau", 0 },
      {  1.0000e-15,  5.0000e-13,  5.0000e-12,  0.0000e+00, "c11o", 0 },
      {  1.0000e-16,  5.0000e-14,  5.0000e-13,  0.0000e+00, "c11th", 0 },
      {  1.0000e-16,  5.0000e-14,  5.0000e-13,  0.0000e+00, "c12sat", 0 },
      {  1.0000e-16,  5.0000e-14,  5.0000e-13,  0.0000e+00, "cgdsat", 0 },
      { -2.0000e+00, -1.0000e+00,  5.0000e-01,  0.0000e+00, "vinfl", 0 },
      {  1.0000e-02,  3.0000e-01,  1.0000e+00,  0.0000e+00, "deltgs", 0 },
      {  5.0000e-01,  5.0000e-01,  5.0000e-01,  0.0000e+00, "deltds", 0 },
      {  0.0000e+00,  4.0000e-01,  2.0000e+00,  0.0000e+00, "lambda", 0 },

      {  2.0000e+00,  5.0000e+00,  2.0000e+01,  0.0000e+00, "vbr", 0 },
      {  5.0000e-01,  2.0000e+00,  4.0000e+00,  0.0000e+00, "nbr", 0 },
      {  1.0000e-02,  5.0000e-01,  1.5000e+01,  0.0000e+00, "kbk", 0 },
      {  1.0000e+00,  1.0000e+00,  1.0000e+00,  0.0000e+00, "idsoc", 0 }
   };

   if (inname)
      {
      file = fopen (inname, "w+");
      if (!file)
         {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
         }

      fprintf (file, "2               # number of gate fingers\n");
      fprintf (file, "100             # unit gate width\n");
      fprintf (file, "27              # extraction temperature\n");
      fprintf (file, "s.end           # Y-fit file name\n");
      fprintf (file, "model.summary   # model summary file name\n");
      fprintf (file, "sdc.iv          # DC I-V file name\n");
      fprintf (file, "5               # max drain voltage for I-V fit\n");
      fprintf (file, "sfwd.iv         # forward I-V file name\n");
      fprintf (file, "svbr.iv         # breakdown I-V file name\n");
      fprintf (file, "eehemt.start    # starting parameters file name\n");
      fprintf (file, "eehemt.end      # finishing parameters file name (output)\n");
      fprintf (file, "eehemt.model    # model file name (output)\n");
      fprintf (file, "500             # maximum optimization iterations\n");
      
      fclose (file);
      }
   
   if (endname)
      {
      unsigned i;
      
      file = fopen (endname, "w+");
      if (!file)
         {
         fprintf (stderr, "Error: %s: unable to create file.\n", inname);
         return;
         }
      
      for (i = 0; i < (sizeof(p) / sizeof(*p)); ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);
            
      fclose (file);
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static double safe_pow (double x, double y)
   {
   if ((x == 0.0) && (y < 0.0))
      return MAXFLOAT;
   else if (x == 0.0)
      return 0.0;

   return pow (x, y);
   }

/*****************************************************************************/
/*****************************************************************************/

static void check_parameter_ranges (MODEL_PARAMS *p, double Vmax, double Vpo)
   {
   OPT_PARAMETER x;
   MODEL_PARAMS *ptr;
  
   /* set VTSO equal to Vpo with a +/- 0.2 range */
   get_parameter_value ("vtso", p, &x);
   x.min = Vpo - 0.2;
   x.nom = Vpo;
   x.max = Vpo + 0.2;
   set_parameter_value (p, x);

   /* make sure that VTO is far enough below pinch-off */
   get_parameter_value ("vto", p, &x);
   x.min = Vpo - 2.0;
   x.nom = Vpo - 0.5;
   x.max = Vpo;
   set_parameter_value (p, x);

   /* make sure that VDS0 is valid and fix it at the nominal value */
   get_parameter_value ("vdso", p, &x);
   if (x.nom < 2.0)
      x.nom = 2.0;
   x.min = x.max = x.nom;
   set_parameter_value (p, x);

   /* fix DELTDS to 0.5 */
   get_parameter_value ("deltds", p, &x);
   x.min = x.max = x.nom = 0.5;
   set_parameter_value (p, x);

   /* fix MU to 1.0 */
   get_parameter_value ("mu", p, &x);
   x.min = x.max = x.nom = 1.0;
   set_parameter_value (p, x);

   /* fix IDSOC to 1.0 */
   get_parameter_value ("idsoc", p, &x);
   x.min = x.max = x.nom = 1.0;
   set_parameter_value (p, x);

   /* set valid ranges on certain "trouble" parameters */

   




   /* check to make sure that the nominal values make sense */

   for (ptr = p; ptr; ptr = ptr->next)
      {
      if (ptr->nom < ptr->min)
         ptr->nom = ptr->min;
      else if (ptr->nom > ptr->max)
         ptr->nom = ptr->max;

      if (ptr->min > ptr->max)
         printf ("Warning: check_parameter_ranges(): parameter \'%s\' min is greater than max.\n", ptr->name);
      }
   }

/*****************************************************************************/
/*****************************************************************************/

static void read_vmax_from_file (char *fname, double *vmax, double *vpo)
   {
   FILE *file;
   char string[256];

   *vmax = 1.0;
   *vpo = -1.0;

   file = fopen (fname, "r");
   if (!file)
      return;

   while (fgets (string, 255, file))
      {
      if (string[0] != '!')
         break;

      if (!strncmp (string, "!Vbr", 4))
         {
         if (fgets (string, 255, file))
            sscanf (string, "!%*f%*f%*f%*f%*f%*f%lf%lf", vmax, vpo);
         break;
         }
      }

   fclose (file);
   }

