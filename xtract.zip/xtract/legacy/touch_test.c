#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "touchstone.h"


int main( int argc, char** argv )
{
   char infile[256];
   char ofile1[256];
   char ofile2[256];
   struct touchstone_file_ *touch;
   struct network_parameters_ *data;
   struct file_data_ *file;
   int e;

   printf( "Enter touchstone file name:\n" );
   scanf( "%255s", infile );

   strcpy( ofile1, infile );
   strcat( ofile1, ".tst1" );

   /* TEST 1: test the high-level interface */

   e = read_touchstone_file( infile, &touch, &data );
   if( e ) {
      fprintf( stderr, "TEST 1 FAILED\n" );
   }
   else {
      e = write_touchstone_file( ofile1, touch, data );
      if( e ) {
         fprintf( stderr, "TEST 1 FAILED\n" );
      }
      else 
         fprintf( stderr, "TEST 1 PASSED\n" );
   }

   free_touchstone_file_data( touch );
   free_network_parameter_data( data );

   /* TEST 2: test the low-level interface */

   touch = create_touchstone_file_data();
   data = create_network_parameter_data();
   file = open_ts_file( infile );

   e = read_ts_file( file, touch, data );
   if( e ) {
      fprintf( stderr, "Error: %s: line %d\n", get_ts_error_message( e ), file?file->lineno:0 );
      fprintf( stderr, "TEST 2 FAILED\n" );
   }
   else {
      printf( "Number of ports: %d\n", data->n_ports );
      printf( "Number of freqs: %d\n", data->n_freqs );
      fprintf( stderr, "TEST 2 PASSED\n" );
   }
   close_ts_file( file );

   free_touchstone_file_data( touch );
   free_network_parameter_data( data );

   return 0;
}
