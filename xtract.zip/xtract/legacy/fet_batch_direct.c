#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
   {
   char fit_files[256];
   char starting_vals[256];
   char range1[256];
   char range2[256];
   char range3[256];
   char end_file[256];
   char tmp_file[256];
   char batch_file[256];
   char string[256];
   char fname[256];
   time_t ts;
   FILE *file,*out_file;
   
   // remove any old error files that may exist
   sprintf (string, "rm -f batch_error_file.txt");
   system (string);
   
   printf ("Files to Fit?\n");
   fgets (fit_files, 255, stdin);
   fit_files[strlen(fit_files)-1] = 0;

   printf ("Starting values file name?\n");
   fgets (starting_vals, 255, stdin);

   printf ("Frequency range for Cgs, Cgd, Cds, Gm and Gds calculations in GHz (min max)?\n");
   fgets (range1, 255, stdin);

   printf ("Frequency range for Ri and Tau calculations in GHz (min max)?\n");
   fgets (range2, 255, stdin);

   printf ("Frequency range for Ggs and Ggd calculations in GHz (min max)?\n");
   fgets (range3, 255, stdin);

   // create temporary file names and get the file list of files to batch fit
   sprintf (tmp_file, "tmp_file-%d", time (&ts));
   sprintf (batch_file, "batch_file-%d", time (&ts));
   sprintf (string, "rm -f %s", tmp_file);
   system (string);
   sprintf (string, "ls -1 %s > %s", fit_files, tmp_file);
   system (string);
   
   // open the file list
   file = fopen (tmp_file, "r");
   if (!file)
      {
      fprintf (stderr, "Failed to find any files.\n");
      return -1;
      }
   
   // open the batch file for writing
   out_file = fopen (batch_file, "w+");
   if (!out_file)
      {
      fprintf (stderr, "Failed to write batch file.\n");
      return -1;
      }
   
   while (fgets (fname, 255, file))
      {      
      sscanf (fname, "%[^.]", end_file);
      strcat (end_file, ".dir\n");
      
      // Y-fit program inputs
      fprintf (out_file, "yfitv500 -b << input\n");
      fprintf (out_file, "%s", fname);
      fprintf (out_file, "%s", starting_vals);
      fprintf (out_file, "%s", end_file);
      fprintf (out_file, "%s", range1);
      fprintf (out_file, "%s", range2);
      fprintf (out_file, "%s", range3);
      fprintf (out_file, "input\n");
      }
   
   fprintf (out_file, "rm -f %s", batch_file);

   fclose (out_file);
   fclose (file);
   
   sprintf (string, "rm -f %s", tmp_file);
   system (string);
   
   sprintf (string, "chmod +x %s", batch_file);
   system (string);
   
   sprintf (string, "./%s &", batch_file);
   system (string);
   
   return 0;
   }
 
 
