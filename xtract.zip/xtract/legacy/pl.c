#include <math.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>
#include <time.h>

/* function prototypes */


/* global variables */

static double top_margin = 0.75;
static double bot_margin = 0.75;
static double left_margin = 0.75;
static double point_size = 10.0;
double x;
double y;
char   time_string[100];
char   file_name[500];
char   printer[500];
char   font[500];
char   mode[500];
int    page_flag;
int    time_flag;
int    file_flag;
int    pages;

/****************************************************************************/
/****************************************************************************/

int main (int argc, char *argv[])
   {
FILE   *infile;
FILE   *outfile;
char   buffer[1025];
char   options[1025];
char   fname[1025];
char   *file_names[500];
char   *option_pointer[50];
int    file_allready;
int    opts;
int    i;
int    k;
int    n;

strcpy (printer,"");
strcpy (font,"courier");
strcpy (mode,"port");
file_allready = 0;
page_flag = 0;
time_flag = 0;
file_flag = 0;
n = -1;
opts = -1;

if (argv == 1)
   {
   usage ();
   exit (1);
   }

for (i = 1; i < argv; ++i)
   {
   sprintf (buffer,"%s",*++argc);
   if (buffer[0] == '-')
      {
      if (strncmp (&(buffer[1]),"P",1) == 0)
         {
         sprintf (printer,"%s",&(buffer[2]));
         }
      else if (strncmp (&(buffer[1]),"fn",2) == 0)
         {
         sprintf (font,"%s",&(buffer[3]));
         if ((strncmp (font,"courier",7) != 0) && (strncmp (font,"helvetica",9) != 0) &&
             (strncmp (font,"times",5) != 0))
            {
            usage ();
            exit (1);
            }
         }
      else if (strncmp (&(buffer[1]),"ps",2) == 0)
         {
         if (sscanf (&(buffer[3]),"%lf",&point_size) != 1)
            {
            usage ();
            exit (1);
            }
/*       if (point_size < (double) 4.0)
            {
            point_size = (double) 4.0;
            }  */
         }
      else if (strncmp (&(buffer[1]),"lm",2) == 0)
         {
         if (sscanf (&(buffer[3]),"%lf",&left_margin) != 1)
            {
            usage ();
            exit (1);
            }
         if (left_margin < (double) 0.1)
            {
            left_margin = (double) 0.1;
            }
         }
      else if (strncmp (&(buffer[1]),"tm",2) == 0)
         {
         if (sscanf (&(buffer[3]),"%lf",&top_margin) != 1)
            {
            usage ();
            exit (1);
            }
         if (top_margin < (double) 0.1)
            {
            top_margin = (double) 0.1;
            }
         }
      else if (strncmp (&(buffer[1]),"bm",2) == 0)
         {
         if (sscanf (&(buffer[3]),"%lf",&bot_margin) != 1)
            {
            usage ();
            exit (1);
            }
         if (bot_margin < (double) 0.1)
            {
            bot_margin = (double) 0.1;
            }
         }
      else if (strncmp (&(buffer[1]),"port",4) == 0)
         {
         strcpy (mode,"port");
         }
      else if (strncmp (&(buffer[1]),"land",4) == 0)
         {
         strcpy (mode,"land");
         }
      else if (strncmp (&(buffer[1]),"page",4) == 0)
         {
         page_flag = 1;
         }
      else if (strncmp (&(buffer[1]),"date",4) == 0)
         {
         time_flag = 1;
         }
      else if (strncmp (&(buffer[1]),"file",4) == 0)
         {
         file_flag = 1;
         }
      else if (strncmp (&(buffer[1]),"o",1) == 0)
         {
         option_pointer[++opts] = *argc;
         }
      else
         {
         usage ();
         exit(1);
         }
      }
   else
      {
      file_names[++n] = *argc;
      }
   }

if (n == -1)
   {
   usage ();
   exit(1);
   }

k = 0;
options[0] = '\0';

for (i = 0; i <= opts; ++i)
   {
   sprintf (&(options[k])," %s",option_pointer[i]);
   k += (strlen (option_pointer[i])+1);
   }

for (i = 0; i <= n; ++i)
   {
   strcpy (file_name,file_names[i]);
   infile  = fopen (file_names[i],"r");
   if (infile == NULL)
      {
      printf ("can't open file %s for read\n",file_names[i]);
      continue;
      }

   sprintf (fname,"%s/pl_postscript.dat",getenv("HOME"));
   outfile = fopen (fname,"w+");
   if (outfile == NULL)
      {
      printf ("can't open file %s for write\n",fname);
      exit (1);
      }

   header (outfile);

   while (fgets (buffer,1024,infile) != NULL)
      {
      write_text (outfile,buffer);
      }

   footer(outfile);

   fclose (infile);
   fclose (outfile);

   if (printer[0] == '\0')
      {
      sprintf (buffer,"dazel_print %s %s;rm -f %s",options,fname,fname);
      system (buffer);
      }
   else
      {
      sprintf (buffer,"dazel_print -d%s %s %s;rm -f %s",printer,options,fname,fname);
      system (buffer);
      }
   }

}

/*                                                                   */
/*--- Function usage ------------------------------------------------*/
/*                                                                   */

void usage ()
{

printf ("usage:  pl filename [-Pprinter] [-fnfont] [-pspointsize] [-lmleftmargin]\n");
printf ("                    [-tmtopmargin] [-bmbottommargin] [-port|land] [-page]\n");
printf ("                    [-date] [-file] [-ooption]\n");
printf ("\n");
printf ("            The pl command converts an ASCII text file into a postscript\n");
printf ("            file and then sends the results to the specified printer.\n");
printf ("\n");
printf ("filename    required file name containing ASCII text\n");
printf ("            (wildcards are accepted)\n");
printf ("\n");
printf ("-P          use printer named (printer)\n");
printf ("            (default is defined in printcap file)\n");
printf ("\n");
printf ("-fn         use font named (font) choices are courier, times, and helvetica\n");
printf ("            (default is courier)\n");
printf ("\n");
printf ("-ps         use font pointsize of (pointsize)\n");
printf ("            (default is 10.0)\n");
printf ("\n");
printf ("-lm         set left margin to (leftmargin) in inches\n");
printf ("            (default is 0.75)\n");
printf ("\n");
printf ("-tm         set top margin to (topmargin) in inches\n");
printf ("            (default is 0.75)\n");
printf ("\n");
printf ("-bm         set bottom margin to (bottommargin) in inches\n");
printf ("            (default is 0.75)\n");
printf ("\n");
printf ("-port|land  set print mode to portrait or landscape\n");
printf ("            (default is portrait -port)\n");
printf ("\n");
printf ("-page       include page numbers on printout (at bottom center)\n");
printf ("            (default is no page numbers)\n");
printf ("\n");
printf ("-date       include date and time on printout (at top right)\n");
printf ("            (default is no date and time)\n");
printf ("\n");
printf ("-file       include ASCII file name on printout (at top left)\n");
printf ("            (default is no file name)\n");
printf ("\n");
printf ("-o          use lp printer option (option)\n");
printf ("            note: must be a valid option for a postscript file\n");
printf ("            (see the lp command for list of -o options)\n");
printf ("\n");
printf ("\n");
printf ("example:    pl my_file -Pic3si -od -fncourier -ps8.5 -lm1.0 -land -page\n");
printf ("\n");
printf ("            Will print the ASCII file (my_file) on printer ic3si in\n");
printf ("            landscape mode using 8.5 point courier font with a left\n");
printf ("            margin of 1.0 inches and page numbers in full duplex mode.\n");
printf ("\n");

return;

}

/*                                                                   */
/*--- Function header -----------------------------------------------*/
/*                                                                   */

void header (outfile)
FILE *outfile;

{

get_the_time (time_string);

fprintf (outfile,"%%!PS-Adobe-1.0\n");
fprintf (outfile,"%%%%Creator: pl program written by Wayne Struble\n");
fprintf (outfile,"%%%%Title: None\n");
fprintf (outfile,"%%%%CreationDate: %s\n",time_string);
fprintf (outfile,"%%%%Pages: (atend)\n");
fprintf (outfile,"%%%%DocumentFonts: (atend)\n");
fprintf (outfile,"%%%%BoundingBox: (atend)\n");
fprintf (outfile,"%%%%EndComments\n");
fprintf (outfile,"/tl  {moveto show} def\n");
fprintf (outfile,"/tr  {moveto dup stringwidth neg exch neg exch rmoveto show} def\n");
fprintf (outfile,"/tc  {moveto dup stringwidth neg 2 div exch neg 2 div exch rmoveto show} def\n");
fprintf (outfile,"/tlr {gsave moveto rotate show grestore} def\n");
fprintf (outfile,"/trr {gsave moveto rotate dup stringwidth neg exch neg exch rmoveto show grestore} def\n");
fprintf (outfile,"/tcr {gsave moveto rotate dup stringwidth neg 2 div exch neg 2 div exch rmoveto show grestore} def\n");
fprintf (outfile,"%%%%EndProlog\n");
fprintf (outfile,"%%%%Page: 1 1\n");

if (strncmp (font,"courier",7) == 0)
   {
   fprintf (outfile,"/Courier findfont %.1f scalefont setfont\n",point_size);
   }
else if (strncmp (font,"helvetica",9) == 0)
   {
   fprintf (outfile,"/Helvetica findfont %.1f scalefont setfont\n",point_size);
   }
else if (strncmp (font,"times",5) == 0)
   {
   fprintf (outfile,"/Times-Roman findfont %.1f scalefont setfont\n",point_size);
   }

pages = 1;

if (strncmp (mode,"port",4) == 0)
   {
   x = left_margin*((double) 72.0);
   y = (((double) 11.0)-top_margin)*((double) 72.0)-point_size;
   }
else
   {
   x = (((double) 8.5)-top_margin)*((double) 72.0)-point_size;
   y = (((double) 11.0)-left_margin)*((double) 72.0);
   }

return;

}

/*                                                                   */
/*--- Function write_text -------------------------------------------*/
/*                                                                   */

void write_text (outfile,buffer)
FILE *outfile;
char buffer[];

{
char ps_string[1025];
char temp[50];
int  i;
int  n;

if ((strncmp (mode,"port",4) == 0) && (y < bot_margin*((double) 72.0)))
   {
   if (page_flag)
      {
      sprintf (temp,"%d",pages);
      fprintf (outfile,"(%s) 306.0 %.1f tc\n",temp,bot_margin*((double) 36.0));
      }
   if (file_flag)
      {
      fprintf (outfile,"(%s) %.1f %.1f tl\n",file_name,left_margin*((double) 72.0),
            (((double) 11.0)-top_margin*((double) 0.5))*((double) 72.0)-
            point_size*((double) 0.5));
      }
   if (time_flag)
      {
      fprintf (outfile,"(%s) %.1f %.1f tr\n",time_string,
            (((double) 8.5)-left_margin)*((double) 72.0),
            (((double) 11.0)-top_margin*((double) 0.5))*((double) 72.0)-
            point_size*((double) 0.5));
      }
   ++pages;
   fprintf (outfile,"showpage\n");
   fprintf (outfile,"%%%%Page: %d %d\n",pages,pages);
   x = left_margin*((double) 72.0);
   y = (((double) 11.0)-top_margin)*((double) 72.0)-point_size;
   if (strncmp (font,"courier",7) == 0)
      {
      fprintf (outfile,"/Courier findfont %.1f scalefont setfont\n",point_size);
      }
   else if (strncmp (font,"helvetica",9) == 0)
      {
      fprintf (outfile,"/Helvetica findfont %.1f scalefont setfont\n",point_size);
      }
   else if (strncmp (font,"times",5) == 0)
      {
      fprintf (outfile,"/Times-Roman findfont %.1f scalefont setfont\n",point_size);
      }
   }
else if ((strncmp (mode,"land",4) == 0) && (x < bot_margin*((double) 72.0)))
   {
   if (page_flag)
      {
      sprintf (temp,"%d",pages);
      fprintf (outfile,"(%s) -90 %.1f 396.0 tcr\n",temp,bot_margin*((double) 36.0));
      }
   if (file_flag)
      {
      fprintf (outfile,"(%s) -90 %.1f %.1f tlr\n",file_name,
            (((double) 8.5)-top_margin*((double) 0.5))*((double) 72.0)-point_size*((double) 0.5),
            (((double) 11.0)-left_margin)*((double) 72.0));
      }
   if (time_flag)
      {
      fprintf (outfile,"(%s) -90 %.1f %.1f trr\n",time_string,
            (((double) 8.5)-top_margin*((double) 0.5))*((double) 72.0)-point_size*((double) 0.5),
            left_margin*((double) 72.0));
      }
   ++pages;
   fprintf (outfile,"showpage\n");
   fprintf (outfile,"%%%%Page: %d %d\n",pages,pages);
   x = (((double) 8.5)-top_margin)*((double) 72.0)-point_size;
   y = (((double) 11.0)-left_margin)*((double) 72.0);
   if (strncmp (font,"courier",7) == 0)
      {
      fprintf (outfile,"/Courier findfont %.1f scalefont setfont\n",point_size);
      }
   else if (strncmp (font,"helvetica",9) == 0)
      {
      fprintf (outfile,"/Helvetica findfont %.1f scalefont setfont\n",point_size);
      }
   else if (strncmp (font,"times",5) == 0)
      {
      fprintf (outfile,"/Times-Roman findfont %.1f scalefont setfont\n",point_size);
      }
   }

n = -1;

for (i = 0; i < 1025; ++i)
   {
   if ((buffer[i] == '\n') || (buffer[i] == '\0'))
      {
      ps_string[++n] = '\0';
      break;
      }
   else if (buffer[i] == '\\')
      {
      ps_string[++n] = '\\';
      ps_string[++n] = '\\';
      }
   else if (buffer[i] == '(')
      {
      ps_string[++n] = '\\';
      ps_string[++n] = '(';
      }
   else if (buffer[i] == ')')
      {
      ps_string[++n] = '\\';
      ps_string[++n] = ')';
      }
   else if (buffer[i] == '\f')
      {
      if (n != -1)
         {
         ps_string[++n] = '\0';
         if ((strncmp (mode,"port",4) == 0) && (n >= 0))
            {
            fprintf (outfile,"(%s) %.1f %.1f tl\n",ps_string,x,y);
            }
         else if ((strncmp (mode,"land",4) == 0) && (n >= 0))
            {
            fprintf (outfile,"(%s) -90 %.1f %.1f tlr\n",ps_string,x,y);
            }
         n = -1;
         }
      sprintf (temp,"%d",pages);
      if (strncmp (mode,"port",4) == 0)
         {
         if (page_flag)
            {
            fprintf (outfile,"(%s) 306.0 %.1f tc\n",temp,bot_margin*((double) 36.0));
            }
         if (file_flag)
            {
            fprintf (outfile,"(%s) %.1f %.1f tl\n",file_name,left_margin*((double) 72.0),
            (((double) 11.0)-top_margin*((double) 0.5))*((double) 72.0)-
            point_size*((double) 0.5));
            }
         if (time_flag)
            {
            fprintf (outfile,"(%s) %.1f %.1f tr\n",time_string,
            (((double) 8.5)-left_margin)*((double) 72.0),
            (((double) 11.0)-top_margin*((double) 0.5))*((double) 72.0)-
            point_size*((double) 0.5));
            }
         x = left_margin*((double) 72.0);
         y = (((double) 11.0)-top_margin)*((double) 72.0)-point_size;
         }
      else
         {
         if (page_flag)
            {
            fprintf (outfile,"(%s) -90 %.1f 396.0 tcr\n",temp,bot_margin*((double) 36.0));
            }
         if (file_flag)
            {
            fprintf (outfile,"(%s) -90 %.1f %.1f tlr\n",file_name,
            (((double) 8.5)-top_margin*((double) 0.5))*((double) 72.0)-point_size*((double) 0.5),
            (((double) 11.0)-left_margin)*((double) 72.0));
            }
         if (time_flag)
            {
            fprintf (outfile,"(%s) -90 %.1f %.1f trr\n",time_string,
            (((double) 8.5)-top_margin*((double) 0.5))*((double) 72.0)-point_size*((double) 0.5),
            left_margin*((double) 72.0));
            }
         x = (((double) 8.5)-top_margin)*((double) 72.0)-point_size;
         y = (((double) 11.0)-left_margin)*((double) 72.0);
         }
      ++pages;
      fprintf (outfile,"showpage\n");
      fprintf (outfile,"%%%%Page: %d %d\n",pages,pages);
      }
   else
      {
      ps_string[++n] = buffer[i];
      }
   }

if ((strncmp (mode,"port",4) == 0) && (n >= 0))
   {
   fprintf (outfile,"(%s) %.1f %.1f tl\n",ps_string,x,y);
   y = y-point_size;
   }
else if ((strncmp (mode,"land",4) == 0) && (n >= 0))
   {
   fprintf (outfile,"(%s) -90 %.1f %.1f tlr\n",ps_string,x,y);
   x = x-point_size;
   }

return;

}

/*                                                                   */
/*--- Function footer -----------------------------------------------*/
/*                                                                   */

void footer (outfile)
FILE *outfile;

{
char temp[50];

sprintf (temp,"%d",pages);

if (strncmp (mode,"port",4) == 0)
   {
   if (page_flag)
      {
      fprintf (outfile,"(%s) 306.0 %.1f tc\n",temp,bot_margin*((double) 36.0));
      }
   if (file_flag)
      {
      fprintf (outfile,"(%s) %.1f %.1f tl\n",file_name,left_margin*((double) 72.0),
            (((double) 11.0)-top_margin*((double) 0.5))*((double) 72.0)-
            point_size*((double) 0.5));
      }
   if (time_flag)
      {
      fprintf (outfile,"(%s) %.1f %.1f tr\n",time_string,
            (((double) 8.5)-left_margin)*((double) 72.0),
            (((double) 11.0)-top_margin*((double) 0.5))*((double) 72.0)-
            point_size*((double) 0.5));
      }
   }
else
   {
   if (page_flag)
      {
      fprintf (outfile,"(%s) -90 %.1f 396.0 tcr\n",temp,bot_margin*((double) 36.0));
      }
   if (file_flag)
      {
      fprintf (outfile,"(%s) -90 %.1f %.1f tlr\n",file_name,
            (((double) 8.5)-top_margin*((double) 0.5))*((double) 72.0)-point_size*((double) 0.5),
            (((double) 11.0)-left_margin)*((double) 72.0));
      }
   if (time_flag)
      {
      fprintf (outfile,"(%s) -90 %.1f %.1f trr\n",time_string,
            (((double) 8.5)-top_margin*((double) 0.5))*((double) 72.0)-point_size*((double) 0.5),
            left_margin*((double) 72.0));
      }
   }

fprintf (outfile,"showpage\n");
fprintf (outfile,"%%%%Pages: %d\n",pages);

return;

}

/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

return;

}
