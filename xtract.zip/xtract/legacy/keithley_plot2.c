#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"

main (int argc, char *argv[])
   {
   int     i,device;
   char    file_name[80],out_name[80],string[256],ch;
   char    head1[2048],head2[2048],head3[512];
   double  t1,t2,xdata[2000],y1data[2000],y2data[2000];
   FILE    *infile;
   jPLOT_ITEM *plot1;

   file_name[0] = 0;
   out_name[0]  = 0;
   device = 0;

   // parse command line
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-h",2))
         {
         printf ("\nUSAGE: keithley_plot [-dA -h] [filename]\n----------------------------------------\n");
         printf ("      -dA   Sets a graphic device, where A is one of X, P, or M; indicating\n");
         printf ("               X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("      -h    Brings up this dialog.\n\n");
         return 0;
         }
      else if (!strncmp (argv[i],"-d",2))
         {
         sscanf (argv[i],"-d%c",&ch);
         if ((ch == 'X') || (ch == 'x'))
            device = 1;
         else if ((ch == 'M') || (ch == 'm'))
            device = 2;
         else if ((ch == 'P') || (ch == 'p'))
            device = 3;
         }
      else if (i == (argc-1))
         sscanf (argv[i],"%s",file_name);
      }

   if (!file_name[0])
      {
      printf ("Filename?\n> ");
      fgets (string,255,stdin);
      sscanf (string,"%79s",file_name);
      }
   else
      device = 1;

   if (device < 1)
      {
      printf ("\nGraphics Device?\n 1: X-Windows\n 2: Metafile\n 3: Postscript\n\n> ");
      fgets (string,255,stdin);
      if (sscanf (string,"%lf%lf",&t1,&t2) == 2)
         {
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         sscanf (string,"%79s",out_name);
         fgets (string,255,stdin);
         i = 0;
         sscanf (string,"%d",&i);
         if (i == 10)
            device = 3;
         else if (i == 11)
            device = 1;
         else if (i == 12)
            device = 2;
         }
      else
         sscanf (string,"%d",&device);
      }

   if ((device < 1) || (device > 3))
      {
      printf ("INVALID GRAPHICS DEVICE.\n");
      return -1;
      }

   if ((device != 1) && !out_name[0])
      {
      printf ("Plot file name?\n> ");
      fgets (string,255,stdin);
      sscanf (string,"%79s",out_name);
      }

   infile = fopen (file_name,"r");
   if (!infile)
      {
      printf ("UNABLE TO OPEN FILE - %s\n",file_name);
      return -1;
      }

   if (!open_graphics_device (device,out_name))
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   plot1 = create_plot_item (SingleY,2.75,1.25,5.5,4.5);
   plot1->attribs.title_offset = 0.3;

   /*****************  HEADER  ******************/

   head1[0] = head2[0] = head3[0] = 0;
   for (i = 0; i < 7; ++i)
      {
      fgets (string,255,infile);
      strcat (head1,&string[1]);
      }

   for (i = 0; i < 6; ++i)
      {
      fgets (string,255,infile);
      strcat (head2,&string[1]);
      }

   while (fgets (string,255,infile))
      {
      if (strstr (string,"DC FET PARAMETERS"))
         {
         fgets (string,255,infile);
         strcat (head3,&string[1]);
         fgets (string,255,infile);
         strcat (head3,string);
         break;
         }
      }

   add_text (head1,2.0,7.9,FNT_COURIER,10,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
   add_text (head2,6.0,7.9,FNT_COURIER,10,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
   add_text (head3,1.75,6.6,FNT_COURIER,10,0.0,LEFT_JUSTIFY,CLR_BLACK,0);

   /*****************  IV CURVES  ******************/
   
   while (fgets (string,255,infile))
      {
      if (strstr (string,"DC IV-CURVES"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&xdata[i],&y1data[i],&t1,&y2data[i]) == 4)
         {
         y1data[i] *= 1000.0;
         y2data[i] *= 1000.0;
         ++i;
         }
      }

   attach_y1data (plot1,xdata,y1data,i,LT_SOLID,1,CLR_RED);

   set_axis_scaling (plot1,POSITIVE_X | POSITIVE_Y1);

   set_axis_labels (plot1,"Vds (volts)","Ids (mA)",NULL,"I-V Curves");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  Igs VS Vds  ******************/

   detach_data (plot1);

   attach_y1data (plot1,xdata,y2data,i,LT_SOLID,1,CLR_RED);

   set_axis_scaling (plot1,POSITIVE_X);

   set_axis_labels (plot1,"Vds (volts)","Igs (mA)",NULL,"Gate Current vs. Drain Voltage");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  REV BREAKDOWN  ***************/

   rewind (infile);
   detach_data (plot1);
    
   while (fgets (string,255,infile))
      {
      if (strstr (string,"BREAKDOWN IV-CURVES"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&t1,&t2,&xdata[i],&y1data[i]) == 4)
         {
         xdata[i] = t1 - xdata[i];
         y1data[i] *= 1000.0;
         ++i;
         }
      }

   attach_y1data (plot1,xdata,y1data,i,LT_SOLID,1,CLR_RED);

   set_axis_scaling (plot1,0);

   set_axis_labels (plot1,"Vdg (volts)","Igd (mA)",NULL,"Breakdown Curves");

   if (!draw_page ())
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   /*****************  DONE PLOTS  ******************/

   close_graphics_device ();
   fclose (infile);

   return 0;
   }
