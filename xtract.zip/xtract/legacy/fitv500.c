#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdarg.h>
#include "ss_tools2.h"
#include "jplot.h"

#define NUM_PARAMS     20
#define MAX_FREQS      500
#define ERROR_FILE_NAME  "batch_error_file.txt"

static int std_fet_fit (char *meas_name, double fmin, double fmax, double *weights, OPT_PARAMETER *init_p,
                        char *final_p, char *mod_out, unsigned max_iter, char *header, char *error, int verbose);
static int plot_meas_vs_model (char *meas_name, char *mod_name, int device, char *error);
static void log_error (char *err_msg, char *fname); 

/*******************************************************************************************/
/*******************************************************************************************/

main (int argc, char *argv[]) 
   {
   char s_measured_name[256];
   char starting_values[256];
   char finishing_values[256];
   char mod_out_name[256];
   char string[256];
   char str2[256];
   char error[500];
   char head[2000];
   char *err_file = NULL;
   unsigned maxiter;
   unsigned i = 0,j;
   double weights[6];
   double fmin,fmax;
   OPT_PARAMETER p[NUM_PARAMS];
   FILE *file;
   int batch_mode = 0;
   int device = 1;
   int no_plots = 0;
   int verbose = 1;

   // parse the command line
   for (j = 1; j < argc; ++j)
      {
      if (!strncmp (argv[j],"-h",2))
         {
         printf ("\nUSAGE: sp_plot [-dA -h] [filename]\n----------------------------------------\n");
         printf ("      -dA   Sets a graphic device, where A is one of X, P, or M; indicating\n");
         printf ("               X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("      -b    Enables batch mode.\n");
         printf ("      -np   Do not generate plots.\n");
         printf ("      -h    Bring up this dialog.\n\n");
         return 0;
         }
      else if (!strcmp (argv[j], "-b"))
         batch_mode = 1;
      else if (!strncmp (argv[j],"-d",2))
         {
         char ch;
         
         sscanf (argv[i],"-d%c",&ch);
         if ((ch == 'M') || (ch == 'm'))
            device = 2;
         else if ((ch == 'P') || (ch == 'p'))
            device = 3;
         }
      else if (!strcmp (argv[j], "-np"))
         no_plots = 1;
      }
   
   if (batch_mode)
      {
      verbose = 0;
      err_file = ERROR_FILE_NAME;
      }
   
   if (!batch_mode)
      printf ("Measured data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", s_measured_name);

   if (!batch_mode)
      printf ("Frequency range for optimization in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fmin, &fmax) != 2)
      {
      log_error ("Error reading min/max frequencies.\n", err_file);
      return -1;
      }
   fmin *= 1.0e9;
   fmax *= 1.0e9;

   if (!batch_mode)
      printf ("Optimization weights (S11 S21 S12 S22 K MAG)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2],
      &weights[3], &weights[4], &weights[5]) != 6)
      {
      log_error ("Error reading optimization weights.\n", err_file);
      return -1;
      }

   if (!batch_mode)
      printf ("Initial parameters file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", starting_values);

   if (!batch_mode)
      printf ("Final parameters file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", finishing_values);

   if (!batch_mode)
      printf ("Model output file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", mod_out_name);

   if (!batch_mode)
      printf ("Maximum number of line searches?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%u", &maxiter);

   // read in starting parameter values

   file = fopen (starting_values, "r");
   if (!file)
      {
      log_error ("Unable to open starting values file.\n", err_file);
      return -1;
      }

   while (fgets (string, 255, file))
      {
      if (i >= NUM_PARAMS)
         break;

      if (sscanf (string,"%lf%lf%lf%lf%19s", &p[i].min, &p[i].nom, &p[i].max, &p[i].tol, p[i].name) == 5)
         {
         if (p[i].min > p[i].max)
            {
            sprintf (str2, "Warning: parameter #%d - \"%s\" - MIN is greater than MAX.\n", i+1, p[i].name);
            log_error (str2, err_file);
            }
         else if (p[i].nom < p[i].min)
            {
            sprintf (str2, "Warning: parameter #%d - \"%s\" - NOMINAL is less than MIN.\n", i+1, p[i].name);
            log_error (str2, err_file);
            }
         else if (p[i].nom > p[i].max)
            {
            sprintf (str2, "Warning: parameter #%d - \"%s\" - NOMINAL is greater than MAX.\n", i+1, p[i].name);
            log_error (str2, err_file);
            }
          
         p[i].optimize = TRUE;

         ++i;
         }
      }
   fclose (file);

   if (i != NUM_PARAMS)
      {
      sprintf (str2, "Error: invalid number of parameters in file %s.\n", starting_values);
      log_error (str2, err_file);
      return -1;
      }

   // read in the model file header

   file = fopen (s_measured_name, "r");
   if (!file)
      {
      log_error ("Measured data file not found.\n", err_file);
      return -1;
      }
      
   i = 0;
   head[0] = 0;      
   while (fgets (string, 255, file))
      {
      if ((++i > 30) || (string[0] != '!'))
         break;
       
      strcat (head, string);
      }
   fclose (file);
      
   // perform the small-signal fit
     
   if (std_fet_fit (s_measured_name, fmin, fmax, weights, p, finishing_values, mod_out_name, maxiter, head, error, verbose))
      {
      log_error (error, err_file);
      return -1;
      }
      
   // plot the results
   if (!no_plots && !batch_mode && plot_meas_vs_model (s_measured_name, mod_out_name, device, error))
      {
      log_error (error, err_file);
      return -1;
      }
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int std_fet_fit (char *meas_name, double fmin, double fmax, double *weights, OPT_PARAMETER *init_p,
                        char *final_p, char *mod_out, unsigned max_iter, char *header, char *error, int verbose)
   {
   S_2PORT sp[MAX_FREQS];
   NETLIST *netlist[20],*nlist;
   OPT_PARAMETER params[NUM_PARAMS];
   unsigned numf;
   unsigned findex,i,j;
   unsigned numf_in_range = 0;
   unsigned long flags = OPT_SINGLE_PARAM;
   COMPLEX s[4];
   POLAR spolar[4];
   double dummy = 0.0;
   FILE *file;
   double error_return[6];

   numf = read_s_from_file (meas_name, sp, NULL, MAX_FREQS);
   if (numf < 1)
      {
      sprintf (error, "No data in %s; or file not found.", meas_name);
      return -1;
      }

   // determine the start and stop indexes for the frequency range of the fit

   findex = numf;
   for (i = 0; i < numf; ++i)
      {
      if (sp[i].freq >= fmin)
         {
         findex = i;
         break;
         }
      }
   
   for (i = findex; i < numf; ++i)
      {
      if (sp[i].freq <= fmax)
         ++numf_in_range;
      }
      
   if (numf_in_range < 1)
      {
      sprintf (error, "No measured data within specified frequency range.");
      return -1;
      }

   // copy the initial parameter values to a local copy

   for (i = 0; i < NUM_PARAMS; ++i)
      params[i] = init_p[i];

   // create the netlist

   netlist[0]  = netlist_component (Netlist_R, dummy, 3, 4, 0);                       // rg
   netlist[1]  = netlist_component (Netlist_R, dummy, 7, 8, 2);                       // rd
   netlist[2]  = netlist_component (Netlist_L, dummy, 1, 3, 10);                      // lg
   netlist[3]  = netlist_component (Netlist_L, dummy, 8, 2, 11);                      // ld
   netlist[4]  = netlist_component (Netlist_SRL, dummy, dummy, 6, 0, 1, 9);           // rs and ls
   netlist[5]  = netlist_component (Netlist_C, dummy, 1, 0, 7);                       // c1
   netlist[6]  = netlist_component (Netlist_C, dummy, 2, 0, 8);                       // c2
   netlist[7]  = netlist_component (Netlist_C, dummy, 3, 6, 18);                      // c11
   netlist[8]  = netlist_component (Netlist_C, dummy, 8, 6, 19);                      // c22
   netlist[9]  = netlist_component (Netlist_C, dummy, 4, 5, 4);                       // cgs
   netlist[10] = netlist_component (Netlist_C, dummy, 4, 7, 5);                       // cgd
   netlist[11] = netlist_component (Netlist_C, dummy, 6, 7, 6);                       // cds
   netlist[12] = netlist_component (Netlist_R, dummy, 5, 6, 3);                       // ri
   netlist[13] = netlist_component (Netlist_G, dummy, 4, 5, 12);                      // ggs
   netlist[14] = netlist_component (Netlist_G, dummy, 4, 7, 13);                      // ggd
   netlist[15] = netlist_component (Netlist_VCCS, dummy, dummy, 4, 5, 7, 6, 14, 15);  // gm and tau
   netlist[16] = netlist_component (Netlist_VCCS, dummy, dummy, 7, 6, 7, 6, 16, 17);  // gds and tau2

   nlist = prepare_netlist (netlist, 17);

   // optimize

   if (verbose)
      flags |= OPT_VERBOSE;
   
   if (small_signal_optimizer (nlist, params, NUM_PARAMS, &sp[findex], numf_in_range, max_iter, weights, flags, error_return))
      {
      sprintf (error, "Error during optimization: %s", get_cg_error());
      return -1;
      }

   // write the final parameter values

   file = fopen (final_p, "w+");
   if (!file)
      {
      sprintf (error, "Error writing final parameter file.");
      return -1;
      }

   for (i = 0; i < NUM_PARAMS; ++i)
      fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", params[i].min, params[i].nom,
         params[i].max, params[i].tol, params[i].name);
   fclose (file);
   
   // write the model file

   file = fopen (mod_out, "w+");
   if (!file)
      {
      sprintf (error, "Error writing model file.");
      return -1;
      }

   fprintf (file, "%s", header);
   fprintf (file, "!\n");

   fprintf (file, "!  Rg     Rs     Rd      Lg     Ls     Ld     C1     C2    C11    C22\n");
   fprintf (file, "! (ohm)  (ohm)  (ohm)   (pH)   (pH)   (pH)   (pF)   (pF)   (pF)   (pF)\n");
   //                |    | |    | |    | |    | |    | |    | |    | |    | |    | |    | 
   fprintf (file, "! %6.3f %6.3f %6.3f %6.2f %6.2f %6.2f %6.3f %6.3f %6.3f %6.3f\n",
      params[0].nom, params[1].nom, params[2].nom, params[10].nom*1.0e12, params[9].nom*1.0e12,
      params[11].nom*1.0e12, params[7].nom*1.0e12, params[8].nom*1.0e12, params[18].nom*1.0e12,
      params[19].nom*1.0e12);
   fprintf (file, "!\n");
   
   fprintf (file, "!  Ri     Cgs    Cgd    Cds     Gm    Tau     Gds    Tau2    Ggs    Ggd\n");
   fprintf (file, "! (ohm)   (pF)   (pF)   (pF)   (mS)   (pS)    (mS)   (pS)    (mS)   (mS)\n");
   //                |    | |    | |    | |    | |    | |    | |     | |    | |     | |     | 
   fprintf (file, "! %6.3f %6.3f %6.3f %6.3f %6.2f %6.3f %7.2f %6.3f %7.2f %7.2f\n",
      params[3].nom, params[4].nom*1.0e12, params[5].nom*1.0e12, params[6].nom*1.0e12,
      params[14].nom*1.0e3, params[15].nom*1.0e12, params[16].nom*1.0e3, params[17].nom*1.0e12,
      params[12].nom*1.0e3, params[13].nom*1.0e3);
   fprintf (file, "!\n");
       
   fprintf (file, "! S11_err S21_err S12_err S22_err  K_err  MAG_err\n");
   //                |    |  |    |  |    |  |    |  |    |  |    |
   fprintf (file, "! %6.3f  %6.3f  %6.3f  %6.3f  %6.3f  %6.3f\n", error_return[0], error_return[1],
      error_return[2], error_return[3], error_return[4], error_return[5]);

   fprintf (file, "!\n");
   fprintf (file, "# S HZ MA R 50\n");
   fprintf (file, "!Frequency    S11-mag     S11-ang      S21-mag     S21-ang      S12-mag     S12-ang      S22-mag     S22-ang\n");
   //              |         | |         | |          | |         | |          | |         | |          | |         | |          |
   for (i = 0, j = findex; i < numf_in_range; ++i, ++j)
      {
      small_signal_model (nlist, sp[j].freq, s);
      CA2PA (s, spolar, 2, 2);
      fprintf (file,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n", sp[j].freq, spolar[0].m, spolar[0].a,
         spolar[2].m, spolar[2].a, spolar[1].m, spolar[1].a, spolar[3].m, spolar[3].a);
      }
   fclose (file);

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int plot_meas_vs_model (char *meas_name, char *mod_name, int device, char *error)
   {
   S_2PORT s_mod[MAX_FREQS];
   S_2PORT s_meas[MAX_FREQS];
   double mod_mag[MAX_FREQS];
   double mod_ang[MAX_FREQS];
   double mod_freq[MAX_FREQS];
   double meas_mag[MAX_FREQS];
   double meas_ang[MAX_FREQS];
   double meas_freq[MAX_FREQS];
   char string[256];
   char head[5000],head2[5000];
   FILE *file;
   int i;
   unsigned j,n_mod_f,n_meas_f;
   char *legend_text1[] = {"Modeled Magnitude", "Modeled Phase", "Measured Magnitude", "Measured Phase"};
   char *legend_text2[] = {"Modeled MAG/MSG", "Modeled K-Factor", "Measured MAG/MSG", "Measured K-Factor"};
   int legend_ltypes[] = {LT_SOLID, LT_DASHED, LT_SOLID, LT_DASHED};
   int legend_lwidths[] = {1, 1, 1, 1};
   int legend_colors[] = {CLR_RED, CLR_RED, CLR_DARKGREEN, CLR_DARKGREEN};
   jHANDLE legend1,header1,title1,header2;
   jPLOT_ITEM *plot1;
   
   // load S-parameter data
   
   n_mod_f = read_s_from_file (mod_name, s_mod, NULL, MAX_FREQS);
   if (n_mod_f < 1)
      {
      sprintf (error, "Unable to read data from file: %s", mod_name);
      return -1;
      }
      
   n_meas_f = read_s_from_file (meas_name, s_meas, NULL, MAX_FREQS);
   if (n_meas_f < 1)
      {
      sprintf (error, "Unable to read data from file: %s", meas_name);
      return -1;
      }
       
   // create the plot header information
   
   i = 0;
   head[0] = 0;
   file = fopen (mod_name, "r");
   while (fgets (string, 255, file))
      {
      if ((string[0] != '!') || (++i > 20) || !strncmp (string, "!COMMENTS", 9))
         break;
      
      strcat (head, &string[1]);
      }
   head2[0] = 0;
   while (fgets (string, 255, file))
      {
      if (string[0] != '!')
         break;
         
      if (!strncmp (string, "!BIAS", 5))
         {
         strcat (head2, &string[1]);
         strcat (head2, "\n");
         fgets (string, 255, file);
         for (i = 0; i < 3; ++i)
            {
            if (fgets (string, 255, file) && (string[0] == '!'))
               strcat (head2, &string[1]);
            }
         strcat (head2, "\n");
         fgets (string, 255, file);
         for (i = 0; i < 3; ++i)
            {
            if (fgets (string, 255, file) && (string[0] == '!'))
               strcat (head2, &string[1]);
            }
         strcat (head2, "\n");
         fgets (string, 255, file);
         for (i = 0; i < 2; ++i)
            {
            if (fgets (string, 255, file) && (string[0] == '!'))
               strcat (head2, &string[1]);
            }
         
         break;
         }
      }
   fclose (file);
   
   header1 = add_text (head, 1.0, 8.0, FNT_HELVETICA, 8, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE);
   header2 = add_text (head2, 4.0, 8.0, FNT_HELVETICA, 8, 0.0, JUST_LEFT, CLR_BLACK, NO_STYLE);
   
   legend1 = add_legend (4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);  
   
   // draw the plots 

   if (!open_graphics_device (device, NULL))
      {
      sprintf (error, "%s",get_error_message (ERROR_NUMBER));
      return -1;
      }

   plot1 = create_plot_item (DoubleY, 1.5, 1.25, 5.0, 4.0);
   set_axis_labels (plot1, "Frequency (GHz)", "Magnitude", "Phase", "");
      
   // cycle through the different plots
   
   for (i = 0; i < 6; ++i)
      {
      switch (i)
         {
         case 0:  // S11
            for (j = 0; j < n_mod_f; ++j)
               {
               mod_mag[j] = Cmag (s_mod[j].s[0]);
               mod_ang[j] = Cangle (s_mod[j].s[0]);
               mod_freq[j] = s_mod[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
            attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);
            
            for (j = 0; j < n_meas_f; ++j)
               {
               meas_mag[j] = Cmag (s_meas[j].s[0]);
               meas_ang[j] = Cangle (s_meas[j].s[0]);
               meas_freq[j] = s_meas[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
            attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
            
            title1 = add_text ("S11", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
            break;

         case 1:  // S21
            for (j = 0; j < n_mod_f; ++j)
               {
               mod_mag[j] = Cmag (s_mod[j].s[2]);
               mod_ang[j] = Cangle (s_mod[j].s[2]);
               mod_freq[j] = s_mod[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
            attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);
            
            for (j = 0; j < n_meas_f; ++j)
               {
               meas_mag[j] = Cmag (s_meas[j].s[2]);
               meas_ang[j] = Cangle (s_meas[j].s[2]);
               meas_freq[j] = s_meas[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
            attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);            
            title1 = add_text ("S21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
            break;

         case 2:  // S12
            for (j = 0; j < n_mod_f; ++j)
               {
               mod_mag[j] = Cmag (s_mod[j].s[1]);
               mod_ang[j] = Cangle (s_mod[j].s[1]);
               mod_freq[j] = s_mod[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
            attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);
            
            for (j = 0; j < n_meas_f; ++j)
               {
               meas_mag[j] = Cmag (s_meas[j].s[1]);
               meas_ang[j] = Cangle (s_meas[j].s[1]);
               meas_freq[j] = s_meas[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
            attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
            title1 = add_text ("S12", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
            break;

         case 3:  // S22
            for (j = 0; j < n_mod_f; ++j)
               {
               mod_mag[j] = Cmag (s_mod[j].s[3]);
               mod_ang[j] = Cangle (s_mod[j].s[3]);
               mod_freq[j] = s_mod[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
            attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);
            
            for (j = 0; j < n_meas_f; ++j)
               {
               meas_mag[j] = Cmag (s_meas[j].s[3]);
               meas_ang[j] = Cangle (s_meas[j].s[3]);
               meas_freq[j] = s_meas[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
            attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
            title1 = add_text ("S22", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
            break;
 
         case 4:  // K and MAG
            for (j = 0; j < n_mod_f; ++j)
               {
               mod_mag[j] = s_mod[j].MAG;
               mod_ang[j] = s_mod[j].k;
               mod_freq[j] = s_mod[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
            attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);
            
            for (j = 0; j < n_meas_f; ++j)
               {
               meas_mag[j] = s_meas[j].MAG;
               meas_ang[j] = s_meas[j].k;
               meas_freq[j] = s_meas[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
            attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
            
            set_axis_labels (plot1, "Frequency (GHz)", "MAG/MSG (dB)", "K-Factor", "");
            remove_user_item (legend1);
            legend1 = add_legend (4, 8.0, 4.0, legend_text2, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);  
            title1 = add_text ("MAG/MSG\nand\nK-Factor", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
            break;

         case 5:  // H21
            for (j = 0; j < n_mod_f; ++j)
               {
               s2h (s_mod[j].s, s_mod[j].s, 50.0);
               mod_mag[j] = 20.0 * log10 (Cmag (s_mod[j].s[2]));
               mod_ang[j] = Cangle (s_mod[j].s[2]);
               mod_freq[j] = s_mod[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, mod_freq, mod_mag, n_mod_f, LT_SOLID, 1, CLR_RED);
            attach_y2data (plot1, mod_freq, mod_ang, n_mod_f, LT_DASHED, 1, CLR_RED);
            
            for (j = 0; j < n_meas_f; ++j)
               {
               s2h (s_meas[j].s, s_meas[j].s, 50.0);
               meas_mag[j] = 20.0 * log10 (Cmag (s_meas[j].s[2]));
               meas_ang[j] = Cangle (s_meas[j].s[2]);
               meas_freq[j] = s_meas[j].freq * 1.0e-9;
               }
            attach_y1data (plot1, meas_freq, meas_mag, n_meas_f, LT_SOLID, 1, CLR_DARKGREEN);
            attach_y2data (plot1, meas_freq, meas_ang, n_meas_f, LT_DASHED, 1, CLR_DARKGREEN);
            
            set_axis_labels (plot1, "Frequency (GHz)", "Magnitude (dB)", "Angle", "");
            set_axis_scaling (plot1, LogX);
            remove_user_item (legend1);
            legend1 = add_legend (4, 8.0, 4.0, legend_text1, FNT_HELVETICA, 12, legend_ltypes, legend_lwidths, legend_colors);  
            title1 = add_text ("H21", 9.0, 5.0, FNT_HELVETICA, 16, 0.0, JUST_CENTER, CLR_BLACK, TS_BOLD);
            break;
         }
      
      if (!draw_page ())
         {
         sprintf (error, "%s",get_error_message (ERROR_NUMBER));
         close_graphics_device ();
         return -1;
         }

      detach_data (plot1);
      remove_user_item (title1);
      }
            
   close_graphics_device ();
   return 0;
   }
   
/*******************************************************************************************/
/*******************************************************************************************/

static void log_error (char *err_msg, char *fname)
   {  
   if (!err_msg)
      return;
      
   if (!fname || (strlen (fname) < 1))
      {
      fprintf (stderr, "%s", err_msg);
      
      if (err_msg[strlen(err_msg)-1] != '\n')
         fprintf (stderr, "\n");
      
      return;
      }
   else
      {
      FILE *file = fopen (fname, "a");
      if (!file)
         return;
      
      fprintf (file, "%s", err_msg);
      
      if (err_msg[strlen(err_msg)-1] != '\n')
         fprintf (stderr, "\n");
      
      fclose (file);
      }
   }
      
      
   
   
   
   
   
   
