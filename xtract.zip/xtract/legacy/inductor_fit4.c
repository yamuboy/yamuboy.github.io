#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "ss_tools2.h"

typedef struct
   {
   S_2PORT *sMeas;
   unsigned sz_s;
   } IND_DATA;

#define MAX_FREQS   500
#define Q_FREQ      1.0e9

static int inductor_erf (double *pl, void *data, double *err, unsigned n_err);
static int q_erf (double *pl, void *data, double *err, unsigned n_err);
static void inductor_model (double *pl, COMPLEX *sp, double freq);
static void linefit_mx0 (double *x, double *y, unsigned n, double *m, double *r2);

/******************************************************************************/
/******************************************************************************/

main (int argc, char *argv[]) 
   {
   IND_DATA ind_data;
   char s_measured[256];
   char string[256];
   char fname[256];
   char out_name[256];
   char starting_values[256];
   char extension[20];
   char *batch_name;
   unsigned maxiter = 0;
   double weights[4];
   S_2PORT sp[MAX_FREQS];
   COMPLEX zp[4];
   OPTIMIZE *opt;
   double fmin,fmax;
   double fr[MAX_FREQS];
   double z21[MAX_FREQS];
   double w_l[MAX_FREQS];
   double c1_l[MAX_FREQS];
   double c2_l[MAX_FREQS];
   double m,r2,l_val;
   unsigned i,j,findex,numf,num_z;
   FILE *batch_file,*file;
   double pl[5];
   COMPLEX sMod[4],y[4];
   POLAR sModp[4];
   OPT_PARAMETER p[] = 
      {
      {0.0, 0.0, 0.0, 0.0, "L", TRUE},
      {0.0, 0.0, 0.0, 0.0, "Q", TRUE},
      {0.0, 0.0, 0.0, 0.0, "CP", TRUE},
      {0.0, 0.0, 0.0, 0.0, "C1", TRUE},
      {0.0, 0.0, 0.0, 0.0, "C2", TRUE}
      }
      ;
         
   printf ("Measured data file(s)?\n");
   fgets (s_measured, 255, stdin);
   s_measured[strlen(s_measured)-1] = 0;

   printf ("Optimization weights (S11 S21 S12 S22)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf%lf%lf", &weights[0], &weights[1], &weights[2],
      &weights[3]) != 4)
      {
      fprintf (stderr, "Error reading optimization weights.\n");
      return -1;
      }

   printf ("Output file extension?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%9s", extension);

   printf ("Maximum number of line searches?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%u", &maxiter);

   // initialize the optimizer

   opt = initialize_cg_optimizer ();
   set_cg_parameters (opt, p, 5);
   // set_cg_flags (opt, OPT_VERBOSE);
   set_cg_error_fraction (opt, 1.0e-10, 5);

   // get the file list

   batch_name = "temp_list_file";

   sprintf (string, "rm -f %s", batch_name);
   system (string);
   sprintf (string, "ls -1 %s > %s", s_measured, batch_name);
   system (string);

   batch_file  = fopen (batch_name, "r");
   if (!batch_file)
      {
      fprintf (stderr, "Cannot read file list.\n");
      return -1;
      }

   // start the loop

   while (fgets (fname, 255, batch_file))
      {
      fname[strlen(fname)-1] = 0;

      // read in s-parameters

      printf ("File %s.\n", fname);
      
      numf = read_s_from_file (fname, sp, NULL, MAX_FREQS);
      if (numf < 1)
         {
         fprintf (stderr, "No data; or file not found.\n");
         continue;
         }
      
      // determine the start and stop indexes
      //  only fit up until the first resonant frequency
      
      ind_data.sMeas = sp;
      ind_data.sz_s = 0;
      
      for (i = 0; i < numf; ++i)
         {
         s2y (sp[i].s, y, 50.0);
         if (Cangle (y[1]) > 0.0) 
            {
            ++ind_data.sz_s;
            continue;
            }
         
         break;
         }
               
      if (ind_data.sz_s < 3)
         {
         fprintf (stderr, "Not enough measured data within frequency range.\n");
         continue;
         }
         
      // direct extract L, C1, C2, and CP
      
      i = ind_data.sz_s/2;
      s2y (sp[i].s, y, 50.0);
      
      p[0].nom = 1.0 / ((y[1].i + y[2].i) * acos (-1.0) * sp[i].freq);
      p[1].nom = 30.0;
      p[2].nom = 1.0 / (4.0 * acos(-1.0) * acos (-1.0) * sp[ind_data.sz_s-1].freq * sp[ind_data.sz_s-1].freq * p[0].nom);
      // p[3].nom = (y[0].i + y[1].i) / (2.0 * acos (-1.0) * sp[i].freq);
      // p[4].nom = (y[3].i + y[2].i) / (2.0 * acos (-1.0) * sp[i].freq);

      for (j = 0; j < i; ++j)
         {
         c1_l[j] = y[0].i + y[1].i;
         c2_l[j] = y[3].i + y[2].i;
         w_l[j] = 2.0 * acos (-1.0) * sp[i].freq;
         }
      
      linefit_mx0 (w_l, c1_l, j, &p[3].nom, &r2);
      linefit_mx0 (w_l, c2_l, j, &p[4].nom, &r2);

      p[0].min = p[0].nom*0.5;
      p[0].max = p[0].nom*1.5;
      p[1].min = 1.0;
      p[1].max = 60.0;
      p[2].min = p[2].nom*0.1;
      p[2].max = p[2].nom*10.0;

      // optimize

      printf ("Optimizing L, C1, C2 and CP ...\n");

      set_cg_error_function (opt, inductor_erf, &ind_data, 4, weights);
   
      p[0].optimize = TRUE;
      p[1].optimize = FALSE;
      p[2].optimize = TRUE;
      p[3].optimize = FALSE;
      p[4].optimize = FALSE;
      if (cg_optimize4 (opt, maxiter, NULL))
         {
         fprintf (stderr, "Error: %s\n", get_cg_error ());
         continue;
         }

      // optimize Q

      printf ("Optimizing Q ...\n");

      set_cg_error_function (opt, q_erf, &ind_data, 4, weights);

      p[0].optimize = FALSE;
      p[1].optimize = TRUE;
      p[2].optimize = FALSE;
      p[3].optimize = FALSE;
      p[4].optimize = FALSE;
      if (cg_optimize4 (opt, maxiter, NULL))
         {
         fprintf (stderr, "Error: %s\n", get_cg_error ());
         continue;
         }

      // write the model file

      sscanf (fname, "%[^.]", out_name);
      strcat (out_name, extension);
      
      file = fopen (out_name, "w+");
      if (!file)
         {
         fprintf (stderr, "Error writing output.\n");
         continue;
         }

      fprintf (file, "!FILE: %s\n!\n", fname);
      fprintf (file, "!L  = %.4e H\n", p[0].nom);
      fprintf (file, "!Q  = %.4e\n", p[1].nom);
      fprintf (file, "!Cp = %.4e F\n", p[2].nom);
      fprintf (file, "!C1 = %.4e F\n", p[3].nom);
      fprintf (file, "!C2 = %.4e F\n!\n", p[4].nom);
      fprintf (file,"# S HZ MA R 50\n");

      pl[0] = p[0].nom;
      pl[1] = p[1].nom;
      pl[2] = p[2].nom;
      pl[3] = p[3].nom;
      pl[4] = p[4].nom;

      for (i = 0; i < numf; ++i)
         {
         inductor_model (pl, sMod, sp[i].freq);

         CA2PA (sMod, sModp, 2, 2);

         fprintf (file, "%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",
            sp[i].freq, sModp[0].m, sModp[0].a, sModp[2].m, sModp[2].a,
            sModp[1].m, sModp[1].a, sModp[3].m, sModp[3].a);
         }
      fclose (file);

      // write final parameter values

      sscanf (fname, "%[^.]", out_name);
      strcat (out_name, ".end");

      file = fopen (out_name, "w+");
      if (!file)
         {
         fprintf (stderr, "Error writing output.\n");
         continue;
         }

      for (i = 0; i < 5; ++i)
         fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", p[i].min, p[i].nom, p[i].max, p[i].tol, p[i].name);

      fclose (file);
      }
   fclose (batch_file);

   sprintf (string, "rm -f %s", batch_name);
   system (string);

   return 0;
   }

/******************************************************************************/
/******************************************************************************/

static int inductor_erf (double *pl, void *data, double *err, unsigned n_err)
   {
   IND_DATA *d = (IND_DATA *) data;
   COMPLEX s[4];
   unsigned i;

   if ((n_err < 4) || !data)
      return 1;

   // zero the error vector
   for (i = 0; i < n_err; ++i)
      err[i] = 0.0;

   // for each frequency,
   //  load the y-matrix
   //  calculate 2-port s-parameters
   //  calculate the L1 error vs measured data
   for (i = 0; i < d->sz_s; ++i)
      {
      inductor_model (pl, s, d->sMeas[i].freq);
      // s2z (s, s, 50.0);

      err[0] += Cmag (Csub (s[0], d->sMeas[i].s[0]));
      err[1] += Cmag (Csub (s[2], d->sMeas[i].s[2]));
      err[2] += Cmag (Csub (s[1], d->sMeas[i].s[1]));
      err[3] += Cmag (Csub (s[3], d->sMeas[i].s[3]));
      }

   // divide by the number of frequencies
   err[0] /= (double) d->sz_s;
   err[1] /= (double) d->sz_s;
   err[2] /= (double) d->sz_s;
   err[3] /= (double) d->sz_s;

   return 0;
   }

/******************************************************************************/
/******************************************************************************/

static int q_erf (double *pl, void *data, double *err, unsigned n_err)
   {
   IND_DATA *d = (IND_DATA *) data;
   COMPLEX s[4],y[4],ym[4];
   unsigned i;

   if ((n_err < 4) || !data)
      return 1;

   // zero the error vector
   for (i = 0; i < n_err; ++i)
      err[i] = 0.0;

   // for each frequency,
   //  load the y-matrix
   //  calculate 2-port s-parameters
   //  calculate the L1 error vs measured data
   for (i = 0; i < d->sz_s; ++i)
      {
      inductor_model (pl, s, d->sMeas[i].freq);
      s2y (s, y, 50.0);
      s2y (d->sMeas[i].s, ym, 50.0);

      err[0] += (y[0].r - ym[0].r) * (y[0].r - ym[0].r);
      err[1] += (y[2].r - ym[2].r) * (y[2].r - ym[2].r);
      err[2] += (y[1].r - ym[1].r) * (y[1].r - ym[1].r);
      err[3] += (y[3].r - ym[3].r) * (y[3].r - ym[3].r);
      }

   // divide by the number of frequencies
   err[0] /= (double) d->sz_s;
   err[1] /= (double) d->sz_s;
   err[2] /= (double) d->sz_s;
   err[3] /= (double) d->sz_s;

   return 0;
   }

/******************************************************************************/
/******************************************************************************/

static void inductor_model (double *pl, COMPLEX *sp, double freq)
   {
   double w = 2.0 * acos (-1.0) * freq;
   double r,indr,indi;
   COMPLEX y[4];
   double l  = pl[0];
   double q  = pl[1];
   double cp = pl[2];
   double c1 = pl[3];
   double c2 = pl[4];

   r = 2.0 * acos (-1.0) * Q_FREQ * l / q;
   r = r * sqrt (freq / Q_FREQ);
   if (r < 1.0e-6)
      r = 1.0e-6;

   indr = r/(r*r + w*w*l*l);
   indi = -w*l/(r*r + w*w*l*l);
   
   y[0].r = indr;
   y[0].i = w*c1 + w*cp + indi;
   
   y[1].r = -indr;
   y[1].i = -w*cp - indi;
   
   y[2].r = -indr;
   y[2].i = -w*cp - indi;
   
   y[3].r = indr;
   y[3].i = w*c2 + w*cp + indi;
   
   y2s (y, sp, 50.0);
   }

/******************************************************************************/
/******************************************************************************/

static void linefit_mx0 (double *x, double *y, unsigned n, double *m, double *r2)
   {
   unsigned i;
   double ysum = 0.0;
   double xxsum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   for (i = 0; i < n; ++i)
      {
      ysum  += y[i];
      xxsum += x[i]*x[i];
      xysum += x[i]*y[i];
      }

   *m = xysum / xxsum;
   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] - y[i])*((*m)*x[i] - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }




