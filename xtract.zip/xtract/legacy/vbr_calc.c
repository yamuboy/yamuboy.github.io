#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main ()

{
double   vlow,vhigh,ilow,ihigh;
double   rg,rd,area;
double   vgs,vds,ids,igs;
double   vbd[1000],ibd[1000];
double   v1,v2,Is,factor;
double   value;
int      i;
int      first;
int      last_dir,direct;
char     string[201];
char     file_name[201];
char     file_name2[201];
char     param[200];
FILE     *file1;

printf ("Vbr File > ");
scanf ("%s",file_name);

printf ("Ending values file > ");
scanf ("%s",file_name2);

file1 = fopen (file_name2,"r");
if (file1 == NULL)
   {
   printf ("ERROR: unable to open starting values file\n");
   return (0);
   }

i = 0;
while (fgets (string,200,file1) != NULL)
   {
   sscanf (string,"%*f %lf %*f %*f %s",&value,&param);
   if (!strncmp (param,"area",4))
      {
      area = value;
      ++i;
      }
   else if (!strncmp (param,"rg",2))
      {
      rg = value;
      ++i;
      }
   else if (!strncmp (param,"rd",2))
      {
      rd = value;
      ++i;
      }
   }
fclose (file1);

if (i != 3)
   {
   printf ("ERROR: incomplete starting values file.\n");
   return (0);
   }

file1 = fopen (file_name,"r");
if (file1 == NULL)
   {
   printf ("ERROR: unable to open vbr file\n");
   return (0);
   }

i = 0;
while (fgets (string,200,file1) != NULL)
   {
   if (string[0] != '!')
      {
      if (sscanf (string,"%lf %lf %lf %lf",&vds,&ids,&vgs,&igs) == 4)
         {
         if (vds != (double) 0.0)
            {
            continue;
            }
         vbd[i] = -vgs-rg*fabs (igs)-rd*fabs (ids);
         ibd[i] = -igs;
         ++i;
         }
      }
   }
fclose (file1);

if (i < 2)
   {
   printf ("ERROR: not enough points.\n");
   return (0);
   }

vhigh = vbd[i-1];
ihigh = ibd[i-1];

i = 0;
while (vbd[i] <= (double) 0.0)
   {
   ++i;
   }

vlow = vbd[i];
ilow = ibd[i];

Is = ilow;
factor = (double) 2.0;
i = 0;
first = 1;

while (++i < 100)
   {
   v1 = vlow/log (ilow/Is+((double) 1.0));
   v2 = vhigh/log (ihigh/Is+((double) 1.0));

   if (v2 > v1)
      {
      Is *= factor;
      direct = 1;
      }
   else if (v2 < v1)
      {
      Is *= ((double) 1.0)/factor;
      direct = 0;
      }
   else
      {
      break;
      }

   if (!first)
      {   
      if (last_dir != direct)
         {
         factor = (factor-((double) 1.0))*((double) 0.5)+((double) 1.0);
         }
      }
   first = 0;
   last_dir = direct;
   
   if (factor < (double) 1.00025)
      {
      break;
      }
   }    

printf ("Ibd = %.5e\n",Is/area*((double) 0.5));
printf ("Vbd = %.5e\n",v2);

return (0);

}
