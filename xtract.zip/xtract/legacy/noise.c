#include <stdio.h>
#include <string.h>
#include <time.h>

void get_the_time ();

main ()
{
FILE  *batch_job_file;
FILE  *tmp_file;
int   i;
char  buffer[201];
char  current_time[80];
char  batch_job_file_name[201];
char  yfit_tmp_file_name[201];
char  fxa_file[201];
char  fxb_file[201];
char  dmb_file[201];
char  noi_file[201];
char  ns_file[201];
char  rpc_file[201];
char  end_file[201];
char string[201];
char  dmb_extension[201];
char  temperature[201];
char  system_command[201];
char  files_to_fit[201];
time_t tb;

printf ("File names to fit (file name must contain wildcards)?\n");
fgets (string, 200, stdin);
sscanf (string, "%s", files_to_fit);

printf ("Input Error Box File Name?\n");
fgets (string, 200, stdin);
sscanf (string, "%s", fxa_file);

printf ("Output Error Box File Name?\n");
fgets (string, 200, stdin);
sscanf (string, "%s", fxb_file);

printf ("Noise Source File Name?\n");
fgets (string, 200, stdin);
sscanf (string, "%s", ns_file);

printf ("Extension for [S] Files?\n");
fgets (string, 200, stdin);
sscanf (string, "%s", dmb_extension);

printf ("Measurement temperature (Celcius)?\n");
fgets (string, 200, stdin);
sscanf (string, "%s", temperature);

sprintf (yfit_tmp_file_name,"tmp.%d",time(&tb));
sprintf (batch_job_file_name,"batch.%d",time(&tb));

sprintf (system_command,"rm -f %s",yfit_tmp_file_name);
system (system_command);
sprintf (system_command,"ls -1 %s > %s",files_to_fit,yfit_tmp_file_name);
system (system_command);

tmp_file = fopen (yfit_tmp_file_name,"r");
if (!tmp_file)
   {
   printf ("** error ** cannot open file %s\n",yfit_tmp_file_name);
   return 1;
   }

batch_job_file = fopen (batch_job_file_name,"w+");
if (!batch_job_file)
   {
   printf ("** error ** cannot open file %s\n",batch_job_file_name);
   return 1;
   }

while (fgets (noi_file,200,tmp_file))
   {
   dmb_file[0] = 's';
   sscanf (&noi_file[1],"%[^.]",&dmb_file[1]);
   strcat (dmb_file,dmb_extension);
   end_file[0] = 's';
   sscanf (&noi_file[1],"%[^.]",&end_file[1]);
   strcat (end_file,".end");
   sscanf (noi_file,"%[^.]",rpc_file);
   strcat (rpc_file,".rpc");
//   fprintf (batch_job_file,"fet_noise -batch << input\n");
   fprintf (batch_job_file,"noise_fort << input >> tmp.log\n");
   fprintf (batch_job_file,"%s",noi_file);
   fprintf (batch_job_file,"%s\n",fxa_file);
   fprintf (batch_job_file,"%s\n",fxb_file);
   fprintf (batch_job_file,"%s\n",dmb_file);
   fprintf (batch_job_file,"%s\n",end_file);
   fprintf (batch_job_file,"%s\n",ns_file);
   fprintf (batch_job_file,"%s\n",rpc_file);
   fprintf (batch_job_file,"%s\n",temperature);
   fprintf (batch_job_file,"input\n");
   }

fprintf (batch_job_file,"rm -f %s\n",batch_job_file_name);

fclose (batch_job_file);
fclose (tmp_file);

sprintf (system_command,"rm -f %s",yfit_tmp_file_name);
system (system_command);

sprintf (system_command,"chmod +x %s",batch_job_file_name);
system (system_command);

sprintf (system_command,"%s &",batch_job_file_name);
system (system_command);

return 0;
}


