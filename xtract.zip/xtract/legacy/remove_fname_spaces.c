#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   char fname[256];
   char cmd[1000];
   int i;
   unsigned len, j;

   if (argc < 2)
      {
      printf ("\n\n");
      printf ("USAGE: %s [files]\n", argv[0]);
      printf ("-------------------------------------------------\n");
      printf ("  Removes spaces from file names, replacing them with\n");
      printf ("     \'_\' characters.\n");
      printf ("\n\n");
      return 0;
      }

   for (i = 1; i < argc; ++i)
      {
      strcpy (fname, argv[i]);

      len = strlen (fname);
      for (j = 0; j < len; j++)
         {
         if (fname[j] == ' ')
            fname[j] = '_';
         }

      if( strcmp( fname, argv[i] ) )
         {
         sprintf (cmd, "mv -f \"%s\" \"%s\"", argv[i], fname);
         system (cmd);
         }
      }
   
   return 0;
   }


