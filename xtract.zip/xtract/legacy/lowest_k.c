#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "microwave_utilities.h"

#define RAD_TO_DEGREE ((double) 57.2957795131)

main ()
{
POLAR   s11,s12,s21,s22,det_s,s12_s21;
int     correct_bias;
double  k_factor,ma[4],an[4],freq,drain_bias,lowest_k;
char    batch_file_name[81],sp_string[256];
char    string[256],filenames[81],filename[81],out_name[81],bias_str[81];
FILE    *file1,*file2,*batch_file;
time_t  current_t;

printf ("Filename(s)? > ");
scanf ("%s",filenames);

printf ("Drain Voltage Bias? > ");
scanf ("%lf",&drain_bias);

printf ("Summary filename > ");
scanf ("%s",out_name);

sprintf (batch_file_name,"batch_%d",time (&current_t));
sprintf (string,"ls -1 %s > %s",filenames,batch_file_name);
system (string);

sprintf (bias_str,"!BIAS: VDS = %+.5e",drain_bias);

batch_file = fopen (batch_file_name,"r");
file2 = fopen (out_name,"w+");

while (fgets (filename,80,batch_file) != NULL)
   {
   filename[strlen (filename)-1] = '\0';
   
   correct_bias = 0;
   lowest_k = (double) 1.0e5;

   file1 = (FILE *) NULL;
   file1 = fopen (filename,"r");
   if (file1 == (FILE *) NULL)
      {
      printf ("\n** could not open %s ** \n\n",filename);
      continue;
      }

   while (fgets (string,255,file1) != NULL)
      {
      if (!strncmp (string,bias_str,strlen (bias_str)))
         {
         correct_bias = 1;
         continue;
         }
      
      if (correct_bias)
         {      
         if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",&freq,&ma[0],&an[0],&ma[1],&an[1],&ma[2],&an[2],&ma[3],&an[3]) == 9)
            {   
            s11.mag = ma[0];
            s11.ang = an[0];
            s12.mag = ma[2];
            s12.ang = an[2];
            s21.mag = ma[1];
            s21.ang = an[1];
            s22.mag = ma[3];
            s22.ang = an[3];
      
            det_s = polar_sub (polar_mult (s11,s22),polar_mult (s12,s21));         
            s12_s21 = polar_mult (s12,s21);
               
            k_factor = (1-(s11.mag)*(s11.mag)-(s22.mag)*(s22.mag)+(det_s.mag)*(det_s.mag)) / (((double) 2.0)*(s12_s21.mag));
          
            if (k_factor < lowest_k)
               {
               lowest_k = k_factor;
               
               sprintf (sp_string,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.4f\n",freq,ma[0],an[0],
                                ma[1],an[1],ma[2],an[2],ma[3],an[3],k_factor);
               }
            }
         else if (!strncmp (string,"!BIAS:",6))
            {
            correct_bias = 0;
            break;
            }
         }
      }

   fprintf (file2,"%s",sp_string);
   fclose (file1);
   }

fclose (file2);
fclose (batch_file);

sprintf (string,"rm -f %s",batch_file_name);
system (string);
}
