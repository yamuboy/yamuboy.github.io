#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <optimize3.h>
#include <cmplxlib.h>

#define MAX_POINTS   100

static PARAM_STRUCT params[] = {
   {0.0, 2.0, 10.0, 0.0, "NFmin", "", TRUE},
   {0.0, 0.5, 2.0, 0.0, "Rn", "", TRUE},
   {0.0, 0.5, 1.0, 0.0, "Gamma_mag", "", TRUE},
   {0.0, 180.0, 360.0, 0.0, "Gamma_ang", "", TRUE}
   };
static COMPLEX gamma_s[MAX_POINTS];
static double nfig[MAX_POINTS];
static int npoints;

static double *nf_erf (double *p);

int main (int argc, char *argv[])
   {
   char filename[100];
   char string[300];
   double weights = 1.0;
   double nfmin,nfigure;
   FILE *file;
   int i = 0;
   int index,polar_data = 0;
   OPT_STRUCT opt;
   COMPLEX gamma_opt;
   POLAR temp;

   /* parse_command_line */
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-p",2))
         polar_data = 1;
      }

   printf ("File of noise figure data?\n> ");
   fgets (string,299,stdin);
   sscanf (string,"%s",filename);

   /* read in measured noise data and source gamma */

   file = fopen (filename, "r");
   if (!file)
      {
      printf ("Error: could not open file \"%s\".\n",filename);
      return -1;
      }

   i = 0;
   while (fgets (string,299,file))
      {
      if (string[0] == '!')
         continue;

      if (i >= MAX_POINTS)
         {
         printf ("Warning: too many data points in file.\n");
         break;
         }
      
      if (polar_data)
         {
         if (sscanf (string,"%lf%lf%lf",&temp.m,&temp.a,&nfig[i]) == 3)
            {
            gamma_s[i] = P2C (temp);
            ++i;
            }
         }
      else
         {
         if (sscanf (string,"%lf%lf%lf",&gamma_s[i].r,&gamma_s[i].i,&nfig[i]) == 3)
            ++i;
         }
      }

   npoints = i;
   fclose (file);

   /* set the starting values */
   
   nfmin = nfig[0];
   index = 0;
   for (i = 1; i < npoints; ++i)
      {
      if (nfig[i] < nfmin)
         {
         index = i;
         nfmin = nfig[i];
         }
      }

   params[0].nom = pow (10.0, nfig[index]*0.1);
   params[2].nom = sqrt (gamma_s[index].r*gamma_s[index].r + gamma_s[index].i*gamma_s[index].i);
   if ((gamma_s[index].i == 0.0) && (gamma_s[index].r == 0.0))
      params[3].nom = 0.0;
   else
      params[3].nom = atan2 (gamma_s[index].i,gamma_s[index].r) * 180.0 / acos (-1.0);

   /* optimize */

   initialize_optimizer (&opt, 4, 1, &weights, 1000, &nf_erf);

   opt.err_fraction = 1.0e-9;
   
   if (cg_optimize (opt,params) < 0)
      return -1;

   printf ("\n\nGamma (Re, Im)  Nf_meas Nf_mod Error\n");
   printf ("-------------------------------------------\n");

   temp.m = params[2].nom;
   temp.a = params[3].nom;
   gamma_opt = P2C (temp);
   
   for (i = 0; i < npoints; ++i)
      {
      nfigure = params[0].nom + 4.0 * params[1].nom * Cmag2 (Csub (gamma_s[i],gamma_opt)) / 
         ( (1.0 - Cmag2 (gamma_s[i])) * Cmag2 (Cadd (Complex (1.0),gamma_opt)) );

      nfigure = 10*log10 (nfigure);
      
      printf ("(%6.3f,%6.3f)  %5.2f  %5.2f %+5.2f\n",gamma_s[i].r,gamma_s[i].i,nfig[i],nfigure,nfigure-nfig[i]);
      }

   printf ("\n\nGamma_opt (Re, Im) Gamma_opt (Ma < An) Nf_min Rn\n");
   printf ("-----------------------------------------------\n");
   printf ("(%6.3f,%6.3f)  (%6.3f<%6.1f)  %5.3f  %6.3f\n\n\n",gamma_opt.r,gamma_opt.i,
      params[2].nom,params[3].nom,10.0*log10 (params[0].nom),params[1].nom);

   return 0;
   }

/************************************************************************************************/
/************************************************************************************************/

static double *nf_erf (double *p)
   {
   double nfigure;
   double deg2rad = acos (-1.0) / 180.0;
   COMPLEX gamma_opt;
   static double error;
   POLAR temp;
   int i;

   error = 0.0;

   temp.m = p[2];
   temp.a = p[3];
   gamma_opt = P2C (temp);

   for (i = 0; i < npoints; ++i)
      {
      nfigure = p[0] + 4.0 * p[1] * Cmag2 (Csub (gamma_s[i],gamma_opt)) / 
         ( (1.0 - Cmag2 (gamma_s[i])) * Cmag2 (Cadd (Complex (1.0),gamma_opt)) );
         
      nfigure = 10*log10 (nfigure);

      error += (nfigure - nfig[i]) * (nfigure - nfig[i]);
      }

   return &error;
   }

