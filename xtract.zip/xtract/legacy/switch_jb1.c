#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "ss_tools2.h"

#define VER       "1.0"
#define REF_IMP   50.0
#define MAX_S     1000

typedef struct
   {
   double lg,ld,ls;
   double rg,rd,rs;
   double c11,c22;
   double cds;
   } FIXED;

typedef struct
   {
   S_2PORT *s;
   unsigned sz_s;
   FIXED *fixed;
   COMPLEX **y;
   double start,stop;
   } ERF_DATA;

static int read_fixed_params (char *fname, FIXED *f);
static int perform_switch_fit (char *fname, FIXED fixed, FILE *ofile);
static int switch_erf (double *p, void *data, double *error, unsigned n_errs);
static void switch_ss_model (COMPLEX **y, FIXED *f, double freq, double gds, double cg, COMPLEX *s);

// global variables
static int global_write_modeled_s = 1;

/* ------------------------------------------------------------------------------- */

int main (int argc, char *argv[])
   {
   char string[256];
   char fit_files[256];
   char para_file[256];
   char out_file[256];
   char tmp_file[256];
   char fname[256];
   int i;
   FILE *lfile,*ofile;
   FIXED fixed;
   time_t t;

   /* parse the command line */

   for (i = 1; i < argc; ++i);

   /* get user inputs */

   printf ("Files to fit? (Vds=0 only!)\n");
   fgets (fit_files, 255, stdin);
   fit_files[strlen(fit_files)-1] = 0;

   printf ("File of fixed parameter values?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", para_file);

   printf ("Name for output file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", out_file);

   /* read in the fixed parameter values */

   if (read_fixed_params (para_file, &fixed))
      return 1;

   /* generate a listing of files to fit */

   sprintf (tmp_file, "tmp.%ld", time (&t));
   sprintf (string, "rm -f %s", tmp_file);
   system (string);
   sprintf (string, "ls -1 %s > %s", fit_files, tmp_file);
   system (string);

   /* open the output file and listing file */

   ofile = fopen (out_file, "w+");
   if (!ofile)
      {
      printf ("Error: unable to write to disk, check permissions.\n");
      return 1;
      }

   lfile = fopen (tmp_file, "r");
   if (!lfile)
      {
      printf ("Error: unable to get file listing.\n");
      return 1;
      }

   /* write the header in the output file */

   fprintf (ofile, "! --- Fitting Info ---\n");
   fprintf (ofile, "! Date: %s", ctime_r (&t, string));
   fprintf (ofile, "! Path: %s\n", getcwd (string, 256));
   fprintf (ofile, "!\n");
   fprintf (ofile, "! --- Program Info ---\n");
   fprintf (ofile, "! Name: %s\n", argv[0]);
   fprintf (ofile, "! Version: %s\n", VER);
   fprintf (ofile, "! Build Date: %s\n", __DATE__);
   fprintf (ofile, "!\n");
   fprintf (ofile, "! --- Fixed Parameter Values ---\n");
   fprintf (ofile, "! Ld = %.1f pH\n", fixed.ld*1.0e12);
   fprintf (ofile, "! Ls = %.1f pH\n", fixed.ls*1.0e12);
   fprintf (ofile, "! Rd = %.2f Ohms\n", fixed.rd);
   fprintf (ofile, "! Rs = %.2f Ohms\n", fixed.rs);
   fprintf (ofile, "! C11 = %.3f pF\n", fixed.c11*1.0e12);
   fprintf (ofile, "! C22 = %.3f pF\n", fixed.c22*1.0e12);
   fprintf (ofile, "! Cds = %.3f pF\n", fixed.cds*1.0e12);
   fprintf (ofile, "! Rg = %.0f Ohms\n", fixed.rg);
   fprintf (ofile, "! Lg = %.0f pH\n", fixed.lg*1.0e12);
   fprintf (ofile, "!\n");
   fprintf (ofile, "! Vgs\t   Igs\t\t   Gds\t\t   Cgs\n");
   fprintf (ofile, "! (V)\t   (A)\t\t   (S)\t\t   (F)\n");

   /* cycle through the listing file, performing a fit on each file within */

   while (fgets (fname, 255, lfile))
      {
      fname[strlen(fname)-1] = 0;

      perform_switch_fit (fname, fixed, ofile);
      }

   /* delete the listing file */

   sprintf (string, "rm -f %s", tmp_file);
   system (string);

   return 0;
   }

/* ------------------------------------------------------------------------------- */

static int read_fixed_params (char *fname, FIXED *f)
   {
   FILE *file;
   char string[256];
   int err = 0;
   char pname[30];
   double pval;
   unsigned i;
   struct parm_struct {char *name; double *ptr; int found;} parms[] = {
      {"lg", &f->lg, 0},
      {"rg", &f->rg, 0},
      {"ld", &f->ld, 0},
      {"rd", &f->rd, 0},
      {"ls", &f->ls, 0},
      {"rs", &f->rs, 0},
      {"c11", &f->c11, 0},
      {"c22", &f->c22, 0},
      {"cds", &f->cds, 0}
      };
   unsigned sz_parms = sizeof(parms)/sizeof(*parms);

   /* open the file for reading */

   file = fopen (fname, "r");
   if (!file)
      {
      printf ("Error opening file: %s\n", fname);
      return 1;
      }

   /* scan through the file and read in parameter values */

   while (fgets (string, 255, file))
      {
      /* skip comment lines */
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (sscanf (string, "%29s %lf", pname, &pval) == 2)
         {
         pname[29] = 0;

         /* find the parameter in the list */
         for (i = 0; i < sz_parms; ++i)
            {
            if (!strcmp (pname, parms[i].name))
               {
               *(parms[i].ptr) = pval;
               parms[i].found = 1;
               break;
               }
            }
         }
      }

   fclose (file);

   /* check for missing paramters */

   for (i = 0; i < sz_parms; ++i)
      {
      if (!parms[i].found)
         {
         printf ("Error: missing parameter \'%s\' in file - %s\n", parms[i].name, fname);
         err = 1;
         }
      }

   return err;
   }

/* ------------------------------------------------------------------------------- */

static int perform_switch_fit (char *fname, FIXED fixed, FILE *ofile)
   {
   S_2PORT sp[MAX_S];
   S_2PORT si[MAX_S];
   S_BIAS sbias;
   unsigned i, n, k = 0;
   COMPLEX y[4], z[4], s[4];
   double c_sum = 0.0;
   OPT_PARAMETER p[2];
   ERF_DATA erf_data;
   double w, cg, gds;
   int xtr_done = 0;
   OPTIMIZE *opt;
   /*
   char dmb_name[256];
   FILE *fdmb;
   POLAR spolar[4];
   */

   double xtr_freq = 2.0e9;

   printf ("Fitting %s.\n", fname);

   /* read [S] data from the file (function & typedefs imported from ss_tools2.c) */

   n = read_s_from_file (fname, sp, &sbias, MAX_S);
   if (n < 1)
      {
      printf ("Error: %s: no data in file.\n", fname);
      return 1;
      }

   if (fabs (sbias.vds) > 0.05)
      {
      printf ("Error: %s: Vds not equal to 0.\n", fname);
      return 1;
      }

   /* create a file name for the de-embeded data and open the file */

   /*
   sscanf (fname, "%[^.]", dmb_name);
   strcat (dmb_name, ".xxx");

   fdmb = fopen (dmb_name, "w+");
   fprintf (fdmb, "# HZ S MA R 50.0\n");
   */

   /* remove fixed components */

   for (i = 0; i < n; ++i)
      {
      si[i] = sp[i];

      w = 2.0 * acos (-1.0) * sp[i].freq;

      s2y (sp[i].s, y, REF_IMP);
      y[0].i -= fixed.c11 * w;
      y[3].i -= fixed.c22 * w;

      y2z (y, z);
      z[0].r -= fixed.rd + fixed.rg;
      z[0].i -= (fixed.ld + fixed.lg) * w;
      z[1].r -= fixed.rg;
      z[1].i -= fixed.lg * w;
      z[2].r -= fixed.rg;
      z[2].i -= fixed.lg * w;
      z[3].r -= fixed.rs + fixed.rg;
      z[3].i -= (fixed.ls + fixed.lg) * w;

      z2y (z, y);
      y[0].i -= fixed.cds * w;
      y[1].i += fixed.cds * w;
      y[2].i += fixed.cds * w;
      y[3].i -= fixed.cds * w;

      y2s (y, si[i].s, REF_IMP);

      /*
      CA2PA (si[i].s, spolar, 2, 2);
      fprintf (fdmb, "%.4e %.4e %+.4e %.4e %+.4e %.4e %+.4e %.4e %+.4e\n",
         sp[i].freq, spolar[0].m, spolar[0].a, spolar[2].m, spolar[2].a,
         spolar[1].m, spolar[1].a, spolar[3].m, spolar[3].a);
      */
      }

   /*
   fclose (fdmb);
   */


   /* direct extract */

   for (i = 0; i < n; ++i)
      {
      if (si[i].freq >= xtr_freq)
         {
         s2y (si[i].s, y, REF_IMP);
         gds = 0.5 * (y[0].r + y[3].r);
         if (gds < 0.0)
            gds = 0.0;

         cg = 2.0 * 0.5 * (y[0].i + y[3].i) / (2.0 * acos (-1.0) * si[i].freq);
         if (cg < 0.0)
            cg = fabs (cg);

         xtr_done = 1;
         break;
         }
      }

   /* check for valid results */

   if (!xtr_done)
      {
      printf ("Error: %s: invalid extraction frequency.\n", fname);
      return 1;
      }

   // printf ("Gds = %.1f, Cg = %.3f\n", gds*1.0e3, cg*1.0e12);

   /* optimize */
 
   erf_data.s = sp;
   erf_data.sz_s = n;
   erf_data.fixed = &fixed;
   erf_data.y = allocate_2d_complex_matrix (5);
   erf_data.start = 0.0;
   erf_data.stop = 30.0e9;

   p[0].min = p[1].min = 0.0;
   p[0].tol = p[1].tol = 0.0;
   p[0].optimize = p[1].optimize = TRUE;
      
   p[0].nom = gds;
   p[0].max = 3.0*gds;
   strcpy (p[0].name, "Gds");
   p[1].nom = cg;
   p[1].max = 3.0*cg;
   strcpy (p[1].name, "Cg");

   opt = initialize_cg_optimizer ();   
   set_cg_parameters (opt, p, 2);
   set_cg_error_function (opt, switch_erf, &erf_data, 2, NULL);
   set_cg_error_fraction (opt, 1.0e-15, 10);
   // set_cg_flags (opt, OPT_VERBOSE);

   if (cg_optimize4 (opt, 1000, NULL))
      {
      printf ("Error: %s: cg_optimize4(): %s\n", fname, get_cg_error());
      free ((void *) opt);
      return 1;
      }

   free ((void *) opt);

   /* write results to file */

   fprintf (ofile, "%.3f\t%.3e\t%.3e\t%.3e\n", sbias.vgs, sbias.igs, p[0].nom, p[1].nom);

   /* write S-parameter results to file */

   if (global_write_modeled_s)
      {
      FILE *f;
      char sp_name[256];
      COMPLEX s[4];
      POLAR s_p[4];

      sscanf (fname, "%[^.]", sp_name);
      strcat (sp_name, ".mod");

      f = fopen (sp_name, "w+");
      fprintf (f, "# HZ S MA R 50.0\n");

      for (i = 0; i < n; ++i)
         {
         switch_ss_model (erf_data.y, &fixed, sp[i].freq, p[0].nom, p[1].nom, s);
         CA2PA (s, s_p, 2, 2);
         fprintf (f, "%.4e %.4e %+.4e %.4e %+.4e %.4e %+.4e %.4e %+.4e\n", sp[i].freq, s_p[0].m, s_p[0].a,
            s_p[2].m, s_p[2].a, s_p[1].m, s_p[1].a, s_p[3].m, s_p[3].a);
         }

      fclose (f);
      }




   return 0;
   }

/* ------------------------------------------------------------------------------- */

static int switch_erf (double *p, void *data, double *error, unsigned n_errs)
   {
   ERF_DATA *d = (ERF_DATA *) data;
   FIXED *f = d->fixed;
   COMPLEX **y = d->y;
   S_2PORT *sp = d->s;
   double gds = p[0];
   double cg = p[1];
   unsigned i, n = 0;
   COMPLEX s[4];

   if (n_errs != 2)
      return 1;

   for (i = 0; i < d->sz_s; ++i)
      {
      if ((sp[i].freq < d->start) || (sp[i].freq > d->stop))
         continue;

      switch_ss_model (y, f, sp[i].freq, gds, cg, s);

      error[0] += Cmag2 (Csub (s[0], sp[i].s[0]));
      error[1] += Cmag2 (Csub (s[2], sp[i].s[2]));

      /* calculate errors in the [Y] domain, only use Y11 and Y21 since model is symmetric */

      /*
      s2y (sp[i].s, yr, REF_IMP);

      error[0] += Cmag2 (Csub (y[0][0], yr[0]));
      error[1] += Cmag2 (Csub (y[1][0], yr[3]));
      */

      ++n;
      }

   if (!n)
      return 1;

   error[0] /= (double) n;
   error[1] /= (double) n;

   return 0;
   }

/* ------------------------------------------------------------------------------- */

static void switch_ss_model (COMPLEX **y, FIXED *f, double freq, double gds, double cg, COMPLEX *s)
   {
   static const COMPLEX zero = {0.0, 0.0};
   static const COMPLEX one = {1.0, 0.0};
   COMPLEX rd_ld, rs_ls, rg_lg, yr[4];
   unsigned j, k;
   double w = 2.0 * acos (-1.0) * freq;

   /* zero the Y matrix */

   for (j = 0; j < 5; ++j)
      {
      for (k = 0; k < 5; ++k)
         y[j][k] = zero;
      }

   /* build the Y matrix */

   rd_ld = Cdiv (one, Cnum (f->rd, w * f->ld));
   rs_ls = Cdiv (one, Cnum (f->rs, w * f->ls));
   rg_lg = Cdiv (one, Cnum (f->rg, w * f->lg));

   y[0][0].r = rd_ld.r;
   y[0][0].i = rd_ld.i + w*f->c11;

   y[0][2] = Csub (zero, rd_ld);

   y[1][1].r = rs_ls.r;
   y[1][1].i = rs_ls.i + w*f->c22;

   y[1][3] = Csub (zero, rs_ls);

   y[2][0] = Csub (zero, rd_ld);

   y[2][2].r = rd_ld.r + gds;
   y[2][2].i = rd_ld.i + w*f->cds + w*cg;

   y[2][3].r = -gds;
   y[2][3].i = -w*f->cds;

   y[2][4].i = -w*cg;

   y[3][1] = Csub (zero, rs_ls);

   y[3][2].r = -gds;
   y[3][2].i = -w*f->cds;

   y[3][3].r = rs_ls.r + gds;
   y[3][3].i = rs_ls.i + w*f->cds + w*cg;

   y[3][4].i = -w*cg;

   y[4][2].i = -w*cg;

   y[4][3].i = -w*cg;

   y[4][4].r = rg_lg.r;
   y[4][4].i = rg_lg.i + 2.0*w*cg;

   /* reduce the Y matrix */

   complex_matrix_reduction (y, 5, 2);

   /* convert back to S params */

   yr[0] = y[0][0];
   yr[1] = y[0][1];
   yr[2] = y[1][0];
   yr[3] = y[1][1];

   y2s (yr, s, REF_IMP);
   }













