#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <optimize3.h>
#include <cmplxlib.h>
#include <jplot.h>

#define MAX_CAP_PTS   30
#define NUM_PARAMS    6

#define EXTRACT_CBC   1
#define EXTRACT_CBE   2

/* Global Variables */

double vcbe[MAX_CAP_PTS];
double vcbc[MAX_CAP_PTS];
double cbem[MAX_CAP_PTS];
double cbcm[MAX_CAP_PTS];
double cce_cbc,cce_cbe;
int num_cbe_pts,num_cbc_pts;
PARAM_STRUCT params[NUM_PARAMS];
char header_file[200];
double rb,rc,re;
double lb,lc,le;

/* Function Prototypes */

static int extract_capacitance (char files[], double fstart, double fstop, int mode);   
static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2);
static void linefit_mx0 (double *x, double *y, int n, double *m, double *r2);
static int plot_data (char *fname, int device);
double *cbc_erf (double *p);
double *cbe_erf (double *p);
static double junction_cap (double v, double cj, double pj, double mj);
   
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

main (int argc, char *argv[])
   {
   char cbc_files[256];
   char cbe_files[256];
   char string[256];
   double fmin,fmax;
   double weights[1];
   int i;
   int device = X_WINDOWS;
   OPT_STRUCT opt;
   
   for (i = 1; i < argc; ++i)
      {
      if (!strcmp (argv[i],"-post"))
         device = POSTSCRIPT;
      else if (!strcmp (argv[i],"-wmf"))
         device = METAFILE;
      }
   
   printf ("B-C junction capacitance extraction files?\n");
   fgets (cbc_files,255,stdin);
   cbc_files[strlen(cbc_files)-1] = 0;

   printf ("B-E junction capacitance extraction files?\n");
   fgets (cbe_files,255,stdin);
   cbe_files[strlen(cbe_files)-1] = 0;
   
   printf ("Minimum and Maximum Frequencies for extraction (in GHz)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf",&fmin,&fmax);
   fmin *= 1.0e9;
   fmax *= 1.0e9;

   printf ("Port Resistances in ohms (Rb Rc Re)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf%lf",&rb,&rc,&re);

   printf ("Port Inductances in pH (Lb Lc Le)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf%lf",&lb,&lc,&le);
   lb *= 1.0e-12;
   lc *= 1.0e-12;
   le *= 1.0e-12;
   
   printf ("Starting values for Pc and Pe?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf",&params[1].nom,&params[4].nom);

   printf ("Starting values for Mc and Me?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf",&params[2].nom,&params[5].nom);

   initialize_optimizer (&opt, NUM_PARAMS, 1, weights, 1000, &cbc_erf);
   weights[0] = 1.0;
   opt.err_fraction = 1.0e-9;   

   printf ("Fitting Base-Collector Capacitance.....\n");
      
   if (extract_capacitance (cbc_files,fmin,fmax,EXTRACT_CBC))
      {
      printf ("ERROR: extract_capacitance() failed.\n");
      return -1;
      }
      
   params[1].min = params[1].nom*0.75;
   params[1].max = params[1].nom*1.25;
   params[1].optimize = TRUE;
   params[2].min = params[2].nom*0.75;
   params[2].max = params[2].nom*1.25;
   params[2].optimize = TRUE;


   opt.function = &cbc_erf;
      
   if (cg_optimize (opt,params) < 0)
      printf ("ERROR in cg_optimize().\n");
      
   params[1].optimize = FALSE;
   params[2].optimize = FALSE;
      
   printf ("Fitting Base-Emitter Capacitance.....\n");
      
   if (extract_capacitance (cbe_files,fmin,fmax,EXTRACT_CBE))
      {
      printf ("ERROR: extract_capacitance() failed.\n");
      return -1;
      }

   params[4].min = params[4].nom*0.75;
   params[4].max = params[4].nom*1.25;
   params[4].optimize = TRUE;
   params[5].min = params[5].nom*0.75;
   params[5].max = params[5].nom*1.25;
   params[5].optimize = TRUE;      
      
   opt.function = &cbe_erf;
      
   if (cg_optimize (opt,params) < 0)
      printf ("ERROR in cg_optimize().\n");
      
   params[4].optimize = FALSE;
   params[5].optimize = FALSE;

   plot_data (header_file, device);
   
   return 0;
   }
   
/*******************************************************************************************/
/*******************************************************************************************/

static int extract_capacitance (char files[], double fstart, double fstop, int mode)
   {
#define MAX_FREQS 500
   char    tmp_file_name[100],string[200];
   time_t  dummy;
   FILE    *file_list,*infile;
   int     i,j,found,is_zb,zb_done;
   double  c1[MAX_FREQS],w[MAX_FREQS],cc[MAX_FREQS];
   COMPLEX sr[4],z[4],y[4];
   POLAR   s[4];
   double  vce,ice,vbe,ibe,freq,r2,tmp,cc_ave;

   sprintf (tmp_file_name,"tmpfile.%d",time(&dummy));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string,"ls -1 %s > %s",files,tmp_file_name);
   system (string);

   file_list = fopen (tmp_file_name,"r");
   if (!file_list)
      {
      sprintf (string,"rm -f %s",tmp_file_name);
      system (string);
      return -1;
      }

   i = 0;
   cc_ave = 0.0;
   zb_done = 0;
   while (fgets(string,100,file_list))
      {
      if (i >= MAX_CAP_PTS)
         {
         printf ("WARNING: too many capacitance files.\n");
         break;
         }

      string[strlen(string)-1] = 0;
      infile = fopen (string,"r");
      if (!infile)
         continue;

      if (!i)
         strcpy (header_file,string);
      
      j = 0;
      found = 0;
      is_zb = 0;
      while (fgets(string,199,infile))
         {
         if (!strncmp(string,"!BIAS",5))
            {
            if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&vce,&ice,&vbe,&ibe) == 4)
               {
               found = 1;
               if (mode == EXTRACT_CBC)
                  {
                  vcbc[i] = (vbe - rb*ibe) - (vce - rc*ice);
                  if (fabs(vbe - vce) < 0.05)
                     is_zb = 1;
                  }
               else if (mode == EXTRACT_CBE)
                  {
                  vcbe[i] = vbe - (ibe+ice)*re - ibe*rb;
                  if (fabs(vbe) < 0.05)
                     is_zb = 1;
                  }
               }
            }
         else if (string[0] == '!')
            continue;

         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].m,&s[0].a,&s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
            {
            if (freq < fstart)
               continue;
            else if (freq > fstop)
               break;

            if (j >= MAX_FREQS)
               {
               printf ("WARNING: too many frequency points in range.\n");
               break;
               }

            s2z (PA2CA (s,sr,2,2),z,50.0);
            w[j] = 2.0*PI*freq;

            z[0] = Csubx (3,z[0],Complex(rb+rc),Cnum(0.0,w[j]*(lb+lc)));
            z[1] = Csubx (3,z[1],Complex(re),Cnum(0.0,w[j]*le));
            z[2] = Csubx (3,z[2],Complex(re),Cnum(0.0,w[j]*le));
            z[3] = Csubx (3,z[3],Complex(rb+rc),Cnum(0.0,w[j]*(lb+lc)));

            z2y (z,y);

            if (mode == EXTRACT_CBE)
               {
               c1[j] = Cimag (Cadd(y[0],Cmult(Cadd(y[1],y[2]),Complex(0.5))));
               cc[j] = Cimag (Cadd(y[3],Cmult(Cadd(y[1],y[2]),Complex(0.5))));
               ++j;
               }
            else if (mode == EXTRACT_CBC)
               {
               c1[j] = -Cimag (Cmult(Cadd(y[1],y[2]),Complex(0.5)));
               cc[j] = Cimag (Cadd(y[3],Cmult(Cadd(y[1],y[2]),Complex(0.5))));
               ++j;
               }
            }
         }

      if (j < 2)
         {
         printf ("WARNING: too few frequency points in range.\n");
         fclose (infile);
         continue;
         }

      if (!found)
         {
         printf ("WARNING: BIAS line not found.\n");
         fclose (infile);
         continue;
         }

      if (mode == EXTRACT_CBE)
         {
         linefit_mx0 (w,c1,j,&cbem[i],&r2);
         linefit_mx0 (w,cc,j,&tmp,&r2);
         cc_ave += tmp;
         
         if (is_zb)
            {
            params[3].nom = params[3].min = params[3].max = cbem[i];
            zb_done = 1;
            }
         }
      else if (mode == EXTRACT_CBC)
         {
         linefit_mx0 (w,c1,j,&cbcm[i],&r2);
         linefit_mx0 (w,cc,j,&tmp,&r2);
         cc_ave += tmp;

         if (is_zb)
            {
            params[0].nom = params[0].min = params[0].max = cbcm[i];
            zb_done = 1;
            }
         }

      fclose (infile);
      ++i;
      }

   if (mode == EXTRACT_CBE)
      {
      num_cbe_pts = i;
      for (i = 0; i < (num_cbe_pts-1); ++i)
         {
         for (j = i; j < num_cbe_pts; ++j)
            {
            if (vcbe[i] > vcbe[j])
               {
               tmp = vcbe[i];
               vcbe[i] = vcbe[j];
               vcbe[j] = tmp;
               
               tmp = cbem[i];
               cbem[i] = cbem[j];
               cbem[j] = tmp;
               }
            }
         }
      cce_cbe = cc_ave/((double) num_cbe_pts);
      }
   else if (mode == EXTRACT_CBC)
      {
      num_cbc_pts = i;
      for (i = 0; i < (num_cbc_pts-1); ++i)
         {
         for (j = i; j < num_cbc_pts; ++j)
            {
            if (vcbc[i] > vcbc[j])
               {
               tmp = vcbc[i];
               vcbc[i] = vcbc[j];
               vcbc[j] = tmp;
               
               tmp = cbcm[i];
               cbcm[i] = cbcm[j];
               cbcm[j] = tmp;
               }
            }
         }
      cce_cbc = cc_ave/((double) num_cbc_pts);
      }
   
   fclose (file_list);
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);

   if (!zb_done)
      {
      printf ("ERROR: no zero-bias file found.\n");
      return 1;
      }

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

double *cbc_erf (double *p)
   {
   int i;
   double cap,factor;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_cbc_pts; ++i)
      {
      factor = cbcm[0]/cbcm[i];
      cap = junction_cap (vcbc[i],p[0],p[1],p[2]);
      error += (cap-cbcm[i])*(cap-cbcm[i])*factor*factor*1.0e24;
      }
   
   error /= ((double) num_cbc_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *cbe_erf (double *p)
   {
   int i;
   double cap,factor;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_cbe_pts; ++i)
      {
      factor = cbem[0]/cbem[i];
      cap = junction_cap (vcbe[i],p[3],p[4],p[5]);
      error += (cap-cbem[i])*(cap-cbem[i])*factor*factor*1.0e24;
      }
   
   error /= ((double) num_cbe_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static double junction_cap (double v, double cj, double pj, double mj)
   {
   double vtmp = 1.0 - v/pj;

   if (vtmp < 1.0e-2)
      vtmp = 1.0e-2;

   return cj/pow (vtmp,mj);
   }

/*******************************************************************************************/
/*******************************************************************************************/

static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2)
   {
   int i;
   double xsum = 0.0;
   double ysum = 0.0;
   double xxsum = 0.0;
   double yysum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 1)
      {
      *m = 0.0;
      *b = 0.0;
      *r2 = 0.0;
      return;
      }

   for (i = 0; i < n; ++i)
      {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
      }

   *m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
   *b  = (xxsum*ysum - xysum*xsum) / (xxsum*((double) n) - xsum*xsum);
   // *r2 = xysum*xysum / (xxsum*yysum);

   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] + (*b) - y[i])*((*m)*x[i] + (*b) - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mx0 (double *x, double *y, int n, double *m, double *r2)
   {
   int i;
   double ysum = 0.0;
   double xxsum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   for (i = 0; i < n; ++i)
      {
      ysum  += y[i];
      xxsum += x[i]*x[i];
      xysum += x[i]*y[i];
      }

   *m = xysum / xxsum;
   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] - y[i])*((*m)*x[i] - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }
   
/*******************************************************************************************/
/*******************************************************************************************/

static int plot_data (char *fname, int device)
   {
   jPLOT_ITEM      *plot1;
   int             i,j,n;
   char            string[200],head[1000];
   double          x1data[MAX_CAP_PTS];
   double          y1data[MAX_CAP_PTS];
   double          y2data[MAX_CAP_PTS];
   static char     *legend_t[] = {"Modeled","Measured"};
   static int      legend_l2[] = {LT_SOLID,PNT_CIRCLE};
   static int      legend_w2[] = {1,2};
   static int      legend_c[] = {CLR_RED,CLR_BLUE};
   jHANDLE         txt1,legend1,header;
   FILE            *infile;

   if (!open_graphics_device (device,NULL))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }
      
   head[0] = 0;
   infile = fopen (fname,"r");
   while (fgets(string,199,infile))
      {
      if (!strncmp(string,"!FILE",4))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!MASK",4))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!WAFER",5))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!DEVICE",7))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!EMITTER AREA",13))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!TEMP",5))
         strcat(head,&string[1]);
      else if (string[0] != '!')
         break;
      }
   fclose (infile);

   plot1 = create_plot_item (SingleY,1.75,1.25,6.0,5.0);
   plot1->attribs.title_offset = 0.3;
   header = add_text (head,4.75,7.8,FNT_COURIER,12,0.0,CENTER_JUSTIFY,CLR_BLACK,0);

   legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l2,legend_w2,legend_c);

   /**** Cbc ****/
      
   for (i = 0; i < num_cbc_pts; ++i)
      {
      x1data[i] = vcbc[i];
      y1data[i] = cbcm[i]*1.0e12;
      y2data[i] = junction_cap (vcbc[i],params[0].nom,params[1].nom,params[2].nom)*1.0e12;
      }
      
   attach_y1data (plot1,x1data,y1data,num_cbc_pts,PNT_CIRCLE,1,CLR_BLUE);
   attach_y1data (plot1,x1data,y2data,num_cbc_pts,LT_SOLID,1,CLR_RED);
      
   set_axis_labels (plot1,"Vbc (volts)","Cbc (pF)","","Base-Collector Capacitance");

   sprintf (string,"Cjc = %.3e\nPc  = %.3f\nMc  = %.2f\n\nCce = %.3e",params[0].nom,
      params[1].nom,params[2].nom,cce_cbc);
   txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
   if (!draw_page ())
      {
      close_graphics_device ();
      return -1;
      }   
      
   remove_user_item (txt1);
   detach_data (plot1);   
      
   /**** Cbe ****/
      
   for (i = 0; i < num_cbe_pts; ++i)
      {
      x1data[i] = vcbe[i];
      y1data[i] = cbem[i]*1.0e12;
      y2data[i] = junction_cap (vcbe[i],params[3].nom,params[4].nom,params[5].nom)*1.0e12;
      }
      
   attach_y1data (plot1,x1data,y1data,num_cbe_pts,PNT_CIRCLE,1,CLR_BLUE);
   attach_y1data (plot1,x1data,y2data,num_cbe_pts,LT_SOLID,1,CLR_RED);
      
   set_axis_labels (plot1,"Vbe (volts)","Cbe (pF)","","Base-Emitter Capacitance");
      
   sprintf (string,"Cje = %.3e\nPe  = %.3f\nMe  = %.2f\n\nCce = %.3e",params[3].nom,
      params[4].nom,params[5].nom,cce_cbe);
   txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
   if (!draw_page ())
      {
      close_graphics_device ();
      return -1;
      }   

   close_graphics_device ();
   
   return 0;
   }   
