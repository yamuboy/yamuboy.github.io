#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "jplot.h"
#include "fit_tools.h"
#include "ss_tools2.h"

#define MAX_PTS   500
#define MAX_FILES  1000

struct BIAS
{
   double vds,ids,vgs,igs;
   int mode;
};

struct FET_Model {
    double c1, c2, c11, c22;
    double b1, b2, ls;
    double rg, rd, rs;
    double cgs, cdg, cds, ri;
    double gm, tau, gds, tau2;
    double ggs, gdg;
};

int read_end_file( const char* name, struct FET_Model* m );
void build_model( const struct FET_Model* p, int pts, const double* flist, double* mod11m, double* mod11a,
    double* mod12m, double* mod12a, double* mod21m, double* mod21a, double* mod22m, double* mod22a, int db_mode );
int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts, int dbret);
double satan2 (double y, double x);

void print_usage( char * progname )
{
   printf( "\nUSAGE: %s [options] file1 [file2 ...]\n\n", progname );
   printf( "  file1 [file2 ...] are the .end files.\n\n" );
   printf( "  Options:\n" );
   printf( "     -wmf, -meta   Set output device to metafile.\n" );
   printf( "     -ps           Set output device to postscript.\n" );
   printf( "     -o name       Set plot file name to \'name\'.\n" );
   printf( "     -db           Plot in dB.\n" );
   printf( "     -np           Disable plotting of phase on the Y2 axis.\n" );
   printf( "     -ext=xx       Set the extension for measured S2P files.\n" );

   printf( "\n" );
}

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
{
   FILE *measfile;
   char string[256];
   char endname[100],measname[100];
   char extension[40];
   char pname[100];
   char *file_list[MAX_FILES];
   jPLOT_ITEM *s11p,*s12p,*s21p,*s22p;
   jPLOT_ATTRIBS attribs1;
   jHANDLE legend1,bias_line;
   int meas_pts,i;
   double measfreq[MAX_PTS];
   double mod11m[MAX_PTS],mod11a[MAX_PTS];
   double mod12m[MAX_PTS],mod12a[MAX_PTS];
   double mod21m[MAX_PTS],mod21a[MAX_PTS];
   double mod22m[MAX_PTS],mod22a[MAX_PTS];
   double meas11m[MAX_PTS],meas11a[MAX_PTS];
   double meas12m[MAX_PTS],meas12a[MAX_PTS];
   double meas21m[MAX_PTS],meas21a[MAX_PTS];
   double meas22m[MAX_PTS],meas22a[MAX_PTS];
   struct BIAS bias;
   static char *legend_t[] = {"Modeled Magnitude","Measured Magnitude","Modeled Phase","Measured Phase"};
   static int  legend_l[] = {LT_SOLID,LT_DASHED,LT_SOLID,LT_DASHED};
   static int  legend_w[] = {1,1,1,1};
   static int  legend_c[] = {CLR_RED,CLR_BLUE,CLR_ORANGE,CLR_GREEN};
   int pdevice = X_WINDOWS;
   int fcount = 0;
   int db_mode=0;
   struct FET_Model model;

   strcpy(pname,"modver.ps");
   strcpy(extension,".dmb");

   if( argc < 2 ) {
      print_usage(argv[0]);
      exit(0);
   }

   // parse the command line
   for (i = 1; i < argc; ++i)
   {
      if( argv[i][0] == '-' ) {
         if( !strcmp(argv[i],"-ps") || !strcmp(argv[i],"-dP") ) pdevice = POSTSCRIPT;
         else if( !strcmp(argv[i],"-meta") || !strcmp(argv[i],"-wmf") || !strcmp(argv[i],"-dM") ) pdevice = METAFILE;
         else if( !strcmp(argv[i],"-db") || !strcmp(argv[i],"-dB") ) db_mode=1;
         else if( !strcmp(argv[i],"-o") ) {
            if( i == argc-1 ) {
               fprintf( stderr, "Error: missing parameter for -o option.\n" );
               print_usage( argv[0] );
               exit(1);
            }
            strcpy(pname,argv[++i]);
         }
         else if( !strncmp(argv[i],"--ext=",6) ) {
            strcpy( extension, &argv[i][6] );
         }
         else if( !strncmp(argv[i],"-ext=",5) ) {
            strcpy( extension, &argv[i][5] );
         }
         else {
            fprintf( stderr, "Error: invalid option: %s\n", argv[i] );
            print_usage( argv[0] );
            exit(1);
         }
      }
      else {
         if( fcount >= MAX_FILES ) {
            fprintf( stderr, "Warning: MAX_FILES exceeded.\n" );
            continue;
         }
         file_list[fcount++] = argv[i];
      }
   }

   if( !fcount ) {
      fprintf( stderr, "Error: no files to plot.\n" );
      print_usage( argv[0] );
      exit(1);
   }

   if (!open_graphics_device (pdevice,pname)) {
      fprintf (stderr, "Failed to open the graphics device.\n");
      return -1;
   }

   s11p = create_plot_item (DoubleY,1.25,4.70,3.0,2.5);
   s12p = create_plot_item (DoubleY,6.75,4.70,3.0,2.5);
   s21p = create_plot_item (DoubleY,1.25,1.00,3.0,2.5);
   s22p = create_plot_item (DoubleY,6.75,1.00,3.0,2.5);

   if( db_mode ) {
      set_axis_labels (s11p,"Frequency (GHz)","dB(S11)","phase(S11)","S11");
      set_axis_labels (s12p,"Frequency (GHz)","dB(S12)","phase(S12)","S12");
      set_axis_labels (s21p,"Frequency (GHz)","dB(S21)","phase(S21)","S21");
      set_axis_labels (s22p,"Frequency (GHz)","dB(S22)","phase(S22)","S22");
   }
   else {
      set_axis_labels (s11p,"Frequency (GHz)","mag(S11)","phase(S11)","S11");
      set_axis_labels (s12p,"Frequency (GHz)","mag(S12)","phase(S12)","S12");
      set_axis_labels (s21p,"Frequency (GHz)","mag(S21)","phase(S21)","S21");
      set_axis_labels (s22p,"Frequency (GHz)","mag(S22)","phase(S22)","S22");
   }

   attribs1.xlabel_offset = 0.3;
   attribs1.ylabel_offset = 0.55;
   attribs1.title_offset  = 0.3;

   set_plot_item_attributes (s11p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s12p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s21p,&attribs1,JPA_LABELOFFSETS);
   set_plot_item_attributes (s22p,&attribs1,JPA_LABELOFFSETS);

   legend1 = add_legend (4,4.55,8.1,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);

   for( i=0; i<fcount; ++i )
   {
      strcpy(endname,file_list[i]);
      strcpy(measname,file_list[i]);
      strip_extension(measname);
      strcat(measname,extension);

      if( read_end_file(endname,&model) ) continue;
      measfile = fopen(measname,"r");
      if( !measfile ) continue;
      meas_pts = read_s_params (measfile,measfreq,meas11m,meas11a,meas12m,meas12a,meas21m,meas21a,meas22m,meas22a,&bias,MAX_PTS,db_mode);
      fclose (measfile);
      if( ! meas_pts ) continue;

      // build the modeled data
      build_model( &model, meas_pts, measfreq, mod11m, mod11a, mod12m, mod12a, mod21m, mod21a, mod22m, mod22a, db_mode );

      // bias line header
      if (bias.mode == 1)
         sprintf (string," Vds    Ids     Vgs    Igs \n (V)    (mA)    (V)    (mA)\n%5.1f  %6.1f  %6.3f  %5.3f",
         bias.vds,bias.ids*1.0e3,bias.vgs,bias.igs*1.0e3);
      else if (bias.mode == 2)
         sprintf (string," Vce    Ice     Vbe    Ibe \n (V)    (mA)    (V)    (mA)\n%5.1f  %6.1f  %6.3f  %5.3f",
         bias.vds,bias.ids*1.0e3,bias.vgs,bias.igs*1.0e3);
      else
         sprintf (string," Vds    Ids     Vgs    Igs \n (V)    (mA)    (V)    (mA)\n%5.1f  %6.1f  %6.3f  %5.3f",
         0.0,0.0,0.0,0.0);
      bias_line = add_text (string,5.5,4.15,FNT_COURIER,12,0.0,CENTER_JUSTIFY,CLR_BLACK,0);

      attach_y1data (s11p,measfreq,mod11m,meas_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s11p,measfreq,meas11m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s11p,measfreq,mod11a,meas_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s11p,measfreq,meas11a,meas_pts,LT_DASHED,1,CLR_GREEN);

      attach_y1data (s12p,measfreq,mod12m,meas_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s12p,measfreq,meas12m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s12p,measfreq,mod12a,meas_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s12p,measfreq,meas12a,meas_pts,LT_DASHED,1,CLR_GREEN);

      attach_y1data (s21p,measfreq,mod21m,meas_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s21p,measfreq,meas21m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s21p,measfreq,mod21a,meas_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s21p,measfreq,meas21a,meas_pts,LT_DASHED,1,CLR_GREEN);

      attach_y1data (s22p,measfreq,mod22m,meas_pts,LT_SOLID,1,CLR_RED);
      attach_y1data (s22p,measfreq,meas22m,meas_pts,LT_DASHED,1,CLR_BLUE);
      attach_y2data (s22p,measfreq,mod22a,meas_pts,LT_SOLID,1,CLR_ORANGE);
      attach_y2data (s22p,measfreq,meas22a,meas_pts,LT_DASHED,1,CLR_GREEN);

      draw_page ();

      detach_data (s11p);
      detach_data (s12p);
      detach_data (s21p);
      detach_data (s22p);
      remove_user_item (bias_line);

   }

   close_graphics_device ();

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

void str2lowercase( char * str )
{
   if( str ) {
      int i;
      int l = strlen(str);
      for( i=0; i<l; ++i ) {
         if( str[i] >= 'A' && str[i] <= 'Z' ) str[i] += (char) ('a' - 'A');
      }
   }
}

/*********************************************************************************************/
/*********************************************************************************************/

int read_s_params (FILE *infile, double *freq, double *s11m, double *s11a, double *s12m, double *s12a, double *s21m,
                   double *s21a, double *s22m, double *s22a, struct BIAS *bias, int max_pts, int dbret)
{
   char string[256],tmp[6];
   int i = 0;
   int ri_mode = 0;
   int db_mode = 0;
   double fscale = 1.0e-9;
   double rad_to_deg = 180.0/acos(-1.0);
   double dtmp;

   bias->mode = 0;
   while (fgets(string,255,infile))
   {
      if (i >= max_pts)
         break;

      if (!strncmp (string,"!BIAS",5))
      {
         if (sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",&bias->vds,&bias->ids,
            &bias->vgs,&bias->igs) == 4)
            bias->mode = 1;
         else if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&bias->vds,&bias->ids,
            &bias->vgs,&bias->igs) == 4)
            bias->mode = 2;
         else
            bias->mode = 0;
      }
      else if (string[0] == '!')
         continue;

      if (sscanf(string,"# %5s %5s",tmp,tmp) == 2)
      {
         str2lowercase( string );
         if (strstr(string,"ri"))
            ri_mode = 1;
         else if (strstr(string,"db"))
            db_mode = 1;

         if (strstr(string,"ghz"))
            fscale = 1.0;
         else if (strstr(string,"mhz"))
            fscale = 1.0e-3;
         else if (strstr(string,"khz"))
            fscale = 1.0e-6;
      }

      if (sscanf(string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq[i],&s11m[i],&s11a[i],&s21m[i],&s21a[i],&s12m[i],&s12a[i],
         &s22m[i],&s22a[i]) == 9)
      {
         freq[i] *= fscale;

         if (ri_mode) {
            dtmp = s11m[i];
            s11m[i] = sqrt (s11m[i]*s11m[i] + s11a[i]*s11a[i]);
            s11a[i] = rad_to_deg*satan2 (s11a[i],dtmp);

            dtmp = s12m[i];
            s12m[i] = sqrt (s12m[i]*s12m[i] + s12a[i]*s12a[i]);
            s12a[i] = rad_to_deg*satan2 (s12a[i],dtmp);

            dtmp = s21m[i];
            s21m[i] = sqrt (s21m[i]*s21m[i] + s21a[i]*s21a[i]);
            s21a[i] = rad_to_deg*satan2 (s21a[i],dtmp);

            dtmp = s22m[i];
            s22m[i] = sqrt (s22m[i]*s22m[i] + s22a[i]*s22a[i]);
            s22a[i] = rad_to_deg*satan2 (s22a[i],dtmp);

            if( dbret ) {
               s11m[i] = 20. * log10(s11m[i]);
               s12m[i] = 20. * log10(s12m[i]);
               s21m[i] = 20. * log10(s21m[i]);
               s22m[i] = 20. * log10(s22m[i]);
            }
         }
         else if( db_mode ) {
            if( !dbret ) {
               s11m[i] = pow( 10., 0.05*s11m[i] );
               s12m[i] = pow( 10., 0.05*s12m[i] );
               s21m[i] = pow( 10., 0.05*s21m[i] );
               s22m[i] = pow( 10., 0.05*s22m[i] );
            }
         }
         else {
            if( dbret ) {
               s11m[i] = 20. * log10(s11m[i]);
               s12m[i] = 20. * log10(s12m[i]);
               s21m[i] = 20. * log10(s21m[i]);
               s22m[i] = 20. * log10(s22m[i]);
            }
         }

         ++i;
      }
   }

   return i;
}

/*********************************************************************************************/
/*********************************************************************************************/

double satan2 (double y, double x)
{
   if ((x == 0.0) && (y == 0.0))
      return 0.0;
   else
      return atan2(y,x);
}

/*********************************************************************************************/
/*********************************************************************************************/

int read_end_file( const char* name, struct FET_Model* m )
{
    MODEL_PARAMS *params;
    OPT_PARAMETER opt;

    if( read_model_parameters_from_file( name, &params, NULL ) ) return 1;
    get_parameter_value( "C1", params, &opt ); m->c1 = opt.nom;
    get_parameter_value( "C2", params, &opt ); m->c2 = opt.nom;
    get_parameter_value( "C11", params, &opt ); m->c11 = opt.nom;
    get_parameter_value( "C22", params, &opt ); m->c22 = opt.nom;
    get_parameter_value( "B1", params, &opt ); m->b1 = opt.nom;
    get_parameter_value( "B2", params, &opt ); m->b2 = opt.nom;
    get_parameter_value( "LS", params, &opt ); m->ls = opt.nom;
    get_parameter_value( "RG", params, &opt ); m->rg = opt.nom;
    get_parameter_value( "RD", params, &opt ); m->rd = opt.nom;
    get_parameter_value( "RS", params, &opt ); m->rs = opt.nom;
    get_parameter_value( "CGS", params, &opt ); m->cgs = opt.nom;
    get_parameter_value( "CDG", params, &opt ); m->cdg = opt.nom;
    get_parameter_value( "CDS", params, &opt ); m->cds = opt.nom;
    get_parameter_value( "RI", params, &opt ); m->ri = opt.nom;
    get_parameter_value( "GM", params, &opt ); m->gm = opt.nom;
    get_parameter_value( "GDS", params, &opt ); m->gds = opt.nom;
    get_parameter_value( "GGS", params, &opt ); m->ggs = opt.nom;
    get_parameter_value( "GDG", params, &opt ); m->gdg = opt.nom;
    get_parameter_value( "TAU", params, &opt ); m->tau = opt.nom;
    get_parameter_value( "TAU2", params, &opt ); m->tau2 = opt.nom;

    free_model_parameters( params );
    return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

void build_model( const struct FET_Model* p, int pts, const double* flist, double* mod11m, double* mod11a,
    double* mod12m, double* mod12a, double* mod21m, double* mod21a, double* mod22m, double* mod22a, int db_mode )
{
    NETLIST *netlist[20], *nlist;
    COMPLEX s[4];
    POLAR spolar[4];
    int i;

/*
    printf( "--------------------------------------------------------\n" );
    printf( "c1 = %g\n", p->c1 );
    printf( "c2 = %g\n", p->c2 );
    printf( "c11 = %g\n", p->c11 );
    printf( "c22 = %g\n", p->c22 );
    printf( "b1 = %g\n", p->b1 );
    printf( "b2 = %g\n", p->b2 );
    printf( "ls = %g\n", p->ls );
    printf( "rg = %g\n", p->rg );
    printf( "rd = %g\n", p->rd );
    printf( "rs = %g\n", p->rs );
    printf( "cgs = %g\n", p->cgs );
    printf( "cdg = %g\n", p->cdg );
    printf( "cds = %g\n", p->cds );
    printf( "ri = %g\n", p->ri );
    printf( "gm = %g\n", p->gm );
    printf( "gds = %g\n", p->gds );
    printf( "tau = %g\n", p->tau );
    printf( "tau2 = %g\n", p->tau2 );
    printf( "ggs = %g\n", p->ggs );
    printf( "gdg = %g\n", p->gdg );
*/


    // create the netlist
    netlist[0]  = netlist_component( Netlist_R, p->rg, 3, 4, STATIC_COMPONENT );
    netlist[1]  = netlist_component( Netlist_R, p->rd, 7, 8, STATIC_COMPONENT );
    netlist[2]  = netlist_component( Netlist_L, p->b1, 1, 3, STATIC_COMPONENT );
    netlist[3]  = netlist_component( Netlist_L, p->b2, 8, 2, STATIC_COMPONENT );
    netlist[4]  = netlist_component( Netlist_SRL, p->rs, p->ls, 6, 0, STATIC_COMPONENT, STATIC_COMPONENT );
    netlist[5]  = netlist_component( Netlist_C, p->c1, 1, 0, STATIC_COMPONENT );
    netlist[6]  = netlist_component( Netlist_C, p->c2, 2, 0, STATIC_COMPONENT );
    netlist[7]  = netlist_component( Netlist_C, p->c11, 3, 6, STATIC_COMPONENT );
    netlist[8]  = netlist_component( Netlist_C, p->c22, 8, 6, STATIC_COMPONENT );
    netlist[9]  = netlist_component( Netlist_C, p->cgs, 4, 5, STATIC_COMPONENT );
    netlist[10] = netlist_component( Netlist_C, p->cdg, 4, 7, STATIC_COMPONENT );
    netlist[11] = netlist_component( Netlist_C, p->cds, 6, 7, STATIC_COMPONENT );
    netlist[12] = netlist_component( Netlist_R, p->ri, 5, 6, STATIC_COMPONENT );
    netlist[13] = netlist_component( Netlist_G, p->ggs, 4, 5, STATIC_COMPONENT );
    netlist[14] = netlist_component( Netlist_G, p->gdg, 4, 7, STATIC_COMPONENT );
    netlist[15] = netlist_component( Netlist_VCCS, p->gm, p->tau, 4, 5, 7, 6, STATIC_COMPONENT, STATIC_COMPONENT );
    netlist[16] = netlist_component( Netlist_VCCS, p->gds, p->tau2, 7, 6, 7, 6, STATIC_COMPONENT, STATIC_COMPONENT );
    nlist = prepare_netlist( netlist, 17 );

    for( i=0; i<pts; ++i ) {
        small_signal_model( nlist, flist[i]*1.e9, s );
        CA2PA( s, spolar, 2, 2 );
        mod11m[i] = db_mode ? 20. * log10(spolar[0].m) : spolar[0].m;
        mod12m[i] = db_mode ? 20. * log10(spolar[1].m) : spolar[1].m;
        mod21m[i] = db_mode ? 20. * log10(spolar[2].m) : spolar[2].m;
        mod22m[i] = db_mode ? 20. * log10(spolar[3].m) : spolar[3].m;
        mod11a[i] = spolar[0].a;
        mod12a[i] = spolar[1].a;
        mod21a[i] = spolar[2].a;
        mod22a[i] = spolar[3].a;
    }
}

