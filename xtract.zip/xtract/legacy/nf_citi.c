#include <stdio.h>
#include <string.h>
#include <math.h>

main ()
{
FILE  *in_file;
FILE  *out_file;
char  in_name[201];
char  out_name[201];
char  header[50][201];
char  buffer[201];
int   header_done;
int   i,n,j,num1;
double nf[128][8];

printf ("nf file name?\n");
gets (in_name);
sscanf (in_name,"%[^.]",out_name);
strcat (out_name,".citi");
n=0;
header_done = 0;
in_file  = (FILE*) NULL;
out_file = (FILE*) NULL;

in_file = fopen (in_name,"r");
if ( in_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",in_name);
   }
out_file = fopen (out_name,"w+");
if ( out_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",out_name);
   fclose (in_file);
   }
i = 0;
while (fgets (buffer,200,in_file) != NULL)
   {
   if ((header_done != 1) && (buffer[0] == '!'))
      {
      strcpy (header[n],buffer);
      ++n;
      if ((buffer[1] == 'V') && (buffer[2] == 'b'))
         {
         fgets (buffer,200,in_file);
         strcpy (header[n],buffer);
         ++n;
         }
      }
   else 
   {
      header_done = 1;
      sscanf (buffer,"%lf%lf%lf%lf%lf%*f%*f%*f%*f%lf%lf%lf",&nf[i][0],&nf[i][1],&nf[i][2],&nf[i][3],&nf[i][4],&nf[i][5],&nf[i][6],&nf[i][7]);
      i=i+1;
   }
}
num1 = i;
for (i = 0; i < n; ++i)
    {
     fprintf (out_file,"# %s",header[i]);
     }
fprintf(out_file,"CITIFILE A.01.00\n");
fprintf(out_file,"NAME MEAS_DATA\n");
fprintf(out_file,"VAR X MAG %d\n",num1);

fprintf(out_file,"DATA FREQ MA\n");
fprintf(out_file,"DATA FMIN MA\n");
fprintf(out_file,"DATA SOPTM MA\n");
fprintf(out_file,"DATA SOPTA MA\n");
fprintf(out_file,"DATA VV MA\n");
fprintf(out_file,"DATA II MA\n");
fprintf(out_file,"DATA GAIN MA\n");
fprintf(out_file,"VAR_LIST_BEGIN\n");
for (i=0;i<num1;i++) {
fprintf(out_file, "%+.4e\n", nf[i][0]);
}
fprintf(out_file,"VAR_LIST_END\n");

for (j=0;j<8;j++) {
  fprintf(out_file,"BEGIN\n");
  for (i=0;i<num1;i++) {
    fprintf(out_file, "%+.4e\n", nf[i][j]);
    }
  fprintf(out_file,"END\n");
}

fclose(out_file);
}

