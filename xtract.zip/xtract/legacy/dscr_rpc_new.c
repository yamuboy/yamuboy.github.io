#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *index ();
void bubble_sort ();
int record_compare ();

#define MAX_PARAMETERS   (30)
#define MAX_MODELS     (3000)

struct fet_model
{
char   device[20];
double p[MAX_PARAMETERS];
};

struct device_counter
{
char directory[20];
};

struct model_head
{
char   device[20];
char   mask[20];
char   process[20];
char   name[20];
char   directory[20];
char   g2gspace[20];
char   dcdata[2500];
char   wafer[20];
double s2dspace;
double temperature;
double p[MAX_PARAMETERS];
};

static struct fet_model model[MAX_MODELS];
static struct fet_model *model_pointer[MAX_MODELS];
static struct device_counter d[MAX_MODELS];
static struct device_counter *d_pointer[MAX_MODELS];
static struct model_head head[MAX_MODELS];
static struct model_head *head_pointer[MAX_MODELS];

main ()
{
double factor[MAX_PARAMETERS];
char   label[MAX_PARAMETERS][13];
time_t time_location;
FILE  *file_list;
FILE  *sum_file;
FILE  *dmb_file;
FILE  *end_file;
FILE  *rpc_file;
FILE  *header_file;
char  dmb_name[100];
char  end_name[100];
char  rpc_name[100];
char  dir[200];
char  header_name[100];
char  buffer[2500];
char  string[80];
char  *pointer;
char  *string_pointer;
char  input_line[80];
char  file_names[80];
char  new_line;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];
char  junk[1];
int   order[MAX_PARAMETERS];
int   i,j,n,m,x,flag,len,counter;

strcpy (label[0],"  Periphery ");
strcpy (label[1],"     ugw    ");
strcpy (label[2],"     ngf    ");
strcpy (label[3],"     Vds    ");
strcpy (label[4],"     Ids    ");
strcpy (label[5],"    mA_mm   ");
strcpy (label[6],"     Vgs    ");
strcpy (label[7],"     Igs    ");
strcpy (label[8],"     Rg     ");
strcpy (label[9],"     Rs     ");
strcpy (label[10],"     Rd     ");
strcpy (label[11],"     Ri     ");
strcpy (label[12],"     Cgs    ");
strcpy (label[13],"     Cdg    ");
strcpy (label[14],"     Cds    ");
strcpy (label[15],"     C1     ");
strcpy (label[16],"     C2     ");
strcpy (label[17],"     Ls     ");
strcpy (label[18],"     Lg     ");
strcpy (label[19],"     Ld     ");
strcpy (label[20],"     Ggs    ");
strcpy (label[21],"     Gdg    ");
strcpy (label[22],"     Gm     ");
strcpy (label[23],"     T1     ");
strcpy (label[24],"     Gds    ");
strcpy (label[25],"     T2     ");
strcpy (label[26],"     C11    ");
strcpy (label[27],"     C22    ");
strcpy (label[28],"     vv     ");
strcpy (label[29],"     ii     ");

factor[0]  = (double) 1.0e-03;
factor[1]  = (double) 1.0e+00;
factor[2]  = (double) 1.0e+00;
factor[3]  = (double) 1.0e+00;
factor[4]  = (double) 1.0e+03;
factor[5]  = (double) 1.0e+06;
factor[6]  = (double) 1.0e+00;
factor[7]  = (double) 1.0e+03;
factor[8]  = (double) 1.0e+00;
factor[9]  = (double) 1.0e+00;
factor[10] = (double) 1.0e+00;
factor[11] = (double) 1.0e+00;
factor[12] = (double) 1.0e+12;
factor[13] = (double) 1.0e+12;
factor[14] = (double) 1.0e+12;
factor[15] = (double) 1.0e+12;
factor[16] = (double) 1.0e+12;
factor[17] = (double) 1.0e+12;
factor[18] = (double) 1.0e+12;
factor[19] = (double) 1.0e+12;
factor[20] = (double) 1.0e+03;
factor[21] = (double) 1.0e+03;
factor[22] = (double) 1.0e+03;
factor[23] = (double) 1.0e+12;
factor[24] = (double) 1.0e+03;
factor[25] = (double) 1.0e+12;
factor[26] = (double) 1.0e+12;
factor[27] = (double) 1.0e+12;
factor[28] = (double) 1.0e+00;
factor[29] = (double) 1.0e+00;

printf ("\n");
printf ("Directory of S-Parameter files to summarize?\n");
scanf ("%s",dir);
printf ("S-Parameter files to summarize?\n");
scanf ("%s",file_names);

sprintf (buffer, "find ./%s -name '%s' -exec ls {} \\; > model_files.list",dir,file_names);
/* sprintf (buffer,"ls -1 %s > model_files.list",file_names); */
system (buffer);

printf ("\n");
printf ("Order for sorting precedence is 1. DEVICE, 4. VDS, 6. VGS:  \n");
printf ("\n");
printf ("    1. DEVICE   7. IGS     13. CDG     19. LD      25. T2 \n");
printf ("    2. UGW      8. RG      14. CDS     20. GGS     26. C11\n");
printf ("    3. NGF      9. RS      15. C1      21. GDG     27. C22\n");
printf ("    4. VDS     10. RD      16. C2      22. GM             \n");
printf ("    5. IDS     11. RI      17. LS      23. T1             \n");
printf ("    6. VGS     12. CGS     18. LG      24. GDS            \n");
printf ("\n");
/* printf ("Enter a negative value if you want to reverse the sort order.\n"); */
/* printf ("For example, -4 will sort VDS from high to low instead of\n"); */
/* printf ("low to high\n"); */
/* printf ("\n"); */
printf ("Sort order is:  1 4 6\n");

/* scanf ("%c%[^\n]",&new_line,input_line); */

/* if (input_line[0] == '\0') */
/*    { */
strcpy (input_line,"1 4 6");
/*    } */

m = sscanf (input_line,
            "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
            &order[0],&order[1],&order[2],&order[3],&order[4],&order[5],
            &order[6],&order[7],&order[8],&order[9],&order[10],&order[11],
            &order[12],&order[13],&order[14],&order[15],&order[16],&order[17],
            &order[18],&order[19],&order[20],&order[21],&order[22],&order[23],
            &order[24],&order[25],&order[26]);

printf ("\n");
printf ("Separation lines every?   Choices are:\n");
printf ("\n");
printf ("    1. DEVICE   7. IGS     13. CDG     19. LD      25. T2 \n");
printf ("    2. UGW      8. RG      14. CDS     20. GGS     26. C11\n");
printf ("    3. NGF      9. RS      15. C1      21. GDG     27. C22\n");
printf ("    4. VDS     10. RD      16. C2      22. GM             \n");
printf ("    5. IDS     11. RI      17. LS      23. T1             \n");
printf ("    6. VGS     12. CGS     18. LG      24. GDS            \n");
printf ("\n");
printf ("<CR> = none\n");

scanf ("%c%[^\n]",&new_line,input_line);

time (&time_location);
string_pointer = asctime (localtime (&time_location));
sscanf (string_pointer+8,"%s",s_day);
sscanf (string_pointer+4,"%s",s_month);
sscanf (string_pointer+20,"%s",s_year);
sscanf (string_pointer+11,"%s",s_time);
sprintf (string,"%s-%s-%s %s",s_day,s_month,s_year,s_time);

sum_file = fopen ("noise.dscr","w+");
header_file = fopen ("heading","w+");

fprintf (sum_file,"!\n");
fprintf (sum_file,"! FET MODEL DSCR PROGRAM VERSION 1.00 %s\n",string);
fprintf (sum_file,"!\n");
fprintf (sum_file,"BEGIN DSCRDATA\n");
fprintf (sum_file,"%% index ");

for (i = 0; i < MAX_PARAMETERS; ++i)
   {
   fprintf (sum_file,"%s",label[i]);
   }

fprintf (sum_file,"\n");

n = 0;

x = 0;
flag = 0;
counter = 0;
strcpy(d[x].directory,"junk");
file_list = fopen ("model_files.list","r");

while (fgets (dmb_name,100,file_list) != NULL)
   {
   dmb_name[strlen (dmb_name)-1] = '\0';
   len = strlen (dmb_name)-4;
   strncpy(end_name,dmb_name,len);
   strncpy(rpc_name,dmb_name,len);
   if (strlen (end_name) <= len)
   {
   strcat (end_name,".end");
   }
   if (strlen (rpc_name) <= len)
   {
   strcat (rpc_name,".rpc");
   }
   for (i = strlen (rpc_name)-1; i >= 0; --i)
      {
      if (rpc_name[i] == '/')
         {
         ++i;
         break;
         }
      }
   rpc_name[i] = 'n';
   dmb_file = fopen (dmb_name,"r");
   end_file = fopen (end_name,"r");
   rpc_file = fopen (rpc_name,"r");
   if (dmb_file == NULL)
      {
      continue;
      }

   if (end_file == NULL)
      {
      fclose (dmb_file);
      continue;
      }

   if (fgets (buffer,1024,dmb_file) != NULL)
   {
         sscanf (buffer,"!FILE NAME: %s",d[x].directory);
   } 
        
   fclose (dmb_file);
   dmb_file = fopen (dmb_name,"r");
   while (fgets (buffer,1024,dmb_file) != NULL)
      {
      if (strncmp (buffer,"!FILE NAME:",11) == 0)
         {
         sscanf (buffer,"!FILE NAME: %s",model[n].device);
         sscanf (buffer,"!FILE NAME: %s",head[n].device);
         }
      if (strncmp (buffer,"!MASK NAME:",11) == 0)
         {
         sscanf (buffer,"!MASK NAME: %s",head[n].mask);
         }
      if (strncmp (buffer,"!PROCESS NAME:",14) == 0)
         {
         sscanf (buffer,"!PROCESS NAME: %s",head[n].process);
         }
      if (strncmp (buffer,"!WAFER NUMBER:",14) == 0)
         {
         sscanf (buffer,"!WAFER NUMBER: %s",head[n].wafer);
         }
      if (strncmp (buffer,"!DEVICE NAME:",13) == 0)
         {
         sscanf (buffer,"!DEVICE NAME: %s",head[n].name);
         }
      if (strncmp (buffer,"!GATE PERIPHERY (um):",21) == 0)
         {
         sscanf (buffer,"!GATE PERIPHERY (um): %lf",&model[n].p[0]);
         head[n].p[0] = model[n].p[0];
         }
      if (strncmp (buffer,"!GATE LENGTH (um):",18) == 0)
         {
         sscanf (buffer,"!GATE LENGTH (um): %lf",&head[n].p[3]);
         }
      if (strncmp (buffer,"!UNIT GATE WIDTH (um):",22) == 0)
         {
         sscanf (buffer,"!UNIT GATE WIDTH (um): %lf",&model[n].p[1]);
         head[n].p[1] = model[n].p[1];
         }
      if (strncmp (buffer,"!NUMBER OF GATE FINGERS:",24) == 0)
         {
         sscanf (buffer,"!NUMBER OF GATE FINGERS: %lf",&model[n].p[2]);
         head[n].p[2] = model[n].p[2];
         }
      if (strncmp (buffer,"!GATE TO GATE SPACING (um):",27) == 0)
         {
         sscanf (buffer,"!GATE TO GATE SPACING (um): %s",head[n].g2gspace);
         }
      if (strncmp (buffer,"!SOURCE-DRAIN SPACING (um):",27) == 0)
         {
         sscanf (buffer,"!SOURCE-DRAIN SPACING (um): %lf",&head[n].s2dspace);
         }
      if (strncmp (buffer,"!TEMPERATURE (C):",17) == 0)
         {
         sscanf (buffer,"!TEMPERATURE (C): %lf",&head[n].temperature);
         }
     if (strncmp (buffer,"!Vbr",4) == 0)
         {
         fgets (buffer,1024,dmb_file);
         sscanf (buffer, "%c%lf%lf%lf%lf%lf%lf%lf",junk,&head[n].p[4],&head[n].p[5],&head[n].p[6],&head[n].p[7],&head[n].p[8],&head[n].p[9],&head[n].p[10]);
         head[n].p[6] = head[n].p[6]*((double) 1.0e3)/(head[n].p[0]*((double) 1.0e-3));
         head[n].p[8] = head[n].p[8]*((double) 1.0e3)/(head[n].p[0]*((double) 1.0e-3));
         }
      if (strncmp (buffer,"!BIAS:",6) == 0)
         {
         sscanf (buffer,
                 "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
                 &model[n].p[3],&model[n].p[4],&model[n].p[6],&model[n].p[7]);
         model[n].p[5] = model[n].p[4]/model[n].p[0];
         for (i = 0; i < 8; ++i)
            {
            model[n].p[i] *= factor[i];
            }
         break;
         }
      }

   for (i = 8; i < (MAX_PARAMETERS-2); ++i)
      {
      fgets (buffer,1024,end_file);
      sscanf (buffer,"%*f %lf",&model[n].p[i]);
      model[n].p[i] *= factor[i];
      }

   model[n].p[28] = model[n].p[11]/factor[11];
   model[n].p[29] = model[n].p[24]/factor[24];

   if (rpc_file != NULL)
      {
      while (fgets (buffer,1024,rpc_file) != NULL)
         {
         if (strncmp (buffer,"!   Freq      Fmin",18) == 0 )
            {
            fgets (buffer,1024,rpc_file);
            fgets (buffer,1024,rpc_file);
            sscanf (buffer,"%*f %*f %*f %*f %*f %*f %*f %*f %*f %lf %lf",&model[n].p[28],&model[n].p[29]);
            break;
            }
         }
      fclose (rpc_file);
      }

   ++n;

   fclose (dmb_file);
   fclose (end_file);
   if (strcmp(d[x].directory, d[x-1].directory) != 0)
   {
   counter = counter +1;
   if (flag == 0)
   {
   fprintf (header_file,"!PROCESS NAME: %s\n",head[n-1].process);
   fprintf (header_file,"!DEVICE NAME: %s\n",head[n-1].name);
   fprintf (header_file,"!GATE PERIPHERY (um): %.1f\n",head[n-1].p[0]);
   fprintf (header_file,"!GATE LENGTH (um): %.3f\n",head[n-1].p[3]);
   fprintf (header_file,"!UNIT GATE WIDTH (um): %.1f\n",head[n-1].p[1]);
   fprintf (header_file,"!NUMBER OF GATE FINGERS: %.0f\n",head[n-1].p[2]);
   fprintf (header_file,"!GATE TO GATE SPACING (um): %s\n",head[n-1].g2gspace);
   fprintf (header_file,"!SOURCE-DRAIN SPACING (um): %.1f\n",head[n-1].s2dspace);
   fprintf (header_file,"!TEMPERATURE (C): %.1f\n",head[n-1].temperature);
   fprintf (header_file,"!Model\tDev\tmask\tlot\tTemp\tVbr(.1mA)\tVbr(1mA)\tIdss(3V)\tVpo(3V)\t\tImax(1.5V)\tVpo(1.5V)\tVmax(1.5V)\n");
   fprintf (header_file,"!\t\t\t\t(C)\t(V)\t\t(V)\t\t(mA/mm)\t\t(V)\t\t(mA/mm)\t\t(V)\t\t(V)\n");
   flag = 1;
   }
   printf("Device %c%c%c%c...\n",head[n-1].device[1],head[n-1].device[2],head[n-1].device[3],head[n-1].device[4]);
   fprintf (header_file,"!%d\t%c%c%c%c\t%s\t%s\t%.1f\t",counter,head[n-1].device[1],head[n-1].device[2],head[n-1].device[3],head[n-1].device[4],head[n-1].mask,head[n-1].wafer,head[n-1].temperature);
   for (j = 4; j < 11; ++j)
   {
   fprintf (header_file,"%.3f\t\t",head[n-1].p[j]);
   }
   fprintf (header_file,"\n");
   }
 ++x;
 }

fclose (file_list);

for (j = 0; j < n; ++j)
   {
   model_pointer[j] = &model[j];
   }

bubble_sort (model_pointer,n,order,m);

for (j = 0; j < n; ++j)
   {
   fprintf (sum_file," %4d   ",j+1);
   for (i = 0; i < MAX_PARAMETERS; ++i)
      {
      fprintf (sum_file," %+.4e",model_pointer[j]->p[i]);
      }
   fprintf (sum_file,"\n");
   }

fprintf (sum_file,"END DSCRDATA");

fclose (sum_file);
fclose (header_file);

system ("rm -f model_files.list");
system ("cp model.dscr temp");
system ("cat heading temp > model.dscr");
system ("wait");
system ("rm -f temp");
system ("wait");
system ("rm -f heading");
printf("Complete!\n");

}

char *index (buffer,string)
char buffer[];
char string[];
{
char *pointer;
int  length;

length = strlen (string);
pointer = buffer;

while (strncmp (pointer,string,length) != 0)
   {
   pointer = strchr (pointer+1,string[0]);
   if (pointer == NULL)
      {
      return (pointer);
      /*
      printf (" can't find string %s\n",string);
      exit (1);
      */
      }
   }

return (pointer);

}
 
void bubble_sort (array,n,order,m)
struct fet_model *array[];
int   n;
int   order[];
int   m;
{
char  *temp;
int   i;
int   j;

for (i = 0; i < n - 1; ++i)
   {
   for (j = i + 1; j < n; ++j)
      {
      if (record_compare (array[i],array[j],order,m) >= 0)
         {
         temp     = array[i];
         array[i] = array[j];
         array[j] = temp;
         }
      }
   }

return;

}
 
int record_compare (record1,record2,order,n)
struct fet_model *record1;
struct fet_model *record2;
int   order[];
int   n;
{
int   value;
int   i;

i = -1;

do
   {
   ++i;
   switch (abs (order[i]))
      {
      case 1:
         if (strcmp (record1->device,record2->device) > 0)
            {
            value = 1;
            }
         else if (strcmp (record1->device,record2->device) < 0)
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      case 4:
         if (record1->p[3] > (record2->p[3]+((double) 0.05)))
            {
            value = 1;
            }
         else if (record1->p[3] < (record2->p[3]-((double) 0.05)))
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      case 6:
         if (record1->p[6] > (record2->p[6]+((double) 0.02)))
            {
            value = 1;
            }
         else if (record1->p[6] < (record2->p[6]-((double) 0.02)))
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      default:
         if (record1->p[abs(order[i])-1] > record2->p[abs(order[i])-1])
            {
            value = 1;
            }
         else if (record1->p[abs(order[i])-1] < record2->p[abs(order[i])-1])
            {
            value = -1;
            }
         else
            {
            value = 0;
            }
         break;
      }
   if (order[i] < 0)
      {
      value = -value;
      }
   }
while (i < n - 1 && value == 0);

return (value);

}
