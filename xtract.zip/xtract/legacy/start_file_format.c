#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main (argc,argv)
int  argc;
char *argv[];

{
FILE    *file1;
FILE    *file2;
double  min,nom,max,tol;
char    name[50];
char    string[201];
char    file_name[201];
char    out_name[201];

if (argc > 1)
   {
   sscanf (argv[1],"%s",file_name);
   }
else
   {
   return (-1);
   }

sscanf (file_name,"%[^.]",out_name);
strcat (out_name,".end");

file1 = fopen (file_name,"r");
if (file1 == (FILE *) NULL)
   {
   printf ("unable to open file - %s\n",file_name);
   return (-1);
   }
file2 = fopen (out_name,"w+");

while (fgets (string,200,file1) != NULL)
   {
   sscanf (string,"%lf %lf %lf %lf %s",&min,&nom,&max,&tol,name);
   fprintf (file2,"%12.4e %12.4e %12.4e %12.4e %s\n",min,nom,max,tol,name);
   }
fclose (file1);
fclose (file2);

return (0);
}
