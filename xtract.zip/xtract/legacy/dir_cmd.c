#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *lfile;
   char dname[256];
   char cmd[256];
   char dirs[256];
   char cwd[256];
   char string[256];
   char tmp_file_name[256];
   time_t tbuf;
   
   printf ("Directories in which to run command?\n");
   fgets (dirs, 255, stdin);
   dirs[strlen(dirs)-1] = 0;
   
   printf ("Command string?\n");
   fgets (cmd, 255, stdin);
   cmd[strlen(cmd)-1] = 0;
   

   if (!getcwd (cwd, 256))
      {
      printf ("Unable to get working directory.\n");
      return 1;
      }

   /**** create and open the file list ****/

   sprintf (tmp_file_name, "tmp.%d", time(&tbuf));
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);
   sprintf (string, "ls -1d %s > %s", dirs, tmp_file_name);
   system (string);

   lfile = fopen (tmp_file_name,"r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }
   
   /**** loop through the directory list ****/

   while (fgets (dname, 255, lfile))
      {
      dname[strlen(dname)-1] = 0;

      if (chdir (dname))
         {
         printf ("%s: failed to change directory.\n", dname);
         continue;
         }
      
      if (system (cmd))
         {
         printf ("system() call returned an error.\n");
         fclose (lfile);
         sprintf (string, "rm -f %s", tmp_file_name);
         system (string);
         return 1;
         }
      
      if (chdir (cwd))
         {
         printf ("%s: failed to change directory.\n", cwd);
         fclose (lfile);
         sprintf (string, "rm -f %s", tmp_file_name);
         system (string);
         return 1;
         }
         
      }   

   fclose (lfile);
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   return 0;
   }
   
