#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

main ()
{
FILE   *file1;
FILE   *file2;
FILE   *file3;
FILE   *file4;
FILE   *out_file;
char   temp[200];
char   name1[200];
char   name2[200];
char   name3[200];
char   name4[200];
char   out_name[200];
char   header[50][200];
char   buffer[1024];
float  vds,ids,vgs,igs;
int    i,j;

i = -1;

printf ("noise file1? ");
scanf ("%s",name1);

file1 = fopen (name1,"r");

while (fgets (buffer,1023,file1) != NULL)
   {
   if (strncmp (buffer,"!BIAS:",6) == 0)
      {
      break;
      }
   else
      {
      strcpy (header[++i],buffer);
      }
   }

sscanf (buffer,"!BIAS: VDS = %f Volts IDS = %f Amps VGS = %f Volts IGS = %f Amps",&vds,&ids,&vgs,&igs);
sprintf (out_name,"%ld",10000000L+((unsigned long int)(vds*10.0+0.5))*10000L+((unsigned long int)(fabs(vgs)*100.0+0.5)));

sscanf (&(out_name[1]),"%7s",temp);

if (vgs >= -2.0e-2)
   {
   temp[3] = 'p';
   }
else
   {
   temp[3] = 'm';
   }

strcpy (out_name,"n");
strcat (out_name,temp);
strcat (out_name,".nfig");

out_file = fopen (out_name,"w+");

for (j = 0; j <= i; ++j)
   {
   fprintf (out_file,"%s",header[j]);
   }
fprintf (out_file,"%s",buffer);

while (fgets (buffer,1023,file1) != NULL)
   {
   if (strncmp (buffer,"!BIAS:",6) == 0)
      {
      fclose (out_file);
      sscanf (buffer,"!BIAS: VDS = %f Volts IDS = %f Amps VGS = %f Volts IGS = %f Amps",&vds,&ids,&vgs,&igs);
      sprintf (out_name,"%ld",10000000L+((unsigned long int)(vds*10.0+0.5))*10000L+((unsigned long int)(fabs(vgs)*100.0+0.5)));
      sscanf (&(out_name[1]),"%7s",temp);
      if (vgs >= -2.0e-2)
         {
         temp[3] = 'p';
         }
      else
         {
         temp[3] = 'm';
         }
      strcpy (out_name,"n");
      strcat (out_name,temp);
      strcat (out_name,".nfig");
      out_file = fopen (out_name,"w+");
      for (j = 0; j <= i; ++j)
         {
         fprintf (out_file,"%s",header[j]);
         }
      fprintf (out_file,"%s",buffer);
      }
   else
      {
      fprintf (out_file,"%s",buffer);
      }
   }

fclose (file1);
fclose (out_file);

}
