#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize3.h"

#ifndef NO_PLOTTING_UTIL
#include "jplot.h"
#endif

#define NUM_PARAMS     47
#define MAX_IV_PTS     1000
#define MAX_BIAS_PTS   500

#define MAX_FWD_IGS    5.0e-8
#define VBI_FIXED_VALUE  0.7

#define ERR     -1
#define OK       0

#define BOLTZ   1.380066e-23
#define CHARGE  1.60218e-19
#define STDTEMP 300.0

#define USE_POSTSCRIPT  2
#define USE_METAFILE    4
#define NO_GRAPHICS     8

/* -------- FUNCTION PROTOTYPES ---------- */

static int fit_parasitics (char *, char *);
static int get_starting_values (char *);
static int get_iv_curves (char *, int);

#ifndef NO_PLOTTING_UTIL
static int plot_data (char *, char *, char *);
#endif

static double *dc_cap_fit (double *);
static double *dc_fit (double *);
static double *cap_fit (double *);
static double *gm_fit (double *);

static double parker_ids (double *, double, double);
static double parker_ac_ids (double *, double, double, double, double, double, double);
static void   parker_capacitance (double *, double, double, double *, double *);

static double bubble_average (double *, int);
static int    diode_fit (double *, double *, int, double, double *, double *, double *);

/* ------------- GLOBAL VARIABLES -------------- */

PARAM_STRUCT  params[NUM_PARAMS];
double        vgsi[MAX_IV_PTS],vdsi[MAX_IV_PTS];
double        igsi[MAX_IV_PTS],idsi[MAX_IV_PTS];
double        vds_c[MAX_BIAS_PTS],vgs_c[MAX_BIAS_PTS];
double        cgsm[MAX_BIAS_PTS],cgdm[MAX_BIAS_PTS];
double        gmm[MAX_BIAS_PTS],gdsm[MAX_BIAS_PTS];
double        lp_gate,lp_drain,eff_gl,eff_dl;
double        maximum_vds,res_gate;
int           num_cap_iv_pts,num_iv_pts;
int           option_flags = 0;
double global_tau2;

/****************************************************************************/
/*                                   MAIN                                   */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   int        i,n,niter,fitn;
   int        do_dciv = 1,do_cap = 1,do_gm = 1;
   OPT_STRUCT opt;
   FILE       *out_file,*in_file;
   double     weights[2];
   char       string[1024];
   char       model_summary_file[100];
   char       start_file[100];
   char       end_file[100];
   char       model_file[100];
   char       yfit_file[100];
   char       iv_curve_file[100];
   char       fwd_iv_file[100];
   char       vbr_iv_file[100];
   double     dummy,ugw;
   int ngf;

   /* parse the command line */
   
   for (i = 1; i < argc; ++i)
      {
      if (!strcmp (argv[i],"-h"))
         {
         printf ("\n\nUSAGE: parker_fit [ options ]\n\n");
         printf ("  options:\n  ---------------------------------------\n");
         printf ("  -h    brings up this help screen\n");
         printf ("  -dW   plot results using Win32 GDI or UNIX X-Windows (default)\n");
         printf ("  -dM   plot results into a group of metafiles named parker-n.wmf\n");
         printf ("          where n is a number from 1 to 4\n");
         printf ("  -dP   plot results into a postscript file named parker.ps\n");
         printf ("          this file is also created by default\n");
         printf ("  -d0   suppress plots\n");
         printf ("\n\n");
         return 0;
         }
      else if (!strcmp (argv[i],"-dM"))
         option_flags |= USE_METAFILE;
      else if (!strcmp (argv[i],"-dP"))
         option_flags |= USE_POSTSCRIPT;
      else if (!strcmp (argv[i],"-d0"))
         option_flags |= NO_GRAPHICS;
      else
         {
         fprintf (stderr,"Unrecognized command line option: %s\n",argv[i]);
         return -1;
         }
      }  

   printf ("Unit Gate Width? (um)\n");
   fgets (string,300,stdin);
   if (sscanf (string,"%lf",&ugw) != 1)
      {
      fprintf (stderr,"Error in parameter read.\n");
      return -1;
      }
   else if (ugw <= 0.0)
      {
      fprintf (stderr,"Unit gate width must be > 0.\n");
      return -1;
      }      

   printf ("Number of Gate Fingers?\n");
   fgets (string,300,stdin);
   if (sscanf (string,"%d",&ngf) != 1)
      {
      fprintf (stderr,"Error in parameter read.\n");
      return -1;
      }
   else if (ngf <= 0)
      {
      fprintf (stderr,"Number of gate fingers must be > 0.\n");
      return -1;
      }
            
   printf ("Y-fit end file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",yfit_file);
   
   printf ("Effective Gate and Drain Lengths? (um)\n");
   fgets (string,300,stdin);
   if (sscanf (string,"%lf%lf",&eff_gl,&eff_dl) != 2)
      {
      fprintf (stderr,"Error in parameter read.\n");
      return -1;
      }
         
   printf ("Model summary file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",model_summary_file);
   
   printf ("DC IV data file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",iv_curve_file);
   
   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string,300,stdin);
   if (sscanf (string,"%lf",&maximum_vds) != 1)
      {
      fprintf (stderr,"Error in parameter read.\n");
      return -1;
      }
      
   printf ("Forward IV data file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",fwd_iv_file);
   
   printf ("Breakdown IV data file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",vbr_iv_file);
   
   printf ("Start parameters file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",start_file);
   
   printf ("Finish parameters file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",end_file);
   
   printf ("Output model file name?\n");
   fgets (string,300,stdin);
   sscanf (string,"%99s",model_file);
   
   printf ("Maximum number of line searches?\n");
   fgets (string,300,stdin);
   if (sscanf (string,"%d",&niter) != 1)
      {
      fprintf (stderr,"Error in parameter read.\n");
      return -1;
      }
   
   if (get_starting_values (start_file))
      return -1;
   
   params[0].min = params[0].max = params[0].nom = ugw*ngf;
   params[38].min = params[38].max = params[38].nom = ugw;
   params[39].min = params[39].max = params[39].nom = ngf;
   
   /************************************************************************/
   
   printf ("\n\nFITTING PARASITICS.....\n");
   
   if (fit_parasitics (model_summary_file,yfit_file))
      return -1;
   
   printf ("Done.\n");
   
   /************************************************************************/
   
   printf ("FITTING IV-CURVES.....\n");
   
   num_iv_pts = get_iv_curves (iv_curve_file,0);
   if (num_iv_pts < 0)
      {
      printf ("** error ** in get_iv_curves()\n");
      return -1;
      }
   
   for (i = 1; i < 16; ++i)
      params[i].optimize = TRUE;
   
   weights[0] = 1.0;
   weights[1] = 1.0;
   
   initialize_optimizer (&opt,NUM_PARAMS,1,weights,niter,&dc_fit);
   
   if (do_dciv)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("Conjugate Gradient Optimizer encountered an error.\n");
         return -1;
         }
      }
   
   for (i = 1; i < 16; ++i)
      params[i].optimize = FALSE;
   
   printf ("Done.\n");
   
   /************************************************************************/
   
   printf ("FITTING GATE CAPACITANCE.....\n");
   
   for (i = 16; i < 21; ++i)
      params[i].optimize = TRUE;
   for (i = 44; i < 47; ++i)
      params[i].optimize = TRUE;
   
   opt.num_of_criteria = 1;
   opt.function = &cap_fit;
   weights[0] = 1.0;
   
   if (do_cap)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("Conjugate Gradient Optimizer encountered an error.\n");
         return -1;
         }
      }
   
   for (i = 0; i < NUM_PARAMS; ++i)
      params[i].optimize = FALSE;
   
   printf ("Done.\n");
   
   /************************************************************************/
   
   printf ("FITTING GM AND GDS.....\n");
   
   for (i = 21; i < 27; ++i)
      params[i].optimize = TRUE;
   
   opt.num_of_criteria = 2;
   opt.function = &gm_fit;
   weights[0] = 3.0;
   weights[1] = 5.0;
   
   if (do_gm)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("Conjugate Gradient Optimizer encountered an error.\n");
         return -1;
         }
      }
   
   printf ("Done.\n");
   
   /************************************************************************/
   
   printf ("FITTING IS AND N.....\n");
   n = get_iv_curves (fwd_iv_file,1);
   if (n < 1)
      {
      printf ("** error ** in get_iv_curves()\n");
      return -1;
      }
   else
      {
      if (diode_fit (vgsi,igsi,n,params[0].nom,&params[40].nom,&params[41].nom,&res_gate))
         {
         printf ("Error in diode_fit()\n");
         return -1;
         }
      }
   
   params[40].nom *= 0.5/params[0].nom;
   params[40].min = params[40].max = params[40].nom;
   params[41].min = params[41].max = params[41].nom;
   
   printf ("Gate diode resistance: %.2f ohms\n",res_gate);
   
   printf ("Done.\n");
   
   /************************************************************************/
   
   printf ("FITTING VBD AND IBD.....\n");
   
   n = get_iv_curves (vbr_iv_file,2);
   if (n < 1)
      {
      printf ("** error ** in get_iv_curves()\n");
      return -1;
      }
   else
      {
      if (diode_fit (vgsi,igsi,n,params[0].nom/10.0,&params[42].nom,&params[43].nom,&dummy) == ERR)
         {
         printf ("Error in diode_fit()\n");
         return -1;
         }
      }
   
   params[42].nom *= 1.0/params[0].nom;
   params[43].nom *= BOLTZ*STDTEMP/CHARGE;
   params[42].min = params[42].max = params[42].nom;
   params[43].min = params[43].max = params[43].nom;
      
   printf ("Done.\n");
   
   /************************************************************************/

#ifndef NO_PLOTTING_UTIL
   
   printf ("PLOTTING DATA.....\n");

   if (!(option_flags & NO_GRAPHICS))
      {
      if (plot_data (iv_curve_file,fwd_iv_file,vbr_iv_file))
         printf ("ERROR in plot_data(), continuing...\n");
      else
         {
         if (!(option_flags & USE_POSTSCRIPT))
            {
            option_flags |= USE_POSTSCRIPT;
            plot_data (iv_curve_file,fwd_iv_file,vbr_iv_file);
            }
         }
      }

#endif
    
   /************************************************************************/
   
   printf ("WRITING DATA TO FILE.....\n");
   
   out_file = fopen (end_file,"w+");
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (out_file,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (out_file);
   
   out_file = fopen (model_file,"w+");
   in_file = fopen (iv_curve_file,"r");
   
   i = 0;
   while (1)
      {
      fgets (string,201,in_file);
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         fprintf (out_file,"%s",string);
         break;
         }
      else if (++i > 30)
         break;
      fprintf (out_file,"%s",string);
      }
   fgets (string,201,in_file);
   fclose (in_file);
   fprintf (out_file,"%s",string);
   fprintf (out_file,"!\n");
   
   fprintf (out_file,"%-7s =  %d\n","model",1);
   fprintf (out_file,"%-7s =  %.4e\n",params[0].name,1.0);
   
   for (i = 1; i < NUM_PARAMS; ++i)
      fprintf (out_file,"%-7s =  %.4e\n",params[i].name,params[i].nom);
   
   fprintf (out_file,"%-7s =  %.4e\n","taud",1.0e-4);
   fprintf (out_file,"%-7s =  %.4e\n","taug",1.0e-6);
   fprintf (out_file,"%-7s =  %.4e\n","tnom",1.0e-6);
   fprintf (out_file,"!\n");
   fprintf (out_file,"%-7s =  %.4e\n","af",1.0);
   fprintf (out_file,"%-7s =  %.4e\n","kf",0.0);
   fprintf (out_file,"%-7s =  %.4e\n","lpg",lp_gate);
   fprintf (out_file,"%-7s =  %.4e\n","lpd",lp_drain);
   fprintf (out_file,"%-7s =  %.4e\n","egl",eff_gl);
   fprintf (out_file,"%-7s =  %.4e\n","edl",eff_dl);
   fprintf (out_file,"%-7s =  %.4e\n","cgsp",0.0);
   fprintf (out_file,"%-7s =  %.4e\n","cgdp",0.0);
   fprintf (out_file,"%-7s =  %.4e\n","cdsp",0.0);
   fprintf (out_file,"%-7s =  %.4e\n","tau2",global_tau2);
   fprintf (out_file,"!\n");
   
   fclose (out_file);
   
   printf ("Parker Fit Complete!\n");
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

#ifndef NO_PLOTTING_UTIL

static int plot_data (char *iv_curve_file, char *fwd_file, char *rev_file)
   {
   jPLOT_ITEM *plot1,*plot2,*plot3;
   int    i,device;
   double x1data[MAX_IV_PTS];
   double x2data[MAX_IV_PTS];
   double y1data[MAX_IV_PTS];
   double y2data[MAX_IV_PTS];
   double y3data[MAX_IV_PTS];
   double y4data[MAX_IV_PTS];
   double p_list[NUM_PARAMS];
   double cgs,cgd,gm,gds,ids1,ids2,p_ave,vgd;
   double del = 1.0e-9;
   double per_mm = 1.0e3/params[0].nom;
   static char *legend_t[] = {"Modeled","Measured"};
   static int  legend_l[] = {LT_SOLID,LT_DASHED};
   static int  legend_w[] = {1,1};
   static int  legend_c[] = {CLR_RED,CLR_BLUE};
   char header[1500],string[200],*plotfile;
   FILE *file;
   
   plot1 = create_plot_item (SingleY,2.5,1.1,5.5,4.5);
   plot2 = create_plot_item (SingleY,1.3,1.1,3.7,3.7);
   plot3 = create_plot_item (SingleY,6.3,1.1,3.7,3.7);
   
   deactivate_plot_item (plot2);
   deactivate_plot_item (plot3);
   
   set_axis_scales (plot1,NULL,POSITIVE_X | POSITIVE_Y1);
   set_axis_scales (plot2,NULL,POSITIVE_X | POSITIVE_Y1);
   set_axis_scales (plot3,NULL,POSITIVE_X | POSITIVE_Y1);
   
   plot2->attribs.ylabel_offset = 0.6;
   plot3->attribs.ylabel_offset = 0.6;
      
   for (i = 0; i < NUM_PARAMS; ++i)
      p_list[i] = params[i].nom;
   
   if (option_flags & USE_POSTSCRIPT)
      {
      device = POSTSCRIPT;
      plotfile = "parker.ps";
      }
   else if (option_flags & USE_METAFILE)
      {
      device = METAFILE;
      plotfile = "parker.wmf";
      }
   else
      {
      device = X_WINDOWS;
      plotfile = "";
      }

   header[0] = 0;
   file = fopen (iv_curve_file,"r");
   while (fgets(string,199,file))
      {
      if (string[0] != '!')
         break;

      if (!strncmp(string,"!FILE",5))
         strcat (header,&string[1]);
      else if (!strncmp(string,"!MASK",5))
         strcat (header,&string[1]);
      else if (!strncmp(string,"!WAFER",5))
         strcat (header,&string[1]);
      else if (!strncmp(string,"!PROCESS",5))
         strcat (header,&string[1]);
      else if (!strncmp(string,"!DEVICE",5))
         strcat (header,&string[1]);
      else if (!strncmp(string,"!TEMP",5))
         strcat (header,&string[1]);
      }
   fclose (file);

   add_text (header,5.5,7.9,FNT_TIMES,12,0.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE);
   add_legend (2,8.0,6.5,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);
   
   if (!open_graphics_device (device,plotfile))
      {
      printf ("open_graphics_device() failed\n");
      return -1;
      }
   
   /************ plot IV curves ****************/
   
   num_iv_pts = get_iv_curves (iv_curve_file,0); 
   for (i = 0; i < num_iv_pts; ++i)
      {
      x1data[i] = vdsi[i];
      y2data[i] = idsi[i]*per_mm*1.0e3;
      y1data[i] = parker_ids (p_list,vdsi[i],vgsi[i])*per_mm*1.0e3;
      }
   
   attach_y1data (plot1,x1data,y1data,num_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,num_iv_pts,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot1,"Vds (volts)","Ids (mA/mm)","","IV Curves");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   deactivate_plot_item (plot1);
   
   /************ plot capacitance ****************/
   
   activate_plot_item (plot2);
   activate_plot_item (plot3);
   
   for (i = 0; i < num_cap_iv_pts; ++i)
      {
      x1data[i] = vds_c[i];
      y2data[i] = cgsm[i]*per_mm*1.0e12;
      y4data[i] = cgdm[i]*per_mm*1.0e12;
      parker_capacitance (p_list,vds_c[i],vgs_c[i],&cgd,&cgs);
      y1data[i] = cgs*per_mm*1.0e12;
      y3data[i] = cgd*per_mm*1.0e12;
      }
   
   attach_y1data (plot2,x1data,y1data,num_cap_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot2,x1data,y2data,num_cap_iv_pts,LT_DASHED,1,CLR_BLUE);
   attach_y1data (plot3,x1data,y3data,num_cap_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot3,x1data,y4data,num_cap_iv_pts,LT_DASHED,1,CLR_BLUE);
      
   set_axis_labels (plot2,"Vds (volts)","Cgs (pF/mm)","","Gate-Source");
   set_axis_labels (plot3,"Vds (volts)","Cgd (pF/mm)","","Gate-Drain");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed\n");
      close_graphics_device ();
      return -1;
      }  
   
   /************ plot gm and gds ****************/
   
   for (i = 0; i < num_cap_iv_pts; ++i)
      {
      vgd = vgs_c[i]-vds_c[i];
      ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i],vgd,vgs_c[i],vgd,0.0);
      p_ave = fabs (ids1*vds_c[i]);
      ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]+del,vgd+del,vgs_c[i],vgd,p_ave);
      ids2 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]-del,vgd-del,vgs_c[i],vgd,p_ave);
      gm = (ids1-ids2)*0.5/del;
      ids1 = parker_ac_ids (p_list,vds_c[i]+del,vgs_c[i],vgd-del,vgs_c[i],vgd,p_ave);
      ids2 = parker_ac_ids (p_list,vds_c[i]-del,vgs_c[i],vgd+del,vgs_c[i],vgd,p_ave);
      gds = (ids1-ids2)*0.5/del;
      
      y2data[i] = gmm[i]*per_mm*1.0e3;
      y4data[i] = gdsm[i]*per_mm*1.0e3;
      y1data[i] = gm*per_mm*1.0e3;
      y3data[i] = gds*per_mm*1.0e3;   
      }
      
   set_axis_labels (plot2,"Vds (volts)","Gm (mS/mm)","","");
   set_axis_labels (plot3,"Vds (volts)","Gds (mS/mm)","","");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }

   detach_data (plot2);
   detach_data (plot3);
   
   /************ plot diode curves ****************/
   
   num_iv_pts = get_iv_curves (fwd_file,1); 
   for (i = 0; i < num_iv_pts; ++i)
      {
      x1data[i] = vgsi[i];
      y2data[i] = igsi[i]*per_mm*1.0e3;
      y1data[i] = 2.0e3*per_mm*params[0].nom*params[40].nom*
         (exp((vgsi[i]-igsi[i]*res_gate)*CHARGE/(BOLTZ*STDTEMP*params[41].nom)) - 1.0);
      }
   
   attach_y1data (plot2,x1data,y1data,num_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot2,x1data,y2data,num_iv_pts,LT_DASHED,1,CLR_BLUE);
   
   num_iv_pts = get_iv_curves (rev_file,2); 
   for (i = 0; i < num_iv_pts; ++i)
      {
      x2data[i] = vgsi[i];
      y4data[i] = igsi[i]*per_mm*1.0e3;
      y3data[i] = 1.0e3*per_mm*params[0].nom*params[42].nom*
         (exp(vgsi[i]/(params[43].nom)) - 1.0);
      }
   
   attach_y1data (plot3,x2data,y4data,num_iv_pts,LT_DASHED,1,CLR_BLUE);
   attach_y1data (plot3,x2data,y3data,num_iv_pts,LT_SOLID,1,CLR_RED);
      
   set_axis_labels (plot2,"Vgs (volts)","Ig (mA/mm)","","Forward");
   set_axis_labels (plot3,"Vdg (volts)","Ig (mA/mm)","","Reverse");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }  
   
   close_graphics_device ();
   
   return 0;
}

#endif

/*****************************************************************************/
/*****************************************************************************/

static int fit_parasitics (char *sum_file, char *end_file)
   {
   FILE     *file;
   int      n = 0;
   int      m = 0;
   int      i;
   char     string[301],pname[80];
   double   idd[MAX_BIAS_PTS];
   double   igg[MAX_BIAS_PTS];
   double   Rg[MAX_BIAS_PTS];
   double   Rd[MAX_BIAS_PTS];
   double   Rs[MAX_BIAS_PTS];
   double   Ri[MAX_BIAS_PTS];
   double   Tau[MAX_BIAS_PTS];
   double   Cds[MAX_BIAS_PTS];
   double   Ls[MAX_BIAS_PTS];
   double   rg1,rd1,rs1,ri1;
   double   value,area,ugw,ngf;
   double   cpg,cpd,c11,c22;
   double   Tau2[MAX_BIAS_PTS];
   
   ngf = params[39].nom;
   ugw = params[38].nom;
   area = params[0].nom;
   
   file = fopen (sum_file,"r");
   if (!file)
      {
      printf ("Unable to open model summary file - %s\n",sum_file);
      return ERR;
      }
   
   while (fgets (string,300,file) != NULL)
      {
      if (m >= MAX_BIAS_PTS)
         {
         printf ("WARNING: too many bias points in model summary file.\n");
         break;
         }
         
      if (sscanf (&string[28],"%lf %lf %lf %lf %*f %*f %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %*f %lf",
         &vds_c[n],&idd[n],&vgs_c[n],&igg[n],
         &Rg[m],&Rs[m],&Rd[m],&Ri[m],&gmm[n],&Tau[m],&gdsm[n],&Tau2[m],
         &cgsm[n],&Cds[m],&cgdm[n],&Ls[m]) == 16)
         {
         ++m;
         
         if ((igg[n]*((double) 1.0e-3)/area) < MAX_FWD_IGS)
            {
            igg[n] *= 1.0e-3;
            idd[n] *= 1.0e-3;
            gmm[n] *= 1.0e-3;
            gdsm[n] *= 1.0e-3;
            cgsm[n] *= 1.0e-12;
            cgdm[n] *= 1.0e-12;
            ++n;
            }
         }
      }
   fclose (file);
   num_cap_iv_pts = n;
   
   file = fopen (end_file,"r");
   if (!file)
      {
      printf ("Unable to open yfit file - %s\n",end_file);
      return ERR;
      }
   
   while (fgets (string,300,file) != NULL)
      {
      sscanf (string,"%*f %lf %*f %*f %s",&value,pname);
      if (!strcmp (pname,"C1"))
         {
         cpg = value;
         }
      else if (!strcmp (pname,"C2"))
         {
         cpd = value;
         }
      else if (!strcmp (pname,"C11"))
         {
         c11 = value;
         }
      else if (!strcmp (pname,"C22"))
         {
         c22 = value;
         }
      else if (!strcmp (pname,"B1"))
         {
         lp_gate = value;
         }
      else if (!strcmp (pname,"B2"))
         {
         lp_drain = value;
         }
      }
   fclose (file);
   
   params[27].nom = bubble_average (Rg,m)*3.0*ngf/ugw;
   params[28].nom = bubble_average (Rs,m)*area;
   params[29].nom = bubble_average (Rd,m)*area;
   params[30].nom = bubble_average (Ri,m)*area*0.5;
   params[31].nom = bubble_average (Tau,m)*1.0e-12;
   params[32].nom = bubble_average (Cds,m)*1.0e-12/area;
   params[33].nom = cpg/area;
   params[34].nom = bubble_average (Ls,m)*1.0e-12;
   params[35].nom = cpd/area;
   params[36].nom = c11/area;
   params[37].nom = c22/area;
   global_tau2 = bubble_average (Tau2,m)*1.0e-12;
   
   lp_gate  = ngf*(lp_gate  - 2.0e-13*ugw*(log (ugw/eff_gl) + 0.498232)/(3.0*ngf));
   lp_drain = ngf*(lp_drain - 2.0e-13*ugw*(log (ugw/eff_dl) + 0.498232)/(1.5*ngf));
   
   rg1 = params[27].nom*ugw/(ngf*3.0);
   rd1 = params[29].nom/area;
   rs1 = params[28].nom/area;
   ri1 = params[30].nom/area;
   
   for (i = 0; i < num_cap_iv_pts; ++i)
      {
      vds_c[i] = vds_c[i] - rd1*idd[i] - rs1*(igg[i]+idd[i]);
      vgs_c[i] = vgs_c[i] - (rg1+ri1)*igg[i] - rs1*(igg[i]+idd[i]);
      }
   
   for (i = 27; i < 42; ++i)
      {
      params[i].tol = 0.0;
      params[i].max = params[i].min = params[i].nom;
      params[i].optimize = FALSE;
      }
   
   params[0].tol = 0.0;
   params[0].max = params[0].min = params[0].nom;
   params[0].optimize = FALSE;
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_starting_values (char *fname)
   {
   FILE   *file;
   char   string[201];
   int    i;
   PARAM_STRUCT *p = params;
   
   strcpy (params[0].units,"um");
   strcpy (params[1].units,"V");
   strcpy (params[2].units,"A/V^2");
   strcpy (params[3].units,"V");
   strcpy (params[4].units,"");
   strcpy (params[5].units,"1/W");
   strcpy (params[6].units,"");
   strcpy (params[7].units,"V");
   strcpy (params[8].units,"1/V");
   strcpy (params[9].units,"");
   strcpy (params[10].units,"");
   strcpy (params[11].units,"1/V");
   strcpy (params[12].units,"");
   strcpy (params[13].units,"");
   strcpy (params[14].units,"1/V");
   strcpy (params[15].units,"1/V");
   strcpy (params[16].units,"F");
   strcpy (params[17].units,"F");
   strcpy (params[18].units,"");
   strcpy (params[19].units,"");
   strcpy (params[20].units,"");
   strcpy (params[21].units,"");
   strcpy (params[22].units,"");
   strcpy (params[23].units,"");
   strcpy (params[24].units,"");
   strcpy (params[25].units,"");
   strcpy (params[26].units,"");
   strcpy (params[27].units,"ohms/um");
   strcpy (params[28].units,"ohm-um");
   strcpy (params[29].units,"ohm-um");
   strcpy (params[30].units,"ohm-um");
   strcpy (params[31].units,"S");
   strcpy (params[32].units,"F/um");
   strcpy (params[33].units,"F/um");
   strcpy (params[34].units,"pH");
   strcpy (params[35].units,"F/um");
   strcpy (params[36].units,"F/um");
   strcpy (params[37].units,"F/um");
   strcpy (params[38].units,"um");
   strcpy (params[39].units,"");
   strcpy (params[40].units,"A/um");
   strcpy (params[41].units,"");
   strcpy (params[42].units,"A/um");
   strcpy (params[43].units,"V");
   strcpy (params[44].units,"V");
   strcpy (params[45].units,"V");
   strcpy (params[46].units,"");
   
   file = fopen (fname,"r");
   if (!file)
      {
      printf ("unable to open starting values file - %s\n",fname);
      return ERR;
      }
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (!fgets (string,200,file))
         {
         if (i > 43)
            {
            printf ("Warning: Adding new parameter to file.\n");
            switch (i)
               {
               case 44:
                  sprintf (string,"%.4e %.4e %.4e %.4e %s\n",params[1].min,params[1].nom,params[1].max,params[1].tol,"vbic");
                  break;
               case 45:
                  sprintf (string,"%.4e %.4e %.4e %.4e %s\n",params[3].min,params[3].nom,params[3].max,params[3].tol,"vtoc");
                  break;
               case 46:
                  sprintf (string,"%.4e %.4e %.4e %.4e %s\n",params[9].min,params[9].nom,params[9].max,params[9].tol,"xic");
                  break;
               default:      
                  sprintf (string,"%.4e %.4e %.4e %.4e %s\n",0.0,0.0,0.0,0.0,"nothing");
                  break;
               }
            }
         else
            {           
            printf ("INCOMPLETE starting values file - %s\n",fname);
            fclose (file);
            return ERR;
            }
         }
      
      sscanf (string,"%lf %lf %lf %lf %s",&params[i].min,&params[i].nom,&params[i].max,&params[i].tol,params[i].name);
      params[i].optimize = FALSE;
      }
   fclose (file);

   /* set VBI and VBIC to be fixed */
   
   if (p[1].nom < 0.6)
      p[1].min = p[1].nom = p[1].max = VBI_FIXED_VALUE;
   else
      p[1].min = p[1].max = p[1].nom;
   
   if (p[44].nom < 0.6)
      p[44].min = p[44].nom = p[44].max = VBI_FIXED_VALUE;
   else
      p[44].min = p[44].max = p[44].nom;
   
   /* set valid ranges on certain "trouble" parameters */

   if (p[2].min < 0.0)  // BETA should be >= 0
      p[2].min = 0.0;
   
   if (p[3].max > (p[1].min - 0.01))  // VTO must be less than VBI
      p[3].max = p[1].min - 0.01;

   if (p[5].min < 0.0)  // DELTA should be >= 0
      p[5].min = 0.0;
      
   if (p[7].min < 0.0)  // VST must be >= 0
      p[7].min = 0.0;
   
   if (p[8].min < 0.0)  // MVST must be >= 0
      p[8].min = 0.0;
   
   if (p[9].min < 0.0)  // XI must be >= 0
      p[9].min = 0.0;
   
   if (p[10].min < 0.0)  // MXI must be >= 0
      p[10].min = 0.0;
   
   if (p[12].min < 0.001)  // Z must be > 0
      p[12].min = 0.001;
   
   if (p[16].min < 1.0e-18)  // CGS must be > 0
      p[16].min = 1.0e-18;
   
   if (p[17].min < 1.0e-18)  // CGD must be > 0
      p[17].min = 1.0e-18;
   
   if (p[19].min < 0.0)  // XC should be >= 0
      p[19].min = 0.0;
   
   if (p[19].max > 0.99999)
      p[19].max = 0.99999;
   
   if (p[20].max >= (p[1].min - 0.01))  // FC must be less than VBI 
      p[20].max = p[1].min - 0.01;
   
   if (p[45].max >= (p[44].min - 0.01))  // VTOC must be less than VBIC
      p[45].max = p[44].min - 0.01;
   
   if (p[46].min < 0.0)  // XIC should be >= 0
      p[46].min = 0.0; 

   /* reset any parameters that have illegal min, max or nominal values */
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (p[i].nom < p[i].min)
         p[i].nom = p[i].min;
      if (p[i].max < p[i].min)
         p[i].max = p[i].min;
      if (p[i].nom > p[i].max)
         p[i].nom = p[i].max;
      }
   
   return OK;
   }

/*****************************************************************************/
/*****************************************************************************/

static int get_iv_curves (char *fname, int mode)
   {
   FILE     *file;
   char     string[201];
   int      i = 0;
   double   rs,rd,rg,ri;
   
   file = fopen (fname,"r");
   if (!file)
      {
      printf ("Unable to open IV file - %s\n",fname);
      return ERR;
      }
   
   rg = params[27].nom*params[38].nom/(params[39].nom*3.0);
   rd = params[29].nom/params[0].nom;
   rs = params[28].nom/params[0].nom;
   ri = params[30].nom/params[0].nom;
   
   while (fgets (string,200,file))
      {
      if (i > MAX_IV_PTS)
         {
         printf ("WARNING: too many points in IV file.\n");
         break;
         }
      
      if (sscanf (string,"%lf %lf %lf %lf",&vdsi[i],&idsi[i],&vgsi[i],&igsi[i]) == 4)
         {
         switch (mode)
            {
            case 0:
               if ((igsi[i]/params[0].nom) >= MAX_FWD_IGS)
                  continue;
               else if (vdsi[i] > maximum_vds)
                  continue;
               else
                  {
                  vdsi[i] = vdsi[i]-rd*idsi[i]-rs*(igsi[i]+idsi[i]);
                  vgsi[i] = vgsi[i]-(rg+ri)*igsi[i]-rs*(igsi[i]+idsi[i]);
                  ++i;
                  }
               break;
               
            case 1:
               if (vdsi[i] != 0.0)
                  continue;
               ++i;
               break;
               
            case 2:
               igsi[i] = -igsi[i];
               vgsi[i] = (vdsi[i]-idsi[i]*rd)-(vgsi[i]+igsi[i]*rg);
               ++i;
               break;
               
            default:
               break;
            }
         }
      }
   fclose (file);
   
   return i;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                        PARKER OPTIMIZER FUNCTIONS                         */
/*****************************************************************************/
/*****************************************************************************/

static double *dc_cap_fit (double *p_list)
   {
   double *err;
   static double result[2];
   
   err = dc_fit (p_list);
   result[0] = err[0];
   err = cap_fit (p_list);
   result[1] = err[0];
   
   return result;
   }

/*****************************************************************************/
/*****************************************************************************/

static double *dc_fit (double *p_list)
   {
   int      i;
   double   pids;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      pids = parker_ids (p_list,vdsi[i],vgsi[i]);
      
      if ((fabs (vdsi[i]) >= 1.0))
         error += 5000.0*(idsi[i]-pids)*(idsi[i]-pids);
      else
         error += 1000.0*(idsi[i]-pids)*(idsi[i]-pids);
      }
   
   error = error/((double) num_iv_pts);
   return &error;
   }

/*****************************************************************************/
/*****************************************************************************/

static double *cap_fit (double *p_list)
   {
   int      i;
   double   cgs,cgd;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_cap_iv_pts; ++i)
      {
      parker_capacitance (p_list,vds_c[i],vgs_c[i],&cgd,&cgs);
      error += 1.0e24*(cgsm[i]-cgs)*(cgsm[i]-cgs) + (4.5*tanh (2.0*vds_c[i] - 0.5) + 5.5) *
         1.0e24*(cgdm[i]-cgd)*(cgdm[i]-cgd);
      }
   
   error = error/((double) num_cap_iv_pts);
   return &error;
   }

/*****************************************************************************/
/*****************************************************************************/

static double *gm_fit (double *p_list)
   {
   int     i;
   double  gm,gds;
   double  ids1,ids2;
   double  p_ave,vgd;
   static double  error[2];
   double del = 1.0e-9;
   
   error[0] = 0.0;
   error[1] = 0.0;
   for (i = 0; i < num_cap_iv_pts; ++i)
      {
      vgd = vgs_c[i]-vds_c[i];
      ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i],vgd,vgs_c[i],vgd,0.0);
      p_ave = fabs (ids1*vds_c[i]);
      
      ids1 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]+del,vgd+del,vgs_c[i],vgd,p_ave);
      ids2 = parker_ac_ids (p_list,vds_c[i],vgs_c[i]-del,vgd-del,vgs_c[i],vgd,p_ave);
      gm = (ids1-ids2)*0.5/del;
      ids1 = parker_ac_ids (p_list,vds_c[i]+del,vgs_c[i],vgd-del,vgs_c[i],vgd,p_ave);
      ids2 = parker_ac_ids (p_list,vds_c[i]-del,vgs_c[i],vgd+del,vgs_c[i],vgd,p_ave);
      gds = (ids1-ids2)*0.5/del;
      
      error[0] += 1.0e3*(gmm[i]-gm)*(gmm[i]-gm);
      error[1] += 1.0e3*(gdsm[i]-gds)*(gdsm[i]-gds)*tanh (2.0*vds_c[i]-0.5);
      }
   
   error[0] = error[0]/((double) num_cap_iv_pts);
   error[1] = error[1]/((double) num_cap_iv_pts);
   
   return error;
   }

/*****************************************************************************/
/*****************************************************************************/
/*                          PARKER MODEL FUNCTIONS                           */
/*****************************************************************************/
/*****************************************************************************/

static double parker_ids (double *pl, double V_ds, double V_gs)
   {
   double V_gst,V_gt,V_st,V_dt,V_dp;
   double V_ds1,V_gs1,V_gd1,V_sat,I_d,I_ds;
   double P_ave,lfgamma;
   double area   = pl[0];
   double vbi    = pl[1];
   double beta   = pl[2];
   double vto    = pl[3];
   double p      = pl[4];
   double delta  = pl[5];
   double q      = pl[6];
   double vst    = pl[7];
   double mvst   = pl[8];
   double xi     = pl[9];
   double mxi    = pl[10];
   double lambda = pl[11];
   double z      = pl[12];
   double lfgam  = pl[13];
   double lfg1   = pl[14];
   double lfg2   = pl[15];
   double V_gd   = V_gs-V_ds;
   
   if (V_ds >= 0.0)
      {
      V_gs1 = V_gs;
      V_gd1 = V_gd;
      V_ds1 = V_ds;
      }
   else
      {
      V_gs1 = V_gd;
      V_gd1 = V_gs;
      V_ds1 = -V_ds;
      }
   
   lfgamma = lfgam - lfg1*V_gs1 + lfg2*V_gd1;
   
   V_gst = V_gs1 - vto - lfgamma*V_gd1;
   
   V_st = vst*(1.0 + mvst*V_ds1);
   
   if (V_gst <= (-40.0*V_st))
      V_gt = V_st*log (exp (-40.0) + 1.0);
   else if (V_gst >= (40.0*V_st))
      V_gt = V_st*log (exp (40.0) + 1.0);
   else
      V_gt = V_st*(1.0e-15 + log (exp (V_gst/V_st) + 1.0));
   
   V_sat = V_gt*(V_gt*mxi + xi*(vbi-vto))/(V_gt + V_gt*mxi + xi*(vbi-vto));
   V_dp = V_ds1*(p/q)*pow (V_gt/(vbi-vto),p-q);
   
   
   V_dt = 0.5*sqrt (pow ((V_dp*sqrt (1.0 + z) + V_sat),2.0) + z*V_sat*V_sat) -
      0.5*sqrt (pow ((V_dp*sqrt (1.0 + z) - V_sat),2.0) + z*V_sat*V_sat);
   
   I_d = area*beta*(1.0 + lambda*V_ds1)*(pow (V_gt,q) - pow (fabs (V_gt-V_dt),q));
   
   P_ave = fabs (I_d*V_ds);
   I_ds = I_d/(1.0 + delta*P_ave/area);
   
   if (V_ds < 0.0)
      I_ds = -I_ds;
   
   return I_ds;
   }

/*****************************************************************************/
/*****************************************************************************/

static double parker_ac_ids (double *pl, double V_ds, double V_gs, double V_gd, 
                      double Vgs_ave, double Vgd_ave, double P_ave)
   {
   double V_gst,V_gt,V_st,V_dt,V_dp;
   double V_ds1,V_gs1,V_gd1,V_sat,I_d,I_ds;
   double Vgd_ave1,Vgs_ave1,lfgamma,hfgamma,hf_eta;
   double area   = pl[0];
   double vbi    = pl[1];
   double beta   = pl[2];
   double vto    = pl[3];
   double p      = pl[4];
   double delta  = pl[5];
   double q      = pl[6];
   double vst    = pl[7];
   double mvst   = pl[8];
   double xi     = pl[9];
   double mxi    = pl[10];
   double lambda = pl[11];
   double z      = pl[12];
   double lfgam  = pl[13];
   double lfg1   = pl[14];
   double lfg2   = pl[15];
   double hfeta  = pl[21];
   double hfe1   = pl[22];
   double hfe2   = pl[23];
   double hfgam  = pl[24];
   double hfg1   = pl[25];
   double hfg2   = pl[26];
   
   if (V_ds >= 0.0)
      {
      V_gs1 = V_gs;
      V_gd1 = V_gd;
      V_ds1 = V_ds;
      Vgs_ave1 = Vgs_ave;
      Vgd_ave1 = Vgd_ave;
      }
   else
      {
      V_gs1 = V_gd;
      V_gd1 = V_gs;
      V_ds1 = -V_ds;
      Vgs_ave1 = Vgd_ave;
      Vgd_ave1 = Vgs_ave;
      }
   
   lfgamma = lfgam - lfg1*Vgs_ave1 + lfg2*Vgd_ave1;
   
   hfgamma = hfgam - hfg1*Vgs_ave1 + hfg2*Vgd_ave1;
   hf_eta  = hfeta - hfe1*Vgd_ave1 + hfe2*Vgs_ave1;
   
   V_gst = V_gs1 - vto - lfgamma*V_gd1 - hfgamma*(V_gd1-Vgd_ave1) - hf_eta*(V_gs1-Vgs_ave1);
   
   V_st = vst*(1.0 + mvst*V_ds1);
   
   if (V_gst <= (-40.0*V_st))
      V_gt = V_st*log (exp (-40.0) + 1.0);
   else if (V_gst >= (40.0*V_st))
      V_gt = V_st*log (exp (40.0) + 1.0);
   else
      V_gt = V_st*(1.0e-15 + log (exp (V_gst/V_st) + 1.0));
   
   V_sat = V_gt*(V_gt*mxi + xi*(vbi-vto))/(V_gt + V_gt*mxi + xi*(vbi-vto));
   V_dp = V_ds1*(p/q)*pow (V_gt/(vbi-vto),p-q);
   
   
   V_dt = 0.5*sqrt (pow ((V_dp*sqrt (1.0 + z) + V_sat),2.0) + z*V_sat*V_sat) -
      0.5*sqrt (pow ((V_dp*sqrt (1.0 + z) - V_sat),2.0) + z*V_sat*V_sat);
   
   I_d = area*beta*(1.0 + lambda*V_ds1)*(pow (V_gt,q) - pow (fabs (V_gt-V_dt),q));
   
   I_ds = I_d/(1.0 + delta*P_ave/area);
   
   if (V_ds < 0.0)
      I_ds = -I_ds;
   
   return I_ds;
   }

/*****************************************************************************/
/*****************************************************************************/

static void parker_capacitance (double *p, double vds, double vgs, double *Cgd, double *Cgs)
   {
   double alpha,cgs0,cgd0;
   double Veff,Vert,Vx,Vnew;
   double Vnr,Vnrt,Ext,Qrt,Par;
   double c_plus,c_minus;   
   double area  = p[0];
   double vbi   = p[44];
   double vto   = p[45];
   double xi    = p[46];
   double cgs   = p[16];
   double cgd   = p[17];
   double acgam = p[18];
   double xc    = p[19];
   double fc    = p[20];
   double vgd   = vgs-vds;
   
   alpha = xi*(vbi-vto)*0.5/(1.0 + xi);
   
   Vert = sqrt (vds*vds + alpha*alpha);
   Veff = 0.5*(vgs + vgd + Vert) + acgam*vds;
   Vnr = (1.0 - xc)*(Veff - vto);
   Vnrt = sqrt (Vnr*Vnr + 0.04);
   Vnew = Veff + 0.5*(Vnrt-Vnr);
   
   if (Vnew < fc)
      {
      Ext = 0.0;
      Qrt = sqrt (1.0 - Vnew/vbi);
      cgs0 = 0.5*cgs*area*(1.0 + xc + (1.0 - xc)*Vnr/Vnrt)/Qrt;
      }
   else
      {
      Vx = 0.5*(Vnew - fc);
      Par = 1.0 + Vx/(vbi - fc);
      Qrt = sqrt (1.0 - fc/vbi);
      cgs0 = 0.5*cgs*area*(1.0 + xc + (1.0 - xc)*Vnr/Vnrt)*Par/Qrt;
      }
   
   c_plus = 0.5*(1.0 + vds/Vert);
   c_minus = c_plus - vds/Vert;
   
   cgd0 = cgd*area;
   
   *Cgs = cgs0*(c_plus  + acgam) + cgd0*(c_minus + acgam);
   *Cgd = cgs0*(c_minus - acgam) + cgd0*(c_plus  - acgam);
   }

/*****************************************************************************/
/*****************************************************************************/
/*                                UTILITIES                                  */
/*****************************************************************************/
/*****************************************************************************/

static double bubble_average (double *values, int n)
   {
   int     i,j;
   double  temp;
   double  delta;
   
   for (i = 0; i < n-1; ++i)
      {
      for (j = i+1; j < n; ++j)
         {
         if (values[j] < values[i])
            {
            temp = values[i];
            values[i] = values[j];
            values[j] = temp;
            }
         }
      }
   
   i = 0;
   temp = 0.0;
   delta = fabs (values[n/2])*0.25;
   for (j = 0; j < n; ++j)
      {
      if (fabs (values[j]-values[n/2]) < delta)
         {
         ++i;
         temp += values[j];
         }
      }
      
   if (i > 0)
      return temp/((double) i);
   else
      return 0.0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int a_x_b (double *a, double *x, double *b, int n)
   {
   double   y[5];
   double   z[5][5];
   double   tempd;
   double   tempd2;
   double   max;
   int      pointer[5];
   int      tempi;
   int      i,j,k;
   int      col,row;
   
   
   if (n > 5)
      {
      printf ("a_x_b () - Matrix is too large.\n");
      return -1;
      }
   
   for (i = 0; i < n; ++i)
      {
      y[i] = b[i];
      pointer[i] = i;
      for (j = 0; j < n; ++j)
         {
         z[i][j] = a[i*n+j];
         }
      }
   
   /* invert the matrix */
   for (k = 0; k < n-1; ++k)
      {
      /* find max */
      max = 0.0;
      for (i = k; i < n; ++i)
         {
         for (j = k; j < n; ++j)
            {
            if (fabs (z[i][j]) > max)
               {
               row = i;
               col = j;
               max = fabs (z[i][j]);
               }
            }
         }
      
      /* rotate rows */
      if (row != k)
         {
         for (j = 0; j < n; ++j)
            {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
            }
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
         }
      
      /* rotate columns */ 
      if (col != k)
         {
         for (i = 0; i < n; ++i)
            {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
            }
         tempi = pointer[k];
         pointer[k] = pointer[col];
         pointer[col] = tempi;
         }
      
      /* gaussian elimination */
      tempd = z[k][k];
      for (i = k+1; i < n; ++i)
         {
         tempd2 = z[i][k]/tempd;
         y[i] -= tempd2*y[k];
         for (j = k; j < n; ++j)
            {
            z[i][j] -= tempd2*z[k][j];
            }
         }
      }  
   
   if (fabs (z[n-1][n-1]) < 1.0e-24)
      return -1;
   
   /* back substitution */
   x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
   for (k = n-2; k > -1; --k)
      {
      tempd = y[k];
      for (i = n-1; i > k; --i)
         {
         tempd -= z[k][i]*x[pointer[i]];
         }
      x[pointer[k]] = tempd/z[k][k];
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_fit (double *vd, double *id, int k, double area, double *is, double *n, double *Rd)
   {
   double   a1[3][MAX_IV_PTS];
   double   a2[MAX_IV_PTS][3];
   double   b1[MAX_IV_PTS];
   double   a[3][3];
   double   b[3];
   double   x[3];
   double   sum;
   int      i,j;
   int      npts;

   j = 0;
   for (i = 0; i < k; ++i)
      {
      if ((vd[i] <= 0.0) || (id[i] <= (1.0e-7*area)))
         continue;
      
      a2[j][0] = log (id[i]);
      a2[j][1] = -1.0;
      a2[j][2] = id[i];
      a1[0][j] = a2[j][0];
      a1[1][j] = a2[j][1];
      a1[2][j] = a2[j][2];
      b1[j] = vd[i];
      ++j;
      }
   
   if (j < 3)
      {
      printf ("Not enough points for diode fit.\n");
      return -1;
      }
   
   npts = j;
   
   for (i = 0; i < 3; ++i)
      {
      for (j = 0; j < 3; ++j)
         {
         sum = 0.0;
         for (k = 0; k < npts; ++k)
            sum += a1[i][k]*a2[k][j];
         
         a[i][j] = sum;
         }
      }
   
   for (i = 0; i < 3; ++i)
      {
      sum = 0.0;
      for (j = 0; j < npts; ++j)
         sum += a1[i][j]*b1[j];
      
      b[i] = sum;
      }
   
   if (a_x_b ((double *)a,x,b,3))
      {
      printf ("Un-invertable matrix in diode fit.\n");
      return (-1);
      }
   
   *n = x[0]*CHARGE/(BOLTZ*STDTEMP);
   *is = exp (x[1]/x[0]);
   *Rd = x[2];
   
   return 0;
   }

