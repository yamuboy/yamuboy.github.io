#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#define RAD2DEG   ((double) 57.2957795131)
#define MAXCOLS        30
#define MAXSWEEPSIZE   100

static int string_index (char *, char *);
static int parse_line (char *, double [][MAXSWEEPSIZE], int, int);
static void interpolate_data (double [][MAXSWEEPSIZE], int, int, double, int, double *);

main ()
   {
   char    file_name[256],out_name[256],string[256];
   char    plot_name[80],batch_name[80],*buffer;
   char    names[MAXCOLS][40];
   static  char sep_chars[] = " .,|:;/\n\"!?";
   int     device,first,i,j,npts;
   int     gt_column = -1,gp_column = -1;
   int     num_cols,used_cols,use_gp;
   int     columns[MAXCOLS];
   double  p_comp,mag,ang,real,imag,freq;
   double  lpdata[MAXCOLS][MAXSWEEPSIZE];
   double  values[MAXCOLS];
   FILE    *infile,*outfile;
   time_t  dummyt;

   printf ("Maury load pull file name?\n> ");
   fgets (string,255,stdin);
   sscanf (string,"%255s",file_name);
   
   printf ("Compression (dB)?\n> ");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&p_comp);
   if (p_comp <= 0.0)
      {
      printf ("ERROR: compression must be g.t. 0 dB.\n");
      return -1;
      }
   
   printf ("Plot file name?\n> ");
   fgets (string,255,stdin);
   sscanf (string,"%79s",plot_name);
   
   printf ("Plotting Device (10=Postscript, 11=X-Windows, 12=Metafile)?\n> ");
   fgets (string,255,stdin);
   sscanf (string,"%d",&device);
   
   sscanf (file_name,"%[^.]",out_name);
   strcat (out_name,".temp");
   
   infile = fopen (file_name,"r");
   if (infile == (FILE *) NULL)
      {
      printf ("ERROR: cannot open file \"%s\"\n",file_name);
      return (-1);
      }
   
   outfile = fopen (out_name,"w+");
   
   first = 1;
   while (fgets (string,200,infile) != NULL)
      {
      if (first)
         {
         if (!strncmp (string,"Frequency range:",16))
            sscanf (&string[16],"%lf",&freq);
         
         if ((i = string_index (string,"Source = (")) > -1)
            {
            sscanf (&string[i+9],"(%lf %lf)",&real,&imag);
            mag = sqrt (real*real + imag*imag);
            ang = atan2 (imag,real)*RAD2DEG;
            fprintf (outfile,"! Source Reflection Coefficient: ( %.3f < %.1f )\n",mag,ang);
            fprintf (outfile,"! Frequency: %.3f GHz\n",freq);
            fprintf (outfile,"! Compression: %.1f dB\n",p_comp);
            i = string_index (string,"Load = (");
            sscanf (&string[i+7],"(%lf %lf)",&real,&imag);
            mag = sqrt (real*real+imag*imag);
            ang = atan2 (imag,real)*RAD2DEG;
            if (fgets (string,255,infile) != NULL)
               {
               i = 0;
               buffer = strtok (string,sep_chars);
               do {
                  if (!strcmp (buffer,"Gt_dB"))
                     gt_column = i;
                  else if (!strcmp (buffer,"Gp_dB"))
                     gp_column = i;
                                    
                  printf ("%2d : %s\n",i+1,buffer);
                  strncpy (names[i],buffer,39);
                  names[i][39] = 0;
                  
                  ++i;
                  
                  if (i >= MAXCOLS)
                     break;
                  }
               while ((buffer = strtok (NULL,sep_chars)) != NULL);
               num_cols = i;
                              
               printf ("Columns to plot (seperated by spaces)\n> ");
               fgets (string,255,stdin);
               
               used_cols = 0;
               buffer = strtok (string,sep_chars);
               do {
                  if (sscanf (buffer,"%d",&columns[used_cols]) == 1)
                     {
                     columns[used_cols] -= 1;
                     if (columns[used_cols] < num_cols)
                        ++used_cols;
                     }

                  if (used_cols >= MAXCOLS)
                     break;
                  }
               while ((buffer = strtok (NULL,sep_chars)) != NULL);

               if ((gt_column > -1) && (gp_column > -1))
                  {
                  i = 1;
                  printf ("Use 1=Gt or 2=Gp to interpolate compression point?\n> ");
                  fgets (string,255,stdin);
                  sscanf (string,"%d",&i);
                  if (i == 2)
                     use_gp = 1;
                  else
                     use_gp = 0;
                  }
               else if (gt_column > -1)
                  use_gp = 0;
               else if (gp_column > -1)
                  use_gp = 1;
               else
                  {
                  printf ("ERROR: Gain columns do not exist.\nUnable to continue.\n");
                  return -1;
                  }
               }

            first = 0;
            npts = 0;
            }
         }
      
      else
         {
         if ((i = string_index (string,"Load = (")) >= 0)
            {
            // find the compression point and interpolate the data
            interpolate_data (lpdata,npts,num_cols,p_comp,(use_gp) ? gp_column : gt_column,values);

            // write to file
            fprintf (outfile,"%7.4f %7.1f ",mag,ang);
            for (j = 0; j < used_cols; ++j)
               fprintf (outfile,"%.4e ",values[columns[j]]);
            fprintf (outfile,"\n");

            // get the new mag/angle
            sscanf (&string[i+7],"(%lf %lf)",&real,&imag);
            mag = sqrt (real*real + imag*imag);
            ang = atan2 (imag,real)*RAD2DEG;
            npts = 0;
            }

         else
            {
            if (parse_line (string,lpdata,npts,num_cols))
               ++npts;
            }
         }
      }

   fclose (infile);
   fclose (outfile);
   
   // write the batch job file
   sprintf (batch_name,"batch.%d",time (&dummyt));
   outfile = fopen (batch_name,"w+");
   fprintf (outfile,"%s\n",out_name);    // contour data file name
   fprintf (outfile,"%s\n",plot_name);   // plot file name
   fprintf (outfile,"%d\n",used_cols);   // number of contour plots
   for (i = 0; i < used_cols; ++i)        // names for the contour plots (from the Maury file header)
      fprintf (outfile,"%s\n",names[columns[i]]);
   fprintf (outfile,"%d\n",device);      // plotting device
   fclose (outfile);
   
   sprintf (string,"contour_plot < %s",batch_name);
   system (string);
   
   sprintf (string,"rm -f %s",out_name);
   system (string);
   sprintf (string,"rm -f %s",batch_name);
   system (string);
   
   return 0;
   }

/*********************************************************************************/                
/*********************************************************************************/                

static int string_index (char *str1,char *str2)
   {
   int   len1,len2,i;
   
   len1 = strlen (str1);
   len2 = strlen (str2);
   
   if (len1 < len2)
      return -1;
   
   for (i = 0; i <= (len1-len2); ++i)
      {
      if (!strncmp (&str1[i],str2,len2))
         return (i);
      }
   
   return -1;
   }

/*********************************************************************************/                
/*********************************************************************************/                

static int parse_line (char *string, double lpdata[][MAXSWEEPSIZE], int npts, int num_cols)
   {
   int       i;
   char      *str,*str1;
   
   str1 = string;
   
   for (i = 0; i < num_cols; ++i)
      {
      lpdata[i][npts] = strtod (str1,&str);
      if (str1 == str)
         return 0;

      str1 = str;
      }
   
   return 1;
   }

/*********************************************************************************/                
/*********************************************************************************/                

static void interpolate_data (double lpdata[][MAXSWEEPSIZE], int npts, int ncols, double p_comp, int gain_col, double *values)
   {
   int     i,index,low_index;
   double  gain,factor;


   // find the maximum gain
   gain = lpdata[gain_col][0];
   index = 0;
   for (i = 1; i < npts; ++i)
      {
      if (lpdata[gain_col][i] > gain)
         {
         gain = lpdata[gain_col][i];
         index = i;
         }
      }

   gain -= p_comp;

   // determine the interpolation factor
   low_index = -1;
   for (i = index; i < (npts-1); ++i)
      {
      if ((gain <= lpdata[gain_col][i]) && (gain > lpdata[gain_col][i+1]))
         low_index = i;
      }

   if (low_index > -1)
      factor = (gain - lpdata[gain_col][low_index]) / (lpdata[gain_col][low_index+1] - lpdata[gain_col][low_index]);
   else
      factor = (gain - lpdata[gain_col][npts-1]) / (lpdata[gain_col][npts-1] - lpdata[gain_col][npts-2]);

   // interpolate (or extrapolate) the data
   for (i = 0; i < ncols; ++i)
      {
      if (low_index > -1)
         values[i] = lpdata[i][low_index] + (lpdata[i][low_index+1] - lpdata[i][low_index])*factor;
      else
         values[i] = lpdata[i][npts-1] + (lpdata[i][npts-1] - lpdata[i][npts-2])*factor;
      }
   }






   





