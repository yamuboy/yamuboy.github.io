#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   int i;
   FILE *in, *out;
   char *bad_dat;
   double vgs, vds, igs, ids;
   double ig_po, ig_on, id_po, id_on;
   int b_count;
   char str[256];
   

   if (argc < 2)
      {
      printf ("\n\n");
      printf ("USAGE: %s [files]\n", argv[0]);
      printf ("-------------------------------------------------\n");
      printf ("  Parsing tool for 1523 MAAPSS0109 data files.\n");
      printf ("\n\n");
      return 0;
      }
   
   out = fopen( "parse_result.txt", "w+" );
   if( !out )
      {
      printf( "Error: unable to write to disc.\n" );
      return 1;
      }
   
   fprintf( out, "!filename\tIg(po)\tId(po)\tIg(on)\tId(on)\n" );

   for (i = 1; i < argc; ++i)
      {
      in = fopen( argv[i], "r" );
      if( !in )
         {
         printf( "Warning: %s: file not found.\n", argv[i] );
         continue;
         }
       
      b_count = 0;
      bad_dat = "";
      while( fgets( str, 255, in ) )
         {
         if( sscanf( str, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
             &vds, &ids, &vgs, &igs ) == 4 )
            {
            if( !b_count )
               {
               ig_po = igs;
               id_po = ids;
               if( id_po > 1.49 || vds < 2.5 )
                  bad_dat = "***";
               }
            else
               {
               ig_on = igs;
               id_on = ids;
               if( id_on > 1.49 || vds < 2.5 )
                  bad_dat = "***";
               }            
            b_count++;
            }
         
         if( b_count == 2 )
            break;      
         }
      
      fclose( in );
      
      if( b_count != 2)
         fprintf( out, "%s:\tmissing data.\n", argv[i] );
      else
         fprintf( out, "%s:\t%.3e\t%.4f\t%.3e\t%.4f\t%s\n", argv[i], ig_po, id_po, ig_on, id_on, bad_dat );
      }
   
   fclose( out );
   
   return 0;
   }


