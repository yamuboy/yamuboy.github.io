#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LOW_LEVEL    0.2
#define HIGH_LEVEL   2.4

static int check_failed (double *o, int n, double low, double high);

/****************************************************************************/

int main (int argc, char *argv[])
   {
   char site[21];
   char string[256];
   char fname[256];
   char outname[256];
   FILE *infile,*outfile;
   int i,failed;
   int total_passed = 0;
   int total_failed = 0;
   double o[10];
   
   printf ("File name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fname);
   
   printf ("Ouptut name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", outname);

   infile = fopen (fname, "r");
   if (!infile)
      {
      printf ("Unable to open file: %s\n", fname);
      return 1;
      }
   
   outfile = fopen (outname, "w+");
   if (!outfile)
      {
      printf ("Unable to write results to disk.\n");
      return 1;
      }   
   
   while (fgets (string, 255, infile))
      {
      if (sscanf (string, "!Site: %20s", &site))
         {
         i = 0;
         failed = 0;
         while (fgets (string, 255, infile) && (i++ < 8))
            {
            sscanf (string, "%*d %lf%lf%lf%lf%lf%lf%lf%lf%lf%lf", 
               &o[0], &o[1], &o[2], &o[3], &o[4], &o[5], &o[6], &o[7], &o[8], &o[9]);
            
            if (check_failed (o, i, LOW_LEVEL, HIGH_LEVEL))
               ++failed;
            }
         
         if (i != 8)
            {
            printf ("Incomplete file.\n");
            break;
            }
         
         if (!failed)
            {
            fprintf (outfile, "Site %s: PASSED\n");
            ++total_passed;
            }
         else
            {
            fprintf (outfile, "Site %s: FAILED - %d states\n", failed);
            ++total_failed;
            }      
         }
      }
   
   fprintf (outfile, "\n-------------- SUMMARY ----------------\n\n");
   fprintf (outfile, "Total Passed: %d\n", total_passed);
   fprintf (outfile, "Total Failed: %d\n", total_failed);
   fprintf (outfile, "%% Yield: %.1f %%\n", 
      ((double) total_passed) / ((double) total_passed+total_failed) * 100.0);
   
   fclose (infile);
   fclose (outfile);
   }

/****************************************************************************/

static int logic_level (double x, double low, double high)
   {
   if (x < low)
      return -1;
   else if (x > high)
      return 1;
   
   return 0;
   }

/****************************************************************************/

static int check_failed (double *o, int n, double low, double high)
   {
   static int state1[] = {-1, -1, -1, -1, -1, -1, -1,  1,  1, -1};
   static int state2[] = {-1, -1, -1, -1, -1, -1,  1,  1, -1, -1};
   static int state3[] = {-1, -1, -1, -1,  1,  1, -1,  1, -1, -1};
   static int state4[] = {-1, -1, -1, -1,  1, -1, -1,  1, -1,  1};
   static int state5[] = { 1,  1, -1, -1,  1, -1, -1, -1, -1, -1};
   static int state6[] = {-1,  1, -1,  1,  1, -1, -1, -1, -1, -1};
   static int state7[] = {-1, -1,  1, -1, -1, -1, -1, -1, -1, -1};
   static int state8[] = {-1, -1,  1, -1, -1, -1, -1, -1, -1, -1};
   int *state;
   int i;
   
   switch (n)
      {
      case 1:
         state = state1;
         break;
      case 2:
         state = state2;
         break;
      case 3:
         state = state3;
         break;
      case 4:
         state = state4;
         break;
      case 5:
         state = state5;
         break;
      case 6:
         state = state6;
         break;
      case 7:
         state = state7;
         break;
      case 8:
         state = state8;
         break;
      default:
         printf ("Error: invalid state number.\n");
         break;
      }
   
   for (i = 0; i < 10; ++i)
      {
      if (state[i] != logic_level (o[i], low, high))
         return 1;
      }
   
   return 0;
   }   
    
            
   
   
   
   
   
   
   
   
   
   
   
   
      
