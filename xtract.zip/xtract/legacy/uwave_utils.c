#include <math.h>
#include "cmplxlib.h"

#ifndef __COMPLEX_TYPES
#define __COMPLEX_TYPES

typedef struct
{
double real;
double imag;
} COMPLEX;

typedef struct
{
double mag;
double ang;
} POLAR;

#endif

COMPLEX *embed ();
COMPLEX *deembed ();

COMPLEX *s2h ();
COMPLEX *s2y ();
COMPLEX *s2z ();
COMPLEX *s2t ();
COMPLEX *s2abcd ();

COMPLEX *y2h ();
COMPLEX *y2z ();
COMPLEX *y2t ();
COMPLEX *y2abcd ();
COMPLEX *y2s ();

COMPLEX *z2h ();
COMPLEX *z2y ();
COMPLEX *z2t ();
COMPLEX *z2abcd ();
COMPLEX *z2s ();

COMPLEX *abcd2h ();
COMPLEX *abcd2y ();
COMPLEX *abcd2z ();
COMPLEX *abcd2t ();
COMPLEX *abcd2s ();

COMPLEX *t2h ();
COMPLEX *t2y ();
COMPLEX *t2s ();
COMPLEX *t2abcd ();
COMPLEX *t2z ();


/*                                                                   */
/*--- Function embed ------------------------------------------------*/
/*                                                                   */

COMPLEX *embed (a,b,c,d)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;
COMPLEX *d;

{
COMPLEX z[4];
COMPLEX x[4];

complex_2x2_mult(a,complex_2x2_mult(b,c,z),x);

d[0].real = x[0].real;
d[0].imag = x[0].imag;
d[1].real = x[1].real;
d[1].imag = x[1].imag;
d[2].real = x[2].real;
d[2].imag = x[2].imag;
d[3].real = x[3].real;
d[3].imag = x[3].imag;

return (d);

}

/*                                                                   */
/*--- Function deembed ----------------------------------------------*/
/*                                                                   */

COMPLEX *deembed (a,b,c,d)
COMPLEX *a;
COMPLEX *b;
COMPLEX *c;
COMPLEX *d;

{
COMPLEX t1[4];
COMPLEX t2[4];
COMPLEX t3[4];
COMPLEX x[4];

complex_2x2_mult(complex_2x2_inv(a,t3),complex_2x2_mult(b,complex_2x2_inv(c,t1),t2),x);

d[0].real = x[0].real;
d[0].imag = x[0].imag;
d[1].real = x[1].real;
d[1].imag = x[1].imag;
d[2].real = x[2].real;
d[2].imag = x[2].imag;
d[3].real = x[3].real;
d[3].imag = x[3].imag;

return (d);

}

/*                                                                   */
/*--- Function s2h --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2h (s,h,rref)
COMPLEX *s;
COMPLEX *h;
double  rref;

{
COMPLEX one;
COMPLEX two;
COMPLEX neg2;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(one,complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])));

x[0] = complex_mult(complex_mult(complex_sub(complex_mult(complex_add(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom),crref);
x[1] = complex_mult(two,complex_mult(s[1],denom));
x[2] = complex_mult(neg2,complex_mult(s[2],denom));
x[3] = complex_div(complex_mult(complex_sub(complex_mult(complex_sub(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom),crref);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function s2y --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2y (s,y,rref)
COMPLEX *s;
COMPLEX *y;
double  rref;

{
COMPLEX one;
COMPLEX neg2;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(one,complex_mult(complex_sub(complex_mult(complex_add(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),crref));

x[0] = complex_mult(complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom);
x[1] = complex_mult(neg2,complex_mult(s[1],denom));
x[2] = complex_mult(neg2,complex_mult(s[2],denom));
x[3] = complex_mult(complex_add(complex_mult(complex_add(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom);

y[0].real = x[0].real;
y[0].imag = x[0].imag;
y[1].real = x[1].real;
y[1].imag = x[1].imag;
y[2].real = x[2].real;
y[2].imag = x[2].imag;
y[3].real = x[3].real;
y[3].imag = x[3].imag;

return (y);

}

/*                                                                   */
/*--- Function s2z --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2z (s,z,rref)
COMPLEX *s;
COMPLEX *z;
double  rref;

{
COMPLEX one;
COMPLEX two;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(crref,complex_sub(complex_mult(complex_sub(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])));

x[0] = complex_mult(complex_add(complex_mult(complex_add(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom);
x[1] = complex_mult(two,complex_mult(s[1],denom));
x[2] = complex_mult(two,complex_mult(s[2],denom));
x[3] = complex_mult(complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom);

z[0].real = x[0].real;
z[0].imag = x[0].imag;
z[1].real = x[1].real;
z[1].imag = x[1].imag;
z[2].real = x[2].real;
z[2].imag = x[2].imag;
z[3].real = x[3].real;
z[3].imag = x[3].imag;

return (z);

}

/*                                                                   */
/*--- Function s2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *s2t (s,t)
COMPLEX *s;
COMPLEX *t;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,s[2]);

x[0] = complex_add(zero,denom);
x[1] = complex_sub(zero,complex_mult(s[3],denom));
x[2] = complex_mult(s[0],denom);
x[3] = complex_mult(complex_sub(complex_mult(s[1],s[2]),complex_mult(s[0],s[3])),denom);

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function s2abcd -----------------------------------------------*/
/*                                                                   */

COMPLEX *s2abcd (s,abcd,rref)
COMPLEX *s;
COMPLEX *abcd;
double  rref;

{
COMPLEX one;
COMPLEX two;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

denom = complex_div(one,complex_mult(two,s[2]));

x[0] = complex_mult(complex_add(complex_mult(complex_add(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom);
x[1] = complex_mult(complex_mult(complex_sub(complex_mult(complex_add(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom),crref);
x[2] = complex_div(complex_mult(complex_sub(complex_mult(complex_sub(one,s[0]),complex_sub(one,s[3])),complex_mult(s[1],s[2])),denom),crref);
x[3] = complex_mult(complex_add(complex_mult(complex_sub(one,s[0]),complex_add(one,s[3])),complex_mult(s[1],s[2])),denom);

abcd[0].real = x[0].real;
abcd[0].imag = x[0].imag;
abcd[1].real = x[1].real;
abcd[1].imag = x[1].imag;
abcd[2].real = x[2].real;
abcd[2].imag = x[2].imag;
abcd[3].real = x[3].real;
abcd[3].imag = x[3].imag;

return (abcd);

}

/*                                                                   */
/*--- Function y2h --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2h (y,h)
COMPLEX *y;
COMPLEX *h;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,y[0]);

x[0] = complex_add(zero,denom);
x[1] = complex_sub(zero,complex_mult(y[1],denom));
x[2] = complex_mult(y[2],denom);
x[3] = complex_mult(complex_sub(complex_mult(y[0],y[3]),complex_mult(y[1],y[2])),denom);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function y2z --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2z (y,z)
COMPLEX *y;
COMPLEX *z;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,complex_sub(complex_mult(y[0],y[3]),complex_mult(y[1],y[2])));

x[0] = complex_mult(y[3],denom);
x[1] = complex_sub(zero,complex_mult(y[1],denom));
x[2] = complex_sub(zero,complex_mult(y[2],denom));
x[3] = complex_mult(y[0],denom);

z[0].real = x[0].real;
z[0].imag = x[0].imag;
z[1].real = x[1].real;
z[1].imag = x[1].imag;
z[2].real = x[2].real;
z[2].imag = x[2].imag;
z[3].real = x[3].real;
z[3].imag = x[3].imag;

return (z);

}

/*                                                                   */
/*--- Function y2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2t (y,t,rref)
COMPLEX *y;
COMPLEX *t;
double  rref;

{
COMPLEX y11,y12,y21,y22;
COMPLEX one;
COMPLEX neg2;
COMPLEX zero;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

y11 = complex_mult(y[0],crref);
y12 = complex_mult(y[1],crref);
y21 = complex_mult(y[2],crref);
y22 = complex_mult(y[3],crref);

denom = complex_div(one,complex_mult(neg2,y21));

x[0] = complex_mult(complex_sub(complex_mult(complex_add(one,y11),complex_add(one,y22)),complex_mult(y12,y21)),denom);
x[1] = complex_sub(zero,complex_mult(complex_add(complex_mult(complex_add(one,y11),complex_sub(one,y22)),complex_mult(y12,y21)),denom));
x[2] = complex_mult(complex_add(complex_mult(complex_sub(one,y11),complex_add(one,y22)),complex_mult(y12,y21)),denom);
x[3] = complex_sub(zero,complex_mult(complex_sub(complex_mult(complex_sub(one,y11),complex_sub(one,y22)),complex_mult(y12,y21)),denom));

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function y2abcd -----------------------------------------------*/
/*                                                                   */

COMPLEX *y2abcd (y,abcd)
COMPLEX *y;
COMPLEX *abcd;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,y[2]);

x[0] = complex_sub(zero,complex_mult(y[3],denom));
x[1] = complex_sub(zero,denom);
x[2] = complex_mult(complex_sub(complex_mult(y[1],y[2]),complex_mult(y[0],y[3])),denom);
x[3] = complex_sub(zero,complex_mult(y[0],denom));

abcd[0].real = x[0].real;
abcd[0].imag = x[0].imag;
abcd[1].real = x[1].real;
abcd[1].imag = x[1].imag;
abcd[2].real = x[2].real;
abcd[2].imag = x[2].imag;
abcd[3].real = x[3].real;
abcd[3].imag = x[3].imag;

return (abcd);

}

/*                                                                   */
/*--- Function y2s --------------------------------------------------*/
/*                                                                   */

COMPLEX *y2s (y,s,rref)
COMPLEX *y;
COMPLEX *s;
double  rref;

{
COMPLEX y11,y12,y21,y22;
COMPLEX one;
COMPLEX neg2;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

neg2.real = (double) -2.0;
neg2.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

y11 = complex_mult(y[0],crref);
y12 = complex_mult(y[1],crref);
y21 = complex_mult(y[2],crref);
y22 = complex_mult(y[3],crref);

denom = complex_div(one,complex_sub(complex_mult(complex_add(one,y11),complex_add(one,y22)),complex_mult(y12,y21)));

x[0] = complex_mult(complex_add(complex_mult(complex_sub(one,y11),complex_add(one,y22)),complex_mult(y12,y21)),denom);
x[1] = complex_mult(neg2,complex_mult(y12,denom));
x[2] = complex_mult(neg2,complex_mult(y21,denom));
x[3] = complex_mult(complex_add(complex_mult(complex_add(one,y11),complex_sub(one,y22)),complex_mult(y12,y21)),denom);

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}

/*                                                                   */
/*--- Function z2h --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2h (z,h)
COMPLEX *z;
COMPLEX *h;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,z[3]);

x[0] = complex_mult(complex_sub(complex_mult(z[0],z[3]),complex_mult(z[1],z[2])),denom);
x[1] = complex_mult(z[1],denom);
x[2] = complex_sub(zero,complex_mult(z[2],denom));
x[3] = complex_add(zero,denom);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function z2y --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2y (z,y)
COMPLEX *z;
COMPLEX *y;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,complex_sub(complex_mult(z[0],z[3]),complex_mult(z[1],z[2])));

x[0] = complex_mult(z[3],denom);
x[1] = complex_sub(zero,complex_mult(z[1],denom));
x[2] = complex_sub(zero,complex_mult(z[2],denom));
x[3] = complex_mult(z[0],denom);

y[0].real = x[0].real;
y[0].imag = x[0].imag;
y[1].real = x[1].real;
y[1].imag = x[1].imag;
y[2].real = x[2].real;
y[2].imag = x[2].imag;
y[3].real = x[3].real;
y[3].imag = x[3].imag;

return (y);

}

/*                                                                   */
/*--- Function z2abcd -----------------------------------------------*/
/*                                                                   */

COMPLEX *z2abcd (z,abcd)
COMPLEX *z;
COMPLEX *abcd;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,z[2]);

x[0] = complex_mult(z[0],denom);
x[1] = complex_mult(complex_sub(complex_mult(z[0],z[3]),complex_mult(z[1],z[2])),denom);
x[2] = complex_add(zero,denom);
x[3] = complex_mult(z[3],denom);

abcd[0].real = x[0].real;
abcd[0].imag = x[0].imag;
abcd[1].real = x[1].real;
abcd[1].imag = x[1].imag;
abcd[2].real = x[2].real;
abcd[2].imag = x[2].imag;
abcd[3].real = x[3].real;
abcd[3].imag = x[3].imag;

return (abcd);

}

/*                                                                   */
/*--- Function z2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2t (z,t,rref)
COMPLEX *z;
COMPLEX *t;
double  rref;

{
COMPLEX z11,z12,z21,z22;
COMPLEX one;
COMPLEX two;
COMPLEX zero;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

z11 = complex_div(z[0],crref);
z12 = complex_div(z[1],crref);
z21 = complex_div(z[2],crref);
z22 = complex_div(z[3],crref);

denom = complex_div(one,complex_mult(two,z21));

x[0] = complex_mult(complex_sub(complex_mult(complex_add(z11,one),complex_add(z22,one)),complex_mult(z12,z21)),denom);
x[1] = complex_sub(zero,complex_mult(complex_sub(complex_mult(complex_add(z11,one),complex_sub(z22,one)),complex_mult(z12,z21)),denom));
x[2] = complex_mult(complex_sub(complex_mult(complex_sub(z11,one),complex_add(z22,one)),complex_mult(z12,z21)),denom);
x[3] = complex_sub(zero,complex_mult(complex_sub(complex_mult(complex_sub(z11,one),complex_sub(z22,one)),complex_mult(z12,z21)),denom));

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function z2s --------------------------------------------------*/
/*                                                                   */

COMPLEX *z2s (z,s,rref)
COMPLEX *z;
COMPLEX *s;
double  rref;

{
COMPLEX z11,z12,z21,z22;
COMPLEX one;
COMPLEX two;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

z11 = complex_div(z[0],crref);
z12 = complex_div(z[1],crref);
z21 = complex_div(z[2],crref);
z22 = complex_div(z[3],crref);

denom = complex_div(one,complex_sub(complex_mult(complex_add(z11,one),complex_add(z22,one)),complex_mult(z12,z21)));

x[0] = complex_mult(complex_sub(complex_mult(complex_sub(z11,one),complex_add(z22,one)),complex_mult(z12,z21)),denom);
x[1] = complex_mult(two,complex_mult(z12,denom));
x[2] = complex_mult(two,complex_mult(z21,denom));
x[3] = complex_mult(complex_sub(complex_mult(complex_add(z11,one),complex_sub(z22,one)),complex_mult(z12,z21)),denom);

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}

/*                                                                   */
/*--- Function abcd2h -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2h (abcd,h)
COMPLEX *abcd;
COMPLEX *h;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,abcd[3]);

x[0] = complex_mult(abcd[1],denom);
x[1] = complex_mult(complex_sub(complex_mult(abcd[0],abcd[3]),complex_mult(abcd[1],abcd[2])),denom);
x[2] = complex_sub(zero,denom);
x[3] = complex_mult(abcd[2],denom);

h[0].real = x[0].real;
h[0].imag = x[0].imag;
h[1].real = x[1].real;
h[1].imag = x[1].imag;
h[2].real = x[2].real;
h[2].imag = x[2].imag;
h[3].real = x[3].real;
h[3].imag = x[3].imag;

return (h);

}

/*                                                                   */
/*--- Function abcd2y -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2y (abcd,y)
COMPLEX *abcd;
COMPLEX *y;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,abcd[1]);

x[0] = complex_mult(abcd[3],denom);
x[1] = complex_mult(complex_sub(complex_mult(abcd[1],abcd[2]),complex_mult(abcd[0],abcd[3])),denom);
x[2] = complex_sub(zero,denom);
x[3] = complex_mult(abcd[0],denom);

y[0].real = x[0].real;
y[0].imag = x[0].imag;
y[1].real = x[1].real;
y[1].imag = x[1].imag;
y[2].real = x[2].real;
y[2].imag = x[2].imag;
y[3].real = x[3].real;
y[3].imag = x[3].imag;

return (y);

}

/*                                                                   */
/*--- Function abcd2z -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2z (abcd,z)
COMPLEX *abcd;
COMPLEX *z;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,abcd[2]);

x[0] = complex_mult(abcd[0],denom);
x[1] = complex_mult(complex_sub(complex_mult(abcd[0],abcd[3]),complex_mult(abcd[1],abcd[2])),denom);
x[2] = complex_add(zero,denom);
x[3] = complex_mult(abcd[3],denom);

z[0].real = x[0].real;
z[0].imag = x[0].imag;
z[1].real = x[1].real;
z[1].imag = x[1].imag;
z[2].real = x[2].real;
z[2].imag = x[2].imag;
z[3].real = x[3].real;
z[3].imag = x[3].imag;

return (z);

}

/*                                                                   */
/*--- Function abcd2t -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2t (abcd,t,rref)
COMPLEX *abcd;
COMPLEX *t;
double  rref;

{
COMPLEX a,b,c,d;
COMPLEX pt5;
COMPLEX zero;
COMPLEX crref;
COMPLEX x[4];

pt5.real = (double) 0.5;
pt5.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

a = complex_add(abcd[0],zero);
b = complex_div(abcd[1],crref);
c = complex_mult(abcd[2],crref);
d = complex_add(abcd[3],zero);

x[0] = complex_mult(pt5,complex_add(complex_add(a,b),complex_add(c,d)));
x[1] = complex_mult(pt5,complex_add(complex_sub(a,b),complex_sub(c,d)));
x[2] = complex_mult(pt5,complex_sub(complex_add(a,b),complex_add(c,d)));
x[3] = complex_mult(pt5,complex_sub(complex_sub(a,b),complex_sub(c,d)));

t[0].real = x[0].real;
t[0].imag = x[0].imag;
t[1].real = x[1].real;
t[1].imag = x[1].imag;
t[2].real = x[2].real;
t[2].imag = x[2].imag;
t[3].real = x[3].real;
t[3].imag = x[3].imag;

return (t);

}

/*                                                                   */
/*--- Function abcd2s -----------------------------------------------*/
/*                                                                   */

COMPLEX *abcd2s (abcd,s,rref)
COMPLEX *abcd;
COMPLEX *s;
double  rref;

{
COMPLEX a,b,c,d;
COMPLEX one;
COMPLEX two;
COMPLEX zero;
COMPLEX crref;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

two.real = (double) 2.0;
two.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

crref.real = rref;
crref.imag = (double) 0.0;

a = complex_add(abcd[0],zero);
b = complex_div(abcd[1],crref);
c = complex_mult(abcd[2],crref);
d = complex_add(abcd[3],zero);

denom = complex_div(one,complex_add(complex_add(a,b),complex_add(c,d)));

x[0] = complex_mult(complex_sub(complex_add(a,b),complex_add(c,d)),denom);
x[1] = complex_mult(two,complex_mult(complex_sub(complex_mult(a,d),complex_mult(b,c)),denom));
x[2] = complex_mult(two,denom);
x[3] = complex_mult(complex_sub(complex_sub(b,a),complex_sub(c,d)),denom);

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}

/*                                                                   */
/*--- Function s2t --------------------------------------------------*/
/*                                                                   */

COMPLEX *t2s (t,s)
COMPLEX *t;
COMPLEX *s;

{
COMPLEX one;
COMPLEX zero;
COMPLEX denom;
COMPLEX x[4];

one.real = (double) 1.0;
one.imag = (double) 0.0;

zero.real = (double) 0.0;
zero.imag = (double) 0.0;

denom = complex_div(one,t[0]);

x[0] = complex_mult(t[2],denom);
x[1] = complex_mult(complex_sub(complex_mult(t[0],t[3]),complex_mult(t[1],t[2])),denom);
x[2] = complex_add(zero,denom);
x[3] = complex_sub(zero,complex_mult(t[1],denom));

s[0].real = x[0].real;
s[0].imag = x[0].imag;
s[1].real = x[1].real;
s[1].imag = x[1].imag;
s[2].real = x[2].real;
s[2].imag = x[2].imag;
s[3].real = x[3].real;
s[3].imag = x[3].imag;

return (s);

}
