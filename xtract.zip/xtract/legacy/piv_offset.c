#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[])
   {
   double vgs_offset = 0.0;
   double vds_offset = 0.0;
   char string[256];
   char fname[256];
   char outname[256];
   double vgs,vds,igs,ids;
   FILE *infile,*outfile;
   unsigned index;
   
   printf ("Pulsed IV data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fname);
   
   printf ("Amount to offset Vgs (enter 0 for no offset)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &vgs_offset);
   
   printf ("Amount to offset Vds (enter 0 for no offset)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &vds_offset);
   
   printf ("Output file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", outname);
   
   infile = fopen (fname, "r");
   if (!infile)
      {
      printf ("** error ** unable to open file - %s\n", fname);
      return 1;
      }
   
   outfile = fopen (outname, "w+");
   if (!outfile)
      {
      printf ("** error ** unable to write to disk\n");
      fclose (infile);
      return 1;
      }
   
   while (fgets (string, 255, infile))
      {
      if (sscanf (string, "%lf%lf%lf%lf%d", &vgs, &vds, &ids, &igs, &index) == 5)
         fprintf (outfile, "\t%.5e\t%.5e\t%.5e\t%.5e\t%u\n", vgs+vgs_offset, vds+vds_offset, ids, igs, index);
      else
         fprintf (outfile, "%s", string);
      }
   
   fclose (infile);
   fclose (outfile);
   
   return 0;
   }


   
