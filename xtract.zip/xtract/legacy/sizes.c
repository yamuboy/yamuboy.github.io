#include <stdlib.h>
#include <stdio.h>

int main( int argc, char** argv )
   {
   printf( "char = %ld bytes\n", sizeof(char) );
   printf( "short = %ld bytes\n", sizeof(short) );
   printf( "int = %ld bytes\n", sizeof(int) );
   printf( "long = %ld bytes\n", sizeof(long) );
   printf( "float = %ld bytes\n", sizeof(float) );
   printf( "double = %ld bytes\n", sizeof(double) );
   printf( "long long = %ld bytes\n", sizeof(long long) );
   printf( "long double = %ld bytes\n", sizeof(long double) );
   printf( "void * = %ld bytes\n", sizeof(void*) );

   return 0;
   }
