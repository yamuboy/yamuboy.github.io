#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "jplot.h"

void re_fit (double *, double *, int, double *, double *, double *);

main (int argc, char *argv[])
   {
   int     i,device;
   char    file_name[80],out_name[80],string[256],ch;
   char    head1[2048],head2[2048],head3[512];
   double  t1,t2,re,intr,r2,xdata[2000],y1data[2000],y2data[2000],linex[2],liney[2];
   FILE    *infile;
   jPLOT_ITEM *plot1;

   file_name[0] = 0;
   out_name[0]  = 0;
   device = 0;

   // parse command line
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-h",2))
         {
         printf ("\nUSAGE: hbt_plot [-dA -h] [filename]\n----------------------------------------\n");
         printf ("      -dA   Sets a graphic device, where A is one of X, P, or M; indicating\n");
         printf ("               X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("      -h    Brings up this dialog.\n\n");
         return 0;
         }
      else if (!strncmp (argv[i],"-d",2))
         {
         sscanf (argv[i],"-d%c",&ch);
         if ((ch == 'X') || (ch == 'x'))
            device = 1;
         else if ((ch == 'M') || (ch == 'm'))
            device = 2;
         else if ((ch == 'P') || (ch == 'p'))
            device = 3;
         }
      else if (i == (argc-1))
         sscanf (argv[i],"%s",file_name);
      }

   if (!file_name[0])
      {
      printf ("Filename?\n> ");
      fgets (string,255,stdin);
      sscanf (string,"%79s",file_name);
      }
   else if (device < 1)
      device = 1;

   if (device < 1)
      {
      printf ("\nGraphics Device?\n 1: X-Windows\n 2: Metafile\n 3: Postscript\n\n> ");
      fgets (string,255,stdin);
      if (sscanf (string,"%lf%lf",&t1,&t2) == 2)
         {
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         fgets (string,255,stdin);
         sscanf (string,"%79s",out_name);
         fgets (string,255,stdin);
         i = 0;
         sscanf (string,"%d",&i);
         if (i == 10)
            device = 3;
         else if (i == 11)
            device = 1;
         else if (i == 12)
            device = 2;
         }
      else
         sscanf (string,"%d",&device);
      }

   if ((device < 1) || (device > 3))
      {
      printf ("INVALID GRAPHICS DEVICE.\n");
      return -1;
      }

   if ((device != 1) && !out_name[0])
      {
      printf ("Plot file name?\n> ");
      fgets (string,255,stdin);
      sscanf (string,"%79s",out_name);
      }

   infile = fopen (file_name,"r");
   if (!infile)
      {
      printf ("UNABLE TO OPEN FILE - %s\n",file_name);
      return -1;
      }

   if (!open_graphics_device (device,out_name))
      {
      printf ("%s\n",get_error_message (ERROR_NUMBER));
      fclose (infile);
      return -1;
      }

   plot1 = create_plot_item (SingleY,2.75,1.25,5.5,4.5);
   plot1->attribs.title_offset = 0.3;

   /*****************  HEADER  ******************/

   head1[0] = 0;
   for (i = 0; i < 8; ++i)
      {
      fgets (string,255,infile);
      strcat (head1,&string[1]);
      }

   add_text (head1,5.5,7.8,FNT_COURIER,10,0.0,CENTER_JUSTIFY,CLR_BLACK,0);

   /*****************  IV CURVES  ******************/
   
   while (fgets (string,255,infile))
      {
      if (strstr (string,"DC IV-CURVES"))
         {
         fgets (string,255,infile);
         fgets (string,255,infile);
         break;
         }
      }

   i = 0;
   while (fgets (string,255,infile))
      {
      if (string[0] == '!')
         break;

      if (sscanf (string,"%lf%lf%lf%lf",&xdata[i],&y1data[i],&t1,&t2) == 4)
         {
         y1data[i] *= 1000.0;
         ++i;
         }
      }

   if (i)
      {
      attach_y1data (plot1,xdata,y1data,i,LT_SOLID,1,CLR_RED);

      set_axis_scaling (plot1,POSITIVE_X | POSITIVE_Y1);

      set_axis_labels (plot1,"Vce (volts)","Ice (mA)",NULL,"I-V Curves");

      if (!draw_page ())
         {
         printf ("%s\n",get_error_message (ERROR_NUMBER));
         fclose (infile);
         return -1;
         }
      }
      
   /*****************  DONE PLOTS  ******************/

   close_graphics_device ();
   fclose (infile);

   return 0;
   }

/************************************************************************************/
/************************************************************************************/

void re_fit (double *x, double *y, int npts, double *re, double *intr, double *r2)
   {
   int    i;
   double xsum,ysum,xxsum,yysum,xysum;

   *re = *r2 = 0.0;

   if (npts < 5)
      return;

   xsum = ysum = xxsum = yysum = xysum = 0.0;
   for (i = npts-1; i > (npts-6); --i)
      {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
      }

   *r2  = (xysum*xysum)/(xxsum*yysum);
   *re  = (xysum*5.0 - xsum*ysum) / (xxsum*5.0 - xsum*xsum);
   *intr = (xxsum*ysum - xysum*xsum) / (xxsum*5.0 - xsum*xsum);
   *re *= 1.0e3;
   }




