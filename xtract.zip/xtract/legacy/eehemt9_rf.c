#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "optimize3.h"
#include "jplot.h"

#define OK            0
#define ERR           -1

#ifndef PI
#define PI            3.14159265359
#endif

#define BOLTZ         1.380066e-23
#define CHARGE        1.60218e-19
#define STDTEMP       300.0

#define NUM_PARAMS    37
#define MAX_IV_PTS    1500
#define MAX_BIAS_PTS  500

#define SUPPRESS_GRAPHS   1
#define USE_POSTSCRIPT    2
#define USE_METAFILE      4

/* -------- FUNCTION PROTOTYPES ---------- */

int get_starting_values (char *);
int fit_parasitics (char *, char *, double, double);
int get_iv_data (char *, int);
int plot_data (char *, char *, char *);
void write_output_files (char *, char *, char *);

double *ids_erf (double *);
double *gm_gds_vds0_erf (double *);
double *gm_gds_erf (double *);
double *cap_vds0_erf (double *);
double *cap_erf (double *);
double *ibr_erf (double *);
double *gds_erf (double *p_list);

void eehemt_ids_gm_gds (double *, double, double, double *, double *, double *, int);
void eehemt_capacitance (double *, double, double, double *, double *, double *, double *);
double eehemt_breakdown (double *, double, double);

double bubble_average (double *, int);
int diode_fit (double *, double *, int, double, double *, double *, double *);
int a_x_b (double *, double *, double *, int);
void find_min_max (double *, int, double *, double *);
double tanh_protect (double);
void tanh_integ_protect (double, double, double *, double *);

/* ---------- GLOBAL VARIABLES ----------- */

PARAM_STRUCT params[NUM_PARAMS];
double fixed_params[30];
double vgsiv[MAX_IV_PTS];
double vdsiv[MAX_IV_PTS];
double igsiv[MAX_IV_PTS];
double idsiv[MAX_IV_PTS];
double mvds[MAX_BIAS_PTS];
double mvgs[MAX_BIAS_PTS];
double xvds[MAX_BIAS_PTS];
double xvgs[MAX_BIAS_PTS];
double mids[MAX_BIAS_PTS];
double migs[MAX_BIAS_PTS];
double mcgs[MAX_BIAS_PTS];
double mcgd[MAX_BIAS_PTS];
double mgm[MAX_BIAS_PTS];
double mgds[MAX_BIAS_PTS];
double maximum_vds;
double area,ugw,Vds0;
int ngf;
int niter = 0;
int num_iv_pts,num_ac_iv_pts;
int option_flags = 0;

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*                                          MAIN                                           */
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

main (int argc, char *argv[])
   {
   int i,n,do_fits = 0;
   int ids_fit,gm_fit,cgs_fit,vbr_fit;
   double weights[5];
   double eff_gl,eff_dl,temp;
   double gm_weight,gds_weight;
   char model_summary_file[100];
   char start_file[100];
   char end_file[100];
   char model_file[100];
   char yfit_file[100];
   char iv_curve_file[100];
   char fwd_iv_file[100];
   char vbr_iv_file[100];
   char string[256];
   OPT_STRUCT  opt;
   
   /* parse command line */
   
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-h",2))
         {
         printf ("\n\nUSAGE: eehemt_fit [-s -h -in -da -fx]\n-------------------------------------------\n");
         printf ("  -s    Suppress graphics output.\n");
         printf ("  -h    Brings up this dialog.\n");
         printf ("  -in   Integer n sets the number of optimizer iterations (overrides stdin).\n");      
         printf ("  -da   Sets the graphics device, where a is one of \'X\' (default), \'P\', or \'M\',\n");      
         printf ("         which indicate X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("  -fx   Integer x sets the fits to perform (same as listed in stdout, overrides stdin)\n");
         printf ("\n\n");
         return 0;
         }
      else if (!strncmp (argv[i],"-s",2))
         option_flags |= SUPPRESS_GRAPHS;
      else if (!strncmp (argv[i],"-i",2))
         sscanf (argv[i],"-i%d",&niter);
      else if (!strncmp (argv[i],"-d",2))
         {
         sscanf (argv[i],"-d%s",string);
         if ((string[0] == 'p') || (string[0] == 'P'))
            option_flags |= USE_POSTSCRIPT;
         else if ((string[0] == 'm') || (string[0] == 'M'))
            option_flags |= USE_METAFILE;
         }
      else if (!strncmp (argv[i],"-f",2))
         sscanf (argv[i],"-f%d",&do_fits);
      }
   
   printf ("Number of gate fingers?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%d",&ngf);

   printf ("Unit gate width? (um)\n");
   fgets (string, 255, stdin);
   sscanf (string,"%lf",&ugw);

   printf ("Effective Gate and Drain Lengths? (um)\n");
   fgets (string, 255, stdin);
   sscanf (string,"%lf%lf",&eff_gl,&eff_dl);

   printf ("Maximum drain voltage for IV fit?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%lf",&maximum_vds);

   printf ("Drain voltage for Vds0?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%lf",&Vds0);

   printf ("Weights for Gm and Gds?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%lf%lf",&gm_weight,&gds_weight);

   printf ("Y-fit start file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",yfit_file);

   printf ("Model summary file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",model_summary_file);

   printf ("DC IV data file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",iv_curve_file);
   
   printf ("Forward IV data file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",fwd_iv_file);

   printf ("Breakdown IV data file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",vbr_iv_file);

   printf ("Start parameters file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string, 255, stdin);
   sscanf (string,"%99s",model_file);

   printf ("Maximum number of line searches?\n");
   fgets (string, 255, stdin);
   if (!niter)
      sscanf (string,"%d",&niter);

   printf ("Optimization fits to perform?\n");
   printf ("    1. All (default)\n    2. Ids only\n    3. Gm/Gds only\n    4. Capacitance only\n    5. Breakdown only\n\n");
   fgets (string, 255, stdin);
   if (!do_fits && !sscanf (string,"%d",&do_fits))
      do_fits = 1;
   
   switch (do_fits)
      {
      case 2:
         gm_fit = cgs_fit = vbr_fit = 0;
         ids_fit = 1;      
         break;
      case 3:
         ids_fit = cgs_fit = vbr_fit = 0;
         gm_fit = 1;
         break;
      case 4:
         ids_fit = gm_fit = vbr_fit = 0;
         cgs_fit = 1;
         break;
      case 5:
         ids_fit = gm_fit = cgs_fit = 0;
         vbr_fit = 1;
         break;
      default:
         ids_fit = gm_fit = cgs_fit = vbr_fit = 1;
         break;
      }
   
   area = ugw*((double) ngf);       
   
   /* read in and scale the starting values */
   if (get_starting_values (start_file) < 0)
      printf ("WARNING: in get_starting_values().\n");
   
   /**************** fit parasitics ************************/
   if (fit_parasitics (yfit_file,model_summary_file,eff_gl,eff_dl) < 0)
      {
      printf ("ERROR in fit_parasitics().\n");
      return -1;
      }
   
   /***************** DC IV curve fit *********************/
   
   printf ("Fitting DC IV curves.....\n");
   
   num_iv_pts = get_iv_data (iv_curve_file,0);
   if (num_iv_pts < 1)
      {
      printf ("ERROR in get_iv_data().\n");
      return (-1);
      }
   
   for (i = 0; i < 15; ++i)
      params[i].optimize = TRUE;
   
   initialize_optimizer (&opt, NUM_PARAMS, 1, weights, niter, &ids_erf);
   
   weights[0] = 1.0;
   opt.err_fraction = 1.0e-9;
   
   if (ids_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize().\n");
         return -1;
         }
      }
   printf ("Done.\n");
   
   /**************** AC parameter fit ***********************/
   
   printf ("Fitting transconductance @ Vds0 .....\n");
   
   opt.num_of_criteria = 1;
   weights[0] = 1.0;
   opt.function = &gm_gds_vds0_erf;
   
   for (i = 0; i < NUM_PARAMS; ++i)
      params[i].optimize = FALSE;
   for (i = 15; i < 25; ++i)
      params[i].optimize = TRUE;
   
   if (gm_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize().\n");
         return -1;
         }
      }
   
   printf ("Done.\n");
   
   printf ("Fitting transconductance vs. Vds .....\n");
   opt.function = &gm_gds_erf;
   
   params[15].optimize = FALSE;
   params[17].optimize = FALSE;
   params[20].optimize = FALSE;
   
   if (gm_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize().\n");
         return -1;
         }
      }
   printf ("Done.\n");

   printf ("Fitting Gds vs. Vds .....\n");
   opt.function = &gds_erf;
   
   for (i = 0; i < NUM_PARAMS; ++i)
      params[i].optimize = FALSE;
   
   params[12].optimize = TRUE;   
   params[22].optimize = TRUE;
   params[23].optimize = TRUE;
   params[24].optimize = TRUE;
   
   if (gm_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize().\n");
         return -1;
         }
      }
   printf ("Done.\n");
   
   /******************* C11 fit @ Vdso **********************/
   
   printf ("Fitting C11 @ Vds0.....\n");
   
   opt.num_of_criteria = 4;
   weights[0] = 1.0;
   weights[1] = 8.0;
   weights[2] = 8.0;
   weights[3] = 6.0;
   opt.err_fraction = 1.0e-8;
   opt.function = &cap_vds0_erf;
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      params[i].optimize = FALSE;
      }
   
   params[25].optimize = TRUE;  /* c11o */
   params[27].optimize = TRUE;  /* vinfl */
   params[28].optimize = TRUE;  /* deltgs */
   
   params[26].nom = params[26].max;
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] == Vds0)
         {
         temp = mcgs[i]+mcgd[i];
         if (temp < params[26].nom)
            {
            params[26].nom = temp;
            }
         }
      }
   
   if (cgs_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize().\n");
         return (-1); 
         }
      }
   printf ("Done.\n");
   
   params[25].optimize = FALSE;  /* c11o */
   params[27].optimize = FALSE;  /* vinfl */
   params[28].optimize = FALSE;  /* deltgs */
   
   /****************** C11 & C12 fit vs. Vds ********************/
   
   printf ("Fitting C11 and C12 vs. Vds.....\n");
   
   opt.err_fraction = 1.0e-6;
   opt.function = &cap_erf;
   
   params[29].optimize = TRUE;  /* deltds */
   params[30].optimize = TRUE;  /* lambda */
   params[31].optimize = TRUE;  /* c12sat */
   params[32].optimize = TRUE;  /* cgdsat */
   
   if (cgs_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize().\n");
         return -1; 
         }
      }
   printf ("Done.\n");
   
   /****************** diode fit ****************************/
   
   printf ("Fitting Forward IV curves.....\n");
   n = get_iv_data (fwd_iv_file,1);
   if (n < 3)
      {
      printf ("ERROR in get_iv_data() during diode fit.\n");
      return -1;
      }
   else
      {
      diode_fit (vgsiv,igsiv,n,area,&fixed_params[16],&fixed_params[17],&fixed_params[18]);
      fixed_params[16] *= 0.5;
      }
   printf ("Done.\n");
   
   /***************** breakdown fit **************************/
   
   printf ("Fitting Reverse Breakdown curves.....\n");
   num_iv_pts = get_iv_data (vbr_iv_file,2);
   if (num_iv_pts < 1)
      {
      printf ("ERROR in get_iv_data() during breakdown fit.\n");
      return -1;
      }
   
   opt.num_of_criteria = 1;
   weights[0] = 1.0;
   opt.function = &ibr_erf;
   
   for (i = 0; i < NUM_PARAMS; ++i)
      params[i].optimize = FALSE;
   
   params[33].optimize = TRUE;
   params[34].optimize = TRUE;
   params[35].optimize = TRUE;
   params[36].optimize = TRUE;
   
   if (vbr_fit)
      {
      if (cg_optimize (opt,params) < 0)
         {
         printf ("ERROR in cg_optimize():\n");
         return (-1);
         }
      }
   
   printf ("Done.\n");
   
   /******************* plot the data *************************/
   
   if (!(option_flags & SUPPRESS_GRAPHS))
      {
      plot_data (iv_curve_file,vbr_iv_file,fwd_iv_file);
      
      if (!(option_flags & USE_POSTSCRIPT))
         {
         option_flags |= USE_POSTSCRIPT;
         plot_data (iv_curve_file,vbr_iv_file,fwd_iv_file);
         }
      }
   
   /************** write the output files *********************/
   
   write_output_files (end_file,model_file,iv_curve_file);
   
   return 0;
}

/*******************************************************************************************/
/*******************************************************************************************/

int get_starting_values (char *fname)
   {
   FILE        *file1;
   char        string[201];
   double      inv_area;
   int         i;
   static int  p[] = {4,7,13,17,19,21,22,25,26,31,32,33,36};
   
   inv_area = 1.0/area;
   
   file1 = fopen (fname,"r");
   if (file1 == (FILE *) NULL)
      {
      printf ("ERROR: Unable to open starting values file - %s\n",fname);
      return -1;
      }
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (fgets (string,200,file1) == NULL)
         {
         printf ("ERROR: Incomplete starting values file - %s\n",fname);
         fclose (file1);
         return -1;
         }
      
      sscanf (string,"%lf %lf %lf %lf %s",&params[i].min,&params[i].nom,&params[i].max,
         &params[i].tol,params[i].name);
      strcpy (params[i].units,"");
      params[i].optimize = FALSE;
      
      if (params[i].min > params[i].max)
         {
         printf ("WARNING in parameter \"%s\": MIN is greater than MAX. Range reset.\n",params[i].name);
         params[i].max = params[i].min;
         }
      
      if (params[i].tol < 0.0)
         params[i].tol = -params[i].tol;
      }
   fclose (file1);
   
   /* check parameter ranges for validity */
   
   
   
   
   
   
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      else if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;
      }
   
   /* scale starting values */
   for (i = 0; i < 13; ++i)
      {
      params[p[i]].min *= area;
      params[p[i]].max *= area;
      params[p[i]].nom *= area;
      params[p[i]].tol *= area;
      }
   params[23].min *= inv_area; /* kdb */
   params[23].max *= inv_area;
   params[23].nom *= inv_area;
   params[23].tol *= inv_area;
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int fit_parasitics (char *yfit_file, char *mod_sum_file, double eff_gl, double eff_dl)
   {
   FILE     *file1;
   int      i,j,k;
   int      found;
   char     string[301];
   char     pname[80];
   double   Ri[MAX_BIAS_PTS];
   double   tau[MAX_BIAS_PTS];
   double   cds[MAX_BIAS_PTS];
   double   temp1[MAX_BIAS_PTS];
   double   temp2[MAX_BIAS_PTS];
   double   temp3[MAX_BIAS_PTS];
   double   Rd,Rg,Rs,ri,Ls,tmp;
   double   value,lpd,lpg;
   double   cpg,cpd,c11,c22;
   
   file1 = fopen (mod_sum_file,"r");
   if (file1 == (FILE *) NULL)
      {
      printf ("Unable to open model summary file - %s\n",mod_sum_file);
      return -1;
      }
   
   i = 0;
   while (fgets (string,300,file1) != NULL)
      {
      if (sscanf (&string[28],"%lf %lf %lf %lf %*f %*f %*f %*f %*f %lf %lf %lf %lf %*f %lf %lf %lf",
         &mvds[i],&mids[i],&mvgs[i],&migs[i],&Ri[i],&mgm[i],&tau[i],&mgds[i],
         &mcgs[i],&cds[i],&mcgd[i]) == 11)
         {
         if ((migs[i]*1.0e-3/area) < 5.0e-8)
            {
            migs[i] *= 1.0e-3;
            mids[i] *= 1.0e-3;
            mgm[i]  *= 1.0e-3;
            mgds[i] *= 1.0e-3;
            mcgs[i] *= 1.0e-12;
            mcgd[i] *= 1.0e-12;
            cds[i]  *= 1.0e-12;
            tau[i]  *= 1.0e-12;
            ++i;
            }
         }
      }
   fclose (file1);
   num_ac_iv_pts = i;
   
   file1 = fopen (yfit_file,"r");
   if (file1 == (FILE *) NULL)
      {
      printf ("Unable to open yfit file - %s\n",yfit_file);
      return -1;
      }
   
   found = 0;
   while (fgets (string,300,file1) != NULL)
      {
      if (sscanf (string,"%*f %lf %*f %*f %s",&value,pname) != 2)
         continue;
      
      if (!strcmp (pname,"C1"))
         {
         cpg = value;
         ++found;
         }
      else if (!strcmp (pname,"C2"))
         {
         cpd = value;
         ++found;
         }
      else if (!strcmp (pname,"C11"))
         {
         c11 = value;
         ++found;
         }
      else if (!strcmp (pname,"C22"))
         {
         c22 = value;
         ++found;
         }
      else if (!strcmp (pname,"B1"))
         {
         lpg = value;
         ++found;
         }
      else if (!strcmp (pname,"B2"))
         {
         lpd = value;
         ++found;
         }
      else if (!strcmp (pname,"RG"))
         {
         Rg = value;
         ++found;
         }
      else if (!strcmp (pname,"RD"))
         {
         Rd = value;
         ++found;
         }
      else if (!strcmp (pname,"RS"))
         {
         Rs = value;
         ++found;
         }
      else if (!strcmp (pname,"LS"))
         {
         Ls = value;
         ++found;
         }
      
      }
   fclose (file1);
   
   if (found != 10)
      {
      printf ("Yfit file problem.  Incorrect number of parameters found.\n");
      return -1;
      }
   
   fixed_params[0] = Rg;
   fixed_params[1] = Rd;
   fixed_params[2] = Rs;
   
   j = 0;
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] == Vds0)
         {
         temp1[j] = Ri[i];
         temp2[j] = cds[i];
         temp3[j] = tau[i];
         ++j;
         }
      }
   
   if (j < 5)
      {
      printf ("Not enough bias pts found matching Vds0 = %.2f volts\n",Vds0);
      return -1;
      }
   
   fixed_params[3] = fixed_params[4] = bubble_average (temp1,j);   // Ris and Rid are equal for symmetry
   fixed_params[5] = bubble_average (temp2,j);
   fixed_params[6] = bubble_average (temp3,j);
   
   fixed_params[7] = Ls;
   fixed_params[8] = cpg;
   fixed_params[9] = cpd;
   fixed_params[10] = c11;
   fixed_params[11] = c22;
   fixed_params[12] = lpg;
   fixed_params[13] = lpd;
   
   // both of these are no longer used
   fixed_params[14] = eff_gl;
   fixed_params[15] = eff_dl;
   
   /* dummy values for Rg, Rd and Rs */
   fixed_params[19] = 1.0e-6;
   fixed_params[20] = 1.0e-6;
   fixed_params[21] = 1.0e-6;
   
   fixed_params[19] = Rg;
   fixed_params[20] = Rd;
   fixed_params[21] = Rs;
   
   // sort the model summary data for ascending vgs then vds
   for (i = 0; i < (num_ac_iv_pts-1); ++i)
      {
      for (k = (i+1); k < num_ac_iv_pts; ++k)
         {
         if ((mvgs[k] < mvgs[i]) ||
            ((mvgs[k] == mvgs[i]) && (mvds[k] < mvds[i])))
            {
            tmp = mvgs[i];
            mvgs[i] = mvgs[k];
            mvgs[k] = tmp;
            
            tmp = mvds[i];
            mvds[i] = mvds[k];
            mvds[k] = tmp;
            
            tmp = migs[i];
            migs[i] = migs[k];
            migs[k] = tmp;
            
            tmp = mids[i];
            mids[i] = mids[k];
            mids[k] = tmp;
            
            tmp = mgm[i];
            mgm[i] = mgm[k];
            mgm[k] = tmp;
            
            tmp = mgds[i];
            mgds[i] = mgds[k];
            mgds[k] = tmp;
            
            tmp = mcgs[i];
            mcgs[i] = mcgs[k];
            mcgs[k] = tmp;
            
            tmp = mcgd[i];
            mcgd[i] = mcgd[k];
            mcgd[k] = tmp;
            }
         }
      }
   
   ri = fixed_params[3];
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      if (migs[i] >= 0.0)
         {
         xvgs[i] = mvgs[i] - migs[i]*(Rg+ri) - (mids[i]+migs[i])*Rs;
         xvds[i] = mvds[i] - (migs[i]+mids[i])*Rs - mids[i]*Rd;
         }
      else
         {
         xvgs[i] = mvgs[i] - migs[i]*(Rg+ri) - mids[i]*Rs;
         xvds[i] = mvds[i] - (mids[i]-migs[i])*Rd - mids[i]*Rs;
         }
      }
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int get_iv_data (char *fname, int mode)
   {
   FILE     *file1;
   char     string[201];
   int      i = 0;
   double   rs,rd,rg,ri;
   
   file1 = fopen (fname,"r");
   if (file1 == (FILE *) NULL)
      {
      printf ("Unable to open IV file - %s\n",fname);
      return -1;
      }
   
   rg = fixed_params[0];
   rd = fixed_params[1];
   rs = fixed_params[2];
   ri = fixed_params[3];
   
   while (fgets (string,200,file1) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf",&vdsiv[i],&idsiv[i],&vgsiv[i],&igsiv[i]) == 4)
         {
         switch (mode)
            {
            case 0:   /* DC IV file */
               if (((igsiv[i]/area) > 5.0e-8) || (vdsiv[i] > maximum_vds))
                  continue;
               
               if (igsiv[i] >= 0.0)
                  {
                  vdsiv[i] -= rd*idsiv[i] + rs*(igsiv[i]+idsiv[i]);
                  vgsiv[i] -= (rg+ri)*igsiv[i] + rs*(igsiv[i]+idsiv[i]);
                  }
               else
                  {
                  vdsiv[i] -= rd*(idsiv[i]-igsiv[i]) + rs*idsiv[i];
                  vgsiv[i] -= (rg+ri)*igsiv[i] + rs*idsiv[i];
                  }
               ++i;
               break;
               
            case 1:   /* forward IV file */
               if (vdsiv[i] != (double) 0.0)
                  continue;
               
               ++i;
               break;
               
            case 2:   /* breakdown IV file */
               vgsiv[i] = (vdsiv[i] - idsiv[i]*rd) - (vgsiv[i] - igsiv[i]*(rg+ri));
               igsiv[i] = -igsiv[i];
               ++i;
               break;
               
            default:
               break;
            }
         }
      }
   fclose (file1);
   
   return i;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int plot_data (char *iv_file, char *vbr_file, char *fwd_iv_file)
   {
   jPLOT_ITEM      *plot1,*plot2,*plot3;
   jHANDLE         thandle;
   int             i,j,n,pdevice;
   char            pname[100];
   double          p_list[NUM_PARAMS];
   double          x1data[MAX_IV_PTS];
   double          x2data[MAX_IV_PTS];
   double          y1data[MAX_IV_PTS];
   double          y2data[MAX_IV_PTS];
   double          y3data[MAX_IV_PTS];
   double          y4data[MAX_IV_PTS];
   double          cgs,cgd,cgst,cgdt,per_mm;
   double          ids,gm,gds,Is,vdiode,ndiode,rdiode;
   static char     *legend_t[] = {"Modeled","Measured"};
   static int      legend_l[] = {LT_SOLID,LT_DASHED};
   static int      legend_w[] = {1,1};
   static int      legend_c[] = {CLR_RED,CLR_BLUE};
   
   for (i = 0; i < NUM_PARAMS; ++i)
      p_list[i] = params[i].nom;
   
   per_mm = ((double) 1.0e3)/area;
   
   pdevice = X_WINDOWS;
   pname[0] = 0;
   if (option_flags & USE_POSTSCRIPT)
      {
      pdevice = POSTSCRIPT;
      strcpy (pname,"eehemt.ps");
      }
   else if (option_flags & USE_METAFILE)
      {
      pdevice = METAFILE;
      strcpy (pname,"eehemt.wmf");
      }
   
   if (!open_graphics_device (pdevice,pname))
      {
      printf ("open_graphics_device() failed\n");
      return -1;
      }
   
   plot1 = create_plot_item (SingleY,2.0,1.25,7.0,6.0);
   plot2 = create_plot_item (SingleY,1.25,1.25,3.5,3.0);
   plot3 = create_plot_item (SingleY,6.25,1.25,3.5,3.0);
   
   deactivate_plot_item (plot2);
   deactivate_plot_item (plot3);
   
   add_legend (2,9.0,7.75,legend_t,FNT_COURIER,12,legend_l,legend_w,legend_c);
   
   /************ plot IV curves ****************/
   
   n = get_iv_data (iv_file,0);
   
   for (i = 0; i < n; ++i)
      {
      x1data[i] = vdsiv[i];
      y2data[i] = idsiv[i]*per_mm*1.0e3;
      eehemt_ids_gm_gds (p_list,vgsiv[i],vdsiv[i],&ids,&gm,&gds,0);
      y1data[i] = ids*per_mm*1.0e3;
      }
   
   attach_y1data (plot1,x1data,y1data,n,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot1,"Vds (volts)","Ids (mA/mm)","","IV Curves");
   
   set_axis_scales (plot1,NULL,POSITIVE_X | POSITIVE_Y1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   detach_data (plot1);
   
   /************ plot c11 vs. vgs ****************/
   
   for (i = 0,j = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] == Vds0)
         {
         x1data[j] = xvgs[i];
         y2data[j] = (mcgs[i]+mcgd[i])*per_mm*1.0e12;
         eehemt_capacitance (p_list,xvgs[i],xvds[i],&cgs,&cgst,&cgd,&cgdt);
         y1data[j] = (cgs+cgd+cgst+cgdt)*per_mm*1.0e12;
         ++j;
         }
      }
   
   attach_y1data (plot1,x1data,y1data,j,LT_SOLID,1,CLR_RED);
   attach_y1data (plot1,x1data,y2data,j,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot1,"Vgs (volts)","C11 (pF/mm)","","Gate Capacitance");
   
   set_axis_scales (plot1,NULL,0);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   detach_data (plot1);
   deactivate_plot_item (plot1);
   
   /************ plot c11 and c12 ****************/
   
   activate_plot_item (plot2);
   activate_plot_item (plot3);
   
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      x1data[i] = mvds[i];
      y2data[i] = (mcgs[i]+mcgd[i])*per_mm*1.0e12;
      y4data[i] = mcgd[i]*per_mm*1.0e12;
      eehemt_capacitance (p_list,xvgs[i],xvds[i],&cgs,&cgst,&cgd,&cgdt);
      y1data[i] = (cgs+cgd+cgst+cgdt)*per_mm*1.0e12;
      y3data[i] = (cgd+cgst)*per_mm*1.0e12;
      }
   
   attach_y1data (plot2,x1data,y1data,num_ac_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot2,x1data,y2data,num_ac_iv_pts,LT_DASHED,1,CLR_BLUE);
   attach_y1data (plot3,x1data,y3data,num_ac_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot3,x1data,y4data,num_ac_iv_pts,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot2,"Vds (volts)","C11 (pF/mm)","","");
   set_axis_labels (plot3,"Vds (volts)","C12 (pF/mm)","","");
   
   thandle = adduser_text ("Gate Capacitance vs. Drain-Source Voltage",5.5,6.0,FNT_COURIER,18,0.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed\n");
      close_graphics_device ();
      return -1;
      }  
   
   remove_user_item (thandle);
   detach_data (plot2);
   detach_data (plot3);
   
   /************ plot gm and gds vs. Vgs ****************/
   
   for (i = 0,j = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] == Vds0)
         {
         x1data[j] = xvgs[i];
         y2data[j] = mgm[i]*per_mm*1.0e3;
         y4data[j] = mgds[i]*per_mm*1.0e3;
         eehemt_ids_gm_gds (p_list,xvgs[i],xvds[i],&ids,&gm,&gds,2);
         y1data[j] = gm*per_mm*1.0e3;
         y3data[j] = gds*per_mm*1.0e3;
         ++j;
         }
      }
   
   attach_y1data (plot2,x1data,y1data,j,LT_SOLID,1,CLR_RED);
   attach_y1data (plot2,x1data,y2data,j,LT_DASHED,1,CLR_BLUE);
   attach_y1data (plot3,x1data,y3data,j,LT_SOLID,1,CLR_RED);
   attach_y1data (plot3,x1data,y4data,j,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot2,"Vgs (volts)","Gm (mS/mm)","","");
   set_axis_labels (plot3,"Vgs (volts)","Gds (mS/mm)","","");
   
   thandle = adduser_text ("AC Transconductance and Drain Conductance",5.5,6.0,FNT_COURIER,18,0.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }  
   
   detach_data (plot2);
   detach_data (plot3);
   
   /************ plot gm and gds vs. Vgs ****************/
   
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      x1data[i] = xvds[i];
      y2data[i] = mgm[i]*per_mm*1.0e3;
      y4data[i] = mgds[i]*per_mm*1.0e3;
      eehemt_ids_gm_gds (p_list,xvgs[i],xvds[i],&ids,&gm,&gds,2);
      y1data[i] = gm*per_mm*1.0e3;
      y3data[i] = gds*per_mm*1.0e3;
      }
   
   attach_y1data (plot2,x1data,y1data,num_ac_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot2,x1data,y2data,num_ac_iv_pts,LT_DASHED,1,CLR_BLUE);
   attach_y1data (plot3,x1data,y3data,num_ac_iv_pts,LT_SOLID,1,CLR_RED);
   attach_y1data (plot3,x1data,y4data,num_ac_iv_pts,LT_DASHED,1,CLR_BLUE);
   
   set_axis_labels (plot2,"Vds (volts)","Gm (mS/mm)","","");
   set_axis_labels (plot3,"Vds (volts)","Gds (mS/mm)","","");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }  
   
   remove_user_item (thandle);
   detach_data (plot2);
   detach_data (plot3);
   
   /************ plot diode curves ****************/
   
   n = get_iv_data (fwd_iv_file,1);
   
   Is = fixed_params[16];
   ndiode = fixed_params[17];
   rdiode = fixed_params[18];
   
   for (i = 0; i < n; ++i)
      {
      vdiode = vgsiv[i]-igsiv[i]*rdiode;
      x1data[i] = vdiode;
      y2data[i] = igsiv[i]*per_mm*1.0e3;
      y1data[i] = per_mm*2.0e3*Is*(exp (vdiode*CHARGE/(BOLTZ*STDTEMP*ndiode)) - 1.0);
      }
   
   attach_y1data (plot2,x1data,y1data,n,LT_SOLID,1,CLR_RED);
   attach_y1data (plot2,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);
   
   n = get_iv_data (vbr_file,2);
   
   for (i = 0; i < n; ++i)
      {
      x2data[i] = vgsiv[i];
      y4data[i] = igsiv[i]*per_mm*1.0e3;
      y3data[i] = eehemt_breakdown (p_list,vgsiv[i],vdsiv[i])*per_mm*1.0e3;
      }
   
   attach_y1data (plot3,x2data,y4data,n,LT_DASHED,1,CLR_BLUE);
   attach_y1data (plot3,x2data,y3data,n,LT_SOLID,1,CLR_RED);
   
   thandle = adduser_text ("Gate Diode Forward and Reverse Conduction",5.5,6.0,FNT_COURIER,18,0.0,CENTER_JUSTIFY,CLR_BLACK,NO_STYLE);
   
   set_axis_labels (plot2,"Vgs (volts)","Igs (mA/mm)","","");
   set_axis_labels (plot3,"Vdg (volts)","Idg (mA/mm)","","");
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }  
   
   close_graphics_device ();
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

void write_output_files (char *end_file, char *mod_file, char *iv_file)
   {
   FILE       *file1,*file2;
   double     inv_area;
   int        i,j,k;
   static int p[] = {4,7,13,17,19,21,22,25,26,31,32,33,36,37};
   char       string[201];
   static char *names[] = {"Rg1","Rd1","Rs1","Ris","Rid","Cdso","Tau","Ls",
      "Cpg","Cpd","Cipg","Cipd","Lpg","Lpd","Effgl","Effdl",
      "Is","N","Rser","Rg","Rd","Rs"};
   
   inv_area = 1.0/area;
   
   file1 = fopen (mod_file,"w+");
   file2 = fopen (iv_file,"r");
   
   i = 0;
   while (++i < 31)
      {
      fgets (string,200,file2);
      if (!strncmp (string,"!Vbr (.1mA) ",12))
         {
         fprintf (file1,"%s",string);
         break;
         }
      
      fprintf (file1,"%s",string);
      }
   fgets (string,200,file2);
   fprintf (file1,"%s",string);
   fclose (file2);
   
   fprintf (file1,"!\n");
   fprintf (file1,"VAR model=1\n");
   fprintf (file1,"BEGIN BDTA\n");
   fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s\n","Ngf","Ugw","Kmod","Kver");
   fprintf (file1,"     %-11d     %+.4e     %-11d     %-11d\n",ngf,ugw,104,2);
   
   params[9].nom -= params[2].nom;
   
   i = 0;
   while (i < NUM_PARAMS)
      {
      fprintf (file1,"%%");
      k = i;
      for (j = 0; j < 6; ++j)
         {
         fprintf (file1,"     %-11s",params[i].name);
         ++i;
         if (i >= NUM_PARAMS)
            {
            break;
            }
         }
      fprintf (file1,"\n");
      i = k;
      for (j = 0; j < 6; ++j)
         {
         fprintf (file1,"     %+.4e",params[i].nom);
         ++i;
         if (i >= NUM_PARAMS)
            {
            break;
            }
         }
      fprintf (file1,"\n");   
      }
   
   params[9].nom += params[2].nom;
   
   fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
      names[0],names[1],names[2],names[3],names[4]);
   fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
      fixed_params[0],fixed_params[1],fixed_params[2],fixed_params[3],fixed_params[4]);
   
   fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
      names[7],names[8],names[9],names[10],names[11]);
   fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
      fixed_params[7],fixed_params[8],fixed_params[9],fixed_params[10],fixed_params[11]);
   
   fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
      names[12],names[13],names[14],names[15],names[16]);
   fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
      fixed_params[12],fixed_params[13],fixed_params[14],fixed_params[15],fixed_params[16]);
   
   fprintf (file1,"%%     %-11s     %-11s     %-11s     %-11s     %-11s\n",
      names[17],names[19],names[20],names[21],"Vdso");
   fprintf (file1,"     %+.4e     %+.4e     %+.4e     %+.4e     %+.4e\n",
      fixed_params[17],fixed_params[19],fixed_params[20],fixed_params[21],Vds0);
   
   fprintf (file1,"END BDTA\n");
   
   fclose (file1);
   
   // write finishing values file
   
   /* scale starting values */
   for (i = 0; i < 14; ++i)
      {
      params[p[i]].min *= inv_area;
      params[p[i]].max *= inv_area;
      params[p[i]].nom *= inv_area;
      params[p[i]].tol *= inv_area;
      }
   params[23].min *= area; /* kdb */
   params[23].max *= area;
   params[23].nom *= area;
   params[23].tol *= area;
   
   file1 = fopen (end_file,"w+");
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (file1,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (file1);
   }

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*                              OPTIMIZATION ERROR FUNCTIONS                               */
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

double *ids_erf (double *p_list)
   {
   int           i;
   double        ids,gm,gds;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      eehemt_ids_gm_gds (p_list,vgsiv[i],vdsiv[i],&ids,&gm,&gds,0);
      if ((fabs (vdsiv[i]) <= 2.0) && ((idsiv[i]/area) <= 0.1))
         error += pow (5000.0*(idsiv[i]-ids),2.0);
      else
         error += pow (1000.0*(idsiv[i]-ids), 2.0);
      }
   
   error /= ((double) num_iv_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *cap_vds0_erf (double *p_list)
   {
   int           i,j;
   double        cgs,cgst,cgd,cgdt;
   double        c11mod,c12mod,c11meas,c21mod;
   static double error[4];
   
   error[0] = error[1] = error[2] = error[3] = 0.0;
   for (i = 0,j = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] == Vds0)
         {
         eehemt_capacitance (p_list,xvgs[i],xvds[i],&cgs,&cgst,&cgd,&cgdt);
         c11mod = cgs+cgd+cgst+cgdt;
         c12mod = cgd+cgst;
         c21mod = cgd+cgdt;
         c11meas = mcgs[i]+mcgd[i];
         error[0] += pow (1.0e12*(c11mod-c11meas),2.0);
         error[1] += pow (1.0e12*(c12mod-mcgd[i]),2.0);
         error[2] += pow (1.0e12*(c21mod-mcgd[i]),2.0);
         error[3] += pow (1.0e12*(cgd-mcgd[i]),2.0);
         ++j;
         }
      }
   
   if (j == 0)
      j = 1;
   
   error[0] /= ((double) j);
   error[1] /= ((double) j);
   error[2] /= ((double) j);
   error[3] /= ((double) j);
   
   return error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *cap_erf (double *p_list)
   {
   int           i;
   double        cgs,cgst,cgd,cgdt;
   double        c11mod,c12mod,c11meas,c21mod;
   static double error[4];
   
   error[0] = error[1] = error[2] = error[3] = 0.0;
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      eehemt_capacitance (p_list,xvgs[i],xvds[i],&cgs,&cgst,&cgd,&cgdt);
      c11mod = cgs+cgd+cgst+cgdt;
      c12mod = cgd+cgst;
      c21mod = cgd+cgdt;
      c11meas = mcgs[i]+mcgd[i];
      error[0] += pow (1.0e12*(c11mod-c11meas),2.0);
      error[1] += pow (1.0e12*(c12mod-mcgd[i]),2.0);
      error[2] += pow (1.0e12*(c21mod-mcgd[i]),2.0);
      error[3] += pow (1.0e12*(cgd-mcgd[i]),2.0);
      }
   
   error[0] /= ((double) num_ac_iv_pts);
   error[1] /= ((double) num_ac_iv_pts);
   error[2] /= ((double) num_ac_iv_pts);
   error[3] /= ((double) num_ac_iv_pts);
   
   return error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *gm_gds_erf (double *p_list)
   {
   int           i;
   double        ids,gm,gds,sf;
   static double error[3];
   
   error[0] = error[1] = error[2] = 0.0;
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] >= 1.5)
         sf = (double) 1.0;
      else
         sf = (double) 0.5;
      
      eehemt_ids_gm_gds (p_list,xvgs[i],xvds[i],&ids,&gm,&gds,1);
      error[0] += pow (1.0e3*(gm-mgm[i]),2.0);
      error[1] += pow (1.0e3*(gds-mgds[i]),2.0);
      error[2] += pow (1.0e3*((xvgs[i]*mgm[i]+xvds[i]*mgds[i])-(xvgs[i]*gm+xvds[i]*gds)),2.0); 
      }
   
   error[0] /= ((double) num_ac_iv_pts);
   error[1] /= ((double) num_ac_iv_pts);
   error[2] /= ((double) num_ac_iv_pts);
   
   return error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *gm_gds_vds0_erf (double *p_list)
   {
   int           i,j;
   double        ids,gm,gds;
   static double error[3];
   
   error[0] = error[1] = error[2] = 0.0;
   for (i = 0,j = 0; i < num_ac_iv_pts; ++i)
      {
      if (mvds[i] == Vds0)
         {
         eehemt_ids_gm_gds (p_list,xvgs[i],xvds[i],&ids,&gm,&gds,1);
         error[0] += pow (1.0e3*(gm-mgm[i]),2.0);
         error[1] += pow (1.0e3*(gds-mgds[i]),2.0);
         error[2] += pow (1.0e3*((xvgs[i]*mgm[i]+xvds[i]*mgds[i])-(xvgs[i]*gm+xvds[i]*gds)),2.0);
         ++j;
         }
      }
   
   if (j == 0)
      {
      j = 1;
      }
   
   error[0] /= ((double) j);
   error[1] /= ((double) j);
   error[2] /= ((double) j);
   
   return error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *gds_erf (double *p_list)
   {
   int           i;
   double        ids,gm,gds,sf;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_ac_iv_pts; ++i)
      {
      eehemt_ids_gm_gds (p_list,xvgs[i],xvds[i],&ids,&gm,&gds,1);
      error += pow (1.0e3*(gds-mgds[i]),2.0);
      }
   
   error /= (double) num_ac_iv_pts;
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *ibr_erf (double *p_list)
   {
   int           i;
   double        igs,vgd;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      vgd = vgsiv[i]-vdsiv[i];
      igs = eehemt_breakdown (p_list,vgsiv[i],vdsiv[i]);
      error += pow (1000.0*(igsiv[i]-igs),2.0)*tanh (3.0e6/area*igsiv[i]);
      }
   
   error /= ((double) num_iv_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*                                 EEHEMT1 MODEL FUNCTIONS                                 */
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

// this function was taken from the Agilent eefet3 source code

void eehemt_ids_gm_gds (double *p_list, double Vgs, double Vds, double *pIds, double *pGm, double *pGds, int mode)
   {
   double vt,vg,alpha,tanhfunc,sech2;
   double gmo,ids1,gds1,dvd,dv,arg,cosarg,sinarg;
   double gmgs,stuff,gdso,idso;
   double pdiss,denom,facdc;
   double arg2,ratio,vts,vjx;
   double va,vb,vc,dv2,alpha2,dvo,dvj,v1;
   double idvb,gmvb,gdvb,svb,a,b,vgb;
   double gdsp,idbp,sqrterm;

   // need to set these
   double Vto, vtso_par, gmmax_par, gamma_par, kapa_par, peff_par;
   double vto_par, deltgm_par, vdelt_par, gmoff_par;
   double Vsat, Vdso, Vch, Vgo, Vco, Mu, Vbc, Vba, Alpha;
   double Svbp, Gmvbp, Idvbp, Gdvbp;
   double Gdbm, Vdsm, Kdb;

   Vto        = p_list[0];
   vto_par    = mode ? p_list[15] : p_list[0];
   gamma_par  = mode ? p_list[16] : p_list[1];
   Vgo        = p_list[2];
   Vch        = p_list[3];
   gmmax_par  = mode ? p_list[17] : p_list[4];
   Vsat       = p_list[5];
   kapa_par   = mode ? p_list[18] : p_list[6];
   peff_par   = mode ? p_list[19] : p_list[7];
   vtso_par   = mode ? p_list[20] : p_list[8];
   Vco        = p_list[9] + p_list[2];
   Vba        = p_list[10];
   Vbc        = p_list[11];
   Mu         = p_list[12];
   deltgm_par = mode ? p_list[21] : p_list[13];
   Alpha      = p_list[14];
   vdelt_par  = (double) 0.0;
   Vdso       = Vds0;
   Gdbm       = p_list[22];
   Kdb        = p_list[23];
   Vdsm       = p_list[24];

   if (Vco >= Vgo)
      gmoff_par = gmmax_par;
   else if (Vco <= Vto)
      gmoff_par = 0.0;
   else
      {
      dvd = Vto - Vgo;
      dv = Vco - Vgo;
      arg = PI*dv/dvd;
      cosarg = cos(arg);
      gmoff_par = gmmax_par*(cosarg + 1.0)*0.5;
      }
   dv2 = Vbc*Vbc;
   alpha2 = Alpha*Alpha;
   dvd = sqrt(dv2 + alpha2);
   Svbp = Vbc/dvd;
   Gmvbp = dvd - Alpha;
   Idvbp = (Vbc*dvd + alpha2*log((Vbc+dvd)/Alpha))*0.5 - Alpha*Vbc;
   Gdvbp = 0.5*Mu*((2.0*dv2 + alpha2)/dvd + (1.0 + Vbc/dvd)*alpha2/(Vbc + dvd)) - Alpha*Mu;
   
#define EPS  1.0e-6
   
   alpha = 3.0 / Vsat;        /* current saturation constant    */
   tanhfunc = tanh_protect(alpha * Vds); 
   sech2 = 1.0 - tanhfunc*tanhfunc; 
   
   dvo = Vdso - Vds;
   dvj = 1.0 + gamma_par*dvo;
   /* don't let dvj go to 0 (used in denominator later on) */
   if (dvj < EPS)
      dvj = EPS;
   
   vt = (vto_par-Vch)/dvj + Vch;
   vts = (vtso_par-Vch)/dvj + Vch;
   
   /* if junction voltage is below threshold onset,  and */
   /* vtso > vto evaluate equations at vts.              */
   if ((Vgs < vts) && (vtso_par > vto_par))
      vjx = vts;
   else
      vjx = Vgs;
   
   vg = (Vgo-Vch)/dvj + Vch;
   v1 = (vjx - Vch)*dvj;
   vgb = ((Vgo - vdelt_par) - Vch)/dvj + Vch;
   
   if (vjx >= vg) /* fix transconductance at vjx = vgo */
      { 
      gmgs = gmmax_par*dvj;
      ids1 = gmmax_par*(v1 - (Vgo + vto_par)*0.5 + Vch); 
      gds1 = (-gmmax_par)*gamma_par*(vjx - Vch);
      }
   else if (vjx <= vt) /* fix current at 0 (where transconductance is 0) */
      {
      gmgs = 0.0;
      ids1 = 0.0;
      gds1 = 0.0;
      }
   else           /* ((vjx > vt) && (vjx < vg)) */
      {
      dvd = vto_par - Vgo;    
      dv = v1 - (Vgo-Vch);     
      arg = PI*dv/dvd;
      cosarg = cos(arg);
      sinarg = sin(arg);
      gmgs = gmmax_par*dvj*(cosarg + 1)*0.5; 
      stuff = dvd*sinarg/PI + v1 - (vto_par - Vch);
      ids1 = gmmax_par*stuff*0.5;
      gds1 = (-gmmax_par)*gamma_par*(vjx - Vch)*(cosarg + 1.0)*0.5;
      }
   
      vc = Vco + Mu*dvo; 
      vb = Vbc + vc;
      va = vb - Vba;
      
      if (vjx > vc) /* transconductance compression at vjx = vc val (peak val) */
         { 
         if (vjx < vb)
            {
            dv = vjx-vc;
            dv2 = dv*dv;
            alpha2 = Alpha*Alpha;
            dvd = sqrt(dv2+alpha2);
            gmgs += deltgm_par*(Alpha - dvd);
            ids1 += deltgm_par*(Alpha*dv - 
               (dv*dvd + alpha2*log((dv+dvd)/Alpha))/2);
            gds1 += deltgm_par*(Alpha*Mu - 
               (Mu/2)*((2*dv2+alpha2)/dvd + (1+dv/dvd)
               *alpha2/(dv+dvd)));
            }
         else /* (vjx > vb) */
            {
            svb =  deltgm_par*Svbp;
            gmvb = deltgm_par*Gmvbp;
            idvb = deltgm_par*Idvbp;
            gdvb = deltgm_par*Gdvbp;    
            
            dv = Vba;
            b = svb*dv/(gmvb-gmoff_par);
            if (fabs(b + 1.0) > EPS)
               {
               a = (gmvb-gmoff_par)/pow(dv,b);
               gmgs -= a*pow((vjx - va),b) + gmoff_par;
               ids1 -= a*(pow((vjx - va),b+1) - pow(dv,b+1))/(b+1) + gmoff_par*
                  (vjx - vb) + idvb;
               gds1 -= Mu*a*pow((vjx - va),b) + Mu * gmoff_par +
                  gdvb;
               }
            else
               {
               a = (gmvb-gmoff_par)*dv;
               gmgs -= a/(vjx - va) + gmoff_par;
               ids1 -= a*(log(vjx - va) - log(dv)) + gmoff_par*(vjx - vb) + idvb;
               gds1 -= Mu*a/(vjx - va) + Mu*gmoff_par + gdvb;
               }
            }
         }

   /* If junction voltage drops below onset of subthreshold (vts), current  */ 
   /* and conductances are modified to decay exponentially from their value */
   /* at Vgs = vts.                                                          */
   
   if (ids1 > 0.0)
      {
      ratio = gmgs / ids1;
      /* if Vgs is below onset of subthreshold, and ratio isn't negative */
      /* and vtso <= vto, modify expressions. */
      if ((Vgs < vts) && (vtso_par > vto_par) && (ratio > 0.0) )
         {
         arg2 = -ratio * (vts - Vgs);
         if (arg2 < -70.0)
            arg2 = -70.0;
         ids1 *= exp(arg2);
         gmgs *= exp(arg2);
         gds1 *= exp(arg2); 
         }
      } 
   
   /* Added output conductance terms to I-V equations */
   
   dv = 1.0 + kapa_par*Vds;
   gmo = gmgs*dv;
   gdso = gds1*dv + ids1*kapa_par;
   idso = ids1*dv;
   
   gmo = gmo*tanhfunc; 
   gdso = gdso*tanhfunc + idso*sech2*alpha; 
   idso = idso*tanhfunc;
   
   /* The quantities idso, gmo, and gdso defined above account for the       */
   /* "basic" drain current model outlined in section 2.1.1 of tm910060.doc. */
   /* The negative resistance effect is added below.                         */

   if (mode == 2)
      {
      *pIds = idso;
      *pGm = gmo;
      *pGds = gdso;
      return;
      }
   
   pdiss = Vds * idso;
   denom = 1 + pdiss/peff_par;
   facdc = 1 / (denom*denom); 
   *pIds = idso / denom; /* dc drain current with "negative resistance" effect */
   *pGm = gmo * facdc;
   *pGds = (gdso - idso*idso / peff_par) * facdc;

    /* Dispersion Source Vds  current. */
   if (mode)
      {
      if ((Vds > Vdsm) && (Kdb != 0.0))
         { 
         arg = Vds - Vdsm;
         gdsp = Gdbm / (Gdbm*Kdb*arg*arg + 1.0);
         sqrterm = sqrt(Kdb*Gdbm);
         idbp = sqrterm*atan(arg*sqrterm)/Kdb + Gdbm*Vdsm;
         }
      else if ((Vds < -Vdsm) && (Kdb != 0.0))
         {
         arg = Vds + Vdsm;
         gdsp = Gdbm / ( Gdbm*Kdb*arg*arg + 1.0 );
         sqrterm = sqrt(Kdb*Gdbm);
         idbp = sqrterm*atan(arg*sqrterm)/Kdb - Gdbm*Vdsm;
         }
      else    /* -Vdsm <= Vds <= Vdsm or Kdb = 0.0 */
         {
         gdsp = Gdbm;
         idbp = Gdbm * Vds;
         }
      *pIds += idbp;
      *pGds += gdsp;
      }

   return;
   }

/*******************************************************************************************/
/*******************************************************************************************/

// this function was taken from the agilent eefet3 source code

void eehemt_capacitance (double *p_list, double Vgc, double Vyc, double *pCgc, double *pdQgc_dVgy, 
                         double *pCgy, double *pdQgy_dVgc)
   {
   // variables
   double Vgy,sqrterm,vjx,vo,dvjxdvds,dvodvds;
   double f2vds,tanhgs,inttanhgs,fvgs,intfvgs;
   double qjo,gvds,gpvds,qj,dv;
   double cjx,co,cjo,alpha,tanhfunc,f1,f2;
   double df1dvgc,df1dvgy,df2dvgc,df2dvgy;
   double cggy,cggc,qterm;
   
   // need to be set
   double Vinfl,Deltds,Deltgs,C11o,C11th;
   double C12sat,Lambda,Cgdsat,Vdso;

   // dummy return variables
   double tmp1,tmp2;
   double *pQgc = &tmp1;
   double *pQgy = &tmp2;

   Vdso    = Vds0;
   C11o    = p_list[25];
   C11th   = p_list[26];
   Vinfl   = p_list[27];
   Deltgs  = p_list[28];
   Deltds  = p_list[29];
   Lambda  = p_list[30];
   C12sat  = p_list[31];
   Cgdsat  = p_list[32];
   
//   Vyc = Vgc - Vgy;
   Vgy = Vgc - Vyc;

   sqrterm = sqrt(Vyc*Vyc + Deltds*Deltds);
   vjx = 0.5*(2.0*Vgc - Vyc + sqrterm);
   vo = sqrterm;
   dvjxdvds = 0.5*(Vyc/sqrterm - 1.0);
   dvodvds = Vyc/sqrterm;
   dv = vjx - Vinfl;
   f2vds = 1 + Lambda*(vo - Vdso);
   
   tanh_integ_protect(3.0/Deltgs, dv, &tanhgs, &inttanhgs);
   
   fvgs = 1 + tanhgs;
   intfvgs = dv + inttanhgs;
   
   qjo = (C11o - C11th)*0.5*intfvgs + C11th*dv;
   gvds = -C12sat*vo;
   gpvds = -C12sat;
   qj = qjo*f2vds + gvds;
   
   cjx = ( (C11o - C11th)*0.5*fvgs + C11th )*f2vds;
   co = qjo*Lambda + gpvds;
   cjo = cjx*dvjxdvds + co*dvodvds;
   
   alpha = 3.0 / Deltds;
   vo = Vgc - Vgy;
   
   tanhfunc = tanh_protect( alpha*vo );
   
   /* smoothing functions */
   f1 = 0.5*(1.0 + tanhfunc);
   f2 = 0.5*(1.0 - tanhfunc);
   
   /* derivatives of smoothing functions wrt vgc and vgy */
   df1dvgc = 0.5*alpha*(1.0 - tanhfunc*tanhfunc);
   df1dvgy = -df1dvgc;
   df2dvgc = -0.5*alpha*(1.0 - tanhfunc*tanhfunc);
   df2dvgy = -df2dvgc;
   
   /* apply chain rule to convert derivatives to functions of Vgc, Vgy */
   cggy = -cjo;
   cggc = cjx + cjo;
   
   /* gate drain charge and its derivatives */
   qterm = qj - Cgdsat*Vgc;
   *pQgy = Cgdsat*Vgy*f1 + qterm*f2;
   *pCgy = Cgdsat*(Vgy*df1dvgy + f1) + qterm*df2dvgy + f2*cggy;
   *pdQgy_dVgc = Cgdsat*Vgy*df1dvgc + qterm*df2dvgc + f2*(cggc - Cgdsat);
   
   /* gate source charge and its derivatives */
   qterm = qj - Cgdsat*Vgy;
   *pQgc = qterm*f1 + Cgdsat*Vgc*f2;
   *pCgc = qterm*df1dvgc + f1*cggc + Cgdsat*(Vgc*df2dvgc + f2);
   *pdQgc_dVgy = qterm*df1dvgy + f1*(cggy - Cgdsat) + Cgdsat*Vgc*df2dvgy;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double eehemt_breakdown (double *p_list, double Vdg, double Vds)
   {
   double    kbk,idsoc,vbr,nbr;
   double    Vgs,ids,gm,gds;
   
   kbk   = p_list[33];
   vbr   = p_list[34];
   nbr   = p_list[35];
   idsoc = p_list[36];
   
   Vgs = Vds - Vdg;
   
   if (Vdg <= vbr)
      return 0.0;
   else
      {
      eehemt_ids_gm_gds (p_list,Vgs,Vds,&ids,&gm,&gds,0);
      return kbk*(1.0 - ids/idsoc) * pow((Vdg-vbr),nbr);
      }
   }

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*                                      UTILITIES                                          */
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

double bubble_average (double *values, int n)
   {
   int     i,j;
   double  temp;
   double  delta;
   
   if (n < 1)
      return 0.0;
   else if (n < 2)
      return values[0];
   else if (n < 3)
      return 0.5*(values[0]+values[1]);
   
   for (i = 0; i < n-1; ++i)
      {
      for (j = i+1; j < n; ++j)
         {
         if (values[j] < values[i])
            {
            temp = values[i];
            values[i] = values[j];
            values[j] = temp;
            }
         }
      }
   
   i = 0;
   temp = (double) 0.0;
   delta = fabs (values[n/2])*((double) 0.25);
   for (j = 0; j < n; ++j)
      {
      if (fabs (values[j]-values[n/2]) < delta)
         {
         ++i;
         temp += values[j];
         }
      }
   temp = temp/((double) i);
   
   return temp;
   }


/*******************************************************************************************/
/*******************************************************************************************/

int diode_fit (double *vd, double *id, int k, double darea, double *is, double *n, double *rd)
   {
   double   a1[3][MAX_IV_PTS];
   double   a2[MAX_IV_PTS][3];
   double   b1[MAX_IV_PTS];
   double   a[3][3];
   double   b[3];
   double   x[3];
   double   sum;
   int      i,j;
   int      npts;
   
   j = 0;
   for (i = 0; i < k; ++i)
      {
      if ((vd[i] <= 0.0) || (id[i] <= (1.0e-9*darea)))
         continue;
      
      a2[j][0] = log (id[i]);
      a2[j][1] = -1.0;
      a2[j][2] = id[i];
      a1[0][j] = a2[j][0];
      a1[1][j] = a2[j][1];
      a1[2][j] = a2[j][2];
      b1[j] = vd[i];
      ++j;
      }
   
   if (j < 3)
      {
      fprintf (stderr,"Not enough points for diode fit.\n");
      return -1;
      }
   
   npts = j;
   
   for (i = 0; i < 3; ++i)
      {
      for (j = 0; j < 3; ++j)
         {
         sum = 0.0;
         for (k = 0; k < npts; ++k)
            sum += a1[i][k]*a2[k][j];
         
         a[i][j] = sum;
         }
      }
   
   for (i = 0; i < 3; ++i)
      {
      sum = 0.0;
      for (j = 0; j < npts; ++j)
         sum += a1[i][j]*b1[j];
      
      b[i] = sum;
      }
   
   if (a_x_b ((double *) a,x,b,3) < 0)
      {
      fprintf (stderr,"Singular matrix in diode fit.\n");
      return -1;
      }
   
   *n = x[0]*CHARGE/(BOLTZ*STDTEMP);
   *is = exp (x[1]/x[0]);
   *rd = x[2];
   
   return 0;
   }


/*******************************************************************************************/
/*******************************************************************************************/

int a_x_b (double *a, double *x, double *b, int n)
   {
   double   y[50];
   double   z[50][50];
   double   tempd;
   double   tempd2;
   double   max;
   int      pointer[50];
   int      tempi;
   int      i,j,k;
   int      col,row;
   
   
   
   for (i = 0; i < n; ++i)
      {
      y[i] = b[i];
      pointer[i] = i;
      for (j = 0; j < n; ++j)
         z[i][j] = a[i*n+j];
      }
   
   /* invert the matrix */
   for (k = 0; k < n-1; ++k)
      {
      /* find max */
      max = 0.0;
      for (i = k; i < n; ++i)
         {
         for (j = k; j < n; ++j)
            {
            if (fabs (z[i][j]) > max)
               {
               row = i;
               col = j;
               max = fabs (z[i][j]);
               }
            }
         }
      
      /* rotate rows */
      if (row != k)
         {
         for (j = 0; j < n; ++j)
            {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
            }
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
         }
      
      /* rotate columns */ 
      if (col != k)
         {
         for (i = 0; i < n; ++i)
            {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
            }
         tempi = pointer[k];
         pointer[k] = pointer[col];
         pointer[col] = tempi;
         }
      
      /* gaussian elimination */
      tempd = z[k][k];
      for (i = k+1; i < n; ++i)
         {
         tempd2 = z[i][k]/tempd;
         y[i] -= tempd2*y[k];
         for (j = k; j < n; ++j)
            {
            z[i][j] -= tempd2*z[k][j];
            }
         }
      }  
   
   if (fabs (z[n-1][n-1]) < 1.0e-24)
      return -1;
   
   /* back substitution */
   x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
   for (k = n-2; k > -1; --k)
      {
      tempd = y[k];
      for (i = n-1; i > k; --i)
         tempd -= z[k][i]*x[pointer[i]];
      
      x[pointer[k]] = tempd/z[k][k];
      }
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double tanh_protect (double arg)
   {
   if (arg < -70.0)
      return -1.0;
   else if (arg > 70.0)
      return 1.0;
   else
      return tanh(arg);
   }

/*******************************************************************************************/
/*******************************************************************************************/

void tanh_integ_protect (double alpha, double voltage, double *tanhfunc, double *integral)
   {
   double vlin, tanhsqr;
   double varg, integ_at_vlin;
   double tanharg, sech2arg, logcosh;
   
#define MAXARG   12.0
   
   vlin = MAXARG/alpha;
   if ((voltage >= -vlin) && (voltage <= vlin) )
      {
      *tanhfunc = tanh(alpha*voltage);
      tanhsqr = (*tanhfunc)*(*tanhfunc);
      *integral = -0.5*log(1.0 - tanhsqr) / alpha;
      }
   else if (voltage > vlin)
      {
      tanharg = tanh(MAXARG);
      sech2arg = 1.0 - tanharg*tanharg;
      logcosh = -0.5*log(sech2arg);
      varg = voltage - vlin;
      integ_at_vlin = logcosh / alpha;
      *tanhfunc = alpha*sech2arg*varg + tanharg;
      *integral = alpha*sech2arg*varg*varg / 2.0 + tanharg*varg + integ_at_vlin;
      }
   else /* voltage < -vlin */
      {
      tanharg = tanh(MAXARG);
      sech2arg = 1.0 - tanharg*tanharg;
      logcosh = -0.5*log(sech2arg);
      varg = voltage + vlin;
      integ_at_vlin = logcosh / alpha;
      *tanhfunc = alpha*sech2arg*varg - tanharg;
      *integral = alpha*sech2arg*varg*varg / 2.0 - tanharg*varg + integ_at_vlin;
      }   
   }

/*******************************************************************************************/
/*******************************************************************************************/
