#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

char *get_function ();

struct _meta_functions
 {
 unsigned int num;
 char *name;
 };

struct _meta_functions meta1[] = 
{
 {0x0201,"SET BACKGROUND COLOR"},
 {0x0102,"sET BACKGROUND MODE"},
 {0x0103,"SET MAPPING MODE"},
 {0x0104,"SET ROP2"},
 {0x0209,"SET TEXT COLOR"},
 {0x0108,"SET TEXT CHARACTER EXTRA"},
 {0x020B,"SET WINDOW ORIGIN"},
 {0x020C,"SET WINDOW EXTENTS"},
 {0x020D,"SET VIEWPORT ORIGIN"},
 {0x020E,"SET VIEWPORT EXTENTS"},
 {0x0213,"LINE TO"},
 {0x0214,"MOVE TO"},
 {0x0817,"ARC"},
 {0x0418,"ELLIPSE"},
 {0x0419,"FLOOD FILL"},
 {0x081A,"PIE"},
 {0x041B,"RECTANGLE"},
 {0x061C,"ROUND RECTANGLE"},
 {0x061D,"PATTERN/ROP2 COMBINE MODE"},
 {0x041F,"SET PIXEL"},
 {0x0324,"POLYGON"},
 {0x0325,"POLYLINE"},
 {0x0626,"ESCAPE!!!"},
 {0x0228,"FILL REGION"},
 {0x0429,"FRAME REGION"},
 {0x012A,"INVERT REGION"},
 {0x012B,"PAINT REGION"},
 {0x012C,"SELECT CLIP REGION"},
 {0x012D,"SELECT OBJECT"},
 {0x012E,"SET TEXT ALIGN"},
 {0x0830,"CHORD"},
 {0x0231,"SET MAPPER FLAGS"},
 {0x0521,"TEXT OUT"},
 {0x0A32,"EXTENDED TEXT OUT"},
 {0x0538,"POLY POLYGON"},
 {0x0940,"DIB BITBLT"},
 {0x0548,"EXTENDED FLOOD FILL"},
 {0x01F0,"DELELE OBJECT"},
 {0x02FA,"CREATE PEN INDIRECT"},
 {0x02FB,"CREATE FONT INDIRECT"},
 {0x02FC,"CREATE BRUSH INDIRECT"},
 {0x06FF,"CREATE REGION"},
 {0x020A,"SET TEXT JUSTIFICATION"}
};

#define num_functions          (43)

char *unknown_f = "UNKNOWN META FUNCTION";

main ()

{
unsigned long  size0,size1,size2,size3;
unsigned long  rec_size;
unsigned long  file_pos;
unsigned int   byte0,byte1;
unsigned int   value;
long int       i,j;
FILE           *in_file,*out_file;
char           in_name[81],out_name[90];

printf ("WMF file to parse > ");
scanf ("%80s",in_name);

sscanf (in_name,"%[^.]",out_name);
strcat (out_name,".dat");

in_file = (FILE *) NULL;
in_file = fopen (in_name,"r");
if (in_file == (FILE *) NULL)
   {
   printf ("ERROR: could not open file - %s\n",in_name);
   exit (0);
   }

out_file = fopen (out_name,"w+");

for (i = 0L; i < 20L; ++i)
   {
   byte0 = fgetc (in_file);
   byte1 = fgetc (in_file);

   value = byte0 | (byte1 << 8);
   fprintf (out_file,"%x\n",value);
   }
fprintf (out_file,"\n");

j = 0L;
file_pos = 40L;

while ((rec_size != 3L) && (j < 20000L)) 
   {
   fseek (in_file,file_pos,0);

   size0 = (long) fgetc (in_file);
   size1 = (long) fgetc (in_file);
   size2 = (long) fgetc (in_file);
   size3 = (long) fgetc (in_file);

   rec_size = size0 | (size1 << 8) | (size2 << 16) | (size3 << 24);
   file_pos += rec_size*2;

   fprintf (out_file,"%ld\n",rec_size);

   byte0 = fgetc (in_file);
   byte1 = fgetc (in_file);

   value = byte0 | (byte1 << 8);

   fprintf (out_file,"%x - %s\n",value,get_function (value));

   for (i = 0L; i < (rec_size-3L); ++i)
      {
      byte0 = fgetc (in_file);
      byte1 = fgetc (in_file);

      value = byte0 | (byte1 << 8);
      fprintf (out_file,"%x\n",value);
      if (++j > 20000L)
         {
         break;
         }
      }
   fprintf (out_file,"\n");
   }

fclose (in_file);
fclose (out_file);

return (0);
}


/*********************************************/

char *get_function (value)
unsigned int value;

{
int i;

for (i = 0; i < num_functions; ++i)
   {
   if (value == meta1[i].num)
      {
      return (meta1[i].name);
      }
   }

return (unknown_f);
}
