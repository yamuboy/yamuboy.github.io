#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "microwave_utilities.h"

main ()
{
POLAR s[4];
COMPLEX s_rect[4];
COMPLEX s_abcd[4];
COMPLEX temp;

s[0].mag = (double) 0.3;
s[0].ang = (double) 100.0;
s[1].mag = (double) 2.0;
s[1].ang = (double) 10.0;
s[2].mag = (double) 0.01;
s[2].ang = (double) 25.0;
s[3].mag = (double) 0.8;
s[3].ang = (double) 75.0;

printf ("original polar:\n");
printf ("%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n",s[0].mag,s[0].ang,s[1].mag,s[1].ang,
         s[2].mag,s[2].ang,s[3].mag,s[3].ang);

polar_2x2_rect (s,s_rect);

printf ("rectangular:\n");
printf ("%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n",s_rect[0].real,s_rect[0].imag,s_rect[1].real,s_rect[1].imag,
         s_rect[2].real,s_rect[2].imag,s_rect[3].real,s_rect[3].imag);

temp.real = s_rect[2].real;
temp.imag = s_rect[2].imag;
s_rect[2].real = s_rect[1].real;
s_rect[2].imag = s_rect[1].imag;
s_rect[1].real = temp.real;
s_rect[1].imag = temp.imag;

s2abcd (s_rect,s_abcd,(double) 50.0);

printf ("abcd:\n");
printf ("%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n",s_abcd[0].real,s_abcd[0].imag,s_abcd[2].real,s_abcd[2].imag,
         s_abcd[1].real,s_abcd[1].imag,s_abcd[3].real,s_abcd[3].imag);

abcd2s (s_abcd,s_rect,(double) 50.0);

temp.real = s_rect[2].real;
temp.imag = s_rect[2].imag;
s_rect[2].real = s_rect[1].real;
s_rect[2].imag = s_rect[1].imag;
s_rect[1].real = temp.real;
s_rect[1].imag = temp.imag;

printf ("back to rectangular:\n");
printf ("%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n",s_rect[0].real,s_rect[0].imag,s_rect[1].real,s_rect[1].imag,
         s_rect[2].real,s_rect[2].imag,s_rect[3].real,s_rect[3].imag);

rect_2x2_polar (s_rect,s);

printf ("back to polar:\n");
printf ("%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n",s[0].mag,s[0].ang,s[1].mag,s[1].ang,
         s[2].mag,s[2].ang,s[3].mag,s[3].ang);

}
