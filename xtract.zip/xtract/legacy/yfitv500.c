#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "cmplxlib.h"
#include "fit_tools.h"

#define NUM_PARAMS   20
#define MAX_FREQS    500
#define ERROR_FILE_NAME  "batch_error_file.txt"

typedef struct
   {
   double min,nom,max,tol;
   char name[20];
   } PARAMS;

typedef struct
   {
   double vds,vgs,ids,igs;
   } BIAS;

static int get_intrinsic_y_params (char *s_file, char *starting_vals, COMPLEX y[][4], double *freq, unsigned sz_y,
                                   PARAMS *p, BIAS *bias, unsigned *n, char *error);
static int perform_y_fit (COMPLEX y[][4], double *freq, unsigned szy, PARAMS *p, BIAS bias, int use_t2, int batch, char *error);
static void ggs_ggd_fit (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                         double gm, double t1, double gds, double t2, double cds, double *ggs, double *ggd);
static void ggs_fit (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                     double gm, double t1, double gds, double t2, double cds, double *ggs);
static void ggd_fit (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                     double gm, double t1, double gds, double t2, double cds, double *ggd);
static void log_error (char *err_msg, char *fname);

/******************************************************************************************/
/******************************************************************************************/

int main (int argc, char *argv[])
   {
   char string[256];
   char file_name[256];
   char starting_vals[256];
   char finishing_vals[256];
   char error[256];
   char *err_file = NULL;
   unsigned i,szy;
   double flist[MAX_FREQS];
   COMPLEX yparms[MAX_FREQS][4];
   FILE *file;
   PARAMS parms[NUM_PARAMS];
   BIAS bias;
   int use_t2 = 0;
   int batch_mode = 0;
   
   // parse the command line
   for (i = 1; i < argc; ++i)
      {
      if (!strcmp (argv[i], "-t2"))
         use_t2 = 1;
      else if (!strcmp (argv[i], "-b"))
         batch_mode = 1;
      }
   
   if (batch_mode)
      err_file = ERROR_FILE_NAME;

   if (!batch_mode)
      printf ("File to Y-Fit?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", file_name);

   if (!batch_mode)
      printf ("Starting values file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", starting_vals);

   if (!batch_mode)
      printf ("Finishing values file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", finishing_vals);

   // read in the S-params and starting values, deembed the fixed parasitics

   if (get_intrinsic_y_params (file_name, starting_vals, yparms, flist, MAX_FREQS, parms, &bias, &szy, error))
      {
      log_error (error, err_file);
      return -1;
      }

   // do the y-fit

   if (perform_y_fit (yparms, flist, szy, parms, bias, use_t2, batch_mode, error))
      {
      log_error (error, err_file);
      return -1;
      }

   // write the final parameter values

   file = fopen (finishing_vals, "w+");
   if (!file)
      {
      log_error ("Error writing final parameter values.\n", err_file);
      return -1;
      }

   for (i = 0; i < NUM_PARAMS; ++i)
      fprintf (file, "%12.4e %12.4e %12.4e %12.4e %s\n", parms[i].min, parms[i].nom, parms[i].max, parms[i].tol, parms[i].name);

   fclose (file);
   
   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int get_intrinsic_y_params (char *s_file, char *starting_vals, COMPLEX y[][4], double *freq, unsigned sz_y,
                                   PARAMS *p, BIAS *bias, unsigned *n, char *error)
   {
   FILE *file;
   unsigned i = 0;
   unsigned j = 0;
   char string[256];
   int db_mode = 0;
   int ri_mode = 0;
   double fmult = 1.0;
   double ref_imp = 50.0;
   double w,rg,rd,rs,b1,b2;
   double ls,c1,c2,c11,c22;
   COMPLEX s_ri[4],z[4];
   POLAR s_ma[4];

   // read in the starting values

   file = fopen (starting_vals, "r");
   if (!file)
      {
      sprintf (error, "Unable to open starting values file.");
      return -1;
      }

   while (fgets (string, 255, file))
      {
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (i >= NUM_PARAMS)
         break;

      if (sscanf (string, "%lf%lf%lf%lf%19s", &p[i].min, &p[i].nom, &p[i].max, &p[i].tol, p[i].name) == 5)
         ++i;
      }

   fclose (file);

   if (i != NUM_PARAMS)
      {
      sprintf (error, "Incomplete starting values file.");
      return -1;
      }

   // read in the S-parameters

   file = fopen (s_file, "r");
   if (!file)
      {
      sprintf (error, "Unable to open measured data file.");
      return -1;
      }

   *n = 0;
   bias->vds = bias->vgs = bias->ids = bias->igs = 0.0;
   while (fgets (string, 255, file))
      {
      if (!strncmp (string, "!BIAS", 5))
         sscanf (string, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf", &bias->vds, &bias->ids, &bias->vgs, &bias->igs);
      else if (string[0] == '!')
         continue;
      else if (string[0] == '#')
         {
         // convert to lowercase
         for (i = 0; i < strlen (string); ++i)
            if ((string[i] >= 65) && (string[i] <= 90))
               string[i] += (char) 32;

         // check for frequency units
         if (strstr (string, "ghz"))
            fmult = 1.0e9;
         else if (strstr (string, "mhz"))
            fmult = 1.0e6;
         else if (strstr (string, "khz"))
            fmult = 1.0e3;

         // check for data type
         if (strstr (string, "ri"))
            ri_mode = 1;
         else if (strstr (string, "db"))
            db_mode = 1;

         // get the reference impedance
         sscanf (string, "#%*s%*s%*s%*s%lf", &ref_imp);
         }

      if (j >= sz_y)
         break;

      if (ri_mode)
         {
         if (sscanf (string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &freq[j], &s_ri[0].r, &s_ri[0].i,
            &s_ri[2].r, &s_ri[2].i, &s_ri[1].r, &s_ri[1].i, &s_ri[3].r, &s_ri[3].i) == 9)
            {
            s2y (s_ri, y[j], ref_imp);
            freq[j] *= fmult;
            ++j;
            }
         }
      else
         {
         if (sscanf (string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &freq[j], &s_ma[0].m, &s_ma[0].a,
            &s_ma[2].m, &s_ma[2].a, &s_ma[1].m, &s_ma[1].a, &s_ma[3].m, &s_ma[3].a) == 9)
            {
            if (db_mode)
               {
               s_ma[0].m = pow (10.0, s_ma[0].m*0.05);
               s_ma[1].m = pow (10.0, s_ma[1].m*0.05);
               s_ma[2].m = pow (10.0, s_ma[2].m*0.05);
               s_ma[3].m = pow (10.0, s_ma[3].m*0.05);
               }

            PA2CA (s_ma, s_ri, 2, 2);
            s2y (s_ri, y[j], ref_imp);
            freq[j] *= fmult;
            ++j;
            }
         }
      }

   fclose (file);

   if (!j)
      {
      sprintf (error, "Nothing in measured data file.");
      return -1;
      }

   *n = j;

   // remove the fixed parasitics

   rg = p[0].nom;
   rd = p[2].nom;
   rs = p[1].nom;
   b1 = p[10].nom;
   b2 = p[11].nom;
   ls = p[9].nom;
   c1 = p[7].nom;
   c2 = p[8].nom;
   c11 = p[18].nom;
   c22 = p[19].nom;

   for (i = 0; i < *n; ++i)
      {
      w = 2.0 * acos (-1.0) * freq[i];

      // remove C1 and C2
      y[i][0].i -= w * c1;
      y[i][3].i -= w * c2;

      // remove B1 and B2
      y2z (y[i], z);
      z[0].i -= w * b1;
      z[3].i -= w * b2;

      // remove C11 and C22
      z2y (z, y[i]);
      y[i][0].i -= w * c11;
      y[i][3].i -= w * c22;

      // remove RG, RD, RS, and LS
      y2z (y[i], z);
      z[0] = Csub (z[0], Cnum (rg + rs, w * ls));
      z[1] = Csub (z[1], Cnum (rs, w * ls));
      z[2] = Csub (z[2], Cnum (rs, w * ls));
      z[3] = Csub (z[3], Cnum (rd + rs, w * ls));
      z2y (z, y[i]);
      }

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static int perform_y_fit (COMPLEX y[][4], double *freq, unsigned szy, PARAMS *p, BIAS bias, int use_t2,
                          int batch_mode, char *error)
   {
   double w,cgs,cgd,cds,gds;
   double ggs,ggd,ri,gm,t1,t2;
   double fmin1,fmin2,fmin3;
   double fmax1,fmax2,fmax3;
   double wl[MAX_FREQS];
   double cgsl[MAX_FREQS];
   double cgdl[MAX_FREQS];
   double cdsl[MAX_FREQS];
   double gml[MAX_FREQS];
   double gdsl[MAX_FREQS];
   double ril[MAX_FREQS];
   double t1l[MAX_FREQS];
   double s11l[MAX_FREQS];
   double tmpd,x1,x2,x3,x4,rval;
   char string[256];
   unsigned i,n;
   COMPLEX x,s[4];

   // print the values of direct parameter extraction to the terminal

   if (!batch_mode)
      {
      printf ("\n");
      printf (" Freq   Cgs     Gds    Cds    Cgd     Ri      Gm      T1      Ggd\n");
      printf (" (GHz)  (pF)    (mS)   (pF)   (pF)   (ohm)    (mS)    (ps)    (mS)\n");
      printf ("-------------------------------------------------------------------\n");
      //       |    | |    | |     | |    | |    | |     | |     | |     | |     |
 
      for (i = 0; i < szy; ++i)
         {
         w = 2.0 * acos (-1.0) * freq[i];

         cgs = -1.0 / (w * Cimag (Cdiv (Complex (1.0), Cadd (y[i][0], y[i][1]))));
         gds = y[i][3].r + y[i][1].r;
         cds = (y[i][3].i + y[i][1].i) / w;
         cgd = -y[i][1].i / w;
         ggd = -y[i][1].r;
         ri = Creal (Cdiv (Complex (1.0), Cadd (y[i][0], y[i][1])));
         x = Cdiv (Csub (y[i][2], y[i][1]), Cadd (y[i][0], y[i][1]));
         x = Cmult (x, Cnum (0.0, w * cgs));
         gm = Cmag (x);
         t1 = -atan2 (x.i, x.r) / w;

         printf ("%6.3f %6.3f %7.2f %6.3f %6.3f %7.3f %7.2f %7.2f %7.2f\n",
            freq[i]*1.0e-9, cgs*1.0e12, gds*1.0e3, cds*1.0e12,
            cgd*1.0e12, ri, gm*1.0e3, t1*1.0e12, ggd*1.0e3);
         }

      printf ("\n");
      }

   // get frequency ranges

   if (!batch_mode)
      printf ("Frequency range for Cgs, Cgd, Cds, Gm and Gds calculations in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fmin1, &fmax1) != 2)
      {
      sprintf (error, "Failed to read frequency range.");
      return -1;
      }
   fmin1 *= 1.0e9;
   fmax1 *= 1.0e9;

   if (!batch_mode)
      printf ("Frequency range for Ri and Tau calculations in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fmin2, &fmax2) != 2)
      {
      sprintf (error, "Failed to read frequency range.");
      return -1;
      }
   fmin2 *= 1.0e9;
   fmax2 *= 1.0e9;

   if (!batch_mode)
      printf ("Frequency range for Ggs and Ggd calculations in GHz (min max)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf%lf", &fmin3, &fmax3) != 2)
      {
      sprintf (error, "Failed to read frequency range.");
      return -1;
      }
   fmin3 *= 1.0e9;
   fmax3 *= 1.0e9;

   // do y-fit on cgs, cgd, cds, gm, and gds

   for (i = 0, n = 0; i < szy; ++i)
      {
      if (freq[i] < fmin1)
         continue;
      else if (freq[i] > fmax1)
         break;

      wl[n] = 2.0 * acos (-1.0) * freq[i];
      cgdl[n] = -y[i][1].i;
      cdsl[n] = y[i][3].i + y[i][1].i;
      x = Cdiv (Cadd (y[i][0], y[i][1]), Csub (y[i][2], y[i][1]));
      cgsl[n] = Cmag (x);
      gdsl[n] = (y[i][3].r + y[i][1].r)*wl[n];
      tmpd = Cmag2 (Csub (y[i][2], y[i][1]));
      x1 += tmpd;
      x2 += tmpd*tmpd * wl[n]*wl[n]*wl[n]*wl[n];
      x3 += tmpd * wl[n]*wl[n];
      x4 += tmpd*tmpd * wl[n]*wl[n];
      ++n;
      }

   gm = sqrt (fabs (x1*x2 - x3*x4) / (((double) n)*x2 - x3*x3));
   linefit_mx0 (wl, cgdl, n, &cgd, &rval);
   linefit_mx0 (wl, cgsl, n, &cgs, &rval);
   linefit_mx0 (wl, cdsl, n, &cds, &rval);
   linefit_mx0 (wl, gdsl, n, &gds, &rval);
   cgs *= gm;

   if (gm < 1.0e-6)
      gm = 0.0;
   if (cgd < 0.0)
      cgd = 0.0;
   if (cgs < 0.0)
      cgs = 0.0;
   if (cds < 0.0)
      cds = 0.0;
   if (gds < 0.0)
      gds = 0.0;

   // do y-fit on ri and tau

   for (i = 0, n = 0; i < szy; ++i)
      {
      if (freq[i] < fmin2)
         continue;
      else if (freq[i] > fmax2)
         break;

      wl[n] = 2.0 * acos (-1.0) * freq[i];
      ril[n] = Creal (Cdiv (Complex (1.0), Cadd (y[i][0], y[i][1]))) * wl[n];
      x1 = -1.0/(wl[n] * Cimag (Cdiv (Complex (1.0), Cadd (y[i][0], y[i][1]))));
      x = Cmult (Cdiv (Csub (y[i][2], y[i][1]), Cadd (y[i][0], y[i][1])), Cnum (0.0, wl[n] * x1));
      t1l[n] = -atan2 (x.i, x.r);
      ++n;
      }

   linefit_mx0 (wl, ril, n, &ri, &rval);
   if (bias.vds <= 0.1)
      t1 = 0.0;
   else
      linefit_mx0 (wl, t1l, n, &t1, &rval);

   if (ri < 1.0e-3)
      ri = 1.0e-3;
   if ((t1 < 0.0) || (gm < 1.0e-6))
      t1 = 0.0;

   if (use_t2)
      t2 = t1;
   else
      t2 = 0.0;

   // do y-fit on ggs and ggd

   for (i = 0, n = 0; i < szy; ++i)
      {
      if (freq[i] < fmin3)
         continue;
      else if (freq[i] > fmax3)
         break;

      wl[n] = 2.0 * acos (-1.0) * freq[i];
      y2s (y[i], s, 50.0);
      s11l[n] = Cmag (s[0]);
      ++n;
      }

   ggs = ggd = 0.0;
   if (fabs (bias.vds) <= 0.1)
      {
      ggs_ggd_fit (wl, s11l, n, cgs, ri, cgd, gm, t1, gds, t2, cds, &ggs, &ggd);

      p[12].min = 0.0;
      p[12].nom = ggs;
      p[12].max = ggs*5.0;
      if (p[12].max < 1e-4)
         p[12].max = 1e-4;

      p[13].min = 0.0;
      p[13].nom = ggd;
      p[13].max = ggd*5.0;
      if (p[13].max < 1e-4)
         p[13].max = 1e-4;
      }

   else if (bias.igs > 0.0)
      {
      ggs_fit (wl, s11l, n, cgs, ri, cgd, gm, t1, gds, t2, cds, &ggs);
      
      p[12].min = 0.0;
      p[12].nom = ggs;
      p[12].max = ggs*5.0;
      if (p[12].max < 1e-4)
         p[12].max = 1e-4;
      
      p[13].min = 0.0;
      p[13].nom = 0.0;
      p[13].max = 0.0;
      }
   else
      {
      ggd_fit (wl, s11l, n, cgs, ri, cgd, gm, t1, gds, t2, cds, &ggd);
      
      p[13].min = 0.0;
      p[13].nom = ggd;
      p[13].max = ggd*5.0;
      if (p[13].max < 1e-4)
         p[13].max = 1e-4;
      
      p[12].min = 0.0;
      p[12].nom = 0.0;
      p[12].max = 0.0;
      }

   if (ggs < 0.0)
      ggs = 0.0;
   if (ggd < 0.0)
      ggd = 0.0;

   // set ranges for optimization

   p[3].min = ri*0.2;
   p[3].nom = ri;
   p[3].max = ri*4.0;
   if (p[3].max < 15.0)
      p[3].max = 15.0;

   p[4].min = 0.0;
   p[4].nom = cgs;
   p[4].max = cgs*4.0;
   if (p[4].max < 2e-12)
      p[4].max = 2e-12;

   p[5].min = 0.0;
   p[5].nom = cgd;
   p[5].max = cgd*4.0;
   if (p[5].max < 2e-12)
      p[5].max = 2e-12;

   p[6].min = 0.0;
   p[6].nom = cds;
   p[6].max = cds*4.0;
   if (p[6].max < 2e-12)
      p[6].max = 2e-12;

   p[14].min = 0.0;
   p[14].nom = gm;
   p[14].max = gm*4.0;
   if (p[14].max < 1e-4)
      p[14].max = 1e-4;

   p[15].min = 0.0;
   p[15].nom = t1;
   p[15].max = t1*1.5;

   p[16].min = 0.0;
   p[16].nom = gds;
   p[16].max = gds*4.0;
   if (p[16].max < 1e-4)
      p[16].max = 1e-4;

   p[17].min = 0.0;
   p[17].nom = t2;
   p[17].max = t2*1.5;

   // print the final values to the screen 

   if (!batch_mode)
      {
      printf ("\n");
      printf (" Cgs     Gds    Cds    Cgd     Ri      Gm      T1      Ggd     T2      Ggs\n");
      printf (" (pF)    (mS)   (pF)   (pF)   (ohm)    (mS)    (ps)    (mS)    (ps)    (mS)\n");
      printf ("----------------------------------------------------------------------------\n");
      //       |    | |     | |    | |    | |     | |     | |     | |     | |     | |     |

      printf ("%6.3f %7.2f %6.3f %6.3f %7.3f %7.2f %7.2f %7.2f %7.2f %7.2f\n",
         cgs*1.0e12, gds*1.0e3, cds*1.0e12, cgd*1.0e12, ri, gm*1.0e3,
         t1*1.0e12, ggd*1.0e3, t2*1.0e12, ggs*1.0e3);
      }

   return 0;
   }

/******************************************************************************************/
/******************************************************************************************/

static double get_s11_error (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                             double gm, double t1, double gds, double t2, double cds, double ggs, double ggd)
   {
   unsigned i;
   COMPLEX y[4],s[4];
   double err = 0.0;

   for (i = 0; i < n; ++i)
      {
      y[1].r = -ggd;
      y[1].i = -w[i] * cgd;

      y[0] = Csub (Cdiv (Complex (1.0), Cadd (Complex (ri), Cdiv (Complex (1.0), Cnum (ggs, w[i] * cgs)))), y[1]);
      
      y[3] = Csub (Cadd (Cnum (gds * cos (-w[i] * t2), gds * sin (-w[i] * t2)), Cnum (0.0, w[i] * cds)), y[1]);

      y[2] = Cmult (Cnum (gm * cos (-w[i] * t1), gm * sin (-w[i] * t1)), Cadd (y[0], y[1]));
      y[2] = Cadd (Cdiv (y[2], Cnum (ggs, w[i] * cgs)), y[1]);

      y2s (y, s, 50.0);

      err += fabs (s11[i] - Cmag (s[0]));
      }
   err /= (double) n;

   return err;
   }

/******************************************************************************************/
/******************************************************************************************/

static void ggs_ggd_fit (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                         double gm, double t1, double gds, double t2, double cds, double *ggs, double *ggd)
   {
   double last;
   double err;
   double delta = 1.0e-4;

   *ggs = 0.0;
   *ggd = 0.0;

   if (n < 1)
      return;

   err = get_s11_error (w, s11, n, cgs, ri, cgd, gm, t1, gds, t2, cds, *ggs, *ggd);

   do {
      last = err;

      *ggs += delta;
      *ggd += delta;

      err = get_s11_error (w, s11, n, cgs, ri, cgd, gm, t1, gds, t2, cds, *ggs, *ggd);
      }
   while ((err <= last) && (*ggs < 5.0));

   *ggs -= delta;
   *ggd -= delta;
   }

/******************************************************************************************/
/******************************************************************************************/

static void ggs_fit (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                     double gm, double t1, double gds, double t2, double cds, double *ggs)
   {
   double last;
   double err;
   double delta = 1.0e-4;

   *ggs = 0.0;

   if (n < 1)
      return;

   err = get_s11_error (w, s11, n, cgs, ri, cgd, gm, t1, gds, t2, cds, *ggs, 0.0);

   do {
      last = err;

      *ggs += delta;

      err = get_s11_error (w, s11, n, cgs, ri, cgd, gm, t1, gds, t2, cds, *ggs, 0.0);
      }
   while ((err <= last) && (*ggs < 5.0));

   *ggs -= delta;
   }

/******************************************************************************************/
/******************************************************************************************/

static void ggd_fit (double *w, double *s11, unsigned n, double cgs, double ri, double cgd,
                     double gm, double t1, double gds, double t2, double cds, double *ggd)
   {
   double last;
   double err;
   double delta = 1.0e-4;

   *ggd = 0.0;

   if (n < 1)
      return;

   err = get_s11_error (w, s11, n, cgs, ri, cgd, gm, t1, gds, t2, cds, 0.0, *ggd);

   do {
      last = err;

      *ggd += delta;

      err = get_s11_error (w, s11, n, cgs, ri, cgd, gm, t1, gds, t2, cds, 0.0, *ggd);
      }
   while ((err <= last) && (*ggd < 5.0));

   *ggd -= delta;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static void log_error (char *err_msg, char *fname)
   {  
   if (!err_msg)
      return;
      
   if (!fname || (strlen (fname) < 1))
      {
      fprintf (stderr, "%s", err_msg);
      
      if (err_msg[strlen(err_msg)-1] != '\n')
         fprintf (stderr, "\n");
      
      return;
      }
   else
      {
      FILE *file = fopen (fname, "a");
      if (!file)
         return;
      
      fprintf (file, "%s", err_msg);
      
      if (err_msg[strlen(err_msg)-1] != '\n')
         fprintf (stderr, "\n");
      
      fclose (file);
      }
   }
      
      
   
   
   
   
   
   
