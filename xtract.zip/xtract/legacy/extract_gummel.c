#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "jplot.h"
#include "fit_tools.h"

#define MAX_IV_PTS      500
#define QELECTRON       1.60217733e-19
#define BOLTZMANN       1.380658e-23

typedef struct
   {
   double vb,vc,ib,ic;
   } DC_DATA;

static int get_iv_data (char *fname, DC_DATA *iv, unsigned sz_iv, unsigned *n);
static int fwd_ic_fit (DC_DATA *iv, unsigned n, double *is, double *nf);
static int fwd_ibei_fit (DC_DATA *iv, unsigned n, double *ibei, double *nei);
static int rev_ibci_fit (DC_DATA *iv, unsigned n, double *ibci, double *nci);
static int fwd_iben_fit (DC_DATA *iv, unsigned n, double ibei, double nei, double *iben, double *nen);

double global_temperature;

/****************************************************************************/
/*                                  MAIN                                    */
/****************************************************************************/

int main (int argc, char *argv[])
   {
   char string[256], fname[256];
   DC_DATA fwdg[MAX_IV_PTS], revg[MAX_IV_PTS];
   unsigned nfwd, nrev;
   double is, nf, ibei, nei, iben, nen, ibci, nci;
   int stat;
   char ch;
   FILE *file;

   printf ("Forward Gummel file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%255s", fname);
   
   if (get_iv_data (fname, fwdg, MAX_IV_PTS, &nfwd))
      return 1;
   else if (nfwd < 10)
      {
      printf ("Problem reading data file.\n");
      return 1;
      } 

   printf ("Reverse Gummel file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%255s", fname);

   if (get_iv_data (fname, revg, MAX_IV_PTS, &nrev))
      return 1;
   else if (nrev < 10)
      {
      printf ("Problem reading data file.\n");
      return 1;
      }
   
   printf ("Extraction temperature in Celcius?\n");
   fgets (string, 255, stdin);
   if (!sscanf (string, "%lf", &global_temperature))
      {
      printf ("Error reading input.\n");
      return 1;
      }
   
   global_temperature += 273.15;
   
   /*  ---------------  Do Fits  --------------  */
   
   // -- Ic and Nf
   
   do {   
      stat = fwd_ic_fit (fwdg, nfwd, &is, &nf);
      
      if (!stat)
         {
         printf ("Data OK (y or n)?\n");
         fgets (string, 255, stdin);
         sscanf (string, "%c", &ch);
         if ((ch == 'n') || (ch == 'N'))
            stat = 1;
         }
      else if (stat < 0)
         {
         printf ("Fatal error.\n");
         return 1;
         }
      else
         printf ("Problem occured: retrying fit...\n");
      }
   while (stat);
   
   // -- Ibei and Nei
   
   do {   
      stat = fwd_ibei_fit (fwdg, nfwd, &ibei, &nei);
      
      if (!stat)
         {
         printf ("Data OK (y or n)?\n");
         fgets (string, 255, stdin);
         sscanf (string, "%c", &ch);
         if ((ch == 'n') || (ch == 'N'))
            stat = 1;
         }
      else if (stat < 0)
         {
         printf ("Fatal error.\n");
         return 1;
         }
      else
         printf ("Problem occured: retrying fit...\n");
      }
   while (stat);   
   
   // -- Iben and Nen
   
   do {   
      stat = fwd_iben_fit (fwdg, nfwd, ibei, nei, &iben, &nen);
      
      if (!stat)
         {
         printf ("Data OK (y or n)?\n");
         fgets (string, 255, stdin);
         sscanf (string, "%c", &ch);
         if ((ch == 'n') || (ch == 'N'))
            stat = 1;
         }
      else if (stat < 0)
         {
         printf ("Fatal error.\n");
         return 1;
         }
      else
         printf ("Problem occured: retrying fit...\n");
      }
   while (stat);      

   // -- Ibci and Nci
   
   do {   
      stat = rev_ibci_fit (revg, nrev, &ibci, &nci);
      
      if (!stat)
         {
         printf ("Data OK (y or n)?\n");
         fgets (string, 255, stdin);
         sscanf (string, "%c", &ch);
         if ((ch == 'n') || (ch == 'N'))
            stat = 1;
         }
      else if (stat < 0)
         {
         printf ("Fatal error.\n");
         return 1;
         }
      else
         printf ("Problem occured: retrying fit...\n");
      }
   while (stat);      
   
   /*  --------------  Print Data  -------------  */
   
   printf ("\n\nResults:\n");
   printf ("--------------------\n");
   
   printf ("%-5s = %12.3e\n", "is", is);
   printf ("%-5s = %12.3e\n", "nf", nf);
   printf ("%-5s = %12.3e\n", "ibei", ibei);
   printf ("%-5s = %12.3e\n", "nei", nei);
   printf ("%-5s = %12.3e\n", "iben", iben);
   printf ("%-5s = %12.3e\n", "nen", nen);
   printf ("%-5s = %12.3e\n", "ibci", ibci);
   printf ("%-5s = %12.3e\n", "nci", nci);
   
   printf ("\n\nFile name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fname);
      
   file = fopen (fname, "w+");
   if (!file)
      {
      printf ("Unable to create file.\n");
      return 1;
      }
      
   fprintf (file, "! Temperature: %.2f C\n", global_temperature - 273.15);
   
   fprintf (file, "%-5s = %12.3e\n", "is", is);
   fprintf (file, "%-5s = %12.3e\n", "nf", nf);
   fprintf (file, "%-5s = %12.3e\n", "ibei", ibei);
   fprintf (file, "%-5s = %12.3e\n", "nei", nei);
   fprintf (file, "%-5s = %12.3e\n", "iben", iben);
   fprintf (file, "%-5s = %12.3e\n", "nen", nen);
   fprintf (file, "%-5s = %12.3e\n", "ibci", ibci);
   fprintf (file, "%-5s = %12.3e\n", "nci", nci);
      
   fclose (file);
      
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int get_iv_data (char *fname, DC_DATA *iv, unsigned sz_iv, unsigned *n)
   {
   FILE *file;
   char string[256];
   unsigned i = 0;
   double v1,v2,v3,v4;
  
   file = fopen (fname,"r");
   if (!file)
      {
      printf ("Unable to open DC data file:  %s\n", fname);
      return 1;
      }
   
   while (fgets (string, 255, file))
      {
      if (i >= sz_iv)
         {
         printf ("Warning: Max points exceeded in file:  %s\n", fname);
         break;
         }

      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      else if (sscanf (string, "%lf%lf%lf%lf", &v1, &v2, &v3, &v4) == 4)
         {
         iv[i].vc = v1;
         iv[i].vb = v3;
         iv[i].ic = v2;
         iv[i].ib = v4;
         ++i;
         }
      }
      
   fclose (file);
 
   *n = i;
 
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int plot_gummel (double *x, double *y, unsigned n, char *xlab, char *ylab, char *title)
   {
   jPLOT_ITEM *plot;

   if (!open_graphics_device (X_WINDOWS, NULL))
      {
      printf ("open_graphics_device() failed.\n");
      return 1;
      }

   plot = create_plot_item (SingleY, 1.75, 1.25, 7.0, 6.0);

   attach_y1data (plot, x, y, n, LT_SOLID, 2, CLR_RED);
      
   set_axis_labels (plot, xlab, ylab, "", title);
   
   set_axis_scaling (plot, LogY1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   
   close_graphics_device ();
   
   return 0;
   }
   
/*******************************************************************************************/
/*******************************************************************************************/

static int plot_gummel_and_fit (double *x, double *y, unsigned n, double id, double nd, double start, double stop,
   char *xlab, char *ylab, char *title)
   {
   jPLOT_ITEM *plot;
   double line_x[2];
   double line_y[2];
   
   line_x[0] = start;
   line_x[1] = stop;
   line_y[0] = id * exp (start * QELECTRON / (BOLTZMANN * global_temperature * nd));
   line_y[1] = id * exp (stop * QELECTRON / (BOLTZMANN * global_temperature * nd));

   if (!open_graphics_device (X_WINDOWS, NULL))
      {
      printf ("open_graphics_device() failed.\n");
      return 1;
      }

   plot = create_plot_item (SingleY, 1.75, 1.25, 7.0, 6.0);

   attach_y1data (plot, x, y, n, LT_SOLID, 2, CLR_RED);
   attach_y1data (plot, line_x, line_y, 2, LT_SOLID, 2, CLR_BLUE);
      
   set_axis_labels (plot, xlab, ylab, "", title);
   
   set_axis_scaling (plot, LogY1);
   
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return 1;
      }
   
   close_graphics_device ();
   
   return 0;
   }   

/*******************************************************************************************/
/*******************************************************************************************/

static int fit_data (double *x, double *y, unsigned n, double start, double stop, double *id, double *nd)
   {
   double x1[MAX_IV_PTS], y1[MAX_IV_PTS];
   unsigned i, j;
   double m, b, r2;
   
   for (i = 0, j = 0; i < n; ++i)
      {
      if ((x[i] < start) || (x[i] > stop))
         continue;
      
      x1[j] = x[i];
      y1[j] = log (y[i]);
      ++j;
      }
   
   if (j < 3)
      {
      printf ("Not enough points.\n");
      return 1;
      }
   
   linefit_mxb (x1, y1, j, &m, &b, &r2);
   
   *id = exp (b);
   *nd = QELECTRON / (BOLTZMANN * global_temperature * m);
   
   return 0;
   }
   
/*******************************************************************************************/
/*******************************************************************************************/

static int fwd_ic_fit (DC_DATA *iv, unsigned n, double *is, double *nf)
   {
   double v[MAX_IV_PTS], i[MAX_IV_PTS];
   unsigned j, k;
   double start, stop;
   char string[100];

   for (k = 0, j = 0; k < n; ++k)
      {
      if (iv[k].vb < 0.5)
         continue;
      else if (iv[k].vb > 1.3)
         break;
      
      v[j] = iv[k].vb;
      i[j] = iv[k].ic;
      ++j;
      }
   
   if (j < 3)
      {
      printf ("Not enough points.\n");
      return -1;
      }
   
   // plot the data to get a range for extraction
   
   if (plot_gummel (v, i, j, "Vbe", "Ice", "Forward Ic"))
      return -1;
   
   printf ("Vbe range (start stop) for parameter extraction?\n");
   fgets (string, 99, stdin);
   if (sscanf (string, "%lf%lf", &start, &stop) != 2)
      {
      printf ("Error reading values.\n");
      return 1;
      }
   
   if (fit_data (v, i, j, start, stop, is, nf))
      return 1;
   
   if (plot_gummel_and_fit (v, i, j, *is, *nf, start, stop, "Vbe", "Ice", "Forward Ic"))
      return -1;
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int fwd_ibei_fit (DC_DATA *iv, unsigned n, double *ibei, double *nei)
   {
   double v[MAX_IV_PTS], i[MAX_IV_PTS];
   unsigned j, k;
   double start, stop;
   char string[100];

   for (k = 0, j = 0; k < n; ++k)
      {
      if (iv[k].vb < 0.5)
         continue;
      else if (iv[k].vb > 1.3)
         break;
      
      v[j] = iv[k].vb;
      i[j] = iv[k].ib;
      ++j;
      }
   
   if (j < 3)
      {
      printf ("Not enough points.\n");
      return -1;
      }
   
   // plot the data to get a range for extraction
   
   if (plot_gummel (v, i, j, "Vbe", "Ibe", "Forward Ib (ideal)"))
      return -1;
   
   printf ("Vbe range (start stop) for parameter extraction?\n");
   fgets (string, 99, stdin);
   if (sscanf (string, "%lf%lf", &start, &stop) != 2)
      {
      printf ("Error reading values.\n");
      return 1;
      }
   
   if (fit_data (v, i, j, start, stop, ibei, nei))
      return 1;
   
   if (plot_gummel_and_fit (v, i, j, *ibei, *nei, start, stop, "Vbe", "Ibe", "Forward Ib (ideal)"))
      return -1;
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int rev_ibci_fit (DC_DATA *iv, unsigned n, double *ibci, double *nci)
   {
   double v[MAX_IV_PTS], i[MAX_IV_PTS];
   unsigned j, k;
   double start, stop;
   char string[100];

   for (k = 0, j = 0; k < n; ++k)
      {
      if (iv[k].vc > -0.5)
         continue;
      else if (iv[k].vc < -1.3)
         break;
      
      v[j] = -iv[k].vc;
      i[j] = iv[k].ib;
      ++j;
      }
   
   if (j < 3)
      {
      printf ("Not enough points.\n");
      return -1;
      }
   
   // plot the data to get a range for extraction
   
   if (plot_gummel (v, i, j, "Vbc", "Ibc", "Reverse Ib (ideal)"))
      return -1;
   
   printf ("Vbc range (start stop) for parameter extraction?\n");
   fgets (string, 99, stdin);
   if (sscanf (string, "%lf%lf", &start, &stop) != 2)
      {
      printf ("Error reading values.\n");
      return 1;
      }
   
   if (fit_data (v, i, j, start, stop, ibci, nci))
      return 1;
   
   if (plot_gummel_and_fit (v, i, j, *ibci, *nci, start, stop, "Vbc", "Ibc", "Reverse Ib (ideal)"))
      return -1;
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int fwd_iben_fit (DC_DATA *iv, unsigned n, double ibei, double nei, double *iben, double *nen)
   {
   double v[MAX_IV_PTS], i[MAX_IV_PTS];
   unsigned j, k;
   double start, stop;
   char string[100];

   for (k = 0, j = 0; k < n; ++k)
      {
      if (iv[k].vb < 0.5)
         continue;
      else if (iv[k].vb > 1.3)
         break;
      
      v[j] = iv[k].vb;
      i[j] = iv[k].ib - ibei * exp (iv[k].vb * QELECTRON / (nei * BOLTZMANN * global_temperature));
      
      if (i[j] < 0.0)
         break;
         
      ++j;
      }
   
   if (j < 3)
      {
      printf ("Not enough points.\n");
      return -1;
      }
   
   // plot the data to get a range for extraction
   
   if (plot_gummel (v, i, j, "Vbe", "Ibe", "Forward Ib (non-ideal)"))
      return -1;
   
   printf ("Vbe range (start stop) for parameter extraction?\n");
   fgets (string, 99, stdin);
   if (sscanf (string, "%lf%lf", &start, &stop) != 2)
      {
      printf ("Error reading values.\n");
      return 1;
      }
   
   if (fit_data (v, i, j, start, stop, iben, nen))
      return 1;
   
   if (plot_gummel_and_fit (v, i, j, *iben, *nen, start, stop, "Vbe", "Ibe", "Forward Ib (non-ideal)"))
      return -1;
   
   return 0;
   }



