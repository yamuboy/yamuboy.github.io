#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#define RAD2DEG   ((double) 57.2957795131)
#define MAXCOLS   30

int string_index (char *sta, char *stb);
int get_values (char *str, int *cols, int ncols, double *vals);

main ()
{
char    file_name[256];
char    out_name[256];
char    batch_name[80];
char    string[201];
char    *buffer;
char    plot_name[80];
double  p_in,mag,ang;
double  real,imag,freq;
int     device;
int     first,i,found;
int     num_cols;
int     columns[MAXCOLS];
char    names[MAXCOLS][40];
char    tnames[MAXCOLS][40];
double  values[MAXCOLS];
FILE    *infile;
FILE    *outfile;
time_t  dummyt;
static char sep_chars[] = " .,|:;/\n\"!?";

printf ("Maury load pull file name > ");
scanf ("%255s",file_name);

printf ("Input power level > ");
scanf ("%lf",&p_in);

printf ("Plot file name > ");
scanf ("%79s",plot_name);

printf ("Plotting Device (10=Postscript, 11=X-Windows, 12=Metafile) > ");
scanf ("%d",&device);

sscanf (file_name,"%[^.]",out_name);
strcat (out_name,".temp");

infile = fopen (file_name,"r");
if (infile == (FILE *) NULL)
   {
   printf ("ERROR: cannot open file \"%s\"\n",file_name);
   return (-1);
   }

for (i = 0; i < MAXCOLS; ++i)
   {
   columns[i] = -1;
   }

outfile = fopen (out_name,"w+");

first = 1;
while (fgets (string,200,infile) != NULL)
   {
   if (first)
      {
      if (!strncmp (string,"Frequency range:",16))
         {
         sscanf (&string[16],"%lf",&freq);
         }

      if ((i = string_index (string,"Source = (")) >= 0)
         {
         sscanf (&string[i+9],"(%lf %lf)",&real,&imag);
         mag = sqrt (real*real+imag*imag);
         ang = atan2 (imag,real)*RAD2DEG;
         fprintf (outfile,"! Source Reflection Coefficient: ( %.3f < %.1f )\n",mag,ang);
         fprintf (outfile,"! Frequency: %.3f GHz\n",freq);
         fprintf (outfile,"! Input Power Level: %.1f dBm\n",p_in);
         i = string_index (string,"Load = (");
         sscanf (&string[i+7],"(%lf %lf)",&real,&imag);
         mag = sqrt (real*real+imag*imag);
         ang = atan2 (imag,real)*RAD2DEG;
         if (fgets (string,200,infile) != NULL)
            {
            i = 0;
            found = 0;
            buffer = strtok (string,sep_chars);
            do {
               if (!strcmp (buffer,"Pin_avail_dBm"))
                  {
                  columns[0] = i;
                  strcpy (names[0],buffer);
                  found = 1;
                  }                

               else if (!strcmp (buffer,"Pin_deliv_dBm"));

               else
                  {
                  printf ("%2d. %s\n",i,buffer);
                  strncpy (tnames[i],buffer,39);
                  }
               ++i;
               
               if (i >= MAXCOLS)
                  {
                  break;
                  }
               }
            while ((buffer = strtok (NULL,sep_chars)) != NULL);

            if (!found)
               {
               printf ("\"Pin_avail_dBm\" column not found. Unable to continue.\n");
               return -1;
               }

            printf ("Columns to plot (seperated by spaces) > ");
            fgets (string,200,stdin);
            fgets (string,200,stdin);
                        
            i = 1;
            buffer = strtok (string,sep_chars);
            do {
               if (sscanf (buffer,"%d",&columns[i]) == 1)
                  {
                  strcpy (names[i],tnames[columns[i]]);
                  ++i;
                  }
               if (i >= MAXCOLS)
                  {
                  break;
                  }
               }
            while ((buffer = strtok (NULL,sep_chars)) != NULL);
            
            num_cols = i;
            }
         first = 0;
         }
      }

   else
      {
      if ((i = string_index (string,"Load = (")) >= 0)
         {
         sscanf (&string[i+7],"(%lf %lf)",&real,&imag);
         mag = sqrt (real*real+imag*imag);
         ang = atan2 (imag,real)*RAD2DEG;
         }
      
      if (get_values (string,columns,num_cols,values))
         {
         if ((values[0] > ((double) 0.99)*p_in) && (values[0] < ((double) 1.01)*p_in))
            {
            fprintf (outfile,"%7.3f %6.1f",mag,ang);
            for (i = 1; i < num_cols; ++i)
               {
               fprintf (outfile," %.4e",values[i]);
               }
            fprintf (outfile,"\n");
            }
         }
      }
   }
fclose (infile);
fclose (outfile);

sprintf (batch_name,"batch.%d",time (&dummyt));
outfile = fopen (batch_name,"w+");
fprintf (outfile,"%s\n",out_name);  // contour data file name
fprintf (outfile,"%s\n",plot_name);  // plot file name
fprintf (outfile,"%d\n",num_cols-1);  // number of contour plots
for (i = 1; i < num_cols; ++i)       // names for the contour plots (from the Maury file header)
   {
   fprintf (outfile,"%s\n",names[i]);
   }
fprintf (outfile,"%d\n",device);   // plotting device
fclose (outfile);

sprintf (string,"contour_plot < %s",batch_name);
system (string);

sprintf (string,"rm -f %s",out_name);
system (string);
sprintf (string,"rm -f %s",batch_name);
system (string);

return (0);
}

/*********************************************************************************/                
/*********************************************************************************/                

string_index (char *str1,char *str2)
{
int   len1;
int   len2;
int   i;

len1 = strlen (str1);
len2 = strlen (str2);

if (len1 < len2)
   {
   return (-1);
   }

for (i = 0; i <= (len1-len2); ++i)
   {
   if (!strncmp (&str1[i],str2,len2))
      {
      return (i);
      }
   }

return (-1);
}

/*********************************************************************************/                
/*********************************************************************************/                

int get_values (char *string, int *cols, int ncols, double *values)
   {
   int       i,j;
   char      *str;
   char      *str1;

   str1 = string;

   j = 0;
   for (i = 0; i < ncols; ++i)
      {
      if (j > cols[i])
         {
         j = 0;
         str1 = string;
         }

      while (j < cols[i])
         {
         strtod (str1,&str);
	 if (str1 == str)
	    {
	    return 0;
	    }
         str1 = str;
         ++j;
         }

      if (cols[i] > -1)
         {
         values[i] = strtod (str1,&str);
	 if (str1 == str)
	    {
	    return 0;
	    }
         str1 = str;
         ++j;
         }
      else
         values[i] = (double) 0.0;
      }

   return 1;
   }



