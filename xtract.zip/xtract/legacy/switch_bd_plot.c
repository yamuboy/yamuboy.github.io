#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "jplot.h"

#define MAX_FILES   35
#define MAX_IV_PTS  100

main (int argc, char *argv[])
   {
   char batch_file_name[100];
   char command[1200];
   char string[200];
   char search_path[1024];
   char gfile[100];
   char filename[256];
   char fnames[MAX_FILES][256];
   char *pfnames[MAX_FILES];
   int i,j,k,gdevice,begin_read;
   int current_lt = 0;
   int current_lc = 2;
   int linetypes[MAX_FILES];
   int linecolors[MAX_FILES];
   int linewidths[MAX_FILES];
   int numpoints[MAX_FILES];
   double lastv,area,per_mm,vds,ids;
   double vgsiv[MAX_FILES][MAX_IV_PTS];
   double igsiv[MAX_FILES][MAX_IV_PTS];   
   FILE *file,*batch_file; 
   jPLOT_ITEM *plot1;
   time_t dummy;
   
   /************ get information ***************/
   
   printf ("Search path(s) for breakdown I-V files (seperate multiple paths by spaces)?\n");
   fgets (search_path,1023,stdin);
   search_path[strlen(search_path)-1] = 0;
   
   printf ("Graphics device?\n");
   printf ("   1 : X-WINDOWS\n");
   printf ("   2 : METAFILE\n");
   printf ("   3 : POSTSCRIPT\n> ");
   fgets (string,199,stdin);
   sscanf (string,"%d",&gdevice);
   
   if ((gdevice < 1) || (gdevice > 3))
      gdevice = 1;
   
   gfile[0] = 0;
   if (gdevice != 1)
      {
      printf ("Graphics output file name?\n");
      fgets (string,199,stdin);
      sscanf (string,"%99s",gfile);
      }
   
   /************ find data files *************/
   
   sprintf (batch_file_name,"temp.%d",time(&dummy));   
   sprintf (command,"rm -f %s",batch_file_name);
   system (command);
   
   sprintf (command,"ls -1 %s > %s",search_path,batch_file_name);
   system (command);
   
   /************ read data from files ***********/
   
   batch_file = fopen (batch_file_name,"r");
   if (!batch_file)
      {
      printf ("ERROR: batch file does not exist.\n");
      return -1;
      }

   i = 0;      
   while (fgets (filename,255,batch_file))
      {
      filename[strlen(filename)-1] = 0;
      
      if (i >= MAX_FILES)
         {
         printf ("WARNING: MAX_FILES exceeded.\n");
         break;
         }
      
      file = fopen (filename,"r");
      if (!file)
         continue;

      // initialize some stuff
      lastv = 0.05;
      per_mm = 0.0;
      begin_read = 0; 
      j = 0;
      
      while (fgets (string,199,file))
         {
         if (j >= MAX_IV_PTS)
            {
            printf ("WARNING: Max IV points exceeded.\n");
            break;
            }

         if (string[0] == '!')
            {
            if (!strncmp (string,"!GATE PERIPHERY (um):",21))
               {
               sscanf (string,"!GATE PERIPHERY (um):%lf",&area);
               per_mm = 1000.0/area;
               }
            else if (strstr (string,"BREAKDOWN IV-CURVES"))
               {
               fgets (string,199,file);
               fgets (string,199,file);
               begin_read = 1;
               }
            
            continue;
            }

         if (begin_read && (per_mm > 0.0))
            {
            if (string[0] == '!')
               break;
            
            if (sscanf (string,"%lf%lf%lf%lf",&vds,&ids,&vgsiv[i][j],&igsiv[i][j]) == 4)
               {
               vgsiv[i][j] = vds - vgsiv[i][j];
               igsiv[i][j] = -igsiv[i][j]*per_mm;
               
               if (vgsiv[i][j] < lastv)
                  break;
               
               lastv = vgsiv[i][j];
               ++j;
               }
            }
         }

      fclose (file);
      
      if (j > 5)
         {
         linetypes[i] = current_lt;
         linecolors[i] = current_lc;
         strcpy (fnames[i],filename);
         numpoints[i] = j;
         
         ++i;
         
         ++current_lc;
         
         if (current_lc > MAX_CLR_INDEX)
            {
            current_lc = 2;
            ++current_lt;
            }
         }
      }
   
   fclose (batch_file);
   
   sprintf (command,"rm -f %s",batch_file_name);
   system (command);
   
   /*********** time to plot ************/

   if (!open_graphics_device (gdevice,gfile))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }
   
   plot1 = create_plot_item (SingleY,1.25,1.25,8.5,6.0);
      
   for (k = 0; k < i; ++k)
      {
      attach_y1data (plot1,vgsiv[k],igsiv[k],numpoints[k],linetypes[k],1,linecolors[k]);
      linewidths[k] = 1;
      pfnames[k] = &fnames[k][0];
      }

   set_axis_scaling (plot1,LogY1);

   set_axis_labels (plot1,"Vdg (volts)","Idg (A/mm)","","Breakdown Characteristics");
      
   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }
   
   deactivate_plot_item (plot1);
   
   add_legend (i,1.5,7.75,pfnames,FNT_COURIER,12,linetypes,linewidths,linecolors);
   add_text ("Legend",2.0,7.9,FNT_COURIER,16,0.0,JUST_LEFT,CLR_BLACK,TS_NONE);

   if (!draw_page ())
      {
      printf ("draw_page() failed.\n");
      close_graphics_device ();
      return -1;
      }   
   
   close_graphics_device ();
   
   return 0;
   }
