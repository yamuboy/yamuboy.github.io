#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "cmplxlib.h"
#include "sortlib.h"

int line_fit ();

main ()

{
char    s_files[80];
char    para_file[80];
char    out_name[80];
char    batch_name[80];
char    file_name[80];
char    pname[11];
char    string[200];
char    s_names[500][80];
char    s_names2[500][80];
FILE    *infile;
FILE    *list_file;
FILE    *outfile;
double  rs,rd,rg,ls,ld,lg;
double  c11,c22,cpg,cpd;
double  ri,gm,tau,cds;
double  d1,d2,d3,value;
double  Vgs,Vds,Igs,Ids;
double  Cgs,Cgst,Cgd,Cgdt;
double  TWOPI,y_values[1000];
double  freq[1000],slope,intercept,r_sq;
double  sorting_data[500][2];
POLAR   sm[4];
COMPLEX s[4],z[4],y[1000][4],x1,x2;
int     found,bias_found;
int     num_freq,i,j;
int     num_s_files;
time_t  current;
SORT_S  sort_this[500];
SORT_S  *sort_result;
static  SORT_ORDER order[] = {{1,0},{0,0}}; 

TWOPI = ((double) 2.0)*acos ((double) -1.0);

printf ("S-parameter files > ");
scanf ("%79s",s_files);

printf ("Scaled Cds value from large-signal fit > ");
scanf ("%lf",&cds);

printf ("Tau value from large-signal fit > ");
scanf ("%lf",&tau);

printf ("Output file name > ");
scanf ("%79s",out_name);

sprintf (batch_name,"tmp.%d",time (&current));
sprintf (string,"rm -f %s",batch_name);
system (string);
sprintf (string,"ls -1 %s > %s",s_files,batch_name);
system (string);

list_file = fopen (batch_name,"r");
if (list_file == (FILE *) NULL)
   {
   printf ("internal error: unable to open batch file.\n");
   return (-1);
   }

i = 0;
while (fgets (s_names[i],79,list_file) != NULL)
   {
   ++i;
   if (i > 499)
      {
      printf ("too many files in arg list.\n");
      return (-1);
      }
   }
fclose (list_file);

num_s_files = i;

sprintf (string,"rm -f %s",batch_name);
system (string);

for (i = 0; i <  num_s_files; ++i)
   {
   j = 0;
   while ((s_names[i][j] > 57) || (s_names[i][j] < 48))
      {
      ++j;
      }
   
   sprintf (string,"%c %c %c",s_names[i][j],s_names[i][j+1],s_names[i][j+2]);
   sscanf (string,"%lf %lf %lf",&d1,&d2,&d3);
   Vds = d1*((double) 10.0) + d2 + d3*((double) 0.1);
   
   sprintf (string,"%c %c %c",s_names[i][j+4],s_names[i][j+5],s_names[i][j+6]);
   sscanf (string,"%lf %lf %lf",&d1,&d2,&d3);
   Vgs = d1 + d2*((double) 0.1) + d3*((double) 0.01); 

   if (s_names[i][j+3] == 'm')
      {
      Vgs = -Vgs;
      }

   sorting_data[i][0] = Vds; 
   sorting_data[i][1] = Vgs;
   sort_this[i].params = sorting_data[i];
   sort_this[i].position = i;
   sort_this[i].next = NULL;
   if (i != 0)
      {
      sort_this[i-1].next = &sort_this[i];
      }   
   }   

sort_result = sort_data (sort_this,order,2);

i = 0;
while (sort_result != NULL)
   {
   strcpy (s_names2[i],s_names[sort_result->position]);
   ++i;
   sort_result = sort_result->next;
   }

outfile = fopen (out_name,"w+");

fprintf (outfile,"!Intrinsic Transcapacitance Direct Extraction Program v1.00\n");
fprintf (outfile,"!\n"); 
fprintf (outfile,"!Cds = %.5e F, Tau = %.5e sec\n",cds,tau);
fprintf (outfile,"!\n");
fprintf (outfile,"!Vgs(v) Vds(v)   Cgs(F)    Cgst(F)      Cgd(F)      Cgdt(F)\n");   

for (j = 0; j < num_s_files; ++j)
   {
   sscanf (s_names2[j],"%79s",file_name);

   sscanf (file_name,"%[^.]",para_file);
   strcat (para_file,".end");

   infile = fopen (para_file,"r");
   if (infile == (FILE *) NULL)
      {
      printf ("warning: unable to open parameter file %s.\n",para_file);
      continue;
      }

   found = 0;
   while (fgets (string,199,infile) != NULL)
      {
      sscanf (string,"%lf %lf %lf %lf %10s",&d1,&value,&d2,&d3,pname);
      if (!strcmp (pname,"RG"))
         {
         rg = value;
         ++found;
         }
      else if (!strcmp (pname,"RS"))
         {
         rs = value;
         ++found;
         }
      else if (!strcmp (pname,"RD"))
         {
         rd = value;
         ++found;
         }
      else if (!strcmp (pname,"RI"))
         {
         ri = value;
         ++found;
         }
      else if (!strcmp (pname,"C1"))
         {
         cpg = value;
         ++found;
         }
      else if (!strcmp (pname,"C2"))
         {
         cpd = value;
         ++found;
         }
      else if (!strcmp (pname,"LS"))
         {
         ls = value;
         ++found;
         }
      else if (!strcmp (pname,"B1"))
         {
         lg = value;
         ++found;
         }
      else if (!strcmp (pname,"B2"))
         {
         ld = value;
         ++found;
         }
      else if (!strcmp (pname,"GM"))
         {
         gm = value;
         ++found;
         }
      else if (!strcmp (pname,"C11"))
         {
         c11 = value;
         ++found;
         }
      else if (!strcmp (pname,"C22"))
         {
         c22 = value;
         ++found;
         }
      }
   fclose (infile);

   if (found != 12)
      {
      printf ("warning: not all parameters found in parameters file %s.\n",para_file);
      continue;
      }

   infile = fopen (file_name,"r");
   if (infile == (FILE *) NULL)
      {
      printf ("warning: unable to open %s.\n",file_name);
      continue;
      }
   
   i = 0;
   bias_found = 0;
   while (fgets (string,199,infile) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",&freq[i],&sm[0].m,&sm[0].a,
                          &sm[2].m,&sm[2].a,&sm[1].m,&sm[1].a,&sm[3].m,&sm[3].a) == 9)
         {
         PA2CA (sm,s,2,2);
         s2y (s,y[i],(double) 50.0);
         
         /* subtract out cpg and cpd */
         x1.r = (double) 0.0;
         x1.i = TWOPI*freq[i]*cpg;
         x2.r = (double) 0.0;
         x2.i = TWOPI*freq[i]*cpd;
         y[i][0] = Csub (y[i][0],x1);
         y[i][3] = Csub (y[i][3],x2);
         
         y2z (y[i],z);
         
         /* subtract out lg, rg, ld, and rd */
         x1.r = rg;
         x1.i = TWOPI*freq[i]*lg;
         x2.r = rd;
         x2.i = TWOPI*freq[i]*ld;
         z[0] = Csub (z[0],x1);
         z[3] = Csub (z[3],x2);
         
         z2y (z,y[i]);
         
         /* subtract out c11 and c22 */
         x1.r = (double) 0.0;
         x1.i = TWOPI*freq[i]*c11;
         x2.r = (double) 0.0;
         x2.i = TWOPI*freq[i]*c22;
         y[i][0] = Csub (y[i][0],x1);
         y[i][3] = Csub (y[i][3],x2);
         
         y2z (y[i],z);
         
         /* subtract out rs and ls */
         x1.r = rs;
         x1.i = TWOPI*freq[i]*ls;
         z[0] = Csub (z[0],x1);
         z[1] = Csub (z[1],x1);
         z[2] = Csub (z[2],x1);
         z[3] = Csub (z[3],x1);
         
         z2y (z,y[i]);
                           
         ++i;
         }

      else if (!strncmp (string,"!BIAS:",6))
         {
         if (sscanf (string,"!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf",
                         &Vds,&Ids,&Vgs,&Igs) == 4)
            {
            Vds = Vds - rd*Ids - rs*(Igs+Ids);
            Vgs = Vgs - (rg+ri)*Igs - rs*(Igs+Ids);
            bias_found = 1;
            }
         }         
      }
   fclose (infile);
   num_freq = i;
   
   if (!bias_found)
      {
      Vgs = (double) 0.0;
      Vds = (double) 0.0;
      }

   /* ---------------------------------------------------------------------- */  
   /* now we have an intrinsic y-parameter matrix                            */
   /* topology: Im{y11} = w*(Cgs+Cgd+Cgst+Cgdt)                              */
   /*           Im{y12} = -w*(Cgd+Cgst)                                      */
   /*           Im{y21} = -gm*sin(w*tau)-w*(Cgd+Cgdt)                         */
   /*           Im{y22} = w*(Cgd+Cds)                                        */   
   /* ---------------------------------------------------------------------- */
   
   /* direct extract cgd */
   for (i = 0; i < num_freq; ++i)
      {
      x1.r = (double) 0.0;
      x1.i = TWOPI*freq[i]*cds;
      y[i][3] = Csub (y[i][3],x1);
      
      y_values[i] = y[i][3].i;
      }
   line_fit (freq,y_values,num_freq,&slope,&intercept,&r_sq);
   Cgd = slope/TWOPI;
      
   /* direct extract cgdt */
   for (i = 0; i < num_freq; ++i)
      {
      x1.r = (double) 0.0;
      x1.i = -gm*sin (TWOPI*freq[i]*tau)-TWOPI*Cgd;
      y[i][2] = Csub (y[i][2],x1);
      
      y_values[i] = y[i][2].i;
      }
   line_fit (freq,y_values,num_freq,&slope,&intercept,&r_sq);
   Cgdt = -slope/TWOPI;

   /* direct extract cgst */
   for (i = 0; i < num_freq; ++i)
      {
      x1.r = (double) 0.0;
      x1.i = TWOPI*Cgd;
      y[i][1] = Cadd (y[i][1],x1);
      
      y_values[i] = y[i][1].i;
      }
   line_fit (freq,y_values,num_freq,&slope,&intercept,&r_sq);
   Cgst = -slope/TWOPI;

   /* direct extract cgs */
   for (i = 0; i < num_freq; ++i)
      {
      x1.r = (double) 0.0;
      x1.i = TWOPI*(Cgd+Cgst+Cgdt);
      y[i][0] = Csub (y[i][0],x1);
      
      y_values[i] = y[i][0].i;
      }
   line_fit (freq,y_values,num_freq,&slope,&intercept,&r_sq);
   Cgs = slope/TWOPI;      
  
   fprintf (outfile,"%6.4f %6.3f %.5e %.5e %.5e %.5e\n",Vgs,Vds,Cgs,Cgst,Cgd,Cgdt);  
   
   fclose (infile);
   }

fclose (outfile);

return (0);
}

/****************************************************************************/

int line_fit (x,y,n,m,b,r_sq)
double   *x,*y,*m,*b,*r_sq;
int      n;

{
double    xsum,ysum;
double    xxsum,yysum;
double    xysum;
int       i;

if (n < 2)
   {
   *m = (double) 0.0;
   *b = (double) 0.0;
   *r_sq = (double) 0.0;
   return (-1);
   }

xsum = (double) 0.0;
ysum = (double) 0.0;
xysum = (double) 0.0;
xxsum = (double) 0.0;
yysum = (double) 0.0;

for (i = 0; i < n; ++i)
   {
   xsum += x[i];
   ysum += y[i];
   xysum += x[i]*y[i];
   xxsum += x[i]*x[i];
   yysum += y[i]*y[i];
   }

*m = (xysum*((double) n)-xsum*ysum)/(((double) n)*xxsum-xsum*xsum);
*b = (ysum-(*m)*xsum)/((double) n);
*r_sq = xysum*xysum/(xxsum*yysum);

return (0);
}
