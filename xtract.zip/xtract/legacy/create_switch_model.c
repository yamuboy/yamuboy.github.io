#include <stdio.h>
#include <string.h>
#include <math.h>


int string_index ();

main ()
{
FILE  *in_file;
FILE  *out_file;
FILE  *tmp;
FILE  *dm2_file;
char  dmb_name[201];
char  out_name[100];
char  buffer[1025];
char  param[201];
int   n,j,flag;
char  system_command[201];
double rd,nn,is,igs,vgs,temperature,q,k,area;
double min,nom,max,last,zero;
double i1,n1,r1,idi,vdi,i0,r0,n0;
double c0,c1,c2,c3,c4,c5;
double ids0,ids1,ids2,ids3,ids4;
double lg,ld,ls,rg,cgs,cdg,cds;
double vdd,vgg,igg;


zero = (double) 0.0;
k = (double) 1.380066e-23;
q = (double) 1.60218e-19;
printf("Output File Name?\n");
scanf("%s",out_name);

in_file = (FILE*) NULL;
in_file = fopen ("diodeout","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named diodeout for read");
     exit(1);
 }
out_file = (FILE*) NULL;
out_file = fopen (out_name,"w+");

while (fgets (buffer,1024,in_file) != NULL) 
  {
  if (buffer[0]=='!') 
    {
    continue;
    }
  else
    {
    sscanf(buffer,"%lf %lf %lf",&nn,&is,&rd);
    }
}
fclose(in_file);

i0 = is/((double) 2.0);
r0 = rd*((double) 2.0);
n0 = nn;

in_file = (FILE*) NULL;
in_file = fopen ("svbr.iv","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named svbr.iv for read");
     exit(1);
 }
 
flag = 0;
n = 0;

while ((fgets (buffer,1024,in_file) != NULL)  && (flag == 0))
  {
  if (buffer[0]=='!') 
    {
    if (strncmp (buffer,"!GATE PERIPHERY (um):",21) == 0)
	{
	sscanf (buffer,"!GATE PERIPHERY (um): %lf",&area);
	}
    if ((string_index (buffer,"BREAKDOWN") > 0) || (string_index (buffer,"Vgs") > 0) || (string_index (buffer,"(Volts)") > 0))
      {
      continue;
      }
    else 
      {
      fprintf(out_file,"%s",buffer);
      }
    }
  else
    {
    sscanf(buffer,"%lf%*f%lf%lf",&vdd,&vgg,&igg);
    if ((n == 0) && (vdd == 0.0))
       flag = 1;
    
    if (flag && (vdd == 0.0))
       {
       igs = -igg;
       vgs = -vgg;
       }
    else if (!flag)
       {
       igs = -igg;
       vgs = vdd - vgg;
       }
    }
 }
fclose(in_file);

if (flag)
   idi = igs*0.5;
else
   idi = igs;
   
vdi = vgs - idi*500.0;
n1 = 20.0;
r1 = 500.0;
temperature = 300.0;
i1 = idi/(exp(q*vdi/(n1*k*temperature)) - 1.0);

in_file = fopen ("cgs.end","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named cgs.end for read");
     exit(1);
 }
while (fgets (buffer,200,in_file) != NULL)
   {
   sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
   if (strcmp(param,"C0") == 0)
	{
	c0 = nom*((double) 1.0e-12);
	}
   else if (strcmp(param,"C1") == 0)
	{
	c1 = nom;
	}
   else if (strcmp(param,"C2") == 0)
	{
	c2 = nom;
	}
   else if (strcmp(param,"C3") == 0)
	{
	c3 = nom*((double) 1.0e-12);
	}
   else if (strcmp(param,"C4") == 0)
	{
	c4 = nom;
	}
   else if (strcmp(param,"C5") == 0)
	{
	c5 = nom;
	}
   }
fclose(in_file);

in_file = fopen ("switch.end","r");
if (in_file == (FILE*) NULL) {
     printf  ("can't open file named switch.end for read");
     exit(1);
 }
while (fgets (buffer,200,in_file) != NULL)
   {
   sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
   if (strcmp(param,"IDS0") == 0)
	{
	ids0 = nom;
	}
   else if (strcmp(param,"IDS1") == 0)
	{
	ids1 = nom;
	}
   else if (strcmp(param,"IDS2") == 0)
	{
	ids2 = nom;
	}
   else if (strcmp(param,"IDS3") == 0)
	{
	ids3 = nom;
	}
   else if (strcmp(param,"IDS4") == 0)
	{
	ids4 = nom;
	}
   }
fclose(in_file);
sprintf (system_command,"ls -r s000m*.end > junk");
system (system_command); 
sprintf (system_command,"chmod 777 junk");
system (system_command); 

tmp = fopen ("junk","r");
fgets (dmb_name,200,tmp);
fclose(tmp);
dmb_name[strlen (dmb_name)-1] = '\0';
dm2_file = fopen (dmb_name,"r");
if ( dm2_file == (FILE*) NULL)
     {
     printf ("** error ** cannot open file %s\n",dmb_name);
     exit (1);
     }
while (fgets (buffer,200,dm2_file) != NULL)
       {
	sscanf(buffer,"%lf %lf %lf %lf %s",&min,&nom,&max,&last,param);
	if (strcmp(param,"RG") == 0)
	    {
	    rg = nom;
	    }
        else if (strcmp(param,"CGS") == 0)
	    {
	    cgs = nom;
	    }
        else if (strcmp(param,"CDG") == 0)
	    {
	    cdg = nom;
	    }
        else if (strcmp(param,"CDS") == 0)
	    {
	    cds = nom;
	    }
        else if (strcmp(param,"LS") == 0)
	    {
	    ls = nom;
	    }
        else if (strcmp(param,"B1") == 0)
	    {
	    lg = nom;
	    }
        else if (strcmp(param,"B2") == 0)
	    {
	    ld = nom;
	    }
       }
fclose(dm2_file);
sprintf (system_command,"rm junk");
system (system_command); 

fprintf(out_file,"model  =   1\n");
fprintf(out_file,"area   = %12.4e\n",area);
fprintf(out_file,"cg     = %12.4e\n",zero);
fprintf(out_file,"cd     = %12.4e\n",zero);
fprintf(out_file,"cs     = %12.4e\n",zero);
fprintf(out_file,"cds    = %12.4e\n",cds);
fprintf(out_file,"lg     = %12.4e\n",lg);
fprintf(out_file,"ld     = %12.4e\n",ld);
fprintf(out_file,"ls     = %12.4e\n",ls);
fprintf(out_file,"rg     = %12.4e\n",rg);
fprintf(out_file,"c0     = %12.4e\n",zero);
fprintf(out_file,"c1     = %12.4e\n",zero);
fprintf(out_file,"c2     = %12.4e\n",zero);
fprintf(out_file,"c3     = %12.4e\n",zero);
fprintf(out_file,"c4     = %12.4e\n",zero);
fprintf(out_file,"c5     = %12.4e\n",zero);
fprintf(out_file,"c6     = %12.4e\n",c0);
fprintf(out_file,"c7     = %12.4e\n",c1);
fprintf(out_file,"c8     = %12.4e\n",c2);
fprintf(out_file,"c9     = %12.4e\n",c3);
fprintf(out_file,"c10    = %12.4e\n",c4);
fprintf(out_file,"c11    = %12.4e\n",c5);
fprintf(out_file,"cgs    = %12.4e\n",cgs);
fprintf(out_file,"cgd    = %12.4e\n",cdg);
fprintf(out_file,"i0     = %12.4e\n",i0);
fprintf(out_file,"n0     = %12.4e\n",n0);
fprintf(out_file,"r0     = %12.4e\n",r0);
fprintf(out_file,"i1     = %12.4e\n",i1);
fprintf(out_file,"n1     = %12.4e\n",n1);
fprintf(out_file,"r1     = %12.4e\n",r1);
fprintf(out_file,"ids0   = %12.4e\n",ids0);
fprintf(out_file,"ids1   = %12.4e\n",ids1);
fprintf(out_file,"ids2   = %12.4e\n",ids2);
fprintf(out_file,"ids3   = %12.4e\n",ids3);
fprintf(out_file,"ids4   = %12.4e\n",ids4);
fprintf(out_file,"!");
fclose(out_file);
}  

    
int string_index (string1,string2)
char   string1[];
char   string2[];

{
int    n1;
int    n2;
int    i;

n1 = strlen (string1);
n2 = strlen (string2);

for (i = 0; i <= (n1-n2); ++i)
   {
   if (strncmp (&(string1[i]),string2,n2) == 0)
      {
      return (i);
      }
   }

return (-1);

}















