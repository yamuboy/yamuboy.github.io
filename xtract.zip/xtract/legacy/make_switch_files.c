#include <stdio.h>
#include <string.h>
#include <math.h>

int string_index ();

main ()
{
float vds,ids,vgs,igs;
FILE  *in_file;
FILE  *out_file;
char  in_name[201];
char  out_name[201];
char  prefix[81];
char  temp[81];
char  header[50][201];
char  buffer[201];
int   cold_fet;
int   open_file;
int   header_done;
int   i,n;

printf ("multifile file name?\n");
scanf ("%200s",in_name);

printf ("prefix name for output files?\n");
scanf ("%80s",prefix);

in_file  = (FILE*) NULL;
out_file = (FILE*) NULL;

in_file = fopen (in_name,"r");
if ( in_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open file %s\n",in_name);
   exit (1);
   }

header_done = 0;
open_file = 0;
n = 0;

while (fgets (buffer,200,in_file) != NULL)
   {
   if (header_done == 0)
      {
      strcpy (header[n],buffer);
      ++n;
      }
   if ((string_index (buffer,"SWITCH FET S-PARAMETERS") > 0) && (header_done == 0))
      {
      header_done = 1;
      --n;
      }
   else if (string_index (buffer,"SWITCH FET S-PARAMETERS") > 0)
      {
      open_file = 0;
      }
   else if (string_index (buffer,"BIAS: VDS =") > 0)
      {
      if (open_file)
         {
         fclose (out_file);
         }
      sscanf (&(buffer[7]),"VDS = %f Volts IDS = %f Amps VGS = %f Volts IGS = %f Amps",&vds,&ids,&vgs,&igs);
      ids = ids*((double) 1.0e+3);
      igs = igs*((double) 1.0e+3);
      sprintf (out_name,"%ld",
      10000000L+
      ((unsigned long int)(vds*10.0+0.5))*10000L+
      ((unsigned long int)(fabs(vgs)*100.0+0.5)));
      sscanf (&(out_name[1]),"%7s",temp);
      if (vgs >= -2.0e-2)
         {
         temp[3] = 'p';
         }
      else
         {
         temp[3] = 'm';
         }
      strcpy (out_name,prefix);
      strcat (out_name,temp);
      strcat (out_name,".dmb");
      out_file = fopen (out_name,"w+");
      if ( out_file == (FILE*) NULL)
         {
         printf ("** error ** cannot open file %s\n",out_name);
         fclose (in_file);
         exit (1);
         }
      for (i = 0; i < n-1; ++i)
         {
         fprintf (out_file,"%s",header[i]);
         }
      fprintf (out_file,"!%s!\n",header[i]);
      fprintf (out_file,"# HZ S MA R 50\n");
      open_file = 1;
      }
   if (open_file)
      {
      fprintf (out_file,"%s",buffer);
      }
   }

fclose (in_file);
fclose (out_file);

}

/*                                                                   */
/*--- Function string_index -----------------------------------------*/
/*                                                                   */

int string_index (string1,string2)
char   string1[];
char   string2[];

{
int    n1;
int    n2;
int    i;

n1 = strlen (string1);
n2 = strlen (string2);

for (i = 0; i <= (n1-n2); ++i)
   {
   if (strncmp (&(string1[i]),string2,n2) == 0)
      {
      return (i);
      }
   }

return (-1);

}
