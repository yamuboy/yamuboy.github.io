#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "microwave_utilities.h"

#define MAX_FREQS (1000)

void get_the_time ();

main ()
{
POLAR s[4];
COMPLEX fxa[MAX_FREQS][4],fxb[MAX_FREQS][4],s_rect[4],s_abcd[4];
static COMPLEX ideal[4] = {{1.0,0.0},
                           {0.0,0.0},
                           {0.0,0.0},
                           {1.0,0.0}};
double freq,freq_p1[MAX_FREQS],freq_p2[MAX_FREQS];
char  string[256];
char  current_time[80];
char  batch_file_name[201];
char  extension[81];
char  out_file_name[81];
char  s_file_name[81];
char  system_command[201];
char  files_to_deembed[201];
char  in_file[201];
char  out_file[201];
FILE  *port1,*port2;
FILE  *s_file;
FILE  *dmb_file;
FILE  *batch_file;
int   num_port1_pts,num_port2_pts;
int   i,j,k,num_files,num_biases;
int   port1_ideal = 0,port2_ideal = 0;

printf ("File names to de-embed?\n> ");
scanf ("%s",files_to_deembed);

printf ("Input error box?\n> ");
scanf ("%s",in_file);

printf ("Output error box?\n> ");
scanf ("%s",out_file);

printf ("Extension for output files?\n> ");
scanf ("%s",extension);

get_the_time (current_time);
sprintf (batch_file_name,"batch_file.%s",current_time);

sprintf (system_command,"ls -1 %s > %s",files_to_deembed,batch_file_name);
system (system_command);

if (!strcmp (in_file,"ideal") || !strcmp (in_file,"IDEAL"))
   {
   port1_ideal = 1;
   }

if (!strcmp (out_file,"ideal") || !strcmp (out_file,"IDEAL"))
   {
   port2_ideal = 1;
   }

batch_file = (FILE*) NULL;
batch_file = fopen (batch_file_name,"r");
if (batch_file == (FILE*) NULL)
   {
   printf ("** error ** cannot open batch file\n");
   exit (1);
   }

if (!port1_ideal)
   {
   port1 = (FILE*) NULL;
   port1 = fopen (in_file,"r");
   if (port1 == (FILE*) NULL)
      {
      printf ("** error ** cannot open input error box file - %s\n",in_file);
      fclose (batch_file);
      exit (1);
      }

   i = 0;
   while (fgets (string,255,port1) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",&freq_p1[i],&s[0].mag,&s[0].ang,
          &s[2].mag,&s[2].ang,&s[1].mag,&s[1].ang,&s[3].mag,&s[3].ang) == 9)
         {
         if ((s[0].mag < (double) 0.0) || (s[1].mag < (double) 0.0) || (s[2].mag < (double) 0.0) || (s[3].mag < (double) 0.0))
            {
            s[0].mag = pow ((double) 10.0,(s[0].mag*((double) 0.05)));
            s[1].mag = pow ((double) 10.0,(s[1].mag*((double) 0.05)));
            s[2].mag = pow ((double) 10.0,(s[2].mag*((double) 0.05)));
            s[3].mag = pow ((double) 10.0,(s[3].mag*((double) 0.05)));
            }
         polar_2x2_rect (s,s_rect);
         s2abcd (s_rect,fxa[i],(double) 50.0);
         ++i;
         }
      if (i > 999)
         {
         printf ("** warning ** %s contains more than %d frequencies, first %d read.",in_file,MAX_FREQS,MAX_FREQS);
         break;
         }
      }
   num_port1_pts = i;

   fclose (port1);
   }

if (!port2_ideal)
   {
   port2 = (FILE*) NULL;
   port2 = fopen (out_file,"r");
   if (port2 == (FILE*) NULL)
      {
      fclose (batch_file);
      printf ("** error ** cannot open output error box file - %s\n",out_file);
      exit (1);
      }
   
   i = 0;
   while (fgets (string,255,port2) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",&freq_p2[i],&s[0].mag,&s[0].ang,
          &s[2].mag,&s[2].ang,&s[1].mag,&s[1].ang,&s[3].mag,&s[3].ang) == 9)
         {
         if ((s[0].mag < (double) 0.0) || (s[1].mag < (double) 0.0) || (s[2].mag < (double) 0.0) || (s[3].mag < (double) 0.0))
            {
            s[0].mag = pow ((double) 10.0,(s[0].mag*((double) 0.05)));
            s[1].mag = pow ((double) 10.0,(s[1].mag*((double) 0.05)));
            s[2].mag = pow ((double) 10.0,(s[2].mag*((double) 0.05)));
            s[3].mag = pow ((double) 10.0,(s[3].mag*((double) 0.05)));
            }
         polar_2x2_rect (s,s_rect);
         s2abcd (s_rect,fxb[i],(double) 50.0);
         ++i;
         }
      if (i > 999)
         {
         printf ("** warning ** %s contains more than %d frequencies, first %d read.",out_file,MAX_FREQS,MAX_FREQS);
         break;
         }
      }
   num_port2_pts = i;

   fclose (port2);
   }

printf ("de-embeding......\n");

num_biases = 0;
num_files = 0;
while (fgets (s_file_name,80,batch_file) != NULL)
   {
   s_file_name[strlen (s_file_name)-1] = '\0';
   sscanf (s_file_name,"%[^.]",out_file_name);
   strcat (out_file_name,extension);

   s_file = (FILE *) NULL;
   s_file = fopen (s_file_name,"r");
   if (s_file == (FILE *) NULL)
      {
      printf ("** error ** could not open file %s\n",s_file_name);
      continue;
      }
   dmb_file = fopen (out_file_name,"w+");
   ++num_files;

   i = 0;
   j = 0;
   while (fgets (string,255,s_file) != NULL)
      {
      if (sscanf (string,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",&freq,&s[0].mag,&s[0].ang,&s[2].mag,&s[2].ang,
             &s[1].mag,&s[1].ang,&s[3].mag,&s[3].ang) == 9)
         {
         if ((s[0].mag < (double) 0.0) || (s[1].mag < (double) 0.0) || (s[2].mag < (double) 0.0) || (s[3].mag < (double) 0.0))
            {
            s[0].mag = pow ((double) 10.0,(s[0].mag*((double) 0.05)));
            s[1].mag = pow ((double) 10.0,(s[1].mag*((double) 0.05)));
            s[2].mag = pow ((double) 10.0,(s[2].mag*((double) 0.05)));
            s[3].mag = pow ((double) 10.0,(s[3].mag*((double) 0.05)));
            }

         if (!port1_ideal)
            {
            while (freq_p1[i] < (freq - ((double) 1.0e3)))
               {
               ++i;
               if (i >= num_port1_pts)
                  {
                  break;
                  }
               }
            if (freq_p1[i] > (freq + ((double) 1.0e3)))
               {
               continue;
               }
            }
         
         if (!port2_ideal)
            {
            while (freq_p2[j] < (freq - ((double) 1.0e3)))
               {
               ++j;
               if (j >= num_port2_pts)
                  {
                  break;
                  }
               }
            if (freq_p2[j] > (freq + ((double) 1.0e3)))
               {
               continue;
               }
            }
         
         polar_2x2_rect (s,s_rect);
         s2abcd (s_rect,s_abcd,(double) 50.0);

         if (port1_ideal && port2_ideal)
            {
            deembed (ideal,s_abcd,ideal,s_abcd);
            }
         else if (port1_ideal)
            {
            deembed (ideal,s_abcd,fxb[j],s_abcd);
            }
         else if (port2_ideal)
            {
            deembed (fxa[i],s_abcd,ideal,s_abcd);
            }
         else
            {
            deembed (fxa[i],s_abcd,fxb[j],s_abcd);
            }

         abcd2s (s_abcd,s_rect,(double) 50.0);
         rect_2x2_polar (s_rect,s);

         /* fix any angles that don't fall into +/- 180 degrees */
         for (k = 0; k < 4; ++k)
            {
            while (s[k].ang < ((double) -180.0))
               {
               s[k].ang += (double) 360.0;
               }
            while (s[k].ang > ((double) 180.0))
               {
               s[k].ang -= (double) 360.0;
               }
            }

         fprintf (dmb_file,"%.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e %.5e %+.5e\n",freq,s[0].mag,s[0].ang,
                  s[2].mag,s[2].ang,s[1].mag,s[1].ang,s[3].mag,s[3].ang);
         }
      else if (!strncmp (string,"!BIAS: ",7))
         {
         ++num_biases;
         i = 0;
         j = 0;
         fprintf (dmb_file,"%s",string);
         }
      else
         {
         fprintf (dmb_file,"%s",string);
         }
      }
   fclose (s_file);
   fclose (dmb_file);
   }

fclose (batch_file);

sprintf (system_command,"rm -f %s",batch_file_name);
system (system_command);

printf ("%d files (%d bias points) successfully de-embeded.\n",num_files,num_biases);

exit (0);

}

/*                                                                   */
/*--- Function get_the_time -----------------------------------------*/
/*                                                                   */

void get_the_time (string)
char  string[];

{
time_t clock;
char  *pointer;
char  s_day[3];
char  s_month[4];
char  s_year[5];
char  s_time[9];

time (&clock);

pointer = asctime (localtime (&clock));

sscanf (pointer+8,"%2s",s_day);
sscanf (pointer+4,"%3s",s_month);
sscanf (pointer+20,"%4s",s_year);
sscanf (pointer+11,"%8s",s_time);

sprintf (string,"%s-%s-%s-%s",s_day,s_month,s_year,s_time);

return;

}
