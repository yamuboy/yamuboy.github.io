#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "cmplxlib.h"
#include "jplot.h"

#define MAX_FREQS 1000
#define ADDITIONAL_OS   4

static int plot_tdr (int device, char *fname, double *freq, COMPLEX *s11, COMPLEX *s12,
                     COMPLEX *s21, COMPLEX *s22, unsigned n, double end_time);
static void cifft (COMPLEX *x, unsigned long npts);

/********************************************************************************/
/********************************************************************************/

int main (int argc, char *argv[])
   {
   char string[256],filename[256],*ptr;
   double end_time;
   double m11,m12,m21,m22;
   double a11,a12,a21,a22;
   FILE *file;
   double freq[MAX_FREQS];
   COMPLEX s11[MAX_FREQS];
   COMPLEX s12[MAX_FREQS];
   COMPLEX s21[MAX_FREQS];
   COMPLEX s22[MAX_FREQS];
   int ri_format = 0;
   int db_format = 0;
   double fmult = 1.0;
   double last_freq = 0.0;
   unsigned i = 0;
      
   printf ("S-Parameter file name?\n");
   fgets (string,255,stdin);
   sscanf (string,"%s",filename);
   
   printf ("TDR end time (nanoseconds)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&end_time);
   
   file = fopen (filename,"r");
   if (!file)
      {
      fprintf (stderr,"File not found!\n\n");
      return -1;
      }
   
   while (fgets (string,255,file))
      {
      if (string[0] == '!')
         continue;
      else if (ptr = strstr (string,"# "))
         {
         if (strstr (ptr,"db") || strstr (ptr,"DB") || strstr (ptr,"Db"))
            db_format = 1;
         if (strstr (ptr,"ri") || strstr (ptr,"RI") || strstr (ptr,"Ri"))
            ri_format = 1;
         
         if (strstr (ptr,"ghz") || strstr (ptr,"GHZ") || strstr (ptr,"Ghz"))
            fmult = 1.0e9;
         else if (strstr (ptr,"mhz") || strstr (ptr,"MHZ") || strstr (ptr,"Mhz"))
            fmult = 1.0e6;
         else if (strstr (ptr,"khz") || strstr (ptr,"KHZ") || strstr (ptr,"Khz"))
            fmult = 1.0e3;
         }
      
      if (i >= MAX_FREQS)
         {
         fprintf (stderr,"Warning: maximum frequency points exceeded.\n");
         break;
         }
      
      if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq[i],&m11,&a11,&m21,&a21,
         &m12,&a12,&m22,&a22) == 9)
         {
         freq[i] *= fmult;
         
         if (freq[i] <= last_freq)
            break;
         
         last_freq = freq[i];
         
         if (ri_format)
            {
            s11[i] = Cnum (m11,a11);
            s12[i] = Cnum (m12,a12);
            s21[i] = Cnum (m21,a21);
            s22[i] = Cnum (m22,a22);
            }
         else
            {
            if (db_format)
               {
               m11 = pow (10.0,m11*0.05);
               m12 = pow (10.0,m12*0.05);
               m21 = pow (10.0,m21*0.05);
               m22 = pow (10.0,m22*0.05);
               }
         
            s11[i] = P2C (Pnum (m11,a11));
            s12[i] = P2C (Pnum (m12,a12));
            s21[i] = P2C (Pnum (m21,a21));
            s22[i] = P2C (Pnum (m22,a22));
            }
         
         ++i;
         }
      }
   
   fclose (file);
   
   plot_tdr (X_WINDOWS, NULL, freq, s11, s12, s21, s22, i, end_time);
   
   return 0;
   }

/********************************************************************************/
/********************************************************************************/

static int plot_tdr (int device, char *fname, double *freq, COMPLEX *s11, COMPLEX *s12,
                     COMPLEX *s21, COMPLEX *s22, unsigned n, double end_time)
   {
   unsigned long fft_size,i,npts;
   double max_len,tstep;
   double *t,*y;
   COMPLEX *x;
   static COMPLEX zero = {0.0,0.0};
   jPLOT_ITEM *plot;
   
   if (n < 64)
      fft_size = 128*ADDITIONAL_OS;
   else if (n < 128)
      fft_size = 256*ADDITIONAL_OS;
   else if (n < 256)
      fft_size = 512*ADDITIONAL_OS;
   else if (n < 512)
      fft_size = 1024*ADDITIONAL_OS;
   else
      fft_size = 2048*ADDITIONAL_OS;

   max_len = 1.0e9 / freq[0];
   tstep = max_len / ((double) fft_size);
   
   if (end_time > max_len)
      {
      fprintf (stderr,"Warning: TDR end time reset.\n");
      end_time = max_len;
      }
   
   if (!open_graphics_device (device, fname))
      {
      fprintf (stderr,"Failed to open display.\n");
      return -1;
      }
   
   plot = create_plot_item (SingleY, 1.5, 1.5, 8.0, 5.5);
      
   x = (COMPLEX *) malloc (sizeof(COMPLEX)*fft_size);
   t = (double *) malloc (sizeof(double)*fft_size);
   y = (double *) malloc (sizeof(double)*fft_size);
   
   for (i = 0; i < fft_size; ++i)
      t[i] = tstep*((double) i);
   
   /********** S11 **********/

   x[0] = zero;
   for (i = 0; i < n; ++i)
      x[i+1] = x[fft_size-i-1] = s11[i];
   for (i = n; i <= fft_size/2; ++i)
      x[i+1] = x[fft_size-i-1] = zero;
   
   cifft (x, fft_size);
   
   for (i = 0, npts = 0; i < fft_size; ++i, ++npts)
      {
      if (t[i] > end_time)
         break;
      
      y[i] = x[i].r;
      }
   
   if (npts > 2)
      {
      attach_y1data (plot, t, y, npts, LT_SOLID, 1, CLR_RED);
      set_axis_labels (plot, "Time (ns)", "Amplitude", NULL, "S11 Time-Domain");
   
      draw_page ();
      }
   else
      fprintf (stderr,"Unable to plot S11 TDR. Not enough points.\n");
      
   /********** S12 **********/
   
   x[0] = zero;
   for (i = 0; i < n; ++i)
      x[i+1] = x[fft_size-i-1] = s12[i];
   for (i = n; i <= fft_size/2; ++i)
      x[i+1] = x[fft_size-i-1] = zero;
   
   cifft (x, fft_size);
   
   for (i = 0, npts = 0; i < fft_size; ++i, ++npts)
      {
      if (t[i] > end_time)
         break;
      
      y[i] = x[i].r;
      }
   
   if (npts > 2)
      {
      attach_y1data (plot, t, y, npts, LT_SOLID, 1, CLR_RED);
      set_axis_labels (plot, "Time (ns)", "Amplitude", NULL, "S12 Time-Domain");
   
      draw_page ();
      }
   else
      fprintf (stderr,"Unable to plot S12 TDR. Not enough points.\n");
         
   /********** S21 **********/   
      
   x[0] = zero;
   for (i = 0; i < n; ++i)
      x[i+1] = x[fft_size-i-1] = s21[i];
   for (i = n; i <= fft_size/2; ++i)
      x[i+1] = x[fft_size-i-1] = zero;
   
   cifft (x, fft_size);
   
   for (i = 0, npts = 0; i < fft_size; ++i, ++npts)
      {
      if (t[i] > end_time)
         break;
      
      y[i] = x[i].r;
      }
   
   if (npts > 2)
      {
      attach_y1data (plot, t, y, npts, LT_SOLID, 1, CLR_RED);
      set_axis_labels (plot, "Time (ns)", "Amplitude", NULL, "S21 Time-Domain");
   
      draw_page ();
      }
   else
      fprintf (stderr,"Unable to plot S21 TDR. Not enough points.\n");
      
   /********** S22 **********/
   
   x[0] = zero;
   for (i = 0; i < n; ++i)
      x[i+1] = x[fft_size-i-1] = s22[i];
   for (i = n; i <= fft_size/2; ++i)
      x[i+1] = x[fft_size-i-1] = zero;
   
   cifft (x, fft_size);
   
   for (i = 0, npts = 0; i < fft_size; ++i, ++npts)
      {
      if (t[i] > end_time)
         break;
      
      y[i] = x[i].r;
      }
   
   if (npts > 2)
      {
      attach_y1data (plot, t, y, npts, LT_SOLID, 1, CLR_RED);
      set_axis_labels (plot, "Time (ns)", "Amplitude", NULL, "S22 Time-Domain");
   
      draw_page ();
      }
   else
      fprintf (stderr,"Unable to plot S22 TDR. Not enough points.\n");
   
   close_graphics_device ();
   
   free ((void *) x);
   free ((void *) y);
   free ((void *) t);
   
   return 0;
   }
      
/********************************************************************************/
/********************************************************************************/

static void cifft (COMPLEX *x, unsigned long npts)
   {
#define imod(x,y)  ((x) - ((long) ((x)/(y)))*(y))
   unsigned long i,j,m,mr;
   COMPLEX  tmp;
   POLAR    tmpp;

   mr = 0;
   for (m = 1; m < npts; ++m)
      {
      j = npts/2;
      while ((mr+j) >= npts)
         j = j/2;
 
      mr = imod (mr,j) + j;

      if (mr > m)
         {
         tmp = x[m];
         x[m] = x[mr];
         x[mr] = tmp;
         }
      }

   j = 1;
   while (j < npts)
      {
      for (m = 0; m < j; ++m)
         {
         for (i = m; i < npts; i += 2*j)
            {
            tmpp.m = 1.0;
            tmpp.a = 180.0*((double) m)/((double) j);
            tmp = P2C (tmpp);
            tmp = Cmult (tmp,x[i+j]);

            x[i+j] = Csub (x[i],tmp);
            x[i] = Cadd (x[i],tmp);
            }
         }

      j *= 2;
      }
   }

   
   
   
