#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PARAMS   100

char *list_command = "ls -1";
char *del_command = "rm -f";
char *mv_command = "mv -f";

static void remove_extension (char *in_name, char *out_name, unsigned max_size);
static void sort_mdif_model_file (char *mdfname);
static char *append_string (char *str1, char *str2);

/*****************************************************************************/
/*****************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *flist,*infile,*outfile;
   time_t tbuf;
   char tmp_file[256];
   char file_list[256];
   char fname[256];
   char mdfname[256];
   char string[256];
   unsigned pcount = 0;
   char *pnames[MAX_PARAMS];
   double pvalues[MAX_PARAMS];
   char str_tab[MAX_PARAMS][25];
   // int model_number = 0;
   char model_name[25];
   double tmp;
   unsigned i;
   
   printf ("File(s) to convert?\n");
   fgets (file_list, 255, stdin);
   file_list[strlen(file_list)-1] = 0;
   
   // line up the string table addresses
   for (i = 0; i < MAX_PARAMS; ++i)
      pnames[i] = &str_tab[i][0];
   
   // create a temporary file of file names
   sprintf (tmp_file, "tmp.%d", time (&tbuf));
   sprintf (string, "%s %s", del_command, tmp_file);
   system (string);
   sprintf (string, "%s %s > %s", list_command, file_list, tmp_file);
   system (string); 
   
   flist = fopen (tmp_file, "r");
   if (!flist)
      {
      printf ("Unable to get file listing.\n");
      return 1;
      }
   
   while (fgets (fname, 255, flist))
      {
      fname[strlen(fname)-1] = 0;
      remove_extension (fname, mdfname, 10);
      strcat (mdfname, ".mdf");
      
      infile = fopen (fname, "r");
      if (!infile)
         {
         printf ("Could not open file: %s\n", fname);
         continue;
         }
      
      outfile = fopen (mdfname, "w+");
      if (!outfile)
         {
         printf ("Could not create output file: %s\n", mdfname);
         fclose (infile);
         continue;
         }
      
      while (fgets (string, 255, infile))
         {
         if (string[0] == '!')
            fprintf (outfile, "%s", string);
         else if (!strncmp (string, "model", 5))
            {
            // write the parameters of the previous model
            if (pcount)
               {
               fprintf (outfile, "VAR model(2) = %s\n", model_name);
               write_model_param_mdif (outfile, pnames, pvalues, pcount, 12, 5);
               pcount = 0;
               }

            sscanf (string, "model = %19s", model_name);
            }
         else if (sscanf (string, "%*s = %lf", &tmp))
            {
            if (pcount >= MAX_PARAMS)
               {
               printf ("Warning: maximum number of parameters exceeed.\n");
               continue;
               }
               
            if (sscanf (string, "%19s = %lf", pnames[pcount], &pvalues[pcount]) == 2)
               {
               pnames[pcount][19] = 0;
               strcat (pnames[pcount], "(1)");
               ++pcount;
               }
            }
         }
      
      // write the parameters of the previous model
      if (pcount)
         {
         fprintf (outfile, "VAR model(2) = %s\n", model_name);
         write_model_param_mdif (outfile, pnames, pvalues, pcount, 12, 5);
         pcount = 0;
         }
      
      fclose (infile);
      fclose (outfile);
      
      // sort_mdif_model_file (mdfname);
      }

   // remove temporary file
   sprintf (string, "%s %s", del_command, tmp_file);
   system (string);
                 
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void remove_extension (char *in_name, char *out_name, unsigned max_size)
   {
   unsigned i,n;
   unsigned len = strlen (in_name);
   
   n = len;
   for (i = 0; i < max_size; ++i)
      {
      if (((len-i) < 1) || (in_name[len-i] == '/'))
         break;
      else if (in_name[len-i] == '.')
         {
         n = len-i;
         break;
         }
      }
   
   for (i = 0; i < n; ++i)
      out_name[i] = in_name[i];
   out_name[n] = 0;
   }
         
/*****************************************************************************/
/*****************************************************************************/

static void sort_mdif_model_file (char *mdfname)
   {
#define MAX_MODELS  200
   FILE *infile,*outfile;
   char tmpname[256];
   char string[256];   
   int header = 1;
   struct {int num; char *data;} mdata[MAX_MODELS];
   int count = 0;
   int max_model = 0;
   int i,j;
   
   infile = fopen (mdfname, "r");
   if (!infile)
      {
      printf ("Warning: unable to sort file - %s\n", mdfname);
      return;
      }
   
   strcpy (tmpname, mdfname);
   strcat (tmpname, ".temp");
   
   outfile = fopen (tmpname, "w+");
   if (!outfile)
      {
      printf ("Warning: unable to sort file - %s\n", mdfname);
      return;
      }
   
   // read in model data, and write the header
   mdata[count].data = NULL;
   mdata[count].num = 0;
   while (fgets (string, 255, infile))
      {
      if (header)
         {
         if (!strncmp (string, "!FILE", 5))
            header = 0;
         else
            fprintf (outfile, "%s", string);
         }
      else
         {
         if (!strncmp (string, "!FILE:", 5))
            {
            ++count;
            
            if (count >= MAX_MODELS-1)
               {
               printf ("Warning: max models exceeded during sort.\n");
               break;
               }
               
            mdata[count].data = NULL;
            mdata[count].num = 0;
            }
         else if (!strncmp (string, "VAR model =", 11))
            {
            sscanf (string, "VAR model = %d", &mdata[count].num);
            if (mdata[count].num > max_model)
               max_model = mdata[count].num;
            }
         
         mdata[count].data = append_string (mdata[count].data, string);
         }
      }
      
   ++count;
      
   // write model data
      
   for (i = 0; i <= max_model; ++i)
      {
      for (j = 0; j < count; ++j)
         {
         if (i == mdata[j].num)
            fprintf (outfile, "%s", mdata[j].data);
         }
      }
         
   fclose (infile);
   fclose (outfile);
   
   for (i = 0; i < count; ++i)
      free ((void *) mdata[i].data);
   
   // rename the temp file to the actual data file
   sprintf (string, "%s %s %s", mv_command, tmpname, mdfname);
   system (string);
   }      

/*****************************************************************************/
/*****************************************************************************/

static char *append_string (char *str1, char *str2)
   {
   char *ret = (char *) malloc (sizeof (char) * (strlen(str1) + strlen(str2) + 1));
   
   strcpy (ret, str1);
   strcat (ret, str2);

   free ((void *) str1);
   
   return ret;
   }

      

