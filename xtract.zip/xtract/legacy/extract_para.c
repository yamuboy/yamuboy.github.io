#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "cmplxlib.h"
#include "jplot.h"

#define MAX_PARA_FILES   10

/********************** GLOBAL VARIABLES **********************/

double ibep[MAX_PARA_FILES];
double rb1[MAX_PARA_FILES];
double rc1[MAX_PARA_FILES];
double re1[MAX_PARA_FILES];
double lb1[MAX_PARA_FILES];
double lc1[MAX_PARA_FILES];
double le1[MAX_PARA_FILES];
double rb_slope,rb_val;
double rc_slope,rc_val;
double re_slope,re_val;
double lb_slope,lb_val;
double lc_slope,lc_val;
double le_slope,le_val;
int num_para_pts;
char header_file_name[256];

/******************** FUNCTION PROTOTYPES *********************/

static int hot_hbt_extraction (char files[], double fstart, double fstop);
static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2);
static void linefit_mx0 (double *x, double *y, int n, double *m, double *r2);
static int plot_data (char *fname, int device);

/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/
/*******************************************************************************************/

int main (int argc, char *argv[])
   {
   char files[256];
   char string[256];
   double fmin,fmax;
   int i;
   int device = X_WINDOWS;
   
   for (i = 1; i < argc; ++i)
      {
      if (!strcmp (argv[i],"-post"))
         device = POSTSCRIPT;
      else if (!strcmp (argv[i],"-wmf"))
         device = METAFILE;
      }
   
   printf ("Parasitic extraction files?\n");
   fgets (files,255,stdin);
   files[strlen(files)-1] = 0;
   
   printf ("Minimum and Maximum Frequencies for Inductance (in GHz)?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf%lf",&fmin,&fmax);
   fmin *= 1.0e9;
   fmax *= 1.0e9;
   
   if (hot_hbt_extraction (files,fmin,fmax))
      {
      fprintf (stderr,"Error occured. Exiting.\n");
      return -1;
      }
   
   if (plot_data (header_file_name,device))
      {
      fprintf (stderr,"Unable to plot data.\n");
      return -1;
      }   
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

static int hot_hbt_extraction (char files[], double fstart, double fstop)
   {
#define MAX_FREQS  200
   char tmp_file_name[100],string[256];
   time_t dummy;
   FILE *file_list,*infile;
   int i = 0;
   int j,found,first;
   double rb,rc,re,freq,r2;
   double lb[MAX_FREQS],lc[MAX_FREQS],le[MAX_FREQS],w[MAX_FREQS];
   COMPLEX sr[4],z[4];
   POLAR s[4];

   sprintf (tmp_file_name,"tmpfile.%d",time(&dummy));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string,"ls -1 %s > %s",files,tmp_file_name);
   system (string);

   file_list = fopen (tmp_file_name,"r");
   if (!file_list)
      {
      sprintf (string,"rm -f %s",tmp_file_name);
      system (string);
      return -1;
      }

   while (fgets(string,255,file_list))
      {
      if (i >= MAX_PARA_FILES)
         {
         printf ("WARNING: too many files.\n");
         break;
         }

      string[strlen(string)-1] = 0;
      infile = fopen (string,"r");
      if (!infile)
         continue;
      
      if (!i)
         strcpy (header_file_name,string);

      j = 0;
      found = 0;
      first = 1;
      while (fgets(string,255,infile))
         {
         if (!strncmp(string,"!BIAS",5))
            {
            if (sscanf (string,"!BIAS: VCE = %*f Volts ICE = %*f Amps VBE = %*f Volts IBE = %lf Amps",&ibep[i]) == 1)
               {
               ibep[i] = 1.0/ibep[i];
               found = 1;
               }
            else if (sscanf (string,"!BIAS: VDS = %*f Volts IDS = %*f Amps VGS = %*f Volts IGS = %lf Amps",&ibep[i]) == 1)
               {
               ibep[i] = 1.0/ibep[i];
               found = 1;
               }
            }
         else if (string[0] == '!')
            continue;

         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].m,&s[0].a,&s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
            {
            if (freq < fstart)
               continue;
            else if (freq > fstop)
               break;

            if (j >= MAX_FREQS)
               {
               printf ("WARNING: too many frequency points in range.\n");
               break;
               }

            s2z (PA2CA (s,sr,2,2),z,50.0);
            w[j] = 2.0*PI*freq;

            if (first)
               {
               rb = Creal (Csub(z[0],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
               rc = Creal (Csub(z[3],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
               re = Creal (Cmult(Cadd(z[1],z[2]),Complex(0.5)));
               first = 0;
               }

            lb[j] = Cimag (Csub(z[0],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
            lc[j] = Cimag (Csub(z[3],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
            le[j] = Cimag (Cmult(Cadd(z[1],z[2]),Complex(0.5)));

            ++j;
            }
         }

      if (j < 2)
         {
         printf ("WARNING: too few frequency points in range.\n");
         fclose (infile);
         continue;
         }

      if (!found)
         {
         printf ("WARNING: BIAS line not found.\n");
         fclose (infile);
         continue;
         }

      rb1[i] = rb;
      rc1[i] = rc;
      re1[i] = re;

      linefit_mx0 (w,lb,j,&lb1[i],&r2);
      linefit_mx0 (w,lc,j,&lc1[i],&r2);
      linefit_mx0 (w,le,j,&le1[i],&r2);

      fclose (infile);
      ++i;
      }

   fclose (file_list);
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);

   num_para_pts = i;

   if (num_para_pts < 2)
      {
      printf ("ERROR: too few files.\n");
      return -1;
      }

   linefit_mxb (ibep,rb1,num_para_pts,&rb_slope,&rb_val,&r2);
   linefit_mxb (ibep,rc1,num_para_pts,&rc_slope,&rc_val,&r2);
   linefit_mxb (ibep,re1,num_para_pts,&re_slope,&re_val,&r2);
   linefit_mxb (ibep,lb1,num_para_pts,&lb_slope,&lb_val,&r2);
   linefit_mxb (ibep,lc1,num_para_pts,&lc_slope,&lc_val,&r2);
   linefit_mxb (ibep,le1,num_para_pts,&le_slope,&le_val,&r2);

   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2)
   {
   int i;
   double xsum = 0.0;
   double ysum = 0.0;
   double xxsum = 0.0;
   double yysum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 1)
      {
      *m = 0.0;
      *b = 0.0;
      *r2 = 0.0;
      return;
      }

   for (i = 0; i < n; ++i)
      {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
      }

   *m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
   *b  = (xxsum*ysum - xysum*xsum) / (xxsum*((double) n) - xsum*xsum);
   // *r2 = xysum*xysum / (xxsum*yysum);

   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] + (*b) - y[i])*((*m)*x[i] + (*b) - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mx0 (double *x, double *y, int n, double *m, double *r2)
   {
   int i;
   double ysum = 0.0;
   double xxsum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   for (i = 0; i < n; ++i)
      {
      ysum  += y[i];
      xxsum += x[i]*x[i];
      xysum += x[i]*y[i];
      }

   *m = xysum / xxsum;
   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] - y[i])*((*m)*x[i] - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }
   
/*******************************************************************************************/
/*******************************************************************************************/

static int plot_data (char *fname, int device)
   {
   jPLOT_ITEM      *plot1;
   int             i,j,n;
   char            string[200],head[1000];
   double          x1data[MAX_PARA_FILES*3];
   double          x2data[6];
   double          y1data[MAX_PARA_FILES*3];
   double          line1[6];
   static char     *legend_t[] = {"Modeled","Measured"};
   static int      legend_l2[] = {LT_SOLID,PNT_CIRCLE};
   static int      legend_w2[] = {1,2};
   static int      legend_c[] = {CLR_RED,CLR_BLUE};
   jHANDLE         txt1,legend1,header;
   FILE            *infile;

   if (!open_graphics_device (device,NULL))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }
      
   head[0] = 0;
   infile = fopen (fname,"r");
   while (fgets(string,199,infile))
      {
      if (!strncmp(string,"!FILE",4))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!MASK",4))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!WAFER",5))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!DEVICE",7))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!EMITTER AREA",13))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!TEMP",5))
         strcat(head,&string[1]);
      else if (string[0] != '!')
         break;
      }
   fclose (infile);

   plot1 = create_plot_item (SingleY,1.75,1.25,6.0,5.0);
   plot1->attribs.title_offset = 0.3;
   header = add_text (head,4.75,7.8,FNT_COURIER,12,0.0,CENTER_JUSTIFY,CLR_BLACK,0);

   /**** Resistances ****/
   
   for (i = 0,j = 0; i < num_para_pts; ++i, j += 3)
      {
      x1data[j] = x1data[j+1] = x1data[j+2] = ibep[i];
      y1data[j] = rb1[i];
      y1data[j+1] = rc1[i];
      y1data[j+2] = re1[i];
      }
      
   attach_y1data (plot1,x1data,y1data,num_para_pts*3,PNT_CIRCLE,2,CLR_BLUE);
     
   // create fit lines....
   x2data[0] = x2data[2] = x2data[4] = 0.0;
   x2data[1] = x2data[3] = x2data[5] = ibep[0];
   line1[0] = rb_val;
   line1[1] = rb_val + rb_slope*ibep[0];
   line1[2] = rc_val;
   line1[3] = rc_val + rc_slope*ibep[0];
   line1[4] = re_val;
   line1[5] = re_val + re_slope*ibep[0];
      
   attach_y1data (plot1,x2data,line1,6,LT_SOLID,1,CLR_RED);
      
   legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l2,legend_w2,legend_c);
   set_axis_labels (plot1,"1/Ibe (1/amp)","Resistance (ohms)","","Port Resistances");
      
   sprintf (string,"Rb = %.3f ohms\nRc = %.3f ohms\nRe = %.3f ohms",rb_val,rc_val,re_val);
   txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
   if (!draw_page ())
      {
      close_graphics_device ();
      return -1;
      }   
      
   remove_user_item (txt1);
   detach_data (plot1);
      
   /**** Inductances ****/
     
   for (i = 0,j = 0; i < num_para_pts; ++i, j += 3)
      {
      x1data[j]   = x1data[j+1] = x1data[j+2] = ibep[i];
      y1data[j]   = lb1[i]*1.0e12;
      y1data[j+1] = lc1[i]*1.0e12;
      y1data[j+2] = le1[i]*1.0e12;
      }
      
   attach_y1data (plot1,x1data,y1data,num_para_pts*3,PNT_CIRCLE,2,CLR_BLUE);
      
   // create fit lines....
   x2data[0] = x2data[2] = x2data[4] = 0.0;
   x2data[1] = x2data[3] = x2data[5] = ibep[0];
   line1[0] = lb_val*1.0e12;
   line1[1] = (lb_val + lb_slope*ibep[0])*1.0e12;
   line1[2] = lc_val*1.0e12;
   line1[3] = (lc_val + lc_slope*ibep[0])*1.0e12;
   line1[4] = le_val*1.0e12;
   line1[5] = (le_val + le_slope*ibep[0])*1.0e12;
      
   attach_y1data (plot1,x2data,line1,6,LT_SOLID,1,CLR_RED);
    
   set_axis_labels (plot1,"1/Ibe (1/amp)","Inductance (pF)","","Port Inductances");
    
   sprintf (string,"Lb = %.3f pH\nLc = %.3f pH\nLe = %.3f pH",lb_val*1.0e12,
      lc_val*1.0e12,le_val*1.0e12);
   txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
   if (!draw_page ())
      {
      close_graphics_device ();
      return -1;
      }   

   close_graphics_device ();
   
   return 0;
   }   
