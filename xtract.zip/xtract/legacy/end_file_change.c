#include <stdio.h>
#include <string.h>

int main ()
{
char     string[256];
FILE     *file1,*file2;
char     file_name[81];
char     param1[30],param[30];
char     sys_command[81];
char     lines[51][201];
double   min,max,var,tol,value;
int      i,j,column,completed,error;

printf ("File(s) to change?\n");
gets (string);
sscanf (string,"%s",sys_command);

sprintf (string,"ls -1 %s > batch939420839024843",sys_command);
system (string);

while (1)
{

printf ("Parameter to change or \"exit\" to quit?\n");
gets (string);
sscanf (string,"%s",param1);

if (!strncmp (param1,"exit",4))
   {
   break;
   }

printf ("Column to change?\n   1. Minimum\n   2. Nominal\n   3. Maximum\n");
gets (string);
sscanf (string,"%d",&column);

printf ("New value for %s column %d?\n",param1,column);
gets (string);
sscanf (string,"%lf",&value);

file1 = (FILE *) NULL;
file1 = fopen ("batch939420839024843","r");
if (file1 == (FILE *) NULL)
   {
   printf ("** error ** unable to open batch file\n");
   exit (1);
   }

while (fgets (string,255,file1) != NULL)
   {
   sscanf (string,"%s",file_name);
   file2 = (FILE *) NULL;
   file2 = fopen (file_name,"r");
   if (file2 == (FILE *) NULL)
      {
      printf ("** error ** unable to open file: %s\n",file_name);
      continue;
      }
   
   i = 0;
   completed = 0;
   error = 0;
   
   while (fgets (lines[i],200,file2) != NULL)
      {
      sscanf (lines[i]," %lf %lf %lf %lf %s",&min,&var,&max,&tol,param);
      if (strcmp (param,param1) == 0)
         {
         switch (column)
            {
            case 1:
               sprintf (lines[i]," %11.4E %11.4E %11.4E %11.4E %s\n",value,var,max,tol,param);
               completed = 1;
               break;
            case 2:
               sprintf (lines[i]," %11.4E %11.4E %11.4E %11.4E %s\n",min,value,max,tol,param);
               completed = 1;
               break;
            case 3:              
               sprintf (lines[i]," %11.4E %11.4E %11.4E %11.4E %s\n",min,var,value,tol,param);
               completed = 1;
               break;
            default:
               completed = 0;
               break;
            }
         }
      
      ++i;
      if (i > 50)
         {
         error = 1;
         break;
         }
      }
      
   fclose (file2);
   
   if (error == 1)
      {
      printf ("** error ** %s is too large, only 50 lines are allowed\n",file_name);
      continue;
      }
   
   if (completed == 0)
      {
      printf ("** error ** %s not found in file %s, no changes made\n",param1,file_name);
      continue;
      }      

   file2 = fopen (file_name,"w+");
   
   for (j = 0; j < i; ++j)
      {
      fprintf (file2,"%s",lines[j]);
      }
   
   fclose (file2);

   }
      
fclose (file1);

} /* while loop closing bracket */

sprintf (string,"rm batch939420839024843");
system (string);

}


