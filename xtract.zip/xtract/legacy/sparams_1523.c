#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   int i;
   FILE *in, *out;
   double vgs, vds, igs, ids;
   int b_count;
   int write_data=1;
   char str[256];
   

   if (argc < 2)
      {
      printf ("\n\n");
      printf ("USAGE: %s [files]\n", argv[0]);
      printf ("-------------------------------------------------\n");
      printf ("  Parsing tool for 1523 MAAPSS0109 data files.\n");
      printf ("\n\n");
      return 0;
      }
   
   
   for (i = 1; i < argc; ++i)
      {
      strcpy( str, argv[i] );
      strcat( str, ".s2p" );

      in = fopen( argv[i], "r" );
      if( !in )
         {
         printf( "Warning: %s: file not found.\n", argv[i] );
         continue;
         }
       
      out = fopen( str, "w+" );
      if( !out )
         {
         printf( "Error: unable to write to disc.\n" );
         return 1;
         }

      b_count = 0;
      write_data=1;
      while( fgets( str, 255, in ) )
         {
         if( str[0] == '#' )
            continue;

         if( sscanf( str, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf Amps",
             &vds, &ids, &vgs, &igs ) == 4 )
            {
            if( b_count == 1 )
               {
               fprintf( out, "# HZ S MA R 50\n" );
	       write_data=1;
	       } 
            else if( b_count > 1 )
               break;
	    else
               {
               b_count++;
	       write_data=0;
               }
            }
         
         if( write_data )
            fprintf( out, "%s", str );      
         }
      
      fclose( in );
      fclose( out );
      }
   
   return 0;
   }


