#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>

#define RAD2DEG   ((double) 57.2957795131)

int string_index (char *sta, char *stb);
char **packetize_string (char *str, int max);
void free_packets (char **str);
int get_values (char *str, int *cols, int ncols, ...);

main ()
{
char    file_name[256];
char    out_name[256];
char    batch_name[80];
char    string[201];
char    plot_name[80];
double  p_in,pow_in,pow_out;
double  eff,acpu,acpl,altu,altl;
double  acp,alt,mag,ang;
double  real,imag,freq;
int     device;
int     first,i;
int     columns[7];
FILE    *infile;
FILE    *outfile;
time_t  dummyt;
char    **xxx;

printf ("Maury load pull file name > ");
scanf ("%255s",file_name);

printf ("Input power level > ");
scanf ("%lf",&p_in);

printf ("Plot file name > ");
scanf ("%79s",plot_name);

printf ("Plotting Device (10=Postscript, 11=X-Windows, 12=Metafile) > ");
scanf ("%d",&device);

sscanf (file_name,"%[^.]",out_name);
strcat (out_name,".temp");

infile = fopen (file_name,"r");
if (infile == (FILE *) NULL)
   {
   printf ("ERROR: cannot open file \"%s\"\n",file_name);
   return (-1);
   }

for (i = 0; i < 7; ++i)
   {
   columns[i] = -1;
   }

outfile = fopen (out_name,"w+");

first = 1;
while (fgets (string,200,infile) != NULL)
   {
   if (first)
      {
      if (!strncmp (string,"Frequency range:",16))
         {
         sscanf (&string[16],"%lf",&freq);
         }

      if ((i = string_index (string,"Source = (")) >= 0)
         {
         sscanf (&string[i+9],"(%lf %lf)",&real,&imag);
         mag = sqrt (real*real+imag*imag);
         ang = atan2 (imag,real)*RAD2DEG;
         fprintf (outfile,"! Source Reflection Coefficient: ( %.3f < %.1f )\n",mag,ang);
         fprintf (outfile,"! Frequency: %.3f GHz\n",freq);
         fprintf (outfile,"! Input Power Level: %.1f dBm\n",p_in);
         i = string_index (string,"Load = (");
         sscanf (&string[i+7],"(%lf %lf)",&real,&imag);
         mag = sqrt (real*real+imag*imag);
         ang = atan2 (imag,real)*RAD2DEG;
         if (fgets (string,200,infile) != NULL)
            {
            xxx = packetize_string (string,30);
            i = 0;
            while (xxx[i] != NULL)
               {
               if (!strcmp (xxx[i],"Pin_avail_dBm"))
                  {
                  columns[0] = i;
                  }                
               else if (!strcmp (xxx[i],"Pout_dBm"))
                  {
                  columns[1] = i;
                  }
               else if (!strcmp (xxx[i],"Eff_%"))
                  {
                  columns[2] = i;
                  }
               else if (!strcmp (xxx[i],"acp_adj_up"))
                  {
                  columns[3] = i;
                  }
               else if (!strcmp (xxx[i],"acp_adj_lo"))
                  {
                  columns[4] = i;
                  }
               else if (!strcmp (xxx[i],"acp_alt_up"))
                  {
                  columns[5] = i;
                  }
               else if (!strcmp (xxx[i],"acp_alt_lo"))
                  {
                  columns[6] = i;
                  }
               ++i;
               }
            free_packets (xxx);
            }
         first = 0;
         }
      }

   else
      {
      if ((i = string_index (string,"Load = (")) >= 0)
         {
         sscanf (&string[i+7],"(%lf %lf)",&real,&imag);
         mag = sqrt (real*real+imag*imag);
         ang = atan2 (imag,real)*RAD2DEG;
         }
      
      if (get_values (string,columns,7,&pow_in,&pow_out,&eff,&acpu,&acpl,&altu,&altl))
         {
         if ((pow_in > ((double) 0.99)*p_in) && (pow_in < ((double) 1.01)*p_in))
            {
            acp = (acpu+acpl)*((double) 0.5);
            alt = (altu+altl)*((double) 0.5);
            fprintf (outfile,"%7.3f %6.1f %.4e %.4e %.4e %.4e\n",mag,ang,pow_out,eff,acp,alt);
            }
         }
      }
   }
fclose (infile);
fclose (outfile);

sprintf (batch_name,"batch.%d",time (&dummyt));
outfile = fopen (batch_name,"w+");
fprintf (outfile,"%s\n",out_name);  // contour data file name
fprintf (outfile,"%s\n",plot_name);  // plot file name
fprintf (outfile,"4\n");            // number of contour plots
fprintf (outfile,"Output Power (dBm)\n");   // names of plots
fprintf (outfile,"Efficiency (%%)\n");
fprintf (outfile,"Adjacent Channel Power (dB)\n");
fprintf (outfile,"Alternate Channel Power (dB)\n");
fprintf (outfile,"%d\n",device);   // plotting device
fclose (outfile);

sprintf (string,"contour_plot < %s",batch_name);
system (string);

sprintf (string,"rm -f %s",out_name);
system (string);
sprintf (string,"rm -f %s",batch_name);
system (string);

return (0);
}

/*********************************************************************************/                
/*********************************************************************************/                

string_index (char *str1,char *str2)
{
int   len1;
int   len2;
int   i;

len1 = strlen (str1);
len2 = strlen (str2);

if (len1 < len2)
   {
   return (-1);
   }

for (i = 0; i <= (len1-len2); ++i)
   {
   if (!strncmp (&str1[i],str2,len2))
      {
      return (i);
      }
   }

return (-1);
}

#if 1

/*********************************************************************************/                
/*********************************************************************************/                

int is_seperator (char value,char *sep_list)
   {
   int i = 0;
   int result = 0;

   while (sep_list[i] != '\0')
      {
      result |= (value == sep_list[i]);
      ++i;
      }

   return result;
   }

/*********************************************************************************/                
/*********************************************************************************/                

char **packetize_string (char *string, int max_packets)
   {
   int i,j;
   int len;
   int in_packet;
   int seperator;
   char *temp;
   char **result;
   static char sep_list[] = ".,|:;/\n\"!?";

   result = (char **) malloc (sizeof(char *)*(max_packets+1));

   in_packet = 0;
   j = 0;
   for (i = 0; i <= strlen(string); ++i)
      {
      seperator = is_seperator (string[i],sep_list);

      if ((string[i] < 33) || (string[i] > 126) || seperator)
         {
         if (in_packet)
            {
            if (j >= max_packets)
               {
               break;
               }

            result[j] = (char *) malloc (sizeof(char)*(len+1));
            strncpy (result[j],temp,len);
            result[j][len] = 0;
            in_packet = 0;
            ++j;
            }
         }
      
      else
         {
         if (!in_packet)
            {
            len = 0;
            in_packet = 1;
            temp = &string[i];
            }
         ++len;
         }
      }

   result[j] = NULL;

   return result;
   }

/*********************************************************************************/                
/*********************************************************************************/                

void free_packets (char **packets)
   {
   int i = 0;

   while (packets[i] != NULL)
      {
      free ((void *) packets[i]);
      ++i;
      }

   free ((void *) packets);
   return;
   }

/*********************************************************************************/                
/*********************************************************************************/                

int get_values (char *string, int *cols, int ncols, ...)
   {
   va_list   ap;
   int       i,j;
   double    *ptr;
   char      *str;
   char      *str1;

   str1 = string;
 
   va_start (ap,ncols);

   j = 0;
   for (i = 0; i < ncols; ++i)
      {
      ptr = va_arg (ap, double *);

      if (j > cols[i])
         {
         j = 0;
         str1 = string;
         }

      while (j < cols[i])
         {
         strtod (str1,&str);
	 if (str1 == str)
	    {
	    va_end (ap);
	    return 0;
	    }
         str1 = str;
         ++j;
         }

      if (cols[i] > -1)
         {
         *ptr = strtod (str1,&str);
	 if (str1 == str)
	    {
	    va_end (ap);
	    return 0;
	    }
         str1 = str;
         ++j;
         }
      else
         *ptr = (double) 0.0;
      }

   va_end (ap);

   return 1;
   }

#endif


