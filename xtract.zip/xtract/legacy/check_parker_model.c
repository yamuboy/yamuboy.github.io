#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
   {
   int tmpi,model_number = 0;
   FILE *file;
   char string[256];
   char file_name[256];
   double vbi = 0.0;
   double vbic = 0.0;
   double val;
   int warn_count = 0;
   int err_count = 0;

   file_name[0] = 0;

   if (argc == 2)
      sscanf (argv[1], "%255s", file_name);

   if (!file_name[0])
      {
      printf ("Parker model file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", file_name);
      }

   file = fopen (file_name, "r");
   if (!file)
      {
      printf ("Error: unable to open file %s.\n",file_name);
      return -1;
      }

   while (fgets (string, 255, file))
      {
      if (string[0] == '!')
         continue;

      if (sscanf (string, "model = %d",&tmpi))
         model_number = tmpi;

      if (sscanf (string, "vbi = %lf", &val))
         {
         vbi = val;

         if (vbi < 0.6)
            {
            fprintf (stderr, "Warning: VBI should be >= 0.6 in model %d.\n",model_number);
            ++warn_count;
            }
         }

      if (sscanf (string, "vbic = %lf", &val))
         {
         vbic = val;

         if (vbic < 0.6)
            {
            fprintf (stderr, "Warning: VBIC should be >= 0.6 in model %d.\n",model_number);
            ++warn_count;
            }
         }

      if (sscanf (string, "beta = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Warning: BETA should be >= 0.0 in model %d.\n",model_number);
            ++warn_count;
            }
         }

      if (sscanf (string, "vto = %lf", &val))
         {
         if (val > (vbi - 1.0e-6))
            {
            fprintf (stderr, "Error: VTO must be less than VBI in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "vtoc = %lf", &val))
         {
         if (val > (vbic - 1.0e-6))
            {
            fprintf (stderr, "Error: VTOC must be less than VBIC in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "fc = %lf", &val))
         {
         if (val > (vbi - 1.0e-6))
            {
            fprintf (stderr, "Error: FC must be less than VBI in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "delta = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Warning: DELTA should be >= 0.0 in model %d.\n",model_number);
            ++warn_count;
            }
         }

      if (sscanf (string, "vst = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Error: VST must be >= 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "mvst = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Error: MVST must be >= 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "xi = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Error: XI must be >= 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }
    
      if (sscanf (string, "mxi = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Error: MXI must be >= 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "z = %lf", &val))
         {
         if (val <= 0.0)
            {
            fprintf (stderr, "Error: Z must be > 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }
                  
      if (sscanf (string, "cgs = %lf", &val))
         {
         if (val <= 0.0)
            {
            fprintf (stderr, "Error: CGS must be > 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "cgd = %lf", &val))
         {
         if (val <= 0.0)
            {
            fprintf (stderr, "Error: CGD must be > 0.0 in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "xc = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Warning: XC should be >= 0.0 in model %d.\n",model_number);
            ++warn_count;
            }
         else if (val >= 1.0)
            {
            fprintf (stderr, "Error: XC must be < 1.0 in model %d.\n",model_number);
            ++err_count;
            }
         }

      if (sscanf (string, "xic = %lf", &val))
         {
         if (val < 0.0)
            {
            fprintf (stderr, "Warning: XIC should be >= 0.0 in model %d.\n",model_number);
            ++warn_count;
            }
         }
      }
   
   fclose (file);

   if (err_count)
      {
      fprintf (stderr, "\n%d errors detected with model parameters in model file %s.\n",err_count,file_name);
      fprintf (stderr, "  These errors may cause the model to exhibit non-physical behavior or fail\n");
      fprintf (stderr, "  to converge under high power levels or under conditions outside\n");
      fprintf (stderr, "  normal small-signal operation range.\n");
      }

   if (warn_count)
      {
      fprintf (stderr, "\n%d warnings detected with model parameters in model file %s.\n",warn_count,file_name);
      fprintf (stderr, "  These warnings may not cause catestrophic failure of the model,\n");
      fprintf (stderr, "  but flag parameters that are outside their normal ranges.\n");
      }

   fprintf (stderr, "\n");

   return 0;
   }



