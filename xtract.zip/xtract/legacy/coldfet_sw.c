#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "cmplxlib.h"
#include "optimize4.h"
#include "fit_tools.h"

#define MAX_FREQS   500
#define MAX_FILES   5

typedef struct
   {
   double vgs,vds,igs,ids;
   } BIAS;

struct z11_data
   {
   double *z11;
   double *w;
   unsigned n;
   };

static int z11_erf (double *p, void *data, double *err, unsigned n);
static unsigned read_s_params (FILE *file, COMPLEX s[][4], double *freqs, unsigned max_f, BIAS *bias);
static int solve_ax_b (double *a, double *b, unsigned n, unsigned m, double *x);

/***********************************************************************************/
/***********************************************************************************/

int main (int argc, char *argv[])
   {
   unsigned npts,i,j;
   unsigned n_files = 0;
   FILE *file;
   COMPLEX s[MAX_FREQS][4];
   COMPLEX z[4],y[4];
   double freqs[MAX_FREQS];
   double a[MAX_FREQS][3];
   double b[MAX_FREQS];
   double x[3];
   double wl[MAX_FREQS];
   double z11rl[MAX_FREQS];
   double ls1[MAX_FREQS];
   double ld1[MAX_FREQS];
   double lg1[MAX_FREQS];
   double cg1[MAX_FREQS];
   double cd1[MAX_FREQS];
   BIAS bias;
   double igs[MAX_FILES];
   double Rg[MAX_FILES];
   double Rd[MAX_FILES];
   double Rs[MAX_FILES];
   double Lg[MAX_FILES];
   double Ld[MAX_FILES];
   double Ls[MAX_FILES];
   double Rgf,Rdf,Rsf,Lgf,Ldf,Lsf,c11,c22;
   double m,r_sq,min_freq,max_freq,r_freq;
   double w,z11r,rg1,rp,cp;
   char file_list[1024];
   char pinchoff_file[256];
   char out_file[256];
   char string[256];
   char *ptr,file_name[256];
   int r_done;
   OPTIMIZE *opt;
   OPT_PARAMETER p[3];
   struct z11_data z11_d;

   printf ("Forward-biased S-parameter files?\n");
   printf ("enter on a single line, separated by spaces\n");
   fgets (file_list, 1023, stdin);

   printf ("Below pinch-off S-parameter file?\n");
   fgets (pinchoff_file, 255, stdin);
   pinchoff_file[strlen(pinchoff_file)-1] = 0;

   printf ("Frequency range for cold-FET extraction in GHz (min max)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf%lf", &min_freq, &max_freq);
   min_freq *= 1.0e9;
   max_freq *= 1.0e9;

   printf ("Frequency for resistance extraction in GHz?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%lf", &r_freq);
   r_freq *= 1.0e9;

   printf ("Output file name?\n");
   fgets (out_file, 255, stdin);
   out_file[strlen(out_file)-1] = 0;

   ptr = strtok (file_list, " \t\n");
   while (ptr)
      {
      strcpy (file_name, ptr);
      ptr = strtok (NULL, " \t\n");

      if (n_files >= MAX_FILES)
         break;

      file = fopen (file_name, "r");
      if (!file)
         {
         fprintf (stderr, "Warning: file not found - %s\n", file_name);
         continue;
         }

      npts = read_s_params (file, s, freqs, MAX_FREQS, &bias);
      fclose (file);
      if (!npts)
         {
         fprintf (stderr, "Warning: file empty - %s\n", file_name);
         continue;
         }

      igs[n_files] = 1.0 / bias.igs;

      // calculate Cp and Rp using the real part of Z12/Z21
      // Re{Z12/Z21} = Rg + Rp / (1 + w^2 * Rp^2 * Cp^2)
      // Rg also falls out of the solution

      for (i = 0, j = 0; i < npts; ++i)
         {
         if (freqs[i] < min_freq)
            continue;
         else if (freqs[i] > max_freq)
            break;

         wl[j] = 2.0 * acos (-1.0) * freqs[i];
         s2z (s[i], z, 50.0);
         z11rl[j] = Creal (Cmult (Complex(0.5), Cadd (z[1], z[2])));
         ++j;
         }

      z11_d.n = j;
      z11_d.z11 = z11rl;
      z11_d.w = wl;

      if (j < 3)
         {
         fprintf (stderr, "Warning: not enough frequency points in file - %s\n", file_name);
         continue;
         }

      // Rg
      p[0].min = 0.0;
      p[0].nom = 1000.0;
      p[0].max = 5000.0;
      p[0].tol = 0.0;
      p[0].optimize = TRUE;

      // Rdiode
      p[1].min = 0.0;
      p[1].nom = 5.0;
      p[1].max = 400.0;
      p[1].tol = 0.0;
      p[1].optimize = TRUE;

      // Cg
      p[2].min = 0.0;
      p[2].nom = 1.0e-12;
      p[2].max = 5.0e-12;
      p[2].tol = 0.0;
      p[2].optimize = TRUE;

      opt = initialize_cg_optimizer ();
      set_cg_parameters (opt, p, 3);
      set_cg_error_function (opt, z11_erf, (void *) &z11_d, 1, NULL);
      set_cg_flags (opt, OPT_SINGLE_PARAM);

      if (cg_optimize4 (opt, 20, NULL))
         {
         fprintf (stderr, "%s\n", get_cg_error ());
         continue;
         }

      rg1 = p[0].nom;
      rp = p[1].nom;
      cp = p[2].nom;

      // solve for Rg, Rd, Rs, Lg, Ld, and Ls

      r_done = 0;
      for (i = 0, j = 0; i < npts; ++i)
         {
         s2z (s[i], z, 50.0);
         w = 2.0 * acos (-1.0) * freqs[i];

         if ((freqs[i] >= r_freq) && !r_done)
            {
            Rs[n_files] = z[3].r - 0.5 * Creal (Cadd (z[1], z[2]));
            Rd[n_files] = z[0].r - 0.5 * Creal (Cadd (z[1], z[2]));
            // Rg[n_files] = z[0].r - Rs[n_files] - rp / (1.0 + w * w * rp * rp * cp * cp);
            Rg[n_files] = rg1;
            r_done = 1;
            }
         
         if (freqs[i] < min_freq)
            continue;
         else if (freqs[i] > max_freq)
            break;

         wl[j] = w;
         ls1[j] = z[3].i - 0.5 * Cimag (Cadd (z[1], z[2]));
         ld1[j] = z[0].i - 0.5 * Cimag (Cadd (z[1], z[2]));
         lg1[j] = 0.5 * Cimag (Cadd (z[1], z[2])) + w * rp * rp * cp / (1.0 + w * w * rp * rp * cp * cp);
         ++j;
         }

      if (j < 2)
         {
         fprintf (stderr, "Warning: not enough frequency points in file - %s\n", file_name);
         continue;
         }

      linefit_mx0 (wl, ls1, j, &Ls[n_files], &r_sq);
      linefit_mx0 (wl, ld1, j, &Ld[n_files], &r_sq);
      linefit_mx0 (wl, lg1, j, &Lg[n_files], &r_sq);

      printf ("---- File: %s ----\n", file_name);
      printf ("  Rp = %.3f, Cp = %.3e\n", rp, cp);
      printf ("  Rg = %.3f, Rd = %.3f, Rs = %.3f\n", Rg[n_files], Rd[n_files], Rs[n_files]);
      printf ("  Lg = %.3e, Ld = %.3e, Ls = %.3e\n\n", Lg[n_files], Ld[n_files], Ls[n_files]);

      ++n_files;
      }

   if (!n_files)
      {
      fprintf (stderr, "No valid data for cold FET extraction.\n");
      return -1;
      }
   else if (n_files < 2)
      {
      // only one data file, use results as is
      Rgf = Rg[0];
      Rdf = Rd[0];
      Rsf = Rs[0];
      Lgf = Lg[0];
      Ldf = Ld[0];
      Lsf = Ls[0];
      }
   else
      {
      // more than one gate bias, extrapolate to infinite Igs
      linefit_mxb (igs, Rg, n_files, &m, &Rgf, &r_sq);
      linefit_mxb (igs, Rd, n_files, &m, &Rdf, &r_sq);
      linefit_mxb (igs, Rs, n_files, &m, &Rsf, &r_sq);
      linefit_mxb (igs, Lg, n_files, &m, &Lgf, &r_sq);
      linefit_mxb (igs, Ld, n_files, &m, &Ldf, &r_sq);
      linefit_mxb (igs, Ls, n_files, &m, &Lsf, &r_sq);
      }

   // do the below pinch-off capacitance extraction

   file = fopen (pinchoff_file, "r");
   if (file)
      {
      npts = read_s_params (file, s, freqs, MAX_FREQS, &bias);
      fclose (file);
      }
   else
      npts = 0;

   if (npts)
      {
      for (i = 0, j = 0; i < npts; ++i)
         {
         if (freqs[i] < min_freq)
            continue;
         else if (freqs[i] > max_freq)
            break;

         // remove the effects of Lg and Ld

         s2z (s[i], z, 50.0);

         z[0] = Csub (z[0], Cnum (0.0, 2.0 * acos (-1.0) * freqs[i] * Lgf));
         z[3] = Csub (z[3], Cnum (0.0, 2.0 * acos (-1.0) * freqs[i] * Ldf));

         // calculate the fringing capacitances

         z2y (z, y);

         cg1[j] = y[0].i + 0.5 * (y[1].i + y[2].i);
         cd1[j] = y[3].i + 0.5 * (y[1].i + y[2].i);
         wl[j] = 2.0 * acos (-1.0) * freqs[i];
         ++j;
         }

      if (j > 1)
         {
         linefit_mx0 (wl, cg1, j, &c11, &r_sq);
         linefit_mx0 (wl, cd1, j, &c22, &r_sq);
         }
      else
         c11 = c22 = 0.0;
      }
   else
      {
      fprintf (stderr, "Warning: file not found - %s\n", pinchoff_file);
      c11 = c22 = 0.0;
      }

   printf ("---- Fringing Capacitances ----\n");
   printf ("  C11 = %.3e, C22 = %.3e\n\n", c11, c22);

   // write the output file
   
   file = fopen (out_file, "w+");
   if (!file)
      {
      fprintf (stderr, "Unable to write output file.\n");
      return -1;
      }

   fprintf (file, "lg\t%.3e\n", Lgf);
   fprintf (file, "rg\t%.1f\n", Rgf);
   fprintf (file, "c11\t%.3e\n", c11);
   fprintf (file, "c22\t%.3e\n", c22);
   fprintf (file, "rd\t%.2f\n", Rdf);
   fprintf (file, "rs\t%.2f\n", Rsf);
   fprintf (file, "ld\t%.3e\n", Ldf);
   fprintf (file, "ls\t%.3e\n", Lsf);
   fprintf (file, "cds\t%.3e\n", 0.0);

   fclose (file);

   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/

static int z11_erf (double *p, void *data, double *err, unsigned n)
   {
   struct z11_data *d;
   unsigned i;

   if (n != 1)
      return 1;

   d = (struct z11_data *) data;

   for (i = 0; i < d->n; ++i)
      err[0] += fabs (d->z11[i] - p[0] - p[1] / (1.0 + d->w[i]*d->w[i]*p[1]*p[1]*p[2]*p[2]));

   err[0] /= (double) d->n;

   return 0;
   }

/***********************************************************************************/
/***********************************************************************************/

static unsigned read_s_params (FILE *file, COMPLEX s[][4], double *freqs, unsigned max_f, BIAS *bias)
   {
   double t[4];
   double freq_mult = 1.0;
   double impedance = 50.0;
   POLAR tmpp[4];
   char string[300];
   int ri_format = 0;
   int db_format = 0;
   unsigned i = 0;
   unsigned j;
   int flag = 0;

   if (bias)
      bias->vgs = bias->vds = bias->ids = bias->igs = 0.0;

   while (fgets (string, 299, file))
      {
      if (!strncmp (string,"!BIAS",5) && bias)
         {
         if (flag)
            break;

         for (j = 0; j < strlen (string); ++j)
            {
            if ((string[j] >= 65) && (string[j] <= 90))
               string[j] += (char) 32;
            }

         if (sscanf (string,"!bias: vds = %lf volts ids = %lf amps vgs = %lf volts igs = %lf amps",&t[0],&t[1],&t[2],&t[3]) == 4)
            {
            bias->vds = t[0];
            bias->ids = t[1];
            bias->vgs = t[2];
            bias->igs = t[3];
            }
         }
      else if (string[0] == '!')
         {
         if (flag)
            break;
         continue;
         }
      else if (string[0] == '#')
         {
         for (j = 0; j < strlen (string); ++j)
            {
            if ((string[j] >= 65) && (string[j] <= 90))
               string[j] += (char) 32;
            }
         sscanf (string,"# %*s %*s %*s %*s %lf",&impedance);

         if (strstr (string, "khz"))
            freq_mult = 1.0e3;
         else if (strstr (string, "mhz"))
            freq_mult = 1.0e6;
         else if (strstr (string, "ghz"))
            freq_mult = 1.0e9;
            
         if (strstr (string, "ri"))
            ri_format = 1;
         else if (strstr (string, "db"))
            db_format = 1;
         }
      
      if (i >= max_f)
         break;

      if (ri_format)
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freqs[i],&s[i][0].r,&s[i][0].i,
            &s[i][2].r,&s[i][2].i,&s[i][1].r,&s[i][1].i,&s[i][3].r,&s[i][3].i) == 9)
            {
            flag = 1;
            freqs[i] *= freq_mult;
            ++i;
            }
         }
      else
         {
         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freqs[i],&tmpp[0].m,&tmpp[0].a,
            &tmpp[2].m,&tmpp[2].a,&tmpp[1].m,&tmpp[1].a,&tmpp[3].m,&tmpp[3].a) == 9)
            {
            if (db_format)
               {
               tmpp[0].m = pow (10.0, tmpp[0].m*0.05);
               tmpp[1].m = pow (10.0, tmpp[1].m*0.05);
               tmpp[2].m = pow (10.0, tmpp[2].m*0.05);
               tmpp[3].m = pow (10.0, tmpp[3].m*0.05);
               }
            flag = 1;
            PA2CA (tmpp, s[i], 2, 2);
            freqs[i] *= freq_mult;
            ++i;
            }         
         }
      }

   return i;
   }

/***********************************************************************************/
/***********************************************************************************/

static int solve_ax_b (double *a, double *b, unsigned n, unsigned m, double *x)
   {
   double **aa;
   double *bb;
   double max,tmp,factor;
   unsigned i,j,k;
   unsigned row,col,tmpi;
   unsigned *point;

#define ind(r,c,sz)  ((r)*(sz)+(c))

   if ((m < 2) || (n < m))
      {
      fprintf (stderr, "Unable to solve system of equations: not enough data.\n");
      return -1;
      }

   // allocate memory

   aa = (double **) malloc (sizeof (double *) * m);
   for (i = 0; i < m; ++i)
      aa[i] = (double *) malloc (sizeof (double) * m);
   bb = (double *) malloc (sizeof (double) * m);
   point = (unsigned *) malloc (sizeof (unsigned) * m);

   // form a square matrix by multiplying both sides of the equation 'a*x = b' by transpose(a)
   // where a is an array of size n-x-m, x is a vector of size m, and b is a vector of size n
   // this yields 'aa*x = bb', where aa is of size m-x-m and bb is of size m

   for (i = 0; i < m; ++i)
      {
      for (j = 0; j < m; ++j)
         {
         aa[i][j] = 0.0;
         for (k = 0; k < n; ++k)
            aa[i][j] += a[ind(k,i,m)] * a[ind(k,j,m)];
         }

      bb[i] = 0.0;
      for (k = 0; k < n; ++k)
         bb[i] += a[ind(k,i,m)] * b[k];
      }

   // initialize the column pointer (needed to keep track of columns during pivoting)

   for (i = 0; i < m; ++i)
      point[i] = i;

   // solve the matrix for the vector x by gaussian elimination

   for (i = 0; i < m; ++i)
      {
      // find the largest value
      max = 0.0;
      row = col = i;
      for (j = i; j < m; ++j)
         {
         for (k = i; k < m; ++k)
            {
            tmp = fabs (aa[j][k]);
            if (tmp > max)
               {
               max = tmp;
               row = j;
               col = k;
               }
            }
         }

      // pivot the rows
      if (row != i)
         {
         for (k = 0; k < m; ++k)
            {
            tmp = aa[i][k];
            aa[i][k] = aa[row][k];
            aa[row][k] = tmp;

            }

         tmp = bb[i];
         bb[i] = bb[row];
         bb[row] = tmp; 
         }

      // pivot the columns
      if (col != i)
         {
         for (j = 0; j < m; ++j)
            {
            tmp = aa[j][i];
            aa[j][i] = aa[j][col];
            aa[j][col] = tmp;
            }

         tmpi = point[i];
         point[i] = point[col];
         point[col] = tmpi;
         }

      // gaussian elimination, this step zeros all of the values in column i of aa
      // except for the position on the main diagonal at aa[i][i]
      for (j = 0; j < m; ++j)
         {
         if (j == i)
            continue;

         factor = aa[j][i] / aa[i][i];
         for (k = 0; k < m; ++k)
            aa[j][k] -= aa[j][k] * factor;

         bb[j] -= bb[j] * factor;
         }
      }

   // now the matrix only has non-zero values on the main diagonal
   // solve for x by dividing by aa: 'x[i] = bb[i] / aa[i][i]'

   for (i = 0; i < m; ++i)
      x[point[i]] = bb[i] / aa[i][i];

   // free memory

   for (i = 0; i < m; ++i)
      free ((void *) aa[i]);
   free ((void *) aa);
   free ((void *) bb);
   free ((void *) point);

   return 0;
   }
