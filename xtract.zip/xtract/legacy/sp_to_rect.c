#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define DEG2RAD    0.01745329252

main ()
{
char    string[256],filename[81],outname[81];
char    type[10],mult[10],junk[10];
FILE    *file1,*file2;
double  m11,m12,m21,m22;
double  a11,a12,a21,a22;
double  r11,r12,r21,r22;
double  i11,i12,i21,i22;
double  freq,imp;

printf ("Input filename?\n> ");
scanf ("%s",filename);
printf ("Output filename?\n> ");
scanf ("%s",outname);

file1 = fopen (filename,"r");
if (!file1)
   {
   printf ("\n** could not open %s ** \n\n",filename);
   exit (-1);
   }
   
file2 = fopen (outname,"w+");

while (fgets (string,255,file1))
   {
   if (strstr (string,"#"))
      {
      sscanf (string,"# %s %s %s %s %lf",type,mult,junk,junk,&imp);
      fprintf (file2,"# %s %s RI R %.1f\n",type,mult,imp);
      }
   
   else if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&m11,&a11,&m21,&a21,&m12,&a12,&m22,&a22) == 9)
      {
      r11 = m11*cos (DEG2RAD*a11);
      i11 = m11*sin (DEG2RAD*a11);
      r12 = m12*cos (DEG2RAD*a12);
      i12 = m12*sin (DEG2RAD*a12);
      r21 = m21*cos (DEG2RAD*a21);
      i21 = m21*sin (DEG2RAD*a21); 
      r22 = m22*cos (DEG2RAD*a22);
      i22 = m22*sin (DEG2RAD*a22);
      
      fprintf (file2,"%.5e %+.5e %+.5e %+.5e %+.5e %+.5e %+.5e %+.5e %+.5e\n",freq,r11,i11,r21,i21,r12,i12,r22,i22);
      }
   else
      fprintf (file2,"%s",string);  
   }

fclose (file1);
fclose (file2);

return 0;
}
