#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PI    3.14159
#define E0    8.854e-12

#define MAX_SUM   10000

int main (int argc, char *argv[])
   {
   char string[256];
   double w,d,er;
   double a,c;
   double last_c = 0.0;
   double sum = 0.0;
   unsigned long n;

   printf ("Width of the microstrip line in microns?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&w);

   printf ("Height of the substrate in microns?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&d);

   printf ("Relative permittivity of the substrate?\n");
   fgets (string,255,stdin);
   sscanf (string,"%lf",&er);

   w *= 1.0e-6;
   d *= 1.0e-6;

   a = d*100.0;

   // calculate the infinite capacitance sum

   for (n = 1; n; n += 2)
      {
      sum += 4.0*a*sin (n*PI*w*0.5/a)*sinh (n*PI*d/a) / (n*n*PI*PI*w*E0*(sinh (n*PI*d/a) + er*cosh (n*PI*d/a)));
      c = 1.0/sum;

      if (fabs (last_c - c) < c*1.0e-4)
         break;

      last_c = c;
      }

   c *= 1.0e12;

   printf ("\n\nLine Capacitance = %.3f pF/m\n\n",c);

   return 0;
   }







