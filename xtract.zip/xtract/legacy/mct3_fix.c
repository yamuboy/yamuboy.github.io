#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   int i;
   FILE *in, *out;
   char str[256];
   

   if (argc < 2)
      {
      printf ("\n\n");
      printf ("USAGE: %s [files]\n", argv[0]);
      printf ("-------------------------------------------------\n");
      printf ("  Repair tool for MCT3 files.\n");
      printf ("\n\n");
      return 0;
      }
   
   for (i = 1; i < argc; ++i)
      {
      out = fopen( "tmp.xxx", "w+" );
      if( !out )
         {
         printf( "Error: unable to write to disc.\n" );
         return 1;
         }
   
      in = fopen( argv[i], "r" );
      if( !in )
         {
         printf( "Warning: %s: file not found.\n", argv[i] );
         continue;
         }
       
      while( fgets(str,255,in) )
         {
         if( !strncmp( str, "!gpib_instr_t", 13 ) )
            fprintf( out, "!BIAS%s", &str[13] );
	 else
            fprintf( out, "%s", str );
         }
      
      fclose( in );
      fclose( out );

      sprintf( str, "mv -f %s %s", "tmp.xxx", argv[i] );
      system( str );
      }
   
   
   return 0;
   }


