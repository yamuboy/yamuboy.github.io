#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include "cmplxlib.h"
#include "optimize4.h"

#define MAX_FREQS     100
#define MATRIX_SIZE   9

#define INTERPOLATE_NONE   0
#define INTERPOLATE_POLAR  1
#define INTERPOLATE_RECT   2

#define T0            290.0
#define F_RES         1.0
#define BOLTZMANN     1.38066e-23
#define ROOM_TEMP     294.0

#define ERR_FILE_NAME   "noise_err.txt"

// flags
#define BATCH_MODE   1<<0

typedef struct
{
   char noise_file[256];
   char fxa_file[256];
   char fxb_file[256];
   char s_file[256];
   char end_file[256];
   char ns_file[256];
   char out_file[256];
   double temp;
} NOISE_FIT_IN;

static int batch_main (unsigned flags);
static int noise_fit_main (NOISE_FIT_IN *inp, unsigned flags);
static int noise_deembed (unsigned flags);
static int noise_scalar_deembed (unsigned flags);

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
{
   int i;
   unsigned flags = 0;

   // parse the command line

   for (i = 0; i < argc; ++i)
   {





   }
   // execute the correct program

   if( strstr(argv[0], "batch") ) {
      flags |= BATCH_MODE;
      if( batch_main(flags) ) {
         fprintf (stderr, "Error: batch extraction not completed.\n");
         return 1;
      }
   }
   else if( strstr (argv[0], "dmb") ) {
      if( strstr (argv[0], "scalar") )
         return noise_scalar_deembed (flags);
      else
         return noise_deembed (flags);
   }
   else {
      if( flags & BATCH_MODE )
         return batch_main(flags);
      else
         return noise_fit_main (NULL, flags);
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static void log_error (char *fname, char *err_msg)
{  
   if (!err_msg)
      return;

   if (!fname || (strlen (fname) < 1))
   {
      fprintf (stderr, "%s", err_msg);

      if (err_msg[strlen(err_msg)-1] != '\n')
         fprintf (stderr, "\n");      
   }
   else
   {
      FILE *file = fopen (fname, "a");
      if (!file)
         return;

      fprintf (file, "%s", err_msg);

      if (err_msg[strlen(err_msg)-1] != '\n')
         fprintf (file, "\n");

      fclose (file);
   }
}

/*********************************************************************************************/
/*********************************************************************************************/

static int batch_main (unsigned flags)
{
   NOISE_FIT_IN input;
   char fit_files[256];
   char fname[256];
   char base_name[256];
   char string[256];
   char tmp_file[100];
   char ext[31];
   char **flist;
   time_t ts;
   FILE *file;
   unsigned i;
   unsigned n = 0;

   printf ("Noise files to fit?\n");
   fgets (fit_files, 255, stdin);
   fit_files[strlen(fit_files)-1] = 0;

   printf ("Input error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", input.fxa_file);

   printf ("Output error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", input.fxb_file);

   printf ("Noise source [S]-parameter file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", input.ns_file);

   printf ("Extension for [S] files?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%30s", ext);

   printf ("Measurement temperature (C)?\n");
   fgets (string, 255, stdin);
   if (sscanf (string, "%lf", &input.temp))
      input.temp += 273.15;
   else
      input.temp = 294.0;

   // remove old error file (if it exists)
   sprintf (string, "rm -f %s", ERR_FILE_NAME);
   system (string);

   // create temporary file names and get the file list of files to batch fit
   sprintf (tmp_file, "tmp-%ld", (long) time (&ts));
   sprintf (string, "rm -f %s", tmp_file);
   system (string);
   sprintf (string, "ls -1 %s > %s", fit_files, tmp_file);
   system (string);

   // open the file list
   file = fopen (tmp_file, "r");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", tmp_file);
      return 1;
   }

   // count the number of files to fit
   while (fgets (fname, 255, file))
      ++n;

   rewind (file);

   // allocate memory
   flist = (char **) malloc (sizeof (char *) * n);

   // read in the file names
   for (i = 0; i < n; ++i)
   {
      if (!fgets (fname, 255, file))
      {
         fprintf (stderr, "Error: %s: error reading file.\n", tmp_file);
         fclose (file);
         sprintf (string, "rm -f %s", tmp_file);
         system (string);
         return 1;
      }

      fname[strlen(fname)-1] = 0;
      flist[i] = (char *) malloc (sizeof (char) * (strlen (fname)+1));
      strcpy (flist[i], fname);
   }

   fclose (file);

   sprintf (string, "rm -f %s", tmp_file);
   system (string);

   // fork into a background process and exit the foreground process
   switch (fork())
   {
   case -1:
      fprintf (stderr, "Error: fork() failed.\n");
      return 1;

   case 0:
      // this is the child process
      break;

   default:
      // this is the parent process
      return 0;
   }

   for (i = 0; i < n; ++i)
   {
      strcpy (input.noise_file, flist[i]);
      sscanf (flist[i], "%[^.]", base_name);
      strcpy (string, base_name);
      strcat (string, ".rpc");
      strcpy (input.out_file, string);
      base_name[0] = 's';
      strcpy (string, base_name);
      strcat (string, ext);
      strcpy (input.s_file, string);
      strcpy (string, base_name);
      strcat (string, ".end");
      strcpy (input.end_file, string);

      // check for existance of the [S] file
      file = fopen (input.s_file, "r");
      if (!file)
         continue;
      fclose (file);

      // check for existance of the end file
      file = fopen (input.end_file, "r");
      if (!file)
         continue;
      fclose (file);

      if (noise_fit_main (&input, flags))
      {
         sprintf (string, "Error: when fitting data from %s.", input.noise_file);
         log_error (ERR_FILE_NAME, string);
      }
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

typedef struct
{
   double *params;
   double *nf;
   COMPLEX *gamma;
   double *freqs;
   int n_freqs;
   double temperature;
   COMPLEX **y, **yc;
} NOISE_OPT;

typedef struct
{
   double vgs,vds,igs,ids;
} BIAS;


static int read_noise_data (char *fname, double *f, double *nf, double *gain, unsigned max_pts, double max_nf,
                            double min_gain, unsigned *n, BIAS *bias);
static int read_s_param_data (char *fname, double *flist, unsigned nf, COMPLEX s[][4], unsigned flags);
static int read_model_params (char *fname, double *p, unsigned sz_p);
static void deembed_noise_figure (double nf, COMPLEX *s_dut, COMPLEX *s_fxa,
                                  COMPLEX *s_fxb, COMPLEX *s_ns_2port, int use_s22,
                                  double temperature, double *nf_d, COMPLEX *gamma_s);
static double calculate_noise_figure (COMPLEX **y, COMPLEX **yc, double *p, double vv, double ii, double temperature,
                                      COMPLEX gamma_s, double freq, COMPLEX *n_corr, COMPLEX *y_params);
static int optimize_noise_parameters (double *params, double *nf, double *f_list, COMPLEX *gamma,
                                      unsigned n_freqs, double temperature, unsigned flags, double *vv, double *ii);
static double associated_gain (COMPLEX *s, COMPLEX gamma);
static int write_output_file (char *fname, char *hname, double *f_list, double *nf, 
                              COMPLEX *gamma_s, unsigned n_freq, double *p, double vv,
                              double ii, double temperature, BIAS bias);

/*********************************************************************************************/
/*********************************************************************************************/

static int noise_fit_main (NOISE_FIT_IN *inp, unsigned flags)
{
   char string[256], noise_file[256];
   char fxa_file[256], fxb_file[256];
   char s_file[256], ns_file[256], out_file[256], end_file[256];
   double f_list[MAX_FREQS], nf[MAX_FREQS], gain[MAX_FREQS];
   double nf_d[MAX_FREQS], parms[20];
   unsigned n_freqs;
   COMPLEX s_fxa[MAX_FREQS][4], s_fxb[MAX_FREQS][4];
   COMPLEX s_dut[MAX_FREQS][4], s_ns[MAX_FREQS][4];
   COMPLEX gamma_s[MAX_FREQS];
   double temperature;
   int interpolation_flag = INTERPOLATE_NONE;
   int use_s22;
   double vv, ii;
   BIAS bias;
   unsigned i;
   double max_nf = 10.0;
   double min_gain = -3.0;

   /**** get user input ****/

   if (inp)
   {
      flags |= BATCH_MODE;
      strcpy (noise_file, inp->noise_file);
      strcpy (fxa_file, inp->fxa_file);
      strcpy (fxb_file, inp->fxb_file);
      strcpy (s_file, inp->s_file);
      strcpy (end_file, inp->end_file);
      strcpy (ns_file, inp->ns_file);
      strcpy (out_file, inp->out_file);
      temperature = inp->temp;
   }
   else
   {
      printf ("Measured noise figure data file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", noise_file);

      printf ("Input error box file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", fxa_file);

      printf ("Output error box file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", fxb_file);

      printf ("Measured S-parameter data file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", s_file);

      printf ("Model parameter data file (.end file)?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", end_file);

      printf ("Noise source S-parameter file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", ns_file);

      printf ("Output file name?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", out_file);

      printf ("Measurement temperature (C)?\n");
      fgets (string, 255, stdin);
      if (sscanf (string, "%lf", &temperature) == 1)
         temperature += 273.15;
      else
         temperature = 294.0;
   }

   /**** read in the noise data ****/

   if (read_noise_data (noise_file, f_list, nf, gain, MAX_FREQS, max_nf, min_gain, &n_freqs, &bias))
      return 1;

   /**** read in S-parameters for the input block, output block, device, and noise source ****/

   if (read_s_param_data (fxa_file, f_list, n_freqs, s_fxa, interpolation_flag))
      return 1;

   if (read_s_param_data (fxb_file, f_list, n_freqs, s_fxb, interpolation_flag))
      return 1;

   if (read_s_param_data (s_file, f_list, n_freqs, s_dut, interpolation_flag))
      return 1;

   if (read_s_param_data (ns_file, f_list, n_freqs, s_ns, interpolation_flag))
      return 1;

   /**** read in the model parameter data ****/

   if (read_model_params (end_file, parms, 20))
      return 1;

   /**** determine wheter to use S11 or S22 of the noise source file ****/

   if (Cmag (s_ns[0][0]) < Cmag (s_ns[0][3]))
      use_s22 = 0;
   else
      use_s22 = 1;

   /**** compute the deembeded NF of the DUT and compute the input gamma ****/

   for (i = 0; i < n_freqs; ++i)
      deembed_noise_figure (nf[i], s_dut[i], s_fxa[i], s_fxb[i], s_ns[i], use_s22, ROOM_TEMP, &nf_d[i], &gamma_s[i]);

   /**** optimize <vv*> and <ii*> ****/

   if (optimize_noise_parameters (parms, nf_d, f_list, gamma_s, n_freqs, temperature, flags, &vv, &ii))
      return 1;

   /**** write output file ****/

   if (write_output_file (out_file, noise_file, f_list, nf_d, gamma_s, n_freqs, parms, vv, ii, temperature, bias))
      return 1;

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static int read_noise_data (char *fname, double *f, double *nf, double *gain, unsigned max_pts, double max_nf,
                            double min_gain, unsigned *n, BIAS *bias)
{
   FILE *file;
   char string[256];

   *n = 0;

   if (bias)
      bias->vds = bias->vgs = bias->ids = bias->igs = 0.0;

   file = fopen (fname, "r");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", fname);
      return 1;
   }

   while (fgets (string, 255, file))
   {
      if (!strncmp (string, "!BIAS:", 6) && bias)
         sscanf (string, "!BIAS: VDS = %lf Volts IDS = %lf Amps VGS = %lf Volts IGS = %lf", &bias->vds,
         &bias->ids, &bias->vgs, &bias->igs);
      else if (string[0] == '!')
         continue;

      if (*n >= max_pts)
      {
         fprintf (stderr, "Warning: %s: max points exceeded.\n", fname);
         break;
      }

      if (sscanf (string, "%lf%lf%lf", &f[*n], &gain[*n], &nf[*n]) == 3)
      {
         if( gain[*n] < min_gain || nf[*n] > max_nf || nf[*n] < 1.0 )
            continue;

         (*n)++;
      }
   }

   fclose (file);

   if (*n < 1)
   {
      fprintf (stderr, "Error: %s: no data.\n", fname);
      return 1;
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static void interpolate_s_params (double f, double f_lo, COMPLEX *s_lo, double f_hi, COMPLEX *s_hi, unsigned flags, COMPLEX *s)
{
   double factor = (f - f_lo) / (f_hi - f_lo);
   int i;

   if (!flags)
      return;

   if (flags == INTERPOLATE_POLAR)
   {
      POLAR s_lo_p[4];
      POLAR s_hi_p[4];
      POLAR s_p[4];

      CA2PA (s_lo, s_lo_p, 2, 2);
      CA2PA (s_hi, s_hi_p, 2, 2);

      for (i = 0; i < 4; ++i)
      {
         s_p[i].m = s_lo_p[i].m + (s_hi_p[i].m - s_lo_p[i].m) * factor;
         s_p[i].a = s_lo_p[i].a + (s_hi_p[i].a - s_lo_p[i].a) * factor;
      }

      PA2CA (s_p, s, 2, 2);
   }

   else
   {
      for (i = 0; i < 4; ++i)
      {
         s[i].r = s_lo[i].r + (s_hi[i].r - s_lo[i].r) * factor;
         s[i].i = s_lo[i].i + (s_hi[i].i - s_lo[i].i) * factor;
      }
   }
}

/*********************************************************************************************/
/*********************************************************************************************/

static int read_s_param_data (char *fname, double *flist, unsigned nf, COMPLEX s[][4], unsigned flags)
{
#define MAX_S_IN_FILE     1000
   char string[256];
   double f;
   double fmult = 1.0;
   int ma_format = 1;
   int db_format = 0;
   FILE *file;
   COMPLEX sdata[MAX_S_IN_FILE][4];
   double fdata[MAX_S_IN_FILE];
   COMPLEX stmp[4];
   unsigned n = 0;
   unsigned i,j;
   int found;

   if (!strcmp (fname, "ideal"))
   {
      for (i = 0; i < nf; ++i)
      {
         s[i][0] = s[i][3] = ((COMPLEX) {0.0, 0.0});
         s[i][1] = s[1][2] = ((COMPLEX) {1.0, 0.0});
      }

      return 0;
   }

   file = fopen (fname, "r");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", fname);
      return 1;
   }

   while (fgets (string, 255, file))
   {
      if (string[0] == '#')
      {
         // read the touchstone format string
         // this defaults to "# HZ S MA R 50" if none is given

         // convert the string to lowercase
         for (i = 0; i < strlen (string); ++i)
         {
            if ((string[i] >= 65) && (string[i] <= 90))
               string[i] += (char) 32;
         }

         // find the frequency multiplier
         if (strstr (string, "khz"))
            fmult = 1.0e3;
         else if (strstr (string, "mhz"))
            fmult = 1.0e6;
         else if (strstr (string, "ghz"))
            fmult = 1.0e9;

         // determine if the data is in RI format
         if (strstr (string, "ri"))
            ma_format = 0;

         // determine if the data is in DB format
         if (strstr (string, "db"))
            db_format = 1;
      }
      else if (string[0] == '!')
         continue;

      if (n >= MAX_S_IN_FILE)
      {
         fprintf (stderr, "Warning: %s: max points exceeded.\n", fname);
         break;
      }

      if (sscanf (string, "%lf%lf%lf%lf%lf%lf%lf%lf%lf", &f, &stmp[0].r, &stmp[0].i,
         &stmp[2].r, &stmp[2].i, &stmp[1].r, &stmp[1].i, &stmp[3].r, &stmp[3].i) == 9)
      {
         f *= fmult;

         if (ma_format || db_format)
         {
            POLAR s_p[4];

            s_p[0].m = stmp[0].r;
            s_p[0].a = stmp[0].i;
            s_p[1].m = stmp[1].r;
            s_p[1].a = stmp[1].i;
            s_p[2].m = stmp[2].r;
            s_p[2].a = stmp[2].i;
            s_p[3].m = stmp[3].r;
            s_p[3].a = stmp[3].i;

            if (db_format)
            {
               s_p[0].m = pow (10.0, s_p[0].m*0.05);
               s_p[1].m = pow (10.0, s_p[1].m*0.05);
               s_p[2].m = pow (10.0, s_p[2].m*0.05);
               s_p[3].m = pow (10.0, s_p[3].m*0.05);
            }

            PA2CA (s_p, stmp, 2, 2);
         }

         fdata[n] = f;
         sdata[n][0] = stmp[0];
         sdata[n][1] = stmp[1];
         sdata[n][2] = stmp[2];
         sdata[n][3] = stmp[3];

         ++n;
      }
   }

   fclose (file);

   /**** match up the frequencies, interpolate if necessary/allowed ****/

   for (i = 0; i < nf; ++i)
   {
      found = 0;

      for (j = 0; j < n; ++j)
      {
         if ((flist[i] >= fdata[j] - F_RES) && (flist[i] <= fdata[j] + F_RES))
         {
            s[i][0] = sdata[j][0];
            s[i][1] = sdata[j][1];
            s[i][2] = sdata[j][2];
            s[i][3] = sdata[j][3];
            found = 1;
            break;
         }
         else if (!j && (flist[i] < fdata[j] - F_RES))
         {
            fprintf (stderr, "Error: %s: unable to interpolate f = %.3e Hz.\n", fname, flist[i]);
            return 1;
         }
         else if ((j == n-1) && (flist[i] > fdata[j] + F_RES))
         {
            fprintf (stderr, "Error: %s: unable to interpolate f = %.3e Hz.\n", fname, flist[i]);
            return 1;
         }
         else if (j && (flist[i] > fdata[j-1] + F_RES) && (flist[i] < fdata[j] - F_RES))
         {
            if (!flags)
            {
               fprintf (stderr, "Error: %s: unable to interpolate f = %.3e Hz.\n", fname, flist[i]);
               return 1;
            }

            interpolate_s_params (flist[i], fdata[j-1], sdata[j-1], fdata[j], sdata[j], flags, s[i]);
            found = 1;
            break;
         }
      }

      if (!found)
      {
         fprintf (stderr, "Error: %s: unable to find/interpolate f = %.3e Hz.\n", fname, flist[i]);
         return 1;
      }
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static int read_model_params (char *fname, double *p, unsigned sz_p)
{
   FILE *file;
   unsigned i = 0;
   char string[256];

   file = fopen (fname, "r");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", fname);
      return 1;
   }

   while (fgets (string, 255, file))
   {
      if ((string[0] == '!') || (string[0] == '#'))
         continue;

      if (i >= sz_p)
         break;

      if (sscanf (string, "%*f%lf", &p[i]) == 1)
         ++i;
   }

   fclose (file);

   if (i != sz_p)
   {
      fprintf (stderr, "Error: %s: not enough parameters.\n", fname);
      return 1;
   }

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static double calculate_gain( COMPLEX gs, COMPLEX *s, COMPLEX *gout )
{
   COMPLEX t1, t2, t3;
   COMPLEX one = {1.0, 0.0};
   COMPLEX goutc;
   double num, den;

   *gout = Cadd(s[3], Cdiv( Cmultx(3, s[1], s[2], gs), Csub(one,Cmult(s[0],gs)) ) );
   goutc = Cconj(*gout);

   t1 = Csub (one, Cmult(gs, s[0]));
   t2 = Csub (one, Cmult(goutc, s[3]));
   t3 = Cmultx (4, gs, goutc, s[1], s[2]);
   den = Cmag2 (Csub (Cmult (t1, t2), t3));
   num = Cmag2 (s[2]) * (1.0 - Cmag2 (gs)) * (1.0 - Cmag2 (*gout));

   return num / den;
}

/*********************************************************************************************/
/*********************************************************************************************/

static void deembed_noise_figure (double nf, COMPLEX *s_dut, COMPLEX *s_fxa,
                                  COMPLEX *s_fxb, COMPLEX *s_ns_2port, int use_s22,
                                  double temperature, double *nf_d, COMPLEX *gamma_s)
{
   /*
   COMPLEX ga, gb, gc;
   COMPLEX one = {1.0, 0.0};
   */
   COMPLEX gam2, gam3;
   double g1, g2, g3;
   double nf1, nf2, nf3;
   COMPLEX s_ns;

   if (use_s22)
      s_ns = s_ns_2port[3];
   else
      s_ns = s_ns_2port[0];

   /*
   ga = Cadd (s_fxa[3], Cdiv (Cmultx (3, s_fxa[1], s_fxa[2], s_ns), Csub (one, Cmult (s_ns, s_fxa[0]))));
   gb = Cadd (s_dut[3], Cdiv (Cmultx (3, s_dut[1], s_dut[2], ga), Csub (one, Cmult (ga, s_dut[0]))));
   gc = Cadd (s_fxb[3], Cdiv (Cmultx (3, s_fxb[1], s_fxb[2], gb), Csub (one, Cmult (gb, s_fxb[0]))));

   g1 = calculate_gt (s_ns, s_fxa, ga);
   g2 = calculate_gt (ga, s_dut, gb);
   g3 = calculate_gt (gb, s_fxb, gc);
   */

   g1 = calculate_gain( s_ns, s_fxa, gamma_s );
   g2 = calculate_gain( *gamma_s, s_dut, &gam2 );
   g3 = calculate_gain( gam2, s_fxb, &gam3 );

   nf1 = (1. / g1 - 1.) * temperature / T0 + 1.;
   nf2 = pow (10., nf * 0.1);
   nf3 = (1. / g3 - 1.) * temperature / T0 + 1.;

   *nf_d = 10.0 * log10( g1 * ( nf2 - nf1 - (nf3 - 1.)/(g1*g2) ) + 1. );

   printf( "%lg %lg %lg %lg %lg %lg %lg %lg %lg\n", g1, g2, g3, nf1, nf2, nf3, *nf_d, gamma_s->r, gamma_s->i );
}

/*********************************************************************************************/
/*********************************************************************************************/

static double noise_figure (COMPLEX *n_corr, COMPLEX gamma, double z0)
{
   COMPLEX z0c = Complex (z0);
   COMPLEX ys = Cdiv (Csub (Complex (1.0), gamma), Cadd (z0c, Cmult (z0c, gamma)));
   double x;

   x = Creal (Caddx (4, n_corr[3], Cmultx (3, n_corr[0], ys, Cconj (ys)), Cmult (n_corr[2], Cconj(ys)), Cmult (n_corr[1], ys)));

   return 10.0 * log10 (1.0 + x / Creal (ys));
}


/*********************************************************************************************/
/*********************************************************************************************/

static void noise_parameters (COMPLEX *ca, double z0, double *fmin, double *mag, double *angle, double *rn)
{
   COMPLEX yopt,gamma;
   COMPLEX one = {1.0, 0.0};
   double gopt, bopt;

   *rn = ca[0].r;

   bopt = 0.5 * Cimag (Csub (ca[1], ca[2])) / *rn;
   gopt = sqrt (fabs (Creal (Csub (Cdiv (ca[3], Complex (*rn)), Complex (bopt*bopt)))));
   yopt = Cnum (gopt, bopt);
   gamma = Cdiv (Csub (Complex (1.0 / z0), yopt), Cadd (Complex (1.0 / z0), yopt));

   *mag = Cmag (gamma);
   *angle = Cangle (gamma);
   *fmin = 10.0 * log10 (Creal (Caddx (4, one, ca[1], ca[2], Complex (2.0 * (*rn) * gopt))));
}

/*********************************************************************************************/
/*********************************************************************************************/

static void noise_matrix_reduction (COMPLEX **y, COMPLEX **cy, unsigned n, unsigned m)
{
   COMPLEX tmpc;
   COMPLEX denom1,denom2;
   COMPLEX one = {1.0, 0.0};
   double max,tmpd;
   unsigned i,j,k,row,col;

   for (k = n-1; k >= m; --k)
   {      
      // find maximum value

      max = 0.0;
      row = k;
      col = k;
      for (i = m; i <= k; ++i)
      {
         for (j = m; j <= k; ++j)
         {
            tmpd = Cmag2 (y[i][j]);
            if (tmpd > max)
            {
               row = i;
               col = j;
               max = tmpd;
            }
         }
      }

      // pivot rows

      if (row != k)
      {
         for (j = 0; j <= k; ++j)
         {
            tmpc = y[k][j];
            y[k][j] = y[row][j];
            y[row][j] = tmpc;

            tmpc = cy[k][j];
            cy[k][j] = cy[row][j];
            cy[row][j] = tmpc;            
         }

         for (i = 0; i <= k; ++i)
         {
            tmpc = cy[i][k];
            cy[i][k] = cy[i][row];
            cy[i][row] = tmpc;            
         }
      }

      // pivot columns

      if (col != k)
      {
         for (i = 0; i <= k; ++i)
         {
            tmpc = y[i][k];
            y[i][k] = y[i][col];
            y[i][col] = tmpc;
         }
      }

      // perform nodal reduction by one

      denom1 = Cdiv (one, y[k][k]);
      denom2 = Cdiv (one, Cconj(y[k][k]));
      for (i = 0; i < k; ++i)
      {
         for (j = 0; j < k; ++j)
         {
            y[i][j] = Csub (y[i][j], Cmultx (3, y[i][k], y[k][j], denom1));
            cy[i][j] = Csub (cy[i][j], Cmultx (3, y[i][k], cy[k][j], denom1));
            cy[i][j] = Csub (cy[i][j], Cmultx (3, cy[i][k], Cconj(y[j][k]), denom2));
            cy[i][j] = Cadd (cy[i][j], Cmultx (5, cy[k][k], y[i][k], Cconj(y[j][k]), denom1, denom2));
         }
      }
   } 
}   

/*********************************************************************************************/
/*********************************************************************************************/

static int noise_erf (double *p, void *data, double *error, unsigned n_err)
{
   NOISE_OPT *n = (NOISE_OPT *) data;
   double nf;
   COMPLEX nc[4],yp[4];
   unsigned i;

   if (n_err != 1)
      return -1;

   for (i = 0; i < n->n_freqs; ++i)
   {
      nf = calculate_noise_figure (n->y, n->yc, n->params, p[0], p[1], n->temperature, n->gamma[i], n->freqs[i], nc, yp);
      error[0] += fabs (n->nf[i] - nf); //  * (n->nf[i] - nf);
   }

   error[0] /= (double) n->n_freqs;

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static void add_y (COMPLEX **y, COMPLEX yval, unsigned n1, unsigned n2)
{
   y[n1][n1] = Cadd (y[n1][n1], yval);
   y[n1][n2] = Csub (y[n1][n2], yval);
   y[n2][n1] = Csub (y[n2][n1], yval);
   y[n2][n2] = Cadd (y[n2][n2], yval);
}

/*********************************************************************************************/
/*********************************************************************************************/

static double calculate_noise_figure (COMPLEX **y, COMPLEX **cy, double *p, double vv, double ii, double temperature,
                                      COMPLEX gamma_s, double freq, COMPLEX *n_corr, COMPLEX *y_params)
{
   double T1 = temperature / T0;
   COMPLEX zero = {0.0, 0.0};
   double w = 2.0 * acos (-1.0) * freq;
   double rg   = p[0];
   double rs   = p[1];
   double rd   = p[2];
   double ri   = p[3];
   double cgs  = p[4];
   double cgd  = p[5];
   double cds  = p[6];
   double cpg  = p[7];
   double cpd  = p[8];
   double ls   = p[9];
   double lg   = p[10];
   double ld   = p[11];
   double ggs  = p[12];
   double ggd  = p[13];
   double gm   = p[14];
   double tau  = p[15];
   double gds  = p[16];
   double tau2 = p[17];
   double c11  = p[18];
   double c22  = p[19];
   COMPLEX denom, yval;
   unsigned i,j;

   // zero the y-matrix and noise correlation matrix
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      for (j = 0; j < MATRIX_SIZE; ++j)
      {
         y[i][j] = zero;
         cy[i][j] = zero;
      }
   }

   /**** build the small-signal y-matrix ****/

   // port resistance and inductance
   add_y (y, Cnum (0.0, -1.0 / (w * lg)), 1, 3);
   add_y (y, Cnum (0.0, -1.0 / (w * ld)), 2, 4);
   add_y (y, Cnum (1.0 / rg, 0.0), 3, 6);
   add_y (y, Cnum (1.0 / rd, 0.0), 4, 7);
   add_y (y, Cnum (rs/(rs*rs + w*w*ls*ls), -w*ls/(rs*rs + w*w*ls*ls)), 5, 0);

   // fringing caps
   add_y (y, Cnum (0.0, w * cpg), 1, 0);
   add_y (y, Cnum (0.0, w * cpd), 2, 0);
   add_y (y, Cnum (0.0, w * c11), 3, 0);
   add_y (y, Cnum (0.0, w * c22), 4, 0);

   // gate capacitance/conductance
   add_y (y, Cnum (ggd, w * cgd), 6, 7);
   add_y (y, Cnum (ggs, w * cgs), 6, 8);

   // drain-source capacitance/conductance
   add_y (y, Cnum (gds*cos(w*tau2), w*cds - gds*sin(w*tau2)), 5, 7);

   // Ri and transconductance
   add_y (y, Cnum (1.0 / ri, 0.0), 5, 8);
   yval = Cnum (gm*cos(w*tau), -gm*sin(w*tau));
   y[7][6] = Cadd (y[7][6], yval);
   y[7][8] = Csub (y[7][8], yval);
   y[5][6] = Csub (y[5][6], yval);
   y[5][8] = Cadd (y[5][8], yval);

   /**** build the noise correlation matrix ****/

   add_y (cy, Complex (T1 / rg), 3, 6);
   add_y (cy, Complex (T1 / rd), 4, 7);
   add_y (cy, Complex (T1*rs/(rs*rs + w*w*ls*ls)), 5, 0);
   add_y (cy, Complex (T1 * ggs), 6, 8);
   add_y (cy, Complex (T1 * ggd), 6, 7);
   add_y (cy, Complex (ii), 7, 5);
   add_y (cy, Complex (vv / (ri*ri)), 8, 5);

   /**** Solve for the 2-port noise correlation matrix ****/

   noise_matrix_reduction (y, cy, MATRIX_SIZE, 3);

   denom = Complex (1.0 / Cmag2 (y[2][1])); 

   n_corr[0] = Cmult (cy[2][2], denom);
   n_corr[1] = Cmult (Csub (Cmult (cy[2][2], Cconj(y[1][1])), Cmult (cy[2][1], Cconj (y[2][1]))), denom);
   n_corr[2] = Cmult (Csub (Cmult (cy[2][2], y[1][1]), Cmult (cy[1][2], y[2][1])), denom);
   n_corr[3] = Csub (Cmult (cy[1][1], Complex (Cmag2 (y[2][1]))), Cmultx (3, cy[1][2], Cconj (y[1][1]), y[2][1]));
   n_corr[3] = Cadd (n_corr[3], Csub (Cmult (cy[2][2], Complex (Cmag2 (y[1][1]))), Cmultx (3, cy[2][1], y[1][1], Cconj (y[2][1]))));
   n_corr[3] = Cmult (n_corr[3], denom);

   y_params[0] = y[1][1];
   y_params[1] = y[1][2];
   y_params[2] = y[2][1];
   y_params[3] = y[2][2];

   return noise_figure (n_corr, gamma_s, 50.0);
}

/*********************************************************************************************/
/*********************************************************************************************/

static int optimize_noise_parameters (double *params, double *nf, double *f_list, COMPLEX *gamma,
                                      unsigned n_freqs, double temperature, unsigned flags, double *vv, double *ii)
{
   NOISE_OPT noise;
   OPT_PARAMETER p[2];
   OPTIMIZE *opt;
   unsigned oflag = OPT_AUTO;
   unsigned i;

   noise.params = params;
   noise.nf = nf;
   noise.gamma = gamma;
   noise.freqs = f_list;
   noise.n_freqs = n_freqs;
   noise.temperature = temperature;

   noise.y = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   noise.yc = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      noise.y[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
      noise.yc[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
   }

   p[0].min = 0.1;
   p[0].nom = 4.0;
   p[0].max = 20.0;
   p[0].tol = 0.0;
   strcpy (p[0].name, "vv");
   p[0].optimize = TRUE;

   p[1].min = 0.01;
   p[1].nom = 0.1;
   p[1].max = 1.0;
   p[1].tol = 0.0;
   strcpy (p[1].name, "ii");
   p[1].optimize = TRUE;

   opt = initialize_cg_optimizer ();
   set_cg_error_function (opt, noise_erf, (void *) &noise, 1, NULL);
   set_cg_parameters (opt, p, 2);
   set_cg_error_fraction (opt, 1.0e-12, 3);

   if (flags & BATCH_MODE)
      set_cg_flags (opt, oflag);
   else
      set_cg_flags (opt, oflag | OPT_VERBOSE);

   if (cg_optimize4 (opt, 200, NULL))
   {
      fprintf (stderr, "Error: %s\n", get_cg_error());
      return 1;
   }

   free ((void *) opt);

   // free memory for y and yc
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      free ((void *) noise.y[i]);
      free ((void *) noise.yc[i]);
   }
   free ((void *) noise.y);
   free ((void *) noise.yc);

   *vv = p[0].nom;
   *ii = p[1].nom;

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/

static double associated_gain (COMPLEX *s, COMPLEX gamma)
{
   COMPLEX gam1;
   return 10.0 * log10 (calculate_gain(gamma, s, &gam1));
}

/*********************************************************************************************/
/*********************************************************************************************/

static int write_output_file (char *fname, char *hname, double *f_list, double *nf, 
                              COMPLEX *gamma_s, unsigned n_freqs, double *p, double vv,
                              double ii, double temperature, BIAS bias)
{
   FILE *file, *infile;
   char string[256];
   COMPLEX n_corr[4], yparams[4], gam;
   POLAR gam_p;
   double f, nfig, fmin, rn, gain;
   COMPLEX zero = {0.0, 0.0};
   unsigned i;
   COMPLEX **y, **cy;

   file = fopen (fname, "w+");
   if (!file)
   {
      fprintf (stderr, "Error: %s: unable to open file for writing.\n", fname);
      return 1;
   }

   // write the header
   infile = fopen (hname, "r");
   if (infile)
   {
      while (fgets (string, 255, infile))
      {
         if ((string[0] != '!') || !strncmp (string, "!BIAS", 5))
            break;

         fprintf (file, "%s", string);
      }

      fclose (infile);
   }

   // allocate memory 
   y = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   cy = (COMPLEX **) malloc (sizeof (COMPLEX *) * MATRIX_SIZE);
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      y[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
      cy[i] = (COMPLEX *) malloc (sizeof (COMPLEX) * MATRIX_SIZE);
   }

   // write modeled vs measured validation info
   fprintf (file, "! Measured vs. Modeled:\n");
   fprintf (file, "! Freq   NF_meas NF_mod Error\n");
   fprintf (file, "! (GHz)   (dB)   (dB)   (dB)\n");
   //                |    | |    | |    | |    |  
   for (i = 0; i < n_freqs; ++i)
   {
      nfig = calculate_noise_figure (y, cy, p, vv, ii, temperature, gamma_s[i], f_list[i], n_corr, yparams);
      fprintf (file, "! %6.3f %6.3f %6.3f %6.3f\n", f_list[i]*1.0e-9, nf[i], nfig, nf[i] - nfig);
   }

   // write the noise parameters from 0.5 to 50 GHz
   fprintf (file, "!\n");
   fprintf (file, "! Freq    Fmin     Gamma_Opt       Rn        Vds           Ids           Vgs           Igs              Noise_Params          Gain\n");
   fprintf (file, "!(GHz)    (dB)     Mag    Ang    (Ohms)    (Volts)        (Amps)       (Volts)        (Amps)      <vv*>/4kT0    <ii*>/4kT0    (dB)\n");
   fprintf (file, "!----------------------------------------------------------------------------------------------------------------------------------\n");
   //              |     | |     | |     | |     | |     | |           | |           | |           | |           | |           | |           | |     |

   for (f = 0.5; f < 50.1; f += 0.5)
   {
      nfig = calculate_noise_figure (y, cy, p, vv, ii, temperature, zero, f*1.0e9, n_corr, yparams);
      noise_parameters (n_corr, 50.0, &fmin, &gam_p.m, &gam_p.a, &rn);

      gam = P2C (gam_p);
      gain = associated_gain (y2s (yparams, yparams, 50.0), gam);

      fprintf (file, "%7.3f %7.3f %7.3f %7.2f %7.3f %13.5e %13.5e %13.5e %13.5e %13.5e %13.5e %7.3f\n",
         f, fmin, gam_p.m, gam_p.a, rn, bias.vds, bias.ids, bias.vgs, bias.igs, vv, ii, gain);      
   }

   fclose (file);

   // free memory for y and yc
   for (i = 0; i < MATRIX_SIZE; ++i)
   {
      free ((void *) y[i]);
      free ((void *) cy[i]);
   }
   free ((void *) y);
   free ((void *) cy);

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/

static int noise_deembed (unsigned flags)
{
   char string[256], noise_file[256];
   char fxa_file[256], fxb_file[256];
   char s_file[256], ns_file[256], out_file[256];
   double freq, nf, gain, nf_d;
   COMPLEX s_fxa[1][4], s_fxb[1][4];
   COMPLEX s_dut[1][4], s_ns[1][4];
   COMPLEX gamma_s;
   int interpolation_flag = INTERPOLATE_POLAR;
   int use_s22;
   FILE *infile, *outfile;

   printf ("Measured noise figure data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", noise_file);

   printf ("Measured S-parameter data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", s_file);

   printf ("Input error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fxa_file);

   printf ("Output error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fxb_file);

   printf ("Noise source S-parameter file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", ns_file);

   printf ("Output file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", out_file);

   infile = fopen (noise_file, "r");
   if (!infile)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", noise_file);
      return 1;
   }

   outfile = fopen (out_file, "w+");
   if (!outfile)
   {
      fprintf (stderr, "Error: %s: unable to write to file.\n", out_file);
      return 1;
   }

   while (fgets (string, 255, infile))
   {
      if (string[0] == '!')
         fprintf (outfile, "%s", string);
      else if (sscanf (string, "%lf%lf%lf", &freq, &gain, &nf) == 3)
      {
         /**** read in S-parameters for the input block, output block, device, and noise source ****/

         if (read_s_param_data (fxa_file, &freq, 1, s_fxa, interpolation_flag))
            return 1;

         if (read_s_param_data (fxb_file, &freq, 1, s_fxb, interpolation_flag))
            return 1;

         if (read_s_param_data (s_file, &freq, 1, s_dut, interpolation_flag))
            return 1;

         if (read_s_param_data (ns_file, &freq, 1, s_ns, interpolation_flag))
            return 1;

         /**** determine wheter to use S11 or S22 of the noise source file ****/

         if (Cmag (s_ns[0][0]) < Cmag (s_ns[0][3]))
            use_s22 = 0;
         else
            use_s22 = 1;

         deembed_noise_figure (nf, s_dut[0], s_fxa[0], s_fxb[0], s_ns[0], use_s22, ROOM_TEMP, &nf_d, &gamma_s);
         fprintf (outfile, "%.5e %.5e\n", freq, nf_d);
      }
   }

   fclose (infile);
   fclose (outfile);

   return 0;
}

/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/
/*********************************************************************************************/

static int noise_scalar_deembed (unsigned flags)
{
   char string[256], noise_file[256];
   char fxa_file[256], fxb_file[256];
   char out_file[256];
   double freq, nf, gain;
   double ft, gt, f1, g1, f2, g2, f3, g3;
   COMPLEX s_fxa[1][4], s_fxb[1][4];
   int interpolation_flag = INTERPOLATE_POLAR;
   FILE *infile, *outfile;

   printf ("Measured noise figure data file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", noise_file);

   printf ("Input error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fxa_file);

   printf ("Output error box file?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", fxb_file);

   printf ("Output file name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", out_file);

   infile = fopen (noise_file, "r");
   if (!infile)
   {
      fprintf (stderr, "Error: %s: unable to open file.\n", noise_file);
      return 1;
   }

   outfile = fopen (out_file, "w+");
   if (!outfile)
   {
      fprintf (stderr, "Error: %s: unable to write to file.\n", out_file);
      return 1;
   }

   while (fgets (string, 255, infile))
   {
      if (string[0] == '!')
         fprintf (outfile, "%s", string);
      else if (sscanf (string, "%lf%lf%lf", &freq, &gain, &nf) == 3)
      {
         /**** read in S-parameters for the input block and output block ****/

         if (read_s_param_data (fxa_file, &freq, 1, s_fxa, interpolation_flag))
            return 1;

         if (read_s_param_data (fxb_file, &freq, 1, s_fxb, interpolation_flag))
            return 1;

         /*** calculate the total noise factor and gain (linear) ***/
         ft = pow (10.0, nf*0.1);
         gt = pow (10.0, gain*0.1);

         /*** calculate the input/output fixture gain (loss) and noise factors ***/
         g1 = 0.5 * (Cmag2 (s_fxa[0][1]) + Cmag2 (s_fxa[0][2]));
         g3 = 0.5 * (Cmag2 (s_fxb[0][1]) + Cmag2 (s_fxb[0][2]));
         f1 = 1.0 / g1;
         f3 = 1.0 / g3;

         /*** calculate the DUT gain ***/
         g2 = gt / (g1 * g3);

         /*** calculate the DUT noise factor ***/
         f2 = (g1*g2*(ft-f1) - (f3-1.0)) / g2 + 1.0;

         /*** convert to noise figure and gain (dB) and write to file ***/
         fprintf (outfile, "%.5e %.5e %.5e\n", freq, 10.0 * log10 (g2), 10.0 * log10 (f2));
      }
   }

   fclose (infile);
   fclose (outfile);

   return 0;
}




