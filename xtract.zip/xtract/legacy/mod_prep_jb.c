#include <stdio.h>
#include <string.h>
#include <time.h>

static void get_basename (char *fname, char *basename);

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *lfile, *tmp;
   char fname[256];
   char dname[256];
   char files[256];
   char embed_file[256];
   char string[256];
   char coldfet_freq[41];
   char tmp_file_name[256];
   char cwd[256];
   char ch;
   char *ext;
   time_t tbuf;
   
   printf ("Files to prep for modeling?\n");
   fgets (files, 255, stdin);
   files[strlen(files)-1] = 0;
   
   printf ("Embed(e), Deembed(d), or None(n)?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%c", &ch);

   if ((ch == 'e') || (ch == 'E') || (ch == 'd') || (ch == 'D'))
      {
      printf ("Embed/Deembed file?\n");
      fgets (string, 255, stdin);
      sscanf (string, "%s", &embed_file);
      ext = ".dm2";
      }
   else
      ext = ".dmb";
      
   printf ("Coldfet frequency range in GHz (start stop)?\n");
   fgets (coldfet_freq, 40, stdin);

   if (!getcwd (cwd, 255))
      {
      printf ("Error: cannot get current directory name.\n");
      return 1;
      }

   /**** create and open the file list ****/

   sprintf (tmp_file_name, "tmp.%d", time(&tbuf));
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);
   sprintf (string, "ls -1 %s > %s", files, tmp_file_name);
   system (string);

   lfile = fopen (tmp_file_name,"r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }
   
   /**** loop through the file list ****/

   while (fgets (fname, 255, lfile))
      {
      fname[strlen(fname)-1] = 0;
      get_basename (fname, dname);
      if (!strcmp (fname, dname))
         {
         printf ("Error: %s: filename has no extension.\n", fname);
         continue;
         }
      
      sprintf (string, "mkdir %s", dname);
      system (string);
      
      sprintf (string, "mv -f %s %s", fname, dname);
      system (string);
      
      if (chdir (dname))
         {
         printf ("%s: Failed to change directory.\n", dname);
         return 1;
         }
      
      sprintf (string, "make_files %s", fname);
      system (string);
      
      if ((ch == 'e') || (ch == 'E'))
         {
         tmp = fopen ("xxxtmp", "w+");
         if (!tmp)
            {
            printf ("Failed to write to disc.\n");
            return 1;
            }
         
         fprintf (tmp, "*.dmb\n");
         fprintf (tmp, "../%s\n", embed_file);
         fprintf (tmp, "../%s\n", embed_file);
         fprintf (tmp, ".dm2\n");
         fclose (tmp);
         
         sprintf (string, "embed < xxxtmp");
         system (string);
         
         sprintf (string, "rm -f *.dmb xxxtmp");
         system (string);
         }
      else if ((ch == 'd') || (ch == 'D'))
         {
         tmp = fopen ("xxxtmp", "w+");
         if (!tmp)
            {
            printf ("Failed to write to disc.\n");
            return 1;
            }
         
         fprintf (tmp, "*.dmb\n");
         fprintf (tmp, "../%s\n", embed_file);
         fprintf (tmp, "../%s\n", embed_file);
         fprintf (tmp, ".dm2\n");
         fclose (tmp);
         
         sprintf (string, "deembed < xxxtmp");
         system (string);
         
         sprintf (string, "rm -f *.dmb xxxtmp");
         system (string);
         }
      
      tmp = fopen ("yyytmp", "w+");
      if (!tmp)
         {
         printf ("Failed to write to disc.\n");
         return 1;
         }
         
      fprintf (tmp, "s000c060%s s000c080%s s000c100%s\n", ext, ext, ext);
      fprintf (tmp, "s000c000%s\n", ext);
      fprintf (tmp, "%s", coldfet_freq);
      fprintf (tmp, "2.0\n");
      fprintf (tmp, "s.end\n");
      fclose (tmp);
      
      sprintf (string, "coldfet2 < yyytmp");
      system (string);
      
      sprintf (string, "rm -f yyytmp");
      system (string);
      
      if (chdir (cwd))
         {
         printf ("%s: Failed to change directory.\n", cwd);
         return 1;
         }
         
      }   

   fclose (lfile);

   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   return 0;
   }
   
/************************************************************************************/

static void get_basename (char *fname, char *basename)
   {
   unsigned i, len = strlen (fname);
   strcpy (basename, fname);
   
   for (i = len; i > 0; --i)
      {
      if (basename[i] == '/')
         break;
      else if (basename[i] == '.')
         {
         len = i;
         break;
         }
      }
   
   basename[len] = 0;   
   }

