#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (int argc, char *argv[])
   {
   char string[256];
   char inname[256];
   char outname[256];
   int x,y;
   double vout;
   FILE *infile,*outfile;
   int header_done = 0;
   
   
   printf ("File name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", inname);
   
   printf ("Output name?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%s", outname);
   
   infile = fopen (inname, "r");
   if (!infile)
      {
      printf ("Unable to open file: %s\n", inname);
      return 1;
      }
   
   outfile = fopen (outname, "w+");
   if (!outfile)
      {
      printf ("Unable to write output file.\n");
      return 1;
      }
   
   while (fgets (string, 255, infile))
      {
      if (!strncmp (string, "!SITE", 5))
         {
         if (!header_done)
            header_done = 1;         
         }
      
      if (!header_done)
         fprintf (outfile, "%s", string);
      else if (sscanf (string, "%lf", &vout))
         fprintf (outfile, "%s", string);
      }
   
   fclose (infile);
   fclose (outfile);
   
   return 0;
   }
      
         
