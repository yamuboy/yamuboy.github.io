#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define  mod(x,y)       (x - ((int) x/y)*y)

main (argc,argv)
int   argc;
char  *argv[];

{
int     i,n,num_biases,fet,err;
FILE    *s_file,*plot_file;
double  vgs[1000],vds[1000],ibe[1000];
char    file_name[81],temp_file_name[200];
char    temp_name2[200],string[201];
time_t  current_t;

if (argc > 1)
   {
   sscanf (argv[1],"%s",file_name);
   }
else
   {
   printf ("S-parameter File Name > ");
   scanf ("%s",file_name);
   }

s_file = (FILE *) NULL;
s_file = fopen (file_name,"r");

if (s_file == (FILE *) NULL)
   {
   printf ("ERROR: File not found - %s\n",file_name);
   exit (-1);
   }

i = 0;
fet = 0;

while (fgets (string,200,s_file) != NULL)
   {
   if (!strncmp (string,"!BIAS: VDS = ",13))
      {
      sscanf (&string[13],"%lf",&vds[i]);
      sscanf (&string[62],"%lf",&vgs[i]);
      fet = 1;
      ++i;
      }
   else if (!strncmp (string,"!BIAS: VCE = ",13))
      {
      sscanf (&string[13],"%lf",&vds[i]);
      sscanf (&string[87],"%lf",&ibe[i]);
      ++i;
      }
   }

printf ("%d bias points found\n",i);
num_biases = i;

if (fet)
   {
   printf (" #    Vgs   Vds      #    Vgs   Vds       #    Vgs   Vds       #    Vgs   Vds       #    Vgs   Vds \n");
   printf ("---------------------------------------------------------------------------------------------------\n");

   for (i = 0; i < num_biases; ++i)
      {
      printf ("%3d %6.3f %6.2f    ",i,vgs[i],vds[i]);
      if (mod (i,5) == 4)
         {
         printf ("\n");
         }
      }
   }
else
   {
   printf (" #    Ibe   Vce       #    Ibe   Vce       #    Ibe   Vce       #    Ibe   Vce       #    Ibe   Vce \n");
   printf ("----------------------------------------------------------------------------------------------------\n");

   for (i = 0; i < num_biases; ++i)
      {
      printf ("%3d %6.3f %6.2f    ",i,ibe[i]*((double) 1000.0),vds[i]);
      if (mod (i,5) == 4)
         {
         printf ("\n");
         }
      }
   }
printf ("\n");

err = 1;
while (err)
   {
   printf ("Enter #: > ");
   scanf ("%d",&n);
   
   if ((n < 0) || (n > (num_biases-1)))
      {
      printf ("** error ** enter a number from 0 to %d\n",num_biases-1);
      }
   else
      {
      err = 0;
      }
   }

rewind (s_file);

sprintf (temp_file_name,"temp_plot.%d",time (&current_t));
plot_file = fopen (temp_file_name,"w+");

do {
   fgets (string,200,s_file);
   
   if (string[0] == '!')
      {
      fprintf (plot_file,"%s",string);
      }
   }
while (string[0] == '!');

rewind (s_file);

i = 0;
while (i < n)
   {
   fgets (string,200,s_file);
   if (!strncmp (string,"!BIAS: ",7))
      {
      ++i;
      }
   }

while (fgets (string,200,s_file) != NULL)
   {
   if (!strncmp (string,"!BIAS: ",7))
      {
      break;
      }
   
   fprintf (plot_file,"%s",string);
   }

fclose (s_file);
fclose (plot_file);

sprintf (temp_name2,"tempin.%d",time (&current_t));
plot_file = fopen (temp_name2,"w+");
fprintf (plot_file,"%s\n11\n",temp_file_name);
fclose (plot_file);

sprintf (string,"plot_s < %s",temp_name2);
system (string);

sprintf (string,"rm -f %s",temp_file_name);
system (string);

sprintf (string,"rm -f %s",temp_name2);
system (string);

}
