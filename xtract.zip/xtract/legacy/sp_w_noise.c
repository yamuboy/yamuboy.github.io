#include <stdio.h>
#include <string.h>
#include <time.h>

/*********************************************************************************************/
/*********************************************************************************************/

int main (int argc, char *argv[])
   {
   FILE *lfile, *ofile, *sfile, *nfile;
   char files[256];
   char fname[256];
   char outname[256];
   char nname[256];
   char string[256];
   char noise_ext[30];
   char file_ext[30];
   char tmp_file_name[256];
   char cwd[256];
   double freq, fmin, soptm, sopta, rn;;
   time_t tbuf;
   
   printf ("S-Parameter files?\n");
   fgets (files, 255, stdin);
   files[strlen(files)-1] = 0;
   
   printf ("Extension for new files?\n");
   fgets (string, 255, stdin);
   sscanf (string, "%29s", file_ext);
   
   /**** create and open the file list ****/

   sprintf (tmp_file_name, "tmp.%d", time(&tbuf));
   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);
   sprintf (string, "ls -1d %s > %s", files, tmp_file_name);
   system (string);

   lfile = fopen (tmp_file_name,"r");
   if (!lfile)
      {
      printf ("Error: cannot open batch file.\n");
      return -1;
      }
   
   /**** loop through the file list ****/

   while (fgets (fname, 255, lfile))
      {
      fname[strlen(fname)-1] = 0;
      
      sscanf (fname, "%[^.]", nname);
      strcpy (outname, nname);
      strcat (nname, ".rpc");
      nname[0] = 'n';
      strcat (outname, file_ext);

      nfile = fopen (nname, "r");
      if (!nfile)
         continue;
         
      sfile = fopen (fname, "r");
      if (!sfile)
         {
         fclose (nfile);
         continue;
         }

      ofile = fopen (outname, "w+");
      if (!ofile)
         {
         printf ("Error writing to disc.\n");
         exit (1);
         }

      while (fgets (string, 255, sfile))
         {         
         fprintf (ofile, "%s", string);
         }
      
      fprintf (ofile, "! ------------    Noise Data    --------------\n");
      fprintf (ofile, "! Freq\t\tFmin\tSopt.m\tSopt.a\trn\n");

      while (fgets (string, 255, nfile))
         {
         if (string[0] == '!')
            continue;
         else if (sscanf (string, "%lf%lf%lf%lf%lf", &freq, &fmin, &soptm, &sopta, &rn) == 5)
            {
            if (freq > 26.5)
               break;
            
            freq *= 1.0e9;
            rn /= 50.0;
            
            fprintf (ofile, "%.5e\t%.4f\t%.4f\t%.2f\t%.4f\n", freq, fmin, soptm, sopta, rn);
            }
         }
      
      fclose (ofile);
      fclose (sfile);
      fclose (nfile);         
      }   

   fclose (lfile);

   sprintf (string, "rm -f %s", tmp_file_name);
   system (string);

   return 0;
   }
   
