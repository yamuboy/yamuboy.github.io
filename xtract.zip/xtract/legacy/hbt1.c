#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <optimize3.h>
#include <cmplxlib.h>
#include <matrix_tools.h>
#include <jplot.h>

// constants
#define BOLTZ         1.3806226e-23
#define CHARGE        1.6021918e-19

// max sizes for arrays
#define NUM_PARAMS    31
#define MAX_PARA_PTS  5
#define MAX_CAP_PTS   30
#define MAX_TF_PTS    30
#define MAX_IV_PTS    1500
#define MAX_S_PTS     200

// option flags
#define SUPPRESS_GRAPHS   1
#define USE_POSTSCRIPT    2
#define USE_METAFILE      4
#define SKIP_PARASITICS   16
#define SKIP_GUMMEL       32
#define SKIP_CAPACITANCE  64
#define SKIP_TF           128
#define SKIP_DCIV         256
#define SKIP_RBI          512

// modes
#define DCIV          1
#define FWD_GUMMEL    2
#define REV_GUMMEL    3
#define FLYBACK       4
#define EXTRACT_CBC   10
#define EXTRACT_CBE   11

/* -------- FUNCTION PROTOTYPES ---------- */

int get_starting_values (char fname[]);
int get_iv_data (char fname[], int mode);
int hot_hbt_extraction (char files[], double fstart, double fstop);
int re_from_flyback (char fname[], double istart, double istop);
int gummel_fit (char fname[], double vstart, double vstop, int mode);
int fit_re_from_gummel (char infile[]);
int extract_capacitance (char files[], double fstart, double fstop, int mode);
int extract_tf (char files[], double imin, double imax);
void write_output_files (char *end_file, char *mod_file, char *head_file);
int plot_data (char fg_file[], char rg_file[], char iv_file[], char flyback_file[],
               double, double, double, double, double, double);
void calculate_eebjt2_s (double *p, double vbe, double vce, double freq, S_2PORT *sp);

double *cbc_erf (double *);
double *cbe_erf (double *);
double *ice_erf (double *);
double *rbi_erf (double *);

static double junction_cap (double v, double vj, double mj, double cj, double coff);
static double eebjt2_iv_model (double *p, double ib, double vc, double vb, double *vbe);
static void high_current_fwd_gummel (double v, double ibif, double nbf, double isf,
                                     double nf, double ikf, double rb, double re,
                                     double *ib, double *ic);
static double eebjt2_gbx (double ibix, double nbx, double isx, double nx, double vbx,
                          double tnom);

static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2);
static void linefit_mx0 (double *x, double *y, int n, double *m, double *r2);
static int diode_fit (double *vd, double *id, int k, double *is, double *n, double *rd);


/* ---------- GLOBAL VARIABLES ----------- */

PARAM_STRUCT   params[NUM_PARAMS];

double         ibep[MAX_PARA_PTS];
double         rb1[MAX_PARA_PTS];
double         rc1[MAX_PARA_PTS];
double         re1[MAX_PARA_PTS];
double         lb1[MAX_PARA_PTS];
double         lc1[MAX_PARA_PTS];
double         le1[MAX_PARA_PTS];
double         ree_orig,lee_orig;
int            num_para_pts;

double         vcbe[MAX_CAP_PTS];
double         vcbc[MAX_CAP_PTS];
double         cbem[MAX_CAP_PTS];
double         cbcm[MAX_CAP_PTS];
double         cjc0_orig,cje0_orig;
double         cce1,cce2;
int            num_cbe_pts,num_cbc_pts;

double         icetf[MAX_TF_PTS];
double         tfm[MAX_TF_PTS];
int            num_tf_pts;

double         vceiv[MAX_IV_PTS];
double         vbeiv[MAX_IV_PTS];
double         iceiv[MAX_IV_PTS];
double         ibeiv[MAX_IV_PTS];
int            num_iv_pts;
int            rc_start_index;

S_2PORT        sparams[MAX_S_PTS];
double         spvbe,spvce;
double         sp_minf,sp_maxf;
int            num_s_pts;

double         area,temperature,max_vce;
double         rc_slope,rb_slope,re_slope;
double         lc_slope,lb_slope,le_slope;
double         tf_slope,tf_intr,fly_intr;

int            option_flags;

/****************************************************************************/
/*                                  MAIN                                    */
/****************************************************************************/

main (int argc, char *argv[])
   {
   int         i,n,niter_cap,niter_iv,niter_rbi,f[10],flag;
   double      weights[6];
   double      pfstart,pfstop,cfstart,cfstop,tfstart,tfstop;
   double      fwdg_start,fwdg_stop,revg_start,revg_stop;
   char        hot_hbt_files[100],cbc_files[100],cbe_files[100],tf_files[100],rbi_file[100];
   char        dc_iv_file[100],fwd_gum_file[100],rev_gum_file[100],skip_fits[50],ch;
   char        start_file[100],end_file[100],model_file[100],string[200];
   char        flyback_file[100];
   double      flystart,flystop;
   OPT_STRUCT  opt;
   S_BIAS      sbias;
   
   // check command line for a help request
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-h",2))
         {
         printf ("\n\nUSAGE: hbt_fit [-s -h -dA]\n-------------------------------------------\n");
         printf ("  -s    Suppress graphics output.\n");
         printf ("  -h    Brings up this dialog.\n");
         printf ("  -dA   Sets the graphics device, where A is one of \'X\' (default), \'P\', or \'M\',\n");      
         printf ("         which indicate X-Windows, Postscript, or Metafile, respectively.\n");
         printf ("\n\n");
         return 0;
         }
      }     

   /************ Get Information ***************/

   printf ("Device size (um^2)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf",&area);
   
   printf ("Hot HBT files (use wildcards)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",hot_hbt_files);

   printf ("Frequency range in Ghz for parasitic extraction (start stop)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&pfstart,&pfstop);
   pfstart *= 1.0e9;
   pfstop  *= 1.0e9;

   printf ("Emitter resistance flyback file?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",flyback_file);

   printf ("Ibe range (kA/cm^2) for Re extraction?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&flystart,&flystop);
   flystart *= 1.0e-5*area;
   flystop  *= 1.0e-5*area;

   printf ("Forward Gummel file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",fwd_gum_file);

   printf ("Forward Gummel Vbe extraction range (start stop)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&fwdg_start,&fwdg_stop);

   printf ("Reverse Gummel file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",rev_gum_file);

   printf ("Reverse Gummel Vbc extraction range (start stop)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&revg_start,&revg_stop);

   printf ("Cbc capacitance files (use wildcards)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",cbc_files);

   printf ("Cbe capacitance files (use wildcards)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",cbe_files);

   printf ("Frequency range in Ghz for capacitance extraction (start stop)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&cfstart,&cfstop);
   cfstart *= 1.0e9;
   cfstop  *= 1.0e9;

   printf ("Maximum number of capacitance line searches?\n");
   fgets (string,199,stdin);
   sscanf (string,"%d",&niter_cap);   

   printf ("[S] files for Tf extraction (use wildcards)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",tf_files);

   printf ("Ice range (kA/cm^2) for Tf extraction (start stop)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&tfstart,&tfstop);
   tfstart *= 1.0e-5*area;
   tfstop  *= 1.0e-5*area;

   printf ("DC I-V file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",dc_iv_file);

   printf ("Maximum Vce for I-V fit?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf",&max_vce);

   printf ("Maximum number of DC I-V line searches?\n");
   fgets (string,199,stdin);
   sscanf (string,"%d",&niter_iv);

   printf ("[S] file for [S]-parameter fit?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",rbi_file);

   printf ("Frequency range in Ghz for [S]-parameter fit (start stop)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf%lf",&sp_minf,&sp_maxf);
   sp_minf *= 1.0e9;
   sp_maxf *= 1.0e9;
   
   printf ("Maximum number of [S]-parameter line searches?\n");
   fgets (string,199,stdin);
   sscanf (string,"%d",&niter_rbi);   

   printf ("Start parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",start_file);

   printf ("Finish parameters file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",end_file);

   printf ("Output model file name?\n");
   fgets (string,199,stdin);
   sscanf (string,"%99s",model_file);

   printf ("Model extraction temperature (degrees C)?\n");
   fgets (string,199,stdin);
   sscanf (string,"%lf",&temperature);
   temperature += 273.15;

   printf ("Fits to skip: (separate by spaces, CR for none)\n");
   printf ("   1: Parasitics\n");
   printf ("   2: Gummel Curves\n");
   printf ("   3: Junction Capacitance\n");
   printf ("   4: Forward Transit Time\n");
   printf ("   5: DC I-V Curves\n");
   printf ("   6: Dynamic [S] Fit\n");
   printf ("   7: Graphics Ouput\n");
   fgets (skip_fits,49,stdin);

   /************ Parse Command Line ***************/

   option_flags = 0;
   for (i = 1; i < argc; ++i)
      {
      if (!strncmp (argv[i],"-s",2))
         option_flags |= SUPPRESS_GRAPHS;
      else if (!strncmp (argv[i],"-d",2))
         {
         sscanf (argv[i],"-d%c",&ch);
         if ((ch == 'p') || (ch == 'P'))
            option_flags |= USE_POSTSCRIPT;
         else if ((ch == 'm') || (ch == 'M'))
            option_flags |= USE_METAFILE;
         }
      }
   
   /************ Parse Fits to Skip ****************/
   n = sscanf (skip_fits,"%d%d%d%d%d%d%d",&f[0],&f[1],&f[2],&f[3],&f[4],&f[5],&f[6]);
   for (i = 0; i < n; ++i)
      {
      switch (f[i])
         {
         case 1:
            option_flags |= SKIP_PARASITICS;
            break;
         case 2:
            option_flags |= SKIP_GUMMEL;
            break;
         case 3:
            option_flags |= SKIP_CAPACITANCE;
            break;
         case 4:
            option_flags |= SKIP_TF;
            break;
         case 5:
            option_flags |= SKIP_DCIV;
            break;
         case 6:
            option_flags |= SKIP_RBI;
            break;
         case 7:
            option_flags |= SUPPRESS_GRAPHS;
            break;
         default:
            break;
         }
      }

   /************** Initialization ******************/
   
   initialize_optimizer (&opt, NUM_PARAMS, 1, weights, niter_cap, &cbc_erf);
   weights[0] = 1.0;
   weights[1] = 1.0;
   opt.err_fraction = 1.0e-9;

   if (get_starting_values (start_file))
      {
      printf ("ERROR: get_starting_values() failed.\n");
      return -1;
      }

   /************ Parasitic Extraction **************/

   if (!(option_flags & SKIP_PARASITICS))
      {
      printf ("Performing Parasitic Extraction.....\n");
      
      if (hot_hbt_extraction (hot_hbt_files,pfstart,pfstop))
         {
         printf ("ERROR: hot_hbt_extraction() failed.\n");
         return -1;
         }

      ree_orig = params[4].nom;
      lee_orig = params[5].nom;
      
      if (re_from_flyback (flyback_file,flystart,flystop))
         {
         printf ("ERROR: re_from_flyback() failed.\n");
         return -1;
         }
      }

   if (!(option_flags & SKIP_GUMMEL))
      {
      /************** Forward Gummel Fit **************/
      
      printf ("Fitting Forward Gummel Curves.....\n");
      
      if (gummel_fit (fwd_gum_file,fwdg_start,fwdg_stop,FWD_GUMMEL))
         {
         printf ("ERROR: gummel_fit() failed.\n");
         return -1;
         }

#if 0
      // not using this method....

      /************ Emitter Resistance Fit ************/

      if (!(option_flags & SKIP_PARASITICS))
         {
         printf ("Fitting Emitter Resistance.....\n");

         if (fit_re_from_gummel (fwd_gum_file))
            {
            printf ("fit_re_from_gummel() failed.\n");
            return -1;
            }
         }
#endif

      /************** Reverse Gummel Fit **************/
      
      printf ("Fitting Reverse Gummel Curves.....\n");
      
      if (gummel_fit (rev_gum_file,revg_start,revg_stop,REV_GUMMEL))
         {
         printf ("ERROR: gummel_fit() failed.\n");
         return -1;
         }
      }

   if (!(option_flags & SKIP_CAPACITANCE))
      {
      /******************* Cbc Fit ********************/
      
      printf ("Fitting Base-Collector Capacitance.....\n");
      
      if (extract_capacitance (cbc_files,cfstart,cfstop,EXTRACT_CBC))
         {
         printf ("ERROR: extract_capacitance() failed.\n");
         return -1;
         }
      
      params[9].min = params[9].max = params[9].nom = cbcm[0]*0.5;

      params[7].optimize = TRUE;
      params[8].optimize = TRUE;

      opt.function = &cbc_erf;
      
      if (cg_optimize (opt,params) < 0)
         printf ("ERROR in cg_optimize().\n");
      
      params[7].optimize = FALSE;
      params[8].optimize = FALSE;
      
      /******************* Cbe Fit ********************/
      
      printf ("Fitting Base-Emitter Capacitance.....\n");
      
      if (extract_capacitance (cbe_files,cfstart,cfstop,EXTRACT_CBE))
         {
         printf ("ERROR: extract_capacitance() failed.\n");
         return -1;
         }

      params[13].min = params[13].max = params[13].nom = cbem[0]*0.1;
      
      params[11].optimize = TRUE;
      params[12].optimize = TRUE;
      
      opt.function = &cbe_erf;
      
      if (cg_optimize (opt,params) < 0)
         printf ("ERROR in cg_optimize().\n");
      
      params[11].optimize = FALSE;
      params[12].optimize = FALSE;
      }

   /******************** Tf Fit ********************/

   if (!(option_flags & SKIP_TF))
      {
      printf ("Fitting Forward Transit Time.....\n");
            
      if (extract_tf (tf_files,tfstart,tfstop))
         {
         printf ("ERROR: extract_tf() failed.\n");
         return -1;
         }
      }

   /******************* I-V Fit ********************/

   if (!(option_flags & SKIP_DCIV))
      {
      printf ("Fitting I-V Curves.....\n");
      
      if ((num_iv_pts = get_iv_data (dc_iv_file,DCIV)) < 1)
         {
         printf ("ERROR in get_iv_data().\n");
         return -1;
         }
      
      for (i = 15; i < 29; ++i)
         params[i].optimize = TRUE;
      
      opt.function = &ice_erf;
      opt.err_fraction = 1.0e-5;
      opt.max_iterations = niter_iv;
      
      params[15].min = params[15].nom*0.7;
      params[15].max = params[15].nom*1.3;
      params[17].min = params[17].nom*0.7;
      params[17].max = params[17].nom*1.3;
      params[18].min = params[18].nom*0.9;
      params[18].max = params[18].nom*1.1;
            
      if (cg_optimize (opt,params) < 0)
         printf ("ERROR in cg_optimize().\n");
      
      for (i = 15; i < 29; ++i)
         params[i].optimize = FALSE;
      }

   /***************** Rbi Fit ***********************/

   if (!(option_flags & SKIP_RBI))
      {
      printf ("Dynamically fitting intristic elements.....\n");

      flag = 1;
      if ((num_s_pts = read_s_from_file (rbi_file,sparams,&sbias,MAX_S_PTS)) < 1)
         {
         printf ("ERROR: failed to read [S] file. Skipping...\n");
         flag = 0;
	 option_flags |= SKIP_RBI;
         }

      spvbe = sbias.vgs - sbias.igs*params[0].nom - (sbias.igs+sbias.ids)*params[4].nom;
      spvce = sbias.vds - sbias.ids*params[2].nom - (sbias.igs+sbias.ids)*params[4].nom;

      params[6].optimize = TRUE;
      params[9].optimize = TRUE;
      params[10].optimize = TRUE;
      params[13].optimize = TRUE;
      params[14].optimize = TRUE;
      params[29].optimize = TRUE;
      params[30].optimize = TRUE;

      params[6].min = params[6].nom*0.5;
      params[6].max = params[6].nom*1.5;
      params[9].min = params[9].nom*0.5;
      params[9].max = params[9].nom*1.5;
      params[10].min = params[10].nom*0.5;
      params[10].max = params[10].nom*1.5;
      params[13].min = params[13].nom*0.5;
      params[13].max = params[13].nom*1.5;
      params[14].min = params[14].nom*0.5;
      params[14].max = params[14].nom*1.5;

      opt.function = &rbi_erf;
      opt.err_fraction = 1.0e-6;
      opt.max_iterations = niter_rbi;
      opt.num_of_criteria = 6;
      weights[0] = weights[3] = 10.0;
      weights[1] = 0.05;
      weights[2] = 8.0;
      weights[4] = 0.5;
      weights[5] = 0.05;

      if (flag)
         if (cg_optimize (opt,params) < 0)
            printf ("ERROR in cg_optimize().\n");
      
      params[6].optimize = FALSE;
      params[9].optimize = FALSE;
      params[10].optimize = FALSE;
      params[13].optimize = FALSE;
      params[14].optimize = FALSE;
      params[29].optimize = FALSE;
      params[30].optimize = FALSE;
      }

   /***************** Plot Data ***********************/
   
   if (!(option_flags & SUPPRESS_GRAPHS))
      {
      printf ("Generating plots.....\n");
      plot_data (fwd_gum_file,rev_gum_file,dc_iv_file,flyback_file,
         fwdg_start,fwdg_stop,revg_start,revg_stop,flystart,flystop);

      // write a postscript output file
      if (!(option_flags & USE_POSTSCRIPT))
         {
         option_flags |= USE_POSTSCRIPT;
         plot_data (fwd_gum_file,rev_gum_file,dc_iv_file,flyback_file,
            fwdg_start,fwdg_stop,revg_start,revg_stop,flystart,flystop);
         }
      }
   
   /************** Write Output Files *****************/
   
   write_output_files (end_file,model_file,dc_iv_file);

   printf ("EEBJT2 Model Fitting Complete!\n\n");
   
   return 0;
   }

/****************************************************************************/
/****************************************************************************/
/*                           SECONDARY FUNCTIONS                            */
/****************************************************************************/
/****************************************************************************/

int get_starting_values (char fname[])
   {
   FILE        *file1;
   char        string[201];
   int         i;
      
   file1 = fopen (fname,"r");
   if (!file1)
      {
      printf ("ERROR: Unable to open starting values file - %s\n",fname);
      return -1;
      }
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      if (!fgets (string,200,file1))
         {
         printf ("ERROR: Incomplete starting values file.\n");
         fclose (file1);
         return -1;
         }
      
      sscanf (string,"%lf%lf%lf%lf%s",&params[i].min,&params[i].nom,&params[i].max,
         &params[i].tol,params[i].name);
      params[i].units[0] = 0;
      params[i].optimize = FALSE;
      
      if (params[i].min > params[i].max)
         {
         printf ("WARNING in parameter \"%s\": MIN > MAX, range reset.\n",params[i].name);
         params[i].max = params[i].min;
         }

      if (params[i].nom < params[i].min)
         params[i].nom = params[i].min;
      else if (params[i].nom > params[i].max)
         params[i].nom = params[i].max;

      if (params[i].tol < 0.0)
         params[i].tol = -params[i].tol;
      }
   fclose (file1);

   /* check parameter ranges for validity */
   
   
    
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int get_iv_data (char fname[], int mode)
   {
   FILE     *file1;
   char     string[201];
   int      i = 0;
   double   rb = params[0].nom;
   double   rc = params[2].nom;
   double   re = params[4].nom;
   
   file1 = fopen (fname,"r");
   if (!file1)
      {
      printf ("Unable to open IV file - %s\n",fname);
      return -1;
      }
   

   while (fgets (string,200,file1))
      {
      if (i >= MAX_IV_PTS)
         {
         printf ("WARNING: Max IV points exceeded.\n");
         break;
         }

      if (string[0] == '!')
         continue;

      if (sscanf (string,"%lf%lf%lf%lf",&vceiv[i],&iceiv[i],&vbeiv[i],&ibeiv[i]) == 4)
         {
         switch (mode)
            {
            case DCIV:
               if (vceiv[i] > max_vce)
                  continue;
               else if (ibeiv[i] < 1.0e-8)
                  continue;

               vceiv[i] -= iceiv[i]*rc + (iceiv[i]+ibeiv[i])*re;
               vbeiv[i] -= ibeiv[i]*rb + (iceiv[i]+ibeiv[i])*re;
               ++i;
               break;
               
            case FWD_GUMMEL:
            case REV_GUMMEL:
            case FLYBACK:
               ++i;
               break;
               
            default:
               printf ("Invalid mode.\n");
               return -1;
            }
         }
      }
   fclose (file1);
 
   return i;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int hot_hbt_extraction (char files[], double fstart, double fstop)
   {
   char    tmp_file_name[100],string[200];
   time_t  dummy;
   FILE    *file_list,*infile;
   int     i,j,found,first;
   double  rb,rc,re,freq,r2;
   double  lb[100],lc[100],le[100],w[100];
   COMPLEX sr[4],z[4];
   POLAR   s[4];

   sprintf (tmp_file_name,"tmpfile.%d",time(&dummy));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string,"ls -1 %s > %s",files,tmp_file_name);
   system (string);

   file_list = fopen (tmp_file_name,"r");
   if (!file_list)
      {
      sprintf (string,"rm -f %s",tmp_file_name);
      system (string);
      return -1;
      }

   i = 0;
   while (fgets(string,100,file_list))
      {
      if (i >= 5)
         {
         printf ("WARNING: too many hot hbt files.\n");
         break;
         }

      string[strlen(string)-1] = 0;
      infile = fopen (string,"r");
      if (!infile)
         continue;

      j = 0;
      found = 0;
      first = 1;
      rb = rc = re = 0.0;
      while (fgets(string,199,infile))
         {
         if (!strncmp(string,"!BIAS",5))
            {
            if (sscanf (string,"!BIAS: VCE = %*f Volts ICE = %*f Amps VBE = %*f Volts IBE = %lf Amps",&ibep[i]) == 1)
               {
               ibep[i] = 1.0/ibep[i];
               found = 1;
               }
            }
         else if (string[0] == '!')
            continue;

         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].m,&s[0].a,&s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
            {
            if (freq < fstart)
               continue;
            else if (freq > fstop)
               break;

            if (j >= 100)
               {
               printf ("WARNING: too many frequency points in range.\n");
               break;
               }

            s2z (PA2CA (s,sr,2,2),z,50.0);
            w[j] = 2.0*PI*freq;

            if (first)
               {
               rb += Creal (Csub(z[0],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
               rc += Creal (Csub(z[3],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
               re += Creal (Cmult(Cadd(z[1],z[2]),Complex(0.5)));
               first = 0;
               }

            lb[j] = Cimag (Csub(z[0],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
            lc[j] = Cimag (Csub(z[3],Cmult(Cadd(z[1],z[2]),Complex(0.5))));
            le[j] = Cimag (Cmult(Cadd(z[1],z[2]),Complex(0.5)));

            ++j;
            }
         }

      if (j < 2)
         {
         printf ("WARNING: too few frequency points in range.\n");
         fclose (infile);
         continue;
         }

      if (!found)
         {
         printf ("WARNING: BIAS line not found.\n");
         fclose (infile);
         continue;
         }

      rb1[i] = rb; // /((double) j);
      rc1[i] = rc; // /((double) j);
      re1[i] = re; // /((double) j);

      linefit_mx0 (w,lb,j,&lb1[i],&r2);
      linefit_mx0 (w,lc,j,&lc1[i],&r2);
      linefit_mx0 (w,le,j,&le1[i],&r2);

      fclose (infile);
      ++i;
      }

   fclose (file_list);
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);

   num_para_pts = i;

   if (num_para_pts < 2)
      {
      printf ("ERROR: too few hot hbt files.\n");
      return -1;
      }

   linefit_mxb (ibep,rb1,num_para_pts,&rb_slope,&params[0].nom,&r2);
   linefit_mxb (ibep,rc1,num_para_pts,&rc_slope,&params[2].nom,&r2);
   linefit_mxb (ibep,re1,num_para_pts,&re_slope,&params[4].nom,&r2);
   linefit_mxb (ibep,lb1,num_para_pts,&lb_slope,&params[1].nom,&r2);
   linefit_mxb (ibep,lc1,num_para_pts,&lc_slope,&params[3].nom,&r2);
   linefit_mxb (ibep,le1,num_para_pts,&le_slope,&params[5].nom,&r2);

   for (i = 0; i < 6; ++i)
      params[i].min = params[i].max = params[i].nom;

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int re_from_flyback (char fname[], double istart, double istop)
   {
   double  v[MAX_IV_PTS],i1[MAX_IV_PTS];
   double  r2;
   int     i,n;

   if ((num_iv_pts = get_iv_data (fname,FLYBACK)) < 1)
      {
      printf ("ERROR: in get_iv_data().\n");
      return -1;
      }

   for (i = 0,n = 0; i < num_iv_pts; ++i)
      {
      if ((ibeiv[i] >= istart) && (ibeiv[i] <= istop))
         {
         v[n] = vceiv[i];
         i1[n] = ibeiv[i];
         ++n;
         }
      }

   if (n < 3)
      {
      printf ("Not enough points for linefit.\n");
      return 1;
      }

   linefit_mxb (i1,v,n,&params[4].nom,&fly_intr,&r2);
   params[4].min = params[4].max = params[4].nom;

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int gummel_fit (char fname[], double vstart, double vstop, int mode)
   {
   double  vb,ib,ic,n1,n2,is1,is2,rd;
   double  v[MAX_IV_PTS],i1[MAX_IV_PTS],i2[MAX_IV_PTS];
   int     i,j;

   if ((num_iv_pts = get_iv_data (fname,mode)) < 1)
      {
      printf ("ERROR: in get_iv_data().\n");
      return -1;
      }

   for (i = 0, j = 0; i < num_iv_pts; ++i)
      {
      if (mode == FWD_GUMMEL)
         {
         vb = vbeiv[i];
         ib = ibeiv[i];
         ic = iceiv[i];
         }
      else if (mode == REV_GUMMEL)
         {
         vb = -vceiv[i];
         ib = ibeiv[i];
         ic = ibeiv[i] - iceiv[i];
         }

      if (vb < vstart)
         continue;
      else if (vb > vstop)
         {
         rc_start_index = i;
         break;
         }

      v[j]  = vb;
      i1[j] = ib;
      i2[j] = ic;
      ++j;
      }

   if (j < 3)
      {
      printf ("ERROR: not enough points in range.\n");
      return -1;
      }

   diode_fit (v,i1,j,&is1,&n1,&rd);
   diode_fit (v,i2,j,&is2,&n2,&rd);

   if (mode == FWD_GUMMEL)
      {
      params[15].nom = params[15].max = params[15].min = is1;   // Ibif
      params[16].nom = params[16].max = params[16].min = n1;    // Nbf
      params[17].nom = params[17].max = params[17].min = is2;   // Isf
      params[18].nom = params[18].max = params[18].min = n2;    // Nf
      }
   else if (mode == REV_GUMMEL)
      {
      params[19].nom = params[19].max = params[19].min = is1;   // Ibir
      params[20].nom = params[20].max = params[20].min = n1;    // Nbr
      params[21].nom = params[21].max = params[21].min = is2;   // Isr
      params[22].nom = params[22].max = params[22].min = n2;    // Nr
      }
   else
      {
      printf ("ERROR: invalid mode.\n");
      return -1;
      }

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int fit_re_from_gummel (char infile[])
   {
   double vb,ib,ic,v;
   double ktq = CHARGE/(temperature*BOLTZ);

   if ((num_iv_pts = get_iv_data (infile,FWD_GUMMEL)) < 1)
      {
      printf ("ERROR: in get_iv_data().\n");
      return -1;
      }

   vb = vbeiv[num_iv_pts-1] - ibeiv[num_iv_pts-1]*params[0].nom;
   ib = ibeiv[num_iv_pts-1];
   ic = iceiv[num_iv_pts-1];

   v = vb - log (ib/params[15].nom + 1.0)*params[16].nom/ktq;

   params[4].nom = params[4].min = params[4].max = v/(ib+ic);

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int extract_capacitance (char files[], double fstart, double fstop, int mode)
   {
   char    tmp_file_name[100],string[200];
   time_t  dummy;
   FILE    *file_list,*infile;
   int     i,j,found,is_zb,zb_done;
   double  c1[100],w[100],cc[100];
   COMPLEX sr[4],z[4],y[4];
   POLAR   s[4];
   double  rb = params[0].nom;
   double  rc = params[2].nom;
   double  re = params[4].nom;
   double  lb = params[1].nom;
   double  lc = params[3].nom;
   double  le = params[5].nom;
   double  vce,ice,vbe,ibe,freq,r2,tmp,cc_ave;

   sprintf (tmp_file_name,"tmpfile.%d",time(&dummy));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string,"ls -1 %s > %s",files,tmp_file_name);
   system (string);

   file_list = fopen (tmp_file_name,"r");
   if (!file_list)
      {
      sprintf (string,"rm -f %s",tmp_file_name);
      system (string);
      return -1;
      }

   i = 0;
   cc_ave = 0.0;
   zb_done = 0;
   while (fgets(string,100,file_list))
      {
      if (i >= MAX_CAP_PTS)
         {
         printf ("WARNING: too many capacitance files.\n");
         break;
         }

      string[strlen(string)-1] = 0;
      infile = fopen (string,"r");
      if (!infile)
         continue;

      j = 0;
      found = 0;
      is_zb = 0;
      while (fgets(string,199,infile))
         {
         if (!strncmp(string,"!BIAS",5))
            {
            if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&vce,&ice,&vbe,&ibe) == 4)
               {
               found = 1;
               if (mode == EXTRACT_CBC)
                  {
                  vcbc[i] = (vbe - rb*ibe) - (vce - rc*ice);
                  if (fabs(vbe - vce) < 0.05)
                     is_zb = 1;
                  }
               else if (mode == EXTRACT_CBE)
                  {
                  vcbe[i] = vbe - (ibe+ice)*re - ibe*rb;
                  if (fabs(vbe) < 0.05)
                     is_zb = 1;
                  }
               }
            }
         else if (string[0] == '!')
            continue;

         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].m,&s[0].a,&s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
            {
            if (freq < fstart)
               continue;
            else if (freq > fstop)
               break;

            if (j >= 100)
               {
               printf ("WARNING: too many frequency points in range.\n");
               break;
               }

            s2z (PA2CA (s,sr,2,2),z,50.0);
            w[j] = 2.0*PI*freq;

            z[0] = Csubx (3,z[0],Complex(rb+rc),Cnum(0.0,w[j]*(lb+lc)));
            z[1] = Csubx (3,z[1],Complex(re),Cnum(0.0,w[j]*le));
            z[2] = Csubx (3,z[2],Complex(re),Cnum(0.0,w[j]*le));
            z[3] = Csubx (3,z[3],Complex(rb+rc),Cnum(0.0,w[j]*(lb+lc)));

            z2y (z,y);

            if (mode == EXTRACT_CBE)
               {
               c1[j] = Cimag (Cadd(y[0],Cmult(Cadd(y[1],y[2]),Complex(0.5))));
               cc[j] = Cimag (Cadd(y[3],Cmult(Cadd(y[1],y[2]),Complex(0.5))));
               ++j;
               }
            else if (mode == EXTRACT_CBC)
               {
               c1[j] = -Cimag (Cmult(Cadd(y[1],y[2]),Complex(0.5)));
               cc[j] = Cimag (Cadd(y[3],Cmult(Cadd(y[1],y[2]),Complex(0.5))));
               ++j;
               }
            }
         }

      if (j < 2)
         {
         printf ("WARNING: too few frequency points in range.\n");
         fclose (infile);
         continue;
         }

      if (!found)
         {
         printf ("WARNING: BIAS line not found.\n");
         fclose (infile);
         continue;
         }

      if (mode == EXTRACT_CBE)
         {
         linefit_mx0 (w,c1,j,&cbem[i],&r2);
         linefit_mx0 (w,cc,j,&tmp,&r2);
         cc_ave += tmp;
         
         if (is_zb)
            {
            params[10].nom = params[10].min = params[10].max = cje0_orig = cbem[i];
            zb_done = 1;
            }
         }
      else if (mode == EXTRACT_CBC)
         {
         linefit_mx0 (w,c1,j,&cbcm[i],&r2);
         linefit_mx0 (w,cc,j,&tmp,&r2);
         cc_ave += tmp;

         if (is_zb)
            {
            params[6].nom = params[6].min = params[6].max = cjc0_orig = cbcm[i];
            zb_done = 1;
            }
         }

      fclose (infile);
      ++i;
      }

   if (mode == EXTRACT_CBE)
      {
      num_cbe_pts = i;
      for (i = 0; i < (num_cbe_pts-1); ++i)
         {
         for (j = i; j < num_cbe_pts; ++j)
            {
            if (vcbe[i] > vcbe[j])
               {
               tmp = vcbe[i];
               vcbe[i] = vcbe[j];
               vcbe[j] = tmp;
               
               tmp = cbem[i];
               cbem[i] = cbem[j];
               cbem[j] = tmp;
               }
            }
         }
      cce1 = cc_ave/((double) num_cbe_pts);
      }
   else if (mode == EXTRACT_CBC)
      {
      num_cbc_pts = i;
      for (i = 0; i < (num_cbc_pts-1); ++i)
         {
         for (j = i; j < num_cbc_pts; ++j)
            {
            if (vcbc[i] > vcbc[j])
               {
               tmp = vcbc[i];
               vcbc[i] = vcbc[j];
               vcbc[j] = tmp;
               
               tmp = cbcm[i];
               cbcm[i] = cbcm[j];
               cbcm[j] = tmp;
               }
            }
         }
      cce2 = cc_ave/((double) num_cbc_pts);
      }
   
   fclose (file_list);
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);

   if (!zb_done)
      {
      printf ("ERROR: no zero-bias file found.\n");
      return 1;
      }

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int extract_tf (char files[], double imin, double imax)
   {
   char    tmp_file_name[100],string[200];
   time_t  dummy;
   FILE    *file_list,*infile;
   int     i,found,good_ft;
   COMPLEX sr[4],h[4];
   POLAR   s[4];
   double  r2,freq,ice,ibe,vce,vbe,v,cbe,rbe;

#define ft_freq   2.0e9

   sprintf (tmp_file_name,"tmpfile.%d",time(&dummy));
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);
   sprintf (string,"ls -1 %s > %s",files,tmp_file_name);
   system (string);

   file_list = fopen (tmp_file_name,"r");
   if (!file_list)
      {
      sprintf (string,"rm -f %s",tmp_file_name);
      system (string);
      return -1;
      }

   i = 0;
   while (fgets(string,100,file_list))
      {
      if (i >= MAX_TF_PTS)
         {
         printf ("WARNING: too many forward transit files.\n");
         break;
         }

      string[strlen(string)-1] = 0;
      infile = fopen (string,"r");
      if (!infile)
         continue;

      found = good_ft = 0;
      while (fgets(string,199,infile))
         {
         if (!strncmp(string,"!BIAS",5))
            {
            if (sscanf (string,"!BIAS: VCE = %lf Volts ICE = %lf Amps VBE = %lf Volts IBE = %lf Amps",&vce,&ice,&vbe,&ibe) == 4)
               {
               if ((ice < imin) || (ice > imax))
                  break;
               found = 1;
               icetf[i] = 1.0/ice;
               v = vbe - ibe*params[0].nom - (ice+ibe)*params[4].nom;
               cbe = junction_cap (v,params[11].nom,params[12].nom,params[10].nom,0.0);
               rbe = v/ibe;
               }
            }
         else if (string[0] == '!')
            continue;

         if (sscanf (string,"%lf%lf%lf%lf%lf%lf%lf%lf%lf",&freq,&s[0].m,&s[0].a,&s[2].m,&s[2].a,&s[1].m,&s[1].a,&s[3].m,&s[3].a) == 9)
            {
            if (freq >= ft_freq)
               {
               s2h (PA2CA (s,sr,2,2),h,50.0);
               tfm[i] = 1.0/(2.0*PI*freq*Cmag(h[2]));
               good_ft = 1;
               break;
               }
            }
         }

      if (!found || !good_ft)
         {
         fclose (infile);
         continue;
         }

      fclose (infile);
      ++i;
      }

   num_tf_pts = i;

   fclose (file_list);
   sprintf (string,"rm -f %s",tmp_file_name);
   system (string);

   if (num_tf_pts < 3)
      {
      printf ("Not enough points for Tf calculation.\n");
      return -1;
      }

   linefit_mxb (icetf,tfm,num_tf_pts,&tf_slope,&tf_intr,&r2);
   params[14].min = params[14].max = params[14].nom = tf_intr;

   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

int plot_data (char *fwdgum_file, char *revgum_file, char *iv_file, char *flyback_file,
               double fwdg_start, double fwdg_stop, double revg_start, double revg_stop,
               double fly_start, double fly_stop)
   {
   jPLOT_ITEM      *plot1,*s11p,*s22p,*s21p,*s12p;
   int             i,j,n,pdevice;
   char            pname[100],string[200],head[400];
   double          p[NUM_PARAMS];
   double          x1data[MAX_IV_PTS];
   double          x2data[MAX_IV_PTS];
   double          y1data[MAX_IV_PTS];
   double          y2data[MAX_IV_PTS];
   double          y3data[MAX_IV_PTS];
   double          y4data[MAX_IV_PTS];
   double          s11d[4][MAX_S_PTS];
   double          s12d[4][MAX_S_PTS];
   double          s21d[4][MAX_S_PTS];
   double          s22d[4][MAX_S_PTS];
   double          freq[MAX_S_PTS];
   double          line1[10];
   double          vbe;
   static char     *legend_t[] = {"Modeled","Measured"};
   static char     *legend_t3[] = {"Modeled Mag","Measured Mag","Modeled Phase","Measured Phase"};
   static int      legend_l1[] = {LT_SOLID,LT_DASHED};
   static int      legend_l2[] = {LT_SOLID,PNT_CIRCLE};
   static int      legend_l3[] = {LT_SOLID,LT_DASHED,LT_SOLID,LT_DASHED};
   static int      legend_w1[] = {1,1};
   static int      legend_w2[] = {1,2};
   static int      legend_w3[] = {1,1,1,1};
   static int      legend_c[] = {CLR_RED,CLR_BLUE};
   static int      legend_c3[] = {CLR_RED,CLR_BLUE,CLR_ORANGE,CLR_GREEN};
   jHANDLE         txt1,legend1,header;
   jPLOT_ATTRIBS   attribs1;
   FILE            *infile;
   POLAR           sp[4],sm1[4];
   S_2PORT         sm;

   for (i = 0; i < NUM_PARAMS; ++i)
      p[i] = params[i].nom;
      
   pdevice = X_WINDOWS;
   pname[0] = 0;
   if (option_flags & USE_POSTSCRIPT)
      {
      pdevice = POSTSCRIPT;
      strcpy (pname,"hbt.ps");
      }
   else if (option_flags & USE_METAFILE)
      {
      pdevice = METAFILE;
      strcpy (pname,"hbt.wmf");
      }
   
   if (!open_graphics_device (pdevice,pname))
      {
      printf ("open_graphics_device() failed.\n");
      return -1;
      }

   head[0] = 0;
   infile = fopen (iv_file,"r");
   while (fgets(string,199,infile))
      {
      if (!strncmp(string,"!FILE",4))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!MASK",4))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!WAFER",5))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!DEVICE",7))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!EMITTER AREA",13))
         strcat(head,&string[1]);
      else if (!strncmp(string,"!TEMP",5))
         strcat(head,&string[1]);
      else if (string[0] != '!')
         break;
      }
   fclose (infile);

   plot1 = create_plot_item (SingleY,1.75,1.25,6.0,5.0);
   plot1->attribs.title_offset = 0.3;
   header = add_text (head,4.75,7.8,FNT_COURIER,12,0.0,CENTER_JUSTIFY,CLR_BLACK,0);

   /************ plot Parasitics *************/

   if (!(option_flags & SKIP_PARASITICS))
      {
      /**** Resistances ****/
      
      for (i = 0,j = 0; i < num_para_pts; ++i, j += 3)
         {
         x1data[j]   = x1data[j+1] = x1data[j+2] = ibep[i];
         y1data[j]   = rb1[i];
         y1data[j+1] = rc1[i];
         y1data[j+2] = re1[i];
         }
      
      attach_y1data (plot1,x1data,y1data,num_para_pts*3,PNT_CIRCLE,2,CLR_BLUE);
      
      // create fit lines....
      x2data[0] = x2data[2] = x2data[4] = 0.0;
      x2data[1] = x2data[3] = x2data[5] = ibep[0];
      line1[0] = params[0].nom;
      line1[1] = params[0].nom + rb_slope*ibep[0];
      line1[2] = params[2].nom;
      line1[3] = params[2].nom + rc_slope*ibep[0];
      line1[4] = ree_orig;
      line1[5] = ree_orig + re_slope*ibep[0];
      
      attach_y1data (plot1,x2data,line1,6,LT_SOLID,1,CLR_RED);
      
      legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l2,legend_w2,legend_c);
      set_axis_labels (plot1,"1/Ibe (1/amp)","Resistance (ohms)","","Hot HBT Resistances");
      
      sprintf (string,"Rb = %.3f ohms\nRc = %.3f ohms\nRe = %.3f ohms",params[0].nom,params[2].nom,ree_orig);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      detach_data (plot1);
      
      /**** Inductances ****/
      
      for (i = 0,j = 0; i < num_para_pts; ++i, j += 3)
         {
         x1data[j]   = x1data[j+1] = x1data[j+2] = ibep[i];
         y1data[j]   = lb1[i]*1.0e12;
         y1data[j+1] = lc1[i]*1.0e12;
         y1data[j+2] = le1[i]*1.0e12;
         }
      
      attach_y1data (plot1,x1data,y1data,num_para_pts*3,PNT_CIRCLE,2,CLR_BLUE);
      
      // create fit lines....
      x2data[0] = x2data[2] = x2data[4] = 0.0;
      x2data[1] = x2data[3] = x2data[5] = ibep[0];
      line1[0] = params[1].nom*1.0e12;
      line1[1] = (params[1].nom + lb_slope*ibep[0])*1.0e12;
      line1[2] = params[3].nom*1.0e12;
      line1[3] = (params[3].nom + lc_slope*ibep[0])*1.0e12;
      line1[4] = lee_orig*1.0e12;
      line1[5] = (lee_orig + le_slope*ibep[0])*1.0e12;
      
      attach_y1data (plot1,x2data,line1,6,LT_SOLID,1,CLR_RED);
      
      set_axis_labels (plot1,"1/Ibe (1/amp)","Inductance (pF)","","Hot HBT Inductances");
      
      sprintf (string,"Lb = %.3f pH\nLc = %.3f pH\nLe = %.3f pH",params[1].nom*1.0e12,
         params[3].nom*1.0e12,lee_orig*1.0e12);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      remove_user_item (legend1);
      detach_data (plot1);

      /**** Flyback ****/

      n = get_iv_data (flyback_file,FLYBACK);
      for (i = 0; i < n; ++i)
         {
         x1data[i] = ibeiv[i]*1.0e3;
         y1data[i] = vceiv[i];
         }
      
      attach_y1data (plot1,x1data,y1data,n,LT_DASHED,1,CLR_BLUE);
      
      // create fit lines
      x2data[0] = fly_start*1.0e3;
      x2data[1] = fly_stop*1.0e3;
      line1[0]  = params[4].nom*fly_start + fly_intr;
      line1[1]  = params[4].nom*fly_stop + fly_intr;
      
      attach_y1data (plot1,x2data,line1,2,LT_SOLID,1,CLR_RED);

      legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l1,legend_w1,legend_c);
      set_axis_labels (plot1,"Ibe (milliamps)","Vce (volts)","","Emitter Resistance Flyback");
      
      sprintf (string,"Re = %.3f",params[4].nom);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      remove_user_item (legend1);
      detach_data (plot1);
      }

   /************ plot Gummel Curves *************/
   
   if (!(option_flags & SKIP_GUMMEL))
      {
      /**** Forward ****/

      n = get_iv_data (fwdgum_file,FWD_GUMMEL);
      for (i = 0; i < n; ++i)
         {
         x1data[i] = vbeiv[i];
         y1data[i] = fabs (ibeiv[i]);
         y2data[i] = fabs (iceiv[i]);
         }
      
      attach_y1data (plot1,x1data,y1data,n,LT_DASHED,1,CLR_BLUE);
      attach_y1data (plot1,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);
      
      // create fit lines
      x2data[0] = fwdg_start;
      x2data[1] = fwdg_stop;
      y3data[0] = params[15].nom*exp(fwdg_start*CHARGE/(BOLTZ*temperature*params[16].nom));
      y3data[1] = params[15].nom*exp(fwdg_stop*CHARGE/(BOLTZ*temperature*params[16].nom));
      y4data[0] = params[17].nom*exp(fwdg_start*CHARGE/(BOLTZ*temperature*params[18].nom));
      y4data[1] = params[17].nom*exp(fwdg_stop*CHARGE/(BOLTZ*temperature*params[18].nom));

      attach_y1data (plot1,x2data,y3data,2,LT_SOLID,1,CLR_RED);
      attach_y1data (plot1,x2data,y4data,2,LT_SOLID,1,CLR_RED);

      legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l1,legend_w1,legend_c);
      set_axis_labels (plot1,"Vbe (volts)","Ibe/Ice (amps)","","Forward Gummel Curves");
      set_axis_scaling (plot1,LogY1);
      
      sprintf (string,"Ibif = %.3e\nNbf  = %.2f\nIsf  = %.3e\nNf   = %.2f",
         params[15].nom,params[16].nom,params[17].nom,params[18].nom);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      detach_data (plot1);
      
      /**** Reverse ****/
      
      n = get_iv_data (revgum_file,REV_GUMMEL);
      for (i = 0; i < n; ++i)
         {
         x1data[i] = -vceiv[i] + params[0].nom*ibeiv[i];
         y1data[i] = fabs (ibeiv[i]);
         y2data[i] = fabs (ibeiv[i] - iceiv[i]);
         }
      
      attach_y1data (plot1,x1data,y1data,n,LT_DASHED,1,CLR_BLUE);
      attach_y1data (plot1,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);
      
      // create fit lines
      x2data[0] = revg_start;
      x2data[1] = revg_stop;
      line1[0]  = params[19].nom*exp(revg_start*CHARGE/(BOLTZ*temperature*params[20].nom));
      line1[1]  = params[19].nom*exp(revg_stop*CHARGE/(BOLTZ*temperature*params[20].nom));
      x2data[2] = revg_start;
      x2data[3] = revg_stop;
      line1[2]  = params[21].nom*exp(revg_start*CHARGE/(BOLTZ*temperature*params[22].nom));
      line1[3]  = params[21].nom*exp(revg_stop*CHARGE/(BOLTZ*temperature*params[22].nom));
      
      attach_y1data (plot1,x2data,line1,4,LT_SOLID,1,CLR_RED);
      
      set_axis_labels (plot1,"Vbc (volts)","Ibc/Iec (amps)","","Reverse Gummel Curves");
      
      sprintf (string,"Ibir = %.3e\nNbr  = %.2f\nIsr  = %.3e\nNr   = %.2f",params[19].nom,
         params[20].nom,params[21].nom,params[22].nom);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      remove_user_item (legend1);
      detach_data (plot1);
      }

   /************ plot Capacitances ***************/

   if (!(option_flags & SKIP_CAPACITANCE))
      {
      /**** Cbc ****/
      
      for (i = 0; i < num_cbc_pts; ++i)
         {
         x1data[i] = vcbc[i];
         y1data[i] = cbcm[i]*1.0e12;
         y2data[i] = junction_cap (vcbc[i],params[7].nom,params[8].nom,cjc0_orig,0.0)*1.0e12;
         }
      
      attach_y1data (plot1,x1data,y1data,num_cbc_pts,LT_DASHED,1,CLR_BLUE);
      attach_y1data (plot1,x1data,y2data,num_cbc_pts,LT_SOLID,1,CLR_RED);
      
      legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l1,legend_w1,legend_c);
      set_axis_labels (plot1,"Vbc (volts)","Cbc (pF)","","Base-Collector Capacitance");
      set_axis_scaling (plot1,0);
      
      sprintf (string,"Cjc0 = %.3e\nVjc  = %.3f\nMjc  = %.2f\nCof1 = %.3e",params[6].nom,
         params[7].nom,params[8].nom,params[9].nom);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      detach_data (plot1);   
      
      /**** Cbe ****/
      
      for (i = 0; i < num_cbe_pts; ++i)
         {
         x1data[i] = vcbe[i];
         y1data[i] = cbem[i]*1.0e12;
         y2data[i] = junction_cap (vcbe[i],params[11].nom,params[12].nom,cje0_orig,0.0)*1.0e12;
         }
      
      attach_y1data (plot1,x1data,y1data,num_cbe_pts,LT_DASHED,1,CLR_BLUE);
      attach_y1data (plot1,x1data,y2data,num_cbe_pts,LT_SOLID,1,CLR_RED);
      
      set_axis_labels (plot1,"Vbe (volts)","Cbe (pF)","","Base-Emitter Capacitance");
      
      sprintf (string,"Cje0 = %.3e\nVje  = %.3f\nMje  = %.2f\nCof2 = %.3e",params[10].nom,
         params[11].nom,params[12].nom,params[13].nom);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (txt1);
      remove_user_item (legend1);
      detach_data (plot1);
      }

   /************ plot Tf ***********************/
   
   if (!(option_flags & SKIP_TF))
      {
      
      for (i = 0; i < num_tf_pts; ++i)
         {
         x1data[i] = icetf[i];
         y1data[i] = tfm[i]*1.0e12;
         }
      
      attach_y1data (plot1,x1data,y1data,num_tf_pts,PNT_CIRCLE,2,CLR_BLUE);
      
      // create fit line
      x2data[0] = 0.0;
      x2data[1] = icetf[0];
      line1[0]  = tf_intr*1.0e12;
      line1[1]  = (tf_intr + tf_slope*icetf[0])*1.0e12;
      
      attach_y1data (plot1,x2data,line1,2,LT_SOLID,1,CLR_RED);
      
      legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l2,legend_w2,legend_c);
      set_axis_labels (plot1,"1/Ice (1/amp)","1/(2*Pi*Ft) (pS)","","Forward Transit Time");
      set_axis_scaling (plot1,0);
      
      sprintf (string,"Tf = %.2f pS",tf_intr*1.0e12);
      txt1 = add_text (string,8.0,5.0,FNT_COURIER,12,0.0,LEFT_JUSTIFY,CLR_BLACK,0);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }   
      
      remove_user_item (legend1);
      remove_user_item (txt1);
      detach_data (plot1);
      }

   /************ plot IV Curves ****************/

   if (!(option_flags & SKIP_DCIV))
      {      
      n = get_iv_data (iv_file,DCIV);
      
      for (i = 0; i < n; ++i)
         {
         x1data[i] = vceiv[i];
         y1data[i] = eebjt2_iv_model (p,ibeiv[i],vceiv[i],vbeiv[i],&vbe)*1.0e3;
         y2data[i] = iceiv[i]*1.0e3;
         }
      
      attach_y1data (plot1,x1data,y1data,n,LT_SOLID,1,CLR_RED);
      attach_y1data (plot1,x1data,y2data,n,LT_DASHED,1,CLR_BLUE);
      
      legend1 = add_legend (2,8.0,6.0,legend_t,FNT_COURIER,12,legend_l1,legend_w1,legend_c);
      set_axis_labels (plot1,"Vce (volts)","Ice (milliamps)","","DC I-V Curves");
      set_axis_scaling (plot1,POSITIVE_X | POSITIVE_Y1);
      
      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }

      remove_user_item (legend1);
      }

   /************ plot S-parameters ***************/

   if (!(option_flags & SKIP_RBI))
      {
      deactivate_plot_item (plot1);
      remove_user_item (header);

      s11p = create_plot_item (DoubleY,1.25,5.00,3.0,2.5);
      s12p = create_plot_item (DoubleY,6.75,5.00,3.0,2.5);
      s21p = create_plot_item (DoubleY,1.25,1.00,3.0,2.5);
      s22p = create_plot_item (DoubleY,6.75,1.00,3.0,2.5);

      for (i = 0, j = 0; i < num_s_pts; ++i)
         {
         if ((sparams[i].freq >= sp_minf) && (sparams[i].freq <= sp_maxf))
            {
            calculate_eebjt2_s (p,spvbe,spvce,sparams[i].freq,&sm);
            CA2PA (sparams[i].s,sp,2,2);
            CA2PA (sm.s,sm1,2,2);
            freq[j]    = sparams[i].freq*1.0e-9;
            s11d[0][j] = sp[0].m;
            s11d[1][j] = sm1[0].m;
            s11d[2][j] = sp[0].a;
            s11d[3][j] = sm1[0].a;
            s12d[0][j] = sp[1].m;
            s12d[1][j] = sm1[1].m;
            s12d[2][j] = sp[1].a;
            s12d[3][j] = sm1[1].a;
            s21d[0][j] = sp[2].m;
            s21d[1][j] = sm1[2].m;
            s21d[2][j] = sp[2].a;
            s21d[3][j] = sm1[2].a;
            s22d[0][j] = sp[3].m;
            s22d[1][j] = sm1[3].m;
            s22d[2][j] = sp[3].a;
            s22d[3][j] = sm1[3].a;
            ++j;
            }
         }

      attach_data (s11p,XY_DATA,freq,s11d[0],s11d[2],j,LT_DASHED,1,CLR_BLUE,LT_DASHED,1,CLR_GREEN);
      attach_data (s11p,XY_DATA,freq,s11d[1],s11d[3],j,LT_SOLID,1,CLR_RED,LT_SOLID,1,CLR_ORANGE);
      attach_data (s12p,XY_DATA,freq,s12d[0],s12d[2],j,LT_DASHED,1,CLR_BLUE,LT_DASHED,1,CLR_GREEN);
      attach_data (s12p,XY_DATA,freq,s12d[1],s12d[3],j,LT_SOLID,1,CLR_RED,LT_SOLID,1,CLR_ORANGE);
      attach_data (s21p,XY_DATA,freq,s21d[0],s21d[2],j,LT_DASHED,1,CLR_BLUE,LT_DASHED,1,CLR_GREEN);
      attach_data (s21p,XY_DATA,freq,s21d[1],s21d[3],j,LT_SOLID,1,CLR_RED,LT_SOLID,1,CLR_ORANGE);
      attach_data (s22p,XY_DATA,freq,s22d[0],s22d[2],j,LT_DASHED,1,CLR_BLUE,LT_DASHED,1,CLR_GREEN);
      attach_data (s22p,XY_DATA,freq,s22d[1],s22d[3],j,LT_SOLID,1,CLR_RED,LT_SOLID,1,CLR_ORANGE);

      set_axis_labels (s11p,"Frequency (GHz)","S11 Magnitude","S11 Phase","S11");
      set_axis_labels (s12p,"Frequency (GHz)","S12 Magnitude","S12 Phase","S12");
      set_axis_labels (s21p,"Frequency (GHz)","S21 Magnitude","S21 Phase","S21");
      set_axis_labels (s22p,"Frequency (GHz)","S22 Magnitude","S22 Phase","S22");

      attribs1.xlabel_offset = 0.3;
      attribs1.ylabel_offset = 0.55;
      attribs1.title_offset  = 0.3;

      set_plot_item_attributes (s11p,&attribs1,JPA_LABELOFFSETS);
      set_plot_item_attributes (s12p,&attribs1,JPA_LABELOFFSETS);
      set_plot_item_attributes (s21p,&attribs1,JPA_LABELOFFSETS);
      set_plot_item_attributes (s22p,&attribs1,JPA_LABELOFFSETS);

      legend1 = add_legend (4,4.75,4.5,legend_t3,FNT_COURIER,12,legend_l3,legend_w3,legend_c3);

      if (!draw_page ())
         {
         close_graphics_device ();
         return -1;
         }
      }

   close_graphics_device ();
   
   return 0;
   }

/*******************************************************************************************/
/*******************************************************************************************/

void write_output_files (char *end_file, char *mod_file, char *head_file)
   {
   FILE       *infile,*outfile;
   int        i = 0,err = 0;
   char       string[201];

   outfile = fopen (mod_file,"w+");
   infile  = fopen (head_file,"r");

   // write the header
   while (++i < 31)
      {
      if (!fgets (string,200,infile))
         break;
         
      if (!strncmp (string,"!COMMENTS",9))
         {
         fprintf (outfile,"!\n");
         while (!strstr (string,"DC BJT PARAMETERS"))
            {
            if (!fgets (string,200,infile))
               {
               err = 1;
               break;
               }
            }
         }
      
      if (err)
         break;

      if (!strncmp (string,"!Vb_beo",7))
         {
         fprintf (outfile,"%s",string);
         break;
         }
      
      fprintf (outfile,"%s",string);
      }
   if (fgets (string,200,infile))
      fprintf (outfile,"%s",string);
   fclose (infile);

   // write the model parameters
   fprintf (outfile,"!\nBEGIN BDTA\n");
   fprintf (outfile,"%%     %-13s%-13s\n","KMOD","KVER");
   fprintf (outfile,"     %-13d%-13d\n",402,1100);
   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Cjc","Vjc","Mjc","Cof1","Cje","Vje");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      params[6].nom,params[7].nom,params[8].nom,params[9].nom,params[10].nom,params[11].nom);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Mje","Cof2","Tf","Ibif","Nbf","Isf");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      params[12].nom,params[13].nom,params[14].nom,params[15].nom,params[16].nom,params[17].nom);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Nf","Ibir","Nbr","Isr","Nr","Ikf");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      params[18].nom,params[19].nom,params[20].nom,params[21].nom,params[22].nom,params[23].nom);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Isc","Nc","Ise","Ne","Ikr","Tamb");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      params[24].nom,params[25].nom,params[26].nom,params[27].nom,params[28].nom,temperature-273.15);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Var","Vaf","Tr","Fc","Xtf","Vtf");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      0.0,0.0,0.0,0.9,0.0,0.0);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Itf","Lb","Lc","Le","Cxbc","Cxbe");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      0.0,0.0,0.0,0.0,0.0,0.0);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s\n",
      "Cxce","Rb","Rc","Re");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e\n",
      0.0,0.0,0.0,0.0);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s%-13s%-13s\n",
      "Rbb","Rcc","Ree","B1","B2","Lee");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e%-13.4e%-13.4e\n",
      params[0].nom,params[2].nom,params[4].nom,params[1].nom,params[3].nom,params[5].nom);

   fprintf (outfile,"%%     %-13s%-13s%-13s%-13s\n",
      "Rbi","Cc","C1","Area");
   fprintf (outfile,"     %-13.4e%-13.4e%-13.4e%-13.4e\n",
      params[29].nom,(cce1 + cce2)*0.5,params[30].nom,area);

   fprintf (outfile,"END BDTA\n");

   fclose (outfile);
   
   // write the finishing values file  
   outfile = fopen (end_file,"w+");
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (outfile,"%12.4e %12.4e %12.4e %12.4e %s\n",params[i].min,params[i].nom,params[i].max,
         params[i].tol,params[i].name);
      }
   fclose (outfile);
   }

/*******************************************************************************************/
/*******************************************************************************************/

void calculate_eebjt2_s (double *p, double vbe, double vce, double freq, S_2PORT *sp)
   {
   COMPLEX y[10][10],x;
   double  vbc = vbe - vce;
   double  cbc,cbe,cde;
   double  gbc,gbe;
   double  gmbc,gmbe;
   double  ktq = CHARGE/(temperature*BOLTZ);
   double  isf = p[17];
   double  ikf = p[23];
   double  nf  = p[18];
   double  isr = p[21];
   double  ikr = p[28];
   double  nr  = p[22];
   int     i,j;
   static COMPLEX zero = {0.0,0.0};
   double FwdExp,RevExp,FwdDeriv,RevDeriv;
   double I_Fwd,I_Rev,InvFwdBetaKnee,InvRevBetaKnee;
   double Q2,InvQb,T1,T2,T3,T4,dInvQb_dVbe,dInvQb_dVbc;
   double ExpDiff,dQde_dVbc;

   for (i = 0; i < 10; ++i)
      for (j = 0; j < 10; ++j)
         y[i][j] = zero;

   addy_inductance (p[1],freq,1,3,(COMPLEX*)y,10);
   addy_inductance (p[3],freq,2,5,(COMPLEX*)y,10);
   addy_inductance (p[5],freq,6,0,(COMPLEX*)y,10);

   addy_capacitance (p[30],freq,1,0,(COMPLEX*)y,10);   // c1
   addy_capacitance (p[13],freq,3,6,(COMPLEX*)y,10);
   addy_capacitance (p[9],freq,4,8,(COMPLEX*)y,10);
   addy_capacitance ((cce1 + cce2)*0.5,freq,5,6,(COMPLEX*)y,10);

   addy_resistance (p[0],3,4,(COMPLEX*)y,10);
   addy_resistance (p[2],5,8,(COMPLEX*)y,10);
   addy_resistance (p[4],6,9,(COMPLEX*)y,10);
   addy_resistance (p[29],4,7,(COMPLEX*)y,10);   // rbi

   // calculate the non-linear components

   cbc = junction_cap (vbc,p[7],p[8],p[6],0.0);
   cbe = junction_cap (vbe,p[11],p[12],p[10],0.0);
   addy_capacitance (cbc,freq,7,8,(COMPLEX*)y,10);
   addy_capacitance (cbe,freq,7,9,(COMPLEX*)y,10);

   gbc = eebjt2_gbx (p[19],p[20],p[24],p[25],vbc,temperature);
   gbe = eebjt2_gbx (p[15],p[16],p[26],p[27],vbe,temperature);
   addy_conductance (gbc,7,8,(COMPLEX*)y,10);
   addy_conductance (gbe,7,9,(COMPLEX*)y,10);
   
   // calculate currents and conductances

   FwdExp   = p[17] * exp (vbe * ktq);
   FwdDeriv = FwdExp * ktq;
   I_Fwd    = FwdExp - p[17];

   RevExp   = p[21] * exp (vbc * ktq);
   RevDeriv = RevExp * ktq;
   I_Rev    = RevExp - p[21];

   InvQb = 1.0;
   dInvQb_dVbe = 0.0;
   dInvQb_dVbc = 0.0;
   
   if (p[23] > 0.0)
      InvFwdBetaKnee = 1.0 / p[23];
   else
      InvFwdBetaKnee = 0.0;

   if (p[28] > 0.0)
      InvRevBetaKnee = 1.0 / p[28];
   else
      InvRevBetaKnee = 0.0;

   Q2 = I_Fwd * InvFwdBetaKnee + I_Rev * InvRevBetaKnee;
   T1 = 1.0 + 4.0 * Q2;
   if ((T1 > 0.0) && (Q2 != 0.0))
      {
      T2 = sqrt(T1);
      T3 = 2.0 / (1.0 + T2);
      T4 = (2.0 * InvQb) / ((1.0 + 2.0 * Q2) * T2 + T1);
      dInvQb_dVbe = T3 * dInvQb_dVbe - InvFwdBetaKnee * T4 * FwdDeriv;
      dInvQb_dVbc = T3 * dInvQb_dVbc - InvRevBetaKnee * T4 * RevDeriv;
      InvQb *= T3;
      }
   
   ExpDiff = FwdExp - RevExp + p[21] - p[17];
      
   gmbe = FwdDeriv * InvQb + dInvQb_dVbe * ExpDiff;
   gmbc = dInvQb_dVbc * ExpDiff - RevDeriv * InvQb;

   addy_delayed_vccs (gmbc,0.0,freq,7,8,8,9,(COMPLEX*)y,10);
   addy_delayed_vccs (gmbe,0.0,freq,7,9,8,9,(COMPLEX*)y,10);

   // add forward diffusion capacitance

   cde = p[14] * (FwdDeriv * InvQb + I_Fwd * dInvQb_dVbe);
   addy_capacitance (cde,freq,7,9,(COMPLEX*)y,10);

   dQde_dVbc = I_Fwd * p[14] * dInvQb_dVbc;
   x.r = 0.0;
   x.i = freq*2.0*PI * dQde_dVbc;
   add_yvccs (x,7,8,7,9,(COMPLEX*)y,10);
   
   // now solve for [S]

   solve_y_for_2port_s ((COMPLEX*)y,sp->s,10);

   // find K and MAG and fill the S_2PORT structure

   k_mag (sp->s,&sp->k,&sp->MAG,&sp->b);
   sp->freq = freq;
   }

/****************************************************************************/
/****************************************************************************/
/*                       OPTIMIZATION ERROR FUNCTIONS                       */
/****************************************************************************/
/****************************************************************************/

double *cbc_erf (double *p)
   {
   int           i;
   double        cap,factor;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_cbc_pts; ++i)
      {
      factor = cbcm[0]/cbcm[i];
      cap = junction_cap (vcbc[i],p[7],p[8],p[6],0.0);
      error += (cap-cbcm[i])*(cap-cbcm[i])*factor*factor*1.0e24;
      }
   
   error /= ((double) num_cbc_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *cbe_erf (double *p)
   {
   int           i;
   double        cap,factor;
   static double error;
   
   error = 0.0;
   for (i = 0; i < num_cbe_pts; ++i)
      {
      factor = cbem[0]/cbem[i];
      cap = junction_cap (vcbe[i],p[11],p[12],p[10],0.0);
      error += (cap-cbem[i])*(cap-cbem[i])*factor*factor*1.0e24;
      }
   
   error /= ((double) num_cbe_pts);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *ice_erf (double *p)
   {
   int           i,j;
   double        ice,vbe;
   static double error;
   
   j = 0;
   error = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      if (vceiv[i] > 1.5)
         continue;
      ice = eebjt2_iv_model (p,ibeiv[i],vceiv[i],vbeiv[i],&vbe);
      error += (ice-iceiv[i])*(ice-iceiv[i])*1.0e6;
      ++j;
      }
      
   error /= ((double) j);
   
   return &error;
   }

/*******************************************************************************************/
/*******************************************************************************************/

double *rbi_erf (double *p)
   {
   int           i,n;
   S_2PORT       sp;
   static double error[6];

   error[0] = error[1] = error[2] = error[3] = error[4] = error[5] = 0.0;
   for (i = 0, n = 0; i < num_s_pts; ++i)
      {
      if ((sparams[i].freq >= sp_minf) && (sparams[i].freq <= sp_maxf))
         {
         calculate_eebjt2_s (p,spvbe,spvce,sparams[i].freq,&sp);
         error[0] += Cmag2(Csub(sp.s[0],sparams[i].s[0]));
         error[1] += Cmag2(Csub(sp.s[2],sparams[i].s[2]));
         error[2] += Cmag2(Csub(sp.s[1],sparams[i].s[1]));
         error[3] += Cmag2(Csub(sp.s[3],sparams[i].s[3]));
         error[4] += (sp.k-sparams[i].k)*(sp.k-sparams[i].k);
         error[5] += (sp.MAG-sparams[i].MAG)*(sp.MAG-sparams[i].MAG);
         ++n;
         }
      }

   if (n > 1)
      {
      error[0] /= ((double) n);
      error[1] /= ((double) n);
      error[2] /= ((double) n);
      error[3] /= ((double) n);
      error[4] /= ((double) n);
      error[5] /= ((double) n);
      }
   
   return error;
   }

/****************************************************************************/
/****************************************************************************/
/*                         EEBJT2 MODEL FUNCTIONS                           */
/****************************************************************************/
/****************************************************************************/

static double junction_cap (double v, double vj, double mj, double cj, double coff)
   {
   double vtmp = 1.0 - v/vj;

   if (vtmp < 1.0e-2)
      vtmp = 1.0e-2;

   return cj/pow (vtmp,mj) + coff;
   }

/********************************************************************/
/********************************************************************/

static double eebjt2_ibx (double ibix, double nbx, double isx, double nx, double vbx, double tnom)
   {
   double ktq = CHARGE/(tnom*BOLTZ);
   return ibix*(exp(ktq*vbx/nbx) - 1.0) + isx*(exp(ktq*vbx/nx) - 1.0);
   }

/********************************************************************/
/********************************************************************/

static double eebjt2_gbx (double ibix, double nbx, double isx, double nx, double vbx, double tnom)
   {
   double ktq = CHARGE/(tnom*BOLTZ);
   return ibix*(ktq/nbx)*exp(ktq*vbx/nbx) + isx*(ktq/nx)*exp(ktq*vbx/nx);
   }

/********************************************************************/
/********************************************************************/

static double eebjt2_ice (double isf, double nf, double ikf, double isr, double nr, double ikr,
                   double vbe, double vbc, double tnom)
   {
   double q2,qb;
   double ktq = CHARGE/(tnom*BOLTZ);

   q2 = 0.0;
   if (ikf != 0.0)
      q2 += (isf/ikf)*(exp(ktq*vbe/nf) - 1.0);
   if (ikr != 0.0)
      q2 += (isr/ikr)*(exp(ktq*vbc/nr) - 1.0);

   qb = 0.5*(1.0 + sqrt(1.0 + 4.0*q2));

   return (isf*(exp(ktq*vbe/nf) - 1.0) - isr*(exp(ktq*vbc/nr) - 1.0))/qb;
   }   
   
/********************************************************************/
/********************************************************************/

static double eebjt2_vbe (double ibif, double nbf, double ise, double ne, double ibir, double nbr,
                   double isc, double nc, double tnom, double ibe, double vce, double vbe)
   {
   double vb1,vb2;
   double ib1,ib2;
   double ktq = CHARGE/(tnom*BOLTZ);
   double step;
   int i = 0;

   vb1 = vbe;
   ib1 = eebjt2_ibx(ibif,nbf,ise,ne,vb1,tnom) + eebjt2_ibx(ibir,nbr,isc,nc,vb1-vce,tnom) - ibe;

   step = 0.05;
   do {
      ib2 = ib1;
      vb2 = vb1;

      if (((ib1 > 0.0) && (step > 0.0)) || ((ib1 < 0.0) && (step < 0.0)))
         step *= -0.5;

      vb1 += step;
      ib1 = eebjt2_ibx(ibif,nbf,ise,ne,vb1,tnom) + eebjt2_ibx(ibir,nbr,isc,nc,vb1-vce,tnom) - ibe;

      ++i;
      }
   while ((fabs(ib1) > fabs (ibe*0.0005)) && (i < 100));

   return vb1;
   }

/********************************************************************/
/********************************************************************/

static double eebjt2_iv_model (double *p, double ibb, double vcc, double vbb, double *vbe)
   {
   double Ibif = p[15];
   double Nbf  = p[16];
   double Isf  = p[17];
   double Nf   = p[18];
   double Ibir = p[19];
   double Nbr  = p[20];
   double Isr  = p[21];
   double Nr   = p[22];
   double Ikf  = p[23];
   double Isc  = p[24];
   double Nc   = p[25];
   double Ise  = p[26];
   double Ne   = p[27];
   double Ikr  = p[28];

   *vbe = eebjt2_vbe (Ibif,Nbf,Ise,Ne,Ibir,Nbr,Isc,Nc,temperature,ibb,vcc,vbb);
   return eebjt2_ice (Isf,Nf,Ikf,Isr,Nr,Ikr,*vbe,*vbe-vcc,temperature) - eebjt2_ibx (Ibir,Nbr,Isc,Nc,*vbe-vcc,temperature);
   }

/********************************************************************/
/********************************************************************/

static void high_current_fwd_gummel (double v, double ibif, double nbf, double isf,
                                     double nf, double ikf, double rb, double re,
                                     double *ib, double *ic)
   {
   double vb = v;
   double ktq = CHARGE/(temperature*BOLTZ);
   double step = -0.01;
   double q2,qb,vcalc;

   do {
      *ib = ibif*(exp(ktq*vb/nbf) - 1.0);

      q2 = 0.0;
      if (ikf != 0.0)
         q2 = (isf/ikf)*(exp(ktq*vb/nf) - 1.0);
      qb = 0.5*(1.0 + sqrt(1.0 + 4.0*q2));

      *ic = isf*(exp(ktq*vb/nf) - 1.0)/qb;

      vcalc = vb + rb*(*ib) + re*((*ic) + (*ib));

      if (((vcalc > v) && (step > 0.0)) || ((vcalc < v) && (step < 0.0)))
         step *= -0.5;

      vb += step;
      }
   while (fabs (vcalc-v) > 0.0005);
   }

/****************************************************************************/
/****************************************************************************/
/*                                UTILITIES                                 */
/****************************************************************************/
/****************************************************************************/

static double pexp (double x)
   {
#define MAX_ARG   70.0

   if (x > MAX_ARG)
      return exp(MAX_ARG)*(1.0 + (x - MAX_ARG));
   else if (x < -MAX_ARG)
      return 0.0;

   return exp(x);
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mxb (double *x, double *y, int n, double *m, double *b, double *r2)
   {
   int i;
   double xsum = 0.0;
   double ysum = 0.0;
   double xxsum = 0.0;
   double yysum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   if (n < 1)
      {
      *m = 0.0;
      *b = 0.0;
      *r2 = 0.0;
      return;
      }

   for (i = 0; i < n; ++i)
      {
      xsum  += x[i];
      ysum  += y[i];
      xxsum += x[i]*x[i];
      yysum += y[i]*y[i];
      xysum += x[i]*y[i];
      }

   *m  = (xysum*((double) n) - xsum*ysum) / (xxsum*((double) n) - xsum*xsum);
   *b  = (xxsum*ysum - xysum*xsum) / (xxsum*((double) n) - xsum*xsum);
   // *r2 = xysum*xysum / (xxsum*yysum);

   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] + (*b) - y[i])*((*m)*x[i] + (*b) - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }

/*****************************************************************************/
/*****************************************************************************/

static void linefit_mx0 (double *x, double *y, int n, double *m, double *r2)
   {
   int i;
   double ysum = 0.0;
   double xxsum = 0.0;
   double xysum = 0.0;
   double err = 0.0;
   double max = 0.0;
   double ymean;

   for (i = 0; i < n; ++i)
      {
      ysum  += y[i];
      xxsum += x[i]*x[i];
      xysum += x[i]*y[i];
      }

   *m = xysum / xxsum;
   ymean = ysum/((double) n);

   for (i = 0; i < n; ++i)
      {
      err += ((*m)*x[i] - y[i])*((*m)*x[i] - y[i]);
      max += (y[i]-ymean)*(y[i]-ymean);
      }

   *r2 = sqrt (1.0 - err/max);
   }

/*****************************************************************************/
/*****************************************************************************/

static int a_x_b (double *a, double *x, double *b, int n)
   {
   double   y[50];
   double   z[50][50];
   double   tempd;
   double   tempd2;
   double   max;
   int      pointer[50];
   int      tempi;
   int      i,j,k;
   int      col,row;
   
   for (i = 0; i < n; ++i)
      {
      y[i] = b[i];
      pointer[i] = i;
      for (j = 0; j < n; ++j)
         z[i][j] = a[i*n+j];
      }
   
   /* invert the matrix */
   for (k = 0; k < n-1; ++k)
      {
      /* find max */
      max = 0.0;
      for (i = k; i < n; ++i)
         {
         for (j = k; j < n; ++j)
            {
            if (fabs (z[i][j]) > max)
               {
               row = i;
               col = j;
               max = fabs (z[i][j]);
               }
            }
         }
      
      /* rotate rows */
      if (row != k)
         {
         for (j = 0; j < n; ++j)
            {
            tempd = z[k][j];
            z[k][j] = z[row][j];
            z[row][j] = tempd;
            }
         tempd = y[k];
         y[k] = y[row];
         y[row] = tempd;
         }
      
      /* rotate columns */ 
      if (col != k)
         {
         for (i = 0; i < n; ++i)
            {
            tempd = z[i][k];
            z[i][k] = z[i][col];
            z[i][col] = tempd;
            }
         tempi = pointer[k];
         pointer[k] = pointer[col];
         pointer[col] = tempi;
         }
      
      /* gaussian elimination */
      tempd = z[k][k];
      for (i = k+1; i < n; ++i)
         {
         tempd2 = z[i][k]/tempd;
         y[i] -= tempd2*y[k];
         for (j = k; j < n; ++j)
            {
            z[i][j] -= tempd2*z[k][j];
            }
         }
      }  
   
   if (fabs (z[n-1][n-1]) < 1.0e-24)
      return -1;
   
   /* back substitution */
   x[pointer[n-1]] = y[n-1]/z[n-1][n-1];
   for (k = n-2; k > -1; --k)
      {
      tempd = y[k];
      for (i = n-1; i > k; --i)
         tempd -= z[k][i]*x[pointer[i]];
      
      x[pointer[k]] = tempd/z[k][k];
      }
   
   return 0;
   }

/*****************************************************************************/
/*****************************************************************************/

static int diode_fit (double *vd, double *id, int k, double *is, double *n, double *rd)
   {
   double   a1[3][MAX_IV_PTS];
   double   a2[MAX_IV_PTS][3];
   double   b1[MAX_IV_PTS];
   double   a[3][3];
   double   b[3];
   double   x[3];
   double   sum;
   int      i,j;
   int      npts;

   j = 0;
   for (i = 0; i < k; ++i)
      {
      if ((vd[i] <= 0.0) || (id[i] <= 1.0e-9))
         continue;
      
      a2[j][0] = log (id[i]);
      a2[j][1] = -1.0;
      a2[j][2] = id[i];
      a1[0][j] = a2[j][0];
      a1[1][j] = a2[j][1];
      a1[2][j] = a2[j][2];
      b1[j] = vd[i];
      ++j;
      }
   
   if (j < 3)
      {
      fprintf (stderr,"Not enough points for diode fit.\n");
      return -1;
      }
   
   npts = j;
   
   for (i = 0; i < 3; ++i)
      {
      for (j = 0; j < 3; ++j)
         {
         sum = 0.0;
         for (k = 0; k < npts; ++k)
            sum += a1[i][k]*a2[k][j];
         
         a[i][j] = sum;
         }
      }
   
   for (i = 0; i < 3; ++i)
      {
      sum = 0.0;
      for (j = 0; j < npts; ++j)
         sum += a1[i][j]*b1[j];
      
      b[i] = sum;
      }
   
   if (a_x_b ((double *)a,x,b,3) < 0)
      {
      fprintf (stderr,"Singular matrix in diode fit.\n");
      return -1;
      }
   
   *n  = x[0]*CHARGE/(BOLTZ*temperature);
   *is = exp (x[1]/x[0]);
   *rd = x[2];
   
   return 0;
   }

