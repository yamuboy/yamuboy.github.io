#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "optimize3.h"
#include "jmbplot.h"

// global definitions
#define NUM_PARAMS      15
#define MAX_IV_PTS      1500

// global variables
double  vcc[MAX_IV_PTS],vbb[MAX_IV_PTS];
double  icc[MAX_IV_PTS],ibb[MAX_IV_PTS];
int     num_iv_pts;

// function prototypes
double *hbt_iv_erf (double *pl);
void eebjt2_iv_model (double *pl, double ibb, double vcc, double vbb, double *vbe, double *ice);

/********************************************************************/
/********************************************************************/

main (int argc, char *argv[])
   {
   char     iv_file_name[80];
   char     para_file[80];
   char     start_params[80];
   char     finish_params[80];
   char     string[1024];
   float    vstart,vstep,vstop;
   float    istart,istep,istop;
   double   v1,i1,v2,i2,wght;
   double   Ree,Rbb,Rcc;
   int      vtick,itick,max_searches;
   int      graphics_device,i;
   FILE     *infile,*outfile;
   PARAM_STRUCT prms[NUM_PARAMS];
   OPT_STRUCT   opts;
   JMBPLOT_ITEM    pitem;
   JMBPLOT_DATA    pdata[2];
   JMBPLOT_SCALE   sc;
   float           vcf[MAX_IV_PTS];
   float           icfmeas[MAX_IV_PTS];
   float           icfmod[MAX_IV_PTS];
   double          pl[NUM_PARAMS];
   double          ice,vbe;

   // user I/O
   printf ("IV data file name?\n");
   scanf ("%79s",iv_file_name);
   printf ("Extrinsics end file name?\n");
   scanf ("%79s",para_file);
   printf ("Start parameters file name?\n");
   scanf ("%79s",start_params);
   printf ("Finish parameters file name?\n");
   scanf ("%79s",finish_params);
   printf ("Maximum line searches?\n");
   scanf ("%d",&max_searches);
   printf ("Collector voltage (Start Stop Step Tick)?\n");
   scanf ("%f%f%f%d",&vstart,&vstop,&vstep,&vtick);
   printf ("Collector current (Start Stop Step Tick)?\n");
   scanf ("%f%f%f%d",&istart,&istop,&istep,&itick);
   printf ("Device?\n");
   scanf ("%d",&graphics_device);

   /* ----------- get parasitics ------------------ */

   infile = fopen (para_file,"r");
   if (infile == (FILE *) NULL)
      {
      printf ("** ERROR ** Unable to open file - %s.\n",para_file);
      return -1;
      }

   if (fgets (string,100,infile) == NULL)
      {
      printf ("** ERROR ** Incomplete file - %s.\n",para_file);
      fclose (infile);
      return -1;
      }
   sscanf (string,"%*f%lf",&Rbb);

   fgets (string,100,infile);
   if (fgets (string,100,infile) == NULL)
      {
      printf ("** ERROR ** Incomplete file - %s.\n",para_file);
      fclose (infile);
      return -1;
      }
   sscanf (string,"%*f%lf",&Rcc);

   fgets (string,100,infile);
   if (fgets (string,100,infile) == NULL)
      {
      printf ("** ERROR ** Incomplete file - %s.\n",para_file);
      fclose (infile);
      return -1;
      }
   sscanf (string,"%*f%lf",&Ree);

   fclose (infile);

   /* ------------ get IV data ----------------- */

   infile = fopen (iv_file_name,"r");
   if (infile == (FILE *) NULL)
      {
      printf ("** ERROR ** Unable to open file - %s.\n",iv_file_name);
      return -1;
      }

   i = 0;
   while (fgets (string,100,infile) != NULL)
      {
      if (sscanf (string,"%lf%lf%lf%lf",&v1,&i1,&v2,&i2) == 4)
         {
         if (i >= MAX_IV_PTS)
            {
            printf ("** WARNING ** Maximum IV points exceeded.\n");
            break;
            }

         if (i2 < 1.0e-7)
            continue;

         vcc[i] = v1 - i1*Rcc - (i1+i2)*Ree;
         vbb[i] = v2 - i2*Rbb - (i1+i2)*Ree;
         icc[i] = i1;
         ibb[i] = i2;
         ++i;
         }
      }

   num_iv_pts = i;
   fclose (infile);

   if (i < 1)
      {
      printf ("** ERROR ** No data in file - %s.\n",iv_file_name);
      return -1;
      }

   /* ------------ get starting values ----------------- */

   infile = fopen (start_params,"r");
   if (infile == (FILE *) NULL)
      {
      printf ("** ERROR ** Unable to open file - %s.\n",start_params);
      return -1;
      }

   i = 0;
   while (fgets (string,100,infile) != NULL)
      {
      if (sscanf (string,"%lf%lf%lf%lf%s",&prms[i].min,&prms[i].nom,&prms[i].max,&prms[i].tol,prms[i].name) == 5)
         {
         strcpy (prms[i].units,"");
         prms[i].optimize = TRUE;
         ++i;
         }

      if (i >= NUM_PARAMS)
         break;

      }

   fclose (infile);

   if (i != NUM_PARAMS)
      {
      printf ("** ERROR ** Missing parameters in %s.\n",start_params);
      return -1;
      }

   /* -------------- optimize ----------------- */

   wght = 1.0;
   initialize_optimizer (&opts, NUM_PARAMS, 1, &wght, max_searches, &hbt_iv_erf);

   // set other stuff ???

   if (cg_optimize (opts,prms) < 0)
      {
      printf ("** ERROR ** optimizer error.\n");
      return -1;
      }

   /* --------- write finish parameters ------- */

   outfile = fopen (finish_params,"w+");

   for (i = 0; i < NUM_PARAMS; ++i)
      {
      fprintf (outfile,"%12.4e %12.4e %12.4e %12.4e %s\n",prms[i].min,prms[i].nom,prms[i].max,prms[i].tol,prms[i].name);
      }

   fclose (outfile);

   /* --------- plot data ------------------ */
   
   pitem.type = singleY;
   pitem.font = 0;
   pitem.scaling = manualX | manualY1 | manualY2;
   pitem.scales = &sc;
   pitem.data = pdata;
   pitem.num_data_items = 2;
   pitem.flags = DRAW_XGRID | DRAW_YGRID;
   
   pdata[0].x1_data = vcf;
   pdata[1].x1_data = vcf;
   pdata[0].y1_data = icfmeas;
   pdata[1].y1_data = icfmod;
   
   pdata[0].curve1_linetype = LT_DASHED;
   pdata[0].curve1_linewidth = 1;
   pdata[1].curve1_linetype = LT_SOLID;
   pdata[1].curve1_linewidth = 1;
   
   for (i = 0; i < NUM_PARAMS; ++i)
      {
      pl[i] = prms[i].nom;
      }
   
   if (jmbplot_open_device (X_WINDOWS,"",string) < 0)
      {
      printf ("%s\n",string);
      return -1;
      }
   
   for (i = 0; i < num_iv_pts; ++i)
      {
      vcf[i] = (float) vcc[i];
      icfmeas[i] = (float) (icc[i]*1000.0);

      eebjt2_iv_model (pl,ibb[i],vcc[i],vbb[i],&vbe,&ice);
      icfmod[i] = (float) (ice*1000.0);
      }
   
   pdata[0].curve1_pts = num_iv_pts;
   pdata[1].curve1_pts = num_iv_pts;
      
   sc.xmin = vstart;
   sc.xmax = vstop;
   sc.xstep = vstep;
   sc.xtick = vtick;
   sc.y1min = istart;
   sc.y1max = istop;
   sc.y1step = istep;
   sc.y1tick = itick;
   
   if (jmbplot_draw_plot (pitem,1,0,string) < 0)
      {
      printf ("%s\n",string);
      jmbplot_close_device ();
      return (-1);
      }

   jmbplot_close_device ();
   
   return 0;
   }

/********************************************************************/
/********************************************************************/

double eebjt2_ibx (double ibix, double nbx, double isx, double nx, double vbx, double tnom)
   {
   double ktq;

   ktq = 1.6021918e-19/(tnom*1.3806226e-23);

   return ibix*(exp(ktq*vbx/nbx) - 1.0) + isx*(exp(ktq*vbx/nx) - 1.0);
   }

/********************************************************************/
/********************************************************************/

double eebjt2_ice (double isf, double nf, double ikf, double isr, double nr, double ikr,
                   double vbe, double vbc, double tnom)
   {
   double ktq,q2,qb;

   ktq = 1.6021918e-19/(tnom*1.3806226e-23);

   q2 = (isf/ikf)*(exp(ktq*vbe/nf) - 1.0);  // + (isr/ikr)*(exp(ktq*vbc/nr) - 1.0);

   qb = 0.5*(1.0 + sqrt(1.0 + 4.0*q2));

   return (isf*(exp(ktq*vbe/nf) - 1.0) - isr*(exp(ktq*vbc/nr) - 1.0))/qb;
   }   
   
/********************************************************************/
/********************************************************************/

double eebjt2_vbe (double ibif, double nbf, double ise, double ne, double ibir, double nbr,
                   double isc, double nc, double tnom, double ibe, double vce, double vbe)
   {
   double vb1,vb2;
   double ib1,ib2;
   double ktq;
   double step;
   int i = 0;

   ktq = 1.6021918e-19/(tnom*1.3806226e-23);

//   vb1 = 0.5*(vce - nbf*log((ibe/ibif) + 1.0)/ktq);
   vb1 = vbe;
   ib1 = eebjt2_ibx(ibif,nbf,ise,ne,vb1,tnom) + eebjt2_ibx(ibir,nbr,isc,nc,vb1-vce,tnom) - ibe;

   step = 0.05;
   do {
      ib2 = ib1;
      vb2 = vb1;

      if (((ib1 > 0.0) && (step > 0.0)) || ((ib1 < 0.0) && (step < 0.0)))
         step *= -0.5;

      vb1 += step;
      ib1 = eebjt2_ibx(ibif,nbf,ise,ne,vb1,tnom) + eebjt2_ibx(ibir,nbr,isc,nc,vb1-vce,tnom) - ibe;

      ++i;
      }
   while (fabs(ib1) > (ibe*0.0005));

   return vb1;
   }

/********************************************************************/
/********************************************************************/

void eebjt2_iv_model (double *pl, double ibb, double vcc, double vbb, double *vbe, double *ice)
   {
   double Ibif,Nbf,Isf,Nf;
   double Ibir,Nbr,Isr,Nr;
   double Ikf,Isc,Nc,Ise;
   double Ne,Ikr,Tnom;
   double vbc;

   Ibif   = pl[0];
   Nbf    = pl[1];
   Isf    = pl[2];
   Nf     = pl[3];
   Ibir   = pl[4];
   Nbr    = pl[5];
   Isr    = pl[6];
   Nr     = pl[7];
   Ikf    = pl[8];
   Isc    = pl[9];
   Nc     = pl[10];
   Ise    = pl[11];
   Ne     = pl[12];
   Ikr    = pl[13];
   Tnom   = pl[14];

   *vbe = eebjt2_vbe (Ibif,Nbf,Ise,Ne,Ibir,Nbr,Isc,Nc,Tnom,ibb,vcc,vbb);
   vbc = *vbe - vcc;

   *ice = eebjt2_ice (Isf,Nf,Ikf,Isr,Nr,Ikr,*vbe,vbc,Tnom) - eebjt2_ibx (Ibir,Nbr,Isc,Nc,vbc,Tnom);

   return;
   }

/********************************************************************/
/********************************************************************/

double *hbt_iv_erf (double *pl)
   {
   static double err;
   double vbe,ice;
   int i;

   err = 0.0;
   for (i = 0; i < num_iv_pts; ++i)
      {
      eebjt2_iv_model (pl, ibb[i], vcc[i], vbb[i], &vbe, &ice);
      err += pow (ice-icc[i],2.0);
      // printf ("vbe = %.5e, ice = %.5e, vbem = %.5e, icem = %.5e\n",vbe,ice,vbb[i],icc[i]);
      }

   err = err / ((double) num_iv_pts);

   return &err;
   }
































