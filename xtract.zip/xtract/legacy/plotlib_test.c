#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "jplot.h"

main (int argc, char *argv[])
   {
   jPLOT_ITEM  *pitem;
   double      xdata[300],ydata[300],zdata[300];
   char        *ltxt[] = {"Item 1","Item 2"};
   int         ltype[] = {LT_SOLID,LT_DASHED};
   int         lwdth[] = {2,1};
   int         lclr[]  = {CLR_RED,CLR_ORANGE};
   int     i;

   for (i = 0; i < 201; ++i)
      {
      xdata[i] = (i-50)/100.0;
      ydata[i] = 100.0/(fabs((double) (i-100))+1.0);
      zdata[i] = fabs ((double) (i-100))*fabs ((double) (i-100))/500.0;
      }


   if (!open_graphics_device (X_WINDOWS,"x"))
      {
      printf ("Failed to open device.\n");
      return -1;
      }

   pitem = create_plot_item (SingleY,3.0,2.0,6.0,5.0);
   if (pitem == NULL)
      {
      printf ("Failed to allocate memory.\n");
      close_graphics_device ();
      return -1;
      }
         
   attach_y1data (pitem,xdata,ydata,201,LT_SOLID,2,CLR_RED);
   attach_y2data (pitem,xdata,zdata,201,LT_DASHED,1,CLR_ORANGE);

   set_axis_labels (pitem,"This is the X axis.","This is the Y1 axis","This is the Y2 axis","This is the title");

   pitem->scaling = LogY1;
   pitem->flags = FULL_LOG_YGRID;

   add_legend (2,0.75,7.75,ltxt,FNT_COURIER,12,ltype,lwdth,lclr);

   add_circle (3.0,3.0,1.0,LT_SOLID,2,CLR_RED);
   add_arc (6.0,3.0,2.2,0.0,90.0,LT_SOLID,1,CLR_BLUE);

   if (!draw_page ())
      {
      printf ("page draw failed.\n");
      return -1;
      }

   close_graphics_device ();

   return 0;
   }
