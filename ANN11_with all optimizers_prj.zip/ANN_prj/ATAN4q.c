

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#define PI 3.1415926538654

extern double atan4q(double, double);

double atan4q(double y, double x)
{
    double answer;

    answer = atan(y/x);  
    if ((y < 0) && (x < 0))
	{
		answer = answer - PI;
	}
    else if ((y > 0) && (x < 0))
	{
        answer = answer + PI;
	}
    
    return answer;
}
