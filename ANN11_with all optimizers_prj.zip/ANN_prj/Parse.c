

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

//#include "protos.h"
//#include "neuron.h"


extern void Parse_Infile(NeuralNet *, SETUP *, Data *TDat, Cntrl *);

void Parse_Infile(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{ 

	char sval[MAXLINELENGTH],seq[MAXLINELENGTH],svar[MAXLINELENGTH];
	char sl[MAXLINELENGTH], sh[MAXLINELENGTH] ;
	int line=0,num_words, i, ni=0, no=0, nin[12], nout[12];
	double ninhigh[12], nouthigh[12];
	double ninlow[12], noutlow[12];
	char linebuffer[MAXLINELENGTH];
	int dline=0, caught = 0, DATAmax=0;
    
	for (i=0;i<=MAX_Layers;i++)
	{	
       C->NNpl[i] = 0 ; 
//	   printf("======== %d  %d\n", i, C->NNpl[i]);        
	}

    strcpy(C->Outfile, "ANN_0.dat");
	
	C->Input  = fopen(C->Infile,READ);
    printf("\n\n\nOpening Input File ===> %s \n",C->Infile);
    printf("Default Output File ===> %s  \n\n\n", C->Outfile);
	
	printf("Printing input file parameters\n");
	printf("======================================\n");

    while (getline(C->Input,linebuffer,MAXLINELENGTH) > 0)
    {
		if ((linebuffer[0] != '#')||(linebuffer[0] != '!'))
        {
            line++;
	        num_words = count_words_o(linebuffer,MAXLINELENGTH);
	        for (i=1;i<num_words;i++)
			{
	            get_word_o(linebuffer,MAXLINELENGTH,i  ,seq );
	            get_word_o(linebuffer,MAXLINELENGTH,i-1,svar);
       	        get_word_o(linebuffer,MAXLINELENGTH,i+1,sval);

                if (!strcmp("=",seq))
				{
					if (!strcmp("in_col",svar))
					{
						ni++ ;
						nin[ni] = atoi(sval);
						get_word_o(linebuffer,MAXLINELENGTH,i+2,sl);
						ninlow[ni] = atof(sl);
       	                get_word_o(linebuffer,MAXLINELENGTH,i+3,sh);
						ninhigh[ni] = atof(sh);
                        printf(" Input #%d in Column %d   Nhigh = %f    Nlow = %f  \n",
							                 ni,nin[ni], ninlow[ni], ninhigh[ni]);
					}
					if (!strcmp("out_col",svar))
					{
						no++ ;
						nout[no] = atoi(sval);
						get_word_o(linebuffer,MAXLINELENGTH,i+2,sl);
						noutlow[no] = atof(sl);
       	                get_word_o(linebuffer,MAXLINELENGTH,i+3,sh);
						nouthigh[no] = atof(sh);
                        printf("Output #%d in Column %d    Nhigh = %f    Nlow = %f  \n",
							                   no,nout[no], noutlow[no], nouthigh[no]);
					}
					if (!strcmp("Output_File",svar))
					{
						strcpy(C->Outfile, sval);
                        printf("%s = %s\n",svar,C->Outfile);
                    }
					if (!strcmp("Load_The_Weights",svar))
					{
						if (!strcmp("yes",sval))
						{
						   C->Load_The_Weights = 1;
						   printf("%s = %s\n",svar,"yes");
						}
						else
						{
						   C->Load_The_Weights = 0;
						   printf("%s = %s\n",svar,"no");
						}
                        
                    }
					if (!strcmp("Random_Init",svar))
					{
						if (!strcmp("yes",sval))
						{
						   C->Randomize_The_Weights = 1;
						   printf("%s = %s\n",svar,"yes");
						}
						else
						{
						   C->Randomize_The_Weights = 0;
						   printf("%s = %s\n",svar,"no");
						}
                        
                    }
					if (!strcmp("Save_Weight_File",svar))
					{
						strcpy(C->Wfile, sval);
                        printf("%s = %s\n",svar,C->Wfile);
                    }
					if (!strcmp("MAX_Random_Inits",svar))
					{
                        Parms->MRI = atoi(sval);
                        printf("%s = %d \n",svar,Parms->MRI);
					}
					if (!strcmp("PercentErrorChange",svar))
					{
                        Parms->PEC = atof(sval)/100;
                        printf("%s = %6f Percent Change\n",svar,100*Parms->PEC);
					}
					if (!strcmp("WeightScale",svar))
					{
                        Parms->WF = atof(sval);
                        printf("%s = %6f\n",svar,Parms->WF);
					}					
					if (!strcmp("DEBUG",svar))
					{
                        Parms->DB = atoi(sval);
                        printf("%s = %d\n",svar,Parms->DB);
					}
					if (!strcmp("Vg_col",svar))
					{
                        C->Vg_col = atoi(sval);
                        printf("%s = %d\n",svar,C->Vg_col);
					}
					if (!strcmp("Vd_col",svar))
					{
                        C->Vd_col = atoi(sval);
	                    printf("%s = %d\n",svar,C->Vd_col);
					}
					if (!strcmp("Id_col",svar))
					{
                        C->Id_col = atoi(sval);
	                    printf("%s = %d\n",svar,C->Id_col);
					}
					if (!strcmp("Data_File",svar))
					{
                        strcpy( C->Dfile, sval);
                        printf("%s = %s\n",svar,C->Dfile);
					}
					if (!strcmp("Nh1",svar))
					{
                        C->NNpl[1] = atoi(sval);
	                    printf("%s = %d\n",svar,C->NNpl[1]);
					}
					if (!strcmp("Nh2",svar))
					{
                        C->NNpl[2] = atoi(sval);
	                    printf("%s = %d\n",svar,C->NNpl[2]);
						
					}
					if (!strcmp("Nh3",svar))
					{
                        C->NNpl[3] = atoi(sval);
	                    printf("%s = %d\n",svar,C->NNpl[3]);
						
					}
					if (!strcmp("Nh4",svar))
					{
                        C->NNpl[4] = atoi(sval);
	                    printf("%s = %d\n",svar,C->NNpl[4]);
					}
					if (!strcmp("Nh5",svar))
					{
                        C->NNpl[5] = atoi(sval);
	                    printf("%s = %d\n",svar,C->NNpl[5]);
					}
					if (!strcmp("Nh6",svar))
					{
                        C->NNpl[6] = atoi(sval);
	                    printf("%s = %d\n",svar,C->NNpl[6]);
					}
					if (!strcmp("SigmoidLamda",svar))
					{
                        Parms->SLamda = atof(sval);
	                    printf("%s = %3f\n",svar,Parms->SLamda);
					}
					if (!strcmp("BP_Eta",svar))
					{
                        Parms->Eta = atof(sval);
	                    printf("%s = %3f\n",svar,Parms->Eta);
					}
					if (!strcmp("minERROR",svar))
					{
                        Parms->minERROR = atof(sval);
	                    printf("%s = %3f\n",svar,Parms->minERROR);
					}
					if (!strcmp("nITER",svar))
					{
                        Parms->nITER = atoi(sval);
	                    printf("%s = %3d\n",svar,Parms->nITER);
					}
                 	if (!strcmp("MAX_Iterations",svar))
					{
                        Parms->MAXITER = atoi(sval);
	                    printf("%s = %3d\n",svar,Parms->MAXITER);
					}
					if (!strcmp("Tmin",svar))
					{
                        C->Tmin = atof(sval);
                        printf("%s = %6f\n",svar,C->Tmin);
					}
					if (!strcmp("Tmax",svar))
					{
                        C->Tmax = atof(sval);
                        printf("%s = %6f\n",svar,C->Tmax);
					}
					if (!strcmp("nTemps",svar))
					{
                        C->nTemp = atoi(sval);
                        printf("%s = %6d\n",svar,C->nTemp);
					}
					if (!strcmp("AlphaMax",svar))
					{
                        C->AlphaMax = atof(sval);
                        printf("%s = %6f\n",svar,C->AlphaMax);
					}
					if (!strcmp("AlphaMin",svar))
					{
                        C->AlphaMin = atof(sval);
                        printf("%s = %6f\n",svar,C->AlphaMin);
					}
					if (!strcmp("nAlpha",svar))
					{
                        C->nAlpha = atoi(sval);
                        printf("%s = %6d\n",svar,C->nAlpha);
					}
					if (!strcmp("HeatFactor",svar))
					{
                        C->HeatFactor = atof(sval);
                        printf("%s = %6f\n",svar,C->HeatFactor);
					}
					if (!strcmp("nRelax",svar))
					{
                        C->nRelax = atoi(sval);
                        printf("%s = %6d\n",svar,C->nRelax);
					}

// ----- END LIST OF INPUT parameters

                }
            }
        }
    }  
    fclose(C->Input);

	NNet->Ni = ni;
	NNet->No = no;
	NNet->Ni_col = ivector(1,ni);
	NNet->No_col = ivector(1,no);

    TDat->dThigh = dvector(1, NNet->Ni);
    TDat->dTlow  = dvector(1, NNet->Ni);
    TDat->dRhigh = dvector(1, NNet->No);
    TDat->dRlow  = dvector(1, NNet->No);

	for (i=1 ; i<=NNet->Ni ; i++)
	{
		NNet->Ni_col[i] = nin[i] ;
		TDat->dThigh[i] = ninhigh[i];
		TDat->dTlow[i] = ninlow[i];
		printf(" Input Column[%d] = %d  NormL = %f   NormH = %f  \n", 
			              i, NNet->Ni_col[i], TDat->dTlow[i], TDat->dThigh[i]);
	}
	for (i=1 ; i<=NNet->No ; i++)
	{
		NNet->No_col[i] = nout[i] ;
		TDat->dRhigh[i] = nouthigh[i];
		TDat->dRlow[i] = noutlow[i];
		printf("Output Column[%d] = %d  NormL = %f   NormH = %f  \n",  
			              i, NNet->No_col[i], TDat->dRlow[i], TDat->dRhigh[i]);
	}

	printf("======================================\n");
    printf("End input file parameter Echo\n\n");

}
