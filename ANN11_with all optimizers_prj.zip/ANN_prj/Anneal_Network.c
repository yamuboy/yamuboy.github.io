

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

extern long idum;

extern void Anneal_Network(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Generate_Weights(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Compute_Error(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Temp_Weights(NeuralNet *);
extern void Update_Weights(NeuralNet *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Update_Temp_Weights(NeuralNet *);
extern void Store_Weights(NeuralNet *);


void Anneal_Network(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{ 
   double dTemp, dAlpha, dBeta, ERRORold ; 

   Store_Weights(NNet);
   dTemp = (C->Tmax - C->Tmin)/((double)C->nTemp+1) ;
   dAlpha = (C->AlphaMax - C->AlphaMin)/((double)C->nAlpha+1) ;
   
   ERRORold = 1e9 ;
   for (Parms->Temp = C->Tmax ; Parms->Temp>=C->Tmin ; Parms->Temp = Parms->Temp - dTemp)
   {
	  dBeta = C->HeatFactor*Parms->Temp/((double)C->nRelax+1);
	  printf("Changing Temperatures to %3.2f \n",Parms->Temp);
      for (Parms->Alpha = C->AlphaMax ; Parms->Alpha >= C->AlphaMin ; Parms->Alpha = Parms->Alpha - dAlpha)
	  {
         for (Parms->Beta = 0 ; Parms->Beta <= C->HeatFactor*Parms->Temp ; Parms->Beta = Parms->Beta + dBeta)
		 {
//			 printf("Temp = %3.1f   Alpha = %3.1f   Beta = %f  Beta/Temp = %4.3f \n", Parms->Temp, Parms->Alpha, Parms->Beta,Parms->Beta/Parms->Temp );
            Generate_Weights(NNet, Parms, TDat, C);
			Compute_Error(NNet, Parms, TDat, C);
/**/
            if (NNet->Error<ERRORold)
			{
		       printf("AN: Temp = %3.1f Alpha = %3.2f B/T = %3.2f Initial Error: %13.12f \n",
			                     Parms->Temp, Parms->Alpha, Parms->Beta/Parms->Temp, NNet->Error);
		       ERRORold = NNet->Error ;
		       Temp_Weights(NNet);
			}
/**/
		 }
		 Update_Temp_Weights(NNet);
	  }
   }

}
