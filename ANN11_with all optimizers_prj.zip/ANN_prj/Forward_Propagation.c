

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern void free_Nmatrix(Neuron **, long , long , long , long );
extern double sigmoid(double , double);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);


void Forward_Prop(int ic, NeuralNet *NNet, SETUP *Parms, Data *TD)
{ 

   int i,j,ii;
   double y;

   for (i=1; i<=NNet->Nlayers; i++)
   {
      for (j=1; j<=NNet->Nl[i]; j++)
	  {
	     y = 0 ;
         if (i>1)
		 {
	        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
			{
                y = y + NNet->Nron[i][j].w[ii] * NNet->Nron[i-1][ii].o;   
			}
		 }
	     else
		 {
	        for (ii=1; ii<=NNet->Ni; ii++)
			{
			   y = y + NNet->Nron[i][j].w[ii] * TD->dT[ic][ii];
		    }
		 }
		 y = y + NNet->Nron[i][j].b ;
		 NNet->Nron[i][j].o  = sigmoid(Parms->SLamda, y) ;
	  }
   }
}


