
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
//#include "protos.h"
#include "file.h"
#include "nrutil.h"
//#include "neuron.h"

extern void Validat(NeuralNet , SETUP , Data, Cntrl);
extern double sigmoid(double , double);

void Validat(NeuralNet NNet, SETUP Parms, Data TD, Cntrl C)
{ 
   int ic, i, ii, j ;
   double y;

   printf("\n\n============ Validate the Network ===========\n");
   printf("\nOpening Output Data File ===> %s \n\n",C.Dfile);
   
   C.Output = fopen(C.Outfile, WRITE);

   for (ic=1; ic<=TD.NTsamples ; ic++)
   {
      for (i=1; i<=NNet.Nlayers; i++)
	  {
         for (j=1; j<=NNet.Nl[i]; j++)
		 {
		    y = 0 ;
            if (i>1)
			{
		       for (ii=1; ii<=NNet.Nl[i-1]; ii++)
			   {
                   y = y + NNet.Nron[i][j].w[ii] * NNet.Nron[i-1][ii].o;   
			   }
			   y = y + NNet.Nron[i][j].b; 
			   NNet.Nron[i][j].o  = sigmoid(Parms.SLamda, y) ;
			}
	        else
			{
		       for (ii=1; ii<=NNet.Ni; ii++)
			   {
				   y = y + NNet.Nron[i][j].w[ii] * TD.dT[ic][ii];
			   }
			   y = y + NNet.Nron[i][j].b;
			   NNet.Nron[i][j].o  = sigmoid(Parms.SLamda, y);
			}
		 }
      }
/*      
      for (i=1; i<=NNet.Ni ; i++)
	  {
		  printf(" %f  ",TD.dT[ic][i]);
	  }
	  for (i=1; i<=NNet.No ; i++)
	  {
		  printf(" %f  %f ",TD.dR[ic][i], NNet.Nron[NNet.Nlayers][i].o);
	  }
	  printf("\n");
*/
      for (i=1; i<=NNet.Ni ; i++)
	  {
		  fprintf(C.Output," %f  ",TD.dT[ic][i]);
	  }
	  for (i=1; i<=NNet.No ; i++)
	  {
		  fprintf(C.Output," %f  %f ",TD.dR[ic][i], NNet.Nron[NNet.Nlayers][i].o);
	  }
	  fprintf(C.Output,"\n");
   }
   fclose(C.Output);	
}
