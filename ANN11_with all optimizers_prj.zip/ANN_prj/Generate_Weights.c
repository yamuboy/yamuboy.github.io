
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern void Generate_Weights(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C);
extern double ran1(long *);
extern long idum;

void Generate_Weights(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{
   int ii, j, ic ;
   double rw ;

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		 if (ii>1)
		 {
	        for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   rw = Parms->Alpha*exp(-Parms->Beta/Parms->Temp)*(2*ran1(&idum)-1);  
//			   rw = (2*ran1(&idum)-1);  
//			   printf("%f\n", rw);
			   NNet->Nron[ii][j].w[ic] = NNet->Nron[ii][j].wold[ic] + rw ;
			}
			rw = Parms->Alpha*exp(-Parms->Beta/Parms->Temp)*(2*ran1(&idum)-1);
			NNet->Nron[ii][j].b = NNet->Nron[ii][j].bold + rw ;
//			printf("%12.11f\n", rw);
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   rw = Parms->Alpha*exp(-Parms->Beta/Parms->Temp)*(2*ran1(&idum)-1);
//			   rw = (2*ran1(&idum)-1);
//			   printf("%f\n", rw);
	           NNet->Nron[ii][j].w[ic] = NNet->Nron[ii][j].wold[ic] + rw ;
			}
			rw = Parms->Alpha*exp(-Parms->Beta/Parms->Temp)*(2*ran1(&idum)-1);
			NNet->Nron[ii][j].b = NNet->Nron[ii][j].bold + rw ;
//		printf("%12.11f\n", rw);
		 }
	  }
   }

}
