

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern NeuralNet  NNet; 
extern SETUP Parms;
extern Cntrl C;
extern Data TDat;


extern float OptFun(float *);

float OptFun(float *Weights)
{
   float FOM;

   
   
printf("O-W1=%.9f  W2=%.9f  W3=%.9f  W4=%.9f  \n",Weights[1],Weights[2],Weights[3],Weights[4]);

   FOM = sqr(Weights[1] - 1.1111111111111111) + sqr(Weights[2] + 2.2222222222222222222) + 
	     sqr(Weights[3] + 3.3333333333333333) + sqr(Weights[4] - 4.4444444444444444444); 

   
   return FOM;

}
