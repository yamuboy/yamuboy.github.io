

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

//#include "neuron.h"
//#include "protos.h"

extern void Set_Up_Neural_Network(NeuralNet *, SETUP *, Cntrl *);

void Set_Up_Neural_Network(NeuralNet *NNet, SETUP *Parms, Cntrl *C)
{
   int i, j, k;
   
   NNet->Nlayers = 0 ;
   for (i=0;i<=MAX_Layers;i++)
   {
      if (C->NNpl[i] != 0)  
	  {
	     NNet->Nlayers++ ;
	  }
   }
   NNet->Nlayers = NNet->Nlayers + 1;  /* Add output layer */
   
   
   printf("====================================================\n");
   printf("ALLOCATING memory for Structuring the Neural Network\n");
   printf("====================================================\n");
   printf("\n\n");
   printf("   There are %3d layers in the Network \n", NNet->Nlayers);
   

   NNet->Nl = ivector(1,NNet->Nlayers);
   NNet->Nmax = 0;
   j = 0;
   k = 0;
 
   printf("   There are %3d inputs to the Network.\n", NNet->Ni);
   
   if (C->NNpl[1] != 0) 
   {
	   NNet->Nl[1] = C->NNpl[1];
	   NNet->Nmax = C->NNpl[1];
	   j = j + C->NNpl[1] ;
	   k = k + 1;
	   printf("   There are %3d Neurons in HIDDEN layer %3d.\n", NNet->Nl[1], 1);
   }
   if (C->NNpl[2] != 0) 
   {
	   NNet->Nl[2] = C->NNpl[2];
	   if (C->NNpl[2]>NNet->Nmax) NNet->Nmax = C->NNpl[2];
	   j = j + C->NNpl[2];
	   k = k + 1;
	   printf("   There are %3d Neurons in HIDDEN layer %3d.\n", NNet->Nl[2], 2);
   }
   if (C->NNpl[3] != 0) 
   {
	   NNet->Nl[3] = C->NNpl[3];
	   if (C->NNpl[3]>NNet->Nmax) NNet->Nmax = C->NNpl[3];
	   j = j + C->NNpl[3];
	   k = k + 1;
	   printf("   There are %3d Neurons in HIDDEN layer %3d.\n", NNet->Nl[3], 3);
   }
   if (C->NNpl[4] != 0) 
   {
	   NNet->Nl[4] = C->NNpl[4];
	   if (C->NNpl[4]>NNet->Nmax) NNet->Nmax = C->NNpl[4];
	   j = j + C->NNpl[4];
	   k = k + 1;
	   printf("   There are %3d Neurons in HIDDEN layer %3d.\n", NNet->Nl[4], 4);
   }
   if (C->NNpl[5] != 0) 
   {
	   NNet->Nl[5] = C->NNpl[5];
	   if (C->NNpl[5]>NNet->Nmax) NNet->Nmax = C->NNpl[5];
	   j = j + C->NNpl[5];
	   k = k + 1;
	   printf("   There are %3d Neurons in HIDDEN layer %3d.\n", NNet->Nl[5], 5);
   }
   if (C->NNpl[6] != 0) 
   {
	   NNet->Nl[6] = C->NNpl[6];
	   if (C->NNpl[6]>NNet->Nmax) NNet->Nmax = C->NNpl[6];
	   j = j + C->NNpl[6];
	   k = k + 1;
	   printf("   There are %3d Neurons in HIDDEN layer %3d.\n", NNet->Nl[6], 6);
   }


   k = k + 1;
   NNet->Nl[k] = NNet->No;
   NNet->Total_Neurons = j + NNet->Nl[k];
   printf("   There are %3d Neurons in the output layer %3d.\n", NNet->Nl[k], k);

   printf("\n");
   printf("=====>  The most Neurons in any layer = %3d \n", NNet->Nmax);
   printf("=====>  The TOTAL number of Neurons is = %3d \n", NNet->Total_Neurons);
   printf("\n\n");
   
   printf("DONE ALLOCATING memory for Neural Network\n");
   printf("=========================================\n");

}
