

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern void free_Nmatrix(Neuron **, long , long , long , long );
extern double sigmoid(double , double);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);


void display_outputs(NeuralNet NNet, SETUP Parms)
{ 
   int i,j;

   printf("\n");
 
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
         if (Parms.DB == 2 || Parms.DB == 21)
		 {
		    printf("N[%2d][%2d].o = %6f\n", i,j, NNet.Nron[i][j].o); 
		 }
		 else if (Parms.DB == 22)
		 {
			printf("N[%2d][%2d].e = %6f\n", i,j, NNet.Nron[i][j].e); 
		 }
		 else if (Parms.DB == 23)
		 {
			printf("N[%2d][%2d].dode = %6f\n", i,j, NNet.Nron[i][j].dode); 
		 }
	  }
   }

}


