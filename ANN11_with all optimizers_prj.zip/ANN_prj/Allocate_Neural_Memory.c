

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

//#include "neuron.h"
//#include "protos.h"


extern Neuron **Nmatrix(long , long , long , long );
extern void Allocate_Neural_Memory(NeuralNet *, SETUP *, Cntrl *);

void Allocate_Neural_Memory(NeuralNet *NNet, SETUP *Parms, Cntrl *C)
{
   int ii,j,ic ;
   double rw ;

   printf("\n\n");
   printf("=============================================================================\n");
   printf("Allocating/Initializing memory for Weights and Outputs for the Neural Network\n");
   printf("=============================================================================\n");

   NNet->Nron = Nmatrix(1,NNet->Nlayers, 1,NNet->Nmax);
   for (ii=1; ii<=NNet->Nlayers; ii++)
   {
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
  	     NNet->Nron[ii][j].e = 0.001;
		 NNet->Nron[ii][j].o = 0.001;
		 NNet->Nron[ii][j].b = 0.25;
		 NNet->Nron[ii][j].bold = 0.25;
		 NNet->Nron[ii][j].btemp = 0.25;
		 if (ii>1)
		 {
	        NNet->Nron[ii][j].w = dvector(1,NNet->Nl[ii-1]);
			NNet->Nron[ii][j].wold = dvector(1,NNet->Nl[ii-1]);
			NNet->Nron[ii][j].wtemp = dvector(1,NNet->Nl[ii-1]);
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   rw = (double)rand()/32767;
	           NNet->Nron[ii][j].w[ic] = -8*rw;
			   NNet->Nron[ii][j].wold[ic] = zero;
			   NNet->Nron[ii][j].wtemp[ic] = zero;
			   NNet->Nron[ii][j].oerror = zero;
			}
		 }
	     else
		 {
            NNet->Nron[ii][j].w = dvector(1,NNet->Ni);
			NNet->Nron[ii][j].wold = dvector(1,NNet->Ni);
			NNet->Nron[ii][j].wtemp = dvector(1,NNet->Ni);
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   rw = (double)rand()/32767;
               NNet->Nron[ii][j].w[ic] = -8*rw;
			   NNet->Nron[ii][j].wold[ic] = zero;
			   NNet->Nron[ii][j].wtemp[ic] = zero;
			   NNet->Nron[ii][j].oerror = zero;
			}
		 }
	  }
   }
   printf("DONE Allocating/Initializing memory\n");
   printf("===================================\n");

}
