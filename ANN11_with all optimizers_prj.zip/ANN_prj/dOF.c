

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

extern void dOF(float *Weights, float *Derivitive);
extern float OptFun(float *);


extern NeuralNet  NNet; 
extern SETUP Parms;
extern Cntrl C;
extern Data TDat;


void dOF(float *Weights, float *Derivitive)
{
   float FOM, h = 0.00001, wsave;
   int i;
	

printf("D-p1=%.9f  p2=%.9f p3=%.9f  p4=%.9f\n", 
	   Weights[1],Weights[2],Weights[3],Weights[4]);

   Derivitive[1] = 2*(Weights[1] - 1.1111111111111111);
   Derivitive[2] = 2*(Weights[2] + 2.2222222222222222222);
   Derivitive[3] = 2*(Weights[3] + 3.3333333333333333);
   Derivitive[4] = 2*(Weights[4] - 4.4444444444444444444);
	   
}

