

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

//#include "neuron.h"
//#include "protos.h"

extern void Random_Initialization(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Random_Init_Weights(long *, NeuralNet *, SETUP *);
extern void Store_Weights(NeuralNet *);
extern void Update_Weights(NeuralNet *);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);

void Random_Initialization(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{
	long rgen;
	int iter, niter, ic, k ;
    double temp, ERRORold, MR = 8 ;

	iter       = 0;
	niter      = 0;
	NNet->Error = 1e9;

    printf("\n\n============ Randon Weight Inititalization ===========\n");
    niter = 0;
    temp = Parms->WF ;
	NNet->Error = 100e6 ;
	ERRORold = 1e9 ;
	while (niter < Parms->MRI)
	{
	  
       Parms->WF = 2*MR*(double)niter/(double)Parms->MRI - MR ;
	   Random_Init_Weights(&rgen, NNet, Parms);    

	   for (ic=1; ic<=TDat->NTsamples ; ic++)
	   {
		  Forward_Prop(ic, NNet, Parms, TDat);
          for (k=1; k<=NNet->Nl[NNet->Nlayers]; k++)
		  {		 
			 NNet->Error = NNet->Error + sqr(TDat->dR[ic][k] - NNet->Nron[NNet->Nlayers][k].o);
		  }
	   }

	   NNet->Error = NNet->Error/(TDat->NTsamples*NNet->No);
	   if (NNet->Error<ERRORold)
	   {
		   printf("RI:   Iteration: %6.6d of %6d   Initial Error: %14.12f \n",
			                        niter, Parms->MRI, NNet->Error);
		   ERRORold = NNet->Error ;
		   Store_Weights(NNet);
	   }
	   niter++ ;
    }
	Update_Weights(NNet);
	niter = 0;
	Parms->WF = temp ;

    printf("\n============ FINISHED Weight Inititalization ===========\n");

}
