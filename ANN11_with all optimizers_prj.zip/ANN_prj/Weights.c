

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"


extern void free_Nmatrix(Neuron **, long , long , long , long );
extern double sigmoid(double , double);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void display_weights(NeuralNet NNet);
extern void Temp_Weights(NeuralNet *);
extern void Update_Temp_Weights(NeuralNet *);

void Save_Weights_To_File(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{ 
   int i,j,ic;
   
   C->Output  = fopen(C->Wfile,WRITE);

   printf("\n\n");
   printf("=====>>> Saving all Neural synaptic weights to file: %s \n", C->Wfile);
   printf("\n");

   fprintf(C->Output, " %d %d %d %d ", NNet->Ni, NNet->No, NNet->Nlayers, NNet->Nmax);
   for (i=1 ; i<=NNet->Nlayers-1 ; i++)
   {
	   fprintf(C->Output, " %d ", NNet->Nl[i]);
   }
   fprintf(C->Output, " \n");
   
   for (i=1; i<=NNet->Nlayers; i++)
   {
      for (j=1; j<=NNet->Nl[i]; j++)
	  {
        fprintf(C->Output, "%d %d %12.10f\n", i, j, NNet->Nron[i][j].b);
        if (i>1)
		{
		   for (ic=1; ic<=NNet->Nl[i-1]; ic++)
		   {
//             fprintf(C->Output, "Layer = %d   Neuron = %d  Input = %d  Weight = %12.10f\n", 
//				                         i,j,ic, NNet->Nron[i][j].w[ic]); 
		      fprintf(C->Output, "%d %d %d %12.10f\n", i,j,ic, NNet->Nron[i][j].w[ic]);
		   }
		}
	    else
		{
		   for (ic=1; ic<=NNet->Ni; ic++)
		   {
// 	          fprintf(C->Output, "Layer = %d   Neuron = %d  Input = %d  Weight = %12.10f\n", 
//				                         i,j,ic, NNet->Nron[i][j].w[ic]); 
		      fprintf(C->Output, "%d %d %d %12.10f\n", i,j,ic, NNet->Nron[i][j].w[ic]); 
		   }
		}
	  }
   }

   fclose(C->Output);

}


void display_weights(NeuralNet NNet)
{ 
   int i,j,ic;

   
   printf("\n\n");
   printf("=======================================\n");
   printf("Displaying all Neural synaptic weights\n");
   printf("=======================================\n");

   printf("\n");
   
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
		printf("N[%2d][%2d].b = %6f\n", i, j, NNet.Nron[i][j].b); 
        if (i>1)
		{
		   for (ic=1; ic<=NNet.Nl[i-1]; ic++)
		   {
             printf("N[%2d][%2d].W[%2d] = %6f\n", i,j,ic, NNet.Nron[i][j].w[ic]); 
		   }
		}
	    else
		{
		   for (ic=1; ic<=NNet.Ni; ic++)
		   {
 	          printf("N[%2d][%2d].W[%2d] = %6f\n", i,j,ic, NNet.Nron[i][j].w[ic]); 
		   }
		}
	  }
   }
}



void Random_Init_Weights(long *rg, NeuralNet *NNet, SETUP *Parms)
{ 
   int ii, j, ic ;
   double rn, rw, rs ;
   long rgen = *rg;

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		 rn = (double)rand();
		 rs = 1;
		 if (rn<0.5*32767) rs = -1 ;
         rw = Parms->WF*rs*(double)rand()/32767;
		 NNet->Nron[ii][j].b = rw ;
		 if (ii>1)
		 {
	        for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
//			   rn = ran1(&rgen)-0.5;
//			   rw = Parms->WF*rs*ran1(&rgen);
               rn = (double)rand();
			   rs = 1;
			   if (rn<0.5*32767) rs = -1 ;
			   rw = Parms->WF*rs*(double)rand()/32767;
			   NNet->Nron[ii][j].w[ic] = rw ;
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
//			   rn = ran1(&rgen)-0.5;
//			   rw = Parms->WF*rs*ran1(&rgen);
			   rn = (double)rand();
			   rs = 1;
			   if (rn<0.5*32767) rs = -1 ;
			   rw = Parms->WF*rs*(double)rand()/32767;
	           NNet->Nron[ii][j].w[ic] = rw ;
			}
		 }
	  }
   }
   rg = &rgen;
}


void Store_Weights(NeuralNet *NNet)
{
   int j,ii,ic;	

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {   
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		 NNet->Nron[ii][j].bold = NNet->Nron[ii][j].b;
  	     if (ii>1)
		 {
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   NNet->Nron[ii][j].wold[ic] = NNet->Nron[ii][j].w[ic];
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   NNet->Nron[ii][j].wold[ic] = NNet->Nron[ii][j].w[ic];
			}
		 }
	  }
   }
}


void Update_Weights(NeuralNet *NNet)
{
   int j,ii,ic;	

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {   
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		 NNet->Nron[ii][j].b = NNet->Nron[ii][j].bold;
  	     if (ii>1)
		 {
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   NNet->Nron[ii][j].w[ic] = NNet->Nron[ii][j].wold[ic];
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   NNet->Nron[ii][j].w[ic] = NNet->Nron[ii][j].wold[ic];
			}
		 }
	  }
   }
}




void Temp_Weights(NeuralNet *NNet)
{
   int j,ii,ic;	

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {   
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		 NNet->Nron[ii][j].btemp = NNet->Nron[ii][j].b;
  	     if (ii>1)
		 {
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   NNet->Nron[ii][j].wtemp[ic] = NNet->Nron[ii][j].w[ic];
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   NNet->Nron[ii][j].wtemp[ic] = NNet->Nron[ii][j].w[ic];
			}
		 }
	  }
   }
}



void Update_Temp_Weights(NeuralNet *NNet)
{
   int j,ii,ic;	

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {   
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		 NNet->Nron[ii][j].bold = NNet->Nron[ii][j].btemp;
  	     if (ii>1)
		 {
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   NNet->Nron[ii][j].wold[ic] = NNet->Nron[ii][j].wtemp[ic];
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   NNet->Nron[ii][j].wold[ic] = NNet->Nron[ii][j].wtemp[ic];
			}
		 }
	  }
   }
}

