
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "file.h"
#include "nrutil.h"

extern void Compute_Error(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);

void Compute_Error(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{
	int ic, k ;

	for (ic=1; ic<=TDat->NTsamples ; ic++)
	{
       Forward_Prop(ic, NNet, Parms, TDat);
	   for (k=1; k<=NNet->Nl[NNet->Nlayers]; k++)
	   {		 
	      NNet->Error = NNet->Error + sqr(TDat->dR[ic][k] - NNet->Nron[NNet->Nlayers][k].o);
	   }
	}
       
	NNet->Error = NNet->Error/(TDat->NTsamples*NNet->No);

}
