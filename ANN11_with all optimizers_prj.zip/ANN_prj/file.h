#ifndef _FILE_H_
#define _FILE_H_

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>

#define DMIN(a,b) ((a) < (b) ? (a) : (b))
#define FMAX(a,b) ((a) > (b) ? (a) : (b))
#define FMIN(a,b) ((a) < (b) ? (a) : (b))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))

#define MAX_LINE_LEN 2048 
#define MAX_NAME_LEN 2048
#define READ   "rt"    
#define WRITE  "wt"    
#define APPEND "a"
#define NOT_IN_WORD     0  
#define IN_WORD         1
#define MAXLINELEN    500
#define MAXLINELENGTH 500
#define TRUE 1
#define FALSE 0
#define T 1
#define F 0
#define sqr(x) ((x)*(x))
#define piang 0.01745329252

extern int getline (FILE *, char *, const int );
extern int count_words(char ,char *,int );
extern int count_words_o(char *,int );
extern int search_string(char *, char *);
extern void uppercase(char *);
extern void get_word(char , char *, int , int , char *);
extern void get_word_o(     char *, int , int , char *);
extern int skip_comment_lines(FILE *, char *, int );
extern int copy_file(char *, char *);
extern int append_file(char *, char *);
extern FILE *open_file(char *, char *); 
extern void remove_commas (char *, int );
extern double round(double);

#endif
