#!/usr/bin/env python

import math
import instrument
from datetime import datetime
from instrument import timed_wait_ms

DEFAULT_CONFIGFILE = 'gan_finger_iv.cfg'

def main(cfgfname=DEFAULT_CONFIGFILE,fname=''):
    "entry point"
    # try to read the configuration
    cfg = _default_config()
    try:
        data = {'arange':arange} 
        execfile(cfgfname,data)
        del data['__builtins__']
        del data['arange']
        cfg.update(data)
        print "read config options from: '%s'"%cfgfname
    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no config file, using default options"
        else:
            raise
        
    # try to open instruments
    gate = instrument.create('bias',*(cfg['gate_smu'][:2]),**(cfg['gate_smu'][2]))
    drain = instrument.create('bias',*(cfg['drain_smu'][:2]),**(cfg['drain_smu'][2]))
    
    try:
        try:
            run(cfg,gate,drain,fname)
        except KeyboardInterrupt:
            print "aborted"
    finally:
        timed_wait_ms(50)
        drain.config(state=0)
        drain.close()
        timed_wait_ms(50)
        gate.config(state=0)
        gate.close()
        

def run(cfg,gate,drain,fname):
    "run test"
    
    # ask for a file name
    while not fname:
        fname = raw_input('Output file name? ').strip()
    
    # open the file and run the test modules
    fp = open(fname,'w')
    try:
        fp.write('! GaN Single Finger I-V Measurement\n')
        fp.write('!\n')
        fp.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
        fp.write('!\n')
        fp.write('! Settings:\n')
        for k in('ngf','ugw','gate_ilimit_mamm','drain_ilimit_mamm'):
            fp.write('!    %s = %s\n'%(k,repr(cfg[k])))
        fp.write('!\n')
        
        fp.write("!Vds\tIds\tVgs\tIgs\n")
    
        periph = cfg['ugw']*cfg['ngf']
        vlist = cfg['v_list']

        nsweeps = 1
        if cfg['multi_sweep']:
            nsweeps = int(cfg['multi_sweep'])
    
        for x in range(nsweeps):
            drain.config(mode='V',vset=0.0,state=1,ilimit=cfg['drain_ilimit_mamm']*periph*1.0e-6,resolution='high',remote=True)
            timed_wait_ms(50)    
            gate.config(mode='V',vset=0.0,state=1,ilimit=cfg['gate_ilimit_mamm']*periph*1.0e-6,resolution='high',remote=True)

            for v in vlist:
                drain.config(vset=v)
                timed_wait_ms(50)    
                gate.config(vset=v)
                timed_wait_ms(cfg['meas_delay_ms'])
                fp.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(v,drain.measure(),v,gate.measure()))
                fp.flush()
    
            gate.set_state(0)
            timed_wait_ms(50)    
            drain.set_state(0)

            fp.write('\n')
            fp.flush()

        
    finally:
        fp.close()

def _default_config():
    "default configuration"
    
    cfg = {}
    cfg['ngf'] = 4
    cfg['ugw'] = 50.0
    cfg['gate_ilimit_mamm'] = 1.0
    cfg['drain_ilimit_mamm'] = 1000.0

    cfg['meas_delay_ms'] = 100

    cfg['v_list'] = arange(0.2,2.0,0.05) 

    cfg['gate_smu'] = ('b2902','GPIB::22',{'chan':1})
    cfg['drain_smu'] = ('b2902','GPIB::22',{'chan':2})

    cfg['multi_sweep'] = 0

    return cfg

def arange(start,stop,step=1.0):
    "compute a range of values returned as a list"    
    if start == stop:
        return [start]
        
    if start > stop and step > 0.0:
        raise ValueError("'start' > 'stop' with 'step' > 0.0 is not possible")    
    elif start < stop and step < 0.0:
        raise ValueError("'start' < 'stop' with 'step' < 0.0 is not possible")
    
    if step == 0.0:
        raise ValueError("'step' cannot be 0.0")
    
    v = start
    ret = []
    if step < 0.0:
        while v > stop:
            ret.append(v)
            v += step
    else:
        while v < stop:
            ret.append(v)
            v += step
    
    return ret


if __name__ == '__main__':
    import optparse, sys
    p = optparse.OptionParser(usage='USAGE: %prog [-c CONFIGFILE] [OUTFILE]')
    p.add_option('-c','--cfg',metavar='FILE',dest='cfg',help='config file path')
    
    opts, args = p.parse_args()
    kw = {}
    if opts.cfg:
        kw['cfgfname'] = opts.cfg
    
    if len(args) == 1:
        kw['fname'] = args[0]
    elif len(args) > 1:
        p.print_usage()
        sys.exit(1)        
    
    main(**kw)
