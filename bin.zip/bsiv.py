#!/usr/bin/env python

import os.path
import datetime
#from instrument.manager import InstrumentManager
import instrument
import time
from instrument.family.bias import BiasInstrument
from instrument.utils import timed_wait_ms
#from modeling.configfile import ConfigVars, ConfigFile
#from modeling.configtypes import *
from optparse import OptionParser
import numpy as np


INSTR = {
    #'bias1':['k23x','GPIB::21',{'remote':True,'resolution':'high'}],
    #'bias2':['k23x','GPIB::23',{'remote':True,'resolution':'high'}],
    'bias1':['b2902','GPIB::22',{'chan':1}],
    'bias2':['b2902','GPIB::22',{'chan':2}],
    'prober':['12k','GPIB::28',{}],
    #'siggen':['SCPISigGen','GPIB::20',{}],
}


# set a delay time in the measurement
delay_time = 100

def load_config(fname):
    data = {}
    execfile(fname,data)
    del data['__builtins__']
    return data
 
"""
def load_config( name ):
    Load config data from a file.
    cv = ConfigVars()
    cv.add('gate_voltages', CF_FLOATTUPLE)
    cv.add('drain_voltages', CF_FLOATTUPLE)
    cv.add('drain_voltage_range', CF_FLOATTUPLE)
    cv.add('gate_voltage_range', CF_FLOATTUPLE)
    cv.add('backside_voltages', CF_FLOATTUPLE)
    cv.add('power_limit', CF_FLOAT, default=1000.0)
    cv.add('gate_ilimit', CF_FLOAT, default=1.0)
    cv.add('drain_ilimit', CF_FLOAT, default=1.0)
    cv.add('sweep_order', CF_TUPLE, default=('g','d'))
    cv.add('output_format')
    
    cf = ConfigFile()
    cf.read(name)
    return cf.get_variables(cv)
"""

def _get_voltages(d):
    """Create a voltage list."""
    assert len(d) == 3
    return np.arange(d[0],d[1]+0.1*d[2],d[2])
    
def main( cfg=None ):
    """Main routine."""
    
    if cfg is not None:
        if isinstance(cfg,str):
            # cfg is an argument specifying the config file name
            cdata = load_config(cfg)
        else:
            # config data passed in
            cdata = cfg
    else:
        # try to load the config from the default config file locations
        cdata = load_config('ivconfig.cfg')
    
    # figure out the voltages, ranges override configured sweep points
    if len(cdata['gate_voltage_range']):
        cdata['gate_voltages'] = _get_voltages(cdata['gate_voltage_range'])
    if len(cdata['drain_voltage_range']):
        cdata['drain_voltages'] = _get_voltages(cdata['drain_voltage_range'])
    
    # read in the name for the data file
    dfile = raw_input("Enter a file name for the data: ")
    if os.path.exists(dfile):
        print "Warning: file '%s' exists." % dfile
        answer = raw_input("Overwrite the existing file? (y/N): ")
        if answer.strip().lower() != 'y':
            print "Exiting."
            return
    
    # open the file and write the header
    f = open(dfile, "w")
    f.write( "! Custom I-V Measurement Program\n!\n" )
    f.write( "! Date/Time: %s\n" % datetime.datetime.now().isoformat(' ') )
    f.write( "!\n" )
    
    # start the test
    try:
        run_test(cdata, f)
        print "Done."
    except Exception:
        import traceback
        traceback.print_exc()
        print "Exiting."
    finally:
        f.close()
    
def run_test( config, f ):
    """Run the test routine."""
    # load and init instruments
    # hard-coded
    #manager = InstrumentManager()
    #driver = manager.get_driver(BiasInstrument,'keithley236')
    sgate = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    sdrain = instrument.create('bias',*(INSTR['bias2'][:2]),**(INSTR['bias2'][2]))
    #kth_keywords = {'averaging':32,'integration':'linecycle','sensing':'local'}
    #sgate = driver('GPIB::21')
    #sdrain = driver('GPIB::23')
    #sgate.config(**kth_keywords)
    #sdrain.config(**kth_keywords)
    ilist = [sgate,sdrain]
    
    if 'backside_voltages' in config:
        do_backgate = bool(len(config['backside_voltages']))
    else:
        do_backgate = False
    
    if do_backgate:
        sback = driver('GPIB::24')
        sback.config(**kth_keywords)
        ilist.insert(0,sback)
    
    #for instr in ilist:
    #    instr.init()
    
    # start looping through backside voltages
    try:
        if do_backgate:
            for bsv in config['backside_voltages']:
                # set and turn on the backside voltage source
                sback.set_source(bsv)
                sback.set_state(1)
                sback.measure()
         
                print "========= V_back = %f =========" % bsv
                # capture the I-V curves of the device
                capture_iv_curve( config, f, sgate, sdrain, sback )
        else:
            capture_iv_curve( config, f, sgate, sdrain, None )
    finally:
        # close all sources (turns them off in the process)
        for instr in reversed(ilist):
            instr.close()
        f.close()
        
    

def capture_iv_curve( config, f, sgate, sdrain, sback ):
    """Capture a set of I-V data from the device."""
    
    # set the initial gate and drain current limits
    sgate.config( mode='v',ilimit=config['gate_ilimit'], remote=True, resolution='high' )
    ilim= config['drain_ilimit']
    sdrain.config( mode='v',ilimit=config['drain_ilimit'], remote=True, resolution='high' )
    power_limit = config['power_limit']
    
    order = config['sweep_order']

    if 'output_format' in config:
        output_format = 'mdif'
    else:
        output_format = 'text'

    def _inner(first):
        # set the power/current limit
        dv2 = abs(dv) + 0.001
        ilimp = power_limit / dv2
        ilim2 = ilim
        if ilimp < ilim: ilim2 = ilimp
        
        # set the voltages
        sgate.config(vset=gv)
        sdrain.config(vset=dv,ilimit=ilim2)
        
        if first:
            # turn on the supplies
            sgate.config(state=1)
            timed_wait_ms(50)
            sdrain.config(state=1)
            timed_wait_ms(50)
	    

            # write the header
            if output_format == 'mdif': 
                f.write( "!\n" )
                if sback is not None:
                    f.write( "VAR Vbs(1) = %f\n" % sback.get_source() )
                f.write( "VAR Vgs(1) = %f\n" % gv )
                f.write( "BEGIN TESTDATA\n" )
                f.write( "%   Vds(1)     Ids(1)    Igs(1)\n" )
            else:
                f.write( "!\n" )
                if sback is not None:
                    f.write( "! Vbs = %f\n" % sback.get_source() )                    
                f.write("! Vds\tIds\tVgs\tIgs\n")
                
        timed_wait_ms(delay_time)
        # measure the currents
        gc = sgate.measure()
        dc = sdrain.measure()
        
        # check for limiting conditions
        if sgate.ask_if_limiting():
            return
        if sdrain.ask_if_limiting():
            raise StopIteration
        
        # write the data
        if output_format == 'mdif': 
            f.write( "%.3e\t%.3e\t%.3e\n" % (dv,dc,gc) )
        else:
            f.write( "%.3e\t%.3e\t%.3e\t%.3e\n" % (dv,dc,gv,gc) )
                
                
    if order[0].lower()[0] == 'g':
        for gv in config['gate_voltages']:
            first=True
            print "Vgs = %f" % gv
            for dv in config['drain_voltages']:
                try:
                    _inner(first)
                except StopIteration:
                    break
                first=False
            
            
            sdrain.config(state=0)
            sgate.config(state=0)

            if config['output_format'].lower() == 'mdif': 
                f.write("END\n")
    else:
        for dv in config['drain_voltages']:
            first=True
            print "Vds = %f" % dv
            for gv in config['gate_voltages']:
                try:
                    _inner(first)
                except StopIteration:
                    break
                first=False
            
            sdrain.config(state=0)
            sgate.config(state=0)
            
            
            
            if output_format == 'mdif': 
                f.write("END\n")
    
    
if __name__ == '__main__':
    
    parser = OptionParser()
    parser.add_option("-f", "--file", dest="filename", help="Read configiguration from FILE", metavar="FILE")
    opts,args = parser.parse_args()
    fname = opts.filename
    
    # run the main routine
    print "Config file:",fname
    main(fname)




    
