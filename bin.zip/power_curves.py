#!/usr/bin/env python

from matplotlib.figure import Figure
from maplot import NoMorePages, plot_gui
import sys 
import numpy as np

stylelist = ('r-','b-','g-','c-','m-','r.','b.','g.','c.','m.','r--','b--','g--','c--','m--',)

class PowerPager(object):
    
    def __init__(self, files=None):
        "initialize"
        self._data = []
        
        if files is not None:
            for fname in files:
                self.add_file(fname)
    
    def add_file(self, fname):
        "read a power data file and add it to the dataset"
        legend_name = fname
        
        fp = open(fname,'r')
        pin, pout, gain, iout, iin = [], [], [], [], []
        vout, vin = None, None
        try:
            for line in fp:
                if line.startswith('!'):
                    continue
                
                try:
                    vals = map(float,line.split())
                    if len(vals) < 7:
                        raise ValueError()
                    if vout is None:
                        vout, vin = vals[3], vals[5]
                    pin.append(vals[0])
                    pout.append(vals[1])
                    gain.append(vals[2])
                    iout.append(vals[4])
                    iin.append(vals[6])
                except Exception:
                    pass
        finally:
            fp.close()
        
        self._data.append({'pout':pout,'pin':pin,'gain':gain,'iout':iout,'iin':iin,'vout':vout,'vin':vin,'label':legend_name})
    
    def init_pages(self, figure):
        "draw the first page"
        self.__i = 0
        self._plot(figure)
        
    def next_page(self, figure):
        "draw the next page"
        i = self.__i + 1
        if i > 3:
            raise NoMorePages()
        self.__i = i
        self._plot(figure)
        
    def prev_page(self, figure):
        "draw the previous page"
        i = self.__i - 1
        if i < 0:
            raise NoMorePages()
        self.__i = i
        self._plot(figure)
        
    def toggle_smith(self,figure):
        pass 
        
    def _plot(self, figure):
        "draw the plot"
        yvar = None
        yscalefact = 1.0
        if self.__i == 0:
            # power
            yvar = 'pout'
            ylabel = 'P-out (dBm)'
            title = 'P-out vs. P-in'
        elif self.__i == 1:
            # gain
            yvar = 'gain'
            ylabel = 'Gain (dB)'
            title = 'Gain vs. P-in'
        elif self.__i == 2:
            # I-out
            yvar = 'iout'
            ylabel = 'I-out (mA)'
            yscalefact = 1000.0
            title = 'I-out vs. P-in'
        elif self.__i == 3:
            # I-in
            yvar = 'iin'
            ylabel = 'I-in (mA)'
            yscalefact = 1000.0
            title = 'I-in vs. P-in'
        else:
            raise ValueError("inconsistent internal state")
            
        # clear the figure and re-generate the axes
        figure.clf()
        ax = figure.add_axes([0.15,0.15,0.7,0.7])
        
        # add the data
        for i,d in enumerate(self._data):
            yvals = np.array(d[yvar])*yscalefact
            ax.plot(d['pin'],yvals,stylelist[i],label=d['label'])
        
        # set axes properties
        ax.legend(loc='best')
        ax.grid(True)
        ax.set_xlabel('P-in (dBm)')
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        

if __name__ == '__main__':
    # entry point for direct invocation
    
    files = sys.argv[1:]
    if not len(files):
        print "USAGE: %s power_file [power_file2 ...]"%sys.argv[0]
        sys.exit(1)
    
    # read files into the pager object
    pager = PowerPager(files)
    
    # start the gui using the base matplotlib Figure object
    plot_gui(Figure(),pager)
    
