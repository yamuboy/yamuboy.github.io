#!/usr/bin/env python

import math
import instrument
from datetime import datetime
from instrument import timed_wait_ms

DEFAULT_CONFIGFILE = 'gan_downpoint.cfg'

def main(cfgfname=DEFAULT_CONFIGFILE,fname=''):
    "entry point"
    # try to read the configuration
    cfg = _default_config()
    try:
        data = {'arange':arange} 
        execfile(cfgfname,data)
        del data['__builtins__']
        del data['arange']
        cfg.update(data)
        print "read config options from: '%s'"%cfgfname
    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no config file, using default options"
        else:
            raise
        
    maxdrain = [ max(cfg['leakage_drain_voltages']) ]
    maxdrain.append( cfg['txfr_drain_voltage'] )
    maxdrain.append( max(cfg['iv_drain_voltages']) )
    maxv = max(maxdrain)
    if maxv > 30.0:
        print "WARNING ***********************************************"
        print "WARNING: maximum drain voltage for this test is %g volts"%maxv
        print "WARNING: ensure that the bias tees can handle this voltage"
        print "WARNING ***********************************************"
        print ""
        r = raw_input("press enter to continue or ctrl-C to quit")

    # try to open instruments
    gate = instrument.create('bias',*(cfg['gate_smu'][:2]),**(cfg['gate_smu'][2]))
    drain = instrument.create('bias',*(cfg['drain_smu'][:2]),**(cfg['drain_smu'][2]))
    
    try:
        try:
            run(cfg,gate,drain,fname)
        except KeyboardInterrupt:
            print "aborted"
    finally:
        timed_wait_ms(50)
        drain.config(state=0)
        drain.close()
        timed_wait_ms(50)
        gate.config(state=0)
        gate.close()
        

def run(cfg,gate,drain,fname):
    "run test"
    
    # ask for a file name
    while not fname:
        fname = raw_input('Output file name? ').strip()
    
    # open the file and run the test modules
    fp = open(fname,'w')
    try:
        fp.write('! GaN Downpoint Test\n')
        fp.write('!\n')
        fp.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
        fp.write('!\n')
        fp.write('! Settings:\n')
        for k in('ngf','ugw','gate_ilimit_mamm','drain_ilimit_mamm','power_limit_wmm','fwd_ig_mamm','gate_vlimit',):
            fp.write('!    %s = %s\n'%(k,repr(cfg[k])))
        fp.write('!\n')
        
	fwd_curve(cfg,fp,gate,drain)      

        
    finally:
        fp.close()

def _default_config():
    "default configuration"
    
    cfg = {}
    cfg['ngf'] = 4
    cfg['ugw'] = 50.0
    cfg['gate_ilimit_mamm'] = 1.0
    cfg['drain_ilimit_mamm'] = 1000.0
    cfg['power_limit_wmm'] = 4.0
    cfg['iv_gate_voltages'] = arange(-3.0,2.1,0.25)
    cfg['iv_drain_voltages'] = arange(0.0,1.05,0.1)+arange(1.25,4.1,0.25)+arange(5.0,28.1,1.0)
    cfg['iv_meas_delay_ms'] = 50

    cfg['fwd_ig_mamm'] = 10.0
    cfg['gate_vlimit'] = 3.0
    cfg['fwd_orders'] = 6
    cfg['fwd_pts_per_order'] = 5
    cfg['fwd_meas_delay_ms'] = 50

    cfg['leakage_gate_voltage'] = -8.0
    cfg['leakage_drain_voltages'] = arange(0.0,70.1,1.0)
    cfg['leakage_meas_delay_ms'] = 100
    
    cfg['txfr_drain_voltage'] = 10.0
    cfg['txfr_gate_voltages'] = arange(-3.0,2.05,0.1)
    
    cfg['gate_smu'] = ('b2902','GPIB::22',{'chan':1})
    cfg['drain_smu'] = ('b2902','GPIB::22',{'chan':2})

    return cfg

def arange(start,stop,step=1.0):
    "compute a range of values returned as a list"    
    if start == stop:
        return [start]
        
    if start > stop and step > 0.0:
        raise ValueError("'start' > 'stop' with 'step' > 0.0 is not possible")    
    elif start < stop and step < 0.0:
        raise ValueError("'start' < 'stop' with 'step' < 0.0 is not possible")
    
    if step == 0.0:
        raise ValueError("'step' cannot be 0.0")
    
    v = start
    ret = []
    while v < stop:
        ret.append(v)
        v += step
    
    return ret


def fwd_curve( cfg, fp, sgate, sdrain ):
    "capture the forward I-V curve of the device"
    fp.write("! *********** Forward I-V ***********\n")
    fp.write("!\n")
    fp.write("!Vds\tIds\tVgs\tIgs\n")
    
    periph = cfg['ugw']*cfg['ngf']
    igmax = cfg['fwd_ig_mamm']*periph*1.0e-6
    idlim = igmax*4.0
    
    sdrain.config(mode='V',vset=0.0,state=1,ilimit=idlim,resolution='high',remote=True)
    timed_wait_ms(50)
    sgate.config(mode='I',iset=0.0,state=1,vlimit=cfg['gate_vlimit'],resolution='high',remote=True)
    
    stop = math.log10(igmax)
    start = math.log10(igmax*(10.0**(-cfg['fwd_orders'])))
    step = 1.0 / float(cfg['fwd_pts_per_order'])
    
    # set the initial SMU range
    current_range = (10.0**start)*100.0
    sgate.config(irange=current_range)    
    
    v = start
    while v < (stop + 0.1*step):
        igs = 10.0**v
        # check for range changes
        if igs > current_range:
            current_range *= 100.0
            sgate.config(irange=current_range)    
    
        sgate.config(iset=igs)
        timed_wait_ms(cfg['fwd_meas_delay_ms'])
        vg = sgate.measure()
        ids = sdrain.measure()
        
        fp.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(0.0,ids,vg,igs))
        fp.flush()
        v += step
    
    sgate.set_state(0)
    timed_wait_ms(50)    
    sdrain.set_state(0)
    fp.write('\n\n')

if __name__ == '__main__':
    import optparse, sys
    p = optparse.OptionParser(usage='USAGE: %prog [-c CONFIGFILE] [OUTFILE]')
    p.add_option('-c','--cfg',metavar='FILE',dest='cfg',help='config file path')
    
    opts, args = p.parse_args()
    kw = {}
    if opts.cfg:
        kw['cfgfname'] = opts.cfg
    
    if len(args) == 1:
        kw['fname'] = args[0]
    elif len(args) > 1:
        p.print_usage()
        sys.exit(1)        
    
    main(**kw)
