#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function

from modeling import load_config
from modeling.fet.extract.ssplot import plot_generator
import logging
from maplot import plot_gui, plot_report
import sys
import optparse

# create an option parser
p = optparse.OptionParser(usage="%prog [options] [s2pfile s2pfile ...]")

p.add_option('-l','--legacy','--oldstyle',action='store_true',dest='oldstyle',default=False,help='run the plots/report in legacy mode to support the C++ modeling tools')
p.add_option('-r','--report',action='store_true',dest='report',default=False,help='generate a model report rather than running in interactive mode')
p.add_option('-m','--report-mode',dest='reportmode',metavar='MODE',help="set the report mode to MODE, this must be one of 'pdf', 'ps', 'png', or 'bmp'")
p.add_option('-o','--out','--output',dest='outfile',metavar='FILE',help='set the file name for the model report to FILE')
p.add_option('-q','--quiet',action='store_true',dest='quiet',default=False,help='suppress most output (everything but errors)')

opts, filelist = p.parse_args()

if sys.platform == 'win32':
    # account for Windows' lack of a useful shell
    import glob
    fn2 = []
    for f in filelist:
        fn2.extend(glob.glob(f))
    filelist = fn2

if not len(filelist):
    if opts.oldstyle:
        p.print_usage()
        sys.exit(1)
    filelist = None
    
kw = {}

# set up logging
if opts.quiet:
    logging.basicConfig(level=logging.ERROR,format='%(levelname)s: %(message)s')
else:
    logging.basicConfig(level=logging.INFO,format='%(levelname)s: %(message)s')

# handle legacy mode
if opts.oldstyle:
    kw['old_style'] = True
else:
    # try to load the FET model configuration file
    try:
        load_config('fetmod.cfg')
    except Exception:
        # pass on failures
        logging.warning("unable to read 'fetmod.cfg'")
        pass

# create the plot window and pager
fig, pager = plot_generator(filelist,**kw)

if opts.report:
    # run in report mode
    k2 = {'orientation':'landscape'}
    if opts.outfile:
        k2['fname'] = opts.outfile
    
    if opts.reportmode:
        m = opts.reportmode.lower().strip('"\'.')
        k2['mode'] = m
    
    plot_report(fig,pager=pager,**k2)
else:
    # run in interactive mode
    pager.key_bindings = (
        ('d',pager.delete_model),
        )

    plot_gui(fig,pager=pager)

