#!/usr/bin/env python2.6

from modeling.mct_files import mdif_cl
mdif_cl()

