#!/usr/bin/env python
import os
from datetime import datetime
import math
import time

import visa

### instrument configuration ###
instrcfg = {
        'vnaaddr': 'GPIB::16',   # VNA address
        'vnachan': 1,            # VNA channel
        'vg1addr': 'GPIB::21',   # gate 1 bias address
        'vg1type': 'k23x',       # gate 1 bias instrument type
        'vg2addr': 'GPIB::23',   # gate 2 bias address
        'vg2type': 'k23x',       # gate 2 bias instrument type
        'vd1addr': 'GPIB::10',    # drain 1 bias address
        'vd1type': 'hp662x:1',   # drain 1 bias instrument type
        'vd2addr': 'GPIB::10',    # drain 2 bias address
        'vd2type': 'hp662x:2',   # drain 2 bias instrument type
    }

### test configuration ###
testcfg = {
        'vg1init': -4.0,         # gate 1 initial bias voltage
        'vg2init': -4.0,         # gate 2 initial bias voltage
        'vd1init': 5.0,          # drain 1 initial bias voltage
        'vd2init': 5.0,          # drain 2 initial bias voltage
        'ig1limit': 10.0e-3,     # gate 1 current limit
        'ig2limit': 10.0e-3,     # gate 2 current limit
        'id1limit': 500.0e-3,    # drain 1 current limit
        'id2limit': 800.0e-3,   # drain 2 current limit
        'id1initmax': 1.0e-3,    # drain 1 initial bias max value (check for short circuit)
        'id2initmax': 2.0e-3,    # drain 2 initial bias max value (check for short circuit)
        'vg1cstep': 0.15,        # gate 1 course step size
        'vg1fstep': 0.01,        # gate 2 course step size
        'vg2cstep': 0.15,        # gate 1 fine step size
        'vg2fstep': 0.01,        # gate 2 fine step size
        'spflo': 3.9e9,          # low frequency for S-param gate verification
        'spfhi': 4.1e9,          # hi frequency for S-param gate verification
        'mingain': 5.0,          # minimum linear gain for S-param check 
    }

### bias configurations for S-parameter measurements ###
sparams_bias = (
        #(vg1init,vg1max,vg2init,vg2max,vd1,vd2,id1target,id2target),
        (-4.0,0.0,-4.0,0.0,5.0,5.0,333.0e-3,666.0e-3),
        (-4.0,0.0,-4.0,0.0,8.0,8.0,208.0e-3,416.0e-3),
        (-4.0,0.0,-4.0,0.0,10.0,10.0,166.0e-3,333.0e-3),
        #(-4.0,0.0,-4.0,0.0,3.0,3.0,600.0e-3,1520.0e-3),
    )


def main():
    """Main entry point."""
    try:
        while True:
            # ask for the site name
            site = raw_input("Enter a site name (Ctrl-C to quit)> ").strip()
            if len(site):
                run_site(site)
    except (KeyboardInterrupt,EOFError):
        print
        print "Goodbye."
    
def run_site( site_name ):
    """Run the test for 1 site."""
    
    # create a file name
    fname = "d%s.dat" % site_name
    
    # open the output file and write a header
    f = open(fname,'w')
    f.write('!WORKING DIR: %s\n!SITE: %s\n!TIMESTAMP: %s\n!\n' % (os.getcwd(),site_name,datetime.now().strftime('%m/%d/%y %H:%M:%S')) )
    
    ### Step 1 - open instruments ###
    print "Opening instruments ..."
    vna = PNA( visa.instrument(instrcfg['vnaaddr'], values_format = visa.double), instrcfg['vnachan'] )
    bg1 = _open_bias( instrcfg['vg1addr'], instrcfg['vg1type'] )
    bg2 = _open_bias( instrcfg['vg2addr'], instrcfg['vg2type'] )
    bd1 = _open_bias( instrcfg['vd1addr'], instrcfg['vd1type'] )
    bd2 = _open_bias( instrcfg['vd2addr'], instrcfg['vd2type'] )
    allinstr = (vna,bg1,bg2,bd1,bd2)
    
    ### Step 2 - set initial gate and drain biases ###
    print "Setting initial bias ..."
    bg1.set_v( testcfg['vg1init'], testcfg['ig1limit'] )
    bg2.set_v( testcfg['vg2init'], testcfg['ig2limit'] )
    bd1.set_v( testcfg['vd1init'], testcfg['id1limit'] )
    bd2.set_v( testcfg['vd2init'], testcfg['id2limit'] )
    
    bg1.on()
    bg2.on()
    wait_ms(100)
    bd1.on()
    bd2.on()
    wait_ms(1000)
    ig1, ig2 = bg1.read_i(), bg2.read_i()
    id1, id2 = bd1.read_i(), bd2.read_i()
    
    ### Step 3 - check for shorted/leaky biases and then ###
    ###   loop through the S-parameter bias conditions   ###
    try:
        # check for shorts
        if id1 > testcfg['id1initmax']:
            raise RuntimeError("Drain 1 appears to be shorted.")
        if id2 > testcfg['id2initmax']:
            raise RuntimeError("Drain 2 appears to be shorted.")
        if abs(ig1-testcfg['ig1limit']) < 0.01*testcfg['ig1limit']:
            raise RuntimeError("Gate 1 appears to be shorted.")
        if abs(ig2-testcfg['ig2limit']) < 0.01*testcfg['ig2limit']:
            raise RuntimeError("Gate 1 appears to be shorted.")
        
        # start the S-param loop
        for i,d in enumerate(sparams_bias):
            print "Bias %d ..." % (i+1)
            if not i:
                verify = True
            else:
                verify = False
            # run the S-param measurement for each configured bias
            bias_and_sparams( f, vna, bg1, bg2, bd1, bd2, verify, *d )
        print "*** PA Passed. ***"
    except Exception, e:
        f.write("! FAILED: %s\n" % e)
        print e
        print "*** PA Failed. ***"
    finally:
        f.close()
        bd1.close()
        bd2.close()
        wait_ms(100)
        bg1.close()
        bg2.close()
        vna.close()
        

def bias_and_sparams( fp, vna, bg1, bg2, bd1, bd2, verify, vg1i, vg1max, vg2i, vg2max, vd1, vd2, id1tgt, id2tgt ):
    """Bias up the part and take a set of S-params."""
    
    # set initial gate bias
    vg1 = vg1i
    vg2 = vg2i
    bg1.set_v( vg1, testcfg['ig1limit'] )
    bg2.set_v( vg2, testcfg['ig2limit'] )
    wait_ms(100)
    # set drain voltage bias
    bd1.set_v( vd1, testcfg['id1limit'] )
    bd2.set_v( vd2, testcfg['id2limit'] )
    # measure initial current
    wait_ms(100)
    id1 = bd1.read_i()
    id2 = bd2.read_i()
    
    if id1 > testcfg['id1initmax']:
        raise RuntimeError("Drain 1 appears to be shorted.")
    if id2 > testcfg['id2initmax']:
        raise RuntimeError("Drain 2 appears to be shorted.")
    
    # start the loop to find the target bias point
    ss1 = testcfg['vg1cstep']
    ss2 = testcfg['vg2cstep']
    while (id1 < id1tgt and abs(id1-id1tgt) > 0.05*id1tgt) or (id2 < id2tgt and abs(id2-id2tgt) > 0.05*id2tgt):
        if id1 < id1tgt or abs(id1-id1tgt) > 0.05*id1tgt:
            if id1 > 0.5*id1tgt:
                # switch use the fine step for vg1
                ss1 = testcfg['vg1fstep']
            vg1 += ss1
            if vg1 > vg1max:
                raise RuntimeError("Gate 1 exceeded max setting.")
            bg1.set_v( vg1, testcfg['ig1limit'] )
        if id2 < id2tgt or abs(id2-id2tgt) > 0.05*id2tgt:
            if id2 > 0.5*id2tgt:
                # switch use the fine step for vg1
                ss2 = testcfg['vg2fstep']
            vg2 += ss1
            if vg2 > vg2max:
                raise RuntimeError("Gate 2 exceeded max setting.")
            bg2.set_v( vg2, testcfg['ig2limit'] )
        # read currents
        wait_ms(100)
        id1 = bd1.read_i()
        id2 = bd2.read_i()
    
    vd1m, vd2m = bd1.read_v(), bd2.read_v()
    # bias targetted
    # print bias info to file
    fp.write('! **** BIAS ****\n!Vg1 = %.3f\n!Vg2 = %.3f\n!Vd1 = %.2f\n!Vd2 = %.2f\n!Id1 = %.4f\n!Id2 = %.4f\n'%(vg1,vg2,
        vd1m,vd2m,id1,id2))
    
    # wait for amp to settle
    wait_ms(500)

    # measure S-params and write to file
    flist,s11,s21,s12,s22 = vna.write_sparams(fp)
    
    # set vg1 and vg2 back to initial values
    bg1.set_v( vg1i, testcfg['ig1limit'] )
    bg2.set_v( vg2i, testcfg['ig2limit'] )

    # verify S-params
    if verify:
        pts = 0
        failed = 0
        for i,f in enumerate(flist):
            if f >= testcfg['spflo'] and f <= testcfg['spfhi']:
                pts += 1
                if abs(s21[i]) < testcfg['mingain']:
                    failed += 1
        if pts > 0:
            ratio = float(failed) / float(pts)
            if ratio > 0.1:
                raise RuntimeError("S-param gain verification failed at %d of %d points."%(failed,pts))

def wait_ms( ms ):
    """Wait for ms milliseconds."""
    time.sleep( ms*0.001 )

def _open_bias( addr, style ):
    """Open a bias object given the address and style of bias."""
    
    if style.find(':') > -1:
        st, chan = style.split(':')
        chan = int(chan)
    else:
        st, chan = style, 0
    
    if st.lower() == 'hp662x':
        return HP662x( visa.instrument(addr), chan )
    elif st.lower() == 'k23x':
        return Keithley( visa.instrument(addr) )
    else:
        raise ValueError("Unsupported instrument style '%s'"%st)
    
class Keithley(object):
    """Control a Keithley 236/237/238 SMU."""
    
    def __init__(self, vi):
        """Initialize the keithley and set up a few things."""
        self.__vi = vi
        self.__vi.write('J0X')
        self.__vi.write('G4,0,0S2P3O1X')
        self.__vset = 0.0
        
    def on(self):
        """Turn on."""
        self.__vi.write('N1X')
        
    def off(self):
        """Turn off."""
        self.__vi.write('N0X')
        
    def set_v(self, val, ilimit):
        """Set the output voltage."""
        self.__vset = val
        self.__vi.write('L%.4e,0B%.4e,0,0X' %(ilimit,val))
        
    def read_i(self):
        """Read current."""
        # turn on triggered measurement, take a reading, then set triggers
        # back to free-running
        self.__vi.write('R0XT4,1,0,0R1XH0X')
        wait_ms(10)
        s = self.__vi.read()
        self.__vi.write('R0XT4,0,0,0R1XH0X')
        return float(s[5:].split(',')[0])

    def read_v(self):
        """Read the output voltage."""
        return self.__vset
        
    def close(self):
        self.off()
        self.__vi.close()
    
class HP662x(object):
    """Control an HP 662X power supply."""
    
    def __init__(self, vi, chan):
        
        if not isinstance(chan,int) or chan < 1:
            raise ValueError("Invalid channel.")
        
        self.__vi = vi
        self.__chan = chan
        self.__vi.write('CLR')

        # set ranges
        irange = 2.0
        if chan == 1:
            irange = 0.5
        self.__vi.write('IRSET %d, %.1f'%(chan,irange))
        
    def on(self):
        """Turn on."""
        self.__vi.write('OUT %d, 1'%self.__chan)
        
    def off(self):
        """Turn off."""
        self.__vi.write('OUT %d, 0'%self.__chan)
        
    def set_v(self, val, ilimit):
        """Set output voltage."""
        self.__vi.write('ISET %d, %.4e'%(self.__chan,ilimit))
        self.__vi.write('VSET %d, %.4e'%(self.__chan,val))
        
    def read_i(self):
        """Read output current."""
        s = self.__vi.ask('IOUT? %d' % self.__chan)
        return float(s)
        
    def read_v(self):
        """Read output voltage."""
        s = self.__vi.ask('VOUT? %d' % self.__chan)
        return float(s)
        
    def close(self):
        self.off()
        self.__vi.close()
        
        
class PNA(object):
    """Control a PNA."""
    
    def __init__(self, vi, chan):
        """Init instrument."""
        
        if not isinstance(chan,int) or chan < 1:
            raise ValueError("Invalid channel.")
        
        self.__vi = vi
        self.__chan = chan
        
        # set the VNA in hold mode
        self.__vi.write('SENS%d:SWE:MODE HOLD' % self.__chan)
        
    def write_sparams(self, fp):
        """Write S-params to a file."""
        
        def ang( c ):
            return math.atan2(c.imag,c.real) * 180.0 / math.pi
        
        params = ('S11','S21','S12','S22')
        chan = self.__chan
    
        # initial setup
        self.__vi.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
        # get the measurement catalog
        catalog = self.__vi.ask('CALC%d:PAR:CAT?' % chan)
        # create measurements as needed
        for p in params:
            measdef = "tawtest_ch%d_%s" % (chan,p)
            if catalog.find(measdef) == -1:
                self.__vi.write("CALC%d:PAR:DEF '%s',%s" % (chan,measdef,p))
        
        # detect averaging state
        avg = int(self.__vi.ask('SENS%d:AVER:STAT?' % chan))
        if avg:
            count = int(self.__vi.ask('SENS%d:AVER:COUN?' % chan))
            # restart averaging
            self.__vi.write('SENS%d:AVER:CLEAR' % chan)
        else:
            count = 1
        
        # set the group count to be equal to the averaging
        self.__vi.write('SENS%d:SWE:GRO:COUN %d' % (chan,count))
        # trigger a measurment group
        #  and wait for the measurement to finish
        self.__vi.ask('SENS%d:SWE:MODE GRO;*OPC?' % chan)
        
        
        # get the frequency list
        flist = self.__vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?' % chan)
        n = len(flist)
        
        # get the S-parameters
        result = []
        for p in params:
            self.__vi.write("CALC%d:PAR:SEL 'tawtest_ch%d_%s'" % (chan,chan,p))
            r = self.__vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA' % chan)
            # combine the interlaced real/imag pairs into complex numbers
            if len(r) != n*2:
                raise RuntimeError("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (p,n,len(r)))
            r2 = []
            for i in range(n):
                cnum = complex(r[2*i],r[2*i+1])
                r2.append(cnum)
            result.append(r2)
        
        # write the S-parameters to the data file
        fp.write("# HZ S MA R 50\n")
        fp.write("!Freq\tS11-mag\tS11-ang\tS21-mag\tS21-ang\tS12-mag\tS12-ang\tS22-mag\tS22-ang\n")
        for i in range(n):
            fp.write("%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\n"%(flist[i],abs(result[0][i]),ang(result[0][i]),
                abs(result[1][i]),ang(result[1][i]),abs(result[2][i]),ang(result[2][i]),abs(result[3][i]),ang(result[3][i])))
        
        
        return flist,result[0],result[1],result[2],result[3]

    def close(self):
        # set free-run mode and close vi
        self.__vi.write('SENS%d:SWE:MODE CONT' % self.__chan)
        self.__vi.close()


if __name__ == '__main__':
    main()
    
