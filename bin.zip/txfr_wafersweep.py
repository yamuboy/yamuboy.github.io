#!/usr/bin/env python

import os, sys, time, math, os.path
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
from modeling.configfile import ConfigVars, ConfigFile
from modeling.configtypes import *
from optparse import OptionParser
import numpy as np
import logging

delay_time = 50 

def load_config( name ):
    """Load config data from a file."""
    cv = ConfigVars()
    cv.add('gate_voltages', CF_FLOATTUPLE)
    cv.add('drain_voltages', CF_FLOATTUPLE)
    cv.add('drain_voltage_range', CF_FLOATTUPLE)
    cv.add('gate_voltage_range', CF_FLOATTUPLE)
    cv.add('backside_voltages', CF_FLOATTUPLE)
    cv.add('power_limit', CF_FLOAT, default=1000.0)
    cv.add('gate_ilimit', CF_FLOAT, default=1.0)
    cv.add('drain_ilimit', CF_FLOAT, default=1.0)
    cv.add('sweep_order', CF_TUPLE, default=('g','d'))
    cv.add('output_format')
    
    cf = ConfigFile()
    cf.read(name)
    return cf.get_variables(cv)

def _get_voltages(d):
    """Create a voltage list."""
    assert len(d) == 3
    return np.arange(d[0],d[1]+0.1*d[2],d[2])

class WaferMap(object):
    """Structure to hold wafer map information."""
    
    _log = logging.getLogger('WaferMap')
    
    def __init__(self):
        """Initialize."""
        self.__xi = 0
        self.__yi = 0
        self.__mf = 'N'
        self.__sites = []
        
    def read_map(self, fname):
        """Read a wafer map file.
        
        The wafer map file has the following format:
        ---------------------------------
        xindex: XXXXX
        yindex: YYYYY
        majorflat: Z
        
        [sites]
        x1 y1
        x2 y2
        x3 y3
        .
        .
        .
        ---------------------------------
        
        Where:
        XXXXX is the step index for X (positive integer)
        YYYYY is the step index for Y (positive integer)
        Z is either N, S, W, or E for the position of the major flat
        
        Any line with a leading '#' is a comment
        
        """
        f = open(fname,'rU')
        startsites = False
        try:
            for line in f:
                if line.startswith('#'):
                    continue
                
                line = line[:-1]
                if not startsites:
                    if line.startswith('xindex:'):
                        self.set_xindex(int(line[7:]))
                    elif line.startswith('yindex:'):
                        self.set_yindex(int(line[7:]))
                    elif line.startswith('majorflat:'):
                        mf = line[10:].strip()
                        self.set_mf(mf)
                    elif line.startswith('[sites]'):
                        startsites = True
                else:
                    if not len(line):
                        continue
                        
                    try:
                        x,y = tuple(line.split())
                        self.add_site(x,y)
                    except Exception, e:
                        self._log.warning("illegal line '%s' in file '%s'"%(line,fname))
                        continue
                        
        finally:
            f.close()
        
    def set_xindex(self, x):
        """Set the X index."""
        x = int(x)
        if x <= 0:
            raise ValueError("X-index must be greater than 0.")            
        self.__xi = x
        
    def set_yindex(self, y):
        """Set the Y index."""
        y = int(y)
        if y <= 0:
            raise ValueError("Y-index must be greater than 0.")            
        self.__yi = y
        
    def set_mf(self, mf):
        """Set the major flat location."""
        mf = mf.upper()
        if mf not in ('N','S','W','E'):
            raise ValueError("Invalid major flat position '%s'"%mf)
        self.__mf = mf
    
    def add_site(self, x, y):
        """Add a site to the map."""
        x, y = int(x), int(y)
        if x <= 0 or y <= 0:
            raise ValueError("site IDs must be positive integers.")
        self.__sites.append( (x,y) )
    
    def compute_pos(self, idx, startidx=0):
        """Compute the differential position from the starting index."""
        indexing_map = dict(N=(self.__xi,-self.__yi),S=(-self.__xi,self.__yi),
            E=(-self.__yi,-self.__xi), W=(self.__yi,self.__xi))
        column_map = dict(N=(0,1), S=(0,1), E=(1,0), W=(1,0))
        
        start = self.__sites[startidx]
        current = self.__sites[idx]
        cm = column_map[self.__mf]
        im = indexing_map[self.__mf]
        return (current[cm[0]]-start[cm[0]])*im[0], (current[cm[1]]-start[cm[1]])*im[1]
       
    def get_site_name(self, idx):
        """Get the name of the site at the given index."""
        x,y = self.__sites[idx]
        return '%0.2d%0.2d'%(x,y)
       
    def get_site_index(self, x, y):
        """Get the ordinal index of site (x,y)."""
        x, y = int(x), int(y)
        for i,site in enumerate(self.__sites):
            if site[0] == x and site[1] == y:
                return i
        raise ValueError("site '%d,%d' is not in the wafer map"%(x,y))
        
    def __getitem__(self,i):
        return self.__sites[i]
    
    def __len__(self):
        return len(self.__sites)


def main(cfg= None):
    "entry point"
    # init logging
    logging.basicConfig()

    if cfg is not None:
        if isinstance(cfg,str):
            # cfg is an argument specifying the config file name
            cdata = load_config(cfg)
        else:
            # config data passed in
            cdata = cfg
    else:
        # try to load the config from the default config file locations
        cdata = load_config('ivconfig.cfg')
    
    # figure out the voltages, ranges override configured sweep points
    if len(cdata['gate_voltage_range']):
        cdata['gate_voltages'] = _get_voltages(cdata['gate_voltage_range'])
    if len(cdata['drain_voltage_range']):
        cdata['drain_voltages'] = _get_voltages(cdata['drain_voltage_range'])
        
    filename = raw_input("File name for test data? ")
    if os.path.exists(filename):
        r = raw_input("'%s' exists - overwrite? (y/N)"%filename).strip().lower()
        if not r.startswith('y'):
            return
    parms = {
        'temp':25.0,
        'mapfile':'sites.map',
    }
   
    map1 = WaferMap()
    map1.read_map(parms.get('mapfile','sites.map'))

    mgr = InstrumentManager()
    driver=mgr.get_driver('bias','Keithley236')
    prober = mgr.open_driver('prober','12k','GPIB::28')
    gatesmu = driver('GPIB::21')
    drainsmu = driver('GPIB::23')
    kth_keywords = {'averaging':32,'integration':'linecycle','sensing':'local'}
    gatesmu.config(**kth_keywords)
    drainsmu.config(**kth_keywords) 
    start_x, start_y = prober.get_position() 
    fp = open(filename,'w')
    fp.write("! Transfer Curve Sweep!\n")
    fp.write("! Test Date: %s\n"%datetime.now().strftime("%Y/%m/%d %H:%M:%S"))
    try:
        try:
            for i in range(len(map1)):
                x, y = map1.compute_pos(i)
                site = map1.get_site_name(i)
                if i > 0:
                    # move probe station
                    prober.set_position_synch(start_x+x,start_y+y)
                
                # run the test
                try:
                    run_site(cdata,gatesmu,drainsmu,site,fp)
                except KeyboardInterrupt:
                    raw_input("site aborted, press Enter to continue (Control-C again to quit)")
        except Exception:
            # clean up instruments and exit
            drainsmu.set_state(0)
            timed_wait_ms(50)
            gatesmu.set_state(0)
            raise
    finally:
        fp.close()


def run_site(config,sgate,sdrain,site,f):
    """Capture a set of I-V data from the device."""
    
    # set the initial gate and drain current limits
    sgate.config( ilimit=config['gate_ilimit'] )
    ilim = config['drain_ilimit']
    sdrain.config( ilimit=ilim )
    power_limit = config['power_limit']
    
    order = config['sweep_order']

    def _inner(first):
        # set the power/current limit
        dv2 = abs(dv) + 0.001
        ilimp = power_limit / dv2
        ilim2 = ilim
        if ilimp < ilim: ilim2 = ilimp
        
        # set the voltages
        sgate.set_source(gv)
        sdrain.config(vset=dv,ilimit=ilim2)
        
        if first:
            # turn on the supplies
            sgate.set_state(1)
            sdrain.set_state(1)

            # write the header
            if config['output_format'].lower() == 'mdif': 
                f.write( "!\n" )
                f.write("!Site\t%d\t%d\n"%(x,y))
                f.write( "VAR Vgs(1) = %f\n" % gv )
                f.write( "BEGIN TESTDATA\n" )
                f.write( "%   Vds(1)     Ids(1)    Igs(1)\n" )
            else:
                f.write("!Site\t%s\n"%site)
                f.write("! Vds\tIds\tVgs\tIgs\n")
                
        timed_wait_ms(delay_time)
        # measure the currents
        #print ".",
        gc = sgate.measure()
        dc = sdrain.measure()
        
        # check for limiting conditions
        if sgate.ask_if_limiting():
            return
        if sdrain.ask_if_limiting():
            raise StopIteration
        
        # write the data
        if config['output_format'].lower() == 'mdif': 
            f.write( "%.3e\t%.3e\t%.3e\n" % (dv,dc,gc) )
        else:
            f.write( "%.3e\t%.3e\t%.3e\t%.3e\n" % (dv,dc,gv,gc) )
                
                
    if order[0].lower()[0] == 'g':
        for gv in config['gate_voltages']:
            first=True
            print "Vgs = %f" % gv
            for dv in config['drain_voltages']:
                try:
                    _inner(first)
                except StopIteration:
                    break
                first=False
            
            sdrain.set_state(0)
            sgate.set_state(0)
            
            if config['output_format'].lower() == 'mdif': 
                f.write("END\n")
    else:
        for dv in config['drain_voltages']:
            first=True
            print "Vds = %f" % dv
            for gv in config['gate_voltages']:
                try:
                    _inner(first)
                except StopIteration:
                    break
                first=False
            
            sdrain.set_state(0)
            sgate.set_state(0)
            
            if config['output_format'].lower() == 'mdif': 
                f.write("END\n")



if __name__ == '__main__':
    parser = OptionParser()
    parser.add_option("-f", "--file", dest="filename", help="Read configiguration from FILE", metavar="FILE")
    opts,args = parser.parse_args()
    fname = opts.filename
    
    # run the main routine
    print "Config file:",fname
    main(fname)
    


