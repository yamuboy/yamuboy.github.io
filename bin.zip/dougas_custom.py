#!/usr/bin/env python

import os, sys, time
from datetime import datetime
import instrument
from instrument.utils import timed_wait_ms

# instrument configuration

def main():
    start_gate_voltage= 0.0
    stop_gate_voltage= 1.05
    gate_step_size= 0.05
    filename=raw_input("Enter Filename for test data?\n")
    if os.path.exists(filename):
        r=raw_input(" ** '%s' exists -> overwrite? (y/N) "%filename).strip().lower()
        if not r.startswith('y'):
            return
    periphery= float(raw_input("Enter the Device Periphery in um:\n"))
    # open instruments
    gate = instrument.create('bias','b2902','GPIB::22',chan=1)
    drain = instrument.create('bias','b2902','GPIB::22',chan=2)
    # Configure the instruments
    gate.config(mode='V',vset=0.0,ilimit=0.5,state=0,resolution='very high')
    drain.config(mode='V',vset=0.0,ilimit=1.0e-6*periphery,state=0,resolution='very high')
    # open output file
    f= open(filename,'w')
    f.write("G-S Diode Measurement\n")
    f.write("Device Periphery(um):%f\n"%periphery)
    f.write("Comment: Float Drain\n")
    f.write("Vg(V)\tIg(A)\n")
    
    while start_gate_voltage<=stop_gate_voltage:
        gate.config(vset=start_gate_voltage,state=1)
        timed_wait_ms(20)
        Ig=gate.measure()
        f.write("%f\t%+.4e\n"%(start_gate_voltage,Ig))
        start_gate_voltage+=gate_step_size
    gate.config(state=0)
    drain.config(state=0)
        
    print "Test Complete!"

if __name__=="__main__":
    main()
    
