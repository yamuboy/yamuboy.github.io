#!/usr/bin/env python

from visa import *
from instrument.manager import InstrumentManager
from instrument.utils import timed_wait_ms
import matplotlib.pyplot as plt
import os,sys
import datetime

def load_config(name):
    cfg={}
    execfile(name,cfg)
    del cfg['__builtins__']
    return cfg

def measure(mtr):
    while (True):
        mtr.write('AP')
        mtr.write('*CLS')
        mtr.write('*SRE001')
        mtr.write('TR2')
        data=mtr.read()
        stb=mtr.ask('*SRE?')
        if stb=='001':
            break
    return data

def set_pwr(src,pwr):
	while (True):
		src.write('POW:AMPL '+str(pwr))
		stb= src.ask('*OPC?')
		if stb=='+1':
			break

def main(cfg=None):
    if cfg is not None:
        if isinstance(cfg,str):
            cdata= load_config(cfg)
        else:
            cdata= cfg
    else:
        cdata= load_config('pwr_sweep_config.cfg')

    filename= raw_input('Enter the filename for the test:\n')
    if os.path.exists(filename):
        print "Warning: file %s exists"%filename
        if raw_input("Overwrite the existing file(Y/N):  ").strip().lower()[0]!='y':
            print "Exiting"
            return

    if raw_input("Turning on the power supplies(Y/N):  ").strip().lower()[0]!='y':
        return
    run_test(filename, cdata)


def run_test(filename, config):
    source= instrument('GPIB::'+str(config.get('source_address')))
    meter= instrument('GPIB::'+str(config.get('meter_address')))
    manager= InstrumentManager()
    driver= manager.get_driver('bias','Keithley236')
    kth_keywords = {'averaging':32,'integration':'linecycle','sensing':'local'}
    gate= driver('GPIB::21')
    drain= driver('GPIB::23')
    gate.config(**kth_keywords)
    drain.config(**kth_keywords)

    f= open(filename, 'w+')
    f.write('Set Power\t Thru Pout\t Device Pout\tGain\t Drain Voltage\t Drain Current\t Gate Voltage\t Gate Current\n')
    source.write('FREQ:CW '+str(config.get('frequency')))
    
    # Connect the power sensor to the output of the amplifier to get the amplifier gain
    if raw_input('Connect Power Meter to Input(y/n): ').strip().lower()[0]!='y':
        return
    set_pwr(source,-40)
    source.write('OUTP:STAT 1')
    tmp1=measure(meter)    
    source.write('OUTP:STAT 0')
    amp_gain= abs(-40.0-float(tmp1))
    print amp_gain

    # Connect a thru to the input to get output loss 
    if raw_input('Connect Thru(y/n): ').strip().lower()[0]!='y':
        return
    set_pwr(source,-40)
    source.write('OUTP:STAT 1')
    tmp1= measure(meter)        
    source.write('OUTP:STAT 0')
    loss= amp_gain-(abs(-40.0-float(tmp1)))
    print loss
    
    # Get Sig gen power level that corresponds to start power in the config file
    points= int(abs(config.get('start_pow')-config.get('stop_pow'))/config.get('step_size'))
    actual_start= 0
    initial_start= -40.0
    set_pwr(source, initial_start)
    source.write('OUTP:STAT 1')
    tmp1= initial_start    
    while (tmp1<= config.get('start_pow')):
        set_pwr(source, initial_start)
        tmp1= float(measure(meter))+ loss
        initial_start+=0.5

    actual_start= float(source.ask('POW:AMPL?'))
    print actual_start
    source.write('OUTP:STAT 0')

    # Create power table
    measured_pwr=[]
    set_power=[]
    source.write('OUTP:STAT 1')
    for i in range(points):
        set_pwr(source, actual_start)
        set_power.append(actual_start)
        measured_pwr.append( float(measure(meter)))
        actual_start+= config.get('step_size')

    source.write('OUTP:STAT 0')
    
    # Plot the set and measured powers to make sure you're within the linear range of the amplifier 
    plt.plot(set_power,measured_pwr)
    plt.show()

    if raw_input("Connect DUT and press yes/no(y/n)").strip().lower()[0]!='y':
        return

    # Main power sweep loop
    gain1=[]
    try:
        gate.config(vset= config.get('gate_v'),ilimit= config.get('gate_limit'),state=1)
        drain.config(vset= config.get('drain_v'),ilimit= config.get('drain_limit'),state=1)
        source.write('OUTP:STAT 1')
        for i in range(points):
            set_pwr(source, set_power[i])
            ig= gate.measure()
            idr= drain.measure()
            time.sleep(0.03)
            p_out= float(measure(meter))+loss
            gain= p_out- set_power[i]
            gain1.append(gain)
            if (len(gain1)>0):
                if ((gain1[len(gain1)-1]-gain1[len(gain1)-2])>= config.get('comp_limit'))or gate.limiting or drain.limiting:
                    break
            f.write('%f\t %f\t %f\t %f\t %f\t %s\t %f\t %s\n'%(set_power[i],measured_pwr[i],p_out,gain,config.get('drain_v'),idr,config.get('gate_v'),ig))
    finally:
        f.close()
        source.write('OUTP:STAT 0')
        drain.set_state(0)
        gate.set_state(0)
        drain.close()
        gate.close()
        print "Test Complete!!"   
        

if __name__=="__main__":
    main()
    
    
    

    
    
    
    

