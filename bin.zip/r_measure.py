#!/usr/bin/env python

import sys
import datetime
import instrument
from instrument import timed_wait_ms
import os
import numpy
import matplotlib.pyplot as plt

INSTR = {
    'bias1':['b2902','GPIB::22',{'chan':1}],
    'bias2':['b2902','GPIB::22',{'chan':2}],
    
}

def run_test(bias1):
    bias1.config(mode = 'V', vset = 0.0, ilimit = 100.0e-3, resolution = 'high', remote = True, state =0)
    i_sweep=[2.0e-3, 2.5e-3, 3.0e-3, 3.5e-3,4.0e-3, 4.5e-3,5.0e-3,5.5e-3,6.0e-3,6.5e-3,7.0e-3,7.5e-3, 8.0e-3]
    v_sweep = numpy.arange(0.0,37.5,2.5)
    filename= raw_input('Enter the filename for the test \n')
    if os.path.exists(filename):
        print "Warning: file '%s' exists." % filename
        if raw_input("Overwrite the existing file? (y/N): ").strip().lower()[0] != 'y': 
            print "Exiting."
            return
    f= open(filename,'w')
    f.write('Vset(V) \t IMeasured(A) \n')
    i_meas_plot = []
    
    try:
       for i in v_sweep:
           bias1.config(vset= i, state=1)
           timed_wait_ms(400)
           if bias1.ask_if_limiting():
               break
           imeas = bias1.measure()
           i_meas_plot.append(imeas)
           
           f.write('%.3e\t %.3e\n'%(i,imeas))
           f.flush()
    except IOError:
           print "Unable to write to the file"
           return
    finally:
           bias1.close()
           f.close()
           
    if len(v_sweep)!= len(i_meas_plot):
        v_sweep = v_sweep[0:len(i_meas_plot)]
    
    plt.plot(v_sweep,i_meas_plot)
    plt.xlabel('V Applied(V)')
    plt.ylabel('I Measured(A)')
    plt.title('R Sweep')
    plt.show()
    

if __name__=="__main__":
    bias1 = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    run_test(bias1)
          

    
