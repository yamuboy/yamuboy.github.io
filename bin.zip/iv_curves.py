#!/usr/bin/env python

import sys
import matplotlib.pyplot as plt
from optparse import OptionParser

# Version 1

"""Need to put things in classes and functions
   Nice and simple for now. Default case- No options included, plots just the DC IV's
   Other Options- -b breakdown, -f forward
"""
def main(fnames,opt):
    colors=['purple','green','blue','yellow','red','black']
    count=0
    if opt[0]=='b':
        for i in range(len(fnames)):
            breakdown_iv={'Vds':[],'Ids':[],'Vgs':[],'Igs':[]}
            try:
                f=open(fnames[i],'r')
                device_name=fnames[i].strip().split('_')[0]
                status=fnames[i].strip().split('_')[1]            
                data=f.readlines()
                for j in range(len(data)):
                    if 'BREAKDOWN'in data[j]:
                        count1=j
                    elif 'FORWARD' in data[j]:
                        count2=j
                    elif 'DC IV-CURVES'in data[j]:
                        count3=j
                for j in range(count1+3,count2):
                    breakdown_iv['Vds'].append(float(data[j].strip().split(' ')[0]))
                    breakdown_iv['Ids'].append(float(data[j].strip().split(' ')[1]))
                    breakdown_iv['Vgs'].append(float(data[j].strip().split(' ')[2]))
                    breakdown_iv['Igs'].append(float(data[j].strip().split(' ')[3]))
                plt.plot(breakdown_iv['Vds'],breakdown_iv['Ids'],label=device_name+' '+status)
                plt.legend()
            except IOError:
                print 'Could not open DCIV file%s'%i
                exit(1)
        plt.xlabel('Vds (Volts)')
        plt.ylabel('Ids (Amps)')
        plt.title('Breakdown Curves, Vds vs. Ids')
        plt.grid('on')
        plt.show()
    elif opt[0]=='f':
        for i in range(len(fnames)):
            forward_iv={'Vds':[],'Ids':[],'Vgs':[],'Igs':[]}
            try:
                f=open(fnames[i],'r')
                device_name=fnames[i].strip().split('_')[0]
                status=fnames[i].strip().split('_')[1]                
                data=f.readlines()
                for j in range(len(data)):
                    if 'BREAKDOWN'in data[j]:
                        count1=j
                    elif 'FORWARD' in data[j]:
                        count2=j
                    elif 'DC IV-CURVES'in data[j]:
                        count3=j
                for j in range(count2+3,count3):
                    forward_iv['Vds'].append(float(data[j].strip().split(' ')[0]))
                    forward_iv['Ids'].append(float(data[j].strip().split(' ')[1]))
                    forward_iv['Vgs'].append(float(data[j].strip().split(' ')[2]))
                    forward_iv['Igs'].append(float(data[j].strip().split(' ')[3]))
                plt.plot(forward_iv['Vgs'],forward_iv['Ids'],label=device_name+' '+status)
                plt.legend()
            except IOError:
                print 'Could not open DCIV file%s'%i
                exit(1)
        plt.xlabel('Vgs (Volts)')
        plt.ylabel('Ids (Amps)')
        plt.title('Forward Curves, Vgs vs. Ids')
        plt.grid('on')
        plt.show()
    elif opt[0]=='d':
        device_names=[]
        status=[]
        plt_objects=[]
        for i in range(len(fnames)):
            device_names.append(fnames[i].strip().split('_')[0])
            status.append(fnames[i].strip().split('_')[1])
            dc_iv={'Vds':[],'Ids':[],'Vgs':[],'Igs':[]}
            try:
                f=open(fnames[i],'r')
                data=f.readlines()
                for j in range(len(data)):
                    if 'BREAKDOWN' in data[j]:
                        count1=j
                    elif 'FORWARD' in data[j]:
                        count2=j
                    elif 'DC IV-CURVES'in data[j]:
                        count3=j
                for j in range(count3+3,len(data)):
                    dc_iv['Vds'].append(float(data[j].strip().split(' ')[0]))
                    dc_iv['Ids'].append(float(data[j].strip().split(' ')[1]))
                    dc_iv['Vgs'].append(float(data[j].strip().split(' ')[2]))
                    dc_iv['Igs'].append(float(data[j].strip().split(' ')[3]))
                vgs_dict={}
                for i in set(dc_iv['Vgs']):
                    vgs_dict[i]=dc_iv['Vgs'].count(i)
                for i in vgs_dict.iterkeys():
                    ind= dc_iv['Vgs'].index(i)
                    next_ind=ind+vgs_dict[i]
                    plt_objects.append(plt.plot(dc_iv['Vds'][ind:next_ind],dc_iv['Ids'][ind:next_ind],color=colors[count]))
                    #plt.text(dc_iv['Vds'][next_ind-2],dc_iv['Ids'][next_ind-2],'Vgs=%s'%str(i))
                                                       
            except IOError:
                print 'Could not open DCIV file%s'%i
                exit()
            count+=1
        colors_used=[]
        legend_names=[]
        for i in range(count):
            colors_used.append(colors[i])
        for i in range(len(device_names)):
            legend_names.append(device_names[i]+' '+status[i])
        a= zip(legend_names,colors_used)
        plt.legend(a)
        plt.xlabel('Vds (Volts)')
        plt.ylabel('Ids (Amps)')
        plt.title('DC IV Curves')
        plt.grid('on')
        plt.show()
        

if __name__ == '__main__':
    """
    parser= argparse.ArgumentParser(description= 'Plots IV data from raw DCIV.dat files', usage= 'prog.py [options] filenames')
    parser.add_argument('-b', help='Plots breakdown IV data',nargs='*')
    parser.add_argument('-f',help='Forward IVs',nargs='*')
    parser.add_argument('-d',help='DC-IVs',nargs='*')
    args= parser.parse_args()
    main(args)
    """
    op= OptionParser(usage='prog.py [option] file1 [file2...]')
    op.add_option('-d','--d', help='display the DC-IV curves')
    op.add_option('-b','--b', help='display the Breakdown-IV curves')
    op.add_option('-f','--f', help='display the Forward-IV curves')
    opts, files= op.parse_args()
            
    filenames=[]
    used_options=[]
    for attr, value in opts.__dict__.iteritems():
        if value==None:
            continue
        else:
            used_options.append(attr)
            filenames.append(value)
    if not len(filenames):
        op.print_usage()
        exit(1)
    for i in range(len(files)):
        filenames.append(files[i])
    main(filenames,used_options)
    
    
    
    
    
    
    
    
    
        
    





