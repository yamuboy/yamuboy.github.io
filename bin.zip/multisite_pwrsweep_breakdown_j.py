
#!/usr/bin/env python

import os, sys, time
from datetime import datetime
import instrument
from instrument.base import GenericInstrument
from instrument.multisite import Multisite
from instrument.utils import timed_wait_ms
import logging

# instrument configuration
INSTR = {
    #'bias1':['k23x','GPIB::21',{'remote':True,'resolution':'high'}],
    #'bias2':['k23x','GPIB::23',{'remote':True,'resolution':'high'}],
    'bias1':['b2902','GPIB::22',{'chan':1,'remote':True,'resolution':'high'}],
    'bias2':['b2902','GPIB::22',{'chan':2,'remote':True,'resolution':'high'}],
    'prober':['12k','GPIB::28',{}],
    'siggen':['SCPISigGen','GPIB::20',{}],
}

# Parameters for the test including FET DC Parameters
# power stress and other parameters such as 
# the wafer and device name and mapfile for stepping across the wafer
TEST_PARAMS = {
    # general parameters
    'periphery_um':400,
    'wafer':'',
    'device':'',
    'mapfile':'sites.map',

    # power stress parameters
    'pstress_vds':11.5,
    'pstress_vg_start':-0.9,
    'pstress_vg_min':-2.0,
    'pstress_vg_max':0.0,
    'pstress_rf_power':-18.3,
    'pstress_ig_max_mamm':4.0,
    'pstress_id_target_mamm':125.0,
    'pstress_soak_ms':10000,
    'pstress_iterations':5,

    # DC screen parameters
    'min_vgs':-3,
    'max_vgs':1.6,
    'max_igs_mamm':1.0,
    'max_ids_mamm':800.0,
    'ibr_low_mamm':0.01,
    'ibr_high_mamm':0.1,
    'max_vbr':30,
    'vds_idss':3.0,
    'vds_imax':1.5,
    'igs_imax_mamm':1.0,
    'vpo_percent':2.5,
    'vpo_current_mamm':1.0,
    }

CONFIG_FNAME = 'multisite_pstress.cfg'

class SCPISigGen(GenericInstrument):
    """Generic SCPI RF source"""

    def __init__(self, *args, **kwargs):
        "initializer"
        super(SCPISigGen,self).__init__(*args,**kwargs)

        if self.vi and not hasattr(self.vi,'_initialized'):
            self.vi.write('*CLS')
            self.vi.write('OUTP:STAT 0')
            self.vi._initialized = True

    def config(self, **kwargs):
        """Configure the source

        Keywords:
        state - boolean, set output state
        plevel - float, set output power level in dBm
        freq - float, set the output frequency in Hz
        """

        req_state = None
        if 'state' in kwargs:
            req_state = bool(kwargs.pop('state'))
            if not req_state:
                # immediately shut off the output
                self.vi.write('OUTP:STAT 0')
                timed_wait_ms(100)

        if 'freq' in kwargs:
            v = float(kwargs.pop('freq'))
            if v < 100e6 or v > 100e9:
                raise ValueError("invalid 'freq' > %g"%v)
            self.vi.write('FREQ %g'%v)
            timed_wait_ms(100)

        if 'plevel' in kwargs:
            v = float(kwargs.pop('plevel'))
            if v < -150.0 or v > 50.0:
                raise ValueError("invalid 'plevel' > %g"%v)
            self.vi.write('POW:AMPL %g'%v)
            timed_wait_ms(100)

        # turn on output if requested
        if req_state:
            self.vi.write('OUTP:STAT 1')
            timed_wait_ms(100)

        # pass remaining keywords on to VISA
        if len(kwargs):
            self.configure_vi(**kwargs)
    
    def _close(self):
        "cleanup prior to closing VISA interface"
        if self.vi:
            self.config(state=0)

    def set_power(self, power):
        "set output power"
        self.config(plevel=power)

    def set_freq(self, f):
        "set frequency"
        self.config(freq=f)

    def set_state(self, state):
        "set output state"
        self.config(state=state)


def main():
    "entry point"

    # read parameters
    params = TEST_PARAMS
    if os.path.isfile(CONFIG_FNAME):
        try:
            c = {}
            execfile(CONFIG_FNAME,c)
            del c['__builtins__']
            params.update(c)
        except Exception, e:
            print "WARNING: failed to read file '%s' => %s"%(CONFIG_FNAME,e)

    filename=raw_input("Enter Filename for test data?\n")
    if os.path.exists(filename):
        r=raw_input(" ** '%s' exists -> overwrite? (y/N) "%filename).strip().lower()
        if not r.startswith('y'):
            return

    # initialize the multisite test object
    multi = Multisite()
    multi.read_map_file(params.get('mapfile','sites.map'))

    # ask the user what site they want to start at
    start_index = 0
    start_site = raw_input("Starting site? [%s]: "%multi.get_site_name(0)).strip()
    if len(start_site): 
        start_index = multi.get_site_index(start_site)

    print "  starting multi-site at site %d of %d"%(start_index+1,len(multi))

    # initialize multisite
    multi.init_multisite(index=start_index,drvname=INSTR['prober'][0],addr=INSTR['prober'][1])

    # open instruments
    gate = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    drain = instrument.create('bias',*(INSTR['bias2'][:2]),**(INSTR['bias2'][2]))
    rf = SCPISigGen(INSTR['siggen'][1],**(INSTR['siggen'][2]))

    # open output file
    f= open(filename,'w')
    f.write('!Multisite RF Stress and Breakdown Test\n')
    f.write('!Test Date: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write('!Wafer: %s\n'%params['wafer'])
    f.write('!Device: %s\n'%params['device'])
    f.write('! Min Vgs: %g V\n'%params['min_vgs'])
    f.write('! Stress Drain Voltage: %g V\n'%(params['pstress_vds']))
    f.write('!\n')
    f.write('!DC FET PARAMETERS\n')
    f.write('!x\ty\tstatus\tpre_Vbr(0.01mA/mm)\tpre_Vbr(0.1mA/mm)\tpre_Idss(3V)\tpre_Vpo(3V)\tpre_Imax(1.5V)\tpre_Vpo(1.5V)\tpre_VMax(1.5V)\tpre_Vpo(1mA/mm)\tpre_Ron(Ohms)\tpre_Ig(10V)\tpre_Ig(12V)\tpre_Ig(15V)\tpre_Ig(20V)\tpost_Vbr(0.01mA/mm)\tpost_Vbr(0.1mA/mm)\tpost_Idss(3V)\tpost_Vpo(3V)\tpost_Imax(1.5V)\tpost_Vpo(1.5V)\tpost_VMax(1.5V)\tpost_Vpo(1mA/mm)\tpost_Ron(Ohms)\tpost_Ig(10V)\tpost_Ig(12V)\tpost_Ig(15V)\tpost_Ig(20V)\n')
    f.flush()
    try:
        while True:
            try:
                run_test(f,gate,drain,rf,params,multi.current_coord)
                f.flush()
                multi.next_site()
            except StopIteration:
                break
            except KeyboardInterrupt:
                # test interrupted, shut down instruments
                rf.set_state(0)
                timed_wait_ms(100)
                drain.set_state(0)
                timed_wait_ms(50)
                gate.set_state(0)
                timed_wait_ms(50)

                # ask the user what they want to do
                r = raw_input("*** Test Interrupted ***\n  Do you want to (r)estart this site, go to the (n)ext site, or (q)uit? [q]: ").lower().strip()
                if not r or r.startswith('q'):
                    break
                elif r.startswith('r'):
                    pass
                elif r.startswith('n'):
                    try:
                        multi.next_site()
                    except StopIteration:
                        break
            except Exception:
                # fatal exception, should never have gotten here!!!
                rf.set_state(0)
                timed_wait_ms(50)
                drain.set_state(0)
                timed_wait_ms(50)
                gate.set_state(0)
                timed_wait_ms(50)
                raise

    finally:
        f.close()
        drain.close()
        gate.close()
        rf.close()
        multi.close()

def fmt_dc_data(data):
    "format DC data in preparation for writing to a file"
    params = ('vbr_ss_low','vbr_ss_high','idss','vpo','imax','vpo_imax',
        'vmax','vpo_mamm','ron','ig_10v','ig_12v','ig_15v','ig_20v')
    
    vals = []
    for p in params:
        vals.append('%+.4e'%data.get(p,0.0))
    
    return '\t'.join(vals)

def run_test(fp, gate, drain, rf, params, coord):  
    """inner test function for readability and clean exception handling

    fp - file object, output file    
    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    rf - `instrument.GenericInstrument`-derived object, signal generator
    params - dict, test parameters
    coord - tuple (2-elements), site coordinate

    returns: None
    """
    print "===== Site %s ====="%str(coord)

    # initial DC screen
    print "- DC Screen (pre)"
    try:
        predata = dc_screen(gate,drain,params)
    except Exception, e:
        fp.write("%d\t%d\tfailed: %s\n"%(coord[0],coord[1],e))
        fp.flush()
        return

    if params['pstress_iterations'] < 1:
        # no RF stress loops, write DC data and return
        fp.write("%d\t%d\tpassed\t%s\n"%(coord[0],coord[1],fmt_dc_data(predata)))
        fp.flush()
        return

    # power stress loops
    print "- RF Stress"
    try:
        power_stress(gate,drain,rf,params)
    except Exception, e:
        # write pre-data but no post data
        fp.write("%d\t%d\tfailed: %s\t%s\n"%(coord[0],coord[1],e,fmt_dc_data(predata)))
        fp.flush()
        return
            
    # post DC screen
    print "- DC Screen (post)" 
    try:
        postdata = dc_screen(gate,drain,params)
    except Exception, e:
        # write pre-data but no post data
        fp.write("%d\t%d\tfailed: %s\t%s\n"%(coord[0],coord[1],e,fmt_dc_data(predata)))
        fp.flush()
        return

    # all tests complete successfully, write all data
    fp.write("%d\t%d\tpassed\t%s\t%s\n"%(coord[0],coord[1],fmt_dc_data(predata),fmt_dc_data(postdata)))
    fp.flush()
    
def power_stress(gate, drain, rf, params):
    """always comment!!!!

    target a stress current and then run power sweeps

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    rf - `instrument.GenericInstrument`-derived object, signal generator
    params - dict, test parameters

    returns: None
    """

    periph = params['periphery_um']
    target = params['pstress_id_target_mamm']*periph*1.0e-6
    iglimit = params['pstress_ig_max_mamm']*periph*1.0e-6
    idlimit = params['max_ids_mamm']*periph*1.0e-6
    vg = params['pstress_vg_start']

    try:
        # (re-)set signal generator state
        rf.set_state(0)
        rf.set_power(params['pstress_rf_power'])

        # Hitting the device with RF to see if we can affect a breakdown shift  
        for i in range(params['pstress_iterations']):
            # target current
            kw = {}
            if i > 0:
                # reduce the step size for the targetting loop on
                # loops other than the first one
                kw['stepfrac'] = 0.05
            vg = ids_target_search(gate,drain,params['pstress_vds'],target,vg,params['pstress_vg_min'],
                params['pstress_vg_max'],iglimit,idlimit,leaveon=True,**kw)
            timed_wait_ms(500)
            # turn on RF and soak
            rf.set_state(1)
            timed_wait_ms(params['pstress_soak_ms'])
            # measure final current
            igm = gate.measure()
            idm = drain.measure()
            timed_wait_ms(20)
            rf.set_state(0)
            print "   (%d) Vg = %g V, Ig = %g mA, Id= %s mA"%(i+1,vg,igm*1000.0,idm*1000.0)
            timed_wait_ms(200)

    finally:
        rf.set_state(0)
        timed_wait_ms(10)
        drain.config(state=0)
        timed_wait_ms(25)
        gate.config(state=0)
        timed_wait_ms(25)

def ids_target_search(gate, drain, vds, target, vgstart, vgmin, vgmax, iglimit, idlimit, maxiter=20,
    stepfrac=0.15, successfrac=0.01, failfrac=0.05, stepadj=0.3, minstep=0.002, leaveon=False):
    """this routine targets a drain current for a given set of gate voltage criteria

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    vds - float, drain voltage
    target - float, target Ids current (amps)
    vgstart - float, starting value for Vg
    vgmin - float, minimum Vg limit
    vgmax - float, maximum Vg limit
    iglimit - float, Ig current limit (amps)
    idlimit - float, Id current limit (amps)
    maxiter - int, maximum number of iterations of the targetting loop
    stepfrac - float, fraction of the range (vgmax-vgmin) that is used for the initial step size
    successfrac - float, fraction of the target current that is considered a "success"
    failfrac - float, fraction of the target current that is considered "failure" at the end of
        the targeting loop
    stepadj - float, fraction by which the step size is reduced when the loop overshoots
    minstep - float, minimum Vg step size
    leaveon - bool, leave the gate and drain SMUs on 

    returns: gate voltage value (float)
    """
    if vgstart > vgmax or vgstart < vgmin or vgmin > vgmax:
        raise ValueError("'vgmin' <= 'vgstart' <= 'vgmax': not satisfied")
        
    step = stepfrac*(vgmax-vgmin)
    vg = vgstart

    gate.config(mode='V',vset=vg,ilimit=iglimit,state=1)
    timed_wait_ms(25)
    drain.config(mode='V',vset=vds,ilimit=idlimit,state=1)
    timed_wait_ms(100)
    idm = drain.measure()
    if idm > target:
        step = -step

    try:
        # start the search loop
        count=0
        while count < maxiter:
            if step > 0.0 and vg == vgmax:
                raise ValueError("'vg' is at 'vgmax' (Id_meas = %g, Target = %g)"%(idm,target))
            elif step < 0.0 and vg == vgmin:
                raise ValueError("'vg' is at 'vgmin' (Id_meas = %g, Target = %g)"%(idm,target))

            vg += step
            if vg > vgmax:
                vg = vgmax
            elif vg < vgmin:
                vg = vgmin

            gate.config(vset=vg)
            timed_wait_ms(50)
            idm = drain.measure()

            if abs(idm-target) <= successfrac*target:
                break

            # reduce step and reverse direction for certain conditions
            if (step < 0.0 and idm < target) or (step > 0.0 and idm > target):
                if abs(step) == minstep:
                    # already at min step, just break
                    break
                step *= -stepadj

            # force a minimum step size
            if abs(step) < minstep:
                if step < 0.0:
                    step = -minstep
                else:
                    step = minstep

            count += 1

        if abs(idm-target) > failfrac*target:
            # more than 5% error, raise error
            raise ValueError("current targeting failed (Vg = %g, Id = %g, Target = %g)"%(vg,idm,target))

        if not leaveon:
            timed_wait_ms(20)
            drain.config(state=0)
            timed_wait_ms(50)
            gate.config(state=0)
                
    except ValueError:
        timed_wait_ms(20)
        drain.config(state=0)
        timed_wait_ms(50)
        gate.config(state=0)        
        raise
        
    return vg
        
def dc_screen(gate, drain, params):
    """FET DC screen measurement

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    params - dict, test parameters

    returns: a dict of measured DUT parameters
    """
    data = {}
        
    periph = params['periphery_um']

    # compliance for breakdown tests
    gate_c = periph*params['ibr_high_mamm']*4.0e-6
    drain_c = params['max_vbr']+params['min_vgs']
    
    #### single-sided breakdown ####

    try:
        print "   Single Sided Breakdown..."    
        gate.config(mode='V',vset=params['min_vgs'],ilimit=gate_c,state=1,resolution='very high')
        timed_wait_ms(25)
        drain.config(mode='I',iset=params['ibr_low_mamm']*1.0e-6*periph,vlimit=drain_c,state=1,resolution='very high')
        timed_wait_ms(1000)
        data['vbr_ss_low'] = params['min_vgs'] - drain.measure()
        
        drain.config(iset=params['ibr_high_mamm']*1e-6*periph)
        timed_wait_ms(1000)
        data['vbr_ss_high'] = params['min_vgs'] - drain.measure()
        
        drain.set_state(0)
        timed_wait_ms(50)
                        
        #### Idss ####

        gate_c = params['max_igs_mamm']*1.0e-6*periph
        drain_c = params['max_ids_mamm']*1.0e-6*periph

        print "   Idss Measurement..."
        gate.config(vset=0.0,ilimit=gate_c)
        timed_wait_ms(25)
        drain.config(mode='V',vset=params['vds_idss'],ilimit=drain_c,state=1)
        timed_wait_ms(100)
        data['idss'] = drain.measure()
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

        #### Imax / Vmax ####

        print "   Imax Measurement..."
        gate.config(mode='I',iset=params['igs_imax_mamm']*1.0e-6*periph,vlimit=params['max_vgs'],state=1)
        timed_wait_ms(25)
        drain.config(vset=params['vds_imax'],state=1)
        timed_wait_ms(100)
        data['vmax'] = gate.measure()
        data['imax'] = drain.measure()
        open_gate = gate.limiting
        shorted_chan = drain.limiting
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

        #### Checks for failed devices ####
        
        if open_gate:
            raise ValueError("gate is open-circuited")
        elif data['vmax'] < 0.5:
            raise ValueError("gate is short-circuited")
        elif data['imax'] < 10.0e-6*periph:
            raise ValueError("channel is open-circuited")
        elif shorted_chan:
            raise ValueError("gate is short-circuited")
        
        #### Vpo measurement at Vds for Idss ####

        print "   Pinchoff Measurement @ Vds for Idss..."    
        
        if data['idss'] < 0.05*data['imax']:
            target_ids = 0.01*params['vpo_percent']*data['imax']
        else:
            target_ids = 0.01*params['vpo_percent']*data['idss']
        
        gate.config(resolution='medium')
        drain.config(resolution='medium')
        data['vpo'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)

        #### Vpo Measurement at Vds for IMax ####

        print "   Pinchoff Measurement for Vds@ Imax..."    
        
        data['vpo_imax'] = ids_target_search(gate,drain,params['vds_imax'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)

        #### Vpo measurement mA/mm ####

        print "   Pinchoff Measurement mA/mm..."
        
        target_ids = params['vpo_current_mamm']*1e-6*periph
        data['vpo_mamm'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
        
        #### Ron Measurement D-FET ####

        print "   Ron Measurement..."
        vset = 0.02
        gate.config(mode='V',vset=0.0,ilimit=gate_c,state=1,resolution='very high')
        timed_wait_ms(25)
        drain.config(mode='V',vset=vset,ilimit=drain_c,state=1,resolution='very high')
        timed_wait_ms(1000)
        data['ron'] = vset/drain.measure()
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)
                
        #### spot leakage current tests ####

        print "   Leakage Current Test..."
        vgs = params['min_vgs']
        gate.config(mode='V',vset=vgs,ilimit=params['ibr_high_mamm']*1e-06*periph,state=1)
        timed_wait_ms(25)
        drain.config(mode='V',vset=0.0,ilimit=params['ibr_high_mamm']*2e-06*periph,state=1)
        timed_wait_ms(25)

        names = ['ig_10v','ig_12v','ig_15v','ig_20v']
        for i,vleak in enumerate([10.0,12.0,15.0,20.0]):
            vds = vleak + vgs
            if vleak <= 1.0*abs(data['vbr_ss_high']):
                drain.config(vset=vds)
                timed_wait_ms(1000)
                data[names[i]] = gate.measure()
                timed_wait_ms(10)
            else:
                data[names[i]] = 0.0

    finally:
        timed_wait_ms(25)
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

    #### done ####

    return data
    
    
if __name__=="__main__":
    main()
    
    
    
    

    
    
