"""
Remove extrinsics from a given set of fet S2P data.

Usage: coldfet_deembed.py <extrinsics file from fet_ss_fit.py> <directory with s2p files>
"""

from __future__ import print_function

import os
import re
import sys

from network_params import Touchstone
from modeling.fet.deembed import remove_parasitics

parasitics_fname = sys.argv[1]
spar_dir = sys.argv[2]

with open(parasitics_fname, 'r') as fp:
    print('\nParasitics file: {}'.format(parasitics_fname))
    parasitics = {}
    for line in fp.readlines():
        m = re.match(r'(?P<param>\w+)\s*=\s*(?P<value>.+)', line)
        if m:
            parasitics[m.group('param')] = float(m.group('value'))

print()
print('Processing spar files in directory: {}'.format(spar_dir))
for spar_fname in os.listdir(spar_dir):
    if re.match(r'.+\.s2p', spar_fname):
        try:
            print('Input file: {}'.format(spar_fname))
            spars = Touchstone(os.path.join(spar_dir, spar_fname))
            out_spars = remove_parasitics(spars, parasitics)
            out_fname = '_cfdeembed'.join(os.path.splitext(spar_fname))
            out_spars.write(os.path.join(spar_dir, out_fname))
            print('Output file: {}'.format(out_fname))

        except Exception:
            print('Unable to process file: {}'.format(spar_fname))
