#!/usr/bin/env python

from modeling.fet.dscr2mdif2 import dscr_models_to_mdif
import os, sys



def main():
    from optparse import OptionParser
    
    parser = OptionParser(usage='%prog [options] file.dscr [file2.dscr] ...')
    parser.add_option('-o', '--out', dest='filename',
        help='Set the name of the output file to FILENAME, the default is "composite.mdf".')
    
    options,files = parser.parse_args()
    
    if sys.platform in ('win32','winnt','win64'):
        from glob import glob
        flist = []
        for f in files:
            flist.extend( glob(f) )
        files = flist
    
    kw = {}
    if options.filename:
        kw['outname'] = options.filename
    
    dscr_models_to_mdif(files,**kw)
    
if __name__ == '__main__':
    main()
