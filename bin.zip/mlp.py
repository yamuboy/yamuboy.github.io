"""
This program implements the multi layer perceptron neural network.
Uses the NeuroFET model as the starting point. Creates five neural networks for the five parameters used in the model.
For Ig-dc,Id-dc, it uses the DC-IV characteristics. 
For Qg,Qd it uses the biased S-parameters.
For Id-ac it uses the pulsed IV measurements.
Training Data for Ig-dc and Id-dc - [Vgs,Vds,Ids] where Ids is the "output" 
"""
# Start with PH6 data

import numpy as np
import re
from modeling.mct_files import MctDataFile
import matplotlib.pyplot as plt
from StringIO import StringIO
from network_params import Touchstone,convert

"""
Idea! Allow the user to specify more points in the vds-vgs plane. Selectable extra points to extend the DCIV's for better models
Idea! Create an extrapolation routine to extend DCIV's beyond measured points.
"""

# Take DCIV data as input and convert it to training vectors
def create_training_set(file,plot= None,type = None):
    data_block = MctDataFile(file)
    dciv_block = data_block.get_blocks_by_section('dciv')
    dciv_data = dciv_block[0].data_lines
    vgs,vds,igs,ids = [],[],[],[]
    for d in dciv_data:
        t = d.strip('\n').split(' ')
        vgs.append(float(t[2]))
        vds.append(float(t[0]))
        igs.append(float(t[3]))
        ids.append(float(t[1]))
        
    # Plot out the bias points to gauge different regions, sanity check
    if plot == 'bias_plane':
        plt.scatter(np.array(vds),np.array(vgs))
        plt.xlabel('Vds(V)')
        plt.ylabel('Vgs(V)')
        plt.show()
        
    elif plot == 'dciv':
        plt.scatter(np.array(vds),np.array(ids))
        plt.xlabel('Vds(V)')
        plt.ylabel('Ids(A)')
        plt.show()
        
        
    # Create training set for Ig-dc and Id-dc [Vgs,Vds,Ids]
    training_set_id,target_id,target_ig = np.array([[vgs[i],vds[i]] for i in range(len(vgs))]), np.array([[i] for i in ids]),np.array([[i] for i in igs])
    training_set_ig = np.array([[vgs[i],vds[i],igs[i]] for i in range(len(vgs))])
    
        
    return training_set_id, target_id,target_ig
    
# Need to turn this into a class- each class has     
def read_biased_spars(file):
    data_block = MctDataFile(file)
    spar_block = data_block.get_blocks_by_section('sparams')
    # Temp dict with bias and touchstone objects
    data_dict = {}
    for b in spar_block:
        if b.isempty:
            continue
        if b.v1 not in data_dict:
            data_dict[b.v1] = [[],None,None]
            data_dict[b.v1][0].append(b.v2)
            
            ts_data = StringIO()
            ts_data.write(b.format_line+'\n')
            ts_data.write(''.join(b.data_lines))
            ts_data.seek(0)
            ts = Touchstone(ts_data)
            data_dict[b.v1][1] = ts
            data_dict[b.v1][2] = convert.param_convert('s','y',ts)
            
        else:
            data_dict[b.v1][0].append(b.v2)
            
            ts_data = StringIO()
            ts_data.write(b.format_line+'\n')
            ts_data.write(''.join(b.data_lines))
            ts_data.seek(0)
            ts = Touchstone(ts_data)
            data_dict[b.v1][1] = ts
            data_dict[b.v1][2] = convert.param_convert('s','y',ts)
            
    print data_dict.keys()
    
    # Get the data in a format that can be plotted
    vds = []
    imagy11 = []
    for vgs in data_dict.iterkeys():
        for d in data_dict[vgs][0]:
            vds.append(d)
        for y in data_dict[vgs][2]:
            w = 2*np.pi*y.freq
            y_mat = np.imag(y.data)/w
            imagy11.append(y_mat[0,0])
            
                
    print len(imagy11)
    print len(vds)
    print vds
    
def read_intrinsic_spars(file):
    
       


# Create Multi Layer Perceptron
class mlp(object):
    """
    nhidden is the number of hidden layer neurons
    inputs - training data
    targets - desired output
    """      
    def __init__(self,inputs,targets,nhidden,beta = 1,momentum = 0.9,outtype = 'logistic'):
        self.nin = np.shape(inputs)[1]
        self.nout = np.shape(targets)[1]
        self.ndata = np.shape(inputs)[0]
        self.nhidden = nhidden

        self.beta = beta
        self.momentum = momentum
        self.outtype = outtype
        
        # Initialize the weights to random values
        self.weights1 = (np.random.rand(self.nin+1,self.nhidden) - 0.5)*2/np.sqrt(self.nin)
        self.weights2 = (np.random.rand(self.nhidden+1,self.nout)-0.5)*2/np.sqrt(self.nhidden)
        
    def earlystopping(self,inputs,targets,valid,validtargets,eta,niterations=200):
    
        valid = np.concatenate((valid,-np.ones((np.shape(valid)[0],1))),axis=1)
        
        old_val_error1 = 100002
        old_val_error2 = 100001
        new_val_error = 100000
        
        count = 0
        while (((old_val_error1 - new_val_error) > 0.001) or ((old_val_error2 - old_val_error1)>0.001)):
            count+=1
            print count
            self.mlptrain(inputs,targets,eta,niterations)
            old_val_error2 = old_val_error1
            old_val_error1 = new_val_error
            validout = self.mlpfwd(valid)
            new_val_error = 0.5*np.sum((validtargets-validout)**2)
            
        print "Stopped", new_val_error,old_val_error1, old_val_error2
        return new_val_error 

    def mlptrain(self,inputs,targets,eta,niterations):
        """ Train the thing """    
        # Add the inputs that match the bias node
        inputs = np.concatenate((inputs,-np.ones((self.ndata,1))),axis=1)
        change = range(self.ndata)
    
        updatew1 = np.zeros((np.shape(self.weights1)))
        updatew2 = np.zeros((np.shape(self.weights2)))
            
        for n in range(niterations):
    
            self.outputs = self.mlpfwd(inputs)

            error = 0.5*np.sum((self.outputs-targets)**2)
            if (np.mod(n,100)==0):
                print "Iteration: ",n, " Error: ",error    

            # Different types of output neurons
            if self.outtype == 'linear':
            	deltao = (self.outputs-targets)/self.ndata
            elif self.outtype == 'logistic':
            	deltao = self.beta*(self.outputs-targets)*self.outputs*(1.0-self.outputs)
            elif self.outtype == 'softmax':
                deltao = (self.outputs-targets)*(self.outputs*(-self.outputs)+self.outputs)/self.ndata 
            else:
            	print "error"
            
            deltah = self.hidden*self.beta*(1.0-self.hidden)*(np.dot(deltao,np.transpose(self.weights2)))
                      
            updatew1 = eta*(np.dot(np.transpose(inputs),deltah[:,:-1])) + self.momentum*updatew1
            updatew2 = eta*(np.dot(np.transpose(self.hidden),deltao)) + self.momentum*updatew2
            self.weights1 -= updatew1
            self.weights2 -= updatew2
                
            # Randomise order of inputs (not necessary for matrix-based calculation)
            #np.random.shuffle(change)
            #inputs = inputs[change,:]
            #targets = targets[change,:]
            
    def mlpfwd(self,inputs):
        """ Run the network forward """
        
        
        self.hidden = np.dot(inputs,self.weights1);
        self.hidden = 1.0/(1.0+np.exp(-self.beta*self.hidden))
        self.hidden = np.concatenate((self.hidden,-np.ones((np.shape(inputs)[0],1))),axis=1)

        outputs = np.dot(self.hidden,self.weights2);

        # Different types of output neurons
        if self.outtype == 'linear':
        	return outputs
        elif self.outtype == 'logistic':
            return 1.0/(1.0+np.exp(-self.beta*outputs))
        elif self.outtype == 'softmax':
            normalisers = np.sum(np.exp(outputs),axis=1)*np.ones((1,np.shape(outputs)[0]))
            return np.transpose(np.transpose(np.exp(outputs))/normalisers)
        else:
            print "error"
            
        
    def confmat(self,inputs,targets):
        """Confusion matrix"""

        # Add the inputs that match the bias node
        inputs = np.concatenate((inputs,-np.ones((np.shape(inputs)[0],1))),axis=1)
        outputs = self.mlpfwd(inputs)
        
        nclasses = np.shape(targets)[1]

        if nclasses==1:
            nclasses = 2
            outputs = np.where(outputs>0.5,1,0)
        else:
            # 1-of-N encoding
            outputs = np.argmax(outputs,1)
            targets = np.argmax(targets,1)

        cm = np.zeros((nclasses,nclasses))
        for i in range(nclasses):
            for j in range(nclasses):
                cm[i,j] = np.sum(np.where(outputs==i,1,0)*np.where(targets==j,1,0))

        print "Confusion matrix is:"
        print cm
        print "Percentage Correct: ",np.trace(cm)/np.sum(cm)*100

class adjoint_mlp(object):
    
    def __init__(self,inputs,targets,nhidden,beta = 1,momentum = 0.9,outtype = 'logistic'):
        # Inputs is an array of 1's
        pass
        
    def adjoint_train(self,inputs,training_set,)
        

      
    
    
if __name__ == "__main__":
    import os
    path = os.getcwd()
    
    
    """
    tr_file = os.path.join(path,'0403_pcm_4x100um_dciv.txt')
    valid_file = os.path.join(path,'0603_pcm_4x100um_dciv.txt')
    tr_set_id, targets_id,targets_ig = create_training_set(tr_file)
    valid, valid_id,valid_ig = create_training_set(valid_file)        
        
    # train the MLP for Id prediction
    net1 = mlp(tr_set_id, targets_id,nhidden = 23,outtype = 'linear')
    net1.mlptrain(tr_set_id,targets_id,0.25,501)
    net1.earlystopping(tr_set_id,targets_id,valid,valid_id,0.25)
    
    # train the mlp for Ig prediction
    net2 = mlp(tr_set_id,targets_ig,nhidden = 23,outtype = 'linear')
    net2.mlptrain(tr_set_id,targets_ig,0.25,501)
    net2.earlystopping(tr_set_id,targets_ig,valid,valid_ig,0.25)
        
    # Append -1's to the set
    valid_id = np.concatenate((tr_set_id,-np.ones((np.shape(tr_set_id)[0],1))),axis = 1)    
    outputs_id = net1.mlpfwd(valid_id)
    
    valid_ig = np.concatenate((tr_set_id,-np.ones((np.shape(tr_set_id)[0],1))),axis = 1)
    outputs_ig = net2.mlpfwd(valid_ig)
       
    
    vd_meas,id_meas = tr_set_id[:,1],targets_id
    vd_modeled, id_modeled = valid[:,1],outputs_id
    
    vg_meas,ig_meas = tr_set_id[:,1],targets_ig
    vg_modeled, ig_modeled = valid[:,1],outputs_ig
    
    plt.plot(vd_meas,id_meas,'o',vd_modeled,id_modeled,'*')
    plt.show()
    
    plt.plot(vg_meas,ig_meas,'o',vg_modeled,ig_modeled,'*')
    plt.show()
    
    """
    fname = os.path.join(path,'dev1_4x100_178201004_dcs.dat')
    read_biased_spars(fname)
    
        
    
    
         
    
    

