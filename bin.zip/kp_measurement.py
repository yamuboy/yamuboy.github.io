#!/usr/bin/env python
import os, sys, time
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
import instrument

INSTR = {
    #'bias1':['k23x','GPIB::21',{'remote':True,'resolution':'high'}],
    #'bias2':['k23x','GPIB::23',{'remote':True,'resolution':'high'}],
    'bias1':['b2902','GPIB::25',{'chan':2,'remote':True,'resolution':'high'}],
    'bias2':['b2902','GPIB::25',{'chan':1,'remote':True,'resolution':'high'}],
    #'prober':['12k','GPIB::28',{}],
    #'siggen':['SCPISigGen','GPIB::19',{}],
}
def main():
    filename=raw_input("Enter Filename for test data?\n")
    if os.path.exists(filename):
        r=raw_input("%s exists-overwrite?(y/n)"%filename).strip().lower()
        if not r.startswith('y'):
            return
    
    gate = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    drain = instrument.create('bias',*(INSTR['bias2'][:2]),**(INSTR['bias2'][2]))

    
    f= open(filename,'w')
    f.write('!Simple DC Measurement\n')
    f.write('!Vd= 0-5V, Vg=0V\n')
    f.write('!Vd\tId\n')
    try:
       dc_measure(gate,drain,f)
    except KeyboardInterrupt:
       drain.set_state(0)
       timed_wait_ms(50)
       gate.set_state(0)
       timed_wait_ms(50)
       f.close()
    

def dc_measure(gate,drain,f):
    i=0.0
    gate.config(mode='V',vset=0.0, ilimit=4.0e-3,state=0)
    timed_wait_ms(20)
    drain.config(mode='V',vset=0.0, ilimit= 0.2,state=0)
    timed_wait_ms(30)
    while(True):
        if i>=5.0:
             break
        else:
             gate.set_state(1)
             timed_wait_ms(20)
             drain.config(vset=i,state=1)
             timed_wait_ms(30)
             ids= drain.measure()
             f.write('%+0.4e\t%+0.4e\n'%(i,ids))
             f.flush()
        i=i+0.1
    drain.set_state(0)
    timed_wait_ms(50)
    gate.set_state(0)
    timed_wait_ms(50)

def transfer(gate,drain,f):
    vds= [0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5.0]
    gate.config(mode='I',iset=0.6e-3,vlimit=10.0,state=0)
    drain.config(mode='V',vset=0.0, ilimit=0.2,state=0)
    for i in vds:
        gate.set_state(1)
        timed_wait_ms(20)
        drain.config(vset=i,state=1)
        timed_wait_ms(30)
        ids= drain.measure()
        f.write('%+0.4e\t%+0.4e\n'%(i,ids))
        f.flush()
    drain.set_state(0)
    timed_wait_ms(50)
    gate.set_state(0)
    timed_wait_ms(50)
    
if __name__=="__main__":
    main()
    

