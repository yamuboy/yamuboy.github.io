#!/usr/bin/env python
###############################################
# parker_sum parker.model [parker.model2...]
##############################################

import sys

def usage():
    print "\nUsage: parker_sum.py parker.model [parker.model2....]\n"

def find(x):
    q=x.rfind(":")
    return x[q+1:]

def header1(x):
    try:
        f=open(x,"r")
    except:
        usage()
        sys.exit()
    header = ""
    for line in f.readlines():
        if line.startswith("!PROCESS NAME"):
            header += line
        if line.startswith("!DEVICE NAME"):
            header += line
        if line.startswith("!GATE LENGTH"):
            header += line
        if line.startswith("!GATE TO GATE SPACING"):
            header += line
        if line.startswith("!SOURCE-DRAIN"):
            header += line
            break
    header +="\n"
    header += "!Model Dev Lot Temp Periphery UGW NGF Vbr(.1mA) Vbr(1mA) Idss(3V) Vpo(3V) Imax(1.5V) Vpo(1.5V) Vmax(1.5V) Vpo(1mA/mm) Ron(ohms)\n"
    header += "!              (C)   (um)    (um)\n"
    return header

def header2(x,i):
    header =""
    i +=1
    header += "!%d"%i
    flag = 0
    f=open(x,"r")
    for line in f.readlines():
        if line.startswith("!FILE NAME"):
            q = line.rfind(":")
            p = line.rfind(".")
            dev = line[q+1:p-2]
            header += dev
        if line.startswith("!WAFER NUMBER"):
            header += find(line.strip())
        if line.startswith("!TEMPERATURE"):
            header += find(line.strip())
        if line.startswith("!GATE PERIPHERY"):
            header += find(line.strip())
        if line.startswith("!UNIT GATE WIDTH"):
            header += find(line.strip())
        if line.startswith("!NUMBER OF GATE FINGER"):
            header += find(line.strip())
        if flag:
            header += line.lstrip('!')
            break
        if line.startswith("!Vbr"):
            flag = 1
    return header

def main():

    if len(sys.argv) < 2:
        usage()
        sys.exit()

    mdf = open("parker.mdf","w")
    mdf.writelines(header1(sys.argv[1]))
    for i,d in enumerate(sys.argv[1:]):
        mdf.writelines(header2(d,i))
    for i,d in enumerate(sys.argv[1:]):
        mdf.writelines("\n\n")
        x = open(d,"r")
        for line in x.readlines():
            if line.startswith("VAR model"): 
                i+=1
                mdf.writelines("VAR model = %s\n" %i)
            else: mdf.writelines(line)
    mdf.close()

if __name__=="__main__":
    main()
