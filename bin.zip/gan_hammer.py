#!/usr/bin/env python

import visa
import pyvisa, pyvisa.constants
import os, sys, time, traceback
import ganlag
import instrument
import mautils.cli_utils
import cPickle as pickle
from testsoft.wafermap import WaferMap
from datetime import datetime
from datetime import timedelta
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
from math import floor
import logging

DEFAULT_CONFIGFILE = 'gan_hammer.cfg'

def preview_map(cfg, maptype):

    # open wafer map
    wafer_map = WaferMap()

    if maptype is 'Downpoint':
        wmap_filename = cfg['downpoint_mapfile']
    elif maptype is 'Stress':
        wmap_filename = cfg['stress_mapfile']

    if not os.path.exists(wmap_filename):
        print "specified map file %s does not exist!" % wmap_filename
        return

    wafer_map.read_map(wmap_filename)
    print "using wafer map %s" % wmap_filename

   # open prober
    mgr = InstrumentManager()

    while True:
        try:
            prober = mgr.open_driver(*(cfg['prober']))
            break
        except instrument.errors.InstrumentError:
            raw_input("\nError inititalizing prober. Ensure the prober is in contact position, then press Enter")

    # loop over devices
    try:
        for i in range(len(wafer_map)):

            x, y = wafer_map.compute_pos(i)
            site = wafer_map.get_site_name(i)

            if i is 0:
                raw_input('Ensure prober is positioned at device %s. Press Enter to continue' % site)
                start_x, start_y = prober.get_position()

            # move prober to device
            if i > 0:
                prober.set_position_synch(start_x + x, start_y + y)

            raw_input("At device %s, (%d, %d). Press Enter to move to next device." % (site, x, y))

    except KeyboardInterrupt:
        print "\nMap preview canceled."

    finally:
        prompt = raw_input("Enter \"y\" to move to first device %s, otherwise just press Enter: " % wafer_map.get_site_name(0))
        if prompt is "y" or prompt is "Y":
            prober.set_position_synch(start_x, start_y)
        prober.close()

# general test functions
def initialize_test(cfg, test):

    # open instruments
    mgr = InstrumentManager()

    while True:
        try:
            prober = mgr.open_driver(*(cfg['prober']))
            break
        except instrument.errors.InstrumentError:
            raw_input("\nError inititalizing prober. Ensure the prober is in contact position, then press Enter")
        except KeyboardInterrupt:
            print "Test canceled, returning to main menu!"
            return
    try:
        gate_smu = cfg['gate_smu']
        drain_smu = cfg['drain_smu']
        # if gate/drain SMU parameters are lists of equal length, open all listed instruments and store them in lists
        if all(isinstance(i, list) for i in [gate_smu, drain_smu]) and (len(gate_smu) == len(drain_smu)):
            gate = [ ]
            drain = [ ]
            for g, d in zip(gate_smu, drain_smu):

                # ensure that gate/drain SMUs are listed in same order, assuming single device is powered by same B2902,
                # so address should be the same between both
                address = g[1]
                if not d[1] == address:
                    raise RuntimeError

                gate.append(instrument.create('bias', *(g[:2]), **(g[2])))
                drain.append(instrument.create('bias', *(d[:2]), **(d[2])))

        # if gate/drain SMU are 3-tuples, then store handles to each instrument individually
        elif all((isinstance(i, tuple) and len(i) == 3) for i in [gate_smu, drain_smu]):
            gate = instrument.create('bias',*(gate_smu[:2]),**(gate_smu[2]))
            drain = instrument.create('bias',*(drain_smu[:2]),**(drain_smu[2]))

        # problem with SMU configuration, throw error
        else:
            raise RuntimeError

    except:
        print "Error in initializing instruments, returning to main menu!"
        return

    # prompt for test description, generate filenames
    filename = raw_input("Enter test name: ")
    picklefilename = filename + '.pkl'
    outputfilename = filename + '.csv'
    for name in [picklefilename, outputfilename]:
        if os.path.exists(name):
            r = raw_input("%s exists-overwrite?(y/n)"%name).strip().lower()
            if not (r.startswith('y') or r.startswith('Y')):
                print "\nCan't output to chosen file %s, aborting test and returning to main menu!\n"%name
                return

    # run the test
    try:
        run_test(cfg, test, picklefilename, outputfilename, prober, gate, drain)

    except KeyboardInterrupt:
        print "\nTest aborted! Returning to main menu...\n"

    except Exception:
        traceback.print_exc()

    finally:
        # close instruments

        # multiple sites
        if all(isinstance(i, list) for i in (gate, drain)):
            for g, d in zip(gate, drain):
                d.close()
                g.close()

        # single site
        else:
            drain.close()
            gate.close()

        prober.close()

def run_test(cfg, test, pfname, ofname, prober, sgate, sdrain):

    # open wafer map
    wmap = WaferMap()

    if test is 'Downpoint':
        wmap_filename = cfg['downpoint_mapfile']
    elif test is 'Stress':
        wmap_filename = cfg['stress_mapfile']

    if not os.path.exists(wmap_filename):
        print "specified map file %s does not exist!" % wmap_filename
        return

    wmap.read_map(wmap_filename)
    print "using wafer map %s" % wmap_filename

    data = {}

    # open output file
    fp = open(ofname, 'w')

    # create directory for output pickle files if it doesn't exist
    if not os.path.exists('pkl'):
        os.mkdir('pkl')

    # run test
    index = 0
    testedsites = []

    # multi-site
    # assume sgate and sdrain are lists and are already same length (checked in test initialization function)
    if isinstance(sgate, list):

        # ensure number of sites in wafer map are identical to number of initialized SMUs
        if not len(wmap) == len(sgate):
            print "Invalid wafer map for multi-site test, map must have same number of sites as initialized SMUs"
            return

        prompt_str = 'Ensure probes are positioned on devices as follows:\n'

        # get all sites and add them to the prompt string
        site = [ ]
        sitedata = [ ]
        for idx in range(len(wmap)):
            site_name = wmap.get_site_name(idx)
            site.append(site_name)
            sitedata.append(wmap.get_site_data(idx))
            prompt_str += '\tSMU %s (%s): %s\n'%(idx, sgate[idx].vi._resource_name, site_name)

        prompt_str += 'Press Enter to continue'
        raw_input(prompt_str)

        # get initial prober position
        start_x, start_y = prober.get_position()

        # write file header
        write_file_header(cfg, fp, test, ' '.join(site), start_x, start_y)

        # gather corresponding data
        if test is 'Downpoint':
            for s, sd, g, d in zip(site, sitedata, sgate, sdrain):
                newcfg = cfg.copy()
                if sd is not None:
                    for key, val in sd.iteritems():
                        newcfg[key] = val
                        print "Using cfg[%s]: %s as defined in map file instead of in %s for site %s"%(key,val,DEFAULT_CONFIGFILE,s)

                data[s] = run_downpoint(newcfg, fp, s, g, d)

        elif test is 'Stress':
            try:
                data = run_stress(cfg, fp, site, sgate, sdrain)

                testcfg = data[0]
                testdata = data[1]

                periph = cfg['ugw']*cfg['ngf']

                # write data file
                # iterate over all sites
                for idx in range(len(site)):

                    x, y = site[idx][:2], site[idx][2:]

                    # write all data for this site
                    for t, igs, ids in zip(testdata[idx]['time'], testdata[idx]['ig'], testdata[idx]['id']):
                        fp.write("\n")
                        fp.write(x)
                        fp.write(',')
                        fp.write(y)
                        fp.write(',')
                        fp.write("%f,"%(periph*1.0e-3))
                        fp.write("%e,%e,%e,%e,%e,%e,%e"%(t, igs*1.0e3, ids*1.0e3, abs(igs*1.0e6/periph), ids*1.0e6/periph, testdata[idx]['vg'], testdata[idx]['vd']))

                    # linebreak between sites
                    fp.write("\n")
                    fp.flush()

            except KeyboardInterrupt:
                sys.stdout.write("\nTest canceled.")

    # single site
    else:
        while index < len(wmap):
            # get current site
            x, y = wmap.compute_pos(index)
            site = wmap.get_site_name(index)

            # if site has already been tested, skip to next site
            if site in testedsites:
                continue

            # move prober to device
            if index == 0:
                raw_input('Ensure prober is positioned at device %s. Press Enter to continue' % site)

                # get initial prober position
                start_x, start_y = prober.get_position()

                # write file header
                write_file_header(cfg, fp, test, site, start_x, start_y)

            else:
                prober.set_position_synch(start_x + x, start_y + y)

            # reload config file
            load_config_file(cfg, DEFAULT_CONFIGFILE)

            # update wafer map
            wmap.update_map(wmap_filename)
            sitedata = wmap.get_site_data(index)

            if sitedata is not None:
                for key,val in sitedata.iteritems():
                    cfg[key] = val
                    print "Using cfg[%s]: %s as defined in map file instead of in %s"%(key,val,DEFAULT_CONFIGFILE)

            # gather corresponding data
            if test is 'Downpoint':
                data[site] = run_downpoint(cfg, fp, site, sgate, sdrain)

            elif test is 'Stress':
                try:
                    #open device-specific stress pickle file
                    path = os.getcwd() + '/pkl/' + "%s_%s"%(site, pfname)
                    devicefile = open(path, 'wb')
                    devicedata = {}
                    data[site] = run_stress(cfg, fp, site, sgate, sdrain)
                    devicedata[site] = data[site]
                    fp.write('\n')

                    # write and close device specific pickle file
                    if devicedata[site] is not None:
                        pickle.dump(devicedata, devicefile)
                        devicefile.close()

                except KeyboardInterrupt:
                    sys.stdout.write("\nTest canceled.")
                    break

            # mark this site as tested
            testedsites.append(site)

            # move to next site
            index += 1

            # end after all sites have been attempted
            if len(testedsites) >= len(wmap):
                break

    # write output files
    if len(data) > 0:
        fp.close()
        path = os.getcwd() + '/pkl/' + pfname
        pkl = open(path, 'wb')
        pickle.dump(data, pkl)
        pkl.close()

        print "\nTest Complete!\n"

    # prompt return to initial device only for single-site
    if not isinstance(site, list):
        prompt = raw_input("Enter \"y\" to move to first device %s, otherwise just press Enter: " % wmap.get_site_name(0) )
        if prompt is "y" or prompt is "Y":
            prober.set_position_synch(start_x, start_y)

def write_file_header(cfg, fp, test, start_site, start_x, start_y):

    fp.write('!GaN Multisite Rapid %s Data\n' % test)
    fp.write('!Test Date:,%s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    fp.write('!Wafer:,%s\n'%cfg['wafer'])
    fp.write('!Device:,%s\n'%cfg['device'])
    fp.write('!Starting stage coordinates:,\'%s\',x: %d,y: %d\n'%(start_site, start_x, start_y))

    # write corresponding table header
    if test is 'Downpoint':
        num_diode_pts = range(0, len(cfg['fwd_target_ig_uamm']))
        num_txfr_pts = range(0, len(cfg['txfr_target_id_mamm']))
        periph = cfg['ngf']*cfg['ugw']

        # create table header
        fp.write("x,y,periphery [mm],")

        # downpoint columns
        for i in num_diode_pts:
            fp.write("fwd_diode_vg_%d [V],"%i)
        for i in num_diode_pts:
            fp.write("fwd_diode_ig_%d [A],"%i)
        for i in num_diode_pts:
            fp.write("fwd_diode_ig_%d [mA/mm],"%i)
        fp.write("imax [A],imax [mA/mm],ron [Ohm],ron [Ohm-mm],")
        for i in num_txfr_pts:
            fp.write("fwd_txfr_vg_%d [V],"%i)
        for i in num_txfr_pts:
            fp.write("fwd_txfr_id_%d [A],"%i)
        for i in num_txfr_pts:
            fp.write("fwd_txfr_id_%d [mA/mm],"%i)
        fp.write("leakage_id [A],leakage_ig [A],leakage_is [A],leakage_id [mA/mm],|leakage_ig| [mA/mm],|leakage_is| [mA/mm],")
        fp.write("\n")

    elif test is 'Stress':

        # create table header
        fp.write("x,y,periphery [mm],")

        # stress columns
        fp.write("t [s],ig [mA],id [mA],|ig| [mA/mm],id [mA/mm],Vg [V],Vd [V]")

# downpoint functions
def run_downpoint(cfg, fp, site, sgate, sdrain):
    #f.write('\n!site: %s\n'%site)

    print('\nRunning downpoint at %s' % site)

    periph = cfg['ngf']*cfg['ugw']

    fwd_data = fwd_points(cfg, sgate, sdrain)
    iv_data = imax_ron(cfg, sgate, sdrain)
    txfr_data = txfr_points(cfg, sgate, sdrain)
    leakage_data = leakage_point(cfg, sgate, sdrain)

    # gather data for columns
    diode_vg = fwd_data[0]
    diode_ig = fwd_data[1]
    diode_ig_norm = [x*1.0e6/periph for x in diode_ig]
    imax = iv_data[0]
    imax_norm = imax*1.0e6/periph
    ron = iv_data[1]
    ron_norm = ron*periph*1.0e-3
    txfr_vg = txfr_data[0]
    txfr_id = txfr_data[1]
    txfr_id_norm = [x*1.0e6/periph for x in txfr_id]
    leakage_ig = leakage_data[1]
    leakage_ig_norm = abs(leakage_ig*1.0e6/periph)
    leakage_id = leakage_data[0]
    leakage_id_norm = leakage_id*1.0e6/periph
    leakage_is = leakage_data[2]
    leakage_is_norm = abs(leakage_is*1.0e6/periph)

    x, y = site[:2], site[2:]
    fp.write(x)
    fp.write(',')
    fp.write(y)
    fp.write(',')

    # write data
    fp.write("%f,"%(periph*1.0e-3))
    for i in diode_vg:
        fp.write("%e,"%i)
    for i in diode_ig:
        fp.write("%e,"%i)
    for i in diode_ig_norm:
        fp.write("%e,"%i)
    fp.write("%e,%e,%e,%e," % (imax, imax_norm, ron, ron_norm))
    for i in txfr_vg:
        fp.write("%e,"%i)
    for i in txfr_id:
        fp.write("%e,"%i)
    for i in txfr_id_norm:
        fp.write("%e,"%i)
    fp.write("%e,%e,%e,%e,%e,%e," % (leakage_id, leakage_ig, leakage_is, leakage_id_norm, leakage_ig_norm, leakage_is_norm))

    fp.write("\n")
    fp.flush()

    data = {'fwd': fwd_data, 'iv': iv_data, 'txfr': txfr_data, 'leakage': leakage_data}
    return (cfg, data)

def fwd_points( cfg, sgate, sdrain ):
    "capture the forward I-V curve of the device"

    print('\nCapturing forward diode points')

    periph = cfg['ugw']*cfg['ngf']
    vgmax = cfg['vg_max']
    igmax = cfg['fwd_ig_max_mamm']*periph*1.0e-6
    idlim = igmax*4.0
    vds = cfg['fwd_vd']
    target_ig_list = [x*periph*1.0e-9 for x in cfg['fwd_target_ig_uamm']]
    meas_delay = cfg['fwd_meas_delay_ms']

    vg = []
    ig = []

    # turn on sources
    sdrain.config(mode='V',vset=vds,state=1,ilimit=idlim,resolution='high',remote=True)
    timed_wait_ms(50)
    sgate.config(mode='I',iset=0.0,state=1,vlimit=vgmax,resolution='high',remote=True)

    # set the initial SMU range
    current_range = target_ig_list[0]*100.0
    sgate.config(irange=current_range)

    for igs in target_ig_list:
        # check for range changes
        if igs > current_range:
            current_range *= 100.0
            sgate.config(irange=current_range)

        # set gate current, wait for settle
        sgate.config(iset=igs)
        timed_wait_ms(cfg['fwd_meas_delay_ms'])

        # take measurement
        vgs = sgate.measure()
        ids = sdrain.measure()
        vg.append(vgs)
        ig.append(igs)

    # turn off sources
    sgate.set_state(0)
    timed_wait_ms(50)
    sdrain.set_state(0)

    return (vg, ig)

def imax_ron( cfg, sgate, sdrain ):
    """Capture a set of I-V data from the device."""

    print('\nCapturing Imax and Ron')

    periph = cfg['ugw']*cfg['ngf']
    iglim = cfg['ig_max_mamm']*periph*1.0e-6
    idlim = cfg['idss_id_max_mamm']*periph*1.0e-6

    # set the initial gate and drain current limits
    sgate.config(mode='V',ilimit=iglim,resolution='medium',remote=True)
    sdrain.config(mode='V',ilimit=idlim,resolution='medium',remote=True)
    power_limit = cfg['power_limit_wmm']*periph*1.0e-3

    # measure imax
    vgs = cfg['idss_vg']
    vds = cfg['idss_vd']
    sgate.config(vset=vgs, state=1)
    timed_wait_ms(50)
    sdrain.config(vset=vds, state=1)
    timed_wait_ms(cfg['iv_meas_delay_ms'])
    igs = sgate.measure()
    imax = sdrain.measure()

    # turn off drain source
    sdrain.config(state=0)

    idlim = cfg['ron_id_max_mamm']*periph*1.0e-6
    sdrain.config(ilimit=idlim)

    # measure ron
    vgs = cfg['ron_vg']
    vds = cfg['ron_vd']
    sgate.config(vset=vgs)
    timed_wait_ms(50)
    sdrain.config(vset=vds, state=1)
    timed_wait_ms(cfg['iv_meas_delay_ms'])
    igs = sgate.measure()
    ids = sdrain.measure()
    ron = vds / ids

    # turn off sources
    sdrain.set_state(0)
    timed_wait_ms(50)
    sgate.set_state(0)

    return (imax, ron)

def txfr_points( cfg, sgate, sdrain ):
    "measure the transfer curve"

    print('\nCapturing transfer curve points')

    periph = cfg['ugw']*cfg['ngf']
    iglim = cfg['txfr_ig_max_mamm']*periph*1.0e-6
    idlim = cfg['txfr_id_max_mamm']*periph*1.0e-6
    vdrain = cfg['txfr_drain_voltage']
    vgs = cfg['initial_vg']
    vg_step = cfg['initial_vg_step']
    vg_min = cfg['vg_min']
    vg_max = cfg['vg_max']
    step_factor = cfg['step_factor']
    tol = cfg['txfr_target_id_tolerance_dec_ma']
    target_id_list = [x*periph*1.0e-6 for x in cfg['txfr_target_id_mamm']]
    power_limit = cfg['power_limit_wmm']*periph*1.0e-3
    idlimp = power_limit / vdrain
    if idlimp < idlim:
        idlim = idlimp

    vg = []
    id = []

    sgate.config(mode='V',vset=vgs,state=1,ilimit=iglim,resolution='high',remote=True)
    timed_wait_ms(50)
    sdrain.config(mode='V',vset=vdrain,state=1,ilimit=idlim,resolution='high',remote=True)

    for ids in target_id_list:
        # find current and settle
        vgs = find_target_Ids(ids, tol, vgs, vg_step, step_factor, vg_max, vg_min, sgate, sdrain)
        timed_wait_ms(cfg['txfr_meas_delay_ms'])

        # take measurement
        igs = sgate.measure()
        ids = sdrain.measure()
        vg.append(vgs)
        id.append(ids)

        # step vg down by one step for next point
        vgs -= vg_step

    # disable sources
    sdrain.set_state(0)
    timed_wait_ms(50)
    sgate.set_state(0)

    return (vg, id)

def leakage_point( cfg, sgate, sdrain ):
    "measure the leakage curve"

    print('\nCapturing leakage points')

    periph = cfg['ugw']*cfg['ngf']
    iglim = cfg['leakage_ig_max_mamm']*periph*1.0e-6
    idlim = cfg['leakage_id_max_mamm']*periph*1.0e-6
    vgate = cfg['leakage_gate_voltage']
    vdrain = cfg['leakage_drain_voltage']

    # set sources and wait for settling
    sgate.config(mode='V',vset=vgate,state=1,ilimit=iglim,resolution='high',remote=True)
    timed_wait_ms(50)
    sdrain.config(mode='V',vset=vdrain,state=1,ilimit=idlim,resolution='high',remote=True)
    timed_wait_ms(cfg['leakage_meas_delay_ms'])

    # take measurement
    igs = sgate.measure()
    ids = sdrain.measure()

    # turn off sources
    sdrain.set_state(0)
    timed_wait_ms(50)
    sgate.set_state(0)

    return (ids, igs, -(ids + igs))

# stress functions
def run_stress(cfg, fp, site, sgate, sdrain):
    "stress the device and measure at specified intervals"

    periph = cfg['ugw']*cfg['ngf']
    iglim = cfg['stress_ig_max_mamm']*periph*1.0e-6
    igcomp = 2.0*iglim
    idlim = cfg['stress_id_max_mamm']*periph*1.0e-6
    power_limit = cfg['power_limit_wmm']*periph*1.0e-3
    vdrain = cfg['stress_vd']
    target_id = cfg['stress_target_id_mamm']*periph*1.0e-6
    vgate = cfg['initial_vg']
    vg_step = cfg['initial_vg_step']
    vg_max = cfg['vg_max']
    vg_min = cfg['vg_min']
    tol = cfg['stress_target_id_tolerance_dec_ma']
    poll = cfg['stress_poll_interval_msec']
    interval = cfg['stress_meas_interval_sec']
    duration = cfg['stress_meas_duration_sec']

    # multi-site
    if isinstance(site, list):

        num_sites = len(site)
        idx_list = range(num_sites)

        if not isinstance(vgate, list):
            vgate = [vgate]*num_sites

        if not isinstance(vdrain, list):
            vdrain = [vdrain]*num_sites

        if not isinstance(cfg['post_stress_lag'], list):
            cfg['post_stress_lag'] = [cfg['post_stress_lag']]*num_sites

        time_list = [[] for i in idx_list]
        ig_list = [[] for i in idx_list]
        id_list = [[] for i in idx_list]

        # turn on sources
        for idx in idx_list:
            sgate[idx].config(mode='V', vset=vgate[idx], state=1, ilimit=igcomp, resolution='high', remote=True)
            timed_wait_ms(50)
            sdrain[idx].config(mode='V', vset=vdrain[idx], state=1, ilimit=idlim, resolution='high', remote=True)

            # increase timeouts
            sgate[idx].timeout = 10000
            sdrain[idx].timeout = 10000

            print('\nDetermining Vg for device %s' % site[idx])

            # adjust vg to desired current, then shut off drain bias
            try:
                vgate[idx] = find_target_Ids(target_id, tol, vgate[idx], vg_step, cfg['step_factor'], vg_max, vg_min, sgate[idx], sdrain[idx])
                timed_wait_ms(50)
                sdrain[idx].config(state=0)

            except KeyboardInterrupt:
                # turn off sources
                timed_wait_ms(500)
                sdrain[idx].config(state=0)
                timed_wait_ms(500)
                sgate[idx].config(state=0)

                r = raw_input("\rTest for site %s canceled. Enter 'c' to cancel test, otherwise just press Enter to continue test: " % site[idx])
                if r is 'c':
                    raise
                else:
                    site[idx] = None

            timed_wait_ms(500)

        # begin stress
        start_time = datetime.now()
        next_time = start_time
        end_time = start_time + timedelta(seconds=duration)
        poll_time = start_time + timedelta(milliseconds=poll)
        current_time = start_time

        print('Start Time: %s'%start_time.strftime('%Y/%m/%d %H:%M:%S'))
        print('End Time: %s'%end_time.strftime('%Y/%m/%d %H:%M:%S'))

        monitorfiles = [None]*num_sites
        failed = [False]*num_sites

        for idx in idx_list:
            monitorfiles[idx] = open('temp_dclife_%s.dat'%site[idx], 'w')
            monitorfiles[idx].write("Timestamp\tIgate\tIdrain\n")
            failed[idx] = site[idx] is None

        pollGate = True

        # turn on drains
        for idx in idx_list:
            if site[idx] is not None:
                sdrain[idx].config(state=1)

        # take t0 measurements
        igs = [0.0]*num_sites
        ids = [0.0]*num_sites

        for idx in idx_list:
            if site[idx] is not None:
                igs[idx] = sgate[idx].measure()
                ids[idx] = sdrain[idx].measure()

        # begin loop
        while True:
            try:
                # wait for the next poll time
                current_time = datetime.now()
                while current_time < poll_time:
                    td = poll_time - current_time
                    sleep_interval = td.seconds + td.microseconds*1.0e-6
                    if sleep_interval < 0.001:
                        break
                    time.sleep(sleep_interval)

                    # update current time
                    current_time = datetime.now()

                # update next poll time this is done in
                # loop in case the time spent measuring the
                # current is greater than the poll interval
                # which could cause the polling to get behind
                while poll_time <= current_time:
                    poll_time += timedelta(milliseconds=poll)

                # measure only one source at each poll, but don't log until interval is exceeded
                pollGate = not pollGate

                # if gate limit or drain compliance reached, end test for device
                if pollGate:
                    for idx in idx_list:
                        if not failed[idx]:
                            igs[idx] = sgate[idx].measure()
                            if sgate[idx].ask_if_limiting():
                                print 'Device %s reached gate compliance, ending test!'%site[idx]
                                failed[idx] = True
                                sdrain[idx].config(state=0)
                                timed_wait_ms(500)
                                sgate[idx].config(state=0)
                                timed_wait_ms(500)
                else:
                    for idx in idx_list:
                        if not failed[idx]:
                            ids[idx] = sdrain[idx].measure()
                            if sdrain[idx].ask_if_limiting():
                                print 'Device %s reached drain compliance, ending test!'%site[idx]
                                failed[idx] = True
                                sdrain[idx].config(state=0)
                                timed_wait_ms(500)
                                sgate[idx].config(state=0)
                                timed_wait_ms(500)

                # reached/exceeded measurement interval
                if next_time == start_time or current_time >= next_time or all(failed):

                    # update next measurement interval
                    next_time += timedelta(seconds=interval)

                    # write to data files and console
                    for idx in idx_list:
                        if not failed[idx]:
                            monitorfiles[idx].write("%s\t%s\t%s\n"%(current_time.strftime('%Y/%m/%d %H:%M:%S'),igs[idx],ids[idx]))
                            monitorfiles[idx].flush()
                            print "Site: %s | Time: %5d s | Ig: %1.3e mA | Id: %5.3e mA | Vg: %1.3e V | Vd: %1.3e V"%(site[idx], (current_time - start_time).seconds, igs[idx]*1.0e3, ids[idx]*1.0e3, vgate[idx], vdrain[idx])

                        # update lists
                        time_list[idx].append((current_time - start_time).seconds)
                        ig_list[idx].append(igs[idx])
                        id_list[idx].append(ids[idx])

                    # if at end of test
                    if current_time >= end_time or all(failed):
                        break

                # print status to console
                sys.stdout.write("\x1b[KStressing devices %s..." % ' '.join([x if x is not None else ' ' for x in site]))
                if (current_time.second % 4 == 0):
                    sys.stdout.write('/ \r')
                elif (current_time.second % 4 == 1):
                    sys.stdout.write('-- \r')
                elif (current_time.second % 4 == 2):
                    sys.stdout.write('\\ \r')
                elif (current_time.second % 4 == 3):
                    sys.stdout.write('| \r')
                sys.stdout.flush()

            except pyvisa.VisaIOError as ex:
                # ignore timeouts
                if ex.error_code == pyvisa.constants.VI_ERROR_TMO:
                    pass
                else:
                    raise
            except KeyboardInterrupt:
                # capture time of pause
                pause_start_time = datetime.now()

                # turn off sources
                for idx in idx_list:
                    timed_wait_ms(500)
                    sdrain[idx].config(state=0)
                    timed_wait_ms(500)
                    sgate[idx].config(state=0)

                # wait for user input
                r = raw_input("\rTest paused. Enter 'c' to cancel test, otherwise just press Enter: ")

                if r is 'c':
                    # run post-stress lag measurement
                    if cfg['post_stress_lag'][idx] and not failed[idx]:

                        # turn sources back on
                        for idx in idx_list:
                            timed_wait_ms(500)
                            sgate[idx].config(state=1)
                            timed_wait_ms(500)
                            sdrain[idx].config(state=1)
                            timed_wait_ms(1000)
                            run_post_stress_lag(cfg, None, site[idx], sgate[idx], sdrain[idx])
                        raise

                # turn sources back on
                for idx in idx_list:
                    if not failed[idx]:
                        timed_wait_ms(500)
                        sgate[idx].config(state=1)
                        timed_wait_ms(500)
                        sdrain[idx].config(state=1)
                        timed_wait_ms(500)

                # capture length of pause, update interval and duration
                pause_end_time = datetime.now()
                pause_time = pause_end_time - pause_start_time
                next_time = next_time + pause_time
                poll_time = poll_time + pause_time
                end_time = end_time + pause_time
                print '\rTest paused for %d seconds. New end time: %s'%(pause_time.seconds, end_time.strftime('%Y/%m/%d %H:%M:%S'))

        # close monitor files
        for idx in idx_list:
            monitorfiles[idx].close()
            print('Finished stressing device %s\n' % site[idx])

        data = [None]*num_sites

        for idx in idx_list:

            data[idx] = {'time': time_list[idx], 'ig': ig_list[idx], 'id': id_list[idx], 'vg': vgate[idx], 'vd':vdrain[idx]}

            # run post-stress lag measurement
            if cfg['post_stress_lag'][idx] and not failed[idx]:
                run_post_stress_lag(cfg, None, site[idx], sgate[idx], sdrain[idx])

            # shut off supplies
            sdrain[idx].config(state=0)
            timed_wait_ms(500)
            sgate[idx].config(state=0)

        # return data
        return (cfg, data)

    # single-site
    else:
        time_list = []
        ig_list = []
        id_list = []

        # turn on sources
        sgate.config(mode='V', vset=vgate, state=1, ilimit=igcomp, resolution='high', remote=True)
        timed_wait_ms(50)
        sdrain.config(mode='V', vset=vdrain, state=1, ilimit=idlim, resolution='high', remote=True)
        # increase timeouts
        sgate.timeout = 10000
        sdrain.timeout = 10000

        print('\nStressing device %s' % site)

        # adjust vg to desired current
        try:
            vgate = find_target_Ids(target_id, tol, vgate, vg_step, cfg['step_factor'], vg_max, vg_min, sgate, sdrain)

        except KeyboardInterrupt:
            # turn off sources
            timed_wait_ms(500)
            sdrain.config(state=0)
            timed_wait_ms(500)
            sgate.config(state=0)

            r = raw_input("\rTest for site %s canceled. Enter 'c' to cancel test, otherwise just press Enter to continue test: " % site)
            if r is 'c':
                raise
            else:
                return None

        timed_wait_ms(500)

        # begin stress
        start_time = datetime.now()
        next_time = start_time
        end_time = start_time + timedelta(seconds=duration)
        poll_time = start_time + timedelta(milliseconds=poll)
        current_time = start_time

        print('Start Time: %s'%start_time.strftime('%Y/%m/%d %H:%M:%S'))
        print('End Time: %s'%end_time.strftime('%Y/%m/%d %H:%M:%S'))

        monitorfile = open('temp_dclife.dat', 'w')
        monitorfile.write("Timestamp\tIgate\tIdrain\n")

        failed = False
        pollGate = True

        # take t0 measurements
        igs = sgate.measure()
        ids = sdrain.measure()

        while True:
            try:
                # wait for the next poll time
                current_time = datetime.now()
                while current_time < poll_time:
                    td = poll_time - current_time
                    sleep_interval = td.seconds + td.microseconds*1.0e-6
                    if sleep_interval < 0.001:
                        break
                    time.sleep(sleep_interval)
                    # update current time
                    current_time = datetime.now()

                # update next poll time this is done in
                # loop in case the time spent measuring the
                # current is greater than the poll interval
                # which could cause the polling to get behind
                while poll_time <= current_time:
                    poll_time += timedelta(milliseconds=poll)

                # measure only one source at each poll, but don't log until interval is exceeded
                pollGate = not pollGate

                # if gate limit or drain compliance reached, end test for device
                if pollGate:
                    igs = sgate.measure()
                    if sgate.ask_if_limiting():
                        print 'Device reached gate compliance, ending test!'
                        failed = True
                else:
                    ids = sdrain.measure()
                    if sdrain.ask_if_limiting():
                        print 'Device reached drain compliance, ending test!'
                        failed = True

                # reached/exceeded measurement interval
                if next_time == start_time or current_time >= next_time or failed:

                    # update next measurement interval
                    next_time += timedelta(seconds=interval)

                    # write to data files and console
                    x, y = site[:2], site[2:]
                    fp.write("\n")
                    fp.write(x)
                    fp.write(',')
                    fp.write(y)
                    fp.write(',')
                    fp.write("%f,"%(periph*1.0e-3))
                    fp.write("%e,%e,%e,%e,%e,%e,%e"%((current_time - start_time).seconds, igs*1.0e3, ids*1.0e3, abs(igs*1.0e6/periph), ids*1.0e6/periph, vgate, vdrain))
                    fp.flush()

                    monitorfile.write("%s\t%s\t%s\n"%(current_time.strftime('%Y/%m/%d %H:%M:%S'),igs,ids))
                    monitorfile.flush()
                    print "Time: %5d s| Ig: %1.3e mA | Id: %5.3e mA | Vg: %1.3e V | Vd: %1.3e V"%((current_time - start_time).seconds, igs*1.0e3, ids*1.0e3, vgate, vdrain)

                    # update lists
                    time_list.append((current_time - start_time).seconds)
                    ig_list.append(igs)
                    id_list.append(ids)

                    # if at end of test
                    if current_time >= end_time or failed:
                        break

                # print status to console
                sys.stdout.write("\x1b[KStressing device %s..." % site)
                if (current_time.second % 4 == 0):
                    sys.stdout.write('/ \r')
                elif (current_time.second % 4 == 1):
                    sys.stdout.write('-- \r')
                elif (current_time.second % 4 == 2):
                    sys.stdout.write('\\ \r')
                elif (current_time.second % 4 == 3):
                    sys.stdout.write('| \r')
                sys.stdout.flush()

            except pyvisa.VisaIOError as ex:
                # ignore timeouts
                if ex.error_code == pyvisa.constants.VI_ERROR_TMO:
                    pass
                else:
                    raise
            except KeyboardInterrupt:
                # capture time of pause
                pause_start_time = datetime.now()

                # turn off sources
                timed_wait_ms(500)
                sdrain.config(state=0)
                timed_wait_ms(500)
                sgate.config(state=0)

                # wait for user input
                r = raw_input("\rTest paused. Enter 'n' to move to next device, or 'c' to cancel test, otherwise just press Enter: ")

                # if skipping to next device, break
                if r is 'n':
                    # run post-stress lag measurement
                    if cfg['post_stress_lag']:
                        # turn sources back on
                        timed_wait_ms(500)
                        sgate.config(state=1)
                        timed_wait_ms(500)
                        sdrain.config(state=1)
                        timed_wait_ms(1000)
                        run_post_stress_lag(cfg, None, site, sgate, sdrain)
                    break

                if r is 'c':
                    # run post-stress lag measurement
                    if cfg['post_stress_lag']:
                        # turn sources back on
                        timed_wait_ms(500)
                        sgate.config(state=1)
                        timed_wait_ms(500)
                        sdrain.config(state=1)
                        timed_wait_ms(1000)
                        run_post_stress_lag(cfg, None, site, sgate, sdrain)
                    raise

                # capture length of pause, update interval and duration
                pause_end_time = datetime.now()
                pause_time = pause_end_time - pause_start_time
                next_time = next_time + pause_time
                poll_time = poll_time + pause_time
                end_time = end_time + pause_time
                print '\rTest paused for %d seconds. New end time: %s'%(pause_time.seconds, end_time.strftime('%Y/%m/%d %H:%M:%S'))

                # turn sources back on
                timed_wait_ms(500)
                sgate.config(state=1)
                timed_wait_ms(500)
                sdrain.config(state=1)
                timed_wait_ms(500)

        monitorfile.close()
        print('Finished stressing device %s\n' % site)
        data = {'time': time_list, 'ig': ig_list, 'id': id_list, 'vg': vgate, 'vd':vdrain}

        # run post-stress lag measurement
        if cfg['post_stress_lag']:
            run_post_stress_lag(cfg, None, site, sgate, sdrain)

        # shut off supplies
        sdrain.config(state=0)
        timed_wait_ms(500)
        sgate.config(state=0)

        # return data
        return (cfg, data)

# post-stress functions
def run_post_stress_lag(cfg, fp, site, sgate, sdrain):
    print('Running post-stress Lag measurement')

    # pinch-off device
    sgate.config(vset=cfg['post_stress_lag_vgq'])
    timed_wait_ms(50)
    sdrain.config(vset=cfg['post_stress_lag_vd'])
    timed_wait_ms(50)

    sgate.vi.write(":SENS1:CURR:PROT %e"%(cfg['post_stress_ig_max_ma']*1e-3))
    timed_wait_ms(50)
    sgate.vi.write(":SENS2:CURR:PROT %e"%(cfg['post_stress_id_max_ma']*1e-3))
    timed_wait_ms(50)
    sgate.vi.write(":OUTP1:FILT 0")
    timed_wait_ms(50)
    sgate.vi.write(":OUTP2:FILT 0")
    timed_wait_ms(50)

    # set up lag configuration parameters
    # using gatelag test from ganlag.py
    lag_cfg = dict()
    lag_cfg['gatelag_measurement_period'] = cfg['post_stress_lag_meas_interval_sec']
    lag_cfg['gatelag_trigger_delay'] = cfg['post_stress_lag_meas_interval_sec']
    lag_cfg['single_pulse'] = True
    lag_cfg['gatelag_Vd_q'] = cfg['post_stress_lag_vd']

    # configure SMU for lag measurement
    ganlag.config_gatelag_trigger_test(lag_cfg, sgate.vi, cfg['post_stress_lag_vgq'], cfg['post_stress_lag_vgp'])
    ganlag.config_SMU_tb(sgate.vi, 100000)
    ganlag.trigger_idle_wait(sgate.vi)
    ganlag.initiate_trigger(sgate.vi)

    # check to see if SMU has gathered all the data
    bufferfull = False
    while not bufferfull:
        result = int(sgate.vi.ask(":STAT:MEAS:COND?")[2:],2)    # string returned from SMU looks like '#Bxxxxxxxxxxxx', need to remove the '#B'
        timed_wait_ms(1000)
        if result&0x0410 == 0x0410: # check for trace buffers to be full
            bufferfull = True

    ganlag.abort_trigger(sgate.vi)

    # pinch-off device
    sgate.config(vset=cfg['post_stress_lag_vgq'])
    timed_wait_ms(50)
    sdrain.config(vset=cfg['post_stress_lag_vd'])

    # pull trace data
    print "Acquiring post-stress data from SMU..."
    g_data = sgate.vi.ask("TRAC1:DATA? 0,%d"%(99999)) # returned as voltage(1),current(1),time(1),voltage(2),current(2),time(2), etc...
    timed_wait_ms(50)
    d_data = sgate.vi.ask("TRAC2:DATA? 0,%d"%(99999))
    timed_wait_ms(50)

    g = zip(*[iter(g_data.split(','))]*3)
    d = zip(*[iter(d_data.split(','))]*3)

    with open('{}_post_stress_lag.dat'.format(site),'w') as output:
        # write header
        output.write('! GaN Hammer Post-stress Lag measurement\n')
        output.write('!\n')
        output.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
        output.write('!\n')
        output.write('! Settings:\n')
        for k in ('post_stress_lag_vgq', 'post_stress_lag_vgp', 'post_stress_lag_vd', 'post_stress_lag_meas_interval_sec',):
            output.write('!    %s = %s\n'%(k,repr(cfg[k])))

        # write data
        output.write('! t (s)\tVg (V)\tVd (V)\tId (A)\n')
        for tg, td in zip(g, d):
            ## skip printing last line
            #if tg == gdata[-1] or td == ddata[-1]:
            #    continue
            output.write(''.join(str(s).strip()+'\t' for s in [tg[2], tg[0], td[0], td[1]]) + '\n')

# postprocessing functions
def compile_data():

    # gather data from previously-taken test files
    data = {}
    singledata = None
    while len(data) == 0 or singledata is not None:
        singledata = open_pickle('Enter filename for stress pickle file, or enter nothing to compile all previous files: ')

        # no file selected
        if singledata is None:
            break

        for site, sitedata in singledata.iteritems():

            # skip sites with no data (device may have been in compliance, etc.)
            if sitedata is None:
                continue

            device = sitedata[0]['device']
            wafer = sitedata[0]['wafer']
            print "Loaded stress data for device %s - %s on wafer %s"%(site, device, wafer)

            if len(data) > 0:
                # check if device/wafer match the first-chosen pkl file
                datadevice = data.values()[0][0]['device']
                datawafer = data.values()[0][0]['wafer']
                if datadevice == device and datawafer == wafer:
                    data.update(singledata)
                else:
                    # allow user to use file, but default to not using it
                    r = raw_input("Device or wafer of this file doesn't match initial chosen file...\nEnter 'y' if the file should be loaded anyway, otherwise press Enter to ignore it: ")
                    if r == 'y':
                        print("Using file anyway!")
                        data.update(singledata)
                    else:
                        print("Ignoring chosen file!")
            else:
                # if on first file, always update data
                data.update(singledata)

    if len(data) < 1:
        print 'No file selected, returning to main menu!'
        return

    filename = prompt_filename("Enter output filename: ", True)
    append = os.path.exists(filename)

    # if an existing data file was selected, append
    if append:
        write_stress_data(filename, data, True)

    # create new data file otherwise
    else:
        write_stress_data(filename, data, False)

def write_downpoint_data(fname, dp_data):

    fp = open(fname, 'w')
    sites = dp_data.keys()
    cfg = dp_data.values()[0][0]

    num_diode_pts = range(0, len(cfg['fwd_target_ig_uamm']))
    num_txfr_pts = range(0, len(cfg['txfr_target_id_mamm']))
    periph = cfg['ngf']*cfg['ugw']

    # create file header
    fp.write('!GaN Multisite Rapid Downpoint Data\n')
    fp.write('!Test Date:,%s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    fp.write('!Wafer:,%s\n'%cfg['wafer'])
    fp.write('!Device:,%s\n'%cfg['device'])
    fp.write('!Starting stage coordinates:,\'%s\',x: ???,y: ???\n'%(sites[0]))

    # create table header
    fp.write("x,y,periphery [mm],")

    # downpoint columns
    for i in num_diode_pts:
        fp.write("fwd_diode_vg_%d [V],"%i)
    for i in num_diode_pts:
        fp.write("fwd_diode_ig_%d [A],"%i)
    for i in num_diode_pts:
        fp.write("fwd_diode_ig_%d [mA/mm],"%i)
    fp.write("imax [A],imax [mA/mm],ron [Ohm],ron [Ohm-mm],")
    for i in num_txfr_pts:
        fp.write("fwd_txfr_vg_%d [V],"%i)
    for i in num_txfr_pts:
        fp.write("fwd_txfr_id_%d [A],"%i)
    for i in num_txfr_pts:
        fp.write("fwd_txfr_id_%d [mA/mm],"%i)
    fp.write("leakage_id [A],leakage_ig [A],leakage_is [A],leakage_id [mA/mm],|leakage_ig| [mA/mm],|leakage_is| [mA/mm],")
    fp.write("\n")

    for site in sites:

        # gather data for columns
        diode_vg = dp_data[site][1]['fwd'][0]
        diode_ig = dp_data[site][1]['fwd'][1]
        diode_ig_norm = [x*1.0e6/periph for x in diode_ig]
        imax = dp_data[site][1]['iv'][0]
        imax_norm = imax*1.0e6/periph
        ron = dp_data[site][1]['iv'][1]
        ron_norm = ron*periph*1.0e-3
        txfr_vg = dp_data[site][1]['txfr'][0]
        txfr_id = dp_data[site][1]['txfr'][1]
        txfr_id_norm = [x*1.0e6/periph for x in txfr_id]
        leakage_ig = dp_data[site][1]['leakage'][1]
        leakage_ig_norm = abs(leakage_ig*1.0e6/periph)
        leakage_id = dp_data[site][1]['leakage'][0]
        leakage_id_norm = leakage_id*1.0e6/periph
        leakage_is = dp_data[site][1]['leakage'][2]
        leakage_is_norm = abs(leakage_is*1.0e6/periph)

        x, y = site[:2], site[2:]
        fp.write(x)
        fp.write(',')
        fp.write(y)
        fp.write(',')

        # write data
        fp.write("%f,"%(periph*1.0e-3))
        for i in diode_vg:
            fp.write("%e,"%i)
        for i in diode_ig:
            fp.write("%e,"%i)
        for i in diode_ig_norm:
            fp.write("%e,"%i)
        fp.write("%e,%e,%e,%e," % (imax, imax_norm, ron, ron_norm))
        for i in txfr_vg:
            fp.write("%e,"%i)
        for i in txfr_id:
            fp.write("%e,"%i)
        for i in txfr_id_norm:
            fp.write("%e,"%i)
        fp.write("%e,%e,%e,%e,%e,%e," % (leakage_id, leakage_ig, leakage_is, leakage_id_norm, leakage_ig_norm, leakage_is_norm))

        fp.write("\n")

    fp.close()

def write_stress_data(fname, st_data, append):

    if append:
        fp = open(fname, 'a')
    else:
        fp = open(fname, 'w')

    sites = st_data.keys()
    cfg = st_data.values()[0][0]

    # create file header
    if not append:
        fp.write('!GaN Multisite Rapid Stress Data\n')
        fp.write('!Test Date:,%s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
        fp.write('!Wafer:,%s\n'%cfg['wafer'])
        fp.write('!Device:,%s\n'%cfg['device'])
        fp.write('!Starting stage coordinates:,\'%s\',x: ???,y: ???\n'%(sites[0]))

        # create table header
        fp.write("x,y,periphery [mm],")

        # stress columns
        fp.write("t [s],ig [mA],id [mA],|ig| [mA/mm],id [mA/mm],Vg [V],Vd [V]")

    for site in sites:
        if st_data[site]:
            cfg = st_data[site][0]
            periph = cfg['ngf']*cfg['ugw']
            # gather data for columns
            data = st_data[site][1]
            time_list = data['time']
            ig_list = data['ig']
            ig_norm_list = [abs(x*1.0e6/periph) for x in ig_list]
            id_list = data['id']
            id_norm_list = [x*1.0e6/periph for x in id_list]
            vg_list = [data['vg']]*len(time_list)
            vd_list = [data['vd']]*len(time_list)
            rows = zip(time_list, ig_list, id_list, ig_norm_list, id_norm_list, vg_list, vd_list)

            # write data
            x, y = site[:2], site[2:]
            fp.write("\n")
            for row in rows:
                fp.write(x)
                fp.write(',')
                fp.write(y)
                fp.write(',')
                fp.write("%f,"%(periph*1.0e-3))
                fp.write("%e,%e,%e,%e,%e,%e,%e\n"%(row[0], row[1]*1000, row[2]*1000, row[3]*1000, row[4]*1000, row[5], row[6]))

    fp.close()

# utility functions
def find_target_Ids(targetIds, tol, initial_vg, vg_step, vg_step_factor, vg_max, vg_min, sgate, sdrain):
    "finds a specified current by adjusting Vgs, assumes limits and drain voltage already set"

    # take measurements to get up-to-date measurements before checking for compliance in while loop
    sgate.measure()
    timed_wait_ms(50)
    sdrain.measure()
    timed_wait_ms(50)

    currentVg = initial_vg
    stepSize = vg_step
    targetIds_rounded = round(targetIds*1000,tol)
    increasing = True

    # measure Ids
    currentId = sdrain.measure()
    currentId_rounded = round(currentId*1000,tol)
    timed_wait_ms(50)

    while currentId_rounded != targetIds_rounded:
        sys.stdout.write('\x1b[KCurrent Vg/Id: %.5f/%e\r'%(currentVg,currentId))
        sys.stdout.flush()

        # if in compliance, throw exception
        if sgate.ask_if_limiting() or sdrain.ask_if_limiting():
            print 'DUT in compliance, aborting current find routine!'
            return currentVg

        if currentId_rounded == targetIds_rounded:
            break

        # if smaller than desired and less than max allowed Vg, step up
        elif (currentId_rounded < targetIds_rounded) and (currentVg <= vg_max) and (currentVg >= vg_min) :
            if not increasing:
                increasing = True
                stepSize = stepSize*vg_step_factor
                # limit step size to 10uV
                if stepSize < 1e-5:
                    stepSize = 1e-5
            currentVg = currentVg + stepSize

        # if larger than desired, step down
        elif (currentId_rounded > targetIds_rounded) and (currentVg <= vg_max) and (currentVg >= vg_min):
            if increasing:
                increasing = False
                stepSize = stepSize*vg_step_factor
                # limit step size to 10uV
                if stepSize < 1e-5:
                    stepSize = 1e-5
            currentVg = currentVg - stepSize

        elif currentVg > vg_max or currentVg < vg_min:
            print("Reached min/max allowed Vg, continuing test with current corresponding to Vg = %.5f V"%currentVg)
            break

        # set next Vg and wait to settle
        sgate.config(vset=currentVg)
        timed_wait_ms(100)

        # measure Ids
        currentId = sdrain.measure()
        currentId_rounded = round(currentId*1000,tol)

    print("Found target current Id = %e A with Vg = %.5f V"%(currentId,currentVg))
    return currentVg

def open_pickle(str):
    "Prompt user to open a pickle file with the given message, and a returns a handle to the data"

    while True:
        filename = raw_input(str)
        if filename == '':
            return None

        if not os.path.exists(filename):
            print "File does not exist!"
            continue
        else:
            try:
                data = None
                pkl = open(filename, 'rb')
                data = pickle.load(pkl)
            except pickle.UnpicklingError:
                print "Unable to load file...ensure the desired file is a pickle file!\n"

        if data is not None:
            break

    return data

def prompt_filename(str, overwrite=False):
    while True:
        filename = raw_input(str)
        if os.path.exists(filename) and not overwrite:
            r = raw_input("%s exists - overwrite? (y/n): "%filename).strip().lower()
            if (r.startswith('y') or r.startswith('Y')):
                break
            else:
                continue
        else:
            break

    return filename

# config functions
def load_config_file(cfg, cfgfname):
    try:
        # if cfg file doesn't exist in current working directory, write one
        if not os.path.isfile(os.getcwd() + '/' + cfgfname):
            print "no config file detected, writing default config file to \'%s\'"%DEFAULT_CONFIGFILE
            write_config_file(os.getcwd() + '/' + cfgfname)
        data = dict()
        print "Loading config file '%s'..."%cfgfname

        execfile(cfgfname,data)
        del data['__builtins__']

        # check for any missing keys in input config file
        for key in _default_config().keys():
            if key not in data.keys():
                print "Config file is missing key '%s'... using default value of %s"%(key, _default_config()[key])

        cfg.update(data)
        print "Config file successfully read!"

    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no or invalid config file, using default options"
        else:
            raise

def write_config_file(filename, cfg=None):
    file = open(filename, 'w')
    # using explicit for loop to keep logical order of variables... must update this list if more variables are added in cfg file
    for k in (
        'ngf', 'ugw', 'vg_min', 'vg_max', 'vd_max', 'ig_max_mamm', 'id_max_mamm', 'initial_vg', 'initial_vg_step', 'power_limit_wmm', 'step_factor',
        'downpoint_mapfile', 'stress_mapfile', 'wafer', 'device',
        'fwd_ig_max_mamm', 'fwd_vd', 'fwd_target_ig_uamm', 'fwd_meas_delay_ms',
        'idss_id_max_mamm', 'idss_vd', 'idss_vg', 'ron_id_max_mamm', 'ron_vd', 'ron_vg', 'iv_meas_delay_ms',
        'txfr_ig_max_mamm', 'txfr_id_max_mamm', 'txfr_drain_voltage', 'txfr_target_id_mamm', 'txfr_meas_delay_ms', 'txfr_target_id_tolerance_dec_ma',
        'leakage_ig_max_mamm', 'leakage_id_max_mamm', 'leakage_gate_voltage', 'leakage_drain_voltage', 'leakage_meas_delay_ms',
        'stress_ig_max_mamm', 'stress_id_max_mamm', 'stress_vd', 'stress_target_id_mamm', 'stress_poll_interval_msec', 'stress_meas_interval_sec', 'stress_meas_duration_sec', 'stress_target_id_tolerance_dec_ma',
        'post_stress_lag', 'post_stress_ig_max_ma', 'post_stress_id_max_ma', 'post_stress_lag_vgq', 'post_stress_lag_vgp', 'post_stress_lag_vd', 'post_stress_lag_meas_interval_sec',
        'gate_smu', 'drain_smu', 'prober'):
        if cfg is not None:
            config = cfg
        else:
            config = _default_config()
        if k in ('downpoint_mapfile', 'stress_mapfile', 'wafer', 'device'):
            file.write("%s = '%s'\n"%(k, config[k]))
        else:
            file.write("%s = %s\n"%(k, str(config[k])))
        if k in ('step_factor', 'fwd_meas_delay_ms', 'iv_meas_delay_ms', 'txfr_target_id_tolerance_dec_ma', 'leakage_meas_delay_ms', 'stress_target_id_tolerance_dec_ma', 'post_stress_lag_meas_interval_sec', 'device'):   # write newlines for readability
            file.write('\n')
    file.close()

def print_config(cfg):
    print "\n"
    # using explicit for loop to keep logical order of variables... must update this list if more variables are added in cfg file
    for k in (
        'ngf', 'ugw', 'vg_min', 'vg_max', 'vd_max', 'ig_max_mamm', 'id_max_mamm', 'initial_vg', 'initial_vg_step', 'power_limit_wmm', 'step_factor',
        'downpoint_mapfile', 'stress_mapfile', 'wafer', 'device',
        'fwd_ig_max_mamm', 'fwd_vd', 'fwd_target_ig_uamm', 'fwd_meas_delay_ms',
        'idss_id_max_mamm', 'idss_vd', 'idss_vg', 'ron_id_max_mamm', 'ron_vd', 'ron_vg', 'iv_meas_delay_ms',
        'txfr_ig_max_mamm', 'txfr_id_max_mamm', 'txfr_drain_voltage', 'txfr_target_id_mamm', 'txfr_meas_delay_ms', 'txfr_target_id_tolerance_dec_ma',
        'leakage_ig_max_mamm', 'leakage_id_max_mamm', 'leakage_gate_voltage', 'leakage_drain_voltage', 'leakage_meas_delay_ms',
        'stress_ig_max_mamm', 'stress_id_max_mamm', 'stress_vd', 'stress_target_id_mamm', 'stress_poll_interval_msec', 'stress_meas_interval_sec', 'stress_meas_duration_sec', 'stress_target_id_tolerance_dec_ma',
        'post_stress_lag', 'post_stress_ig_max_ma', 'post_stress_id_max_ma', 'post_stress_lag_vgq', 'post_stress_lag_vgp', 'post_stress_lag_vd', 'post_stress_lag_meas_interval_sec',
        'gate_smu', 'drain_smu', 'prober'):

        if k in ('downpoint_mapfile', 'stress_mapfile', 'wafer', 'device'):
            print("%s = '%s'"%(k, cfg[k]))
        else:
            print("%s = %s"%(k, str(cfg[k])))

        if k in ('step_factor', 'fwd_meas_delay_ms', 'iv_meas_delay_ms', 'txfr_target_id_tolerance_dec_ma', 'leakage_meas_delay_ms', 'stress_target_id_tolerance_dec_ma', 'post_stress_lag_meas_interval_sec', 'device'):   # write newlines for readability
            print ''

    print "\n"

def _default_config():
    "default configuration"

    cfg = {}
    cfg['ngf'] = 2
    cfg['ugw'] = 200.0
    cfg['vg_min'] = -5.0
    cfg['vg_max'] = 2.0
    cfg['vd_max'] = 60.0
    cfg['ig_max_mamm'] = 1.0
    cfg['id_max_mamm'] = 1200.0
    cfg['initial_vg'] = -3.0
    cfg['initial_vg_step'] = 0.025
    cfg['power_limit_wmm'] = 4.0
    cfg['step_factor'] = 0.5

    cfg['downpoint_mapfile'] = 'downpoint.map'
    cfg['stress_mapfile'] = 'stress.map'
    cfg['wafer'] = 'MASKxLOTwWAFER_SCRIBE'
    cfg['device'] = 'NGFxUGWum_DEV'

    cfg['fwd_ig_max_mamm'] = 10.0
    cfg['fwd_vd'] = 0.0
    cfg['fwd_target_ig_uamm'] = [1.0, 10.0, 100.0]
    cfg['fwd_meas_delay_ms'] = 50.0

    cfg['idss_id_max_mamm'] = 1200.0
    cfg['idss_vd'] = 7.0
    cfg['idss_vg'] = 2.0
    cfg['ron_id_max_mamm'] = 500.0
    cfg['ron_vd'] = 1.0
    cfg['ron_vg'] = 0.0
    cfg['iv_meas_delay_ms'] = 50.0

    cfg['txfr_ig_max_mamm'] = 10.0
    cfg['txfr_id_max_mamm'] = 500.0
    cfg['txfr_drain_voltage'] = 10.0
    cfg['txfr_target_id_mamm'] = [100.0, 200.0, 300.0]
    cfg['txfr_meas_delay_ms'] = 50.0
    cfg['txfr_target_id_tolerance_dec_ma'] = 1

    cfg['leakage_ig_max_mamm'] = 10.0
    cfg['leakage_id_max_mamm'] = 10.0
    cfg['leakage_gate_voltage'] = -8.0
    cfg['leakage_drain_voltage'] = 50.0
    cfg['leakage_meas_delay_ms'] = 100.0

    cfg['stress_ig_max_mamm'] = 10.0
    cfg['stress_id_max_mamm'] = 250.0
    cfg['stress_vd'] = 50.0
    cfg['stress_target_id_mamm'] = 200.0
    cfg['stress_poll_interval_msec'] = 500
    cfg['stress_meas_interval_sec'] = 5
    cfg['stress_meas_duration_sec'] = 30
    cfg['stress_target_id_tolerance_dec_ma'] = 3

    cfg['post_stress_lag'] = False
    cfg['post_stress_ig_max_ma'] = 20
    cfg['post_stress_id_max_ma'] = 1500
    cfg['post_stress_lag_vgq'] = -5.0
    cfg['post_stress_lag_vgp'] = 1.0
    cfg['post_stress_lag_vd'] = 10.0
    cfg['post_stress_lag_meas_interval_sec'] = 20e-6

    cfg['gate_smu'] = ('b2902', 'TCPIP0::10.0.0.10', {'chan': 1})
    cfg['drain_smu'] = ('b2902', 'TCPIP0::10.0.0.10', {'chan': 2})
    cfg['prober'] = ('prober', '12k', 'GPIB::28')

    return cfg

if __name__ == '__main__':

    # load configuration
    cfg = _default_config()
    load_config_file(cfg, DEFAULT_CONFIGFILE)

    while True:
        print "Menu:\n"
        print "\t d - Run downpoint test\n"
        print "\t s - Run stress test\n"
        print "\t cd - Compile downpoint pickle file\n"
        print "\t c - Compile stress pkl file(s)\n"
        print "\t pd - Preview downpoint wafer map\n"
        print "\t ps - Preview stress wafer map\n"
        print "\t r - Reload config file\n"
        print "\t p - Print currently loaded config file\n"
        print "\t w - Write currently loaded config to '%s'\n"%DEFAULT_CONFIGFILE
        print "\t q - Quit\n\n"

        try:
            r = raw_input("Enter your choice: ")

            if r == "d":
                initialize_test(cfg, 'Downpoint')
            elif r == "s":
                initialize_test(cfg, 'Stress')
            elif r == "c":
                compile_data()
            elif r == "cd":
                testdata = open_pickle("dp file:")
                outfile = prompt_filename("output file:")
                write_downpoint_data(outfile, testdata)
            elif r == "pd":
                preview_map(cfg, 'Downpoint')
            elif r == "ps":
                preview_map(cfg, 'Stress')
            elif r == "r":
                load_config_file(cfg, DEFAULT_CONFIGFILE)
            elif r == "p":
                print_config(cfg)
            elif r == "w":
                write_config_file(DEFAULT_CONFIGFILE, cfg)
            elif r == "q":
                break
            else:
                print "Invalid Option! Try again\n"

        except KeyboardInterrupt:
            print "\nReturning to main menu!"
