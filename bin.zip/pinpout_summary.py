#! /usr/bin/env python

import fnmatch
import os
from collections import deque

"""Simple script to summarize multiple pinpout files"""
g=open('pinpout_summary.dat','w')
g.write('Device \tStatus \tPin \tPout \tGain \tI_out \tI_in\n')
for file in os.listdir('.'):
    if fnmatch.fnmatch(file,'*_pinpout.dat'):
        dev_name=file.split('_')[0]
        status=file.split('_')[1]
        f= open(file,'r')
        lines= deque(f)
        tmp= lines[len(lines)-5].split('\t')
        tmp1=lines[len(lines)-4].split('\t')
        tmp2=lines[len(lines)-3].split('\t')
        g.write('%s \t%s \t%s \t%s \t%s \t%s \t%s\n'%(dev_name,status,tmp[0],tmp[1],tmp[2],tmp[4],tmp[6].split('\n')[0]))
        g.write('%s \t%s \t%s \t%s \t%s \t%s \t%s\n'%(dev_name,status,tmp1[0],tmp1[1],tmp1[2],tmp1[4],tmp1[6].split('\n')[0]))
        g.write('%s \t%s \t%s \t%s \t%s \t%s \t%s\n'%(dev_name,status,tmp2[0],tmp2[1],tmp2[2],tmp2[4],tmp2[6].split('\n')[0]))
        f.close()

g.close()
