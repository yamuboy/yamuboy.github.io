#!/usr/bin/env python

import visa
import time
import sys
import datetime
from modeling.configfile import ConfigVars,ConfigFile
from modeling.configtypes import *
from instrument.manager import InstrumentManager
from instrument.utils import timed_wait_ms
from optparse import OptionParser
import instrument
import os

INSTR = {
    #'bias1':['k23x','GPIB::21',{'remote':True,'resolution':'high'}],
    #'bias2':['k23x','GPIB::23',{'remote':True,'resolution':'high'}],
    'bias1':['b2902','GPIB::22',{'chan':1}],
    'bias2':['b2902','GPIB::22',{'chan':2}],
    #'prober':['12k','GPIB::28',{}],
    #'siggen':['SCPISigGen','GPIB::19',{}],
}

def load_config(name):
    cfg = {}
    execfile(name,cfg)
    del cfg['__builtins__']
    return cfg

def main(cfg=None):
    if cfg is not None:
        if isinstance(cfg,str):
            # cfg is an argument specifying the config file name
            cdata = load_config(cfg)
        else:
            # config data passed in
            cdata = cfg
    else:
        # try to load the config from the default config file locations
        cdata = load_config('power_config.cfg')

    filename= raw_input('Enter the filename for the test:\n')
    if os.path.exists(filename):
        print "Warning: file '%s' exists." % filename
        if raw_input("Overwrite the existing file? (y/N): ").strip().lower()[0] != 'y': 
            print "Exiting."
            return
   
    if raw_input('Turning on power supplies now (y/n)! ').strip().lower()[0] != 'y':
        return

    run_test(filename, cdata)
    
def convert_raw(data):
    t = data.split('\n')
    # Remove leading header junk
    t[0] = t[0].split(' ')[1]
    t.pop(len(t)-1)
    cleaned_data = [float(i) for i in t]
    return cleaned_data

def run_test(filename, config):
    "main routine of test"
        
    # open instruments
    t = visa.ResourceManager()
    vna = t.open_resource('GPIB::6')
    #vna= visa.instrument(config.get('vna_address','GPIB::6'))
    
    gate = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    drain = instrument.create('bias',*(INSTR['bias2'][:2]),**(INSTR['bias2'][2]))
    
    # get the compression, gate, and drain current limits
    comp_limit = config.get('compression_limit',100.0)
    gate_limit = config.get('gate_current_limit',None)
    drain_limit = config.get('drain_current_limit',None)

    points= int((config['stop_power']-config['start_power'])/config['power_step'] + 1.0) 

    # open the output file and write the header
    f= open(filename, 'w+')
    t = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
    f.write("!Downpoint Test \t%s\n"%(t))
    f.write("!Start Power: %.3f\n"%config['start_power'])
    f.write("!Stop Power: %.3f\n"%config['stop_power'])
    f.write("!Power Step: %.3f\n"%config['power_step'])
    f.write("!Num Points: %d\n"%points)
    f.write("!\n")
    f.write("!Pin\tPout\tGain\tV_out\tI_out\tV_in\tI_in\n")

    # Set the start and stop pin and pout powers to zero
    # This program assumes that the VNA is already configured to measure Pin on Ch1 and Pout on Ch2
    # and that a power cal has been performed.
    gate.config(vset=config['gate_voltage'],ilimit=gate_limit,state=1,resolution = 'high',remote = True)
    timed_wait_ms(50)
    kw = {}
    imrange = config.get('ids_range_ma',None)
    if imrange:
        kw['imrange'] = imrange*0.001
    drain.config(vset=config['drain_voltage'],ilimit=drain_limit,state=1,resolution = 'high',remote = True)
    timed_wait_ms(500)
    try:
        time.sleep(0.05) 

        # Configure port1 to do a linar power sweep, starting at 0dBm
        #vna.write('SOUR1:POW:PORT1:LIN:POW:START -50')
        #vna.write('SOUR1:POW:PORT1:LIN:POW:STOP -50')

        #vna.write(':TRIG:SING')
        #vna.write(':TRIG:SOUR AUTO')
               
        tmp_points = float(vna.ask('SOUR1:POW:PORT1:LIN:POW:POIN?'))
        tmp_start =  float(vna.ask('SOUR1:POW:PORT1:LIN:POW:START?'))
        tmp_stop = float(vna.ask('SOUR1:POW:PORT1:LIN:POW:STOP?'))
        #print 'points %f\t start %f\t stop %f'%(tmp_points,tmp_start,tmp_stop)
        #print 'config points %f\t config start %f\t config stop%f'%(points,config['start_power'],config['stop_power'])

        if tmp_points!=points or tmp_start!=config['start_power'] or tmp_stop!=config['stop_power']:
            # force the instrument to forget the channel data
            vna.write('SOUR1:POW:PORT1:LIN:POW:START %.3f'%config['start_power'])
            vna.write('SOUR1:POW:PORT1:LIN:POW:STOP %.3f'%(config['start_power']+0.01))

            # reset the source data
            vna.write('SOUR1:POW:PORT1:LIN:POW:POIN 2')
            vna.write('SOUR1:POW:PORT1:LIN:POW:STOP %.3f'%config['stop_power'])
            vna.write('SOUR1:POW:PORT1:LIN:POW:POIN %d'%points)
            tmp = vna.ask('SOUR1:POW:PORT1:LIN:POW:POIN?')
            #vna.ask('*OPC?') 
                
            # this stupid wait is needed because the instrument is really slow
            # at setting up
            #time.sleep(5) 

        # Set the VNA trigger mode to GPIB remote and sweep type to point
        vna.write(':TRIG:SEQ:REM:TYP POIN')
        vna.write(':TRIG:SOUR REM')
        vna.ask('*OPC?') 

        # force the sweep to restart
        #vna.write(':SENS:HOLD:FUNC HOLD')
        #vna.write(':TRIG:SING')
        vna.write(':SENS:HOLD:FUNC SING')
        #vna.write(':TRIG:SING')
        vna.write(':TRIG')

        # this stupid wait is needed because the instrument is really slow
        # at setting up
        time.sleep(1) 

        gate_v=[]
        drain_v=[]
        gate_curr=[]
        drain_curr=[]

        # set up vna hold function
        for i in range(points):
             # read supplies
             ig = gate.measure()
             idr = drain.measure()
             gate_curr.append(ig)
             drain_curr.append(idr)
             gate_v.append(config['gate_voltage'])
             drain_v.append(config['drain_voltage'])

             #time.sleep(0.03)
             timed_wait_ms(400)

             # this has to be done after the DC measurement since it increments
             # to the next power level
             #vna.write(':TRIG;*WAI')
             vna.write(':TRIG')
             
             vna.ask('*OPC?') 

             # this wait should not be necessary, since the *WAI should delay
             # command processing until the instrument has processed the trigger
             # but it does not work
             time.sleep(0.5)

             # read VNA
             #p_out = vna.ask_for_values('OFD2')
             p_out = vna.ask(":CALC:PAR2:SEL;:CALC:SEL:DATA:FDATA?")
             p_out = convert_raw(p_out)
             valid_pout = p_out[0:i+2]
             #p_in = vna.ask_for_values('OFD1')
             p_in = vna.ask(":CALC:PAR1:SEL;:CALC:SEL:DATA:FDATA?")
             p_in = convert_raw(p_in)
             valid_pin = p_in[0:i+2]

             #print p_out

             # calculate gains
             gain0 = valid_pout[0] - valid_pin[0]
             gain = valid_pout[-1] - valid_pin[-1]

             # Add some DUT protection
             if (gain0-gain >= comp_limit) or gate.limiting or drain.limiting:
                  break

             # write data to the file
             f.write("%.4f\t%.4f\t%.4f\t%.3e\t%.3e\t%.3e\t%.3e\n"%(valid_pin[i],valid_pout[i],valid_pout[i]-valid_pin[i],config['drain_voltage'],idr,config['gate_voltage'],ig))
             f.flush()

             # wait for something??? this does not seem to serve a purpose!!
             #time.sleep(1)

        #vna.write('SOUR1:POW:PORT1:ATT 4E1')

        # reset vna triggering
        #vna.write(':SENS:HOLD:FUNC HOLD')
        vna.write(':TRIG:SOUR AUTO')

    finally:
        f.close()
        vna.close()
        gate.set_state(0)
        drain.set_state(0)
        gate.close()
        drain.close()


if __name__ == '__main__':
    "entry point"
    parser = OptionParser()
    parser.add_option("-f", "--file", dest="filename", help="Read configiguration from FILE", metavar="FILE")
    opts,args = parser.parse_args()
    fname = opts.filename
    
    # run the main routine
    main(fname)
    

              

