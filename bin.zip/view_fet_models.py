#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function

from modeling.fet.extract.ssplot import plot_interactive
import logging
from maplot import plot_gui
import sys


#logging.basicConfig(filename='model.log',filemode='w',level=logging.INFO)
logging.basicConfig(level=logging.INFO,format='%(levelname)s: %(message)s')

filelist = sys.argv[1:]

if sys.platform == 'win32':
    # account for Windows' lack of a useful shell
    import glob
    fn2 = []
    for f in filelist:
        fn2.extend(glob.glob(f))
    filelist = fn2

if not len(filelist):
    sys.stderr.write("USAGE: %s s2pfile [s2pfile ...]\n\n"%sys.argv[0])
    sys.exit(1)

# generate the report engine and load all files
fig, pager = plot_interactive(filelist,old_style=True)
pager.key_bindings = (
    ('d',pager.delete_model),
    )

# start the interactive window
plot_gui(fig,pager=pager)

