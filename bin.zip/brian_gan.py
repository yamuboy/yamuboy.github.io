#!/usr/bin/env python
import os, sys, time
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
import instrument

INSTR = {
    #'bias1':['k23x','GPIB::21',{'remote':True,'resolution':'high'}],
    #'bias2':['k23x','GPIB::23',{'remote':True,'resolution':'high'}],
    'bias1':['b2902','GPIB::25',{'chan':2,'remote':True,'resolution':'high'}],
    'bias2':['b2902','GPIB::25',{'chan':1,'remote':True,'resolution':'high'}],
    #'prober':['12k','GPIB::28',{}],
    #'siggen':['SCPISigGen','GPIB::19',{}],
}
def main():
    filename=raw_input("Enter Filename for test data?\n")
    if os.path.exists(filename):
        r=raw_input("%s exists-overwrite?(y/n)"%filename).strip().lower()
        if not r.startswith('y'):
            return
    
    gate = instrument.create('bias',*(INSTR['bias1'][:2]),**(INSTR['bias1'][2]))
    drain = instrument.create('bias',*(INSTR['bias2'][:2]),**(INSTR['bias2'][2]))

    
    f= open(filename,'w')
    f.write('!Simple DC Measurement\n')
    f.write('!Ig= 0.06mA\n')
    f.write('!Device Name\tIg\tVg\n')
    while True:
        try:
            dc_measure(gate,drain,f)
        except KeyboardInterrupt:
            drain.set_state(0)
            timed_wait_ms(50)
            gate.set_state(0)
            timed_wait_ms(50)

            # ask the user what they want to do
            r = raw_input("*** Test Interrupted ***\n  Do you want to (r)estart, or (q)uit? [q]: ").lower().strip()
            if not r or r.startswith('q'):
               break
            elif r.startswith('r'):
               pass


def dc_measure(gate,drain,f):
    dev= raw_input("Device name:\n")
    gate.config(mode='I',iset=0.06e-3, vlimit=30.0,state=1)
    timed_wait_ms(20)
    #drain.config(mode='V',vset=15.0, ilimit= 0.2,state=1)
    #timed_wait_ms(30)
    vgs= gate.measure()
    drain.set_state(0)
    timed_wait_ms(50)
    gate.set_state(0)
    timed_wait_ms(50)
    f.write('%s\t%+0.4e\t%+0.4e\n'%(dev,0.06e-3,vgs))
    f.flush()

if __name__=="__main__":
    main()
    

