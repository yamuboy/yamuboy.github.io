#!/usr/bin/env python

import os, sys

    
def read_pnax_nf_data( pna, chan, param_list ):
    "read the data from the instrument and return it"
        
    # initial setup
    pna.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
    # put sweep in hold
    pna.write('SENS%d:SWE:MODE HOLD'%chan)
    
    # get the measurement catalog
    x = pna.ask('CALC%d:PAR:CAT:EXT?'%chan).split(',')
    assert (len(x)%2 == 0)
    catalog = {}
    for i in range(0,len(x),2):
        n = x[i].strip('\'"')
        v = x[i+1].strip('\'"')
        catalog[n] = v
    
    # create measurements as needed #
    for p in param_list:
        mname = "pymeas_%s"%p
        if mname not in catalog:
            pna.write('CALC%d:CUST:DEF "%s","Noise Figure Cold Source","%s"'%(chan,mname,p))
    
    # detect averaging state
    avg = int(pna.ask('SENS%d:AVER:STAT?'%chan))
    if avg:
        count = int(pna.ask('SENS%d:AVER:COUN?'%chan))
        # restart averaging
        pna.write('SENS%d:AVER:CLEAR'%chan)
    else:
        count = 1
    
    # set the group count to be equal to the averaging
    pna.write('SENS%d:SWE:GRO:COUN %d'%(chan,count))
    # trigger a measurment group
    pna.write('SENS%d:SWE:MODE GRO;*ESE 1;*OPC'%chan)
    
    # wait for the measurement to finish
    while 1:
        
        esr = int(pna.ask('*ESR?'))
        if esr:
            break
    
    result = {}
    # get the frequency list
    r = pna.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?'%chan)
    n = len(r)
    result['freq'] = r
    
    # get the measured parameters
    for p in param_list:
        mname = "pymeas_%s"%p
        pna.write('CALC%d:PAR:SEL "%s"'%(chan,mname))
        r = pna.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA'%chan)
        lr = len(r)
        if lr == n:
            # real data
            r2 = r            
        elif lr == 2*n:
            # complex data
            r2 = []
            for i in range(n):
                r2.append(complex(r[2*i],r[2*i+1]))
        else:
            raise Exception("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (mname,n,len(r)))
            
        result[p.lower()] = r2
        
    # allow the PNA to enter continous sweep mode
    pna.write('SENS%d:SWE:MODE CONT' % chan)
    
    # return results
    return result
    
    
    
def main():
    "entry point"
    
    addr = 'GPIB::16'
    chan = 1
    param_list = ['S11','S12','S21','S22','NF','NCorr_11','NCorr_12','NCorr_21','NCorr_22','Gammaopt','Rn','NFmin']
    outname = 'out.txt'
    
    import visa    
    pna = visa.instrument(addr,values_format=visa.double)
    data = read_pnax_nf_data(pna,chan,param_list)
    
    out_list = ['freq'] + [p.lower() for p in param_list]
    fp = open(outname,'w')
    headers = []
    for p in out_list:
        if isinstance(data[p][0],complex):
            headers.append('re{'+p.title()+'}')      
            headers.append('im{'+p.title()+'}')
        else:
            headers.append(p.title())
    fp.write('!'+'\t'.join(headers)+'\n')
    for i in range(len(data['freq'])):
        d = []
        for p in out_list:
            if isinstance(data[p][0],complex):
                d.append('%.4e'%data[p][i].real)
                d.append('%.4e'%data[p][i].imag)         
            else:
                d.append('%.4e'%data[p][i])
        fp.write('\t'.join(d)+'\n')
    
    fp.close()
    
    
    
if __name__ == '__main__':
    main()
    
    
