#!/usr/bin/env python

import os, sys, traceback, math
import mautils.cli_utils
import re
from datetime import datetime
import visa
import time

DEFAULT_CONFIGFILE = 'gan_lag.cfg'

def timed_wait( seconds ):
    """Start a timed wait period."""
    start = time.time()
    remain = float(seconds)
    while remain > 0.0:
        time.sleep(remain)
        stop = time.time()
        remain = seconds - (stop-start)
        
def timed_wait_ms( milliseconds ):
    """Start a timed wait period."""
    timed_wait(milliseconds*1.0e-3)
    
def load_config_file(cfg, cfgfname):
    try:
        # if cfg file doesn't exist in current working directory, write one
        if not os.path.isfile(os.getcwd() + '/' + cfgfname):
            print "no config file detected, writing default config file to \'%s\'"%DEFAULT_CONFIGFILE
            write_config_file(os.getcwd() + '/' + cfgfname)
        data = dict()
        execfile(cfgfname,data)
        del data['__builtins__']
        cfg.update(data)
        print "read config options from: '%s'\n"%cfgfname
    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no config file, using default options"
        else:
            raise

def write_config_file(filename):
    file = open(filename, 'w')
    # using explicit for loop to keep logical order of variables... must update this list if more variables are added in cfg file
    for k in ('gatelag_Vg_ss', 'gatelag_Vg_pulse', 'gatelag_Vd_q', 'gatelag_pulse_width', 'gatelag_pulse_period', 'gatelag_trigger_delay', 'gatelag_measurement_period',
              'drainlag_Vd_ss', 'drainlag_Vd_pulse', 'drainlag_Vg_q', 'drainlag_pulse_width', 'drainlag_pulse_period', 'drainlag_trigger_delay', 'drainlag_measurement_period',
              'piv_test_Vg_ss', 'piv_test_Vg_pulse' ,'piv_test_Vd_ss', 'piv_test_Vd_pulse', 'piv_test_trigger_delay', 'piv_test_Vg_delay_ms', 'piv_test_Vd_delay_ms', 'piv_test_measurement_period',
              'pulsed_bias_Vg',
              'target_Ids', 'target_Ids_delay_ms', 'Vg_start', 'Vg_step', 'Vg_stop', 'step_factor', 'Ig_limit_ua', 'Id_limit_ma',
              'output_filter', 'single_pulse', 'smu'):
        file.write(k + ' = ' + str(_default_config()[k]) + '\n')
        if k in ('gatelag_measurement_period', 'drainlag_measurement_period', 'piv_test_measurement_period', 'target_Ids_delay_ms', 'Id_limit_ma', 'measurement_period'):   # write newlines for readability
            file.write('\n')
    file.close()

def print_config(cfg):
    print "\n"
    # using explicit for loop to keep logical order of variables... must update this list if more variables are added in cfg file
    for k in ('gatelag_Vg_ss', 'gatelag_Vg_pulse', 'gatelag_Vd_q', 'gatelag_pulse_width', 'gatelag_pulse_period', 'gatelag_trigger_delay', 'gatelag_measurement_period',
              'drainlag_Vd_ss', 'drainlag_Vd_pulse', 'drainlag_Vg_q', 'drainlag_pulse_width', 'drainlag_pulse_period', 'drainlag_trigger_delay', 'drainlag_measurement_period',
              'piv_test_Vg_ss', 'piv_test_Vg_pulse' ,'piv_test_Vd_ss', 'piv_test_Vd_pulse', 'piv_test_trigger_delay', 'piv_test_Vg_delay_ms', 'piv_test_Vd_delay_ms', 'piv_test_measurement_period',
              'pulsed_bias_Vg',
              'target_Ids', 'target_Ids_delay_ms', 'Vg_start', 'Vg_step', 'Vg_stop', 'step_factor', 'Ig_limit_ua', 'Id_limit_ma',
              'output_filter', 'single_pulse', 'smu'):
                if k in ('gatelag_measurement_period', 'drainlag_measurement_period', 'piv_test_measurement_period', 'target_Ids_delay_ms', 'Id_limit_ma', 'measurement_period'):   # write newlines for readability
                    print k + ' = ' + str(cfg[k]) + '\n'
                else:
                    print k + ' = ' + str(cfg[k])
    print "\n"
    
def _default_config():
    "default configuration"
    
    cfg = {}
    cfg['gatelag_Vg_ss'] = -10.0
    cfg['gatelag_Vg_pulse'] = -2.0
    cfg['gatelag_Vd_q'] = 10.0
    cfg['gatelag_pulse_width'] = 20.0e-3
    cfg['gatelag_pulse_period'] = 40.0e-3
    cfg['gatelag_trigger_delay'] = 2.0
    cfg['gatelag_measurement_period'] = 20.0e-6
    
    cfg['drainlag_Vd_ss'] = 50.0
    cfg['drainlag_Vd_pulse'] = 10.0
    cfg['drainlag_Vg_q'] = -2.0
    cfg['drainlag_pulse_width'] = 100.0e-3
    cfg['drainlag_pulse_period'] = 200.0e-3
    cfg['drainlag_trigger_delay'] = 2.0
    cfg['drainlag_measurement_period'] = 20.0e-6

    cfg['piv_test_Vg_ss'] = [ -10.0 ]
    cfg['piv_test_Vg_pulse'] = [ 1.0 ]
    cfg['piv_test_Vd_ss'] = [ 10.0 ]
    cfg['piv_test_Vd_pulse'] = [ 6.0 ]
    cfg['piv_test_trigger_delay'] = 100.0
    cfg['piv_test_Vg_delay_ms'] = 20.0
    cfg['piv_test_Vd_delay_ms'] = 10.0
    cfg['piv_test_measurement_period'] = 1e-3

    cfg['pulsed_bias_Vg'] = [ ]
    
    cfg['target_Ids'] = [ 20.0e-3 ]
    cfg['target_Ids_delay_ms'] = 10000
    cfg['Vg_start'] = -2.0
    cfg['Vg_step'] = 10.0e-3
    cfg['Vg_stop'] = 0.0
    cfg['step_factor'] = 0.5
    cfg['Ig_limit_ua'] = 100.0
    cfg['Id_limit_ma'] = 100.0
    
    cfg['output_filter'] = False
    cfg['single_pulse'] = True
    cfg['smu'] = '\'GPIB::22\''
    
    return cfg
    
def main(cfgfname=DEFAULT_CONFIGFILE,fname=''):
    "entry point"
    print "\n\n***********************************************\n"
    print "***************GaN Lag Tester******************\n"
    print "***********************************************\n\n"

    cfg = _default_config()
    load_config_file(cfg, cfgfname)

    rm = visa.ResourceManager()
    inst = rm.open_resource(cfg['smu'])
    
    while True:
        print "Menu:\n"
        print "\t tt - Run both tests (pulse to target)\n"
        print "\t tf - Run both tests (pulse from target)\n"
        print "\t tgt - Run only gate lag test (pulse to target)\n"
        print "\t tdt - Run only drain lag test (pulse to target)\n"
        print "\t tgf - Run only gate lag test (pulse from target)\n"
        print "\t tdf - Run only drain lag test (pulse from target)\n"
        print "\t tp - Run PIV test\n"
        print "\t g - Set SMU to pulse current gate lag settings\n"
        print "\t d - Set SMU to pulse current drain lag settings\n"
        print "\t r - Reload config file\n"
        print "\t p - Print currently loaded config file\n"
        print "\t q - Quit\n\n"
        r = raw_input("Enter your choice: ")
        
        try:        
            if r == "tt":
                load_config_file(cfg, cfgfname)
                run_to_target(cfg, inst, fname, "both")
            elif r == "tf":
                load_config_file(cfg, cfgfname)
                run_from_target(cfg, inst, fname, "both")
            elif r == "tgt":
                load_config_file(cfg, cfgfname)
                run_to_target(cfg, inst, fname, "gate")
            elif r == "tdt":
                load_config_file(cfg, cfgfname)
                run_to_target(cfg, inst, fname, "drain")    
            elif r == "tgf":
                load_config_file(cfg, cfgfname)
                run_from_target(cfg, inst, fname, "gate")
            elif r == "tdf":
                load_config_file(cfg, cfgfname)
                run_from_target(cfg, inst, fname, "drain")    
            elif r == "tp":
                load_config_file(cfg, cfgfname)
                run_piv_test(cfg, inst, fname)
            elif r == "g":
                test_gatelag_settings(cfg, cfgfname, inst)
            elif r == "d":
                test_drainlag_settings(cfg, cfgfname, inst)
            elif r == "r":
                load_config_file(cfg, cfgfname)
            elif r == "p":
                print_config(cfg)
            elif r == "q":
                inst.close()
                raise SystemExit
            else:
                print "Invalid Option! Try again\n"
    
        except KeyboardInterrupt:
            print "\nAborted! Exiting to main menu...\n"
            abort_trigger(inst)
            disable_sources(inst)
            
def maxv_warning(cfg):
    maxv = max(cfg['gatelag_Vd_q'], cfg['drainlag_Vd_ss'], cfg['drainlag_Vd_pulse'])
    if maxv > 30.0:
        print "WARNING ***********************************************"
        print "WARNING: maximum drain voltage for this test is %g volts"%maxv
        print "WARNING: ensure that the bias tees can handle this voltage"
        print "WARNING ***********************************************"
        print ""
        r = raw_input("press enter to continue or ctrl-C to quit")

def run_to_target(cfg, inst, fname, tests):
    "run tests that pulse from steady-state to target bias"

    maxv_warning(cfg)
    
    # ask for a file name
    while not fname:
        fname = raw_input('Base output file name? ').strip()
        
    if not cfg['pulsed_bias_Vg']:
        for ids in cfg['target_Ids']:
            config_sources(cfg, inst)
            cfg['pulsed_bias_Vg'].append(find_target_Ids(cfg, inst, ids))
            
        #SMU_display_graph(inst)
        
    for ids, vgs in zip(cfg['target_Ids'], cfg['pulsed_bias_Vg']):
        newcfg = cfg
        newcfg['pulsed_bias_Vg'] = vgs
        if tests == "both" or tests == "gate":
            # gate lag
            print "\nRunning Gate Lag Test...\n"
            run_gatelag(newcfg, inst, fname, ids)

        if tests == "both" or tests == "drain":
            # drain lag
            print "\nRunning Drain Lag Test...\n"
            run_drainlag(newcfg, inst, fname, ids)
    
    #SMU_display_dual(inst)
    print "\nTests complete!\n"

def run_from_target(cfg, inst, fname, tests):
    "run tests that pulse from target bias to steady-state"

    maxv_warning(cfg)
    
    # ask for a file name
    print "Running pulse-from-target test"
    while not fname:
        fname = raw_input('Base output file name? ').strip()
        
    if not cfg['pulsed_bias_Vg']:
        for ids in cfg['target_Ids']:
            config_sources(cfg, inst)
            cfg['pulsed_bias_Vg'].append(find_target_Ids(cfg, inst, ids))
            
        #SMU_display_graph(inst)
        
    for ids, vgs in zip(cfg['target_Ids'], cfg['pulsed_bias_Vg']):
        newcfg = cfg
        newcfg['pulsed_bias_Vg'] = vgs
        if tests == "both" or tests == "gate":
            # gate lag
            print "\nRunning Gate Lag Test...\n"
            run_gatelag(newcfg, inst, fname, ids, False)

        if tests == "both" or tests == "drain":
            # drain lag
            print "\nRunning Drain Lag Test...\n"
            run_drainlag(newcfg, inst, fname, ids, False)
    
    #SMU_display_dual(inst)
    print "\nTests complete!\n"
     
def run_piv_test(cfg, inst, fname):
    "run test that pulses both gate and drain sources"

    maxv_warning(cfg)
    
    # ask for a file name
    while not fname:
        fname = raw_input('Base output file name? ').strip()
        
    for Vg1, Vg2, Vd1, Vd2 in zip(cfg['piv_test_Vg_ss'], cfg['piv_test_Vg_pulse'], cfg['piv_test_Vd_ss'], cfg['piv_test_Vd_pulse']):
        print "\nRunning PIV Test...\n"
        gate = (Vg1, Vg2)
        drain = (Vd1, Vd2)
        run_piv(cfg, inst, fname, gate, drain)
    
    #SMU_display_dual(inst)
    print "\nTests complete!\n"

def test_gatelag_settings(cfg, cfgfname, inst):
    while True:
        maxv_warning(cfg)

        xmin = 0
        xmax =  cfg['gatelag_pulse_period']*3.0
        ymin = 0
        ymax = cfg['target_Ids']
            
        config_sources(cfg, inst)
        
        # configure triggers and pulse values
        config_gatelag_trigger_test(cfg, inst, cfg['gatelag_Vg_pulse'])
        
        enable_sources(inst)
        trigger_idle_wait(inst)
        timed_wait_ms(1000)
        initiate_trigger(inst)

        # set SMU to display graph
#            SMU_display_graph(gate)
        
        r = raw_input("SMU enabled! Wait for enough data to be captured, then press enter!")
        
        abort_trigger(inst)
        disable_sources(inst)
        
        r = raw_input("SMU set to view gate lag pulse waveform.\nPress enter to continue, or press 'r' to reload config file and re-test.")
        
        if r == "r":
            load_config_file(cfg, cfgfname)
        else:
            break
        
def test_drainlag_settings(cfg, cfgfname, inst):
    while True:
        maxv_warning(cfg)

        xmin = 0
        xmax =  cfg['drainlag_pulse_period']*3.0
        ymin = 0
        ymax = cfg['target_Ids']
            
        config_sources(cfg, inst)
        
        # configure triggers and pulse values
        config_drainlag_trigger_test(cfg, inst, cfg['drainlag_Vg_q'])
        
        enable_sources(inst)
        trigger_idle_wait(inst)
        timed_wait_ms(1000)
        initiate_trigger(inst)

        # set SMU to display graph
#            SMU_display_graph(gate)
        
        r = raw_input("SMU enabled! Wait for enough data to be captured, then press enter!")
        
        abort_trigger(inst)
        disable_sources(inst)
        
        r = raw_input("SMU set to view drain lag pulse waveform.\nPress enter to continue, or press 'r' to reload config file and re-test.")
        
        if r == "r":
            load_config_file(cfg, cfgfname)
        else:
            break

def SMU_display_graph(inst):
    "set SMU display to graph view"
    inst.write(":DISP:ENAB ON")
    timed_wait_ms(50)
    inst.write(":DISP:VIEW GRAP")
    timed_wait_ms(50)
    
def SMU_display_dual(inst):
    "set SMU display to dual-supply view"
    inst.write(":DISP:ENAB ON")
    timed_wait_ms(50)
    inst.write(":DISP:VIEW DUAL")
    timed_wait_ms(50)

def SMU_cont_meas(inst):
    "Emulates pressing the AUTO trigger button on the b2902 front panel"
    inst.write(":ARM1:ACQ:COUN INF")
    timed_wait_ms(50)
    inst.write(":ARM2:ACQ:COUN INF")
    timed_wait_ms(50)

    inst.write(":TRIG1:ACQ:COUN 100")
    timed_wait_ms(50)
    inst.write(":TRIG2:ACQ:COUN 100")
    timed_wait_ms(50)
    inst.write(":TRIG1:ACQ:TIM 10e-3")
    timed_wait_ms(50)
    inst.write(":TRIG2:ACQ:TIM 10e-3")
    timed_wait_ms(50)
    inst.write(":INIT:ACQ (@1:2)")
    timed_wait_ms(50)

def write_gatelag(cfg, gdata, ddata, basename, ids):
    
    testparams = re.sub(r'\.', 'p', ('_gatelag_%2.0fmA'%(ids*1000)))
    filename = basename + testparams + '.lag'
    
    print "Writing Gate Lag Test data to %s\n"%filename

    # write header
    output = open(filename,'w')
    output.write('! GaN Gate Lag Test\n')
    output.write('!\n')
    output.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    output.write('!\n')
    output.write('! Settings:\n')
    for k in ('gatelag_Vg_ss', 'gatelag_Vg_pulse', 'gatelag_Vd_q', 'gatelag_pulse_width', 'gatelag_pulse_period'):
        output.write('!    %s = %s\n'%(k,repr(cfg[k])))
    output.write('!    target_Ids = %s\n\n'%ids)

    # write data
    output.write('! t (s)\tVg (V)\tVd (V)\tId (A)\n')
    for tg, td in zip(gdata, ddata):
        ## skip printing last line
        #if tg == gdata[-1] or td == ddata[-1]:
        #    continue
        output.write(''.join(str(s).strip()+'\t' for s in [tg[2], tg[0], td[0], td[1]]) + '\n')

    output.close()

def write_drainlag(cfg, gdata, ddata, basename, ids):

    testparams = re.sub(r'\.', 'p', ('_drainlag_%2.0fmA'%(ids*1000)))
    filename = basename + testparams + '.lag'
    
    print "Writing Drain Lag Test data to %s\n"%filename

    # write header
    output = open(filename,'w')
    output.write('! GaN Drain Lag Test\n')
    output.write('!\n')
    output.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    output.write('!\n')
    output.write('! Settings:\n')
    for k in ('drainlag_Vd_ss', 'drainlag_Vd_pulse', 'drainlag_Vg_q', 'drainlag_pulse_width', 'drainlag_pulse_period'):
        output.write('!    %s = %s\n'%(k,repr(cfg[k])))
    output.write('!    target_Ids = %s\n\n'%ids)
    
    # write data
    output.write('! t (s)\tVg (V)\tVd (V)\tId (A)\n')
    for tg, td in zip(gdata, ddata):
        ## skip printing last line
        #if tg == gdata[-1] or td == ddata[-1]:
        #    continue
        output.write(''.join(str(s).strip()+'\t' for s in [tg[2], tg[0], td[0], td[1]]) + '\n')

    output.close()

def write_piv(cfg, gdata, ddata, basename, gatecfg, draincfg):
    
    filename = basename + '_piv.lag'
    
    print "Writing PIV Lag Test data to %s\n"%filename

    # write header
    output = open(filename,'w')
    output.write('! GaN PIV Lag Test\n')
    output.write('!\n')
    output.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    output.write('!\n')
    output.write('! Settings:\n')
    
    output.write('!    Vg_ss = %s\n'%gatecfg[0])
    output.write('!    Vg_pulse = %s\n'%gatecfg[1])
    output.write('!    Vd_ss = %s\n'%draincfg[0])
    output.write('!    Vd_pulse = %s\n'%draincfg[1])

    for k in ('piv_test_trigger_delay', 'piv_test_Vg_delay_ms', 'piv_test_Vd_delay_ms', 'piv_test_measurement_period'):
        output.write('!    %s = %s\n'%(k[9:],repr(cfg[k])))

    output.write('\n')

    # write data
    output.write('! t (s)\tVg (V)\tVd (V)\tId (A)\n')
    for tg, td in zip(gdata, ddata):
        output.write(''.join(str(s).strip()+'\t' for s in [tg[2], tg[0], td[0], td[1]]) + '\n')

    output.close()

def config_sources(cfg, inst):
    "Resets and reconfigures SMU outputs"
    # reset SMU
    inst.write("*RST")
        
    # set sources to voltage, with compliance limits and 4-wire mode
    inst.write(":SOUR1:FUNC:MODE VOLT")
    timed_wait_ms(50)
    inst.write(":SENS1:CURR:PROT %e"%(cfg['Ig_limit_ua']*1.0e-6))
    timed_wait_ms(50)
    inst.write(":SENS1:REM ON")
    timed_wait_ms(50)

    inst.write(":SOUR2:FUNC:MODE VOLT")
    timed_wait_ms(50)
    inst.write(":SENS2:CURR:PROT %e"%(cfg['Id_limit_ma']*1.0e-3))
    timed_wait_ms(50)
    inst.write(":SENS2:REM ON")
    timed_wait_ms(50)
    
    # output filters enabled by default, disable if need be
    if not cfg['output_filter']:
        inst.write(":OUTP1:FILT 0")
        timed_wait_ms(50)
        inst.write(":OUTP2:FILT 0")
        timed_wait_ms(50)
        
def config_gatelag_trigger_test(cfg, inst, Vgss, targetVg):
    "Configures trigger settings for a gatelag test"
    # set trigger parameters
    inst.write(":TRIG1:ALL:COUN %s"%"INF")  # infinite trigger count for gate
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:COUN %s"%"INF")
    timed_wait_ms(50)
    inst.write(":TRIG1:ALL:DEL %e"%0.0)
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:DEL %e"%0.0)
    timed_wait_ms(50)
    inst.write(":TRIG1:ALL:SOUR %s"%"TIM")  # trigger source = internal timer
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    inst.write(":TRIG1:ACQ:TIM %e"%cfg['gatelag_measurement_period']) # measure as fast as possible, 20us
    timed_wait_ms(50)
    inst.write(":TRIG2:ACQ:TIM %e"%cfg['gatelag_measurement_period'])
    timed_wait_ms(50)
    
    inst.write(":ARM1:ALL:COUN %d"%1)       # infinite trigger count for gate
    timed_wait_ms(50)
    inst.write(":ARM2:ALL:COUN %d"%1)
    timed_wait_ms(50)
    inst.write(":ARM1:ACQ:DEL %e"%cfg['gatelag_trigger_delay'])
    timed_wait_ms(50)
    inst.write(":ARM2:ACQ:DEL %e"%cfg['gatelag_trigger_delay'])
    timed_wait_ms(50)
    inst.write(":ARM1:TRAN:DEL %e"%(cfg['gatelag_trigger_delay'] + cfg['gatelag_measurement_period']))
    timed_wait_ms(50)
    inst.write(":ARM2:TRAN:DEL %e"%(cfg['gatelag_trigger_delay'] + cfg['gatelag_measurement_period']))
    timed_wait_ms(50)
    inst.write(":ARM1:ALL:SOUR %s"%"TIM")   # trigger source = internal timer
    timed_wait_ms(50)
    inst.write(":ARM2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    inst.write(":ARM1:ACQ:TIM %e"%cfg['gatelag_measurement_period'])    # measure as fast as possible, 20us
    timed_wait_ms(50)
    inst.write(":ARM2:ACQ:TIM %e"%cfg['gatelag_measurement_period'])
    timed_wait_ms(50)
    
    # set gate pulse parameters
    if cfg['single_pulse']:
        inst.write(":SOUR1:FUNC:SHAP %s"%"DC")                          # set gate source to DC
        timed_wait_ms(50)
    else:
        inst.write(":TRIG1:TRAN:TIM %e"%cfg['gatelag_pulse_period'])    # pulse period set as in config
        timed_wait_ms(50)
        inst.write(":TRIG2:TRAN:TIM %e"%cfg['gatelag_pulse_period'])    # pulse period must be same across channels for trigger to work
        timed_wait_ms(50)
        inst.write(":SOUR1:PULS:DEL %e"%0.0)                            # pulse delay
        timed_wait_ms(50)
        inst.write(":SOUR1:PULS:WIDT %e"%cfg['gatelag_pulse_width'])    # pulse width
        timed_wait_ms(50)
        inst.write(":SOUR1:FUNC:SHAP %s"%"PULS")                        # set gate source to pulsed
        timed_wait_ms(50)
    

    inst.write(":SOUR1:VOLT %e"%Vgss)                                   # set gate initial voltage
    timed_wait_ms(50)
    inst.write(":SOUR1:VOLT:TRIG %e"%targetVg)                          # set gate pulse voltage
    timed_wait_ms(50)
    
    inst.write(":SOUR2:FUNC:SHAP %s"%"DC")                              # set drain source to DC
    timed_wait_ms(50)
    inst.write(":SOUR2:VOLT %e"%cfg['gatelag_Vd_q'])                    # set drain quiescent voltage
    timed_wait_ms(50)
    inst.write(":SOUR2:VOLT:TRIG %e"%cfg['gatelag_Vd_q'])               # must set both DC and pulse voltages for triggered DC source to work correctly
    timed_wait_ms(50)

def config_drainlag_trigger_test(cfg, inst, Vd1, Vd2, targetVg):
    "Configures trigger settings for a drainlag test"

    # set trigger parameters
    inst.write(":TRIG1:ALL:COUN %s"%"INF")  # infinite trigger count for gate
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:COUN %s"%"INF")
    timed_wait_ms(50)
    inst.write(":TRIG1:ALL:DEL %e"%0.0)     # source pulse train delay = 0
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:DEL %e"%0.0)
    timed_wait_ms(50)
    inst.write(":TRIG1:ALL:SOUR %s"%"TIM")  # trigger source = internal timer
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    inst.write(":TRIG1:ACQ:TIM %e"%cfg['drainlag_measurement_period']) # measure as fast as possible, 20us
    timed_wait_ms(50)
    inst.write(":TRIG2:ACQ:TIM %e"%cfg['drainlag_measurement_period'])
    timed_wait_ms(50)
    
    inst.write(":ARM1:ALL:COUN %d"%1)       # infinite trigger count for gate
    timed_wait_ms(50)
    inst.write(":ARM2:ALL:COUN %d"%1)
    timed_wait_ms(50)
    inst.write(":ARM1:ACQ:DEL %e"%cfg['drainlag_trigger_delay'])
    timed_wait_ms(50)
    inst.write(":ARM2:ACQ:DEL %e"%cfg['drainlag_trigger_delay'])
    timed_wait_ms(50)
    inst.write(":ARM1:TRAN:DEL %e"%(cfg['drainlag_trigger_delay'] + cfg['drainlag_measurement_period']))
    timed_wait_ms(50)
    inst.write(":ARM2:TRAN:DEL %e"%(cfg['drainlag_trigger_delay'] + cfg['drainlag_measurement_period']))
    timed_wait_ms(50)
    inst.write(":ARM1:ALL:SOUR %s"%"TIM")   # trigger source = internal timer
    timed_wait_ms(50)
    inst.write(":ARM2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    inst.write(":ARM1:ACQ:TIM %e"%cfg['drainlag_measurement_period'])  # measure as fast as possible, 20us
    timed_wait_ms(50)
    inst.write(":ARM:ACQ:TIM %e"%cfg['drainlag_measurement_period'])
    timed_wait_ms(50)
    
    # set drain pulse parameters
    if cfg['single_pulse']:
        #inst.write(":TRIG1:TRAN:TIM %s"%"MAX")  # pulse period set to max for single-pulse mode
        #timed_wait_ms(50)
        #inst.write(":TRIG2:TRAN:TIM %s"%"MAX")  # pulse period must be same across channels for trigger to work
        #timed_wait_ms(50)
        #inst.write(":SOUR2:PULS:DEL %e"%100e-6) # pulse delay
        #timed_wait_ms(50)
        #inst.write(":SOUR2:PULS:WIDT %e"%cfg['drainlag_pulse_width'])   # pulse width
        #timed_wait_ms(50)
        inst.write(":SOUR2:FUNC:SHAP %s"%"DC")                    # set drain source to DC
        timed_wait_ms(50)
    else:
        inst.write(":TRIG1:TRAN:TIM %e"%cfg['drainlag_pulse_period'])# pulse period set as in config
        timed_wait_ms(50)
        inst.write(":TRIG2:TRAN:TIM %e"%cfg['drainlag_pulse_period'])# pulse period must be same across channels for trigger to work
        timed_wait_ms(50)
        inst.write(":SOUR2:PULS:DEL %e"%0.0)                         # pulse delay
        timed_wait_ms(50)
        inst.write(":SOUR2:PULS:WIDT %e"%cfg['drainlag_pulse_width'])# pulse width
        timed_wait_ms(50)
        inst.write(":SOUR2:FUNC:SHAP %s"%"DC")                    # set drain source to pulsed
        timed_wait_ms(50)
        
    inst.write(":SOUR2:VOLT %e"%Vd1)            # set drain initial voltage
    timed_wait_ms(50)
    inst.write(":SOUR2:VOLT:TRIG %e"%Vd2)       # set drain pulse voltage
    timed_wait_ms(50)
    
    inst.write(":SOUR1:FUNC:SHAP %s"%"DC")      # set gate source to DC
    timed_wait_ms(50)
    inst.write(":SOUR1:VOLT %e"%targetVg)       # set gate quiescent voltage
    timed_wait_ms(50)
    inst.write(":SOUR1:VOLT:TRIG %e"%targetVg)  # must set both DC and pulse voltages for triggered DC source to work correctly
    timed_wait_ms(50)

def config_piv_trigger_test(cfg, inst, vg1, vg2, vd1, vd2):
    "Configures trigger settings for a PIV test"

    # set trigger parameters
    inst.write(":TRIG1:ALL:COUN %s"%"INF")  # infinite trigger count (using ARM layer to trigger)
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:COUN %s"%"INF")
    timed_wait_ms(50)
    inst.write(":TRIG1:ALL:DEL %e"%0.0)     # zero trigger delay (using ARM layer to trigger)
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:DEL %e"%0.0)
    timed_wait_ms(50)
    inst.write(":TRIG1:ALL:SOUR %s"%"TIM")  # trigger source = internal timer
    timed_wait_ms(50)
    inst.write(":TRIG2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    inst.write(":TRIG1:ACQ:TIM %e"%cfg['piv_test_measurement_period']) # measurement period
    timed_wait_ms(50)
    inst.write(":TRIG2:ACQ:TIM %e"%cfg['piv_test_measurement_period'])
    timed_wait_ms(50)
    
    inst.write(":ARM1:ALL:COUN %d"%1)       # single pulse
    timed_wait_ms(50)
    inst.write(":ARM2:ALL:COUN %d"%1)
    timed_wait_ms(50)
    inst.write(":ARM1:ACQ:DEL %e"%cfg['piv_test_trigger_delay']) # measurement delay for gate
    timed_wait_ms(50)
    inst.write(":ARM2:ACQ:DEL %e"%cfg['piv_test_trigger_delay']) # measurement delay for drain
    timed_wait_ms(50)
    inst.write(":ARM1:TRAN:DEL %e"%(cfg['piv_test_trigger_delay'] + cfg['piv_test_Vg_delay_ms']*0.001)) # switching delay for gate
    timed_wait_ms(50)
    inst.write(":ARM2:TRAN:DEL %e"%(cfg['piv_test_trigger_delay'] + cfg['piv_test_Vd_delay_ms']*0.001)) # switching delay for drain
    timed_wait_ms(50)
    inst.write(":ARM1:ALL:SOUR %s"%"TIM")   # trigger source = internal timer
    timed_wait_ms(50)
    inst.write(":ARM2:ALL:SOUR %s"%"TIM")
    timed_wait_ms(50)  
    inst.write(":ARM1:ACQ:TIM %e"%cfg['piv_test_measurement_period'])  # measurement period
    timed_wait_ms(50)
    inst.write(":ARM:ACQ:TIM %e"%cfg['piv_test_measurement_period'])
    timed_wait_ms(50)
    
    inst.write(":SOUR1:FUNC:SHAP %s"%"DC")                    # set gate source to DC
    timed_wait_ms(50)
    inst.write(":SOUR2:FUNC:SHAP %s"%"DC")                    # set drain source to DC
    timed_wait_ms(50)
    
    inst.write(":SOUR1:VOLT %e"%vg1)            # set gate initial voltage
    timed_wait_ms(50)
    inst.write(":SOUR1:VOLT:TRIG %e"%vg2)       # set gate pulse voltage
    timed_wait_ms(50)
        
    inst.write(":SOUR2:VOLT %e"%vd1)            # set drain initial voltage
    timed_wait_ms(50)
    inst.write(":SOUR2:VOLT:TRIG %e"%vd2)       # set drain pulse voltage
    timed_wait_ms(50)

def enable_sources(inst):
    # turn on gate
    inst.write(":OUTP1 ON")
    timed_wait_ms(1000)
    
    # turn on drain
    inst.write(":OUTP2 ON")
    timed_wait_ms(500)

def disable_sources(inst):
    # turn off drain
    inst.write(":OUTP2 OFF")
    timed_wait_ms(1000)

    # turn off gate
    inst.write(":OUTP1 OFF")
    timed_wait_ms(500)

def initiate_trigger(inst):
    # initiate global trigger
    inst.write(":INIT:ALL (@1:2)")
    timed_wait_ms(50)

def trigger_idle_wait(inst):
    # wait for channels to be idle
    inst.ask(":IDLE1:ALL?")
    timed_wait_ms(50)
    inst.ask(":IDLE2:ALL?")
    timed_wait_ms(50)

def abort_trigger(inst):
    # abort trigger
    inst.write(":ABOR:ALL (@1:2)")
    timed_wait_ms(50)

def config_SMU_tb(inst, numBlocks):
    "Configure the SMU's trace buffer"
    # set data format
    inst.write(":FORM:ELEM:SENS VOLT,CURR,TIME")
    timed_wait_ms(50)
    inst.write(":FORM:SREG BIN")
    timed_wait_ms(50)
    
    # set trace buffer settings and clear
    inst.write(":TRAC1:FEED SENS")
    timed_wait_ms(50)
    inst.write(":TRAC1:POIN %d"%numBlocks)
    timed_wait_ms(50)
    inst.write(":TRAC2:FEED SENS")
    timed_wait_ms(50)
    inst.write(":TRAC2:POIN %d"%numBlocks)
    timed_wait_ms(50)
    inst.write(":TRAC1:FEED:CONT NEV")
    timed_wait_ms(50)
    inst.write(":TRAC2:FEED:CONT NEV")
    timed_wait_ms(50)
    inst.write(":TRAC1:CLE")
    timed_wait_ms(50)
    inst.write(":TRAC2:CLE")
    timed_wait_ms(50)
    inst.write(":TRAC1:FEED:CONT NEXT")
    timed_wait_ms(50)
    inst.write(":TRAC2:FEED:CONT NEXT")
    timed_wait_ms(50)

def run_gatelag(cfg, inst, fname, ids, to_target=True):
    "inner gatelag test loop"
    
    print "Target Current = %.1fmA"%(ids*1000.0)
    numBlocks = int((cfg['gatelag_pulse_period']/(20.0e-6))*3)  # store only ~3 periods of data    
    if numBlocks > 100000 or cfg['single_pulse']:               # b2902 only can hold 100000 blocks
        numBlocks = 100000
    
    config_sources(cfg, inst)

    # find Vg for target Ids
#        SMU_display_dual(gate)
    if to_target:
        Vgss = cfg['gatelag_Vg_ss']
        targetVg = cfg['pulsed_bias_Vg']
    else:
        Vgss = cfg['pulsed_bias_Vg']
        targetVg = cfg['gatelag_Vg_ss']
    
    # configure triggers and pulse values
#        SMU_display_graph(gate)
    config_gatelag_trigger_test(cfg, inst, Vgss, targetVg)
    
    # configure trace buffer
    config_SMU_tb(inst, numBlocks)
    
    enable_sources(inst)
    trigger_idle_wait(inst)
    timed_wait_ms(1000)
    initiate_trigger(inst)
    
    # wait for 3 full periods, at least
#        timed_wait_ms(cfg['gatelag_pulse_period']*1000*3)
    
    # check to see if SMU has gathered all the data
    bufferfull = False
    while not bufferfull:
        result = int(inst.ask(":STAT:MEAS:COND?")[2:],2)    # string returned from SMU looks like '#Bxxxxxxxxxxxx', need to remove the '#B'
        timed_wait_ms(1000)
        if result&0x0410 == 0x0410: # check for trace buffers to be full
            bufferfull = True

    abort_trigger(inst)
    disable_sources(inst)

    # pull trace data
    print "Acquiring data from SMU..."
    g_data = inst.ask("TRAC1:DATA? 0,%d"%(numBlocks-1)) # returned as voltage(1),current(1),time(1),voltage(2),current(2),time(2), etc...
    timed_wait_ms(50)
    d_data = inst.ask("TRAC2:DATA? 0,%d"%(numBlocks-1))
    timed_wait_ms(50)
    
    g = zip(*[iter(g_data.split(','))]*3)
    d = zip(*[iter(d_data.split(','))]*3)
    
    write_gatelag(cfg, g, d, fname, ids)
    
def run_drainlag(cfg, inst, fname, ids, to_target=True):

    print "Target Current = %.1fmA"%(ids*1000.0)
    numBlocks = int((cfg['drainlag_pulse_period']/(20.0e-6))*3) # store only 3 periods of data    
    if numBlocks > 100000 or cfg['single_pulse']:               # b2902 only can hold 100000 blocks
        numBlocks = 100000
    
    config_sources(cfg, inst)

    # find Vg for target Ids
#        SMU_display_dual(gate)
    targetVg = cfg['pulsed_bias_Vg']
    
    # configure triggers and pulse values
#        SMU_display_graph(gate)
    if to_target:
        Vd1 = cfg['drainlag_Vd_ss']
        Vd2 = cfg['drainlag_Vd_pulse']
    else:
        Vd1 = cfg['drainlag_Vd_pulse']
        Vd2 = cfg['drainlag_Vd_ss']

    config_drainlag_trigger_test(cfg, inst, Vd1, Vd2, targetVg)
    
    # configure trace buffer
    config_SMU_tb(inst, numBlocks)
    
    enable_sources(inst)
    trigger_idle_wait(inst)
    timed_wait_ms(1000)
    initiate_trigger(inst)
    
    # wait for 3 full periods, at least
    #timed_wait_ms(cfg['drainlag_pulse_period']*1000*3)
    
    # check to see if SMU has gathered all the data
    bufferfull = False
    while not bufferfull:
        result = int(inst.ask(":STAT:MEAS:COND?")[2:],2)    # string returned from SMU looks like '#Bxxxxxxxxxxxx', need to remove the '#B'
        timed_wait_ms(1000)
        if result&0x0410 == 0x0410: # check for trace buffers to be full
            bufferfull = True
    
    abort_trigger(inst)
    disable_sources(inst)

    # pull trace data
    print "Acquiring data from SMU..."
    g_data = inst.ask("TRAC1:DATA? 0,%d"%(numBlocks-1)) # returned as voltage(1),current(1),time(1),voltage(2),current(2),time(2), etc...
    timed_wait_ms(50)
    d_data = inst.ask("TRAC2:DATA? 0,%d"%(numBlocks-1))
    timed_wait_ms(50)
    
    g = zip(*[iter(g_data.split(','))]*3)
    d = zip(*[iter(d_data.split(','))]*3)
    
    write_drainlag(cfg, g, d, fname, ids)
    
def run_piv(cfg, inst, fname, gate, drain):
    "inner PIV test loop"
    
    print "Vg_ss = %.1fV, Vg_pulse = %.1fV, Vd_ss = %.1fV, Vd_pulse = %.1fV\n"%(gate[0], gate[1], drain[0], drain[1])
    
    # always use entire trace buffer
    numBlocks = 100000

    # reset sources and set them to 4-wire mode        
    config_sources(cfg, inst)

    # configure triggers and pulse values
    config_piv_trigger_test(cfg, inst, gate[0], gate[1], drain[0], drain[1])
    
    # configure trace buffer
    config_SMU_tb(inst, numBlocks)
    
    enable_sources(inst)
    trigger_idle_wait(inst)
    timed_wait_ms(1000)
    initiate_trigger(inst)

    # check to see if SMU has gathered all the data
    bufferfull = False
    while not bufferfull:
        result = int(inst.ask(":STAT:MEAS:COND?")[2:],2)    # string returned from SMU looks like '#Bxxxxxxxxxxxx', need to remove the '#B'
        timed_wait_ms(1000)
        if result&0x0410 == 0x0410: # check for trace buffers to be full
            bufferfull = True

    abort_trigger(inst)
    disable_sources(inst)

    # pull trace data
    print "Acquiring data from SMU..."
    g_data = inst.ask("TRAC1:DATA? 0,%d"%(numBlocks-1)) # returned as voltage(1),current(1),time(1),voltage(2),current(2),time(2), etc...
    timed_wait_ms(50)
    d_data = inst.ask("TRAC2:DATA? 0,%d"%(numBlocks-1))
    timed_wait_ms(50)
    
    g = zip(*[iter(g_data.split(','))]*3)
    d = zip(*[iter(d_data.split(','))]*3)
    
    write_piv(cfg, g, d, fname, gate, drain)

def find_target_Ids(cfg, inst, targetIds):
    
    currentVg = cfg['Vg_start']
    currentId = 0.0
    currentId_rounded = 0.0

    # set sources to pulsed value, then turn them on
    inst.write(":SOUR1:VOLT:IMM %e"%currentVg)
    timed_wait_ms(50)
    inst.write(":SOUR2:VOLT:IMM %e"%cfg['drainlag_Vd_pulse'])
    timed_wait_ms(50)
    enable_sources(inst)
    timed_wait_ms(1000)

    stepSize = cfg['Vg_step']
    targetIds_rounded = round(targetIds*1000,1)
    increasing = True

    # measure Ids
    currentId = float(inst.ask(":MEAS:CURR? (@2)"))
    currentId_rounded = round(currentId*1000,1)
    timed_wait_ms(50)

    while currentId_rounded != targetIds_rounded:
        sys.stdout.write("\x1b[KCurrent Vg/Id: %.5f/%e\r"%(currentVg,currentId))
        sys.stdout.flush()
            
        # if in compliance, throw exception
        gatelimit = int(inst.ask(":SENS1:CURR:PROT:TRIP?"))
        timed_wait_ms(50)
        drainlimit = int(inst.ask(":SENS2:CURR:PROT:TRIP?"))
        timed_wait_ms(50)
        if gatelimit or drainlimit:
            print "DUT in compliance, aborting test!"
            raise SystemExit

        # if smaller than desired and less than max allowed Vg, step up
        if (currentId_rounded < targetIds_rounded) and (currentVg <= cfg['Vg_stop']):
            if not increasing:
                increasing = True
                stepSize = stepSize*cfg['step_factor']
                # limit step size to 10uV
                if stepSize < 1e-5:
                    stepSize = 1e-5
            currentVg = currentVg + stepSize

            # abort trigger, change to next pulse value
            abort_trigger(inst)
            inst.write(":SOUR1:VOLT:IMM %e"%currentVg)
            timed_wait_ms(500) # ensure long enough wait to get measurement before fetching

        # if larger than desired, step down
        elif (currentId_rounded > targetIds_rounded):
            if increasing:
                increasing = False
                stepSize = stepSize*cfg['step_factor']
                # limit step size to 10uV
                if stepSize < 1e-5:
                    stepSize = 1e-5
            currentVg = currentVg - stepSize

            # abort trigger, change to next pulse value
            abort_trigger(inst)
            inst.write(":SOUR1:VOLT:IMM %e"%currentVg)
            timed_wait_ms(50)
            timed_wait_ms(500) # ensure long enough wait to get measurement before fetching

        elif currentVg >= cfg['Vg_stop']:
            print("Reached maximum allowed Vg, continuing test with current corresponding to Vg = %.5f V"%currentVg)
            break

        # measure Ids
        currentId = float(inst.ask(":MEAS:CURR? (@2)"))
        currentId_rounded = round(currentId*1000,1)
        timed_wait_ms(50)
        
        if currentId_rounded == targetIds_rounded:
            print("\x1b[KAllowing current to settle...")
            timed_wait_ms(cfg['target_Ids_delay_ms'])

            # re-measure Ids after settling
            currentId = float(inst.ask(":MEAS:CURR? (@2)"))
            currentId_rounded = round(currentId*1000,1)
            timed_wait_ms(50)

    print("Found target current Id = %e A with Vg = %.5f V"%(currentId,currentVg))
    abort_trigger(inst)
    disable_sources(inst)
    return currentVg

if __name__ == '__main__':
    import optparse, sys
    p = optparse.OptionParser(usage='USAGE: %prog [-c CONFIGFILE] [OUTFILE]')
    p.add_option('-c','--cfg',metavar='FILE',dest='cfg',help='config file path')
    
    opts, args = p.parse_args()
    kw = {}
    if opts.cfg:
        kw['cfgfname'] = opts.cfg
    
    if len(args) == 1:
        kw['fname'] = args[0]
    elif len(args) > 1:
        p.print_usage()
        sys.exit(1)        
    
    main(**kw)
