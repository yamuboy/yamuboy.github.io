#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function

import os, sys
from network_params import BiasedTouchstone

VERSION = '0.1'

def ft_calc( s2p_file, freq ):
    "compute ft"
    
    ft, v1, v2, i1, i2 = 0.0, 0.0, 0.0, 0.0, 0.0
    try:
        ts = BiasedTouchstone(s2p_file)
        ts.convert('h')
        h21 = ts.extract(freq).data[1,0]
        ft = freq*abs(h21)*1.0e-9
        
        if ts.valid_bias:
            v1, v2, i1, i2 = ts.v1, ts.v2, ts.i1, ts.i2
        
    except Exception as ex:
        sys.stderr.write("error reading file '%s' -> %s\n"%(s2p_file,ex))
    
    return ft, v1, v2, i1, i2


if __name__ == '__main__':
    # create a parser for the command line
    import optparse
    p = optparse.OptionParser(usage="%prog [options] file [file2 ...]", version="%prog "+VERSION)
    p.add_option('-f','--freq',dest='freq',type='float',default=1.0,help="extraction frequency in GHz, default is 1.0")
    
    opts,files = p.parse_args()
    
    if not files:
        p.print_usage()
        sys.exit(0)
    
    freq = opts.freq*1.0e9    
    
    results = []
    for f in files:
        results.append([f]+list(ft_calc(f,freq)))
    
    # just print the result to the terminal
    sys.stdout.write("Filename\tV1\tV2\tI1\tI2\tFt\n")
    for r in results:
        sys.stdout.write("{}\t{}\t{}\t{}\t{}\t{}\n".format(*tuple(r)))
        
    
