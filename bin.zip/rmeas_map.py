#!/usr/bin/env python

import math
import instrument
from datetime import datetime
from instrument.multisite import Multisite
from instrument import timed_wait_ms

DEFAULT_CONFIGFILE = 'rmeas.cfg'

def main(cfgfname=DEFAULT_CONFIGFILE,fname=''):
    "entry point"
    # try to read the configuration
    cfg = _default_config()
    try:
        data = {} 
        execfile(cfgfname,data)
        del data['__builtins__']
        cfg.update(data)
        print "read config options from: '%s'"%cfgfname
    except SyntaxError:
	raise
    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no config file, using default options"
        else:
            raise

    # initialize the multisite test object
    multi = Multisite()
    multi.read_map_file(cfg['mapfile'])

    # ask the user what site they want to start at
    start_index = 0
    start_site = raw_input("Starting site? [%s]: "%multi.get_site_name(0)).strip()
    if len(start_site): 
        start_index = multi.get_site_index(start_site)

    print "  starting multi-site at site %d of %d"%(start_index+1,len(multi))

    # initialize multisite
    multi.init_multisite(index=start_index,drvname='12k',addr="GPIB::28")

    # try to open instruments
    smu = instrument.create('bias',*(cfg['meas_smu'][:2]),**(cfg['meas_smu'][2]))
    
    try:
        try:
            run(cfg,smu,fname,multi)
        except KeyboardInterrupt:
            print "aborted"
    finally:
        timed_wait_ms(50)
        smu.config(state=0)
        smu.close()

def run(cfg,smu,fname,multi):
    "run test"
    
    # ask for a file name
    while not fname:
        fname = raw_input('Output file name? ').strip()
    
    # open the file and run the test modules
    fp = open(fname,'w')
    fp.write('! R Measurement - Multisite Version\n')
    fp.write('!\n')
    fp.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    fp.write('!\n')
    fp.write('! Settings:\n')
    fp.write('! I Forced: %f, V Compliance: %f'%(cfg['i_force_ma'],cfg['v_compliance']))
    fp.write('!\n')
    fp.write("!I_meas(mA)\tV_meas(V)\tx\ty\n")
        
    try:
        while True:
	    try:
		r_meas(cfg,fp,smu,multi.current_coord)
		fp.flush()
		multi.next_site()
            except StopIteration:
		break
	    except KeyboardInterrupt:
                # test interrupted, shut down instruments
                smu.set_state(0)
                timed_wait_ms(50)
                
                # ask the user what they want to do
                r = raw_input("*** Test Interrupted ***\n  Do you want to (r)estart this site, go to the (n)ext site, or (q)uit? [q]: ").lower().strip()
                if not r or r.startswith('q'):
                    break
                elif r.startswith('r'):
                    pass
                elif r.startswith('n'):
                    try:
                        multi.next_site()
                    except StopIteration:
                        break
            except Exception:
                # fatal exception, should never have gotten here!!!
                smu.set_state(0)
                timed_wait_ms(50)
                raise

    finally:
	pass
        
def r_meas(cfg,fp,smu,coord):
    "capture the forward I-V curve of the device"
    
    smu.config(mode='I',iset=cfg['i_force_ma']*1e-3,state=1,vlimit=cfg['v_compliance'],resolution='high',remote=True)

    smu.config(state=1)    
    timed_wait_ms(cfg['meas_delay_ms'])
    v_meas = smu.measure()
    smu.config(state=0)
        
    fp.write("%.4e\t%.4e\t%d\t%d\n"%(cfg['i_force_ma'],v_meas,coord[0],coord[1]))
    fp.flush()
    
        
def _default_config():
    "default configuration"
    
    cfg = {}
    cfg['i_force_ma'] = 1.0
    cfg['v_compliance'] = 10.0
    cfg['meas_delay_ms'] = 50
    cfg['meas_smu'] = ('b2902','GPIB::22',{'chan':1})
    
    cfg['mapfile'] = "sites.map"

    return cfg

if __name__ == '__main__':
    import optparse, sys
    p = optparse.OptionParser(usage='USAGE: %prog [-c CONFIGFILE] [OUTFILE]')
    p.add_option('-c','--cfg',metavar='FILE',dest='cfg',help='config file path')
    
    opts, args = p.parse_args()
    kw = {}
    if opts.cfg:
        kw['cfgfname'] = opts.cfg
    
    if len(args) == 1:
        kw['fname'] = args[0]
    elif len(args) > 1:
        p.print_usage()
        sys.exit(1)        
    
    main(**kw)
