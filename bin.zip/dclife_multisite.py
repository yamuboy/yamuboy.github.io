#!/usr/bin/env python

import os, sys, time, math, os.path
from datetime import datetime
from instrument.utils import timed_wait_ms
from instrument.manager import InstrumentManager
from modeling.configfile import ConfigVars, ConfigFile
from modeling.configtypes import *
from optparse import OptionParser
import numpy as np
import logging

delay_time = 50 
def get_response( valid_resp ):
    """Get a response, waiting for a valid one."""
    while True:
        try:
            r = raw_input("  > ").strip()
            if r in valid_resp:
                return r
            elif len(r):
                print " ** invalid response **"
        except KeyboardInterrupt:
            pass

class WaferMap(object):
    """Structure to hold wafer map information."""
    
    _log = logging.getLogger('WaferMap')
    
    def __init__(self):
        """Initialize."""
        self.__xi = 0
        self.__yi = 0
        self.__mf = 'N'
        self.__sites = []
        
    def read_map(self, fname):
        """Read a wafer map file.
        
        The wafer map file has the following format:
        ---------------------------------
        xindex: XXXXX
        yindex: YYYYY
        majorflat: Z
        
        [sites]
        x1 y1
        x2 y2
        x3 y3
        .
        .
        .
        ---------------------------------
        
        Where:
        XXXXX is the step index for X (positive integer)
        YYYYY is the step index for Y (positive integer)
        Z is either N, S, W, or E for the position of the major flat
        
        Any line with a leading '#' is a comment
        
        """
        f = open(fname,'rU')
        startsites = False
        try:
            for line in f:
                if line.startswith('#'):
                    continue
                
                line = line[:-1]
                if not startsites:
                    if line.startswith('xindex:'):
                        self.set_xindex(int(line[7:]))
                    elif line.startswith('yindex:'):
                        self.set_yindex(int(line[7:]))
                    elif line.startswith('majorflat:'):
                        mf = line[10:].strip()
                        self.set_mf(mf)
                    elif line.startswith('[sites]'):
                        startsites = True
                else:
                    if not len(line):
                        continue
                        
                    try:
                        x,y = tuple(line.split())
                        self.add_site(x,y)
                    except Exception, e:
                        self._log.warning("illegal line '%s' in file '%s'"%(line,fname))
                        continue
                        
        finally:
            f.close()
        
    def set_xindex(self, x):
        """Set the X index."""
        x = int(x)
        if x <= 0:
            raise ValueError("X-index must be greater than 0.")            
        self.__xi = x
        
    def set_yindex(self, y):
        """Set the Y index."""
        y = int(y)
        if y <= 0:
            raise ValueError("Y-index must be greater than 0.")            
        self.__yi = y
        
    def set_mf(self, mf):
        """Set the major flat location."""
        mf = mf.upper()
        if mf not in ('N','S','W','E'):
            raise ValueError("Invalid major flat position '%s'"%mf)
        self.__mf = mf
    
    def add_site(self, x, y):
        """Add a site to the map."""
        x, y = int(x), int(y)
        if x <= 0 or y <= 0:
            raise ValueError("site IDs must be positive integers.")
        self.__sites.append( (x,y) )
    
    def compute_pos(self, idx, startidx=0):
        """Compute the differential position from the starting index."""
        indexing_map = dict(N=(self.__xi,-self.__yi),S=(-self.__xi,self.__yi),
            E=(-self.__yi,-self.__xi), W=(self.__yi,self.__xi))
        column_map = dict(N=(0,1), S=(0,1), E=(1,0), W=(1,0))
        
        start = self.__sites[startidx]
        current = self.__sites[idx]
        cm = column_map[self.__mf]
        im = indexing_map[self.__mf]
        return (current[cm[0]]-start[cm[0]])*im[0], (current[cm[1]]-start[cm[1]])*im[1]
       
    def get_site_name(self, idx):
        """Get the name of the site at the given index."""
        x,y = self.__sites[idx]
        return '%0.2d%0.2d'%(x,y)
       
    def get_site_index(self, x, y):
        """Get the ordinal index of site (x,y)."""
        x, y = int(x), int(y)
        for i,site in enumerate(self.__sites):
            if site[0] == x and site[1] == y:
                return i
        raise ValueError("site '%d,%d' is not in the wafer map"%(x,y))
        
    def __getitem__(self,i):
        return self.__sites[i]
    
    def __len__(self):
        return len(self.__sites)


def main():
    parms = {
        'temp':25.0,
        'soak':900.0,
        'mapfile':'sites.map'
    }
        
    filename = raw_input("File name for test data? ")
    if os.path.exists(filename):
        r = raw_input("'%s' exists - overwrite? (y/N)"%filename).strip().lower()
        if not r.startswith('y'):
            return
   
    map1 = WaferMap()
    map1.read_map(parms.get('mapfile','sites.map'))

    mgr = InstrumentManager()
    driver=mgr.get_driver('bias','Keithley236')
    prober = mgr.open_driver('prober','12k','GPIB::28')
    gatesmu = driver('GPIB::21')
    drainsmu = driver('GPIB::23')
    kth_keywords = {'averaging':32,'integration':'linecycle','sensing':'local'}
    gatesmu.config(**kth_keywords)
    drainsmu.config(**kth_keywords) 
    start_x, start_y = prober.get_position() 
    fp = open(filename,'w')
    fp.write("! Multisite DC Life!\n")
    fp.write("! Test Date: %s\n"%datetime.now().strftime("%Y/%m/%d %H:%M:%S"))
    try:
        try:
            for i in range(len(map1)):
                x, y = map1.compute_pos(i)
                site = map1.get_site_name(i)
                if i > 0:
                    # move probe station
                    prober.set_position_synch(start_x+x,start_y+y)
                                
                # run the test
                try:
                    run_site(gatesmu,drainsmu,site,fp,parms)
                except KeyboardInterrupt:
                    print
                    print "test paused, type q to quit, type c to continue"
                    r = get_response( ('q','c',) )
                    if r == 'q':
                        break
                    else:
                        run_site(gatesmu,drainsmu,site,fp,parms)
                    
        except Exception:
            # clean up instruments and exit
            drainsmu.set_state(0)
            timed_wait_ms(50)
            gatesmu.set_state(0)
            raise
    finally:
        fp.close()


def run_site(sgate,sdrain,site,f, params):
    """Capture a set of I-V data from the device."""

    f.write("======== Site (%s)=========\n"%site)
    f.write("Timestamp\tIgate\tIdrain\n")
    
    # set the initial gate and drain current limits
    sgate.config( ilimit=0.8e-3 )
    sdrain.config( ilimit=0.4 )
    sgate.config(mode='V',vset=-1.0,state=1)
    timed_wait_ms(500)
    sdrain.config(mode='V',vset=12.0,state=1)
    timed_wait_ms(1000)
    
    # wait the specified time
    starttime = time.time()
    stoptime = starttime + params.get('soak',1200)
    
    print "Starting soak at:   ",datetime.fromtimestamp(starttime).strftime("%H:%M:%S")
    print "Soak will finish at:",datetime.fromtimestamp(stoptime).strftime("%H:%M:%S")
    while True:
        cur = time.time()
        if cur >= stoptime:
            break
        time.sleep(1.0)
        t = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
        ig= sgate.measure()
        timed_wait_ms(20)
        time.sleep(0.01)
        id= sdrain.measure()
        time.sleep(0.01)
        if sgate.limiting or sdrain.limiting:
            break
        print t, ig, id
        f.write("%s\t%s\t%s\n"%(t,ig,id))
        f.flush()
        

        
    elapsed = cur - starttime
    print "Soak done, elapsed: ", str(elapsed)
    
    sdrain.set_state(0)
    sgate.set_state(0)
    
if __name__ == '__main__':
    main()
    


