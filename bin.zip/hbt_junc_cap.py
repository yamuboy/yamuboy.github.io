from modeling.hbt.junction_cap import VBICCapExtract
import sys
import glob
from modeling.configfile import ConfigVars, ConfigFile
from modeling.configtypes import *
import logging

CONFIG_FILENAME = 'hbt_model.cfg'

def main():
    """Entry point."""
    logging.basicConfig(level=logging.WARNING)
    
    mode_map = { 1:'cbc', 2:'cbe' }
    
    ## get user input ##
    fstr = raw_input("Enter files (wildcards OK):\n")
    mstr = raw_input("\nModes:\n  1 - Cbc\n  2 - Cbe\n\nEnter Mode: ")
    try:
        mode = mode_map[int(mstr)]
    except:
        print "Invalid mode."
        sys.exit(1)
    outfname = raw_input("Enter output filename: ")
    
    
    ## read data from the configuration file ##
    cv = ConfigVars()
    cv.add('cj_fmin', CF_FLOAT, default=0.0)
    cv.add('cj_fmax', CF_FLOAT, default=100.0)
    cv.add('cbc_vmax', CF_FLOAT, default=100.0)
    cv.add('cbe_vmax', CF_FLOAT, default=100.0)
    cv.add('rb', CF_FLOAT, default=1.0e-6)
    cv.add('rc', CF_FLOAT, default=1.0e-6)
    cv.add('re', CF_FLOAT, default=1.0e-6)
    cv.add('lb', CF_FLOAT, default=1.0e-18)
    cv.add('lc', CF_FLOAT, default=1.0e-18)
    cv.add('le', CF_FLOAT, default=1.0e-18)
    try:
        # try to locate and parse the config file
        cfg = ConfigFile()
        cfg.read(CONFIG_FILENAME)
        # get values for the defined variables
        # start by searching the [hbt] section first, then fall
        # back to the [global] section (implied)
        kw = cfg.get_variables(cv, section='hbt')
    except IOError:
        print "Config file '%s' not found."%CONFIG_FILENAME
        sys.exit(1)
    
    ## extract the junction capacitance ##
    xt = VBICCapExtract()
    xt.extract(glob.glob(fstr),mode,**kw)
    
    ## print data to the terminal ##
    print "CJ = %g"%xt.model['cj'].v
    print "PJ = %g"%xt.model['p'].v
    print "MJ = %g"%xt.model['m'].v
    print "FC = %g"%xt.model['fc'].v
    print "AJ = %g"%xt.model['aj'].v
    
    ## write data to a file ##
    data = xt.cap_data[:]
    data.sort()
    f = open(outfname,'w')
    f.write("! CJ = %g\n"%xt.model['cj'].v)
    f.write("! PJ = %g\n"%xt.model['p'].v)
    f.write("! MJ = %g\n"%xt.model['m'].v)
    f.write("! FC = %g\n"%xt.model['fc'].v)
    f.write("! AJ = %g\n"%xt.model['aj'].v)
    f.write("! CC = %g\n"%xt.ccave)
    f.write("!\n! Vj\tCj\tCj-mod\n")
    for vj,cj in data:
        cjm = xt.model.compute_cj(vj)
        f.write("%g\t%g\t%g\n"%(vj,cj,cjm))
    f.close()
    
if __name__ == '__main__':
    main()
    
