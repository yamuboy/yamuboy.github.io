#!/usr/bin/env python

import os, os.path, sys
import visa


def load_enr_8970(addr, table, instrkw={}):
    "load the ENR table into an HP 8970 NFM"
    
    # check the ENR table
    out = []
    if not isinstance(table,(list,tuple)):
        raise TypeError("'table' must be a list/tuple object")
    if not len(table) or len(table) > 99:
        raise ValueError("ENR table length error: 1 <= len(table) <= 99")
    for d in table:
        if not isinstance(d,(list,tuple)) or len(d) != 2:
            raise TypeError("'table' must be a list/tuple containing 2-tuples")
        out.append( (float(d[0]),float(d[1])) )        
    
    # load the ENR table into the instrument
    nfm = visa.instrument(addr,**instrkw)
    
    nfm.write("NR")
    for fr, enr in out:
        nfm.write("%.0fEN%.3fEN"%(fr*1000.0,enr))
    nfm.write("FR")

    nfm.close()
    

def main():
    "entry point"
        
    # hard code address for now
    loader = load_enr_8970
    address = 'GPIB::8'
    instrkw = {}
    
    # read in data from the ENR table file
    fpath = os.path.expanduser('~/.enrdata')
    if not os.path.isfile(fpath):
        sys.stderr.write("Error: '%s' is not present\n\n"%fpath)
        return -1
        
    try:
        cfg = {}
        execfile(fpath,cfg)
        if 'ENRDATA' not in cfg:
            raise ValueError("in file '%s' => 'ENRDATA' is not present"%fpath)
        
        data = cfg['ENRDATA']
        if not isinstance(data,dict):
            raise ValueError("in file '%s' => 'ENRDATA' is not a dictionary object"%fpath)
        
        if not len(data):
            raise ValueError("in file '%s' => 'ENRDATA' is empty"%fpath)
    
    except Exception, e:
        sys.stderr.write("Error: %s\n\n"%e)
        return -2
        
    idx = data.keys()
    idx.sort()
    table_name = None
    table_data = None
    print('')
    print('Noise Source Selection')
    print('------------------------------------------------')
    for i,k in enumerate(idx):
        print(' %2d - %s'%(i+1,k))
    print('')
    while True:
        r = raw_input('Selection? ').strip()
        if not len(r):
            continue
        try:
            v = int(r)
            if v < 1 or v > len(idx):
                raise ValueError("invalid index")
            table_name = idx[v-1]
            table_data = data[table_name]
            break            
        except Exception:
            print('  *** invalid selection ***')
    
    if not table_data:
        sys.stderr.write("Error: ENR table '%s' is empty\n\n"%table_name)
        return -3
        
    print('')
    print('loading ENR table ...')
    loader(address,table_data,instrkw)
    print('done')
    print('')
    
if __name__ == '__main__':
    main()
    
