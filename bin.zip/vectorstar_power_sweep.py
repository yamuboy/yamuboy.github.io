#!/usr/bin/env python

import visa
import time
import sys
import datetime
from instrument.manager import InstrumentManager
from instrument.utils import timed_wait_ms
from optparse import OptionParser
import instrument
import os


def load_config(name):
    cfg = {}
    execfile(name,cfg)
    del cfg['__builtins__']
    return cfg

def main(cfg=None):

    filename= raw_input('Enter the filename for the test:\n')
    if os.path.exists(filename):
        print "Warning: file '%s' exists." % filename
        if raw_input("Overwrite the existing file? (y/N): ").strip().lower()[0] != 'y': 
            print "Exiting."
            return
   
    run_test(filename)

def run_test(filename):
    "main routine of test"
        
    # open instruments
    vna= visa.instrument('GPIB::6')
    f = open(filename,'w')
    f.write("! Date/Time: %s\n"%datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write("!\n")
    f.write("!Pin\tPout\tGain/Loss\n")
    f.write("!(dBm)\t(dBm)\t(dB)\n")
    

    try:
               
        points = int(vna.ask('SOUR1:POW:PORT1:LIN:POW:POIN?'))
        start =  float(vna.ask('SOUR1:POW:PORT1:LIN:POW:START?'))
        stop = float(vna.ask('SOUR1:POW:PORT1:LIN:POW:STOP?'))
        #print 'points %f\t start %f\t stop %f'%(tmp_points,tmp_start,tmp_stop)
        #print 'config points %f\t config start %f\t config stop%f'%(points,config['start_power'],config['stop_power'])

        # force the sweep to restart
        #vna.write(':SENS:HOLD:FUNC HOLD')
        #vna.write(':TRIG:SING')
        vna.write(':TRIG:SOUR AUTO')
        vna.write(':TRIG:REM:TYP SWE')
        vna.write('*CLS')
        vna.write(':SENS:HOLD:FUNC SING')
        time.sleep(0.4) 
        #vna.write(':TRIG')

        # this stupid wait is needed because the instrument is really slow
        # at setting up
        time.sleep(10) 

        # wait for the sweep
        while 0:
            x = int(vna.ask(':STAT:OPER:COND?'))
            print x
            if x & 4:
                break
            time.sleep(0.1)

        # read VNA
        #p_out = vna.ask_for_values('OFD2')
        p_out = vna.ask_for_values(":CALC:PAR2:SEL;:CALC:SEL:DATA:FDATA?")[1:]
        #p_in = vna.ask_for_values('OFD1')
        p_in = vna.ask_for_values(":CALC:PAR1:SEL;:CALC:SEL:DATA:FDATA?")[1:]

        if len(p_out) != points:
            raise ValueError("wrong number of points in p_out array (%d != %d)"%(points,len(p_out)))
        if len(p_in) != points:
            raise ValueError("wrong number of points in p_in array (%d != %d)"%(points,len(p_in)))

        for i in range(points):
            # write data to the file
            f.write("%.4f\t%.4f\t%.4f\n"%(p_in[i],p_out[i],p_out[i]-p_in[i]))

    finally:
        vna.write(':SENS:HOLD:FUNC CONT')
        vna.write(':STAT:OPER:ENAB 0')
        f.close()
        vna.close()


if __name__ == '__main__':
    "entry point"
    parser = OptionParser()
    parser.add_option("-f", "--file", dest="filename", help="Read configiguration from FILE", metavar="FILE")
    opts,args = parser.parse_args()
    fname = opts.filename
    
    # run the main routine
    main(fname)
    

              

