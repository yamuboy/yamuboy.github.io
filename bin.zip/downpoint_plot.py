#!/usr/bin/env python2.6

import wx
from maplot.downpoint import DownpointPlotFigure, DownpointPlotMain

app = wx.App(redirect=False)
frame_1 = DownpointPlotMain(DownpointPlotFigure(),None)
app.SetTopWindow(frame_1)
frame_1.Show()
app.MainLoop()

