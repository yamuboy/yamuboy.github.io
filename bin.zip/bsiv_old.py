#!/usr/bin/env python

import os.path
import datetime
from instrument.manager import InstrumentManager
from instrument.family.bias import BiasInstrument
from instrument.utils import timed_wait_ms
from modeling.configfile import ConfigVars, ConfigFile
from modeling.configtypes import *
from optparse import OptionParser
import numpy as np


# set a delay time in the measurement
delay_time = 50 

def load_config( name ):
    """Load config data from a file."""
    cv = ConfigVars()
    cv.add('gate_voltages', CF_FLOATTUPLE)
    cv.add('drain_voltages', CF_FLOATTUPLE)
    cv.add('drain_voltage_range', CF_FLOATTUPLE)
    cv.add('gate_voltage_range', CF_FLOATTUPLE)
    cv.add('backside_voltages', CF_FLOATTUPLE)
    cv.add('power_limit', CF_FLOAT, default=1000.0)
    cv.add('gate_ilimit', CF_FLOAT, default=1.0)
    cv.add('drain_ilimit', CF_FLOAT, default=1.0)
    cv.add('sweep_order', CF_TUPLE, default=('g','d'))
    cv.add('output_format')
    
    cf = ConfigFile()
    cf.read(name)
    return cf.get_variables(cv)

def _get_voltages(d):
    """Create a voltage list."""
    assert len(d) == 3
    return np.arange(d[0],d[1]+0.1*d[2],d[2])
    
def main( cfg=None ):
    """Main routine."""
    
    if cfg is not None:
        if isinstance(cfg,str):
            # cfg is an argument specifying the config file name
            cdata = load_config(cfg)
        else:
            # config data passed in
            cdata = cfg
    else:
        # try to load the config from the default config file locations
        cdata = load_config('ivconfig.cfg')
    
    # figure out the voltages, ranges override configured sweep points
    if len(cdata['gate_voltage_range']):
        cdata['gate_voltages'] = _get_voltages(cdata['gate_voltage_range'])
    if len(cdata['drain_voltage_range']):
        cdata['drain_voltages'] = _get_voltages(cdata['drain_voltage_range'])
    
    # read in the name for the data file
    dfile = raw_input("Enter a file name for the data: ")
    if os.path.exists(dfile):
        print "Warning: file '%s' exists." % dfile
        answer = raw_input("Overwrite the existing file? (y/N): ")
        if answer.strip().lower() != 'y':
            print "Exiting."
            return
    
    # open the file and write the header
    f = open(dfile, "w")
    f.write( "! Custom I-V Measurement Program\n!\n" )
    f.write( "! Date/Time: %s\n" % datetime.datetime.now().isoformat(' ') )
    f.write( "!\n" )
    
    # start the test
    try:
        run_test(cdata, f)
        print "Done."
    except Exception:
        import traceback
        traceback.print_exc()
        print "Exiting."
    finally:
        f.close()
    
def run_test( config, f ):
    """Run the test routine."""
    # load and init instruments
    # hard-coded
    manager = InstrumentManager()
    driver = manager.get_driver(BiasInstrument,'keithley236')
    sgate = driver('GPIB::21')
    sdrain = driver('GPIB::23')
    ilist = [sgate,sdrain]
    
    do_backgate = bool(len(config['backside_voltages']))
    
    if do_backgate:
        sback = driver('GPIB::24')
        ilist.insert(0,sback)
    
    for instr in ilist:
        instr.initialize()
    
    # start looping through backside voltages
    try:
        if do_backgate:
            for bsv in config['backside_voltages']:
                # set and turn on the backside voltage source
                sback.set_source(bsv)
                sback.set_state(1)
                sback.measure()
         
                print "========= V_back = %f =========" % bsv
                # capture the I-V curves of the device
                capture_iv_curve( config, f, sgate, sdrain, sback )
        else:
            capture_iv_curve( config, f, sgate, sdrain, None )
    finally:
        # close all sources (turns them off in the process)
        for instr in reversed(ilist):
            instr.close()
        f.close()
        
    

def capture_iv_curve( config, f, sgate, sdrain, sback ):
    """Capture a set of I-V data from the device."""
    
    # set the initial gate and drain current limits
    sgate.configure( ilimit=config['gate_ilimit'] )
    ilim = config['drain_ilimit']
    sdrain.configure( ilimit=ilim )
    power_limit = config['power_limit']
    
    order = config['sweep_order']

    def _inner(first):
        # set the power/current limit
        dv2 = abs(dv) + 0.001
        ilimp = power_limit / dv2
        ilim2 = ilim
        if ilimp < ilim: ilim2 = ilimp
        sdrain.configure(ilimit=ilim2)
        
        # set the voltages
        sgate.set_source(gv)
        sdrain.set_source(dv)
        
        if first:
            # turn on the supplies
            sgate.set_state(1)
            sdrain.set_state(1)

            # write the header
            if config['output_format'].lower() == 'mdif': 
                f.write( "!\n" )
                if sback is not None:
                    f.write( "VAR Vbs(1) = %f\n" % sback.get_source() )
                f.write( "VAR Vgs(1) = %f\n" % gv )
                f.write( "BEGIN TESTDATA\n" )
                f.write( "%   Vds(1)     Ids(1)    Igs(1)\n" )
            else:
                f.write( "!\n" )
                if sback is not None:
                    f.write( "! Vbs = %f\n" % sback.get_source() )                    
                f.write("! Vds\tIds\tVgs\tIgs\n")
                
        timed_wait_ms(delay_time)
        # measure the currents
        #print ".",
        gc = sgate.measure()
        dc = sdrain.measure()
        
        # check for limiting conditions
        if sgate.ask_if_limiting():
            return
        if sdrain.ask_if_limiting():
            raise StopIteration
        
        # write the data
        if config['output_format'].lower() == 'mdif': 
            f.write( "%.3e\t%.3e\t%.3e\n" % (dv,dc,gc) )
        else:
            f.write( "%.3e\t%.3e\t%.3e\t%.3e\n" % (dv,dc,gv,gc) )
                
                
    if order[0].lower()[0] == 'g':
        for gv in config['gate_voltages']:
            first=True
            print "Vgs = %f" % gv
            for dv in config['drain_voltages']:
                try:
                    _inner(first)
                except StopIteration:
                    break
                first=False
            
            sdrain.set_state(0)
            sgate.set_state(0)
            
            if config['output_format'].lower() == 'mdif': 
                f.write("END\n")
    else:
        for dv in config['drain_voltages']:
            first=True
            print "Vds = %f" % dv
            for gv in config['gate_voltages']:
                try:
                    _inner(first)
                except StopIteration:
                    break
                first=False
            
            sdrain.set_state(0)
            sgate.set_state(0)
            
            if config['output_format'].lower() == 'mdif': 
                f.write("END\n")
    
    
if __name__ == '__main__':
    
    parser = OptionParser()
    parser.add_option("-f", "--file", dest="filename", help="Read configiguration from FILE", metavar="FILE")
    opts,args = parser.parse_args()
    fname = opts.filename
    
    # run the main routine
    print "Config file:",fname
    main(fname)
    
