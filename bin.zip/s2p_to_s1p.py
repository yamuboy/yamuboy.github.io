#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function
from network_params import Touchstone
from optparse import OptionParser
import sys

def main(inname, outname, use_s22=False):
    "entry point"
    i = Touchstone(inname)
    if i.nports != 2:
        raise ValueError("'%s' is not a 2-port data file"%inname)
    
    o = i.copy_truncated()
    for p in i:
        if use_s22:
            d = p.data[1,1]
        else:
            d = p.data[0,0]
        o.insert(p.freq,d)
    
    o.write(outname)

if __name__ == '__main__':
    
    p = OptionParser(usage="%prog [options] s2p_file output_file")
    p.add_option('-2',dest='port2',action='store_true',help='use port 2 data for the s1p file')
    
    opts, files = p.parse_args()
    
    if len(files) != 2:
        p.print_usage()
        sys.exit(1)
    
    kw = {}
    if opts.port2:
        kw['use_s22'] = True
    
    main(files[0],files[1],**kw)
    
