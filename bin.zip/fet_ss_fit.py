#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function

import os, sys, os.path
import shutil
import signal
from modeling.fet.extract.ss import SSExtract
from modeling.fet import FET_Model_Config
from modeling import load_config
import logging

VERSION='0.1'
CONFIG_FILE='fetmod.cfg'

try:
    inpf = raw_input
except NameError:
    inpf = input
    

def _gen_config_cb(option, opt_str, value, parser, *args, **kwargs):
    "callback for the --gen-config option"
    # this callback generates a default config file and then causes
    # the program to exit immediately
    fname = None
    if len(parser.rargs):
        arg = parser.rargs[0]
        if arg[0] != '-':
            fname = arg
            del parser.rargs[0]

    if not fname:
        fname = CONFIG_FILE

    if os.path.exists(fname):
        sys.stderr.write("Cowardly refusing to overwrite existing file '%s'\n\n"%fname)
        sys.exit(1)

    cfg = FET_Model_Config()
    cfg.write_file(fname)
    sys.exit(0)


def _update_config_cb(option, opt_str, value, parser, *args, **kwargs):
    "callback for the --update-cfg option"
    # this callback generates a default config file and then causes
    # the program to exit immediately
    fname = None
    if len(parser.rargs):
        arg = parser.rargs[0]
        if arg[0] != '-':
            fname = arg
            del parser.rargs[0]

    if not fname:
        sys.stderr.write("'%s' requires a file name parameter\n\n"%opt_str)
        sys.exit(1)

    cfg = FET_Model_Config()
    cfg.read_file(fname)
    
    # save a backup copy
    shutil.copy2(fname,fname+'.bak')

    cfg.write_file(fname)
    sys.exit(0)


def simple_daemonize():
    "a quick and dirty daemonize for disconnecting from the terminal"

    # note that this does not perform all of the typical tasks that
    # are required of a daemon-izing program since the program
    # is not really designed to run continuously like most daemons

    # really what we are doing here is a double-fork to disconnect
    # from the controlling terminal and move into our own process
    # group followed by retargeting the stdin/stdout/stderr file
    # descriptors to /dev/null

    # fork 1
    pid = os.fork()
    if pid == 0:
        # become the session leader of a new process group
        os.setsid()

        # ignore SIGHUP
        signal.signal(signal.SIGHUP,signal.SIG_IGN)

        # fork 2
        pid = os.fork()
        if pid == 0:
            # child process
            pass
        else:
            # exit second parent
            os._exit(0)
    else:
        # exit first parent
        os._exit(0)

    # retarget stdin, stdout, and stderr to /dev/null
    os.close(0)
    os.close(1)
    os.close(2)
    os.open('/dev/null',os.O_RDWR)
    os.dup2(0,1)
    os.dup2(0,2)

def main():
    "entry point for the command-line model fit tool"
    
    # create a command-line option parser
    import optparse
    p = optparse.OptionParser(usage="%prog [options] [s2p_files ...]", version="%prog "+VERSION)
    p.add_option('-c','--config-file',metavar='FILE',dest='config',help="use the configuration file FILE, if this is not specified then a file named '%s' in the current directory will be used"%CONFIG_FILE)
    p.add_option('-g','--gen-config',action='callback',metavar="FILE",callback=_gen_config_cb,help="write a new configuration file named FILE using all of the default configuration options")
    p.add_option('-u','--update','--update-cfg',action='callback',metavar="FILE",callback=_update_config_cb,help="Update config file FILE by filling in missing options")
    p.add_option('-q','--quiet',action='store_false',dest='verbose',default=True,help='suppress all output')
    p.add_option('-i','--interactive',action='store_true',dest='interactive',help='run in interactive mode')
    p.add_option('--yfit',action='store_true',dest='yfit',help='run a Y-fit on all target S-parameter files (batch mode only)')
    p.add_option('--optimize',action='store_true',dest='optimize',help='run an optimization on all target S-parameter files (batch mode only)')
    p.add_option('--coldfet',action='store_true',dest='coldfet',help='run a cold-FET extraction')
    p.add_option('--noise',action='store_true',dest='noise',help='run a noise extraction')
    p.add_option('--all',action='store_true',dest='extract_all',help='run all extractions sequentially')
    p.add_option('--debug',action='store_true',dest='debug',help='enable debug logging')
    p.add_option('--bg','--background',action='store_true',dest='background',help='fork to the background')
    p.add_option('-l','--logfile',metavar='FILE',dest='logfile',default='ssfit.log',help='log file name for background mode')
    
    opts,files = p.parse_args()

    cfg_search = True
    if opts.config:
        cfgfname = opts.config
        cfg_search = False
    else:
        cfgfname = CONFIG_FILE
    
    if not len(files):
        files = None
            
    if opts.interactive:
        #### go into interactive mode ####
        interactive_menu(cfgfname)
        
    #### batch mode ####
    
    # set up batch-mode logging
    logging_args = {'level':logging.ERROR}

    if opts.background:
        # background job
        logging_args['format'] = "%(asctime)s %(levelname)s: %(message)s" 
        logging_args['filename'] = opts.logfile 
        if opts.debug:
            logging_args['level'] = logging.DEBUG
            logging_args['format'] = "%(asctime)s [%(filename)s:%(lineno)d] %(levelname)s: %(message)s" 
        elif opts.verbose:
            logging_args['level'] = logging.INFO

        simple_daemonize()
    else:
        logging_args['format'] = "%(levelname)s: %(message)s" 
        if opts.debug:
            logging_args['level'] = logging.DEBUG
            logging_args['format'] = "[%(filename)s:%(lineno)d] %(levelname)s: %(message)s" 
        elif opts.verbose:
            logging_args['level'] = logging.INFO

    logging.basicConfig(**logging_args)

    # load the configuration file
    try:
        cfg, p = load_config(cfgfname)
        logging.info("read config file: %s"%p)
    except Exception as e:
        logging.warning("config file could not be read")
        sys.stderr.write("WARNING: config file '%s' could not be read. => %s\n"%(cfgfname,e))
        sys.stderr.write("WARNING: default configuration parameters will be used.\n")
    
    # figure out what to do
    docf, doy, doopt, donoise = False, False, False, False
    if opts.extract_all:
        docf, doy, doopt, donoise = True, True, True, True
    else:
        if opts.yfit:
            doy = True
        if opts.optimize:
            doopt = True
        if opts.coldfet:
            docf = True
        if opts.noise:
            donoise = True
            
    if not docf and not doy and not doopt and not donoise:
        sys.stderr.write("ERROR: nothing to do.\n")
        sys.exit(1)
    
    ### create the extraction object and run the extractions ###
    xtr = SSExtract()
    if docf:
        if files and not (doy or doopt or donoise):
            xtr.coldfet(files)
        else:
            xtr.coldfet()
    
    if doy and doopt:
        xtr.yfit_and_optimize(files)
    elif doy:
        xtr.yfit(files)   
    elif doopt:
        xtr.optimize(files)
    
    if donoise:
        xtr.noise(files)
        
    
def interactive_menu(cfgfile):
    """interactive mode"""
    
    cfg = ConfigData()
    
    
    ###### unfinished #######
    
    
    
    xtr = SSExtract()
    picklist = {
        'y':xtr.yfit,
        'o':xtr.optimize,
        }
    
    
    while True:
        
    
    
        try:
            p = _menu_select(valid_picks=picklist.keys())
            
        except KeyboardInterrupt:
            break
    
    
    sys.exit(0)
    


def _menu_select(prompt='Selection? ', valid_picks=None):
    "select a pick from the menu"
    while True:
        try:
            r = inpf(prompt).strip().lower()
            if valid_picks and r not in valid_picks:
                raise ValueError()
            return r
        except KeyboardInterrupt:
            raise
        except ValueError:
            sys.write.stdout(" *** invalid entry ***\n")


if __name__ == '__main__':
    main()
