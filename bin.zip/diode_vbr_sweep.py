#!/usr/bin/env python

import os.path
import datetime
import math
import sys
from instrument import InstrumentManager, timed_wait_ms


# measurement parameters
vbr_delay_time = 2000
vsweep_delay_time = 100
keithley_addr = 'GPIB::21'
v_compliance = 110.0
i_set_for_vbr = 1.0e-6
num_v_points = 20


    
def main(neg=False):
    """Main routine."""
    i_level = abs(i_set_for_vbr)
    if neg:
        i_level = -i_level
    
    # open the instrument
    smu = InstrumentManager().open_driver('bias','keithley236',keithley_addr,averaging=32,integration='linecycle',sensing='remote')    
    
    # request the data file name from the user
    fname = raw_input("Data file name? ").strip()
    if not fname:
        sys.stderr.write("Invalid file name.\n")
        sys.exit(1)
    
    # open the file and write the header
    fp = open(fname,"w")
    fp.write("! Custom Diode Vbr Measurement Program\n!\n")
    fp.write("! Date/Time: %s\n"%datetime.datetime.now().isoformat(' '))
    fp.write("! I-br: %g\n"%i_level)
    fp.write("! V-compliance: %g\n"%v_compliance)
    fp.write("!\n")
    
    # set the SMU to measure the breakdown
    smu.config(mode='I',iset=i_level,vlimit=v_compliance,state=1)
    timed_wait_ms(vbr_delay_time)
    vbr = smu.measure()
    smu.config(state=0)
    fp.write("! Vbr-measured: %g\n"%vbr)
    fp.write("!\n! V      I\n")
    
    # generate a voltage sweep for the breakdown curve
    vmax = math.floor(abs(vbr))
    if i_level < 0.0:
        vmax = -vmax
    vstep = vmax / float(num_v_points)
    vswp = [vstep*(i+1) for i in range(num_v_points)]
    
    # sweep the voltage
    smu.config(mode='V',vset=0.0,ilimit=abs(i_level),vrange=abs(vmax),state=1)
    timed_wait_ms(vsweep_delay_time)
    
    for v in vswp:
        smu.config(vset=v)
        timed_wait_ms(vsweep_delay_time)
        i = smu.measure()
        fp.write("%g\t%g\n"%(v,i))
        
    fp.close()
    smu.close()
    
if __name__ == '__main__':    
    neg = False
    for a in sys.argv[1:]:
        if a == '-n':
            neg = True
    main(neg)
    
