#!/usr/bin/env python
"""



"""
from __future__ import unicode_literals, absolute_import, division, print_function
import os, sys
from network_params import ParamSet, Touchstone
import numpy as np
import logging
import optparse
from glob import glob

try:
    inpf = raw_input
except NameError:
    inpf = input

def em_finger_deembed( meas_p, em_p, num_fingers, common_gate=True, common_gate_mapping=['d','s'], common_source_mapping=['g','d','s'] ):
    """EM deembedding routine
    
    """
    
    if not isinstance(meas_p,ParamSet):
        raise ValueError("'meas_p' is not a `network_params.ParamSet` object")
    elif meas_p.nports != 2:
        raise ValueError("'meas_p' is not a 2-port data set")
        
    if not isinstance(em_p,ParamSet):
        raise ValueError("'em_p' is not a `network_params.ParamSet` object")
    
    # check mappings
    # common_gate_mapping
    
    
    
    # make sure num_fingers is an integer
    num_fingers = int(num_fingers)
    
    # compute port counts
    if common_gate:
        n_int_ports = 2
    else:
        n_int_ports = 3
    em_size = num_fingers*n_int_ports + 2
    
    if em_p.nports != em_size:
        raise ValueError("'em_p' must be a %d-port data set (for the given parameters)"%em_size)
    
    # convert measured and EM data into Y-parameters
    meas_p.convert('y')
    em_p.convert('y')
    
    # start the math
    out = meas_p.copy_truncated()
    for m in meas_p:
        
        # extract data from the EM dataset
        try:
            emd = em_p.extract(m.freq)
        except Exception:
            logging.warning("EM data set does not encompass frequency %g GHz - this data will not be available in the output set"%(m.freq*1.0e-9))
            continue
        
        # partition the EM data and convert to the speciality `numpy.matrix` type for matrix math operations
        A = np.matrix(emd[0:2,0:2])
        B = np.matrix(emd[0:2,2:])
        C = np.matrix(emd[2:,0:2])
        D = np.matrix(emd[2:,2:])
        
        # debug:
        # print "shape(A) = %s, shape(B) = %s, shape(C) = %s, shape(D) = %s"%(A.shape,B.shape,C.shape,D.shape)
        
        # compute deembedding
        E = (A-m.data).I
        T = C*E*B-D
        
        # average the result matrix over the sub-matrices that make up the fingers
        TA = np.zeros((n_int_ports,n_int_ports),dtype=complex)
        for x in range(num_fingers):
            for y in range(num_fingers):
                for i in range(n_int_ports):
                    for j in range(n_int_ports):
                        TA[i,j] += T[x*n_int_ports+i,y*n_int_ports+j]
        TA = TA / float(num_fingers)
        
        # convert common gate solution to common source
        # OR
        # convert common source (indefinite form) to 2-port common source
        if common_gate:
            # convert common gate to common source
            md = common_gate_mapping.index('d')
            ms = common_gate_mapping.index('s')
            R = np.array([[TA[ms,ms]+TA[md,ms]+TA[ms,md]+TA[md,md],-TA[ms,md]-TA[md,md]],[-TA[md,ms]-TA[md,md],TA[md,md]]])
        else:
            # take the indefite common source matrix and drop the source
            mg = common_source_mapping.index('g')
            md = common_source_mapping.index('d')
            R = np.array([[TA[mg,mg],TA[mg,md]],[TA[md,mg],TA[md,md]]])
        
        # store the results
        out.insert(m.freq,R)
    
    # convert back to S-parameters and return the results
    out.convert('s')
    return out
        
def em_finger_cl():
    "command-line interface for EM-based FET finger deembedding"
    
    ext = '.dm2'
    commongate = True
    num_fingers = 1
    
    
    
    # interactive mode
    if True:
        em_sp_f = inpf("EM sNp data file? ").strip()
        em_data = Touchstone(em_sp_f)    
        
        meas_sp_f = inpf("Measured s2p data file(s)? ").strip()
        flist = []
        for pat in meas_sp_f.split(';'):
            if pat.find('*') > -1 or pat.find('?') > -1 or pat.find('[') > -1:
                flist.extend(glob(pat))
            else:
                flist.append(pat)

        r = inpf("Extension for output file(s) [.dm2]? ").strip()
        if len(r):
            if not r.startswith('.'):
                ext = '.'+r
            else:
                ext = r
        
        try:
            num_fingers = int(inpf("Number of FET fingers in EM [1]? "))
        except Exception:   
            pass
        
        r = inpf("Common gate mode [Y/n]? ").strip().lower()
        if r.startswith('n'):
            commongate = False
        
    # run the deembedding routine
    for f in flist:
    
        print("{} ...".format(f))
        
        try:
            meas = Touchstone(f)
        except Exception, e:
            sys.stderr.write("Error: could not read '%s' -> %s\n"%(f,e))
            continue
            
        outfname = os.path.splitext(f)[0] + ext
        if outfname == f:
            sys.stderr.write("Error: output file name is the same as input file name\n")
            continue
    
        # compute deembedding
        out = em_finger_deembed(meas,em_data,num_fingers,common_gate=commongate)
        
        # write output
        if isinstance(out,Touchstone):
            out.write(outfname)
        else:
            t = Touchstone(out)
            t.write(outfname)
            
if __name__ == '__main__':
    em_finger_cl()
    