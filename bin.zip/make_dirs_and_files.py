#!/usr/bin/env python2.6

from modeling.mct_files import make_dirs_and_files_cl
make_dirs_and_files_cl()

