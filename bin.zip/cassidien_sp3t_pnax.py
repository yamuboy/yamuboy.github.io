#!/usr/bin/env python

import os, sys
import visa
from network_params import Touchstone
import instrument
from instrument.multisite import Multisite
from instrument import timed_wait_ms



TESTS = [
    # testname, pna port 1, pna port 2, bias 1 mA, bias 2 mA, bias 3 mA
    ('J1_J2_ins_5ma',1,2,-5.0,5.0,5.0),
    ('J1_J2_ins_10ma',1,2,-10.0,5.0,5.0),
    ('J1_J2_ins_20ma',1,2,-20.0,5.0,5.0),
    ('J1_J2_ins_40ma',1,2,-40.0,5.0,5.0),
    ('J1_J2_isol_5ma',1,2,5.0,-5.0,5.0),
    ('J1_J2_isol_40ma',1,2,40.0,-5.0,5.0),
    ('J1_J3_ins_5ma',1,3,5.0,-5.0,5.0),
    ('J1_J3_ins_10ma',1,3,5.0,-10.0,5.0),
    ('J1_J3_ins_20ma',1,3,5.0,-20.0,5.0),
    ('J1_J3_ins_40ma',1,3,5.0,-40.0,5.0),
    ('J1_J3_isol_5ma',1,3,-5.0,5.0,5.0),
    ('J1_J3_isol_40ma',1,3,-5.0,40.0,5.0),
    ('J1_J4_ins_5ma',1,4,5.0,5.0,-5.0),
    ('J1_J4_ins_10ma',1,4,5.0,5.0,-10.0),
    ('J1_J4_ins_20ma',1,4,5.0,5.0,-20.0),
    ('J1_J4_ins_40ma',1,4,5.0,5.0,-40.0),
    ('J1_J4_isol_5ma',1,4,5.0,-5.0,5.0),
    ('J1_J4_isol_40ma',1,4,5.0,-5.0,40.0),
]


class PNAX_sp(object):
    """
    Simple PNA-X S-parameter reader
    
    """

    def __init__(self, resource, chan=1):
        "initializer"
        self.vi = visa.instrument(resource,values_format=visa.double)
        self.chan = int(chan)
        
        assert self.chan > 0
        
        # initialize setup and put sweep in hold
        self.vi.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
        self.vi.write('SENS%d:SWE:MODE HOLD'%self.chan)
    
    def read_sparams(self, ports=[1,2]):
        """Read S-parameters"""
        
        mports = ports[:]
        mports.sort()
        
        for p in mports:
            assert 1 <= p <= 4
        
        ##### generate measurements #####
        
        # get measurement catalog
        x = self.vi.ask('CALC%d:PAR:CAT:EXT?'%self.chan).split(',')
        assert (len(x)%2 == 0)
        catalog = {}
        for i in range(0,len(x),2):
            n = x[i].strip('\'"')
            v = x[i+1].strip('\'"')
            catalog[n] = v
        
        # create measurements as needed
        measurements = []
        for p in mports:
            for p2 in mports:
                m = "S%d_%d"%(p,p2)
                mname = "pymeas_%s"%m
                measurements.append(mname)
                if mname not in catalog:
                    self.vi.write("CALC%d:PAR:DEF:EXT '%s','%s'"%(self.chan,mname,m))
        
        # detect averaging state
        avg = int(self.vi.ask('SENS%d:AVER:STAT?'%self.chan))
        if avg:
            count = int(self.vi.ask('SENS%d:AVER:COUN?'%self.chan))
            # restart averaging
            self.vi.write('SENS%d:AVER:CLEAR'%self.chan)
        else:
            count = 1
        
        # set the group count to be equal to the averaging
        self.vi.write('SENS%d:SWE:GRO:COUN %d'%(self.chan,count))
        # trigger a measurment group
        self.vi.write('SENS%d:SWE:MODE GRO;*ESE 1;*OPC'%self.chan)
        
        # wait for the measurement to finish
        while True:
            esr = int(self.vi.ask('*ESR?'))
            if esr:
                break
                
        # get the frequency list
        flist = self.vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?'%self.chan)
        n = len(flist)
        
        # get the measured parameters
        result = []
        for m in measurements:
            self.vi.write("CALC%d:PAR:SEL '%s'"%(self.chan,m))
            r = self.vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA'%self.chan)
            lr = len(r)
            if lr == n:
                # real data
                r2 = r            
            elif lr == 2*n:
                # complex data
                r2 = []
                for i in range(n):
                    r2.append(complex(r[2*i],r[2*i+1]))
            else:
                raise Exception("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (mname,n,len(r)))
                
            result.append(r2)
        
        # return results
        return flist, result

    def close(self):
        "close instrument"
        self.vi.write('SENS%d:SWE:MODE CONT'%self.chan)
        self.vi.close()
        self.vi = None
    
    
def test_site( pna, b1, b2, b3, sitename, suffix ):
    "entry point"
    
    print "++++++ %s ++++++"%sitename
    # init bias
    b1.config(mode='I',iset=0.0,vlimit=5.0,state=1)
    b2.config(mode='I',iset=0.0,vlimit=5.0,state=1)
    b3.config(mode='I',iset=0.0,vlimit=5.0,state=1)    
    
    for testname,p1,p2,i1,i2,i3 in TESTS:
        print "  ", testname
        
        # set up the bias condition
        b1.config(iset=i1*0.001)
        b2.config(iset=i2*0.001)
        b3.config(iset=i3*0.001)
        
        # wait for settling
        timed_wait_ms(100)
        
        # measure voltages
        v1 = b1.measure()
        v2 = b2.measure()
        v3 = b3.measure()
        
        # measure S-parameters
        flist, params = pna.read_sparams([p1,p2])
        
        # write the data file
        fname = '%s_%s%s.s2p'%(sitename,testname,suffix)
        ts = Touchstone()
        ts.header = '! Site: %s\n! Test name: "%s"\n! Bias 1: I = %.1f mA ; V = %.3f V\n! Bias 2: I = %.1f mA ; V = %.3f V\n! Bias 3: I = %.1f mA ; V = %.3f V\n!\n'%(sitename,testname,i1,v1,i2,v2,i3,v3)
        ts.format = '# s hz ma r 50'
        for i,f in enumerate(flist):
            ts.insert(f,[params[0][i],params[1][i],params[2][i],params[3][i]])
        ts.write(fname)
    
    # turn off bias
    b1.config(state=0)
    b2.config(state=0)
    b3.config(state=0)    

def test_wafer( multi, start_idx=0, suffix='' ):
    "test the wafer"
    
    # load the instruments
    pna = PNAX_sp('GPIB::16')
    b1 = instrument.create('bias','b2902','GPIB::22',chan=1)
    b2 = instrument.create('bias','b2902','GPIB::22',chan=2)
    b3 = instrument.create('bias','b2902','GPIB::23',chan=1)
    
    # start multisite
    multi.init_multisite(start_idx,'12k','GPIB::28')
    try:
        try:
            while True:
                test_site(pna,b1,b2,b3,multi.current_name,suffix)
                multi.next_site()
        except StopIteration:
            pass
    finally:
        pna.close()
        b1.close()
        b2.close()
        b3.close()
    
def main():
    "entry point"
    
    # get map file name
    mapname = 'wafer.map'
    r = raw_input('Wafer map file? [%s] > '%mapname).strip()
    if len(r):
        mapname = r
    
    # create the multisite object
    multi = Multisite()
    multi.read_map(mapname)
    
    # get starting site name
    start_idx = 0
    r = raw_input('Starting site? [%s] > '%multi.get_site_name(start_idx)).strip()
    if len(r):
        start_idx = multi.get_site_index(r)

    # get data file suffix
    suffix = ''
    r = raw_input('Filename suffix? [%s] > '%suffix).strip()
    if len(r):
        if r[0] not in ('-','_'):
            r = '_'+r
        suffix = r
        
    # run the test
    test_wafer(multi,start_idx,suffix)
        
if __name__ == '__main__':
    main()
    
    
