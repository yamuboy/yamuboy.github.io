import visa
import time
import datetime
from instrument.manager import InstrumentManager
from instrument.utils import timed_wait_ms
import instrument
import os

DEFAULT_CONFIGFILE = 'power_config.cfg'

def main(cfgfname=DEFAULT_CONFIGFILE,fname=''):
    cfg = _default_config()
    try:
        data = {'arange':arange} 
        execfile(cfgfname,data)
        del data['__builtins__']
        del data['arange']
        cfg.update(data)
        print "read config options from: '%s'" %cfgfname
#        print "read config options from: ", cfgfname
    except Exception:
        if cfgfname == DEFAULT_CONFIGFILE:
            print "no config file, using default options"
        else:
            raise
    
    
    filename= raw_input('Enter the filename for the test:\n')
    if os.path.exists(filename):
        print "Warning: file '%s' exists." % filename
        if raw_input("Overwrite the existing file? (y/N): ").strip().lower()[0] != 'y': 
            print "Exiting."
            return
   
    if raw_input('Turning on power supplies now (y/n)! ').strip().lower()[0] != 'y':
        return

    run_test(filename, cfg)
    
def arange(start,stop,step=1.0):
    "compute a range of values returned as a list"    
    if start == stop:
        return [start]
        
    if start > stop and step > 0.0:
        raise ValueError("'start' > 'stop' with 'step' > 0.0 is not possible")    
    elif start < stop and step < 0.0:
        raise ValueError("'start' < 'stop' with 'step' < 0.0 is not possible")
    
    if step == 0.0:
        raise ValueError("'step' cannot be 0.0")
    
    v = start
    ret = []
    while v < stop:
        ret.append(v)
        v += step
    
    return ret
    
def _default_config():
    "default configuration"
    
    cfg = {}
    cfg['compression_limit'] = 3.0
    cfg['gate_current_limit'] = 0.05
    cfg['drain_current_limit'] = 0.2
    cfg['start_power'] = -5.0
    cfg['stop_power'] = 19.0 
    cfg['power_step'] = 1.0
    cfg['gate_voltage'] = -2.465
    cfg['drain_voltage'] = 50.0
    cfg['ids_range_ma'] = 1
    
    cfg['vna_address'] = 'TCPIP0::10.99.3.124::inst0::INSTR'
    cfg['gate_address'] = ('b2902','TCPIP0::192.168.1.10::instr',{'chan':1,'remote':True,'resolution':'high'})
    cfg['drain_address'] = ['N6700','TCPIP0::192.168.1.4::instr',{'chan':2,'remote':True,'resolution':'high'}]
    cfg['dmm_address'] = ['34460A','GPIB::22::instr']
        
    return cfg


def run_test(filename, cfg):
    "main routine of test"
        
    # open instruments
    vna= visa.instrument(cfg['vna_address'],values_format=visa.double)
    
    gate = instrument.create('bias',*(cfg['gate_address'][:2]),**(cfg['gate_address'][2]))
    drain = instrument.create('bias',*(cfg['drain_address'][:2]),**(cfg['drain_address'][2]))
    drain_dmm = instrument.create('dmm',cfg['dmm_address'][0],cfg['dmm_address'][1])
    drain_dmm.config(mode='i',resolution='low')
    
    # get the compression, gate, and drain current limits
    comp_limit = cfg['compression_limit']
    gate_limit = cfg['gate_current_limit']
    drain_limit = cfg['drain_current_limit']

    points= int((cfg['stop_power']-cfg['start_power'])/cfg['power_step'] + 1.0) 

    # open the output file and write the header
    f= open(filename, 'w+')
    t = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
#    f.write("!Downpoint Test \t%s\n"%(t))
    f.write("!Downpoint Test %s\n"%(t))
    f.write("!Start Power: %.3f\n"%cfg['start_power'])
    f.write("!Stop Power: %.3f\n"%cfg['stop_power'])
    f.write("!Power Step: %.3f\n"%cfg['power_step'])
    f.write("!Num Points: %d\n"%points)
    f.write(filename)
    f.write("\n")
    f.write("!Pin\tPout\tGain\tV_out\tI_out\tV_in\tI_in\n")

    # Set the start and stop pin and pout powers to zero
    # This program assumes that the VNA is already configured to measure Pin on Ch1 and Pout on Ch2
    # and that a power cal has been performed.
    gate.config(mode= 'v',vset=cfg['gate_voltage'],ilimit=gate_limit,state=1)
    timed_wait_ms(50)
    kw = {}
    imrange = cfg['ids_range_ma']
    if imrange:
        kw['imrange'] = imrange*0.001
    drain.config(mode = 'v', vset=cfg['drain_voltage'],ilimit=drain_limit,state=1)
    
    # Setting up the sweep mode to be a point by point sweep
    vna.write('SENS:SWE:MODE HOLD')
    vna.write('SENS:SWE:TRIG:POIN ON')
    #vna.write('SENS:SWE:POIN %d'%points)
    vna.write('TRIG:SOUR MAN')
    vna.write('TRIG:SCOP CURRENT')
    
    # This script assumes that the VNA is set up to the state which has the following measurements
    # Trace 1, R1/1 ; Trace 3 B/1 ; Trace 4 B/R1
    # Trace 1 is Pin, Trace 3 is pout
    # This is the trace catalaog: CH1_R1_P1_1,R1,1,CH1_R1_P1_2,S21,CH1_B_P1_3,B,1,CH1_B/R1_P1_4,B/R1,1
    # NEVER ASSUME THAT THE INSTRUMENT IS SET UP A CERTAIN WAY!!!! -J.B.
    # instead do it this way:
    
    # find the correct measurements in the catalog
    instr_cat = vna.ask('CALC:PAR:CAT:EXT?').strip('"\'').split(',')
    pout_meas = None
    pin_meas = None
    for i in range(0,len(instr_cat),2):
        # print "p_in = ", pin_meas    #FG
        name = instr_cat[i]
        if not pin_meas and name.find('_R1_P1_') > -1:
            pin_meas = name
        elif not pout_meas and name.find('_B_P1_') > -1:
            pout_meas = name
    
    if not pout_meas:
        raise ValueError("could not locate an output power trace in the PNA measurement catalog")
    if not pin_meas:
        raise ValueError("could not locate an input power trace in the PNA measurement catalog")
    
    timed_wait_ms(500)
    try:
        time.sleep(0.05)
                        
        gate_v=[]
        drain_v=[]
        gate_curr=[]
        drain_curr=[]
        
        vna.write('SOUR:POW1:PORT:STAR %.3f'%cfg['start_power'])
        vna.write('SOUR:POW1:PORT:STOP %.3f'%cfg['stop_power'])        
        vna.write('OUTP ON')
              
        # set up vna hold function
        npts = int(vna.ask('SENS:SWE:POIN?'))
        for i in range(npts):
            # read supplies
            
            timed_wait_ms(400)
            gate_curr.append(gate.measure())
            drain_curr.append(drain_dmm.measure())
            gate_v.append(cfg['gate_voltage'])
            drain_v.append(cfg['drain_voltage'])
            
            # trigger VNA measurement
            vna.write('INIT:IMM')
            #vna.ask('*OPC?')
            
            # FIX THIS LATER, IT'S WRONG
            # vna.write('CALC:PAR:SEL "%s"'%(meas_jb[1][0]))
            # p_out = vna.ask_for_values("CALC:RDATA? B")
            # print p_out
            # valid_pout = p_out[1:i+2]
            # vna.write('CALC:PAR:SEL "%s"'%(meas_jb[0][0]))
            # p_in = vna.ask_for_values("CALC:RDATA? REF")
            # print "p_in = ", p_in[i]    # FG
            # valid_pin = p_in[1:i+2]
            
            # calculate gains
            # gain0 = valid_pout[0] - valid_pin[0]
            # gain = valid_pout[-1] - valid_pin[-1]

            # Add some DUT protection
            if gate.limiting or drain.limiting: # or (gain0-gain >= comp_limit):
                break

            # write data to the file
             
        vna.write('CALC:PAR:SEL "%s"'%pout_meas)
        p_out = vna.ask_for_values(":FORM:DATA REAL,64;:FORM:BORD SWAP;:CALC:DATA? FDATA")

        if len(p_out) > npts:
            print "Warning: p_out array is too long, truncating ..."
            p_out = p_out[-npts:]
        vna.write('CALC:PAR:SEL "%s"'%pin_meas)
        p_in = vna.ask_for_values(":FORM:DATA REAL,64;:FORM:BORD SWAP;:CALC:DATA? FDATA")
        if len(p_in) > npts:
            print "Warning: p_in array is too long, truncating ..."
            p_in = p_in[-npts:]
        # print "p_in = ", p_in[i]    # FG

        for i in range(len(p_in)):
            # print "p_in = ", p_in[i]    # FG
            f.write("%.4f\t%.4f\t%.4f\t%.3e\t%.3e\t%.3e\t%.3e\n"%(p_in[i],p_out[i],p_out[i]-p_in[i],drain_v[i],drain_curr[i],gate_v[i],gate_curr[i]))
            f.flush()
        
    finally:
        vna.write('SENS:SWE:TRIG:POIN OFF')
        vna.write('TRIG:SCOP ALL')
        vna.write('TRIG:SOUR IMM')
    
        f.close()
        vna.close()
        gate.set_state(0)
        drain.set_state(0)
        gate.close()
        drain.close()
        drain_dmm.close()


if __name__ == '__main__':
    import optparse, sys
    p = optparse.OptionParser(usage='USAGE: %prog [-c CONFIGFILE] [OUTFILE]')
    p.add_option('-c','--cfg',metavar='FILE',dest='cfg',help='config file path')
    
    opts, args = p.parse_args()
    kw = {}
    if opts.cfg:
        kw['cfgfname'] = opts.cfg
    
    if len(args) == 1:
        kw['fname'] = args[0]
    elif len(args) > 1:
        p.print_usage()
        sys.exit(1)        
    
    main(**kw)
