from maplot.batch_setup import *

from maplot.axes import IVCurveAxes
from modeling.fet.ivdata import IVData

def main(room_fname, cold_fname, hot_fname, out_fname):
    
    data_25 = IVData(fname=room_fname)
    data_m40 = IVData(fname=cold_fname)
    data_85 = IVData(fname=hot_fname)
    
    fig = create_figure()
    ax = IVCurveAxes(fig,[0.15,0.1,0.7,0.65])
    fig.add_axes(ax)
    l25 = ax.plot(data_25,'g-')
    lm40 = ax.plot(data_m40,'b-')
    l85 = ax.plot(data_85,'r-')
    ax.set_xlabel('Vds (V)')
    ax.set_ylabel('Ids (A)')
    ax.set_ylim(ymin=0.0)
    
    lines = [l25[0],lm40[0],l85[0]]
    fig.legend(lines, ['+25C','-40C','+85C'], 'upper right')
    fig.savefig(out_fname)


if __name__ == '__main__':
    main('std_iv_r.iv','std_iv_c.iv','std_iv_h.iv','1571_2x100_std_iv.png')
    main('ckt_iv_r.iv','ckt_iv_c.iv','ckt_iv_h.iv','1571_2x100_ckt_iv.png')

