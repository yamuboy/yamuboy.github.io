from maplot.batch_setup import *

from maplot.axes import IVCurveAxes
from modeling.fet.ivdata import IVData

def main():
    
    data = IVData(fname='ckt_iv_c.iv')
    
    fig = create_figure()
    ax = IVCurveAxes(fig,[0.15,0.1,0.7,0.7])
    fig.add_axes(ax)
    line = ax.plot(data,'b-')
    ax.set_xlabel('Vds (V)')
    ax.set_ylabel('Ids (A)')
    ax.set_ylim(ymin=0.0)
    
    fig.legend([line[0]], ['-40C 2x100 CKT'], 'upper right')
    fig.savefig('ckt_cold_iv.png')


if __name__ == '__main__':
    main()
