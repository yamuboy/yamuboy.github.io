from maplot.batch_setup import *

from maplot.axes import IVCurveAxes
from modeling.fet.ivdata import IVData

def main(fname):
    
    data = IVData(fname=fname)
    
    fig = create_figure()
    ax = IVCurveAxes(fig,[0.2,0.2,0.6,0.5])
    fig.add_axes(ax)
    ax.plot(data,'r-')
    ax.set_xlabel('Vds (V)')
    ax.set_ylabel('Ids (A)')
    
    fig.savefig('ivout.png')


if __name__ == '__main__':
    main('sdc.iv')
