from gdsii_parse import *

inc = 0

def cb(context, libname, sname, rec):
    "callback"
    global inc
    #if inc > 200:
    #    return
        
    ind = context
    rt = rec.record_type
    if rt in (RT_ENDEL,RT_ENDSTR,RT_ENDLIB):
        return
    elif rt in (RT_BGNLIB,RT_BGNSTR,RT_BOUNDARY,RT_PATH,RT_SREF,RT_AREF,RT_TEXT,RT_NODE,RT_BOX):
        ind -= 1
        
    indent = '    '*ind
    print "%s%s"%(indent,rec)
    inc += 1


f = open('test_gds.gds','rb')
p = GDSII_Parser(f)
p.parse(cb,store_records=True)
f.close()

print len(p.all_records)

raw_input('press enter')




