import gdsii_parse

fp = open('input.gds','rb')
p = gdsii_parse.GDSII_Layer_Strip(fp)
p.run('output.gds',lylist=[27,31,32,33,37])
fp.close()

print p.stats