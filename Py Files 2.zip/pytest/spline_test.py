
import numpy as np
from modeling import splines
import matplotlib.pyplot as plt
from matplotlib.figure import Figure

if __name__ == '__main__':
    
    x = np.arange(0,2*np.pi+0.0001,0.125*np.pi)
    x2 = np.arange(0,2*np.pi+0.0001,0.01*np.pi)
    
    y = np.sinc(x)
    y2 = np.sinc(x2)
    
    # calculate the spline interpolated curve
    spl = splines.natural_cubic_spline(x,y)
    
    yspl= []
    for xv in x2:
        yspl.append( splines.cubic_spline_solve(spl,xv) )
    
    fig = plt.figure()
    ax = fig.add_axes( [0.1,0.1,0.8,0.8] )
    ax.plot( x2, y2, 'r-', x2, yspl, 'b-' )
    
    plt.show()
    
