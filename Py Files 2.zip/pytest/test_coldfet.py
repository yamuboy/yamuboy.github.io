from modeling.fet.coldfet import coldfet


def main():
    
    kwargs = dict()
    
    # frequency list
    kwargs['specify_freq_list'] = True
    kwargs['min_freq_ghz'] = 2.0
    kwargs['max_freq_ghz'] = 15.5
    kwargs['freq_step_ghz'] = 0.5
    
    ## deembedding related parameters
    #kwargs['deembedding_fixture1'] = 'inp.s2p'
    #kwargs['deembedding_fixture2'] = 'inp.s2p'
    
    ## cold-FET extraction parameters
    kwargs['coldfet_rfreq_ghz'] = 2.5
    kwargs['coldfet_min_lfreq_ghz'] = 10.0
    kwargs['coldfet_max_lfreq_ghz'] = 1000.0
    kwargs['coldfet_min_cfreq_ghz'] = 0.0
    kwargs['coldfet_max_cfreq_ghz'] = 5.0
    
    res = coldfet( ('s000c021.dmb','s000c041.dmb','s000c060.dmb','s000c081.dmb','s000c101.dmb'), 's000m463.dmb', **kwargs )
    print res
    
if __name__ == '__main__':
    main()
    
    
    