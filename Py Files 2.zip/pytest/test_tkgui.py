from maplot import NoMorePages
from maplot.tkgui import TkPlotRoot
from maplot.figures import TestFigure
from matplotlib.figure import Figure

if __name__ == '__main__':
    root = TkPlotRoot(TestFigure())
    root.mainloop()
    