
from modeling.optimize.engine import BasicEngine
from modeling.optimize.worker import GradientWorker, SimultGradientWorker
from modeling.optimize.param import OptimizableParam
from modeling.model import Model
import math
import numpy as np
import logging

class TestProblem(Model):
    
    def __init__(self):
        
        p = (
            OptimizableParam('a',1.0,optrange=(0.0,2.0)),
            OptimizableParam('b',-0.5,optrange=(-1.5,3.5)),
            OptimizableParam('c',4.0,optrange=(0.0,10.0)),
            OptimizableParam('d',0.2,optrange=(-1.0,1.0)),
            )
        
        Model.__init__(self,params=p)
    
    def compute_err(self):
        
        e = 0.0
        for x in np.arange(0.0,10.05,0.5):
            ycomp = 0.75*math.exp( 2.2*math.cos(12.4*x) - 1.5*math.sin(4.73*x) - 0.13 )
            ymod = self['a'].v * math.exp( self['b'].v*math.cos(12.4*x) - 1.5*math.sin(self['c'].v*x) + self['d'].v )
            f = ycomp-ymod
            e += f*f
        
        return e
        
    def itercb(self, n, e):
        print "%-5d: %s" % (n,e)



def main():
    
    logging.basicConfig(level=logging.WARNING)
    
    prob = TestProblem()
    w = GradientWorker( prob.compute_err, prob.get_named_params(None) )
    engine = BasicEngine( worker=w, iter=200, itercb=prob.itercb )
    
    engine.optimize()
    
    print "Final Error:", engine.error
    
    for k,v in prob.params.iteritems():
        print k, "=", v.v
        
    
    
if __name__ == '__main__':
    main()