
from modeling.fet.ivdata import IVData


def main():
    
    d = IVData(fname='sdc.iv')
    d2 = d.filter(vgsrange=(-0.6,0.2), vdsrange=(0.7,2.7))
    print d2
    
    
if __name__ == '__main__':
    main()