#!/usr/bin/env python
import os
from datetime import datetime
import math
import time

import visa

### instrument configuration ###
instrcfg = {
        'vbaddr': 'GPIB::21',   # gate 1 bias address
        'vbtype': 'k23x',       # gate 1 bias instrument type
        'vcaddr': 'GPIB::23',   # gate 2 bias address
        'vctype': 'k23x',       # gate 2 bias instrument type
    }

### test configuration ###
testcfg = {
        'ibinit': 0.0,         # be initial bias voltage
        'vcinit': 1.0,          # ce initial bias voltage
        'vblimit': 1.7,     # be voltage limit
        'iclimit': 30.0e-3,    # ce current limit
        'icinitmax': 100.0e-3,    # ce initial bias max value (check for short circuit)
        'ibctep': 4e-6,        #be coarse step size
        'ibfstep': 1e-6,        # be fine step size
    }

### bias configurations for S-parameter measurements ###
sparams_bias = (
        #(ib1init,vbmax,vd1,id1target),
        (0,1.7, 1.0,1.8e-3),
        (0,1.7, 2.0,1.8e-3),
        (0,1.7, 3.0,1.8e-3),
        (0,1.7, 4.0,1.8e-3),
    )


def main():
    """Main entry point."""
    try:
        while True:
            # ask for the site name
            temp = raw_input("Enter a Temp (Ctrl-C to quit)> ").strip()
            if len(temp):
                run_rth(temp)
    except (KeyboardInterrupt,EOFError):
        print
        print "Goodbye."
    
def run_rth( temp ):
    """Run the test for 1 site."""
    
    # create a file name
    fname = "rth_%s.dat" %temp 
    
    # open the output file and write a header
    f = open(fname,'w')
    f.write('!WORKING DIR: %s\n!Temp: %s\n!TIMESTAMP: %s\n!\n' % (os.getcwd(),temp,datetime.now().strftime('%m/%d/%y %H:%M:%S')) )
    
    ### Step 1 - open instruments ###
    print "Opening instruments ..."
    bb = _open_bias( instrcfg['vbaddr'], instrcfg['vbtype'] )
    bc = _open_bias( instrcfg['vcaddr'], instrcfg['vctype'] )
    allinstr = (bb,bc)
    
    ### Step 2 - set initial gate and drain biases ###
    print "Setting initial bias ..."
    bb.set_i( testcfg['ibinit'], testcfg['vblimit'] )
    bc.set_v( testcfg['vcinit'], testcfg['iclimit'] )
    
    bb.on()
    wait_ms(100)
    bc.on()
    wait_ms(1000)
    vb = bb.read_v()
    ic = bc.read_i()
    
    ### Step 3 - check for shorted/leaky biases and then ###
    try:
        # check for compliance
        if ic > testcfg['icinitmax']:
            raise RuntimeError("CE appears to be shorted.")
        if vb > testcfg['vblimit']:
            raise RuntimeError("BE appears to open.")
        
        # start the Rth loop
        for i,d in enumerate(sparams_bias):
            # run the S-param measurement for each configured bias
            rth_meas( bb, bc, verify, *d )
    except Exception, e:
        f.write("! FAILED: %s\n" % e)
        print e
    finally:
        f.close()
        bc.close()
        wait_ms(100)
        bb.close()
        

def rth_meas( bb, bc, verify, ibi, vbmax, vc, ictgt ):
    """Bias up the part and take a set of S-params."""
    
    # set initial gate bias
    ib = ibi
    bb.set_i( ibi, testcfg['vblimit'] )
    wait_ms(100)
    # set drain voltage bias
    bc.set_v( vc, testcfg['iclimit'] )
    # measure initial current
    wait_ms(100)
    ic = bc.read_i()
    
    if ic > testcfg['icinitmax']:
        raise RuntimeError("Collector appears to be shorted.")
    
    # start the loop to find the target bias point
    ss1 = testcfg['ibcstep']
    while (ic < ictgt and abs(ic-ictgt) > 0.05*ictgt):
        if ic < ictgt or abs(ic-ictgt) > 0.05*ictgt:
            if ic > 0.5*ictgt:
                # switch use the fine step for vg1
                ss1 = testcfg['ibfstep']
            ib += ss1
            if vb > vbmax:
                raise RuntimeError("Base exceeded max setting.")
            bb.set_i( ib, testcfg['vblimit'] )
        # read currents
        wait_ms(100)
        ic = bc.read_i()
    
    vcm = bc.read_v()
    # bias targetted
    # print bias info to file
    fp.write('! **** BIAS ****\n! Vbe = %.3e Ibe= %.3e Vce = %.3f Ice= %.4e\n'%(vb,
       ib,  vcm,ic))
    
    # wait for amp to settle
    wait_ms(500)

    # set vb back to initial values
    bb.set_i( ibi, testcfg['vblimit'] )

def wait_ms( ms ):
    """Wait for ms milliseconds."""
    time.sleep( ms*0.001 )

def _open_bias( addr, style ):
    """Open a bias object given the address and style of bias."""
    
    if style.find(':') > -1:
        st, chan = style.split(':')
        chan = int(chan)
    else:
        st, chan = style, 0
    
    if st.lower() == 'hp662x':
        return HP662x( visa.instrument(addr), chan )
    elif st.lower() == 'k23x':
        return Keithley( visa.instrument(addr) )
    else:
        raise ValueError("Unsupported instrument style '%s'"%st)
    
class Keithley(object):
    """Control a Keithley 236/237/238 SMU."""
    
    def __init__(self, vi):
        """Initialize the keithley and set up a few things."""
        self.__vi = vi
        self.__vi.write('J0X')
        self.__vi.write('G4,0,0S2P3O1X')
        self.__iset = 0.0
        
    def on(self):
        """Turn on."""
        self.__vi.write('N1X')
        
    def off(self):
        """Turn off."""
        self.__vi.write('N0X')
        
    def set_i(self, val, vlimit):
        """Set the output voltage."""
        self.__iset = val
        self.__vi.write('L%.4e,0B%.4e,0,0X' %(vlimit,val))
        
    def read_i(self):
        """Read current."""
        return self.__iset

    def read_v(self):
        """Read the output voltage."""
        self.__vi.write('R0XF1,1,0,0R1XH0X')
        wait_ms(10)
        s = self.__vi.read()
        self.__vi.write('R0XF1,0,0,0R1XH0X')
        return float(s[5:].split(',')[1][5:]
        
        
    def close(self):
        self.off()
        self.__vi.close()
    
class HP662x(object):
    """Control an HP 662X power supply."""
    
    def __init__(self, vi, chan):
        
        if not isinstance(chan,int) or chan < 1:
            raise ValueError("Invalid channel.")
        
        self.__vi = vi
        self.__chan = chan
        self.__vi.write('CLR')

        # set ranges
        irange = 2.0
        if chan == 1:
            irange = 0.5
        self.__vi.write('IRSET %d, %.1f'%(chan,irange))
        
    def on(self):
        """Turn on."""
        self.__vi.write('OUT %d, 1'%self.__chan)
        
    def off(self):
        """Turn off."""
        self.__vi.write('OUT %d, 0'%self.__chan)
        
    def set_v(self, val, ilimit):
        """Set output voltage."""
        self.__vi.write('ISET %d, %.4e'%(self.__chan,ilimit))
        self.__vi.write('VSET %d, %.4e'%(self.__chan,val))
        
    def read_i(self):
        """Read output current."""
        s = self.__vi.ask('IOUT? %d' % self.__chan)
        return float(s)
        
    def read_v(self):
        """Read output voltage."""
        s = self.__vi.ask('VOUT? %d' % self.__chan)
        return float(s)
        
    def close(self):
        self.off()
        self.__vi.close()
        
        
class PNA(object):
    """Control a PNA."""
    
    def __init__(self, vi, chan):
        """Init instrument."""
        
        if not isinstance(chan,int) or chan < 1:
            raise ValueError("Invalid channel.")
        
        self.__vi = vi
        self.__chan = chan
        
        # set the VNA in hold mode
        self.__vi.write('SENS%d:SWE:MODE HOLD' % self.__chan)
        
    def write_sparams(self, fp):
        """Write S-params to a file."""
        
        def ang( c ):
            return math.atan2(c.imag,c.real) * 180.0 / math.pi
        
        params = ('S11','S21','S12','S22')
        chan = self.__chan
    
        # initial setup
        self.__vi.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
        # get the measurement catalog
        catalog = self.__vi.ask('CALC%d:PAR:CAT?' % chan)
        # create measurements as needed
        for p in params:
            measdef = "tawtest_ch%d_%s" % (chan,p)
            if catalog.find(measdef) == -1:
                self.__vi.write("CALC%d:PAR:DEF '%s',%s" % (chan,measdef,p))
        
        # detect averaging state
        avg = int(self.__vi.ask('SENS%d:AVER:STAT?' % chan))
        if avg:
            count = int(self.__vi.ask('SENS%d:AVER:COUN?' % chan))
            # restart averaging
            self.__vi.write('SENS%d:AVER:CLEAR' % chan)
        else:
            count = 1
        
        # set the group count to be equal to the averaging
        self.__vi.write('SENS%d:SWE:GRO:COUN %d' % (chan,count))
        # trigger a measurment group
        #  and wait for the measurement to finish
        self.__vi.ask('SENS%d:SWE:MODE GRO;*OPC?' % chan)
        
        
        # get the frequency list
        flist = self.__vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?' % chan)
        n = len(flist)
        
        # get the S-parameters
        result = []
        for p in params:
            self.__vi.write("CALC%d:PAR:SEL 'tawtest_ch%d_%s'" % (chan,chan,p))
            r = self.__vi.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA' % chan)
            # combine the interlaced real/imag pairs into complex numbers
            if len(r) != n*2:
                raise RuntimeError("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (p,n,len(r)))
            r2 = []
            for i in range(n):
                cnum = complex(r[2*i],r[2*i+1])
                r2.append(cnum)
            result.append(r2)
        
        # write the S-parameters to the data file
        fp.write("# HZ S MA R 50\n")
        fp.write("!Freq\tS11-mag\tS11-ang\tS21-mag\tS21-ang\tS12-mag\tS12-ang\tS22-mag\tS22-ang\n")
        for i in range(n):
            fp.write("%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\n"%(flist[i],abs(result[0][i]),ang(result[0][i]),
                abs(result[1][i]),ang(result[1][i]),abs(result[2][i]),ang(result[2][i]),abs(result[3][i]),ang(result[3][i])))
        
        
        return flist,result[0],result[1],result[2],result[3]

    def close(self):
        # set free-run mode and close vi
        self.__vi.write('SENS%d:SWE:MODE CONT' % self.__chan)
        self.__vi.close()


if __name__ == '__main__':
    main()
    
