from network_params import *

def main():
    
    ts = Touchstone()
    ts.read('test.s2p')
    orig = ts.param_type
    
    print ts.data[0]
    
    print "Original type: %s" % orig
    print "%s -> t" % orig
    ts.convert('t')
    
    print "t -> abcd"
    ts.convert('a')
    
    print "abcd -> h"
    ts.convert('h')
    
    print "h -> g"
    ts.convert('g')
    
    print "g -> z"
    ts.convert('z')
    
    print "z -> y"
    ts.convert('y')
    
    print "y -> %s" % orig
    ts.convert(orig)
    
    print ts.data[0]
    

if __name__ == '__main__':
    main()