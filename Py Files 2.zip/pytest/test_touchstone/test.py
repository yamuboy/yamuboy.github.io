import network_params as parms

def main():
    
    ts = parms.Touchstone()
    
    # read/write test
    print "Reading 'test.s7p'"
    ts.read('test.s7p')
    
    print "Writing 'output.s7p'"
    ts.write('output.s7p')
    
    # try extracting some data
    print "Trying to extract data at 7.5 GHz."
    print "Got frequency:", ts.extract(7.5e9).freq
    
    print "Trying to extract data at 7.75 GHz."
    print "Got frequency:", ts.extract(7.75e9).freq
    
    print "Trying to extract data at 20 GHz."
    print "Got frequency:", ts.extract(20.0e9).freq
    
    # try extracting some data outside of the prescribed range
    try:
        print "Trying to extract data (outside of the file range) at 20.05 GHz."
        ts.extract(20.05e9).freq
    except Exception, e:
        print "Got an exception (as expected):", e
    
    # try reading a badly formatted file
    try:
        print "Trying to read a badly formatted file."
        ts.read('test_bad.s7p')
    except Exception, e:
        print "Got an exception (as expected):", e
    
    print 'Done'

if __name__ == '__main__':
    main()
    
