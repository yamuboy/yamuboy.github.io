import tuner_file


        
if __name__ == '__main__':
    # read a tuner file
    tf = tuner_file.TunerFile()
    tf.read_file('test.tun')
    
    print 'finding complex(0.5,0.5)...'
    print '     ', tf.find_nearest_position( complex(0.5,0.5) ).position
    
    print 'finding complex(0.9,0.0)...'
    print '     ', tf.find_nearest_position( complex(0.9,0.0) ).position
    
    print 'finding swapped complex(0.3,0.5)...'
    print '     ', tf.find_nearest_position( complex(0.3,0.5), swapped=True ).position
    
    print 'finding complex(0.5,0.5) with a complex(0.2,-0.1) termination'
    print '     ', tf.find_nearest_position( complex(0.3,0.5), term=complex(0.2,-0.1) ).position



