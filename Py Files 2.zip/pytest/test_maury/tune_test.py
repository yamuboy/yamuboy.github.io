from mt993d import *


def test_program( stand ):
    
    # configure test stand parameters
    # values are controller_serial, tuner0_serial, tuner1_serial
    test_stands = { 1:(5005,1163,1164), 2:(2030,1153,1152) }
    
    print 'Version:', get_tuner_driver_version()
    
    # set up the controller and tuners
    print "Configuring..."
    if stand not in test_stands:
        raise Exception("Invalid test stand.")
    ctrl_serial,tun0_serial,tun1_serial = test_stands[stand]
    
    # add a GPIB board (even though it is not being used)
    #add_gpib_board('PCI-GPIB', 13, 0, 0, 'Gpibw.exe')
    
    # create controller 0
    add_controller(0, 'Tun1020c.exe', 'MT1020C', 15, 0, 0, ctrl_serial)
    
    # create tuners 0 and 1 on ports 1 and 2 of the controller
    add_tuner(0, 'MT982B01', tun0_serial, 0, 1)
    add_tuner(1, 'MT982B01', tun1_serial, 0, 2)
    
    # check the controller
    print "Checking tuner controller..."
    check_tuner_controllers(0)
    
    # try to init the tuners
    print "Initializing tuners..."
    init_tuners()
    
    # try to move the tuners to a point
    target = { 0:(2345,546,5000), 1:(4679,2241,5000) }
    print "Moving tuners (simultaneous)..."
    move_tuners(target)
    
    # check the tuner positions
    print "Verifying tuner positions..."
    pos0 = get_tuner_position(0)
    pos1 = get_tuner_position(1)
    print "Tuner     Requested        Reported"
    print "---------------------------------------------"
    print "Tuner0   ", target[0], pos0
    print "Tuner1   ", target[1], pos1
    
    print "Moving Tuner0..."
    carr = 3586
    p1 = 1025
    p2 = 5000
    move_tuner(0,carr,p1,p2)
    pos0 = get_tuner_position(0)
    print "  ", carr, "<-->", pos0[0]
    print "  ", p1, "<-->", pos0[1]
    print "  ", p2, "<-->", pos0[2]
    
    print "Moving Tuner1..."
    carr = 1895
    p1 = 24
    p2 = 5000
    move_tuner(0,carr,p1,p2)
    pos1 = get_tuner_position(1)
    print "  ", carr, "<-->", pos1[0]
    print "  ", p1, "<-->", pos1[1]
    print "  ", p2, "<-->", pos1[2]
    
    print "Moving tuners to Z0..."
    target = { 0:(100,5000,5000), 1:(100,5000,5000) }
    move_tuners(target)
    
    print "Done."


### Direct load test program ###
if __name__ == '__main__':
    
    # test station 2
    test_program(2)
    
    

