
from modeling.fet.ssdata import FET_SS_Data

def main():
    
    
    data = FET_SS_Data(fname='test.dscr')
    
    # create a data subset
    data2  = data.filter( vdsrange=(2.5,3.1), vgsrange=(-1.0,-0.2) )
    
    # print the subset
    print data2
    
    # print some properties of the internal data
    for d in data2:
        print d.vgs, d.vds, d.cgs
    
    print data2.lg, data2.rd, data2.rs, data2.ld


if __name__ == '__main__':
    main()