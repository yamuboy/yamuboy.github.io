#!/usr/bin/env python

from network_params import Touchstone

def main():


    # read a list of files from the command line
    # and compute ft on them









if __name__ == '__main__':
    main()

