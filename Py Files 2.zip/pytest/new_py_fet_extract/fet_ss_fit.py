import os, sys, os.path
from modeling.fet.extract.ss import SSExtract
from modeling import ConfigData
import logging

VERSION='0.1'
CONFIG_FILE='fetmod.cfg'

def _gen_config_cb(option, opt_str, value, parser, *args, **kwargs):
    "callback for the --gen-config option"
    # this callback generates a default config file and then causes
    # the program to exit immediately
    fname = value
    if not fname:
        fname = CONFIG_FILE
    cfg = ConfigData()
    cfg.write_file(fname)
    sys.exit(0)


def main():
    "entry point for the command-line model fit tool"
    
    # create a command-line option parser
    import optparse
    p = optparse.OptionParser(usage="%prog [options] [s2p_files ...]", version="%prog "+VERSION)
    p.add_option('-c','--config-file',metavar='FILE',dest='config',help="use the configuration file FILE, if this is not specified then a file named '%s' in the current directory will be used"%CONFIG_FILE)
    p.add_option('--gen-config',action='callback',callback=_gen_config_cb,help="write a new configuration file named FILE using all of the default configuration options")
    p.add_option('-q','--quiet',action='store_false',dest='verbose',default=True,help='suppress all output')
    p.add_option('-b','--batch',action='store_true',dest='batch',help='run in batch mode (non-interactive)')
    p.add_option('--yfit',action='store_true',dest='yfit',help='run a Y-fit on all target S-parameter files (batch mode only)')
    p.add_option('--optimize',action='store_true',dest='optimize',help='run an optimization on all target S-parameter files (batch mode only)')
    p.add_option('--coldfet',action='store_true',dest='coldfet',help='run a cold-FET extraction')
    p.add_option('--all',action='store_true',dest='extract_all',help='run all extractions sequentially')
    
    opts,files = p.parse_args()

    if opts.config:
        cfgfname = opts.config
    else:
        cfgfname = CONFIG_FILE

    
    if opts.batch:
        #### batch mode ####
        
        # set up batch-mode logging
        if opts.verbose:
            logging.basicConfig(level=logging.INFO)
    
        
        # load config data
        # this needs to be done prior to creating the extraction object
        cfg = ConfigData()
        try:
            cfg.read_file(cfgfname)
        except Exception, e:
            sys.stderr.write('ERROR: configuration file could not be read. => %s\n'%e)
            sys.exit(1)
        
        docf, doy, doopt = False, False, False
        if opts.extract_all:
            docf, doy, doopt = True, True, True
        else:
            if opts.yfit:
                doy = True
            if opts.optimize:
                doopt = True
            if opts.coldfet:
                docf = True
        
        if not len(files):
            files = None
        else:
            # make sure all files are existing valid data files
            for f in files:
                if not os.path.isfile(f):
                    sys.stderr.write("ERROR: '%s' is not a valid data file\n"%f)
                    sys.exit(1)
        
        ### create the extraction object and run the extractions ###
        xtr = SSExtract()
        if docf:
            xtr.coldfet()
        
        if doy and doopt:
            xtr.yfit_and_optimize(files)
        elif doy:
            xtr.yfit(files)   
        elif doopt:
            xtr.optimize(files)   
    else:
        #### go into interactive mode ####
        interactive_menu(cfgfname)
    
    
    
    
def interactive_menu(cfgfile):
    """interactive mode"""
    
    pass
    
    
    











if __name__ == '__main__':
    main()
