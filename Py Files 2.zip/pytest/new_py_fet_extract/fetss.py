from modeling.fet.extract.ss import SSExtract
from modeling import ConfigData
import logging

#logging.basicConfig(filename='model.log',filemode='w',level=logging.INFO)
logging.basicConfig(level=logging.DEBUG)


# load configuration variables
# this needs to be done prior to creating the extraction object
cfg = ConfigData()
cfg.read_file('modeling_config.txt')

print cfg

cfg.write_file('modeling_config2.txt')


xtr = SSExtract()


# run coldfet
xtr.coldfet()

# run y-fit
#xtr.yfit()
xtr.yfit_and_optimize()

