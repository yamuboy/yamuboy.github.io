from modeling.fet.extract.ssplot import SSPlot
from modeling import ConfigData
import logging

#logging.basicConfig(filename='model.log',filemode='w',level=logging.INFO)
logging.basicConfig(level=logging.DEBUG)

# load configuration variables
# this needs to be done prior to creating the extraction object
cfg = ConfigData()
cfg.read_file('fetmod.cfg')

# generate plots
plt = SSPlot()
plt.report()

