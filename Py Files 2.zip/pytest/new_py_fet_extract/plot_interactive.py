from modeling.fet.extract.ssplot import SSPlot
from modeling import ConfigData
import logging
from maplot import plot_gui

#logging.basicConfig(filename='model.log',filemode='w',level=logging.INFO)
logging.basicConfig(level=logging.INFO,format='%(levelname)s: %(message)s')

# load configuration variables
# this needs to be done prior to creating the plot object
cfg = ConfigData()
cfg.read_file('fetmod.cfg')

# generate the report engine and load all files
rpt = SSPlot()
fig, pager = rpt.interactive()

# start the interactive window
plot_gui(fig,pager=pager)
