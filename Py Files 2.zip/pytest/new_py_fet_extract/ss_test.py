from modeling.fet.extract.ss import SSExtract
from modeling import ConfigData
import logging
from modeling.fet.ssmodel import FET_SS_Model
from modeling.utils import y2s_2port_50ohms
import numpy as np
from network_params import Touchstone


def _read_model(fname):
    "read model data from a file"
    try:
        data = {}
        execfile(fname,data)
        del data['__builtins__']
    except Exception, e:
        self._log.warning("_read_model('%s'): %s"%(fname,e))
        return None
    
    optvals = {}
    pvals = {}
    for k,v in data.iteritems():
        if isinstance(v,tuple):
            if len(v) != 3:
                raise ValueError("_read_model('%s'): format of parameter '%s' is incorrect"%(fname,k))
            pvals[k] = v[0]
            optvals[k] = v[1:]
        else:
            pvals[k] = v
        
    model = FET_SS_Model()
    model.update(pvals)
    for k,v in optvals.iteritems():
        try:
            op = model[k]
            op.set_opt_range(*v)
        except KeyError:
            pass        
    
    return model



#logging.basicConfig(filename='model.log',filemode='w',level=logging.INFO)
logging.basicConfig(level=logging.DEBUG)


# load configuration variables
# this needs to be done prior to creating the extraction object
cfg = ConfigData()
cfg.read_file('modeling_config.txt')

# read a FET model to test
model = _read_model('s030m050.dmb-model')

# compute Y-params and convert to S-params
flist = np.arange(0.5e9,26.1e9,0.5e9)
yp = model.compute_y(flist,True)
sp = y2s_2port_50ohms(yp)

ts = Touchstone()
for i in range(len(flist)):
    ts.insert(flist[i],sp[i])
ts.write('out.s2p')


