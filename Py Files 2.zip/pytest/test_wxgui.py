
import wx
from maplot import NoMorePages
from maplot.wxgui import WxPlotFrame
from maplot.figures import TestFigure

        
if __name__ == '__main__':
    app = wx.PySimpleApp()
    frame = WxPlotFrame(TestFigure(),size=(800,600))
    frame.Show()
    app.MainLoop()
    
    