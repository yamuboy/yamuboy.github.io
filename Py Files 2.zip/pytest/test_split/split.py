from modeling.mct_files import split_cl
split_cl()