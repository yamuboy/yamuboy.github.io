from modeling.trl import trl_cl
import logging

logging.basicConfig(level=logging.DEBUG,format='%(levelname)s: %(message)s')
trl_cl()
