from rpc_plot  import RPC_Plot
import glob

def main():
    flist = glob.glob("*.rpc")
    RPC = RPC_Plot()
    RPC.read_files(flist=flist, f_ghz=10)
    RPC.rect(params = ["nfmin","ga"], versus="ids", outname="rpc_rect.png")
    #RPC.plot_meas_vs_mod()
    RPC.contour(param="nfmin", outname="rpc_cont.png")
            
    
if __name__ == '__main__':
    main()
    
