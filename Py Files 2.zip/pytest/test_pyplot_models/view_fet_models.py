
from maplot.tkgui import PlotRoot
from maplot.figures.sparam_quad import SparamQuadFigure
import numpy as np
from numpy import linalg
from network_params import ParamSet, param_convert, BiasedTouchstone
from optparse import OptionParser
import os
import os.path
import cmath

def _compute_model_sparams( params, flist ):
    """Compute S-params for the passed FET parameters and frequency list
    
    params - a dictionary of FET model parameters
    flist - a sequence of frequecy values in Hz
    
    Returns a ParamSet object
    """
    
    def addy( mat, y, n, m ):
        'add a standard branch component to the Y-matrix'
        mat[n,n] += y
        mat[m,m] += y
        mat[n,m] -= y
        mat[m,n] -= y
        
    # verify that all the parameters exist
    ####
    
    
    ret = ParamSet()
    for f in flist:
        w = 2.0*np.pi*f
        yp = np.zeros( (8,8), dtype=complex)
        
        addy(yp, 1.0/params['rg'], 2, 3)
        addy(yp, 1.0/params['rd'], 6, 7)
        addy(yp, complex(0.,-1.0/(w*params['lg'])), 0, 2)
        addy(yp, complex(0.,-1.0/(w*params['ld'])), 7, 1)
        addy(yp, complex(params['ggs'],w*params['cgs']), 3, 4)
        addy(yp, complex(params['ggd'],w*params['cgd']), 3, 6)
        addy(yp, params['gds']*cmath.exp(complex(0.,-w*params['tau2'])) + complex(0.,w*params['cds']), 5, 6)
        addy(yp, 1.0/params['ri'], 4, 5)
        
        # add components that only connect to one place
        yp[2,2] += complex(0.,w*params['c11'])
        yp[7,7] += complex(0.,w*params['c22'])
        yp[0,0] += complex(0.,w*params['cpg'])
        yp[1,1] += complex(0.,w*params['cpd'])
        den = 1. / (params['rs']*params['rs'] + w*w*params['ls']*params['ls'])
        yp[5,5] += complex(params['rs']*den,-w*params['ls']*den)
        
        # add Gm/Tau
        gm_tau = params['gm'] * cmath.exp( complex(0., -w*params['tau']) )
        yp[6,3] += gm_tau
        yp[6,4] -= gm_tau
        yp[5,3] -= gm_tau
        yp[5,4] += gm_tau
        
        # reduce the Y-matrix by inverting it and then converting the 2x2
        # Z matrix formed from rows/cols 0 and 1 into S-params
        zp = np.matrix(yp).I
        spars = param_convert('z','s', zp[0:2,0:2], 50.0)
        ret.insert(f, spars)
    
    return ret

def _read_param_file( fname ):
    """Read a model param file and return the parameter values as a dictionary."""
    
    pmap = {'GDG':'ggd', 'CDG':'cgd', 'C1':'cpg', 'C2':'cpd', 'B1':'lg', 'B2':'ld', 'TAU1':'tau'}
    parms = dict()
    
    f = open(fname,'r')
    try:
        for line in f:
            d = line.split()
            if len(d) == 5:
                pname = d[4]
                if pname in pmap:
                    name = pmap[pname].lower()
                else:
                    name = pname.lower()
                parms[name] = float(d[1])
    finally:
        f.close()
    
    return parms
    
class FETModelPlot(object):
    """A controller class for plotting measured vs modeled FET S-params.
    
    This class keeps track of the measured and modeled data and sends it to
    the plot figure when requested (i.e. when the page is changed)
    """
    
    def __init__(self, figure, sparam_files, param_ext='.end', **kwargs):
        
        if not isinstance(figure,SparamQuadFigure):
            raise TypeError('The first argument must be a SparamQuadFigure-like object.')
            
        self.__figure = figure
        self.__i = 0
        
        # loop through the list of sparam_files, verify that each file exists
        # verify that the parameter file exists, and add it to the dataset
        self.__dataset = []
        for fname in sparam_files:
            
            if not os.path.exists(fname):
                print "Warning: '%s' is not readable." % fname
                continue
            
            pfname,spext = os.path.splitext(fname)
            pfname += param_ext
            
            if not os.path.exists(pfname):
                print "Warning: '%s' is not readable." % pfname
                continue
            
            self.__dataset.append( { 'sfn':fname, 'pfn':pfname, 'meas':None, 'mod':None } )
        
        if not self.__dataset:
            raise ValueError("Nothing to plot.")
    
    def _draw_page(self, i):
        """Draw the requested page.
        
        This is done by picking the index from the dataset, reading data and
        computing the model if necessary, and then pushing the measured and
        model data to the plot figure.
        """
        # check for out of range
        if i<0: raise StopIteration
        elif i>=len(self.__dataset): raise StopIteration
        
        if not self.__dataset[i]['meas']:
            # read the measured data
            ts = BiasedTouchstone()
            ts.read(self.__dataset[i]['sfn'])
            self.__dataset[i]['meas'] = ts
        
        if not self.__dataset[i]['mod']:
            # read the model parameters and generate modeled data
            parms = _read_param_file(self.__dataset[i]['pfn'])
            self.__dataset[i]['mod'] = _compute_model_sparams(parms,self.__dataset[i]['meas'].flist)
        
        # generate the plots
        self.__figure.plot(self.__dataset[i]['meas'], 'r-', 'b--', linewidth=2)
        self.__figure.addplot(self.__dataset[i]['mod'], 'm-', 'c--', linewidth=2)
        
        # add information about the files to the figure
        #### TODO #####
    
    def goto_page(self, num):
        'Go to the specified page.'
        self._draw_page(num)
        self.__i = num
    
    def prev_page(self):
        'Go to the previous page.'
        self._draw_page(self.__i-1)
        self.__i -= 1
        
    def next_page(self):
        'Go to the next page.'
        self._draw_page(self.__i+1)
        self.__i += 1

def main():
    # parse the command line
    parser = OptionParser()
    parser.add_option('--db', action='store_false', dest='lin_mode', default=True, help='Show magnitude plots in dB.')
    parser.add_option('--no-phase', action='store_false', dest='show_phase', default=True, help='Disable display of the phase axis.')
    
    opts, args = parser.parse_args()
    
    flist = []
    if os.name == 'nt':
        import glob
        for f in args:
            if f.startswith('-'):
                print "Warning: '%s' is an invalid command line option." % f
                continue
            flist.extend(glob.glob(f))
    else:
        for f in args:
            if f.startswith('-'):
                print "Warning: '%s' is an invalid command line option." % f
                continue
            flist.append(f)
    
    if not flist:
        print "Nothing to plot."
    else:
        # create the figure and the plot controller
        fig = SparamQuadFigure(linear_mode=opts.lin_mode,show_phase=opts.show_phase)
        plotter = FETModelPlot(fig,flist)
        
        # create the TK main window and start the main loop
        root = PlotRoot(fig=fig,pager=plotter,debug_mode=True)
        
        # connect the resize_event to the figure's _adjust_plotwin method
        # TkAgg has a bug, so the following doesn't work
        fig.canvas.mpl_connect('resize_event',fig._adjust_plotwin)
        
        # set the window size
        
        
        root.mainloop()
        
if __name__ == '__main__':
    
    # create a set of args for the command line
    import sys
    sys.argv.append( 's050*.dm2' )
    main()
    
    
