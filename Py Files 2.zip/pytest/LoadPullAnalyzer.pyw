﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import wx
import re
import traceback
import numpy as np
import matplotlib.mlab as mlab
import testsoft.plotlib as plotlib


from testsoft.plotlib import _styleLUT
from testsoft.plotlib import _colorLUT
from testsoft.plotlib import _markerLUT
from testsoft.plotlib import LineColor
from testsoft.plotlib import LineStyle
from testsoft.plotlib import MarkerType
from loadpull.ats_parser import maury_ats_parser
from loadpull.focus_parser import focus_lpwave_parser
from testsoft.plotlib import RectAxis
from wx.lib.scrolledpanel import ScrolledPanel
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from cmath import phase
from numpy import pi
from enum import Enum

###############################################################################
# Global Definitions/Enums
###############################################################################
indep_plot_params = ['pin_avail_dbm', 'pout_dbm']
dep_plot_params = ['pin_avail_dbm', 'pin_deliv_dbm', 'refl_db', 'refl_coef', 'pout_dbm', 'gt_db', 'gp_db', 'eff_%']
supported_filetypes =  ("Maury Sweep Plan File (*.spl)|*.spl|" 
                        "Maury Power Sweep File (*.swp)|*.swp|"
                        "Focus Power Sweep Source/Load Pull File (*.lpcwave)|*.lpcwave|"
                        "Focus Power Sweep File (*.satwave)|*.satwave")
marker1Color = LineColor.Orange
marker2Color = LineColor.Purple

###############################################################################
# Global Functions
###############################################################################
def linkGraphControls(graphCanvas, controlPanel):
    """
    Sets two-way references between a graphCanvas and its corresponding controlPanel
    """
    graphCanvas.controlPanel = controlPanel
    controlPanel.graphCanvas = graphCanvas

def showMessageDialog(parent, title, message):
    dlg = wx.MessageDialog(parent, message, caption=title, style=wx.OK)
    dlg.ShowModal()

def complexToRIString(complex):
    """
    Convert a complex number into a real-imaginary string representation.
    
    """
    re, im = round(complex.real,5), round(complex.imag,5)
    return "%f + %fj"%(re, im)

def complexToMAString(complex):
    """
    Convert a complex number into a magnitude-angle string representation.
    
    """
    return u"%.5f \u2220 %.5f\u00b0"%(abs(complex), phase(complex)*180.0/pi)

def RIstringToComplex(string):
    """
    Convert an input string into a complex representation. Assumes that
    the string input is of form "<number> + <number>j", to correctly allow
    for conversion back and forth from the complexToRIString function.
    Rounds resulting complex number to 5 places in R + jX form.
    """
    substring = re.match(r"(.+)( \+ )(.+)(j)", string)
    return round(float(substring.group(1)),5) + round(float(substring.group(3)),5)*1j

def MAstringToComplex(string):
    """
    Convert an input string into a complex representation. Assumes that
    the string input is of form "<number> \u2220 <number>\u00b0", to correctly
    allow for conversion back and forth from the complexToRIString function.
    Rounds resulting complex number to 5 places in R + jX form.
    """
    substring = re.match(ur"(.+)( \u2220 )(.+)(\u00b0)", string)
    complex = plotlib._MA_to_complex(substring.group(1), substring.group(3))
    return round(complex.real,5) + round(complex.imag,5)*1j

###############################################################################
# Container Classes
###############################################################################
class LPAGraphContainer(wx.Notebook):
    controlContainer = None
    dataContainer = None
    graphContainer = None
    
    def __init__(self, *args, **kwargs):
        super(LPAGraphContainer, self).__init__(*args, **kwargs)
        self.initialize()
    
    def initialize(self):
        self.SetBackgroundColour((240, 240, 240))

        self.graphSummary1Panel = LPAGraphSummary1Panel(self)
        self.graphSummary2Panel = LPAGraphSummary2Panel(self)
        self.customGraphPanel = LPAGenericGraphPanel(self)

        self.AddPage(self.graphSummary1Panel, "Graph Summary 1")
        self.AddPage(self.graphSummary2Panel, "Graph Summary 2")
        self.AddPage(self.customGraphPanel, "Custom Graphs")
        
        self.SetSelection(0)

        self.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self.onTabChange)
    
    def onTabChange(self, event=None):
        selectedTab = self.GetPageText(event.GetSelection())
        if selectedTab == "Custom Graphs":
            self.controlContainer.selectPanel("Custom Graphs")
        elif selectedTab == "Graph Summary 1":
            self.controlContainer.selectPanel("Graph Summary 1")
        elif selectedTab == "Graph Summary 2":
            self.controlContainer.selectPanel("Graph Summary 2")
        elif selectedTab in "Table Summary":
            self.controlContainer.selectPanel("Table Summary")
        return

class LPADataContainer(ScrolledPanel):
    controlContainer = None
    graphContainer = None
    dataContainer = None
    
    lpfiles = dict()        # filename : (maury_ats_parser, label, color, style)
    lpfilesUI = dict()      # filename : UI elements
    selectedFilename = ""
    selectedFile = None
    
    def __init__(self, *args, **kwargs):
        super(LPADataContainer, self).__init__(*args, **kwargs)
        
        self.fileListLabel = wx.StaticText(self, wx.ID_ANY, label="Load-Pull File")
        self.fileListBox = wx.ListBox(self, wx.ID_ANY, size=(198,100), style=wx.LB_SINGLE | wx.LB_ALWAYS_SB)
        self.openDataFilesButton = wx.Button(self, wx.ID_ANY, "Open Files...", style=wx.BU_EXACTFIT)
        self.sizer = wx.GridBagSizer(5, 5)
        self.initializeSizer()
        self.initializeBindings()
    
    def initializeSizer(self):
        # detach all children from sizer
        for child in [x.GetWindow() for x in self.sizer.GetChildren()]:
            if child not in [self.fileListLabel, self.fileListBox, self.openDataFilesButton]:
                child.Hide()
                self.sizer.Detach(child)
        
        # if there is a file selected
        if self.selectedFile is not None:
            # add and show the elements for this selected file
            # label, color and style boxes for this file
            selectedFileElements = self.lpfilesUI[self.fileListBox.GetStringSelection()]
            self.sizer.Add(selectedFileElements[0][0], pos=(0,1), span=(1,1), flag=wx.ALIGN_LEFT | wx.ALL)
            self.sizer.Add(selectedFileElements[0][1], pos=(1,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            self.sizer.Add(selectedFileElements[0][2], pos=(2,1), span=(1,1), flag=wx.ALIGN_LEFT | wx.ALL)
            self.sizer.Add(selectedFileElements[0][3], pos=(3,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            self.sizer.Add(selectedFileElements[0][4], pos=(4,1), span=(1,1), flag=wx.ALIGN_LEFT | wx.ALL)
            self.sizer.Add(selectedFileElements[0][5], pos=(5,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            for element in selectedFileElements[0]:
                element.Show()
            
            self.sizer.Add(wx.StaticLine(self, wx.ID_ANY, size=(1,0.9*self.sizer.GetSize()[1]), style=wx.LI_VERTICAL), pos=(0,2), span=(6,1))
            
            # all other variables in this file
            col = 3
            for UIElements in selectedFileElements[1:]:
                self.sizer.Add(UIElements[0], pos=(2, col), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
                self.sizer.Add(UIElements[1], pos=(3, col), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
                UIElements[0].Show()
                UIElements[1].Show()
                col += 1
        else:
            self.sizer.Add(self.fileListLabel, pos=(0,0), span=(1,1), flag = wx.ALIGN_CENTER | wx.ALL)
            self.sizer.Add(self.fileListBox, pos=(1,0), span=(4,1), flag=wx.ALIGN_CENTER | wx.ALL)
            self.sizer.Add(self.openDataFilesButton, pos=(5,0), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        
        self.SetSizer(self.sizer)
        self.Layout()
    
    def initializeBindings(self):
        # unbind all bindings
        self.Unbind(wx.EVT_BUTTON)
        self.Unbind(wx.EVT_LISTBOX)
        self.Unbind(wx.EVT_COMBOBOX)
        self.Unbind(wx.EVT_TEXT_ENTER)
        
        # get the label/color elements corresponding to the currently selected file
        if self.selectedFile is not None:
            currentLabelBox = self.lpfilesUI[self.selectedFilename][0][1]
            currentColorDropDown = self.lpfilesUI[self.selectedFilename][0][3]
            currentStyleDropDown = self.lpfilesUI[self.selectedFilename][0][5]
        
        # initialize bindings
        self.Bind(wx.EVT_BUTTON, self.openDataFiles, self.openDataFilesButton)
        self.Bind(wx.EVT_LISTBOX, self.updateSelectedFile)
        self.Bind(wx.EVT_COMBOBOX, self.updateBlock)
        
        if self.selectedFile is not None:
            self.Bind(wx.EVT_COMBOBOX, self.updateStyle, currentStyleDropDown)
            self.Bind(wx.EVT_COMBOBOX, self.updateColor, currentColorDropDown)
            self.Bind(wx.EVT_TEXT_ENTER, self.updateLabel, currentLabelBox)
            self.updateColor(dropDown=currentColorDropDown)
    
    def createFileUIElement(self, file, index=0):
        """
        Creates and returns the UI elements corresponding to a single load-pull data file
        Returns a list of length n + 1, where n is the number of variables in the load-pull file,
        excluding the power-sweep variable ("Pin_avail").
        
        Elements in this list are tuples; the first element is a 6-tuple that contains the label, 
        color, and style elements for this file, the remaining elements are 2-tuples that contain
        the label and drop-down box corresponding to each variable.
        
        The argument "index" is used to stagger subsequent files' color and style selections, so
        that by default the files do not all have the same color and line style when plotted.
        
        Returns:
        [(label elements, color elements, style elements), (var1 StaticText, var1 ComboBox), (var2, ...), ...]
        """
        UIelements = [ ]
        datasetLabelLabel = wx.StaticText(self, wx.ID_ANY, label="Label")
        datasetLabelLabel.Hide()
        
        datasetLabelBox = wx.TextCtrl(self, wx.ID_ANY, value=file, style=wx.TE_PROCESS_ENTER)
        datasetLabelBox.Hide()
        
        datasetColorLabel = wx.StaticText(self, wx.ID_ANY, label="Color")
        datasetColorLabel.Hide()
        
        datasetColorDropDown = wx.ComboBox(self, wx.ID_ANY, choices=[color.name for color in LineColor])
        datasetColorDropDown.Hide()
        datasetColorDropDown.Select(index%len(LineColor))
        datasetColorDropDown.SetBackgroundColour(_colorLUT(LineColor.LtRed))
        
        datasetStyleLabel = wx.StaticText(self, wx.ID_ANY, label="Style")
        datasetStyleLabel.Hide()
        
        datasetStyleDropDown = wx.ComboBox(self, wx.ID_ANY, choices=[style.name for style in LineStyle])
        datasetStyleDropDown.Hide()
        datasetStyleDropDown.Select(index%len(LineStyle))

        # add label, color and style elements to list
        UIelements.append(( datasetLabelLabel, datasetLabelBox,
                            datasetColorLabel, datasetColorDropDown,
                            datasetStyleLabel, datasetStyleDropDown))
        
        # generate variable UI elements
        varUIElements = [ ]
        for var in self.lpfiles[file][0]._vars:
            if var == "F1 Load Gamma":
                data = [complexToMAString(x._gammal[0]) for x in self.lpfiles[file][0].flat_data]
                
                varLabel = wx.StaticText(self, wx.ID_ANY, label=var)
                varLabel.Hide()
                
                varDropDown = wx.ComboBox(self, wx.ID_ANY, choices=data)
                varDropDown.Insert("Disabled", 0)
                varDropDown.Select(1)
                varDropDown.Hide()

            elif var == "F2 Load Gamma":
                data = [complexToMAString(x._gammal[1]) for x in self.lpfiles[file][0].flat_data]
                
                varLabel = wx.StaticText(self, wx.ID_ANY, label=var)
                varLabel.Hide()
                
                varDropDown = wx.ComboBox(self, wx.ID_ANY, choices=data)
                varDropDown.Insert("Disabled", 0)
                varDropDown.Select(1)
                varDropDown.Hide()

            elif var == "F3 Load Gamma":
                data = [complexToMAString(x._gammal[2]) for x in self.lpfiles[file][0].flat_data]
                
                varLabel = wx.StaticText(self, wx.ID_ANY, label=var)
                varLabel.Hide()
                
                varDropDown = wx.ComboBox(self, wx.ID_ANY, choices=data)
                varDropDown.Insert("Disabled", 0)
                varDropDown.Select(1)
                varDropDown.Hide()
            
            elif var == "F1 Source Gamma":
                data = [complexToMAString(x._gammas[0]) for x in self.lpfiles[file][0].flat_data]
                
                varLabel = wx.StaticText(self, wx.ID_ANY, label=var)
                varLabel.Hide()
                
                varDropDown = wx.ComboBox(self, wx.ID_ANY, choices=data)
                varDropDown.Insert("Disabled", 0)
                varDropDown.Select(1)
                varDropDown.Hide()

            elif var == "F2 Source Gamma":
                data = [complexToMAString(x._gammas[1]) for x in self.lpfiles[file][0].flat_data]
                
                varLabel = wx.StaticText(self, wx.ID_ANY, label=var)
                varLabel.Hide()
                
                varDropDown = wx.ComboBox(self, wx.ID_ANY, choices=data)
                varDropDown.Insert("Disabled", 0)
                varDropDown.Select(1)
                varDropDown.Hide()

            elif var == "F3 Source Gamma":
                data = [complexToMAString(x._gammas[2]) for x in self.lpfiles[file][0].flat_data]
                
                varLabel = wx.StaticText(self, wx.ID_ANY, label=var)
                varLabel.Hide()
                
                varDropDown = wx.ComboBox(self, wx.ID_ANY, choices=data)
                varDropDown.Insert("Disabled", 0)
                varDropDown.Select(1)
                varDropDown.Hide()

            elif var == "Pin_avail":
                continue
            # TODO: handle other potential variables

            varUIElements.append((varLabel, varDropDown))
        
        # add each variable element to list
        for x in varUIElements:
            UIelements.append(x)
        
        # return all elements
        return UIelements
    
    def openDataFiles(self, event=None):
        "Callback to choose data files"
        self._redraw = True
        dlg = wx.FileDialog(self, "Choose file", "", "",
                            supported_filetypes,
                            style = wx.FD_OPEN | wx.FD_MULTIPLE)
        if dlg.ShowModal() == wx.ID_OK:
            filepaths = dlg.GetPaths()
            filenames = dlg.GetFilenames()
            
            self.loadDataFiles(filepaths, filenames)

    def loadDataFiles(self, filepaths, filenames):
        index = 0
        for filepath, filename in zip(filepaths, filenames):
            # get filetype (Maury or Focus)
            extension = filepath.split(".")[1]

            if extension in ["lpcwave", "satwave"]:
                lpfile = focus_lpwave_parser(filepath)
            elif extension in ["spl", "swp"]:
                lpfile = maury_ats_parser(filepath)
            else:
                del filenames[index]
                del filepaths[index]
                print "Invalid filetype, continuing to next file"
                continue

            if filename not in self.fileListBox.GetItems():
                self.fileListBox.Insert(filename, len(self.lpfiles))
                
            # generate UI elements for this file
            self.lpfiles[filename] = (lpfile, None, None, None)
            self.lpfilesUI[filename] = self.createFileUIElement(filename, index)
            staticUIElems = self.lpfilesUI[filename][0]
            label = staticUIElems[1].GetValue()
            color = LineColor[staticUIElems[3].GetStringSelection()]
            style = LineStyle[staticUIElems[5].GetStringSelection()]

            # update loadpull file list with corresponding data
            self.lpfiles[filename] = (lpfile, label, color, style)
            self.selectedFilename = filename
            self.selectedFile = self.lpfiles[filename]
            self.updateBlock(varDropDown = self.lpfilesUI[filename][1][1])
            index += 1

        self.controlContainer.updateSubPanels(self.lpfiles)
        if filenames:
            self.fileListBox.SetStringSelection(filenames[-1])
            self.selectedFilename = filenames[-1]
            self.selectedFile = self.lpfiles[filenames[-1]]
        self.initializeSizer()
        self.initializeBindings()
    
    def updateSelectedFile(self, event=None):
        filename = self.fileListBox.GetStringSelection()
        self.selectedFilename = filename
        self.selectedFile = self.lpfiles[filename]
        self.initializeSizer()
        self.initializeBindings()
    
    def updateBlock(self, event=None, varDropDown=None):
        if varDropDown is not None:
            sender = varDropDown
        else:
            sender = event.GetEventObject()
        variable = None
        for UIElem in self.lpfilesUI[self.selectedFilename][1:]:
            # check if sender was this variable's dropdown
            if sender is UIElem[1]:
                variable = UIElem[0].GetLabel()
                break
        
        # assertion, variable in UI should have been defined by
        # variable definition in the data file
        if variable is None:
            raise RuntimeError("Invalid variable!")
        
        if sender.GetValue() == "Disabled":
            self.controlContainer.customPanel.removeBlocks(self.selectedFilename)
            return
        
        if variable == "F1 Load Gamma":
            for block in self.selectedFile[0].flat_data:
                staticUIElems = self.lpfilesUI[self.selectedFilename][0]
                label = staticUIElems[1].GetValue()
                color = LineColor[staticUIElems[3].GetStringSelection()]
                style = LineStyle[staticUIElems[5].GetStringSelection()]
                if block._gammal[0] == MAstringToComplex(sender.GetValue()):
                    self.controlContainer.customPanel.addBlocks(self.selectedFilename, block, label, color, style)
                    return
        elif variable == "F2 Load Gamma":
            for block in self.selectedFile[0].flat_data:
                staticUIElems = self.lpfilesUI[self.selectedFilename][0]
                label = staticUIElems[1].GetValue()
                color = LineColor[staticUIElems[3].GetStringSelection()]
                style = LineStyle[staticUIElems[5].GetStringSelection()]
                if block._gammal[1] == MAstringToComplex(sender.GetValue()):
                    self.controlContainer.customPanel.addBlocks(self.selectedFilename, block, label, color, style)
                    return
        elif variable == "F3 Load Gamma":
            for block in self.selectedFile[0].flat_data:
                staticUIElems = self.lpfilesUI[self.selectedFilename][0]
                label = staticUIElems[1].GetValue()
                color = LineColor[staticUIElems[3].GetStringSelection()]
                style = LineStyle[staticUIElems[5].GetStringSelection()]
                if block._gammal[2] == MAstringToComplex(sender.GetValue()):
                    self.controlContainer.customPanel.addBlocks(self.selectedFilename, block, label, color, style)
                    return
        elif variable == "F1 Source Gamma":
            for block in self.selectedFile[0].flat_data:
                staticUIElems = self.lpfilesUI[self.selectedFilename][0]
                label = staticUIElems[1].GetValue()
                color = LineColor[staticUIElems[3].GetStringSelection()]
                style = LineStyle[staticUIElems[5].GetStringSelection()]
                if block._gammas[0] == MAstringToComplex(sender.GetValue()):
                    self.controlContainer.customPanel.addBlocks(self.selectedFilename, block, label, color, style)
                    return
        elif variable == "F2 Source Gamma":
            for block in self.selectedFile[0].flat_data:
                staticUIElems = self.lpfilesUI[self.selectedFilename][0]
                label = staticUIElems[1].GetValue()
                color = LineColor[staticUIElems[3].GetStringSelection()]
                style = LineStyle[staticUIElems[5].GetStringSelection()]
                if block._gammas[1] == MAstringToComplex(sender.GetValue()):
                    self.controlContainer.customPanel.addBlocks(self.selectedFilename, block, label, color, style)
                    return
        elif variable == "F3 Source Gamma":
            for block in self.selectedFile[0].flat_data:
                staticUIElems = self.lpfilesUI[self.selectedFilename][0]
                label = staticUIElems[1].GetValue()
                color = LineColor[staticUIElems[3].GetStringSelection()]
                style = LineStyle[staticUIElems[5].GetStringSelection()]
                if block._gammas[2] == MAstringToComplex(sender.GetValue()):
                    self.controlContainer.customPanel.addBlocks(self.selectedFilename, block, label, color, style)
                    return
    
    def updateColor(self, event=None, dropDown=None):
        if dropDown is not None:
            newcolor = LineColor[dropDown.GetStringSelection()]
            if newcolor in [   LineColor.LtBlue,
                            LineColor.DkBlue,
                            LineColor.DkGreen,
                            LineColor.DkPurple,
                            LineColor.DkRed,
                            LineColor.Black]:
                dropDown.SetForegroundColour('#ffffff')
            else:
                dropDown.SetForegroundColour('#000000')
            dropDown.SetBackgroundColour(_colorLUT(newcolor))
        else:
            sender = event.GetEventObject()
            newcolor = LineColor[sender.GetStringSelection()]
            if newcolor in [   LineColor.LtBlue,
                            LineColor.DkBlue,
                            LineColor.DkGreen,
                            LineColor.DkPurple,
                            LineColor.DkRed,
                            LineColor.Black]:
                sender.SetForegroundColour('#ffffff')
            else:
                sender.SetForegroundColour('#000000')
            sender.SetBackgroundColour(_colorLUT(newcolor))

            currentFile = self.lpfiles[self.selectedFilename]
            self.lpfiles[self.selectedFilename] = currentFile[0], currentFile[1], newcolor, currentFile[3]
            self.controlContainer.updateSubPanels(self.lpfiles)
            self.controlContainer.customPanel.updateBlocks(self.selectedFilename, color=newcolor)
            event.StopPropagation()
    
    def updateStyle(self, event=None):
        sender = event.GetEventObject()
        newstyle = LineStyle[sender.GetStringSelection()]
        currentFile = self.lpfiles[self.selectedFilename]
        self.lpfiles[self.selectedFilename] = currentFile[0], currentFile[1], currentFile[2], newstyle
        self.controlContainer.updateSubPanels(self.lpfiles)
        self.controlContainer.customPanel.updateBlocks(self.selectedFilename, style=newstyle)
        event.StopPropagation()
    
    def updateLabel(self, event=None):
        sender = event.GetEventObject()
        newlabel = sender.GetValue()
        currentFile = self.lpfiles[self.selectedFilename]
        self.lpfiles[self.selectedFilename] = currentFile[0], newlabel, currentFile[2], currentFile[3]
        self.controlContainer.updateSubPanels(self.lpfiles)
        self.controlContainer.customPanel.updateBlocks(self.selectedFilename, label=newlabel)
        event.StopPropagation()

class LPAControlContainer(ScrolledPanel):
    controlContainer = None
    dataContainer = None
    graphContainer = None

    def __init__(self, *args, **kwargs):
        super(LPAControlContainer, self).__init__(*args, **kwargs)
        self.ShowScrollbars(wx.SHOW_SB_NEVER, wx.SHOW_SB_ALWAYS)
        
    def initialize(self):
        self.customPanel = LPACustomGraphControls(self, style=wx.NB_TOP | wx.NB_NOPAGETHEME)
        self.graphSummary1Panel = LPAGraphSummary1Controls(self, graphPanel=self.graphContainer.graphSummary1Panel)
        self.graphSummary2Panel = LPAGraphSummary2Controls(self, graphPanel=self.graphContainer.graphSummary2Panel)
        self.tableSummaryPanel = LPATableSummaryControls(self)

        self.customPanel.graphPanel = self.graphContainer.customGraphPanel
        self.customPanel.initialize()

        self.graphSummary1Panel.graphSummary2Controls = self.graphSummary2Panel
        self.graphSummary2Panel.graphSummary1Controls = self.graphSummary1Panel

        self.controls = [self.customPanel, self.graphSummary1Panel, self.graphSummary2Panel, self.tableSummaryPanel]

        self.customPanel.Hide()
        self.graphSummary2Panel.Hide()
        self.tableSummaryPanel.Hide()

        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.graphSummary1Panel, flag=wx.EXPAND | wx.ALL, border=0)
        self.SetSizer(self.sizer)
        self.resize()

    def selectPanel(self, display):
        """
        display - string
        Change the displayed control panel to correspond
        to the selected data display
        """
        self.sizer.Clear()

        for control in self.controls:
            control.Hide()

        panel = None
        if display == "Custom Graphs":
            panel = self.customPanel
        elif display == "Graph Summary 1":
            panel = self.graphSummary1Panel
        elif display == "Graph Summary 2":
            panel = self.graphSummary2Panel
        elif display == "Table Summary":
            panel = self.tableSummaryPanel

        panel.Show()
        self.sizer.Add(panel, flag=wx.EXPAND)
        self.SetSizer(self.sizer)
        self.resize()

    def updateSubPanels(self, files):
        """
        files - dict ( filename : 
                        (maury_ats_parser instance, label, color, style) )
        """
        self.graphSummary1Panel.updatePanes(files)
        self.graphSummary2Panel.updatePanes(files)

    def resize(self):
        self.Layout()
        self.SetupScrolling()

###############################################################################
# Panel/Canvas Classes
###############################################################################
class LPAGraphCanvas(FigureCanvas):
    "Displays a double rectangular plot by default"
    ftype = None
    controlPanel = None
    
    xmin, xmax = 0.0, 1.0
    y1min, y1max = 0.0, 1.0
    y2min, y2max = 0.0, 1.0
    polarmax = 1.0
    smithZ0 = 50 + 0j
    
    _redraw = False
    
    def __init__( self, parent, identifier, graphType=plotlib.PlotFigureType.DoubleRectPlot, title="Title"):
        if graphType == plotlib.PlotFigureType.DoubleRectPlot:
            super(LPAGraphCanvas,self).__init__(parent, identifier, plotlib.DoubleRectPlot(figsize=(6,4), dpi=68))
            self.ftype = plotlib.PlotFigureType.DoubleRectPlot
        elif graphType == plotlib.PlotFigureType.SingleRectPlot:
            super(LPAGraphCanvas,self).__init__(parent, identifier, plotlib.SingleRectPlot(figsize=(6,4), dpi=68))
            self.ftype = plotlib.PlotFigureType.SingleRectPlot
        elif graphType == plotlib.PlotFigureType.SmithPlot:
            super(LPAGraphCanvas,self).__init__(parent, identifier, plotlib.SmithPlot(figsize=(6,4), dpi=68))
            self.ftype = plotlib.PlotFigureType.SmithPlot

        self.parent = parent
        self.title = title
        self._SetColor()
        
        self.initializeUIElements()
        self.initializeBindings()
        
        self.resizeCanvas()
    
    def initializeUIElements(self):
        # Controls
        # Title
        self.titleTextBox = wx.TextCtrl(         self,
                                                wx.ID_ANY,
                                                self.title,
                                                (0, 0),
                                                (50,20),
                                                style=wx.TE_PROCESS_ENTER | wx.TE_CENTRE)
        self.titleTextLabel = wx.StaticText(    self,
                                                wx.ID_ANY,
                                                self.title,
                                                style=wx.ALIGN_CENTRE_HORIZONTAL)
        self.titleTextBox.Hide()    
        
        # Close Button
        self.closeButton = wx.Button(            self,
                                                wx.ID_ANY,
                                                "X",
                                                style=wx.BU_EXACTFIT)
        
    def initializeBindings(self):
        # Event Bindings
        self.titleTextLabel.Bind(wx.EVT_LEFT_DCLICK, self.showTitleTextBox)
        self.Bind(wx.EVT_TEXT_ENTER, self.updateTitle, self.titleTextBox)
        self.Bind(wx.EVT_BUTTON, self.closeCanvas)
        self.Bind(wx.EVT_IDLE, self._onIdle)
    
    def _onIdle(self, event=None):
        if self._redraw:
            self._redraw = False
            self.parent.Layout()
    
    def resetAutoscaleLimits(self):
        self.xmin, self.xmax, self.y1min, self.y1max, self.y2min, self.y2max = (0.0, 1.0, 0.0, 1.0, 0.0, 1.0)
        self.polarmax = 1.0
    
    def changeFigureType(self, figType):
        # only change figure type if new type is different
        if not self.ftype == figType:
            if figType == plotlib.PlotFigureType.SingleRectPlot:
                self.figure = plotlib.SingleRectPlot(figsize=(6,4), dpi=68)
                self.ftype = plotlib.PlotFigureType.SingleRectPlot
            elif figType == plotlib.PlotFigureType.DoubleRectPlot:
                self.figure = plotlib.DoubleRectPlot(figsize=(6,4), dpi=68)
                self.ftype = plotlib.PlotFigureType.DoubleRectPlot
            elif figType == plotlib.PlotFigureType.SmithPlot:
                self.figure = plotlib.SmithPlot(figsize=(6,4), dpi=68)
                self.ftype = plotlib.PlotFigureType.SmithPlot
            
            # if plot type changed, update new plot's canvas and reset autoscale limits
            self.figure.set_canvas(self)
            self._SetColor()
            self.parent._SetSize()
            self.resetAutoscaleLimits()
    
    def closeCanvas(self, event=None):
        self.controlPanel.removeGraph(self)
        self.parent.removeGraph(self)
    
    def updateTitle(self, event=None):
        self._redraw = True
        
        # hide editable box
        self.titleTextBox.Hide()
        
        # create initial title if blank
        if self.titleTextBox.GetValue() == "":
            self.titleTextLabel.SetLabel("Title")
            self.titleTextBox.SetValue("Title")
            if self.controlPanel is not None:
                self.controlPanel.changeName("Title")
        else:
            self.titleTextLabel.SetLabel(self.titleTextBox.GetValue())
            if self.controlPanel is not None:
                self.controlPanel.changeName(self.titleTextBox.GetValue())
        
        self.titleTextLabel.Show()
        self.resizeCanvas()
        self._redraw = True
    
    def showTitleTextBox(self, event=None):
        self._redraw = True
        self.titleTextLabel.Hide()
        self.titleTextBox.SetSizeWH(self.titleTextLabel.GetSizeTuple()[0]*1.4, self.titleTextBox.GetSizeTuple()[1])
        self.resizeCanvas()
        self.titleTextBox.Show()
        self.titleTextBox.SetFocus()
        self.titleTextBox.SelectAll()
        self.draw()
    
    def resizeCanvas(self):
        self._redraw = True        
        self.titleTextBox.SetPosition(wx.Point(     self.GetSizeTuple()[0]*0.5-self.titleTextBox.GetSizeTuple()[0]*0.5,
                                                    0))
        
        self.titleTextLabel.SetPosition(wx.Point(   self.GetSizeTuple()[0]*0.5-self.titleTextLabel.GetSizeTuple()[0]*0.5,
                                                    0))
        
        self.closeButton.SetPosition(wx.Point(     self.GetSizeTuple()[0] - self.closeButton.GetSizeTuple()[0],
                                                   0))
    
    def setAxisLimits(self, xlimits, y1limits, y2limits):
        """
        xlimits, y1limits, y2limits - (float, float)
        
        Update all axis limits accordingly
        """
        
        self._redraw = True
        currentLimits = self.figure.getAxisLimits()
        
        if xlimits is not None:
            xmin, xmax = xlimits
        else:
            xmin, xmax = currentLimits[0]
        
        if y1limits is not None:
            y1min, y1max = y1limits
        else:
            y1min, y1max = currentLimits[1]
        
        if y2limits is not None:
            y2min, y2max = y2limits
        else:
            y2min, y2max = currentLimits[2]
        
        try:
            if xmin >= xmax or y1min >= y1max or y2min >= y2max:
                raise ValueError
            self.figure.setAxisLimits(    xmin, xmax,
                                        y1min, y1max,
                                        y2min, y2max)
        except ValueError:
            traceback.print_exc()
            dlg = wx.MessageDialog(    self, "Invalid limit!",
                                    caption="Invalid Value",
                                    style=wx.OK)
            dlg.ShowModal()
    
    def setAxisScaling(self, xscale, y1scale, y2scale):
        """
        xscale, y1scale, y2scale - string or None
        
        Update all scales accordingly.
        """
        self._redraw = True
        self.figure.setAxisScaling(xscale, y1scale, y2scale)
    
    def getAxisLimits(self):
        return self.figure.getAxisLimits()
    
    def getAutoScaleLimits(self):
        return [(self.xmin, self.xmax), (self.y1min, self.y1max), (self.y2min, self.y2max)]
    
    def setPolarMax(self, max):
        """
        max - float
        If this graph is a polar plot, set the maximum value to 'max'
        """
        
        #TODO - implement polar plots
        pass
    
    def clearGraph(self):
        self.figure.resetPlot()
        self._redraw = True
    
    def plotAll(self, xvals, y1vals, y2vals=None):
        """
        xvals - 2-tuple (label, data)
        y1vals, y2vals - dicts
        
        Update the graph with the given data and labels
        """
        xlabel = xvals[0]
        xdata = xvals[1]
        for y1label, y1data in y1vals.items():
            self.figure.plotPrimary(xdata, y1data, y1label)
        
        for y2label, y2data in y2vals.items():
            self.figure.plotSecondary(xdata, y2data, y2label)
        
        self.figure.setXLabel(xlabel)
        self.xmin, self.xmax = self.getAxisLimits()[0]
        self.y1min, self.y1max = self.getAxisLimits()[1]
        self.y2min, self.y2max = self.getAxisLimits()[2]
        self._redraw = True
    
    def plotPrimary(self, xvals, yvals, ylabel="Trace", ycolor=LineColor.LtRed, ystyle=LineStyle.Solid):
        """
        Plot the given trace on the graph's primary y-axis
        """
        if self.ftype == plotlib.PlotFigureType.SingleRectPlot:
            self.figure.plotData(xvals, yvals, ylabel, _styleLUT(ystyle), _colorLUT(ycolor))
        elif self.ftype == plotlib.PlotFigureType.DoubleRectPlot:
            self.figure.plotPrimary(xvals, yvals, ylabel, _styleLUT(ystyle), _colorLUT(ycolor))
        self.xmin, self.xmax = self.getAxisLimits()[0]
        self.y1min, self.y1max = self.getAxisLimits()[1]
        self._redraw = True
    
    def plotSecondary(self, xvals, yvals, ylabel="Trace", ycolor=LineColor.LtRed, ystyle=LineStyle.Dashed):
        """
        Plot the given trace on the graph's primary y-axis
        """
        self.figure.plotSecondary(xvals, yvals, ylabel, _styleLUT(ystyle), _colorLUT(ycolor))
        self.xmin, self.xmax = self.getAxisLimits()[0]
        self.y2min, self.y2max = self.getAxisLimits()[2]
        self._redraw = True
    
    def scatterPlot(self, xvals, yvals, color=LineColor.Black, markerStyle=MarkerType.x, **kwargs):
        self.figure.scatterData(xvals, yvals, _colorLUT(color), _markerLUT(markerStyle), picker=True, **kwargs)
        self._redraw = True

    def contourPlot(self, xvals, yvals, zvals, numContours=5, linewidth=1, label="Label", linecolor=LineColor.Black):
        self.figure.plotContour(xvals, yvals, zvals, numContours, linewidth, label, _colorLUT(linecolor))
        self._redraw = True

    def annotatePrimary(self, string, xcoord, ycoord, **kwargs):
        annotation = self.figure.annotate(string, xcoord, ycoord, **kwargs)
        self._redraw = True
        return annotation

    def annotateSecondary(self, string, xcoord, ycoord, **kwargs):
        annotation = self.figure.annotateSec(string, xcoord, ycoord, **kwargs)
        self._redraw = True
        return annotation

    def setXLabel(self, label):
        """
        label - string
        Set the graph's x-axis label
        """
        self.figure.setXLabel(label)

    def setPrimaryYLabel(self, label):
        """
        label - string
        Set the graph's y-axis label.
        For a double-rectangular plot, set the Y1 label
        """
        if self.ftype == plotlib.PlotFigureType.SingleRectPlot:
            self.figure.setYLabel(label)
        elif self.ftype == plotlib.PlotFigureType.DoubleRectPlot:
            self.figure.setY1Label(label)

    def setSecondaryYLabel(self, label):
        """
        label - string
        For a double-rectangular plot, set the Y2 label
        """
        if self.ftype == plotlib.PlotFigureType.DoubleRectPlot:
            self.figure.setY2Label(label)

    def setTitle(self, title):
        """
        title - string
        Set the graph's title
        """
        self.figure.setTitle(title)
    
    def showLegend(self, show):
        """
        show - boolean
        Show legend on plot if show is True, otherwise hide legend.
        """
        self.figure.showLegend(show)
    
    def _SetColor( self, rgbtuple=None ):
        "Set figure and canvas colours to be the same."
        if rgbtuple is None:
            rgbtuple = wx.SystemSettings.GetColour( wx.SYS_COLOUR_BTNFACE ).Get()
        clr = [c/255. for c in rgbtuple]
        self.figure.set_facecolor( clr )
        self.figure.set_edgecolor( clr )
        self.SetBackgroundColour( wx.Colour( *rgbtuple ) )

class LPAGenericGraphPanel(ScrolledPanel):
    controlContainer = None
    dataContainer = None
    graphContainer = None
    
    def __init__(self, *args, **kwargs):
        super(LPAGenericGraphPanel, self).__init__(*args, **kwargs)
        
        self.graphs = [ ]
        
        self.sizer = wx.GridSizer(cols=1, vgap=10, hgap=10)
        self.SetSizer(self.sizer)
        
        self._resizeflag = False
        self.Bind(wx.EVT_IDLE, self._onIdle)
        self.Bind(wx.EVT_SIZE, self._onSize)
    
    def _onSize( self, event ):
        "event method for resize"
        self._resizeflag = True
    
    def _onIdle( self, evt ):
        "event method for idle events"
        if self._resizeflag:
            self._SetSize()
    
    def _SetSize(self, event=None):
        "resize the figure image" 
        
        self._resizeflag = False
        self.Layout()
        self.SetupScrolling() 
        for g in self.graphs:
            g.resizeCanvas()
    
    def addNewGraph(self, graphCanvas=None, graphType=plotlib.PlotFigureType.DoubleRectPlot, title=""):
        newGraph = None
        if graphCanvas is None:
            newGraph = LPAGraphCanvas(self, wx.ID_ANY, graphType, title)
        else:
            newGraph = graphCanvas
        
        self.graphs.append(newGraph)
        if len(self.graphs) >= 2:
            self.sizer.SetCols(2)
        else:
            self.sizer.SetCols(1)
        
        self.sizer.Add(newGraph, proportion=1, flag=wx.ALIGN_CENTER | wx.SHAPED | wx.ALL, border=1)
        self.sizer.SetItemMinSize(newGraph, wx.Size(375,250))
        self._resizeflag = True
    
    def removeGraph(self, graphCanvas):
        self.sizer.Detach(graphCanvas)
        self.graphs.remove(graphCanvas)
        graphCanvas.Destroy()
        self._resizeflag = True

    def clearGraphs(self):
        for graph in self.graphs:
            graph.clearGraph()

class LPAGraphSummary1Panel(LPAGenericGraphPanel):
    controlPanel = None

    def __init__(self, *args, **kwargs):
        super(LPAGraphSummary1Panel, self).__init__(*args, **kwargs)

        self.canvas0 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)
        self.canvas1 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.DoubleRectPlot)
        self.canvas2 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)

        self.canvas0.mpl_connect('pick_event', self.onClick)
        self.canvas2.mpl_connect('pick_event', self.onClick)

        self.graphs.append(self.canvas0)
        self.graphs.append(self.canvas1)
        self.graphs.append(self.canvas2)

        for graph in self.graphs:
            graph.titleTextLabel.Hide()
            graph.closeButton.Hide()
            graph.titleTextBox.Disable()
        
        self.sizer = wx.GridBagSizer(5, 5)
        self.sizer.Add(self.canvas0, pos=(0,0), span=(2,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas1, pos=(0,1), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas2, pos=(1,1), span=(1,1), flag=wx.EXPAND | wx.ALL)
        
        for row in range(0, self.sizer.Rows):
            self.sizer.AddGrowableRow(row)
        for col in range(0, self.sizer.Cols):
            self.sizer.AddGrowableCol(col)

        self.SetSizer(self.sizer)
        self.Layout()
        self.SetupScrolling()

    def onClick(self, event):
        imp = self.controlPanel.contourImpedances[event.ind[0]]
        
        # left-click, update marker 1
        if event.mouseevent.button == 1:
            self.controlPanel.updateMarker(imp, None)
        # right-click, update marker 2
        elif event.mouseevent.button == 3:
            self.controlPanel.updateMarker(None, imp)

class LPAGraphSummary2Panel(LPAGenericGraphPanel):

    def __init__(self, *args, **kwargs):
        super(LPAGraphSummary2Panel, self).__init__(*args, **kwargs)

        self.canvas0 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)
        self.canvas1 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)
        self.canvas2 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)
        self.canvas3 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)
        self.canvas4 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)
        self.canvas5 = LPAGraphCanvas(self, wx.ID_ANY, plotlib.PlotFigureType.SingleRectPlot)

        self.graphs.append(self.canvas0)
        self.graphs.append(self.canvas1)
        self.graphs.append(self.canvas2)
        self.graphs.append(self.canvas3)
        self.graphs.append(self.canvas4)
        self.graphs.append(self.canvas5)

        for graph in self.graphs:
            graph.titleTextLabel.Hide()
            graph.closeButton.Hide()
            graph.titleTextBox.Disable()
        
        self.sizer = wx.GridBagSizer(5, 5)
        self.sizer.Add(self.canvas0, pos=(0,0), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas1, pos=(0,1), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas2, pos=(0,2), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas3, pos=(1,0), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas4, pos=(1,1), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.canvas5, pos=(1,2), span=(1,1), flag=wx.EXPAND | wx.ALL)
        
        for row in range(0, self.sizer.Rows):
            self.sizer.AddGrowableRow(row)
        for col in range(0, self.sizer.Cols):
            self.sizer.AddGrowableCol(col)

        self.SetSizer(self.sizer)
        self.Layout()
        self.SetupScrolling()

class LPACustomGraphControls(wx.Notebook):
    graphPanel = None
    
    def __init__(self, *args, **kwargs):
        super(LPACustomGraphControls, self).__init__(*args, **kwargs)
    
    def initialize(self):
        self.SetBackgroundColour((240,240,240))
        
        # create initial graph canvas
        initialGraph = LPAGraphCanvas(self.graphPanel, wx.ID_ANY, title="Graph 1")
        self.graphPanel.addNewGraph(initialGraph)
        
        # create initial control panel
        self.panels = [ ]
        initialPanel = LPAGraphControlPanel(self, name="Graph 1", graphCanvas=initialGraph)
        self.panels.append(initialPanel)
        self.AddPage(initialPanel, initialPanel.Name)
        self.AddPage(wx.Panel(self, wx.ID_ANY), "+")
        
        linkGraphControls(initialGraph, initialPanel)
        
        self.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self.onTabChange)
    
    def onTabChange(self, event=None):
        if self.GetSelection()+1 == self.GetPageCount():
            self.newTab()
    
    def resize(self):
        self.Layout()
        self.Parent.Layout()
        self.Parent.SetupScrolling()

    def newTab(self):
        # create graph canvas
        newGraph = LPAGraphCanvas(self.graphPanel, wx.ID_ANY, title=("Graph %d"%(len(self.panels)+1)))
        self.graphPanel.addNewGraph(newGraph)
        
        # create control panel
        newPanel = LPAGraphControlPanel(self, name=("Graph %d"%(len(self.panels)+1)), graphCanvas=newGraph)
        self.panels.append(newPanel)
        self.InsertPage(self.GetPageCount()-1, newPanel, newPanel.Name, select=False)
        self.ChangeSelection(self.GetPageCount()-2)
        
        # link panel to canvas
        linkGraphControls(newGraph, newPanel)
        
        if self.panels[len(self.panels)-1].blocks.keys():
            newPanel.blocks = self.panels[len(self.panels)-1].blocks
        newGraph.clearGraph()
    
    def removeTab(self, panel):
        if panel in self.panels:
            index = self.panels.index(panel)
            self.panels.remove(panel)
            self.RemovePage(index)
    
    def addBlocks(self, name, block, label, color, style):
        "see description in LPAControlPanel.addBlock"
        for panel in self.panels:
            panel.addBlock(name, block, label, color, style)
    
    def removeBlocks(self, name):
        "see description in LPAControlPanel.removeBlock"
        for panel in self.panels:
            panel.removeBlock(name)
    
    def updateBlocks(self, name, label=None, color=None, style=None):
        "see description in LPAControlPanel.updateBlock"
        for panel in self.panels:
            panel.updateBlock(name, label, color, style)

class LPAGraphControlPanel(wx.Panel):
    graphCanvas = None
    
    blocks = dict()     # filename : (block, label, color, style, xdata, y1data, y2data)
    indepParam = None   # label
    Y1Params = [ ]      # [ labels ]
    Y2Params = [ ]      # [ labels ]
    
    def __init__(self, *args, **kwargs):
        if "graphCanvas" in kwargs.keys():
            self.graphCanvas = kwargs.pop("graphCanvas")
        super(LPAGraphControlPanel, self).__init__(*args, **kwargs)
        
        self.initializeUIElements()
        self.initializeSizer()
        self.initializeBindings()
    
    def initializeUIElements(self):
        self.indepParameterPane = LPAIndepParamPane(self, self.graphCanvas, wx.ID_ANY, "Independent Parameter")
        self.depParameterPane = LPADepParamPane(self, self.graphCanvas, wx.ID_ANY, "Dependent Parameters")
        self.formatPane = LPAFormatPane(self, self.graphCanvas, wx.ID_ANY, "Format")
        self.xScalingPane = LPAScalingPane(self, self.graphCanvas, RectAxis.x)
        self.y1ScalingPane = LPAScalingPane(self, self.graphCanvas, RectAxis.y1)
        self.y2ScalingPane = LPAScalingPane(self, self.graphCanvas, RectAxis.y2)
        self.smithPane = LPASmithPane(self, self.graphCanvas)
        self.polarPane = LPAPolarPane(self, self.graphCanvas)
        self.formatPane.Hide()
        self.smithPane.Hide()
        self.polarPane.Hide()
        self.updateIndependentParam(self.indepParameterPane.GetPane().parameterDropDown.GetStringSelection())
    
    def initializeSizer(self):
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.indepParameterPane, 0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.depParameterPane,   0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.formatPane,         0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.xScalingPane,       0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.y1ScalingPane,      0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.y2ScalingPane,      0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.smithPane,          0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.polarPane,          0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.SetSizer(self.sizer)
    
    def initializeBindings(self):
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.onPaneChange)
    
    def onPaneChange(self, event=None):
        self.Layout()
        self.Parent.resize()
    
    def changeName(self, name):
        self.Parent.SetPageText(self.Parent.panels.index(self), name)
        self.Name = name
    
    def updateIndependentParam(self, param=None):
        """
        param - string
        Updates this control panel's currently selected independent data parameter,
        then extracts independent data to be plotted from each block.
        """
        if param is not None:
            self.indepParam = param
        
        for name, tuple in self.blocks.items():
            block = tuple[0]
            if self.indepParam in block.swept_columns:
                self.blocks[name] = tuple[0], tuple[1], tuple[2], tuple[3], block.__getitem__(self.indepParam), tuple[5], tuple[6]
        
        if self.blocks.values():
            self.updateRectGraph()
    
    def updateDependentParam(self):
        """
        Extracts dependent data to be plotted from each block from
        the currently selected dependent parameters
        """
        for tuple in self.blocks.values():
            block = tuple[0]
            y1data = tuple[5]
            y2data = tuple[6]
            
            for param1 in self.Y1Params:
                y1data[param1] = block.__getitem__(param1)
            
            for param2 in self.Y2Params:
                y2data[param2] = block.__getitem__(param2)
        
        self.updateRectGraph()
    
    def addDependentParam(self, param1 = None, param2 = None):
        """
        param1, param2 - string, parameter
        Extracts dependent data to be plotted from each block
        param2 is used only for a rectangular plot's secondary y-axis.
        """
        if param1 is not None:
            self.Y1Params.append(param1)
        if param2 is not None:
            self.Y2Params.append(param2)
        
        self.updateDependentParam()
    
    def removeDependentParam(self, param1 = None, param2 = None):
        """
        param1, param2 - single parameter
        Removes dependent data to be plotted from each block
        param2 is used only for a rectangular plot's secondary y-axis.
        """
        if param1 is not None:
            if param1 in self.Y1Params:
                self.Y1Params.remove(param1)
        if param2 is not None:
            if param2 in self.Y2Params:
                self.Y2Params.remove(param2)
        
        for tuple in self.blocks.values():
            y1data = tuple[5]
            y2data = tuple[6]
            if param1 is not None:
                if param1 in y1data.keys():
                    y1data.pop(param1)
            
            if param2 is not None:
                if param2 in y2data.keys():
                    y2data.pop(param2)
        
        self.updateRectGraph()
    
    def addBlock(self, name, block=None, label=None, color=None, style=None):
        """
        Add a block of data to this control panel's block dictionary
        with the specified parameters.
        
        Arguments:
        name -  string, filename of the data file from which the block
                originated, used to index the block dictionary
        block - single index of a maury_ats_parser.flat_data instance
        label - string, label to be used when graphing data from this block
        color - LineColor, color to be used when graphing
        style - LineStyle, line style to be used when graphing
        """
        
        # dictionary stores block and associated plotting parameters in a 7-tuple
        # (block, label, color, style, xdata list, y1data dict, y2data dict)
        
        # if file is already plotted
        if name in self.blocks.keys():
            curBlock = self.blocks[name][0]
            curXdata = self.blocks[name][4]
            curY1data = self.blocks[name][5]
            curY2data = self.blocks[name][6]
            
            # if plotting the same block (change in label, color or style)
            if block is curBlock:
                self.blocks[name] = (curBlock, label, color, style, curXdata, curY1data, curY2data)
                self.updateRectGraph()
            
            # if plotting a different block (change in variable selection)
            else:
                self.blocks[name] = (block, label, color, style, [ ], dict(), dict())
                self.updateIndependentParam()
                self.updateDependentParam()
        
        # if the file hasn't been plotted
        else:
            self.blocks[name] = (block, label, color, style, [ ], dict(), dict())
            self.updateIndependentParam()
            self.updateDependentParam()
    
    def removeBlock(self, name):
        """
        Remove a block of data from this control panel's block dictionary
        """
        if name in self.blocks.keys():
            self.blocks.pop(name)
        
        self.updateRectGraph()
    
    def updateBlock(self, name, label=None, color=None, style=None):
        """
        Update a block's plot style.
        """
        if not name in self.blocks.keys():
            return
        curBlock = self.blocks[name][0]
        curLabel = self.blocks[name][1]
        curColor = self.blocks[name][2]
        curStyle = self.blocks[name][3]
        curXdata = self.blocks[name][4]
        curY1data = self.blocks[name][5]
        curY2data = self.blocks[name][6]
        self.blocks[name] = (curBlock,
                             curLabel if label is None else label,
                             curColor if color is None else color,
                             curStyle if style is None else style,
                             curXdata,
                             curY1data,
                             curY2data)
        self.updateRectGraph()
    
    def updateRectGraph(self):
        """
        Update graph with data from all blocks
        """
        self.graphCanvas.clearGraph()
        self.graphCanvas.showLegend(False)
        for tuple in self.blocks.values():
            label = tuple[1]
            color = tuple[2]
            style = tuple[3]
            xdata = tuple[4]
            y1data = tuple[5]
            y2data = tuple[6]
            
            for data in y1data.values():
                self.graphCanvas.plotPrimary(xdata, data, label, color, style)
                self.graphCanvas.showLegend(True)
            
            for data in y2data.values():
                self.graphCanvas.plotSecondary(xdata, data, label, color, style)
                self.graphCanvas.showLegend(True)
        
        self.graphCanvas.setXLabel(self.indepParam)
        self.xScalingPane.updateGraphAutoscaleUI()
        self.y1ScalingPane.updateGraphAutoscaleUI()
        self.y2ScalingPane.updateGraphAutoscaleUI()

    def removeGraph(self, graph):
        self.Parent.removeTab(self)

class LPAGraphSummary1Controls(wx.Panel):

    lpfiles = dict()    # filename : (maury_ats_parser instance, label, color, style)
    contourFilename = ""
    contourFile = None

    graphPanel = None
    graphSummary2Controls = None

    # tuple used to determine which data is chosen to be plotted
    # ('comp_gt', x) will get data at x-dB of transducer gain compression
    # ('pout_dbm', y) will get data at Pout = y dBm
    plotAt = ('comp_gt', 1.0)

    # data arrays used to store contour/rect graph data
    contourReflCoeffs   = [ ]
    contourImpedances   = [ ]
    pout                = [ ]
    contourPout         = [ ]
    gt                  = [ ]
    contourGt           = [ ]
    efficiency          = [ ]
    contourEff          = [ ]
    contourBlocks       = [ ]
    rectPout            = [ ]
    rectEff             = [ ]

    # impedance interpolation grid settings
    gridExtension = 0.01
    xGridDensity = 0.001
    yGridDensity = 0.001

    # frequency in GHz
    freq = 1.0

    # 3-tuples
    # ( index of refl-coeff/impedance in array,
    # contour plot annotation matplotlib.Artist,
    # rectangular plot annotation matplotlib.Artist )
    marker1 = None
    marker2 = None
    
    def __init__(self, *args, **kwargs):
        if "graphPanel" in kwargs:
            self.graphPanel = kwargs.pop("graphPanel")
            self.graphPanel.controlPanel = self
        super(LPAGraphSummary1Controls, self).__init__(*args, **kwargs)
        self.initializeUIElements()
        self.initializeSizer()
        self.initializeBindings()
    
    def initializeUIElements(self):
        self.markerPane = LPAMarkerPane(self, label="Variable Selection")
        self.markerPane.Expand()
        self.rectContourPane = LPAContourPane(self, label="Contour Options")
        self.rectContourPane.Expand()
        #self.freqPane = LPAFreqPane(self, label="Frequency Selection")

    def initializeSizer(self):
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.markerPane, 0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.rectContourPane, 0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        #self.sizer.Add(self.freqPane, 0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.SetSizer(self.sizer)
    
    def initializeBindings(self):
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.onPaneChange)

    def onPaneChange(self, event=None):
        self.Layout()
        self.Parent.resize()

    def updatePanes(self, files):
        """
        files - dict (filename : maury_ats_parser instance)
        """
        self.lpfiles = files

        self.rectContourPane.updateFileList(self.lpfiles.keys())
        
        #frequencies = set()
        #for file in self.lpfiles.values():
        #    frequencies.add(file.frequency)

        #self.freqPane.updateFreqList(frequencies)

    def updateMarker(self, marker1=None, marker2=None):
        """
        marker1, marker2 = complex (impedances)
        """
        if marker1 is not None:
            
            # remove the markers currently displayed on the graph
            if self.marker1 is not None:
                self.marker1[1].remove()
                self.marker1[2].remove()

            # find the index of the impedance corresponding to the marker
            index = self.contourImpedances.index(marker1)

            # create the marker for the contour plot
            contourAnnotation = self.graphPanel.canvas0.annotatePrimary("M1", marker1.real, marker1.imag,
                                                    xytext=(0, 10), textcoords='offset points', color=_colorLUT(LineColor.Orange), ha='center',
                                                    arrowprops={'width':10, 'frac':1.0, 'color':_colorLUT(LineColor.Orange)})

            # create the marker for the rectangular eff-vs-pout plot
            pout = self.rectPout[index]
            eff = self.rectEff[index]
            rectAnnotation = self.graphPanel.canvas2.annotatePrimary("M1", pout, eff,
                                                    xytext=(0, 10), textcoords='offset points', color=_colorLUT(LineColor.Orange), ha='center',
                                                    arrowprops={'width':10, 'frac':1.0, 'color':_colorLUT(LineColor.Orange)})

            # store the index of the impedance and the markers locally
            self.marker1 = (index, contourAnnotation, rectAnnotation)
            imp = marker1
            gamma = -(1/plotlib._get_normalized_impedance(marker1))
            self.markerPane.updateMarkerValues((imp, gamma), None)
            self.graphSummary2Controls.updateMarker(marker1, None)

        if marker2 is not None:
            if self.marker2 is not None:
                self.marker2[1].remove()
                self.marker2[2].remove()
            index = self.contourImpedances.index(marker2)
            contourAnnotation = self.graphPanel.canvas0.annotatePrimary("M2", marker2.real, marker2.imag,
                                                    xytext=(0, 10), textcoords='offset points', color=_colorLUT(LineColor.Purple), ha='center',
                                                    arrowprops={'width':10, 'frac':1.0, 'color':_colorLUT(LineColor.Purple)})

            pout = self.rectPout[index]
            eff = self.rectEff[index]
            rectAnnotation = self.graphPanel.canvas2.annotatePrimary("M2", pout, eff,
                                                    xytext=(0, 10), textcoords='offset points', color=_colorLUT(LineColor.Purple), ha='center',
                                                    arrowprops={'width':10, 'frac':1.0, 'color':_colorLUT(LineColor.Purple)})
            self.marker2 = (index, contourAnnotation, rectAnnotation)
            imp = marker2
            gamma = -(1/plotlib._get_normalized_impedance(marker2))
            self.markerPane.updateMarkerValues(None, (imp, gamma))
            self.graphSummary2Controls.updateMarker(None, marker2)

        self.updateRectGraph1()

    def clearMarkers(self):
        self.marker1 = None
        self.marker2 = None
        self.markerPane.updateMarkerValues(None, None)
        
    def updateContourFile(self, filename):
        self.contourFilename = filename
        self.contourFile = self.lpfiles[self.contourFilename]

        self.graphSummary2Controls.clearFileSelections()
        self.graphSummary2Controls.updateMarkerFile(filename)

        if self.updateData():
            self.updateGraphs()

    def updatePlotAt(self, variable=None, value=None):
        if variable is not None:
            # if changing the variable, must change value at the same time!
            self.plotAt = variable, value
        if value is not None:
            self.plotAt = self.plotAt[0], value

        if self.updateData():
            self.updateGraphs()

    def setGridSettings(self, extension=None, xdensity=None, ydensity=None):
        if extension is not None:
            self.gridExtension = extension
        if xdensity is not None:
            self.xGridDensity = xdensity
        if ydensity is not None:
            self.yGridDensity = ydensity
        
        self.clearMarkers()
        self.updateGraphs()

    def updateGraphs(self):
        self.updateContourGraph()
        self.updateRectGraph2()
        self.updateRectGraph1()

    def updateData(self):
        if self.contourFile is None:
            return

        self.freq = self.contourFile[0].frequency

        # get impedances for sweep
        data = [block.extract(self.plotAt[1],parameter=self.plotAt[0]) for block in self.contourFile[0].flat_data]

        # find harmonic of impedance sweep
        for var in self.contourFile[0]._vars:
            if var == "Pin_avail":
                continue
            if var in ["F1 Load Gamma", "F1 Source Gamma"]:
                harmonic = 0
            elif var in ["F2 Load Gamma", "F2 Source Gamma"]:
                harmonic = 1
            elif var in ["F3 Load Gamma", "F3 Source Gamma"]:
                harmonic = 2
            else:
                showMessageDialog(self, "Invalid data", "No swept impedances in this file!")
                return False

        self.contourReflCoeffs = [ ]
        self.contourImpedances = [ ]
        self.clearMarkers()

        # get contour x/y and z values
        self.efficiency, self.gt, self.pout = [ ], [ ], [ ]
        valid = False
        for block in data:
            if block is not None:
                valid = True
                # full block data, to allow indexing by gamma/Z
                self.contourBlocks.append(block)

                # x/y values
                if self.contourFile[0]._type:
                    if self.contourFile[0]._type == "sourcepull":
                        self.contourReflCoeffs.append(block['gamma_src'][harmonic])
                    else:
                        self.contourReflCoeffs.append(block['gamma_ld'][harmonic])
                # maintain compatibility with maury ATS files
                else:
                        self.contourReflCoeffs.append(block['gamma_ld'][harmonic])
                        
                # z values
                self.efficiency.append(block['eff_%'])
                self.gt.append(block['gt_db'])
                self.pout.append(block['pout_dbm'])
        
        if not valid:
            showMessageDialog(self, "Invalid data", "No data from file at selected power/compression!")
            return False

        # generate impedances from reflection coefficients
        self.contourImpedances = [plotlib._get_normalized_impedance(x) for x in self.contourReflCoeffs]

        # generate grid over impedance plane to use for contour generation
        impedances_real = [x.real for x in self.contourImpedances]
        impedances_imag = [x.imag for x in self.contourImpedances]
        
        xmin, xmax = min(impedances_real), max(impedances_real)
        ymin, ymax = min(impedances_imag), max(impedances_imag)

        self.gridExtension = min((xmax - xmin)/len(self.contourImpedances),(ymax - ymin)/len(self.contourImpedances))
        self.xGridDensity = (xmax - xmin)/len(self.contourImpedances)
        self.yGridDensity = (ymax - ymin)/len(self.contourImpedances)
        self.rectContourPane.updateGridDensity(self.gridExtension, self.xGridDensity, self.yGridDensity)
        return True

    def updateContourGraph(self):
        self.graphPanel.clearGraphs()

        if not self.contourImpedances:
            return

        # generate grid over impedance plane to use for contour generation
        impedances_real = [x.real for x in self.contourImpedances]
        impedances_imag = [x.imag for x in self.contourImpedances]
        
        xmin, xmax = min(impedances_real), max(impedances_real)
        ymin, ymax = min(impedances_imag), max(impedances_imag)

        xr = xmax - xmin + 2*self.gridExtension
        yr = ymax - ymin + 2*self.gridExtension
        xi = np.linspace(xmin-self.gridExtension,xmax+self.gridExtension,int(xr/self.xGridDensity))
        yi = np.linspace(ymin-self.gridExtension,ymax+self.gridExtension,int(yr/self.yGridDensity))

        # generate contour data for each parameter
        self.contourEff = mlab.griddata(impedances_real, impedances_imag, self.efficiency, xi, yi, interp='linear')
        self.contourGt = mlab.griddata(impedances_real, impedances_imag, self.gt, xi, yi, interp='linear')
        self.contourPout = mlab.griddata(impedances_real, impedances_imag, self.pout, xi, yi, interp='linear')

        # scatter plot impedances
        self.graphPanel.canvas0.scatterPlot(impedances_real, impedances_imag, markerStyle=MarkerType.x)
        if self.graphPanel.canvas0.ftype == plotlib.PlotFigureType.SingleRectPlot:
            self.graphPanel.canvas0.setXLabel("Real(Zl)")
            self.graphPanel.canvas0.setPrimaryYLabel("Imag(Zl)")
            self.graphPanel.canvas0.setAxisLimits((xmin-2*self.gridExtension, xmax+2*self.gridExtension),
                                                  (ymin-2*self.gridExtension, ymax+2*self.gridExtension),
                                                  None)

        # need 6+ points to make contours
        if len(self.contourReflCoeffs) < 6:
            showMessageDialog(self, "Insufficient Points", "Not enough impedances at selected condition to generate contours!")
            return

        # plot contours
        self.graphPanel.canvas0.contourPlot(xi, yi, self.contourEff, 10, 1, "Efficiency (%)", LineColor.LtBlue)
        self.graphPanel.canvas0.contourPlot(xi, yi, self.contourGt, 10, 1, "Transducer Gain (dB)", LineColor.Purple)
        self.graphPanel.canvas0.contourPlot(xi, yi, self.contourPout, 10, 1, "Output Power (dBm)", LineColor.LtRed)

    def changeContourGraphType(self, type=plotlib.PlotFigureType.SingleRectPlot):
        if not self.graphPanel.canvas0.ftype == type:
            self.graphPanel.canvas0.changeFigureType(type)
            self.updateGraphs()
            
            m1, m2 = None, None
            if self.marker1:
                m1 = self.contourImpedances[self.marker1[0]]
            if self.marker2:
                m2 = self.contourImpedances[self.marker2[0]]
            self.clearMarkers()
            self.updateMarker(m1, m2)

    def updateRectGraph1(self):
        self.graphPanel.canvas1.clearGraph()

        if self.marker1 is not None:
            gamma = self.contourReflCoeffs[self.marker1[0]]

            block = None
            for b in self.contourFile[0].flat_data:
                if gamma in (b['gamma_ld'] + b['gamma_src']):
                    block = b
                    break
            
            pout = block['pout_dbm']
            gt = block['gt_db']
            eff = block['eff_%']

            self.graphPanel.canvas1.plotPrimary(pout, gt, "M1 Gain", marker1Color, LineStyle.Solid)
            self.graphPanel.canvas1.plotSecondary(pout, eff, "M1 Efficiency", marker1Color, LineStyle.DashDot)
            self.graphPanel.canvas1.showLegend(True)

        if self.marker2 is not None:
            gamma = self.contourReflCoeffs[self.marker2[0]]

            block = None
            for b in self.contourFile[0].flat_data:
                if gamma in (b['gamma_ld'] + b['gamma_src']):
                    block = b
                    break
            
            pout = block['pout_dbm']
            gt = block['gt_db']
            eff = block['eff_%']

            self.graphPanel.canvas1.plotPrimary(pout, gt, "M2 Gain", marker2Color, LineStyle.Solid)
            self.graphPanel.canvas1.plotSecondary(pout, eff, "M2 Efficiency", marker2Color, LineStyle.DashDot)
            self.graphPanel.canvas1.showLegend(True)
    
        self.graphPanel.canvas1.setXLabel("Pout (dBm)")
        self.graphPanel.canvas1.setPrimaryYLabel("Gain (dB)")
        self.graphPanel.canvas1.setSecondaryYLabel("Efficiency (%)")

    def updateRectGraph2(self):
        if self.contourFile is None:
            return

        self.graphPanel.canvas2.clearGraph()

        data = [block.extract(self.plotAt[1],parameter=self.plotAt[0]) for block in self.contourFile[0].flat_data]

        # get contour x/y and z values
        self.rectPout, self.rectEff = [ ], [ ]
        for block in data:
            if block is not None:
                self.rectPout.append(block['pout_dbm'])
                self.rectEff.append(block['eff_%'])

        self.graphPanel.canvas2.scatterPlot(self.rectPout, self.rectEff, LineColor.DkBlue, MarkerType.plus)
        self.graphPanel.canvas2.setXLabel("Pout (dBm)")
        self.graphPanel.canvas2.setPrimaryYLabel("Efficiency (%)")

        if self.plotAt[0] == 'comp_gt':
            self.graphPanel.canvas2.setTitle("Compression = %.2fdB, Freq: %.3fGHz"%(self.plotAt[1], self.freq))
        elif self.plotAt[0] == 'pout_dbm':
            self.graphPanel.canvas2.setTitle("Pout = %.2fdBm, Freq: %.3fGHz"%(self.plotAt[1], self.freq))

class LPAGraphSummary2Controls(wx.Panel):

    lpfiles = dict()    # filename : (maury_ats_parser instance, label, color, style)
    selectedFiles = dict()

    graphPanel = None
    graphSummary1Controls = None

    marker1 = None
    marker2 = None

    reflCoeffs  = dict()

    comp        = 1.0

    Pout1       = dict()
    Gt1         = dict()
    Eff1        = dict()

    Pout2       = dict()
    Gt2         = dict()
    Eff2        = dict()

    Pout_comp   = dict()
    Gt_comp     = dict()
    Eff_comp    = dict()

    
    def __init__(self, *args, **kwargs):
        if "graphPanel" in kwargs:
            self.graphPanel = kwargs.pop("graphPanel")
        super(LPAGraphSummary2Controls, self).__init__(*args, **kwargs)
        self.initializeUIElements()
        self.initializeSizer()
        self.initializeBindings()

    def initializeUIElements(self):
        self.markerPane = LPAMarkerPane(self, label="Variable Selection")
        self.markerPane.Expand()
        self.fileSelectPane = LPAFileSelectPane(self, label="File Selection")
        self.fileSelectPane.Expand()

        self.compressionLabel = wx.StaticText(self, wx.ID_ANY, label="Compression Level: ")
        self.compressionBox = wx.TextCtrl(self, wx.ID_ANY, value="1.0", style=wx.TE_PROCESS_ENTER)
        self.compressiondBLabel=wx.StaticText(self, wx.ID_ANY, label="dB")

    def initializeSizer(self):
        self.sizer = wx.GridBagSizer(1,1)
        self.sizer.Add(self.markerPane, pos=(0,0), span=(1,3), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.fileSelectPane, pos=(1,0), span=(1,3), flag=wx.EXPAND | wx.ALL)

        self.sizer.AddSpacer((10,10), pos=(2,0))

        self.sizer.Add(self.compressionLabel, pos=(3,0), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.compressionBox, pos=(3,1), span=(1,1), flag=wx.EXPAND | wx.ALL)
        self.sizer.Add(self.compressiondBLabel, pos=(3,2), span=(1,1), flag=wx.EXPAND | wx.ALL)

        for row in range(0, self.sizer.Rows):
            self.sizer.AddGrowableRow(row)
        for col in range(0, self.sizer.Cols):
            self.sizer.AddGrowableCol(col)

        self.SetSizer(self.sizer)
    
    def initializeBindings(self):
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.onPaneChange)
        self.Bind(wx.EVT_TEXT_ENTER, self.updateComp)

    def onPaneChange(self, event=None):
        self.Layout()
        self.Parent.resize()

    def updateComp(self, event=None):
        sender = event.GetEventObject()
        compLevel = 1.0
        try:
            compLevel = float(sender.GetValue())
        except ValueError:
            showMessageDialog(self, "Invalid Entry", "Must enter a number!")

        self.comp = compLevel
        self.updateData()

    def updatePanes(self, files):
        """
        files - dict (filename : maury_ats_parser instance)
        """
        self.lpfiles = files
        self.fileSelectPane.updateFileList(self.lpfiles.keys())
        
        for filename in self.selectedFiles.keys():
            self.selectedFiles[filename] = self.lpfiles[filename]
            self.fileSelectPane.updateUIElement(filename, True)

        self.updateData()

    def updateMarker(self, marker1=None, marker2=None):
        """
        marker1, marker2 = complex (impedances)
        """
        if marker1 is not None:
            self.marker1 = marker1
            imp = marker1
            gamma = -(1/plotlib._get_normalized_impedance(marker1))
            self.markerPane.updateMarkerValues((imp, gamma), None)
            self.updateData()

        if marker2 is not None:
            self.marker2 = marker2
            imp = marker2
            gamma = -(1/plotlib._get_normalized_impedance(marker2))
            self.markerPane.updateMarkerValues(None, (imp, gamma))
            self.updateData()

    def updateMarkerFile(self, filename):
        self.markerFilename = filename
        self.markerFile = self.lpfiles[self.markerFilename]
        self.fileSelectPane.updateUIElement(filename, True)
        self.updateSelectedFiles(filename, True)
    
    def updateSelectedFiles(self, filename, selected):
        """
        filename - string
        selected - boolean
        """
        if selected:
            self.selectedFiles[filename] = self.lpfiles[filename]
            self.reflCoeffs[filename] = [ ]
            type = self.lpfiles[filename][0]._type
            harm = self.lpfiles[filename][0]._harm
            for block in self.lpfiles[filename][0].flat_data:
                if type == "loadpull":
                    self.reflCoeffs[filename].append(block._gammal[harm])
                elif type == "sourcepull":
                    self.reflCoeffs[filename].append(block._gammas[harm])
        else:
            if filename in self.selectedFiles.keys():
                self.selectedFiles.pop(filename)
                self.reflCoeffs.pop(filename)

        self.updateData()

    def updateData(self):

        self.Pout_comp.clear()
        self.Gt_comp.clear()
        self.Eff_comp.clear()

        for filename, file in self.selectedFiles.items():
            # update graphs at x-dB compression
            compData = [block.extract(self.comp, parameter='comp_gt') for block in file[0].flat_data]
            self.Pout_comp[filename] = [ ]
            self.Gt_comp[filename] = [ ]
            self.Eff_comp[filename] = [ ]
            for block in compData:
                if block is not None:
                    self.Pout_comp[filename].append(block['pout_dbm'])
                    self.Gt_comp[filename].append(block['gt_db'])
                    self.Eff_comp[filename].append(block['eff_%'])

        if self.marker1 is not None:
            self.Pout1.clear()
            self.Gt1.clear()
            self.Eff1.clear()

            for filename, file in self.selectedFiles.items():
                type = file[0]._type
                harm = file[0]._harm
                impedances = [plotlib._get_normalized_impedance(x) for x in self.reflCoeffs[filename]]
                if self.marker1 in impedances:
                    index = impedances.index(self.marker1)
                
                else:
                    showMessageDialog(self, "Invalid Impedance",
                                      "Selected file \"%s\" doesn't contain impedance %.6f + j%.6f"%(filename, self.marker1.real, self.marker1.imag))
                    self.fileSelectPane.updateUIElement(filename, False)
                    self.selectedFiles.pop(filename)
                    continue

                for block in file[0].flat_data:
                    if type == "sourcepull":
                        gamma = block._gammas[harm]
                    else:
                        gamma = block._gammal[harm]
                    if gamma == self.reflCoeffs[filename][index]:
                        self.Pout1[filename] = block['pout_dbm']
                        self.Gt1[filename] = block['gt_db']
                        self.Eff1[filename] = block['eff_%']
                        break

        if self.marker2 is not None:
            self.Pout2.clear()
            self.Gt2.clear()
            self.Eff2.clear()

            for filename, file in self.selectedFiles.items():
                type = file[0]._type
                harm = file[0]._harm
                impedances = [plotlib._get_normalized_impedance(x) for x in self.reflCoeffs[filename]]
                if self.marker2 in impedances:
                    index = impedances.index(self.marker2)

                else:
                    showMessageDialog(self, "Invalid Impedance",
                                      "Selected file \"%s\" doesn't contain impedance %.6f + j%.6f"%(filename, self.marker2.real, self.marker2.imag))
                    self.fileSelectPane.updateUIElement(filename, False)
                    self.selectedFiles.pop(filename)
                    continue

                for block in file[0].flat_data:
                    if type == "sourcepull":
                        gamma = block._gammas[harm]
                    else:
                        gamma = block._gammal[harm]
                    if gamma == self.reflCoeffs[filename][index]:
                        self.Pout2[filename] = block['pout_dbm']
                        self.Gt2[filename] = block['gt_db']
                        self.Eff2[filename] = block['eff_%']
                        break

        self.updateGraphs()

    def updateGraphs(self):
        self.graphPanel.clearGraphs()

        for filename, file in self.selectedFiles.items():
            if self.marker1 is not None:
                # plot gain/pout for M1
                self.graphPanel.canvas0.plotPrimary(self.Pout1[filename], self.Gt1[filename], file[1], ycolor=file[2], ystyle=file[3])
                self.graphPanel.canvas0.setTitle("Gain vs Pout @ Marker M1")
                self.graphPanel.canvas0.setXLabel("Pout (dBm)")
                self.graphPanel.canvas0.setPrimaryYLabel("Gain (dB)")
                self.graphPanel.canvas0.showLegend(True)
                
                # plot eff/pout for M1
                self.graphPanel.canvas3.plotPrimary(self.Pout1[filename], self.Eff1[filename], file[1], ycolor=file[2], ystyle=file[3])
                self.graphPanel.canvas3.setTitle("Efficiency vs Pout @ Marker M1")
                self.graphPanel.canvas3.setXLabel("Pout (dBm)")
                self.graphPanel.canvas3.setPrimaryYLabel("Efficiency (%)")
                self.graphPanel.canvas3.showLegend(True)

            if self.marker2 is not None:
                # plot gain/pout for M2
                self.graphPanel.canvas1.plotPrimary(self.Pout2[filename], self.Gt2[filename], file[1], ycolor=file[2], ystyle=file[3])
                self.graphPanel.canvas1.setTitle("Gain vs Pout @ Marker M2")
                self.graphPanel.canvas1.setXLabel("Pout (dBm)")
                self.graphPanel.canvas1.setPrimaryYLabel("Gain (dB)")
                self.graphPanel.canvas1.showLegend(True)

                # plot eff/pout for M2
                self.graphPanel.canvas4.plotPrimary(self.Pout2[filename], self.Eff2[filename], file[1], ycolor=file[2], ystyle=file[3])
                self.graphPanel.canvas4.setTitle("Efficiency vs Pout @ Marker M2")
                self.graphPanel.canvas4.setXLabel("Pout (dBm)")
                self.graphPanel.canvas4.setPrimaryYLabel("Efficiency (%)")
                self.graphPanel.canvas4.showLegend(True)

            # plot gain/pout @ x-dB compression
            self.graphPanel.canvas2.scatterPlot(self.Pout_comp[filename], self.Gt_comp[filename], markerStyle=MarkerType.x, label=file[1], color=file[2])
            self.graphPanel.canvas2.setTitle("Gain vs Pout @ %.2fdB Compression"%self.comp)
            self.graphPanel.canvas2.setXLabel("Pout (dBm)")
            self.graphPanel.canvas2.setPrimaryYLabel("Gain (dB)")
            self.graphPanel.canvas2.showLegend(True)

            # plot eff/pout @ x-db compression
            self.graphPanel.canvas5.scatterPlot(self.Pout_comp[filename], self.Eff_comp[filename], markerStyle=MarkerType.x, label=file[1], color=file[2])
            self.graphPanel.canvas5.setTitle("Efficiency vs Pout @ %.2fdB Compression"%self.comp)
            self.graphPanel.canvas5.setXLabel("Pout (dBm)")
            self.graphPanel.canvas5.setPrimaryYLabel("Efficiency (%)")
            self.graphPanel.canvas5.showLegend(True)

    def clearFileSelections(self):
        for filename in self.selectedFiles.keys():
            # clear UI checkboxes
            self.fileSelectPane.updateUIElement(filename, False)
            self.updateSelectedFiles(filename, False)
        
        # reset markers
        self.marker1 = None
        self.marker2 = None
        self.markerPane.updateMarkerValues(None, None)

class LPATableSummaryControls(wx.Panel):

    lpfile = None
    
    def __init__(self, *args, **kwargs):
        super(LPATableSummaryControls, self).__init__(*args, **kwargs)
    
    def initializeUIElements(self):
        self.indepParameterPane = LPAIndepParamPane(self, self.graphCanvas, wx.ID_ANY, "Independent Parameter")
        self.depParameterPane = LPADepParamPane(self, self.graphCanvas, wx.ID_ANY, "Dependent Parameters")
        self.formatPane = LPAFormatPane(self, self.graphCanvas, wx.ID_ANY, "Format")
        self.xScalingPane = LPAScalingPane(self, self.graphCanvas, RectAxis.x)
        self.y1ScalingPane = LPAScalingPane(self, self.graphCanvas, RectAxis.y1)
        self.y2ScalingPane = LPAScalingPane(self, self.graphCanvas, RectAxis.y2)
        self.smithPane = LPASmithPane(self, self.graphCanvas)
        self.polarPane = LPAPolarPane(self, self.graphCanvas)
        self.formatPane.Hide()
        self.smithPane.Hide()
        self.polarPane.Hide()

    def initializeSizer(self):
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.indepParameterPane, 0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.depParameterPane,   0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.formatPane,         0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.xScalingPane,       0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.y1ScalingPane,      0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.y2ScalingPane,      0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.smithPane,          0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.sizer.Add(self.polarPane,          0, wx.GROW | wx.ALL | wx.EXPAND, 1)
        self.SetSizer(self.sizer)
    
    def initializeBindings(self):
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.onPaneChange)
    
    def onPaneChange(self, event=None):
        self.Layout()
        self.Parent.resize()

###############################################################################
# Pane Classes
###############################################################################
class LPAFileSelectPane(wx.CollapsiblePane):
    filenames = [ ]
    UIElements = dict()
    def __init__(self, *args, **kwargs):
        super(LPAFileSelectPane, self).__init__(*args, **kwargs)
        
        pane = self.GetPane()
        pane.sizer = wx.GridBagSizer(5, 5)

        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        self.UIElements.clear()

        self.enableLabel = wx.StaticText(pane, wx.ID_ANY, label="Enable\nPlot", style=wx.ALIGN_CENTRE_HORIZONTAL)
        self.enableLabel.Hide()

        for name in self.filenames:
            elements = self.createFileUIElement(pane, name)
            self.UIElements[name] = elements
    
    def initializeSizer(self, pane):
        pane.sizer.Clear(True)
        
        if self.UIElements.keys():
            self.enableLabel.Show()
            pane.sizer.Add(self.enableLabel, pos=(0,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        else:
            return
        
        row = 1
        for element in self.UIElements.values():
            pane.sizer.Add(element[0], pos=(row,0), span=(1,1), flag=wx.EXPAND | wx.ALIGN_CENTER | wx.ALL)
            pane.sizer.Add(element[1], pos=(row,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            row += 1
        
        if not pane.sizer.IsColGrowable(0):
            pane.sizer.AddGrowableCol(0)

        pane.SetSizer(pane.sizer)
        pane.sizer.SetSizeHints(pane)
        pane.sizer.Fit(self)
        self.Parent.onPaneChange()
    
    def initializeBindings(self, pane):
        self.Bind(wx.EVT_CHECKBOX, self.updateGraph)
    
    def updateFileList(self, filenames):
        self.filenames = [ ]
        for name in filenames:
            self.filenames.append(name)
        
        self.initializeUIElements(self.GetPane())
        self.initializeSizer(self.GetPane())
        self.initializeBindings(self.GetPane())
    
    def createFileUIElement(self, pane, name):
        label = wx.StaticText(pane, wx.ID_ANY, label=name, size=(20,20), style=wx.ST_ELLIPSIZE_END)
        chkbox = wx.CheckBox(pane, wx.ID_ANY, label="")

        return (label, chkbox)
    
    def updateGraph(self, event=None):
        for filename, elements in self.UIElements.items():
            checkbox = elements[1]
            if checkbox.IsChecked():
                self.Parent.updateSelectedFiles(filename, True)
            else:
                self.Parent.updateSelectedFiles(filename, False)

    def updateUIElement(self, filename, selected):
        self.UIElements[filename][1].SetValue(selected)

class LPAContourPane(wx.CollapsiblePane):
    filenames = [ ]
    def __init__(self, *args, **kwargs):
        super(LPAContourPane, self).__init__(*args, **kwargs)
        
        pane = self.GetPane()
        pane.sizer = wx.GridBagSizer(1, 5)
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        self.rectRB = wx.RadioButton(pane, wx.ID_ANY, label="Rectangular", style=wx.RB_GROUP)
        self.smithRB = wx.RadioButton(pane, wx.ID_ANY, label="Smith")

        self.fileSelectlabel = wx.StaticText(pane, wx.ID_ANY, label="File to plot", style=wx.ALIGN_LEFT)
        self.fileSelectDropDown = wx.ComboBox(pane, wx.ID_ANY, size=(10,20), choices=self.filenames)

        self.interpGridLabel = wx.StaticText(pane, wx.ID_ANY, label="Impedance Grid Settings", style=wx.ALIGN_CENTER)
        self.xDensityLabel = wx.StaticText(pane, wx.ID_ANY, label="X Grid Density", style=wx.ALIGN_LEFT)
        self.xDensityBox = wx.TextCtrl(pane, wx.ID_ANY, value="0.01", size=(10,20), style=wx.TE_PROCESS_ENTER)
        self.yDensityLabel = wx.StaticText(pane, wx.ID_ANY, label="Y Grid Density", style=wx.ALIGN_LEFT)
        self.yDensityBox = wx.TextCtrl(pane, wx.ID_ANY, value="0.01", size=(10,20), style=wx.TE_PROCESS_ENTER)
        self.dtLabel = wx.StaticText(pane, wx.ID_ANY, label="Range Extension", style=wx.ALIGN_LEFT)
        self.extensionBox = wx.TextCtrl(pane, wx.ID_ANY, value="0.001", size=(10,20), style=wx.TE_PROCESS_ENTER)

        self.plotAtLabel = wx.StaticText(pane, wx.ID_ANY, label="Plot at:", style=wx.ALIGN_LEFT)

        self.plotAtCompRB = wx.RadioButton(pane, wx.ID_ANY, label="", style=wx.RB_GROUP)
        self.plotAtCompRBLabel = wx.StaticText(pane, wx.ID_ANY, label="Gain Compression = ", style=wx.ALIGN_LEFT)
        self.plotAtCompBox = wx.TextCtrl(pane, wx.ID_ANY, size=(30,18), value="1.0", style=wx.TE_PROCESS_ENTER)
        self.plotAtCompdBLabel = wx.StaticText(pane, wx.ID_ANY, label="dB", style=wx.ALIGN_LEFT)
        
        self.plotAtPoutRB = wx.RadioButton(pane, wx.ID_ANY, label="")
        self.plotAtPoutRBLabel = wx.StaticText(pane, wx.ID_ANY, label="Pout = ", style=wx.ALIGN_LEFT)
        self.plotAtPoutBox = wx.TextCtrl(pane, wx.ID_ANY, size=(30,18), value="20.0", style=wx.TE_PROCESS_ENTER)
        self.plotAtPoutdBLabel = wx.StaticText(pane, wx.ID_ANY, label="dBm", style=wx.ALIGN_LEFT)
        self.plotAtPoutBox.Disable()

    def initializeSizer(self, pane):
        pane.sizer.Clear(True)

        pane.sizer.Add(self.rectRB,     pos=(0,0), span=(1,2), border=2, flag=wx.ALIGN_CENTER | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.smithRB,    pos=(0,2), span=(1,2), border=2, flag=wx.ALIGN_CENTER | wx.EXPAND | wx.ALL)

        pane.sizer.Add(self.fileSelectlabel,    pos=(1,0), span=(1,4), border=2, flag=wx.ALIGN_CENTER | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.fileSelectDropDown, pos=(2,0), span=(1,4), border=2, flag=wx.ALIGN_CENTER | wx.EXPAND | wx.ALL)

        pane.sizer.Add(wx.StaticLine(pane, wx.ID_ANY, size=(1,1), style=wx.HORIZONTAL),
                       pos=(3,0), span=(1,4), border=2, flag=wx.ALIGN_CENTER | wx.EXPAND | wx.ALL)
        
        pane.sizer.Add(self.interpGridLabel,    pos=(4,0), span=(1,4), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.xDensityLabel,      pos=(5,0), span=(1,4), border=2, flag=wx.ALIGN_RIGHT| wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.xDensityBox,        pos=(6,0), span=(1,4), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.yDensityLabel,      pos=(7,0), span=(1,4), border=2, flag=wx.ALIGN_RIGHT| wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.yDensityBox,        pos=(8,0), span=(1,4), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.dtLabel,            pos=(9,0), span=(1,4), border=2, flag=wx.ALIGN_RIGHT| wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.extensionBox,       pos=(10,0), span=(1,4), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)

        pane.sizer.Add(wx.StaticLine(pane, wx.ID_ANY, size=(1,1), style=wx.HORIZONTAL),
                       pos=(11,0), span=(1,4), border=2, flag=wx.ALIGN_CENTER | wx.EXPAND | wx.ALL)

        pane.sizer.Add(self.plotAtLabel,        pos=(12,0), span=(1,4), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)

        pane.sizer.Add(self.plotAtCompRB,       pos=(13,0), span=(1,1), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.plotAtCompRBLabel,  pos=(13,1), span=(1,1), border=2, flag=wx.ALIGN_RIGHT| wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.plotAtCompBox,      pos=(13,2), span=(1,1), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.plotAtCompdBLabel,  pos=(13,3), span=(1,1), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)

        pane.sizer.Add(self.plotAtPoutRB,       pos=(14,0), span=(1,1), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.plotAtPoutRBLabel,  pos=(14,1), span=(1,1), border=2, flag=wx.ALIGN_RIGHT| wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.plotAtPoutBox,      pos=(14,2), span=(1,1), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)
        pane.sizer.Add(self.plotAtPoutdBLabel,  pos=(14,3), span=(1,1), border=2, flag=wx.ALIGN_LEFT | wx.EXPAND | wx.ALL)

        for row in range(0, pane.sizer.Rows):
            if not pane.sizer.IsRowGrowable(row):
                pane.sizer.AddGrowableRow(row)
        for col in range(0, pane.sizer.Cols):
            if not pane.sizer.IsColGrowable(col):
                pane.sizer.AddGrowableCol(col)

        pane.SetSizer(pane.sizer)
        pane.sizer.SetSizeHints(pane)
        pane.sizer.Fit(self)

    def initializeBindings(self, pane):
        self.Bind(wx.EVT_TEXT_ENTER, self.processTextBox)
        self.Bind(wx.EVT_RADIOBUTTON, self.processRadioButton)
        self.Bind(wx.EVT_COMBOBOX, self.updateFile)

    def processTextBox(self, event=None):
        sender = event.GetEventObject()
        try:
            val = float(sender.GetValue())
        except ValueError:
            showMessageDialog(self, "Invalid Entry", "Must enter a number!")
        
        # handle grid density settings
        if sender in [self.extensionBox, self.xDensityBox, self.yDensityBox]:
            if sender is self.extensionBox:
                self.Parent.setGridSettings(extension=val)
            elif sender is self.xDensityBox:
                self.Parent.setGridSettings(xdensity=val)
            elif sender is self.yDensityBox:
                self.Parent.setGridSettings(ydensity=val)

        # handle plot at settings
        else:
            self.Parent.updatePlotAt(value=val)

    def processRadioButton(self, event=None):
        sender = event.GetEventObject()

        if sender in (self.smithRB, self.rectRB):
            if self.smithRB.GetValue():
                self.Parent.changeContourGraphType(plotlib.PlotFigureType.SmithPlot)
            elif self.rectRB.GetValue():
                self.Parent.changeContourGraphType(plotlib.PlotFigureType.SingleRectPlot)

        # plotting at x-dB compression
        elif self.plotAtCompRB.GetValue():
            val = float(self.plotAtCompBox.GetValue())
            self.Parent.updatePlotAt(variable="comp_gt", value=val)
            self.plotAtPoutBox.Disable()
            self.plotAtCompBox.Enable()
        # plotting at x-dBm Pout
        elif self.plotAtPoutRB.GetValue():
            val = float(self.plotAtPoutBox.GetValue())
            self.Parent.updatePlotAt(variable="pout_dbm", value=val)
            self.plotAtCompBox.Disable()
            self.plotAtPoutBox.Enable()
    
    def updateFile(self, event=None):
        sender = event.GetEventObject()
        self.Parent.updateContourFile(sender.GetValue())
        return
    
    def updateFileList(self, filenames):
        # true if rectangular, false if smith
        contourPlotType = self.rectRB.GetValue()
        # true if plotting at x-dB compression, false if at x-dBm pout
        plotAtType = self.plotAtCompRB.GetValue()

        selectedFile = self.fileSelectDropDown.GetValue()
        self.filenames = [ ]
        for name in filenames:
            self.filenames.append(name)
        
        self.initializeUIElements(self.GetPane())
        self.initializeSizer(self.GetPane())
        self.initializeBindings(self.GetPane())

        self.rectRB.SetValue(contourPlotType)
        self.smithRB.SetValue(not contourPlotType)
        self.plotAtCompRB.SetValue(plotAtType)
        self.plotAtPoutRB.SetValue(not plotAtType)

        if selectedFile in self.fileSelectDropDown.GetItems():
            index = self.fileSelectDropDown.FindString(selectedFile)
            self.fileSelectDropDown.SetSelection(index)
    
    def updateGridDensity(self, xdensity=None, ydensity=None, extension=None):
        if xdensity is not None:
            self.xDensityBox.Value = str(xdensity)
        if ydensity is not None:
            self.yDensityBox.Value = str(ydensity)
        if extension is not None:
            self.extensionBox.Value = str(extension)

    def createFileUIElement(self, pane, name):
        label = wx.StaticText(pane, wx.ID_ANY, label=name)
        chkbox = wx.CheckBox(pane, wx.ID_ANY, label="")

        return (label, chkbox)

class LPAMarkerPane(wx.CollapsiblePane):
    variables = [ ]
    UIElements = dict()
    def __init__(self, *args, **kwargs):
        super(LPAMarkerPane, self).__init__(*args, **kwargs)
        
        pane = self.GetPane()
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        #self.variablelabel = wx.statictext(pane, wx.id_any, label="variable", style=wx.align_left)
        #self.variabledropdown = wx.combobox(pane, wx.id_any, choices=self.variables)
        
        self.marker1Label = wx.StaticText(pane, wx.ID_ANY, label="Marker 1", style=wx.ALIGN_CENTRE_HORIZONTAL)
        self.marker1RI = wx.StaticText(pane, wx.ID_ANY, label=u"Z = ", style=wx.ALIGN_LEFT)
        self.marker1MA = wx.StaticText(pane, wx.ID_ANY, label=u"\u0393 = ", style=wx.ALIGN_LEFT)

        self.marker2Label = wx.StaticText(pane, wx.ID_ANY, label="Marker 2", style=wx.ALIGN_CENTRE_HORIZONTAL)
        self.marker2RI = wx.StaticText(pane, wx.ID_ANY, label=u"Z = ", style=wx.ALIGN_LEFT)
        self.marker2MA = wx.StaticText(pane, wx.ID_ANY, label=u"\u0393 = ", style=wx.ALIGN_LEFT)

        for elem in [self.marker1MA, self.marker1RI]:
            elem.SetForegroundColour(_colorLUT(marker1Color))
        for elem in [self.marker2MA, self.marker2RI]:
            elem.SetForegroundColour(_colorLUT(marker2Color))
    
    def initializeSizer(self, pane):
        pane.sizer = wx.BoxSizer(wx.VERTICAL)
        #pane.sizer.Add(self.variableLabel, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        #pane.sizer.Add(self.variableDropDown, border=20, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        #pane.sizer.AddSpacer(10)
        #pane.sizer.Add(wx.StaticLine(pane, wx.ID_ANY, size=(1,1), style=wx.LI_HORIZONTAL), border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        #pane.sizer.AddSpacer(10)
        pane.sizer.Add(self.marker1Label, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.sizer.Add(self.marker1RI, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.sizer.Add(self.marker1MA, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.sizer.AddSpacer(10)
        pane.sizer.Add(wx.StaticLine(pane, wx.ID_ANY, size=(1,1), style=wx.LI_HORIZONTAL), border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.sizer.AddSpacer(10)
        pane.sizer.Add(self.marker2Label, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.sizer.Add(self.marker2RI, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.sizer.Add(self.marker2MA, border=10, flag=wx.EXPAND | wx.LEFT | wx.RIGHT)
        pane.SetSizer(pane.sizer)
        pane.sizer.SetSizeHints(pane)
        pane.sizer.Fit(self)
        self.Parent.onPaneChange()
    
    def initializeBindings(self, pane):
        #self.Bind(wx.EVT_COMBOBOX, self.updateGraph)
        return
    
    #def updateVariableList(self, variables):
    #    self.variableDropDown.Clear()
    #    for var in variables:
    #        if not var == "Pin_avail":
    #            self.variableDropDown.Insert(var, self.variableDropDown.Count)

    #        self.variableDropDown.Select(0)
    
    def updateMarkerValues(self, marker1=None, marker2=None):
        """
        marker1, marker2 - (complex, complex) -- (impedance, refl_coeff)
        """
        if marker1 is not None:
            self.marker1RI.SetLabel(u"Z = %f + j%f \u2126"%(marker1[0].real, marker1[0].imag))
            self.marker1MA.SetLabel(u"\u0393 = %.5f \u2220 %.2f \u00b0"%(abs(marker1[1]), phase(marker1[1])*180/pi))

        elif marker2 is not None:
            self.marker2RI.SetLabel(u"Z = %f + j%f \u2126"%(marker2[0].real, marker2[0].imag))
            self.marker2MA.SetLabel(u"\u0393 = %.5f \u2220 %.2f \u00b0"%(abs(marker2[1]), phase(marker2[1])*180/pi))

        elif marker1 is None and marker2 is None:
            self.marker1RI.SetLabel(u"Z = ")
            self.marker1MA.SetLabel(u"\u0393 = ")
            self.marker2RI.SetLabel(u"Z = ")
            self.marker2MA.SetLabel(u"\u0393 = ")

class LPAFreqPane(wx.CollapsiblePane):
    frequencies = [ ]
    def __init__(self, *args, **kwargs):
        super(LPAFreqPane, self).__init__(*args, **kwargs)
        
        pane = self.GetPane()
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        self.freqDropDown = wx.ComboBox(pane, wx.ID_ANY, choices=self.frequencies)
        self.freqDropDown.SetSelection(0)
    
    def initializeSizer(self, pane):
        pane.sizer = wx.BoxSizer(wx.VERTICAL)
        pane.sizer.Add(self.freqDropDown, 0, wx.GROW | wx.ALL, 2)
        pane.SetSizer(pane.sizer)
    
    def initializeBindings(self, pane):
        self.Bind(wx.EVT_COMBOBOX, self.updateFreq)
    
    def updateFreq(self, event=None):
        parameter = self.freqDropDown.GetValue()

    def updateFreqList(self, frequencies):
        """
        frequencies - [ double ]
        """
        self.frequencies = [ ]
        for freq in frequencies:
            self.frequencies.append(freq)
        self.freqDropDown.Clear()
        self.freqDropDown.SetItems([str(x) + " GHz" for x in self.frequencies])

class LPAIndepParamPane(wx.CollapsiblePane):
    def __init__(self, parent, graphCanvas, *args, **kwargs):
        super(LPAIndepParamPane, self).__init__(parent, *args, **kwargs)
        
        self.initializeUIElements()
        self.initializeSizer()
        self.initializeBindings()
    
    def initializeUIElements(self):
        self.GetPane().parameterDropDown = wx.ComboBox(self.GetPane(), wx.ID_ANY, choices=indep_plot_params)
        self.GetPane().parameterDropDown.SetSelection(0)
    
    def initializeSizer(self):
        self.GetPane().sizer = wx.BoxSizer(wx.VERTICAL)
        self.GetPane().sizer.Add(self.GetPane().parameterDropDown, 0, wx.GROW | wx.ALL, 2)
        self.GetPane().SetSizer(self.GetPane().sizer)
    
    def initializeBindings(self):
        self.Bind(wx.EVT_COMBOBOX, self.updateIndepParameter)
    
    def updateIndepParameter(self, event=None):
        parameter = self.GetPane().parameterDropDown.GetValue()
        self.Parent.updateIndependentParam(parameter)

class LPADepParamPane(wx.CollapsiblePane):
    def __init__(self, parent, graphCanvas, *args, **kwargs):
        super(LPADepParamPane, self).__init__(parent, *args, **kwargs)
        
        pane = self.GetPane()
        pane.sizer = wx.GridBagSizer(1, 5)
        self.parameterUI = dict() # string : 3-tuple of UI elements
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        self.Y1Label = wx.StaticText(pane, wx.ID_ANY, label="Primary\nY-Axis", style=wx.ALIGN_CENTRE_HORIZONTAL)
        self.Y2Label = wx.StaticText(pane, wx.ID_ANY, label="Secondary\nY-Axis", style=wx.ALIGN_CENTRE_HORIZONTAL)
        for param in dep_plot_params:
            elements = self.createParameterUIElement(pane, param)
            self.parameterUI[param] = elements
    
    def initializeSizer(self, pane):
        pane.sizer.Add(self.Y1Label, pos=(0,0), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(self.Y2Label, pos=(0,2), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        
        row = 1
        for paramUI in self.parameterUI.values():
            pane.sizer.Add(paramUI[0], pos=(row, 0), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            pane.sizer.Add(paramUI[1], pos=(row, 1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            pane.sizer.Add(paramUI[2], pos=(row, 2), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
            row += 1
        
        pane.SetSizer(pane.sizer)
        pane.Layout()
        self.Layout()
    
    def initializeBindings(self, pane):
        self.Bind(wx.EVT_CHECKBOX, self.updateGraphDependentParams)
    
    def createParameterUIElement(self, pane, parameter):
        """
        Creates and returns the checkboxes and labels corresponding to a single dependent parameter
        """
        Y1ChkBox = wx.CheckBox(pane, wx.ID_ANY, label="")
        ParamLabel = wx.StaticText(pane, wx.ID_ANY, label=parameter)
        Y2ChkBox = wx.CheckBox(pane, wx.ID_ANY, label="")
        
        return Y1ChkBox, ParamLabel, Y2ChkBox
    
    def updateGraphDependentParams(self, event=None):
        sender = event.GetEventObject()
        
        for paramUI in self.parameterUI.values():    
            parameter = paramUI[1].GetLabel()
            
            if paramUI[0] is sender and paramUI[0].IsChecked():
                paramUI[2].SetValue(False)
                self.Parent.removeDependentParam(param2=parameter)
                self.Parent.addDependentParam(param1=parameter)
                
            elif paramUI[2] is sender and paramUI[2].IsChecked():
                paramUI[0].SetValue(False)
                self.Parent.removeDependentParam(param1=parameter)
                self.Parent.addDependentParam(param2=parameter)
                
            elif not paramUI[0].IsChecked() and not paramUI[2].IsChecked():
                self.Parent.removeDependentParam(parameter, parameter)
    
    def updateCheckboxUI(self, parameter, axis):
        for paramUI in self.parameterUI.values():
            if paramUI[1].GetLabel() == parameter:
                if axis == RectAxis.y1:
                    paramUI[0].SetValue(True)
                elif axis == RectAxis.y2:
                    paramUI[2].SetValue(True)

class LPAFormatPane(wx.CollapsiblePane):
    def __init__(self, parent, graphCanvas, *args, **kwargs):
        super(LPAFormatPane, self).__init__(parent, *args, **kwargs)

class LPAScalingPane(wx.CollapsiblePane):
    axis = RectAxis.x
    graphCanvas = None
    def __init__(self, parent, graphCanvas, axis=RectAxis.x, *args, **kwargs):
        self.axis = axis
        self.graphCanvas = graphCanvas
        
        title = ""
        if axis == RectAxis.x:
            title = "X-Axis Scaling"
        elif axis == RectAxis.y1:
            title = "Primary Y-Axis Scaling"
        elif axis == RectAxis.y2:
            title = "Secondary Y-Axis Scaling"
        else:
            title = "TODO"
        kwargs['label'] = title
        super(LPAScalingPane, self).__init__(parent, *args, **kwargs)
        
        pane = self.GetPane()
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        pane.autoLabel = wx.StaticText(pane, wx.ID_ANY, label="Auto")
        
        pane.minLabel = wx.StaticText(pane, wx.ID_ANY, label="Min")
        pane.minBox = wx.TextCtrl(pane, wx.ID_ANY, value="0.0", style=wx.TE_PROCESS_ENTER)
        pane.minAuto = wx.CheckBox(pane, wx.ID_ANY, label="")
        
        pane.maxLabel = wx.StaticText(pane, wx.ID_ANY, label="Max")
        pane.maxBox = wx.TextCtrl(pane, wx.ID_ANY, value="1.0", style=wx.TE_PROCESS_ENTER)
        pane.maxAuto = wx.CheckBox(pane, wx.ID_ANY, label="")
        
        pane.linRB = wx.RadioButton(pane, wx.ID_ANY, label="Linear", style=wx.RB_GROUP)
        pane.logRB = wx.RadioButton(pane, wx.ID_ANY, label="Logarithmic")
        
    def initializeSizer(self, pane):
        pane.sizer = wx.GridBagSizer(1, 5)
        pane.sizer.Add(pane.autoLabel, pos=(0,2), span=(1,1), flag=wx.ALIGN_LEFT | wx.ALL)
        
        pane.sizer.Add(pane.minLabel, pos=(1,0), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.minBox, pos=(1,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.minAuto, pos=(1,2), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        
        pane.sizer.Add(pane.maxLabel, pos=(2,0), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.maxBox, pos=(2,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.maxAuto, pos=(2,2), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        
        pane.sizer.Add(pane.linRB, pos=(3,0), span=(1,3), flag=wx.ALIGN_LEFT | wx.ALL)
        
        pane.sizer.Add(pane.logRB, pos=(4,0), span=(1,3), flag=wx.ALIGN_LEFT | wx.ALL)
        
        pane.SetSizer(pane.sizer)
        pane.sizer.SetSizeHints(pane)
        pane.sizer.Fit(self)
    
    def initializeBindings(self, pane):
        self.Bind(wx.EVT_TEXT_ENTER, self.updateGraphAxisLimits)
        self.Bind(wx.EVT_RADIOBUTTON, self.updateGraphAxisScaling)
        self.Bind(wx.EVT_CHECKBOX, self.updateGraphAutoscale)
    
    def updateGraphAxisLimits(self, event=None):
        pane = self.GetPane()
        
        limits = (float(pane.minBox.GetValue()), float(pane.maxBox.GetValue()))
        
        if self.axis == RectAxis.x:
            self.graphCanvas.setAxisLimits(limits, None, None)
        elif self.axis == RectAxis.y1:
            self.graphCanvas.setAxisLimits(None, limits, None)
        elif self.axis == RectAxis.y2:
            self.graphCanvas.setAxisLimits(None, None, limits)
    
    def updateGraphAxisScaling(self, event=None):
        pane = self.GetPane()
        
        if pane.linRB.GetValue():
            scale = "linear"
        elif pane.logRB.GetValue():
            scale = "log"
        
        if self.axis == RectAxis.x:
            self.graphCanvas.setAxisScaling(scale, None, None)
        elif self.axis == RectAxis.y1:
            self.graphCanvas.setAxisScaling(None, scale, None)
        elif self.axis == RectAxis.y2:
            self.graphCanvas.setAxisScaling(None, None, scale)
    
    def updateGraphAutoscale(self, event=None):
        pane = self.GetPane()
        if pane.minAuto.IsChecked():
            pane.minBox.Disable()
            if self.axis == RectAxis.x:
                pane.minBox.SetValue(str(self.graphCanvas.getAutoScaleLimits()[0][0]))
            elif self.axis == RectAxis.y1:
                pane.minBox.SetValue(str(self.graphCanvas.getAutoScaleLimits()[1][0]))
            elif self.axis == RectAxis.y2:
                pane.minBox.SetValue(str(self.graphCanvas.getAutoScaleLimits()[2][0]))
        else:
            pane.minBox.Enable()
        
        if pane.maxAuto.IsChecked():
            pane.maxBox.Disable()
            if self.axis == RectAxis.x:
                pane.maxBox.SetValue(str(self.graphCanvas.getAutoScaleLimits()[0][1]))
            elif self.axis == RectAxis.y1:
                pane.maxBox.SetValue(str(self.graphCanvas.getAutoScaleLimits()[1][1]))
            elif self.axis == RectAxis.y2:
                pane.maxBox.SetValue(str(self.graphCanvas.getAutoScaleLimits()[2][1]))
        else:
            pane.maxBox.Enable()
        
        self.updateGraphAxisLimits()
    
    def updateGraphAutoscaleUI(self, min=True, max=True):
        pane = self.GetPane()
        if min:
            pane.minAuto.SetValue(True)
        if max:
            pane.maxAuto.SetValue(True)
        self.updateGraphAutoscale()

class LPASmithPane(wx.CollapsiblePane):
    def __init__(self, parent, graphCanvas, *args, **kwargs):
        kwargs['label'] = "Smith Chart Options"
        super(LPASmithPane, self).__init__(parent, *args, **kwargs)
        
        pane = self.GetPane()
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        pane.Z0Label1 = wx.StaticText(pane, wx.ID_ANY, label="Z0 = ")
        pane.Z0Box1 = wx.TextCtrl(pane, wx.ID_ANY, value="50", size=(35,22))
        pane.Z0Label2 = wx.StaticText(pane, wx.ID_ANY, label=" + j")
        pane.Z0Box2 =  wx.TextCtrl(pane, wx.ID_ANY, value="0", size=(35,22))
        
        pane.ReImRB = wx.RadioButton(pane, wx.ID_ANY, label="Re/Im", style=wx.RB_GROUP)
        pane.MARB = wx.RadioButton(pane, wx.ID_ANY, label="Mag/Ang")
        
        pane.ImpedanceBox = wx.CheckBox(pane, wx.ID_ANY, label="Impedance Grid")
        
        pane.AdmittanceBox = wx.CheckBox(pane, wx.ID_ANY, label="Admittance Grid")
    
    def initializeSizer(self, pane):
        pane.sizer = wx.GridBagSizer(5, 5)
        
        pane.sizer.Add(pane.Z0Label1,        pos=(0,0),    span=(1,1), flag=wx.ALIGN_LEFT | wx.ALL)
        pane.sizer.Add(pane.Z0Box1,            pos=(0,1),    span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.Z0Label2,        pos=(0,2),    span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.Z0Box2,            pos=(0,3),    span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        
        pane.sizer.Add(pane.ReImRB,            pos=(1,0),    span=(1,2), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.MARB,            pos=(1,2),    span=(1,2), flag=wx.ALIGN_CENTER | wx.ALL)
        
        pane.sizer.Add(pane.ImpedanceBox,    pos=(2,0),    span=(1,4), flag=wx.ALIGN_LEFT | wx.ALL)
        
        pane.sizer.Add(pane.AdmittanceBox,    pos=(3,0),    span=(1,4), flag=wx.ALIGN_LEFT | wx.ALL)
        
        pane.SetSizer(pane.sizer)
        pane.sizer.SetSizeHints(pane)
        pane.sizer.Fit(self)
    
    def initializeBindings(self, pane):
        self.Bind(wx.EVT_RADIOBUTTON, self.convertZ0)
    
    def convertZ0(self, event=None):
        pane = self.GetPane()
        Z0 = None
        try:
            # converting from Mag/Ang to Re/Im
            if pane.ReImRB.GetValue():
                Z0 = plotlib._MA_to_complex(
                        float(pane.Z0Box1.Value),
                        float(pane.Z0Box2.Value))
                pane.Z0Box1.Value = str(Z0.real)
                pane.Z0Box2.Value = str(Z0.imag)
                pane.Z0Label2.SetLabel("+ j")
            
            # Converting from Re/Im to Mag/Ang
            elif pane.MARB.GetValue():
                Z0 = plotlib._RI_to_complex(
                        float(pane.Z0Box1.Value),
                        float(pane.Z0Box2.Value))
                pane.Z0Box1.Value = str(abs(Z0))
                pane.Z0Box2.Value = str(phase(Z0)*180.0/pi)
                pane.Z0Label2.SetLabel(u'  \u2220')
            
            self.updateReferenceImpedance(Z0)
        
        except ValueError:
            if pane.ReImRB.GetValue():
                pane.MARB.SetValue(True)
            else:
                pane.ReImRB.SetValue(True)
            dlg = wx.MessageDialog(    self, "Invalid value for Z0, must enter a number!",
                                    caption="Invalid Value",
                                    style=wx.OK)
            dlg.ShowModal()
    
    def updateReferenceImpedance(self, impedance):
        print "TODO"
        return

class LPAPolarPane(wx.CollapsiblePane):
    def __init__(self, parent, graphCanvas, *args, **kwargs):
        kwargs['label'] = "Polar Chart Options"
        super(LPAPolarPane, self).__init__(parent, *args, **kwargs)
        
        pane = self.GetPane()
        
        self.initializeUIElements(pane)
        self.initializeSizer(pane)
        self.initializeBindings(pane)
    
    def initializeUIElements(self, pane):
        pane.autoLabel = wx.StaticText(pane, wx.ID_ANY, label="Auto")
        
        pane.maxLabel = wx.StaticText(pane, wx.ID_ANY, label="Max")
        pane.maxBox = wx.TextCtrl(pane, wx.ID_ANY, value="1.0")
        pane.maxAuto = wx.CheckBox(pane, wx.ID_ANY, label="")
    
    def initializeSizer(self, pane):
        pane.sizer = wx.GridBagSizer(1, 5)
        pane.sizer.Add(pane.autoLabel, pos=(0,2), span=(1,1), flag=wx.ALIGN_LEFT | wx.ALL)
        
        pane.sizer.Add(pane.maxLabel, pos=(1,0), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.maxBox, pos=(1,1), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        pane.sizer.Add(pane.maxAuto, pos=(1,2), span=(1,1), flag=wx.ALIGN_CENTER | wx.ALL)
        
        pane.SetSizer(pane.sizer)
        pane.sizer.SetSizeHints(pane)
        pane.sizer.Fit(self)
    
    def initializeBindings(self, pane):
        self.Bind(wx.EVT_TEXT_ENTER, self.updateGraphAxisLimits)
        self.Bind(wx.EVT_CHECKBOX, self.updateGraphAutoscale)
    
    def updateGraphAxisLimits(self, event=None):
        pane = self.GetPane()
        
        limit = float(pane.maxBox.GetValue())
        self.graphCanvas.setPolarMax(limit)
    
    def updateGraphAutoscale(self, event=None):
        pane = self.GetPane()
        if pane.maxAuto.IsChecked():
            pane.maxBox.Disable()
            # TODO - handle setting limits from graph data
        else:
            pane.maxBox.Enable()

###############################################################################
# Frame Class
###############################################################################
class LPAFrame(wx.Frame):
    filepaths = None
    filenames = None
    
    def __init__(self, *args, **kwargs):    
        self.filepaths = kwargs.pop('filepaths')
        self.filenames = kwargs.pop('filenames')
        super(LPAFrame, self).__init__(*args, **kwargs)
        self.InitUI()
    
    def InitUI(self):
        
        menubar = wx.MenuBar()
        
        fileMenu = wx.Menu()
        
        qmi = wx.MenuItem(fileMenu, wx.ID_EXIT, '&Quit\tCtrl+W')
        fileMenu.AppendItem(qmi)
        
        menubar.Append(fileMenu, '&File')
        self.SetMenuBar(menubar)
        
        self.SetSize(wx.Size(1000,800))
        self.SetTitle('Load Pull Analyzer')
        
        # splitter windows for basic panel layout
        self.horizontalSplitter = wx.SplitterWindow(self)
        self.verticalSplitter = wx.SplitterWindow(self.horizontalSplitter)
        self.horizontalSplitter.SetMinimumPaneSize(150)
        self.verticalSplitter.SetMinimumPaneSize(250)
        
        # create container panels
        self.controlsContainer = LPAControlContainer(self.verticalSplitter, wx.ID_ANY)
        self.graphsContainer = LPAGraphContainer(self.verticalSplitter, wx.ID_ANY)
        self.dataContainer = LPADataContainer(self.horizontalSplitter, wx.ID_ANY)
        containers = [self.controlsContainer, self.graphsContainer, self.dataContainer]
        
        for container in containers:
            container.graphContainer = self.graphsContainer
            container.controlContainer = self.controlsContainer
            container.dataContainer = self.dataContainer

        self.controlsContainer.initialize()
        
        # lay out panels
        self.verticalSplitter.SplitVertically(self.controlsContainer, self.graphsContainer)
        self.horizontalSplitter.SplitHorizontally(self.verticalSplitter, self.dataContainer)
        
        self.Bind(wx.EVT_MENU, self.OnQuit, qmi)
        self.Bind(wx.EVT_SIZE, self.OnResize)
        
        self.Show(True)

        if self.filepaths and self.filenames:
            self.dataContainer.loadDataFiles(self.filepaths, self.filenames)
        
    def OnResize(self, e):
        self.verticalSplitter.SetSashPosition(200)
        self.horizontalSplitter.SetSashPosition(self.GetSize()[1]-225)
        e.Skip()
        
    def OnQuit(self, e):
        self.Close()

def main():
    
    ex = wx.App()
    names = [ ]
    paths = [ ]
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            if os.path.isfile(arg):
                paths.append(arg)
                names.append(os.path.basename(arg))
    LPAFrame(None, filepaths=paths, filenames=names)
    ex.MainLoop()

if __name__ == '__main__':
    main()
