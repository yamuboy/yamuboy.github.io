
import visa
import datetime
import numpy as np
import matplotlib.pyplot as plt
import os
import math
from matplotlib.lines import Line2D
import colorsys


########################Ask to input the file name#####################################
"""
fname=[]
while not fname:
        fname = raw_input('Output file name? ').strip()

"""        

#########################################################################################
#########################################################################################

###########################################Connect to the instrument PNA N5222A #####################################

Address3='TCPIP0::192.168.1.5::inst0::INSTR' ## PNA N5222A adress

rm = visa.ResourceManager()  ## define rm as resource Manager

PNA=rm.get_instrument(Address3)
PNA.write("*RST")       ## Reset PNA instrument (Default: S11, f=10MHz-26.5GHz, P = -5dBm)
print(PNA.ask("*IDN?")) ## print PNA Address

#########################Connect to the instrument#################################################################
####################################################################################################################


#################################Set the power sweep###################################################################

PNA.write('SENS:SWE:TYPE LIN') ## set sweep type to Lin
##PNA.ask('SENS:SWE:TYPE?')
PNA.write('SENS:SWE:TYPE POW') ## set sweep type to POWER

PNA.write('SENS:FEQ:CW 2 GHZ') ## set CW frequency in GHz

PNA.write('SOUR:POW:COUP OFF') ## set port source couple off

PNA.write('SOUR:POW1:ATT 20')  ## source attenuation need to be set fisrt if source power < -30 dbm (here min P = -30-20=50 dBm)

PNA.write('SOUR:POW1:PORT:STAR -40') ## set start sweep POWER to -40dbm

PNA.write('SOUR:POW1:PORT:STOP -30') ## set start sweep POWER to -30dbm

PNA.write('SYST:POW1:LIM 0')    ### This sets the limit on or off
## set the source power Max limit to 0 dBm to SOA

PNA.write('SYST:POW1:LIM:STAT 1')    ## Enable (1) or disable (0) the power limit for the specified port
## PNA.ask('SYST:POW1:LIMit:STATe?') ##ask the enable or disable state

PNA.write('SOUR:POW1:ALC:REC:OFFS 25')  ##Sets and returns the power level offset value
PNA.write('SENSe:POWer:ATTenuator ARECeiver,20 ') # Receiver A attenuator in -dBm
#
PNA.write('CALCulate1:PARameter:DEFine "S21cal",S21 ')
# calculate s21 parameter
PNA.write('DISPlay:WINDow1:TRACe3:FEED "S21cal" ')
# Display S21 on screen
PNA.write('HCOPy:FILE "test" ')
# save screen on hard drive in png format
#
PNA.write('MMEMory:MDIRectory "c:/Frankgao_test"')
# creat a new folder
PNA.write('MMEMory:STORe:DATA "testdata.csv","csv","Trace","DISPLAYed",2 ')
# store displayed measurement data to hard drive, default directory in c/program file/Angilent/network analyzer

      


