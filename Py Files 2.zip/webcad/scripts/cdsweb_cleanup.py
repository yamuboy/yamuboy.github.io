#!/usr/bin/env python2.6

import os, sys, os.path
from datetime import datetime, timedelta

def _getpath():
    base = os.path.dirname(sys._getframe(1).f_code.co_filename)
    if base == '.':
        base = os.getcwd()
    return base
    
def main():
    "main routine"
    # determine the path for the package directory
    p = os.path.dirname(_getpath())
    if not p:
        p = os.path.dirname(os.getcwd())
    if p not in sys.path:
        sys.path.insert(0,p)
	    
    # set up django
    os.environ['DJANGO_SETTINGS_MODULE'] = 'mysite.settings'
    
    # import stuff that hooks into django
    from django.conf import settings
    from cdsweb.models import Attachment, AssuraLVSJob, AssuraDRCJob, AssuraJobHistory, GDSRewriteJob
    
    now = datetime.now()
    now_minus90 = now - timedelta(days=90)
    
    # find all expired attachments
    Attachment.objects.filter(expires__lt=now).delete()
    
    # find all old Assura DRC, Assura LVS, Assura job history, and GDS Rewrite instances
    # and clean them out of the database
    AssuraLVSJob.objects.filter(submit_date__lt=now_minus90).delete()
    AssuraDRCJob.objects.filter(submit_date__lt=now_minus90).delete()
    GDSRewriteJob.objects.filter(submit_date__lt=now_minus90).delete()
    AssuraJobHistory.objects.filter(datestamp__lt=now_minus90).delete()

    # delete any files in the data directory that do not have an associated
    # Attachment object in the database
    valid_files = set()
    for att in Attachment.objects.all():
        valid_files.add(str(att.id))

    datapath = settings.CDSWEB_DATA_PATH
    for fname in os.listdir(datapath):
        if os.path.isfile(os.path.join(datapath,fname)) and fname not in valid_files:
            os.unlink(os.path.join(datapath,fname))

    
if __name__ == '__main__':
    # script entry point
    main()
     
        
        
