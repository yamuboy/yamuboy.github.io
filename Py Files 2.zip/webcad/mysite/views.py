from django.http import HttpResponse, Http404
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.conf import settings
from django.contrib import messages

from cdsweb.utils import default_cdsweb_context

def home(request):
    "home page view"
    return render(request,'home_page.htm',default_cdsweb_context())


def documentation(request):
    "documentation page view"
    return render(request,'documentation.htm',default_cdsweb_context())
    
def tools(request):
    "tools page view"
    return render(request,'tools.htm',default_cdsweb_context())
    
def redirect_to_lvs(request):
    "redirect to the LVS submission page"
    return redirect('cdsweb.assura_views.lvs_submit')
    
def redirect_to_drc(request):
    "redirect to the DRC submission page"
    return redirect('cdsweb.assura_views.drc_submit')    