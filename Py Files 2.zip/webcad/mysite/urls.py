from django.conf.urls import patterns, include, url

urlpatterns = patterns('mysite.views',
    url(r'^$','home'),
    url(r'^docs/$','documentation'),
    url(r'^tools/$','tools'),
    url(r'^verify/',include('cdsweb.assura_urls')),
    url(r'^gdsii/',include('cdsweb.gds_urls')),
    url(r'^qsrv/',include('cdsweb.qserve_urls')),
    url(r'^ajax/',include('cdsweb.ajax_urls')),
    url(r'^fndry/',include('cdsweb.foundry_urls')),
    url(r'^alvs/submit/$','redirect_to_lvs'),
    url(r'^adrc/submit/$','redirect_to_drc'),
)
