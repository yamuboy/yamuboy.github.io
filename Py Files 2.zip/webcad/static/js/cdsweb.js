
/**
 * define tooltips
 */
var Tooltip = {
    show_tooltip: function($el) {
        var $w = $('#tooltip-window')
        var $sh = $('#tooltip-window-shim')
        var offset = $el.offset()
        var $body = $(document.body)
        var x = (offset.left+$el.width()+6)+'px'
        var y = (offset.top+$el.height()+2)+'px'
        $w.html($el.attr('tooltiptext'))
        $w.css( { left:x, top:y} )
        var w = $w.width()+'px'
        var h = $w.height()+'px'
        $sh.css( { left:x, top:y, width:w, height:h} )
        $sh.show()
        $w.show('fast')
    },

    hide_tooltip: function() {
        var $w = $('#tooltip-window')
        var $sh = $('#tooltip-window-shim')
        $sh.hide()
        $w.hide('fast')
    },
    
    _showtimer: null
}    
    

/**
 * stuff to do when the page loads
 */
$(document).ready(function() {
    /**
     * handle "expandable" sections of the page
     */
    // attach the expander code to expand-section divs
    $('div.expand-section').each(function() {
        var es = $(this);
        var expander = es.children('.expander');
        var expandcontent = es.children('.expand-content');
        // hide all images in the expander
        expander.find('img').hide()
        if( es.hasClass('show-expanded') ) {
            // show the expand content and the collapse image
            expandcontent.show();
            expandcontent.addClass('_isexpanded');
            expander.find('img.collapse').show();
        }
        else {
            // hide the expand content and show the expand image
            expandcontent.hide();
            expandcontent.removeClass('_isexpanded');
            expander.find('img.expand').show();
        }
        // attach a function to toggle the expand content
        var f = function() {
            if( expandcontent.hasClass('_isexpanded') ) {
                // collapse the content and swap the image
                expander.find('img.collapse').hide();
                expander.find('img.expand').show();
                expandcontent.slideUp('fast');
                expandcontent.removeClass('_isexpanded');
            }
            else {
                // expand the content and swap the image
                expander.find('img.expand').hide();
                expander.find('img.collapse').show();
                expandcontent.slideDown('fast');
                expandcontent.addClass('_isexpanded');
            }
        };
        expander.find('span.toggle').click(f);
        expander.find('img').click(f);
    });
    
    /*
     * initialize tooltips
     */
    var $tips = $('.tooltip');
    if( ! $tips.length )
        return;
    
    // add the tooltip DOM elements to the page
    $ttip = $('<div id="tooltip-window" style="position:absolute; display:none;">')
    $shim = $('<iframe id="tooltip-window-shim" style="position:absolute; display:none;">')
    $(document.body).append($ttip,$shim)
    
    // add the tooltip code to each element
    $tips.each(function() {
        var $el = $(this);
        if( $el.attr('tooltiptext').length ) {
            $el.bind('mouseover', function(e) {
                if( typeof Tooltip._showtimer == "number" ) {
                    // cancel the current timer
                    window.clearTimeout(Tooltip._showtimer)
                }
                Tooltip._showtimer = window.setTimeout(
                    function() { Tooltip._showtimer = null; Tooltip.show_tooltip($el) },
                    300
                )
            })
            $el.bind('mouseout', function(e) {
                if( typeof Tooltip._showtimer == "number" ) {
                    // cancel the current timer
                    window.clearTimeout(Tooltip._showtimer)
                    Tooltip._showtimer = null
                }
                Tooltip.hide_tooltip();
            })
        }
    })
    
});

/**
 * define a function for building deck information tables from JSON AJAX data
 */

function webcad_create_deckinfo_table( deckinfo, process )
{
    if( !deckinfo.length ) {
        return $('<p class="note">No deck info available.</p>')
    }
    
    var $table = $('<table class="padded">')
    var $tr = $('<tr>')
    $tr.append('<th>Deck File</th>')
    $tr.append('<th>Last Modified</th>')
    $tr.append('<th>&nbsp;</th>')
    $table.append($tr)
    var $td, d, fdate, args;
    for( var i=0; i<deckinfo.length; ++i ) {
        d = deckinfo[i]
        $tr = $('<tr>')
        if( i%2 ) $tr.addClass('odd');
        else $tr.addClass('even');
        
        $tr.append('<td>'+d.name+'</td>')
        $tr.append('<td>'+d.last_modified+'</td>')
        args = "'"+process+"', '"+d.name+"'"
        $tr.append('<td><a href="#" onclick="show_deck_info('+args+'); return false;">details</a></td>')

        $table.append($tr)
    }
    
    return $table
}

/**
 * define a function for building switch selection tables from JSON AJAX data
 */
 
function webcad_create_switch_table( swinfo )
{
    if( !swinfo.length ) {
        return $('<p class="note">No process switches</p>')
    }
    
    var $table = $('<table class="padded">')
    var $tr = $('<tr>')
    $tr.append('<th>Switch Name</th>')
    $tr.append('<th>Value</th>')
    $tr.append('<th>Description</th>')
    $table.append($tr)
    var name
    for( var i=0; i<swinfo.length; ++i ) {
        d = swinfo[i]
        $tr = $('<tr>')
        if( i%2 ) $tr.addClass('odd');
        else $tr.addClass('even');
        
        if( d.label ) name = d.label
        else name = d.name
        
        $tr.append('<td>'+name+'</td>')                    
        if( d.type == 'select' ) {
            // create a select input
            var $td = $('<td class="acenter">')
            var $sel = $('<select>')
            $sel.attr('name','sw_'+d.name)
            var $opt, e;
            for( var j=0; j<d.entries.length; ++j ) {
                e = d.entries[j]
                var $opt = $('<option>'+e.label+'</option>')
                $opt.val(e.value)
                if( e.selected ) $opt.attr('selected','selected')                     
                $sel.append($opt)
            }
            $td.append($sel)
            $tr.append($td)
        }
        else {
            // create a checkbox input
            var $td = $('<td class="acenter">')
            var $chk = $('<input type="checkbox" value="t">')
            $chk.attr('name','sw_'+d.name)
            if( d.checked ) $chk.prop('checked',true)                     
            $td.append($chk)
            $tr.append($td)
        }
        $tr.append('<td>'+d.desc+'</td>')
        $table.append($tr)
    }
    
    return $table
}



