from django.http import HttpResponse, Http404
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.conf import settings
from django.contrib import messages

from cdsweb.qserver import qserver_connect
from cdsweb.utils import default_cdsweb_context

def home(request):
    "qserver main status page"
    context = default_cdsweb_context()
    
    srv_stat = '(unknown)'
    queued = []
    
    try:
        if settings.CDSWEB_TEST_MODE:
            srv_stat = 'demo mode'
        else:
            c = qserver_connect(authenticate=True)
            # get qserver status
            srv_stat = c.command('status')['status']
            # get queued jobs
            queued = c.command('showqueue')
            c.close()
    except Exception, e:
        messages.add_message(request,messages.ERROR,'Error: %s'%e)
    
    context['queue_status'] = srv_stat
    context['queued_jobs'] = queued    
    
    return render(request,'cdsweb/qserve_status.htm',context)
    
def job_status(request, jobid):
    "get information about a queued job"
    context = default_cdsweb_context()
    
    info = {
        'id':jobid,
        'job_type':'',
        'state':'(unknown)',
        'notify':'',
        'queue_time':'',
        'start_time':'',
        'stop_time':'',
    }
    
    try:
        if settings.CDSWEB_TEST_MODE:
            info['job_type'] = 'demo'
        else:
            c = qserver_connect(authenticate=True)
            # get qserver status
            info = c.command('jobinfo',{'id':int(jobid)})
            c.close()
    except Exception, e:
        messages.add_message(request,messages.ERROR,'Error: %s'%e)
    
    context['info'] = info
    return render(request,'cdsweb/qserve_jobinfo.htm',context)
    
    
