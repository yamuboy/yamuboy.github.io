from django.conf.urls import patterns, include, url

urlpatterns = patterns('cdsweb.foundry_views',
    url(r'^ping/$','test'),
    url(r'^submit/$','submit'),
    url(r'^status/$','status'),
    url(r'^results/$','results'),
)
