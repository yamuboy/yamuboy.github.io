
## messages 
_no_licenses = """
<p style="font-size:120%;font-weight:bold;color:#ff0000;">Assura licenses are unavailable.</p>

<p>Due to a contract hold up at Cadence, we are waiting on updated license files.
We hope to resolve the problem shortly, but it could be a few days.</p>
"""


# variables to turn manual shutdown mode on/off
# and set the shutdown message (which should be an HTML string)
MANUAL_SHUTDOWN = False
SHUTDOWN_MESSAGE = _no_licenses

def assura_is_down():
    "check to see if Assura is down"
    # check the status of the manual shutdown flag
    if MANUAL_SHUTDOWN:
        return True
    
    return False


def assura_shutdown_message():
    "return a message explaining why Assura is down"
    return SHUTDOWN_MESSAGE
    
