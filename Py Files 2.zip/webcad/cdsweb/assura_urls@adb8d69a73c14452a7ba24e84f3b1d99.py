from django.conf.urls import patterns, include, url

urlpatterns = patterns('cdsweb.assura_views',
    url(r'^lvs/submit/$','lvs_submit'),
    url(r'^lvs/reconcile/([a-zA-Z0-9]{10,})/$','lvs_reconcile'),
    url(r'^lvs/results/([a-zA-Z0-9]{10,})/$','lvs_results'),
    url(r'^lvs/zipfile/([a-zA-Z0-9]{10,})/$','lvs_zipfile'),
    url(r'^lvs/sysdown/$','lvs_system_down'),
    url(r'^drc/submit/$','drc_submit'),
    url(r'^drc/results/([a-zA-Z0-9]{10,})/$','drc_results'),
    url(r'^drc/zipfile/([a-zA-Z0-9]{10,})/$','drc_zipfile'),
    url(r'^drc/sysdown/$','drc_system_down'),
    url(r'^file/([a-zA-Z0-9]{10,})/$','get_attachment'),
    url(r'^newreults/$','new_results_page'),
    url(r'^clearhistory/$','clear_history'),
)
