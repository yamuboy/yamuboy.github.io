from django.http import HttpResponse, Http404
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.conf import settings
from django.contrib import messages
from django import forms as djforms
from django.core.urlresolvers import reverse
from django.utils.encoding import iri_to_uri

from cdsweb.models import GDSRewriteJob, Attachment
from cdsweb.utils import default_cdsweb_context, random_hash, unique_file_name, create_expires_datetime, create_attachment_from_upload

import os
import os.path

import gdsiitools

class GdsRewriteForm(djforms.Form):
    "LVS job submission form"
    gdsfile = djforms.FileField(label="GDSII File",widget=djforms.FileInput(attrs={'size':'50'}),help_text='GDSII data file')
    prefix = djforms.CharField(required=False,max_length=8,widget=djforms.TextInput(attrs={'size':'8'}),help_text='prefix to add to all GDSII cell names')
    suffix = djforms.CharField(required=False,max_length=8,widget=djforms.TextInput(attrs={'size':'8'}),help_text='suffix to add to all GDSII cell names')
    trunc_begin = djforms.BooleanField(required=False)
    
class GdsInfoForm(djforms.Form):
    "LVS job submission form"
    gdsfile = djforms.FileField(label="GDSII File",widget=djforms.FileInput(attrs={'size':'50'}),help_text='GDSII data file')

    
        
def gdsii_rewrite(request):
    "submit an Assura LVS job"
    context = default_cdsweb_context()
    
    # upload of schematic and layout files plus other metadata for doing LVS
    if request.method == 'POST':
        form = GdsRewriteForm(request.POST,request.FILES)
        if form.is_valid():
            prefix = form.cleaned_data['prefix'].strip().encode('ascii')
            suffix = form.cleaned_data['suffix'].strip().encode('ascii')
            trunc = bool(form.cleaned_data['trunc_begin'])
            
            if prefix or suffix:
                jobid = random_hash(32)
                
                # store the incoming GDSII file
                gdsfile = create_attachment_from_upload(request.FILES['gdsfile'])
                gdsfile.mimetype = 'application/octet-stream'
                gdsfile.save()
                
                # create the outgoing GDSII file
                parms = {
                    'id': unique_file_name(settings.CDSWEB_DATA_PATH,32),
                    'name': os.path.splitext(gdsfile.name)[0]+'-rr.gds',
                    'desc': 'Re-write of `%s` with prefix = `%s`, suffix = `%s`'%(gdsfile.name,prefix,suffix),
                    'mimetype':'application/octet-stream',
                    'size':0,
                    'expires': create_expires_datetime(hours=96),
                }
                outfile = Attachment(**parms)
            
                try:
                    # run the GDSII rewrite tool
                    rr = gdsiitools.GDSII_Struct_Rewrite()
                    kw = {}
                    if prefix:
                        kw['prefix'] = prefix
                    if suffix:
                        kw['suffix'] = suffix
                    if trunc:
                        kw['truncate_beginning'] = True
                    rr.rewrite(gdsfile.get_filesystem_path(),outfile.get_filesystem_path(),**kw)
                    
                    outfile.size = os.stat(outfile.get_filesystem_path()).st_size
                    outfile.save()
                    
                    # store the job information
                    mdata = {
                        'jobid':jobid,
                        'infile':gdsfile,
                        'outfile':outfile,
                    }
                    model = GDSRewriteJob(**mdata)
                    model.save()
                    
                    # redirect to the rewrite done page
                    return redirect('cdsweb.gds_views.gdsii_rewrite_done',jobid)
                except Exception, e:
                    messages.add_message(request,messages.ERROR,'Rewrite operation failed: '+str(e))
            else:
                # add an error message and delete the uploaded file
                messages.add_message(request,messages.ERROR,'"Prefix" or "Suffix" must be specified')
                        
        else:
            # error message??
            #messages.add_message(request, messages.ERROR, '')
            pass
    else:
        # unbound form
        form = GdsRewriteForm()
    
    context['form'] = form
    return render(request,'cdsweb/gdsii_rewrite.htm',context)

def gdsii_rewrite_done(request, jobid):
    "page to display the completion of the re-write"
    data = get_object_or_404(GDSRewriteJob,pk=jobid)
    context = default_cdsweb_context()
    context['download_url'] = reverse('cdsweb.assura_views.get_attachment',args=[data.outfile.id])
    context['rrdata'] = data
    return render(request,'cdsweb/gdsii_rewrite_done.htm',context)
    
def gdsii_info_upload(request):
    "upload a GDSII file to get information about it"
    context = default_cdsweb_context()
    
    # upload of schematic and layout files plus other metadata for doing LVS
    if request.method == 'POST':
        form = GdsInfoForm(request.POST,request.FILES)
        if form.is_valid():
            # create an attachment
            gdsfile = create_attachment_from_upload(request.FILES['gdsfile'])
                            
            # redirect to the information page
            return redirect('cdsweb.gds_views.gdsii_info',gdsfile.id)
        else:
            # error message??
            #messages.add_message(request, messages.ERROR, '')
            pass
    else:
        # unbound form
        form = GdsInfoForm()
    
    context['form'] = form
    return render(request,'cdsweb/gdsii_info_upload.htm',context)

def gdsii_info(request, fileid):
    "retrieve information about a GDSII file"
    context = default_cdsweb_context()
    
    att = get_object_or_404(Attachment,pk=fileid)
    try:
        fp = open(att.get_filesystem_path(),'rb')
    except Exception:
        raise Http404()
        
    try:
        try:
            info = gdsiitools.GDSII_Basic_Info(fp)
            ly = list(info.all_layers)
            ly.sort()
            lystr = [str(x) for x in ly]
            
            cellinfo = []
            for sname in info.snames:
                s = info[sname]
                cellinfo.append( {'name':s.name,'nelements':s.nelements,'nparents':s.num_parents,'nchildren':s.num_children} )    
            
            units = info.units[1]/info.units[0]
            unitssuf = 'm'
            if units < 0.1:
                units *= 1000.0
                unitssuf = 'mm'
            if units < 0.1:
                units *= 1000.0
                unitssuf = 'um'
            
            
            context['info'] = info
            context['filename'] = att.name
            context['filesize'] = att.size
            context['layers'] = ', '.join(lystr)
            context['units'] = '%g %s'%(units,unitssuf)
            context['precision'] = '%g'%info.units[0]
            context['cellinfo'] = cellinfo
        except Exception, e:
            context['error'] = str(e)
    finally:
        fp.close()
        
    return render(request,'cdsweb/gdsii_info.htm',context)
    
    
    
    
    
    
