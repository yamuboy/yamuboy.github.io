from django.conf.urls import patterns, include, url

urlpatterns = patterns('cdsweb.qserve_views',
    url(r'^$','home'),
    url(r'^jobinfo/(\d+)/$','job_status'),
)
