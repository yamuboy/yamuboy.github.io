from django.http import HttpResponse, Http404
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404
from django.conf import settings
from django import forms as djforms
from django.utils.html import escape
from django.views.decorators.csrf import csrf_exempt                                          
from django.utils.decorators import available_attrs

from cdsweb.utils import random_hash, create_attachment_from_upload
from cdsweb.assura_utils import get_deck_switches, submit_job_to_daemon
from cdsweb.qserver import qserver_connect
from cdsweb.models import AssuraDRCJob
from cdsweb.assura_status import assura_is_down
from cdsweb.assura_views import AssuraSwitchForm, _store_advanced_options, _DRC_ADVANCED_OPTIONS
from cdsweb.ajax_views import MyJSONResponse, _get_job_results

import base64
import os, os.path
import pickle
from functools import wraps

class FoundryAssuraDRCSubmitForm(djforms.Form):
    "foundry portal DRC submission form"
    
    process = djforms.CharField()
    layout_file = djforms.FileField()
    
    # advanced options
    flatten = djforms.BooleanField(required=False)
    flat_output = djforms.BooleanField(required=False)
    ignore_cells = djforms.CharField(required=False)
    topcell = djforms.CharField(required=False)

# access control view decorator
def check_foundry_access(func):
    "check that remote address to make sure it is allowed"
    @wraps(func,assigned=available_attrs(func))
    def _f(*args,**kwargs):
        if settings.CDSWEB_FOUNDRY_REMOTE_HOSTS and args[0].META['REMOTE_ADDR'] not in settings.CDSWEB_FOUNDRY_REMOTE_HOSTS:
            raise PermissionDenied()
        elif settings.CDSWEB_FOUNDRY_REQUIRE_HTTPS and not args[0].is_secure():
            raise PermissionDenied()        
        return func(*args,**kwargs)
    return _f


@check_foundry_access
def test(request):
    "test the endpoint"
    
    if not request.is_ajax():
        return HttpResponse('Warning: this should be called with header `X-Requested-With: XMLHttpRequest` set')
    else:
        return MyJSONResponse({'ping':'ok'})
        
@csrf_exempt         
@check_foundry_access
def submit(request):
    "submit a DRC job"
    
    if request.method != 'POST':
        return MyJSONResponse({'error':'Only the POST method is supported.'}, status=500)
    
    if assura_is_down():
        return MyJSONResponse({'error':'Web DRC system is offline for maintenance.'}, status=503)
    
    form = FoundryAssuraDRCSubmitForm(request.POST,request.FILES)
    if form.is_valid():
        data = form.cleaned_data
        lay_file = create_attachment_from_upload(request.FILES['layout_file'])
    else:
        errs = []
        for k, v in form.errors.iteritems():
            errs.append(str(k)+' -> '+str(v))
    
        return MyJSONResponse({'error':'Data validation error(s): '+('; '.join(errs))}, status=500)
        
    # create a job identifier
    jobid = random_hash(32)

    # check the Assura DRC configuration and see if any switches are defined for the process
    try:
        switches, setswitches = get_deck_switches(data['process'],'drc.switches')
    except Exception, e:
        return MyJSONResponse({'error':'Invalid `process` form field.'}, status=500)
    
    # process the switches
    if len(switches):
        swform = AssuraSwitchForm(switches,request.POST)
        if swform.is_valid():
            swdata = swform.cleaned_data
            for s in switches:
                if s.type == 'toggle':
                    if bool(swdata['sw_'+s.name]):
                        setswitches.append(str(s.name))
                elif s.type == 'select':
                    v = swdata['sw_'+s.name]
                    if len(v):
                        setswitches.append(str(v))                            
        else:
            return MyJSONResponse({'error':'Switch data is invalid.'}, status=500)

    # process advanced options
    opts = _store_advanced_options(data,request,_DRC_ADVANCED_OPTIONS,None)
    
    # create display parameters
    optstr = ''
    if opts:
        keys = opts.keys()
        keys.sort()
        a = []
        for k in keys:
            a.append(k+' = '+str(opts[k]))
        optstr = ', '.join(a)
    dispparms = [
        (u'Job Type',u'DRC'),
        (u'Process',data['process']),
        (u'Layout File',lay_file.name),
        (u'Switches',', '.join(setswitches)),
        (u'Options',optstr),
    ]                    
    
    # create the model in the database
    model_data = {
        'jobid':jobid,
        'process':data['process'],
        'email':'',
        'layout_file':lay_file,
        'status':'Q',
        'parameters':pickle.dumps(dispparms),
    }
    model = AssuraDRCJob(**model_data)
    
    ##### submit the DRC job #####
    try:
        fp = open(lay_file.get_filesystem_path(),'rb')
        parms = {
            'job_type': 'assuradrc',
            'notify': '',
            'process': model.process,
            'lay_file': base64.b64encode(fp.read()),
            'options': opts,
            'switches': setswitches,
        }
        fp.close()
        model.submission_id = submit_job_to_daemon(parms,auth_as='foundry')                        
    except Exception, e:
        model.status = 'F'
        model.status_message = u'Fatal Error in job submission: '+unicode(e)

    # save the model to the database
    model.save()
    
    # create and return the response
    return MyJSONResponse({'id':jobid})

@check_foundry_access
def status(request):
    "get the job status"
    
    if request.method != 'GET':
        return MyJSONResponse({'error':'Only the GET method is supported.'}, status=500)
    
    # load the job from the database
    jobid = request.GET.get('id','')
    if not jobid:
        raise Http404()
    model = get_object_or_404(AssuraDRCJob,pk=jobid)
    
    # get the status from the job queue
    c = qserver_connect(authenticate=True,authenticate_as='foundry')
    stat = c.command('jobstatus',{'id':model.submission_id})['status']
    c.close()
    
    # create and return the response
    return MyJSONResponse({'id':jobid,'status':stat})
    
STATUS_MAPPING = {
    u'Q': 'queued',
    u'R': 'running',
    u'C': 'complete',
    u'F': 'failed',
    u'X': 'expired',
    }
    
@check_foundry_access
def results(request):
    "get the DRC results"
    
    if request.method != 'GET':
        return MyJSONResponse({'error':'Only the GET method is supported.'}, status=500)
    
    # load the job from the database
    jobid = request.GET.get('id','')
    if not jobid:
        raise Http404()
    model = get_object_or_404(AssuraDRCJob,pk=jobid)
    
    # see if results are available, they either are loaded
    # from the job manager queue or they have already been uploaded
    # to the web server - if this call returns True then the
    # results are available and can be loaded from the model
    r = _get_job_results(model,auth_as='foundry')
    
    # initialize the return object
    result = {
        'id':jobid,
        'status': STATUS_MAPPING.get(model.status,'undefined'),
        'summary_text':'',
        'parameters':[],
        'drc_summary':[],
        'files':[],
        'refresh': False,
        }
    
    if r:
        #### full results are available ####
        
        # summary text
        result['summary_text'] = model.status_message
        
        # load parameters table
        try:
            result['parameters'] = pickle.loads(str(model.parameters))
        except Exception:
            pass
        
        # load DRC summary table
        try:
            result['drc_summary'] = pickle.loads(str(model.summary))
        except Exception:
            pass
        
        # build file table
        files = model.result_files.all()
        if files:
            fileset = []
            for att in files:
                d = {'name':att.name,'desc':att.desc,'mimetype':att.mimetype}
                try:
                    fp = open(att.get_filesystem_path(),'rb')
                    d['contents'] = base64.b64encode(fp.read())
                    fp.close()
                    fileset.append(d)
                except Exception:
                    pass
        
            result['files'] = fileset
    else:
        # need to refresh to get results (job is still running)
        result['refresh'] = True
    
    return MyJSONResponse(result)    
    
    
