import os, os.path
import random
from django.conf import settings
from cdsweb.models import Attachment
from datetime import datetime, timedelta
import base64

try:
    from cdsweb.banner import BANNER_CONTENT
except ImportError:
    BANNER_CONTENT = None
    

class ToggleSwitch(object):
    """Toggle switch for Assura switch configuration"""
    def __init__(self, name, description=None, default=False, label=None):
        "initializer"
        self.type = 'toggle'
        if not isinstance(name,str):
            raise TypeError("'name' must be a string")
        self.name = name
        
        if isinstance(description,str):
            self.desc = description
        else:
            self.desc = name
        
        if isinstance(label,str):
            self.label = label
        else:
            self.label = None
        
        self.default = bool(default)
        self.value = self.default

class SelectSwitch(object):
    """Select switch for Assura switch configuration"""
    def __init__(self, name, description=None, choices=None, default=None, label=None):
        "initializer"
        self.type = 'select'
        if not isinstance(name,str):
            raise TypeError("'name' must be a string")
        self.name = name
        
        if isinstance(description,str):
            self.desc = description
        else:
            self.desc = name
        
        if isinstance(label,str):
            self.label = label
        else:
            self.label = None
        
        self.choices = self._process_choices(choices)
        self.default = default
        self.set_value(default)
        
    def set_value(self, v=None):
        "set the switch's value"
        if len(self.choices):
            if v is not None:
                d = unicode(default)
                for c in self.choices:
                    if c[0] == d:
                        self.value = d
                        break
            else:
                self.value = self.choices[0][0]
        else:
            self.value = u''
    
    def _process_choices(self, choices):
        "process the choices list"
        if choices is None:
            raise ValueError("'choices' is required")
        elif not isinstance(choices,(list,tuple)):
            raise TypeError("'choices' must be a list/tuple")
        
        out = []
        for c in choices:
            if not isinstance(c,tuple) or len(c) != 2:
                raise ValueError("'choices' must consist of 2-tuples")
                
            if not isinstance(c[0],(str,unicode)) or not isinstance(c[1],(str,unicode)):
                raise TypeError("'choices' must consist of 2-tuples of strings")
            out.append( (unicode(c[0]),unicode(c[1])) )
                
        return out
    
         
def random_hash(len):
    "generate a random hash string"
    chars = 'abcdefghijkmnopqrstuvwxyz23456789'
    ret = ''
    for i in range(len):
        ret += random.choice(chars)
    return ret


def default_cdsweb_context(data=None):
    "default context for the page"
    ret = {
        'page_banner_content':BANNER_CONTENT if BANNER_CONTENT else u'',
    }
    if data:
        ret.update(data)
    return ret
    
def _read_process_config_file():
    "read the process config file"
    fname = settings.CDSWEB_PROCESS_CONFIG_FILE
    ret = {}
    try:
        data = {}
        execfile(fname,data)
        for p in data['PROCESS_CFG']:
            if len(p) != 4:
                continue
            d = dict(name=p[0].strip(), display=p[1].strip(), directory=p[2].strip())
            for t in p[3].split('|'):
                t = t.strip()
                if t not in ret:
                    ret[t] = []
                ret[t].append(d)
    except Exception, e:
        raise IOError("unable to read process config file => %s"%e)
        
    return ret
    
    
def get_pdk_choices(toolname):
    "get a choice set for PDKs to choose from"
    # load the process configuration file
    cfg = _read_process_config_file()
    # create the choices
    choices = [(u'',u'--------')]
    if toolname in cfg:
        # sort the processes by name
        pdat = {}
        for d in cfg[toolname]:
            pdat[d['display']] = d['name']        
        keys = pdat.keys()
        keys.sort()
        
        # append to the choices
        for k in keys:
            choices.append( (unicode(pdat[k]),unicode(k)) )
    
    return choices

def get_assura_deck_path(toolname, process):
    "get the full path to the top level folder of a deck"
    # load the process configuration file
    cfg = _read_process_config_file()
    if toolname == '*':
        for t in cfg.keys():
            for d in cfg[t]:
                if d['name'] == process:
                    return d['directory']        
    elif toolname in cfg:
        for d in cfg[toolname]:
            if d['name'] == process:
                return d['directory']
        
    return None

def read_assura_switches( fpath ):
    "read a switch configuration file for Assura"
    switches = []
    fixed_switches = []
    
    if os.path.isfile(fpath):
        # execute the configuration with execfile
        glb = {'ToggleSwitch':ToggleSwitch, 'SelectSwitch':SelectSwitch}
        execfile(fpath,glb)
        
        if 'SWITCHES' not in glb:
            raise ValueError("missing variable 'SWITCHES'")

        data = glb['SWITCHES']
        if not isinstance(data,(list,tuple)):
            raise TypeError("'SWITCHES' must be a list/tuple")
        
        for d in data:
            if isinstance(d,(ToggleSwitch,SelectSwitch)):
                switches.append(d)
            elif isinstance(d,str) and len(d):
                fixed_switches.append(d)
            else:
                # unknown data
                pass
    
    return switches, fixed_switches
    
def unique_file_name( path, length=24 ):
    "generate a unique filename in the specified path"
    if not os.path.isdir(path):
        raise IOError("invalid path")
    
    while True:
        fn = random_hash(length)
        if not os.path.isfile(os.path.join(path,fn)):
            return fn
 

def create_attachment_from_upload( uploaded_file ):
    "create an Attachment model object from an UploadedFile object (from the request.FILES list)"
    path = settings.CDSWEB_DATA_PATH
    fileid = unique_file_name(path,32)

    fpath = os.path.join(path,fileid)
    fp = open(fpath,'wb')
    sz = 0
    for c in uploaded_file.chunks():
        fp.write(c)
        sz += len(c)
    fp.close()

    try:
        kw = {
            'id':fileid,
            'name':uploaded_file.name,
            'desc':uploaded_file.name,
            'size':sz,
            'mimetype':uploaded_file.content_type,
            'expires':create_expires_datetime(hours=96),
        }
        model = Attachment(**kw)
        model.save()
    except Exception:
        try:
            os.unlink(fpath)
        except Exception:
            pass
        raise
    
    return model

def create_attachment_from_qserve( data, order=0 ):
    "create an Attachment model object from data returned from the queue server"
    path = settings.CDSWEB_DATA_PATH
    fileid = unique_file_name(path,32)

    fpath = os.path.join(path,fileid)
    fp = open(fpath,'wb')
    if data['error']:
        fp.write(data['error'])        
    else:
        fp.write(base64.b64decode(data['contents']))
    fp.close()
    sz = os.stat(fpath).st_size

    try:
        kw = {
            'id':fileid,
            'name':data['name'],
            'desc':data['desc'],
            'size':sz,
            'mimetype':data['mimetype'],
            'expires':create_expires_datetime(hours=96),
            'order': order,
        }
        model = Attachment(**kw)
        model.save()
    except Exception:
        try:
            os.unlink(fpath)
        except Exception:
            pass
        raise
    
    return model
    
def create_expires_datetime(**kwargs):
    "create a datetime object for Attachment expiration"
    return datetime.now()+timedelta(**kwargs)
    
    
    