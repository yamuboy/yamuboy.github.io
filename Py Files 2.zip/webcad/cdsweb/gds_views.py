from django.http import HttpResponse, Http404
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.conf import settings
from django.contrib import messages
from django import forms as djforms
from django.core.urlresolvers import reverse
from django.utils.encoding import iri_to_uri

from cdsweb.models import GDSRewriteJob, Attachment
from cdsweb.utils import default_cdsweb_context, random_hash, unique_file_name, create_expires_datetime, create_attachment_from_upload

import os, os.path, math
import csv as _csv

import gdsiitools
from gdsiitools.utils import compute_element_bounding_boxes

class GdsRewriteForm(djforms.Form):
    "LVS job submission form"
    gdsfile = djforms.FileField(label="GDSII File",widget=djforms.FileInput(attrs={'size':'50'}),help_text='GDSII data file')
    prefix = djforms.CharField(required=False,max_length=8,widget=djforms.TextInput(attrs={'size':'8'}),help_text='prefix to add to all GDSII cell names')
    suffix = djforms.CharField(required=False,max_length=8,widget=djforms.TextInput(attrs={'size':'8'}),help_text='suffix to add to all GDSII cell names')
    trunc_begin = djforms.BooleanField(required=False)
    
class GdsInfoForm(djforms.Form):
    "LVS job submission form"
    gdsfile = djforms.FileField(label="GDSII File",widget=djforms.FileInput(attrs={'size':'50'}),help_text='GDSII data file')

    
        
def gdsii_rewrite(request):
    "submit an Assura LVS job"
    context = default_cdsweb_context()
    
    # upload of schematic and layout files plus other metadata for doing LVS
    if request.method == 'POST':
        form = GdsRewriteForm(request.POST,request.FILES)
        if form.is_valid():
            prefix = form.cleaned_data['prefix'].strip().encode('ascii')
            suffix = form.cleaned_data['suffix'].strip().encode('ascii')
            trunc = bool(form.cleaned_data['trunc_begin'])
            
            if prefix or suffix:
                jobid = random_hash(32)
                
                # store the incoming GDSII file
                gdsfile = create_attachment_from_upload(request.FILES['gdsfile'])
                gdsfile.mimetype = 'application/octet-stream'
                gdsfile.save()
                
                # create the outgoing GDSII file
                parms = {
                    'id': unique_file_name(settings.CDSWEB_DATA_PATH,32),
                    'name': os.path.splitext(gdsfile.name)[0]+'-rr.gds',
                    'desc': 'Re-write of `%s` with prefix = `%s`, suffix = `%s`'%(gdsfile.name,prefix,suffix),
                    'mimetype':'application/octet-stream',
                    'size':0,
                    'expires': create_expires_datetime(hours=96),
                }
                outfile = Attachment(**parms)
            
                try:
                    # run the GDSII rewrite tool
                    rr = gdsiitools.GDSII_Struct_Rewrite()
                    kw = {}
                    if prefix:
                        kw['prefix'] = prefix
                    if suffix:
                        kw['suffix'] = suffix
                    if trunc:
                        kw['truncate_beginning'] = True
                    rr.rewrite(gdsfile.get_filesystem_path(),outfile.get_filesystem_path(),**kw)
                    
                    outfile.size = os.stat(outfile.get_filesystem_path()).st_size
                    outfile.save()
                    
                    # store the job information
                    mdata = {
                        'jobid':jobid,
                        'infile':gdsfile,
                        'outfile':outfile,
                    }
                    model = GDSRewriteJob(**mdata)
                    model.save()
                    
                    # redirect to the rewrite done page
                    return redirect('cdsweb.gds_views.gdsii_rewrite_done',jobid)
                except Exception as e:
                    messages.add_message(request,messages.ERROR,'Rewrite operation failed: '+str(e))
            else:
                # add an error message and delete the uploaded file
                messages.add_message(request,messages.ERROR,'"Prefix" or "Suffix" must be specified')
                        
        else:
            # error message??
            #messages.add_message(request, messages.ERROR, '')
            pass
    else:
        # unbound form
        form = GdsRewriteForm()
    
    context['form'] = form
    return render(request,'cdsweb/gdsii_rewrite.htm',context)

def gdsii_rewrite_done(request, jobid):
    "page to display the completion of the re-write"
    data = get_object_or_404(GDSRewriteJob,pk=jobid)
    context = default_cdsweb_context()
    context['download_url'] = reverse('cdsweb.assura_views.get_attachment',args=[data.outfile.id])
    context['rrdata'] = data
    return render(request,'cdsweb/gdsii_rewrite_done.htm',context)
    
def gdsii_info_upload(request):
    "upload a GDSII file to get information about it"
    context = default_cdsweb_context()
    
    if request.method == 'POST':
        form = GdsInfoForm(request.POST,request.FILES)
        if form.is_valid():
            # create an attachment
            gdsfile = create_attachment_from_upload(request.FILES['gdsfile'])
                            
            # redirect to the information page
            return redirect('cdsweb.gds_views.gdsii_info',gdsfile.id)
        else:
            messages.add_message(request, messages.ERROR, 'Upload failed! Please try again.')
    else:
        # unbound form
        form = GdsInfoForm()
    
    context['form'] = form
    return render(request,'cdsweb/gdsii_info_upload.htm',context)

def gdsii_info(request, fileid):
    "retrieve information about a GDSII file"
    context = default_cdsweb_context()
    
    att = get_object_or_404(Attachment,pk=fileid)
    try:
        fp = open(att.get_filesystem_path(),'rb')
    except Exception:
        raise Http404()
        
    try:
        try:
            info = gdsiitools.GDSII_Basic_Info(fp)
            ly = list(info.all_layers)
            ly.sort()
            lystr = [str(x[0])+'/'+str(x[1]) for x in ly]
            
            cellinfo = []
            for sname in info.snames:
                s = info[sname]
                cellinfo.append( {'name':s.name,'nelements':s.nelements,'nparents':s.num_parents,'nchildren':s.num_children} )    
            
            units = info.units[1]/info.units[0]
            unitssuf = 'm'
            if units < 0.1:
                units *= 1000.0
                unitssuf = 'mm'
            if units < 0.1:
                units *= 1000.0
                unitssuf = 'um'
            
            
            context['info'] = info
            context['filename'] = att.name
            context['filesize'] = att.size
            context['layers'] = ', '.join(lystr)
            context['units'] = '%g %s'%(units,unitssuf)
            context['precision'] = '%g'%info.units[0]
            context['cellinfo'] = cellinfo
        except Exception as e:
            context['error'] = str(e)
    finally:
        fp.close()
        
    return render(request,'cdsweb/gdsii_info.htm',context)

    
class GdsMarkerForm(djforms.Form):
    "XOR job submission form"
    
    def __init__(self, structures, layers, *args, **kwargs):
        "initializer"
        super(GdsMarkerForm,self).__init__(*args,**kwargs)
        # create structure fields
        for i in range(len(structures)):
            self.fields['structure_'+str(i)] = djforms.BooleanField(required=False,label=structures[i],initial=False)
        # create layer fields
        for i in range(len(layers)):
            self.fields['layer_'+str(i)] = djforms.BooleanField(required=False,label=str(layers[i]),initial=False)
            
        self._structlist = structures[:]
        self._layerlist = layers[:]    
    
    def get_selected_structures(self):
        "return a list of the selected structure names"
        ret = []
        for i in range(len(self._structlist)):
            fname = 'structure_'+str(i)
            if fname in self.cleaned_data and self.cleaned_data[fname]:
                ret.append(self._structlist[i])
        return ret
    
    def get_selected_layers(self):
        "return a list of the selected layer numbers"
        ret = []
        for i in range(len(self._layerlist)):
            fname = 'layer_'+str(i)
            if fname in self.cleaned_data and self.cleaned_data[fname]:
                ret.append(self._layerlist[i])
        return ret

    def structure_select_fields(self):
        "return a list of the structure select fields"
        ret = []
        for i in range(len(self._structlist)):
            ret.append(self['structure_'+str(i)])
        return ret
        
    def layer_select_fields(self):
        "return a list of the layer select fields"
        ret = []
        for i in range(len(self._layerlist)):
            ret.append(self['layer_'+str(i)])
        return ret


        
def gdsii_marker_upload(request):
    "upload a GDSII file to get marker positions"
    context = default_cdsweb_context()
    
    if request.method == 'POST':
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()
            
            form = GdsInfoForm(request.POST,request.FILES)
            if form.is_valid():
                # create an attachment
                gdsfile = create_attachment_from_upload(request.FILES['gdsfile'])
                                
                # redirect to the information page
                return redirect('cdsweb.gds_views.gdsii_marker_config',gdsfile.id)
            else:
                messages.add_message(request, messages.ERROR, 'Upload failed! Please try again.')
        else:
            # test cookie failed
            messages.add_message(request, messages.ERROR, 'Cookies must be enabled!!! Enable cookies in your browser and reload the page!')
            form = GdsInfoForm()
    else:
        # unbound form
        form = GdsInfoForm()
    
    context['form'] = form
    request.session.set_test_cookie()
    return render(request,'cdsweb/gdsii_marker_upload.htm',context)

def gdsii_marker_config(request, fileid):
    "show selections for which cells and layers to use"
    context = default_cdsweb_context()
    
    att = get_object_or_404(Attachment,pk=fileid)
    fpath = att.get_filesystem_path()
    if not os.path.isfile(fpath):
        raise Http404()

    form = None
    structs = []
    layers = []
    try:
        inf = gdsiitools.GDSII_Basic_Info(fpath)
        structs = inf.snames
        layers = [x[0] for x in inf.all_layers]
        
        if request.method == 'POST':
            form = GdsMarkerForm(structs,layers,request.POST,request.FILES)
            form.is_valid()   # <-- form will always be valid, this just populates form.cleaned_data
            # get the structure names and layer numbers from
            # the web form
            selected_structs = form.get_selected_structures()
            selected_layers = form.get_selected_layers()
            
            if not len(selected_structs):
                raise ValueError('no cells were selected')
            if not len(selected_layers):
                raise ValueError('no marker layers were selected')
            
            # store selections in the session
            d = request.session.get('gdsii_marker_config')
            if d is None:
                d = {}
            d[fileid] = {'structs':selected_structs,'layers':selected_layers}
            request.session['gdsii_marker_config'] = d
                                
            # redirect to the results page
            return redirect('cdsweb.gds_views.gdsii_marker_result',att.id)
        else:
            form = GdsMarkerForm(structs,layers)
        
    except Exception, e:
        messages.add_message(request,messages.ERROR,'Error: '+str(e))
    
    if form:
        context['form'] = form
    return render(request,'cdsweb/gdsii_marker_config.htm',context)


def _sort_in_y( lst ):
    "sort in the Y-direction"
    def _srtf(a, b):
        return cmp(a[4],b[4])
    lst.sort(_srtf)
    
def gdsii_marker_result(request, fileid):
    "show the results of the marker position computation"
    context = default_cdsweb_context()
    
    do_csv = bool(request.GET.get('csv',False))
    
    att = get_object_or_404(Attachment,pk=fileid)
    fpath = att.get_filesystem_path()
    if not os.path.isfile(fpath):
        raise Http404()
    
    try:
        # get selections from the session
        d = request.session.get('gdsii_marker_config')
        if d is None:
            raise ValueError('session data is expired')
        if fileid not in d:
            raise ValueError('session data for this file is missing')
        
        selected_structs = d[fileid]['structs']     
        selected_layers = d[fileid]['layers']     
        
        # load the library
        lib = gdsiitools.Library.load(fpath)
        sf = lib.user_unit_per_dbunit
        
        # for each structure
        result = []
        caches = {}
        for struct in selected_structs:
            # for each layer
            for lay in selected_layers:
                if lay not in caches:
                    caches[lay] = {}
            
                try:
                    sdata = lib.get_structure_by_name(struct)
                    out = []
                    for r in gdsiitools.utils.compute_element_bounding_boxes(sdata,layers=[lay],cache=caches[lay]):
                        out.append( ( struct, lay, gdsiitools.get_record_name(r.type),
                            r.x1*sf, r.y1*sf, r.x2*sf, r.y2*sf,
                            (r.x1+(r.x2-r.x1)//2)*sf,
                            (r.y1+(r.y2-r.y1)//2)*sf )
                        )
                        
                    # sort the result list
                    if len(out) > 1:
                        x1_list = []
                        for r in out:
                            x1_list.append(r[3])
                            
                        min_x1, max_x1 = min(x1_list), max(x1_list)
                        x1_range = max_x1 - min_x1
                        
                        # slice into 50 um widths
                        nslices = int(math.floor(x1_range/50.0))
                        if nslices > 1:
                            step = (x1_range+1.0)/float(nslices)
                            start = min_x1
                            stop = start+step
                            out2 = []
                            for i in range(nslices):
                                t = []
                                for r in out:
                                    if start <= r[3] < stop:
                                        t.append(r)                    
                                _sort_in_y(t)
                                out2.extend(t)
                                start += step
                                stop = start+step
                            assert len(out) == len(out2)
                            out = out2
                        else:
                            # only sort in Y, don't slice X
                            _sort_in_y(out)
                    
                    result.extend(out)
                except Exception as e:
                    messages.add_message(request,messages.WARNING,"Structure '%s' -> %s"%(struct,e))
                    
                
        context['filename'] = att.name
        context['library'] = lib
        context['data'] = result
        context['fileid'] = fileid
        
        if do_csv:
            response = HttpResponse(mimetype='text/csv')
            response['Content-Disposition'] = 'attachment; filename="'+random_hash(16)+'.csv"'
            writer = _csv.writer(response)
            writer.writerow(['Structure','Layer','Type','X1','Y1','X2','Y2','Xc','Yc'])
            for d in result:
                row = list(d[:3])
                row.extend(['%g'%x for x in d[3:]])
                writer.writerow(row)
            return response    
        
    except Exception as e:
        context['error'] = True
        messages.add_message(request,messages.ERROR,'Error: '+str(e))
        
    return render(request,'cdsweb/gdsii_marker_result.htm',context)

    