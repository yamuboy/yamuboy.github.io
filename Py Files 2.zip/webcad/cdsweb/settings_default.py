

# full filesystem path to the data storage directory
CDSWEB_DATA_PATH = ''

# schematic type choices
# the first item in the list will be the default value
# when the LVS submission form is rendered
ASSURA_LVS_SCHEM_CHOICES = (
    (u'ADS',u'ADS'),
    (u'MO',u'Microwave Office'),
)

# queuing server socket path
CDSWEB_QSERVE_SOCKET_PATH = ''

# queuing server socket timeout
#  uses default value if set to None 
CDSWEB_QSERVE_SOCKET_TIMEOUT = None

# queuing server login details 
CDSWEB_QSERVE_USER = ''
CDSWEB_QSERVE_PASSWORD = ''

# separate user for foundry logins
CDSWEB_QSERVE_FOUNDRY_USER = ''
CDSWEB_QSERVE_FOUNDRY_PASSWORD = ''

# use an SSL socket when connecting to the queuing server
CDSWEB_QSERVE_USE_SSL = False

# path to the process configuration file
CDSWEB_PROCESS_CONFIG_FILE = ''

# path to the Assura decks
CDSWEB_DECK_PATH = ''

# test mode
CDSWEB_TEST_MODE = False

# a list of IP addresses that are allowed access
# to the special foundry portal
# IF THIS IS EMPTY THEN ALL REMOTE HOST ADDRESSES ARE ALLOWED
CDSWEB_FOUNDRY_REMOTE_HOSTS = []

# require an HTTPS connection to the foundry portal
CDSWEB_FOUNDRY_REQUIRE_HTTPS = False
