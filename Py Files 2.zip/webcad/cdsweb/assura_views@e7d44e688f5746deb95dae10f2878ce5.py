from django.http import HttpResponse, Http404, StreamingHttpResponse, HttpResponseRedirect
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.conf import settings
from django.contrib import messages
from django import forms as djforms
from django.forms.formsets import formset_factory
from django.core.urlresolvers import reverse
from wsgiref.util import FileWrapper

from cdsweb.utils import get_pdk_choices, default_cdsweb_context, random_hash, \
    ToggleSwitch, SelectSwitch, create_attachment_from_upload
from cdsweb.assura_utils import hierarchy_match, validate_sch2lay_mapping, \
    set_lvsdrc_cookie_data, get_lvsdrc_cookie_data, get_deck_switches, submit_job_to_daemon, \
    get_job_history, store_job_history, clear_job_history
from cdsweb.models import AssuraLVSJob, AssuraDRCJob, Attachment
from cdsweb.assura_status import assura_is_down, assura_shutdown_message

import os, os.path
import pickle
import base64
import tempfile, zipfile
from StringIO import StringIO
import csv as _csv
import urllib

import schemtools
import gdsiitools

class AssuraSwitchForm(djforms.Form):
    "custom dynamic form for capturing Assura switch information"
    
    def __init__(self, swdata, data=None, **kwargs):
        "initialize the form"
        # init the parent
        super(AssuraSwitchForm,self).__init__(data,**kwargs)
        
        # augment self.fields with dynamically generated fields
        if not isinstance(swdata,(list,tuple)):
            raise TypeError("'swdata' must be a list/tuple")
        for s in swdata:
            if isinstance(s,ToggleSwitch):
                self.fields['sw_'+s.name] = djforms.BooleanField(required=False,help_text=s.desc,label=s.label)
            elif isinstance(s,SelectSwitch):
                self.fields['sw_'+s.name] = djforms.ChoiceField(choices=s.choices,required=False,help_text=s.desc,label=s.label)            
            else:
                raise TypeError("'swdata' must contain `ToggleSwitch` and `SelectSwitch` instances")                

                
def _store_advanced_options( data, request, options, sesskey ):
    "store advanced options in the session for use later"
    
    optout = {}
    optsess = {}
    for o in options:
        if o[0] in data:
            v = o[1](data[o[0]])
            if v != o[2]:
                optout[o[3]] = o[4](data[o[0]])
                optsess[o[0]] = v
    
    if optsess and sesskey:      
        request.session[sesskey] = optsess
        request.session.set_expiry(8*60*60)
    else:
        if sesskey and sesskey in request.session:
            del request.session[sesskey]
    
    return optout

def get_attachment(request, fileid):
    "get a file attachment"
    att = get_object_or_404(Attachment,pk=fileid)
    try:
        fp = open(att.get_filesystem_path(),'rb')
    except IOError:
        raise Http404()
    
    if request.GET.get('m','') == 'inline':
        disp = 'inline'
    else:
        disp = 'attachment'
    
    content_type = att.mimetype
    if content_type in ('text/plain','text/html'):
        content_type += '; charset=utf8'
        
    resp = StreamingHttpResponse(FileWrapper(fp))
    resp['Content-Type'] = content_type
    resp['Content-Disposition'] = disp+'; filename="'+att.name+'"'
    resp['Content-Length'] = os.stat(att.get_filesystem_path()).st_size
    
    return resp

def new_results_page(request):
    "page explaining the new results"
    return render(request,'cdsweb/static_lvs_drc_results_update.htm',default_cdsweb_context())

def clear_history(request):
    "clear the browser's job history"
    return_url = urllib.unquote(request.GET.get('returnTo',''))
    if not return_url:
        return_url = request.META.get('HTTP_REFERER','')
        
    if return_url:
        resp = HttpResponseRedirect(return_url)
    else:
        resp = render(request,'cdsweb/history_cleared.htm',default_cdsweb_context())
        
    if request.method == 'POST' and 'clearhistory' in request.POST:
        clear_job_history(request,resp)
        messages.add_message(request,messages.SUCCESS,'Job history cleared.')      
        
    return resp
    
def _get_result_url( request, view_name, jobid ):
    "generate the result URL to pass on to the job manager"
    scheme = 'https://' if request.is_secure() else 'http://'
    return scheme+request.get_host()+reverse(view_name,args=[jobid])
    
def _get_zipped_files( model ):
    "get the zipped reults files from a model"
    attachments = model.result_files.all()
    
    # create a temporary zip file
    zftemp = tempfile.TemporaryFile()
    zf = zipfile.ZipFile(zftemp,'w',zipfile.ZIP_DEFLATED)
    
    # create a StringIO-backed CSV file for file descriptions
    descriptions_file = StringIO()
    desc = _csv.writer(descriptions_file)
    
    desc.writerow(['Name','Description','Size'])
    for att in attachments:
        fpath = att.get_filesystem_path()
        if os.path.isfile(fpath):
            try:
                sz = os.stat(fpath).st_size
                zf.write(fpath,att.name)
                desc.writerow([att.name.encode('ascii','replace'),att.desc.encode('ascii','replace'),str(sz)])
            except Exception:
                pass
    
    # add the descriptions file to the zip
    zf.writestr('file_info.csv',descriptions_file.getvalue())
    descriptions_file.close()
    
    # close the zipfile, but not the underlying temp file
    # this finalizes the archive
    zf.close()
    
    # return the zip file response
    zftemp.seek(0)
    resp = StreamingHttpResponse(FileWrapper(zftemp))
    resp['Content-Type'] = 'application/zip'
    resp['Content-Disposition'] = 'attachment; filename="files_'+str(model.submission_id)+'.zip"'
    return resp
    
    
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
#                                   LVS Views and Utils                                         #
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #

_DRC_COOKIE_KEY = 'webdrcparms'
_DRC_SWITCH_SESSION_KEY_PREFIX = 'drc_switches_'
_DRC_OPT_SESSION_KEY = 'drc_advopt'
_DRC_ADVANCED_OPTIONS = [
    ('flatten',bool,False,'flatten_hierarchy',bool),
    ('flat_output',bool,False,'flatten_output',bool),
    ('ignore_cells',str,'','ignore_cells',str),
    ('topcell',str,'','topcell',str),
    ]
                                
class AssuraDRCSubmitForm(djforms.Form):
    "DRC job submission form"
    
    def __init__(self, *args, **kwargs):
        "initializer"
        super(AssuraDRCSubmitForm,self).__init__(*args,**kwargs)
        self.fields['process'] = djforms.ChoiceField(choices=get_pdk_choices('assuradrc'))
    
    email = djforms.EmailField(required=False,widget=djforms.TextInput(attrs={'size':'50'}))
    layout_file = djforms.FileField(widget=djforms.FileInput(attrs={'size':'50'}))
    
    # advanced options
    flatten = djforms.BooleanField(required=False)
    flat_output = djforms.BooleanField(required=False)
    ignore_cells = djforms.CharField(required=False)
    topcell = djforms.CharField(required=False)
    
    def clean_email(self):
        "clean the e-mail address field to make sure it is a MACOM e-mail"
        email = self.cleaned_data['email']
        if not len(email):
            return u''
            
        try:
            domain = email.split('@')[1].lower()
        except:
            raise djforms.ValidationError("Not a valid e-mail address")
            
        if domain not in ('macomtech.com','macom.com'):
            raise djforms.ValidationError("E-mail address must be from the MACOM domain")
        return email
        
def drc_system_down(request):
    "system is down page"
    context = default_cdsweb_context()
    context['msg'] = assura_shutdown_message()
    context['tool'] = 'DRC'
    return render(request,'cdsweb/assura_down.htm',context)
    
def drc_submit(request):
    "submit an Assura LVS job"
    context = default_cdsweb_context()
    
    if assura_is_down():
        return redirect('cdsweb.assura_views.drc_system_down')
    
    # check to see if the advanced configuration dialog should be expanded when the page loads
    advconf = False
    
    # generate the deck info AJAX URL
    scheme = 'https://' if request.is_secure() else 'http://'
    deckinfo_url = scheme+request.get_host()+reverse('cdsweb.ajax_views.deck_info')
    deckdetails_url = scheme+request.get_host()+reverse('cdsweb.ajax_views.deck_details')
        
    if request.method == 'POST':
        form = AssuraDRCSubmitForm(request.POST,request.FILES)
        
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()
            
            if form.is_valid():
                data = form.cleaned_data
                
                # create a job identifier
                jobid = random_hash(32)
            
                # create an attachment
                lay_file = create_attachment_from_upload(request.FILES['layout_file'])
                
                # check the Assura DRC configuration and see if any switches are defined for the process
                switches = []
                setswitches = []
                ok = True
                try:
                    switches, setswitches = get_deck_switches(data['process'],'drc.switches')
                except Exception, e:
                    ok = False
                    messages.add_message(request,messages.ERROR,'Configuration error: %s'%e)        
                
                if len(switches):
                    swform = AssuraSwitchForm(switches,request.POST)
                    if swform.is_valid():
                        swdata = swform.cleaned_data
                        sessdata = {}
                        for s in switches:
                            if s.type == 'toggle':
                                if bool(swdata['sw_'+s.name]):
                                    setswitches.append(str(s.name))
                                    sessdata[s.name] = True
                            elif s.type == 'select':
                                v = swdata['sw_'+s.name]
                                if len(v):
                                    setswitches.append(str(v))
                                    sessdata[s.name] = v
                                    
                        # store set switches in the session for reuse
                        swsesskey = _DRC_SWITCH_SESSION_KEY_PREFIX+str(data['process'])
                        if len(sessdata):
                            request.session[swsesskey] = sessdata
                            request.session.set_expiry(8*60*60)
                        else:
                            if swsesskey in request.session:
                                del request.session[swsesskey]
                    else:
                        ok = False
                        messages.add_message(request,messages.ERROR,'Switch data is invalid')        

                # process advanced options and store them in the session
                opts = _store_advanced_options(data,request,_DRC_ADVANCED_OPTIONS,_DRC_OPT_SESSION_KEY)
                
                if ok:
                    ##### store data in the database and session #####
                    
                    # store stuff in the session
                    jobsesskey = 'drc_'+jobid
                    request.session[jobsesskey] = {'options':opts,'switches':setswitches}
                    
                    # create a set of parameters to display in the results view
                    optstr = ''
                    if opts:
                        keys = opts.keys()
                        keys.sort()
                        a = []
                        for k in keys:
                            a.append(k+' = '+str(opts[k]))
                        optstr = ', '.join(a)
                    dispparms = [
                        (u'Job Type',u'DRC'),
                        (u'Process',data['process']),
                        (u'Layout File',lay_file.name),
                        (u'Switches',', '.join(setswitches)),
                        (u'Options',optstr),
                    ]                    
                    
                    model_data = {
                        'jobid':jobid,
                        'process':data['process'],
                        'email':data['email'],
                        'layout_file':lay_file,
                        'status':'Q',
                        'parameters':pickle.dumps(dispparms),
                    }
                    model = AssuraDRCJob(**model_data)
                    
                    ##### submit the DRC job #####
                    try:
                        fp = open(lay_file.get_filesystem_path(),'rb')
                        parms = {
                            'job_type': 'assuradrc',
                            'notify': 'email = '+model.email+'; result_url = '+_get_result_url(request,'cdsweb.assura_views.drc_results',model.jobid),
                            'process': model.process,
                            'lay_file': base64.b64encode(fp.read()),
                            'options': opts,
                            'switches': setswitches,
                        }
                        fp.close()
                        model.submission_id = submit_job_to_daemon(parms)                        
                    except Exception, e:
                        model.status = 'F'
                        model.status_message = u'Fatal Error in job submission: '+unicode(e)
                        messages.add_message(request,messages.ERROR,'Fatal Error in job submission: %s %s'%(type(e),e))

                    # save the model to the database
                    model.save()

                    # send a redirect to the results view
                    resp = redirect('cdsweb.assura_views.drc_results', model.jobid)
                    store_job_history(request,resp,model)
                    return set_lvsdrc_cookie_data(request,resp,_DRC_COOKIE_KEY,{'process':data['process'],'email':data['email']})
                    
                else:
                    lay_file.delete()
            else:
                messages.add_message(request, messages.ERROR, 'Please fill out all form fields.')
            
        else:
            # test cookie failed
            messages.add_message(request, messages.ERROR, 'Cookies must be enabled!!! Enable cookies in your browser and reload the page!')
    else:
        # unbound form
        idat = get_lvsdrc_cookie_data(request,_DRC_COOKIE_KEY)
        if _DRC_OPT_SESSION_KEY in request.session:
            # set advanced configuration parameters
            idat.update(request.session[_DRC_OPT_SESSION_KEY])
            advconf = True
        
        form = AssuraDRCSubmitForm(initial=idat)
    
    context['form'] = form
    context['deckinfo_url'] = deckinfo_url
    context['deckdetails_url'] = deckdetails_url
    if advconf:
        context['advanced_options_classname'] = ' show-expanded'
    request.session.set_test_cookie()
    context['history'] = get_job_history(request)
    
    return render(request,'cdsweb/drc_submit.htm',context)

    
def drc_results(request, jobid):
    "submission finished, get results"
    model = get_object_or_404(AssuraDRCJob,pk=jobid)
    parms = pickle.loads(str(model.parameters))
    parms.append((u'Job ID',unicode(model.submission_id)))
    
    results_url = reverse('cdsweb.ajax_views.drc_results')+'?id='+str(jobid)
    
    context = default_cdsweb_context( {'results_url':results_url,'params':parms} )
    context['history'] = get_job_history(request)
    context['model'] = model
    return render(request,'cdsweb/drc_results.htm',context)
    
def drc_zipfile(request, jobid):
    "get a zipfile of all job results"
    model = get_object_or_404(AssuraDRCJob,pk=jobid)
    return _get_zipped_files(model)
    

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
#                                   LVS Views and Utils                                         #
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #

def _conv_t_nil(x):
    if bool(x):
        return 't'
    else:
        return 'nil'

def _conv_tol(x):
    try:
        v = float(x)
    except Exception:
        return ''
    
    if v >= 0.1 and v <= 10.0:
        return '%g'%v
    return ''

_LVS_COOKIE_KEY = 'weblvsparms'
_LVS_SWITCH_SESSION_KEY_PREFIX = 'lvs_switches_'
_LVS_OPT_SESSION_KEY = 'lvs_advopt'
_LVS_ADVANCED_OPTIONS = [
    (u'pin_binding', str, 'nil', 'pin_name_binding', str),
    (u'net_binding', bool, False, 'net_name_binding', _conv_t_nil),
    (u'match_toplevel_pins', bool, False, 'verify_toplevel_pins', _conv_t_nil),
    (u'expand_reduce', bool, True, 'expand_on_reduce_error', _conv_t_nil),
    (u'expand_match', bool, True, 'expand_on_match_error', _conv_t_nil),
    (u'expand_swap', bool, True, 'expand_on_swap_error', _conv_t_nil),
    (u'tolerance_resistor', _conv_tol, '', 'tolerance_r', _conv_tol),
    (u'tolerance_capacitor', _conv_tol, '', 'tolerance_c', _conv_tol),
]

class AssuraLVSSubmitForm(djforms.Form):
    "LVS job submission form"
    
    PIN_BINDING_CHOICES = (
        ('nil','None'),
        ('top','Toplevel'),
        ('t','All'),
    )
    
    def __init__(self, *args, **kwargs):
        "initializer"
        super(AssuraLVSSubmitForm,self).__init__(*args,**kwargs)
        self.fields['process'] = djforms.ChoiceField(choices=get_pdk_choices('assuralvs'))
        
    email = djforms.EmailField(required=False,widget=djforms.TextInput(attrs={'size':'50'}))
    schematic_file = djforms.FileField(widget=djforms.FileInput(attrs={'size':'50'}))
    schematic_type = djforms.ChoiceField(choices=settings.ASSURA_LVS_SCHEM_CHOICES)
    layout_file = djforms.FileField(widget=djforms.FileInput(attrs={'size':'50'}))
    pin_binding = djforms.ChoiceField(choices=PIN_BINDING_CHOICES)
    net_binding = djforms.BooleanField(required=False)
    match_toplevel_pins = djforms.BooleanField(required=False)
    expand_reduce = djforms.BooleanField(required=False,initial=True)
    expand_match = djforms.BooleanField(required=False,initial=True)
    expand_swap = djforms.BooleanField(required=False,initial=True)
    tolerance_resistor = djforms.CharField(required=False,widget=djforms.TextInput(attrs={'size':'6'}))
    tolerance_capacitor = djforms.CharField(required=False,widget=djforms.TextInput(attrs={'size':'6'}))
    

    def clean_email(self):
        "clean the e-mail address field to make sure it is a MACOM e-mail"
        email = self.cleaned_data['email']
        if not len(email):
            return u''
            
        try:
            domain = email.split('@')[1].lower()
        except:
            raise djforms.ValidationError("Not a valid e-mail address")
            
        if domain not in ('macomtech.com','macom.com'):
            raise djforms.ValidationError("E-mail address must end in @macomtech.com")
        return email

        
def _submit_lvs_job(request, model, top_subckt_name, options, switches, mapping=None):
    "submit an LVS job to the queue"
    fp = open(model.layout_file.get_filesystem_path(),'rb')
    fp2 = open(model.schematic_file.get_filesystem_path(),'rb')
    parms = {
        'job_type': 'assuralvs',
        'notify': 'email = '+model.email+'; result_url = '+_get_result_url(request,'cdsweb.assura_views.lvs_results',model.jobid),
        'process': model.process,
        'lay_file': base64.b64encode(fp.read()),
        'sch_file': base64.b64encode(fp2.read()),
        'top_subckt_name': top_subckt_name,        
        'options': options,
        'switches': switches,
    }
    fp.close()
    fp2.close()
    
    if mapping:
        parms['sch_to_lay_mapping'] = mapping    
    
    return submit_job_to_daemon(parms)                        
    
    
def lvs_system_down(request):
    "system is down page"
    context = default_cdsweb_context()
    context['msg'] = assura_shutdown_message()
    context['tool'] = 'LVS'
    return render(request,'cdsweb/assura_down.htm',context)
    
def lvs_submit(request):
    "submit an Assura LVS job"
    context = default_cdsweb_context()
    
    if assura_is_down():
        return redirect('cdsweb.assura_views.lvs_system_down')
    
    # check to see if the advanced configuration dialog should be expanded when the page loads
    advconf = False
    
    # generate the deck info AJAX URL
    scheme = 'https://' if request.is_secure() else 'http://'
    deckinfo_url = scheme+request.get_host()+reverse('cdsweb.ajax_views.deck_info')
    deckdetails_url = scheme+request.get_host()+reverse('cdsweb.ajax_views.deck_details')
    
    # upload of schematic and layout files plus other metadata for doing LVS
    if request.method == 'POST':
        form = AssuraLVSSubmitForm(request.POST,request.FILES)
        
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()
            
            if form.is_valid():
                data = form.cleaned_data
                
                # create a job identifier
                jobid = random_hash(32)
            
                # move the schematic and layout files to the data storage location
                lay_file = create_attachment_from_upload(request.FILES['layout_file'])
                sch_file = create_attachment_from_upload(request.FILES['schematic_file'])
                
                # check the Assura LVS configuration and see if any switches are defined for the process
                switches = []
                setswitches = []
                try:
                    switches, setswitches = get_deck_switches(data['process'],'lvs.switches')
                except Exception, e:
                    ok = False
                    messages.add_message(request,messages.ERROR,'Configuration error: %s'%e)
                    
                if len(switches):
                    swform = AssuraSwitchForm(switches,request.POST)
                    if swform.is_valid():
                        swdata = swform.cleaned_data
                        sessdata = {}
                        for s in switches:
                            if s.type == 'toggle':
                                if bool(swdata['sw_'+s.name]):
                                    setswitches.append(str(s.name))
                                    sessdata[s.name] = True
                            elif s.type == 'select':
                                v = swdata['sw_'+s.name]
                                if len(v):
                                    setswitches.append(str(v))
                                    sessdata[s.name] = v
                                    
                        # store set switches in the session for reuse
                        swsesskey = _LVS_SWITCH_SESSION_KEY_PREFIX+str(data['process'])
                        if len(sessdata):
                            request.session[swsesskey] = sessdata
                            request.session.set_expiry(8*60*60)
                        else:
                            if swsesskey in request.session:
                                del request.session[swsesskey]
                                    
                    else:
                        ok = False
                        messages.add_message(request,messages.ERROR,'Switch data is invalid')
                        
                # scan both the schematic and layout to get a list of cells in each
                ok = True
                try:
                    sch_cells, toplevel_sch_cells = schemtools.get_subckts_and_toplevels(sch_file.get_filesystem_path(),'CDL')
                    if not len(sch_cells):
                        ok = False
                        messages.add_message(request,messages.ERROR,'Schematic file parse error. No subckts found in file.')
                    elif not len(toplevel_sch_cells):
                        ok = False
                        messages.add_message(request,messages.ERROR,'Schematic file parse error. Recursive dependency: no top-level subcircuits.')
                except Exception, e:
                    ok = False
                    messages.add_message(request,messages.ERROR,'Exception in schematic parse: %s'%e)                
                
                try:
                    lay_cells = list(gdsiitools.get_cell_names(lay_file.get_filesystem_path()))
                    if not len(lay_cells):
                        ok = False
                        messages.add_message(request,messages.ERROR,'GDSII file parse error. No cells found in file.')
                except Exception, e:
                    ok = False
                    messages.add_message(request,messages.ERROR,'Exception in GDSII parse: %s'%e)
                
                # process advanced options and store them in the session
                opts = _store_advanced_options(data,request,_LVS_ADVANCED_OPTIONS,_LVS_OPT_SESSION_KEY)
                
                if ok:
                    #
                    # handle ADS2011+ long schematic names by stripping the library name and view name
                    # unless more that one library is present, in which case the first library that is
                    # encountered is used as the default and the other libraries get prepended to the
                    # cell names
                    #
                    # this same procedure is used to re-write the schematic file during the Assura
                    # LVS pre-processing phase, so the schematic subckt name re-writes that happen here
                    # for the web interface will also be reflected in the schematic file when the LVS
                    # process is run by the job queue
                    #
                    tsch = []
                    libname = None
                    for c in sch_cells:
                        cspl = c.split(':')
                        if len(cspl) == 3:
                            if libname is None or libname == cspl[0]:
                                tsch.append(cspl[1])
                                if libname is None:
                                    libname = cspl[0]                    
                            else:
                                tsch.append('%s:%s'%(cspl[0],cspl[1]))
                        else:
                            tsch.append(c)
                    sch_cells = tsch            
                    
                    # sort the cells/subckts alphabetically
                    sch_cells.sort()
                    lay_cells.sort()
                                        
                    # store stuff in the session
                    jobsesskey = 'lvs_'+jobid
                    request.session[jobsesskey] = {
                        'options':opts,
                        'switches':setswitches,
                        'sch_cells':sch_cells,
                        'lay_cells':lay_cells,
                        'top_subckts':toplevel_sch_cells,
                        }
                    
                    # create job parameter information to hand back to the queue system
                    optstr = ''
                    if opts:
                        keys = opts.keys()
                        keys.sort()
                        a = []
                        for k in keys:
                            a.append(k+' = '+str(opts[k]))
                        optstr = ', '.join(a)
                    dispparms = [
                        (u'Job Type',u'LVS'),
                        (u'Process',data['process']),
                        (u'Schematic File',sch_file.name),
                        (u'Schematic Type',u'CDL'),
                        (u'Layout File',lay_file.name),
                        (u'Switches',', '.join(setswitches)),
                        (u'Options',optstr),
                    ]
                                        
                    #### store data in the database ####
                    model_data = {
                        'jobid':jobid,
                        'process':data['process'],
                        'email':data['email'],
                        'layout_file':lay_file,
                        'schematic_file':sch_file,
                        'status':'Q',
                        'parameters':pickle.dumps(dispparms),
                    }
                    model = AssuraLVSJob(**model_data)
                    
                    #### decide which step to move on to next ####
                    cookiedat = {'process':data['process'],'email':data['email'],'schematic_type':data['schematic_type']}
                    if len(sch_cells) > 1 or sch_cells[0] not in lay_cells:
                        # more than 1 schematic subckt, or the hierarchy doesn't exactly match
                        # go to the next step of hierarchy reconciliation
                        model.save()
                        resp = redirect('cdsweb.assura_views.lvs_reconcile', jobid)
                        return set_lvsdrc_cookie_data(request,resp,_LVS_COOKIE_KEY,cookiedat)
                    else:
                        # everything is OK for direct submission
                        try:
                            model.submission_id = _submit_lvs_job(request,model,sch_cells[0],opts,setswitches)
                        except Exception, e:
                            model.status = 'F'
                            model.status_message = u'Fatal Error in job submission: '+unicode(e)
                            messages.add_message(request,messages.ERROR,'Fatal Error in job submission: %s %s'%(type(e),e))
                    
                    # save the model                     
                    model.save()
                    
                    # redirect to the results view
                    resp = redirect('cdsweb.assura_views.lvs_results', model.jobid)
                    store_job_history(request,resp,model)
                    return set_lvsdrc_cookie_data(request,resp,_LVS_COOKIE_KEY,cookiedat)
                                    
                else:
                    # delete the uploaded files
                    sch_file.delete()
                    lay_file.delete()
            else:
                # error message
                messages.add_message(request, messages.ERROR, 'Please fill out all form fields.')
        else:
            # test cookie failed
            messages.add_message(request, messages.ERROR, 'Cookies must be enabled!!! Enable cookies in your browser and reload the page!')
    else:
        # unbound form
        idat = get_lvsdrc_cookie_data(request,_LVS_COOKIE_KEY)
        if _LVS_OPT_SESSION_KEY in request.session:
            # set advanced configuration parameters
            idat.update(request.session[_LVS_OPT_SESSION_KEY])
            advconf = True
        
        form = AssuraLVSSubmitForm(initial=idat)
    
    context['form'] = form
    context['deckinfo_url'] = deckinfo_url
    context['deckdetails_url'] = deckdetails_url
    if advconf:
        context['advanced_options_classname'] = ' show-expanded'
    request.session.set_test_cookie()
    context['history'] = get_job_history(request)
    
    return render(request,'cdsweb/lvs_submit.htm',context)

def lvs_reconcile(request, jobid):
    "reconcile necessary matching between schematic and layout"
    model = get_object_or_404(AssuraLVSJob,pk=jobid)
    context = default_cdsweb_context()
    
    # get the session dictionary
    jobsesskey = 'lvs_'+model.jobid
    sessdict = request.session[jobsesskey]
    
    sch_cells = sessdict['sch_cells']
    lay_cells = sessdict['lay_cells']
    options = sessdict['options']
    switches = sessdict['switches']
    top_subckts = sessdict['top_subckts']
    sch2lay_mapping = {}
    
    need_tl_sch = False
    if len(sch_cells) > 1:
        if len(top_subckts) == 1:
            sch_toplevel = top_subckts[0]
        else:
            sch_toplevel = ''
        need_tl_sch = True        
        schem_cell_choices = [('','---------')]
        for c in sch_cells:
            schem_cell_choices.append( (c,c) )

        # create a form to select the top subckt
        class TopSubcktSelectForm(djforms.Form):
            "match layout cells to schematic subcircuits"
            subckt = djforms.ChoiceField(choices=schem_cell_choices)
    else:
        sch_toplevel = sch_cells[0]
        
    
    # generate a list of layout cells that are unmatched to schematic subckts
    unmatched_subckts = sch_cells[:]
    layout_cell_choices = [('','---------')]
    for c in lay_cells:
        if c in unmatched_subckts:
            del unmatched_subckts[unmatched_subckts.index(c)]
        else:
            layout_cell_choices.append( (c,c) )
    
    # generate the form and formset for cell matching
    need_matching_forms = False
    if len(unmatched_subckts):
        need_matching_forms = True
        class LayToSchMatchForm(djforms.Form):
            "match layout cells to schematic subcircuits"
            subckt = djforms.CharField(widget=djforms.HiddenInput)
            laycell = djforms.ChoiceField(choices=layout_cell_choices,required=False)
        LayToSchMatchFormSet = formset_factory(LayToSchMatchForm, extra=0)
    
    if request.method == 'POST':    
        ok = True
        if need_tl_sch:
            form = TopSubcktSelectForm(request.POST)
            context['toplevel_form'] = form
            context['do_toplevel'] = True
            if form.is_valid():
                # store the top subckt data in the database
                sch_toplevel = form.cleaned_data['subckt']
            else:
                ok = False        
        else:
            context['top_level'] = sch_toplevel            
        
        if need_matching_forms:
            formset = LayToSchMatchFormSet(request.POST)
            context['match_formset'] = formset
            context['do_matching'] = True
            if formset.is_valid():
                # iterate through the cleaned data and generate the mapping of layout cell to schematic
                for data in formset.cleaned_data:
                    if data['laycell']:
                        sch2lay_mapping[data['subckt']] = data['laycell']
                
                try:
                    # validate the user's mapping selection
                    validate_sch2lay_mapping(sch_cells,lay_cells,sch2lay_mapping,sch_toplevel)
                except Exception, e:
                    ok = False
                    messages.add_message(request,messages.ERROR,str(e))
            else:
                ok = False
                                        
        if ok:
            # validation of submitted data was OK
            # now we are ready to submit the LVS job
            
            # store the top-level schematic and schematic-to-layout mapping in the session
            sessdict['top_subckt'] = sch_toplevel
            sessdict['sch2lay_mapping'] = sch2lay_mapping
            request.session[jobsesskey] = sessdict

            # update the parameters of the model
            dispparms = pickle.loads(str(model.parameters))
            if need_tl_sch:
                dispparms.append((u'Top Subckt Name',sch_toplevel))
            if sch2lay_mapping:
                sclist = sch2lay_mapping.keys()
                sclist.sort()
                lst = []
                for s in sclist:
                    lst.append(s+' => '+sch2lay_mapping[s])
                dispparms.append((u'Sch-to-Lay Mappings','; '.join(lst)))
            model.parameters = pickle.dumps(dispparms)
            
            # try to submit the LVS job
            try:
                model.submission_id = _submit_lvs_job(request,model,sch_toplevel,options,switches,mapping=sch2lay_mapping)
            except Exception, e:
                model.status = 'F'
                model.status_message = u'Fatal Error in job submission: '+unicode(e)
                messages.add_message(request,messages.ERROR,'Fatal Error in job submission: %s %s'%(type(e),e))
            
            # save the model                     
            model.save()
            
            # store history and redirect
            resp = redirect('cdsweb.assura_views.lvs_results', model.jobid)
            store_job_history(request,resp,model)
            return resp
            
    else:
        # prepare initial data
        if need_tl_sch:
            context['toplevel_form'] = TopSubcktSelectForm(initial={'subckt':sch_toplevel})
            context['do_toplevel'] = True
        else:
            context['top_level'] = sch_toplevel
        
        if need_matching_forms:
            initial = []
            for c in unmatched_subckts:
                initial.append( {'subckt':c} )
            context['match_formset'] = LayToSchMatchFormSet(initial=initial)
            context['do_matching'] = True
    
    return render(request,'cdsweb/lvs_reconcile.htm',context)
    
def lvs_results(request, jobid):
    "submission finished"
    model = get_object_or_404(AssuraLVSJob,pk=jobid)
    parms = pickle.loads(str(model.parameters))
    parms.append((u'Job ID',unicode(model.submission_id)))
    
    results_url = reverse('cdsweb.ajax_views.lvs_results')+'?id='+str(jobid)
    
    context = default_cdsweb_context( {'results_url':results_url,'params':parms} )
    context['history'] = get_job_history(request)
    context['model'] = model
    return render(request,'cdsweb/lvs_results.htm',context)

def lvs_zipfile(request, jobid):
    "get a zipfile of all job results"
    model = get_object_or_404(AssuraLVSJob,pk=jobid)
    return _get_zipped_files(model)
    
    
    
