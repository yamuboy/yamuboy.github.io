import pickle
import binascii
import os, os.path
from datetime import datetime, timedelta, date
import time
import base64

from django.conf import settings
from django.contrib import messages
from django.shortcuts import redirect

from cdsweb.utils import get_pdk_choices, get_assura_deck_path, read_assura_switches, random_hash
from cdsweb.models import AssuraJobHistory, AssuraLVSJob, AssuraDRCJob, AssuraXORJob
from qserver import qserver_connect

# import pysvn for looking up SVN information
try:
    import pysvn
except ImportError:
    pysvn = None

JOB_HISTORY_COOKIE_NAME = 'drc_lvs_history'    
    
def validate_sch2lay_mapping(sch_cells, lay_cells, mapping, sch_toplevel):
    """validate the schematic-to-layout mapping, raises exceptions for all errors found
    
    """
    # check the top-level mappings
    if not sch_toplevel:
        raise ValueError("The schematic top-level sub-circuit is not defined.")
    elif sch_toplevel not in sch_cells:
        raise ValueError("'%s' is not a valid top-level schematic sub-circuit name."%sch_toplevel)
    
    if sch_toplevel not in lay_cells:
        if sch_toplevel not in mapping:
            raise ValueError("Top-level sub-circuit '%s' must be mapped to a layout cell."%sch_toplevel)
        elif mapping[sch_toplevel] not in lay_cells:
            raise ValueError("The mapping of top-level sub-circuit '%s' is invalid."%sch_toplevel)
    
    # check the rest of the mappings
    used_cells = set()
    dups = []
    for sch, lay in mapping.iteritems():
        if sch not in sch_cells:
            raise ValueError("In the mapping dictionary - schematic sub-circuit name '%s' is invalid."%sch)
        if lay not in lay_cells:
            raise ValueError("In the mapping dictionary - layout cell name '%s' is invalid."%lay)
        
        if lay in used_cells:
            dups.append(lay)
        else:
            used_cells.add(lay)
    if dups:
        raise ValueError('Duplicate mappings to layout cells: '+(', '.join(dups)))
        
def hierarchy_match(sch_cells, lay_cells):
    "check for a hierarchy match between schematic and layout cells"
    if len(lay_cells) < len(sch_cells):
        return False
        
    for sc in sch_cells:
        if sc not in lay_cells:
            return False
    
    return True

def _get_choice_value(choices, value):
    "get the label string for a choice given it's value"
    for v,n in choices:
        if v == value:
            return n
    return u''    
    
def get_deck_switches( process, switch_file ):
    "get the deck switches for the given process"
    p = get_assura_deck_path('*',process)
    if not p:
        raise ValueError("process '%s' is not configured properly"%process)
        
    deckpath = os.path.join(settings.CDSWEB_DECK_PATH,p)
    if not os.path.isdir(deckpath):
        raise IOError("deck path '%s' is invalid"%deckpath)
        
    # read the switches file if it exists and return the switch configuration
    swfile = os.path.join(deckpath,switch_file)
    if os.path.isfile(swfile):
        return read_assura_switches(swfile)
        
    return [], []

C2M_MAPPING = {
    'em': 'email',
    'pr': 'process',
    'st': 'schematic_type',
}


M2C_MAPPING = {}
for k,v in C2M_MAPPING.iteritems():
    M2C_MAPPING[v] = k
del k, v
    
def get_lvsdrc_cookie_data( request, key, decode=True ):
    "get cookie data and process it, returning a dictionary"
    
    if key not in request.COOKIES:
        return {}
    
    try:
        # convert back from base64 and unpickle
        cdat = pickle.loads(binascii.a2b_base64(str(request.COOKIES[key])))
    except Exception:
        return {}
    
    ret = {}
    for k,v in cdat.iteritems():
        if k in C2M_MAPPING:
            if decode:
                ret[C2M_MAPPING[k]] = v
            else:
                ret[k] = v
    
    return ret
        

def set_lvsdrc_cookie_data( request, response, key, params ):
    "set cookie data"
    
    # start with existing cookie data
    cdat = get_lvsdrc_cookie_data(request,key,decode=False)
    
    # add/replace data
    for k,v in params.iteritems():
        if k in M2C_MAPPING:
            cdat[M2C_MAPPING[k]] = v
    
    # pickle the structure and convert to base64 encoding 
    s = binascii.b2a_base64(pickle.dumps(cdat,pickle.HIGHEST_PROTOCOL))
    
    # set the cookie and make it valid for 20 days
    response.set_cookie(key,s,max_age=60*60*24*20)
    return response

def submit_job_to_daemon( payload, auth_as=None ):
    "submit a job to the Assura queuing daemon"
    
    # create a connection to the queue server
    # and submit the job
    if settings.CDSWEB_TEST_MODE:
        resp = {'id': 99999999}
    else:
        conn = qserver_connect(authenticate=True,authenticate_as=auth_as)
        resp = conn.command('SUBMIT',payload)
        conn.close()
    
    # return the resulting submission id
    return resp['id']
    

def get_deck_status( process, files ):
    "get the deck information for the given process"
    p = get_assura_deck_path('*',process)
    if not p:
        raise ValueError("process '%s' is not configured properly"%process)
        
    deckpath = os.path.join(settings.CDSWEB_DECK_PATH,p)
    if not os.path.isdir(deckpath):
        raise IOError("deck path '%s' is invalid"%deckpath)
    
    # get deck information
    deckinfo = []
    for fn in files:
        deckinfo.append( _deck_file_info(fn,deckpath) )
    
    return deckinfo
    
def get_detailed_deck_file_info( process, file, detailed=False ):
    "get detailed information on a single deck file"
    p = get_assura_deck_path('*',process)
    if not p:
        raise ValueError("process '%s' is not configured properly"%process)
    deckpath = os.path.join(settings.CDSWEB_DECK_PATH,p)
    
    return _deck_file_info(file,deckpath,True)
    
    
def _normalize_deck_path( p ):
    "normalize the deck path"
    base = os.path.normpath(settings.CDSWEB_DECK_PATH).rstrip('/\\')
    p = os.path.normpath(p)
    if p.startswith(base):
        return '${DECKPATH}'+p[len(base):]
    else:
        return p
    
    
def _deck_file_info( fname, path, detailed=False ):
    "get information about a given deck file"
    
    fpath = os.path.join(path,fname)
    realpath = os.path.realpath(fpath)
    info = { 'name':fname, 'path':_normalize_deck_path(fpath), 'realpath':realpath }
    
    # get the last modified timestamp
    info['last_modified'] = datetime.fromtimestamp(os.stat(realpath).st_mtime).strftime('%Y/%m/%d %H:%M:%S')
    
    if detailed:
        # get file header info
        info['file_header'] = ''
        try:
            head = []
            fp = open(realpath,'rU')
            for line in fp:
                ls = line.strip()
                if not ls.startswith(';'):
                    break
                head.append(ls)            
            fp.close()
            
            # strip out header information that is not necessary
            for i,line in enumerate(head):
                if line.find('----Change Log----') > -1:
                    head = head[i:]
                    break
            
            info['file_header'] = '\n'.join(head)
        except Exception, e:
            print e        
        
        # get the SVN revision number, status, and log info
        info['svn_rev'] = ''
        info['svn_status'] = ''
        info['svn_log'] = []
        try:
            if pysvn:
                c = pysvn.Client()
                svnstatus = c.status(realpath)[0]
                svnlogentries = c.log(realpath,limit=10)
                del c
                
                info['svn_status'] = str(svnstatus.text_status)
                rev = svnstatus.entry.revision
                if rev:
                    info['svn_rev'] = rev.number
                
                outlog = []
                for log in svnlogentries:
                    dt = datetime.fromtimestamp(log.date).strftime('%Y/%m/%d %H:%M:%S')
                    outlog.append( (log.revision.number,log.author,dt,log.message) )
                info['svn_log'] = outlog
        
        except Exception, e:
            pass
                
    return info
    
def get_job_history(request):
    "return a QuerySet of job history, or an empty QuerySet"
    if JOB_HISTORY_COOKIE_NAME in request.COOKIES:
        return AssuraJobHistory.objects.filter(uid__exact=request.COOKIES[JOB_HISTORY_COOKIE_NAME])[:20]
    else:
        return AssuraJobHistory.objects.none()
        

def store_job_history(request, response, model):
    "store job history for a newly created job"
    if JOB_HISTORY_COOKIE_NAME in request.COOKIES:
        uid = request.COOKIES[JOB_HISTORY_COOKIE_NAME]
    else:
        uid = random_hash(64)
    
    dstr = date.today().strftime('%Y/%m/%d')
    
    if isinstance(model,AssuraLVSJob):
        desc = 'LVS job '+str(model.submission_id)+(u' (%s; %s; %s; %s)'%(model.process,model.layout_file.name,model.schematic_file.name,dstr))
        viewname = 'lvs_results'
    elif isinstance(model,AssuraDRCJob):
        desc = 'DRC job '+str(model.submission_id)+(u' (%s; %s; %s)'%(model.process,model.layout_file.name,dstr))
        viewname = 'drc_results'    
    elif isinstance(model,AssuraXORJob):
        desc = 'XOR job '+str(model.submission_id)+(u' (%s; %s; %s)'%(model.layout_file1.name,model.layout_file2.name,dstr))
        viewname = 'xor_results'    
    else:
        # don't know how to save history
        return response
    
    
    # create the job history object and store it
    parms = {
        'uid': uid,
        'desc': desc,
        'viewname': viewname,
        'model_id': model.jobid,
    }
    model = AssuraJobHistory(**parms)
    model.save()
    
    # update the response cookie and return
    response.set_cookie(JOB_HISTORY_COOKIE_NAME,uid,max_age=60*60*24*30)
    return response
    
def clear_job_history(request,response):
    "clear job history for a given browser uid"
    if JOB_HISTORY_COOKIE_NAME in request.COOKIES:
        uid = request.COOKIES[JOB_HISTORY_COOKIE_NAME]
        AssuraJobHistory.objects.filter(uid__exact=uid).delete()
        response.delete_cookie(JOB_HISTORY_COOKIE_NAME)
    
    return response
    
    




    