from django.http import HttpResponse, Http404
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.conf import settings
from django.contrib import messages
from django import forms as djforms
from django.forms.formsets import formset_factory
from django.utils.html import escape
from django.template import loader, Context, RequestContext
from django.template.loader import render_to_string
from django.core.urlresolvers import reverse

from cdsweb.utils import get_pdk_choices, default_cdsweb_context, random_hash, \
    create_attachment_from_qserve
from cdsweb.assura_utils import get_deck_switches, get_deck_status, get_detailed_deck_file_info
from cdsweb.models import AssuraDRCJob, AssuraLVSJob, Attachment
from cdsweb.assura_views import _DRC_SWITCH_SESSION_KEY_PREFIX, _LVS_SWITCH_SESSION_KEY_PREFIX
from cdsweb.qserver import qserver_connect

import json
import pickle


class MyJSONResponse(HttpResponse):
    "JSON response object"
    
    def __init__(self, data, **kwargs):
        "initializer"
        # convert the data to JSON format
        jsondata = json.dumps(data)       
        # initialize the parent class
        if 'content_type' in kwargs:
            # don't allow content_type to be overridden
            del kwargs['content_type']
        super(MyJSONResponse,self).__init__(jsondata, content_type='application/json; charset=utf-8', **kwargs)
        
        
def deck_info(request):
    "get the process information"
    
    if not request.is_ajax():
        raise ValueError('not an AJAX request')
    
    # retrieve GET variables
    process = request.GET.get('p','')
    tool = request.GET.get('t','').lower()
    
    if not process:
        return MyJSONResponse( {'errorInfo':'process is not set'}, status=500 )
        
    if not tool:
        return MyJSONResponse( {'errorInfo':'tool is not set'}, status=500 )
        
        
    # get the switch information for the process and the modified dates for the
    # deck files that are used
    if tool == 'drc':
        switches, fixedswitches = get_deck_switches(process,'drc.switches')
        deckinfo = get_deck_status(process,['drc.rul'])
        sesskey = _DRC_SWITCH_SESSION_KEY_PREFIX+str(process)
    elif tool == 'lvs':
        switches, fixedswitches = get_deck_switches(process,'lvs.switches')
        deckinfo = get_deck_status(process,['extract.rul','compare.rul'])
        sesskey = _LVS_SWITCH_SESSION_KEY_PREFIX+str(process)
    else:
        return MyJSONResponse( {'errorInfo':'tool is not valid'}, status=500 )
        
    # get session data
    sessdata = request.session.get(sesskey,{})
        
    # format switch data
    swdata = []
    for s in switches:
        if s.type == 'toggle':
            swdata.append( {'type': 'toggle', 'name':s.name, 'desc':s.desc, 'label':s.label, 'checked':sessdata.get(s.name,s.value) } )
        elif s.type == 'select':
            selentries = []
            sval = sessdata.get(s.name,s.value)
            for c in s.choices:
                selentries.append( {'label': c[1], 'value': c[0], 'selected': True if sval == c[0] else False } )
            swdata.append( {'type': 'select', 'name':s.name, 'desc':s.desc, 'label':s.label, 'entries':selentries } )
    
    # generate the data structure for the returned data
    data = {'switches':swdata, 'deckInfo':deckinfo, 'errorInfo':None}
    
    # render the response as JSON and return
    return MyJSONResponse(data)
    
def deck_details(request):
    "get details about the Assura deck file"
    if not request.is_ajax():
        raise ValueError('not an AJAX request')
    
    # retrieve GET variables
    process = request.GET.get('p','')
    filename = request.GET.get('f','')
    
    if not process:
        return MyJSONResponse( {'html':'<p class="error">process is invalid</p>'} )
        
    if not filename:
        return MyJSONResponse( {'html':'<p class="error">filename is invalid</p>'} )

    # load information about the deck in question
    info = get_detailed_deck_file_info(process,filename,detailed=True)
    t = loader.get_template('cdsweb/ajax_deck_details.htm')
    
    return MyJSONResponse({'html':t.render(RequestContext(request,info))})

def job_status(request):
    "get the simple job status"
    
    st = '<unknown>'
    err = None
    jobid = request.GET.get('id',None)
    httpst = 200
    
    if not jobid:
        httpst = 500
        err = 'invalid or missing "id" parameter'
    else:
        try:
            if settings.CDSWEB_TEST_MODE:
                st = 'demo'
            else:
                c = qserver_connect()
                # get qserver status
                st = c.command('JOBSTATUS', {'id':int(jobid)})['status']
        except Exception, e:
            err = str(e)
            httpst = 500
    
    return MyJSONResponse({'status':str(escape(st)), 'errorInfo':err}, status=httpst)


STATUS_MAPPING = {
    u'Q': '<span style="color:#000066;">Queued</span>',
    u'R': '<span style="color:#0000ff;">Running</span>',
    u'C': '<span style="color:#00bf00;font-weight:bold;">Complete</span>',
    u'F': '<span style="color:#c80000;font-weight:bold;">Failed</span>',
    u'X': '<span style="color:#ff00ff;">Expired</span>',
    }

Q2W_MAPPING = {
    'queued': u'Q',
    'running': u'R',
    'complete': u'C',
    'failed': u'F',
}    
    
def _get_job_results( model, auth_as=None ):
    """get the job results from the underlying queuing system
    
    this is used by both DRC and LVS jobs to check the job
    status and download results
    """
    if model.status in ('Q','R'):
        # need to contact the queue server to see what the
        # status of the job is now
        c = qserver_connect(authenticate=True,authenticate_as=auth_as)
        try:
            r = c.command('jobstatus',{'id':model.submission_id})
            st = Q2W_MAPPING[r['status']]
            if st != model.status:
                model.status = st
                if st in ('Q','R'):
                    # job is still running
                    model.save()
                    return False
            else:
                return False
                
                
            # status has changed (to 'C' or 'F')
            # download the results of the job
            r = c.command('results',{'id':model.submission_id})
            model.status_message = r['comment']
            if r['result_status'] == 'ok':
                model.summary = pickle.dumps(r['summary'])
                flist = []
                for i,f in enumerate(r['files']):
                    flist.append( create_attachment_from_qserve(f,order=i+1) )
                
                if flist:
                    model.result_files = flist
            else:
                # job expired
                model.status = 'X'
                
            model.save()
            
        finally:
            c.close()

        return True
    else:
        # the job has been completed so simply return True and let
        # the LVS/DRC specific code build the response
        return True
    
def drc_results(request):
    "retrieve DRC results"
    jobid = request.GET.get('id',None)
    if not jobid:
        raise Http404()
    model = get_object_or_404(AssuraDRCJob,pk=jobid)
    
    if settings.CDSWEB_TEST_MODE:
        if model.status != 'C':
            model.status = 'C'
            model.status_message = 'DRC complete with errors'
            model.summary = pickle.dumps([
                {'rule':'Rule No. 150 : M2/AS: bridge width > 75 um', 'real_errors':2, 'flat_errors':2, 'cells':[{'name':'cell1','cell_errors':2,'real_errors':2,'cell_placements':1}]},
                {'rule':'Rule No. 151 : M2/AS: air bridge aspect ratio violation', 'real_errors':2, 'flat_errors':2, 'cells':[{'name':'cell1','cell_errors':2,'real_errors':2,'cell_placements':1}]},
                {'rule':'Rule No. 165 : D-FET: gate fingers must be vertical', 'real_errors':28, 'flat_errors':28, 'cells':[{'name':'cell1','cell_errors':28,'real_errors':28,'cell_placements':1}]},
                ])
            model.save()
        r = True
    else:    
        r = _get_job_results(model)
    
    result = {
        'status': STATUS_MAPPING.get(model.status,'<span style="color:#ff0000;">Undefined</span>'),
        'refresh': False,
        }
    
    if r:
        # full results are available
        result['summary'] = _generate_status_markup(model.status_message,model.status)
        
        # build DRC table
        try:
            errsum = pickle.loads(str(model.summary))
        except Exception:
            errsum = []
        if errsum:
            result['details'] = render_to_string('cdsweb/helper_drc_details.htm',{ 'summary':errsum })
        else:
            result['details'] = '<p class="note">No DRC errors.</p>'
        
        files = model.result_files.all()
        if files:
            context = {
                'files': files,
                'zip_url': reverse('cdsweb.assura_views.drc_zipfile',args=[model.jobid]),
                'view_icon': settings.STATIC_URL+'img/view-32x32.png',
                'dl_icon': settings.STATIC_URL+'img/dl-32x32.png',
            }
            result['files'] = render_to_string('cdsweb/helper_file_table.htm',context)
        else:
            result['files'] = '<p class="note">No files.</p>'
    else:
        # need to refresh to get results (job is still running)
        result['refresh'] = True
    
    return MyJSONResponse(result)    
    
def lvs_results(request):
    "retrieve LVS results"
    jobid = request.GET.get('id',None)
    if not jobid:
        raise Http404()
    model = get_object_or_404(AssuraLVSJob,pk=jobid)
    
    if settings.CDSWEB_TEST_MODE:
        if model.status != 'C':
            model.status = 'C'
            model.status_message = 'LVS complete with errors'
            model.summary = pickle.dumps([])
            model.save()
        r = True
    else:    
        r = _get_job_results(model)
    
    result = {
        'status': STATUS_MAPPING.get(model.status,'<span style="color:#ff0000;">Undefined</span>'),
        'refresh': False,
        }
    
    if r:
        # full results are available
        result['summary'] = _generate_status_markup(model.status_message,model.status)
        
        # build LVS table
        try:
            lvssum = pickle.loads(str(model.summary))
        except Exception:
            lvssum = {}
        
        if lvssum:
            result['details'] = render_to_string('cdsweb/helper_lvs_details.htm',{ 'summary':lvssum })
        else:
            result['details'] = '<p class="note">No details available.</p>'
        
        files = model.result_files.all()
        if files:
            context = {
                'files': files,
                'zip_url': reverse('cdsweb.assura_views.lvs_zipfile',args=[model.jobid]),
                'view_icon': settings.STATIC_URL+'img/view-32x32.png',
                'dl_icon': settings.STATIC_URL+'img/dl-32x32.png',
            }
            result['files'] = render_to_string('cdsweb/helper_file_table.htm',context)
        else:
            result['files'] = '<p class="note">No files.</p>'
    else:
        # need to refresh to get results (job is still running)
        result['refresh'] = True
    
    return MyJSONResponse(result)
    
def _generate_status_markup( status_message, st ):
    "generate markup for the status message"
    
    stlist = status_message.split('|')
    s = unicode(escape(stlist[0]))
    if len(stlist) > 1:
        s += u'<ul>'
        for m in stlist[1:]:
            s += u'<li>'+unicode(escape(m))+u'</li>'
        s += u'</ul>'
    
    return s
        
    
    
