from django.conf.urls import patterns, include, url

urlpatterns = patterns('cdsweb.gds_views',
    url(r'^rewrite/$','gdsii_rewrite'),
    url(r'^rewrite/done/([a-zA-Z0-9]{10,})/$','gdsii_rewrite_done'),
    url(r'^info/$','gdsii_info_upload'),
    url(r'^info/([a-zA-Z0-9]{10,})/$','gdsii_info'),
    url(r'^markers/$','gdsii_marker_upload'),
    url(r'^markers/([a-zA-Z0-9]{10,})/$','gdsii_marker_config'),
    url(r'^markers/([a-zA-Z0-9]{10,})/result/$','gdsii_marker_result'),
)
