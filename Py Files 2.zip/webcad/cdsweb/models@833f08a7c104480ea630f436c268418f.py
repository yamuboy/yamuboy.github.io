from django.db import models
from django.db.models.signals import post_delete
from django.core.urlresolvers import reverse
from django.conf import settings
import os, os.path


class AssuraJobBase(models.Model):
    "base class for Assura jobs"
    jobid = models.CharField(max_length=64,primary_key=True)
    process = models.CharField(max_length=100)
    email = models.EmailField(blank=True)
    submission_id = models.IntegerField(blank=True,null=True)
    submit_date = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=1)
    status_message = models.TextField(blank=True)
    parameters = models.TextField(blank=True)
    summary = models.TextField(blank=True)
    
    class Meta:
        abstract=True
    
    
class AssuraLVSJob(AssuraJobBase):
    "Assura LVS job information"
    
    schematic_file = models.ForeignKey('Attachment',related_name='+',null=True,on_delete=models.SET_NULL)
    layout_file = models.ForeignKey('Attachment',related_name='+',null=True,on_delete=models.SET_NULL)
    result_files = models.ManyToManyField('Attachment',related_name='lvsjob')
        
    def __unicode__(self):
        return 'Assura LVS: id = '+unicode(self.jobid)
    
    
class AssuraDRCJob(AssuraJobBase):
    "Assura LVS job information"
    
    layout_file = models.ForeignKey('Attachment',related_name='+',null=True,on_delete=models.SET_NULL)
    result_files = models.ManyToManyField('Attachment',related_name='drcjob')
        
    def __unicode__(self):
        return 'Assura DRC: id = '+unicode(self.jobid)

class AssuraJobHistory(models.Model):
    "keep track of recently run DRC/LVS jobs"
    uid = models.CharField(max_length=64)
    datestamp = models.DateTimeField(auto_now=True)
    desc = models.CharField(max_length=255)
    viewname = models.CharField(max_length=64)
    model_id = models.CharField(max_length=64)
    
    class Meta:
        ordering = ('-datestamp',)
    
    def __unicode__(self):
        return 'History: uid = '+unicode(self.uid)+', model id = '+unicode(self.model_id)
    
    def get_job_url(self):
        "return the full view name"
        return reverse('cdsweb.assura_views.'+self.viewname,args=[self.model_id])
        
class GDSRewriteJob(models.Model):
    "GDSII re-writer information"
    
    jobid = models.CharField(max_length=64,primary_key=True)
    infile = models.ForeignKey('Attachment',related_name='+',null=True,on_delete=models.SET_NULL)
    outfile = models.ForeignKey('Attachment',related_name='+',null=True,on_delete=models.SET_NULL)
    submit_date = models.DateTimeField(auto_now=True)
        
    def __unicode__(self):
        return 'GDS rewrite: id = '+unicode(self.jobid)
    
        
class Attachment(models.Model):
    "File attachment for output"
    id = models.CharField(max_length=64,primary_key=True)
    name = models.CharField(max_length=255)
    desc = models.TextField()
    mimetype = models.CharField(max_length=128)
    size = models.IntegerField()
    expires = models.DateTimeField()
    order = models.IntegerField(default=0)
    
    class Meta:
        ordering = ('order','name')
        
    def __unicode__(self):
        return 'Attachment: id = '+unicode(self.id)+', name = '+self.name
    
    def get_absolute_url(self):
        "return the URL to get this object"
        return reverse('cdsweb.assura_views.get_attachment',args=[self.id])
    
    def get_filesystem_path(self):
        "get the filesystem path to the file"
        return os.path.join(settings.CDSWEB_DATA_PATH,self.id)
    
    
# connect a signal to the delete of Attachment objects to
# remove them from the disk

def clean_up_attachment_file(sender, instance, **kwargs):
    "clean up the attachment file on the disk"
    try:
        os.unlink(instance.get_filesystem_path())
    except Exception:
        pass
    
post_delete.connect(clean_up_attachment_file,sender=Attachment)    
    
