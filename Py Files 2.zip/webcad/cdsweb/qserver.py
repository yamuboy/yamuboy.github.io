
from django.conf import settings
from cdsqueue.client import QserveClient


def qserver_connect(authenticate=False, authenticate_as=None):
    "connect to the queue server"
    
    kw = {'socket_path': settings.CDSWEB_QSERVE_SOCKET_PATH}
    timeout = settings.CDSWEB_QSERVE_SOCKET_TIMEOUT
    if timeout:
        kw['timeout'] = timeout
    if settings.CDSWEB_QSERVE_USE_SSL:
        kw['secure'] = True
    
    # create the connection
    conn = QserveClient(**kw)
    
    if authenticate:
        # authenticate the user
        if not authenticate_as or authenticate_as=='cdsweb':
            args = (settings.CDSWEB_QSERVE_USER,settings.CDSWEB_QSERVE_PASSWORD)
        elif authenticate_as == 'foundry':
            args = (settings.CDSWEB_QSERVE_FOUNDRY_USER,settings.CDSWEB_QSERVE_FOUNDRY_PASSWORD)
        else:
            raise ValueError("invalid `authenticate_as` parameter")
        
        try:
            conn.login(*args)
        except Exception:
            conn.close()
            raise
    
    return conn
        
