from django.conf.urls import patterns, include, url

urlpatterns = patterns('cdsweb.ajax_views',
    url(r'^deckinfo/$','deck_info'),
    url(r'^deckdetails/$','deck_details'),
    url(r'^jobstatus/$','job_status'),
    url(r'^drcresults/$','drc_results'),
    url(r'^lvsresults/$','lvs_results'),
    url(r'^xorresults/$','xor_results'),
)
