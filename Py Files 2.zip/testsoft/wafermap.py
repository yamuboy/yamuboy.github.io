﻿from __future__ import division, print_function, unicode_literals, absolute_import
import ast
import logging

class WaferMap(object):
    """Structure to hold wafer map information."""

    _log = logging.getLogger(__name__)

    def __init__(self, fname=None):
        """Initialize."""
        self.__xi = 0
        self.__yi = 0
        self.__xa = 0.0
        self.__ya = 0.0
        self.__mf = 'N'
        self.__sites = []

        if fname is not None:
            self.read_map(fname)

    def read_map(self, fname):
        """Read a wafer map file.

        The wafer map file has the following format:
        ---------------------------------
        xindex: XXXXX
        yindex: YYYYY
        xalpha: AA.AA
        yalpha: BB.BB
        majorflat: Z

        [sites]
        x1 y1 {'key1': val1, 'key2': val2}
        x2 y2 {'key1': val1,'key2': val2}
        x3 y3 {'key1':val1,'key2':val2}
        .
        .
        .
        ---------------------------------

        Where:
        XXXXX is the step index for X at 25 degC (positive integer)
        YYYYY is the step index for Y at 25 degC (positive integer)
        AA.AA is the thermal coefficient of expansion in the X direction in um/degC (optional, set to 0.0 if omitted)
        BB.BB is the thermal coefficient of expansion in the Y direction in um/degC (optional, set to 0.0 if omitted)
        Z is either N, S, W, or E for the position of the major flat

        Each line can optionally include a string-formatted dictionary to store with each site
        Any whitespace separation within dictionary is handled correctly.

        Any line with a leading '#' is a comment

        """

        # clear any existing data in map
        self.__init__()

        f = open(fname,'rU')
        startsites = False
        try:
            for line in f:
                if line.startswith('#'):
                    continue

                line = line.strip()
                if not startsites:
                    if line.startswith('xindex:'):
                        self.set_xindex(int(line[7:]))
                    elif line.startswith('yindex:'):
                        self.set_yindex(int(line[7:]))
                    elif line.startswith('xalpha:'):
                        self.set_xalpha(float(line[7:]))
                    elif line.startswith('yalpha:'):
                        self.set_yalpha(float(line[7:]))
                    elif line.startswith('majorflat:'):
                        mf = line[10:].strip()
                        self.set_mf(mf)
                    elif line.startswith('[sites]'):
                        startsites = True
                else:
                    if not len(line):
                        continue

                    try:
                        linedata = tuple(line.split())

                        # if no optional data dict included
                        if len(linedata) == 2:
                            x,y = linedata
                            data = {}

                        # if optional data dict included
                        elif len(linedata) >= 3:
                            # combine any remaining tokens into single string
                            x,y,datastring = linedata[0], linedata[1], ''.join(linedata[2:])
                            # try to parse string into dictionary
                            try:
                                data = ast.literal_eval(datastring)
                            except:
                                self._log.warning("Unable to parse optional data dictionary for this site, ignoring data")
                                data = {}

                        self.add_site(x,y,data)

                    except Exception as e:
                        self._log.warning("illegal line '%s' in file '%s'"%(line,fname))
                        continue

        finally:
            f.close()

    def update_map(self, fname):
        """
        Updates the map with the map defined in the given filename by
        updating any existing sites, and appending any additional sites
        to the end of the map, regardless of their location in the file
        """

        # create a new map from the given file
        new_map = WaferMap(fname)

        # iterate over new map
        for site in new_map:
            coordinates = (site[0], site[1])
            new_data = site[2]

            # site already in original map
            if coordinates in self:
                index = self.get_site_index(coordinates[0], coordinates[1])

                # no change to original site in new map
                if self.get_site_data(index) == new_data:
                    pass

                # new map has different data for site existing in original map
                else:
                    originalSite = self.__sites[index]
                    self.__sites[index] = site
                    self._log.info(("Updated site ", originalSite, " with data ", new_data))

            # site not in original map
            else:
                self.add_site(site[0], site[1], site[2])
                self._log.info(("Added site ", site))

    def set_xindex(self, x):
        """Set the X index."""
        x = int(x)
        if x <= 0:
            raise ValueError("X-index must be greater than 0.")
        self.__xi = x

    def set_yindex(self, y):
        """Set the Y index."""
        y = int(y)
        if y <= 0:
            raise ValueError("Y-index must be greater than 0.")
        self.__yi = y

    def set_xalpha(self, x):
        """Set the X alpha."""
        x = float(x)
        self.__xa = x

    def set_yalpha(self, y):
        """Set the Y alpha."""
        y = float(y)
        self.__ya = y

    def set_mf(self, mf):
        """Set the major flat location."""
        mf = mf.upper()
        if mf not in ('N','S','W','E'):
            raise ValueError("Invalid major flat position '%s'"%mf)
        self.__mf = mf

    def add_site(self, x, y, data=None):
        """Add a site to the map."""
        x, y = int(x), int(y)
        if x <= 0 or y <= 0:
            raise ValueError("site IDs must be positive integers.")
        if data is not None and not isinstance(data, dict):
            raise ValueError("site data must be a dictionary.")
        self.__sites.append( (x,y,data) )

    def compute_pos(self, idx, startidx=0, tdelta=0.0):
        """Compute the differential position from the starting index with the given temperature delta from reference"""
        indexing_map = dict(
            N=((self.__xi + tdelta*self.__xa), -(self.__yi + tdelta*self.__ya)),
            S=(-(self.__xi + tdelta*self.__xa), (self.__yi + tdelta*self.__ya)),
            E=(-(self.__yi + tdelta*self.__ya), -(self.__xi + tdelta*self.__xa)),
            W=((self.__yi + tdelta*self.__ya), (self.__xi + tdelta*self.__xa))
        )
        column_map = dict(
            N=(0,1),
            S=(0,1),
            E=(1,0),
            W=(1,0)
        )

        start = self.__sites[startidx]
        current = self.__sites[idx]
        cm = column_map[self.__mf]
        im = indexing_map[self.__mf]
        return (current[cm[0]]-start[cm[0]])*im[0], (current[cm[1]]-start[cm[1]])*im[1]

    def get_site_name(self, idx):
        """Get the name of the site at the given index."""
        x,y,data = self.__sites[idx]
        return '%0.2d%0.2d'%(x,y)

    def get_site_coordinates(self, idx):
        """Get the 2-tuple of xy-coordinates of the site at the given index."""
        x, y, data = self.__sites[idx]
        return (x, y)

    def get_site_data(self, idx):
        """Get the optional data dictionary associated with the site at the given index"""
        return self.__sites[idx][2]

    def set_site_data(self, idx, data):
        """Set the optional data dictionary associated with the site at the given index"""
        if idx in range(len(self.__sites)) and isinstance(data, dict):
            self.__sites[idx][2] = data
        else:
            raise ValueError("Invalid index '{}' or data dictionary".format(idx))

    def update_site_data(self, idx, data):
        """Update the optional data dictionary associated with the site at the given index"""
        if idx in range(len(self.__sites)) and isinstance(data, dict):
            self.__sites[idx][2].update(data)
        else:
            raise ValueError("Invalid index '{}' or data dictionary".format(idx))

    def get_site_index(self, x, y):
        """Get the ordinal index of site (x,y)."""
        x, y = int(x), int(y)
        for i,site in enumerate(self.__sites):
            if site[0] == x and site[1] == y:
                return i
        raise ValueError("site '{},{}' is not in the wafer map".format(x,y))

    def remove_site_index(self, idx):
        """Remove the site at the given index."""
        del self.__sites[idx]

    @property
    def x_index(self):
        return self.__xi

    @property
    def y_index(self):
        return self.__yi

    @property
    def x_alpha(self):
        return self.__xa

    @property
    def y_alpha(self):
        return self.__ya
        
    @property
    def major_flat(self):
        return self.__mf

    @property
    def sites(self):
        return self.__sites

    def __getitem__(self,i):
        return self.__sites[i]

    def __len__(self):
        return len(self.__sites)

    def __contains__(self, item):
        if isinstance(item, tuple):
            if len(item) in [2, 3]:
                coords = item[0], item[1]
                coord_list = [(x[0], x[1]) for x in self.__sites]
                if coords in coord_list:
                    return True
        return False

    def __iter__(self):
        return iter(self.__sites)