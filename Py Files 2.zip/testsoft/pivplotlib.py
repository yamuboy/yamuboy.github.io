#
#  A Tk-centric GUI for interactive display of plots
#

# import wxPython
import wx

# import stuff that is needed from matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg
import numpy as np

import os, os.path, sys, traceback

def get_style(i):
    "get the line style associated with the index"
    colors = ['#ff0000','#800000','#ff8080','#ffff00','#808000','#008000','#00ff00','#008080','#30ffff',
        '#0000ff','#800080','#ff80ff','#b0b0b0','#606060','#000000']
    styles = ['-','--','-.',':']
    
    nc = len(colors)
    ns = len(styles)
    
    ci = i%nc
    si = (i//nc)%ns
    
    return styles[si], colors[ci]
    
def read_piv_data_file(fname):
    "read pulsed I-V data"
    fp = open(fname,'rU')
    data = []
    try:
        last_vd = -10000000.0
        vdl, idl = [], []
        label = None
        for line in fp:
            try:
                vals = [float(x) for x in line.split()]
                
                if len(vals) > 5:
                    vdset = vals[1]
                    vd = vals[3]
                    id = vals[5]*1000.0
                    vg = vals[0]
                    
                    if vdset < last_vd and len(vdl) > 0:
                        data.append( (vdl,idl,label) )
                        vdl, idl = [], []
                        label = None
                    last_vd = vdset
                    
                    vdl.append(vd)
                    idl.append(id)
                    if label is None:
                        label = 'Vg = %.3f'%vg
            
            except Exception:
                pass

        if len(vdl) > 0:
            data.append( (vdl,idl,label) )
            
    finally:
        fp.close()
    return data
    
    
class PIVPlotFigure(Figure):
    "Plot figure for plotting PIV data"
    
    def __init__(self,*args,**kwargs):
        "initializer"
        # strip keywords specific to this figure
        
        # init parent
        super(PIVPlotFigure,self).__init__(*args,**kwargs)
        
        # create the plot axes
        self.iv_axes = self.add_axes([0.1,0.1,0.8,0.8])        
        
    def plot_iv_data(self, data):
        "plot the I-V data on the axes"
        
        # check argument
        if not isinstance(data,list):
            raise TypeError("'data' must be a list")                
        
        linewidth = 2
        showlegend = True
        
        # reset the plot
        self.reset_plot()
        
        # draw the I-V curves
        plotargs = []
        for i,dset in enumerate(data):
            try:
                if not isinstance(dset,(list,tuple)):
                    raise TypeError("'data' element %d: not a tuple/list"%i)
                elif len(dset) not in (2,3):
                    raise TypeError("'data' element %d: not a 2-element or 3-element tuple/list"%i)
                    
                x = dset[0]
                y = dset[1]
                if len(dset) == 3:
                    label = dset[2]
                else:
                    label = 'Series %d'%(i+1)
                print x,y
                
                if not np.iterable(x):
                    raise ValueError("'data' element %d: X data is not an iterable"%i)            
                elif not np.iterable(y):
                    raise ValueError("'data' element %d: Y data is not an iterable"%i)
                elif len(x) != len(y):
                    raise ValueError("'data' element %d: X and Y data are not the same length"%i)
                elif not isinstance(label,(str,unicode)):
                    raise TypeError("'data' element %d: label is not a string value"%i)
                
                # generate keywords and plot
                kw = {'lw':linewidth, 'label':label}
                kw['ls'], kw['c'] = get_style(i)
                self.iv_axes.plot(x,y,**kw)
            except Exception, e:
                import traceback
                traceback.print_exc()
        
        # generate the legend
        if showlegend:
            self.iv_axes.legend(loc ='upper right',fontsize='x-small')
    
    def reset_plot(self):
        "reset the plot"
        # clear the axes, then set hold mode so that plot()
        # can be called more than once
        self.iv_axes.cla()
        self.iv_axes.hold(True)
        self.iv_axes.grid(True)
        
        # set the axis labels
        self.iv_axes.set_xlabel('Vds (V)')
        self.iv_axes.set_ylabel('Ids (mA)')
        self.iv_axes.set_title('Pulsed I-V')
        
        
        

class WxPIVPlotPanel(wx.Panel):
    """Plot panel for displaying plots
    
    """
    def __init__( self, parent, **kwargs ):
        "initializer"
        
        # set the last update time for the plot
        self._lastupdate = None
        self._liveplotfile = 'pivplotdata.txt'

        # initialize Panel
        if 'id' not in kwargs.keys():
            kwargs['id'] = wx.ID_ANY
        if 'style' not in kwargs.keys():
            kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS
        else:
            kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS 
        super(WxPIVPlotPanel,self).__init__(parent,**kwargs)
        self.parent = parent
        
        # initialize matplotlib stuff
        self.figure = PIVPlotFigure()
        canvas = FigureCanvasWxAgg(self,-1,self.figure)
        canvas.SetFocus()
        #self.SetColor(color)

        self._SetSize()

        self._resizeflag = False

        self.Bind(wx.EVT_IDLE, self._onIdle)
        self.Bind(wx.EVT_SIZE, self._onSize)
        
        # do an initial plot update
        self._check_replot(None)
        
        # start a timer to check for plot data file updates
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self._check_replot, self.timer)
        self.timer.Start(2000)
    
    def set_plot_file(self, fname):
        "set the plot up for static plotting"
        if not isinstance(fname,(str,unicode)):
            raise TypeError("'fname' must be a string")
        self.set_live_mode(False)
        self.update_plot(fname)
    
    def set_live_mode(self, b=True):
        "set live mode plotting"
        if b:
            self._check_replot(None)
            self.timer.Start(2000)
        else:
            self.timer.Stop()
            self._lastupdate = None
            self.figure.reset_plot()
            self.figure.canvas.draw()            
        
    def _onSize( self, event ):
        "event method for resize"
        self._resizeflag = True

    def _onIdle( self, evt ):
        "event method for idle events"
        if self._resizeflag:
            self._resizeflag = False
            self._SetSize()
        
    def _SetSize( self ):
        "resize the figure image" 
        pixels = tuple(self.parent.GetClientSize())
        self.SetSize(pixels)
        self.figure.canvas.SetSize(pixels)
        self.figure.set_size_inches( float( pixels[0] )/self.figure.get_dpi(),
                                     float( pixels[1] )/self.figure.get_dpi() )
            
    def _SetColor( self, rgbtuple=None ):
        "Set figure and canvas colours to be the same."
        if rgbtuple is None:
            rgbtuple = wx.SystemSettings.GetColour( wx.SYS_COLOUR_BTNFACE ).Get()
        clr = [c/255. for c in rgbtuple]
        self.figure.set_facecolor( clr )
        self.figure.set_edgecolor( clr )
        self.canvas.SetBackgroundColour( wx.Colour( *rgbtuple ) )
    
    def _check_replot( self, event ):
        "check if there is any new data to plot"
        try:
            sz = os.stat(self._liveplotfile).st_size
        except Exception:
            return
                    
        if self._lastupdate is None or self._lastupdate != sz:
            # plot needs to be updated
            # read the PIV plot file
            self._lastupdate = sz
            self.update_plot(self._liveplotfile)
    
    def update_plot(self, fname):
        "update the plot window"
        try:
            data = read_piv_data_file(fname)
        except Exception, e:
            sys.stderr.write(traceback.format_exc()+'\n')
            self.parent.error_msg("plot update failed for '%s'"%fname)
            return
        
        # plot the data
        if len(data):
            self.figure.plot_iv_data(data)
            self.figure.canvas.draw()
        
                
class WxPIVPlotFrame(wx.Frame):
    """Main frame for holding the WxPIVPlotPanel"""    
    
    def __init__( self, parent=None, *args, **kwargs ):
        "initializer"
    
        title = kwargs.pop('title','PIV Plot 0.1')
        
        #if 'style' not in kwargs:
        #    kwargs['style'] = wx.DEFAULT_FRAME_STYLE | wx.WANTS_CHARS
        #else:
        #    kwargs['style'] |= wx.WANTS_CHARS

        # init the parent
        super(WxPIVPlotFrame,self).__init__(parent,*args,**kwargs)
        
        self.SetTitle(title)
        
        # create a status bar
        self.statusbar = self.CreateStatusBar()
        
        # create a menu bar
        menubar = wx.MenuBar()

        filemenu = wx.Menu()
        omi = wx.MenuItem(filemenu, wx.ID_ANY, '&Open PIV File\tCtrl+O')
        filemenu.AppendItem(omi)
        lmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Live Mode\tCtrl+L')
        filemenu.AppendItem(lmi)
        smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
        filemenu.AppendItem(smi)
        filemenu.AppendSeparator()
        qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(qmi)

        self.Bind(wx.EVT_MENU,self.open_plotfile,omi)
        self.Bind(wx.EVT_MENU,self.live_mode,lmi)
        self.Bind(wx.EVT_MENU,self.save_figure,smi)
        self.Bind(wx.EVT_MENU,self.OnQuit,qmi)

        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)
        
        # create the panel that holds the matplotlib Figure
        self.panel = WxPIVPlotPanel(self)
        
        # draw the canvas for the first time
        self.panel.figure.canvas.draw()
        
        # show this Window
        #self.SetSize((350, 250))
        self.Centre()
        self.Show(True)
                    
    def OnQuit(self, e=None):
        "capture quit commands"
        self.Close()
    
    def open_plotfile(self, e=None):
        "set the plot utility to open a static file"
        dlg = wx.FileDialog(self, "Open file", "", "", "All files (*.*)|*.*", wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            dirname  = dlg.GetDirectory()
            filename = dlg.GetFilename()
            fname = os.path.join(dlg.GetDirectory(),dlg.GetFilename())
            self.panel.set_plot_file(fname)
        
    def live_mode(self, e=None):
        "set the plot utility into live mode"
        self.panel.set_live_mode(True)        
        
    def save_figure(self,e=None):
        """Menu entry callback to save the current figure."""
        filetypes, exts, filter_index = self.panel.figure.canvas._get_imagesave_wildcards()
        default_file = "image." + self.panel.figure.canvas.get_default_filetype()
        dlg = wx.FileDialog(self, "Save to file", "", default_file,
                            filetypes,
                            wx.SAVE|wx.OVERWRITE_PROMPT)
        dlg.SetFilterIndex(filter_index)
        if dlg.ShowModal() == wx.ID_OK:
            dirname  = dlg.GetDirectory()
            filename = dlg.GetFilename()
            format = exts[dlg.GetFilterIndex()]
            basename, ext = os.path.splitext(filename)
            if ext.startswith('.'):
                ext = ext[1:]
            if ext in ('svg', 'pdf', 'ps', 'eps', 'png') and format!=ext:
                #looks like they forgot to set the image type drop
                #down, going with the extension.
                #warnings.warn('extension %s did not match the selected image type %s; going with %s'%(ext, format, ext), stacklevel=0)
                format = ext
                
            try:
                fname = os.path.join(dirname,filename)
                self.panel.figure.canvas.print_figure(fname,format=format)
                self.status_msg("Saved file '%s'"%fname)
            except Exception, e:
                self.error_msg(str(e))
        
    def status_msg(self, msg):
        "print a status message to the status bar"
        self.statusbar.SetForegroundColour('black')
        self.statusbar.SetStatusText(msg)
        
    def error_msg(self, msg):
        "print an error message to the status bar"
        self.statusbar.SetForegroundColour('red')
        self.statusbar.SetStatusText(msg)
                
        
