# import stuff that is needed from matplotlib
import os, os.path, sys, traceback, re

import maplot.smithplot
from network_params import Touchstone


import numpy as np
from wx import wx
from wx.lib import scrolledpanel
from numpy import cos, sin, log10, pi, matrix, absolute, angle
from matplotlib import dates, ticker
from matplotlib.dates import date2num
from matplotlib.figure import Figure
#from matplotlib.pyplot import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from enum import Enum
from datetime import datetime, timedelta
from collections import OrderedDict

# Constant used to decide how many bias points is too many to plot
excessiveBiasPoints = 20

# Keep fileFilterIndex and CanvasType synchronized! 
fileFilterIndex = "Pulsed IV/S-par Files (*.piv)|*.piv|DCMonitor/Stress Files (*.dat)|*.dat|2-port S-par Files (*.s2p)|*.s2p"

# file extensions used to match fileFilterIndex from above
# used to extract the file extension from the chosen filename
# independently of the chosen filetype in the dialog
class fileFilterEnum(Enum):
	piv = 0
	dat = 1
	s2p = 2

class CanvasType(Enum):
	PIVandS		= 0
	DCMonitor 	= 1
	S2P 		= 2
	GenericRect = 3
	
class PlotFigureType(Enum):
	SingleRectPlot 	= 0
	DoubleRectPlot 	= 1
	IVPlot 			= 2
	DCMonitorPlot 	= 3
	SmithPlot 		= 4
	PolarPlot		= 5
	
class ComplexType(Enum):
	MagAngle = 0
	RealImag = 1

class LineStyle(Enum): # use in conjunction with global _styleLUT function
	Solid 	= 0
	Dashed 	= 1
	DashDot = 2
	Dot 	= 3

class LineColor(Enum):
	LtRed 		= 0		#ff0000
	DkRed 		= 1		#800000
	LtGreen		= 2		#00ff00
	DkGreen		= 3		#008000
	LtBlue		= 4		#0000ff 
	DkBlue		= 5		#000080
	Orange 		= 6		#ff8000
	Lime		= 7		#80ff00
	Yellow		= 8		#ffff00
	Magenta 	= 9		#ff0080
	DkPurple	= 10	#8000ff
	Purple		= 11	#ff00ff
	Aqua		= 12	#00ff80
	SkyBlue		= 13	#0080ff
	Cyan		= 14	#00ffff
	Black 		= 15	#000000
		
class SParLUT(Enum):
	S11 = 0
	S12 = 1
	S21 = 2
	S22 = 3

def _styleLUT(style=LineStyle.Solid):
	"get the line style associated with the index"
	# 16 colors, 4 line styles
	styles = ['-','--','-.',':']
	
	if isinstance(style, LineStyle):	
		return styles[style.value]
	elif isinstance(style, int):
		return styles[(style//16)%4]
	else:
		raise ValueError

def _colorLUT(color=LineColor.LtRed):
	"get the line color associated with the index"
	# 16 colors
	colors = ['#ff0000', '#800000', '#00ff00', '#008000', '#0000ff', '#000080', '#ff8000', '#80ff00', '#ffff00', '#ff0080', '#8000ff', '#ff00ff', '#00ff80', '#0080ff', '#00ffff', '#000000']
	
	if isinstance(color, LineColor):	
		return colors[color.value]
	elif isinstance(color, int):
		return colors[color%16]
	else:
		raise ValueError

def _get_normalized_impedance(g):
	"get the impedance corresponding to a given reflection coefficient"
	return (1.0 + g)/(1.0 - g)

def _MA_to_complex(mag, ang_degrees):
	"get the complex number corresponding to a mag-angle input"
	magarray = np.asarray(mag, float)
	angarray = np.asarray(ang_degrees, float)
	real = magarray * cos(angarray*pi/180.0)
	imag = magarray * sin(angarray*pi/180.0)
	return real + imag*1j

def _RI_to_complex(real, imag):
	"get the complex number corresponding to a real-imaginary input"
	return real + imag*1j

def findLimitsTupleArray(minval, maxval, array):
	"return the extremes of the values between the input min/max and array"
	if minval is None or minval > min(array):
		minval = min(array)
	if maxval is None or maxval < max(array):
		maxval = max(array)
	return minval, maxval

###############################################################################
# Figure Classes
###############################################################################

class SingleRectPlot(Figure):
	"Rectangular Plot Figure with one Y-axis"
	
	def __init__(self, *args, **kwargs):
		super(SingleRectPlot, self).__init__(*args, **kwargs)
		self.add_axes([0.075, 0.075, 0.85, 0.85])
		
	def plotData(self, xdata, ydata, label="Series", linestyle=LineStyle.Solid, linecolor=LineColor.LtRed):
		# generate keywords and plot
		kw = { }
		kw['lw'] = 1
		kw['ls'] = _styleLUT(linestyle)
		kw['c'] = _colorLUT(linecolor)
		kw['label'] = label
		self.axes[0].plot(xdata, ydata, **kw)
	
	def showLegend(self, show):
		# generate the legend
		if show:
			self.axes[0].legend(loc ='upper right',fontsize='x-small')
		else:
			self.axes[0].legend_ = None
			
	def resetPlot(self):
		self.axes[0].cla()
		
	def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min=None, y2max=None):
		self.axes[0].set_xlim([xmin, xmax])
		self.axes[0].set_ylim([y1min, y1max])
		
	def setXLabel(self, label):
		self.axes[0].set_xlabel(label)
		
	def setYLabel(self, label):
		self.axes[0].set_ylabel(label)
	
	def setTitle(self, title):
		self.axes[0].set_title(title)
			
class DoubleRectPlot(Figure):
	"Rectangular Plot Figure with two Y-axes"
	
	def __init__(self, *args, **kwargs):
		super(DoubleRectPlot, self).__init__(*args, **kwargs)
		self.priax = self.add_axes([0.075, 0.075, 0.85, 0.85])
		self.secax = self.priax.twinx()
		
	def plotData(self, xdata, ydata1, ydata2, ydata1lab="Series 1", ydata2lab="Series 2"):
		self.priax.plot(xdata, ydata1, label=ydata1lab, ls='-', c='#ff0000')
		self.secax.plot(xdata, ydata2, label=ydata2lab, ls='--', c='#0000ff')
	
	def showLegend(self, show):
		# generate the legend
		if show:
			self.priax.legend(loc ='upper left',fontsize='x-small')
			self.secax.legend(loc ='upper right',fontsize='x-small')
		else:
			self.priax.legend_ = None
			self.secax.legend_ = None
	
	def resetPlot(self):
		self.priax.cla()
		self.secax.cla()
	
	def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min, y2max):
		self.priax.set_xlim([xmin, xmax])
		self.priax.set_ylim([y1min, y1max])
		self.secax.set_ylim([y2min, y2max])
	
	def setXLabel(self, label):
		self.priax.set_xlabel(label)
	
	def setY1Label(self, label):
		self.priax.set_ylabel(label)
	
	def setY2Label(self, label):
		self.secax.set_ylabel(label)
	
	def setTitle(self, title):
		self.priax.set_title(title)

class IVPlot(Figure):
	"Plot Figure for IV data"
	
	def __init__(self, *args, **kwargs):
		super(IVPlot, self).__init__(*args, **kwargs)
		self.add_axes([0.075, 0.075, 0.85, 0.85])
	
	def plotData(self, Vd, Id, Vglabel="Series", styleIndex=0):
		"plot the I-V data on the axes"
		# draw the I-V curves
		try:
			# generate keywords and plot
			kw = { }
			kw['lw'] = 1
			kw['ls'] = _styleLUT(styleIndex)
			kw['c'] = _colorLUT(styleIndex)
			kw['label'] = 'Vg = ' + Vglabel
			self.axes[0].plot(Vd,Id,**kw)
		
		except Exception:
			traceback.print_exc()
	
	def showLegend(self, show):
		# generate the legend
		if show:
			self.axes[0].legend(loc ='upper right',fontsize='x-small')
		else:
			self.axes[0].legend_ = None
	
	def resetPlot(self):
		"reset the plot"
		# clear the axes, then set hold mode so that plot()
		# can be called more than once
		self.axes[0].cla()
		self.axes[0].hold(True)
		self.axes[0].grid(True)
		
		# set the axis labels
		self.axes[0].set_xlabel('Vds (V)')
		self.axes[0].set_ylabel('Ids (mA)')
		self.axes[0].set_title('Pulsed I-V')
	
	def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min=None, y2max=None):
		self.axes[0].set_xlim([xmin, xmax])
		self.axes[0].set_ylim([y1min, y1max])

class DCMonitorPlot(Figure):
	"Figure for plotting DC Monitor data"
	
	def __init__(self,*args,**kwargs):
		"initializer"
		# strip keywords specific to this figure
		
		# init parent
		super(DCMonitorPlot,self).__init__(*args,**kwargs)
		self.add_axes([0.075, 0.075, 0.85, 0.85])
	
	def plotData(self, times, data, terminal):
		"plot the data on the axes"
		
		# check argument
		if not isinstance(data, list):
			raise TypeError("'data' must be a list")
		
		# reset the plot
		self.resetPlot(terminal)
		
		# set/rotate x-axis labels
		self.axes[0].set_xticklabels(times, rotation='30')
	
		# set x-axes to plot time elapsed based on timeTicks formatter
		def timeTicks(x, pos):
			d = timedelta(seconds=x)
			return str(d)
		
		timeformatter = ticker.FuncFormatter(timeTicks)
		self.axes[0].get_xaxis().set_major_formatter(timeformatter)
		
		# plot data
		self.axes[0].plot(times, data)
		
		# set graphs to use scientific notation on y-axis
		self.axes[0].ticklabel_format(style='sci', scilimits=(0,0), axis='y')
	
	def resetPlot(self, terminal):
		"reset the plot"
		# clear the axes
		self.axes[0].cla()
		self.axes[0].grid(True)
		
		# set the axis labels
		self.axes[0].set_xlabel('Time (D:HH:MM elapsed)')
		if terminal == "Gate":
			self.axes[0].set_ylabel('Ig (A)')
			self.axes[0].set_title('Igate vs Time')
		else:
			self.axes[0].set_ylabel('Id (A)')
			self.axes[0].set_title('Idrain vs Time')
	
	def setAxisLimits(self, xmin, xmax, y1min, y1max, y2min=None, y2max=None):
		self.axes[0].set_xlim([xmin, xmax])
		self.axes[0].set_ylim([y1min, y1max])
	
	def showLegend(self, show):
		# generate the legend
		if show:
			self.axes[0].legend(loc ='upper right',fontsize='x-small')
		else:
			self.axes[0].legend_ = None

class SmithPlot(Figure):
	"Smith Chart Plot Figure"
	
	def __init__(self, *args, **kwargs):
		super(SmithPlot, self).__init__(*args, **kwargs)
		self.set_tight_layout(True)
		self.add_subplot(1, 1, 1, projection="smith", axes_scale=1.0)
	
	def plotLine(self, data_normalized_complex, label="Series", linestyle=LineStyle.Solid, linecolor=LineColor.LtRed):
		# generate keywords and plot
		kw = { }
		kw['lw'] = 2
		kw['ls'] = _styleLUT(linestyle)
		kw['c'] = _colorLUT(linecolor)
		kw['label'] = label
		kw['marker'] = None
		self.axes[0].plot(data_normalized_complex, **kw)
	
# 	def plotPoints(self, xdata, ydata_complex, label="Series", color=LineColor.LtRed):
# 		pass
	
	def showLegend(self, show):
		# generate the legend
		if show:
			self.axes[0].legend(loc ='upper right',fontsize='x-small')
		else:
			self.axes[0].legend_ = None
	
	def resetPlot(self):
		self.axes[0].cla()
		self.axes[0].grid(True)
	
	def setTitle(self, title):
		self.axes[0].set_title(title)
	
###############################################################################
# Canvas Classes
###############################################################################

class GenericCanvas(FigureCanvas):
	"Generic Canvas, displays a single rectangular plot by default"
	
	ctype = CanvasType.GenericRect
	ftype = PlotFigureType.SingleRectPlot
	filepath = None
	filename = None
	
	xmin, xmax = 0.0, 1.0
	y1min, y1max = 0.0, 1.0
	y2min, y2max = 0.0, 1.0

	_redraw = False
	
	def __init__( self, parent, identifier, figure=SingleRectPlot() ):
		super(GenericCanvas,self).__init__(parent, identifier, figure)
		self.parent = parent
		self.filepath = None
		self.filename = None
		
		# Controls
		# Axis Limits
		self.xMaxTextBox = wx.TextCtrl(	self, 
										wx.ID_ANY, 
										"1.0", 
										(0, 0), 
										(30, 20),
										style=wx.TE_PROCESS_ENTER)
		self.xMinTextBox = wx.TextCtrl(	self, 
										wx.ID_ANY, 
										"0.0", 
										(0, 0), 
										(30, 20),
										style=wx.TE_PROCESS_ENTER)
		self.y1MaxTextBox = wx.TextCtrl(self, 
										wx.ID_ANY, 
										"1.0", 
										(0, 0), 
										(30, 20),
										style=wx.TE_PROCESS_ENTER)
		self.y1MinTextBox = wx.TextCtrl(self, 
										wx.ID_ANY, 
										"0.0", 
										(0, 0), 
										(30, 20),
										style=wx.TE_PROCESS_ENTER)
		self.y2MaxTextBox = wx.TextCtrl(self, 
										wx.ID_ANY, 
										"1.0", 
										(0, 0), 
										(30, 20),
										style=wx.TE_PROCESS_ENTER)
		self.y2MinTextBox = wx.TextCtrl(self, 
										wx.ID_ANY, 
										"0.0", 
										(0, 0), 
										(30, 20),
										style=wx.TE_PROCESS_ENTER)
		
		self.xMaxTextLabel = wx.StaticText(	self, 
											wx.ID_ANY, 
											"X-Max", 
											(0, 0), 
											style=wx.ALIGN_CENTRE_HORIZONTAL)
		self.xMinTextLabel = wx.StaticText(	self, 
											wx.ID_ANY, 
											"X-Min", 
											(0, 0), 
											style=wx.ALIGN_CENTRE_HORIZONTAL)
		self.y1MaxTextLabel = wx.StaticText(self, 
											wx.ID_ANY, 
											"Y1-Max", 
											(0, 0), 
											style=wx.ALIGN_CENTRE_HORIZONTAL)
		self.y1MinTextLabel = wx.StaticText(self, 
											wx.ID_ANY, 
											"Y1-Min", 
											(0, 0),
											style=wx.ALIGN_CENTRE_HORIZONTAL)
		self.y2MaxTextLabel = wx.StaticText(self, 
											wx.ID_ANY, 
											"Y2-Max", 
											(0, 0), 
											style=wx.ALIGN_CENTRE_HORIZONTAL)
		self.y2MinTextLabel = wx.StaticText(self, 
											wx.ID_ANY, 
											"Y2-Min", 
											(0, 0),
											style=wx.ALIGN_CENTRE_HORIZONTAL)
		# hide the textboxes and labels
		self.xMaxTextBox.Hide()
		self.xMinTextBox.Hide()
		self.y1MaxTextBox.Hide()
		self.y1MinTextBox.Hide()
		self.y2MaxTextBox.Hide()
		self.y2MinTextBox.Hide()
		self.xMaxTextLabel.Hide()
		self.xMinTextLabel.Hide()
		self.y1MaxTextLabel.Hide()
		self.y1MinTextLabel.Hide()
		self.y2MaxTextLabel.Hide()
		self.y2MinTextLabel.Hide()
		
		# Title
		self.titleTextBox = wx.TextCtrl( 		self,
												wx.ID_ANY,
												"Title",
												(0, 0),
												(50,20),
												style=wx.TE_PROCESS_ENTER | wx.TE_CENTRE)
		self.titleTextLabel = wx.StaticText(	self,
												wx.ID_ANY,
												"Title",
												style=wx.ALIGN_CENTRE_HORIZONTAL)
		# same idea as the axis limits
		self.titleTextBox.Hide()	
		
		# Close Button
		self.closeButton = wx.Button(			self,
												wx.ID_ANY,
												"X",
												style=wx.BU_EXACTFIT)
		
		# Open File Button
		self.openDataFileButton = wx.Button(	self,
												wx.ID_ANY,
												"Open File...",
												style=wx.BU_EXACTFIT)
		
		# Live File Update CheckBox
		self.liveUpdateChkBox = wx.CheckBox(	self,
												wx.ID_ANY,
												"Live Update",
												(0, 0),
												style=wx.CHK_2STATE)
		
		# Autoscale Axis CheckBoxes
		self.autoScaleXChkBox = wx.CheckBox(	self,
												wx.ID_ANY,
												"Autoscale X-Axis",
												(0, 0),
												style=wx.CHK_2STATE)
		self.autoScaleY1ChkBox = wx.CheckBox(	self,
												wx.ID_ANY,
												"Autoscale 1st Y-Axis",
												(0, 0),
												style=wx.CHK_2STATE)
		self.autoScaleY2ChkBox = wx.CheckBox(	self,
												wx.ID_ANY,
												"Autoscale 2nd Y-Axis",
												(0, 0),
												style=wx.CHK_2STATE)
		
		self.autoScaleXChkBox.SetValue(True)
		self.autoScaleY1ChkBox.SetValue(True)
		self.autoScaleY2ChkBox.SetValue(True)
		
		# Live Update Timer
		self.timer = wx.Timer(self)
		
		# Event Bindings
		# Axis Limits
		self.xMaxTextLabel.Bind(wx.EVT_LEFT_DOWN, self.changeLimit)
		self.xMinTextLabel.Bind(wx.EVT_LEFT_DOWN, self.changeLimit)
		self.y1MaxTextLabel.Bind(wx.EVT_LEFT_DOWN, self.changeLimit)
		self.y1MinTextLabel.Bind(wx.EVT_LEFT_DOWN, self.changeLimit)
		self.y2MaxTextLabel.Bind(wx.EVT_LEFT_DOWN, self.changeLimit)
		self.y2MinTextLabel.Bind(wx.EVT_LEFT_DOWN, self.changeLimit)
		self.Bind(wx.EVT_TEXT_ENTER, self.setAxisLimits)
		
		# Title
		self.titleTextLabel.Bind(wx.EVT_LEFT_DCLICK, self.showTitleTextBox)
		self.Bind(wx.EVT_TEXT_ENTER, self.updateTitle, self.titleTextBox)
		
		# Buttons/Checkboxes
		self.Bind(wx.EVT_CHECKBOX, self.liveUpdate, self.liveUpdateChkBox)
		self.Bind(wx.EVT_CHECKBOX, self.autoScaleX, self.autoScaleXChkBox)
		self.Bind(wx.EVT_CHECKBOX, self.autoScaleY1, self.autoScaleY1ChkBox)
		self.Bind(wx.EVT_CHECKBOX, self.autoScaleY2, self.autoScaleY2ChkBox)
		self.Bind(wx.EVT_BUTTON, self.openDataFile, self.openDataFileButton)
		self.Bind(wx.EVT_BUTTON, self.closeCanvas, self.closeButton)
		
		# Timer
		self.Bind(wx.EVT_TIMER, self.timerUpdate, self.timer)
		
		self.Bind(wx.EVT_IDLE, self._onIdle)
	
	def _onIdle(self, event=None):
		if self._redraw:
			self._redraw = False
			self.draw()
	
	def liveUpdate(self, event=None):
		self._redraw = True
		if self.liveUpdateChkBox.IsChecked():
			self.timer.Start(2000)
		else:
			self.timer.Stop()
	
	def resetAutoscaleLimits(self):
		self.xmin, self.xmax, self.y1min, self.y1max, self.y2min, self.y2max = (None, None, None, None, None, None)
	
	def autoScaleX(self, event=None):
		self._redraw = True
		if self.autoScaleXChkBox.IsChecked():
			self.xMaxTextBox.SetValue("%e"%self.xmax)
			self.xMinTextBox.SetValue("%e"%self.xmin)
			self.xMaxTextLabel.Hide()
			self.xMinTextLabel.Hide()
		else:
			self.xMaxTextLabel.Show()
			self.xMinTextLabel.Show()
		
		self.setAxisLimits()
	
	def autoScaleY1(self, event=None):
		self._redraw = True
		if self.autoScaleY1ChkBox.IsChecked():
			self.y1MaxTextBox.SetValue("%e"%(self.y1max + absolute(self.y1max - self.y1min)*0.05))
			self.y1MinTextBox.SetValue("%e"%(self.y1min - absolute(self.y1max - self.y1min)*0.05))
			self.y1MaxTextLabel.Hide()
			self.y1MinTextLabel.Hide()
		else:
			self.y1MaxTextLabel.Show()
			self.y1MinTextLabel.Show()

		self.setAxisLimits()
	
	def autoScaleY2(self, event=None):
		if self.y2min is None or self.y2max is None:
			return
		self._redraw = True
		if self.autoScaleY2ChkBox.IsChecked():
			self.y2MaxTextBox.SetValue("%e"%(self.y2max + absolute(self.y2max - self.y2min)*0.05))
			self.y2MinTextBox.SetValue("%e"%(self.y2min - absolute(self.y2max - self.y2min)*0.05))
			self.y2MaxTextLabel.Hide()
			self.y2MinTextLabel.Hide()
		else:
			self.y2MaxTextLabel.Show()
			self.y2MinTextLabel.Show()
		
		self.setAxisLimits()
	
	def timerUpdate(self, event=None):
		print "Timer update not implemented with generic canvas! Must be overridden for every canvas type!"
	
	def changeLimit(self, event=None):
		self._redraw = True
		textLabel = event.GetEventObject()
		textLabel.Hide()
		# set label to desired value as kludgy way to auto-size the textbox to fit the value
		# then set the label back to its original text
		if textLabel is self.xMaxTextLabel:
			textLabel.SetLabel(self.xMaxTextBox.GetValue())
			self.xMaxTextBox.SetSizeWH(textLabel.GetSizeTuple()[0]*2.0, self.xMaxTextBox.GetSizeTuple()[1])
			textLabel.SetLabel("X-Max")
			self.xMaxTextBox.Show()
			self.xMaxTextBox.SetFocus()
			self.xMaxTextBox.SelectAll()
		elif textLabel is self.xMinTextLabel:
			textLabel.SetLabel(self.xMinTextBox.GetValue())
			self.xMinTextBox.SetSizeWH(textLabel.GetSizeTuple()[0]*2.0, self.xMinTextBox.GetSizeTuple()[1])
			textLabel.SetLabel("X-Min")
			self.xMinTextBox.Show()
			self.xMinTextBox.SetFocus()
			self.xMinTextBox.SelectAll()
		elif textLabel is self.y1MaxTextLabel:
			textLabel.SetLabel(self.y1MaxTextBox.GetValue())
			self.y1MaxTextBox.SetSizeWH(textLabel.GetSizeTuple()[0]*2.0, self.y1MaxTextBox.GetSizeTuple()[1])
			textLabel.SetLabel("Y1-Max")
			self.y1MaxTextBox.Show()
			self.y1MaxTextBox.SetFocus()
			self.y1MaxTextBox.SelectAll()
		elif textLabel is self.y1MinTextLabel:
			textLabel.SetLabel(self.y1MinTextBox.GetValue())
			self.y1MinTextBox.SetSizeWH(textLabel.GetSizeTuple()[0]*2.0, self.y1MinTextBox.GetSizeTuple()[1])
			textLabel.SetLabel("Y1-Min")
			self.y1MinTextBox.Show()
			self.y1MinTextBox.SetFocus()
			self.y1MinTextBox.SelectAll()
		elif textLabel is self.y2MaxTextLabel:
			textLabel.SetLabel(self.y2MaxTextBox.GetValue())
			self.y2MaxTextBox.SetSizeWH(textLabel.GetSizeTuple()[0]*2.0, self.y2MaxTextBox.GetSizeTuple()[1])
			textLabel.SetLabel("Y2-Max")
			self.y2MaxTextBox.Show()
			self.y2MaxTextBox.SetFocus()
			self.y2MaxTextBox.SelectAll()
		elif textLabel is self.y2MinTextLabel:
			textLabel.SetLabel(self.y2MinTextBox.GetValue())
			self.y2MinTextBox.SetSizeWH(textLabel.GetSizeTuple()[0]*2.0, self.y2MinTextBox.GetSizeTuple()[1])
			textLabel.SetLabel("Y2-Min")
			self.y2MinTextBox.Show()
			self.y2MinTextBox.SetFocus()
			self.y2MinTextBox.SelectAll()
	
	def openDataFile(self, event=None):
		"Callback to choose data file for this canvas"
		self._redraw = True
		dlg = wx.FileDialog(	self, "Choose file", "", "",
								fileFilterIndex,
								wx.OPEN)
		if dlg.ShowModal() == wx.ID_OK:
			filepath = dlg.GetPath()
			filename = dlg.GetFilename()
			filterIndex = fileFilterEnum[re.split("\.", filepath)[-1]]
			
			# if this is a generic canvas, change to the correct one
			if self.ctype == CanvasType.GenericRect:
				self.changeCanvasType(CanvasType(filterIndex.value), filepath, filename)
				return
			
			# if this is a specific canvas type and new file is of same type,
			# return tuple of new info and let canvas subclass handle accordingly
			elif CanvasType(filterIndex.value) == self.ctype:
				try:
					self.filepath = filepath
					self.filename = filename
					self.updateTitle()
					self.updateDataFromFile()
					self.UpdatePlot()
				except Exception:
					traceback.print_exc()
					self.parent.parent.error_msg("Unable to opdate from file %s!"%self.filename)
				return
			# otherwise, return the new canvas type and info, and let the
			# canvas subclass update accordingly
			else:
				self.changeCanvasType(CanvasType(filterIndex.Value), filepath, filename)
	
	def changeCanvasType(self, ctype, filepath=None, filename=None):
		# call parent to change this canvas in list to new one
		# with correct type, then dispose of this canvas
		self.parent.changeCanvas(self, ctype, filepath, filename)
	
	def changeFigureType(self, figType):
		# only change figure type if new type is different
		if not self.ftype == figType:
			self.autoScaleXChkBox.Show()
			self.autoScaleY1ChkBox.Show()
			self.autoScaleY2ChkBox.Show()
			if figType == PlotFigureType.SingleRectPlot:
				self.figure = SingleRectPlot()
				self.ftype = PlotFigureType.SingleRectPlot
			elif figType == PlotFigureType.DoubleRectPlot:
				self.figure = DoubleRectPlot()
				self.ftype = PlotFigureType.DoubleRectPlot
			elif figType == PlotFigureType.IVPlot:
				self.figure = IVPlot()
				self.ftype = PlotFigureType.IVPlot
			elif figType == PlotFigureType.DCMonitorPlot:
				self.figure = DCMonitorPlot()
				self.ftype = PlotFigureType.DCMonitorPlot
			elif figType == PlotFigureType.SmithPlot:
				self.figure = SmithPlot()
				self.ftype = PlotFigureType.SmithPlot
				self.autoScaleXChkBox.Hide()
				self.autoScaleY1ChkBox.Hide()
				self.autoScaleY2ChkBox.Hide()
		
			# if plot type changed, update new plot's canvas and reset autoscale limits
			self.figure.set_canvas(self)
			self.parent._SetSize()
			self.resetAutoscaleLimits()
	
	def closeCanvas(self, event=None):
		self.parent.removeCanvas(self)
		
	def updateTitle(self, event=None):
		self._redraw = True
		
		if self.filename is not None:
			self.titleTextBox.SetValue(self.filename)
			self.titleTextLabel.SetLabel(self.filename)
		
		# hide editable box
		self.titleTextBox.Hide()
		
		# create initial title if blank
		if self.titleTextBox.GetValue() == "":
			self.titleTextLabel.SetLabel("Title")
			self.titleTextBox.SetValue("Title")
		else:
			self.titleTextLabel.SetLabel(self.titleTextBox.GetValue())
		
		self.titleTextLabel.Show()
		self.resizeCanvas()
		self._redraw = True
	
	def showTitleTextBox(self, event=None):
		self._redraw = True
		self.titleTextLabel.Hide()
		self.titleTextBox.SetSizeWH(self.titleTextLabel.GetSizeTuple()[0]*1.4, self.titleTextBox.GetSizeTuple()[1])
		self.resizeCanvas()
		self.titleTextBox.Show()
		self.titleTextBox.SetFocus()
		self.titleTextBox.SelectAll()
		self.draw()
	
	def resizeCanvas(self):
		self._redraw = True
		self.xMaxTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.925 - self.xMaxTextBox.GetSizeTuple()[0],
														self.GetSizeTuple()[1]*0.925 - self.xMaxTextBox.GetSizeTuple()[1]))
		self.xMinTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.075, 
														self.GetSizeTuple()[1]*0.925 - self.xMinTextBox.GetSizeTuple()[1]))
		self.y1MaxTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.075, 
														self.GetSizeTuple()[1]*0.075))
		self.y1MinTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.075, 
														self.xMinTextBox.GetPositionTuple()[1] - self.y1MinTextBox.GetSizeTuple()[1]))
		self.y2MaxTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.925 - self.y2MaxTextBox.GetSizeTuple()[0], 
														self.GetSizeTuple()[1]*0.075))
		self.y2MinTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.925 - self.y2MinTextBox.GetSizeTuple()[0], 
														self.xMaxTextBox.GetPositionTuple()[1] - self.y2MinTextBox.GetSizeTuple()[1]))
		
		self.xMaxTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.925 - self.xMaxTextLabel.GetSizeTuple()[0],
														self.GetSizeTuple()[1]*0.925 - self.xMaxTextLabel.GetSizeTuple()[1]))
		self.xMinTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.075, 
														self.GetSizeTuple()[1]*0.925 - self.xMinTextLabel.GetSizeTuple()[1]))
		self.y1MaxTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.075, 
														self.GetSizeTuple()[1]*0.075))
		self.y1MinTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.075, 
														self.xMinTextLabel.GetPositionTuple()[1] - self.y1MinTextLabel.GetSizeTuple()[1]))
		self.y2MaxTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.925 - self.y2MaxTextLabel.GetSizeTuple()[0], 
														self.GetSizeTuple()[1]*0.075))
		self.y2MinTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.925 - self.y2MinTextLabel.GetSizeTuple()[0], 
														self.xMaxTextLabel.GetPositionTuple()[1] - self.y2MinTextLabel.GetSizeTuple()[1]))
		
		self.titleTextBox.SetPosition(wx.Point(			self.GetSizeTuple()[0]*0.5-self.titleTextBox.GetSizeTuple()[0]*0.5,
														0))
		
		self.titleTextLabel.SetPosition(wx.Point(		self.GetSizeTuple()[0]*0.5-self.titleTextLabel.GetSizeTuple()[0]*0.5,
														0))
		
		self.closeButton.SetPosition(wx.Point(			self.GetSizeTuple()[0] - self.closeButton.GetSizeTuple()[0],
														0))
		
		self.openDataFileButton.SetPosition(wx.Point(	self.closeButton.GetPositionTuple()[0]-self.openDataFileButton.GetSizeTuple()[0],
														0))
		
		self.liveUpdateChkBox.SetPosition(wx.Point(		self.openDataFileButton.GetPositionTuple()[0],
														self.openDataFileButton.GetSizeTuple()[1]))
		
		self.autoScaleY1ChkBox.SetPosition(wx.Point(	self.GetSizeTuple()[0]-self.autoScaleY1ChkBox.GetSizeTuple()[0],
														self.GetSizeTuple()[1]-self.autoScaleY1ChkBox.GetSizeTuple()[1]))
		
		self.autoScaleY2ChkBox.SetPosition(wx.Point(	self.GetSizeTuple()[0]-self.autoScaleY2ChkBox.GetSizeTuple()[0],
														self.autoScaleY1ChkBox.GetPositionTuple()[1]-self.autoScaleY2ChkBox.GetSizeTuple()[1]))
		
		self.autoScaleXChkBox.SetPosition(wx.Point(		self.autoScaleY1ChkBox.GetPositionTuple()[0]-self.autoScaleY1ChkBox.GetSizeTuple()[0],
														self.GetSizeTuple()[1]-self.autoScaleY1ChkBox.GetSizeTuple()[1]))
	
	def setAxisLimits(self, event=None):
		self._redraw = True
		if self.ftype == PlotFigureType.SmithPlot:
			return
		xmin, xmax = float(self.xMinTextBox.GetValue()), float(self.xMaxTextBox.GetValue())
		y1min, y1max = float(self.y1MinTextBox.GetValue()), float(self.y1MaxTextBox.GetValue())
		y2min, y2max = float(self.y2MinTextBox.GetValue()), float(self.y2MaxTextBox.GetValue())
		try:
			if self.ftype == PlotFigureType.PolarPlot:
				print "TODO -- Handle Polar Axis limit scaling"
			else:
				if xmin >= xmax or y1min >= y1max or y2min >= y2max:
					raise ValueError
				self.figure.setAxisLimits(	xmin, xmax,
											y1min, y1max,
											y2min, y2max)
		except ValueError:
			traceback.print_exc()
			self.parent.parent.error_msg("Invalid limit!")
		
		if event is not None:
			textBox = event.GetEventObject()
			if textBox is self.xMaxTextBox:
				self.xMaxTextLabel.Show()
				self.xMaxTextBox.Hide()
			elif textBox is self.xMinTextBox:
				self.xMinTextLabel.Show()
				self.xMinTextBox.Hide()
			elif textBox is self.y1MaxTextBox:
				self.y1MaxTextLabel.Show()
				self.y1MaxTextBox.Hide()
			elif textBox is self.y1MinTextBox:
				self.y1MinTextLabel.Show()
				self.y1MinTextBox.Hide()
			elif textBox is self.y2MaxTextBox:
				self.y2MaxTextLabel.Show()
				self.y2MaxTextBox.Hide()
			elif textBox is self.y2MinTextBox:
				self.y2MinTextLabel.Show()
				self.y2MinTextBox.Hide()
	
	def _SetColor( self, rgbtuple=None ):
		"Set figure and canvas colours to be the same."
		if rgbtuple is None:
			rgbtuple = wx.SystemSettings.GetColour( wx.SYS_COLOUR_BTNFACE ).Get()
		clr = [c/255. for c in rgbtuple]
		self.figure.set_facecolor( clr )
		self.figure.set_edgecolor( clr )
		self.SetBackgroundColour( wx.Colour( *rgbtuple ) )

class PIVandSCanvas(GenericCanvas):
	"Canvas for a PIV and Pulsed S-Parameter file, displays an IVPlot by default"
	ctype = CanvasType.PIVandS
	ftype = PlotFigureType.IVPlot
	filepath = None
	filename = None
	filesize = None
	
	# lists used to populate bias drop-down boxes
	vglist = [ ]
	vdlist = [ ]
	selectedvg = None
	selectedvd = None
	
	# ordered dict of float:2-tuple of list key/val pairs -- Vg:(vd list, id list)
	PIVlist = OrderedDict()
	
	# ordered dict of 2-tuple:2-tuple of list key/val pairs -- (Vg, Vd):(freq list, spar tuple list)
	Sparlist = OrderedDict()
	
	def __init__(self, parent, identifier, figure, path=None, name=None, initialPlot="PIV"):
		super(PIVandSCanvas,self).__init__(parent, identifier, figure)
		self.filepath = path
		self.filename = name
		
		# Drop-down for gate/drain
		# TODO -- add SS parameters
		self.plotDropDown = wx.ComboBox(self,
										wx.ID_ANY,
										initialPlot,
										choices=["PIV", "PSpar"],
										style=wx.CB_DROPDOWN|wx.CB_READONLY)
		
		self.vgDropDown = wx.ComboBox(	self,
										wx.ID_ANY,
										"ALL",
										choices=["ALL"],
										size=(60,30),
										style=wx.CB_DROPDOWN|wx.CB_READONLY)
		
		self.vdDropDown = wx.ComboBox(	self,
										wx.ID_ANY,
										"ALL",
										choices=["ALL"],
										size=(60,30),
										style=wx.CB_DROPDOWN|wx.CB_READONLY)
		self.vdDropDown.Hide()
		
		# Drop-down for parameter (which s-par or which SS parameter)
		# TODO -- add SS parameters
		self.paramDropDown = wx.ComboBox(	self,
											wx.ID_ANY,
											"S11",
											choices=["S11", "S12", "S21", "S22"],
											style=wx.CB_DROPDOWN|wx.CB_READONLY)
		self.paramDropDown.Hide()
		
		# Drop-down for type of graph (either mag/phase/both/Smith for spars, or Vg/Vd for SS params)
		self.gtypeDropDown = wx.ComboBox(	self,
											wx.ID_ANY,
											"Both",
											choices=["Mag", "Phase", "Both", "Smith"],
											style=wx.CB_DROPDOWN|wx.CB_READONLY)
		self.gtypeDropDown.Hide()
		
		self.Bind(wx.EVT_COMBOBOX, self.updatePlot)
		self.Bind(wx.EVT_COMBOBOX, self.changePlot, self.plotDropDown)
		
		self.updateTitle()
		
		if self.filepath is not None:
			self.updateDataFromFile()
			self.updatePlot()
			self.liveUpdateChkBox.SetValue(True)
			self.liveUpdate()
		
		self.resizeCanvas()
	
	def changePlot(self, event=None):
		self._redraw = True
		if self.plotDropDown.GetValue() == "PIV":
			self.vdDropDown.Hide()
			self.paramDropDown.Hide()
			self.gtypeDropDown.Hide()
		elif self.plotDropDown.GetValue() == "PSpar":
			self.vdDropDown.Show()
			self.paramDropDown.Show()
			self.gtypeDropDown.Show()
			self.vgDropDown.SetSelection(1)
			self.vdDropDown.SetSelection(1)
		else:
			print "TODO -- Implement SS parameter plots"
		self.updatePlot()

	def resizeCanvas(self):
		self.plotDropDown.SetPosition(wx.Point(		0, 
													0))
		self.vgDropDown.SetPosition(wx.Point(		self.plotDropDown.GetSizeTuple()[0],
													0))
		self.vdDropDown.SetPosition(wx.Point(		self.vgDropDown.GetPositionTuple()[0] + self.vgDropDown.GetSizeTuple()[0],
													0))
		self.paramDropDown.SetPosition(wx.Point(	0,
													self.plotDropDown.GetSizeTuple()[1]))
		self.gtypeDropDown.SetPosition(wx.Point(	self.paramDropDown.GetSizeTuple()[0],
													self.paramDropDown.GetPositionTuple()[1]))
		GenericCanvas.resizeCanvas(self)
	
	def updateDataFromFile(self):
		"read data from file"
		
		# Sample lines  from .piv file below (taken after header)
		# !       Vg[V]	Vd[V]	Vg_meas[V]	Vd_meas[V]	Id_raw[A]	Id_corr[A]
		# !PULSE: -4.000	0.000	-4.0449	0.0798	5.4115e-03	1.3021e-04
		# # S HZ MA R 50
		# !Freq	S11-mag	S11-ang	S21-mag	S21-ang	S12-mag	S12-ang	S22-mag	S22-ang
		# 1.00000e+09	9.80118e-01	-2.57527e+01	1.61297e-01	6.70114e+01	1.62254e-01	6.71045e+01	9.83858e-01	-1.77581e+01
		# 2.00000e+09	9.35766e-01	-4.86325e+01	2.86988e-01	4.65873e+01	2.88568e-01	4.65203e+01	9.46474e-01	-3.39163e+01
		# repeats as above starting with bias header line (!      Vg......)
		
		self.PIVlist.clear()
		self.Sparlist.clear()
		fp = open(self.filepath,'r')
		try:
			line = fp.readline()
			
			# assume file has header
			# move down till end of header
			# must check for both, \r\n and \n to be cross-platform compatible
			while not ( line == "!-----------------------------------------------------------------------------\n" or
						line == "!-----------------------------------------------------------------------------\r\n"):
				line = fp.readline()
				
			# move down one more line, now current line is first bias header
			line = fp.readline()
				
			# assume rest of file is contiguous (i.e. no newlines between points)
			while not line == "":
				# current line should be first bias header (!       Vg[V]\tVd[V]\t....), so move to next line
				line = fp.readline()
				
				# extract bias tuple, Vd, Vg, Id from line
				#!       Vg[V]	Vd[V]	Vg_meas[V]	Vd_meas[V]	Id_raw[A]	Id_corr[A]
				# !PULSE: -4.000	0.000	-4.0449	0.0798	5.4115e-03	1.3021e-04
				#	0		1		2		3		4		5			6
				pulsetokens = re.split('\s', line)
				
				# using formatted string to ensure keys match entries in drop-down box
				vg = "%.3f"%float(pulsetokens[1])
				vd = "%.3f"%float(pulsetokens[2])
				ids = float(pulsetokens[6])
				
				# update bias lists
				if not vg in self.vglist:
					self.vglist.append(vg)
				if not vd in self.vdlist:
					self.vdlist.append(vd)
				
				# if current gate bias isn't in the dict, add it
				if vg not in self.PIVlist.keys():
					self.PIVlist[vg] = ([vd], [ids])
				# otherwise, find it, and append the corresponding vd/id lists
				else:
					self.PIVlist.get(vg)[0].append(vd)
					self.PIVlist.get(vg)[1].append(ids)
				
				# since this is a PIV file, assuming all touchstone headers are exactly "# S HZ MA R 50"
				# TODO -- update this to be more general, using the parser from network_params.touchstone
				line = fp.readline()	# move to next line, should be touchstone header (# S HZ etc..)
				line = fp.readline()	# move to next line, should be touchstone comment (!Freq\tS11-mag\t........)
				line = fp.readline()	# move to next line (first frequency point for spar at this bias point)
				
				# while current line isn't bias header line
				# must check for both, \r\n and \n to be cross-platform compatible
				while not ( line == "!       Vg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_raw[A]\tId_corr[A]\n" or
				            line == "!       Vg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_raw[A]\tId_corr[A]\r\n"):
					if line == "\n" or line == "\r\n":
						line = fp.readline()
						continue
					elif line == "":
						break
					
					# extract frequency, spars from line
					#1.00000e+09	9.80118e-01	-2.57527e+01	1.61297e-01	6.70114e+01	1.62254e-01	6.71045e+01	9.83858e-01	-1.77581e+01
					# freq 0		s11mag 1	s11ang 2		s21mag 3	s21ang 4	s12mag 5	s12ang 6	s22mag 7	s22ang 8
					spartokens = re.split('\t|\n|\r\n', line)
					freq = spartokens[0]
					S11 = _MA_to_complex(spartokens[1], spartokens[2])
					S12 = _MA_to_complex(spartokens[5], spartokens[6])
					S21 = _MA_to_complex(spartokens[3], spartokens[4])
					S22 = _MA_to_complex(spartokens[7], spartokens[8])
					spar = matrix(	[[S11, S12],
									 [S21, S22]]) 
					bias = (vg, vd)
					
					# if current bias point isn't in spar dict, add it
					if bias not in self.Sparlist.keys():
						self.Sparlist[bias] = ([freq], [spar])
					#otherwise find it, and append the corresponding freq/spar lists
					else:
						self.Sparlist[bias][0].append(freq)
						self.Sparlist[bias][1].append(spar)
						
					line = fp.readline()	# move to next line
			
			self.filesize = os.stat(self.filepath).st_size 
			
			# Clear dropdown boxes, update them with new bias values
			self.vgDropDown.Clear()
			self.vgDropDown.Append("ALL")
			self.vgDropDown.AppendItems(self.vglist)
			
			self.vdDropDown.Clear()
			self.vdDropDown.Append("ALL")
			self.vdDropDown.AppendItems(self.vdlist)
			
			self.vgDropDown.SetSelection(0)
			self.vdDropDown.SetSelection(0)
		
		finally:
			fp.close()
			self.resizeCanvas()
	
	def plotPSpar(self, vg, vd):
		sparam = self.paramDropDown.GetValue()
		freqs, spars = self.Sparlist[(vg, vd)]
		freqdata = [float(x) for x in freqs]
		if self.gtypeDropDown.GetValue() == "Mag":
			spardata = [20*log10(absolute(x.item(SParLUT[sparam].value))) for x in spars]
			self.changeFigureType(PlotFigureType.SingleRectPlot)
			self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, freqdata)
			self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, spardata)
			self.y2min, self.y2max = 0.0, 1.0
			self.figure.plotData(freqdata, spardata)
			self.figure.setXLabel("Frequency [Hz]")
			self.figure.setYLabel("Magnitude [dB]")
			self.figure.setTitle(sparam)
		elif self.gtypeDropDown.GetValue() == "Phase":
			spardata = [angle(x.item(SParLUT[sparam].value), True) for x in spars]
			self.changeFigureType(PlotFigureType.SingleRectPlot)
			self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, freqdata)
			self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, spardata)
			self.y2min, self.y2max = 0.0, 1.0
			self.figure.plotData(freqdata, spardata, linestyle=LineStyle.Dashed, linecolor=LineColor.LtBlue)
			self.figure.setXLabel("Frequency [Hz]")
			self.figure.setYLabel("Phase [deg]")
			self.figure.setTitle(sparam)
		elif self.gtypeDropDown.GetValue() == "Both":
			sparmag = [20*log10(absolute(x.item(SParLUT[sparam].value))) for x in spars]
			sparang = [angle(x.item(SParLUT[sparam].value), True) for x in spars]
			self.changeFigureType(PlotFigureType.DoubleRectPlot)
			self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, freqdata)
			self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, sparmag)
			self.y2min, self.y2max = findLimitsTupleArray(self.y2min, self.y2max, sparang)
			self.figure.plotData(freqdata, sparmag, sparang, "Magnitude", "Phase")
			self.figure.setXLabel("Frequency [Hz]")
			self.figure.setY1Label("Magnitude [dB]")
			self.figure.setY2Label("Phase [deg]")
			self.figure.setTitle(sparam)
		elif self.gtypeDropDown.GetValue() == "Smith":
			self.changeFigureType(PlotFigureType.SmithPlot)
			self.xmin, self.xmax = 0.0, 1.0
			self.y1min, self.y1max = 0.0, 1.0
			self.y2min, self.y2max = 0.0, 1.0
			label = "Vg=" + vg + "; Vd=" + vd
			index = self.Sparlist.keys().index((vg, vd))
			spar = np.asarray([x.item(SParLUT[sparam].value) for x in spars])
			spardata = _get_normalized_impedance(spar)
			self.figure.plotLine(spardata, label, index, index)
			self.figure.setTitle(sparam)
	
	def excessivePlotWarning(self, numPlots):
		# if large list of points, prompt user to continue or not
		if (numPlots > excessiveBiasPoints):
			dlg = wx.MessageDialog(	self, "Greater than %d bias points may take a long time to render. Continue?"%excessiveBiasPoints,
									caption="Large number of bias points!",
									style=wx.YES_NO)
			if dlg.ShowModal() == wx.ID_NO:
				return False
		return True
	
	def updatePlot(self, e=None):
		self.selectedvg = self.vgDropDown.GetValue()
		self.selectedvd = self.vdDropDown.GetValue()
		self.resetAutoscaleLimits()
		
		if self.plotDropDown.GetValue() == "PIV":
			self.changeFigureType(PlotFigureType.IVPlot)
			self.figure.resetPlot()
			
			# if Vg = ALL, plot all gate bias plots
			# otherwise, only plot the selected gate bias plot
			if self.selectedvg == "ALL":
				for vg, data in self.PIVlist.iteritems():
					vd = [float(x) for x in data[0]]
					ids = [float(x) for x in data[1]]
					self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, vd)
					self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, ids)
					self.y2min, self.y2max = 0.0, 1.0
					self.figure.plotData(vd, ids, vg, self.PIVlist.keys().index(vg))
				self.figure.showLegend(True)
			else:
				vd = [float(x) for x in self.PIVlist[self.selectedvg][0]]
				ids = [float(x) for x in self.PIVlist[self.selectedvg][1]]
				self.xmin, self.xmax = min(vd), max(vd)
				self.y1min, self.y1max = min(ids), max(ids)
				self.y2min, self.y2max = 0.0, 1.0
				self.figure.plotData(vd, ids, self.selectedvg, self.PIVlist.keys().index(self.selectedvg))
				self.figure.showLegend(False)
		
		elif self.plotDropDown.GetValue() == "PSpar":
			if self.selectedvg == "ALL" and self.selectedvd == "ALL":
				self.figure.resetPlot()
				if not self.excessivePlotWarning(len(self.Sparlist.keys())):
					return
				
				for (vg, vd) in self.Sparlist.iterkeys():
					self.plotPSpar(vg, vd)
				
# 				if (len(self.Sparlist.keys()) < excessiveBiasPoints):
				self.figure.showLegend(True)
					
			elif self.selectedvg == "ALL" and not self.selectedvd == "ALL":
				self.figure.resetPlot()
				
				if not self.excessivePlotWarning(self.vgDropDown.GetCount() - 1):
					return
				
				for (vg, vd) in self.Sparlist.iterkeys():
					if vd == self.selectedvd:
						self.plotPSpar(vg, vd)
						
# 				if (len(self.Sparlist.keys()) < excessiveBiasPoints):
				self.figure.showLegend(True)
					
			elif not self.selectedvg == "ALL" and self.selectedvd == "ALL":
				self.figure.resetPlot()
				
				if not self.excessivePlotWarning(self.vdDropDown.GetCount() - 1):
					return
				
				for (vg, vd) in self.Sparlist.iterkeys():
					if vg == self.selectedvg:
						self.plotPSpar(vg, vd)
						
# 				if (len(self.Sparlist.keys()) < excessiveBiasPoints):
				self.figure.showLegend(True)
			else:
				self.figure.resetPlot()
				self.plotPSpar(self.selectedvg, self.selectedvd)
				self.figure.showLegend(False)
			
		else:
			print "TODO -- implement update plots for SPars, SS, etc."
			
		self.autoScaleX()
		self.autoScaleY1()
		self.autoScaleY2()
		
		self._redraw = True
		
	def timerUpdate(self, event=None):
		"check if the file has changed"
		try:
			current_filesize = os.stat(self.filepath).st_size
		except Exception:
			return
		
		if current_filesize != self.filesize:
			# plot needs to be updated
			self.updateDataFromFile()
			self.updatePlot()

class DCMonitorCanvas(GenericCanvas):
	"Canvas for a DC Monitor file"
	
	ctype = CanvasType.DCMonitor
	ftype = PlotFigureType.DCMonitorPlot
	filepath = None
	filename = None
	filesize = None
	timevalues = [ ]
	igatevalues = [ ]
	idrainvalues = [ ]
	
	def __init__(self, parent, identifier, figure, path=None, name=None, initialterminal="Gate", live=True):
		super(DCMonitorCanvas,self).__init__(parent, identifier, figure)
		self.filepath = path
		self.filename = name
		
		# Drop-down for gate/drain
		self.terminalDropDown = wx.ComboBox(	self,
												wx.ID_ANY,
												initialterminal,
												choices=["Gate", "Drain"],
												style=wx.CB_DROPDOWN|wx.CB_READONLY|wx.CB_SORT)
		
		self.Bind(wx.EVT_COMBOBOX, self.updatePlot, self.terminalDropDown)
		
		if self.filename is not None:
			self.titleTextBox.SetValue(self.filename)
			self.titleTextLabel.SetLabel(self.filename)
			self.updateTitle()
			self.resizeCanvas()
		
		if self.filepath is not None:
			self.updateDataFromFile()
			self.updatePlot()
			self.liveUpdateChkBox.SetValue(True)
			self.liveUpdate()
		
			self._redraw = True
	
	def resizeCanvas(self):
		self.terminalDropDown.SetPosition(wx.Point(0, 0))
		GenericCanvas.resizeCanvas(self)
	
	def abs_to_elapsed(self, timeList):
		"process raw time strings into elapsed time (in seconds)"
		tl = []
		for t in timeList:
			td = datetime.strptime(t, '%Y/%m/%d %H:%M:%S') - datetime.strptime(timeList[0], '%Y/%m/%d %H:%M:%S')
			tl.append(td.days * 1440 + td.seconds // 60)
		return tl
	
	def updateDataFromFile(self):
		"read data from file"
		
		# Sample lines from .dat file below
		# Timestamp	Igate	Idrain
		# 2015/07/13 11:25:52	-4.11959e-07	0.0603194
		# date <space> time <tab> ig <tab> id
		
		fp = open(self.filepath,'r')
		try:
			lines = fp.readlines()
			time, igate, idrain = [], [], []
			for line in lines:
				if line == lines[0]:
					if (line == "Timestamp\tIgate\tIdrain\n" or line == "\n" or
						line == "Timestamp\tIgate\tIdrain\r\n" or line == "\r\n"):
						continue
					else:
						self.parent.parent.parent.err_msg("Invalid DC Monitor data file!")
						return
				
				try:
					tokens = re.split('\t', line)
					time.append(tokens[0])			# get timestamp (without date)
					igate.append(float(tokens[1]))	# get gate current
					idrain.append(float(tokens[2]))	# get drain current
				except Exception:
					pass
		
		finally:
			fp.close()
		
		times = self.abs_to_elapsed(time)
		self.timevalues = times
		self.igatevalues = igate
		self.idrainvalues = idrain
		self.filesize = os.stat(self.filepath).st_size
	
	def updatePlot(self, e=None):
		self._redraw = True
		self.xmin = min(self.timevalues)
		self.xmax = max(self.timevalues)
		self.y2min = 0.0
		self.y2max = 1.0
		if self.terminalDropDown.GetValue() == "Gate":
			self.figure.plotData(self.timevalues, self.igatevalues, "Gate")
			self.y1min = min(self.igatevalues)
			self.y1max = max(self.igatevalues)
		else:
			self.figure.plotData(self.timevalues, self.idrainvalues, "Drain")
			self.y1min = min(self.idrainvalues)
			self.y1max = max(self.idrainvalues)
		
		self.autoScaleX()
		self.autoScaleY1()
	
	def timerUpdate(self, event=None):
		"check if the file has changed"
		try:
			current_filesize = os.stat(self.filepath).st_size
		except Exception:
			return
		
		if current_filesize != self.filesize:
			# plot needs to be updated
			self.updateDataFromFile()
			self.updatePlot()

class S2PCanvas(GenericCanvas):
	"Canvas for a PIV and Pulsed S-Parameter file, displays an IVPlot by default"
	ctype = CanvasType.S2P
	ftype = PlotFigureType.SingleRectPlot
	filepath = None
	filename = None
	filesize = None
	
	# ordered dict of 2-tuple:2-tuple of list key/val pairs -- (Vg, Vd):(freq list, spar tuple list)
	freqlist = [ ]
	sparlist = [ ]
	
	def __init__(self, parent, identifier, figure, path=None, name=None):
		super(S2PCanvas,self).__init__(parent, identifier, figure)
		self.filepath = path
		self.filename = name
		
		# Drop-down for parameter (which s-par or which SS parameter)
		# TODO -- add SS parameters
		self.paramDropDown = wx.ComboBox(	self,
											wx.ID_ANY,
											"S11",
											choices=["S11", "S12", "S21", "S22"],
											style=wx.CB_DROPDOWN|wx.CB_READONLY)
		
		# Drop-down for type of graph (either mag/phase/both/Smith for spars, or Vg/Vd for SS params)
		self.gtypeDropDown = wx.ComboBox(	self,
											wx.ID_ANY,
											"Both",
											choices=["Mag", "Phase", "Both", "Smith"],
											style=wx.CB_DROPDOWN|wx.CB_READONLY)
		
		self.Bind(wx.EVT_COMBOBOX, self.updatePlot)
		
		self.updateTitle()
		
		if self.filepath is not None:
			self.updateDataFromFile()
			self.updatePlot()
			self.liveUpdateChkBox.SetValue(True)
			self.liveUpdate()
		
		self.resizeCanvas()
	
	def resizeCanvas(self):
		self.paramDropDown.SetPosition(wx.Point(	0,
													0))
		self.gtypeDropDown.SetPosition(wx.Point(	self.paramDropDown.GetSizeTuple()[0],
													0))
		GenericCanvas.resizeCanvas(self)
	
	def updateDataFromFile(self):
		"read data from file"
		
		# read data from file
		reader = Touchstone(self.filepath)
		
		# convert arbitrary S2P file to Hz/Mag-Angle data-format before pulling data
		reader.set_format("# HZ S MA R 50", True)
		
		# pull data from reader
		self.freqlist = reader.flist
		self.sparlist = reader.extract_raw(self.freqlist)
		
		# update filesize
		self.filesize = os.stat(self.filepath).st_size 
		self.resizeCanvas()	

	def updatePlot(self, e=None):
		sparam = self.paramDropDown.GetValue()
		self.figure.resetPlot()
		self.resetAutoscaleLimits()
		if self.gtypeDropDown.GetValue() == "Mag":
			spardata = [20*log10(absolute(x.item(SParLUT[sparam].value))) for x in self.sparlist]
			self.changeFigureType(PlotFigureType.SingleRectPlot)
			self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, self.freqlist)
			self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, spardata)
			self.y2min, self.y2max = 0.0, 1.0
			self.figure.plotData(self.freqlist, spardata)
			self.figure.setXLabel("Frequency [Hz]")
			self.figure.setYLabel("Magnitude [dB]")
			self.figure.setTitle(sparam)
		elif self.gtypeDropDown.GetValue() == "Phase":
			spardata = [angle(x.item(SParLUT[sparam].value), True) for x in self.sparlist]
			self.changeFigureType(PlotFigureType.SingleRectPlot)
			self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, self.freqlist)
			self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, spardata)
			self.y2min, self.y2max = 0.0, 1.0
			self.figure.plotData(self.freqlist, spardata, linestyle=LineStyle.Dashed, linecolor=LineColor.LtBlue)
			self.figure.setXLabel("Frequency [Hz]")
			self.figure.setYLabel("Phase [deg]")
			self.figure.setTitle(sparam)
		elif self.gtypeDropDown.GetValue() == "Both":
			sparmag = [20*log10(absolute(x.item(SParLUT[sparam].value))) for x in self.sparlist]
			sparang = [angle(x.item(SParLUT[sparam].value), True) for x in self.sparlist]
			self.changeFigureType(PlotFigureType.DoubleRectPlot)
			self.xmin, self.xmax = findLimitsTupleArray(self.xmin, self.xmax, self.freqlist)
			self.y1min, self.y1max = findLimitsTupleArray(self.y1min, self.y1max, sparmag)
			self.y2min, self.y2max = findLimitsTupleArray(self.y2min, self.y2max, sparang)
			self.figure.plotData(self.freqlist, sparmag, sparang, "Magnitude", "Phase")
			self.figure.setXLabel("Frequency [Hz]")
			self.figure.setY1Label("Magnitude [dB]")
			self.figure.setY2Label("Phase [deg]")
			self.figure.setTitle(sparam)
		elif self.gtypeDropDown.GetValue() == "Smith":
			self.changeFigureType(PlotFigureType.SmithPlot)
			self.xmin, self.xmax = 0.0, 1.0
			self.y1min, self.y1max = 0.0, 1.0
			self.y2min, self.y2max = 0.0, 1.0
			spar = np.asarray([x.item(SParLUT[sparam].value) for x in self.sparlist])
			spardata = _get_normalized_impedance(spar)
			self.figure.plotLine(spardata, "", LineStyle.Solid, LineColor.LtRed)
			self.figure.setTitle(sparam)
		
		self.autoScaleX()
		self.autoScaleY1()
		self.autoScaleY2()
		
		self._redraw = True

	def timerUpdate(self, event=None):
		"check if the file has changed"
		try:
			current_filesize = os.stat(self.filepath).st_size
		except Exception:
			return
		
		if current_filesize != self.filesize:
			# plot needs to be updated
			self.updateDataFromFile()
			self.updatePlot()
			

###############################################################################	
# Panel Class
###############################################################################
class WxPlotPanel(scrolledpanel.ScrolledPanel):
	"Panel that contains all of the plots"
	def __init__( self, parent, **kwargs):
		"initializer"
		
		# initialize Panel
		if 'id' not in kwargs.keys():
			kwargs['id'] = wx.ID_ANY
		if 'style' not in kwargs.keys():
			kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS
		else:
			kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS 
		super(WxPlotPanel,self).__init__(parent,**kwargs)
		
		self.parent = parent
		self.sizer = wx.BoxSizer(wx.HORIZONTAL)
		self.SetSizer(self.sizer)
		self.sizer.FitInside(self)
		self.canvases = [ ]
		self.addCanvas()

		self._resizeflag = False

		self.Bind(wx.EVT_IDLE, self._onIdle)
		self.Bind(wx.EVT_SIZE, self._onSize)
		self.Bind(wx.EVT_SCROLL, self._SetSize())
	
	def addCanvas(self, newcanvas=None):
		if newcanvas is None:
			newcanvas = GenericCanvas(self, wx.ID_ANY, SingleRectPlot())
		self.canvases.append(newcanvas)
		
		# change to gridsizer if making more than one plot
		# should ONLY change when creating plot #2
		if len(self.canvases) == 2:
			self.sizer = wx.GridSizer(0, 2, 5, 5)	# "0" rows == create rows as needed
			self.SetSizer(self.sizer)
			self.sizer.Add(self.canvases[0], 1, wx.ALL | wx.GROW | wx.FIXED_MINSIZE) # add first plot to new sizer
			self.sizer.SetItemMinSize(self.canvases[0], wx.Size(800, 600))
		
		self.sizer.Add(self.canvases[-1], 1, wx.ALL | wx.GROW | wx.FIXED_MINSIZE)
		self.sizer.SetItemMinSize(self.canvases[-1], wx.Size(800, 600))
		self.Layout()
		self._SetSize()
	
	def removeCanvas(self, canvas):
		if self.sizer.Detach(canvas):
			title = canvas.titleTextBox.GetValue()
			self.canvases.remove(canvas)
			
			# change back to boxsizer if down to a single plot
			if len(self.canvases) == 1:
				self.sizer = wx.BoxSizer()
				self.SetSizer(self.sizer)
				self.sizer.Add(self.canvases[0], 1, wx.ALL | wx.GROW | wx.FIXED_MINSIZE)
				self.sizer.SetItemMinSize(self.canvases[0], wx.Size(800, 600))
				
			canvas.Destroy()
			self.Layout()
			self._SetSize()
			self.parent.status_msg("Canvas \"%s\" Removed!"%title)
	
	def changeCanvas(self, canvas, canvastype=CanvasType.GenericRect, filepath=None, filename=None):
		newcanvas = [ ]
		if canvastype == CanvasType.PIVandS:
			newcanvas.append(PIVandSCanvas(self, wx.ID_ANY, IVPlot(), filepath, filename, "PIV"))
		elif canvastype == CanvasType.DCMonitor:
			newcanvas.append(DCMonitorCanvas(self, wx.ID_ANY, DCMonitorPlot(), filepath, filename, "Gate"))
			newcanvas.append(DCMonitorCanvas(self, wx.ID_ANY, DCMonitorPlot(), filepath, filename, "Drain"))
		elif canvastype == CanvasType.S2P:
			newcanvas.append(S2PCanvas(self, wx.ID_ANY, SingleRectPlot(), filepath, filename))
		elif canvastype == CanvasType.GenericRect:
			newcanvas = GenericCanvas(self, wx.ID_ANY, SingleRectPlot())
		else:
			self.parent.error_msg("Invalid Canvas Type!")
		
		if len(newcanvas) == 0:
			wx.MessageBox(message="File-type not implemented yet!", caption="Unable to open file!", style=wx.CENTRE)
			return
		
		index = self.canvases.index(canvas)
		oldtype = canvas.ctype
		oldtitle = canvas.titleTextBox.GetValue()
		if len(newcanvas) == 1:
			if self.sizer.Replace(canvas, newcanvas[0]):
				self.canvases[index] = newcanvas[0]
				canvas.Destroy()
				self.Layout()
				self._SetSize()
				self.parent.status_msg("Canvas \"%s (%s)\" replaced with new canvas of type \"%s\"!"%(oldtitle, oldtype.name, canvastype.name))
		else:
			# replace existing canvas with first in new list
			if self.sizer.Replace(canvas, newcanvas[0]):
				self.canvases[index] = newcanvas[0]
				canvas.Destroy()
				self.Layout()
				
			# add rest of new list
			for nc in newcanvas[1:]:
				self.addCanvas(nc)
			self.Layout()
			self._SetSize()
			self.parent.status_msg("Canvas \"%s (%s)\" replaced with new canvases of type \"%s\"!"%(oldtitle, oldtype.name, canvastype.name))
	
	def _onSize( self, event ):
		"event method for resize"
		self._resizeflag = True

	def _onIdle( self, evt ):
		"event method for idle events"
		if self._resizeflag:
			self._SetSize()
		
	def _SetSize( self ):
		"resize the figure image" 
		self.Layout()
		self.SetupScrolling()
		for c in self.canvases:
			c.resizeCanvas()
		self._resizeflag = False
		
###############################################################################	
# Frame Class
###############################################################################
class WxPlotFrame(wx.Frame):
	"Frame that contains the Plot Panel"	
	
	def __init__( self, parent=None, *args, **kwargs ):
		"initializer"
	
		title = kwargs.pop('title','Plot')
		super(WxPlotFrame,self).__init__(parent,*args,**kwargs)
		
		self.SetTitle(title)
		
		# create a status bar
		self.statusbar = self.CreateStatusBar()
		
		# create a menu bar
		menubar = wx.MenuBar()

		filemenu = wx.Menu()
		addNewPlot_menu = wx.MenuItem(filemenu, wx.ID_ANY, '&Add New Plot\tCtrl+N')
		filemenu.AppendItem(addNewPlot_menu)
# 		omi = wx.MenuItem(filemenu, wx.ID_ANY, '&Open .dat File\tCtrl+O')
# 		filemenu.AppendItem(omi)
# 		lmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Live Mode\tCtrl+L')
# 		filemenu.AppendItem(lmi)
# 		smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
# 		filemenu.AppendItem(smi)
# 		filemenu.AppendSeparator()
		qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
		filemenu.AppendItem(qmi)

		self.Bind(wx.EVT_MENU, self.addNewPlot, addNewPlot_menu)
# 		self.Bind(wx.EVT_MENU,self.open_plotfile,omi)
# 		self.Bind(wx.EVT_MENU,self.live_mode,lmi)
# 		self.Bind(wx.EVT_MENU,self.save_figure,smi)
		self.Bind(wx.EVT_MENU,self.OnQuit,qmi)

		menubar.Append(filemenu, '&File')
		self.SetMenuBar(menubar)
		
		# panel that holds all of the plots
		self.panel = WxPlotPanel(self)
		
		self.Centre()
		self.Show(True)
					
	def OnQuit(self, e=None):
		"capture quit commands"
		self.Close()
	
	def addNewPlot(self, e=None):
		# wrap panel's addCanvas method to avoid passing in binding wx.Event as newcanvas argument
		self.panel.addCanvas()
	
	def status_msg(self, msg):
		"print a status message to the status bar"
		self.statusbar.SetForegroundColour('black')
		self.statusbar.SetStatusText(msg)
		
	def error_msg(self, msg):
		"print an error message to the status bar"
		self.statusbar.SetForegroundColour('red')
		self.statusbar.SetStatusText(msg)
		
