import visa
from pyvisa import vpp43
from instrument import timed_wait_ms

class AgilentMSO(object):
    "Agilent MSO/DSO scope driver"
    
    def __init__(self, addr):
        "initialize"
        self.vi = visa.instrument(addr)
        self.init()
        
    def init(self):
        "init instrument state"
        self.vi.write('*CLS')
        self.vi.write('MARK:MODE WAV')
        # not a valid command
        #self.vi.write('MARK:TYPE AVER')
        self.vi.write('ACQ:TYPE AVER;COUN 256;COMP 100;*CLS')
        self.vi.write('WAV:POIN:MODE NORM')
        # not a valid command
        #self.vi.write('TRIG:SWE:NORM')

    def trigger(self):
        "trigger sweep"
        self.vi.write(':DIG')
    sweep = trigger
    
    
    def measure(self, chan, qpoint=False):
        "measure sweep"
        # grab waveform, but skip first point
        w = self.vi.ask_for_values('WAV:SOUR CHAN%d;FORM ASC;DATA?'%chan)[1:]
        n = len(w)
        # get timing (x-axis) parameters
        range = float(self.vi.ask('TIM:RANG?'))
        pos = float(self.vi.ask('TIM:POS?'))
        ref = self.vi.ask('TIM:REF?').strip().upper()
        if ref == 'LEFT':
            sf = 0.1
        elif ref == 'RIGH':
            sf = 0.9
        else:
            sf = 0.5
        
        zidx = int(n*(sf-pos/range))
        
        self.vi.ask('MARK:X1Y1 CHAN%d;X2Y2 CHAN%d;*OPC?'%(chan,chan))
        
        x1 = float(self.vi.ask('MARK:X1P?'))
        x2 = float(self.vi.ask('MARK:X2P?'))
        x1i = int((x1/range)*n) + zidx
        x2i = int((x2/range)*n) + zidx
                
        if x1i > x2i:
            x1i, x2i = x2i, x1i
        av = 0.0
        for v in w[x1i:x2i+1]:
            av += v
        av = av/float(x2i-x1i+1)
        
        if qpoint:
            # average the first 5 points of the waveform to get the q-point
            qp = 0.0
            for v in w[:5]:
                qp += v
            qp *= 0.2
            return av, qp
        else:
            return av
    
    def getMarkerPos(self):
        "get marker positions, returns a 2-tuple"
        x1 = float(self.vi.ask('MARK:X1P?'))
        x2 = float(self.vi.ask('MARK:X2P?'))
        return x1, x2    
    
    def setMarkerPos(self,*args):
        "set marker position"
        if len(args) == 2:
            m1, m2 = float(args[0]), float(args[1])
        elif len(args) == 1:
            m1, m2 = float(args[0][0]), float(args[0][1])        
        self.vi.write('MARK:X1P %g;X2P %g'%(m1,m2))
    
    def getYScale(self,chan):
        "get Y scale of a channel"
        return float(self.vi.ask('CHAN%d:SCAL?'%chan))
    
    def getYOffset(self,chan):
        "get Y offset of a channel"
        return float(self.vi.ask('CHAN%d:OFFS?'%chan))
    
    def setYScale(self, chan, v):
        "set Y scale of a channel"
        self.vi.write('CHAN%d:SCAL %g'%(chan,v))
    
    def setYOffset(self, chan, v):
        "set Y offset of a channel"
        self.vi.write('CHAN%d:OFFS %g'%(chan,v))
    
    def getWaveform(self, chan):
        """get the scope waveform of a channel
        
        returns a 2-tuple of lists of x-values (in time units)
        and y-values (in the units of the trace)
        """
        w = self.vi.ask_for_values('WAV:SOUR CHAN%d;FORM ASC;DATA?'%chan)
        n = len(w)
        range = float(self.vi.ask('TIM:RANG?'))
        ref = self.vi.ask('TIM:REF?').strip().upper()
        pos = float(self.vi.ask('TIM:POS?'))
        if ref == 'LEFT':
            sf = 0.1
        elif ref == 'RIGH':
            sf = 0.9
        else:
            sf = 0.5
        
        ts = pos-sf*range
        step = range/float(n-1)
        x, y = [], []
        for v in w:
            y.append(v)
            x.append(ts)
            ts += step
        
        return x, y        
        
    def close(self):
        "close instrument"
        if hasattr(self,'vi') and self.vi is not None:
            self.vi.write(':RUN')
            self.vi.close()
            self.vi = None      
    
    def __del__(self):
        "auto-close instrument on delete"
        self.close()


class LambdaPS(object):
    "TDK Lambda power supply"
    
    def __init__(self, addr, nsel):
        "initialize"
        self.vi = visa.instrument(addr)
        self.nsel = nsel
        self.setState(0)
        self.vi.write(':VOLT:LIMIT:LOW 0')
        self.vi.write(':VOLT:PROTECTION:LEVEL 80')
        timed_wait_ms(100)
    
    def _nsel(self):
        "run instrument select command"
        self.vi.write('INST:NSEL %d'%self.nsel)
        
    def setCurrent(self,curr):
        "set current"
        self._nsel()
        self.vi.write(':CURR '+str(curr))
        timed_wait_ms(100)
        
    def setVoltage(self,volt):
        "set voltage"
        self._nsel()
        self.vi.write(':VOLT '+str(volt))
        timed_wait_ms(100)
        
    def readVoltage(self):
        "read voltage"
        self._nsel()
        return float(self.vi.ask(':VOLTAGE?'))  
        
    def readCurrent(self):
        "read current"
        self._nsel()
        return float(self.vi.ask('MEAS:CURR?'))
    
    def getState(self):
        "get state"
        self._nsel()
        return int(self.vi.ask('OUTP:STAT?'))

    def setState(self, onoff=0):
        "set state"
        s = 0
        if bool(onoff):
            s = 1        
        self._nsel()
        self.vi.write('OUTP:STAT %d'%s)

    def close(self):
        "close instrument"
        if hasattr(self,'vi') and self.vi is not None:          
            self.vi.close()
            self.vi = None      
    
    def __del__(self):
        "auto-close instrument on delete"
        self.close()

    

            
class Agilent6632(object):
    "agilent 6632 instrument driver"
    
    def __init__(self, addr):
        "initializer"
        self.vi = visa.instrument(addr)
        self.vi.write('RST')
        self.vi.write('CLR')
        self.vi.write('OVSET 50.0')
        self.setState(0)
                
    def setCurrent(self,curr):
        "set current"
        self.vi.write('ISET %g'%curr)
        timed_wait_ms(30)
        
    def setVoltage(self,volt):
        "set voltage"
        self.vi.write('VSET %g'%volt)
        timed_wait_ms(30)
        
    def readVoltage(self):
        "read voltage"
        return float(self.vi.ask('VOUT?'))
    
    def readCurrent(self):
        "read current"
        return float(self.vi.ask('IOUT?'))
    
    def setState(self,onoff=0):
        "set output state"
        s = 0
        if bool(onoff):
            s = 1
        self.vi.write('OUT %d'%s)
        timed_wait_ms(30)
        
    def getState(self):
        "get output state"
        return int(self.vi.ask('OUT?'))
    
    def close(self):
        "close instrument"
        if hasattr(self,'vi') and self.vi is not None:          
            self.vi.close()
            self.vi = None      
    
    def __del__(self):
        "auto-close instrument on delete"
        self.close()
    
class AgilentN6700(object):
    "agilent N6700 instrument driver"
    
    def __init__(self, addr, chan=1):
        "initializer"
        self.vi = visa.instrument(addr)
        self.chan = int(chan)
        self.init()
    
    def init(self):
        "initialize state"
        self.vi.write('OUTP:STAT 0,(@%d)'%self.chan)
        #self.vi.write('SOUR:VOLT:PROT 50.0,(@%d)'%self.chan)
        self.vi.write('SOUR:CURR:PROT:STAT 0,(@%d)'%self.chan)
                
    def setCurrent(self,curr):
        "set current"
        self.vi.write('SOUR:CURR %g,(@%d)'%(curr,self.chan))
        timed_wait_ms(30)
        
    def setVoltage(self,volt):
        "set voltage"
        self.vi.write('SOUR:VOLT %g,(@%d)'%(volt,self.chan))
        timed_wait_ms(30)
        
    def readVoltage(self):
        "read voltage"
        return float(self.vi.ask('MEAS:VOLT? (@%d)'%self.chan))
    
    def readCurrent(self):
        "read current"
        return float(self.vi.ask('MEAS:CURR? (@%d)'%self.chan))
    
    def setState(self,onoff=0):
        "set output state"
        s = 0
        if bool(onoff):
            s = 1
        self.vi.write('OUTP:STAT %d,(@%d)'%(s,self.chan))
        timed_wait_ms(30)
        
    def getState(self):
        "get output state"
        return int(self.vi.ask('OUTP:STAT? (@%d)'%self.chan))
        
    def close(self):
        "close instrument"
        if hasattr(self,'vi') and self.vi is not None:          
            self.vi.close()
            self.vi = None      
    
    def __del__(self):
        "auto-close instrument on delete"
        self.close()
    

    
class FocusPulser(object):
    "Focus pulser driver"
    
    def __init__(self, rsc):
        "initializer"
        self.vi = visa.instrument(rsc)
        # set VISA to terminate reads on receipt of the '>' character
        vpp43.set_attribute(self.vi.vi, vpp43.VI_ATTR_TERMCHAR, ord('>'))
        vpp43.set_attribute(self.vi.vi, vpp43.VI_ATTR_TERMCHAR_EN, True)
        # read the initial block of data from the connection 
        self.vi.read()
        
        self.init()
        
    def init(self):
        "initialize"
        pass
    
    def setPulse(self, width, period):
        "set up the pulse"
        self._write('PULSE %g %g'%(width,period))
        self.enable()
    
    def setTiming(self, gate1=0.0, gate2=0.0, drain1=0.0, drain2=0.0):
        "set up pulser timing"
        self._write('TIMING GATE %g %g'%(gate1,gate2))
        self._write('TIMING DRAIN %g %g'%(drain1,drain2))
        self._write('TRIGGER FREE')
        timed_wait_ms(500)
    
    def setGate(self, vg, vgq):
        "set gate voltages"
        self._write('GATE PULSE %g %g'%(vg,vgq))
        timed_wait_ms(100)
    
    def setDrain(self, vd, vdq):
        "set drain voltages"
        if vd > vdq:
            self._write('DRAIN PULSE %g %g'%(vdq,0.0))
        else:
            self._write('DRAIN PULSE %g %g'%(0.0,vdq))
        timed_wait_ms(100)
    
    def disable(self):
        "disable the pulser"
        self._write('DRAIN OFF')
        self._write('MODE PULSE')
        timed_wait_ms(500)
        self._write('RELAY 0')
        self._write('GATE OFF')
        timed_wait_ms(500)
        
    def enable(self):
        "enable the pulser"
        self._write('TRIGGER FREE')
        self._write('MODE PULSE')
        self._write('RELAY 1')
        timed_wait_ms(500)
        
    def _write(self, cmd):
        "write a command and wait for the prompt to re-appear"
        resp = self.vi.ask(cmd.rstrip())
    
    def close(self):
        "close instrument"
        if hasattr(self,'vi') and self.vi is not None:          
            self.vi.close()
            self.vi = None      
    
    def __del__(self):
        "auto-close instrument on delete"
        self.close()
    
        
 