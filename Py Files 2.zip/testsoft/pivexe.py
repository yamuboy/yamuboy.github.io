"""
Custom PIV program


"""
import os, sys, traceback, math
from datetime import datetime
#import socket
#import thread
#import matplotlib.pyplot as plt
#from modeling.configfile import ConfigVars,ConfigFile
#from modeling.configtypes import *
#from itertools import *

# bad practice to import *, but in this case it is OK
# this module defines the instrument drivers
from .pivlib import *
from modeling import ConfigData

class PIV_Config(ConfigData):
    "class for storing pulsed IV config data"
    
    def __init__(self):
        "initializer"
        super(PIV_Config,self).__init__(search_path='pulsediv', disable_default=True)
    
    def read_file(self, fname):
        "modify the read_file method to set the default namespace"
        super(PIV_Config,self).read_file(fname,default_ns='pulsediv')

##########################################################################
#### define configuration variables
##########################################################################

_cv = PIV_Config()

# pulser parameters
_cv.add('pulse_width',1.0,float,help="pulse width in microseconds")
_cv.add('pulse_period',1000.0,float,help="pulse period in microseconds")
_cv.add('vgs_vds_offset',0.1,float,help="offset between the Vgs and Vds pulse in microseconds")
_cv.add('qpoint_offset',-1000.0,float,help="offset to use for measuring the Q-point")
_cv.add('qpoint_window',1.0,float,help="time window to use for measuring the Q-point")

# gate voltage parameters
_cv.add('gate_q',0.0,float,help="gate quiescent voltage")
_cv.add('gate_cal_pulsed_v',0.0,float,help="gate pulsed calibration voltage (need to ensure that drain current is 0 at this voltage)")
_cv.add('gate_start',0.0,float,help="gate voltage sweep start")
_cv.add('gate_stop',0.1,float,help="gate voltage sweep stop")
_cv.add('gate_step',0.1,float,help="gate voltage sweep step")
_cv.add('gate_sweep_list',None,list,help="gate voltage sweep list, overrides gate_start, gate_stop, and gate_step settings")
_cv.add('gate_q_min',-2.0,float,help="minimum gate q-point setting for the q-point targeting routine")
_cv.add('gate_q_max',0.0,float,help="maximum gate q-point setting for the q-point targeting routine")

# drain voltage parameters
_cv.add('drain_q',0.0,float,help="drain quiescent voltage")
_cv.add('drain_start',0.0,float,help="drain voltage sweep start")
_cv.add('drain_stop',1.0,float,help="drain voltage sweep stop")
_cv.add('drain_step_coarse',1.0,float,help="drain voltage sweep course step")
_cv.add('drain_step_fine',0.1,float,help="drain voltage sweep fine step")
_cv.add('drain_step_transition',-1.0,float,help="drain voltage to use as the transition point between fine and course step size")
_cv.add('drain_sweep_list',None,list,help="drain voltage sweep list, overrides drain_start, drain_stop, and drain_step* settings")

# power limits
_cv.add('plimit_region1',1.0,float,help="power limit for region 1")
_cv.add('plimit_region2',1.0,float,help="power limit for region 2")
_cv.add('plimit_region3',1.0,float,help="power limit for region 3")
_cv.add('plimit_region4',1.0,float,help="power limit for region 4")
_cv.add('plimit_vds_region1',-1.0,float,help="power limit for region 1")
_cv.add('plimit_vds_region2',-1.0,float,help="power limit for region 2")
_cv.add('plimit_vds_region3',-1.0,float,help="power limit for region 3")
_cv.add('plimit_vds_region4',-1.0,float,help="power limit for region 4")

# measurement parameters
_cv.add('drain_ilimit',10.0,float,help="drain current limit in amps")
_cv.add('drain_iscale',1.0,float,help="scale factor for drain current")
_cv.add('dont_swap_timing',False,bool,help="turn off the feature that swaps gate/drain pulse timing as a function of drain voltage")

# q-point shift
_cv.add('check_qpoint_shift',True,bool,help="check for q-point shift during measurement")
_cv.add('qpoint_shift_fraction',0.2,float,help="fraction of current that results in a q-point shift error")

# pulsed spars
_cv.add('measure_pulsed_spars',False,bool,help="turn on pulsed S-param measurement")

# system timing parameters
_cv.add('vd_slew_rate',50.0,float,help="drain supply slew rate in V/sec")


def load_instruments(*args,**kwargs):
    "load instruments"
    fname = kwargs.pop('fname','piv_instr.cfg')
    cfg = {}
    execfile(fname,cfg)
    del cfg['__builtins__']
    
    g = globals()
    ilist = []
    for n in args:
        if n not in cfg:
            raise ValueError("'%s': '%s' is not configured"%(fname,n))
        if not isinstance(cfg[n],tuple):
            raise TypeError("'%s': '%s' is not a tuple"%(fname,n))
        
        cls = cfg[n][0]
        alst = cfg[n][1:]
        
        if cls not in g:
            raise ValueError("'%s': class '%s' is not defined"%(fname,cls))
        
        # instanciate the instrument
        try:
            ilist.append(g[cls](*alst))
        except Exception, e:
            raise ValueError("failed to load '%s' - > %s"%(n,e))
    
    return ilist
    
def run_test(filename,cfgfile,mode,vgq=None):
    "run the test"
    # re-read the config file
    cfg = PIV_Config()
    cfg.read_file(cfgfile)
    
    ### create instruments
    ilist = []
    
    ret = None

    if mode == 'test':
        # load instruments
        try:
            ilist = load_instruments('vdlow','vdhigh','pulser','oscope')
            pna = None
            if cfg['measure_pulsed_spars']:
                # load the instrument config again and get the PNA address
                ic = {}
                execfile('piv_instr.cfg',ic)
                if 'pna' in ic:
                    addr = ic['pna'][1]
                else:
                    addr = 'GPIB::16'
                pna = visa.instrument(addr,values_format=visa.double)
        except Exception, e:
            sys.stderr.write(traceback.format_exc()+"\n")
            sys.stderr.write("Failed to load instruments ...\n")
            return
    
        if filename is None:
            # interactive filename selection
            filename = raw_input('Enter the filename for the data\n: ')
            if os.path.exists(filename):
                print("Warning: '%s' exists"%filename)
                ans = raw_input('* Overwrite existing file (y/N)? ').strip().lower()
                if not ans.startswith('y'):
                    print('Aborting ...')
                    sys.exit(0)
    
        fp = open(filename,'w')
        fpplot = open('pivplotdata.txt','w')
        try:
            run_test_inner(fp,fpplot,*ilist,vgq_override=vgq,pna=pna)
        except KeyboardInterrupt:
            sys.stderr.write("exiting on user abort ...\n")
        except Exception, e:
            sys.stderr.write(traceback.format_exc()+"\n")
            sys.stderr.write("Exiting on fatal exception ...\n")            
            
        fp.close()
        fpplot.close()
        
        if pna:
            # allow the PNA to enter continous sweep mode
            pna.write('SENS1:SWE:MODE CONT')            
        
        ilist[2].disable()
        ilist[0].setState(0) 
        ilist[1].setState(0)
    elif mode == 'cursors':
        try:
            ilist = load_instruments('vdlow','vdhigh','pulser')
            setup_scope_cursors(*ilist)
        except Exception, e:
            sys.stderr.write(traceback.format_exc()+"\n")
            sys.stderr.write("Operation failed with fatal exception ...\n")
    elif mode == 'qpoint':
        try:
            qp = abs(float(raw_input("Target Q-point current in mA? ")))*0.001
        except KeyboardInterrupt:
            return
        except Exception, e:
            sys.stderr.write("Failed ...\n")
            return
    
        try:
            ilist = load_instruments('vdlow','vdhigh','pulser','oscope')
            vg, ids = target_qpoint(qp, *ilist)
            sys.stderr.write("Target: Vg = %g V   Id = %g mA\n"%(vg,ids*1000.0))
            ret = vg
        except Exception, e:
            sys.stderr.write(traceback.format_exc()+"\n")
            sys.stderr.write("Operation failed with fatal exception ...\n")
    else:
        raise ValueError("invalid 'mode'")
    
    # close instruments
    for i in ilist:
        i.close()
    
    return ret

def setup_scope_cursors(low_supply, high_supply, pulser):
    "setup a test condition so that scope cursors can be placed"
    
    config = PIV_Config()

    pulser.disable()
    timed_wait_ms(200)
    high_supply.setVoltage(config['drain_q'])
    high_supply.setState(1)
    low_supply.setVoltage(config['drain_start'])
    low_supply.setState(1)
    timed_wait_ms(200)
    
    pulser.setGate(config['gate_start'],config['gate_q'])
    pulser.setDrain(config['drain_start'],config['drain_q'])
    pulser.setPulse(config['pulse_width'],config['pulse_period'])
    
    print("\nSet the cursors to the correct position on the pulse\n")
    try:
        raw_input('Press RETURN to continue')
    except KeyboardInterrupt:
        pass
    
    pulser.disable()
    timed_wait_ms(200)
    high_supply.setState(0)
    low_supply.setState(0)
    
    
def _create_sweep( start, stop, step, fine_step=None, transition=None ):
    "create a sweep list from start/stop/step data"
    rev = False
    if stop < start:
        rev = True
        start, stop = stop, start
    step = abs(step)
    
    ret = []
    if isinstance(fine_step,float) and isinstance(transition,float) and transition > start:
        # use the transition point
        fine_step = abs(fine_step)
        x = start
        while x < (transition+0.01*fine_step):
            ret.append(x)
            x += fine_step
        # remove the last fine step and add the course step
        x += step - fine_step
        while x < (stop+0.01*step):
            ret.append(x)
            x += step
    else:
        # no transition point
        x = start
        while x < (stop+0.01*step):
            ret.append(x)
            x += step
    
    # add the stop point if the last point of the sweep is more than
    # 30% of the step value away from it
    if ret[-1] < stop-0.3*step:
        ret.append(stop)
    
    if rev:
        return reversed(ret)
    else:
        return ret
    
def _get_power_limit(cfg, vdsval):
    "determine the applicable power limit and apply it"
    plimits = {}
    for v, l in {'plimit_vds_region1':'plimit_region1', 'plimit_vds_region2':'plimit_region2',
        'plimit_vds_region3':'plimit_region3', 'plimit_vds_region4':'plimit_region4'}.iteritems():
        vd, lim = cfg[v], cfg[l]
        if vd > 0.0 and lim > 0.0:
            plimits[vd] = lim
    
    if len(plimits):
        llst = plimits.keys()
        llst.sort()
        
        lim = -1.0
        for vd in llst:
            if vdsval <= vd:
                lim = plimits[vd]
                break
    
        if lim < 0.0:
            lim = plimits[llst[-1]]
        
        return lim
    else:
        # default power limit, when none are set
        return 1000.0

def target_qpoint(cur_target, low_supply, high_supply, pulser, o_scope):
    "run a targeting routine to get a gate voltage for the Q-point"
    
    def measure_q():
        "measure q-point"
        # get scope waveform
        o_scope.trigger()
        timed_wait_ms(50)
        return o_scope.measure(3,True)[1]
            
    cfg = PIV_Config()
    mn, mx = cfg['gate_q_min'], cfg['gate_q_max']
    vg, vdq, vgp = cfg['gate_q'], cfg['drain_q'], cfg['gate_cal_pulsed_v']
    ilimit = cfg['drain_ilimit']
    offs = cfg['vgs_vds_offset']
    
    # timings for std operation
    std_timings = [-offs,-offs,0.3,0.0]

    if mn >= mx:
        raise ValueError("'gate_q_min' and 'gate_q_max' configuration variables are inconsistent")
    
    # target acceptable error, use 2%
    target_err = cur_target*0.02
    if target_err < 0.001:
        target_err = 0.001
        
    # set up the pulser condition and DC supplies
    high_supply.setCurrent(ilimit)
    low_supply.setCurrent(ilimit)
    high_supply.setVoltage(vdq)
    low_supply.setVoltage(0.0)
    pulser.setTiming(*std_timings)
    high_supply.setState(1) 
    low_supply.setState(1)
    timed_wait_ms(200)
    pulser.setGate(vgp,vg)
    pulser.setDrain(0.0,vdq)
    pulser.setPulse(cfg['pulse_width'],cfg['pulse_period'])
    timed_wait_ms(1000)
    
    # measure the initial current
    idm = measure_q()
    
    # set initial step
    step = (mx - mn)*0.1
    if idm > cur_target:
        step = -step
    
    n = 0
    while n < 20:    
        # check for limits
        if step > 0.0 and vg == mx:
            sys.stderr.write("WARNING: hit upper limit during Q-point current targeting\n")
            break
        elif step < 0.0 and vg == mn:
            sys.stderr.write("WARNING: hit lower limit during Q-point current targeting\n")
            break
        
        # change vg and re-measure
        vg += step
        if vg < mn:
            vg = mn
        elif vg > mx:
            vg = mx        
        pulser.setGate(vgp,vg)
        timed_wait_ms(100)
        
        # measure the new current
        idm = measure_q()
        
        # see if we hit the target
        if abs(idm-cur_target) <= target_err:
            break
            
        # if we overshoot target then reverse the step and cut it by a factor of 4
        if idm > cur_target and step > 0.0:
            step *= -0.25        
        elif idm < cur_target and step < 0.0:
            step *= -0.25
                
        n += 1
    
    # reset the pulser and supplies
    high_supply.setState(0)
    low_supply.setState(0)
    pulser.disable()
    
    return vg, idm
        
        
def run_test_inner(fp, fpplot, low_supply, high_supply, pulser, o_scope, vgq_override=None, pna=None):
    "inner implementation of the test routine for proper error handling and cleanup"
    
    cfg = PIV_Config()
    
    offs = cfg['vgs_vds_offset']
    ilimit = cfg['drain_ilimit']
    vd_slew_rate = cfg['vd_slew_rate']

    check_qpoint_shift = cfg['check_qpoint_shift']
    qpoint_shift_fraction = cfg['qpoint_shift_fraction']
    
    # timings for std and swapped operation
    std_timings = [-offs,-offs,0.3,0.0]
    swapped_timings = [offs,offs,0.3,0.0]
    if cfg['dont_swap_timing']:
        swapped_timings = std_timings[:]
    
    # need to add this to the scope driver
    scope_ydivs = 8.0
    avail_scope_fs_iranges = [0.16,0.24,0.32,0.4,0.64,0.8,1.0,1.6,2.4,3.2,4.0,6.4,8.0,10.0,12.0]

    # determine which ranges are viable given our current limit
    use_fs_iranges = []
    for x in avail_scope_fs_iranges:
        if 0.9*x <= ilimit:
            use_fs_iranges.append(x)
    if not len(use_fs_iranges):
        use_fs_iranges.append(avail_scope_fs_iranges[0])
    
    # scope ranges to use for measuring drain current
    # this code produces a list of 3-tuples, where the contents of each
    # 3-tuple are (`range_high`, `scale_value`, `offset_value`)
    # `range_high` is the current at which the scale setting should be increased
    #    this is defined as 85% of the full-scale range
    # `scale_value` is the value of the Y-axis per-division scale for this range
    # `offset_value` is the value of the Y-axis offset for this range
    scope_iranges = [(r*0.85, r/scope_ydivs, r*0.45) for r in use_fs_iranges]

    ### generate sweep lists
    
    if cfg['gate_sweep_list'] is None:
        vgs_set = _create_sweep(cfg['gate_start'],cfg['gate_stop'],cfg['gate_step'])
    else:
        # use the specified vgs values, removing duplicates
        vgs_set = list(set(cfg['gate_sweep_list']))
    
    if cfg['drain_sweep_list'] is None:
        vds_set = _create_sweep(cfg['drain_start'],cfg['drain_stop'],cfg['drain_step_coarse'],cfg['drain_step_fine'],cfg['drain_step_transition'])
    else:
        # use the specified vds values, removing duplicates
        vds_set = list(set(cfg['drain_sweep_list']))
    
    # sort vgs and vds step in increasing order
    vgs_set.sort()
    vds_set.sort()
    
    # store q-point in convenient variables
    vdq, vgq = cfg['drain_q'], cfg['gate_q']
    if vgq_override is not None:
        vgq = vgq_override
    
    # set up the initial state of the 'swapped' variable
    swapped = False
    if vds_set[0] > vdq:
        swapped = True
    
    
    vgslist = list(vgs_set)
    vgslist.append(vgq)
    vgmax = max(vgslist)
    vgmin = min(vgslist)
    vgoffset = (vgmax + vgmin) / 2.0
    vgscale = (vgmax - vgmin)/scope_ydivs
    
    o_scope.setYScale(1,vgscale * 1.2)
    o_scope.setYOffset(1,vgoffset)
    
    vdslist = list(vds_set)
    vdslist.append(vdq)
    vdmax = max(vdslist)
    vdmin = min(vdslist)
    vdoffset = (vdmax + vdmin) / 2.0
    vdscale = (vdmax - vdmin)/scope_ydivs
    
    o_scope.setYScale(2,vdscale * 1.2)
    o_scope.setYOffset(2,vdoffset)
    
    # determine the largest offset between vdq and the vd sweep values
    #vddiff = abs(vdq - vds_set[0])
    #if vddiff < abs(vds_set[0] - vds_set[-1]):
    #    vddiff = abs(vds_set[0] - vds_set[-1])
    
    # compute fullscale and per-division scales for Vds on the scope
    #vd_fullscale = math.ceil(vddiff*1.2)
    #if abs(math.fmod(vd_fullscale,2.0)) > 0.1:
        # full scale came out odd, adjust it so that the scope range isn't funny
    #    vd_fullscale += 1.0
    #vd_scale = vd_fullscale / scope_ydivs

    # set the Vds range and offset on the scope
    #o_scope.setYScale(2,vd_scale)
    #if swapped:
    #    o_scope.setYOffset(2,vdq+0.4*vd_fullscale)
    #else:
    #    o_scope.setYOffset(2,0.4*vd_fullscale)
           
    ### measure scope offsets    
    print('performing O-Scope offset calibration ...')

    # set drain current limits
    high_supply.setCurrent(ilimit)
    low_supply.setCurrent(ilimit)
    
    # disable pulser to start
    pulser.disable()
    timed_wait_ms(200)
    
    # measure vg_offset with pulser disabled
    o_scope.trigger()
    timed_wait_ms(50)
    vg_offset = o_scope.measure(1)
    
    # set up drain supplies and pulser for calibration condition
    high_supply.setVoltage(vdq)
    low_supply.setVoltage(0.0)
    pulser.setTiming(*std_timings)
    high_supply.setState(1) 
    low_supply.setState(1)
    timed_wait_ms(200)
    pulser.setGate(cfg['gate_cal_pulsed_v'],vgq)
    pulser.setDrain(0.0,vdq)
    pulser.setPulse(cfg['pulse_width'],cfg['pulse_period'])
    timed_wait_ms(1000)
    
    # measure calibration offsets
    irange_offsets = []
    iscal = cfg['drain_iscale']
    for i,(ru,sc,of) in enumerate(scope_iranges):
        o_scope.setYScale(3,sc)
        o_scope.setYOffset(3,of)
        o_scope.trigger()
        timed_wait_ms(50)
        if i == 0:
            # measure the drain voltage on the scope and subtract
            # out the measured voltage from the low-side supply
            vd_offset = o_scope.measure(2) - low_supply.readVoltage()
        irange_offsets.append(o_scope.measure(3))
        
    # reset the Ids range and offset on the scope
    # to the minimum range
    o_scope.setYScale(3,scope_iranges[0][1])
    o_scope.setYOffset(3,scope_iranges[0][2])
    curr_irange = 0
    
    # set the high drain supply to 0 (device safety)
    high_supply.setVoltage(0.0)
    timed_wait_ms(50)
    
    print('starting measurement ...')

    if pna:
        # initialize the PNA
        pna_init(pna)
    
    # set up drain supplies and pulser timings depending on swap state
    if swapped:
        low_supply.setVoltage(vdq)
        high_supply.setVoltage(vds_set[0])
        pulser.setTiming(*swapped_timings)
    else:
        high_supply.setVoltage(vdq)
        low_supply.setVoltage(vds_set[0])
        pulser.setTiming(*std_timings)
    timed_wait_ms(200)
    
    # setup pulse and enable pulser
    pulser.setGate(vgs_set[0],vgq)
    pulser.setDrain(vds_set[0],vdq)
    
    # measure initial q-point
    timed_wait_ms(200)
    o_scope.trigger()
    timed_wait_ms(50)
    vgq_meas = o_scope.measure(1,True)[1] - vg_offset
    vdq_meas = o_scope.measure(2,True)[1] - vd_offset
    idq_meas_init = (o_scope.measure(3,True)[1] - irange_offsets[curr_irange])*iscal
    
    # set headers in data file and plot file
    tstamp = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
    fp.write('! Pulsed I-V Test\n!\n')
    fp.write('! TestDate: %s\n'%tstamp)
    fp.write('! Q-Point:\n')
    fp.write('!    Vg = %g V (meas: %g V)\n'%(vgq,vgq_meas))
    fp.write('!    Vd = %g V (meas: %g V)\n'%(vdq,vdq_meas))
    fp.write('!    Id = %g A\n'%idq_meas_init)
    fp.write('! Drain Max Voltage = %g V\n'%vds_set[-1])
    fp.write('! O-Scope Offsets:\n!    Vg = %g V\n!    Vd = %g V\n'%(vg_offset,vd_offset))
    for i,x in enumerate(irange_offsets):
        fp.write('!    Id[%.3f] = %g A\n'%(avail_scope_fs_iranges[i],x))
    fp.write('!\n!-----------------------------------------------------------------------------\n')
    if not pna:
        fp.write('!Vg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_raw[A]\tId_corr[A]\n')
    
    fpplot.write('! TestDate: %s\n'%tstamp)
    fpplot.write('!\n!Vg[V]\tVd[V]\tVg_m[V]\tVd_m[V]\tId_m[A]\tId_m(corr)[A]\n')    
    
    ##################################
    ### start the measurement loop ###
    ##################################
    
    last_vd = vds_set[0]
    for i,vgset in enumerate(vgs_set):
        print('Vgs = %g (%d of %d)'%(vgset,i+1,len(vgs_set)))
        first = True
    
        for vdset in vds_set:
            # determine power limit
            plimit = _get_power_limit(cfg,vdset)
            
            if vdset <= cfg['drain_q']:
                ### non-swapped state ###
                 
                if swapped:
                    # transisitioning from other region, need to be careful
                    # set the voltages on the supplies to be equal
                    high_supply.setVoltage(vdq)
                    timed_wait_ms(100)
                    # modify pulser timings
                    pulser.setTiming(*std_timings)
                    timed_wait_ms(100)
                    swapped = False
                    
                    # reset scope offset for Vd
                    #o_scope.setYOffset(2,0.4*vd_fullscale)
                    
                # change the low drain supply value
                low_supply.setVoltage(vdset)
                    
            else:
                ### swapped state ###
                
                if not swapped:
                    # transisitioning from other region, need to be careful
                    # set the voltages on the supplies to be equal
                    low_supply.setVoltage(vdq)
                    timed_wait_ms(100)
                    # modify pulser timings
                    pulser.setTiming(*swapped_timings)
                    timed_wait_ms(100)
                    swapped = True
                    
                    # reset scope offset for Vd
                    #o_scope.setYOffset(2,vdq+0.4*vd_fullscale)
                    
                # change the high drain supply value
                high_supply.setVoltage(vdset)
            
            # set pulser
            if first:
                pulser.setGate(vgset,vgq)
                first = False
            pulser.setDrain(vdset,vdq)

            # allow the system to settle
            vd_delta = abs(last_vd - vdset)
            timed_wait_ms(200+vd_delta*1000/vd_slew_rate)
            last_vd = vdset

            # measure sweep and correct offsets
            o_scope.trigger()
            timed_wait_ms(50)
            vgmeas = o_scope.measure(1) - vg_offset
            vdmeas = o_scope.measure(2) - vd_offset
            
            # set the oscope current range
            # and measure the current
            idmeas, idq_meas = o_scope.measure(3,True)
            if curr_irange > 0 and idmeas < scope_iranges[curr_irange-1][0]*0.9:
                # need to go to a lower range, find the lowest range in which the
                # measured value of current is less than the upper end of its
                # measurement window for greatest accuracy of low current values
                for i,(ru,sc,of) in enumerate(scope_iranges):
                    if idmeas < ru:
                        curr_irange = i
                        o_scope.setYScale(3,sc)
                        o_scope.setYOffset(3,of)
                        o_scope.trigger()
                        timed_wait_ms(50)
                        idmeas, idq_meas = o_scope.measure(3,True)
                        break
            elif idmeas > scope_iranges[curr_irange][0]:
                # need to go to a higher range, try to go up 1 range at a time
                while curr_irange < len(scope_iranges)-1:
                    curr_irange += 1                    
                    o_scope.setYScale(3,scope_iranges[curr_irange][1])
                    o_scope.setYOffset(3,scope_iranges[curr_irange][2])
                    o_scope.trigger()
                    timed_wait_ms(50)
                    idmeas, idq_meas = o_scope.measure(3,True)
                    if idmeas <= scope_iranges[curr_irange][0]:
                        break
            
            id_corrected = (idmeas - irange_offsets[curr_irange])*iscal
            
            # check power limit
            if id_corrected*vdmeas > plimit:
                break
            
            # check Q-point shifts
            
            if check_qpoint_shift and abs(idq_meas-idq_meas_init) > qpoint_shift_fraction*abs(idq_meas_init):
                # uh-oh, device either shifted a lot or blew up
                pulser.disable()
                timed_wait_ms(200)
                low_supply.setVoltage(vds_set[0])
                high_supply.setVoltage(vdq)
                raise ValueError("Q-point shifted - possible dead device (initial: %.1f mA, current: %.1f mA"%(idq_meas_init*1000.0,idq_meas*1000.0))

            if pna:
                fp.write('!       Vg[V]\tVd[V]\tVg_meas[V]\tVd_meas[V]\tId_raw[A]\tId_corr[A]\n')            
                fp.write('!PULSE: %.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(vgset,vdset,vgmeas,vdmeas,idmeas,id_corrected))                
            else:
                fp.write('%.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(vgset,vdset,vgmeas,vdmeas,idmeas,id_corrected))
            fpplot.write('%.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(vgset,vdset,vgmeas,vdmeas,idmeas,id_corrected))
            fp.flush()
            fpplot.flush()
            
            # measure pulsed S-parameters if requested
            if pna:
                measure_pulsed_spars(pna, fp)
            
            
        
        
        
        fp.write('\n')
        fpplot.write('\n')
        
    # step drain voltage down from set point
    vdoff = 0.5 # voltage to step to/past before shutting off
    vdscale = 0.9 # amount to step drain voltage down by (as a fraction of current voltage)
    vdstep = vdq
    while vdstep > vdoff:
       vdstep = vdscale*vdstep
       if vdstep < vdoff:
            break
       print ('\nSetting drain to ' + ('%3.2f' % vdstep))
       high_supply.setVoltage(float('%3.2f' % vdstep))
       low_supply.setVoltage(float('%3.2f' % vdstep))
       timed_wait_ms(500)
        
    # step gate voltage down from set point
    vgoff = -2.0 # voltage to step to/past before shutting off
    vgstep = vgq
    while vgstep > vgoff:
       if vgstep < vgoff:
            break
       vgstep -= 0.25
       print ('\nSetting gate to ' + ('%3.2f' % vgstep))
       pulser.setGate(float('%3.2f' % vgstep),float('%3.2f' % vgstep))
       timed_wait_ms(500)
        
    # turn off the pulser and setting the supplies to default values
    # print ('\nSetting gate to q-point of ' + ('%3.2f' % vgq))
    # pulser.setGate(vgq,vgq)
    # timed_wait_ms(500)
    
    # print ('\nSetting drain to q-point of ' + ('%3.2f' % vdq))
    # high_supply.setVoltage(vdq)
    # low_supply.setVoltage(vdq)
    # timed_wait_ms(500)
    
    pulser.disable()
        
    print('PIV Done')
    print
               
def main(fname=None,cfg=None,**kwargs):
    "entry point"
    if cfg is not None:
        if isinstance(cfg,str):
            cfgfile = cfg
    else:
        cfgfile = 'piv_config.cfg'
    
    if fname is None:
        vgq = None
        # open an interactive menu to select the mode of operation
        while True:
            print
            print(' r : run the test')
            print(' c : configure the O-Scope cursors')
            print(' s : set the Q-point')
            print(' f : forget the current Q-point (use the value from the file)')
            print
            print(' q : quit')
            print
            while True:
                try:
                    r = raw_input('Selection? ').lower().strip()
                    if r not in ('r','c','s','f','q'):
                        raise ValueError()
                    break
                except ValueError:
                    print(' *** invalid selection ***') 
                except KeyboardInterrupt:
                    r = 'q'
                    break
            
            mode = 'test'
            if r == 'q':
                sys.exit(0)
            elif r == 'c':
                mode = 'cursors'
            elif r == 's':
                mode = 'qpoint'
            elif r == 'r':
                pass
            elif r == 'f':
                vgq = None
                print ' *** Q-point target forgotten ***' 
                continue
            
            # run main routine
            try:
                if mode == 'qpoint':
                    new_q = run_test(None,cfgfile,mode)
                    if new_q is not None:
                        vgq = new_q
                else:
                    run_test(None,cfgfile,mode,vgq=vgq)
            except Exception:
                sys.stderr.write(traceback.format_exc()+'\n')
                sys.stderr.write('Exited with a fatal exception ...\n')
    else:
        # run main routine
        run_test(fname,cfgfile,'test')

def pna_init(pna, chan=1):
    "initializing routine for the PNA"    
    # initial setup
    pna.write('*SRE 0;TRIG:SEQ:SCOP ALL;SOUR IMM;:INIT:CONT 1')
    # put sweep in hold
    pna.write('SENS%d:SWE:MODE HOLD'%chan)
    
    # get the measurement catalog
    catalog = pna.ask('CALC%d:PAR:CAT?'%chan)
    # create measurements as needed
    for p in ('S11','S12','S21','S22'):
        measdef = "pysparams_ch%d_%s"%(chan,p)
        if catalog.find(measdef) == -1:
            pna.write("CALC%d:PAR:DEF '%s',%s" % (chan,measdef,p))
        
def measure_pulsed_spars(pna, fp, chan=1):
    "extra routine to measure pulsed S-params"
        
    # detect averaging state
    count = 1
    avg = int(pna.ask('SENS%d:AVER:STAT?'%chan))
    if avg:
        count = int(pna.ask('SENS%d:AVER:COUN?'%chan))
        
    # force the PNA to do a set of measurements to force it
    # to adjust IF gain/filter parameters
    # num_measurements_to_force = 1
    # pna.write('SENS%d:AVER OFF'%chan)
    # pna.write('SENS%d:SWE:GRO:COUN %d' % (chan,num_measurements_to_force))
    # pna.write('SENS%d:SWE:MODE GRO;*ESE 1;*OPC' % chan)
    # while 1:    
        # esr = int(pna.ask('*ESR?'))
        # if esr:
            # break
        # timed_wait_ms(20)
    
    if avg:
        # re-enable and restart averaging
        pna.write('SENS%d:AVER OFF'%chan)
        pna.write('SENS%d:AVER ON'%chan)
        #pna.write('SENS%d:AVER:CLE'%chan)
        
    # set the group count to be equal to the averaging
    # and trigger the real measurement group
    pna.write('SENS%d:SWE:GRO:COUN %d' % (chan,count))
    pna.write('SENS%d:SWE:MODE GRO;*ESE 1;*OPC' % chan)
    
    # wait for the measurement to finish
    while 1:    
        esr = int(pna.ask('*ESR?'))
        if esr:
            break
        timed_wait_ms(20)
    
    # get the frequency list
    freq = pna.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:SENS%d:X:VAL?' % chan)
    n = len(freq)
    
    # get the S-parameters
    sp = []
    for p in ('S11','S12','S21','S22'):
        
        pna.write("CALC%d:PAR:SEL 'pysparams_ch%d_%s'" % (chan,chan,p))
        r = pna.ask_for_values('FORM:DATA REAL,64;BORD SWAP;:CALC%d:DATA? SDATA' % chan)
        # combine the interlaced real/imag pairs into complex numbers
        if len(r) != n*2:
            raise Exception("The length of data returned from measurement '%s' does not match the frequency list length (%d <--> %d)." % (p,n,len(r)))
        r2 = []
        for i in range(n):
            cnum = complex(r[2*i],r[2*i+1])
            r2.append(cnum)
        sp.append(r2)
        
    def maconv( s ):
        "convert a complex number to a 2-tuple of (magnitude,angle)"
        return abs(s),math.atan2(s.imag,s.real)*180.0/math.pi
    
    # write the result to the file
    fp.write('# S HZ MA R 50\n')
    fp.write('!Freq\tS11-mag\tS11-ang\tS21-mag\tS21-ang\tS12-mag\tS12-ang\tS22-mag\tS22-ang\n')
    for i in range(n):
        data = [freq[i]]
        data.extend(maconv(sp[0][i]))
        data.extend(maconv(sp[2][i]))
        data.extend(maconv(sp[1][i]))
        data.extend(maconv(sp[3][i]))
        fp.write('%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\t%.5e\n'%tuple(data))
        
    fp.flush()
    
    
    
    