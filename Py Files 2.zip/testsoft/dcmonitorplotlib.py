from __future__ import division, print_function, unicode_literals, absolute_import
# import stuff that is needed from matplotlib

import wx
from matplotlib import dates, ticker
from matplotlib.figure import Figure
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg
import numpy as np
from datetime import datetime, timedelta


import os, os.path, sys, traceback, re
from matplotlib.dates import date2num

def update_data_from_file(fname):
	"read data from file"
	
	# Sample lines  from .dat file below
	# Timestamp	Igate	Idrain
	# 2015/07/13 11:25:52	-4.11959e-07	0.0603194
	# date <space> time <tab> ig <tab> id
	
	fp = open(fname,'r')
	try:
		lines = fp.readlines()
		time, igate, idrain = [], [], []
		for line in lines:
			if line == lines[0]:
				if line == "Timestamp\tIgate\tIdrain\n":
					continue
				else:
					sys.stderr.write("Invalid dcmonitor data file!")
					return
			
			try:
				tokens = re.split('\t', line)
				time.append(tokens[0])				 #get timestamp (without date)
				igate.append(float(tokens[1]))	  #get gate current
				idrain.append(float(tokens[2]))	 #get drain current
				
			except Exception:
				pass
			
	finally:
		fp.close()
	return time, igate, idrain

class DCMonitorPlotFigure(Figure):
	"Plot figure for plotting PIV data"
	
	def __init__(self,*args,**kwargs):
		"initializer"
		# strip keywords specific to this figure
		
		# init parent
		super(DCMonitorPlotFigure,self).__init__(*args,**kwargs)
		
		self.gate_axes = self.add_axes([0.1,0.1,0.8,0.3])
		self.drain_axes = self.add_axes([0.1,0.6,0.8,0.3])
	
	def abs_to_elapsed(self, timeList):
		"process times into elapsed time (in seconds)"
		tl = []
		for t in timeList:
			td = datetime.strptime(t, '%Y/%m/%d %H:%M:%S') - datetime.strptime(timeList[0], '%Y/%m/%d %H:%M:%S')
			tl.append(td.days * 1440 + td.seconds // 60)
		return tl
		
	def plot_data(self, time, gate, drain):
		"plot the data on the axes"
		
		# check argument
		if not isinstance(gate,list) and isinstance(drain,list):
			raise TypeError("'data' must be a list")				
		
		linewidth = 2
		showlegend = True
		
		# reset the plot
		self.resetPlot()
		
		# convert time list to elapsed time (in seconds)
		times = self.abs_to_elapsed(time)
		
		# set/rotate x-axis labels
		self.gate_axes.set_xticklabels(times, rotation='30')
		self.drain_axes.set_xticklabels(times, rotation='30')
		
		# set x-axes to plot time elapsed based on timeTicks formatter
		def timeTicks(x, pos):
			d = timedelta(seconds=x)
			return '{}'.format(d)
		
		timeformatter = ticker.FuncFormatter(timeTicks)
		self.gate_axes.get_xaxis().set_major_formatter(timeformatter)
		self.drain_axes.get_xaxis().set_major_formatter(timeformatter)
		
		# plot data
		self.gate_axes.plot(times, gate)
		self.drain_axes.plot(times, drain)
		
		# set graphs to use scientific notation on y-axis
		self.gate_axes.ticklabel_format(style='sci', scilimits=(0,0), axis='y')
		self.drain_axes.ticklabel_format(style='sci', scilimits=(0,0), axis='y')
		
		
	def resetPlot(self):
		"reset the plot"
		# clear the axes
		self.gate_axes.cla()
		self.drain_axes.cla()
		
		# set the axis labels
		self.gate_axes.set_xlabel('Time')
		self.gate_axes.set_ylabel('Ig (A)')
		self.gate_axes.set_title('Igate vs Time')
		self.drain_axes.set_xlabel('Time')
		self.drain_axes.set_ylabel('Id (A)')
		self.drain_axes.set_title('Idrain vs Time')
		
class WxDCMonitorPlotPanel(wx.Panel):
	"""Plot panel for displaying plots"""
	def __init__( self, parent, **kwargs ):
		"initializer"
		
		# set the last update time for the plot
		self._lastupdate = None
		self._liveplotfile = 'dcmonitor.dat'

		# initialize Panel
		if 'id' not in kwargs.keys():
			kwargs['id'] = wx.ID_ANY
		if 'style' not in kwargs.keys():
			kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS
		else:
			kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS 
		super(WxDCMonitorPlotPanel,self).__init__(parent,**kwargs)
		self.parent = parent
		
		# initialize matplotlib stuff
		self.figure = DCMonitorPlotFigure()
		canvas = FigureCanvasWxAgg(self, -1, self.figure)
		canvas.SetFocus()
		#self.SetColor(color)

		self._SetSize()

		self._resizeflag = False

		self.Bind(wx.EVT_IDLE, self._onIdle)
		self.Bind(wx.EVT_SIZE, self._onSize)
		
		# do an initial plot update
		self._check_replot(None)
		
		# start a timer to check for plot data file updates
		self.timer = wx.Timer(self)
		self.Bind(wx.EVT_TIMER, self._check_replot, self.timer)
		self.timer.Start(2000)
	
	def set_plot_file(self, fname):
		"set the plot up for static plotting"
		self.set_live_mode(False)
		self.update_plot(fname)
	
	def set_live_mode(self, live, newfile):
		"set live mode plotting"
		if live:
			if newfile:
				self.parent.load_live_file(self.parent)
			self._check_replot(None)
			self.timer.Start(2000)
		else:
			self.timer.Stop()
			self._lastupdate = None
			self.figure.resetPlot()
			self.figure.canvas.draw()			
		
	def _onSize( self, event ):
		"event method for resize"
		self._resizeflag = True

	def _onIdle( self, evt ):
		"event method for idle events"
		if self._resizeflag:
			self._resizeflag = False
			self._SetSize()
		
	def _SetSize( self ):
		"resize the figure image" 
		pixels = self.parent.GetClientSizeTuple() # (width, height)
		self.SetSize(pixels)
		self.figure.canvas.SetSize(pixels)
		self.figure.set_size_inches( float( pixels[0] )/self.figure.get_dpi(),
									 float( pixels[1] )/self.figure.get_dpi() )
			
	def _SetColor( self, rgbtuple=None ):
		"Set figure and canvas colours to be the same."
		if rgbtuple is None:
			rgbtuple = wx.SystemSettings.GetColour( wx.SYS_COLOUR_BTNFACE ).Get()
		clr = [c/255. for c in rgbtuple]
		self.figure.set_facecolor( clr )
		self.figure.set_edgecolor( clr )
		self.canvas.SetBackgroundColour( wx.Colour( *rgbtuple ) )
	
	def _check_replot( self, event ):
		"check if there is any new data to plot"
		try:
			sz = os.stat(self._liveplotfile).st_size
		except Exception:
			return
					
		if self._lastupdate is None or self._lastupdate != sz:
			# plot needs to be updated
			# read the PIV plot file
			self._lastupdate = sz
			self.update_plot(self._liveplotfile)
	
	def update_plot(self, fname):
		"update the plot window"
		try:
			time, gdata, ddata = update_data_from_file(fname)
		except Exception as e:
			sys.stderr.write(traceback.format_exc()+'\n')
			self.parent.error_msg("plot update failed for '%s'"%fname)
			return
		
		# plot the data
		if len(gdata) and len(ddata):
			self.figure.plot_data(time, gdata, ddata)
			self.figure.canvas.draw()
					  
class WxDCMonitorPlotFrame(wx.Frame):
	"""Main frame for holding the WxDCMonitorPlotPanel"""	
	
	def __init__( self, parent=None, *args, **kwargs ):
		"initializer"
	
		title = kwargs.pop('title','DC Monitor Plot')
		
		#if 'style' not in kwargs:
		#	kwargs['style'] = wx.DEFAULT_FRAME_STYLE | wx.WANTS_CHARS
		#else:
		#	kwargs['style'] |= wx.WANTS_CHARS

		# init the parent
		super(WxDCMonitorPlotFrame,self).__init__(parent,*args,**kwargs)
		
		self.SetTitle(title)
		
		# create a status bar
		self.statusbar = self.CreateStatusBar()
		
		# create a menu bar
		menubar = wx.MenuBar()

		filemenu = wx.Menu()
		omi = wx.MenuItem(filemenu, wx.ID_ANY, '&Open .dat File\tCtrl+O')
		filemenu.AppendItem(omi)
		lmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Live Mode\tCtrl+L')
		filemenu.AppendItem(lmi)
		smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
		filemenu.AppendItem(smi)
		filemenu.AppendSeparator()
		qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
		filemenu.AppendItem(qmi)

		self.Bind(wx.EVT_MENU,self.open_plotfile,omi)
		self.Bind(wx.EVT_MENU,self.live_mode,lmi)
		self.Bind(wx.EVT_MENU,self.save_figure,smi)
		self.Bind(wx.EVT_MENU,self.OnQuit,qmi)

		menubar.Append(filemenu, '&File')
		self.SetMenuBar(menubar)
		
		# create the panel that holds the matplotlib Figure
		self.panel = WxDCMonitorPlotPanel(self)
		
		# draw the canvas for the first time
		self.panel.figure.canvas.draw()
		
		# show this Window
		#self.SetSize((350, 250))
		self.Centre()
		self.Show(True)
					
	def OnQuit(self, e=None):
		"capture quit commands"
		self.Close()
	
	def open_plotfile(self, e=None):
		"set the plot utility to open a static file"
		dlg = wx.FileDialog(self, "Open file", "", "", "All files (*.*)|*.*", wx.OPEN)
		if dlg.ShowModal() == wx.ID_OK:
			path = dlg.GetPath()
			filename = dlg.GetFilename()
			self.panel.set_plot_file(path)
			self.SetTitle(("DC Monitor Plot - %s (Static)" % filename))
		
	def live_mode(self, e=None):
		"set the plot utility into live mode"
		self.panel.set_live_mode(True, True)		
		
	def live_mode_initial(self):
		"set the plot utility into live mode without choosing a new file"
		self.panel.set_live_mode(True, False)
		
	def set_live_file_path(self, path, filename):
		self.panel._liveplotfile = path
		self.SetTitle(("DC Monitor Plot - %s (Live Updating)" % filename))
		
	def load_live_file(self, e=None):
		"""Menu entry callback to choose a file to live-update from."""
		dlg = wx.FileDialog(self, "Choose file", "", "dcstress.dat",
							"*.dat",
							wx.OPEN)
		if dlg.ShowModal() == wx.ID_OK:
			path = dlg.GetPath()
			filename = dlg.GetFilename()
			self.set_live_file_path(path, filename)
			
			
	def save_figure(self,e=None):
		"""Menu entry callback to save the current figure."""
		filetypes, exts, filter_index = self.panel.figure.canvas._get_imagesave_wildcards()
		default_file = "image." + self.panel.figure.canvas.get_default_filetype()
		dlg = wx.FileDialog(self, "Save to file", "", default_file,
							filetypes,
							wx.SAVE|wx.OVERWRITE_PROMPT)
		dlg.SetFilterIndex(filter_index)
		if dlg.ShowModal() == wx.ID_OK:
			dirname  = dlg.GetDirectory()
			filename = dlg.GetFilename()
			format = exts[dlg.GetFilterIndex()]
			basename, ext = os.path.splitext(filename)
			if ext.startswith('.'):
				ext = ext[1:]
			if ext in ('svg', 'pdf', 'ps', 'eps', 'png') and format!=ext:
				#looks like they forgot to set the image type drop
				#down, going with the extension.
				#warnings.warn('extension %s did not match the selected image type %s; going with %s'%(ext, format, ext), stacklevel=0)
				format = ext
				
			try:
				fname = os.path.join(dirname,filename)
				self.panel.figure.canvas.print_figure(fname,format=format)
				self.status_msg("Saved file '%s'"%fname)
			except Exception as e:
				self.error_msg('{}'.format(e))
				
	def status_msg(self, msg):
		"print a status message to the status bar"
		self.statusbar.SetForegroundColour('black')
		self.statusbar.SetStatusText(msg)
		
	def error_msg(self, msg):
		"print an error message to the status bar"
		self.statusbar.SetForegroundColour('red')
		self.statusbar.SetStatusText(msg)
	