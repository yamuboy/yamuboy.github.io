import re as _re
from .utils import generate_label
import threading as _threading

_valid_name = _re.compile(r'[a-zA-Z][a-zA-Z0-9_.]*$')


class Param(object):
    """Abstract base class of all test parameter types.
    
    This type should not be instantiated directly, all parameters
    should be stored in a derived type
    
    """
    
    #def __new__(cls, *args, **kwargs):
    #    "new class customization"
        
    
    
    def __init__(self, type, name, **kwargs):
        "initializer"
        # make sure that this is not being instantiated directly
        if __builtins__['type'](self) is Param:
            raise ValueError("the 'Param' type is abstract and should not be instantiated")
                
        if not isinstance(type,basestring):
            raise TypeError("'type' must be a string")
        self.__ty = type
            
        if not isinstance(name,basestring):
            raise TypeError("'name' must be a string")
        if not _valid_name.match(name):
            raise ValueError("'%s' is not a valid parameter name"%name)
        self.__name = name
        
        self.__label = unicode(kwargs.pop('label',generate_label(self.__name)))
        self.__help_text = unicode(kwargs.pop('help_text',''))
        self.__validator = kwargs.pop('validator',None)
        if self.__validator is not None and not callable(self.__validator):
            raise TypeError("'validator' must be callable")
        
        style = kwargs.pop('style',{})
        if not isinstance(style,dict):
            raise TypeError("'style' must be a dictionary")
        self.__style = style
        self.__hidden = bool(kwargs.pop('hidden',False))
        
        
        # set the parameter value
        self._set_value(kwargs.pop('value',None))
        
        # init the default value
        self.__default_value = self.__value
        
        if len(kwargs):
            # extra keywords are left over, raise an error
            raise ValueError("unknown keywords: "+(', '.join([str(k) for k in kwargs.keys()])))
            
    def _get_value(self):
        "get the parameter value"
        return self.__value
        
    def _set_value(self, v):
        "set the parameter value"
        self.__value = self.validate(v)
        
    def _set_raw_value(self, v):
        "set the parameter value without validation"
        self.__value = v
    
    def _coerce_value(self, v):
        """coerce the value to the correct type for storage
        
        MUST BE DEFINED BY DERIVED TYPES!!!
        """
        raise NotImplemented()
        
    def validate(self, v):
        "run the validator for the parameter"
        if self.__validator:
            return self._coerce_value(self.__validator(self.__name,self._coerce_value(v)))
        return self._coerce_value(v)
    
    def reset(self):
        "reset the parameter to its default value"
        self.__value = self.__default_value
    
    def __get__(self):
        "parameter value"
        return self._get_value()
       
    def __set__(self,v):
        "set parameter value"
        return self._set_value(v)        
    
    value = property(_get_value,_set_value,None,'parameter value')
    
    @property
    def name(self):
        "parameter name"
        return self.__name
    
    @property
    def label(self):
        "human-readable label for the parameter"
        return self.__label
        
    @property
    def help_text(self):
        "help text"
        return self.__help_text
    
    @property
    def type(self):
        "parameter type, a string"
        return self.__ty
    
    @property
    def style(self):
        "parameter style options"
        return self.__style
        
    @property
    def hidden(self):
        "indicates that this is a hidden parameter group"
        return self.__hidden
        
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("Param('%s', value='%u')"%(self.name,unicode(self.value)))

    def __str__(self):
        "return a string representation of the parameter"
        return str(unicode(self))
    
        
class StringParam(Param):
    """Test parameter that stores its value as a unicode string.
    """
    
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'string'
        super(StringParam,self).__init__(**kwargs)
                
    def _coerce_value(self, v):
        "coerce the parameter value to the correct type"
        if v is None:
            return unicode('')
        return unicode(v)
    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("StringParam('%s', value='%s')"%(self.name,self.value))
        
           
class BooleanParam(Param):
    """Test parameter that stores its value as a boolean
    """
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'boolean'
        super(BooleanParam,self).__init__(**kwargs)    
    
    def _coerce_value(self, v):
        "coerce the parameter value to the correct type"
        return bool(v)
        
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("BooleanParam('%s', value=%s)"%(self.name,unicode(self.value)))
        
class FloatParam(Param):
    """Test parameter that stores its value as a floating point value
    """
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'float'
        super(FloatParam,self).__init__(**kwargs)
    
    def _coerce_value(self, v):
        "coerce the parameter value to the correct type"
        if v is None:
            return 0.0
        try:
            return float(v)
        except Exception:
            raise ValueError("not a float: '%s'"%unicode(v))

    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("FloatParam('%s', value=%g)"%(self.name,self.value))
            
class IntParam(FloatParam):
    """Test parameter that stores its value as an integer
    """
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'int'
        super(IntParam,self).__init__(**kwargs)    
    
    def _coerce_value(self, v):
        "coerce the parameter value to the correct type"
        if v is None:
            return 0
        try:
            return int(v)
        except Exception:
            raise ValueError("not an integer: '%s'"%unicode(v))
    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("IntParam('%s', value=%d)"%(self.name,self.value))
        
class ChoiceParam(Param):
    """Test parameter that stores its value as a
    one-of-many multiple choice
    """
    
    def __init__(self, **kwargs):
        "initializer"
        # pull out keywords that are specific to this parameter type
        choices = kwargs.pop('choices')
        if not isinstance(choices,(list,tuple)):
            raise TypeError("'choices' must be a tuple/list object")
        
        # verify and save the choices list
        cvals = []
        clst = []
        try:
            for lab,val in choices:
                if not isinstance(lab,basestring):
                    raise TypeError("choice labels must be string-like")
                clst.append( (unicode(lab),val) )
                cvals.append(val)
        except Exception, e:
            raise ValueError("error in 'choices' keyword: "+str(e))
        
        self._choice_list = clst
        self._choices = cvals
        # init the parent
        if 'type' not in kwargs:
            kwargs['type'] = 'choice'
        super(ChoiceParam,self).__init__(**kwargs)
    
    def _set_value(self, v):
        "override the default behavior for setting the value"
        v = self.validate(v)
        if v is None:
            self._set_raw_value(-1)
        else:
            self._set_raw_value(self._choices.index(v))
        
    def _get_value(self):
        "override the default behavior for getting the value"
        v = super(ChoiceParam,self)._get_value() 
        if v < 0:
            return None
        return self._choices[v]
        
    value = property(_get_value,_set_value,None,'parameter value')

    def _coerce_value(self, v):
        "check the choice label and map it to it's value"
        if v not in self._choices:
            raise ValueError("invalid choice => '%s'"%unicode(v))
        return v
        
    def _set_index(self, i):
        "set choice by index"
        if not isinstance(i,int):
            raise TypeError("index parameter must be an integer")
        if i < 0:
            i = -1
        elif i >= len(self._choices):
            raise IndexError("index out of range")
        self._set_raw_value(i)
    
    def _get_index(self):
        "get the index of the selected choice"
        return super(ChoiceParam,self)._get_value() 
            
    selected_index = property(_get_index,_set_index,None,"index of the current choice value")
    
    def get_byindex(self, i):
        "get the choice label by index"
        if not isinstance(i,int):
            raise TypeError("index parameter must be an integer")
        if i < 0 or i >= len(self._choices):
            return None
        return self._choices[i]

    @property
    def choice_list(self):
        "a list of 2-tuples of (label,value)"
        return self._choice_list[:]

    @property
    def choice_labels(self):
        "a list of choice labels"
        return [x for x,y in self._choice_list]
        
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("ChoiceParam('%s', value='%s')"%(self.name,self.value))
        
class FloatListParam(Param):
    """Test parameter that stores its value as a
    list of floating point values
    """
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'float_list'
        super(FloatListParam,self).__init__(**kwargs)
    
    def _coerce_value(self, v):
        "check the values in the list"
        if v is None:
            return []
        
        if not isinstance(v,(list,tuple)):
            raise TypeError("value must be a list/tuple object")
        
        return [float(x) for x in v]
    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("FloatListParam('%s', value=%s)"%(self.name,str(self.value)))
            
class IntegerListParam(FloatListParam):
    """Test parameter that stores its value as a
    list of integer values
    """
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'int_list'
        super(IntegerListParam,self).__init__(**kwargs)    
    
    def _coerce_value(self, v):
        "check the values in the list"
        if v is None:
            return []
        
        if not isinstance(v,(list,tuple)):
            raise TypeError("value must be a list/tuple object")
        
        return [int(x) for x in v]

    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("IntegerListParam('%s', value=%s)"%(self.name,str(self.value)))

class OrderedListParam(Param):
    """Test parameter that stores its value as a
    list of ordered string values
    
    The control for editing this parameter allows the parameter order to be changed
    but does not add or remove values
    """
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'ordered_list'
        super(OrderedListParam,self).__init__(**kwargs)
    
    def _coerce_value(self, v):
        "check the values in the list"
        if v is None:
            return []
        
        if not isinstance(v,(list,tuple)):
            raise TypeError("value must be a list/tuple object")
        
        return list(v[:])
    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("OrderedListParam('%s', value=%s)"%(self.name,str(self.value)))


class FileParam(StringParam):
    """Test parameter for storing file names"""
    
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'file'
        super(FileParam,self).__init__(**kwargs)
                    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("FileParam('%s', value='%s')"%(self.name,self.value))
        
class DirectoryParam(FileParam):
    """Test parameter for storing directory names"""
    
    def __init__(self, **kwargs):
        "initializer"
        if 'type' not in kwargs:
            kwargs['type'] = 'directory'
        super(DirectoryParam,self).__init__(**kwargs)
                    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        return unicode("DirectoryParam('%s', value='%s')"%(self.name,self.value))

        
class ParamGroup(object):
    """A group of parameters that should be displayed together
    in a common display box.
    
    """
    
    def __init__(self, label, *args, **kwargs):
        "initializer"
        
        if not isinstance(label,basestring): 
            raise TypeError("'label' must be a string")
        
        self.__label = unicode(label)
        self.__params = []
        self.__hidden = bool(kwargs.pop('hidden',False))
        self.add(*args)
        
        if len(kwargs):
            # extra keywords were passed
            raise ValueError("unknown keywords: "+(', '.join([str(k) for k in kwargs.keys()])))
        
        
    def add(self, *args):
        "add parameters to the group"
        
        for p in args:
            if not isinstance(p,Param):
                raise TypeError("positional arguments must be test parameter objects")
            self.__params.append(p)
                    
    @property
    def params(self):
        "child parameters"
        return self.__params[:]
    
    @property
    def label(self):
        "parameter group label"
        return self.__label
    
    @property
    def hidden(self):
        "indicates that this is a hidden parameter group"
        return self.__hidden
    
    def __len__(self):
        return len(self.__params)
    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        if not len(self.__params):
            return unicode("ParamGroup('%s')"%self.__label)
        d = [unicode(x) for x in self.__params]
        return ("ParamGroup('%s'\n    "%self.__label)+unicode('\n    ').join(d)+'\n)'
        
    def __str__(self):
        "return a string representation of the parameter"
        return str(unicode(self))
    

       
class ParamPage(object):
    """A group of parameters that should be displayed together
    on a common page in a multi-page parameter edit dialog
    
    """
    
    def __init__(self, label, *args, **kwargs):
        "initializer"
        
        if not isinstance(label,basestring): 
            raise TypeError("'label' must be a string")
        
        self.__label = unicode(label)
        self.__params = []
        self.__hidden = bool(kwargs.pop('hidden',False))
        self.add(*args)
        
        if len(kwargs):
            # extra keywords were passed
            raise ValueError("unknown keywords: "+(', '.join([str(k) for k in kwargs.keys()])))
        
        
    def add(self, *args):
        "add parameters to the page"
        
        for p in args:
            if isinstance(p,ParamGroup):
                self.__params.append(p)                
            elif isinstance(p,Param):
                self.__params.append(p)
            else:
                raise TypeError("positional arguments must be test parameter objects")
                    
    @property
    def params(self):
        "child parameters"
        return self.__params[:]
    
    @property
    def label(self):
        "parameter group label"
        return self.__label
    
    @property
    def hidden(self):
        "indicates that this is a hidden parameter group"
        return self.__hidden
    
    def __len__(self):
        return len(self.__params)
    
    def __unicode__(self):
        "return a unicode representation of the parameter"
        if not len(self.__params):
            return unicode("ParamPage('%s')"%self.__label)
        d = [unicode(x) for x in self.__params]
        return ("ParamPage('%s'\n    "%self.__label)+unicode('\n    ').join(d)+'\n)'
        
    def __str__(self):
        "return a string representation of the parameter"
        return str(unicode(self))
    
    






    
    
_valid_param_line = _re.compile(r'([a-zA-Z][a-zA-Z0-9_.]*)\s*=')
    
class TestParameters(object):
    """class to store parameters in an intelligent manner


    
    """
    
    def __init__(self, params=None):
        "initializer"
        self.__params = dict()
        self.__porder = []
        self._lock = _threading.RLock()
        
        if params:
            self.add_params(params)        
        
    def add_params(self, params):
        "add parameters to the internal set"
        if not isinstance(params,(list,tuple)):
            raise TypeError("argument must be a list/tuple of `Param` and/or ParamGroup objects")
        
        for i,p in enumerate(params):
            if isinstance(p,Param):
                if p.name in self.__params:
                    raise ValueError("duplicate parameter name `%s`"%p.name)
                self.__params[p.name] = p
                self.__porder.append(p)
            
            elif isinstance(p,ParamGroup):
                # add each parameter in the ParamGroup
                for p2 in p.params:
                    if p2.name in self.__params:
                        raise ValueError("duplicate parameter name `%s`"%p2.name)
                    self.__params[p2.name] = p2
                # only add the ParamGroup to the parameter order list
                self.__porder.append(p)
                
            elif isinstance(p,ParamPage):
                # add each parameter
                for p2 in p.params:
                    if isinstance(p2,Param):
                        if p2.name in self.__params:
                            raise ValueError("duplicate parameter name `%s`"%p2.name)
                        self.__params[p2.name] = p2
                    else:
                        # ParamGroup
                        for p3 in p2.params:
                            if p3.name in self.__params:
                                raise ValueError("duplicate parameter name `%s`"%p3.name)
                            self.__params[p3.name] = p3
                            
                # only add the ParamPage to the parameter order list
                self.__porder.append(p)
                
            else:
                raise TypeError("element at index %d is not a `Param`, `ParamGroup`, or `ParamPage` object"%i)        
    
    def get_dialog_list(self):  
        """get a list of Param/ParamGroup objects that is suitable to pass along
        to the parameter editing dialog box
        """
        out = []
        with self._lock:
            for p in self.__porder:
                if not p.hidden:
                    out.append(p)
        return out
        
    def clear(self):
        "remove all parameters"
        with self._lock:
            self.__params = dict()
            self.__porder = []
    
    def load(self, fname):
        "load parameters from a file"
        fp = open(fname,'r')
        data = {}
        for line in fp:
            m = _valid_param_line.match(line)
            if m:
                data[m.group(1)] = line[line.index('=')+1:].strip()
        fp.close()
        
        errs = []
        with self._lock:
            for k,v in data.iteritems():
                if k in self.__params:
                    try:
                        self.__params[k].value = eval(v)
                    except Exception, e:
                        errs.append(e)
        
        if len(errs):
            e = ValueError("file load errors in '%s'"%fname)
            e.allerrs = errs
            raise e
        
    def save(self, fname):
        "save parameters to a file"
        with self._lock:
            keys = self.__params.keys()
            keys.sort()
            fp = open(fname,'w')
            fp.write("# test parameters\n#\n\n")
            try:
                for k in keys:
                    p = self.__params[k]
                    v = p.value
                    # handle certain types specially, and for the rest just use repr
                    wv = repr(v)
                    
                    fp.write("%s = %s\n"%(k,wv))            
            finally:
                fp.close()
        
    def get(self, name, default=None):
        "get a parameter object, or return the default value"
        return self.__params.get(name,default)        
        
    def __contains__(self, name):
        "check to see if the preference is set"
        return name in self.__params
    
    def __getitem__(self, name):
        "get a preference by name"
        return self.__params[name]
            
    def __len__(self):
        "number of preferences"
        return len(self.__params)
       
       
       
       
