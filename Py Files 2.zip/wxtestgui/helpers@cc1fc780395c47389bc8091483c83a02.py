


def parm( name, type='string', **kwargs ):
    """define a test routine parameter
    
    Each parm must have a 'name' - the name must be a string, and
       there are certain requirements of this name string
    
    'type' (if defined) sets the parameter type, the following types
       are supported:
       
       - 'string', 'str', 'unicode' (the default), the value is stored as a
             unicode string
       - 'boolean' or 'bool', the value is stored as a True/False value
       - 'integer' or 'int', the value is stored as an integer
       - 'float', the value is stored as a float
       - 'choice', the value is stored as a choice from a list of choices
       - 'integer_list' or 'int_list', the value is stored as a list
             of integer values
       - 'float_list', the value is stored as a list of floating
             point values
    
    -------------------------------------------------------------------
    
    Keywords to this function are dependent on the type of parameter,
    but all parameters support the following keywords:
    
    'value', the initial/default value of the parameter - this must be
       able to be coerced to the correct type for the parameter type 
    
    'label', a string that will be used as a "human-friendly" label
       for the parameter when needed - if this is not defined then
       a label will be auto-generated
    
    'validator', a callable object that is used to validate the
       parameter value - it will be passed 2 arguments, the parameter
       name and the parameter value
    
    'help_text', a string that is used to display help text for the
       parameter
    
    -------------------------------------------------------------------
    
    Special information for the 'choice' parameter type:
    
    The 'choice' type has a required keyword called 'choices' which
    must be a list/tuple of 2-tuples. Each 2-tuple consists of a
    label string for the choice and a value (the value can be of
    any type). When the 'value' for a 'choice' parameter is set
    it must be the label string portion of one of the 'choices'
    that is used.

    Example:
        MYCHOICES = (
            ('Choice 1',1),
            ('Choice 2',2),
            ('Choice 3','fudge'),
        )
        
        # define parameter 'choice1' using the choice list
        # MYCHOICES, the default will be 'Choice 1'
        parm('choice1',type='choice',choices=MYCHOICES)
        
        # define parameter 'choice2' using the choice list
        # MYCHOICES, and set the default to 'Choice 3'
        parm('choice2',type='choice',choices=MYCHOICES,value='Choice 3')
    
    """
    from .params import StringParam, BooleanParam, FloatParam, IntParam, \
        FloatListParam, IntegerListParam, ChoiceParam, OrderedListParam, \
        FileParam, DirectoryParam
    
    if not isinstance(name,str):
        raise TypeError("'name' must be a string")
    if not isinstance(type,str):
        raise TypeError("'type' must be a string")
    
    # get the type object for the parameter
    if type in ('str','string','unicode'):
        t = StringParam
    elif type in ('bool','boolean'):
        t = BooleanParam        
    elif type == 'float':
        t = FloatParam    
    elif type in ('int','integer'):
        t = IntParam
    elif type == 'float_list':
        t = FloatListParam
    elif type in ('int_list','integer_list'):
        t = IntegerListParam
    elif type == 'choice':
        t = ChoiceParam    
    elif type == 'file':
        t = FileParam    
    elif type in ('dir','directory'):
        t = DirectoryParam    
    elif type == 'ordered_list':
        t = OrderedListParam    
    else:
        raise ValueError("invalid 'type' for parameter '%s'"%name)

    # generate the parameter object
    kwargs['name'] = name
    #try:
    p = t(**kwargs)
    #except KeyError, e:
    #    raise ValueError("parameter '%s' - '%s' is a required keyword"%(name,e))
    #except Exception, e:
    #    raise ValueError("parameter '%s' creation error: %s"%(name,e))
    
    return p
        
