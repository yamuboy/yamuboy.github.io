#!/usr/bin/env python3
"""
Two-tone IM3/IM5 and OIP3 measurement automation for:
  - two Keysight MXG signal generators
  - one Keysight UXA / X-Series spectrum analyzer
  - on-wafer thru scalar calibration

Run:
    python two_tone_imx_measure.py --config two_tone_imx_config.yaml

Optional:
    python two_tone_imx_measure.py --config two_tone_imx_config.yaml --skip-cal
    python two_tone_imx_measure.py --config two_tone_imx_config.yaml --list-resources

Dependencies:
    pip install pyvisa pyyaml

Notes:
  1. The on-wafer thru calibration here is scalar. It equalizes source paths and
     provides an optional scalar frequency correction for measured powers.
  2. A thru alone does not separate input-path loss from output-path loss. For
     absolute DUT input and output powers, use a VNA/power-sensor calibration of
     the input and output paths separately.
  3. OIP3 is computed using the standard equal-tone approximation:
         OIP3 = P_fund + (P_fund - P_IM3) / 2
     This is most meaningful when the measured output fundamentals are nearly
     balanced and the PA is in the weakly nonlinear region.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

try:
    import yaml
except ImportError as exc:  # pragma: no cover - runtime dependency message
    raise SystemExit("Missing dependency: PyYAML. Install with: pip install pyyaml") from exc


# -----------------------------------------------------------------------------
# Unit parsing and math helpers
# -----------------------------------------------------------------------------

_UNIT_SCALE = {
    "hz": 1.0,
    "khz": 1e3,
    "mhz": 1e6,
    "ghz": 1e9,
}


def parse_hz(value: Any) -> float:
    """Accept numbers, '7.5e9', '7.5 GHz', '100 MHz', etc."""
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        raise TypeError(f"Cannot parse frequency from {value!r}")

    s = value.strip().lower().replace(" ", "")
    match = re.fullmatch(r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)(hz|khz|mhz|ghz)?", s)
    if not match:
        raise ValueError(f"Cannot parse frequency value: {value!r}")
    number = float(match.group(1))
    unit = match.group(2) or "hz"
    return number * _UNIT_SCALE[unit]


def parse_db(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        raise TypeError(f"Cannot parse dB/dBm value from {value!r}")
    s = value.strip().lower().replace("dbm", "").replace("db", "").strip()
    return float(s)


def dbm_to_mw(dbm: float) -> float:
    return 10.0 ** (dbm / 10.0)


def mw_to_dbm(mw: float) -> float:
    if mw <= 0:
        return float("-inf")
    return 10.0 * math.log10(mw)


def split_total_two_tone_power(total_dbm: float, p2_minus_p1_db: float) -> tuple[float, float]:
    """
    Split total two-tone power into per-tone powers while enforcing:
        P2_dBm - P1_dBm = p2_minus_p1_db
        P1_mW + P2_mW = total_mW
    """
    total_mw = dbm_to_mw(total_dbm)
    ratio = 10.0 ** (p2_minus_p1_db / 10.0)
    p1_mw = total_mw / (1.0 + ratio)
    p2_mw = total_mw - p1_mw
    return mw_to_dbm(p1_mw), mw_to_dbm(p2_mw)


def mean(values: Iterable[float]) -> float:
    values = list(values)
    return sum(values) / len(values) if values else float("nan")


def linear_interp(x: float, xs: list[float], ys: list[float]) -> float:
    """Small dependency-free 1D interpolation with endpoint clamping."""
    if not xs:
        return 0.0
    if len(xs) == 1:
        return ys[0]
    if x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]

    for i in range(len(xs) - 1):
        x0, x1 = xs[i], xs[i + 1]
        if x0 <= x <= x1:
            y0, y1 = ys[i], ys[i + 1]
            frac = (x - x0) / (x1 - x0)
            return y0 + frac * (y1 - y0)
    return ys[-1]


# -----------------------------------------------------------------------------
# Calibration table
# -----------------------------------------------------------------------------

@dataclass
class CalTable:
    freq_hz: list[float]
    correction_db: list[float]

    def __post_init__(self):
        pairs = sorted(zip(self.freq_hz, self.correction_db), key=lambda p: p[0])
        self.freq_hz = [float(p[0]) for p in pairs]
        self.correction_db = [float(p[1]) for p in pairs]

    def interp(self, freq_hz: float) -> float:
        return linear_interp(freq_hz, self.freq_hz, self.correction_db)

    def to_dict(self) -> dict[str, Any]:
        return {"freq_hz": self.freq_hz, "correction_db": self.correction_db}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "CalTable":
        return cls(freq_hz=list(map(float, d["freq_hz"])), correction_db=list(map(float, d["correction_db"])))


def save_calibration(path: Path, cal: dict[str, CalTable], meta: dict[str, Any]) -> None:
    payload = {
        "metadata": meta,
        "tables": {name: table.to_dict() for name, table in cal.items()},
    }
    path.write_text(json.dumps(payload, indent=2))


def load_calibration(path: Path) -> dict[str, CalTable]:
    payload = json.loads(path.read_text())
    tables = payload.get("tables", payload)
    return {name: CalTable.from_dict(table) for name, table in tables.items()}


# -----------------------------------------------------------------------------
# Config handling
# -----------------------------------------------------------------------------

def cfg_get(cfg: dict[str, Any], path: str, default: Any = None, required: bool = False) -> Any:
    cur: Any = cfg
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            if required:
                raise KeyError(f"Missing required config key: {path}")
            return default
    return cur


def cfg_bool(cfg: dict[str, Any], path: str, default: bool) -> bool:
    return bool(cfg_get(cfg, path, default))


def cfg_float(cfg: dict[str, Any], path: str, default: float) -> float:
    return parse_db(cfg_get(cfg, path, default))


def cfg_hz(cfg: dict[str, Any], path: str, default: Any) -> float:
    return parse_hz(cfg_get(cfg, path, default))


def cfg_hz_list(cfg: dict[str, Any], path: str, default: list[Any]) -> list[float]:
    return [parse_hz(v) for v in cfg_get(cfg, path, default)]


def cfg_db_list(cfg: dict[str, Any], path: str, default: list[Any]) -> list[float]:
    return [parse_db(v) for v in cfg_get(cfg, path, default)]


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ValueError("Config file did not parse to a dictionary/object.")
    return cfg


# -----------------------------------------------------------------------------
# Instrument wrappers
# -----------------------------------------------------------------------------

class ScpiInstrument:
    def __init__(self, resource: Any, name: str, timeout_ms: int = 20000, verbose: bool = False):
        self.inst = resource
        self.name = name
        self.verbose = verbose
        self.inst.timeout = timeout_ms

    def write(self, cmd: str) -> None:
        if self.verbose:
            print(f"{self.name} << {cmd}")
        self.inst.write(cmd)

    def query(self, cmd: str) -> str:
        if self.verbose:
            print(f"{self.name} << {cmd}")
        resp = self.inst.query(cmd)
        if self.verbose:
            print(f"{self.name} >> {resp.strip()}")
        return resp

    def opc(self) -> None:
        self.query("*OPC?")

    def idn(self) -> str:
        return self.query("*IDN?").strip()

    def clear(self) -> None:
        self.write("*CLS")

    def try_write(self, cmd: str) -> None:
        try:
            self.write(cmd)
        except Exception as exc:
            print(f"[WARN] {self.name}: command failed: {cmd!r}: {exc}")

    def try_query(self, cmd: str) -> str | None:
        try:
            return self.query(cmd)
        except Exception as exc:
            print(f"[WARN] {self.name}: query failed: {cmd!r}: {exc}")
            return None

    def system_error(self) -> str | None:
        return self.try_query("SYST:ERR?")


class MXG(ScpiInstrument):
    def set_external_ref(self, enable: bool = True) -> None:
        self.try_write(f"ROSC:SOUR {'EXT' if enable else 'INT'}")

    def set_alc(self, enable: bool = True) -> None:
        self.try_write(f"POW:ALC:STAT {'ON' if enable else 'OFF'}")

    def output(self, enable: bool) -> None:
        self.write(f"OUTP:STAT {'ON' if enable else 'OFF'}")
        self.opc()

    def set_cw(self, freq_hz: float, power_dbm: float) -> None:
        self.write(f"SOUR:FREQ:CW {freq_hz:.6f} HZ")
        self.write(f"SOUR:POW:LEV:IMM:AMPL {power_dbm:.6f} DBM")
        self.opc()


class UXA(ScpiInstrument):
    def set_external_ref(self, enable: bool = True) -> None:
        self.try_write(f"ROSC:SOUR {'EXT' if enable else 'INT'}")

    def preset_sa(self, do_preset: bool = False) -> None:
        self.clear()
        self.try_write("INST:SEL SA")
        if do_preset:
            self.try_write("SYST:PRES")
        self.try_write("INIT:CONT OFF")
        self.opc()

    def configure_basic(
        self,
        ref_level_dbm: float,
        rbw_hz: float,
        vbw_hz: float | None,
        input_attenuation_db: float | None,
        sweep_points: int | None = None,
    ) -> None:
        self.try_write(f"DISP:WIND:TRAC:Y:RLEV {ref_level_dbm:.3f} DBM")
        self.try_write(f"BAND:RES {rbw_hz:.6f} HZ")
        if vbw_hz is not None:
            self.try_write(f"BAND:VID {vbw_hz:.6f} HZ")
        if input_attenuation_db is not None:
            self.try_write(f"POW:ATT {input_attenuation_db:.3f}")
        if sweep_points is not None:
            self.try_write(f"SWE:POIN {int(sweep_points)}")
        self.try_write("DET:TRAC POS")
        self.try_write("INIT:CONT OFF")
        self.opc()

    def measure_peak_near(
        self,
        freq_hz: float,
        span_hz: float,
        rbw_hz: float,
        averages: int,
        settle_s: float,
    ) -> dict[str, float]:
        self.write(f"FREQ:CENT {freq_hz:.6f} HZ")
        self.write(f"FREQ:SPAN {span_hz:.6f} HZ")
        self.write(f"BAND:RES {rbw_hz:.6f} HZ")
        self.write("CALC:MARK1:STAT ON")

        if averages > 1:
            self.try_write("AVER:STAT ON")
            self.try_write(f"AVER:COUN {int(averages)}")
            self.try_write("AVER:CLE")
        else:
            self.try_write("AVER:STAT OFF")

        self.opc()
        if settle_s > 0:
            time.sleep(settle_s)

        for _ in range(max(1, int(averages))):
            self.write("INIT:IMM")
            self.opc()

        self.write("CALC:MARK1:MAX")
        self.opc()
        p_dbm = float(self.query("CALC:MARK1:Y?").strip())
        marker_hz = float(self.query("CALC:MARK1:X?").strip())

        return {
            "target_freq_hz": float(freq_hz),
            "marker_freq_hz": marker_hz,
            "freq_error_hz": marker_hz - float(freq_hz),
            "power_dbm": p_dbm,
        }


# -----------------------------------------------------------------------------
# Measurement definitions
# -----------------------------------------------------------------------------

@dataclass
class ProductFrequencies:
    f1_hz: float
    f2_hz: float
    im3l_hz: float
    im3u_hz: float
    im5l_hz: float
    im5u_hz: float


def product_frequencies(fc_hz: float, spacing_hz: float) -> ProductFrequencies:
    f1 = fc_hz - spacing_hz / 2.0
    f2 = fc_hz + spacing_hz / 2.0
    return ProductFrequencies(
        f1_hz=f1,
        f2_hz=f2,
        im3l_hz=2.0 * f1 - f2,
        im3u_hz=2.0 * f2 - f1,
        im5l_hz=3.0 * f1 - 2.0 * f2,
        im5u_hz=3.0 * f2 - 2.0 * f1,
    )


def all_input_freqs(fc_hz: float, spacings_hz: list[float]) -> list[float]:
    freqs: set[float] = set()
    for spacing in spacings_hz:
        p = product_frequencies(fc_hz, spacing)
        freqs.update([p.f1_hz, p.f2_hz])
    return sorted(freqs)


def all_output_freqs(fc_hz: float, spacings_hz: list[float]) -> list[float]:
    freqs: set[float] = set()
    for spacing in spacings_hz:
        p = product_frequencies(fc_hz, spacing)
        freqs.update([p.f1_hz, p.f2_hz, p.im3l_hz, p.im3u_hz, p.im5l_hz, p.im5u_hz])
    return sorted(freqs)


def search_span_for_spacing(spacing_hz: float, requested_span_hz: float, rbw_hz: float) -> float:
    span = min(requested_span_hz, spacing_hz / 4.0)
    span = max(span, 10.0 * rbw_hz)
    if span >= spacing_hz / 2.0:
        raise ValueError(
            f"RBW/search span too large for spacing {spacing_hz} Hz. "
            "Reduce RBW/search_span_hz or increase tone spacing."
        )
    return span


@dataclass
class MeasurementRow:
    timestamp: str
    center_frequency_hz: float
    tone_spacing_hz: float
    requested_total_two_tone_power_dbm: float
    requested_p2_minus_p1_db: float
    desired_p1_dbm: float
    desired_p2_dbm: float
    sg1_frequency_hz: float
    sg2_frequency_hz: float
    sg1_set_power_dbm: float
    sg2_set_power_dbm: float
    sg1_source_correction_db: float
    sg2_source_correction_db: float
    output_correction_mode: str

    f1_raw_dbm: float
    f2_raw_dbm: float
    im3l_raw_dbm: float
    im3u_raw_dbm: float
    im5l_raw_dbm: float
    im5u_raw_dbm: float

    f1_corr_dbm: float
    f2_corr_dbm: float
    im3l_corr_dbm: float
    im3u_corr_dbm: float
    im5l_corr_dbm: float
    im5u_corr_dbm: float

    output_tone_imbalance_db: float
    im3l_dbc: float
    im3u_dbc: float
    im5l_dbc: float
    im5u_dbc: float
    im3_raw_asym_db: float
    im3_dbc_asym_db: float
    im5_raw_asym_db: float
    im5_dbc_asym_db: float

    oip3_lower_dbm: float
    oip3_upper_dbm: float
    oip3_average_dbm: float
    oip5_lower_dbm: float
    oip5_upper_dbm: float
    oip5_average_dbm: float

    f1_marker_error_hz: float
    f2_marker_error_hz: float
    im3l_marker_error_hz: float
    im3u_marker_error_hz: float
    im5l_marker_error_hz: float
    im5u_marker_error_hz: float


# -----------------------------------------------------------------------------
# Calibration and measurement flow
# -----------------------------------------------------------------------------

def receiver_correction(cal: dict[str, CalTable], freq_hz: float, mode: str) -> float:
    if mode == "none" or not cal:
        return 0.0
    if mode == "thru_scalar_average":
        values = []
        if "sg1_thru_corr" in cal:
            values.append(cal["sg1_thru_corr"].interp(freq_hz))
        if "sg2_thru_corr" in cal:
            values.append(cal["sg2_thru_corr"].interp(freq_hz))
        return mean(values) if values else 0.0
    if mode == "sg1_thru_scalar":
        return cal.get("sg1_thru_corr", CalTable([], [])).interp(freq_hz)
    if mode == "sg2_thru_scalar":
        return cal.get("sg2_thru_corr", CalTable([], [])).interp(freq_hz)
    raise ValueError(f"Unknown output correction mode: {mode}")


def measure_single_source_thru(
    active_sg: MXG,
    inactive_sg: MXG,
    uxa: UXA,
    freqs_hz: list[float],
    cal_power_dbm: float,
    search_span_hz: float,
    rbw_hz: float,
    averages: int,
    source_settle_s: float,
    analyzer_settle_s: float,
) -> CalTable:
    freqs: list[float] = []
    corrs: list[float] = []

    inactive_sg.output(False)
    active_sg.output(False)

    for f in freqs_hz:
        active_sg.set_cw(f, cal_power_dbm)
        active_sg.output(True)
        time.sleep(source_settle_s)
        meas = uxa.measure_peak_near(f, search_span_hz, rbw_hz, averages, analyzer_settle_s)
        active_sg.output(False)

        measured_dbm = meas["power_dbm"]
        corr_db = cal_power_dbm - measured_dbm
        freqs.append(f)
        corrs.append(corr_db)

        print(
            f"  {active_sg.name}: f={f/1e9:.9f} GHz, "
            f"measured={measured_dbm:+.3f} dBm, correction={corr_db:+.3f} dB"
        )

    return CalTable(freqs, corrs)


def run_thru_calibration(sg1: MXG, sg2: MXG, uxa: UXA, cfg: dict[str, Any]) -> dict[str, CalTable]:
    fc_hz = cfg_hz(cfg, "measurement.center_frequency_hz", 7.5e9)
    spacings_hz = cfg_hz_list(cfg, "measurement.tone_spacings_hz", [1e6])

    source_cal_power_dbm = cfg_float(cfg, "calibration.source_cal_power_dbm", -20.0)
    rbw_hz = cfg_hz(cfg, "analyzer.rbw_hz", 1e3)
    vbw_hz = cfg_hz(cfg, "analyzer.vbw_hz", rbw_hz)
    averages = int(cfg_get(cfg, "analyzer.averages", 4))
    ref_level_dbm = cfg_float(cfg, "analyzer.ref_level_dbm", 0.0)
    attenuation_db = cfg_float(cfg, "analyzer.input_attenuation_db", 20.0)
    sweep_points = cfg_get(cfg, "analyzer.sweep_points", None)
    sweep_points = int(sweep_points) if sweep_points is not None else None

    source_settle_s = float(cfg_get(cfg, "timing.source_settle_s", 0.2))
    analyzer_settle_s = float(cfg_get(cfg, "timing.analyzer_settle_s", 0.05))
    cal_search_span_hz = cfg_hz(cfg, "calibration.search_span_hz", 50e3)

    # Calibrate across all output frequencies so the same scalar table can be
    # used for fundamentals and IM3/IM5 products. Source corrections only use f1/f2.
    freqs_hz = all_output_freqs(fc_hz, spacings_hz)

    print("\n=== On-wafer thru scalar calibration ===")
    print("Land both probes on the on-wafer thru before this step.")
    print(f"Calibration frequencies: {len(freqs_hz)}")
    print(f"Source calibration power: {source_cal_power_dbm:+.2f} dBm\n")

    uxa.configure_basic(
        ref_level_dbm=ref_level_dbm,
        rbw_hz=rbw_hz,
        vbw_hz=vbw_hz,
        input_attenuation_db=attenuation_db,
        sweep_points=sweep_points,
    )

    print("Calibrating SG1 path through thru...")
    sg1_table = measure_single_source_thru(
        active_sg=sg1,
        inactive_sg=sg2,
        uxa=uxa,
        freqs_hz=freqs_hz,
        cal_power_dbm=source_cal_power_dbm,
        search_span_hz=cal_search_span_hz,
        rbw_hz=rbw_hz,
        averages=averages,
        source_settle_s=source_settle_s,
        analyzer_settle_s=analyzer_settle_s,
    )

    print("\nCalibrating SG2 path through thru...")
    sg2_table = measure_single_source_thru(
        active_sg=sg2,
        inactive_sg=sg1,
        uxa=uxa,
        freqs_hz=freqs_hz,
        cal_power_dbm=source_cal_power_dbm,
        search_span_hz=cal_search_span_hz,
        rbw_hz=rbw_hz,
        averages=averages,
        source_settle_s=source_settle_s,
        analyzer_settle_s=analyzer_settle_s,
    )

    return {"sg1_thru_corr": sg1_table, "sg2_thru_corr": sg2_table}


def measure_one_condition(
    sg1: MXG,
    sg2: MXG,
    uxa: UXA,
    cfg: dict[str, Any],
    cal: dict[str, CalTable],
    spacing_hz: float,
    total_power_dbm: float,
    requested_imbalance_db: float,
) -> MeasurementRow:
    fc_hz = cfg_hz(cfg, "measurement.center_frequency_hz", 7.5e9)
    p = product_frequencies(fc_hz, spacing_hz)

    rbw_hz = cfg_hz(cfg, "analyzer.rbw_hz", 1e3)
    averages = int(cfg_get(cfg, "analyzer.averages", 4))
    source_settle_s = float(cfg_get(cfg, "timing.source_settle_s", 0.2))
    analyzer_settle_s = float(cfg_get(cfg, "timing.analyzer_settle_s", 0.05))
    nominal_search_span_hz = cfg_hz(cfg, "analyzer.search_span_hz", 20e3)
    output_corr_mode = str(cfg_get(cfg, "calibration.output_correction_mode", "thru_scalar_average"))

    sg1_extra_offset = cfg_float(cfg, "source.sg1_extra_power_offset_db", 0.0)
    sg2_extra_offset = cfg_float(cfg, "source.sg2_extra_power_offset_db", 0.0)
    min_source_power = cfg_float(cfg, "source.min_source_power_dbm", -130.0)
    max_source_power = cfg_float(cfg, "source.max_source_power_dbm", 25.0)

    desired_p1_dbm, desired_p2_dbm = split_total_two_tone_power(total_power_dbm, requested_imbalance_db)

    sg1_corr = cal.get("sg1_thru_corr", CalTable([], [])).interp(p.f1_hz) if cal else 0.0
    sg2_corr = cal.get("sg2_thru_corr", CalTable([], [])).interp(p.f2_hz) if cal else 0.0

    sg1_set_power = desired_p1_dbm + sg1_corr + sg1_extra_offset
    sg2_set_power = desired_p2_dbm + sg2_corr + sg2_extra_offset

    for name, value in [("SG1", sg1_set_power), ("SG2", sg2_set_power)]:
        if value < min_source_power or value > max_source_power:
            raise ValueError(
                f"{name} set power {value:+.2f} dBm is outside configured limits "
                f"[{min_source_power:+.2f}, {max_source_power:+.2f}] dBm."
            )

    sg1.output(False)
    sg2.output(False)
    sg1.set_cw(p.f1_hz, sg1_set_power)
    sg2.set_cw(p.f2_hz, sg2_set_power)
    sg1.output(True)
    sg2.output(True)
    time.sleep(source_settle_s)

    search_span_hz = search_span_for_spacing(spacing_hz, nominal_search_span_hz, rbw_hz)

    m_f1 = uxa.measure_peak_near(p.f1_hz, search_span_hz, rbw_hz, averages, analyzer_settle_s)
    m_f2 = uxa.measure_peak_near(p.f2_hz, search_span_hz, rbw_hz, averages, analyzer_settle_s)
    m_3l = uxa.measure_peak_near(p.im3l_hz, search_span_hz, rbw_hz, averages, analyzer_settle_s)
    m_3u = uxa.measure_peak_near(p.im3u_hz, search_span_hz, rbw_hz, averages, analyzer_settle_s)
    m_5l = uxa.measure_peak_near(p.im5l_hz, search_span_hz, rbw_hz, averages, analyzer_settle_s)
    m_5u = uxa.measure_peak_near(p.im5u_hz, search_span_hz, rbw_hz, averages, analyzer_settle_s)

    f1_raw = m_f1["power_dbm"]
    f2_raw = m_f2["power_dbm"]
    im3l_raw = m_3l["power_dbm"]
    im3u_raw = m_3u["power_dbm"]
    im5l_raw = m_5l["power_dbm"]
    im5u_raw = m_5u["power_dbm"]

    f1_corr = f1_raw + receiver_correction(cal, p.f1_hz, output_corr_mode)
    f2_corr = f2_raw + receiver_correction(cal, p.f2_hz, output_corr_mode)
    im3l_corr = im3l_raw + receiver_correction(cal, p.im3l_hz, output_corr_mode)
    im3u_corr = im3u_raw + receiver_correction(cal, p.im3u_hz, output_corr_mode)
    im5l_corr = im5l_raw + receiver_correction(cal, p.im5l_hz, output_corr_mode)
    im5u_corr = im5u_raw + receiver_correction(cal, p.im5u_hz, output_corr_mode)

    tone_imbalance = f2_corr - f1_corr

    # Lower products are normalized to f1, upper products to f2.
    im3l_dbc = im3l_corr - f1_corr
    im3u_dbc = im3u_corr - f2_corr
    im5l_dbc = im5l_corr - f1_corr
    im5u_dbc = im5u_corr - f2_corr

    im3_raw_asym = im3u_raw - im3l_raw
    im5_raw_asym = im5u_raw - im5l_raw
    im3_dbc_asym = im3u_dbc - im3l_dbc
    im5_dbc_asym = im5u_dbc - im5l_dbc

    oip3_lower = f1_corr + (f1_corr - im3l_corr) / 2.0
    oip3_upper = f2_corr + (f2_corr - im3u_corr) / 2.0
    oip3_avg = mean([oip3_lower, oip3_upper])

    # Optional diagnostic; not the primary requested metric.
    oip5_lower = f1_corr + (f1_corr - im5l_corr) / 4.0
    oip5_upper = f2_corr + (f2_corr - im5u_corr) / 4.0
    oip5_avg = mean([oip5_lower, oip5_upper])

    return MeasurementRow(
        timestamp=datetime.now().isoformat(timespec="seconds"),
        center_frequency_hz=fc_hz,
        tone_spacing_hz=spacing_hz,
        requested_total_two_tone_power_dbm=total_power_dbm,
        requested_p2_minus_p1_db=requested_imbalance_db,
        desired_p1_dbm=desired_p1_dbm,
        desired_p2_dbm=desired_p2_dbm,
        sg1_frequency_hz=p.f1_hz,
        sg2_frequency_hz=p.f2_hz,
        sg1_set_power_dbm=sg1_set_power,
        sg2_set_power_dbm=sg2_set_power,
        sg1_source_correction_db=sg1_corr,
        sg2_source_correction_db=sg2_corr,
        output_correction_mode=output_corr_mode,
        f1_raw_dbm=f1_raw,
        f2_raw_dbm=f2_raw,
        im3l_raw_dbm=im3l_raw,
        im3u_raw_dbm=im3u_raw,
        im5l_raw_dbm=im5l_raw,
        im5u_raw_dbm=im5u_raw,
        f1_corr_dbm=f1_corr,
        f2_corr_dbm=f2_corr,
        im3l_corr_dbm=im3l_corr,
        im3u_corr_dbm=im3u_corr,
        im5l_corr_dbm=im5l_corr,
        im5u_corr_dbm=im5u_corr,
        output_tone_imbalance_db=tone_imbalance,
        im3l_dbc=im3l_dbc,
        im3u_dbc=im3u_dbc,
        im5l_dbc=im5l_dbc,
        im5u_dbc=im5u_dbc,
        im3_raw_asym_db=im3_raw_asym,
        im3_dbc_asym_db=im3_dbc_asym,
        im5_raw_asym_db=im5_raw_asym,
        im5_dbc_asym_db=im5_dbc_asym,
        oip3_lower_dbm=oip3_lower,
        oip3_upper_dbm=oip3_upper,
        oip3_average_dbm=oip3_avg,
        oip5_lower_dbm=oip5_lower,
        oip5_upper_dbm=oip5_upper,
        oip5_average_dbm=oip5_avg,
        f1_marker_error_hz=m_f1["freq_error_hz"],
        f2_marker_error_hz=m_f2["freq_error_hz"],
        im3l_marker_error_hz=m_3l["freq_error_hz"],
        im3u_marker_error_hz=m_3u["freq_error_hz"],
        im5l_marker_error_hz=m_5l["freq_error_hz"],
        im5u_marker_error_hz=m_5u["freq_error_hz"],
    )


def append_csv(path: Path, row: MeasurementRow) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    with path.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(row).keys()))
        if not exists:
            writer.writeheader()
        writer.writerow(asdict(row))


def run_measurement_sweep(sg1: MXG, sg2: MXG, uxa: UXA, cfg: dict[str, Any], cal: dict[str, CalTable]) -> Path:
    fc_hz = cfg_hz(cfg, "measurement.center_frequency_hz", 7.5e9)
    spacings_hz = cfg_hz_list(cfg, "measurement.tone_spacings_hz", [1e6])
    powers_dbm = cfg_db_list(cfg, "measurement.total_two_tone_powers_dbm", [-20.0])
    imbalances_db = cfg_db_list(cfg, "measurement.requested_p2_minus_p1_db", [0.0])

    rbw_hz = cfg_hz(cfg, "analyzer.rbw_hz", 1e3)
    vbw_hz = cfg_hz(cfg, "analyzer.vbw_hz", rbw_hz)
    ref_level_dbm = cfg_float(cfg, "analyzer.ref_level_dbm", 0.0)
    attenuation_db = cfg_float(cfg, "analyzer.input_attenuation_db", 20.0)
    sweep_points = cfg_get(cfg, "analyzer.sweep_points", None)
    sweep_points = int(sweep_points) if sweep_points is not None else None

    out_csv = Path(str(cfg_get(cfg, "output.results_csv", "results/two_tone_imx_results.csv")))
    if cfg_bool(cfg, "output.overwrite_results_csv", False) and out_csv.exists():
        out_csv.unlink()

    uxa.configure_basic(ref_level_dbm, rbw_hz, vbw_hz, attenuation_db, sweep_points)

    print("\n=== DUT IM3/IM5/OIP3 measurement sweep ===")
    print(f"Center frequency: {fc_hz/1e9:.9f} GHz")
    print(f"Results CSV: {out_csv}\n")

    try:
        for spacing in spacings_hz:
            for total_power in powers_dbm:
                for imbalance in imbalances_db:
                    print(
                        f"Measuring: spacing={spacing/1e6:.6f} MHz, "
                        f"Ptot={total_power:+.2f} dBm, P2-P1={imbalance:+.2f} dB"
                    )
                    row = measure_one_condition(sg1, sg2, uxa, cfg, cal, spacing, total_power, imbalance)
                    append_csv(out_csv, row)
                    print(
                        f"  tone imbalance={row.output_tone_imbalance_db:+.3f} dB, "
                        f"IM3 asym={row.im3_dbc_asym_db:+.3f} dB, "
                        f"OIP3(avg)={row.oip3_average_dbm:+.3f} dBm"
                    )
    finally:
        sg1.output(False)
        sg2.output(False)

    return out_csv


# -----------------------------------------------------------------------------
# Program entry point
# -----------------------------------------------------------------------------

def connect_instruments(cfg: dict[str, Any], verbose: bool = False) -> tuple[Any, MXG, MXG, UXA]:
    try:
        import pyvisa
    except ImportError as exc:  # pragma: no cover - runtime dependency message
        raise SystemExit("Missing dependency: PyVISA. Install with: pip install pyvisa") from exc

    rm = pyvisa.ResourceManager()
    timeout_ms = int(cfg_get(cfg, "instrument.timeout_ms", 20000))

    sg1_addr = cfg_get(cfg, "instrument.sg1_visa_address", required=True)
    sg2_addr = cfg_get(cfg, "instrument.sg2_visa_address", required=True)
    uxa_addr = cfg_get(cfg, "instrument.uxa_visa_address", required=True)

    sg1 = MXG(rm.open_resource(sg1_addr), "SG1", timeout_ms, verbose)
    sg2 = MXG(rm.open_resource(sg2_addr), "SG2", timeout_ms, verbose)
    uxa = UXA(rm.open_resource(uxa_addr), "UXA", timeout_ms, verbose)

    print("Connected instruments:")
    print("  SG1:", sg1.idn())
    print("  SG2:", sg2.idn())
    print("  UXA:", uxa.idn())

    return rm, sg1, sg2, uxa


def list_resources() -> None:
    try:
        import pyvisa
    except ImportError as exc:  # pragma: no cover
        raise SystemExit("Missing dependency: PyVISA. Install with: pip install pyvisa") from exc
    rm = pyvisa.ResourceManager()
    print("VISA resources:")
    for resource in rm.list_resources():
        print(" ", resource)


def maybe_prompt(enabled: bool, message: str) -> None:
    if enabled:
        input(message)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Two-tone IM3/IM5/OIP3 measurement with on-wafer thru calibration.")
    parser.add_argument("--config", type=Path, default=Path("two_tone_imx_config.yaml"), help="YAML config file")
    parser.add_argument("--skip-cal", action="store_true", help="Skip calibration and load existing calibration file if available")
    parser.add_argument("--list-resources", action="store_true", help="List VISA resources and exit")
    parser.add_argument("--verbose-scpi", action="store_true", help="Print SCPI commands and responses")
    args = parser.parse_args(argv)

    if args.list_resources:
        list_resources()
        return 0

    cfg = load_config(args.config)
    cal_file = Path(str(cfg_get(cfg, "calibration.save_file", "results/two_tone_thru_scalar_cal.json")))
    cal_enabled = cfg_bool(cfg, "calibration.enabled", True)
    reuse_cal = cfg_bool(cfg, "calibration.reuse_existing_calibration", False)

    _, sg1, sg2, uxa = connect_instruments(cfg, verbose=args.verbose_scpi)

    try:
        sg1.output(False)
        sg2.output(False)

        if cfg_bool(cfg, "instrument.use_external_10mhz_reference", True):
            sg1.set_external_ref(True)
            sg2.set_external_ref(True)
            uxa.set_external_ref(True)

        if cfg_bool(cfg, "source.alc_enabled", True):
            sg1.set_alc(True)
            sg2.set_alc(True)

        uxa.preset_sa(do_preset=cfg_bool(cfg, "analyzer.preset", False))

        cal: dict[str, CalTable] = {}
        if args.skip_cal or not cal_enabled or (reuse_cal and cal_file.exists()):
            if cal_file.exists():
                print(f"Loading calibration: {cal_file}")
                cal = load_calibration(cal_file)
            else:
                print("No calibration loaded. Running uncalibrated measurement.")
        else:
            maybe_prompt(
                cfg_bool(cfg, "calibration.prompt_before_calibration", True),
                "\nLand probes on the on-wafer THRU, then press Enter to start calibration...",
            )
            cal = run_thru_calibration(sg1, sg2, uxa, cfg)
            cal_file.parent.mkdir(parents=True, exist_ok=True)
            save_calibration(
                cal_file,
                cal,
                meta={
                    "created": datetime.now().isoformat(timespec="seconds"),
                    "config_file": str(args.config),
                    "note": "Scalar on-wafer thru calibration. Does not separate input and output path loss.",
                },
            )
            print(f"\nSaved calibration: {cal_file}")

        maybe_prompt(
            cfg_bool(cfg, "measurement.prompt_before_measurement", True),
            "\nMove probes from THRU to DUT and verify bias/attenuation, then press Enter to start measurement...",
        )
        out_csv = run_measurement_sweep(sg1, sg2, uxa, cfg, cal)
        print(f"\nDone. Results written to: {out_csv.resolve()}")
        return 0

    finally:
        try:
            sg1.output(False)
            sg2.output(False)
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
