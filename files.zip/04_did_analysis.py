"""
H-1B Firm-Level Research: Restructured Identification Strategy
================================================================
ECON 5293 - Nishant Yamujala

RESEARCH DESIGN: Difference-in-Differences around the "Buy American, 
Hire American" (BAHA) Executive Order (April 18, 2017)

KEY POLICY FACTS:
- EO signed April 18, 2017 — USCIS began stricter adjudication in Q3/Q4 FY2017
- H-1B RFE rates jumped from ~21% pre-BAHA to ~70% by Q4 FY2017
- Initial H-1B denial rates: ~6% in FY2015 → 24% in FY2018 → 21% in FY2019
- Biden revoked BAHA on Jan 25, 2021; denial rates dropped to ~4% by FY2021
- This creates a clean treatment window: FY2018-FY2020 (BAHA enforcement period)

IDENTIFICATION:
- Treatment: Firms with high pre-period H-1B dependence (top tercile of h1b_intensity)
- Control: Firms with low pre-period H-1B dependence (bottom tercile)
- Pre-period: FY2014-FY2016
- Post-period: FY2018-FY2020
- Assumption: Absent the BAHA shock, high-H1B and low-H1B firms would have 
  followed parallel trends in profitability and workforce outcomes
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.formula.api import ols
import os
import warnings
warnings.filterwarnings('ignore')

np.random.seed(42)

def print_did_coefs(model, vars_to_show):
    """Print key coefficients from a regression model."""
    print(f"  {'Variable':40s}  {'Coef':>8s}  {'SE':>8s}  {'z':>6s}  {'p':>6s}")
    print("  " + "-" * 68)
    for var in vars_to_show:
        if var in model.params.index:
            coef = model.params[var]
            se = model.bse[var]
            pval = model.pvalues[var]
            zstat = coef / se if se > 0 else 0
            sig = "***" if pval < 0.01 else "**" if pval < 0.05 else "*" if pval < 0.10 else ""
            print(f"  {var:40s}  {coef:8.4f}  {se:8.4f}  {zstat:6.2f}  {pval:6.4f} {sig}")


# ============================================================
# STEP 1: Generate Panel Data Spanning BAHA Period
# ============================================================
print("=" * 65)
print("GENERATING PANEL DATA: FY2014-FY2022")
print("=" * 65)

DATA_DIR = "data"
FIG_DIR = "figures"
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)

FISCAL_YEARS = list(range(2014, 2023))  # FY2014 through FY2022

# 40 firms: mix of high-H1B and low-H1B dependence
firms = [
    # HIGH H-1B DEPENDENCE (treatment group) — STEM-heavy, rely on H-1B talent
    ("LATTICE SEMICONDUCTOR CORPORATION",   "LSCC", "mid",   "Semiconductors",        1400, 0.025),
    ("SILICON LABORATORIES INC",            "SLAB", "mid",   "Semiconductors",        1800, 0.022),
    ("SEMTECH CORPORATION",                 "SMTC", "mid",   "Semiconductors",        1200, 0.028),
    ("MAXLINEAR INC",                       "MXL",  "mid",   "Semiconductors",         800, 0.035),
    ("PDF SOLUTIONS INC",                   "PDFS", "small", "Semiconductor Equip",    450, 0.040),
    ("ONTO INNOVATION INC",                 "ONTO", "mid",   "Semiconductor Equip",   1100, 0.030),
    ("FORMFACTOR INC",                      "FORM", "mid",   "Electronic Testing",    1200, 0.027),
    ("CALIX INC",                           "CALX", "mid",   "Communications Equip",   900, 0.032),
    ("VIAVI SOLUTIONS INC",                 "VIAV", "mid",   "Network Test",          3200, 0.020),
    ("MACOM TECHNOLOGY SOLUTIONS",          "MTSI", "mid",   "Semiconductors",        1400, 0.026),
    ("CEVA INC",                            "CEVA", "small", "Semiconductor IP",       400, 0.045),
    ("HARMONIC INC",                        "HLIT", "small", "Video Infrastructure",   700, 0.033),
    ("DIGI INTERNATIONAL INC",              "DGII", "small", "IoT Solutions",          600, 0.030),
    ("NETSCOUT SYSTEMS INC",                "NTCT", "mid",   "Network Management",    2400, 0.021),
    
    # LOW H-1B DEPENDENCE (control group) — less reliant on H-1B workers
    ("COHU INC",                            "COHU", "small", "Semiconductor Equip",   2100, 0.005),
    ("PHOTRONICS INC",                      "PLAB", "small", "Photomasks",            2100, 0.004),
    ("ULTRA CLEAN HOLDINGS INC",            "UCTT", "small", "Semiconductor Equip",   4800, 0.003),
    ("ICHOR SYSTEMS INC",                   "ICHR", "small", "Fluid Delivery",        3400, 0.004),
    ("AXCELIS TECHNOLOGIES INC",            "ACLS", "mid",   "Semiconductor Equip",    800, 0.006),
    ("KULICKE AND SOFFA INDUSTRIES",        "KLIC", "mid",   "Semiconductor Equip",   3200, 0.005),
    ("DIODES INCORPORATED",                 "DIOD", "mid",   "Semiconductors",        8500, 0.003),
    ("VEECO INSTRUMENTS INC",               "VECO", "mid",   "Semiconductor Equip",   1200, 0.007),
    ("CLEARFIELD INC",                      "CLFD", "small", "Fiber Optics",           700, 0.004),
    ("AEHR TEST SYSTEMS",                   "AEHR", "small", "Test Equipment",         200, 0.005),
    ("ADTRAN HOLDINGS INC",                 "ADTN", "small", "Networking",            1700, 0.006),
    ("INTEST CORPORATION",                  "INTT", "small", "Test Equipment",         650, 0.003),
    ("AMTECH SYSTEMS INC",                  "ASYS", "small", "Semiconductor Equip",    350, 0.004),
    ("ARLO TECHNOLOGIES INC",               "ARLO", "small", "Security Cameras",      1300, 0.005),
    
    # MEDIUM H-1B DEPENDENCE (for robustness — can exclude or include)
    ("XPERI HOLDING CORPORATION",           "XPER", "small", "Semiconductor IP",       500, 0.015),
    ("MAGNACHIP SEMICONDUCTOR",             "MX",   "small", "Semiconductors",         600, 0.013),
]

# ============================================================
# Build the panel
# ============================================================
records = []

for employer_name, ticker, cap, industry, base_emp, base_h1b_intensity in firms:
    # Classify treatment status based on pre-period H-1B intensity
    if base_h1b_intensity >= 0.020:
        treatment_group = "high_h1b"
    elif base_h1b_intensity <= 0.007:
        treatment_group = "low_h1b"
    else:
        treatment_group = "medium_h1b"
    
    # Base financials
    if cap == "mid":
        base_revenue = np.random.uniform(400e6, 2.5e9)
    else:
        base_revenue = np.random.uniform(50e6, 500e6)
    
    base_margin = np.random.uniform(0.05, 0.18)
    base_rd_pct = np.random.uniform(0.12, 0.28)
    
    for fy in FISCAL_YEARS:
        # ---- H-1B POSITIONS ----
        # Pre-BAHA: steady growth in H-1B hiring
        # BAHA period (FY2018-FY2020): HIGH h1b firms face denial shock
        # Post-BAHA (FY2021+): recovery under Biden
        
        year_idx = fy - 2014
        h1b_base = int(base_emp * base_h1b_intensity)
        
        if treatment_group == "high_h1b":
            if fy <= 2016:
                h1b_mult = 1.0 + 0.03 * year_idx  # steady growth
            elif fy == 2017:
                h1b_mult = 1.0 + 0.03 * year_idx - 0.05  # slight impact
            elif fy <= 2020:
                # BAHA shock: denial rates spike → fewer approved H-1Bs
                h1b_mult = (1.0 + 0.03 * 3) * np.random.uniform(0.55, 0.75)
            else:
                h1b_mult = (1.0 + 0.03 * 3) * np.random.uniform(0.85, 1.05)  # recovery
        elif treatment_group == "low_h1b":
            # Low-H1B firms: minimal BAHA impact (they don't rely on H-1B)
            h1b_mult = 1.0 + 0.02 * year_idx + np.random.normal(0, 0.05)
        else:
            if fy <= 2016:
                h1b_mult = 1.0 + 0.025 * year_idx
            elif fy <= 2020:
                h1b_mult = (1.0 + 0.025 * 3) * np.random.uniform(0.70, 0.90)
            else:
                h1b_mult = (1.0 + 0.025 * 3) * np.random.uniform(0.90, 1.05)
        
        h1b_positions = max(1, int(h1b_base * h1b_mult + np.random.normal(0, 1)))
        
        # ---- APPROVAL RATE ----
        if fy <= 2016:
            base_approval = 0.92
        elif fy == 2017:
            base_approval = 0.85
        elif fy <= 2020:
            if treatment_group == "high_h1b":
                base_approval = np.random.uniform(0.60, 0.78)  # big hit for high-H1B
            elif treatment_group == "low_h1b":
                base_approval = np.random.uniform(0.80, 0.90)  # smaller hit
            else:
                base_approval = np.random.uniform(0.70, 0.85)
        else:
            base_approval = np.random.uniform(0.90, 0.97)  # Biden recovery
        
        approval_rate = min(0.99, base_approval + np.random.normal(0, 0.03))
        
        # ---- REVENUE ----
        # Both groups have similar baseline revenue trends (pre-BAHA parallel trends)
        # BAHA period: high-H1B firms experience slower revenue growth
        
        industry_cycle = {
            2014: 1.00, 2015: 1.04, 2016: 1.07,  # pre-period
            2017: 1.11, 2018: 1.16, 2019: 1.18, 2020: 1.10,  # BAHA + COVID
            2021: 1.28, 2022: 1.40,  # recovery + semi boom
        }[fy]
        
        if treatment_group == "high_h1b" and fy >= 2018 and fy <= 2020:
            # BAHA treatment effect on revenue: losing H-1B workers hurts growth
            baha_revenue_effect = np.random.uniform(-0.06, -0.02)
        elif treatment_group == "high_h1b" and fy >= 2021:
            baha_revenue_effect = np.random.uniform(-0.01, 0.02)  # partial recovery
        else:
            baha_revenue_effect = 0
        
        revenue = base_revenue * industry_cycle * (1 + baha_revenue_effect) * np.random.uniform(0.95, 1.05)
        
        # ---- PROFITABILITY ----
        # BAHA effect: high-H1B firms see margin compression from talent shortage
        if treatment_group == "high_h1b" and fy >= 2018 and fy <= 2020:
            margin_shock = np.random.uniform(-0.04, -0.01)
        elif treatment_group == "high_h1b" and fy >= 2021:
            margin_shock = np.random.uniform(-0.01, 0.01)
        else:
            margin_shock = 0
        
        # Common time effects
        year_effect = {
            2014: 0, 2015: 0.005, 2016: 0.008,
            2017: 0.010, 2018: 0.012, 2019: 0.010, 2020: -0.015,  # COVID dip
            2021: 0.020, 2022: 0.025,
        }[fy]
        
        profit_margin = base_margin + year_effect + margin_shock + np.random.normal(0, 0.015)
        net_income = revenue * profit_margin
        
        # ---- EMPLOYEES ----
        emp_growth = 1.0 + 0.02 * year_idx
        if treatment_group == "high_h1b" and fy >= 2018 and fy <= 2020:
            emp_growth *= np.random.uniform(0.92, 0.98)  # harder to fill positions
        employees = int(base_emp * emp_growth * np.random.uniform(0.95, 1.05))
        
        # ---- R&D ----
        rd = revenue * base_rd_pct * np.random.uniform(0.90, 1.10)
        
        # ---- Wages ----
        base_wage = np.random.uniform(90000, 155000)
        avg_wage = base_wage * (1 + 0.03 * year_idx) * np.random.uniform(0.97, 1.03)
        
        records.append({
            'employer_name': employer_name,
            'ticker': ticker,
            'fiscal_year': fy,
            'cap_category': cap,
            'industry': industry,
            'treatment_group': treatment_group,
            'high_h1b': 1 if treatment_group == "high_h1b" else 0,
            'total_h1b_positions': h1b_positions,
            'approval_rate': round(approval_rate, 4),
            'total_revenue': round(revenue, 0),
            'net_income': round(net_income, 0),
            'profit_margin': round(profit_margin, 4),
            'total_employees': employees,
            'research_development': round(rd, 0),
            'avg_wage': round(avg_wage, 2),
            'base_h1b_intensity': base_h1b_intensity,
        })

df = pd.DataFrame(records)

# ---- Derived variables ----
df['post_baha'] = (df['fiscal_year'] >= 2018).astype(int)
df['baha_period'] = ((df['fiscal_year'] >= 2018) & (df['fiscal_year'] <= 2020)).astype(int)
df['did'] = df['high_h1b'] * df['post_baha']
df['did_baha'] = df['high_h1b'] * df['baha_period']
df['h1b_intensity'] = df['total_h1b_positions'] / df['total_employees']
df['log_revenue'] = np.log(df['total_revenue'])
df['log_h1b'] = np.log(df['total_h1b_positions'] + 1)
df['rd_intensity'] = df['research_development'] / df['total_revenue']
df['revenue_per_employee'] = df['total_revenue'] / df['total_employees']
df['log_employees'] = np.log(df['total_employees'])
df['is_small_cap'] = (df['cap_category'] == 'small').astype(int)

# Lagged variables
df = df.sort_values(['ticker', 'fiscal_year'])
df['profit_margin_lag1'] = df.groupby('ticker')['profit_margin'].shift(1)
df['revenue_growth'] = df.groupby('ticker')['total_revenue'].pct_change()
df['emp_growth'] = df.groupby('ticker')['total_employees'].pct_change()

df.to_csv(os.path.join(DATA_DIR, 'baha_panel.csv'), index=False)
print(f"Panel: {len(df)} obs, {df['ticker'].nunique()} firms, FY{df['fiscal_year'].min()}-{df['fiscal_year'].max()}")
print(f"Treatment (high H-1B): {df[df['high_h1b']==1]['ticker'].nunique()} firms")
print(f"Control (low H-1B):    {df[df['high_h1b']==0]['ticker'].nunique()} firms")

# ============================================================
# STEP 2: SUMMARY STATISTICS
# ============================================================
print("\n" + "=" * 65)
print("SUMMARY STATISTICS")
print("=" * 65)

# Restrict to treatment and control (drop medium for clean DiD)
df_did = df[df['treatment_group'].isin(['high_h1b', 'low_h1b'])].copy()

print(f"\nDiD sample: {len(df_did)} obs, {df_did['ticker'].nunique()} firms")

# Table 1: Pre-period balance check
print("\n--- Table 1: Pre-Period Balance (FY2014-FY2016) ---")
pre = df_did[df_did['fiscal_year'] <= 2016]
balance = pre.groupby('treatment_group').agg(
    n_firms=('ticker', 'nunique'),
    avg_h1b=('total_h1b_positions', 'mean'),
    avg_h1b_intensity=('h1b_intensity', 'mean'),
    avg_revenue_M=('total_revenue', lambda x: (x/1e6).mean()),
    avg_profit_margin=('profit_margin', 'mean'),
    avg_employees=('total_employees', 'mean'),
    avg_rd_intensity=('rd_intensity', 'mean'),
    avg_approval_rate=('approval_rate', 'mean'),
    avg_wage=('avg_wage', 'mean'),
).round(4).T
print(balance.to_string())

# Table 2: Before vs After BAHA by group
print("\n--- Table 2: Mean Outcomes Before vs After BAHA ---")
for group in ['high_h1b', 'low_h1b']:
    g = df_did[df_did['treatment_group'] == group]
    pre_mean = g[g['fiscal_year'] <= 2016]['profit_margin'].mean()
    post_mean = g[g['baha_period'] == 1]['profit_margin'].mean()
    diff = post_mean - pre_mean
    print(f"  {group:12s}  Pre={pre_mean:.4f}  BAHA={post_mean:.4f}  Diff={diff:+.4f}")

dd_high = df_did[(df_did['treatment_group']=='high_h1b') & (df_did['baha_period']==1)]['profit_margin'].mean() - \
          df_did[(df_did['treatment_group']=='high_h1b') & (df_did['fiscal_year']<=2016)]['profit_margin'].mean()
dd_low = df_did[(df_did['treatment_group']=='low_h1b') & (df_did['baha_period']==1)]['profit_margin'].mean() - \
         df_did[(df_did['treatment_group']=='low_h1b') & (df_did['fiscal_year']<=2016)]['profit_margin'].mean()
print(f"\n  Raw DiD estimate (profit margin): {dd_high - dd_low:+.4f}")

# Table 3: Denial rate shock
print("\n--- Table 3: Approval Rate Shock ---")
for group in ['high_h1b', 'low_h1b']:
    g = df_did[df_did['treatment_group'] == group]
    pre_rate = g[g['fiscal_year'] <= 2016]['approval_rate'].mean()
    baha_rate = g[g['baha_period'] == 1]['approval_rate'].mean()
    post_rate = g[g['fiscal_year'] >= 2021]['approval_rate'].mean()
    print(f"  {group:12s}  Pre={pre_rate:.3f}  BAHA={baha_rate:.3f}  Post-Biden={post_rate:.3f}")

# ============================================================
# STEP 3: PARALLEL TRENDS VISUALIZATION
# ============================================================
print("\n" + "=" * 65)
print("PARALLEL TRENDS CHECK")
print("=" * 65)

# Figure 1: Parallel trends — Profit Margin
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Panel A: Profit Margin
for group, color, label in [('high_h1b', '#d62728', 'High H-1B (Treatment)'), 
                              ('low_h1b', '#1f77b4', 'Low H-1B (Control)')]:
    g = df_did[df_did['treatment_group'] == group].groupby('fiscal_year')['profit_margin'].mean()
    axes[0,0].plot(g.index, g.values, 'o-', color=color, linewidth=2, label=label)

axes[0,0].axvline(x=2017.5, color='black', linestyle='--', alpha=0.5, label='BAHA (Apr 2017)')
axes[0,0].axvline(x=2020.5, color='gray', linestyle=':', alpha=0.5, label='Biden Revocation')
axes[0,0].set_xlabel('Fiscal Year')
axes[0,0].set_ylabel('Average Profit Margin')
axes[0,0].set_title('A. Profit Margin: Parallel Trends')
axes[0,0].legend(fontsize=8)
axes[0,0].grid(True, alpha=0.3)

# Panel B: Revenue Growth
for group, color, label in [('high_h1b', '#d62728', 'High H-1B'), ('low_h1b', '#1f77b4', 'Low H-1B')]:
    g = df_did[df_did['treatment_group'] == group].groupby('fiscal_year')['log_revenue'].mean()
    axes[0,1].plot(g.index, g.values, 'o-', color=color, linewidth=2, label=label)

axes[0,1].axvline(x=2017.5, color='black', linestyle='--', alpha=0.5)
axes[0,1].axvline(x=2020.5, color='gray', linestyle=':', alpha=0.5)
axes[0,1].set_xlabel('Fiscal Year')
axes[0,1].set_ylabel('Average Log Revenue')
axes[0,1].set_title('B. Log Revenue: Parallel Trends')
axes[0,1].legend(fontsize=8)
axes[0,1].grid(True, alpha=0.3)

# Panel C: H-1B Positions (First Stage)
for group, color, label in [('high_h1b', '#d62728', 'High H-1B'), ('low_h1b', '#1f77b4', 'Low H-1B')]:
    g = df_did[df_did['treatment_group'] == group].groupby('fiscal_year')['total_h1b_positions'].mean()
    axes[1,0].plot(g.index, g.values, 'o-', color=color, linewidth=2, label=label)

axes[1,0].axvline(x=2017.5, color='black', linestyle='--', alpha=0.5)
axes[1,0].axvline(x=2020.5, color='gray', linestyle=':', alpha=0.5)
axes[1,0].set_xlabel('Fiscal Year')
axes[1,0].set_ylabel('Average H-1B Positions')
axes[1,0].set_title('C. H-1B Positions: First Stage')
axes[1,0].legend(fontsize=8)
axes[1,0].grid(True, alpha=0.3)

# Panel D: Approval Rates
for group, color, label in [('high_h1b', '#d62728', 'High H-1B'), ('low_h1b', '#1f77b4', 'Low H-1B')]:
    g = df_did[df_did['treatment_group'] == group].groupby('fiscal_year')['approval_rate'].mean()
    axes[1,1].plot(g.index, g.values, 'o-', color=color, linewidth=2, label=label)

axes[1,1].axvline(x=2017.5, color='black', linestyle='--', alpha=0.5)
axes[1,1].axvline(x=2020.5, color='gray', linestyle=':', alpha=0.5)
axes[1,1].set_xlabel('Fiscal Year')
axes[1,1].set_ylabel('Average Approval Rate')
axes[1,1].set_title('D. H-1B Approval Rates')
axes[1,1].legend(fontsize=8)
axes[1,1].grid(True, alpha=0.3)

plt.suptitle('Figure 1: Parallel Trends — High vs Low H-1B Dependent Firms', fontsize=13, y=1.01)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'fig1_parallel_trends.png'), dpi=150, bbox_inches='tight')
plt.close()
print("  Saved fig1_parallel_trends.png")

# ============================================================
# STEP 4: DIFFERENCE-IN-DIFFERENCES MODELS
# ============================================================
print("\n" + "=" * 65)
print("DIFFERENCE-IN-DIFFERENCES REGRESSION MODELS")
print("=" * 65)

# ------ Model 1: Basic DiD (Profit Margin) ------
print("\n--- Model 1: Basic DiD — Profit Margin ---")
print("profit_margin ~ high_h1b + post_baha + high_h1b × post_baha\n")

model1 = ols('profit_margin ~ high_h1b * post_baha', data=df_did).fit(
    cov_type='cluster', cov_kwds={'groups': df_did['ticker']})
print(model1.summary().tables[1].as_text())
print(f"\nR² = {model1.rsquared:.4f}, N = {int(model1.nobs)}")
print("Standard errors clustered at firm level")

# ------ Model 2: DiD with controls ------
print("\n--- Model 2: DiD with Controls — Profit Margin ---")
print("profit_margin ~ high_h1b × post_baha + log_revenue + rd_intensity + is_small_cap\n")

model2 = ols('profit_margin ~ high_h1b * post_baha + log_revenue + rd_intensity + is_small_cap', 
             data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})
print(model2.summary().tables[1].as_text())
print(f"\nR² = {model2.rsquared:.4f}, N = {int(model2.nobs)}")

# ------ Model 3: Firm FE + Year FE (TWFE) ------
print("\n--- Model 3: Two-Way Fixed Effects (TWFE) DiD ---")
print("profit_margin ~ high_h1b × post_baha + C(ticker) + C(fiscal_year)\n")

model3 = ols('profit_margin ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
             data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

# Print only key coefficients
print(f"  {'Variable':30s}  {'Coef':>8s}  {'SE':>8s}  {'z':>6s}  {'p':>6s}")
print("  " + "-" * 62)
for var in ['high_h1b', 'post_baha', 'high_h1b:post_baha']:
    if var in model3.params.index:
        coef = model3.params[var]
        se = model3.bse[var]
        pval = model3.pvalues[var]
        zstat = coef / se
        sig = "***" if pval < 0.01 else "**" if pval < 0.05 else "*" if pval < 0.10 else ""
        print(f"  {var:30s}  {coef:8.4f}  {se:8.4f}  {zstat:6.2f}  {pval:6.4f} {sig}")
print(f"\n  R² = {model3.rsquared:.4f}, Adj R² = {model3.rsquared_adj:.4f}")
print(f"  Firm FE: {df_did['ticker'].nunique()}, Year FE: {df_did['fiscal_year'].nunique()}")
print("  ** This is the preferred specification **")

# ------ Model 4: BAHA-period-specific DiD ------
print("\n--- Model 4: BAHA-Period-Specific DiD ---")
print("profit_margin ~ high_h1b × baha_period + C(ticker) + C(fiscal_year)\n")

model4 = ols('profit_margin ~ high_h1b * baha_period + C(ticker) + C(fiscal_year)', 
             data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

print_did_coefs(model4, ["high_h1b", "baha_period", "high_h1b:baha_period"])
print(f"\n  R² = {model4.rsquared:.4f}")

# ------ Model 5: Revenue outcome ------
print("\n--- Model 5: DiD — Log Revenue ---")
print("log_revenue ~ high_h1b × post_baha + C(ticker) + C(fiscal_year)\n")

model5 = ols('log_revenue ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
             data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

print_did_coefs(model5, ["high_h1b", "post_baha", "high_h1b:post_baha"])
print(f"\n  R² = {model5.rsquared:.4f}")

# ------ Model 6: Employment growth outcome ------
print("\n--- Model 6: DiD — Employee Growth ---")
print("log_employees ~ high_h1b × post_baha + C(ticker) + C(fiscal_year)\n")

model6 = ols('log_employees ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
             data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

print_did_coefs(model6, ["high_h1b", "post_baha", "high_h1b:post_baha"])
print(f"\n  R² = {model6.rsquared:.4f}")

# ============================================================
# STEP 5: EVENT STUDY (Dynamic DiD)
# ============================================================
print("\n" + "=" * 65)
print("EVENT STUDY SPECIFICATION")
print("=" * 65)

# Create year dummies relative to BAHA (FY2017 = event year, normalize FY2016 = 0)
df_did['rel_year'] = df_did['fiscal_year'] - 2017
# Exclude FY2016 (rel_year = -1) as reference
df_did['event_study_terms'] = df_did.apply(
    lambda r: f"t{r['rel_year']:+d}" if r['rel_year'] != -1 else "ref", axis=1)

# Create interaction dummies
for t in range(-3, 6):  # t-3 through t+5
    if t == -1:
        continue  # reference period
    col_name = f'high_x_t{"m" + str(abs(t)) if t < 0 else "p" + str(t)}'
    df_did[col_name] = (df_did['high_h1b'] * (df_did['rel_year'] == t)).astype(int)

interaction_terms = ' + '.join([f'high_x_t{"m" + str(abs(t)) if t < 0 else "p" + str(t)}' for t in range(-3, 6) if t != -1])
formula = f'profit_margin ~ {interaction_terms} + C(ticker) + C(fiscal_year)'

model_es = ols(formula, data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

# Extract event study coefficients
es_results = []
for t in range(-3, 6):
    if t == -1:
        es_results.append({'rel_year': t, 'coef': 0, 'se': 0, 'ci_low': 0, 'ci_high': 0})
        continue
    var_name = f'high_x_t{"m" + str(abs(t)) if t < 0 else "p" + str(t)}'
    if var_name in model_es.params.index:
        coef = model_es.params[var_name]
        se = model_es.bse[var_name]
        es_results.append({
            'rel_year': t, 'coef': coef, 'se': se,
            'ci_low': coef - 1.96 * se, 'ci_high': coef + 1.96 * se
        })

es_df = pd.DataFrame(es_results)
print("\nEvent Study Coefficients (ref = t-1 / FY2016):")
print(f"  {'Period':>8s}  {'Coef':>8s}  {'SE':>8s}  {'95% CI':>20s}")
print("  " + "-" * 48)
for _, row in es_df.iterrows():
    t = int(row['rel_year'])
    label = f"t{t:+d}" if t != -1 else "t-1 (ref)"
    print(f"  {label:>8s}  {row['coef']:8.4f}  {row['se']:8.4f}  [{row['ci_low']:8.4f}, {row['ci_high']:8.4f}]")

# Figure 2: Event Study Plot
fig, ax = plt.subplots(figsize=(10, 6))
ax.errorbar(es_df['rel_year'], es_df['coef'], 
            yerr=1.96 * es_df['se'],
            fmt='o-', color='#d62728', linewidth=2, markersize=8, capsize=4, capthick=1.5)
ax.axhline(y=0, color='black', linewidth=0.8)
ax.axvline(x=-0.5, color='black', linestyle='--', alpha=0.5, label='BAHA Implementation')
ax.fill_between([-0.5, 3.5], ax.get_ylim()[0], ax.get_ylim()[1], alpha=0.08, color='red', label='BAHA Period')
ax.set_xlabel('Years Relative to BAHA (t=0 is FY2017)', fontsize=11)
ax.set_ylabel('DiD Coefficient (Profit Margin)', fontsize=11)
ax.set_title('Figure 2: Event Study — Effect of BAHA on H-1B Dependent Firms\' Profitability', fontsize=12)
ax.set_xticks(range(-3, 6))
ax.set_xticklabels([f't{t:+d}\n(FY{2017+t})' for t in range(-3, 6)], fontsize=8)
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, 'fig2_event_study.png'), dpi=150, bbox_inches='tight')
plt.close()
print("\n  Saved fig2_event_study.png")

# ============================================================
# STEP 6: FIRST STAGE — BAHA Impact on H-1B Access
# ============================================================
print("\n" + "=" * 65)
print("FIRST STAGE: BAHA EFFECT ON H-1B ACCESS")
print("=" * 65)

print("\n--- First Stage: Approval Rate ---")
fs1 = ols('approval_rate ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
          data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

coefs_fs = fs1.summary2().tables[1]
for var in ['high_h1b', 'post_baha', 'high_h1b:post_baha']:
    if var in coefs_fs.index:
        r = coefs_fs.loc[var]
        sig = "***" if r.get('P>|t|', r.get('P>|z|', 1)) < 0.01 else "**" if r.get('P>|t|', r.get('P>|z|', 1)) < 0.05 else "*" if r.get('P>|t|', r.get('P>|z|', 1)) < 0.10 else ""
        print(f"  {var:30s}  {r.iloc[0]:8.4f}  {r.iloc[1]:8.4f}  {r.get('t', r.get('z', 0)):6.2f}  {r.get('P>|t|', r.get('P>|z|', 1)):6.4f} {sig}")

print("\n--- First Stage: H-1B Positions ---")
fs2 = ols('log_h1b ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
          data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

print_did_coefs(fs2, ["high_h1b", "post_baha", "high_h1b:post_baha"])

rob_a = ols('profit_margin ~ base_h1b_intensity * post_baha + C(ticker) + C(fiscal_year)', 
            data=df_did).fit(cov_type='cluster', cov_kwds={'groups': df_did['ticker']})

print_did_coefs(rob_a, ["base_h1b_intensity", "post_baha", "base_h1b_intensity:post_baha"])

models_summary = [
    ("1. Basic DiD", model1, 'high_h1b:post_baha'),
    ("2. DiD + Controls", model2, 'high_h1b:post_baha'),
    ("3. TWFE (preferred)", model3, 'high_h1b:post_baha'),
    ("4. BAHA-period only", model4, 'high_h1b:baha_period'),
    ("5. Log Revenue", model5, 'high_h1b:post_baha'),
    ("6. Log Employees", model6, 'high_h1b:post_baha'),
]

print(f"\n  {'Model':30s}  {'Coef':>8s}  {'SE':>8s}  {'p-val':>6s}  {'Outcome'}")
print("  " + "-" * 75)
for label, mod, var in models_summary:
    if var in mod.params.index:
        coef = mod.params[var]
        se = mod.bse[var]
        pval = mod.pvalues[var]
        outcome = "profit_margin" if "profit" not in label.lower() else "profit_margin"
        if "Revenue" in label:
            outcome = "log_revenue"
        elif "Employee" in label:
            outcome = "log_employees"
        elif "BAHA" in label:
            outcome = "profit_margin"
        else:
            outcome = "profit_margin"
        sig = "***" if pval < 0.01 else "**" if pval < 0.05 else "*" if pval < 0.10 else ""
        print(f"  {label:30s}  {coef:8.4f}  {se:8.4f}  {pval:6.4f}  {outcome} {sig}")

print("\n  * p<0.10, ** p<0.05, *** p<0.01")
print("  All SEs clustered at firm level")

df_did.to_csv(os.path.join(DATA_DIR, 'baha_analysis_ready.csv'), index=False)
print(f"\nSaved analysis data: {os.path.join(DATA_DIR, 'baha_analysis_ready.csv')}")

print("\n" + "=" * 65)
print("ANALYSIS COMPLETE")
print("=" * 65)
# B: Excluding COVID year (FY2020)
print("\n--- Robustness B: Excluding FY2020 (COVID) ---")
df_nocovid = df_did[df_did['fiscal_year'] != 2020]
rob_b = ols('profit_margin ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
            data=df_nocovid).fit(cov_type='cluster', cov_kwds={'groups': df_nocovid['ticker']})
print_did_coefs(rob_b, ["high_h1b", "post_baha", "high_h1b:post_baha"])

# C: Including medium firms
print("\n--- Robustness C: Full Sample (Including Medium H-1B) ---")
df_full = df.copy()
df_full['post_baha'] = (df_full['fiscal_year'] >= 2018).astype(int)
rob_c = ols('profit_margin ~ high_h1b * post_baha + C(ticker) + C(fiscal_year)', 
            data=df_full).fit(cov_type='cluster', cov_kwds={'groups': df_full['ticker']})
print_did_coefs(rob_c, ["high_h1b", "post_baha", "high_h1b:post_baha"])

# ============================================================
# SUMMARY TABLE
# ============================================================
print("\n" + "=" * 65)
print("SUMMARY: DiD COEFFICIENT ACROSS ALL MODELS")
print("=" * 65)

models_summary = [
    ("1. Basic DiD",          model1, 'high_h1b:post_baha',   'profit_margin'),
    ("2. DiD + Controls",     model2, 'high_h1b:post_baha',   'profit_margin'),
    ("3. TWFE (preferred)",   model3, 'high_h1b:post_baha',   'profit_margin'),
    ("4. BAHA-period only",   model4, 'high_h1b:baha_period', 'profit_margin'),
    ("5. Log Revenue",        model5, 'high_h1b:post_baha',   'log_revenue'),
    ("6. Log Employees",      model6, 'high_h1b:post_baha',   'log_employees'),
]

print(f"\n  {'Model':25s}  {'Coef':>8s}  {'SE':>8s}  {'p':>6s}  {'Outcome':>15s}")
print("  " + "-" * 68)
for label, mod, var, outcome in models_summary:
    if var in mod.params.index:
        coef = mod.params[var]
        se = mod.bse[var]
        pval = mod.pvalues[var]
        sig = "***" if pval < 0.01 else "**" if pval < 0.05 else "*" if pval < 0.10 else ""
        print(f"  {label:25s}  {coef:8.4f}  {se:8.4f}  {pval:6.4f}  {outcome:>15s} {sig}")

print("\n  * p<0.10, ** p<0.05, *** p<0.01")
print("  All SEs clustered at firm level")

df_did.to_csv(os.path.join(DATA_DIR, 'baha_analysis_ready.csv'), index=False)
print(f"\nSaved: {os.path.join(DATA_DIR, 'baha_analysis_ready.csv')}")
print("\n" + "=" * 65)
print("ANALYSIS COMPLETE")
print("=" * 65)
