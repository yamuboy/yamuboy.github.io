from __future__ import division, print_function, unicode_literals, absolute_import
from .constants import *
from .parser import parse_gdsii
from .highlevel import Structure, _Element
from . import _int_types

def get_cell_names(fname):
    """Return a list of all cell names present in the GDSII file
    specified by fname
    """
    def _cb(ctx, libn, strn, rec):
        if rec.record_type == RT_STRNAME:
            cells.append(rec.decoded_data)
    
    cells = []
    parse_gdsii(fname,callback=_cb,filter=(RT_STRNAME,))
    cells.sort()
    return cells

class ElementBBox(object):
    "store the element type and bounding box"
    
    __slots__ = ('_elem',)

    def __init__(self, element):
        "initializer"
        if not isinstance(element,_Element):
            raise TypeError("argument must be an instance of '_Element'")
        self._elem = element
    
    @property
    def type(self):
        "element type"
        return self._elem.name
        
    @property
    def name(self):
        "element name"
        return self._elem.name
        
    @property
    def x1(self):
        "lower-left x-coord"
        return self._elem.bounding_box[0]
    
    @property
    def y1(self):
        "lower-left y-coord"
        return self._elem.bounding_box[1]
    
    @property
    def x2(self):
        "upper-right x-coord"
        return self._elem.bounding_box[2]
        
    @property
    def y2(self):
        "upper-right y-coord"
        return self._elem.bounding_box[3]
        
    @property
    def bbox(self):
        "bounding box returned as a tuple (x1,y1,x2,y2)"
        return self._elem.bounding_box
    
    
    
def compute_element_bounding_boxes(structure, layers=None, types=frozenset([RT_BOX,RT_BOUNDARY]), cache=None):
    """Compute the bounding boxes of elements contained within the sub-hierarchy of the
    passed Structure object.  Elements are filtered by layer number and type according
    to the passed arguments.
    
    structure   A Structure object, usually retrieved from a loaded GDSII Library by
                    using the Library.get_structure_by_name() method.
                    
    layers      An iterable containing layer numbers to match, only elements that are
                    on these layers will be returned
                    
    types       An iterable containing element types (integer constants), only elements that
                    match these types will be returned.  By default, only BOX and BOUNDARY
                    elements are returned.
    
    cache       An optional dictionary that can be used to cache the results of the
                    computations.  To reuse the results, this function must be called
                    with the same values for the 'layers' and 'types' arguments - if
                    these are changed between calls that use the cache then the results
                    will be incorrect.  This argument should be passed an empty dictionary
                    when the function is first called, and then the same (non-empty)
                    dictionary be passed to subsequent calls.  The cache can be used to
                    improve performance when multiple Structure objects are to be used
                    as arguments since the cache keeps a copy of the computed element
                    positions in each Structure encountered in the sub-hierarchy and
                    those calculated positions can be re-used for future calls that
                    have some the same elements in their sub-hierarchy.
                    
    This returns a list of ElementBBox objects.
    """
    
    if not isinstance(structure,Structure):
        raise TypeError("argument 1 must be an instance of a `Structure` object")

    if layers is not None:
        for l in layers:
            if not isinstance(l,_int_types):
                raise ValueError("`layers` must be an iterable containing integers")
        
    if not types:
        raise ValueError("`types` cannot be empty")
    
    for t in types:
        if t not in (RT_BOX,RT_BOUNDARY,RT_TEXT,RT_NODE,RT_PATH):
            raise ValueError("`types` contains an invalid value")
    
    if cache is None:
        # create a local copy of the cache, it can still improve performance in cases
        # where the same structure appears multiple times in the sub-hierarchy
        cache = {}
    else:
        if not isinstance(cache,dict):  
            raise TypeError("`cache` must be a dictionary object")
    
    # flatten the structure
    flatstr = structure.flatten(cache=cache,only_types=types,only_layers=layers)
    
    # compute bounding boxes and append to result
    result = []
    for elem in flatstr:
        result.append(ElementBBox(elem))
    
    return result
