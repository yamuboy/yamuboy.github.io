from __future__ import division, print_function, unicode_literals, absolute_import
import math, io
from datetime import datetime
try:
    from collections import OrderedDict
except ImportError:
    from ordereddict import OrderedDict

from .constants import *
from .errors import *
from .record import Record, build_record
from .parser import parse_gdsii
from . import _int_types, _str_type

__all__ = ['Boundary','Box','Node','Text','Path','SRef','ARef','Structure','Library']

_element_record_types = frozenset((RT_BOX,RT_BOUNDARY,RT_NODE,RT_TEXT,RT_PATH,RT_SREF,RT_AREF))
_element_record_names = {
    RT_BOX:       'Box',
    RT_BOUNDARY:  'Boundary',
    RT_NODE:      'Node',
    RT_TEXT:      'Text',
    RT_PATH:      'Path',
    RT_SREF:      'SRef',
    RT_AREF:      'ARef'
    }

def _element_name(ty):
    "element name string"
    return _element_record_names.get(ty,'INVALID')  

class _TransformInner(object):
    "inner container for transforms"
    
    __slots__ = ('_flags','_mag','_angle','_aidx')
    
    def __init__(self, flags, mag, angle):
        "store inner transform data"
        self._flags = flags
        self._mag = None
        self._angle = None
        self._aidx = -1
        if mag is not None and abs(mag-1.0) > 0.0001:
            self._mag = mag            
        if angle is not None and abs(angle) > 0.0001:
            while angle < -0.0001:
                angle += 360.0
            if abs(angle-360.0) < 0.00015:
                angle = 0.0
            self._angle = angle
            
            aidx = -1
            if abs(angle) < 0.0001:
                aidx = 0
            elif abs(angle-90.0) < 0.0001:
                aidx = 1
            elif abs(angle-180.0) < 0.0001:
                aidx = 2 
            elif abs(angle-270.0) < 0.0001:
                aidx = 3
            self._aidx = aidx
        
    def compute(self, x, y, x0, y0, absmag, absang):
        "inner method to compute the transform"
        # the first transform is mirroring
        if self._flags & 0x8000:
            y = -y            
        
        # the second transform is magnitude
        if self._mag is not None and not absmag:
            x = int(round(self._mag*x))
            y = int(round(self._mag*y))
        
        # the third transform is angle
        if self._angle is not None and not absang:
            if self._aidx == 0:
                # no angle change
                pass
            elif self._aidx == 1:
                # 90 degrees
                x, y = -y, x
            elif self._aidx == 2:
                # 180 degrees
                x, y = -x, -y
            elif self._aidx == 3:
                # 270 degrees
                x, y = y, -x
            else:
                # non-Manhattan angle
                if x != 0 or y != 0:
                    # requires real math
                    m = math.sqrt(x*x+y*y)
                    a = math.atan2(y,x)
                    ta = self._angle*math.pi/180.0
                    x = int(round(m*math.cos(a+ta)))
                    y = int(round(m*math.sin(a+ta)))          
        
        # the last transform is translation
        if x0 != 0 or y0 != 0:
            x += x0
            y += y0
                
        return x, y
    
    @property
    def mirror(self):
        "mirror transform is enabled"
        return bool(self._flags&0x8000)
        
    @property
    def absmag(self):
        "absolute magnitude flag is set"
        return bool(self._flags&0x0004)
    
    @property
    def absang(self):
        "absolute angle flag is set"
        return bool(self._flags&0x0002)
    
    @property
    def mag(self):
        "transform magnitude"
        if self._mag is None:
            return 1.0
        return self._mag
    
    @property
    def angle(self):
        "transform angle"
        if self._angle is None:
            return 0.0
        return self._angle
        
    @property
    def records(self):
        "transform GDSII records"
        out = []
        if self._flags or self._mag is not None or self._angle is not None:
            out.append(build_record(RT_STRANS,self._flags))
            if self._mag is not None:
                out.append(build_record(RT_MAG,self._mag))
            if self._angle is not None:
                out.append(build_record(RT_ANGLE,self._angle))
        return out
        
        
class Transform(object):
    "GDSII transform"
    
    __slots__ = ('_stk')
    
    def __init__(self, flags=0, mag=None, angle=None):
        ""
        if isinstance(flags,Transform):
            # copy construction
            self._stk = flags._stk[:]
        else:
            # normal construction
            if flags is None:
                flags = 0
            self._stk = [_TransformInner(flags,mag,angle)]
    
    def compute(self, xy, x0=0, y0=0, absmag=False, absang=False):
        "compute the transform on a set of data"
        if not isinstance(xy,(list,tuple)):
            raise TypeError("invalid data format to compute transform")
        
        n = len(xy)
        out = []
        if n > 0:
            r0 = xy[0]
            if isinstance(r0,_Point):
                for p in xy:
                    x, y, am, aa = self._compute(p.x,p.y,x0,y0,absmag,absang)
                    out.append(_Point(x,y))
            elif isinstance(r0,_int_types):
                if n % 2:
                    raise XYInvalidLength("XY data must have an even length")
                if n == 2:
                    # 2-tuple gets special treatment and returns another 2-tuple
                    return self._compute(xy[0],xy[1],x0,y0,absmag,absang)[:2]
                else:
                    for i in range(0,n,2):
                        x, y, am, aa = self._compute(xy[i],xy[i+1],x0,y0,absmag,absang)
                        out.extend([x,y])
            elif isinstance(r0,(list,tuple)):
                # assume format to be a list of 2-tuples
                for p in xy:
                    x, y, am, aa = self._compute(p[0],p[1],x0,y0,absmag,absang)
                    out.append((x,y))
        return out, am, aa
    
    def _compute(self, x, y, x0, y0, absmag, absang):
        "compute transforms"
        for xfrm in self._stk:
            x, y = xfrm.compute(x,y,x0,y0,absmag,absang)
            if xfrm.absmag:
                absmag = True
            if xfrm.absang:
                absang = True
        return x, y, absmag, absang
    
    @property
    def is_simple(self):
        "simple transform boolean indicator"
        return bool(len(self._stk)==1)
        
    @property
    def records(self):
        "transform GDSII records"
        if not self.is_simple:
            raise TransformError("cannot generate records for a non-simple Transform")
        return self._stk[0].records
    
    def copy(self): 
        "copy this transform"
        return Transform(self)
    
    def apply_transform(self, xfrm):
        "apply the passed transform to this one"
        if not isinstance(xfrm,(Transform,_TransformInner)):
            raise TypeError("`Transform` object expected")
        if isinstance(xfrm,_TransformInner):
            self._stk.append(xfrm)
        else:
            self._stk.extend(xfrm._stk)
        
        
class _Point(object):
    "store a single (x,y) point"
    
    __slots__ = ('_x','_y')
    
    def __init__(self, x, y):
        "initializer"
        self._x = int(x)
        self._y = int(y)        
    
    @property
    def x(self):
        "x-value"
        return self._x
        
    @property
    def y(self):
        "y-value"
        return self._y
    
    @property
    def xy(self):
        "x,y as a tuple"
        return self._x, self._y
    
    def __eq__(self, other):
        "equality"
        if not isinstance(other,_Point):
            return NotImplemented
        if self._x == other._x and self._y == other._y:
            return True
        return False
    
    def __ne__(self, other):
        "inequality"
        return not self.__eq__(other)
        
        
class _XYData(object):
    "holds and manipulates XY data"
    
    __slots__ = ('_eltype','_data','_flags')
    
    def __init__(self, xyrec, eltype, flags=0):
        "initializer"
        self._data = []
        if eltype not in _element_record_types:
            raise ValueError("0x{0:x} is not a valid element type".format(eltype))
            
        self._eltype = eltype
        self._flags = flags
        self.store(xyrec)
        
    def store(self, data):
        "store the XY data"
        res = []
        if isinstance(data,Record) and data.type == RT_XY:
            d = data.data
            n = len(d)
            if n % 2:
                raise XYInvalidLength("'XY' records cannot have an odd data length")
            for i in range(0,n,2):
                res.append(_Point(d[i],d[i+1]))
        elif isinstance(data,(list,tuple)) and len(data) > 0:
            if isinstance(data[0],(list,tuple)):
                # list/tuple of 2-tuples
                for i,pair in enumerate(data):
                    if not isinstance(pair,(list,tuple)) or len(pair) != 2:
                        raise TypeError("'XY' element at position {0} is not a 2-tuple".format(i))
                    res.append(_Point(pair[0],pair[1]))
            elif isinstance(data[0],_Point):
                # list/tuple of _Point objects
                for i,point in enumerate(data):
                    if not isinstance(point,_Point):
                        raise TypeError("'XY' element at position {0} is not a _Point object".format(i))
                res = data[:]            
            else:
                # assume a list/tuple of integers 
                n = len(data)
                if n % 2:
                    raise XYInvalidLength("'XY' records cannot have an odd data length")
                for i in range(0,n,2):
                    res.append(_Point(data[i],data[i+1]))
        
        min_pairs, max_pairs = 1, 8191
        first_matches_last = False
        if self._eltype in (RT_SREF,RT_TEXT):
            min_pairs = max_pairs = 1
        elif self._eltype == RT_BOX:
            min_pairs = max_pairs = 5            
            first_matches_last = True
        elif self._eltype == RT_AREF:
            min_pairs = max_pairs = 3
        elif self._eltype == RT_BOUNDARY:
            min_pairs = 4
            first_matches_last = True
        elif self._eltype == RT_PATH:
            min_pairs = 2
            
        n = len(res)
        if n < min_pairs or n > max_pairs:
            if min_pairs == max_pairs:
                raise XYInvalidLength("XY data for element type '{0}' must consist of exactly {1} pairs -> got {2} pairs".format(_element_name(self._eltype),min_pairs,n))
            else:
                raise XYInvalidLength("XY data for element type '{0}' must consist of {1} <= pairs <= {2} -> got {3} pairs".format(_element_name(self._eltype),min_pairs,max_pairs,n))
        
        if first_matches_last and res[0] != res[-1]:
            raise XYInconsitentPoints("the first XY pair must equal the last XY pair for element type '{0}'".format(_element_name(self._eltype)))
        
        self._data = res
        
    def apply_transform(self, xfrm, x0=0, y0=0):
        "apply the transform to the contained data"
        absmag = bool(self._flags & 0x0004)
        absang = bool(self._flags & 0x0002)
        res, am, aa = xfrm.compute(self._data,x0,y0,absmag,absang)
        if am:
            self._flags |= 0x0004
        if aa:
            self._flags |= 0x0002
        self._data = res
    
    def compute_transform(self, xfrm, x0=0, y0=0):
        "return a new _XYData object containing transformed data"
        absmag = bool(self._flags & 0x0004)
        absang = bool(self._flags & 0x0002)
        res, am, aa = xfrm.compute(self._data,x0,y0,absmag,absang)
        flags = self._flags
        if am:
            flags |= 0x0004
        if aa:
            flags |= 0x0002
        return _XYData(res,self._eltype,flags)
    
    def copy(self):
        "copy the XY data object"
        return _XYData(self._data,self._eltype,self._flags)

    @property
    def points(self):
        "x,y coordinates as a list"
        return self._data[:]
    
    @property
    def record(self):
        "the Record object for this data"
        d = []
        for point in self._data:
            d.append(point.x)
            d.append(point.y)
        return build_record(RT_XY,d)
    
    def __getitem__(self, key):
        "indexing method"
        return self._data[key]
    
    def __len__(self):
        "length method"
        return len(self._data)
        
    def __iter__(self):
        "point iterator"
        return iter(self._data)
        
        
class _Element(object):
    "base element for the high-level GDSII interface"
    # class variables used to store things that are constants
    # for a given type of GDSII element
    _record_name = '_Element'
    _starting_record = None
    _ending_record = Record(RT_ENDEL,DT_NONE,None)
    _datatype_record = -1
    
    __slots__ = ('_properties','_data_fields','_structure')
    
    def __init__(self, records):
        "create the element and populate the record dictionary"
        self._properties = OrderedDict()
        self._data_fields = dict()
        self._structure = None
        if isinstance(records,_Element):
            # copy constructor
            self._properties.update(records._properties)
            for field in records._data_fields:
                value = records._data_fields[field]
                if hasattr(value,'copy'):
                    self._data_fields[field] = value.copy()
                else:
                    self._data_fields[field] = value
        else:
            # normal initialization
            remain = self._process_records(records)
            if remain:
                # there were extra records
                raise InvalidElementRecord("{0} extra records were passed to the '{1}' initializer".format(len(remain),self._record_name))
        
    def _df(self, name, default=None, exceptions=False):
        "get the data field value or return the default"
        try:
            return self._data_fields[name]
        except KeyError:
            if exceptions:
                raise MissingRequiredRecords("missing the record for data field '{0}'".format(name))
            return default
        
    def _setdf(self, name, value):
        "set the data field value"
        self._data_fields[name] = value
    
    def _hasdf(self, name):
        "see if the data field has been set"
        return name in self._data_fields
        
    def _process_records(self, records):
        "process records, returns a list of records not handled"
        out = []
        propattr = None
        for rec in records:
            if not isinstance(rec,Record):
                raise TypeError("argument must be an iterable of `Record` objects")
            ty = rec.type
            if ty in _element_record_types:
                propattr = None
                pass
            elif ty == RT_ENDEL:
                break
            elif ty == RT_ELFLAGS:
                propattr = None
                self._setdf('elflags',rec.data)
            elif ty == RT_PLEX:
                propattr = None
                plex = rec.data[0]
                head = False
                if plex & 0x01000000:
                    head = True
                self._setdf('plex',plex)
                self._setdf('plexhead',head)
            elif ty == RT_XY:
                propattr = None
                self._setdf('xy',_XYData(rec,self.type))
            elif ty == RT_PROPATTR:
                propattr = rec
            elif ty == RT_PROPVALUE:
                if not propattr:
                    raise TypeError("got a `PROPVALUE` record without a corresponding `PROPATTR` record")
                self._properties[propattr.data[0]] = rec.data
            elif ty == RT_UINTEGER:
                # translate this to property number 126
                self._properties[126] = '{0}'.format(rec.data[0])            
            elif ty == RT_USTRING:
                # translate this to property number 127
                self._properties[127] = rec.data
            else:
                propattr = None
                out.append(rec)
                
        return out
                
    @property
    def records(self):
        "element records list"
        records = [self._starting_record]
        if self._hasdf('elflags'):
            records.append(build_record(RT_ELFLAGS,self._df('elflags')))
        if self._hasdf('plex'):
            v = self._df('plex') & 0x00ffffff
            if self.plexhead:
                v |= 0x01000000
            records.append(build_record(RT_PLEX,v))
        self._gather_records(records)
        records.append(self.xy.record)
        self._gather_postxy_records(records)
        for prop in self._properties:
            records.append(build_record(RT_PROPATTR,prop))
            records.append(build_record(RT_PROPVALUE,self._properties[prop]))
        records.append(self._ending_record)
        return records
    
    def write_records(self, fp):
        "write records to a file-like object (opened in binary mode)"
        for rec in self.records:
            fp.write(rec.binary_record)
    
    def iter_records(self):
        "record iterator"
        for rec in self.records:
            yield rec
    
    def __iter__(self):
        "iterator initializer"
        return self.iter_records()
    
    def _gather_records(self, lst):
        "gather element records by appending them to the passed list"
        pass

    def _gather_postxy_records(self, lst):
        "gather records after the XY record, only the TEXT element does this"
        pass
        
    def _attach(self, structure):
        "attach this element to a Structure"
        if not isinstance(structure,Structure):
            raise TypeError("a `Structure` object is required")
        self._structure = structure
        
    def _detach(self):
        "detach this element from it's Structure"
        self._structure = None
        
    def copy(self):
        "create a copy of the element"
        return self.__class__(self)
        
    def compute_transform(self, xfrm, x0=0, y0=0):
        "compute the passed transform on this element and return a new element"
        if not isinstance(xfrm,Transform):
            raise TypeError("argument 1 must be a Transform object")
        
        newel = self.copy()
        newel.xy.apply_transform(xfrm,x0,y0)
        return newel
    
    @property
    def name(self):
        "element name"
        return self._record_name
    
    @property
    def type(self):
        "element type integer"
        return self._starting_record.type
    
    @property
    def structure(self):
        "Structure this element is part of"
        return self._structure
        
    @property
    def plex(self):
        "PLEX record data, an integer or None if there is no PLEX data"
        return self._df('plex')
        
    @property
    def plexhead(self):
        "boolean to indicate that this is a PLEX header (not meaningful if plex is None)"
        return bool(self._df('plexhead',False))
    
    @property
    def elflags(self):
        "ELFLAGS field data, an integer"
        return self._df('elflags',0)
        
    @property
    def xy(self):
        "XY record data, returns an _XYData object"
        return self._df('xy',exceptions=True)
    
    @xy.setter
    def xy(self, data):
        """XY record setter, requires a list of integers,
        a list of integer 2-tuples, or a list of _Point objects"""
        self._df('xy',exceptions=True).store(data)
         
    @property
    def is_geom_element(self):
        "is a geometry element"
        # default to False
        return False

         
class _GeomElement(_Element):
    "intermediate base class for BOUNDARY, PATH, TEXT, NODE, and BOX elements"

    def _process_records(self, records):
        "process records found in geometry type elements"
        # process records through the element level first 
        remain = _Element._process_records(self,records)
        # remaining records get handled here
        out = []
        for rec in remain:
            ty = rec.type
            if ty == RT_LAYER:
                self._setdf('layer',rec.data[0])
            elif ty == self._datatype_record:
                # data type (also box type, text type, and node type)
                self._setdf('datatype',rec.data[0])
            else:
                out.append(rec)
        return out
        
    def _gather_records(self, lst):
        "gather element records by appending them to the passed list"
        lst.append(build_record(RT_LAYER,self._df('layer',exceptions=True)))
        lst.append(build_record(self._datatype_record,self._df('datatype',exceptions=True)))
        
    @property
    def layer(self):
        "LAYER record data, returns an integer"
        return self._df('layer',exceptions=True)
        
    @layer.setter
    def layer(self, value):
        "setter for LAYER record data"
        if not isinstance(value,_int_types):
            raise TypeError("integer value required")
        self._setdf('layer',value)
    
    @property
    def datatype(self):
        "the element datatype"
        return self._df('datatype',exceptions=True)
        
    @datatype.setter
    def datatype(self):
        "the element datatype"
        if not isinstance(value,_int_types):
            raise TypeError("integer value required")
        self._setdf('datatype',value)
        
    # legacy
    generictype = datatype
    
    @property
    def is_geom_element(self):
        "is a geometry element"
        return True
    
    @property
    def bounding_box(self):
        "compute the bounding box of the element"
        first = True
        xl, xh, yl, yh = 0, 0, 0, 0
        for point in self.xy:
            if first:
                xl = xh = point.x
                yl = yh = point.y
                first = False
            else:
                x, y = point.x, point.y
                if x < xl:
                    xl = x
                elif x > xh:
                    xh = x
                
                if y < yl:
                    yl = y
                elif y > yh:
                    yh = y
        
        return xl, yl, xh, yh

    
class _ReferenceElement(_Element):
    "intermediate base class for SREF and AREF elements"
    
    def _process_records(self, records):
        "process records found in reference type elements"
        # process records through the element level first 
        remain = _Element._process_records(self,records)
        # remaining records get handled here
        out = []
        strans = None
        mag = None
        angle = None
        for rec in remain:
            ty = rec.type
            if ty == RT_SNAME:
                self._setdf('sname',rec.data)
            elif ty == RT_STRANS:
                strans = rec.data
            elif ty == RT_MAG:
                mag = rec.data[0]
            elif ty == RT_ANGLE:
                angle = rec.data[0]
            else:
                out.append(rec)
                
        # save the transform data
        if strans is not None:
            self._setdf('_xfrm',Transform(strans,mag,angle))                
                
        return out
    
    def _gather_records(self, lst):
        "gather element records by appending them to the passed list"
        lst.append(build_record(RT_SNAME,self._df('sname')))
        if self._hasdf('_xfrm'):
            lst.extend(self._df('_xfrm').records)
            
    def compute_transform(self, xfrm, x0=0, y0=0):
        "compute the passed transform on this element and return a new element"
        if not isinstance(xfrm,Transform):
            raise TypeError("argument 1 must be a Transform object")
        
        newel = self.copy()
        newel.xy.apply_transform(xfrm,x0,y0)
        # apply the transform to this element's transform
        x = newel.transform
        x.apply_transform(xfrm)
        newel._setdf('_xfrm',x)
        return newel
    
    @property
    def sname(self):
        "SNAME record data, returns a string"
        return self._df('sname',exceptions=True)
        
    @sname.setter
    def sname(self, value):
        "setter for SNAME record data"
        if not isinstance(value,_str_type):
            raise TypeError("string argument required")
        self._setdf('sname',value)
    
    @property
    def referenced_structure(self):
        "returns the Structure object that this element references"
        if self._structure is None:
            raise UnattachedElement("unattached elements cannot resolve references")
        sname = self._df('sname',exceptions=True)
        try:
            return self._structure.library[sname]
        except KeyError:            
            raise InvalidStructureReference("'{0}' is not a valid structure name".format(sname))
        except AttributeError:            
            raise UnattachedStructure("Structure '{0}' is not attached to a Library and cannot resolve references".format(self._structure.name))
    
    @property
    def transform(self):
        "get the transform applied by the reference element"
        xfrm = self._df('_xfrm')
        if xfrm is None:
            return Transform()
        return xfrm
    
class Boundary(_GeomElement):
    "BOUNDARY elememt"    
    _record_name = 'Boundary'
    _starting_record = Record(RT_BOUNDARY,DT_NONE,None)
    _datatype_record = RT_DATATYPE
        

class Path(_GeomElement):
    "PATH element"
    _record_name = 'Path'
    _starting_record = Record(RT_PATH,DT_NONE,None)
    _datatype_record = RT_DATATYPE
    
    def _process_records(self, records):
        "process records found in reference type elements"
        # process records through the geom element level first 
        remain = _GeomElement._process_records(self,records)
        # remaining records get handled here
        out = []
        for rec in remain:
            ty = rec.type
            if ty == RT_WIDTH:
                self._setdf('width',rec.data[0])
            elif ty == RT_PATHTYPE:
                self._setdf('pathtype',rec.data[0])
            elif ty == RT_BGNEXTN:
                self._setdf('bgnextn',rec.data[0])
            elif ty == RT_ENDEXTN:
                self._setdf('endextn',rec.data[0])
            else:
                out.append(rec)
        return out
        
    def _gather_records(self, lst):
        "gather records"
        # get the ones from the parent first
        _GeomElement._gather_records(self,lst)
        # add the ones for this element
        if self._hasdf('pathtype'):
            lst.append(build_record(RT_PATHTYPE,self._df('pathtype')))
        if self._hasdf('width'):
            lst.append(build_record(RT_WIDTH,self._df('width')))
        if self._hasdf('bgnextn'):
            lst.append(build_record(RT_BGNEXTN,self._df('bgnextn')))
        if self._hasdf('endextn'):
            lst.append(build_record(RT_ENDEXTN,self._df('endextn')))
    
    
class Text(_GeomElement):
    "TEXT element"
    _record_name = 'Text'
    _starting_record = Record(RT_TEXT,DT_NONE,None)
    _datatype_record = RT_TEXTTYPE
        
    def _process_records(self, records):
        "process records found in reference type elements"
        # process records through the geom element level first 
        remain = _GeomElement._process_records(self,records)
        # remaining records get handled here
        out = []
        strans = None
        mag = None
        angle = None
        for rec in remain:
            ty = rec.type
            if ty == RT_STRING:
                self._setdf('string',rec.data)
            elif ty == RT_PRESENTATION:
                self._setdf('presentation',rec.data)
            elif ty == RT_PATHTYPE:
                self._setdf('pathtype',rec.data[0])
            elif ty == RT_WIDTH:
                self._setdf('width',rec.data[0])
            elif ty == RT_STRANS:
                strans = rec.data
                self._setdf('textmirror',bool(strans & 0x8000))
                self._setdf('_absmag',bool(strans & 0x0004))
                self._setdf('_absang',bool(strans & 0x0002))
            elif ty == RT_MAG:
                self._setdf('textmag',rec.data[0])
            elif ty == RT_ANGLE:
                self._setdf('textang',rec.data[0])
            else:
                out.append(rec)
        return out

    def _gather_records(self, lst):
        "gather element records by appending them to the passed list"
        # get parent records
        _GeomElement._gather_records(self,lst)
        # add text records
        if self._hasdf('presentation'):
            lst.append(build_record(RT_PRESENTATION,self._df('presentation')))
        if self._hasdf('pathtype'):
            lst.append(build_record(RT_PATHTYPE,self._df('pathtype')))
        if self._hasdf('width'):
            lst.append(build_record(RT_WIDTH,self._df('width')))
        # transform records
        flags = 0
        if self._df('textmirror',False):
            flags |= 0x8000
        if self._df('_absmag',False):
            flags |= 0x0004
        if self._df('_absang',False):
            flags |= 0x0002
        lst.extend(Transform(flags,self._df('textmag'),self._df('textang')).records)

    def _gather_postxy_records(self, lst):
        "gather element records by appending them to the passed list"
        lst.append(build_record(RT_STRING,self._df('string')))
        
    def compute_transform(self, xfrm, x0=0, y0=0):
        "compute the passed transform on this element and return a new element"
        newel = _Element.compute_transform(self,xfrm,x0,y0)
        # apply the transform to the text properties
        if not newel._df('_absmag',False):
            m = newel._df('textmag',1.0)
            for x in xfrm._stk:
                m *= x.mag
                if x.absmag:
                    newel._setdf('_absmag',True)
                    break
            if abs(m-1.0) > 0.0001:
                newel._setdf('textmag',m)
        if not newel._df('_absang',False):
            ang = newel._df('textang',0.0)
            for x in xfrm._stk:
                ang += x.angle
                if x.absang:
                    newel._setdf('_absang',True)
                    break
            while ang > 360.0001:
                ang -= 360.0
            if abs(ang) > 0.0001:
                newel._setdf('textang',ang)
        return newel
        
    @property
    def string(self):
        "STRING record data, returns a string"
        return self._df('string',exceptions=True)

    @string.setter
    def string(self, value):
        "setter for STRING record data"
        if not isinstance(value,_str_type):
            raise TypeError("string data required")
        return self._setdf('string',value)
        
    @property
    def pathtype(self):
        "PATHTYPE record data, an integer"
        return self._df('pathtype',0)
        
    @property
    def presentation(self):
        "PRESENTATION record data, an integer"
        return self._df('presentation',0)
    
    @property
    def justify(self):
        "justify setting (0=left, 1=center, 2=right)"
        return self.presentation & 0x0003
        
    @property
    def valign(self):
        "vertical alignment setting (0=top, 1=center, 2=bottom)"
        return (self.presentation & 0x000c) >> 2
    
    @property
    def font(self):
        "font number setting"
        return (self.presentation & 0x0030) >> 4
        
    @property
    def width(self):
        "WIDTH record data, an integer"
        return self._df('width',0)
    
    @property
    def mag(self):
        "MAG record data, a float"
        return self._df('textmag',1.0)
    
    @property
    def angle(self):
        "ANGLE record data, a float"
        return self._df('textang',0.0)
        
class Node(_GeomElement):
    "NODE element"
    _record_name = 'Node'
    _starting_record = Record(RT_NODE,DT_NONE,None)
    _datatype_record = RT_NODETYPE
    
    
class Box(_GeomElement):
    "BOX element"
    _record_name = 'Box'
    _starting_record = Record(RT_BOX,DT_NONE,None)
    _datatype_record = RT_BOXTYPE
        
        
class SRef(_ReferenceElement):
    "SREF element"
    _record_name = 'SRef'
    _starting_record = Record(RT_SREF,DT_NONE,None)
    

class ARef(_ReferenceElement):
    "AREF element"
    _record_name = 'ARef'
    _starting_record = Record(RT_AREF,DT_NONE,None)
    
    def _process_records(self, records):
        "process records found in reference type elements"
        # process records through the reference element level first 
        remain = _ReferenceElement._process_records(self,records)
        # remaining records get handled here
        out = []
        for rec in remain:
            if rec.type == RT_COLROW:
                self._setdf('colrow',tuple(rec.data[:2]))
            else:
                out.append(rec)
        return out
    
    def _gather_records(self, lst):
        "gather element records by appending them to the passed list"
        _ReferenceElement._gather_records(self,lst)
        lst.append(build_record(RT_COLROW,self._df('colrow')))
    
    @property
    def colrow(self):
        "COLROW record data, returns a 2-tuple of integers"
        return self._df('colrow',exceptions=True)

    @colrow.setter
    def colrow(self, value):
        "setter for COLROW record data, must be a 2-tuple of integers"
        if not isinstance(value,tuple) or len(value) != 2:
            raise TypeError("2-tuple of integers required")
        self._setdf('colrow',(int(value[0]),int(value[1])))

        
class Structure(object):
    "GDSII STRUCTURE (cell) container"
    
    __slots__ = ('_name','_timestamps','_elements','_library')
    
    def __init__(self, records):
        "initializer with initial records"
        self._library = None
        self._elements = []
        
        if isinstance(records,Structure):
            # copy constructor
            self._name = records._name
            self._timestamps = records._timestamps[:]
            # don't copy elements here
        else:
            # normal construction
            nrecs = len(records)
            if nrecs < 2:
                raise MissingRequiredRecords("`Structure` object initializer requires at least 2 Records")
            elif nrecs > 4:
                raise InvalidElementRecord("too many Records passed to `Structure` initializer, at most 4 are allowed")
            
            # record 0 must be BGNSTR
            if records[0].type != RT_BGNSTR:
                raise InvalidElementRecord("`Structure` first record must be 'BGNSTR'")
            self._timestamps = records[0].data[:]
            
            # record 1 must be STRNAME
            if records[1].type != RT_STRNAME:
                raise InvalidElementRecord("`Structure` second record must be 'STRNAME'")
            self._name = records[1].data
                        
            # record 2 is optional and can only be STRCLASS though
            # we don't store or propagate it though as it is a Calma-only feature
            if nrecs > 2:
                for rec in records[2:]:
                    if rec.type not in (RT_STRCLASS,RT_ENDSTR):
                        raise InvalidElementRecord("`Structure` cannot contain a record type 0x{0:x}".format(rec.type))
            
    def append_element(self, element):
        "append an element record to the structure"
        if not isinstance(element,_Element):
            raise TypeError("expected `_Element` object")
        element._attach(self)
        self._elements.append(element)

    def append_elements(self, element_list):
        "append an iterable of element records to the structure"
        for el in element_list:
            self.append_element(el)
        
    def _attach(self, library):
        "attach this structure to a Library"
        if not isinstance(library,Library):
            raise TypeError("a `Library` object is required")
        self._library = library
        
    def _detach(self):
        "detach this element from it's Structure"
        self._library = None
        
    @property
    def name(self):
        "structure name"
        return self._name
            
    @property
    def modified_date(self):
        "structure creation date"
        return datetime(*(self._timestamps[:6]))
        
    @property
    def accessed_date(self):
        "structure last modified date"
        return datetime(*(self._timestamps[6:12]))
    
    @property
    def elements(self):
        "the element list"
        return self._elements[:]
    
    @property
    def library(self):
        "the library that this Structure is attached to"
        return self._library
        
    def copy(self, include_elements=False):
        "create a copy of the Structure"
        newst = Structure(self)
        if include_elements:
            for element in self._elements:
                newst.append_element(element.copy())
        return newst
        
    def write_records(self, fp):
        "write records to a file-like object (opened in binary mode)"
        fp.write(build_record(RT_BGNSTR,self._timestamps).binary_record)
        fp.write(build_record(RT_STRNAME,self._name).binary_record)
        for elem in self._elements:
            elem.write_records(fp)
        fp.write(build_record(RT_ENDSTR,None).binary_record)

    def flatten(self, cache={}, only_types=None, only_layers=None):
        """returns a new Structure in which all hierarchy has been flattened
        
        cache must be a dict instance that is used to improve performance by
            caching the flatten operation of Structures that are encountered
            more than once in the hierarchy
        only_types is an optional iterable containing integer element types, if
            present it may contain one or more of the elements with record type
            ids RT_BOUNDARY, RT_BOX, RT_TEXT, RT_NODE, and RT_PATH and only
            elements that match the specified types will be included in the
            flattened structure (all other elements will be dropped)            
        only_layers is an optional iterable containing integer layer numbers, if
            present only elements that match this layer type will be included
            and all other elements will be dropped
        """
        if not isinstance(cache,dict):
            raise TypeError("'cache' must be a dict object")
        
        if only_types is not None:
            if not isinstance(only_types,frozenset):
                only_types = frozenset(only_types)            
        if only_layers is not None:
            if not isinstance(only_layers,frozenset):
                only_layers = frozenset(only_layers)            
            
        newst = self.copy()
        for element in self._elements:
            if isinstance(element,SRef):
                # structure reference object
                if element.sname in cache:
                    struct = cache[element.sname]
                else:
                    struct = element.referenced_structure.flatten(cache=cache,only_types=only_types,only_layers=only_layers)
                    cache[element.sname] = struct
                
                x0, y0 = element.xy[0].x, element.xy[0].y
                xfrm = element.transform
                # compute the transform on each element in the referenced structure
                for el in struct.elements:
                    newel = el.compute_transform(xfrm,x0,y0)
                    self.append_element(newel)
            elif isinstance(element,ARef):
                # array reference element
                if element.sname in cache:
                    struct = cache[element.sname]
                else:
                    struct = element.referenced_structure.flatten(cache=cache,only_types=only_types,only_layers=only_layers)
                    cache[element.sname] = struct
                
                x0, y0 = element.xy[0].x, element.xy[0].y
                xc, yc = element.xy[1].x, element.xy[1].y
                xr, yr = element.xy[2].x, element.xy[2].y
                cols, rows = element.colrow
                xfrm = element.transform
                cinc = (xc - x0)//cols
                rinc = (yr - y0)//rows
                
                # apply the transform to elements in each structure in the array
                for c in range(cols):
                    for r in range(rows):
                        # compute the array transform to get the correct (x0, y0) for 
                        # each structure in the array
                        xa0, ya0 = xfrm.compute((c*cinc,r*rinc),x0,y0)
                        # compute the transform on each element in the referenced structure
                        for el in struct.elements:
                            newel = el.compute_transform(xfrm,xa0,ya0)
                            self.append_element(newel)
            else:
                # other elements are simply copied
                keep = True
                if only_types is not None:
                    if element.type not in only_types:
                        keep = False
                if keep and only_layers is not None:
                    if element.layer not in only_layers:    
                        keep = False
                
                if keep:                
                    newst.append_element(element.copy())
        return newst
        
    def __iter__(self):
        "iterator"
        return iter(self._elements)
        
        
_unsupported_library_records = frozenset([RT_LIBDIRSIZE,RT_SRFNAME,RT_LIBSECUR,RT_REFLIBS,RT_FONTS,
    RT_ATTRTABLE,RT_GENERATIONS,RT_FORMAT,RT_MASK,RT_ENDMASKS,RT_TAPENUM,RT_TAPECODE]),
        
class Library(object):
    "GDSII library"
    
    def __init__(self, records):
        "library initializer"
        self._structures = OrderedDict()
        
        if isinstance(records,Library):
            # copy constructor
            self._version = records._version
            self._timestamps = records._timestamps[:]
            self._libname = records._libname
            self._dbprec = records._dbprec
            self._dbmeters = records._dbmeters
            # don't copy the structures here
        else:
            # normal initialization
            nrecs = len(records)
            if nrecs < 4:
                raise MissingRequiredRecords("`Library` object initializer requires at least 4 Records")
            
            # HEADER record must be first
            if records[0].type != RT_HEADER:
                raise InvalidElementRecord("`Library` first record must be 'HEADER'")
            self._version = records[0].data[0]
            
            # BGNLIB record must be second
            if records[1].type != RT_BGNLIB:
                raise InvalidElementRecord("`Library` second record must be 'BGNLIB'")
            self._timestamps = records[1].data[:]
            
            # read the rest of the records
            dbprec, dbmeters = None, None
            libname = None
            extra = []
            for rec in records[2:]:
                ty = rec.type
                if ty in _unsupported_library_records:
                    # don't support these features
                    # warning?
                    pass
                elif ty == RT_UNITS:
                    dbprec, dbmeters = tuple(rec.data)
                elif ty == RT_LIBNAME:
                    libname = rec.data
                elif ty == RT_ENDLIB:
                    break
                else:
                    extra.append(rec)
            
            if extra:
                raise InvalidElementRecord("{0} extra records passed to the `Library` object initializer".format(len(extra)))
            if dbprec is None:
                raise MissingRequiredRecords("'UNITS' Record is required in the `Library` object initializer")    
            if libname is None:
                raise MissingRequiredRecords("'LIBNAME' Record is required in the `Library` object initializer")    
            
            self._dbprec = dbprec
            self._dbmeters = dbmeters
            self._libname = libname
    
    @staticmethod
    def load(fname):
        "load a new GDSII file"
        return GDSII_File_Reader(fname).get_library()
        
    def save(self, fname):
        "save the library"
        ac = True
        if hasattr(fname,'write') and hasattr(fname.write,'__call__'):
            # file-like object, hopefully it's open in binary mode
            ac = False
            fp = fname
        else:
            fp = io.open(fname,'wb')
        
        try:
            fp.write(build_record(RT_HEADER,self._version).binary_record)
            fp.write(build_record(RT_BGNLIB,self._timestamps).binary_record)
            fp.write(build_record(RT_LIBNAME,self._libname).binary_record)
            fp.write(build_record(RT_UNITS,[self._dbprec,self._dbmeters]).binary_record)
            for struct in self._structures.values():
                struct.write_records(fp)
            fp.write(build_record(RT_ENDLIB,None).binary_record)
        finally:
            if ac:
                fp.close()        
            
    def append_structure(self, struct):
        "append a structure to the list"
        if not isinstance(struct,Structure):
            raise TypeError("expected `Structure` object")
        if struct.name in self._structures:
            raise DuplicateStructure("a structure named '{0}' is already defined".format(struct.name))
        struct._attach(self)
        self._structures[struct.name] = struct
    
    def get_structure_by_name(self, name):
        "get a structure by name or return None if not found"
        try:
            return self._structures[name]
        except KeyError:
            return None
    
    def truncate(self):
        "truncate the library be removing all structures"
        for struct in self._structures.values():
            struct._detach()
        self._structures = OrderedDict()
    
    def copy(self, include_structures=False):
        "create a copy of the Library"
        newlib = Library(self)
        if include_structures:
            for struct in self._structures:
                newst = struct.copy()
                newlib.append_structure(newst)
        return newlib
    
    @property
    def name(self):
        "the library name"
        return self._libname
    
    @property
    def version(self):
        "the library version"
        return self._version
        
    @property
    def dbunit_meters(self):
        "database unit in meters, returns a float"
        return self._dbmeters
    
    @property
    def dbprecision(self):
        "database precision, returns a float generally less than 1"
        return self._dbprec
    user_unit_per_dbunit = dbprecision
        
    @property
    def user_unit_meters(self):
        "user unit in meters, returns a float"
        return self._dbmeters/self._dbprec
                
    @property
    def modified_date(self):
        "structure creation date"
        return datetime(*(self._timestamps[:6]))
        
    @property
    def accessed_date(self):
        "structure last modified date"
        return datetime(*(self._timestamps[6:12]))
        
    def __getitem__(self, name):
        "dictionary access of structures"
        return self._structures[name]
        
# map element record types to the classes that store them        
_record_to_class = {
    RT_BOUNDARY:  Boundary,
    RT_PATH:      Path,
    RT_SREF:      SRef,
    RT_AREF:      ARef,
    RT_TEXT:      Text,
    RT_NODE:      Node,
    RT_BOX:       Box,
}

class GDSII_File_Reader(object):
    "GDSII file"
    
    def __init__(self, fname):
        "read a GDSII file"
        self._lib = None
        self._curstr = None
        self._libdone = False
        self._records = []
        parse_gdsii(fname,callback=self._cb)        
        
    def get_library(self):
        "get the Library object"
        return self._lib
                
    def _cb(self, context, libname, sname, rec):
        "record creator for the parse_gdsii function to call as it reads records"
        record_type = rec.type
        
        if self._libdone:
            raise ParserError("no more records are allowed after an ENDLIB record")
        
        if record_type == RT_BGNSTR:
            # start of a new structure (cell)
            if self._curstr is not None:
                raise ParserError('got a BGNSTR record while already in a structure')
            if self._lib is None:
                # this is the first structure, create the library from accumulated records
                self._lib = Library(self._records)
                self._records = []
            self._records.append(rec)
                
        elif record_type == RT_ENDSTR:
            # end of structure definition
            if self._records:
                # this should only happen when a structure is empty (has no elements)
                if self._curstr:
                    # should not be the case
                    raise ParserError('internal records list should be empty when an ENDSTR record is reached')
                else:
                    s = Structure(self._records)
                    self._records = []
                    self._lib.append_structure(s)
                    
            self._curstr = None
        
        elif record_type in _element_record_types:
            # start of a new element
            if self._curstr is None:
                # this is the first element of a structure
                # create the structure from accumulated records
                self._curstr = Structure(self._records)
                self._records = []
                self._lib.append_structure(self._curstr)
                
            if self._records:
                raise ParserError('internal records list should be empty when a starting element record is reached')
            self._records.append(rec)
                
        elif record_type == RT_ENDEL:
            # end of the current element, create it using accumulated records
            el = self.create_element(self._records)
            self._records = []
            self._curstr.append_element(el)
            
        elif record_type == RT_BGNLIB:
            # start of the library
            if self._lib:
                raise ParserError('got a BGNLIB record while already inside a library')
            self._records.append(rec)
            
        elif record_type == RT_ENDLIB:
            # end of the current library
            if self._records:
                raise ParserError('internal records list should be empty when an ENDLIB record is reached')
            self._libdone = True
            
        else:
            # add any other records to the accumulator
            self._records.append(rec)
            
    @staticmethod
    def create_element(records):
        "create an element from a list of records"
        if not isinstance(records,(list,tuple)) or not len(records) or not isinstance(records[0],Record):
            raise TypeError("a non-empty list or tuple of Record objects is required")
        eltype = records[0].type
        if eltype not in _element_record_types:
            raise ValueError("the first Record must be an element creation record")
        cls = _record_to_class[eltype]
        return cls(records)
        

