"""
GDSII parser object


"""
from __future__ import division, print_function, unicode_literals, absolute_import
import logging, io
import os

from .constants import *
from .errors import *
from .record import Record, _bstr2int, _int_types
    
#############################################################################
#   GDSII Parser
#############################################################################

def parse_gdsii( fp, callback=None, filter=None, filter_out=False, store_records=False,
    record_creator=Record ):
    """Parse a GDSII stream file
    
    """
    if hasattr(fp,'read') and hasattr(fp.read,'__call__'):
        # file-like object passed
        if hasattr(fp,'name'):
            filename = os.path.basename(fp.name)
        else:
            filename = '<stream>'
        ac = False
    else:
        # assume the argument is a file name
        filename = os.path.basename(fp)
        fp = io.open(fp,'rb')
        ac = True
    
    return_records = bool(store_records) or (callback is None)     
    if return_records:
        records = []
    
    bytes_read = 0
    try:
        # check arguments
        if callback and not hasattr(callback,'__call__'):
            raise TypeError("`callback` argument must be callable")
        
        if filter:
            filter_out = bool(filter_out)
            try:
                iter(filter)
            except Exception:
                filter = (filter,)
                
            for f in filter:
                if not isinstance(f,_int_types):
                    raise TypeError("`filter` argument must be a sequence of integers")
                elif f < 0x00 or f > 0x3b:
                    raise ValueError("`filter` values must be in the range 0x00 (0) to 0x3b (59)")
        
        if not hasattr(record_creator,'__call__'):
            raise TypeError("`record_creator` argument must be callable")
                    
        # initialize the context variables 
        context = CTX_NONE
        libname = ''
        sname = ''
                
        # read the first record
        rec, n = _read_gdsii_record(fp,record_creator,filename,bytes_read)
        bytes_read += n
        if not rec:
            raise EmptyFile("{0}[0x{1:x}]: empty file".format(filename,bytes_read))
        rt = rec.record_type
        
        # parse the rest of the file
        while True:
            if context == CTX_ELEM:
                if rt == RT_ENDEL:
                    context = CTX_STRUCT
            elif context == CTX_STRUCT:
                if rt in (RT_BOUNDARY,RT_PATH,RT_SREF,RT_AREF,RT_TEXT,RT_NODE,RT_BOX):
                    context = CTX_ELEM
                elif rt == RT_ENDSTR:
                    context = CTX_LIB
                    sname = ''
                elif rt == RT_STRNAME:
                    sname = rec.decoded_data
            elif context == CTX_LIB:                
                if rt == RT_BGNSTR:
                    context = CTX_STRUCT
                elif rt == RT_ENDLIB:
                    context = CTX_NONE
                    libname = ''
                elif rt == RT_LIBNAME:
                    libname = rec.decoded_data
            elif context == CTX_NONE:
                if rt == RT_BGNLIB:
                    context = CTX_LIB
            else:
                raise Error("{0}[0x{1:x}]: invalid context (bug??)".format(filename,bytes_read))
                            
            ## call the callback
            if filter and ((filter_out and rt in filter) or (not filter_out and rt not in filter)):
                # skip processing this record due to the filter
                pass
            else:
                if callback:
                    callback(context,libname,sname,rec)
                if return_records:
                    records.append(rec)
            
            # read the next record
            rec, n = _read_gdsii_record(fp,record_creator,filename,bytes_read)
            bytes_read += n
            if not rec:
                # end of file
                break
            rt = rec.record_type
        
    finally:
        if ac:
            fp.close()
    
    if return_records:
        return records
    
def _read_gdsii_record(fp, record_creator, fname, offset):
    "Read a single record from the file"
    total_read = 0
    
    # read the first 2 bytes of the record which contain the length
    # if the length is 0 (NULL padding) then move on to the next 2 bytes
    # until a non-zero record length is encountered
    lnrec = 0
    while lnrec == 0:
        h1 = fp.read(2)
        if not h1:
            # end of file
            return None, total_read
        total_read += 2
        lnrec = _bstr2int(h1,size=2,multiple=False)
    
    if lnrec < 4:
        raise BadRecordLength("{0}[0x{1:x}]: illegal record length '{2}' (must be at least 4)".format(fname,offset,lnrec))
    elif lnrec % 2:
        raise BadRecordLength("{0}[0x{1:x}]: illegal record length '{2}' (cannot be odd)".format(fname,offset,lnrec))
    
    # got a valid record length, read the rest of the record
    remain = fp.read(lnrec-2)
    total_read += lnrec - 2
    if len(remain)+2 != lnrec:
        raise EOFError("{0}[0x{1:x}]: incomplete record - expected {2} bytes but only read {3} bytes".format(fname,offset,lnrec,len(remain)+2))
    
    # create the record from the remaining record data
    # first byte is the record type (byte 3 overall)
    # second byte is the record data type (byte 4 overall)
    # remaining bytes are the data payload for the record
    try:
        return record_creator(_bstr2int(remain[:1],size=1,multiple=False),_bstr2int(remain[1:2],size=1,multiple=False),remain[2:]), total_read
    except Exception as ex:
        raise ParserError("{0}[0x{1:x}]: unable to create Record -> {2}: {3}".format(fname,offset,type(ex).__name__,ex))
    
#############################################################################
#   legacy Parser converted to use the functions above to do it's work
#############################################################################

class Parser(object):
    """GDSII stream file parser."""
        
    def __init__(self, fobj, callback=None, **kwargs):
        """Initialize.
        
        fobj must be a file-like object that has a read() method for
           byte-by-byte reading IT MUST BE OPENED IN BINARY MODE
           by using the 'rb' flags to the open() built-in function
           or by whatever method is required for the stream
        """
        self.__records = []
        if hasattr(fobj,'read') and hasattr(fobj.read,'__call__'):
            self.__infile = fobj
            self.__autoclose = False
        else:
            # assume that the passed object is a string indicating the
            # path to the GDSII file
            self.__infile = io.open(fobj,'rb')
            self.__autoclose = True
        
        if callback:
            # automatically run the parse() method
            self.parse(callback,**kwargs)
    
    def parse(self, callback, fltr=None, filter_out=False, force_rewind=False,
        store_records=False):
        """Parse the GDSII stream file.
        
        callback must be a callable object that will be called
           with 4 arguments: (context,lib_name,struct_name,GDSII_Record)
           where context is one of the CTX_* constants, lib_name and struct_name
           are either strings or None depending on the context, and GDSII_Record
           is an object of that type
        fltr is an optional filter that must be a sequence of integer
           record types if specified
        filter_out is a boolean that sets the filter mode to filter out the
           records specified in the fltr argument, the default behavior of
           fltr is to "filter in" the specified records
        force_rewind will try to call the seek() method of the file-like object
           with an argument of 0.  This will fail if the file-like object does
           not support seeking
        store_records will save all parsed records as GDSII_Record objects in an
           array that will be returned by the function, it is also accessible
           through the all_records property of the object. Normally the records
           are not saved and get discarded after being passed to the callback
           function
        """
        self.__records = []
        
        if force_rewind:
            self.__infile.seek(0)
        
        self.__records = parse_gdsii(self.__infile, callback=callback, filter=fltr, filter_out=filter_out, store_records=store_records)
        if not store_records:
            self.__records = []
            
        return self.__records

    def close(self):
        "close the GDSII stream"
        self.__records = []
        if self.__autoclose:
            try:
                self.__infile.close()
            except Exception:
                pass
        self.__infile = None
    
    def __del__(self):
        "cleanup on delete"
        self.close()
                
    @property
    def all_records(self):
        "a list of all parsed Record objects (only valid if 'store_records' was True during parsing)"
        return self.__records[:]
    
    @property
    def num_records(self):
        "the number of GDSII records in the file (only valid if 'store_records' was True during parsing)"
        return len(self.__records)

