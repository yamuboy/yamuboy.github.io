from __future__ import division, print_function, unicode_literals, absolute_import
"""
This file exists to provide backward compatibility for things that
linked to the old version of the GDSII API


"""
from .constants import *
from .errors import *
from .record import Record as GDSII_Record
from .parser import Parser as GDSII_Parser
from .utils import get_cell_names
from .tools import GDSII_Basic_Info, GDSII_Struct_Rewrite, GDSII_Layer_Strip
from .old_info import GDSII_Element, GDSII_Struct, GDSII_Library, GDSII_Info
    
