from __future__ import division, print_function, unicode_literals, absolute_import
import logging
from .record import Record
from .parser import parse_gdsii
from .constants import *
from .errors import *
from . import _str_type

class GDSII_Element(object):
    """GDSII stream element."""
    
    def __init__(self, ty):
        """initializer"""
        if ty not in (RT_BOUNDARY,RT_PATH,RT_SREF,RT_AREF,RT_TEXT,RT_NODE,RT_BOX):
            raise ValueError("invalid element type")
        self.__records = []
        self.__type = ty
    
    def add_rec(self, rec):
        """add a record to the element"""
        if not isinstance(rec,Record):
            raise TypeError("argument must be a Record object")
        self.__records.append(rec)


class GDSII_Struct(object):
    """GDSII stream structure."""
    
    def __init__(self, name=None):
        """initializer"""
        if name is not None and not isinstance(name,_str_type):
            raise TypeError("name must be a string")
            
        self.__name = name or ''
        self.__elements = []
        self.__records = []
    
    def add_elem(self, elem):
        "add an element to the structure"
        if not isinstance(elem,GDSII_Element):
            raise TypeError("argument must be a GDSII_Element object")
        self.__elements.append(elem)
        
    def add_rec(self, rec):
        "add a non-element record"
        if not isinstance(rec,Record):
            raise TypeError("argument must be a Record object")
        self.__records.append(rec)
        
    def _getname(self):
        return self.__name
    def _setname(self,n):
        if not isinstance(n,_str_type):
            raise TypeError("argument must be a string")
        self.__name = n
    name = property(_getname,_setname,None,"structure name")            
    
    
class GDSII_Library(object):
    """GDSII library structure."""
    
    def __init__(self, name=None):
        """Initializer."""
        if name is not None and not isinstance(name,_str_type):
            raise TypeError("name must be a string")
        
        self.__name = name or ''
        self.__structs = []
        self.__records = []
    
    def add_struct(self, struct):
        "add an element to the structure"
        if not isinstance(struct,GDSII_Struct):
            raise TypeError("argument must be a GDSII_Struct object")
        self.__structs.append(struct)
        
    def add_rec(self, rec):
        "add a non-struct, non-element record"
        if not isinstance(rec,Record):
            raise TypeError("argument must be a Record object")
        self.__records.append(rec)
    
    def _getname(self):
        return self.__name        
    def _setname(self, n):
        if not isinstance(n,_str_type):
            raise TypeError("the name must be a string")
        self.__name = n
    name = property(_getname,_setname,None,"library name")
    

class GDSII_Info(object):
    """GDSII file information tool"""
    
    _log = logging.getLogger('gdsiitools.GDSII_Info')
    
    def __init__(self, fp):
        """Parse and compile information about a GDSII stream file."""
        # init the storage
        self.__header = None
        self.__libs = []
        self.__allstructs = []
        self.__allelems = []
        self.__heir = [None,None,None,None]
        
        # call the parser
        parse_gdsii(fp,callback=self._cb)
    
    def parse(self,*args,**kwargs):
        "do nothing (here for backward compatibility)"
        pass
                
    def _cb(self, ctx, libn, strn, rec):
        """Callback for the GDSII_Parser parent class."""
        rt = rec.record_type
        if rt in (RT_ENDEL,RT_ENDSTR,RT_ENDLIB):
            # ignore end tags
            return
        elif rt == RT_HEADER:
            # file header
            self.__header = rec.decoded_data
        elif rt == RT_BGNLIB:
            # start of a new library
            assert ctx == CTX_LIB
            lib = GDSII_Library()
            self.__libs.append(lib)
            self.__heir[ctx] = lib
        elif rt == RT_LIBNAME:
            # library name
            assert ctx == CTX_LIB
            self.__heir[ctx].name = rec.decoded_data
        elif rt == RT_BGNSTR:
            # start of a new structure
            assert ctx == CTX_STRUCT
            st = GDSII_Structure()
            self.__heir[ctx] = st
            self.__heir[ctx-1].add_struct(st)
            self.__allstructs.append(st)
        elif rt == RT_SNAME:
            # structure name
            assert ctx == CTX_STRUCT
            self.__heir[ctx].name = rec.decoded_data
        elif rt in (RT_BOUNDARY,RT_PATH,RT_SREF,RT_AREF,RT_TEXT,RT_NODE,RT_BOX):
            # start of a new element
            assert ctx == CTX_ELEM
            elem = GDSII_Element()
            self.__heir[ctx] = elem
            self.__heir[ctx-1].add_elem(elem)
            self.__allelems.append(elem)
        else:
            # add all other GDSII record types to the current hierarchy element
            assert ctx >= CTX_LIB and ctx <= CTX_ELEM
            self.__heir[ctx].add_rec(rec)
        
