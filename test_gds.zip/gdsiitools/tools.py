"""
GDSII manipulation and information tools

"""
from __future__ import division, print_function, unicode_literals, absolute_import
import logging, datetime, re
from .parser import parse_gdsii
from .constants import *
from .errors import *
from io import StringIO
from . import _str_type

try:
    ustr = unicode
except NameError:
    ustr = str

class GDSII_Basic_Info(object):
    "GDSII basic file information tool"
    
    _log = logging.getLogger('gdsiitools.GDSII_Basic_Info')
    
    class StructStorage(object):
        "store information about GDSII structures"
        def __init__(self, moddate, accessdate):
            "init"
            self.moddate = moddate
            self.accessdate = accessdate
            self.name = ''
            self.nelements = 0
            self.__layers = set()
            self.__parents = set()
            self.__children = {}
        
        def add_layer(self, lynum, dtnum):
            "add a layer to the layer set"
            assert isinstance(lynum,int)
            assert isinstance(dtnum,int)
            data = (lynum,dtnum)
            if data not in self.__layers:
                self.__layers.add(data)
        
        def add_child(self, name):
            "add a child to the list of referenced children"
            assert isinstance(name,_str_type)
            if name not in self.__children:
                self.__children[name] = 0
            self.__children[name] += 1
        
        def add_parent(self, name):
            "add a parent to the set of parents"
            if name not in self.__parents:
                self.__parents.add(name)
        
        @property
        def layers(self):
            "set of layers that are present in the structure"
            return frozenset(self.__layers)
        
        @property
        def parents(self):
            "list of parents of this structure"
            s = list(self.__parents)
            s.sort()
            return s
        
        @property
        def children(self):
            "list of children as 2-tuples -> (name,refcount)"
            names = list(self.__children.keys())
            names.sort()
            return [(n,self.__children[n]) for n in names]
        
        @property
        def num_parents(self):
            "the number of parents that this structure has"
            return len(self.__parents)
            
        @property
        def num_children(self):
            "the number of children that this structure has"
            return len(self.__children)
        
        @property
        def num_layers(self):
            "the number of layers that this structure contains (directly)"
            return len(self.__layers)
        
    def __init__(self, fp, **kwargs):
        """Parse and compile information about a GDSII stream file."""
        
        if 'callback' in kwargs:
            # don't allow a user-specified 'callback' keyword
            raise ValueError("'callback' is not a valid keyword for this object")
        
        # init the storage
        self.__version = -1
        self.__libname = ''
        self.__libmoddate = None
        self.__libaccessdate = None
        self.__units = None
        self.__structs = dict()
        # used for bookkeeping
        self.__currstruct = None
        self.__currlay = -1
        self.__currdt = -1
        
        # run the parser
        parse_gdsii(fp,callback=self._cb,**kwargs)

        # reconcile all parents after all elements now exist
        for name in self.__structs:
            struct = self.__structs[name]
            for child,count in struct.children:
                if child not in self.__structs:
                    raise ValueError("in structure '%s' -> invalid reference to structure '%s'"%(name,child))
                self.__structs[child].add_parent(name)
    
    def parse(self,*args,**kwargs):
        "do nothing, already parsed (here for backward compatibility)"        
        pass
        
    def _cb(self, ctx, libn, strn, rec):
        """Callback for the GDSII_Parser parent class."""
        rt = rec.record_type
        if rt == RT_HEADER:
            # file header with version info
            self.__version = rec.decoded_data[0]
        elif rt == RT_BGNLIB:
            # start of a new library
            if self.__libname:
                raise ValueError("GDSII stream contains more than 1 library")
            self.__libmoddate = datetime.datetime(*(rec.decoded_data[:6]))
            self.__libaccessdate = datetime.datetime(*(rec.decoded_data[6:]))
        elif rt == RT_LIBNAME:
            # library name
            self.__libname = rec.decoded_data
        elif rt == RT_UNITS:
            # library name
            self.__units = tuple(rec.decoded_data[:])
        elif rt == RT_BGNSTR:
            # start of a new structure
            moddate = datetime.datetime(*(rec.decoded_data[:6]))
            accessdate = datetime.datetime(*(rec.decoded_data[6:]))
            self.__currstruct = self.StructStorage(moddate,accessdate)
        elif rt == RT_STRNAME:
            assert self.__currstruct is not None
            self.__currstruct.name = rec.decoded_data
        elif rt == RT_SNAME:
            # structure name in an SREF or AREF element
            assert self.__currstruct is not None
            self.__currstruct.add_child(rec.decoded_data)
        elif rt in (RT_BOUNDARY,RT_PATH,RT_TEXT,RT_NODE,RT_BOX,RT_SREF,RT_AREF):
            # start of a new element
            assert self.__currstruct is not None
            self.__currstruct.nelements += 1
            self.__currlay = -1
            self.__currdt = -1
        elif rt == RT_LAYER:
            assert self.__currstruct is not None
            self.__currlay = rec.decoded_data[0]
        elif rt in (RT_DATATYPE,RT_BOXTYPE,RT_TEXTTYPE,RT_NODETYPE):
            assert self.__currstruct is not None
            self.__currdt = rec.decoded_data[0]
        elif rt == RT_ENDSTR:
            # store the current structure
            assert self.__currstruct is not None
            assert self.__currstruct.name != ''
            self.__structs[self.__currstruct.name] = self.__currstruct
        elif rt == RT_ENDEL:
            # end of element, store layer data
            if self.__currlay != -1:
                self.__currstruct.add_layer(self.__currlay,self.__currdt)
            
    @property
    def version(self):
        "GDSII file version"
        return self.__version
    
    @property
    def libname(self):
        "library name"
        return self.__libname
    
    @property
    def libmoddate(self):
        "library modification date"
        return self.__libmoddate

    @property
    def libaccessdate(self):
        "library access date"
        return self.__libaccessdate
    
    @property
    def units(self):
        "units as a 2-tuple -> (db_unit_in_user_units,db_unit_in_meters)"
        return self.__units
    
    @property
    def snames(self):
        "a list of the names of all structures in the file"
        s = list(self.__structs.keys())
        s.sort()
        return s
    
    @property
    def all_layers(self):
        "get a list of all layers in the file"
        s = set()
        for struct in self.__structs.values():
            s |= struct.layers
        r = list(s)
        r.sort()
        return r
           
    def __getitem__(self,name):
        "dictionary-like access of structure data by structure name"
        return self.__structs[name]
    
    def show_hierarchy(self, indent='   ', linesep='\n'):
        "show the hierarchy of the file, returns a string"
        
        def _hier_recurse(fp, struct, level):
            "recurse heirarachy"
            fp.write((indent*level)+struct.name+linesep)
            for sname,count in struct.children:
                _hier_recurse(fp,self.__structs[sname],level+1)
        
        if not len(self.__structs):
            return ''
        
        # find all top-level structures
        tl = []
        for sname in self.snames:
            s = self[sname]
            if s.num_parents == 0:
                tl.append(s)
        assert len(tl) > 0
        
        # start printing the heirarchy
        fp = StringIO()
        for i,s in enumerate(tl):
            if i > 0:
                fp.write(linesep)
            _hier_recurse(fp,s,0)
        s = fp.getvalue()
        fp.close()
        
        return s
    
    def show_fancy_hierarchy(self, linesep='\n'):
        "show the hierarchy of the file, returns a string"
        
        def _hier_recurse(fp, struct, indstr, tl=False, last_child=False):
            "recurse heirarachy"
            if tl:
                locstr = ''
                addstr = ''
            else:
                if last_child:
                    locstr = '`-- '
                    addstr = '    '
                else:
                    locstr = '|-- '
                    addstr = '|   '
            
            fp.write(indstr+locstr+struct.name+linesep)
            nch = struct.num_children
            
            for i,data in enumerate(struct.children):
                sname = data[0]
                lch = False
                if i == nch-1:
                    lch = True
                _hier_recurse(fp,self.__structs[sname],indstr+addstr,last_child=lch)
        
        if not len(self.__structs):
            return ''
        
        # find all top-level structures
        tl = []
        for sname in self.snames:
            s = self[sname]
            if s.num_parents == 0:
                tl.append(s)
        assert len(tl) > 0
        
        # start printing the heirarchy
        fp = StringIO()
        for i,s in enumerate(tl):
            if i > 0:
                fp.write(linesep)
            _hier_recurse(fp,s,'',tl=True)
        s = fp.getvalue()
        fp.close()
        
        return s

     
class GDSII_Struct_Rewrite(object):
    """Re-write structure names and references in a GDSII stream file."""
    
    _log = logging.getLogger('gdsiitools.GDSII_Struct_Rewrite')
    _legal_prefix = re.compile(r'^[a-z0-9_]+$',re.I)
    _legal_strname = re.compile(r'^[a-z0-9_?$]+$',re.I)
    
    def rewrite(self, in_fname, out_fname, **kwargs):
        """Perform the re-write of structure names and references.
        
        in_fname - string or file-like object, the input file name or file object (opened in 'rb' mode)
        out_fname - string or file-like object, the output file name or file object (opened in 'wb' mode)
        
        Keywords:
        ---------------------------------------------
        prefix
        strprefix
        
        suffix
        strsuffix
        
        rewrite_map
        
        truncate_beginning
        
        """
        
        prefix = kwargs.pop('prefix',None)
        if prefix is None:
            prefix = kwargs.pop('strprefix',None)
        suffix = kwargs.pop('suffix',None)
        if suffix is None:
            suffix = kwargs.pop('strsuffix',None)
        rewrite_map = kwargs.pop('rewrite_map',None)
                
        if prefix is not None:
            prefix = ustr(prefix)
            if not self._legal_prefix.match(prefix):
                raise ValueError("'prefix' is not a valid prefix string")
            elif len(prefix) > 8:
                raise ValueError("'prefix' cannot be longer than 8 characters")            
        
        if suffix is not None:
            suffix = ustr(suffix)
            if not self._legal_prefix.match(suffix):
                raise ValueError("'suffix' is not a valid suffix string")
            elif len(suffix) > 8:
                raise ValueError("'suffix' cannot be longer than 8 characters")            
                
        if rewrite_map is not None:
            if not isinstance(rewrite_map,dict):
                raise TypeError("'rewrite_map' must be a dictionary")
        
        # define runtime variables
        self.__prefix = prefix
        self.__suffix = suffix
        self.__rewrite_map = rewrite_map
        self.__namemap = dict()
        self.__uid = 5001
        self.__truncate_begin = bool(kwargs.get('truncate_beginning',False))
        
        # open the output file
        if hasattr(out_fname,'write') and hasattr(out_fname.write,'__call__'):
            self.__outfile = out_fname
            acout = False
        else:
            self.__outfile = open(out_fname,'wb')
            acout = True
            
        try:
            # run the parser
            parse_gdsii(in_fname,callback=self._cb)            
        finally:
            if acout:
                self.__outfile.close()
            self.__outfile = None
        
        # delete the runtime variables
        del self.__prefix
        del self.__suffix
        del self.__rewrite_map
        del self.__namemap
        del self.__uid
               
    def _cb(self, ctx, libn, strn, rec):
        """Callback for the GDSII_Parser."""
        # for certain records, make modifications
        rt = rec.record_type
        if rt == RT_SNAME:
            # this is a structure name record found within an SREF or AREF record
            sname = self._get_new_name(rec.decoded_data)
            if sname != rec.decoded_data:
                self._log.info("rewriting reference '%s' => '%s'"%(rec.decoded_data,sname))
                rec.decoded_data = sname
        elif rt == RT_STRNAME:
            # this is a structure name record that names a structure
            sname = self._get_new_name(rec.decoded_data)
            if sname != rec.decoded_data:
                self._log.info("rewriting structure name '%s' => '%s'"%(rec.decoded_data,sname))
                rec.decoded_data = sname
        
        # write the record back out to the file
        self.__outfile.write(rec.binary_record)
        
    def _get_new_name(self, name):
        """Get a new name for the input name."""
        if name in self.__namemap:
            # name has already been rewritten, so use the new name that
            # is already in the name map
            return self.__namemap[name]
        else:
            # might need to rewrite the name
            pre = ''
            post = ''
            if self.__prefix:
                pre = self.__prefix
            if self.__suffix:
                post = self.__suffix
            base = name
                
            # check for mapping rewrites
            if self.__rewrite_map and name in self.__rewrite_map:
                base = ustr(self.__rewrite_map[name])
            
            # combine prefix, suffix, and mapping re-writes
            n = pre+base+post
            
            if len(n) > 32:
                # the resulting name is too long!!!
                # re-write it as a generic name
                self._log.debug("during re-write of '%s' to '%s' => resulting name was too long"%(name,n))
                maxln = 32 - (len(pre) + len(post) + 7)
                if self.__truncate_begin:
                    # truncate the beginning of the base name
                    n = pre+('A%0.4d_'%self.__uid)+base[-maxln:]+post
                else:
                    # truncate the end of the base name
                    n = pre+('A%0.4d_'%self.__uid)+base[:maxln]+post
                self.__uid += 1
                self._log.debug("   -> unique name generator was used to generate '%s'"%n)
            
            # store and return the re-written name
            self.__namemap[name] = n
            return n


class GDSII_Layer_Strip(object):
    """Tool for stripping unwanted layers from a GDSII file."""
    _log = logging.getLogger('gdsiitools.GDSII_Layer_Strip')
    
    def __init__(self, fp):
        "initializer"
        self.__fp = fp
        self.__stats = dict()
    
    def run(self, outfp, lylist=[], filter_out=True):
        """run the layer strip utility
        
        outfp is a file object to write the new GDSII file to or it can
          be a string indicating the path of the file to open for writing
        
        Keywords:
        lylist is a list of layer numbers (integers) to filter
        filter_out is a flag indicating whether the layers in the list
          should be filtered out (True, the default) or filtered in
        """
        self.__stats = dict()
        self.__elem = None
        if not isinstance(lylist,list):
            raise TypeError("'lylist' must be a list")
        for ly in lylist:
            if not isinstance(ly,int):
                raise TypeError("'lylist' must be a list of integers")
        self.__lylist = lylist
        self.__fltrout = bool(filter_out)        
        
        # open the output file
        if hasattr(outfp,'write') and hasattr(outfp.write,'__call__'):
            self.__outfp = outfp
            ac = False
        else:
            self.__outfp = open(outfp,'wb')
            ac = True       
        
        try:
            parse_gdsii(self.__fp,callback=self._cb)
        finally:
            if ac:
                self.__outfp.close()
            del self.__elem
            del self.__lylist
            del self.__fltrout        
            
    def _cb(self, ctx, libn, strn, rec):
        "callback for the parser"
        ty = rec.record_type
        if ty in (RT_BOUNDARY,RT_PATH,RT_SREF,RT_AREF,RT_TEXT,RT_NODE,RT_BOX):
            # start of an element
            if self.__elem is not None:
                raise GDSII_Error("parse error: intersecting elements")
            self.__elem = [rec]
        elif ty == RT_ENDEL:
            # end of an element
            self.__elem.append(rec)
            # scan the element for a layer record and decide whether to
            # keep or discard the entire element
            keep = True
            for r in self.__elem:
                if r.record_type == RT_LAYER:
                    ly = r.decoded_data[0]
                    if (self.__fltrout and ly in self.__lylist) or (not self.__fltrout and ly not in self.__lylist):
                        keep = False
                        break
            if not keep:
                # element is filtered out
                ty = self.__elem[0].record_type
                # keep stats on the number of filtered elements of each type
                if ty not in self.__stats:
                    self.__stats[ty] = 1
                else:
                    self.__stats[ty] += 1
            else:
                # element is not filtered, write the records to the GDSII file
                for r in self.__elem:
                    self.__outfp.write(r.binary_record)
            self.__elem = None
        else:
            # either in or outside of an element
            if self.__elem is not None:
                # inside an element, store the record for later
                self.__elem.append(rec)                
            else:
                # outside of an element
                # write data directly to the output file
                self.__outfp.write(rec.binary_record)
    
    @property
    def stats(self):
        "statistics on filtered elements"
        return self.__stats.copy()

    
