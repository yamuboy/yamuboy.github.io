from __future__ import division, print_function, unicode_literals, absolute_import
# set up a null logging handler for default setups
import logging as _logging
if hasattr(_logging,'NullHandler'):
    _h = _logging.NullHandler()
else:
    class _NullHandler(_logging.Handler):    
        def emit(self, record):
            pass
    _h = _NullHandler()
_logging.getLogger('gdsiitools').addHandler(_h)

# python 2/3 compatibility
try:
    _str_type = basestring
except NameError:
    _str_type = str
try:
    _int_types = (int,long)
except NameError:
    _int_types = (int,)
    
# import the bits and pieces
from .constants import *
from .errors import *
from .record import Record
from .parser import Parser, parse_gdsii
from .utils import get_cell_names
from .tools import GDSII_Basic_Info, GDSII_Struct_Rewrite, GDSII_Layer_Strip

# high level interface
from .highlevel import Library, Structure, SRef, ARef, Text, Node, Boundary, Box, Path

# these are for backward compatibility
GDSII_Record = Record
GDSII_Parser = Parser 
from .old_info import GDSII_Element, GDSII_Struct, GDSII_Library, GDSII_Info
