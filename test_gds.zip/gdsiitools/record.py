from __future__ import unicode_literals, absolute_import, division, print_function
import struct
from .constants import *
from .errors import *
from . import _int_types

#############################################################################
#   GDSII Record
#############################################################################

_rec_header_fmt = struct.Struct(b'>HBB')

class Record(object):
    """A single GDSII record from a GDSII stream file."""
    
    # use slots to save space
    __slots__ = ('__recty','__dataty','__convdata','__rawdata')
    
    def __init__(self, record_type, data_type, data, binary_data=True):
        "initializer"
        if not isinstance(record_type,_int_types):
            raise TypeError("`record_type` (argument 1) must be an integer")
        if not isinstance(data_type,_int_types):
            raise TypeError("`data_type` (argument 2) must be an integer")
        
        self.__recty = int(record_type)
        if self.__recty not in RECORD_MAP:
            raise BadRecordType("`record_type` is not valid")
        
        self.__dataty = int(data_type)
        if self.__dataty not in DATA_TYPE_MAP:
            raise BadDataType("`data_type` is not valid")
     
        self.__convdata = None
        if binary_data:
            # data is in binary form
            if data_type is DT_NONE:
                self.__rawdata = b''       
            else:
                # check that the binary data is in the correct format
                if not isinstance(data,bytes):
                    raise InvalidPayload("record data payload must be a binary string")
                elif len(data)%2:
                    raise InvalidPayload("record data payload cannot have an odd length")     
                self.__rawdata = data
        else:
            # data must be converted to binary
            self.__rawdata = b''
            self.decoded_data = data
            
    @property
    def record_type(self):
        "GDSII record type, an integer from 0 to 59"
        return self.__recty
    type = record_type
    
    @property
    def data_type(self):
        "GDSII record data type, an integer from 0 to 6"
        return self.__dataty
                
    @property
    def raw_data(self):
        "the raw binary data payload of the record, a binary string"
        return self.__rawdata
        
    def _getdecodeddata(self):
        if self.__convdata is None and self.__dataty != DT_NONE:
            # need to convert the raw data
            dt = self.__dataty
            if dt == DT_BITS:
                # 2-byte bit field
                self.__convdata = _bstr2int(self.__rawdata, size=2, multiple=False)
            elif dt == DT_SHORT:
                # a list of 2-byte signed int
                self.__convdata = _bstr2int(self.__rawdata, size=2, signed=True)
            elif dt == DT_INT:
                # a list of 4-byte signed int
                self.__convdata = _bstr2int(self.__rawdata, size=4, signed=True)
            elif dt == DT_FLOAT:
                # a list of 4-byte float
                self.__convdata = _bstr2float(self.__rawdata)
            elif dt == DT_DOUBLE:
                # a list of 8-byte float
                self.__convdata = _bstr2double(self.__rawdata)
            elif dt == DT_STRING:
                # string
                self.__convdata = self.__rawdata.decode('latin-1').rstrip('\x00')
            
        return self.__convdata
        
    def _setdecodeddata(self, data):
        # need to convert the decoded data to binary data
        dt = self.__dataty
        self.__convdata = None
        if dt == DT_NONE:
            if data:
                raise InvalidPayload("records with the data type 'none(0)' cannot have a data payload")
        elif dt == DT_BITS:
            # 2-byte bit field
            self.__rawdata = _int2bstr(data, size=2, multiple=False)
        elif dt == DT_SHORT:
            # list of 2-byte signed int
            self.__rawdata = _int2bstr(data, size=2, signed=True)
        elif dt == DT_INT:
            # list of 4-byte signed int
            self.__rawdata = _int2bstr(data, size=4, signed=True)
        elif dt == DT_FLOAT:
            # list of 4-byte float
            self.__rawdata = _float2bstr(data)
        elif dt == DT_DOUBLE:
            # list of 8-byte float
            self.__rawdata = _double2bstr(data)
        elif dt == DT_STRING:
            # string
            if len(data) % 2:
                data += '\x00'
            self.__rawdata = data.encode('latin-1')
        else:
            # invalid data type
            raise BadDataType("record data type is invalid")
    
    decoded_data = property(_getdecodeddata,_setdecodeddata,None,"the decoded data payload of the record, can be None, a string, or a list of integers or floats.")
    data = decoded_data
    
    @property
    def binary_record(self):
        "The complete binary record, ready to be written to a GDSII stream file"
        b = self.__rawdata
        return _rec_header_fmt.pack(len(b)+4, self.__recty, self.__dataty) + b
    
    @property
    def name(self):
        "name of the record"
        return get_record_name(self.__recty)

    @property
    def verbose_name(self):
        "verbose name of the record"
        return get_record_name(self.__recty,True)
        
    def __str__(self):
        "string representation"
        s = self.name
        data = self.decoded_data
        if data is not None:
            s += ' -> ' + repr(data)
        return s
    
    def __len__(self):
        "length of the binary record"
        return 4+len(self.__rawdata)
            
    def copy(self):
        "create a copy of the record"
        return Record(self.__recty,self.__dataty,self.__rawdata)
            
# backward compatibility
GDSII_Record = Record

class NullRecord(Record):
    "special empty Record object"

    def __init__(self, *args, **kwargs):
        "initializer"
        Record.__init__(self,RT_NULL,DT_NONE,None)
    
    @property
    def binary_record(self):
        "complete binary record, ready to be written to a GDSII stream file"
        # as this record is completely empty (and invalid as a GDSII stream
        # record), this function returns an empty binary string
        return b''
        
    def __len__(self):
        "length of the binary record"
        return 0
        
def build_record(recty, data):
    "build a Record object from a record type and some data"
    # get the data type for the record type
    try:
        dataty = RECORD_TYPE_TO_DATA_TYPE[recty]
    except KeyError:
        raise ValueError("invalid record type")
    
    # create and return the record
    return Record(recty,dataty,data,False)
    
#############################################################################
#   data conversion helpers
#############################################################################

_conv_uint8 = struct.Struct('>B')
_conv_int8 = struct.Struct('>b')
_conv_uint16 = struct.Struct('>H')
_conv_int16 = struct.Struct('>h')
_conv_uint32 = struct.Struct('>I')
_conv_int32 = struct.Struct('>i')

# these don't work: GDSII uses a non-standard float format
#_conv_float = struct.Struct('>f')
#_conv_double = struct.Struct('>d')

_conv_gdsii_float = struct.Struct('>BBH')
_conv_gdsii_double = struct.Struct('>BBHI')
_float_den = 2.0**-24
_double_den = 2.0**-56
_2_e_16 = 1<<16
_2_e_32 = 1<<32
_2_e_48 = 1<<48

def _unpack_float(s, idx=0):
    "Unpack a float that is formatted in the ugly GDSII 32-bit float format"
    s2 = s[idx:idx+4]
    if len(s2) != 4:
        raise ValueError("hit end of string")
    exp,i2,i3 = _conv_gdsii_float.unpack(s2)
    sgn = 1.0
    if exp > 127:
        sgn = -1.0
        exp -= 128
    m = i2*_2_e_16 + i3
    return sgn*m*_float_den*(16.0**(exp-64))
    
def _unpack_double(s, idx=0):
    "Unpack a double that is formatted in the ugly GDSII 64-bit float format"
    s2 = s[idx:idx+8]
    if len(s2) != 8:
        raise ValueError("hit end of string")
    exp,i2,i3,i4 = _conv_gdsii_double.unpack(s2)
    sgn = 1.0
    if exp > 127:
        sgn = -1.0
        exp -= 128
    m = i2*_2_e_48 + i3*_2_e_32 + i4
    return sgn*m*_double_den*(16.0**(exp-64))

def _scale_float(f):
    "scale a float/double value in preparation for converting to binary"
    sgn = 0
    if f < 0.0:
        sgn = 1
        f = abs(f)
    elif f == 0.0:
        # exactly 0.0
        return 64, 0.0
    
    # scale the float
    exp = 64
    if f >= 1.0:
        # float is 1.0 or larger, reduce the exponent until it is less than 1.0
        while f >= 1.0:
            if exp == 127:
                break
            f *= 0.0625
            exp += 1
    else:
        # float is less than 1.0, increase the exponent until it is as close
        # as possible to 1.0 but still less than 1.0
        d = f
        while d < 1.0:
            if exp == 0:
                break
            d *= 16.0
            if d < 1.0:
                f = d
                exp -= 1
                    
    # check for inconsistency
    if f >= 1.0:
        raise ValueError("overflow in exponent")
    
    if sgn:
        # add the sign bit
        exp += 128
        
    return exp, f
    
def _pack_float(f):
    "pack a float into the ugly GDSII 32-bit float format"
    
    # get the exponent byte and scaled mantissa
    exp, fs = _scale_float(f)
    
    # turn the mantissa into bits
    m = 0
    for i in range(24):
        m = m << 1
        if fs != 0.0:
            fs *= 2.0
            if fs >= 1.0:
                m += 1
                fs -= 1.0
    
    # return the packed results
    i1 = (m & 0x00ff0000)>>16
    i2 = m & 0x0000ffff
    return _conv_gdsii_float.pack(exp,i1,i2)

def _pack_double(f):
    "pack a double into the ugly GDSII 64-bit float format"
    
    # get the exponent byte and scaled mantissa
    exp, fs = _scale_float(f)
    
    # turn the mantissa into bits
    m = 0
    for i in range(56):
        m = m << 1
        if fs != 0.0:
            fs *= 2.0
            if fs >= 1.0:
                m += 1
                fs -= 1.0
    
    # return the packed results
    i1 = (m & 0xff000000000000)>>48
    i2 = (m & 0x00ffff00000000)>>32
    i3 = m & 0x000000ffffffff
    return _conv_gdsii_double.pack(exp,i1,i2,i3)

def _bstr2int(x, size=2, signed=False, multiple=True):
    """convert a binary string to a list of integer values
    
    size    indicates the number of bytes for each integer: 1, 2, or 4
    signed  indicated signed format (2's compliment)
    """
    if size == 1:
        if signed:
            fmt = _conv_int8
        else:
            fmt = _conv_uint8
    elif size == 2:
        if signed:
            fmt = _conv_int16
        else:
            fmt = _conv_uint16
    elif size == 4:
        if signed:
            fmt = _conv_int32
        else:
            fmt = _conv_uint32
    else:
        raise ValueError("invalid integer size.")
    
    ln = len(x)
    if multiple:
        if ln % size:
            raise ValueError("illegal data length: must be divisible by {0}".format(size))
        i = 0    
        ret = []
        while i < ln:
            ret.extend(fmt.unpack_from(x,i))
            i += size
        return ret
    else:
        if ln != size:
            raise ValueError("illegal data length: must be exactly {0} bytes".format(size))
        return fmt.unpack(x)[0]
    
def _bstr2float(x):
    "convert a binary string to a list of floats (32-bit format)"
    size = 4
    ln = len(x)
    if ln % size:
        raise ValueError("illegal data length: must be divisible by %d"%size)

    i = 0
    ret = []
    while i < ln:
        ret.append(_unpack_float(x,i))
        i += size
    return ret    
    
def _bstr2double(x):
    "convert a binary string to a list of floats (64-bit format)"
    size = 8
    ln = len(x)
    if ln % size:
        raise ValueError("illegal data length: must be divisible by %d"%size)

    i = 0
    ret = []
    while i < ln:
        ret.append(_unpack_double(x,i))
        i += size
    return ret    
     
def _int2bstr(x, size=2, signed=False, multiple=True):
    """convert a list of integers to a binary string
    
    size    indicates the number of bytes for each integer: 1, 2, or 4
    signed  indicated signed format (2's compliment)    
    """
    
    if size == 1:
        if signed:
            fmt = _conv_int8
        else:
            fmt = _conv_uint8
    elif size == 2:
        if signed:
            fmt = _conv_int16
        else:
            fmt = _conv_uint16
    elif size == 4:
        if signed:
            fmt = _conv_int32
        else:
            fmt = _conv_uint32
    else:
        raise ValueError("invalid integer size")

    if multiple:
        # convert single values into an iterable
        try:
            iter(x)
        except Exception:
            x = (x,)
            
        ret = bytearray()
        for i,n in enumerate(x):
            if not isinstance(n,_int_types):
                raise TypeError("element at list index {0} is not an integer".format(i))
            ret.extend(fmt.pack(n))
        return bytes(ret)
    else:
        if not isinstance(x,_int_types):
            raise TypeError("argument must be an integer")
        return fmt.pack(x)
    
def _float2bstr(x):
    "convert a list of floats to a binary string (32-bits each)"
    # convert single values into an iterable
    try:
        iter(x)
    except Exception:
        x = (x,)
        
    ret = bytearray()
    for n in x:
        ret.extend(_pack_float(n))
    return bytes(ret)
    
def _double2bstr(x):
    "convert a list of floats to a binary string (64-bits each)"
    # convert single values into an iterable
    try:
        iter(x)
    except Exception:
        x = (x,)
        
    ret = bytearray()
    for n in x:
        ret.extend(_pack_double(n))
    return bytes(ret)
        