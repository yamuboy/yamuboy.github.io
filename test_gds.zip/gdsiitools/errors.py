from __future__ import division, print_function, unicode_literals, absolute_import

#############################################################################
#   GDSII exception
#############################################################################

class Error(Exception):
    "base error"
    pass
    
class EmptyFile(Error):
    "data file had not valid records"
    pass
    
class BadRecordLength(Error):
    "record has an invalid length"
    pass
    
class BadDataType(Error):
    "record has a bad or incorrect data type"
    pass
    
class BadRecordType(Error):
    "record has an invalid record type"
    pass
    
class XYInvalidLength(Error):
    "XY record has an invalid length"
    pass
    
class EOFError(Error):
    "got an EOF in the middle of a record"
    pass
    
class MissingRequiredRecords(Error):
    "an element has a missing required records"
    pass
    
class InvalidElementRecord(Error):
    "an element has a record that is invalid for its type"
    pass

class DuplicateRecord(Error):
    "an element has a duplicate record"
    pass
    
class DuplicateStructure(Error):
    "a library has a duplicate structure name"
    pass
    
class UnattachedElement(Error):
    "an element object that is not attached to a structure attempted to resolve a reference"
    pass
    
class UnattachedStructure(Error):
    "a structure object that is not attached to a Library attempted to resolve a reference"
    pass

class TransformError(Error):
    "a structure object that is not attached to a Library attempted to resolve a reference"
    pass
    
class ParserError(Error):
    "an error was encountered while parsing the GDSII file"
    pass
    
class InvalidStructureReference(Error):
    "an element has a duplicate record"
    pass
    
# backward compatibility    
GDSII_Error = Error
