from __future__ import division, print_function, unicode_literals, absolute_import
#############################################################################
#    GDSII record types
#############################################################################

RT_HEADER =       0x00
RT_BGNLIB =       0x01
RT_LIBNAME =      0x02
RT_UNITS =        0x03
RT_ENDLIB =       0x04
RT_BGNSTR =       0x05
RT_STRNAME =      0x06
RT_ENDSTR =       0x07
RT_BOUNDARY =     0x08
RT_PATH =         0x09
RT_SREF =         0x0a
RT_AREF =         0x0b
RT_TEXT =         0x0c
RT_LAYER =        0x0d
RT_DATATYPE =     0x0e
RT_WIDTH =        0x0f
RT_XY =           0x10
RT_ENDEL =        0x11
RT_SNAME =        0x12
RT_COLROW =       0x13
RT_TEXTNODE =     0x14
RT_NODE =         0x15
RT_TEXTTYPE =     0x16
RT_PRESENTATION = 0x17
RT_SPACING =      0x18
RT_STRING =       0x19
RT_STRANS =       0x1a
RT_MAG =          0x1b
RT_ANGLE =        0x1c
RT_UINTEGER =     0x1d
RT_USTRING =      0x1e
RT_REFLIBS =      0x1f
RT_FONTS =        0x20
RT_PATHTYPE =     0x21
RT_GENERATIONS =  0x22
RT_ATTRTABLE =    0x23
RT_STYPTABLE =    0x24
RT_STRTYPE =      0x25
RT_ELFLAGS =      0x26
RT_ELKEY =        0x27
RT_LINKTYPE =     0x28
RT_LINKKEYS =     0x29
RT_NODETYPE =     0x2a
RT_PROPATTR =     0x2b
RT_PROPVALUE =    0x2c
RT_BOX =          0x2d
RT_BOXTYPE =      0x2e
RT_PLEX =         0x2f
RT_BGNEXTN =      0x30
RT_ENDEXTN =      0x31
RT_TAPENUM =      0x32
RT_TAPECODE =     0x33
RT_STRCLASS =     0x34
RT_RESERVED =     0x35
RT_FORMAT =       0x36
RT_MASK =         0x37
RT_ENDMASKS =     0x38
RT_LIBDIRSIZE =   0x39
RT_SRFNAME =      0x3a
RT_LIBSECUR =     0x3b
# special record type used by this package
# for NULL records that contain no data
RT_NULL =         0xff

#############################################################################
#   GDSII data types
#############################################################################

DT_NONE =     0
DT_BITS =     1
DT_SHORT =    2
DT_INT =      3
DT_FLOAT =    4
DT_DOUBLE =   5
DT_STRING =   6

#############################################################################
#   Mapping of GDSII record types to names
#############################################################################

RECORD_MAP = {
    RT_HEADER:       'HEADER',
    RT_BGNLIB:       'BGNLIB',
    RT_LIBNAME:      'LIBNAME',
    RT_UNITS:        'UNITS',
    RT_ENDLIB:       'ENDLIB',
    RT_BGNSTR:       'BGNSTR',
    RT_STRNAME:      'STRNAME',
    RT_ENDSTR:       'ENDSTR',
    RT_BOUNDARY:     'BOUNDARY',
    RT_PATH:         'PATH',
    RT_SREF:         'SREF',
    RT_AREF:         'AREF',
    RT_TEXT:         'TEXT',
    RT_LAYER:        'LAYER',
    RT_DATATYPE:     'DATATYPE',
    RT_WIDTH:        'WIDTH',
    RT_XY:           'XY',
    RT_ENDEL:        'ENDEL',
    RT_SNAME:        'SNAME',
    RT_COLROW:       'COLROW',
    RT_TEXTNODE:     'TEXTNODE',
    RT_NODE:         'NODE',
    RT_TEXTTYPE:     'TEXTTYPE',
    RT_PRESENTATION: 'PRESENTATION',
    RT_SPACING:      'SPACING',
    RT_STRING:       'STRING',
    RT_STRANS:       'STRANS',
    RT_MAG:          'MAG',
    RT_ANGLE:        'ANGLE',
    RT_UINTEGER:     'UINTEGER',
    RT_USTRING:      'USTRING',
    RT_REFLIBS:      'REFLIBS',
    RT_FONTS:        'FONTS',
    RT_PATHTYPE:     'PATHTYPE',
    RT_GENERATIONS:  'GENERATIONS',
    RT_ATTRTABLE:    'ATTRTABLE',
    RT_STYPTABLE:    'STYPTABLE',
    RT_STRTYPE:      'STRTYPE',
    RT_ELFLAGS:      'ELFLAGS',
    RT_ELKEY:        'ELKEY',
    RT_LINKTYPE:     'LINKTYPE',
    RT_LINKKEYS:     'LINKKEYS',
    RT_NODETYPE:     'NODETYPE',
    RT_PROPATTR:     'PROPATTR',
    RT_PROPVALUE:    'PROPVALUE',
    RT_BOX:          'BOX',
    RT_BOXTYPE:      'BOXTYPE',
    RT_PLEX:         'PLEX',
    RT_BGNEXTN:      'BGNEXTN',
    RT_ENDEXTN:      'ENDEXTN',
    RT_TAPENUM:      'TAPENUM',
    RT_TAPECODE:     'TAPECODE',
    RT_STRCLASS:     'STRCLASS',
    RT_RESERVED:     'RESERVED',
    RT_FORMAT:       'FORMAT',
    RT_MASK:         'MASK',
    RT_ENDMASKS:     'ENDMASKS',
    RT_LIBDIRSIZE:   'LIBDIRSIZE',
    RT_SRFNAME:      'SRFNAME',
    RT_LIBSECUR:     'LIBSECUR',
    RT_NULL:         'NULL',
}

def get_record_name(rt, include_number=False):
    "get the record name as a string"
    name = RECORD_MAP.get(rt,'UNKNOWN')
    if include_number:
        return "{0}(0x{1:x})".format(name,rt)
    return name
        

#############################################################################
#   Mapping of GDSII data types to names
#############################################################################

DATA_TYPE_MAP = {
    DT_NONE:   'none',
    DT_BITS:   'bitfield',
    DT_SHORT:  'short',
    DT_INT:    'int',
    DT_FLOAT:  'float',
    DT_DOUBLE: 'double',
    DT_STRING: 'string',
}

def get_record_datatype(dt, include_number=False):
    "get the record datatype as a string"
    dtype = DATA_TYPE_MAP.get(dt,'unknown')
    if include_number:
        return "{0}({1})".format(dtype,dt)
    return dtype


#############################################################################
#   Parser contexts
#############################################################################

CTX_NONE =    0
CTX_LIB =     1
CTX_STRUCT =  2
CTX_ELEM =    3

#############################################################################
#   Record type to data type mapping (each record type only supports a
#     single data type, which is redundant, but part of the standard)
#############################################################################

RECORD_TYPE_TO_DATA_TYPE = {
    RT_HEADER:       DT_SHORT,
    RT_BGNLIB:       DT_SHORT,
    RT_LIBNAME:      DT_STRING,
    RT_UNITS:        DT_DOUBLE,
    RT_ENDLIB:       DT_NONE,
    RT_BGNSTR:       DT_SHORT,
    RT_STRNAME:      DT_STRING,
    RT_ENDSTR:       DT_NONE,
    RT_BOUNDARY:     DT_NONE,
    RT_PATH:         DT_NONE,
    RT_SREF:         DT_NONE,
    RT_AREF:         DT_NONE,
    RT_TEXT:         DT_NONE,
    RT_LAYER:        DT_SHORT,
    RT_DATATYPE:     DT_SHORT,
    RT_WIDTH:        DT_INT,
    RT_XY:           DT_INT,
    RT_ENDEL:        DT_NONE,
    RT_SNAME:        DT_STRING,
    RT_COLROW:       DT_SHORT,
    RT_TEXTNODE:     DT_NONE,
    RT_NODE:         DT_NONE,
    RT_TEXTTYPE:     DT_SHORT,
    RT_PRESENTATION: DT_BITS,
    RT_SPACING:      DT_NONE,    # discontinued (unknown type)
    RT_STRING:       DT_STRING,
    RT_STRANS:       DT_BITS,
    RT_MAG:          DT_DOUBLE,
    RT_ANGLE:        DT_DOUBLE,
    RT_UINTEGER:     DT_INT,
    RT_USTRING:      DT_STRING,
    RT_REFLIBS:      DT_STRING,
    RT_FONTS:        DT_STRING,
    RT_PATHTYPE:     DT_SHORT,
    RT_GENERATIONS:  DT_SHORT,
    RT_ATTRTABLE:    DT_STRING,
    RT_STYPTABLE:    DT_STRING,  # unreleased feature
    RT_STRTYPE:      DT_SHORT,   # unreleased feature
    RT_ELFLAGS:      DT_BITS,
    RT_ELKEY:        DT_INT,     # unreleased feature
    RT_LINKTYPE:     DT_SHORT,   # unreleased feature
    RT_LINKKEYS:     DT_INT,     # unreleased feature
    RT_NODETYPE:     DT_SHORT,
    RT_PROPATTR:     DT_SHORT,
    RT_PROPVALUE:    DT_STRING,
    RT_BOX:          DT_NONE,
    RT_BOXTYPE:      DT_SHORT,
    RT_PLEX:         DT_INT,
    RT_BGNEXTN:      DT_INT,
    RT_ENDEXTN:      DT_INT,
    RT_TAPENUM:      DT_SHORT,
    RT_TAPECODE:     DT_SHORT,
    RT_STRCLASS:     DT_BITS,
    RT_RESERVED:     DT_INT,
    RT_FORMAT:       DT_SHORT,
    RT_MASK:         DT_STRING,
    RT_ENDMASKS:     DT_NONE,
    RT_LIBDIRSIZE:   DT_SHORT,
    RT_SRFNAME:      DT_STRING,
    RT_LIBSECUR:     DT_SHORT,
    RT_NULL:         DT_NONE,
}

