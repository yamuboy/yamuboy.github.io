"""
802.11ax (HE-SU) baseband waveform generation + memory-polynomial DPD test bench.

Configuration as built:
  - HE-SU, 20 MHz, 242-tone RU (full-band): 234 data + 8 pilot + 3 DC null + 11 guard
  - MCS2  -> QPSK constellation (coding rate 3/4 does not change the RF envelope,
            so it is omitted; the data field is filled with random QPSK symbols)
  - 256-pt FFT, 78.125 kHz spacing, 0.8 us GI (16-sample CP at the 20 MHz base rate)
  - Frequency-domain zero-pad oversampling by OSR -> fs = OSR * 20 MHz
  - PA: memory polynomial. Static term is an LS fit to a smooth, monotonic Rapp
        AM/AM + mild AM/PM (invertible); m>=1 taps are small rotated copies giving
        nonlinear (dispersive) memory.
  - DPD: memory-polynomial via the Indirect Learning Architecture (ILA)

Author scaffold for Nishant's DPD investigation. Tune the marked knobs freely.
"""

import numpy as np
from numpy.fft import fft, ifft, fftshift
from scipy.signal import lfilter, welch

rng = np.random.default_rng(0)

# ----------------------------------------------------------------------------
# 1. 802.11ax 20 MHz subcarrier plan (logical index k = -128 .. +127)
# ----------------------------------------------------------------------------
NFFT_BASE = 256
BW = 20e6
DF = BW / NFFT_BASE          # 78.125 kHz subcarrier spacing

PILOTS = np.array([-116, -90, -48, -22, 22, 48, 90, 116])
DC_NULL = np.array([-1, 0, 1])
GUARD = np.concatenate([np.arange(-128, -122), np.arange(123, 128)])  # 6 left + 5 right

_used = np.arange(-122, 123)                       # -122..122 inclusive
_excl = np.concatenate([DC_NULL, PILOTS])
DATA_IDX = np.array([k for k in _used if k not in _excl])   # 234 data tones
assert DATA_IDX.size == 234, DATA_IDX.size

# QPSK (MCS0-2 modulation), unit average power, Gray mapped
_QPSK = np.array([1 + 1j, 1 - 1j, -1 + 1j, -1 - 1j]) / np.sqrt(2)


def he_symbol_freq():
    """Build one HE 20 MHz frequency-domain symbol (length 256, logical order)."""
    X = np.zeros(NFFT_BASE, dtype=complex)
    # logical index k -> array position (k mod 256)
    def pos(k):
        return k % NFFT_BASE
    data_syms = _QPSK[rng.integers(0, 4, DATA_IDX.size)]
    for k, s in zip(DATA_IDX, data_syms):
        X[pos(k)] = s
    pil = rng.choice([-1.0, 1.0], PILOTS.size)        # +/-1 pilot polarity
    for k, s in zip(PILOTS, pil):
        X[pos(k)] = s
    return X, data_syms


def generate_he_waveform(n_sym=80, osr=8, gi_samples_base=16, t_tr_ns=100):
    """Return oversampled complex baseband, fs, and metadata for demod/EVM.

    Applies the 802.11 raised-cosine inter-symbol windowing (transition T_TR)
    via overlap-add so the clean waveform meets a realistic spectral mask and
    PA-induced regrowth is the dominant out-of-band term.
    """
    nup = NFFT_BASE * osr
    cp_up = gi_samples_base * osr
    fs = BW * osr
    wtr = max(2, int(round(t_tr_ns * 1e-9 * fs)))     # transition length (samples)

    # raised-cosine window for an extended symbol of length sym_len + wtr
    sym_len = nup + cp_up
    ext_len = sym_len + wtr
    w = np.ones(ext_len)
    ramp = 0.5 * (1 - np.cos(np.pi * (np.arange(wtr) + 0.5) / wtr))
    w[:wtr] = ramp
    w[-wtr:] = ramp[::-1]

    out = np.zeros(n_sym * sym_len + wtr, dtype=complex)
    tx_data = []
    for s in range(n_sym):
        Xb, dsyms = he_symbol_freq()
        tx_data.append(dsyms)
        Xup = np.zeros(nup, dtype=complex)
        for b in range(NFFT_BASE):               # base bin -> oversampled bin
            k = b if b < 128 else b - NFFT_BASE
            Xup[k % nup] = Xb[b]
        t = ifft(Xup) * osr
        # extended symbol: [CP | body | head], windowed, overlap-added by wtr
        ext = np.concatenate([t[-cp_up:], t, t[:wtr]]) * w
        i0 = s * sym_len
        out[i0:i0 + ext_len] += ext

    x = out[:n_sym * sym_len]                     # drop trailing tail
    x = x / np.sqrt(np.mean(np.abs(x) ** 2))      # unit RMS
    meta = dict(osr=osr, nup=nup, cp_up=cp_up, fs=fs, n_sym=n_sym, wtr=wtr,
                tx_data=np.array(tx_data), data_idx=DATA_IDX)
    return x, fs, meta


# ----------------------------------------------------------------------------
# 2. Power amplifier model (Wiener-Hammerstein, soft saturation + memory)
# ----------------------------------------------------------------------------
class PAModel:
    """Memory-polynomial PA: y(n) = sum_m sum_k c[k,m] x(n-m) |x(n-m)|^(k-1).

    The static (m=0) coefficients are LS-fit to a smooth, monotonic Rapp AM/AM
    plus mild AM/PM, guaranteeing an invertible compression curve. The m>=1 taps
    are small rotated copies giving *nonlinear* memory (dispersive IMD) that a
    memoryless DPD cannot remove.
    """
    def __init__(self, vsat=1.5, p=2.0, ampm=0.20,
                 mem=((0.12, 0.6), (0.06, 1.2))):
        self.orders = [1, 3, 5, 7]
        # fit static odd-order polynomial to a smooth, monotonic complex AM/AM-AM/PM
        r = np.linspace(1e-3, 1.9, 400)
        g = 1.0 / (1.0 + (r / vsat) ** (2 * p)) ** (1.0 / (2 * p))     # Rapp gain
        phase = ampm * r ** 2 / (1.0 + (r / vsat) ** 2)
        target = r * g * np.exp(1j * phase)
        V = np.column_stack([r ** k for k in self.orders])
        c0, *_ = np.linalg.lstsq(V, target, rcond=None)               # static coeffs
        C = np.zeros((len(self.orders), 1 + len(mem)), dtype=complex)
        C[:, 0] = c0
        for j, (amp, ph) in enumerate(mem, start=1):
            C[:, j] = c0 * amp * np.exp(1j * ph)                       # nonlinear memory taps
        self.C = C

    def __call__(self, x):
        y = np.zeros_like(x, dtype=complex)
        absx = np.abs(x)
        for mi in range(self.C.shape[1]):
            xm = np.roll(x, mi); am = np.roll(absx, mi)
            xm[:mi] = 0; am[:mi] = 0
            for ki, k in enumerate(self.orders):
                c = self.C[ki, mi]
                if c != 0:
                    y += c * xm * am ** (k - 1)
        return y


# ----------------------------------------------------------------------------
# 3. Memory-polynomial DPD via Indirect Learning Architecture
# ----------------------------------------------------------------------------
def mp_basis(u, K_orders, M):
    """Columns: u(n-m)*|u(n-m)|^(k-1) for k in K_orders (odd), m in 0..M."""
    cols = []
    absu = np.abs(u)
    for m in range(M + 1):
        um = np.roll(u, m)
        am = np.roll(absu, m)
        um[:m] = 0
        am[:m] = 0
        for k in K_orders:
            cols.append(um * am ** (k - 1))
    return np.column_stack(cols)


class MemoryPolyDPD:
    def __init__(self, K=7, M=3, ridge=1e-3):
        self.K_orders = list(range(1, K + 1, 2))   # odd orders 1,3,5,7
        self.M = M
        self.ridge = ridge
        self.theta = None

    def apply(self, x):
        Phi = mp_basis(x, self.K_orders, self.M)
        return Phi @ self.theta

    def train(self, pa, x_desired, iters=4):
        """ILA: learn predistorter so PA(DPD(x)) ~= G*x. Returns the linear gain G."""
        G = np.vdot(x_desired, pa(x_desired)) / np.vdot(x_desired, x_desired)
        G = np.abs(G)                              # target linear gain
        x_in = x_desired.copy()
        for _ in range(iters):
            y = pa(x_in)
            z = y / G                              # PA output referred to input
            Phi = mp_basis(z, self.K_orders, self.M)
            # ridge-regularized LS: postinverse maps PA-output(z) -> PA-input(x_in)
            A = Phi.conj().T @ Phi
            A += self.ridge * np.trace(A) / A.shape[0] * np.eye(A.shape[0])
            self.theta = np.linalg.solve(A, Phi.conj().T @ x_in)
            x_in = self.apply(x_desired)           # predistort the desired signal
        return G


# ----------------------------------------------------------------------------
# 4. Metrics: ACLR and post-equalization EVM
# ----------------------------------------------------------------------------
def measure_aclr(x, fs, ch_bw=20e6, nperseg=4096):
    f, Pxx = welch(x, fs=fs, nperseg=nperseg, return_onesided=False,
                   detrend=False, scaling='density')
    f = fftshift(f)
    Pxx = fftshift(Pxx)

    def band_power(lo, hi):
        m = (f >= lo) & (f < hi)
        return np.trapezoid(Pxx[m], f[m])

    main = band_power(-ch_bw / 2, ch_bw / 2)
    adj_l = band_power(-1.5 * ch_bw, -0.5 * ch_bw)
    adj_u = band_power(0.5 * ch_bw, 1.5 * ch_bw)
    alt_l = band_power(-2.5 * ch_bw, -1.5 * ch_bw)
    alt_u = band_power(1.5 * ch_bw, 2.5 * ch_bw)
    aclr1 = 10 * np.log10(0.5 * (adj_l + adj_u) / main)   # adjacent
    aclr2 = 10 * np.log10(0.5 * (alt_l + alt_u) / main)   # alternate adjacent
    return aclr1, aclr2, (f, Pxx)


def measure_evm(y, x_ref, meta, G=1.0):
    """OFDM-demod the PA output, per-subcarrier equalize against TX, return EVM %."""
    osr, nup, cp_up = meta['osr'], meta['nup'], meta['cp_up']
    n_sym, didx = meta['n_sym'], meta['data_idx']
    sym_len = nup + cp_up
    # estimate integer sample delay (PA/DPD FIR group delay) via FFT xcorr
    L = min(len(y), len(x_ref))
    xc = np.fft.ifft(np.fft.fft(y[:L]) * np.conj(np.fft.fft(x_ref[:L])))
    lag = int(np.argmax(np.abs(xc)))
    if lag > L // 2:
        lag -= L
    lag = int(np.clip(lag, 0, sym_len))
    y = y[lag:]

    rx, tx = [], []
    for s in range(n_sym):
        start = s * sym_len + cp_up
        if start + nup > len(y):
            break
        Yup = fft(y[start:start + nup]) / osr
        # logical k -> nup bin; gather data subcarriers
        rx_k = np.array([Yup[k % nup] for k in didx])
        rx.append(rx_k)
        tx.append(meta['tx_data'][s])
    rx = np.array(rx)
    tx = np.array(tx)
    # 1-tap per-subcarrier equalizer (removes linear amplitude/phase response)
    H = np.sum(rx * np.conj(tx), axis=0) / np.sum(np.abs(tx) ** 2, axis=0)
    rx_eq = rx / H
    err = rx_eq - tx
    evm = np.sqrt(np.mean(np.abs(err) ** 2) / np.mean(np.abs(tx) ** 2))
    return 100.0 * evm


def papr_db(x):
    p = np.abs(x) ** 2
    return 10 * np.log10(np.max(p) / np.mean(p))


def cfr(x, fs, papr_target_db=7.5, bw=22e6, iters=6):
    """Clip-and-filter crest factor reduction. Caps PAPR, keeps clip noise in-band.

    Lowers the dynamic range the DPD must linearize, preventing gain-expansion
    runaway. Trade: adds a small in-band EVM floor (the CFR/quantization of peaks).
    """
    x = x.copy()
    rms = np.sqrt(np.mean(np.abs(x) ** 2))
    thr = rms * 10 ** (papr_target_db / 20)
    N = len(x)
    f = np.fft.fftfreq(N, 1 / fs)
    mask = np.abs(f) <= bw / 2                       # keep clip noise within the channel
    for _ in range(iters):
        a = np.abs(x)
        over = a > thr
        if not np.any(over):
            break
        clipped = x.copy()
        clipped[over] = x[over] / a[over] * thr
        noise = x - clipped
        noise_ib = np.fft.ifft(np.fft.fft(noise) * mask)   # band-limit the correction
        x = x - noise_ib
    return x
