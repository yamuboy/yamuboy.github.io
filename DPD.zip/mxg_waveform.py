#!/usr/bin/env python3
"""
mxg_waveform.py — manual path utilities
=======================================
Use these when you want to bypass the UXA PA-mode loop and run your own
host-side DPD (e.g., your existing memory-polynomial test bench):

  1. download_iq()      : push a numpy complex I/Q vector into the MXG
                          volatile ARB (WFM1:) and play it.
  2. wlan_evm()         : standalone EVM via the UXA WLAN mode
                          (N9077 Modulation Analysis, :READ:EVM1?).
  3. capture_iq_pamp()  : raw pre/post-DPD I/Q from PA mode
                          (:FETCh:PAMPlifier15? / 16?) for offline
                          model extraction.

Waveform encoding rules (from "Creating and Downloading Waveform
Files", 9018-05434):
  * 16-bit signed integers, BIG-ENDIAN byte order
  * I and Q interleaved: I0,Q0,I1,Q1,...
  * download with  MMEM:DATA "WFM1:<name>",<IEEE-488.2 block>
  * select + play: :SOUR:RAD:ARB:WAV "WFM1:<name>", :SOUR:RAD:ARB:STAT ON,
                   :OUTP:MOD ON, :OUTP ON
  * minimum waveform length and a multiple-of-N samples requirement
    apply (N5182B: multiple of 2, >= 60 samples).
"""

import numpy as np
import pyvisa


# ----------------------------------------------------------------------
# 1. Direct ARB download to the MXG
# ----------------------------------------------------------------------
def encode_iq_int16_be(iq: np.ndarray, full_scale: float = 1.0) -> bytes:
    """Interleave I/Q and encode as big-endian int16 (MXG requirement).

    iq          : complex baseband vector, |iq| <= full_scale
    full_scale  : value mapped to DAC full scale (32767)
    """
    iq = np.asarray(iq, dtype=np.complex128) / full_scale
    peak = np.max(np.abs(np.concatenate([iq.real, iq.imag])))
    if peak > 1.0:
        raise ValueError(f"I/Q exceeds full scale by {20*np.log10(peak):.2f} dB")

    interleaved = np.empty(2 * iq.size, dtype=">i2")     # big-endian int16
    interleaved[0::2] = np.round(iq.real * 32767).astype(">i2")
    interleaved[1::2] = np.round(iq.imag * 32767).astype(">i2")
    return interleaved.tobytes()


def download_iq(mxg, iq: np.ndarray, name: str, sample_rate_hz: float,
                freq_hz: float | None = None, power_dbm: float | None = None,
                play: bool = True):
    """Download complex I/Q to MXG volatile memory (WFM1:) and play.

    mxg : pyvisa resource (write_termination must NOT corrupt binary —
          pyvisa's write_binary_values handles the block formatting).
    """
    if iq.size < 60 or iq.size % 2:
        raise ValueError("MXG ARB requires >= 60 samples, multiple of 2")

    payload = encode_iq_int16_be(iq)

    mxg.write(":SOURce:RADio:ARB:STATe OFF")
    # IEEE-488.2 definite-length block download into volatile memory
    mxg.write_binary_values(
        f'MMEM:DATA "WFM1:{name}",',
        payload, datatype="B", is_big_endian=False,  # raw bytes, pre-encoded
    )
    mxg.query("*OPC?")

    # ARB sample clock for playback
    mxg.write(f":SOURce:RADio:ARB:SCLock:RATE {sample_rate_hz}")

    if freq_hz is not None:
        mxg.write(f":SOURce:FREQuency {freq_hz}")
    if power_dbm is not None:
        mxg.write(f":SOURce:POWer {power_dbm}")

    # ALC off for high-PAPR signals; use power-search instead
    mxg.write(":SOURce:POWer:ALC:STATe OFF")

    if play:
        mxg.write(f':SOURce:RADio:ARB:WAVeform "WFM1:{name}"')
        mxg.write(":SOURce:RADio:ARB:STATe ON")
        mxg.write(":OUTPut:MODulation:STATe ON")
        mxg.write(":OUTPut:STATe ON")
    mxg.query("*OPC?")

    err = mxg.query(":SYSTem:ERRor?").strip()
    if not err.startswith(("0,", "+0,")):
        raise RuntimeError(f"MXG error after download: {err}")


# ----------------------------------------------------------------------
# 2. Standalone WLAN-mode EVM on the UXA (N9077)
# ----------------------------------------------------------------------
WLAN_EVM_KEYS = [  # first 12 of the 60 scalars from :READ:EVM1?
    "rms_evm_max_db", "rms_evm_avg_db", "peak_evm_max_db", "peak_evm_avg_db",
    "max_peak_evm_index", "peak_evm_index",
    "freq_err_max_hz", "freq_err_avg_hz",
    "freq_err_max_ppm", "freq_err_avg_ppm",
    "sym_clk_err_max_ppm", "sym_clk_err_avg_ppm",
]


def wlan_evm(uxa, center_freq_hz: float, standard: str = "AX80",
             ext_atten_db: float = 0.0) -> dict:
    """One-shot 802.11 Modulation Analysis (EVM) in WLAN mode.

    standard      : AX20|AX40|AX80|AX160|AC80|N40|... (N9077 enum)
    ext_atten_db  : output-path loss (probe+pad+cable) entered as
                    External Gain = -loss so burst powers refer to the
                    probe tip.
    """
    uxa.write(":INSTrument:SELect WLAN")
    uxa.query("*OPC?")
    uxa.write(":CONFigure:EVM:NDEFault")
    uxa.write(f":SENSe:RADio:STANdard {standard}")
    uxa.write(f":SENSe:FREQuency:CENTer {center_freq_hz}")
    # external gain (negative of loss) re-references reported power
    uxa.write(f":CORRection:SA:GAIN {-abs(ext_atten_db)}")
    uxa.query("*OPC?")

    vals = [float(x) for x in uxa.query(":READ:EVM1?").split(",")]
    out = dict(zip(WLAN_EVM_KEYS, vals[:12]))
    out["rms_evm_avg_pct"] = vals[33]     # index 34 (1-based) = RMS EVM Avg %
    out["avg_burst_pwr_dbm"] = vals[19]   # index 20 = Avg Burst Power Avg
    out["data_evm_avg_db"] = vals[29]     # index 30 = Data EVM Avg (dB)
    return out


# ----------------------------------------------------------------------
# 3. Raw I/Q capture out of PA mode for offline DPD extraction
# ----------------------------------------------------------------------
def capture_iq_pamp(uxa, post_dpd: bool = False) -> np.ndarray:
    """Fetch raw interleaved I/Q (pre- or post-DPD) from a completed
    PA-mode acquisition and return it as a complex vector.

    Feed this + your transmitted reference into your own
    memory-polynomial LS fit, then download the predistorted waveform
    with download_iq() — your existing Python DPD bench plugs in here.
    """
    n = 16 if post_dpd else 15
    raw = uxa.query_ascii_values(f":FETCh:PAMPlifier{n}?",
                                 container=np.ndarray)
    return raw[0::2] + 1j * raw[1::2]
