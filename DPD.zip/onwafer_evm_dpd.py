#!/usr/bin/env python3
"""
On-wafer PA EVM + DPD measurement
=================================
Keysight UXA (N9040B/N9042B) Power Amplifier mode (N9055EM0C)
controlling a Keysight MXG/EXG X-Series vector signal generator
(N5182B/N5172B) over LAN.

Architecture
------------
The UXA PA mode orchestrates the full measurement:

    MXG --[cable + bias tee + input probe]--> DUT (on wafer)
    DUT --[output probe + attenuator + cable]--> UXA

  1. UXA connects to the MXG (LAN) and pushes the reference waveform
     plus frequency / power / ALC / runtime-scaling settings.
  2. UXA captures the DUT output, time-aligns it against the reference,
     extracts the DPD model (memory polynomial here), predistorts the
     waveform, re-downloads it to the MXG, and iterates.
  3. Pre- and post-DPD EVM, ACP, gain, crest factor, AM/AM and AM/PM
     are all available from a single :READ:PAMPlifier[n]? family.

All SCPI below is taken from:
  - "Power Amplifier Mode User's & Programmer's Reference" (N9055EM0C)
  - "X-Series Signal Generators Programming Guide" (MXG)
  - "Creating and Downloading Waveform Files" (9018-05434, for the
    optional manual waveform download path in mxg_waveform.py)

On-wafer specifics handled here
-------------------------------
  * Loss In  = SG output -> probe tip   (cable + bias tee + RF probe)
  * Loss Out = probe tip -> UXA input   (RF probe + pad + cable)
    -> these move the power reference planes to the DUT pads, so
       Power In / Power Out / Gain are reported at the wafer plane.
  * :PAMP:POW:IN:MAX caps the drive the servo may apply — protects a
    fragile wafer-level device from overdrive.
  * :SOUR:PRES:OFF 1 forces MXG RF OFF after any measurement preset —
    no surprise full-power CW hitting an unbiased die.
  * Power servo converges delivered PA output power (as seen at the
    de-embedded plane) before DPD extraction.

Requires: pyvisa  (pip install pyvisa pyvisa-py, or use Keysight IO Libs)
"""

import sys
import time
import logging
from dataclasses import dataclass, field

import pyvisa

log = logging.getLogger("onwafer_dpd")
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")


# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------
@dataclass
class TestConfig:
    # --- Instrument addresses -----------------------------------------
    uxa_visa: str = "TCPIP0::192.168.0.10::hislip0::INSTR"
    mxg_ip: str = "192.168.0.20"        # PA mode connects by IP/hostname

    # --- DUT / RF plan -------------------------------------------------
    center_freq_hz: float = 7.125e9     # carrier at the DUT reference plane
    pa_gain_est_db: float = 22.0        # rough small-signal gain estimate
    pa_max_pin_dbm: float = 5.0         # absolute drive cap at the input pad
    target_pin_dbm: float = -8.0        # PAINput mode target (at input pad)
    power_control: str = "PAINput"      # "PAINput" or "PAOutput"
    target_pout_dbm: float = 14.0       # used when power_control = PAOutput
    servo: bool = True                  # power servo before extraction
    servo_tol_db: float = 0.2

    # --- On-wafer path de-embedding (positive numbers = loss, dB) ------
    loss_in_db: float = 3.1             # SG -> input probe tip @ f0
    loss_out_db: float = 23.4           # output probe tip -> UXA
                                        #   (probe 1.4 + 20 dB pad + 2.0 cable)

    # --- Reference waveform ---------------------------------------------
    # Signal Studio (.wfm) file already on the UXA disk (LOCal), e.g. a
    # 802.11ax 80 MHz HE-SU burst, or a USER .bin/.csv/.mat I/Q file.
    waveform_type: str = "SSWaveform"   # SSWaveform | USER | MVARiable
    waveform_path: str = (
        r"D:\Users\Instrument\Documents\waveforms\11ax_80M_MCS11.wfm"
    )
    runtime_scaling_pct: float = 70.0   # WLAN default per PA mode manual

    # --- Standard / EVM --------------------------------------------------
    radio_std: str = "AX80"             # 802.11ax 80 MHz preset in PA mode
    evm_format: str = "WLAN"            # needs N9077 WLAN app installed
    report_evm_db: bool = True

    # --- DPD model --------------------------------------------------------
    dpd_algorithm: str = "MPOLynomial"  # LUT | MPOLynomial | VOLTerra | GMP
    memory_order: int = 3
    nonlinear_order: int = 7
    odd_only: bool = True
    iterations: int = 3
    measure_iterations: bool = True     # log EVM/ACP/gain per iteration
    single_extraction: bool = False     # re-extract at every power step

    # --- Misc --------------------------------------------------------------
    timeout_ms: int = 300_000           # DPD iterations are slow; be generous
    csv_out: str = "dpd_results.csv"


# ----------------------------------------------------------------------
# Thin instrument wrapper
# ----------------------------------------------------------------------
class UXA:
    def __init__(self, visa_addr: str, timeout_ms: int):
        rm = pyvisa.ResourceManager()
        self.inst = rm.open_resource(visa_addr)
        self.inst.timeout = timeout_ms
        self.inst.read_termination = "\n"
        self.inst.write_termination = "\n"
        idn = self.query("*IDN?")
        log.info("UXA: %s", idn.strip())

    def write(self, cmd: str):
        log.debug(">> %s", cmd)
        self.inst.write(cmd)

    def query(self, cmd: str) -> str:
        log.debug("?? %s", cmd)
        return self.inst.query(cmd)

    def opc(self, cmd: str | None = None):
        """Blocking, *OPC?-synchronized write."""
        if cmd:
            self.write(cmd)
        self.query("*OPC?")

    def check_errors(self, context: str = ""):
        errs = []
        while True:
            e = self.query(":SYSTem:ERRor?").strip()
            if e.startswith("0,") or e.startswith("+0,"):
                break
            errs.append(e)
        if errs:
            for e in errs:
                log.warning("SCPI error %s: %s", f"({context})" if context else "", e)
        return errs


# ----------------------------------------------------------------------
# Measurement sequence
# ----------------------------------------------------------------------
def setup_pa_mode(u: UXA, cfg: TestConfig):
    """Select PA mode, connect the MXG, set frequency and protections."""
    u.opc("*CLS;*RST")

    # PA mode (mode id 'PA', mode number 81), PAMP measurement
    u.opc(":INSTrument:SELect PA")
    u.opc(":CONFigure:PAMPlifier:NDEFault")

    # --- Wafer-safety first: RF off after preset, before anything else
    u.write(":SENSe:SOURce:PRESet:OFF 1")        # power-on persistent
    u.write(":SENSe:SOURce:RFOutput OFF")

    # --- Connect the MXG (must already be in the SG list or reachable IP)
    u.opc(f':SENSe:SOURce:CONNect "{cfg.mxg_ip}"')
    state = u.query(":SENSe:SOURce:CONNect:STATe?").strip()
    if state not in ("1", "+1", "ON"):
        raise RuntimeError(
            f"PA mode failed to connect to signal generator at {cfg.mxg_ip}"
        )
    sg = u.query(":SENSe:SOURce:CONNect:NAME?").strip()
    log.info("Connected signal generator: %s", sg)

    # --- Frequency: analyzer center freq couples to SG when AUTO
    u.write(f":SENSe:FREQuency:CENTer {cfg.center_freq_hz}")
    u.write(":SENSe:SOURce:FREQuency:AUTO ON")

    # --- ALC OFF: mandatory for high-PAPR OFDM through a compressing DUT
    u.write(":SENSe:SOURce:ALC OFF")

    u.check_errors("setup")


def setup_radio_and_waveform(u: UXA, cfg: TestConfig):
    """Radio-standard preset (carriers/ACP/EVM coupling) + reference wfm."""
    # Radio Std preset configures carriers, ACP offsets, EVM coupling.
    # AX80 = 802.11ax 80 MHz; EVM uses the N9077 WLAN engine.
    u.opc(f":SENSe:PAMPlifier:RADio:STANdard {cfg.radio_std}")
    u.write(f":SENSe:PAMPlifier:EVM:FORMat {cfg.evm_format}")
    u.write(":SENSe:PAMPlifier:EVM:STATe ON")
    u.write(f":SENSe:PAMPlifier:EVM:REPort:DB {'ON' if cfg.report_evm_db else 'OFF'}")

    # --- Reference waveform: local file on the UXA, exported to the MXG
    u.write(f":SENSe:SOURce:WAVeform:TYPE {cfg.waveform_type}")
    if cfg.waveform_type == "SSWaveform":
        u.write(":SENSe:SOURce:WAVeform:LOCation LOCal")
    u.opc(f':SENSe:SOURce:WAVeform:NAME "{cfg.waveform_path}"')

    srate = float(u.query(":SENSe:SOURce:WAVeform:SRATe?"))
    npts = int(float(u.query(":SENSe:SOURce:WAVeform:IQCount?")))
    log.info("Reference waveform: %.3f MHz sample rate, %d samples",
             srate / 1e6, npts)

    # DAC headroom for OFDM (PA-mode preset for WLAN formats is 70 %)
    u.write(f":SENSe:SOURce:RUNTime:SCALing {cfg.runtime_scaling_pct}")

    # Push waveform + settings to the MXG
    u.opc(":SENSe:SOURce:WAVeform:EXPort:IMMediate")
    u.opc(":SENSe:SOURce:SETTings:APPLy")
    u.check_errors("radio/waveform")


def setup_onwafer_power_plan(u: UXA, cfg: TestConfig):
    """Move reference planes to the probe tips; arm protections + servo."""
    # Path de-embedding (dB of loss; Loss Out duplicates External Gain)
    u.write(f":SENSe:PAMPlifier:POWer:LOSS:IN {cfg.loss_in_db}")
    u.write(f":SENSe:PAMPlifier:POWer:LOSS:OUT {cfg.loss_out_db}")

    # DUT bookkeeping + drive protection
    u.write(f":SENSe:PAMPlifier:POWer:GAIN {cfg.pa_gain_est_db}")
    u.write(f":SENSe:PAMPlifier:POWer:IN:MAX {cfg.pa_max_pin_dbm}")

    u.write(f":SENSe:PAMPlifier:POWer:CONTrol:MODE {cfg.power_control}")
    if cfg.power_control == "PAINput":
        u.write(f":SENSe:PAMPlifier:POWer:IN {cfg.target_pin_dbm}")
    else:
        u.write(f":SENSe:PAMPlifier:POWer:OUT {cfg.target_pout_dbm}")
        if cfg.servo:
            u.write(":SENSe:PAMPlifier:POWer:SERVo ON")
            u.write(f":SENSe:PAMPlifier:POWer:SERVo:TOLerance {cfg.servo_tol_db}")
    u.check_errors("power-plan")


def setup_dpd(u: UXA, cfg: TestConfig):
    """Memory-polynomial DPD, extract & apply, N iterations."""
    u.write(":SENSe:PAMPlifier:DPD:ENABle ON")
    u.write(":SENSe:PAMPlifier:DPD:MODE EAPPly")          # Extract & Apply
    u.write(f":SENSe:PAMPlifier:DPD:MODel:TYPE {cfg.dpd_algorithm}")

    if cfg.dpd_algorithm in ("MPOLynomial", "VOLTerra"):
        u.write(":SENSe:PAMPlifier:DPD:MODel:MPVolterra:IALGorithm QR")
        u.write(f":SENSe:PAMPlifier:DPD:MODel:MPVolterra:ORDer:MEMory {cfg.memory_order}")
        u.write(f":SENSe:PAMPlifier:DPD:MODel:MPVolterra:ORDer:NONLinear {cfg.nonlinear_order}")
        u.write(f":SENSe:PAMPlifier:DPD:MODel:MPVolterra:ORDer:ODD "
                f"{'ON' if cfg.odd_only else 'OFF'}")

    u.write(f":SENSe:PAMPlifier:DPD:ITERation {cfg.iterations}")
    if cfg.iterations > 1 and cfg.measure_iterations:
        u.write(":SENSe:PAMPlifier:DPD:ITERation:MEASure ON")
    u.write(f":SENSe:PAMPlifier:DPD:SINGle:EXTRaction "
            f"{'ON' if cfg.single_extraction else 'OFF'}")
    u.check_errors("dpd-setup")


def run_and_fetch(u: UXA, cfg: TestConfig) -> dict:
    """Run one full pre/post-DPD measurement and pull the result set."""
    log.info("Starting measurement (%d DPD iteration(s))...", cfg.iterations)
    t0 = time.time()

    # READ = INITiate + FETCh.  n=1: 16 scalars pre/post power & CF & dEVM
    scalars = [float(x) for x in u.query(":READ:PAMPlifier1?").split(",")]
    log.info("Measurement complete in %.1f s", time.time() - t0)

    res = {
        "pre":  dict(zip(
            ["delta_evm", "pin_dbm", "pout_dbm", "gain_db",
             "cf_in_db", "cf_out_db", "ppk_in_dbm", "ppk_out_dbm"],
            scalars[0:8])),
        "post": dict(zip(
            ["delta_evm", "pin_dbm", "pout_dbm", "gain_db",
             "cf_in_db", "cf_out_db", "ppk_in_dbm", "ppk_out_dbm"],
            scalars[8:16])),
    }

    # n=9 / n=10: WLAN EVM scalars (RMS, peak, pilot, data EVM, freq err,
    # clk err, IQ offset, peak/avg burst power)  — FETCh reuses the capture
    evm_keys = ["rms_evm", "peak_evm", "pilot_evm", "data_evm",
                "freq_err_hz", "sym_clk_err", "iq_origin_offset",
                "peak_burst_dbm", "avg_burst_dbm"]
    pre_evm = [float(x) for x in u.query(":FETCh:PAMPlifier9?").split(",")]
    post_evm = [float(x) for x in u.query(":FETCh:PAMPlifier10?").split(",")]
    res["pre"].update(dict(zip(evm_keys, pre_evm[:9])))
    res["post"].update(dict(zip(evm_keys, post_evm[:9])))

    # n=3 / n=4: ACP summary (total carrier power, ref carrier power)
    res["pre"]["acp_summary"] = u.query(":FETCh:PAMPlifier3?").strip()
    res["post"]["acp_summary"] = u.query(":FETCh:PAMPlifier4?").strip()

    # n=5 / n=6: full 60-value ACP offset tables (dBc per offset/side)
    res["pre"]["acp_offsets"] = [float(x) for x in
                                 u.query(":FETCh:PAMPlifier5?").split(",")]
    res["post"]["acp_offsets"] = [float(x) for x in
                                  u.query(":FETCh:PAMPlifier6?").split(",")]

    # Per-iteration convergence traces (only valid if measured)
    if cfg.iterations > 1 and cfg.measure_iterations:
        res["iter_evm"] = u.query(":FETCh:PAMPlifier22?").strip()
        res["iter_acp_lo"] = u.query(":FETCh:PAMPlifier23?").strip()
        res["iter_acp_hi"] = u.query(":FETCh:PAMPlifier24?").strip()
        res["iter_gain"] = u.query(":FETCh:PAMPlifier30?").strip()
        res["iter_pout"] = u.query(":FETCh:PAMPlifier31?").strip()

    u.check_errors("read")
    return res


def report(res: dict, cfg: TestConfig):
    unit = "dB" if cfg.report_evm_db else "%"
    pre, post = res["pre"], res["post"]
    log.info("=" * 64)
    log.info("            %12s   %12s", "PRE-DPD", "POST-DPD")
    log.info("Pin  (pad)  %9.2f dBm  %9.2f dBm", pre["pin_dbm"], post["pin_dbm"])
    log.info("Pout (pad)  %9.2f dBm  %9.2f dBm", pre["pout_dbm"], post["pout_dbm"])
    log.info("Gain        %9.2f dB   %9.2f dB", pre["gain_db"], post["gain_db"])
    log.info("CF out      %9.2f dB   %9.2f dB", pre["cf_out_db"], post["cf_out_db"])
    log.info("RMS EVM     %9.2f %-3s  %9.2f %-3s",
             pre["rms_evm"], unit, post["rms_evm"], unit)
    log.info("Data EVM    %9.2f %-3s  %9.2f %-3s",
             pre["data_evm"], unit, post["data_evm"], unit)
    log.info("Freq error  %9.1f Hz   %9.1f Hz",
             pre["freq_err_hz"], post["freq_err_hz"])
    log.info("=" * 64)
    if "iter_evm" in res:
        log.info("EVM vs DPD iteration : %s", res["iter_evm"])
        log.info("Gain vs iteration    : %s", res["iter_gain"])

    with open(cfg.csv_out, "w") as f:
        f.write("metric,pre_dpd,post_dpd\n")
        for k in pre:
            if isinstance(pre[k], float):
                f.write(f"{k},{pre[k]},{post[k]}\n")
    log.info("Scalar results written to %s", cfg.csv_out)


def safe_shutdown(u: UXA):
    """RF off at the probe before anyone touches the chuck."""
    try:
        u.write(":SENSe:SOURce:RFOutput OFF")
        u.check_errors("shutdown")
    except Exception:
        pass


# ----------------------------------------------------------------------
def main():
    cfg = TestConfig()
    u = UXA(cfg.uxa_visa, cfg.timeout_ms)
    try:
        setup_pa_mode(u, cfg)

        # >>> Operator checkpoint: probes landed, quiescent bias applied,
        # >>> drain current verified, THEN enable RF.
        input("Probes down + DUT biased?  Press Enter to enable RF...")

        setup_radio_and_waveform(u, cfg)
        setup_onwafer_power_plan(u, cfg)
        setup_dpd(u, cfg)

        u.write(":SENSe:SOURce:RFOutput ON")
        res = run_and_fetch(u, cfg)
        report(res, cfg)
    finally:
        safe_shutdown(u)


if __name__ == "__main__":
    main()
