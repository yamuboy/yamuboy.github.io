# On-Wafer EVM + DPD Test Bench — File-by-File Guide

**Instruments:** Keysight MXG X-Series vector signal generator (N5182B class) + Keysight UXA signal analyzer (N9040B/N9042B) with Power Amplifier mode (N9055EM0C) and the WLAN measurement application (N9077).
**DUT:** on-wafer PA, GSG probes, 7.0–7.5 GHz.
**Files:** `loss_cal.py` → `onwafer_evm_dpd.py` → `power_sweep_evm.py`, with `mxg_waveform.py` as the manual/offline-DPD alternative.

All SCPI commands referenced below come from the uploaded Keysight manuals: the *Power Amplifier Mode User's & Programmer's Reference*, the *X-Series Signal Generators Programming Guide*, the *Creating and Downloading Waveform Files* manual (9018-05434), and the *WLAN Mode User's & Programmer's Reference* (N9040B).

---

## 0. The architecture in one paragraph

The measurement is built around the UXA's **Power Amplifier mode**, which acts as the conductor: the analyzer connects to the MXG over LAN, pushes the reference waveform and source settings to it, captures the DUT output, time-aligns capture against reference, extracts a digital predistortion model, predistorts the waveform, re-downloads it to the MXG, and repeats for N iterations. At the end, a single family of queries (`:READ:PAMPlifier[n]?` / `:FETCh:PAMPlifier[n]?`) returns pre-DPD and post-DPD power, gain, crest factor, EVM, and ACP. The signal path is:

```
MXG ──[cable + bias tee + input probe]──► DUT (on wafer) ──[output probe + pad + cable]──► UXA
        └──────── Loss In ────────┘                 └──────────── Loss Out ────────────┘
```

`Loss In` and `Loss Out` are scalar de-embedding terms entered into the PA mode. They move the power reference planes from the instrument connectors to the DUT probe pads, so every reported power (Pin, Pout, gain, servo target, protection limit) is a wafer-plane number. Getting these two values right is the entire point of `loss_cal.py`, which is why it runs first.

---

## 1. `loss_cal.py` — establish the probe-tip reference planes

**What it produces:** the two numbers `loss_in_db` and `loss_out_db` that you paste into `TestConfig`, plus `loss_cal.csv` with total path loss versus frequency.

**Why it exists:** in PA-input power-control mode there is no servo correcting the drive level — the commanded Pin is only as accurate as Loss In. Likewise, the reported Pout and the UXA protection margin are only as good as Loss Out. A 1 dB error here is a 1 dB error in every gain and compression number downstream.

### Step by step

1. **Configuration block (top of file).** `FREQS_HZ` is a CW frequency list spanning the band (7.0–7.5 GHz, five points). `P_SET_DBM = −10` is a safe CW level for the thru standard. The `KNOWN` dictionary holds your fixed-element budget at band center: input cable + bias tee, input probe insertion loss, the cal-substrate thru line, output probe, the output attenuator pad (use its calibrated value, not the nominal 20 dB), and the output cable.

2. **`open_inst()`** opens each VISA resource, sets terminations and timeout, and logs `*IDN?` so the run record shows exactly which instruments were used.

3. **MXG setup.** `*RST`, then `:SOURce:RADio:ARB:STATe OFF` and `:OUTPut:MODulation:STATe OFF` to guarantee a clean CW carrier, `:SOURce:POWer −10`, and ALC **ON** — for unmodulated CW the ALC loop is exactly what you want, since it servoes the leveled output against drift.

4. **UXA setup.** Selects the base SA mode (`:INSTrument:SELect SA`), configures the Channel Power measurement (`:CONFigure:CHPower:NDEFault`) with a 1 MHz integration bandwidth and 5 MHz span around the tone, and turns on 10-count averaging. Channel power with a narrow IBW is a robust way to read a CW tone without worrying about RBW/detector choices.

5. **The measurement loop.** With both probes landed on the **THRU** standard of the cal substrate (e.g., Cascade 101-190), the loop steps frequency on both instruments simultaneously, waits 300 ms for settling and ALC convergence, reads channel power, and computes total path loss as `L_total = P_set − P_measured`. RF is wrapped in a `try/finally` so the output always shuts off even if a read fails.

6. **The split.** Loss In is the sum of the input-side fixed elements, Loss Out the output side. The script sums the full budget (including the thru line), compares it against the measured `L_total` at band center, and reports the residual. A residual above 0.5 dB triggers a warning — in practice that means probe contact/planarity, a worn cable, or a pad whose actual attenuation differs from nominal. Small residuals are split evenly between the two arms and the final suggested values are printed and appended to the CSV.

**Practical note:** if you have two-tier TRL S21 data for the probes from the PNA-X, those values belong in `KNOWN` and this CW run becomes a sanity cross-check of the assembled chain rather than the primary source. Re-run this script any time you swap a cable, change the pad, or re-planarize probes.

---

## 2. `onwafer_evm_dpd.py` — the main single-power EVM + DPD measurement

**What it produces:** a console table and `dpd_results.csv` comparing pre- and post-DPD Pin, Pout, gain, output crest factor, RMS/data EVM, frequency error, and ACP, plus per-iteration convergence traces.

### The configuration object

`TestConfig` is a dataclass holding everything you'd edit between runs, grouped as: instrument addresses (UXA by VISA string, MXG by **IP address** — PA mode connects to the generator by IP/hostname, not VISA); the RF plan (carrier frequency, estimated gain, the absolute input drive cap `pa_max_pin_dbm`, the target level and whether you control PA input or PA output); the two de-embedding losses from `loss_cal.py`; the reference waveform (a Signal Studio `.wfm` already on the UXA disk, or a USER `.bin`/`.csv`/`.mat` I/Q file); the radio standard (`AX80` = 802.11ax 80 MHz); and the DPD model parameters (memory polynomial, memory order 3, nonlinear order 7, odd-only terms, 3 iterations).

### The `UXA` wrapper class

A thin PyVISA wrapper with four conveniences: logged `write`/`query`, an `opc()` method that appends a blocking `*OPC?` after slow operations (mode switches, waveform exports, connection attempts), and `check_errors()`, which drains the entire `:SYSTem:ERRor?` queue after each phase and logs anything found. The error-queue drains are deliberate: a few PA-mode enum spellings vary across X-series firmware versions, and the queue is how you find out which command your firmware spells differently.

### Step by step through `main()`

1. **`setup_pa_mode()`**
   - `*CLS;*RST` then `:INSTrument:SELect PA` selects Power Amplifier mode (mode ID `PA`, mode number 81), and `:CONFigure:PAMPlifier:NDEFault` selects the PAMP measurement without clobbering settings.
   - **Wafer safety before anything else:** `:SENSe:SOURce:PRESet:OFF 1` is a power-on-persistent setting that forces the generator's RF output OFF after any measurement preset — the manual describes it explicitly as protection for a sensitive PA. Then RF is explicitly switched off. The point: no full-power carrier ever reaches an unbiased die because of a preset side effect.
   - `:SENSe:SOURce:CONNect "<ip>"` makes the analyzer connect to the MXG; the script verifies `:SENSe:SOURce:CONNect:STATe?` returns 1 and logs the generator's reported name, raising immediately if the link failed (everything downstream is meaningless without it).
   - Frequency: the analyzer center frequency is set to the carrier, and `:SENSe:SOURce:FREQuency:AUTO ON` couples the generator's frequency to it, so one number controls both boxes.
   - `:SENSe:SOURce:ALC OFF` — mandatory for high-PAPR OFDM. The ALC loop tries to level the *envelope* of a modulated signal and corrupts it; leveling for modulated signals is instead handled by the waveform header and runtime scaling.

2. **Operator checkpoint.** The script blocks at an `input()` prompt. The intended sequence at the station: probes landed and planarized, gate bias applied, quiescent drain current verified — *then* press Enter. RF-enable is the last thing that happens, never the first.

3. **`setup_radio_and_waveform()`**
   - `:SENSe:PAMPlifier:RADio:STANdard AX80` runs the radio-standard preset: it configures carrier count, carrier bandwidth, ACP offsets and integration bandwidths, and the EVM coupling, all matched to 802.11ax 80 MHz in one command.
   - `:SENSe:PAMPlifier:EVM:FORMat WLAN` plus `:SENSe:PAMPlifier:EVM:STATe ON` turns on EVM. Important dependency from the manual: with Radio Format = WLAN, the EVM engine is the **N9077 WLAN application**, which must be installed and preloaded on the analyzer, otherwise EVM State stays disabled. `REPort:DB ON` selects dB readout (set OFF for %).
   - The reference waveform is declared (`WAVeform:TYPE SSWaveform`, `LOCation LOCal`, `NAME "<path on UXA disk>"`), and the script reads back the sample rate and I/Q count as a sanity check that the file parsed.
   - `:SENSe:SOURce:RUNTime:SCALing 70` sets DAC headroom — 70% is the PA-mode default for WLAN formats, balancing dynamic range against DAC overflow and interpolation-filter overshoot.
   - `:SENSe:SOURce:WAVeform:EXPort:IMMediate` pushes the waveform file to the MXG, and `:SENSe:SOURce:SETTings:APPLy` pushes frequency/power/ALC/scaling. Both are `*OPC?`-synchronized because the export is a multi-second file transfer.

4. **`setup_onwafer_power_plan()`**
   - `:SENSe:PAMPlifier:POWer:LOSS:IN` / `:LOSS:OUT` enter the de-embedding values from `loss_cal.py`. From here on, all powers are probe-tip referred.
   - `:SENSe:PAMPlifier:POWer:GAIN` (your gain estimate, used for initial level planning) and `:SENSe:PAMPlifier:POWer:IN:MAX` (the hard drive cap protecting the die — the manual caps achievable input power at this value regardless of what the servo wants).
   - Power control mode: `PAINput` sets a fixed wafer-plane input power (`:PAMP:POW:IN`). `PAOutput` instead targets a delivered output power (`:PAMP:POW:OUT`) and enables the **power servo**, a measure-and-adjust loop that converges actual PA output to the target within `SERVo:TOLerance` — the right choice when you want EVM *at a defined Pout* (e.g., at rated average power) rather than at a defined drive.

5. **`setup_dpd()`**
   - `:SENSe:PAMPlifier:DPD:ENABle ON` and `:DPD:MODE EAPPly` select Extract & Apply: the analyzer extracts the PA model from the captured input/output pair and applies its inverse to the waveform. (The alternative, `APPLy`, applies a user-supplied LUT or coefficient file without extraction.)
   - `:DPD:MODel:TYPE MPOLynomial` selects the memory-polynomial algorithm; the manual's own guidance pairs MP with memory order 3–5, nonlinear order 5–7, odd-only ON — which is exactly what the defaults encode (M=3, K=7, odd-only). The shared `MPVolterra` command branch sets identification algorithm (QR least squares), memory order, nonlinear order, and odd-only.
   - `:DPD:ITERation 3` runs three extract→apply→re-measure passes, and `:DPD:ITERation:MEASure ON` records EVM/ACP/gain/Pout *per iteration* so you can see convergence (this toggle only exists when iterations > 1).
   - `:DPD:SINGle:EXTRaction OFF` means re-extract at every power step (relevant when combined with power sweep; harmless here).

6. **`run_and_fetch()`** — RF is enabled, then a single `:READ:PAMPlifier1?` initiates the full acquisition + DPD loop and returns 16 scalars: the pre-DPD set (delta-EVM, Pin, Pout, gain, crest factor in/out, peak powers) followed by the identical post-DPD set. With the capture already in memory, the script uses **FETCh** (which re-uses the data, no re-measurement) for the rest:
   - `FETCh:PAMPlifier9?` / `10?` — WLAN EVM scalars pre/post-DPD: RMS EVM, peak EVM, pilot EVM, data EVM, frequency error, symbol-clock error, IQ origin offset, peak and average burst power.
   - `FETCh:PAMPlifier3?` / `4?` — ACP summary (total/reference carrier powers), and `5?` / `6?` — the full 60-value ACP offset tables (per-offset, per-side dBc).
   - If iteration measurement was on: `22?` (EVM vs iteration), `23?`/`24?` (lower/upper ACP offset-A vs iteration), `30?` (gain), `31?` (Pout). These are the convergence diagnostics — EVM should drop hard on iteration 1 and flatten; if it keeps moving on iteration 3, raise the iteration count or suspect a drifting operating point (thermal, trapping).

7. **`report()` and `safe_shutdown()`** — prints the pre/post comparison table, writes `dpd_results.csv`, and the `finally` block forces generator RF off no matter how the run ended, so the probes are always safe to lift.

---

## 3. `power_sweep_evm.py` — EVM vs. drive level with DPD

**What it produces:** `evm_vs_power.csv` with one row per drive level: commanded Pin, whether DPD was applied at that level, the measured average burst Pout, and EVM. This is the modulated analogue of a CW power sweep — it gives you the EVM-vs-Pout curve and, implicitly, gain compression under modulation.

### Step by step

1. **`SweepConfig`** extends `TestConfig`, adding the sweep plan: PA-input start/stop/step (−20 → +2 dBm in 1 dB steps, wafer-plane referred via Loss In) and `dpd_threshold_dbm`. It flips `single_extraction` to True (see step 3).

2. **Reuse.** The script imports and reuses `setup_pa_mode`, `setup_radio_and_waveform`, `setup_onwafer_power_plan`, and `setup_dpd` from the main file — the bench setup is identical; only the measurement type changes.

3. **`setup_power_sweep()`**
   - `:SENSe:PAMPlifier:MEAS:TYPE PSWeep` switches from single-power to power sweep. Per the manual's couplings, this forces EVM State ON and puts the instrument in single-sweep mode.
   - `:PAMP:POW:SWE:IN:STARt/STOP/STEP` define the levels; `:PAMP:POW:SWE:IN:DTHReshold` is the level at and above which DPD engages during the sweep — below it, points run un-predistorted (fast, and the PA is linear there anyway); above it, every point is linearized. The default threshold (−8 dBm) is set near where your DUT starts compressing.
   - The script raises a `ValueError` if the sweep stop exceeds `pa_max_pin_dbm`, rather than letting the instrument silently clip the plan — a deliberate fail-loud choice for wafer work.
   - Two constraints inherited from the instrument, documented in the header: per-iteration traces (n = 22–32) are unavailable because the instrument disables Measure DPD Iteration during a power sweep; and `single_extraction = True` extracts the model **once**, at the first DPD-active level, then re-applies it at all later levels. That is both faster and a useful robustness test — if one M=3/K=7 model extracted at −8 dBm holds EVM flat up to +2 dBm, the model generalizes across drive; if post-DPD EVM degrades toward the top, set `single_extraction = False` to re-extract per level (slower, best-case linearization at each point).

4. **`run_power_sweep()`** — one `:READ:PAMPlifier12?` runs the whole sweep and returns a self-describing block: `[radio format, number of power levels, scalars per level, then (level, DPD flag, avg burst power, EVM) × p]`. The parser walks that structure into row dictionaries. `FETCh:PAMPlifier11?` (the EVM-vs-power trace) and `17?` (the measured power readouts, low-to-high) are fetched as cross-checks against the parsed scalars.

5. **`report_sweep()`** — console table plus CSV. Plot EVM vs. `avg_burst_pout_dbm` with the DPD flag as the series split and you have the headline figure: where the un-predistorted curve breaks upward and how far DPD extends usable Pout.

---

## 4. `mxg_waveform.py` — the manual / offline-DPD path

This module exists because you may want the DPD math **outside** the analyzer — for example, running your own memory-polynomial test bench against this hardware, comparing your LS-fit coefficients to the instrument's, or playing a waveform you synthesized in Python rather than a Signal Studio file. It has three independent pieces.

### 4.1 `encode_iq_int16_be()` + `download_iq()` — direct ARB download to the MXG

The MXG's waveform format rules (from manual 9018-05434) are strict, and this function pair encodes all of them:

1. **Encoding.** I/Q must be 16-bit signed integers in **big-endian** byte order, with I and Q **interleaved** (`I0, Q0, I1, Q1, …`). `encode_iq_int16_be()` scales your complex vector so full scale maps to 32767, raises if any sample exceeds full scale (telling you by how many dB), and packs into a `>i2` NumPy array — the `>` is the big-endian requirement, the single most common silent failure in MXG downloads (little-endian data downloads "successfully" and plays as noise).

2. **Length rules.** `download_iq()` enforces the minimum length (≥ 60 samples) and even-sample-count requirement before touching the instrument.

3. **The transfer.** ARB is stopped, then `MMEM:DATA "WFM1:<name>",<block>` writes the file into volatile waveform memory using an IEEE-488.2 definite-length block (PyVISA's `write_binary_values` builds the `#ABC` header). `WFM1:` is the volatile-memory path prefix.

4. **Playback chain.** `:SOURce:RADio:ARB:SCLock:RATE` sets the ARB sample clock to your waveform's sample rate (get this wrong and the signal plays at the wrong bandwidth), optional frequency/power are set, ALC is turned **OFF** (same high-PAPR reason as before), and then the canonical play sequence from the manual: select with `:SOURce:RADio:ARB:WAVeform "WFM1:<name>"`, then `:RADio:ARB:STATe ON`, `:OUTPut:MODulation:STATe ON`, `:OUTPut:STATe ON`. Finally the error queue is checked and any error raised.

### 4.2 `wlan_evm()` — standalone EVM via the UXA WLAN mode

When you want demod-level control (or a second opinion on PA-mode EVM), this runs the N9077 Modulation Analysis measurement directly: select WLAN mode, `:CONFigure:EVM:NDEFault`, set the standard enum (`AX80` etc. — same family of enums as PA mode) and center frequency, and enter the output-path loss as a negative External Gain so reported burst powers are probe-tip referred. One `:READ:EVM1?` returns the 60-scalar result block; the module maps the most useful indices by name — RMS/peak EVM max/avg in dB (positions 1–4), frequency and symbol-clock error (7–12), average burst power (position 20), data EVM in dB (position 30), and RMS EVM in % (position 34). The full 60-entry layout is in the WLAN manual's Modulation Analysis chapter if you need the rest (gain imbalance, quadrature error, IQ timing skew, …).

### 4.3 `capture_iq_pamp()` — raw I/Q out of PA mode for offline extraction

After any completed PA-mode acquisition, `FETCh:PAMPlifier15?` (pre-DPD) and `16?` (post-DPD) return the raw captured I/Q as interleaved ASCII values; this function de-interleaves them into a complex NumPy vector. The closed loop for a fully host-side DPD experiment is then:

1. Generate your 802.11ax reference in Python → `download_iq()` to the MXG.
2. Run one PA-mode acquisition (DPD disabled) → `capture_iq_pamp()` to get the DUT output.
3. Time-align reference and capture, run your own memory-polynomial LS fit, predistort the reference.
4. `download_iq()` the predistorted waveform → re-measure EVM/ACP (PA mode or `wlan_evm()`).
5. Iterate; compare your coefficients and residual EVM against the instrument's built-in MP extraction as a cross-validation of your bench.

---

## 5. Recommended run order and checklist

1. **Cal day:** TRL on the cal substrate (PNA-X) for probe S21 if you want best accuracy → fill `KNOWN` in `loss_cal.py` → land on THRU → run `loss_cal.py` → paste `loss_in_db` / `loss_out_db` into `TestConfig`.
2. **Bench sanity (no DUT):** probes on THRU, run `onwafer_evm_dpd.py` with DPD iterations = 1 and a low drive. Pre-DPD EVM here is your **system residual EVM floor** — everything the DUT measurement can never beat. For 802.11ax MCS11 work you want this floor several dB below your DUT spec line.
3. **DUT, single power:** land on the PA, bias, verify Idq, run `onwafer_evm_dpd.py` at the nominal operating point. Check the iteration traces converge.
4. **DUT, characterization:** run `power_sweep_evm.py` for the EVM-vs-Pout curve, first with `single_extraction = True` (model robustness), then `False` if you want best-case linearized numbers.
5. **Always:** watch the post-DPD output crest factor against your output pad + UXA mixer budget — DPD *raises* peak power at the DUT output; the script reports CF out pre/post so you can verify margin.
6. **Firmware quirks:** the scripts drain `:SYSTem:ERRor?` after every phase. On first run on your specific firmware, watch the log — if a command is rejected (a handful of PA-mode enums vary slightly between X-series releases), the error message names the offending command and the manual's command reference gives the variant.
