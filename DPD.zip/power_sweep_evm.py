#!/usr/bin/env python3
"""
power_sweep_evm.py — EVM vs. drive level with DPD, on-wafer
===========================================================
Extends onwafer_evm_dpd.py with the PA-mode Power Sweep measurement
(:PAMP:MEAS:TYPE PSWeep). At each drive level the analyzer measures
burst power and EVM at the PA output; DPD engages only above a
threshold level you set, so the low-power (linear) points run fast and
the compressed points get linearized.

Output: CSV of (commanded level, DPD on/off, avg burst power, EVM)
suitable for plotting EVM-vs-Pout / gain compression curves — the
modulated analogue of your CW load-pull power sweeps.

Notes from the PA-mode manual that shape this script:
  * PSWeep forces EVM State ON and puts the instrument in Single mode.
  * "Measure DPD Iteration" is OFF/disabled during Power Sweep, so the
    per-iteration traces (n=22..32) are unavailable here.
  * :PAMP:DPD:SINGle:EXTRaction ON  -> extract the model once at the
    first DPD-active level and re-apply it at later levels (fast, and a
    good test of model robustness vs. drive). OFF -> re-extract at
    every level (slow, best linearization at each point).
  * n=12 returns 3 header values + 4 scalars per power point:
    [fmt, npts, nscal, (level, dpd_flag, avg_burst_dbm, evm) * p]
  * n=11 returns the EVM-vs-power trace; n=17 the measured powers.

Usage: import the setup/instrument pieces from onwafer_evm_dpd and run
       run_power_sweep() in place of run_and_fetch().
"""

import logging
from dataclasses import dataclass

from onwafer_evm_dpd import (
    TestConfig, UXA,
    setup_pa_mode, setup_radio_and_waveform,
    setup_onwafer_power_plan, setup_dpd, safe_shutdown,
)

log = logging.getLogger("onwafer_dpd")


@dataclass
class SweepConfig(TestConfig):
    # PA *input* power sweep (Power Control Mode = PAINput), referenced
    # to the input probe tip thanks to Loss In.
    pin_start_dbm: float = -20.0
    pin_stop_dbm: float = 2.0
    pin_step_db: float = 1.0
    # DPD engages at and above this input level (PAINput mode).
    dpd_threshold_dbm: float = -8.0
    # One model extraction reused across the sweep (ON) vs re-extract
    # at every level (OFF).
    single_extraction: bool = True
    csv_out: str = "evm_vs_power.csv"


def setup_power_sweep(u: UXA, cfg: SweepConfig):
    """Configure the input-referred power sweep with a DPD threshold."""
    u.write(":SENSe:PAMPlifier:POWer:CONTrol:MODE PAINput")
    u.write(":SENSe:PAMPlifier:MEAS:TYPE PSWeep")   # forces EVM ON

    u.write(f":SENSe:PAMPlifier:POWer:SWEep:IN:STARt {cfg.pin_start_dbm}")
    u.write(f":SENSe:PAMPlifier:POWer:SWEep:IN:STOP {cfg.pin_stop_dbm}")
    u.write(f":SENSe:PAMPlifier:POWer:SWEep:IN:STEP {cfg.pin_step_db}")
    u.write(f":SENSe:PAMPlifier:POWer:SWEep:IN:DTHReshold {cfg.dpd_threshold_dbm}")

    # Sweep stop must respect the wafer drive cap
    if cfg.pin_stop_dbm > cfg.pa_max_pin_dbm:
        raise ValueError(
            f"Sweep stop {cfg.pin_stop_dbm} dBm exceeds Max Input Power "
            f"{cfg.pa_max_pin_dbm} dBm — fix the plan, not the cap."
        )
    u.check_errors("sweep-setup")


def run_power_sweep(u: UXA, cfg: SweepConfig) -> list[dict]:
    """Run the sweep; parse the n=12 scalar block into rows."""
    n_levels = int(round(
        (cfg.pin_stop_dbm - cfg.pin_start_dbm) / cfg.pin_step_db)) + 1
    log.info("Power sweep: %d levels, %.1f -> %.1f dBm (DPD above %.1f dBm)",
             n_levels, cfg.pin_start_dbm, cfg.pin_stop_dbm,
             cfg.dpd_threshold_dbm)

    vals = [float(x) for x in u.query(":READ:PAMPlifier12?").split(",")]
    fmt, npts, nscal = int(vals[0]), int(vals[1]), int(vals[2])
    rows = []
    for p in range(npts):
        base = 3 + p * nscal
        rows.append({
            "pin_cmd_dbm": vals[base + 0],
            "dpd_applied": int(vals[base + 1]),
            "avg_burst_pout_dbm": vals[base + 2],
            "evm": vals[base + 3],
        })

    # Cross-check arrays: EVM trace + measured power readouts
    evm_trace = u.query(":FETCh:PAMPlifier11?").strip()
    pow_trace = u.query(":FETCh:PAMPlifier17?").strip()
    log.debug("EVM trace: %s", evm_trace)
    log.debug("Power readouts: %s", pow_trace)
    u.check_errors("sweep-read")
    return rows


def report_sweep(rows: list[dict], cfg: SweepConfig):
    unit = "dB" if cfg.report_evm_db else "%"
    log.info("%-12s %-6s %-18s %-10s", "Pin (dBm)", "DPD", "Pout avg (dBm)",
             f"EVM ({unit})")
    for r in rows:
        log.info("%-12.1f %-6s %-18.2f %-10.2f",
                 r["pin_cmd_dbm"], "ON" if r["dpd_applied"] else "off",
                 r["avg_burst_pout_dbm"], r["evm"])
    with open(cfg.csv_out, "w") as f:
        f.write("pin_cmd_dbm,dpd_applied,avg_burst_pout_dbm,evm\n")
        for r in rows:
            f.write(f"{r['pin_cmd_dbm']},{r['dpd_applied']},"
                    f"{r['avg_burst_pout_dbm']},{r['evm']}\n")
    log.info("Sweep written to %s", cfg.csv_out)


def main():
    cfg = SweepConfig()
    u = UXA(cfg.uxa_visa, cfg.timeout_ms)
    try:
        setup_pa_mode(u, cfg)
        input("Probes down + DUT biased?  Press Enter to enable RF...")
        setup_radio_and_waveform(u, cfg)
        setup_onwafer_power_plan(u, cfg)
        setup_dpd(u, cfg)            # model config; threshold gates it
        setup_power_sweep(u, cfg)
        u.write(":SENSe:SOURce:RFOutput ON")
        rows = run_power_sweep(u, cfg)
        report_sweep(rows, cfg)
    finally:
        safe_shutdown(u)


if __name__ == "__main__":
    main()
