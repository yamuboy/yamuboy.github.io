#!/usr/bin/env python3
"""
loss_cal.py — establish probe-tip reference planes for Loss In/Out
==================================================================
The accuracy of every power number in the PA-mode measurement (Pin,
Pout, gain, the servo target, and the Max Input Power protection) rests
on two scalars: Loss In and Loss Out. This helper measures them with
the instruments you already have on the bench.

Definitions (PA-mode manual):
  Loss In  : path loss MXG output  -> DUT input pad
             (RF cable + bias tee + input GSG probe)
  Loss Out : path loss DUT output pad -> UXA input
             (output GSG probe + attenuator pad + RF cable)

Strategy
--------
A) Probe-pair insertion loss via a thru standard:
   Land both probes on the cal-substrate THRU (e.g., Cascade 101-190).
   Drive CW from the MXG, read channel power on the UXA. The measured
   total path loss is

       L_total(f0) = P_mxg_set - P_uxa_meas
                   = L_in_cable + L_probe_in + L_thru
                     + L_probe_out + L_pad + L_out_cable

   Split the probe pair per the probe datasheet or symmetrically
   (L_probe ~= (L_pair)/2 after removing the known pad/cable terms).
   If you have two-tier TRL data from the PNA-X for these probes at f0
   (you've done <0.001 dB-class TRL on this substrate), prefer those
   S21 values and use this CW check only as a sanity cross-check.

B) Per-arm split using a power-sensor reference (optional refinement):
   Measure cable+bias-tee loss to the probe connector with a USB power
   sensor, then attribute the remainder of L_total to the probes+thru.

This script implements (A): a small CW frequency list around the band,
channel-power readout on the UXA, and a CSV of L_total(f) with the
suggested Loss In / Loss Out split given your known fixed elements.
"""

import logging
import time

import pyvisa

log = logging.getLogger("loss_cal")
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s")

# ---------------------------------------------------------------------
MXG_VISA = "TCPIP0::192.168.0.20::hislip0::INSTR"
UXA_VISA = "TCPIP0::192.168.0.10::hislip0::INSTR"

FREQS_HZ = [7.000e9, 7.125e9, 7.250e9, 7.375e9, 7.500e9]
P_SET_DBM = -10.0          # safe CW level through the thru standard

# Known fixed elements at band center (from datasheets / PNA-X TRL):
KNOWN = {
    "in_cable_biastee_db": 2.1,    # MXG -> input probe connector
    "probe_in_db": 1.0,            # input probe tip loss
    "thru_db": 0.1,                # cal-substrate thru line
    "probe_out_db": 1.0,           # output probe tip loss
    "pad_db": 20.0,                # output attenuator (nominal; use cal data)
    "out_cable_db": 2.3,           # pad -> UXA input
}
# ---------------------------------------------------------------------


def open_inst(addr, timeout_ms=30000):
    rm = pyvisa.ResourceManager()
    inst = rm.open_resource(addr)
    inst.timeout = timeout_ms
    inst.read_termination = "\n"
    inst.write_termination = "\n"
    log.info("%s -> %s", addr, inst.query("*IDN?").strip())
    return inst


def main():
    mxg = open_inst(MXG_VISA)
    uxa = open_inst(UXA_VISA)

    # --- MXG: clean CW, ALC ON is fine for CW loss cal
    mxg.write("*RST")
    mxg.write(":SOURce:RADio:ARB:STATe OFF")
    mxg.write(":OUTPut:MODulation:STATe OFF")
    mxg.write(f":SOURce:POWer {P_SET_DBM}")
    mxg.write(":SOURce:POWer:ALC:STATe ON")

    # --- UXA: SA mode channel power, narrow IBW around the CW tone
    uxa.write("*RST")
    uxa.write(":INSTrument:SELect SA")
    uxa.query("*OPC?")
    uxa.write(":CONFigure:CHPower:NDEFault")
    uxa.write(":SENSe:CHPower:BANDwidth:INTegration 1e6")
    uxa.write(":SENSe:CHPower:FREQuency:SPAN 5e6")
    uxa.write(":SENSe:CHPower:AVERage:COUNt 10")
    uxa.write(":SENSe:CHPower:AVERage:STATe ON")

    rows = []
    mxg.write(":OUTPut:STATe ON")
    try:
        for f0 in FREQS_HZ:
            mxg.write(f":SOURce:FREQuency {f0}")
            uxa.write(f":SENSe:FREQuency:CENTer {f0}")
            time.sleep(0.3)                       # settle + ALC
            chp = float(uxa.query(":READ:CHPower:CHPower?").split(",")[0])
            l_total = P_SET_DBM - chp
            rows.append((f0, chp, l_total))
            log.info("f = %.3f GHz  P_meas = %7.2f dBm  L_total = %5.2f dB",
                     f0 / 1e9, chp, l_total)
    finally:
        mxg.write(":OUTPut:STATe OFF")

    # --- Suggested split at band center using known fixed elements
    k = KNOWN
    loss_in = k["in_cable_biastee_db"] + k["probe_in_db"]
    loss_out = k["probe_out_db"] + k["pad_db"] + k["out_cable_db"]
    budget = loss_in + k["thru_db"] + loss_out

    mid = rows[len(rows) // 2]
    resid = mid[2] - budget
    log.info("-" * 60)
    log.info("Budget at %.3f GHz: %.2f dB; measured %.2f dB; residual %+.2f dB",
             mid[0] / 1e9, budget, mid[2], resid)
    if abs(resid) > 0.5:
        log.warning("Residual > 0.5 dB — re-check pad cal data, probe "
                    "planarity/contact, or cable wear before trusting "
                    "the split.")
    # Distribute any small residual evenly between the two arms
    loss_in_final = loss_in + resid / 2
    loss_out_final = loss_out + resid / 2
    log.info("=> Set in TestConfig:  loss_in_db = %.2f   loss_out_db = %.2f",
             loss_in_final, loss_out_final)

    with open("loss_cal.csv", "w") as f:
        f.write("freq_hz,p_meas_dbm,l_total_db\n")
        for r in rows:
            f.write(f"{r[0]},{r[1]},{r[2]}\n")
        f.write(f"# suggested loss_in_db,{loss_in_final:.2f}\n")
        f.write(f"# suggested loss_out_db,{loss_out_final:.2f}\n")
    log.info("Written loss_cal.csv")


if __name__ == "__main__":
    main()
