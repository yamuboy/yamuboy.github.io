import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from numpy.fft import fft
from wifi_ax_dpd import (generate_he_waveform, PAModel, MemoryPolyDPD,
                         measure_aclr, measure_evm, papr_db)

# ---- 1. Waveform ----------------------------------------------------------
x, fs, meta = generate_he_waveform(n_sym=120, osr=8)
print(f"fs = {fs/1e6:.0f} MHz | {len(x)} samples | PAPR = {papr_db(x):.2f} dB")

RMS = 0.50                      # input backoff operating point
pa = PAModel()
xb = x * RMS

# ---- 2. PA without DPD ----------------------------------------------------
y0 = pa(xb)
a1_0, a2_0, (f, P0) = measure_aclr(y0, fs)
G0 = np.abs(np.vdot(xb, y0) / np.vdot(xb, xb))
evm0 = measure_evm(y0, xb, meta, G0)

# ---- 3. Memoryless DPD (M=0) ----------------------------------------------
dpd_ml = MemoryPolyDPD(K=7, M=0)
dpd_ml.train(pa, xb, iters=5)
y_ml = pa(dpd_ml.apply(xb))
a1_1, a2_1, (_, P1) = measure_aclr(y_ml, fs)
evm1 = measure_evm(y_ml, xb, meta, G0)

# ---- 4. Memory-polynomial DPD (M=3) ---------------------------------------
dpd = MemoryPolyDPD(K=7, M=3)
dpd.train(pa, xb, iters=6)
y_mp = pa(dpd.apply(xb))
a1_2, a2_2, (_, P2) = measure_aclr(y_mp, fs)
evm2 = measure_evm(y_mp, xb, meta, G0)

# clean reference spectrum
_, _, (_, Pc) = measure_aclr(xb, fs)

print("\n                 ACLR1     ACLR2      EVM")
print(f"No DPD        {a1_0:7.1f}  {a2_0:8.1f}  {evm0:6.2f}%")
print(f"DPD  K7 M0    {a1_1:7.1f}  {a2_1:8.1f}  {evm1:6.2f}%")
print(f"DPD  K7 M3    {a1_2:7.1f}  {a2_2:8.1f}  {evm2:6.2f}%")

# ============================ PLOTS ========================================
def dB(P): return 10*np.log10(P/np.max(Pc))

# Fig A: clean waveform spectrum + time envelope
figA, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].plot(f/1e6, dB(Pc), lw=1)
ax[0].axvspan(-10, 10, alpha=.08, color='C2')
ax[0].set(title="802.11ax HE-SU MCS2, 20 MHz — baseband PSD (clean)",
          xlabel="Frequency (MHz)", ylabel="PSD (dB, norm.)",
          xlim=(-60, 60), ylim=(-70, 5))
ax[0].grid(alpha=.3)
n0 = meta['cp_up']; seg = slice(0, 6*(meta['nup']+meta['cp_up']))
t = np.arange(len(x))[seg]/fs*1e6
ax[1].plot(t, np.abs(x[seg]), lw=.6)
ax[1].set(title="Envelope |x(t)|  (high PAPR OFDM)",
          xlabel="Time (us)", ylabel="|x|"); ax[1].grid(alpha=.3)
figA.tight_layout(); figA.savefig("fig_waveform_spectrum.png", dpi=120)

# Fig B: PAPR CCDF
figB, axb = plt.subplots(figsize=(6, 4.2))
papr_sym = []
sym_len = meta['nup']+meta['cp_up']
for s in range(meta['n_sym']):
    seg = x[s*sym_len:(s+1)*sym_len]
    p = np.abs(seg)**2
    papr_sym.append(10*np.log10(p.max()/p.mean()))
papr_sym = np.sort(papr_sym)
ccdf = 1 - np.arange(len(papr_sym))/len(papr_sym)
axb.semilogy(papr_sym, ccdf, lw=1.5)
axb.set(title="PAPR CCDF (per OFDM symbol)", xlabel="PAPR (dB)",
        ylabel="P(PAPR > x)", ylim=(1e-2, 1)); axb.grid(alpha=.3, which='both')
figB.tight_layout(); figB.savefig("fig_papr_ccdf.png", dpi=120)

# Fig C: DPD spectral comparison
figC, axc = plt.subplots(figsize=(8.5, 5))
axc.plot(f/1e6, dB(Pc), lw=1.2, color='0.6', label="Clean (TX)")
axc.plot(f/1e6, dB(P0), lw=1.2, label=f"PA, no DPD  (ACLR1 {a1_0:.1f})")
axc.plot(f/1e6, dB(P1), lw=1.2, label=f"PA + DPD M=0 (ACLR1 {a1_1:.1f})")
axc.plot(f/1e6, dB(P2), lw=1.4, label=f"PA + DPD M=3 (ACLR1 {a1_2:.1f})")
axc.set(title="DPD spectral regrowth — 802.11ax 20 MHz, MCS2",
        xlabel="Frequency (MHz)", ylabel="PSD (dB, norm.)",
        xlim=(-60, 60), ylim=(-65, 5))
axc.legend(fontsize=8, loc='upper right'); axc.grid(alpha=.3)
figC.tight_layout(); figC.savefig("fig_dpd_spectrum.png", dpi=120)

# Fig D: AM/AM of PA with vs without DPD
figD, axd = plt.subplots(figsize=(6, 5))
axd.plot(np.abs(xb), np.abs(y0)/G0, '.', ms=1, alpha=.3, label="no DPD")
axd.plot(np.abs(xb), np.abs(y_mp)/G0, '.', ms=1, alpha=.3, label="DPD M=3")
mx = np.abs(xb).max()
axd.plot([0, mx], [0, mx], 'k--', lw=.8, label="linear")
axd.set(title="AM/AM (PA output referred to input)",
        xlabel="|input|", ylabel="|output| / G"); axd.legend(); axd.grid(alpha=.3)
figD.tight_layout(); figD.savefig("fig_amam.png", dpi=120)
print("\nSaved: fig_waveform_spectrum.png, fig_papr_ccdf.png, fig_dpd_spectrum.png, fig_amam.png")
