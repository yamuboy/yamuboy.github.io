import wx
import wx.lib.agw.genericmessagedialog as GMD
import traceback

#####  Custom Exceptions for tests #####
class InstrumentLoadError(Exception):
    "Error thrown when the instrument can't be loaded"
    pass 
    
class UserAbort(Exception):
    "raised when abort button is pressed in the main GUI"
    pass
    
class DeviceFailedError(Exception):
    "Raised when the device is dead"
    pass
    
class CalAbort(Exception):
    "Raised when the cal abort button is pressed"
    pass 
    
class PowerSearchError(Exception):
    "Raised when the power search method can't find the target within the max iterations"
    pass 
    
class ModuleError(Exception):
    "Custom Exception to catch module errors"
    pass


### Utility methods to set and get the main gui window ###
    
def set_main_window( win ):
    "set the main window"
    global _mainwin
    _mainwin = win    
    
def get_main_window():
    "get the main window"
    return _mainwin

   
### Top level exception handler, ensure exceptions are caught and displayed in a dialog as opposed to command line ###
def MyExceptionHook(etype, value, trace):
    """
    Handler for all unhandled exceptions.
 
    :param `etype`: the exception type (`SyntaxError`, `ZeroDivisionError`, etc...);
    :type `etype`: `Exception`
    :param string `value`: the exception error message;
    :param string `trace`: the traceback header, if any (otherwise, it prints the
     standard Python header: ``Traceback (most recent call last)``.
    """
    frame = wx.GetApp().GetTopWindow()
    tmp = traceback.format_exception(etype, value, trace)
    exception = "".join(tmp)
 
    dlg = ExceptionDialog(exception)
    dlg.ShowModal()
    dlg.Destroy()
    
class ExceptionDialog(GMD.GenericMessageDialog):
    def __init__(self, msg):
        """Constructor"""
        GMD.GenericMessageDialog.__init__(self, None, msg, "Exception!",wx.OK|wx.ICON_ERROR)
        
### arange equivalent when needed ###
def arange(start,stop,step=1.0):
    "compute a range of values returned as a list"    
    if start == stop:
        return [start]
        
    if start > stop and step > 0.0:
        raise ValueError("'start' > 'stop' with 'step' > 0.0 is not possible")    
    elif start < stop and step < 0.0:
        raise ValueError("'start' < 'stop' with 'step' < 0.0 is not possible")
    
    if step == 0.0:
        raise ValueError("'step' cannot be 0.0")
    
    v = start
    ret = []
    while v < stop:
        ret.append(v)
        v += step
    
    return ret
        
    
####### File Header Information Dialog ########

class file_header_gui(wx.Dialog):
    def __init__(self,controls,*args,**kwargs):
        super(file_header_gui,self).__init__(*args,**kwargs)
        self.controls = controls
        self.initUI()
    def initUI(self):
        #Dialog that allows the user to enter the data file header, process, temp, etc
                        
        # Create boxes for file header input
        wafer_txt = wx.StaticText(self, -1, label="Wafer :")
        self.controls['wafer_name'] = wx.TextCtrl(self, value = " ", style = 0)
        process_txt = wx.StaticText(self, -1, label="Process :")
        self.controls['process_name'] = wx.TextCtrl(self, value = " ", style = 0)
        device_txt = wx.StaticText(self, -1, label="Device :")
        self.controls['device_name'] = wx.TextCtrl(self, value = " ", style = 0)
        cal_kit_txt = wx.StaticText(self, -1, label="Cal Kit :")
        self.controls['cal_kit_name'] = wx.TextCtrl(self, value = " ", style = 0)
        temp_txt = wx.StaticText(self, -1, label="Temperature (C) :")
        self.controls['temp'] = wx.TextCtrl(self, value = "27.0", style = 0)
        comments_txt = wx.StaticText(self, -1, label="Comments :")
        self.controls['comments'] = wx.TextCtrl(self, value = " ", style = 0)
        
        ok_btn = wx.Button(self,wx.ID_OK)
        
        # Create a flexgrid sizer
        file_fgs = wx.FlexGridSizer(rows=7, cols=2, hgap=9, vgap=10)
        file_fgs.Add(wafer_txt, 0,0)
        file_fgs.AddMany([(self.controls['wafer_name'],1,wx.EXPAND),(process_txt),(self.controls['process_name'],1,wx.EXPAND),(device_txt),(self.controls['device_name'],1,wx.EXPAND),(cal_kit_txt),(self.controls['cal_kit_name'],1,wx.EXPAND),
                 (temp_txt),(self.controls['temp'],1,wx.EXPAND),(comments_txt),(self.controls['comments'],1,wx.EXPAND)])
        file_fgs.Add(ok_btn, 6,0)
        
        file_fgs.AddGrowableRow(5,1)
        file_fgs.AddGrowableCol(1,5)
        
        file_main_sizer = wx.BoxSizer(wx.VERTICAL)
        file_main_sizer.Add(file_fgs, 1, wx.ALL|wx.EXPAND, 15)
        self.SetTitle("Data File Header Entry")
        self.SetSizer(file_main_sizer)                
        self.Fit()
    
    
    
    