from MTACS_2 import mtacs_main
import wx

if __name__ == "__main__": 
    #sys.excepthook = ExceptionHook
    app = wx.App(redirect=False) 
    frame_1 = mtacs_main(None, -1) 
    app.SetTopWindow(frame_1) 
    frame_1.Show() 
    app.MainLoop()