import numpy
import os
import wx
from instrument import multisite

import wafer_map_expts 

class edit_wafermap_dlg(wx.Dialog):
    def __init__(self,m_dict,*args,**kwargs):
        super(edit_wafermap_dlg,self).__init__(*args,**kwargs)
        self.m_dict = m_dict
        self.initUI()
        
    def initUI(self):
        
        self.controls = {}        
        #Dialog that allows the user to enter the data file header, process, temp, etc
        wafer_txt = wx.StaticText(self, -1, label="Wafer Diameter:")
        self.controls['wafer_diameter'] = wx.TextCtrl(self, value = str(self.m_dict['wafer_diameter']), style = 0)
        retx_txt = wx.StaticText(self, -1, label="Reticle x dim :")
        self.controls['reticle_x'] = wx.TextCtrl(self, value = str(self.m_dict['reticle_x']), style = 0)
        rety_txt = wx.StaticText(self, -1, label="Reticle Y dim :")
        self.controls['reticle_y'] = wx.TextCtrl(self, value = str(self.m_dict['reticle_y']), style = 0)
        xref_txt = wx.StaticText(self, -1, label="X reference :")
        self.controls['x_ref'] = wx.TextCtrl(self, value = str(self.m_dict['x_ref']), style = 0)
        yref_txt = wx.StaticText(self, -1, label="Y reference :")
        self.controls['y_ref'] = wx.TextCtrl(self, value = str(self.m_dict['y_ref']), style = 0)
        mf_txt = wx.StaticText(self, -1, label="Major Flat :")
        self.controls['major_flat'] = wx.TextCtrl(self, value = str(self.m_dict['major_flat']), style = 0)
        
        ok_btn = wx.Button(self,wx.ID_OK)
        
        # Create a flexgrid sizer
        file_fgs = wx.FlexGridSizer(rows=7, cols=2, hgap=9, vgap=10)
        file_fgs.Add(wafer_txt, 0,0)
        file_fgs.AddMany([(self.controls['wafer_diameter'],1,wx.EXPAND),(retx_txt),(self.controls['reticle_x'],1,wx.EXPAND),(rety_txt),(self.controls['reticle_y'],1,wx.EXPAND),(xref_txt),(self.controls['x_ref'],1,wx.EXPAND),
                 (yref_txt),(self.controls['y_ref'],1,wx.EXPAND),(mf_txt),(self.controls['major_flat'],1,wx.EXPAND)])
        file_fgs.Add(ok_btn, 6,0)
        
        file_fgs.AddGrowableRow(5,1)
        file_fgs.AddGrowableCol(1,5)
        
        file_main_sizer = wx.BoxSizer(wx.VERTICAL)
        file_main_sizer.Add(file_fgs, 1, wx.ALL|wx.EXPAND, 15)
        self.SetTitle("Edit Wafer Map")
        self.SetSizer(file_main_sizer)                
        self.Fit()
        
    def get_edited_wafer_params(self):
        edited_vals = {}
        for i in self.controls:
            edited_vals[i] = self.controls[i].GetValue()
        return edited_vals
        
        

class reticle_frame(wx.Frame):
    # Display the reticle dialog with the list of dies
    # Just need dies and die_locs
    def __init__(self,parent,reticle_dict):
        wx.Frame.__init__(self,parent)
        self.parent = parent
        self.reticle_dict = reticle_dict
        self.init()
        
    def init(self):
        menubar = wx.MenuBar()
        
        file_menu = wx.Menu()
        file1 = file_menu.Append(wx.ID_SAVE,"Measure Die Selected...")
        file_menu.AppendSeparator()
        file2 = file_menu.Append(wx.ID_EXIT,"Exit...")
        
        self.Bind(wx.EVT_MENU,self.OnMeasureSelectedDie,file1)
        self.Bind(wx.EVT_MENU,self.OnExit,file2)
        
        menubar.Append(file_menu, "File")
        self.SetMenuBar(menubar)
        
        self.die_selected = None
        
        d_locs = dict()
        
        for x in self.reticle_dict:
            d_locs[x['location']] = x['name']
        
        self.reticle_grid = wx.grid.Grid(self)
        # die locations are tuples of (col,row)
        # get all the die columns
        self.reticle_grid.CreateGrid(5,5)
        for d in d_locs.iterkeys():
            self.reticle_grid.SetCellValue(d[1]-1,d[0]-1,d_locs[d])
        self.Bind(wx.grid.EVT_GRID_CELL_LEFT_DCLICK, self.OnCellLeftClick)
        self.Bind(wx.grid.EVT_GRID_CELL_RIGHT_DCLICK,self.OnCellRightClick)
        
    def OnCellRightClick(self,event):
        self.r = event.GetRow()
        self.c = event.GetCol()
        self.reticle_grid.SetCellBackgroundColour(self.r,self.c,wx.WHITE)
        
    def OnCellLeftClick(self,event):
        self.r = event.GetRow()
        self.c = event.GetCol()
        self.die_name = self.reticle_grid.GetCellValue(self.r,self.c)
        self.die_loc = (self.r+1,self.c+1)
        self.reticle_grid.SetCellBackgroundColour(self.r,self.c,wx.CYAN)
        
    def set_die_locations(self,die_l):
        self.die_locs = die_l
        
    def OnMeasureSelectedDie(self,evt):
        wx.CallAfter(self.parent.set_reticle_die,(self.die_name,self.die_loc))
        self.Close()
        
    def OnExit(self,evt):
        self.Close()       
            
        

class multisite_window(wx.Frame):
    def __init__(self,*args,**kwargs):
        super(multisite_window,self).__init__(*args,**kwargs)
        self.init()
        
    def init(self):
        # Create a menu for the wafer mapping utility
        
        # If the wafer map extension is .map, it disables the reticle utility 
        # This is because it assumes the user's doing an "old" style multisite test
                
        menubar = wx.MenuBar()       
        
        file_menu = wx.Menu()
        file1 = file_menu.Append(wx.ID_OPEN,'Load Wafer Map...')
        file2 = file_menu.Append(wx.ID_SAVE, 'Save Wafer Map...')
        file3 = file_menu.Append(wx.ID_ANY, 'Create Wafer Map...')
        file_menu.AppendSeparator()
        file4 = file_menu.Append(wx.ID_EXIT, 'Exit')
        
        self.Bind(wx.EVT_MENU,self.load_wafer_map,file1)
        self.Bind(wx.EVT_MENU,self.save_wafer_map,file2)
        self.Bind(wx.EVT_MENU,self.create_wafer_map,file3)
        self.Bind(wx.EVT_MENU,self.on_exit,file4)        
               
        # Edit menu item
        edit_menu = wx.Menu()
        edit1 = edit_menu.Append(wx.ID_ANY,"Edit Wafer Map...")
        edit2 = edit_menu.Append(wx.ID_ANY,"Edit Reticle...")
        self.Bind(wx.EVT_MENU,self.edit_wafer_map, edit1)
        self.Bind(wx.EVT_MENU,self.edit_reticle, edit2)
                
        menubar.Append(file_menu,'File')
        menubar.Append(edit_menu,'Edit')
        
        self.SetMenuBar(menubar)
        
        self.measure_selected = wx.Button(self,wx.ID_ANY,"Measure Selected")
        self.measure_all = wx.Button(self,wx.ID_ANY,"Measure All")
        button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        button_sizer.Add(self.measure_selected, wx.LEFT|wx.ALL)
        button_sizer.Add(self.measure_all,wx.RIGHT|wx.ALL)
        
        self.Bind(wx.EVT_BUTTON, self.OnMeasureSelected, self.measure_selected)
        self.Bind(wx.EVT_BUTTON, self.OnMeasureAll,self.measure_all)
        
        self.wafer_grid = wx.grid.Grid(self)
        # Create an initial grid with 10 rows and 10 cols
        self.wafer_grid.CreateGrid(10,10)
        self.Bind(wx.grid.EVT_GRID_CELL_LEFT_DCLICK,self.OnDieSelected,self.wafer_grid)
        self.Bind(wx.grid.EVT_GRID_CELL_RIGHT_DCLICK,self.OnDieUnSelected,self.wafer_grid)
                
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        main_sizer.Add(self.wafer_grid,-1,wx.EXPAND|wx.ALL)
        main_sizer.Add(button_sizer,-1,wx.ALIGN_CENTER)
        
        self.SetSizer(main_sizer)
        self.SetSize((900,400))
        self.die_selected = []        
        
        self.wm = multisite.Multisite()
                   
                
    def OnMeasureSelected(self,evt):
        # Clear sites, add selected sites to the site list and return the multisite object to main
        self.wm.clear_sites()
        for die in self.die_selected:
            self.wm.add_site(die[0],die[1])
        parent = self.GetParent()
        parent.set_multisite_controller(self.wm)
                
    def OnMeasureAll(self,evt):
        # Return the multisite object to main
        parent = self.GetParent()
        parent.set_multisite_controller(self.wm)
        
    def OnDieSelected(self,evt):
        self.r = evt.GetRow()
        self.c = evt.GetCol()
        t = self.wafer_grid.GetCellValue(self.r,self.c)
        self.die_selected.append((int(t[0:2]),int(t[2:])))
        self.wafer_grid.SetCellBackgroundColour(self.r,self.c,wx.CYAN)

    def OnDieUnSelected(self,evt):
        self.r = evt.GetRow()
        self.c = evt.GetCol()
        self.wafer_grid.SetCellBackgroundColour(self.r,self.c,wx.WHITE)        
    
    def _update_window(self):
        if self.map_loaded:
            sites = self.wm.all_sites(rettype = 'coord')
            col_count = set(i[0] for i in sites)
            row_count = set(i[1] for i in sites)
            #self.wafer_grid.CreateGrid(len(col_count)+1, len(row_count)+1)
            for i in sites:
                # Create names on the fly instead of calling all_sites again
                site = "0%d0%d"%(i[0],i[1])
                self.wafer_grid.SetCellValue(i[1]-1,i[0]-1,site)                   
                        
        
    def load_wafer_map(self, evt):
        # Create a file dialog to select the wafer map file
        dlg = wx.FileDialog(self, "Choose a File:",os.getcwd(),"","(*.cfg,*.map,*.rmap)|*.cfg;*.map;*.rmap",wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            fname = os.path.basename(path)
        dlg.Destroy()
        # Read the wafer map data
        self.wm.read_map(fname)
        # update the grid on the wafer map main window
        self.map_loaded = True
        self._update_window()
                
        
    def save_wafer_map(self, evt):
        dlg = wx.FileDialog(self, "Save file as...",os.getcwd(),"","*.cfg",wx.FD_SAVE)
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            fname = os.path.basename(path)
        dlg.Destroy()
        self.wm.write_map_data(fname)        
        
    def create_wafer_map(self, evt):
        # This allows the user to create a wafer map. The user has to enter the wafer size, and add the number of reticles, die info, etc
        # Get dialog from wafer map utils
        raise NotImplemented
        
    def edit_wafer_map(self, evt):
        if self.wm.map_type == 'nr':
            dlg = wx.MessageDialog(self,message = 'This Feature is only available for maps with reticle info',style = wx.OK)
            if dlg.ShowModal() == wx.OK:
                dlg.Destroy()
        else:            
            m_dict = self.wm.get_map_dict()
            dlg = edit_wafermap_dlg(m_dict, parent = None)
            if dlg.ShowModal() == wx.ID_OK:
                self.wm.set_map_dict(dlg.get_edited_wafer_params())
            dlg.Destroy()
            
    def edit_reticle(self,evt):
        if self.wm.get_map_type() == 'nr':
            dlg = wx.MessageDialog(self,message = 'No Reticle Information Available for this map file',style = wx.OK)
            if dlg.ShowModal() == wx.ID_OK:
                dlg.Destroy()
        else:
            reticle_dict = self.wm.get_reticle_dict()
            r_frame = reticle_frame(self,reticle_dict)
            r_frame.Show()
            
    def set_reticle_die(self,die):
        print die
        self.wm.set_die_tbm(die[0],die[1])
               
    def on_exit(self, evt):
        self.Close()

if __name__ == "__main__":
    app = wx.App(redirect = False)
    main_frame = multisite_window(None, -1)
    app.SetTopWindow(main_frame)
    main_frame.Show()
    app.MainLoop()        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        