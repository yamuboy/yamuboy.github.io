





class InstrumentManager:
    """This class maintains a set of configured instruments.
    
    This is basically an instrument "pool", that allows test routines
    to grab instruments by using a name or a name and a "class" of instrument.
    """
    
    # the instrument pool, which is simply a dictionary of instrument objects
    # keyed off the instrument name
    __pool = {}
    
    
    def get_instrument(self, name, cls=None):
        """Retrieve an instrument by name.
        
        Arguments:
        name - the instrument name, which is case insensitive
        cls - the optional instrument class name to restrict the instrument to
        
        Returns: the instrument object.
        """
        
        if not name.lower() in self.__pool:
            raise InstrumentNotFound(name.lower())
        
        instr = self.__pool[name.lower()]
        if cls is not None and not isinstance(instr,cls):
            raise InstrumentNotFound(name.lower())
        
        return instr
        
    def new_instrument(self, name, cls, resource=None, driver=None, **kwargs):
        """Create a new instrument.  Then store it in the pool and return a
        reference to it.
        
        Arguments:
        name - the name for the new instrument (must be unique within the
           instrument manager namespace
        cls - the class name of the instrument to create
        resource - the VISA resource string that describes how to connect
           to the instrument
        driver - the name of the driver for the instrument
        
        Returns: the newly created instrument object
        """
        
        name2 = name.lower()
        
        # make sure that the name is not already being used
        if name2 in self.__pool:
            raise InstrumentCreateFailed("an instrument named '%s' already exists"%name2)
        
        instr = create_instrument(cls, name2, resource, driver, **kwargs)
        
        self.__pool[name2] = instr
        
        return instr
        
    def remove_instrument(self, name, cls=None):
        """Remove an instrument from the manager.
        
        Arguments:
        name - the instrument name, which is case insensitive
        cls - the optional instrument class name to restrict the instrument to
        """
        
        
        
        
        
        
    def get_instruments(self):
        """Get a dictionary of all the instruments defined."""
        return self.__pool
        
    
    def verify_instruments(self, *args):
        """Verify that connections to instruments can be achived.
        
        
        
        
        
        
        