import wx
import re as _re
import os
import logging
import focus_piv_module
from wxtestgui.edit_params import EditTestParamsDialog,EditNumberListDialog
from wxtestgui.edit_instruments import InstrumentConfigDialog
from wxtestgui import TestParameters, Instr
import threading
import traceback
import sys
from maplot.pivplotlib import WxPIVPlotPanel
import wx.lib.agw.genericmessagedialog as GMD
from wx.lib.pubsub import pub
logger = logging.getLogger(__name__)

LEVELS = [
 logging.DEBUG, 
 logging.INFO,
 logging.ERROR,
 logging.WARNING
 ]

class WxTextCtrlHandler(logging.Handler):
    def __init__(self, ctrl):
        logging.Handler.__init__(self)
        self.ctrl = ctrl

    def emit(self, record):
        s = self.format(record) + '\n'
        wx.CallAfter(self.ctrl.WriteText, s)

_valid_param_line = _re.compile(r'([a-zA-Z][a-zA-Z0-9_.]*)\s*=')
_valid_instrument_line = _re.compile(r'([a-zA-Z][a-zA-Z0-9_.]*)\s*:')

# Create an Event for thread updates
wxEVT_THREAD_UPDATE = wx.NewEventType()
EVT_THREAD_UPDATE = wx.PyEventBinder(wxEVT_THREAD_UPDATE,1)

class ExceptionDialog(GMD.GenericMessageDialog):
    def __init__(self, msg):
        """Constructor"""
        GMD.GenericMessageDialog.__init__(self, None, msg, "Exception!",wx.OK|wx.ICON_ERROR)

# Catch all exceptions and use a dialog
def MyExceptionHook(etype, value, trace):
    """
    Handler for all unhandled exceptions.
 
    :param `etype`: the exception type (`SyntaxError`, `ZeroDivisionError`, etc...);
    :type `etype`: `Exception`
    :param string `value`: the exception error message;
    :param string `trace`: the traceback header, if any (otherwise, it prints the
     standard Python header: ``Traceback (most recent call last)``.
    """
    frame = wx.GetApp().GetTopWindow()
    tmp = traceback.format_exception(etype, value, trace)
    exception = "".join(tmp)
 
    dlg = ExceptionDialog(exception)
    dlg.ShowModal()
    dlg.Destroy()

class ManualBiasDialog(wx.Dialog):
    """
    This Dialog Allows the user to Manually bias a device with a Vd and Vg pulse specified
    """
    def __init__(self,*args,**kwargs):
    
        if 'parent' in kwargs:
            parent = kwargs['parent']
        if 'piv_module' in kwargs:
            self.piv_module = kwargs.pop('piv_module')
            
        
        super(ManualBiasDialog,self).__init__(*args,**kwargs)        
        
        vd_text = wx.StaticText(self,-1,label = "Vd Pulsed (V)")
        self.vd_value = wx.TextCtrl(self,value = " ",style = 0)
        vdq_text = wx.StaticText(self, -1, label = "Vd Quiescent (V)")
        self.vdq_value = wx.TextCtrl(self,value = " ", style = 0)
        vg_text = wx.StaticText(self,-1,label = "Vg Pulsed(V)")
        self.vg_value = wx.TextCtrl(self,value = " ",style = 0)
        vgq_text = wx.StaticText(self,-1,label = "Vg Quiescent (V)")
        self.vgq_value = wx.TextCtrl(self,value = " ",style = 0)
        id_text = wx.StaticText(self,label = "Id Measured (mA)",style = 0)
        self.id_value = wx.TextCtrl(self, value = " ", style = 0)
        
        measure_button = wx.Button(self, wx.ID_ANY, "Measure")
        close_button = wx.Button(self, wx.ID_CLOSE)
        
        self.Bind(wx.EVT_BUTTON,self.OnMeasure, measure_button)
        self.Bind(wx.EVT_BUTTON, self.OnClose, close_button)
        
        fgs = wx.FlexGridSizer(rows = 6,cols = 2,hgap = 9, vgap = 10)
        fgs.AddMany([(vd_text),(self.vd_value,1,wx.EXPAND),(vdq_text),(self.vdq_value,1,wx.EXPAND),(vg_text),(self.vg_value,1,wx.EXPAND),
                     (vgq_text),(self.vgq_value,1,wx.EXPAND),(id_text),(self.id_value,1,wx.EXPAND)])
        fgs.Add(measure_button, 5,0)
        fgs.Add(close_button, 5,1)
        
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        main_sizer.Add(fgs,1,wx.ALL|wx.EXPAND,10)
        self.SetTitle("Manual Bias Mode")
        self.SetSizer(main_sizer)
        self.Fit()
        
    def OnMeasure(self,evt):
        # Get the values from the window
        vdp = float(self.vd_value.GetValue())
        vdq = float(self.vdq_value.GetValue())
        vgp = float(self.vg_value.GetValue())
        vgq = float(self.vgq_value.GetValue())
        id_meas = self.piv_module.manual_bias(vgq = vgq, vgp = vgp, vdq = vdq, vdp = vdp)
        self.id_value.SetValue(str(id_meas))
        
    def OnClose(self,evt):
        self.piv_module.disable_pulser()
        self.piv_module.disable_pulser()
        self.Destroy()
        
        
# Worker thread that does the work of running the PIV
class RunThread(threading.Thread):
    def __init__(self,*args,**kwargs):
        super(RunThread,self).__init__()
        
        # The test type defines the type of test being performed - q point targeting, standard PIV, etc        
        if 'window' in kwargs:
            self.window = kwargs['window']
        if 'params' in kwargs:
            self.params  = kwargs['params']
        if 'run_func' in kwargs:
            self.run_func = kwargs['run_func']
        if 'fname' in kwargs:
            self.fname = kwargs['fname']
        if 'test_type' in kwargs:
            self.test_type = kwargs['test_type']
        # The type of value the run_function returns        
        if 'return_type' in kwargs:
            self.return_type = kwargs['return_type']
        self.stop = False
        
    def set_run_function(self, run_func):
        self.run_func = run_func
        
    def set_params(self,params):
        self.params = params
        
    def set_test_type(self,test_type):
        self.test_type = test_type 
        
    def run(self):
        if self.test_type == 'q_point':
            status = self.run_func(self.params)
            if status == 'success':
                wx.CallAfter(self.window.OnTestDone, message = 'Q Point Found!')
            else:
                wx.CallAfter(self.window.OnTestDone, message = 'Q Point Not Found!')
        if self.test_type == 'run_piv':            
            genresult = None
            d = self.run_func(self.fname)
            while True:
                try:
                    t = d.send(genresult)
                    self.window.PlotPanel.update_plot(dat = t,fname = None)                    
                except self.Stop == True:
                    break
            wx.CallAfter(self.window.OnTestDone,message = 'Test Complete!')
               
    def Stop(self):
        self.Stop = True            
   

class PIV_Main(wx.Frame):
    def __init__(self,*args,**kwargs):
        super(PIV_Main,self).__init__(*args,**kwargs)
        
        # Set up controls for some of the GUI objects
        self.controls = {}
        self.params = focus_piv_module.TEST_PARAMS
        self.instrs = focus_piv_module.INSTR_LIST
        self.test_params = TestParameters(self.params)
        self.test_instrs = {}
        
        # Create a Focus PIV object
        self.piv = focus_piv_module.PIVControl()
        
        sys.excepthook = MyExceptionHook
        
        
        self.Notebook = wx.Notebook(self, -1, style = 0)
        self.MainPanel = wx.Panel(self.Notebook,-1)
        self.PlotPanel = WxPIVPlotPanel(self.Notebook)
        
        # Make sure that the plot panel is in live mode       
        self.PlotPanel.set_live_mode(True)        
        
        menubar = wx.MenuBar()
        
        # File Menu 
        file_menu = wx.Menu()
        file1 = file_menu.Append(wx.ID_OPEN,"Load Config..")
        file2 = file_menu.Append(wx.ID_SAVE,"Save Config..")
        file_menu.AppendSeparator()
        
        file3 = file_menu.Append(wx.ID_EXIT,"Exit")
        # Bind menu items to events
        self.Bind(wx.EVT_MENU,self.OnLoadConfig,file1)
        self.Bind(wx.EVT_MENU,self.OnSaveConfig,file2)
        self.Bind(wx.EVT_MENU,self.OnExit,file3)
        
        setup_menu = wx.Menu()
        setup1 = setup_menu.Append(wx.ID_ANY, "Instrument Setup")
        self.Bind(wx.EVT_MENU,self.OnInstrumentSetup,setup1)
        
        menubar.Append(file_menu,"File")
        menubar.Append(setup_menu,"Setup")
        
        self.SetMenuBar(menubar)
        
        test_info_box = wx.StaticBox(self.MainPanel, label = "Test Module Information")
        test_info_box_sizer = wx.StaticBoxSizer(test_info_box, wx.HORIZONTAL)
        self.controls['test_info'] = wx.TextCtrl(self.MainPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        test_info_box_sizer.Add(self.controls['test_info'],1,wx.EXPAND,5)        
        
        # Test Setup Box
        setup_box = wx.StaticBox(self.MainPanel, label = "Setup Menu")
        setup_sizer = wx.StaticBoxSizer(setup_box,wx.VERTICAL)
        #self.controls['instrument_setup'] = wx.Button(self.MainPanel, wx.ID_ANY,"Instruments")
        self.controls['edit_params'] = wx.Button(self.MainPanel,wx.ID_ANY,"Edit Parameters")
        # Bind buttons 
        #self.Bind(wx.EVT_BUTTON, self.OnInstrumentSetup,self.controls['instrument_setup'])
        self.Bind(wx.EVT_BUTTON, self.OnEditParams, self.controls['edit_params'])
        
        #setup_sizer.Add(self.controls['instrument_setup'],1,wx.CENTER,5)
        setup_sizer.Add(self.controls['edit_params'],1,wx.CENTER,5)
                
        
        # Calibrate, set-cursors, and q point test
        test_box = wx.StaticBox(self.MainPanel, label = "Test Menu")
        test_sizer = wx.StaticBoxSizer(test_box, wx.VERTICAL)
        self.controls['cursors'] = wx.Button(self.MainPanel,wx.ID_ANY,"Setup Cursors")
        self.controls['q_point'] = wx.Button(self.MainPanel, wx.ID_ANY, "Set Q Point")
        self.controls['manual_bias'] = wx.Button(self.MainPanel, wx.ID_ANY, "Manual Bias")
        
        self.Bind(wx.EVT_BUTTON, self.OnSetupCursors,self.controls['cursors'])
        self.Bind(wx.EVT_BUTTON, self.OnSetQ, self.controls['q_point'])
        self.Bind(wx.EVT_BUTTON, self.OnManualBias, self.controls['manual_bias'])
        
        test_sizer.Add(self.controls['cursors'],1,wx.CENTER,5)
        test_sizer.Add(self.controls['q_point'],1,wx.CENTER,5)
        test_sizer.Add(self.controls['manual_bias'],1,wx.CENTER, 5)
        
        
        # Run Test Options
        run_box = wx.StaticBox(self.MainPanel, label = "Run Menu")
        run_sizer = wx.StaticBoxSizer(run_box,wx.VERTICAL)
        self.controls['run'] = wx.Button(self.MainPanel, wx.ID_ANY, "Run Test")
        self.controls['abort'] = wx.Button(self.MainPanel, wx.ID_ANY, "Abort Test")
        self.controls['run'].SetBackgroundColour("Green")
        self.controls['abort'].SetBackgroundColour("Red")
        
        self.Bind(wx.EVT_BUTTON,self.OnRun, self.controls['run'])
        self.Bind(wx.EVT_BUTTON,self.OnAbort, self.controls['abort'])
        
        run_sizer.Add(self.controls['run'],1,wx.CENTER,5)
        run_sizer.Add(self.controls['abort'],1,wx.CENTER,5)
        
        # Text Control for the logging utility
        logging_info_box = wx.StaticBox(self.MainPanel,label = "Test Logger")
        
        logging_box_sizer = wx.StaticBoxSizer(logging_info_box,wx.HORIZONTAL)
        self.controls['test_logger'] = wx.TextCtrl(self.MainPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        logging_box_sizer.Add(self.controls['test_logger'],1,wx.EXPAND|wx.ALL,5)   
        handler = WxTextCtrlHandler(self.controls['test_logger'])
        logger.addHandler(handler)
        FORMAT = "%(asctime)s %(levelname)s %(message)s"
        handler.setFormatter(logging.Formatter(FORMAT))
        logger.setLevel(logging.DEBUG)
        
        main_button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        main_button_sizer.Add(setup_sizer,1,wx.LEFT,5)
        main_button_sizer.Add(test_sizer,1,wx.CENTER,5)
        main_button_sizer.Add(run_sizer,1, wx.RIGHT,5)

        main_panel_sizer = wx.BoxSizer(wx.VERTICAL)
        main_panel_sizer.Add(test_info_box_sizer, 0, wx.EXPAND|wx.ALL)
        main_panel_sizer.Add((-1,20))
        main_panel_sizer.Add(main_button_sizer, 0, wx.EXPAND|wx.ALL)
        main_panel_sizer.Add((-1,20))
        main_panel_sizer.Add(logging_box_sizer,0,wx.EXPAND|wx.BOTTOM, 10)
        
        self.Notebook.AddPage(self.MainPanel, "Main")
        self.Notebook.AddPage(self.PlotPanel, "PIV Plot")
        
        self.MainPanel.SetSizer(main_panel_sizer)
        
        self.Fit()                
        self.SetSize((500,500))
        self.SetPosition((100,100))
        self.SetTitle("Pulsed IV Software")

        self._update_gui()
        
        
    def StartBusy(self):
        self.timer.Start(100)
        self.controls['run'].Disable()
        
    def StopBusy(self):
        self.timer.Stop()

    def _update_gui(self):
        # Use this to grey out buttons when tests are running
        pass

    def OnManualBias(self,evt):
        dlg = ManualBiasDialog(parent = self, piv_module = self.piv)
        dlg.Show()
        
    def OnLoadConfig(self,evt):
        # Load the test configuration file
        kw = {'style':wx.FD_OPEN}
        dlg = wx.FileDialog(self,'Load Test Config',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            f = open(fname, 'r')
            params = {}
            instrs = {}
            for line in f:
                m = _valid_param_line.match(line)
                i = _valid_instrument_line.match(line)
                if m:
                    params[m.group(1)] = line[line.index('=')+1:].strip('\n')
                if i:
                    instrs[i.group(1)] = eval(line[line.index(':')+1:].strip('\n'))
            for k,v in params.iteritems():
                if k in self.test_params._TestParameters__params:
                    self.test_params._TestParameters__params[k].value = eval(v)
            for k in instrs:
                for i in self.instrs:
                    if k == i.name:
                        i.driver_name = instrs[k][0]
                        i.resource = instrs[k][1]
                        i.chan = instrs[k][2]
                        i.params = instrs[k][3]
            f.close()
            dlg.Destroy()
            for instr in self.instrs:
                self.test_instrs[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)
            self.piv.set_test_instrs(self.instrs)
            self.piv.set_test_params(self.test_params)        
        logger.log(logging.INFO, "Config Loaded Successfully")
        
    def OnSaveConfig(self,evt):
        # Save the test configuration file
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT,'wildcard':"Test Setup Files (*.stp)|*.stp"}
        dlg = wx.FileDialog(self,'Save Test Config',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            keys = self.test_params._TestParameters__params.keys()
            keys.sort()
            f = open(fname,'w')
            f.write("#Test Parameters\n")
            for k in keys:
                p = self.test_params._TestParameters__params[k]
                v = p.value
                wv = repr(v)
                f.write("%s = %s\n"%(k,wv))
            f.write('\n')                
            f.write("#Instruments\n")
            for inst in self.test_instrs:
                f.write("%s : %s\n"%(inst,repr(self.test_instrs[inst])))            
            f.close()
            dlg.Destroy()
            logger.log(logging.INFO,"Config Saved")
        
        
    def OnExit(self,evt):
        dlg = wx.MessageDialog(self, 'Are You Sure You Want To Exit?', 'Exit', wx.YES_NO|wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlg.Destroy()
            self.Close()
        else:
            dlg.Destroy()
        
    def OnInstrumentSetup(self,evt):
        dlg = InstrumentConfigDialog(self.instrs,parent = self)
        if dlg.ShowModal() == wx.ID_OK:
            self.test_instrs = {}
            for instr in self.instrs:
                self.test_instrs[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)
            logger.log(logging.INFO,"Instrument Information Entered")
            dlg.Destroy()
        self.piv.set_test_instrs(self.instrs)
        
    def OnEditParams(self,evt):
        dlg = EditTestParamsDialog(self.test_params.get_dialog_list(),None,style = wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        if dlg.ShowModal() == wx.ID_OK:
            # Get the modified test parameters for the test
            self.test_params = TestParameters(self.params)
            logger.log(logging.INFO,"Test Parameters Edited")
            dlg.Destroy()
        self.piv.set_test_params(self.test_params)    
        
        
    def OnSetupCursors(self,evt):
        
        dlg = wx.MessageDialog(self,message="Please Adjust O-Scope Cursors and Then Press OK to Continue",style= wx.OK)
        self.piv.set_cursors()
        if dlg.ShowModal() == wx.ID_OK:
            logger.log(logging.INFO,"Cursors Adjusted")
            self.piv.disable_pulser()
            dlg.Destroy()
        else:
            logger.log(logging.WARNING,"Cursors Maintained at Original Position")
        
    def OnSetQ(self,evt):
        # Dialog for the Q point Targeting Routine
        dlg = wx.TextEntryDialog(self,"Enter the Drain Current Target in mA :","Q Point Targeting")
        if dlg.ShowModal() == wx.ID_OK:
            target = float(dlg.GetValue())
            dlg.Destroy()
            self.piv.target_q_point(target)      
        
          
    def OnRun(self,evt):
        f = open('dummy_data.dat','w')
        self.worker = RunThread(window = self, run_func = self.piv.test, fname = f)
        self.worker.start()
        
    def OnTestDone(self,message):
        dlg = wx.MessageDialog(parent=self,message= message,style = wx.OK)
        if dlg.ShowModal() == wx.ID_OK:
            dlg.Destroy()
                
    def OnAbort(self,evt):
        pass
        
if __name__ == "__main__":
    app = wx.App(redirect = False)
    main_frame = PIV_Main(None, -1)
    app.SetTopWindow(main_frame)
    main_frame.Show()
    app.MainLoop()
        
    