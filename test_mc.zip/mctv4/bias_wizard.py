"""
A bias wizard that allows the user to create a custom bias plan.
"""
import wx
from wxtestgui import Instr
from wxtestgui.edit_params import EditTestParamsDialog, EditNumberListDialog, EditOrderedListDialog

BIAS_INSTRUMENTS = [ 
    Instr('bias1','bias',label = 'source 1'),
    Instr('bias2','bias',label = 'source 2'),
    Instr('bias3','bias',label = 'source 3'),
    Instr('bias4','bias',label = 'source 4'),
    Instr('bias5','bias',label = 'source 5'),
    Instr('bias6','bias',label = 'source 6'),
    Instr('meas1','dmm',label = 'DMM 1'),
    Instr('meas2','dmm',label = 'DMM 2'),
    Instr('meas3','dmm',label = 'DMM 3'),
    Instr('meas4','dmm',label = 'DMM 4'),
    Instr('meas5','dmm',label = 'DMM 5'),
    Instr('meas6','dmm',label = 'DMM 6'),        
]

class SourcePanel(wx.Panel):
    def __init__(self,parent):
        wx.Panel.__init__(self,parent)
        
        self.parent = parent
        
        self.source_box = wx.StaticBox(self, label = "Sources")
        self.source_sizer = wx.StaticBoxSizer(self.source_box, wx.VERTICAL)
        
        self.supplies_added = []
        
        self.SetSizer(self.source_sizer)
        
    def add_source(self, bias):
        self.supplies_added.append(bias)
        tmp_sizer = wx.FlexGridSizer(1, 5, 10, 10)
        txt1 = wx.StaticText(self, -1, bias)
        # Button to modify the bias list
        self.list_btn = wx.Button(self, wx.ID_ANY, "Bias List")
        self.Bind(wx.EVT_BUTTON, self.OnModifyBias, self.list_btn)
        txt2 = wx.StaticText(self, -1, "Order")
        self.sweep_order = wx.SpinCtrl(self,-1,'1',min=1, max=6)
        self.dependent = wx.CheckBox(self, -1, "Independent Source?")
        
        tmp_sizer.AddMany([txt1,self.list_btn,txt2,self.sweep_order,self.dependent])
        self.source_sizer.Add(tmp_sizer,1,wx.EXPAND|wx.ALL)
        self.Update()
        self.parent.Update()
        self.parent.Fit()
        
    def delete_source(self,  bias):
        pass        
        
    def OnModifyBias(self):
        pass 
        
    

class biaswiz_main(wx.Frame):
    def __init__(self,*args,**kwargs):
        super(biaswiz_main,self).__init__(*args,**kwargs)
        
        self.current_supplies = []
        self.available_supplies = ['bias'+str(i+1) for i in range(6)]
        self.available_dmms = ['dmm'+str(i+1) for i in range(6)]
        self.instr_vals_mapping = {}
        
        self.init()           
        
        
    def init(self):
    
        menubar = wx.MenuBar()
        
        file_menu = wx.Menu()
        file1 = file_menu.Append(wx.ID_OPEN,"Load Config..")
        file2 = file_menu.Append(wx.ID_SAVE,"Save Config..")
        file_menu.AppendSeparator()
        file3 = file_menu.Append(wx.ID_EXIT,"Exit..")
        
        self.Bind(wx.EVT_MENU, self.OnLoadConfig, file1)
        self.Bind(wx.EVT_MENU, self.OnSaveConfig, file2)
        self.Bind(wx.EVT_MENU, self.OnExit, file3)
        
        menubar.Append(file_menu, 'File')
        
        self.SetMenuBar(menubar)
        
        # Set up the panels for buttons and source display
        splitter = wx.SplitterWindow(self, -1)        
        
        self.btn_panel = wx.Panel(splitter)
        self.source_panel = SourcePanel(splitter)
        
        # Buttons to add sources and dmm's
        self.btn_box = wx.StaticBox(self.btn_panel, label = "Add Sources and DMM's")
        self.btn_sizer = wx.StaticBoxSizer(self.btn_box, wx.HORIZONTAL)
        
        self.add_source = wx.Button(self.btn_panel, wx.ID_ANY, "Add Source")
        self.Bind(wx.EVT_BUTTON, self.OnAddSource, self.add_source)
        self.btn_sizer.Add(self.add_source,1)
        
        self.delete_source = wx.Button(self.btn_panel, wx.ID_ANY, "Delete Source")
        self.Bind(wx.EVT_BUTTON, self.OnDeleteSource, self.delete_source)
        self.btn_sizer.Add(self.delete_source,1)
        
        self.add_dmm = wx.Button(self.btn_panel, wx.ID_ANY, "Add DMM")
        self.Bind(wx.EVT_BUTTON, self.OnAddDmm, self.add_dmm)
        self.btn_sizer.Add(self.add_dmm,1)
        
        self.delete_dmm = wx.Button(self.btn_panel, wx.ID_ANY, "Delete DMM")
        self.Bind(wx.EVT_BUTTON, self.OnDeleteDmm, self.delete_dmm)
        self.btn_sizer.Add(self.delete_dmm, 1)
        
        self.btn_panel.SetSizer(self.btn_sizer) 
        
        
        splitter.SplitHorizontally(self.btn_panel,self.source_panel, 80)
        splitter.UpdateSize()        
        
        
    def OnAddSource(self, evt):
        
        self.source_panel.add_source('bias1')           
     
                
    def _display_supplies(self,supply_name):
    
        pass            
        
        
    def OnModifyBias(self,evt):
        pass 
         

    def OnAddDmm(self, evt):
        pass 

    def OnDeleteSource(self, evt):
        pass

    def OnDeleteDmm(self,evt):
        pass    
        
    def OnLoadConfig(self, evt):
        pass
        
    def OnSaveConfig(self, evt):
        pass 
        
    def OnExit(self, evt):
        self.Close()
        
if __name__ == "__main__":
    app = wx.App(redirect=False) 
    frame_1 = biaswiz_main(None, -1) 
    app.SetTopWindow(frame_1)
    frame_1.Show() 
    app.MainLoop()
        
        
        
        
        
        
        
        
        
    
