import os,sys
import sys
from wxtestgui.worker import Worker,send_to_ui,get_next_message,NoMessages
from utils import InstrumentLoadError, ModuleError, CalAbort, UserAbort
    
    
def check_message_queue(block = False):
    try:
        msg = get_next_message(block)
        if msg.msgtype == "abort":
            raise UserAbort
        if msg.msgtype == "cal abort":
            raise CalAbort
        return msg
    except NoMessages:
        pass
        
        
# Load and open the instruments at runtime
 
def instrument_loader( instr_list, required = [], optional = [] ):
    "load instruments in a safe manner"
    intr = list(set(required).intersection(optional))
    if len(intr):
        raise ValueError("duplicate instrument names exist in `required` and `optional`: %s"%(', '.join(intr)))
    
    out = {}
    tmp = {}
    for instr in instr_list:
        tmp[instr.name] = instr 
                
    try:
        for name in required:
            if name not in tmp:
                raise ValueError("no definition for instrument '%s'"%name)
                
            try:
                out[name] = tmp[name].open_instrument()
                if out[name] is None:
                    raise ValueError('not configured')
            except Exception as e:
                 raise InstrumentLoadError("could not load required instrument '%s' -> %s"%(tmp[name].label,e))
        
        for name in optional:
            if name not in tmp:
                out[name] = None
            else:
                try:
                    out[name] = tmp[name].open_instrument()
                except Exception:
                    # optional instruments do not need to be loaded successfully
                    out[name] = None
    except Exception:
        # unload instruments when exceptions occur during loading
        instrument_unloader(out)
        raise
    
    return out

    
def instrument_unloader( instr ):
    "unload all open instruments"
    for i in instr_dict.values():
        if i:
            try:
                i.close()
            except Exception as e:
                logger.warning("error unloading instrument '%s' -> %s"%(i.name,e))

def new_import(mod_path):
    mod = __import__(mod_path)
    components = mod_path.split('.')
    for comp in components[1:]:
        mod = getattr(mod, comp)
    return mod

class test_mod_loader(object):
    
    _shared_state = dict()
    
    def __init__(self):
        self.__dict__ = self._shared_state
        
        if '_isinitialized' not in self.__dict__:
            
            self._isinitialized = True
            # Populate the module dictionary
            self._module_dict = {'fet':[],'bjt':[],'mosfet':[]}
            # Account for os differences
            if sys.platform == 'win32':
                dir = '~\\modeling\\pylib\mctv4\\routines\\'
            else:
                dir = '/nfs/home/fetdata/pylib/mctv4/routines'
            for i in self._module_dict.iterkeys():
                for j in os.listdir(os.path.expanduser(dir+i)):
                    if j.endswith('.svn') or j.endswith('.pyc') or j == '__init__.py':
                        next
                    else:
                        self._module_dict[i].append(j)
                        
        self.update = ''
        self.required_instrs = []
        self.optional_instrs = []
        
    def get_modules(self):
        return self._module_dict
        
    def get_current_module(self):
        return self.current_module
        
    def load_module(self, device, module):
        try:
            self.current_module = new_import('mctv4.routines.%s.%s'%(device,module.strip('.py')))
        except ImportError:
            raise Exception("Unable to import module %s"%module.strip('.py'))
                        
    def get_module_docstr(self):
        if self.current_module == None:
            raise Exception("Load a module first!")
        return self.current_module.__doc__.strip(" ")
        
    def get_module_params(self):
        if self.current_module == None:
            raise Exception("Load a module first!")
        elif not hasattr(self.current_module, "TEST_PARAMS"):
            raise Exception("The module must have some test parameters")
        return (self.current_module.TEST_PARAMS)
        
    def get_module_instrs(self):
        if self.current_module == None:
            raise Exception("Load a Module first!")
        elif not hasattr(self.current_module, "INSTR_LIST"):
            raise Exception("The Module must have some Instrs")
        return (self.current_module.INSTR_LIST)
        
    def get_module_cal_flag(self):
        if not self.current_module:
            raise Exception("Load a module first!")
        if not hasattr(self.current_module,"CAL_REQD"):
            raise Exception("The module must have a cal flag")
        return (self.current_module.CAL_REQD)
        
    def get_module_cal_function(self):
        if not hasattr(self.current_module,"CAL_FUNCTION"):
            raise Exception("This module requires a cal function")
        return (self.current_module.CAL_FUNCTION)
        
    def get_module_biaswizard_flag(self):
        if not hasattr(self.current_module, "BIAS_WIZARD"):
            raise Exception("Need to know if the module needs a bias wizard")
        return (self.current_module.BIAS_WIZARD)
        
    def get_module_cal_dict(self):
        if hasattr(self.current_module, "CAL_DICT"):
            return(self.current_module.CAL_DICT)
        
    # Actually we don't necessarily need this, could keep it for legacy modules        
    def get_bias_list(self):
        if hasattr(self.current_module, "BIAS_LIST"):
            return(self.current_module.BIAS_LIST)
        
    def get_test_routines(self):
        if hasattr(self.current_module, "ROUTINES"):
            return(self.current_module.ROUTINES)
        else:
            return None        
        
    def set_multisite_controller(self,controller):
        self.multisite_controller  = controller 

    def set_multisite_enable(self,flag):
        # The flag value is true or false, let's the module loader know if multisite is enabled or not
        self.multisite_enable = flag                     
        
        
    def clear_mod_cal(self,reset,c_dict = None):
        self.current_module.set_cal_data(reset, c_dict)
        
    def _get_optional_instrs(self):
        # Get the list of optional and required instrs from the module
        # If it doesn't exist, set it to empty lists
        if hasattr(self.current_module, "REQUIRED_INSTRS"):
            self.required_instrs = self.current_module.REQUIRED_INSTRS
        if hasattr(self.current_module, "OPTIONAL_INSTRS"):
            self.optional_instrs = self.current_module.OPTIONAL_INSTRS
        
    def load_instrs(self, instrs):
        # determine what the required and optional instruments are
        # maybe make that a part of the module definition
        self._get_optional_instrs()
        inst_dict = instrument_loader(instrs, self.required_instrs, self.optional_instrs)
        return inst_dict        
           
    @property
    def run_func(self):
        return self.current_module.RUN_FUNCTION
                
    def validate_params(self,test_params,cal_data):
        # This method validates the test params, returns a fail flag if a parameter isn't valid 
        # Call the module's validator function. If no validator found, return false
        if hasattr(self.current_module,"VALIDATOR"):
            result = self.current_module.VALIDATOR(test_params)
            return result
    
    @property            
    def mod_cal_data(self):
        return self.current_module._cal_data  
    
        
        
        
        
        
        
       
            
        
    
    
            