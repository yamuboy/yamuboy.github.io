"""
Vector fit algorithms given Y params. Can convert to Y Params using some Jay utils.
This algorithm is more robust than Prony's method and can be used for model based param estimation.
 
"""
import numpy as np
import scipy

def convert(fname):
    # Convert to Y-params
    pass 
    
class vector_fit(object):
    def __init__(self,*args,**kwargs):
        if 'yparams' in kwargs:
            self.data = kwargs['yparams']
        if 'sparams' in kwargs:
            self.data = convert(getkwargs['sparams'])
        if 'num_ports' in kwargs:
            self.n_ports = kwargs['num_ports']
        else:
            # Set default num of ports to 2
            self.n_ports = 2
        # num of poles 
        self.n_poles = kwargs['num_poles']
        
        

        

   