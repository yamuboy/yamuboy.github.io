"""
Program to convert different file types
1. mct to mdif
2. s2p to s1p
3. s to y, y to z, etc
4. piv to mdif
"""
import wx
import sys
import os
from network_params import Touchstone,DeembeddingUtil
from modeling.mct_files import split_to_mdif
from piv_to_mdf import convert_piv_to_mdf
import wx.lib.agw.genericmessagedialog as GMD
import traceback

def MyExceptionHook(etype, value, trace):
    """
    Handler for all unhandled exceptions.
 
    :param `etype`: the exception type (`SyntaxError`, `ZeroDivisionError`, etc...);
    :type `etype`: `Exception`
    :param string `value`: the exception error message;
    :param string `trace`: the traceback header, if any (otherwise, it prints the
     standard Python header: ``Traceback (most recent call last)``.
    """
    frame = wx.GetApp().GetTopWindow()
    tmp = traceback.format_exception(etype, value, trace)
    exception = "".join(tmp)
 
    dlg = ExceptionDialog(exception)
    dlg.ShowModal()
    dlg.Destroy()
    
class ExceptionDialog(GMD.GenericMessageDialog):
    def __init__(self, msg):
        """Constructor"""
        GMD.GenericMessageDialog.__init__(self, None, msg, "Exception!",wx.OK|wx.ICON_ERROR)


def s2p_to_s1p(files,use_s22 = False):
    """
    Convert all the files from S2p to s1p. This keeps all original files,
    just gives the new files the same name with a .s1p extension.
    """
    for f in files:
        i = Touchstone(f)
        if i.nports != 2:
            raise ValueError("'%s' is not a 2-port data file"%inname)
        o = i.copy_truncated()
        for p in i:
            if use_s22:
                d = p.data[1,1]
            else:
                d = p.data[0,0]
            o.insert(p.freq, d)
        oname = f.split('.')[0]+'.s1p'
        o.write(oname)        
        
def mct_to_mdif(files,fxa = None, fxb = None):
    if (fxa is not None) or (fxb is not None):
        dmbkw = {'file1':fxa,'file2':fxb}
        deembed_obj = DeembeddingUtil(dmbkw)
    else:
        deembed_obj = None
    for f in files:
        try:
            split_to_mdif(f,prefix = None,deembedding_object = deembed_obj)
        except Exception:
            raise Exception('Unable to Convert File')
            
    
def piv_to_mdif(files):
    for f in files:
        try:
            fname = f.split('.')[1]
            oname = fname+'.mdf'
            convert_piv_to_mdf(f,oname)
        except Exception:
            raise Exception('Unable to Convert File')
    
class options(wx.Dialog):
    """
    Select options for the file converter
    For S2p to s1p select if you want to use s22
    For mct to mdif choose the prefix
    """
    def __init__(self,parent):
    
        self.parent = parent    
        super(options,self).__init__(parent = parent)
        
        main_panel = wx.Panel(self,-1)
        
        s1p_options = ['use s22','use S11']
        self.fxa_path = None
        self.fxb_path = None 

        sys.excepthook = MyExceptionHook        
              
        s1p_box = wx.StaticBox(main_panel, label = 'S2P to S1P Options')
        s1p_box_sizer = wx.StaticBoxSizer(s1p_box, wx.HORIZONTAL)
        s1p_text = wx.StaticText(main_panel,-1, label = "Port Selection")
        self.s1p_sel = wx.ComboBox(main_panel,-1,choices = s1p_options, style = wx.CB_DROPDOWN)
        s1p_box_sizer.Add(s1p_text,wx.LEFT)
        s1p_box_sizer.Add(self.s1p_sel,0,wx.RIGHT|wx.EXPAND,5)        
                
        # Embed or deembed files
        fxa_box_sizer = wx.BoxSizer(wx.HORIZONTAL)
        fxa_text = wx.StaticText(main_panel,-1,label = 'Fixture A File')
        self.fxa_txctrl = wx.TextCtrl(main_panel,-1,"")
        fxa_button = wx.Button(main_panel,wx.ID_ANY, "Select File")
        self.Bind(wx.EVT_BUTTON,self.OnFxA,fxa_button)
        fxa_box_sizer.Add(fxa_text,wx.LEFT|wx.ALL)
        fxa_box_sizer.Add(self.fxa_txctrl,wx.CENTER|wx.ALL)
        fxa_box_sizer.Add(fxa_button,wx.RIGHT|wx.ALL)
        
        fxb_box_sizer = wx.BoxSizer(wx.HORIZONTAL)
        fxb_text = wx.StaticText(main_panel,-1,label = 'Fixture B File')
        self.fxb_txctrl = wx.TextCtrl(main_panel,-1,"")
        fxb_button = wx.Button(main_panel,wx.ID_ANY, "Select File")
        self.Bind(wx.EVT_BUTTON,self.OnFxB,fxb_button)
        fxb_box_sizer.Add(fxb_text,wx.LEFT|wx.ALL)
        fxb_box_sizer.Add(self.fxb_txctrl,wx.CENTER|wx.ALL)
        fxb_box_sizer.Add(fxb_button,wx.RIGHT|wx.ALL)
        
        ok_button = wx.Button(main_panel,wx.ID_OK)
        self.Bind(wx.EVT_BUTTON, self.OkButton, ok_button)
        
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        main_sizer.Add(s1p_box_sizer,0,wx.EXPAND|wx.ALL,5)
        main_sizer.Add((-1,20))
        main_sizer.Add(wx.StaticText(main_panel,-1,label = 'MDIF Conversion Options'),0,wx.CENTER|wx.ALL)
        main_sizer.Add((-1,20))
        main_sizer.Add(fxa_box_sizer,0,wx.EXPAND|wx.ALL,5)
        main_sizer.Add((-1,20))
        main_sizer.Add(fxb_box_sizer,0,wx.EXPAND|wx.ALL,5)
        main_sizer.Add((-1,20))
        main_sizer.Add(ok_button,0,wx.CENTER|wx.ALL,5)
        main_panel.SetSizer(main_sizer)
        self.SetSize((400,400))
        
    def OnFxA(self,evt):
        dlg = wx.DirDialog(self,message = "Select Fixture A File",defaultPath = os.getcwd())
        if dlg.ShowModal() == wx.ID_OK:
            self.fxa_path = dlg.GetPath()
            dlg.Destroy()
            self.fxa_txctrl.SetValue(self.fxa_path)
            
    def OnFxB(self,evt):
        dlg = wx.DirDialog(self,message = "Select Fixture B File",defaultPath = os.getcwd())
        if dlg.ShowModal() == wx.ID_OK:
            self.fxb_path = dlg.GetPath()
            dlg.Destroy()
            self.fxb_txctrl.SetValue(self.fxb_path)
                
    def OkButton(self,evt):
        # Accept the changes and move on
        s1_dict = {0:True, 1:False}
        s1p_opt = self.s1p_sel.GetCurrentSelection()
        
        self.Destroy()
        wx.CallAfter(self.parent.set_selections,use_s22 = s1p_opt,fxa_fname = self.fxa_path, fxb_fname = self.fxb_path)
        
        
    
class converter_main(wx.Frame):
    def __init__(self,*args,**kwargs):
        super(converter_main,self).__init__(*args,**kwargs)
        
        self.controls = {}
        self.files = None
        
        self.MainPanel = wx.Panel(self, -1)
                  
        # Setup the menu bar for the software main window
        menubar    = wx.MenuBar()
        
        # Default Options
        self.use_s22 = False
        self.fxa_fname = None
        self.fxb_fname = None
        
        #File Menu
        file_menu  = wx.Menu()
        file1 = file_menu.Append(wx.ID_ANY, "Options..")
        file_menu.AppendSeparator()
        file2 = file_menu.Append(wx.ID_EXIT,"Exit", "Exit")
        #File Menu Action Handlers
        self.Bind(wx.EVT_MENU, self.OnOptions, file1)
        self.Bind(wx.EVT_MENU, self.OnExit, file2)
                
        #Add Menus to Menubar
        menubar.Append(file_menu,"File")
        self.SetMenuBar(menubar)
        
        #Browse directory
        browse_box = wx.StaticBox(self.MainPanel, label = 'Current Working Directory')
        browse_sizer = wx.StaticBoxSizer(browse_box, wx.HORIZONTAL)
        self.controls['curr_dir'] = wx.TextCtrl(self.MainPanel,-1,"")
        self.controls['browse_button'] = wx.Button(self.MainPanel, wx.ID_ANY, "Change Current Directory")
        self.controls['curr_dir'].SetValue('%s'%os.getcwd())
        browse_sizer.Add(self.controls['curr_dir'],wx.EXPAND)
        browse_sizer.Add(self.controls['browse_button'])
        
        self.Bind(wx.EVT_BUTTON, self.onChcurrdir, self.controls['browse_button'])
                             
        
        # Radio buttons for the different conversion types
        mode_box = wx.StaticBox(self.MainPanel, label = 'Conversion Option')
        mode_sizer = wx.StaticBoxSizer(mode_box, wx.VERTICAL)        
        self.controls['rb1'] = wx.RadioButton(self.MainPanel, -1, 'S2P to S1P',(10,10), style = wx.RB_GROUP)
        self.controls['rb2'] = wx.RadioButton(self.MainPanel, -1, 'MCT to MDIF',(10,10))
        self.controls['rb3'] = wx.RadioButton(self.MainPanel, -1, 'PIV to MDIF',(10,10))
        
        mode_sizer.AddMany([(self.controls['rb1'],wx.CENTER,5),(self.controls['rb2'],wx.CENTER,5),(self.controls['rb3'],wx.CENTER,5)])
        
        run_box = wx.StaticBox(self.MainPanel, label = 'Convert')
        run_sizer = wx.StaticBoxSizer(run_box,wx.VERTICAL)
        self.controls['convert'] = wx.Button(self.MainPanel, wx.ID_ANY, "Convert")
        self.controls['file_selection'] = wx.Button(self.MainPanel, wx.ID_ANY, "Select Files")
        run_sizer.Add(self.controls['file_selection'], wx.CENTER, 5)
        run_sizer.Add(self.controls['convert'],wx.CENTER,5)
        
        self.Bind(wx.EVT_BUTTON, self.OnConvert, self.controls['convert'])
        self.Bind(wx.EVT_BUTTON, self.OnFileSelect, self.controls['file_selection'])
        
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        main_sizer.Add(browse_sizer,0,wx.EXPAND|wx.ALL,5)
        main_sizer.Add(mode_sizer,0,wx.EXPAND|wx.ALL,5)
        main_sizer.Add(run_sizer,0,wx.EXPAND|wx.ALL,5)
        
        self.MainPanel.SetSizer(main_sizer)
        self.SetSize((400,400))
        self.SetTitle("Universal File Converter")
        
    def onChcurrdir(self,evt):
        dlg = wx.DirDialog(self,message = "Change Current Directory",defaultPath = os.getcwd())
        if dlg.ShowModal() == wx.ID_OK:
            self.curr_path = dlg.GetPath()
            dlg.Destroy()
            self.controls['curr_dir'].SetValue(self.curr_path)

    def set_selections(self,**kwargs):
        if 'use_s22' in kwargs:
            self.use_s22 = kwargs['use_s22']
        if 'fxa_fname' in kwargs:
            self.fxa_fname = kwargs['fxa_fname']
        if 'fxb_fname' in kwargs:
            self.fxb_fname = kwargs['fxb_fname']
        
    def OnOptions(self,evt):
        # options for the file conveter
        dlg = options(self)
        dlg.Show()            
        
    def OnExit(self, evt):
        self.Close()
        
    def OnFileSelect(self, evt):
        dlg = wx.FileDialog(self,"Choose Files to be Converted",self.controls['curr_dir'].GetValue(),style = wx.FD_MULTIPLE)
        if dlg.ShowModal() == wx.ID_OK:
            self.files = dlg.GetFilenames()
            dlg.Destroy()

    def OnConvert(self,evt):
        mapping = {}
        if len(self.files) < 1:
            raise ValueError("Choose Files to Convert First!")
        if self.controls['rb1'].GetValue() == True:
            s2p_to_s1p(self.files,self.use_s22)
        elif self.controls['rb2'].GetValue() == True:
            mct_to_mdif(self.files,self.fxa_fname,self.fxb_fname)
        elif self.controls['rb3'].GetValue() == True:
            piv_to_mdif(self.files)


if __name__ == "__main__":
    app = wx.App(redirect = False)
    frame = converter_main(None, -1)
    frame.Show()
    app.MainLoop()    
        
        
        
        
        
        
        