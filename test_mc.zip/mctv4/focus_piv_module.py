"""
This Module allows the user to perform a PIV Measurement
"""

from wxtestgui import parm,ParamPage,ParamGroup,ValidationError,Instr
from instrument.utils import timed_wait_ms
import math


# TO DO Set a validator for the pulse width and period according to Focus Limits
TEST_PARAMS = [
    ParamPage('Main Test Settings',
    
    # Gate Voltage Parameters
    ParamGroup('Gate Settings',
    parm('gate_q','float',value = -3.0,label="Gate Quiescent Voltage(V)"),
    parm('gate_list','float_list',label = "Gate Sweep Plan"),
    ),
    ParamGroup('Drain Settings',
    #Drain Voltage Parameters
    parm('drain_q','float',value = 50.0,label="Drain Quiescent Voltage(V)"),
    parm('drain_list','float_list',label = "Drain Sweep Plan"),
    parm('drain_ilimit','float',value = 1.0, label = "Drain Current Limit(A)"),
    ),
    parm('measure_pulsed_spars','choice',value = 'No', choices=[('Measure','Yes'),('Do Not Measure','No')],label= "Measure Pulsed Spars (Yes/No)?"),    
    parm('width','float',value=5,validator=None,label="Pulse Width(uS)"),
    parm('period','float',value = 1000,validator = None, label = "Pulse Period(uS)"),
    ),
    
    #Power limits
    ParamPage('Advanced Settings',    
    ParamGroup('Power Limits',
    parm('plimit_region1','float',value = 100.0,label="Power Limit for Region 1"),
    parm('plimit_region2','float',value = 100.0,label="Power Limit for Region 2"),
    parm('plimit_region3','float',value = 20.0,label="Power Limit for Region 3"),
    parm('plimit_region4','float',value = 40.0,label="Power Limit for Region 4"),
    ),
    ParamGroup('Calibration and Q Point Targeting',
    parm('drain_iscale','float',value = 1.0, label = "Scaling factor for drain current"),
    parm('gate_cal_pulsed_v','float',value = -3.0, label = "Gate Pulsed calibration voltage"),
    parm('gate_q_min','float',value = -2.0, label = "Min Gate V for the Q point Targeting Routine"),
    parm('gate_q_max','float',value = 0.0, label = "Max Gate V for the Q point Targeting Routine"),
    parm('vgs_vds_offset','float',value = 0.025, label = "Vgs Vds offset for Q Point targeting"),
    parm('q_point_shift_frac','float',value = 0.2, label = "Fraction of Q Point Shift"),
    parm('check_q_point_shift','choice',value = 'No', choices = [('Check','Yes'),('Do not Check','No')],label = "Check Q Point Shift During Test?"),
    ),    
    ),    
    # Another Page for Parameters that aren't changed often
    ParamPage('Timing Parameters',
    parm('pre_gate','float',value = 0.1,label= "Gate pulse pre-gate(pulse start) (us)"),
    parm('post_gate','float',value = 0.1,label= "Gate pulse post-gate (us)"),
    parm('pre_drain','float',value = 0.1,label= "Drain pulse pre-drain (us) "),
    parm('post_drain','float',value = 0.1,label= "Drain pulse post-drain (us)"),
    parm('qpoint_offset','float',value= -1000.0,label = "Offset to use for measuring the Q-point"),
    parm('qpoint_window','float',value = 1.0, label = "Time window to use for measuring the Q-point"),    
    parm('dont_swap_timing','bool',value = False, label = "Turn off feature that swaps gate/drain pulse timing"),
    parm('vd_slew_rate','float',value= 50.0,label = "Drain Supply Slew Rate in V/sec"),
    ),
    # Measurement Channel Parameters, used to determine which channel performs which measurement
    ParamPage('Measurement Channels',    
    parm('vg_meas','int',value = 1,label= "Gate Voltage Measurement Channel [1,2,3,4]"),
    parm('vd_meas','int',value= 2,label = "Drain Voltage Measurement Channel [1,2,3,4]"),
    parm('id_meas','int',value = 3, label = "Drain Current Measurement Channel [1,2,3,4]"),
    parm('trig_meas','int',value = 4, label = "Trigger Channel [1,2,3,4]"),
    parm('drainhi','string',value = "bias1", label = "Drain High Supply [bias1,bias2,bias3,bias4]"),
    parm('drainlo','string',value = "bias2", label = "Drain Low Supply [bias1,bias2,bias3,bias4]"),    
    ),
        
]

INSTR_LIST = [
    Instr('vna1','vna',label='Vector Network Analyzer'),
    Instr('meas1','custom',label='Measurement Channel 1'),
    Instr('meas2','custom',label='Measurement Channel 2'),
    Instr('meas3','custom',label='Measurement Channel 3'),
    Instr('meas4','custom',label='Measurement Channel 4'),
    Instr('pulser','bias',label='Pulser Unit'),
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('bias3','bias',label='Bias 3'),
    Instr('bias4','bias',label='Bias 4'),    
]

def instrument_loader(instrs):
    # Load all the instruments specified
    ret = {}
    errs = []
    
    for name in range(len(instrs)):
        try:
            if instrs[name].driver_name is None:
                pass
            else:
                ret[instrs[name].name] = instrs[name].open_instrument()
                if ret[name] is None:
                    raise ValueError('invalid configuration')
        except Exception, e:
            pass
            #raise Exception("instrument load exeption for %s"%instrs[name].name)
            #log.exception("instrument load exception for '%s'"%name)
            #errs.append('%s: initialization error: %s'%(instr[name].label,str(e)))
            
    if len(errs):
        # close all open instrument drivers
        # and raise an exception
        instrument_unloader(ret)                
        raise ValueError('\n'.join(errs))
    return ret
    
def instrument_unloader(instr):
    # unload the instruments
    for i in instr.values():
        try:
            i.close()
        except Exception:
            pass

class PIVControl(object):
    # 
    def __init__(self,**kwargs):
        # A flag to determine if the pulser has been set up
        self.pulser_set = False
        self.instruments_opened = False
        self.q_point = False
        
    def set_test_params(self,test_params):
        self.test_params = test_params
        
    def set_test_instrs(self,test_instrs):
        self.instrs = test_instrs
        
    def open_instruments(self):
        self.test_instrs = instrument_loader(self.instrs) 
        self.instruments_opened = True        
        
    def setup_pulser(self,pulser,drainhi,drainlo):
        # Setup the pulser for PIV. Set the pulse width, period, high and low supplies
        pulser.setup_instruments(drain_lo = drainlo, drain_hi = drainhi)
        pulser.set_current_limits(idlimit = self.test_params['drain_ilimit'].value)
                   
        pulser.setup_pulse(width = self.test_params['width'].value, period = self.test_params['period'].value,
                           gate_mode = 'pulse', drain_mode = 'pulse')
                        
        self.pulser_set = True
        
    def target_q_point(self,target):
        min = self.test_params['gate_q_min'].value
        max = self.test_params['gate_q_max'].value
        vgq, vdq, vgp = self.test_params['gate_q'].value, self.test_params['drain_q'].value, min
        offs = self.test_params['vgs_vds_offset'].value
        
        if self.instruments_opened != True:
            self.open_instruments()       
        
        if min >= max:
            raise ValueError("'gate_q_min' and 'gate_q_max' configuration variables are inconsistent")
                
        pulser = self.test_instrs['pulser']
        drainhi = self.test_instrs[self.test_params['drainhi'].value]
        drainlo = self.test_instrs[self.test_params['drainlo'].value]
        
        if self.pulser_set != True:
            self.setup_pulser(pulser,drainhi,drainlo)
            
        vg_meas = self.test_instrs['meas'+str(self.test_params['vg_meas'].value)]
        vd_meas = self.test_instrs['meas'+str(self.test_params['vd_meas'].value)]
        id_meas = self.test_instrs['meas'+str(self.test_params['id_meas'].value)]
               
        # Config the measurements to track the current waveforms         
        vg_meas.set_marker_mode(mode = 'wav')
        vd_meas.set_marker_mode(mode = 'wav')
        id_meas.set_marker_mode(mode = 'wav')        
             
        # The pulser timing information can be found in the help section
        pulser.set_pulse_timing(pre_gate = -offs, post_gate = -offs,
                                pre_drain = 0.3, post_drain = 0.0)                
                
        pulser.set_gate_p(vgq = vgq, vgp = vgp)
        pulser.set_supply_voltages(d_lo = 0.0, d_hi = vdq)
        pulser.set_drain_p(vdq = vdq, vdp = 0.0)
        
        timed_wait_ms(300)       
                        
        # Measure the drain current
        id_meas.trigger()
        idm = id_meas.get_marker_value()
        vd_meas.trigger()
        vg_meas.trigger()
        print "Starting vdq and vgq (%f,%f)"%(self.get_q_point(vd_meas),self.get_q_point(vg_meas))
        
        vg = vgq

        step = (max-min)*0.1
        if idm > target:
            step = -step
            
        target_err  = target * 0.02
        if target_err < 0.001:
            target_err = 0.001

        n = 0
        while n < 20:
            if step > 0.0 and vg == max:
                raise Exception("Warning: Hit Upper limit during Q point targeting")
                pulser.turn_off_supplies()
                pulser.disable()
                break
            elif step < 0.0 and vg == min:
                raise Exception("Warning: Hit Lower limit during Q point targeting")
                pulser.turn_off_supplies()
                pulser.disable()
                break
            
            vg += step
            if vg < min:
                vg = min
            elif vg > max:
                vg = max
            pulser.set_gate_p(vgp = vgp, vgq = vg)
            timed_wait_ms(100)
            
            # Get the q_point from the waveform
            id_meas.trigger()
            idm = self.get_q_point(id_meas)
            
            print "current idm and vgq (%f,%f)"%(idm, self.get_q_point(vg_meas)) 
            
            if abs(idm-target) <= target_err:
                break
                
            elif idm < target and step < 0.0:
                step *= -0.25
            n += 1
            
        # Turn off the high and low supplies and disable pulser
        pulser.set_trigger_mode(mode = 'free')
        pulser.turn_off_supplies()
        pulser.disable()
        
        self.vg_set = vg
        self.idm_q = idm
                
        self.q_point = True
        return 'success'
        
    def disable_pulser(self):
        pulser = self.test_instrs['pulser']
        pulser.disable()
                   
        
    def set_cursors(self):
        # Check to see if instruments are opened
        if self.instruments_opened != True:
            self.open_instruments()            
        
        # This method allows the user to set the cursors
        pulser = self.test_instrs['pulser']
        drainhi = self.test_instrs[self.test_params['drainhi'].value]
        drainlo = self.test_instrs[self.test_params['drainlo'].value]
        
        if self.pulser_set != True:
            self.setup_pulser(pulser, drainhi, drainlo)
            
        pulser.disable()
        timed_wait_ms(200)
                
        vgq, vdq = self.test_params['gate_q'].value, self.test_params['drain_q'].value
        vgp, vdp = self.test_params['gate_list'].value[0], self.test_params['drain_list'].value[0]
        pulser.set_gate_p(vgq = vgq, vgp = vgp)
        pulser.set_supply_voltages(d_lo = vdp, d_hi = vdq)
        pulser.set_drain_p(vdp = vdp, vdq = vdq)
               
        pulser.enable()
        
        
    def manual_bias(self,vgq,vgp,vdq,vdp):
        if self.instruments_opened != True:
            self.open_instruments()            
                
        pulser = self.test_instrs['pulser']
        drainhi = self.test_instrs[self.test_params['drainhi'].value]
        drainlo = self.test_instrs[self.test_params['drainlo'].value]        
        
        id_meas = self.test_instrs['meas'+str(self.test_params['id_meas'].value)]
        id_meas.set_marker_mode( mode = 'wav')
        id_meas.config(avg = 5)
               
        if self.pulser_set != True:
            self.setup_pulser(pulser, drainhi, drainlo)
            
        pulser.disable()
        timed_wait_ms(100)
                
        pulser.set_gate_p(vgq = vgq, vgp = vgp)
        if vdq > vdp:
            pulser.set_supply_voltages(d_lo = vdp, d_hi = vdq)
        else:
            pulser.set_supply_voltages(d_lo = vdq, d_hi = vdp)
        pulser.set_drain_p(vdq = vdq, vdp = vdp)
        pulser.enable()
        timed_wait_ms(200)
        
        id_meas.trigger()
        id = id_meas.get_marker_value()
        id_meas.set_trigger_mode(mode = 'auto')
        
        return id
        
    def get_q_point(self,o_scope):
        x,y = o_scope.get_waveform()
        # Get the first 5 values and take the average
        qp = 0.0
        for v in y[:5]:
            qp += v
        qp *= 0.2
        return qp
        
    def _get_power_limit(cfg, vdsval):
        "determine the applicable power limit and apply it"
        plimits = {}
        for v, l in {'plimit_vds_region1':'plimit_region1', 'plimit_vds_region2':'plimit_region2',
            'plimit_vds_region3':'plimit_region3', 'plimit_vds_region4':'plimit_region4'}.iteritems():
            vd, lim = cfg[v], cfg[l]
            if vd > 0.0 and lim > 0.0:
                plimits[vd] = lim
        
        if len(plimits):
            llst = plimits.keys()
            llst.sort()
            
            lim = -1.0
            for vd in llst:
                if vdsval <= vd:
                    lim = plimits[vd]
                    break
        
            if lim < 0.0:
                lim = plimits[llst[-1]]
            
            return lim
        else:
            # default power limit, when none are set
            return 1000.0            
               
    
    def test(self,fp):
        # Output data format
        #!Vg[V]	Vd[V]	Vg_meas[V]	Vd_meas[V]	Id_raw[A]	Id_corr[A]
         
        """
        beta = 1e-4
        vto = 0.7
        lamda = 0.0
        alpha = 2.0
        data = []
        fp.write('!\n!Vg[V]\tVd[V]\tVg_m[V]\tVd_m[V]\tId_m[A]\tId_m(corr)[A]\n')

        print self.test_instrs        
                
        for gv in self.test_params['gate_list'].value:
            vdl,idl = [],[]
            label = "Vg = %.3f"%gv
            for dv in self.test_params['drain_list'].value:
                ids_raw = ((beta*(gv-vto)**2)*(1+lamda*dv)*math.tanh(alpha*dv))
                vdl.append(dv+0.05)
                idl.append(ids_raw+0.05)
                fp.write('%.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(gv,dv,gv+0.02,dv+0.05,ids_raw,ids_raw+0.05))
                timed_wait_ms(100)
                
            data.append((vdl,idl,label))
            yield data   
        """
        pulser = self.test_instrs['pulser']
        drainhi = self.test_instrs[self.test_params['drainhi'].value]
        drainlo = self.test_instrs[self.test_params['drainlo'].value]

        if self.pulser_set != True:
            self.setup_pulser(pulser,drainhi,drainlo)
        
        vg_meas = self.test_instrs['meas'+str(self.test_params['vg_meas'].value)]
        vd_meas = self.test_instrs['meas'+str(self.test_params['vd_meas'].value)]
        id_meas = self.test_instrs['meas'+str(self.test_params['id_meas'].value)]
               
        # Config the measurements to track the current waveforms         
        vg_meas.set_marker_mode(mode = 'wav')
        vd_meas.set_marker_mode(mode = 'wav')
        id_meas.set_marker_mode(mode = 'wav')        
                
        # Check if q point has been found 
        if self.q_point == True:
            vgq = self.vg_set
        else:
            vgq = self.test_params['gate_q'].value
        
        # Check if we need to perform pulsed s-pars
        offs = self.test_params['vgs_vds_offset'].value
        ilimit = self.test_params['drain_ilimit'].value
        vd_slew_rate = self.test_params['vd_slew_rate'].value
        vds_set = self.test_params['drain_list'].value
                
        check_q_point_shift = self.test_params['check_q_point_shift'].value
        
        vgq = self.test_params['gate_q'].value
        vdq = self.test_params['drain_q'].value
        
        swapped = False
        if vds_set[0] > vdq:
            swapped = True

        vddiff = abs(vdq - vds_set[0])
        if vddiff < abs(vds_set[0] - vds_set[-1]):
            vddiff = abs(vds_set[0] - vds_set[-1])
            
        vd_fullscale = math.ceil(vddiff*1.2)
        if abs(math.fmod(vd_fullscale,2.0)) >0.1:
            vd_fullscale += 1.0
        vd_scale = vd_fullscale/vd_meas.get_ydivs()
        
        vd_meas.set_y_scale(vd_scale)
        
        if swapped:
            vd_meas.set_y_offset(vdq + 0.4*vd_fullscale)
        else:
            vd_meas.set_y_offset(0.4*vd_fullscale)
            
        # Perform the o-scope calibration
        
        pulser.set_current_limits(idlimit = ilimit)
        pulser.disable()
        
        timed_wait_ms(200)
        vg_meas.trigger()
        timed_wait_ms(50)
        vg_offset = vg_meas.get_marker_value()
        
        # Set up the drain for calibration condition
        
        pulser.set_pulse_timing(pre_gate = -offs, post_gate = -offs,pre_drain = 0.3,post_drain = 0.0)
        pulser.set_gate_p(vgq = vgq, vgp = self.test_params['gate_cal_pulsed_v'].value)
        pulser.set_drain_p(vdq = vdq, vdp = 0.0)
        timed_wait_ms(1000)
        
        # Measure calibration offsets
        irange_offsets = []
        iscal = self.test_params['drain_iscale'].value
        
        oscope_iranges = id_meas.get_oscope_iranges()
        for i,(ru,sc,of) in enumerate(oscope_iranges):
            id_meas.setYScale(sc)
            id_meas.setYOfffset(of)
            id_meas.trigger()
            timed_wait_ms(50)
            if i == 0:
                # Measure the drain voltage on the scope and subtract 
                # the measured voltage from the low-side supply
                vd_offset = vd_meas.get_marker_value() - pulser.get_supply_voltages()[0]
            irange_offsets.append(id_meas.get_marker_value())
        
        # Reset the Ids range and offset on the scope to the minimum range
        id_meas.setYScale(oscope_iranges[0][1])
        id_meas.setYOfffset(oscope_iranges[0][2])
        curr_irange = 0
        
        pulser.set_supply_voltages(d_hi = 0.0)
        timed_wait_ms(50)
        
                
        if swapped:
            pulser.set_supply_voltages(d_hi = vds_set[0], d_lo = vdq)
            pulser.set_pulse_timing(pre_gate = offs, post_gate = offs, pre_drain = 0.3, post_drain = 0.0)
        else:
            pulser.set_supply_voltages(d_hi = vdq, d_lo = vds_set[0])
            pulsser.set_pulse_timing(pre_gate = -offs, post_gate = -offs, pre_drain = 0.3, post_drain = 0.0)
        timed_wait_ms(200)
        
        pulser.set_gate_p(vgp = vgs_set[0], vgq = vgq)
        pulser.set_drain_p(vdp = vds_setp[0], vdq = vdq)
        
        # measure initial q-point
        timed_wait_ms(200)
        vg_meas.trigger()
        timed_wait_ms(50)
        
        vgq_meas  = vg_meas.get_marker_value() - vg_offset
        vdq_meas = vd_meas.get_marker_value() - vd_offset
        idq_meas_init = (id_meas.get_marker_value() - irange_offsets[curr_irange])*iscal
        
        # set headers in data file and plot file
        tstamp = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
        fp.write('! Pulsed I-V Test\n!\n')
        fp.write('! TestDate: %s\n'%tstamp)
        fp.write('! Q-Point:\n')
        fp.write('!    Vg = %g V (meas: %g V)\n'%(vgq,vgq_meas))
        fp.write('!    Vd = %g V (meas: %g V)\n'%(vdq,vdq_meas))
        fp.write('!    Id = %g A\n'%idq_meas_init)
        fp.write('! Drain Max Voltage = %g V\n'%vds_set[-1])
        fp.write('! O-Scope Offsets:\n!    Vg = %g V\n!    Vd = %g V\n'%(vg_offset,vd_offset))
        for i,x in enumerate(irange_offsets):
            fp.write('!    Id[%.3f] = %g A\n'%(avail_scope_fs_iranges[i],x))
        fp.write('!\n!-----------------------------------------------------------------------------\n')

        # Main measurement loop
        last_vds = vds_set[0]
        for i,vgset in enumerate(vgs_set):
            # send update to main gui
            first = True
            for vdset in vds_set:
                # Determine the power limit
                plimit = self._get_power_limit(self.test_params, vdset)
                
                if vdset <= vdq:
                    if swapped:
                        # Transitioning regions, need to be careful
                        # set the voltages on the supplies to be equal
                        pulser.set_supply_voltages(d_hi = vdq)
                        timed_wait_ms(100)
                        pulser.set_pulse_timing(pre_gate = -offs, post_gate = -offs, pre_drain = 0.3, post_drain = 0.0)
                        timed_wait_ms(100)
                        swapped = False
                        
                    pulser.set_supply_voltages(d_lo = vdset)
                else:
                    if not swapped:
                        pulser.set_supply_voltages(d_lo = vdq)
                        timed_wait_ms(100)
                        pulser.set_pulse_timing(pre_gate = offs, post_gate = offs, pre_drain = 0.3, post_drain = 0.0)
                        timed_wait_ms(100)
                        swapped = True 
                        
                    pulser.set_supply_voltages(d_hi = vdset)
                    
                if first:
                    pulser.set_gate_p(vdp = vgset, vgq = vgq)
                    first = False
                pulser.set_drain_p(vdp = vdset, vdq = vdq)
                
                vd_delta = abs(last_vd - vdset)
                timed_wait_ms(200+vd_delta*1000/vd_slew_rate)
                last_vd = vdset
                
                # Measure sweep and correct the offsets
                vg_meas.trigger()
                timed_wait_ms(50)
                vgmeas = vg_meas.get_marker_value() - vg_offset
                vdmeas = vd_meas.get_marker_value() - vd_offset
                
                # Set the oscope current range and measure the current
                idmeas, idq_meas = id_meas.get_marker_value()
                if curr_irange > 0 and idmeas < oscope_iranges[curr_irange-1][0]*0.9:
                    # need to go to a lower range, find the lowest range in which the
                    # measured value of current is less than the upper end of its
                    # measurement window for greatest accuracy of low current values
                    for i,(ru,sc,of) in enumerate(oscope_iranges):
                        if idmeas < ru:
                            curr_irange = i
                            id_meas.set_y_scale(sc)
                            id_meas.set_y_offset(of)
                            id_meas.trigger()
                            timed_wait_ms(50)
                            idmeas, idq_meas = id_meas.get_marker_value()
                            break
                elif idmeas > oscope_iranges[curr_irange][0]:
                    # Need to go to a higher range, try to go up 1 range at a time
                    while curr_irange < len(oscope_iranges) - 1:
                        curr_irange += 1
                        id_meas.set_y_scale(oscope_iranges[curr_irange][1])
                        id_meas.set_y_offset(oscope_iranges[curr_irange][2])
                        id_meas.trigger()
                        timed_wait_ms(50)
                        idmeas, idq_meas = id_meas.get_marker_value()
                        if idmeas <= oscope_iranges[curr_irange][0]:
                            break
                        
                id_corrected = (idmeas - irange_offsets[curr_irange])*iscal
                
                # Check power limit
                if id_corrected*vdmeas > plimit:
                    break
                    
                # Check q point shifts
                if check_qpoint_shift and abs(idq_meas-idq_meas_init) > self.test_params['qpoint_shift_frac'].value*abs(idq_meas_init):
                    # uh-oh, device either shifted a lot or blew up
                    pulser.disable()
                    timed_wait_ms(200)
                    pulser.set_supply_voltages(d_lo = vds_set[0], d_hi = vdq)
                    raise ValueError("Q-point shifted - possible dead device (initial: %.1f mA, current: %.1f mA"%(idq_meas_init*1000.0,idq_meas*1000.0))

                fp.write('%.3f\t%.3f\t%.4f\t%.4f\t%.4e\t%.4e\n'%(vgset,vdset,vgmeas,vdmeas,idmeas,id_corrected))
                fp.flush()
                
                # measure pulsed S-parameters if requested
                
            fp.write('\n')
            
        self.set_supply_voltages(d_hi = vdq, d_lo = vdq)
        timed_wait_ms(500)
        pulser.disable()
                    
            
           
        
        
                

        