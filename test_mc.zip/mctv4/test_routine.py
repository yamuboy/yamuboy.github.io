
from test_routine_registry import get_registrar


class TestRoutineParam(object):
    
    name = None
    value = None
    def_value = None
    ptype = None
    disp_str = None
    description = None
    
    def __init__( self, name, **kwargs ):
        """Create a test routine parameter.
        
        Arguments:
        name - the name of the parameter.
        
        Keywords:
        text - a string that can be used by the test enviroment as a more
           display-friendly version of the parameter's name
        desc - an optional, more wordy description of the parameter's purpose
        type - a string representing the parameter type. One of:
           'string'      a string
           'any'         any value is accepted, no checks are done
           'float'       a floating-point number
           'int'         an integer
           'boolean'     a true/false value
           'array'       a general array
           'intarray'    an array of integers
           'floatarray'  an array of floats
           'select'      an enumerated set
        value - the initial (default) value of the parameter - this must match
           the type of the parameter
        selections - an iterable of select values
        flags - a set of integer flags...
        """
        
        self.name = name
        
        
        
    def get_name( self ):
        """Returns the parameter name."""
        return self.name
        
    def get_display_str( self ):
        """Returns the parameter's display string."""
        if self.disp_str:
            return self.disp_str
        return self.name
        
    def get_value( self ):
        """Returns either the value or default value of the parameter."""
        if self.value is None:
            return self._get_value( self.def_value )
        else
            return self._get_value( self.value )
            
    def _get_value( self, v ):
        """Internal method to convert the parameter value to the correct
        variable type (in case it is None)
        """
        if v is None:
            if self.ptype == 'float':
                return 0.0
            elif self.ptype == 'int':
                return 0
            elif self.ptype == 'string':
                return ''
            elif self.ptype == 'boolean':
                return False
            elif self.ptype in ('array','intarray','floatarray'):
                return tuple()
            else:
                return None
        else:
            return v
        
    def validate( self, value ):
        """Validate that the value is valid given the parameter type and
        validate any other constraints that may be set on the parameter.
        """
        try:
            v = self._convert_value(value)
            return True
        except ValueError:
            return False
        
    def set_value( self, value ):
        """Set the value of the parameter. This performs checks that make sure
        that the value jives with the parameter type."""
        self.value = self._convert_value(value)
        
    def _convert_value( self, value ):
        """Internal function for converting the value to the correct type to
        be stored.  This will raise a TypeError exception if the value cannot
        be converted in an intelligent manner.
        """
        
        
        
        



class TestRoutine(object):
    # the test routine name - this must be globally unique
    name = None
    # the actual function that is executed
    execf = None
    # a list of TestRoutineParameter objects
    params = None
    # a list of dependancies - names of other TestRoutine objects that
    # must be 
    depends = None
    # a "pretty" display string for the test routine
    disp_str = None
    # a 1-line description string to display for the test routine
    description = None
    # a list of flags, this 
    flags = None
    
    def __init__( self, routine_name, display_name=None, **kwargs ):
        """Create a test routine object.
        
        Arguments:
        routine_name - globally unique test routine name. This parameter
           has naming restrictions similar to that of Python functions.
        display_name - optional display name for the test routine
        
        Keywords:
        exec - link the test routine with a Python function
        """
        
        # create a regex to check that the routine_name is legal
        
        
        
        self.name = routine_name
        self.disp_str = display_name
        
        if 'exec' in kwargs:
            self.set_exec(kwargs['exec'])
            
        
        # register the test routine
        self._register()
        
        
    def add_param( self, param_name, **kwargs ):
        """Add a test routine parameter."""
        p = TestRoutineParam(param_name,**kwargs)
        if self.params is None:
            self.params = [p]
        else:
            self.params.append(p)
        
    def set_exec( self, ex ):
        """Set the test routine function."""
        if not callable(ex):
            raise TypeError('expected a callable object.')
        self.execf = ex
        
    def add_dependency(self, name):
        """Add a dependency on another TestRoutine.
        
        The test execution manager will enforce that the dependency will be
        configured and executed before this routine when the test is run."""
        if not isinstance(name,str):
            raise TypeError('expected a string.')
        if self.depends is None:
            self.depends = [name]
        else:
            self.depends.append(name)
            
    def update_params( self, p_list ):
        """Update the values of the TestRoutineParam objects stored in this
        test routine.
        
        This is normally called by the GUI when applying a set of updated parameters
        to the test routine.
        """
        if self.params is None:
            return
        for p in self.params:
            i = p_list.find(p)
            if i != -1:
                p.set_value( p_list[i].get_value() )
        
    def _register( self ):
        """Register the TestRoutine with the global TestRoutineRegistrar.
        
        This is done automatically as part of the __init__ routine
        """
        get_registrar().register_test_routine(self)
        
    def __call__( self, *args, **kwargs ):
        """Call (execute) the test routine."""
        if self.execf is None:
            raise RuntimeError('`%s` is not connected to a valid procedure.'%self.name)
        f = self.execf
        f(*args,**kwargs)
