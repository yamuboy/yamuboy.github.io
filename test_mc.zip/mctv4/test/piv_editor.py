import wx
from maplot.piv_editor import PivEditorFrame

app = wx.App(redirect = False)
root = PivEditorFrame(None,-1,size = (800,600))
root.Show()
app.SetTopWindow(root)
app.MainLoop()

