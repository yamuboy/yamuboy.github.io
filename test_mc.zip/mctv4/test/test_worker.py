import wx
import wx.wizard 
from wxtestgui.worker import Worker,EVT_WORKER_MESSAGE, EVT_WORKER_EXITING,send_to_ui,get_next_message
import logging
import time
from exec_1 import * 
from collections import OrderedDict

logger = logging.getLogger(__name__)

class CalBox(wx.Frame):
    def __init__(self,parent,id, cal_dict):
        super(CalBox,self).__init__(parent,id)
        self.panel = wx.Panel(self)
        self.parent = parent
        pos_x = 100
        pos_y = 20
        self.cbs = []
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        self.cal_dict = cal_dict
        self.steps_done = []
        
        for i in cal_dict.iterkeys():
            pos_y += 20
            cb = wx.CheckBox(self.panel, label = i, pos = (pos_x,pos_y))
            self.cbs.append((cb,i))
            
        self.statusbar = self.CreateStatusBar()
        
        self.Bind(EVT_WORKER_MESSAGE,self.OnWorkerUpdate)
        self.Bind(EVT_WORKER_EXITING,self.OnTestComplete)
            
        self.btn_sizer = wx.BoxSizer(wx.HORIZONTAL)        
        self.measure = wx.Button(self.panel, wx.ID_ANY, "Measure")
        self.Bind(wx.EVT_BUTTON,self.OnMeasure,self.measure)
        self.abort = wx.Button(self.panel, wx.ID_ANY, "Abort Step")
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.abort)
        self.cancel = wx.Button(self.panel, wx.ID_ANY, "Cancel")
        self.Bind(wx.EVT_BUTTON, self.OnCancel, self.cancel)
        self.finish = wx.Button(self.panel, wx.ID_ANY, "Finish")
        self.Bind(wx.EVT_BUTTON,self.OnFinish, self.finish)
        
        self.finish.Disable()
        
        self.btn_sizer.Add(self.measure,0,wx.ALL,5)
        self.btn_sizer.Add(self.abort,0,wx.ALL,5)
        self.btn_sizer.Add(self.cancel,0,wx.ALL,5)
        self.btn_sizer.Add(self.finish,0,wx.ALL,5)
        
        cb_sizer = wx.BoxSizer(wx.VERTICAL)                
        for i in self.cbs:
            cb_sizer.Add(i[0],1,wx.EXPAND)
            
        main_sizer.Add(cb_sizer,1,wx.ALL|wx.EXPAND)       
        main_sizer.Add((20,20))
        main_sizer.Add(self.btn_sizer,1,wx.ALL|wx.EXPAND)
        
        self.panel.SetSizer(main_sizer)
        self.SetSize((300,300))
        self.Layout()
        
    def OnFinish(self,evt):
        self.parent.cal_completed = True
        self.Destroy()
        
        
    def OnMeasure(self,evt):        
        for i in self.cbs:
            if i[0].GetValue() and i[1] not in self.steps_done:
                try:    
                    self.steps_done.append(i[1])
                    new_worker = Worker(self,target = self.cal_dict[i[1]])
                    new_worker.start()
                except Exception:
                    print "Exception"
                finally:
                    i[0].SetBackgroundColour(wx.GREEN)
        self._update_ui()
        
    def _update_ui(self):
        if len(self.cal_dict) == len(self.steps_done):
            self.finish.SetBackgroundColour(wx.GREEN)
            self.finish.Enable()
        else:            
            self.finish.Disable()
                        
    def OnWorkerUpdate(self,evt):            
        self.statusbar.SetStatusText(evt.msgtype)
        
    def OnTestComplete(self,evt):
        self.statusbar.SetStatusText("Step Complete")                
           
    def OnAbort(self,evt):
        self.new_worker.comm.send_to_worker("cal abort")
        self.statusbar.SetStatusText("Cal Step Aborted, Redo Step")        
        
    def OnCancel(self,evt):
        self.Destroy()       
        
 

class WxTextCtrlHandler(logging.Handler):
    def __init__(self, ctrl):
        logging.Handler.__init__(self)
        self.ctrl = ctrl

    def emit(self, record):
        s = self.format(record) + '\n'
        wx.CallAfter(self.ctrl.WriteText, s)
        

class test_frame(wx.Frame):
    def __init__(self,*args,**kwargs):
        super(test_frame,self).__init__(*args,**kwargs)
        
        self.controls = {}
        
        self.cal_completed = False
        
        self.Main_panel = wx.Panel(self)
        
        logging_box = wx.StaticBox(self.Main_panel,label = "Test Logger")
        logging_box_sizer = wx.StaticBoxSizer(logging_box,wx.HORIZONTAL)
        self.controls['logger'] = wx.TextCtrl(self.Main_panel, style = wx.TE_MULTILINE|wx.HSCROLL|wx.TE_READONLY,size = (100,100))
        logging_box_sizer.Add(self.controls['logger'],1,wx.EXPAND)
        
        handler = WxTextCtrlHandler(self.controls['logger'])
        logger.addHandler(handler)
        FORMAT = "%(asctime)s %(levelname)s %(message)s"
        handler.setFormatter(logging.Formatter(FORMAT))
        logger.setLevel(logging.DEBUG)

        btn_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.controls['run_btn'] = wx.Button(self.Main_panel,wx.ID_ANY,"Run")
        self.Bind(wx.EVT_BUTTON,self.OnRun,self.controls['run_btn'])
        self.controls['stop_btn'] = wx.Button(self.Main_panel,wx.ID_ANY, "Stop")
        self.Bind(wx.EVT_BUTTON,self.OnStop, self.controls['stop_btn'])
        btn_sizer.Add(self.controls['run_btn'],0,wx.LEFT)
        btn_sizer.Add(self.controls['stop_btn'],0,wx.RIGHT)
        
        self.controls['cal_btn'] = wx.Button(self.Main_panel,wx.ID_ANY,"Calibrate")
        self.Bind(wx.EVT_BUTTON,self.OnCal,self.controls['cal_btn'])
                
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        main_sizer.Add(logging_box_sizer,0,wx.EXPAND|wx.ALL)
        main_sizer.Add((-1,20))
        main_sizer.Add(self.controls['cal_btn'],0,wx.CENTER|wx.ALL)
        main_sizer.Add((-1,20))
        main_sizer.Add(btn_sizer,0,wx.EXPAND|wx.ALL)
        
        self.Bind(EVT_WORKER_MESSAGE,self.OnWorkerUpdate)
        self.Bind(EVT_WORKER_EXITING,self.OnTestComplete)
        
        self.Main_panel.SetSizer(main_sizer)
        self.SetTitle("Test")
        
    def OnRun(self,evt):
        if self.cal_completed == False:
            dlg = wx.MessageDialog(self,"Calibration Step Not Completed. Please Perform Cal First","Warning",wx.OK)
            if dlg.ShowModal() == wx.ID_OK:
                dlg.Destroy()
        else:
            logger.log(logging.INFO,"Starting the test")
            self.new_worker = Worker(self,target = run_func)
            self.new_worker.start()
        
    def OnCal(self,evt):
        # In main program, get the cal dictionary from the module
        self.cal_steps = OrderedDict()
        self.cal_steps['input cal'] = cal1
        self.cal_steps['output cal'] = cal2
        self.cal_steps['sensor cal'] = cal3
        cal_frame = CalBox(parent = self, id = -1, cal_dict = self.cal_steps)
        cal_frame.Show()
                 
                   
    def OnStop(self,evt):
        self.new_worker.comm.send_to_worker("abort")
        logger.log(logging.INFO,"Test Stopped")        
        
    def OnWorkerUpdate(self,evt):
        if evt.msgtype == 'error':
            logger.log(logging.ERROR,evt.msgtype)
            self.new_worker.comm.send_to_worker("abort")                
        else:
            logger.log(logging.INFO,evt.msgtype)   
    

    def OnTestComplete(self,evt):
        dlg = wx.MessageBox('Test Complete','Info',wx.OK)
        
    

       

if __name__ == "__main__":
    app = wx.App(redirect = False)
    fr1 = test_frame(None,-1)
    app.SetTopWindow(fr1)
    fr1.Show()
    app.MainLoop()
    
