from wxtestgui import parm, ParamPage,parm_group, ValidationError, Instr

MODNAME = "Pulsed IV"
CAL_REQD = False
BIAS_WIZARD = False
RUN_FUNCTION = None

