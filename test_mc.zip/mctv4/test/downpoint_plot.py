#!/usr/bin/env python

import wx 
import numpy as np
import os
from matplotlib.figure import Figure
import sys,traceback
from maplot import NoMorePages
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg


KEY_TRANSLATION_TABLE = {
    '<RETURN>':wx.WXK_RETURN,
    '<F1>':wx.WXK_F1,
    '<F2>':wx.WXK_F2,
    '<F3>':wx.WXK_F3,
    '<F4>':wx.WXK_F4,
    '<F5>':wx.WXK_F5,
    '<F6>':wx.WXK_F6,
    '<F7>':wx.WXK_F7,
    '<F8>':wx.WXK_F8,
    '<F9>':wx.WXK_F9,
    '<F10>':wx.WXK_F10,
    '<F11>':wx.WXK_F11,
    '<F12>':wx.WXK_F12,
    #### todo: add more
}

# This is the list that will contain the filenames for the datasets
datasets = []

stylelist = ('r-','b-','g-','c-','m-','r.','b.','g.','c.','m.','r--','b--','g--','c--','m--',)

#Create a pager for the plots
class downpoint_pager(object):
    def __init__(self, files=None):
        "initialize"
        self._data = []
        
        if files is not None:
            for fname in files:
                self.add_file(fname)           
    
    def add_file(self, fname):
        "read a power data file and add it to the dataset"
        legend_name = fname.split('\\')[len(fname.split('\\'))-1]
        
        try:
            iv_list = ['! *********** Forward I-V ***********\n','! *********** Leakage I-V ***********\n','! *********** DC I-V ***********\n','! *********** Transfer I-V ***********\n']
            with open(fname) as f:
                temp = f.readlines()
                
            ngf = float(temp[5].split('=')[1].strip('\n'))
            ugw = float(temp[6].split('=')[1].strip('\n'))
            periph = (ngf*ugw)/1000.0
            
            fwdiv_index = temp.index(iv_list[0])
            leakiv_index = temp.index(iv_list[1])
            dciv_index = temp.index(iv_list[2])
            txfr_index = temp.index(iv_list[3])
            
            fwdiv_data = temp[fwdiv_index+3:leakiv_index-2]
            leakiv_data = temp[leakiv_index+3:dciv_index-2]
            dciv_data = temp[dciv_index+3:txfr_index-3]
            txfr_data = temp[txfr_index+3:len(temp)-2]
            
            dataset = {'fwdiv':self.get_data(fwdiv_data,periph),'leakiv':self.get_data(leakiv_data,periph), 'dciv':self.get_data(dciv_data,periph), 'txfr':self.get_data(txfr_data,periph), 'label':legend_name}
            self._data.append(dataset)                    
            
        except Exception:
            print "File Read Exception for %s"%fname
            
        finally:
            f.close()       
        
    def get_data(self, name, periph):
        data = {'vds':[],'ids':[],'vgs':[],'igs':[]}
        for i in name:
            if i == '\n':
                # Need to add this so that the DCIV's look fine
                data['vds'].append(None)
                data['ids'].append(0.0)
                data['vgs'].append(None)
                data['igs'].append(None)
                continue
                
            # Store all the igs and ids values in mA/mm
            data['vds'].append(float(i.split('\t')[0]))
            ids_mamm = 1000.0 * abs(float(i.split('\t')[1]))/periph
            data['ids'].append(ids_mamm)
            data['vgs'].append(float(i.split('\t')[2]))
            igs_mamm = 1000.0 * abs(float(i.split('\t')[3].strip('\n')))/periph
            data['igs'].append(igs_mamm)        
        return data
    
    def init_pages(self, figure):
        "draw the first page"
        self.__i = 0
        self._plot(figure)
        
    def next_page(self, figure):
        "draw the next page"
        i = self.__i + 1
        if i > 3:
            raise NoMorePages()
        self.__i = i
        self._plot(figure)
        
    def prev_page(self, figure):
        "draw the previous page"
        i = self.__i - 1
        if i < 0:
            raise NoMorePages()
        self.__i = i
        self._plot(figure)
        
    def _plot(self, figure):
        "draw the plot"
        yvar = None
        yscalefact = 1.0
                
        if self.__i == 0:
            # power
            yvar = 'fwdiv'
            ylabel = 'Igs (mA/mm)'
            title = 'Forward IV Curve Vgs(V) vs. Igs(mA/mm)'
            
        elif self.__i == 1:
            # gain
            yvar = 'leakiv'
            ylabel = 'Ids (mA/mm)'
            title = 'Leakage IV Vds(V) vs. Ids(mA/mm)'
            
        elif self.__i == 2:
            # I-out
            yvar = 'dciv'
            ylabel = 'Ids (mA/mm)'
            yscalefact = 1.0
            title = 'DC-IV Vds(V) vs Ids(mA/mm)'
        elif self.__i == 3:
            # I-in
            yvar = 'txfr'
            ylabel = 'Ids (mA/mm)'
            yscalefact = 1.0
            title = 'Transfer Curve Vds(V) vs Ids(mA/mm)'
        else:
            raise ValueError("inconsistent internal state")
            
        # clear the figure and re-generate the axes
        # add the data
        figure.clf()
        ax = figure.add_axes([0.15,0.15,0.7,0.7])
                
        count  = 0
        for i in self._data:
            if yvar == 'fwdiv':
                yvals = np.array(i[yvar]['igs'])*yscalefact
                ax.plot(i[yvar]['vgs'],yvals,stylelist[count],label = i['label'])
                ax.set_xlabel('Gate Voltage (V)')        
            elif yvar == 'leakiv' or yvar == 'dciv':
                yvals = np.array(i[yvar]['ids'])*yscalefact
                ax.plot(i[yvar]['vds'],yvals,stylelist[count],label = i['label'])
                ax.set_xlabel('Drain Voltage (V)')        
            elif yvar == 'txfr':
                yvals = np.array(i[yvar]['ids'])*yscalefact
                ax.plot(i[yvar]['vgs'],yvals,stylelist[count],label = i['label'])
                ax.set_xlabel('Gate Voltage (V)')        
            count+=1
                
        # set axes properties
        ax.legend(loc='best')
        ax.grid(True)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        
class WxPlotPanel(wx.Panel):
    """Plot panel for displaying plots
    
    """
    def __init__( self, figure, parent, dpi=None, **kwargs ):
        "initializer"

        # initialize Panel
        if 'id' not in kwargs.keys():
            kwargs['id'] = wx.ID_ANY
        if 'style' not in kwargs.keys():
            kwargs['style'] = wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS
        else:
            kwargs['style'] |= wx.NO_FULL_REPAINT_ON_RESIZE # | wx.WANTS_CHARS 
        super(WxPlotPanel,self).__init__(parent,**kwargs)
        self.parent = parent
        
        # initialize matplotlib stuff
        self.figure = figure
        canvas = FigureCanvasWxAgg(self,-1,self.figure)
        canvas.SetFocus()
        #self.SetColor(color)

        self._SetSize()

        self._resizeflag = False

        self.Bind(wx.EVT_IDLE, self._onIdle)
        self.Bind(wx.EVT_SIZE, self._onSize)

        
    def _onSize( self, event ):
        self._resizeflag = True

    def _onIdle( self, evt ):
        if self._resizeflag:
            self._resizeflag = False
            self._SetSize()

    def _SetSize( self ):
        pixels = tuple(self.parent.GetClientSize())
        self.SetSize(pixels)
        self.figure.canvas.SetSize(pixels)
        self.figure.set_size_inches( float( pixels[0] )/self.figure.get_dpi(),
                                     float( pixels[1] )/self.figure.get_dpi() )
    

class main_window(wx.Frame):
    def __init__(self,figure, parent=None, *args,**kwargs):
        super(main_window,self).__init__(parent,*args,**kwargs)
        
        menubar = wx.MenuBar()
        
        self.pager = kwargs.pop('pager',None)
        
        # Create file menu items        
        file_menu = wx.Menu()
        file1 = file_menu.Append(wx.ID_ANY, "Add Datasets...")
        file2 = file_menu.Append(wx.ID_ANY, "Edit Datasets...")
        file3 = file_menu.Append(wx.ID_SAVE, "Save Plots")
        file_menu.AppendSeparator()
        file4 = file_menu.Append(wx.ID_EXIT, "Exit")
        
        self.Bind(wx.EVT_MENU, self.OnAddDataset, file1)
        self.Bind(wx.EVT_MENU, self.OnEditDataset, file2)
        self.Bind(wx.EVT_MENU, self.save_figure, file3)
        self.Bind(wx.EVT_MENU, self.OnExit, file4)
        
        menubar.Append(file_menu, "File")
        self.SetMenuBar(menubar)
        
        self.statusbar = self.CreateStatusBar()
        
        self.panel = WxPlotPanel(figure,self)

        # verify the pager setup 
        if self.pager:
            # verify that the has a prev_page and next_page method
            if not hasattr(self.pager,'prev_page') or not callable(self.pager.prev_page):
                raise TypeError("The 'pager' must have a callable prev_page method.")
            elif not hasattr(self.pager,'next_page') or not callable(self.pager.next_page):
                raise TypeError("The 'pager' must have a callable next_page method.")
            elif not hasattr(self.pager,'init_pages') or not callable(self.pager.init_pages):
                raise TypeError("The 'pager' must have a callable init_pages method.")
        
        
        # draw the canvas for the first time
        self.init_pages()
        
        # show this Window
        self.SetSize((800,800))
        self.Centre()
        self.Show(True)
        # connect KeyDown events
        self._connect_keydown(self)
        
        # connect navigation events
        self.Bind(wx.EVT_NAVIGATION_KEY,self.OnNavEvent)
        self.panel.Bind(wx.EVT_NAVIGATION_KEY,self.OnNavEvent)
        
        # connect figure/pager specific events
        self.__bindings = {}
        b = None
        if self.pager:
            if hasattr(self.pager,'key_bindings'):
                b = self.pager.key_bindings
        else:
            if hasattr(figure,'key_bindings'):
                b = figure.key_bindings
        
        if b is not None:
            # check the format of the key bindings data
            if not isinstance(b,(list,tuple)):
                raise TypeError("'key_bindings' must be a list/tuple object")
            for x in b:
                if not isinstance(x,tuple) or len(x) != 2:
                    raise TypeError("'key_bindings' must contain 2-tuples")
                if not isinstance(x[0],str):
                    raise ValueError("in 'key_bindings', the first element of each 2-tuple must be a string")                
                if not callable(x[1]):
                    raise ValueError("in 'key_bindings', the second element of each 2-tuple must be a callable object")
            
            # add key bindings to the array
            for k,f in b:
                if len(k) == 1:
                    key = ord(k.upper())
                else:
                    try:
                        key = KEY_TRANSLATION_TABLE[k.upper()]
                    except Exception:
                        sys.stderr.write("WARNING: key binding for '%s' could not be translated\n"%k)
                        continue
                
                self.__bindings[key] = f
                
    def OnEditDataset(self, event):
        if len(datasets) == 0:
            dlg = wx.MessageBox("Please Select Some Datasets First!",'Info', wx.OK)
        dlg = wx.MultiChoiceDialog( self,"Pick the datasets you want displayed","Dataset Choice Dialog", datasets)
        edited_datasets = []
        if dlg.ShowModal() == wx.ID_OK:
            selections  = dlg.GetSelections()
            for i in selections:
                edited_datasets.append(datasets[i])
        
        self.pager = downpoint_pager(edited_datasets)
        self.init_pages()    
        
        
    def _connect_keydown(self, w):
        "bind the key down event for all widgets"
        w.Bind(wx.EVT_KEY_DOWN,self.OnKeyEvent)
        # recursively call children
        for w2 in w.GetChildren():
            self._connect_keydown(w2)
        
    def OnKeyEvent(self, e):
        "capture key press events"
        code = e.GetKeyCode()
        if code in (ord('P'),wx.WXK_LEFT,wx.WXK_UP):
            self.prev_page()        
        elif code in (ord('N'),wx.WXK_SPACE,wx.WXK_RIGHT,wx.WXK_DOWN):
            self.next_page()        
        elif code in (ord('Q'),ord('X')):
            self.OnQuit()
        elif code == ord('S'):
            self.save_figure()
        elif code in self.__bindings:
            # call all callback functions for the key binding
            try:
                r = self.__bindings[code](self.panel.figure)
                if isinstance(r,str):
                    self.status_msg(r)
                else:
                    self.status_msg('key binding callback executed')
            except Exception, e:
                self.error_msg("callback failed: %s"%e)
                sys.stderr.write(traceback.format_exc()+'\n')
    
    def OnNavEvent(self, e):
        "capture navigation events"
        if e.IsFromTab():
            e.Skip()
        else:
            if e.GetDirection():
                self.next_page()
            else:
                self.prev_page()
            
    def init_pages(self):
        "do the initial page draw"
        if self.pager:
            cb = self.pager.init_pages
        #elif self._initcb:
            #cb = self._initcb
        elif hasattr(self.panel.figure,'init_pages') and callable(self.panel.figure.init_pages):
            cb = self.panel.figure.init_pages
        else:
            self.panel.figure.canvas.draw()
            return
            
        try:
            txt = cb(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except Exception, e:
            self.error_msg('Cannot initialize the first page.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
        
        self.panel.figure.canvas.draw()

    def prev_page(self):
        """Go to the previous plot page."""
        if self.pager:
            pager = self.pager
        elif hasattr(self.panel.figure,'prev_page') and callable(self.panel.figure.prev_page):
            pager = self.panel.figure
        else:
            self.error_msg('Cannot go to the previous page.')
            return
            
        try:
            txt = pager.prev_page(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except NoMorePages:
            self.status_msg('Already at the first page.')
            return
        except Exception, e:
            self.error_msg('Cannot go to the previous page.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
        
        self.panel.figure.canvas.draw()
        
    def next_page(self):
        """Go to the next plot page."""
        if self.pager:
            pager = self.pager
        elif hasattr(self.panel.figure,'next_page') and callable(self.panel.figure.next_page):
            pager = self.panel.figure
        else:
            self.error_msg('Cannot go to the next page.')
            return
            
        try:
            txt = pager.next_page(self.panel.figure)
            if isinstance(txt,str):
                self.status_msg(txt)
            else:
                self.status_msg('')
        except NoMorePages:
            self.status_msg('Already at the last page.')
            return
        except Exception, e:
            self.error_msg('Cannot go to the next page.')
            sys.stderr.write(traceback.format_exc()+'\n')
            return
            
        self.panel.figure.canvas.draw()
    
    
    def save_figure(self,e=None):
        """Menu entry callback to save the current figure."""
        filetypes, exts, filter_index = self.panel.figure.canvas._get_imagesave_wildcards()
        default_file = "image." + self.panel.figure.canvas.get_default_filetype()
        dlg = wx.FileDialog(self, "Save to file", "", default_file,
                            filetypes,
                            wx.SAVE|wx.OVERWRITE_PROMPT)
        dlg.SetFilterIndex(filter_index)
        if dlg.ShowModal() == wx.ID_OK:
            dirname  = dlg.GetDirectory()
            filename = dlg.GetFilename()
            format = exts[dlg.GetFilterIndex()]
            basename, ext = os.path.splitext(filename)
            if ext.startswith('.'):
                ext = ext[1:]
            if ext in ('svg', 'pdf', 'ps', 'eps', 'png') and format!=ext:
                #looks like they forgot to set the image type drop
                #down, going with the extension.
                #warnings.warn('extension %s did not match the selected image type %s; going with %s'%(ext, format, ext), stacklevel=0)
                format = ext
                
            try:
                fname = os.path.join(dirname,filename)
                self.panel.figure.canvas.print_figure(fname,format=format)
                self.status_msg("Saved file '%s'"%fname)
            except Exception, e:
                self.error_msg(str(e))
        
    def status_msg(self, msg):
        "print a status message to the status bar"
        self.statusbar.SetForegroundColour('black')
        self.statusbar.SetStatusText(msg)
        
    def error_msg(self, msg):
        "print an error message to the status bar"
        self.statusbar.SetForegroundColour('red')
        self.statusbar.SetStatusText(msg)        
        
    def OnAddDataset(self, event):
        self.datasetdialog = FileDropDialog(parent = self)
        self.datasetdialog.Show()
        self.datasetdialog.Bind(wx.EVT_CLOSE, self.OnAddDatasetClosed)
                
    def OnAddDatasetClosed(self, event):
        self.datasetdialog.Destroy()
        self.pager = downpoint_pager(datasets)
        self.init_pages()
        
    def OnExit(self, event):
        self.Close()
        
        
class MyTextDropTarget(wx.TextDropTarget):
    file_names = []
    
    def __init__(self, object):
        wx.TextDropTarget.__init__(self)
        self.object = object
        
    def OnDropText(self, x, y, data):
        self.object.InsertStringItem(0, data)
        self.file_names.append(os.path.join(self.path,data))
                
    def set_cwd(self,path):
        self.path = path
        
    def return_filenames(self):
        return self.file_names
        
        
class FileDropDialog(wx.Frame):
    def __init__(self, parent=None):
        wx.Frame.__init__(self,parent = parent, title = "Drag and Drop", size = (700,700))
        
        main_splitter = wx.SplitterWindow(self)
        h_splitter = wx.SplitterWindow(main_splitter)
                
        menubar = wx.MenuBar()
        
        file_menu = wx.Menu()
        file1 = file_menu.Append(wx.ID_ANY, "Add Datasets...")
        file_menu.AppendSeparator()
        file2 = file_menu.Append(wx.ID_ANY, "Close...")
        
        self.Bind(wx.EVT_MENU,self.OnAddDatasets,file1)
        self.Bind(wx.EVT_MENU,self.OnClose,file2)
        
        menubar.Append(file_menu, "File")
        self.SetMenuBar(menubar)        
        
        self.dir = wx.GenericDirCtrl(main_splitter, -1, dir= os.getcwd(), style=wx.DIRCTRL_DIR_ONLY, size = (300,500))
        
        self.lc1 = wx.ListCtrl(h_splitter, -1, style=wx.LC_LIST, size = (100,100))
        self.lc2 = wx.ListCtrl(h_splitter, -1, style=wx.LC_LIST, size = (100,100))
        self.dt = MyTextDropTarget(self.lc2)
        self.lc2.SetDropTarget(self.dt)
        wx.EVT_LIST_BEGIN_DRAG(self, self.lc1.GetId(), self.OnDragInit)
        tree = self.dir.GetTreeCtrl()
        
        h_splitter.SplitHorizontally(self.lc1, self.lc2)        
        main_splitter.SplitVertically(self.dir, h_splitter)
        
        main_sizer = wx.BoxSizer(wx.VERTICAL)        
        main_sizer.Add(main_splitter,1, wx.EXPAND)
        
        wx.EVT_TREE_SEL_CHANGED(self, tree.GetId(), self.OnSelect)
        self.OnSelect(0)
        self.SetSizer(main_sizer)
        
    def OnSelect(self, event):
        list = os.listdir(self.dir.GetPath())
        self.dt.set_cwd(self.dir.GetPath())
        self.lc1.ClearAll()
        #self.lc2.ClearAll()
        for i in range(len(list)):
            if list[i][0] != '.':
                self.lc1.InsertStringItem(0, list[i])

    def OnDragInit(self, event):
        self.dt.set_cwd(self.dir.GetPath())
        text = self.lc1.GetItemText(event.GetIndex())
        tdo = wx.PyTextDataObject(text)
        tds = wx.DropSource(self.lc1)
        tds.SetData(tdo)
        tds.DoDragDrop(True)
        
    def OnAddDatasets(self, event):
        a = self.dt.return_filenames()
        for i in a:
            if type(i) is unicode:
                datasets.append(i.encode('ascii','ignore'))
            else:
                datasets.append(i)
        self.Close()
        
    def OnClose(self, event):
        self.Close()        
        
       
if __name__ == "__main__":
    app = wx.App(redirect=False) 
    frame_1 = main_window(Figure(),None) 
    app.SetTopWindow(frame_1) 
    frame_1.Show() 
    app.MainLoop()   
        
        