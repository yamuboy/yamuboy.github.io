from wxtestgui.worker import Worker,send_to_ui,get_next_message,NoMessages
import time

class UserAbort(Exception):
    pass

class CalAbort(Exception):
    pass
    
_cal_data = {'offset_A':[],'offset_B':[]}
    
def cal1():
    """
    Attach Sensor A to the input coupler
    """    
    try:
        
        for i in range(5):
            check_message_queue()
            time.sleep(2)
            _cal_data['offset_A'].append(i)
            send_to_ui("performing input cal %d"%i)
    except CalAbort:
        print "Test Aborted"
    

def cal2():
    """
    Please attach Sensor B in place of the DUT
    """
    try:
        print _cal_data
        for i in range(5):
            check_message_queue()
            time.sleep(2)
            _cal_data['offset_B'].append(i+1)
            send_to_ui("performing output cal %d"%i)
    except CalAbort:
        print "Test Aborted"
    
    

def cal3():
    """
    Place a short in place of the DUT and attach sensor C
    To the input coupler.
    """
    print _cal_data     

def check_message_queue(block = False):
    try:
        msg = get_next_message(block)
        if msg.msgtype == "abort":
            raise UserAbort
        if msg.msgtype == "cal abort":
            raise CalAbort        
        return msg
    except NoMessages:
        pass 

def run_func():
    print "Entering run function"
    try:
        for i in range(5):
            check_message_queue()
            time.sleep(2)
            send_to_ui("performing point %d of 5"%i)
            
    except UserAbort:
        print "Test Aborted"
    