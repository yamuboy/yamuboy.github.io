from pylab import plot,show
import numpy as np

path = "C:\\Users\\ma099737\\Desktop"
file = "\\0304_2x125um_qp_12ma_gs_p9v_ds_18v.piv"

from piv_files import PIV_Datafile

# plot gds for -0.7v and gm for 7v
p =  PIV_Datafile(fname = path+file)

print p._vgsourced
print len(p._vgvddict)
print p._vgvddict[-2.3]

gds_data = p.get_vgblock(vg = -0.7)
gm_data = p.get_vdblock(vd = 7)

gd_ids = np.array([i['id_c'] for i in gds_data])
gd_vds = np.array([i['vd_m'] for i in gds_data])

gds = np.zeros(gd_ids.shape,np.float)
gds[0:-1] = np.diff(gd_ids)/np.diff(gd_vds)
gds[-1] = (gd_ids[-1] - gd_ids[-2])/(gd_vds[-1]-gd_vds[-2])

plot(gd_vds,gds)
show()

gm_ids = np.array([i['id_c'] for i in gm_data])
gm_vgs = np.array([i['vg_m'] for i in gm_data])

gm = np.zeros(gm_ids.shape,np.float)
gm[0:-1] = np.diff(gm_ids)/np.diff(gm_vgs)
gm[-1] = (gm_ids[-1] - gm_ids[-2])/(gm_vgs[-1]-gm_vgs[-2])

plot(gm_vgs,gm)
show()





