""" This module creates a generic calibration dialog
    Bulk of the processing is done within the test module
    Cal_params included in test module 
    This module just takes the cal functions, runs them and returns data
    It creates a wizard with wizard steps based on list given
    ack, nack passing  
"""
# Need to clean up the code. Remove redundant snippets.
import wx
from utils import *
import threading
from wxtestgui.worker import Worker,EVT_WORKER_MESSAGE, EVT_WORKER_EXITING,send_to_ui,get_next_message

class WorkerThread(threading.Thread):
    def __init__(self,window):
        super(WorkerThread,self).__init__()
        self.window = window
        self.stop_thread = False
        self.a = abort()
               
    def set_run_func(self, run_func,cal_params=None,cal_dict=None,instrs =None):
        self.run_func = run_func
        self.cal_params = cal_params
        self.cal_dict = cal_dict
        self.instrs = instrs
        
    def run(self):
        self.ack, self.data = self.run_func(self.cal_params, self.cal_dict, self.instrs)
        wx.CallAfter(self.window.StopBusy)
                
    def stop(self):
        self.stop_thread = True
        self.a.set_abort(1)
        
    def get_ack_data(self):
        return self.ack, self.data    

class wizardpage(wx.Panel):
    
    def __init__(self,parent,title = None,docstr=None):
        wx.Panel.__init__(self,parent)
        if title:
            self.title = title
        else:
            self.title = "Cal Step Undefined"
        if docstr:
            self.docstr = docstr
        else:
            self.docstr = "Docstr for this calibration function not available"
        self.init()
            
    def init(self):
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        page_sizer = wx.BoxSizer(wx.HORIZONTAL)
        desc_sizer = wx.BoxSizer(wx.HORIZONTAL)
        
        title = wx.StaticText(self, -1, self.title)
        title.SetFont(wx.Font(18, wx.SWISS, wx.NORMAL, wx.BOLD))
        page_sizer.Add(title, 0, wx.ALIGN_CENTRE|wx.ALL, 5)
        page_sizer.Add(wx.StaticLine(self, -1), 0, wx.EXPAND|wx.ALL, 5)
        
        step_desc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,value = self.docstr)
        desc_sizer.Add(step_desc,wx.EXPAND|wx.ALL)
        
        main_sizer.Add(page_sizer,0,wx.ALL)
        main_sizer.Add(desc_sizer,0,wx.EXPAND|wx.ALL)
        self.SetSizer(main_sizer)
        
class wizardpanel(wx.Panel):
    # Keep count of the executed function
    exec_count = 0
    
    def __init__(self,parent,main_window):
        wx.Panel.__init__(self,parent= parent)
        
        # This list holds wizardpage objects
        self.pages = []
        self.cal_functions = []
        self.titles = []
        self.steps_done = []
        
        self.main_window = main_window
                       
        self.page_num = 0
        
        self.a = abort()
        self.timer = wx.Timer(self)
        
        self.status_bar = self.GetParent().CreateStatusBar(style = 0)
        
        self.mainsizer = wx.BoxSizer(wx.VERTICAL)
        self.panelsizer = wx.BoxSizer(wx.VERTICAL)
        btnsizer = wx.BoxSizer(wx.HORIZONTAL)
        
        self.prevBtn = wx.Button(self, label= "Previous")
        self.prevBtn.Bind(wx.EVT_BUTTON, self.onPrev)
        btnsizer.Add(self.prevBtn,0,wx.ALL)
        
        self.nextBtn = wx.Button(self, label = "Next")
        self.nextBtn.Bind(wx.EVT_BUTTON,self.onNext)
        btnsizer.Add(self.nextBtn,0,wx.ALL)
        
        self.cancelBtn = wx.Button(self,label = "Cancel")
        self.cancelBtn.Bind(wx.EVT_BUTTON, self.onCancel)
        btnsizer.Add(self.cancelBtn, 0, wx.ALL)
        
        self.abortBtn = wx.Button(self, label = "Abort")
        self.abortBtn.Bind(wx.EVT_BUTTON, self.OnAbort)
        btnsizer.Add(self.abortBtn,0,wx.ALL)
                
        self.mainsizer.Add(self.panelsizer,1,wx.EXPAND)
        self.mainsizer.Add(btnsizer,0,wx.ALIGN_RIGHT)
        self.SetSizer(self.mainsizer)
        
    def addPage(self,cal_function= None, title= None,cal_params= None, cal_dict = None,instrs = None):
        # Save the title so it can be used as a dictionary key
        panel = wizardpage(self,title,cal_function.__doc__)
        self.panelsizer.Add(panel,2,wx.EXPAND)
        
        self.cal_functions.append(cal_function)
        self.titles.append(title)
        self.cal_dict = cal_dict
        self.instrs = instrs 
        
        if cal_params:
            self.cal_params = cal_params
        if cal_dict:
            self.cal_dict = cal_dict
                
        # Append the wizardpage object to the page list
        
        self.pages.append(panel)
        if len(self.pages)> 1:
            # Hide all the panels after the first one
            panel.Hide()
            self.Layout()
            
    def onNext(self,event):
        # This is where most of the action takes place. Pressing Next causes the cal step to be run.
        # A thread is spawned which makes sure the cal dialog doesn't hang.
        
        pagecount = len(self.pages)
                
        #self.pages_done.append(self.page_num)
        if pagecount-1 != self.page_num:
            self.pages[self.page_num].Hide()
            self.pages[self.page_num+1].Show()
            self.panelsizer.Layout()
            try:
                self.nextBtn.Disable()
                if self.cal_params:
                    #ack,data = self.cal_functions[self.page_num](self.cal_params,self.cal_dict)
                    self.task = WorkerThread(self)
                    self.task.set_run_func(self.cal_functions[self.page_num],self.cal_params,self.cal_dict,self.instrs)
                    self.task.start()
                    self.status_bar.SetStatusText("Performing %s. Please Be Patient."%self.titles[self.page_num])
                else:
                    #ack,data = self.cal_function[self.page_num](self.cal_dict)
                    self.task = WorkerThread(self)
                    self.task.set_run_func(self.cal_functions[self.page_num],cal_dict = self.cal_dict,instrs = self.instrs)
                    self.task.start()                             
                    self.status_bar.SetStatusText("Performing %s. Please Be Patient."%self.titles[self.page_num]) 
            except Exception:
                wx.MessageBox("Unable to Perform Cal Step. Redo.")
        
                
        if self.nextBtn.GetLabel() == "Finish":
            # Need to perform the cal step on the last page
            if self.cal_params:
                #ack,data = self.cal_functions[self.page_num](self.cal_params,self.cal_dict)
                self.task = WorkerThread(self)
                self.task.set_run_func(self.cal_functions[self.page_num],self.cal_params,self.cal_dict,self.instrs)
                self.task.start()
                self.status_bar.SetStatusText("Performing %s. Please Be Patient."%self.titles[self.page_num])                
            else:
                #ack,data = self.cal_function[self.page_num](self.cal_dict)
                self.task = WorkerThread(self)
                ack,data = self.task.set_run_func(self.cal_functions[self.page_num],cal_dict = self.cal_dict, instrs = self.instrs)
                self.task.start()                   
                self.status_bar.SetStatusText("Performing %s. Please Be Patient."%self.titles[self.page_num])                       
            
        if pagecount == self.page_num+2:
            self.nextBtn.SetLabel("Finish")
            self.nextBtn.Enable()
                       
            
    def onPrev(self,event):
        pagecount = len(self.pages)
        
        if self.page_num-1 != -1:
            self.pages[self.page_num].Hide()
            self.page_num -= 1
            if self.page_num == self.steps_done[self.page_num][0] and self.steps_done[self.page_num][1] == "Done":
                dlg = wx.MessageDialog(self,message="Cal Step Already Done, Redo?", style=wx.YES_NO)
                if dlg.ShowModal() == wx.ID_YES:
                    #ack,data = self.cal_functions[self.page_num](self.cal_params,self.cal_dict)
                    self.task = WorkerThread(self)
                    ack,data = self.task.set_run_func(self.cal_functions[self.page_num],self.cal_params,self.cal_dict,self.instrs)
                    self.task.start()
                    self.status_bar.SetStatusText("Performing %s. Please Be Patient."%self.titles[self.page_num])                    
                    self.nextBtn.SetLabel("Next")                    
                else:
                    # Do Nothing. Just wait for the user to press next
                    self.nextBtn.SetLabel("Next")
                    pass
            self.pages[self.page_num].Show()
            self.panelsizer.Layout()
        else:
            wx.MessageBox("Already on First Page")
            
            
    def StartBusy(self):
        self.timer.Start(100)
        
    def StopBusy(self):        
        self.timer.Stop()
        if self.task.stop_thread == True:
            wx.MessageBox('Cal Step Aborted')
            self.nextBtn.Enable()
        else:
            ack,data = self.task.get_ack_data()
            if ack == True:
                self.cal_dict[self.titles[self.page_num]] = data
                self.steps_done.append((self.page_num,"Done"))
                wx.MessageBox("%s Done!"%self.titles[self.page_num])
                self.page_num +=1
                self.status_bar.SetStatusText("")
                self.nextBtn.Enable()                                    
            else:
                self.steps_done.append((self.page_num,"Not Done"))
                wx.MessageBox("Cal Step Not Done, Redo!")        
                self.nextBtn.Enable()
                
        # Do a final cal data dump to the main gui 
        if len(self.pages) == self.page_num:
            self.main_window.cal_data = self.cal_dict

    def OnAbort(self,event):
        self.task.stop()
        self.status_bar.SetStatusText("Cal Step Aborted")                
               
    def onCancel(self, event):
        self.GetParent().Close()
            
class CalMain(wx.Frame):
    # The main calibration frame that takes the dict containing the cal functions and their labels
    def __init__(self,*args,**kwargs):
        super(CalMain,self).__init__(*args,**kwargs)
        self.SetTitle("Calibration Wizard")
        main_gui_window = get_main_window()        
        self.panel = wizardpanel(self,main_gui_window)
                
    def run_cal(self,cal_dict):
        if cal_dict == None:
            # The cal dict has the cal method names. Need it to run the cal wizard.
            raise Exception("Value required for cal dict")
            
        for i in cal_dict.iterkeys():
            # The cal dict contains a tuple the first element of which is a cal function 
            # The second element is the parameters to be calibrated
            self.panel.addPage(cal_dict[i][0],i,cal_dict[i][1],cal_dict[i][2],cal_dict[i][3])        
        self.Show() 
       
        