import os
import modeling.mct_files as mct

# print out the dciv data block
a = mct.MctDataFile('dev1_2x125um_dcands.dat')
b = a.get_blocks_by_section('sparams')
for i in b:
    print i.bias_line
    print type(i.data_lines)
        
    break    