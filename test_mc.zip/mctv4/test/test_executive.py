import threading
import logging
from .comm import send_message, get_command_queue, check_abort, TestExecQuit, AbortTest
from test_module_loader_1 import test_mod_loader

def instrument_loader( instr, required=[], optional=[] ):
    "load instruments in a safe manner"
    ret = {}
    errs = []
    
    log = logging.getLogger('catv_dist.instrument_loader')
    
    for name in required:
        if name not in instr:
            errs.append('%s: invalid instrument name'%instr[name].label)
            continue
        
        try:
            ret[name] = instr[name].open_instrument()
            if ret[name] is None:
                raise ValueError('invalid configuration')
        except Exception, e:
            log.exception("instrument load exception for '%s'"%name)
            errs.append('%s: initialization error: %s'%(instr[name].label,str(e)))
        
    if len(errs):
        # close all open instrument drivers
        # and raise an exception
        instrument_unloader(ret)                
        raise ValueError('\n'.join(errs))
        
    for name in optional:
        if name not in instr:
            ret[name] = None
            continue
        
        try:
            ret[name] = instr[name].open_instrument()
        except Exception, e:
            # ignore errors
            log.debug("instrument load exception for '%s' (optional instrument) -> %s"%(name,e))
            ret[name] = None
    
    return ret

def instrument_unloader( instr ):
    "unload all open instruments"
    for i in instr.values():
        try:
            i.close()
        except Exception:
            pass

class TestExecutive(threading.Thread):
    
    def run(self):
        loader = test_mod_loader()
        self._queue = get_command_queue()
        while True:
            try:
                c = self._queue.get()
                cmd = c.command()
                if cmd == "load module":
                    c.ack()
                    loader.load_module()
                elif cmd == "get module dict":
                    c.ack()
                    d = loader.get_modules()
                    return d
                    # Do something
                elif cmd == "get module params":
                    c.ack()
                    # Do something
                elif cmd == "get module instrs":
                    c.ack()
                    # Do something
                elif cmd == "get module bias wizard flag":
                    c.ack()
                    # Do something
                elif cmd == "run cal":
                    c.ack()
                elif cmd == "get cal flag":
                    c.ack()
                elif cmd == "get cal dict":
                    c.ack()
                    
                    
        
    