"""
Modeling Test and Characterization Suite V 0.0




"""
import wx
import logging, os, sys, traceback
from data_structs import ApplicationPreferences
from test_module_loader_1 import test_mod_loader
import wx.lib.newevent
from wx.lib.pubsub import pub
from utils import *
from data_display import DataFrame
from wxtestgui import parm, parm_group, Param, ValidationError, TestParameters, Instr
from wxtestgui.edit_params import EditTestParamsDialog, EditNumberListDialog, EditOrderedListDialog
from wxtestgui.edit_instruments import InstrumentConfigDialog
from wafer_map_main import multisite_window
import wx.lib.agw.genericmessagedialog as GMD
import threading
import time
from collections import OrderedDict
from wxtestgui.worker import Worker,EVT_WORKER_MESSAGE,EVT_WORKER_EXITING,send_to_ui,get_next_message
#from test_module_loader import *

about_info = wx.AboutDialogInfo()
about_info.SetCopyright('MACOM (2016)')
about_info.SetDescription('Modeling Test and Characterization Suite V 0.0')
about_info.SetName('MTACS')
about_info.SetVersion('0.0')
about_info.SetDevelopers(['Modeling Team',])

logger = logging.getLogger('mtacs_main')            
    
class ExceptionDialog(GMD.GenericMessageDialog):
    def __init__(self, msg):
        """Constructor"""
        GMD.GenericMessageDialog.__init__(self, None, msg, "Exception!",wx.OK|wx.ICON_ERROR)

 # Top level exception handler
def MyExceptionHook(etype, value, trace):
    """
    Handler for all unhandled exceptions.
 
    :param `etype`: the exception type (`SyntaxError`, `ZeroDivisionError`, etc...);
    :type `etype`: `Exception`
    :param string `value`: the exception error message;
    :param string `trace`: the traceback header, if any (otherwise, it prints the
     standard Python header: ``Traceback (most recent call last)``.
    """
    frame = wx.GetApp().GetTopWindow()
    tmp = traceback.format_exception(etype, value, trace)
    exception = "".join(tmp)
 
    dlg = ExceptionDialog(exception)
    dlg.ShowModal()
    dlg.Destroy()

# Simple GUI for calibration
class CalFrame(wx.Frame):
    def __init__(self,parent,id, cal_dict):
        # cal_dict is of the format {'step name':(function,test_params,instrs)}
        super(CalBox,self).__init__(parent,id)
        self.panel = wx.Panel(self)
        self.parent = parent
        pos_x = 100
        pos_y = 20
        self.cbs = []
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        self.cal_dict = cal_dict
        self.steps_done = []
        
        for i in cal_dict.iterkeys():
            pos_y += 20
            cb = wx.CheckBox(self.panel, label = i, pos = (pos_x,pos_y))
            self.cbs.append((cb,i[0]))
            
        self.statusbar = self.CreateStatusBar()
        
        self.Bind(EVT_WORKER_MESSAGE,self.OnWorkerUpdate)
        self.Bind(EVT_WORKER_EXITING,self.OnTestComplete)
        
                    
        self.btn_box = wx.StaticBox(self.panel,label = "Cal Buttons")
        self.btn_sizer = wx.StaticBoxSizer(self.btn_box, wx.HORIZONTAL) 
        
        self.measure = wx.Button(self.panel, wx.ID_ANY, "Measure")
        self.Bind(wx.EVT_BUTTON,self.OnMeasure,self.measure)
        self.abort = wx.Button(self.panel, wx.ID_ANY, "Abort Step")
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.abort)
        self.cancel = wx.Button(self.panel, wx.ID_ANY, "Cancel")
        self.Bind(wx.EVT_BUTTON, self.OnCancel, self.cancel)
        self.finish = wx.Button(self.panel, wx.ID_ANY, "Finish")
        self.Bind(wx.EVT_BUTTON,self.OnFinish, self.finish)
        
        self.finish.Disable()
        
        self.btn_sizer.Add(self.measure,0,wx.ALL,5)
        self.btn_sizer.Add(self.abort,0,wx.ALL,5)
        self.btn_sizer.Add(self.cancel,0,wx.ALL,5)
        self.btn_sizer.Add(self.finish,0,wx.ALL,5)
        
        self.cb_box = wx.StaticBox(self.panel, label = "Cal Steps")
        self.cb_sizer = wx.StaticBoxSizerBoxSizer(self.cb_box,wx.VERTICAL)                
        for i in self.cbs:
            self.cb_sizer.Add(i[0],1,wx.EXPAND)
            
        main_sizer.Add(self.cb_sizer,1,wx.ALL|wx.EXPAND)       
        main_sizer.Add((20,20))
        main_sizer.Add(self.btn_sizer,1,wx.ALL|wx.EXPAND)
        
        self.panel.SetSizer(main_sizer)
        self.SetSize((300,300))
        
        
    def OnFinish(self,evt):
        self.parent.cal_completed = True
        self.Destroy()
        
        
    def OnMeasure(self,evt):        
        for i in self.cbs:
            if i[0].GetValue() and i[1] not in self.steps_done:
                try:    
                    self.steps_done.append(i[1])
                    new_worker = Worker(self,target = self.cal_dict[i[1]])
                    new_worker.start()
                except Exception:
                    print "Exception"
                finally:
                    i[0].SetBackgroundColour(wx.GREEN)
        self._update_ui()
        
    def _update_ui(self):
        if len(self.cal_dict) == len(self.steps_done):
            self.finish.SetBackgroundColour(wx.GREEN)
            self.finish.Enable()
        else:            
            self.finish.Disable()
                        
    def OnWorkerUpdate(self,evt):            
        self.statusbar.SetStatusText(evt.msgtype)
        
    def OnTestComplete(self,evt):
        self.statusbar.SetStatusText("Step Complete")                
           
    def OnAbort(self,evt):
        self.new_worker.comm.send_to_worker("cal abort")
        self.statusbar.SetStatusText("Cal Step Aborted, Redo Step")        
        
    def OnCancel(self,evt):
        self.Destroy()

class WxTextCtrlHandler(logging.Handler):
    def __init__(self, ctrl):
        logging.Handler.__init__(self)
        self.ctrl = ctrl

    def emit(self, record):
        s = self.format(record) + '\n'
        wx.CallAfter(self.ctrl.WriteText, s) 

###### Main GUI Frame ########
        
class mtacs_main(wx.Frame):
    def __init__(self,*args,**kwargs):
                
        super(mtacs_main,self).__init__(*args,**kwargs)

                              
        self.setup = ApplicationPreferences()
        self.test_params = TestParameters()
        
        sys.excepthook = MyExceptionHook
                
        self.current_test_setup = None
                 
        # Create the test module loader object
        self.test_loader = test_mod_loader()
        self.module_loaded = False
        
        set_main_window(self)                
                
        self.controls = {}
        self.current_test_selection = None
        self.CreateStatusBar(style = 0)
                
        pub.subscribe(self.change_status,'change status')
        self.timer = wx.Timer(self)
                
        self.Notebook = wx.Notebook(self,-1, style = 0)
        self.MainPanel = wx.Panel(self.Notebook, -1)
        self.SetupPanel = wx.Panel(self.Notebook, -1)
                  
        # Setup the menu bar for the software main window
        menubar    = wx.MenuBar()
        
        #File Menu
        file_menu  = wx.Menu()
        file1 = file_menu.Append(wx.ID_OPEN,"Load Setup...")
        file2 = file_menu.Append(wx.ID_SAVE,"Save Setup...")
        file_menu.AppendSeparator()
        file3 = file_menu.Append(wx.ID_EXIT,"Exit", "Exit")
        #File Menu Action Handlers
        self.Bind(wx.EVT_MENU,self.OnLoadSetup,file1)
        self.Bind(wx.EVT_MENU,self.OnSaveSetup,file2)
        self.Bind(wx.EVT_MENU,self.OnExit,file3)
        
        #Help Menu
        help_menu = wx.Menu()
        help1 = help_menu.Append(wx.ID_HELP,"Help")
        info1 = help_menu.Append(wx.ID_ANY, "About")
        #Help Menu Action Handlers
        self.Bind(wx.EVT_MENU,self.OnHelp,help1)
        self.Bind(wx.EVT_MENU,self.OnAbout,info1)
        
        #Add Menus to Menubar
        menubar.Append(file_menu,"File")
        menubar.Append(help_menu, "Help")
        self.SetMenuBar(menubar)
          
        #Create Tree control for loading test module   
        # The main page just has a list of tests and a description of the test
        #Create List of Test Names
        tree_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.controls['test_tree'] = wx.TreeCtrl(self.MainPanel,-1, style=wx.TR_HAS_BUTTONS|wx.TR_DEFAULT_STYLE|wx.SUNKEN_BORDER)
        
        # Need to replace this with pretty looking test module names
        # The rootdir is temporarily hard coded. It will be replaced with a dir specified by application_preferences()
        module_dict = self.test_loader.get_modules()        
        root = self.controls['test_tree'].AddRoot("Routines")
        
        for i in module_dict.iterkeys():
            new_item = self.controls['test_tree'].AppendItem(root,i)
            for j in module_dict[i]:
                self.controls['test_tree'].AppendItem(new_item,j)
                
        self.Bind(wx.EVT_TREE_SEL_CHANGED,self.OnSelChanged,self.controls['test_tree'])        
        tree_sizer.Add(self.controls['test_tree'],1,wx.EXPAND, 5)
        
        load_btn_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.controls['load_module_button'] = wx.Button(self.MainPanel,wx.ID_ANY,"Load Test Module")
        self.Bind(wx.EVT_BUTTON, self.OnTestSelect, self.controls['load_module_button'])
        load_btn_sizer.Add(self.controls['load_module_button'], 1,wx.CENTER)
        
        mainwinsizer = wx.BoxSizer(wx.VERTICAL)
        mainwinsizer.Add(tree_sizer,1,wx.EXPAND|wx.ALL,5)
        mainwinsizer.Add(load_btn_sizer,1,wx.CENTER,5)
                
        # Code for the "Setup" page of the notebook
        
        # Box to display the test module's docstring
        test_info_box = wx.StaticBox(self.SetupPanel, label = "Test Module Information")
        test_info_box_sizer = wx.StaticBoxSizer(test_info_box, wx.HORIZONTAL)
        self.controls['test_info'] = wx.TextCtrl(self.SetupPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        test_info_box_sizer.Add(self.controls['test_info'],1,wx.EXPAND,5)        
                                
        # Test Control buttons
        setup_box = wx.StaticBox(self.SetupPanel, label = "Setup Menu")
        setup_sizer = wx.StaticBoxSizer(setup_box,wx.VERTICAL)
        self.controls['instrument_setup'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Instruments")
        self.controls['multisite_control'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Multisite Controller")
        # Bind buttons to event handlers
        self.Bind(wx.EVT_BUTTON,self.OnInstrumentSetup,self.controls['instrument_setup'])
        self.Bind(wx.EVT_BUTTON,self.OnMultisite, self.controls['multisite_control'])
        # Add buttons to the sizer
        setup_sizer.Add(self.controls['instrument_setup'],1, wx.CENTER,5)
        setup_sizer.Add(self.controls['multisite_control'],1, wx.CENTER,5)
        
        # Test Parameter buttons
        test_box = wx.StaticBox(self.SetupPanel, label = "Test Menu")
        test_sizer = wx.StaticBoxSizer(test_box, wx.VERTICAL )
        self.controls['edit_params'] = wx.Button(self.SetupPanel, wx.ID_ANY,"Edit Parameters")
        self.Bind(wx.EVT_BUTTON, self.OnEditParams, self.controls['edit_params'])
        self.controls['calibrate'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Calibrate")
        self.Bind(wx.EVT_BUTTON, self.OnCalibrate, self.controls['calibrate'])
        self.controls['validate'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Validate")
        # Sizer for the Test parameters and calibrate options
        test_sizer.Add(self.controls['edit_params'],1, wx.CENTER,5)
        test_sizer.Add(self.controls['calibrate'],1, wx.CENTER,5)
        test_sizer.Add(self.controls['validate'],1, wx.CENTER,5)
        
        # Buttons for the run/abort buttons
        run_box = wx.StaticBox(self.SetupPanel, label = "Test Controller")
        run_sizer = wx.StaticBoxSizer(run_box, wx.VERTICAL)
        self.controls['run'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Run")
        self.Bind(wx.EVT_BUTTON,self.OnRunTest, self.controls['run'])
        self.controls['abort'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Abort")
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.controls['abort'])
        self.controls['data_display'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Data Display")
        self.Bind(wx.EVT_BUTTON, self.OnDataDisplay, self.controls['data_display'])
        # Add run and abort to the sizer
        run_sizer.Add(self.controls['run'],1,wx.CENTER, 5)
        run_sizer.Add(self.controls['abort'],1,wx.CENTER, 5)
        run_sizer.Add(self.controls['data_display'],1,wx.CENTER, 5)
        
        # Button for the unload module button
        unload_box = wx.StaticBox(self.SetupPanel, label = "Unload Module")
        unload_sizer = wx.StaticBoxSizer(unload_box, wx.HORIZONTAL)
        self.controls['unload_module'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Unload Module")
        self.Bind(wx.EVT_BUTTON, self.OnUnloadModule, self.controls['unload_module'])
        unload_sizer.Add(self.controls['unload_module'],1,wx.CENTER, 5)

        # Drop down combo-box for routine selection
        routine_box = wx.StaticBox(self.SetupPanel, label = "Select Routine")
        routine_sizer = wx.StaticBoxSizer(routine_box, wx.HORIZONTAL)
        # If the test module has routines, get it, else display nothing
        self.controls['routine_selection'] = wx.ComboBox(self.SetupPanel,choices = [''],style = wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX,self.OnRoutineSelect) 
        routine_sizer.Add(self.controls['routine_selection'],1,wx.CENTER, 5)        
        
        # Text control for the logging utility
        logging_info_box = wx.StaticBox(self.SetupPanel, label = "Test Logger")
        logging_box_sizer = wx.StaticBoxSizer(logging_info_box, wx.HORIZONTAL)
        self.controls['test_logger'] = wx.TextCtrl(self.SetupPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        logging_box_sizer.Add(self.controls['test_logger'],1,wx.EXPAND,5)   
        handler = WxTextCtrlHandler(self.controls['test_logger'])
        logger.addHandler(handler)
        FORMAT = "%(asctime)s %(levelname)s %(message)s"
        handler.setFormatter(logging.Formatter(FORMAT))
        logger.setLevel(logging.DEBUG)
        
        main_button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        main_button_sizer.Add(setup_sizer, 1, wx.LEFT, 5)
        main_button_sizer.Add(test_sizer, 1, wx.CENTER, 5)
        main_button_sizer.Add(run_sizer, 1, wx.RIGHT, 5)
                
        setup_main_sizer = wx.BoxSizer(wx.VERTICAL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(test_info_box_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(main_button_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(routine_sizer,0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(unload_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(logging_box_sizer,0,wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,40))
                    
        self.Notebook.AddPage(self.MainPanel, "Main")
        self.Notebook.AddPage(self.SetupPanel, "Setup")
        
        self.MainPanel.SetSizer(mainwinsizer)
        self.SetupPanel.SetSizer(setup_main_sizer)
        
        self.SetSize((700,700))
        self.SetPosition((100,100))
        self.SetTitle(PROGNAME)
        
        self.change_status("No Module Loaded")
        
        self._update_gui()
        
    def OnMultisite(self,evt):
        m_display = multisite_window(self)
        m_display.Show()        
            
    def OnSelChanged(self, evt):
        self.tree_choice = evt.GetItem()
                
    def OnInstrumentSetup(self, evt):
        self.instruments = {}
        for instr in self.instrs:
            self.instruments[instr.name] = instr
        if 'instrument_setup' in self.setup:
            for nm, data in self.setup['instrument_setup'].iteritems():
                if nm in self.instruments and len(data) == 4:
                    instr = self.instruments[nm]
                    instr.driver_name = data[0]
                    instr.resource = data[1]
                    instr.chan = data[2]
                    instr.parms = data[3]
            
        dlg = InstrumentConfigDialog(self.instrs,parent=None)
        if dlg.ShowModal() == wx.ID_OK:
            # save instrument setup in preferences
            data = {}
            for instr in self.instrs:
                data[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)
            self.setup['instrument_setup'] = data
            dlg.Destroy()
            
    def OnRoutineSelect(self,evt):
        self.test_routine = self.controls['routine_selection'].GetSelection()
        
    def change_status(self,message):
        self.SetStatusText(message)
        
    def OnEditParams(self, evt):
        dlg = EditTestParamsDialog(self.test_params.get_dialog_list(),None,style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        if dlg.ShowModal() == wx.ID_OK:
            # Get the values of the changed parameters
            self.test_params = TestParameters(self.params)
            logger.log(logging.INFO, "Parameters Edited")
            dlg.Destroy()
        
    def _update_gui(self):
        
        # First check if a module has been loaded. If it has, enable/disable buttons on page 2, else diable all
        if self.module_loaded == False:
            self.change_status("No Module Loaded")
            for i in ['data_display','edit_params','calibrate','validate','run','abort','instrument_setup', 'unload_module','routine_selection','multisite_control']:
                self.controls[i].Disable()
            self.controls['test_info'].SetValue(" ")
            
        else:
            self.change_status('Module Loaded')
            self.controls['test_info'].SetValue(self.doc_str)
            for i in ['data_display','edit_params','run','abort','instrument_setup','unload_module','multisite_control']:
                self.controls[i].Enable()
            self.routines = self.test_loader.get_test_routines()
            if self.routines != None:
                self.controls['routine_selection'].Enable()
                for i in self.routines:
                    self.controls['routine_selection'].Append(i)                
            if self.test_loader.get_module_cal_flag() == False:
                self.controls['calibrate'].Disable()
            else:
                self.controls['calibrate'].Enable()
                
    def OnDataDisplay(self,evt):
        self.test_data_dict = self.test_loader.get_test_data() 
        
        if self.test_data_dict:
            datadisp = DataFrame(self.test_data_dict)
            datadisp.Show()
        else:
            logger.log(logging.ERROR, "No Data to Display. Run the Test First")
        
        
    def OnLoadSetup(self, evt):
        dir = os.path.expanduser('~')
        kw = {'style':wx.FD_OPEN,'wildcard':"Test Setup Files (*.stp)|*.stp"}
        if len(dir) and os.path.isdir(dir):
            kw['defaultDir'] = dir
        dlg = wx.FileDialog(None,'Load Test Setup File',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            try:
                self.setup.load(fname+'.cfg')
                self.module_loaded = True
                self.test_loader.load_module(str(self.setup['device']), str(self.setup['current_test_selection']))
                self.doc_str = self.test_loader.get_module_docstr()
                self.cal_flag = self.test_loader.get_module_cal_flag()
                self.params = self.test_loader.get_module_params()
                self.test_params = TestParameters(self.params)
                self.instrs = self.test_loader.get_module_instrs()
                self.test_routine = self.test_loader.get_test_routines()
                self.test_params.load(fname)
                logger.log(logging.INFO, "Setup Loaded")
                                
            except Exception, e:
                logger.log(logging.ERROR, "Error loading module: %s" %e)
                           
        dlg.Destroy()
        
        # update the main GUI
        self._update_gui()
        
    def OnSaveSetup(self, evt):
        # Put a wx dialog in here for the setup filename
        "save the current setup"
        dir = os.path.expanduser('~')
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT,'wildcard':"Test Setup Files (*.stp)|*.stp"}
        if len(dir) and os.path.isdir(dir):
            kw['defaultDir'] = dir
        dlg = wx.FileDialog(None,'Save Test Setup File',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            self.test_params.save(fname)
            self.setup['test_setup_file'] = fname
            self.setup.save(fname+'.cfg')
            
        dlg.Destroy()
        
    def OnCalibrate(self, evt):
        logger.log(logging.INFO, "Running Calibration")
        cal_dict = self.test_loader.get_module_cal_dict()
        tmp_dict = {}
        # Provide the cal routine with a cal dict
        cal_data_dict = {}
        
        self.a.set_abort(0)
        self.change_status("Running Cal....")
        self.cal_data = {}
        self.test_loader.run_cal(cal_dict,self.test_params,cal_data_dict,self.instrs)
                
                
    # This method is called when the File Exit button is clicked. It allows the user to exit the program
    def OnExit(self, evt):
        dlg = wx.MessageDialog(self, 'Are You Sure You Want To Exit?', 'Exit', wx.YES_NO|wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlg.Destroy()
            self.Close()
        else:
            dlg.Destroy()
            
    def OnHelp(self, evt):
        dlg = wx.MessageDialog(self, 'This Help menu is currently not implemented', 'Help')
        if dlg.ShowModal() == wx.ID_OK:
            dlg.Destroy()
            
    def OnAbout(self, evt):
        "show the program information dialog"
        wx.AboutBox(about_info)
        
    def OnTestSelect(self, evt):
        # Loads the module
        logger.log(logging.INFO, "Loading the module")
        
        self.module_loaded = True
        
        # Store the current test selection as a parameter, will be useful while loading/saving the setup
        self.current_test_selection = self.controls['test_tree'].GetItemText(self.tree_choice)
        self.setup['current_test_selection'] = self.current_test_selection
        
        # Store the current device type as a parameter
        parent = self.controls['test_tree'].GetItemParent(self.tree_choice)
        self.device = self.controls['test_tree'].GetItemText(parent)
        self.setup['device'] = self.device
        
        self.test_loader.load_module(self.device, self.current_test_selection)
        
        # Now get the module docstr and parameters
        self.doc_str = self.test_loader.get_module_docstr()
        self.params = self.test_loader.get_module_params()
        self.test_params = TestParameters(self.params)
        self.cal_flag = self.test_loader.get_module_cal_flag()
        self.instrs = self.test_loader.get_module_instrs()
        self.test_routine = self.test_loader.get_test_routines()
                
        self._update_gui()
        
    def OnRunTest(self,evt):
        dlg = file_header_gui(self.controls,parent = None )
        
                
        # Temporary dictionary that store the file header
        self.file_header = {}
        
        self.a.set_abort(0)
                
        if dlg.ShowModal() == wx.ID_OK:
            for i in ['wafer_name','process_name','device_name','cal_kit_name','temp','comments']:
                self.file_header[i] = self.controls[i].GetValue()
            self.setup['file_header'] = self.file_header
            dlg.Destroy()
            
        if 'output_filename' not in self.setup:
            kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT}
            if 'last_data_path' in self.setup and os.path.isdir(self.setup['last_data_path']):
                kw['defaultDir'] = self.setup['last_data_path']
            dlg = wx.FileDialog(None,'Select output file',**kw)  
            if dlg.ShowModal() != wx.ID_OK:
                return
            fname = dlg.GetPath()
            self.setup['last_data_path'] = os.path.dirname(fname)
            init_file = True
        else:
            fname = self.setup['output_filename']
        logger.log(logging.INFO, "Running the Test")
        self.controls['run'].Disable()
        
        if self.cal_flag == False:
            self.cal_data = None 
        
        self.task = WorkerThread(self)
        self.task.set_run_func(self.test_loader.run_test,self.test_params,self.file_header,self.instrs,fname,self.cal_data,self.test_routine)
        self.task.start()
        #self.test_loader.run_test(self.test_params,self.file_header,self.instrs,fname)
        
        self.change_status("Running Test. Please Be Patient or Press Abort!")
                    
        
    def StartBusy(self):
        self.timer.Start(100)
        
    def StopBusy(self):
        self.timer.Stop()
        if self.task.stop_thread == True:
            logger.log(logging.INFO, 'Test Aborted!')
            self.change_status("Test aborted. Press run again to restart.")
        else:
            logger.log(logging.INFO,'Test Complete!')
            self.change_status("Idle")
        self.controls['run'].Enable()
                        
    def OnAbort(self,evt):
        self.task.stop()
        logger.log(logging.INFO,'Test Aborted!')

    def OnUnloadModule(self,evt):
        logger.log(logging.INFO, "Unloading the module")
        self.module_loaded = False
        self.doc_str = None
        self.params = None
        self.cal_flag = None
        self.instrs = None
        self.routines = ['']
        self._update_gui()
       
                    

if __name__ == "__main__": 
     #sys.excepthook = ExceptionHook
     app = wx.App(redirect=False) 
     frame_1 = mtacs_main(None, -1) 
     app.SetTopWindow(frame_1) 
     frame_1.Show() 
     app.MainLoop()   
        
        