
import wx
import wx.wizard as wiz
from wxtestgui.worker import Worker,send_to_ui,EVT_WORKER_MESSAGE, EVT_WORKER_EXITING

class WizardPage(wx.Panel):
    
    def __init__(self,parent,title = None,docstr=None):
        wx.Panel.__init__(self,parent)
        if title:
            self.title = title
        else:
            self.title = "Cal Step Undefined"
        if docstr:
            self.docstr = docstr
        else:
            self.docstr = "Docstr for this calibration function not available"
        self.init()
            
    def init(self):
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        page_sizer = wx.BoxSizer(wx.HORIZONTAL)
        desc_sizer = wx.BoxSizer(wx.HORIZONTAL)
        
        title = wx.StaticText(self, -1, self.title)
        title.SetFont(wx.Font(18, wx.SWISS, wx.NORMAL, wx.BOLD))
        page_sizer.Add(title, 0, wx.ALIGN_CENTRE|wx.ALL, 5)
        page_sizer.Add(wx.StaticLine(self, -1), 0, wx.EXPAND|wx.ALL, 5)
        
        step_desc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,value = self.docstr)
        desc_sizer.Add(step_desc,wx.EXPAND|wx.ALL)
        
        main_sizer.Add(page_sizer,0,wx.ALL)
        main_sizer.Add(desc_sizer,0,wx.EXPAND|wx.ALL)
        self.SetSizer(main_sizer)

class WizardPanel(wx.Panel):
    def __init__(self,parent):
        
        wx.Panel.__init__(self, parent=parent)
        self.pages = []
        self.page_num = 0
 
        self.mainSizer = wx.BoxSizer(wx.VERTICAL)
        self.panelSizer = wx.BoxSizer(wx.VERTICAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)
 
        # add prev/next buttons
        self.prevBtn = wx.Button(self, label="Previous")
        self.prevBtn.Bind(wx.EVT_BUTTON, self.onPrev)
        btnSizer.Add(self.prevBtn, 0, wx.ALL|wx.ALIGN_RIGHT, 5)
 
        self.nextBtn = wx.Button(self, label="Next")
        self.nextBtn.Bind(wx.EVT_BUTTON, self.onNext)
        btnSizer.Add(self.nextBtn, 0, wx.ALL|wx.ALIGN_RIGHT, 5)
 
        # finish layout
        self.mainSizer.Add(self.panelSizer, 1, wx.EXPAND)
        self.mainSizer.Add(btnSizer, 0, wx.ALIGN_RIGHT)
        self.SetSizer(self.mainSizer)
        
    def addPage(self, title=None):
        """"""
        panel = WizardPage(self, title)
        self.panelSizer.Add(panel, 2, wx.EXPAND)
        self.pages.append(panel)
        if len(self.pages) > 1:
            # hide all panels after the first one
            panel.Hide()
            self.Layout()
            
    def onNext(self, event):
        """"""
        pageCount = len(self.pages)
        if pageCount-1 != self.page_num:
            self.pages[self.page_num].Hide()
            self.page_num += 1
            self.pages[self.page_num].Show()
            self.panelSizer.Layout()
        else:
            print "End of pages!"
 
        if self.nextBtn.GetLabel() == "Finish":
            # close the app
            self.GetParent().Close()
 
        if pageCount == self.page_num+1:
            # change label
            self.nextBtn.SetLabel("Finish")
            
    def onPrev(self, event):
        """"""
        pageCount = len(self.pages)
        if self.page_num-1 != -1:
            self.pages[self.page_num].Hide()
            self.page_num -= 1
            self.pages[self.page_num].Show()
            self.panelSizer.Layout()
        else:
            print "You're already on the first page!"
            
class CalMain(wx.Frame):
    """"""
 
    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        wx.Frame.__init__(self, None, title="Generic Wizard", size=(800,600))
 
        self.panel = WizardPanel(self)
        self.panel.addPage("Page 1")
        self.panel.addPage("Page 2")
        self.panel.addPage("Page 3")
 
        self.Show()
 
if __name__ == "__main__":
    app = wx.App(False)
    frame = MainFrame()
    app.MainLoop()
        
