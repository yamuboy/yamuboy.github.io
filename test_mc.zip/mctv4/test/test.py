def get_data(name):
    data = {'vds':[],'ids':[],'vgs':[],'igs':[]}
    for i in name:
        if i == '\n':
            data['vds'].append(0.0)
            data['ids'].append(0.0)
            data['vgs'].append(0.0)
            data['igs'].append(0.0)
            continue
            
        data['vds'].append(i.split('\t')[0])
        data['ids'].append(i.split('\t')[1])
        data['vgs'].append(i.split('\t')[2])
        data['igs'].append(i.split('\t')[3].strip('\n'))
    return data


def file_parser(file):
    iv_list = ['! *********** Forward I-V ***********\n','! *********** Leakage I-V ***********\n','! *********** DC I-V ***********\n','! *********** Transfer I-V ***********\n']
    with open(file) as f:
        temp = f.readlines()
        
    ngf = float(temp[5].split('=')[1].strip('\n'))
    ugw = float(temp[6].split('=')[1].strip('\n'))
    periph = (ngf*ugw)/1000.0
    fwdiv_index = temp.index(iv_list[0])
    leakiv_index = temp.index(iv_list[1])
    dciv_index = temp.index(iv_list[2])
    txfr_index = temp.index(iv_list[3])
    
    fwdiv_data = temp[fwdiv_index+3:leakiv_index-2]
    leakiv_data = temp[leakiv_index+3:dciv_index-2]
    dciv_data = temp[dciv_index+3:txfr_index-3]
    txfr_data = temp[txfr_index+3:len(temp)-2]
    
    dataset = {'periph':periph,'fwdiv':get_data(fwdiv_data),'leakiv':get_data(leakiv_data), 'dciv':get_data(dciv_data), 'txfr':get_data(txfr_data)}
    
    print dataset
        
    
if __name__ == "__main__":
    file_parser('xx.dat')
        