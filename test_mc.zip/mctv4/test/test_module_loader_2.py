import os
from cal_wizard_1 import CalMain
import threading
import wx
# test module loader functions

def new_import(mod_path):
    mod = __import__(mod_path)
    components = mod_path.split('.')
    for comp in components[1:]:
        mod = getattr(mod, comp)
    return mod

class test_mod_loader(object):
    
    _shared_state = dict()
    
    def __init__(self):
        self.__dict__ = self._shared_state
        
        if '_isinitialized' not in self.__dict__:
            self._isinitialized = True
            # Populate the module dictionary
            self._module_dict = {'fet':[],'bjt':[],'mosfet':[]}
            for i in self._module_dict.iterkeys():
                for j in os.listdir(os.path.expanduser('~\\pylib\mctv4\\routines\\'+i)):
                    if j.endswith('.svn') or j.endswith('.pyc') or j == '__init__.py':
                        next
                    else:
                        self._module_dict[i].append(j)
                        
    def get_modules(self):
        return self._module_dict
        
    def get_current_module(self):
        return self.current_module
        
    def load_module(self, device, module):
        try:
            self.current_module = new_import('mctv4.routines.%s.%s'%(device,module.strip('.py')))
        except ImportError:
            raise Exception("Unable to import module %s"%module.strip('.py'))
                        
    def get_module_docstr(self):
        if self.current_module == None:
            raise Exception("Load a module first!")
        return self.current_module.__doc__.strip(" ")
        
    def get_module_params(self):
        if self.current_module == None:
            raise Exception("Load a module first!")
        elif not hasattr(self.current_module, "TEST_PARAMS"):
            raise Exception("The module must have some test parameters")
        return (self.current_module.TEST_PARAMS)
        
    def get_module_instrs(self):
        if self.current_module == None:
            raise Exception("Load a Module first!")
        elif not hasattr(self.current_module, "INSTR_LIST"):
            raise Exception("The Module must have some Instrs")
        return (self.current_module.INSTR_LIST)
        
    def get_module_cal_flag(self):
        if not self.current_module:
            raise Exception("Load a module first!")
        if not hasattr(self.current_module,"CAL_REQD"):
            raise Exception("The module must have a cal flag")
        return (self.current_module.CAL_REQD)
        
    def get_module_cal_function(self):
        if not hasattr(self.current_module,"CAL_FUNCTION"):
            raise Exception("This module requires a cal function")
        return (self.current_module.CAL_FUNCTION)
        
    def get_module_biaswizard_flag(self):
        if not hasattr(self.current_module, "BIAS_WIZARD"):
            raise Exception("Need to know if the module needs a bias wizard")
        return (self.current_module.BIAS_WIZARD)
        
    def get_module_cal_dict(self):
        if not hasattr(self.current_module, "CAL_DICT"):
            raise Exception("Need a cal dict for this module")
        return(self.current_module.CAL_DICT)
        
    def get_bias_list(self):
        if not hasattr(self.current_module, "BIAS_LIST"):
            raise Exception("Need a bias list with bias order for this test")
        return(self.current_module.BIAS_LIST)
        
    def run_test(self,test_params,file_header,instrs,dfname):
        if not hasattr(self.current_module, "RUN_FUNCTION"):
            raise Exception("Module Needs a run function")
        test_parm_flag = self.validate_params(test_params)
        if test_parm_flag != True:
            raise Exception("Parameter x isn't valid")
        # dfname is the name of the file the data will be written to
        test_dict = {'test_params': test_params, 'file_header':file_header,'instrs': instrs, 'dfname': dfname}
        # Hand the test_dict to the module's run function which will go off and run the test
        test_data = self.current_module.RUN_FUNCTION(**test_dict)
        return test_data
        
    def validate_params(self,test_params):
        # This method validates the test params, returns a fail flag if a parameter isn't valid 
        # For now, just return true
        return True
        
    def run_cal(self,cal_dict):
        c = CalMain()
        c.run_cal(cal_dict)
        
        
        
        
        
        
       
            
        
    
    
            