import sys
import os.path
import math

def main():
    """Entry point."""
    files = sys.argv[1:]
    if sys.platform in ('winnt','win32'):
        import glob
        f2 = []
        for f in files:
            f2.extend(glob.glob(f))
        files = f2
    
    for inname in files:
        outname, _ = os.path.splitext(inname)
        outname += '.mdf'
        convert_piv_to_mdf(inname, outname)

def convert_piv_to_mdf( piv_fname, out_fname ):
    """Converted a pulsed-IV data file to MDIF format."""
    fin = open(piv_fname,'r')
    fout = open(out_fname,'w')
    
    try:
        for line in fin:
            if line.startswith('\\'):
                fout.write('!'+line[1:])
            else:
                ds = _read_block(fin)
                _write_mdif(fout,ds)
    finally:
        fin.close()
        fout.close()
    

def _read_floats(line):
    """Read floats from a line of data."""
    lary = line.split()
    ret = []
    for d in lary:
        try:
            ret.append(float(d))
        except ValueError:
            pass
    return ret

def _read_block(f):
    """Read a block of PIV data at a single gate voltage."""
    ds = {'vgs':[], 'vds':[], 'ids':[], 'igs':[]}
    count = 0
    for line in f:
        fl = _read_floats(line)
        if len(fl) < 5:
            if count > 0:
                return ds
        else:
            ds['vgs'].append(fl[0])
            ds['vds'].append(fl[1])
            ds['ids'].append(fl[2])
            ds['igs'].append(fl[3])
            count += 1
    
    return ds

def _write_mdif(f, ds):
    """Write a block of the MDIF data file."""
    # find the average vgs and round it to 3 decimal places
    if not len(ds['vgs']):
        return
    
    vgs = 0.0
    for v in ds['vgs']:
        vgs += v
    vgs = round(vgs / float(len(ds['vgs'])),3)
    
    f.write('!\n')
    f.write('VAR Vgs(1) = %g\n'%vgs)
    f.write('BEGIN PIVDATA\n')
    f.write('%\tVds(1)\tIds(1)\tIgs(1)\n')
    for i in range(len(ds['vgs'])):
        f.write('\t%g\t%g\t%g\n'%(ds['vds'][i],ds['ids'][i],ds['igs'][i]))    
    f.write('END\n')
     
if __name__ == '__main__':
    main()
    