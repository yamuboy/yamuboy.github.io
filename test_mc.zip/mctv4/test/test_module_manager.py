import weakref

class TestModuleManager(object):

    __shared_state = dict()
    def __init__(self):
        self.__dict__ = self.__shared_state
        
        if '_isinitialized' not in self.__dict__:
            self._isinitialized = True
            # Store a dictionary of registered modules
            self.__module_list = []
            
    def _register_module(self,module):
        self.__module_list.append(weakref.ref(module))
        
    def _open_module(self,module):
        # This
        
    
            
            
        