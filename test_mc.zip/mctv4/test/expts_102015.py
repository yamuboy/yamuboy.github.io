# Exception handler
class CalibrationError(Exception): pass
class ValidationError(Exception): pass

def validation_check(v):
    try:
        if v == True:
            pass
        else:
            raise ValidationError
            
    except ValidationError:
        print 'validation error'
        
class Eval:
    def __init__(self,*args,**kwargs):
        if 'val' in kwargs:
            self.val = kwargs['val']
        else:
            self.val = []
            
    def __setitem__(self,val):
        self.val.append(val)
            
    def __getitem__(self,item):
        return self.val[item]
        
    def __contains__(self,val):
        if val in self.val:
            return True
        else:
            return False
        
        
        