# testing the wafer mapping utility with real data 
from instrument import multisite

multi = multisite.Multisite()
die_locations = []
reticle_dict = [{'die_x':1000,'die_y':500,'name':'28v_2x100','location':(1,1)},
                {'die_x':1000,'die_y':500,'name':'28v_2x100','location':(1,2)},
                {'die_x':1000,'die_y':500,'name':'28v_2x100','location':(1,3)},
                {'die_x':1000,'die_y':500,'name':'28v_4x100','location':(1,4)},
                {'die_x':1000,'die_y':500,'name':'28v_4x100','location':(2,1)},
                {'die_x':1000,'die_y':500,'name':'pcm','location':(2,2)},
                {'die_x':1000,'die_y':500,'name':'40v_2x200','location':(2,3)},
                {'die_x':1000,'die_y':500,'name':'28v_2x100','location':(2,4)},
                {'die_x':1000,'die_y':500,'name':'28v_2x100','location':(3,1)},
                {'die_x':1000,'die_y':500,'name':'40v_4x100','location':(3,2)},
                {'die_x':1000,'die_y':500,'name':'test1','location':(3,3)},
                {'die_x':1000,'die_y':500,'name':'test2','location':(3,4)}]
x_ref = 1500
y_ref = 1500
init_x = x_ref
init_y = y_ref
ref_list = []
for n,i in enumerate(reticle_dict):
    die = {}
    d['name'] = i['name']
    loc = i['location']
    if loc[0] == 1 and loc[1] == 1:
        # at first die, reference is the same
        die['ref_x'] = x_ref
        die['ref_y'] = y_ref
        
    