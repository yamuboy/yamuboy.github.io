def generate_sweeps( auto_test_data ):
    "generate sweep data"

    def _recurse( lvl, names, data, incoming ):
        "recursively generate sweep data"
        myname = names[lvl]
        mydata = data[lvl]
        next = lvl+1
        out = []
        for val in mydata:
            d = incoming.copy()
            d[myname] = val
            if next < len(names):
                out.extend(_recurse(next,names,data,d))
            else:
                out.append(d)
        return out
            
    mapping = {'power':'power_dbmv'}
    for b in 'bias1','bias2','bias3','bias4':
        mapping[b] = b+'_volts'
    
    names = []
    data = []
    for svar in reversed(auto_test_data['sweep_order']):
        sweep = auto_test_data[svar]
        if len(sweep):
            names.append(svar)
            data.append(sweep)
    
    return _recurse(0,names,data,{})
    
if __name__ == "__main__":
    test_dict = {'frequency':[1000,2000],'power':[1,2],'bias1':[-1,-0.5],'bias2':[8,10],'sweep_order':['bias1','bias2','frequency','power']}
    t = generate_sweeps(test_dict)
    for i in  t:
        print i