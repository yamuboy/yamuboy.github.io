import wx 
from wx.lib.floatcanvas import FloatCanvas
import math
import random
import wx.grid

FLAT_LENGTHS = {50: 15.88, 75: 22.22, 100: 32.5, 125: 42.5, 150: 57.5}


def dummy_data(w_diameter):    
    # Create some dummy reticle data, in mm
    # Offsets 0,0 which means that the center of the wafer is in the center of the die
    reticle_x = 6.5
    reticle_y = 6.58
    offset_x = 0
    offset_y = 0
    excl_list = [0, 2.5, 5, 10]
    
    edge_excl = 2.5
    flat_excl = 2.5
    # Wafer diameter is 150 mm
    reticle_size = (reticle_x, reticle_y)
    # Generate a square grid 
    grid_max_x = 2 * int(math.ceil(w_diameter/reticle_x))
    grid_max_y = 2 * int(math.ceil(w_diameter/reticle_y))
    grid_center = ((grid_max_x/2)+offset_x , (grid_max_y/2)+offset_y)
    
    flat_y = -w_diameter/2     # assume wafer edge at first
    if w_diameter in FLAT_LENGTHS:
        # A flat is defined by SEMI M1-0302, so we calcualte where it is
        flat_y = -math.sqrt((w_diameter/2)**2 - (FLAT_LENGTHS[w_diameter] * 0.5)**2)

    # calculate the exclusion radius^2
    excl_sqrd = (w_diameter/2)**2 + (edge_excl**2) - (w_diameter * edge_excl)
    
    grid_points = []
    for x in range(1,grid_max_x):
        for y in range(1,grid_max_y):
            ret_cent_x = reticle_x * (x - grid_center[0])
            ret_cent_y = reticle_y * (grid_center[1] - y)
            
            cent_rad_sqrd = ret_cent_x**2 + ret_cent_y**2
            
            ret_cent_xy = (ret_cent_x, ret_cent_y)
                        
            ret_max_sqrd = max_dist_sqrd( ret_cent_xy , reticle_size)
            
            ret_lower_left_y = ret_cent_y - reticle_y/2
            
            if (ret_max_sqrd > excl_sqrd or ret_lower_left_y < (flat_y + flat_excl)):
                continue 
            else:
                grid_points.append((x,y,cent_rad_sqrd))
            
    return grid_points, reticle_size,grid_center
    
def grid_to_rect_coord(grid, die_size, grid_center):
    _x = die_size[0] * (grid[0] - grid_center[0] - 0.5)
    _y = die_size[1] * (grid_center[1] - grid[1] - 0.5)
    return (_x, _y)
    
    
def max_dist_sqrd(center, size):
    half_x = size[0]/2.
    half_y = size[1]/2.
    if center[0] < 0:
        half_x = -half_x
    if center[1] < 0:
        half_y = -half_y
    dist = (center[0] + half_x)**2 + (center[1] + half_y)**2
    return dist
    

class WaferMapPanel(wx.Panel):
    def __init__(self,parent):
        wx.Panel.__init__(self,parent)
        self.initUI()
    
    def initUI(self):
        self.canvas = FloatCanvas.FloatCanvas(self, BackgroundColor = "Black")
        self.canvas.InitAll()
        
        self.draw_die()
        self.draw_wafer_objects()       
        
    def draw_wafer_objects(self):        
        
        self.wafer_outline = draw_wafer_outline()
        self.canvas.AddObject(self.wafer_outline)
        
        
        self.main_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.main_sizer.Add(self.canvas, 1, wx.EXPAND)
        
        self.SetSizer(self.main_sizer)
        
    def draw_die(self):
        # draw first die with 0,0 as center of the rectangle
        # Assuming 6500um x 6580um die size, i.e 6.5mmx 6.58mm
        self.reticles,reticle_size,grid_center = dummy_data(150)
        
        for ret in self.reticles:
            lower_left_coord = grid_to_rect_coord(ret[:2],reticle_size,grid_center)
            self.canvas.AddRectangle(lower_left_coord,reticle_size,LineWidth =1, FillColor = wx.YELLOW)       
        
    def _clear_canvas(self):
        self.canvas.ClearAll(ResetBB = False)
        
     
        
#This part of the code is replaced with an easier pygrid selectable table
"""        
# Create a Panel to select the die to be measured on the reticle        
class ReticlePanel(wx.Panel):
    # Pass on reticle information to the reticle panel
    # The reticle info includes all the information about the die
    def __init__(self,parent=None,reticle_info= None):
        wx.Panel.__init__(self,parent)
        self.reticle_info = reticle_info
        self.InitUI()
                
    def InitUI(self):
        self.canvas = FloatCanvas.FloatCanvas(self,BackgroundColor = "Black")
        self.canvas.InitAll()
        
        self.main_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.main_sizer.Add(self.canvas, 1, wx.EXPAND)
        
        self.SetSizer(self.main_sizer)
                
        self.draw_die()
        
    def draw_die(self):
        lower_left_locs = []
        init_text_y = self.reticle_info[0].get_die_y()/20.0
        count = 0
        text_loc_list = []
        # generate die text locations
        text_start = (0,0)
            
        for die in self.reticle_info:            
            if die.get_location()[1] == 1:
                curr_x = 0
                curr_y = -(die.get_location()[0]*die.get_die_y())
                die_size = (die.get_die_x()/float(10),die.get_die_y()/float(10))
                lower_left_locs.append((curr_x,curr_y))
                print "die x,y : %d,%d, rect_xy :%d,%d"%(curr_x,curr_y,die_size[0],die_size[1])
                self.canvas.AddRectangle((curr_x/float(10),curr_y/float(10)),die_size, LineColor = wx.YELLOW, LineWidth = 1)
                #self.canvas.AddText(die.get_name(),,Size = 5,Color = wx.YELLOW)
                count+=1                
            else:
                curr_x = curr_x+ die.get_die_x()
                curr_y = curr_y
                die_size = (die.get_die_x()/float(10),die.get_die_y()/float(10))
                lower_left_locs.append((curr_x,curr_y))
                print "die x,y : %d,%d, rect_xy :%d,%d"%(curr_x,curr_y,die_size[0],die_size[1])
                self.canvas.AddRectangle((curr_x/float(10),curr_y/float(10)),die_size,LineColor = wx.YELLOW,LineWidth = 1)
                #self.canvas.AddText(die.get_name(),(text_x,text_y),Size = 5,Color = wx.YELLOW)
                count+=1
                           
        
    def _clear_canvas(self):
        self.canvas.ClearAll(ResetBB = False)
        
"""
                

def draw_wafer_flat(rad, flat_length,major_flat):
    """ Draws a wafer flat for a given radius and flat length """
    if major_flat == 'N':
        x = flat_length/2    
        y = math.sqrt(rad**2 - x**2)
        flat = FloatCanvas.Line([(-x, y), (x, y)],
                            LineColor=wx.RED,
                            LineWidth=3,
                            )
    
    elif major_flat == 'S':
        x = flat_length/2
        y = -math.sqrt(rad**2 - x**2)
        flat = FloatCanvas.Line([(-x, y), (x, y)],
                            LineColor=wx.RED,
                            LineWidth=3,
                            )
    
    elif major_flat == 'E':
        y = flat_length/2
        x = math.sqrt(rad**2 - y**2)        
        flat = FloatCanvas.Line([(x, y), (x, -y)],
                            LineColor=wx.RED,
                            LineWidth=3,
                            )
    elif major_flat == 'W':
        y = flat_length/2
        x = math.sqrt(rad**2 - y**2)        
        flat = FloatCanvas.Line([(-x, y), (-x, -y)],
                            LineColor=wx.RED,
                            LineWidth=3,
                            )

    return flat, x, y        

def draw_wafer_outline(dia = 150, flat = 5, major_flat = 'N'):
    """
    Draws a wafer outline for a given radius, including any edge exclusion
    lines.

    Returns a FloatCanvas.Group object that can be added to any
    FloatCanvas.FloatCanvas instance.

    :dia:   Wafer diameter in mm
    :excl:  Wafer edge exclusion in mm. Defaults to None (no edge excl.)
    :flat:  Flat edge exclusion. Defaults to the same as excl.
    """
    
    # define the radius 
    rad = float(dia)/2.0
    
    # Create a circle with center at the center of the canvas
    w_outline = FloatCanvas.Circle((0,0),dia, LineColor = wx.YELLOW, LineWidth = 1)
    
    flat_size = FLAT_LENGTHS[dia]
    
    """
    x = flat_size/2
    y = -math.sqrt(rad**2 - x**2)
    """
    
    # Draw the wafer flat for the major flat orientation specified
    flat,x,y = draw_wafer_flat(rad, FLAT_LENGTHS[dia], major_flat)
    
    # Arc for major flat 'N'
    if major_flat == 'N':
        arc = FloatCanvas.Arc((-x,y),(x,y),(0,0), LineColor = wx.RED, LineWidth = 3)
    # Arc for major flat 'S'
    elif major_flat == 'S':
        arc = FloatCanvas.Arc((x,y),(-x,y),(0,0), LineColor = wx.RED, LineWidth = 3)
    # Arc for major flat 'E'
    elif major_flat == 'E':
        arc = FloatCanvas.Arc((x,y),(x,-y),(0,0), LineColor = wx.RED, LineWidth = 3)
    # Arc for major flat 'W'
    elif major_flat == 'W':
        arc = FloatCanvas.Arc((-x,-y),(-x,y),(0,0), LineColor = wx.RED, LineWidth = 3)
    
    group = FloatCanvas.Group([flat, arc])
    
    return group
    

   
