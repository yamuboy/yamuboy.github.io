"""
Create Custom data containers for different measurements to enable live plotting.
S Par data container - Takes in complex data with bias information. 
                       Plots the data on a pager plot. Each page corresponds to a bias point.
IP3 data container - 
DCIV data container -

"""
import numpy
import modeling.mct_files as mct
import math
import pylab as plb
from matplotlib.figure import Figure
from maplot.wxgui import WxPlotFrame,WxPlotPanel
import wx
import numpy as np 
import os
import smithplot


def plot_rectangular(x,y,x_label=None,y_label=None,title = None, show_legend = True, axis = 'tight',ax = None, *args,**kwargs):
    if ax is None:
        ax = plb.gca()
        
    my_plot = ax.plot(x,y,*args,**kwargs)
    
    if x_label is not None:
        ax.set_xlabel(x_label)
        
    if y_label is not None:
        ax.set_ylabel(y_label)
        
    if title is not None:
        ax.set_title(title)
        
    if show_legend:
        if 'label' in kwargs:
            ax.legend()
    
    if axis is not None:
        ax.autoscale(True, 'x', True)
        ax.autoscale(True, 'y', False)
        
    if plb.isinteractive():
        plb.draw()
        
    return my_plot
    
colorlist = ('#ff0000','#0000ff','#00ff00','#ff00ff')

    
    
class spar_figure(Figure):
    
    def __init__(self,*args,**kwargs):
        super(spar_figure,self).__init__(*args,**kwargs)
        self.__i = 0
        self.__data = []
        self.__num_pages = 0
        
    def add_data(self,d):
        # Get the spar data block
        self.__num_pages = len(d)
        for blk in d:
            t_dict = {}
            for v in ['flist','s11_mag','s11_ang','s21_mag','s21_ang','s12_mag','s12_ang','s22_mag','s22_ang']:
                t_dict[v] = []
            vgs,igs,vds,ids = blk.v1,blk.i1,blk.v2,blk.i2
            t_dict['bias'] = (vgs,igs,vds,ids)
            for s in blk.data_lines:
                t = s.strip('\n').split(' ')
                t_dict['flist'].append(float(t[0]))
                t_dict['s11_mag'].append(20*math.log10(float(t[1])))
                t_dict['s11_ang'].append(t[2])
                t_dict['s21_mag'].append(20*math.log10(float(t[3])))
                t_dict['s21_ang'].append(t[4])
                t_dict['s12_mag'].append(20*math.log10(float(t[5])))
                t_dict['s12_ang'].append(t[6])
                t_dict['s22_mag'].append(20*math.log10(float(t[7])))
                t_dict['s22_ang'].append(t[8])
            self.__data.append(t_dict)
        self._plot()
        
    def clear_data(self):
        self.__data = []
        
    def init_pages(self,figure):
        self._plot()
        
    def next_page(self,figure):
        i = self.__i + 1
        if i > self.__num_pages:
            raise NoMorePages()
        self.__i = i
        self._plot()
        
        
    def prev_page(self, figure):
        "draw the previous page"
        i = self.__i - 1
        if i < 0:
            raise NoMorePages()
        self.__i = i
        self._plot()
        
    def _plot(self):
        self.clf()
        lines, labels = [],[]
        ax = self.add_axes([0.1,0.1,0.8,0.7])
        if self.__i:
            d = self.__data[self.__i]
            title = 'Vgs :%f Igs: %f Vds:%f Ids:%f'%(d['bias'][0],d['bias'][1],d['bias'][2],d['bias'][3])
            s11 = ax.plot(d['flist'],d['s11_mag'],color = colorlist[0],label = 'S11 Mag')
            s21 = ax.plot(d['flist'],d['s21_mag'],color = colorlist[1],label = 'S21 Mag')
            s12 = ax.plot(d['flist'],d['s12_mag'],color = colorlist[2],label = 'S12 Mag')
            s22 = ax.plot(d['flist'],d['s22_mag'],color = colorlist[3],label = 'S22 Mag')                       
        
            ax.set_xlabel('Frequency (Hz)')
            ax.set_ylabel('Magnitude (dB)')
            ax.set_title(title)
            ax.legend()
                
class SparPlotMain(WxPlotFrame):
    "extension of the base plot frame with an updated menu bar"
    
    def __init__(self, *args, **kwargs):
        "initializer"
        
        # init parent
        super(SparPlotMain,self).__init__(*args,**kwargs)        
        
        # redefine the menubar
        menubar = wx.MenuBar()

        filemenu = wx.Menu()
        
        addmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Add File\tCtrl+A')
        filemenu.AppendItem(addmi)
        clrmi = wx.MenuItem(filemenu, wx.ID_ANY, '&Clear Files\tCtrl+D')
        filemenu.AppendItem(clrmi)
        filemenu.AppendSeparator()
        smi = wx.MenuItem(filemenu, wx.ID_ANY, '&Save Image\tCtrl+S')
        filemenu.AppendItem(smi)
        filemenu.AppendSeparator()
        qmi = wx.MenuItem(filemenu, wx.ID_EXIT, '&Quit\tCtrl+Q')
        filemenu.AppendItem(qmi)

        self.Bind(wx.EVT_MENU,self.save_figure,smi)
        self.Bind(wx.EVT_MENU,self.OnQuit,qmi)
        self.Bind(wx.EVT_MENU,self.add_dataset,addmi)
        self.Bind(wx.EVT_MENU,self.clear_datasets,clrmi)

        menubar.Append(filemenu, '&File')
        self.SetMenuBar(menubar)

                
                
        self.SetSize((800,600))
    
    def add_dataset(self, e):
        "add a dataset using a file browser"
        kw = {'style':wx.FD_OPEN,
            'wildcard':"All Files (*.*)|*.*",
            'defaultDir':os.getcwd(),
            }
        dlg = wx.FileDialog(None,'Add Smith Data',**kw)
        if dlg.ShowModal() == wx.ID_OK:
        
            fname = dlg.GetPath()
            try:
                s = smith_container()
                dset = s.read(fname)
                
            except Exception, e:
                self.error_msg('failed to read file: '+str(e))
                return 
            
            self.status_msg('loaded: '+fname)
            self.panel.figure.add_data(dset)            
            self.panel.figure.canvas.draw()
        else:
            self.status_msg('')
            return
        
    def clear_datasets(self, e):
        "clear datasets"
        self.panel.figure.clear_data()
        self.panel.figure.canvas.draw()
        
    def save_figure(self,e):
        pass 
        
    def OnQuit(self,evt):
        self.Close()
        


def mag_to_db(input):
    """
    Converts real and imaginary format data to dB
    Takes as its argument the abs value of complex data
    """
    return 20*numpy.log10(input)
    
def complex_to_db(complex):
    """
    converts a complex number to dB
    """
    return mag_to_db(numpy.abs(complex))
    
def complex_to_magnitude(input):
    return abs(input)
    
def complex_to_radians(input):
    return numpy.angle(input)
    
def complex_to_degrees(input):
    return numpy.angle(input, deg = True)
    
SPAR_TYPE_MAPPING = {
    're' : numpy.real,
    'im' : numpy.imag,
    'mag': numpy.abs,
    'db' : complex_to_db,
    'rad': numpy.angle,
    'deg': lambda x: numpy.angle(x, deg = True),
    'vswr': lambda x: (1+abs(x))/(1-abs(x)),
}
Y_LABEL_DICT = {
    're' : 'Real Part',
    'im' : 'Imaginary Part',
    'mag': 'Magnitude',
    'db' : 'Magnitude (dB)',
    'rad': 'Phase (rad)',
    'deg': 'Phase (degrees)',
    'vswr': 'VSWR',
}


class smith_container(object):
    def __init__(self,*args,**kwargs):
        """
        Smith Container that holds bias dependent or independent s-par info.
        Data is a list of dictionaries.
        Each dictionary has the following format {'vgs':xx,'vds':xx,'igs':xx,'ids':xx,'spars':[list of real and imag data]}        
        """
        self.data = []
        self.s_container = None
        
    def update_spars(self,data):
        # Add a new biased s-par point to the data
        self.data.append(data)
        
    def find_by_bias(self,vgs = None,vds = None):
        # Find data corresponding to a particular bias point, or something that's closest to it
        bias_list = []
        for blk in self.s_container:
            g,d = blk.v1, blk.v2
            bias_list.append((g,d))
            if (vgs,vds) == (g,d):
                found_exact = True
                data = blk.data_lines
            else:
                found_exact = False
        if found_exact ==  False:
            # Exact bias point not found, find nearest value
            def distance(b1,b2):
                return math.sqrt(abs(b1[0]-b2[0])**2+abs(b1[1]-b2[1])**2)
            nearest = min(bias_list, key =lambda x:distance(x,(vgs,vds)))
            for blk in self.s_container:
                if (blk.v1,blk.v2) == nearest:
                    data =  blk.data_lines            
        
    def plot(self,plot_type):
        if plot_type == 'smith':
            # Plot the data in smith chart format
            pass
        elif plot_type == 'db':
            # plot in mag format
            pass
        elif plot_type == 'mag_angle':
            # plot the data in mag angle format
            pass
            
    def plot_by_bias(self,vgs,vds,plot_type):
        pass         
        
    def write(self,fname):
        # Write the data to file, probably use Jay's network for this
        pass
           
    def read(self,fname):
        # use mct_files to read custom data 
        tmp = mct.MctDataFile(fname)
        self.s_container = tmp.get_blocks_by_section('sparams')
        if self.s_container == None:
            raise ValueError('File Does not contain S-paramters')
        return self.s_container
        
        
if __name__ == "__main__":
    app = wx.App(redirect=False) 
    frame_1 = SparPlotMain(spar_figure(),None) 
    app.SetTopWindow(frame_1) 
    frame_1.Show() 
    app.MainLoop() 
    
    
        
        
        
                
        
        
    
        