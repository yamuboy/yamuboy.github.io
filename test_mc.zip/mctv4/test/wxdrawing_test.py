"""
Stand alone wafer map utility.
Wafer map with better graphics
"""

import wx
import math
import numpy as np

MAP_UNITS  = 'MICRONS'

# lists the number of reticles on each row of the wafer
reticle_map = [6,8,8,10,10,10,10,10,10,8,8,6]

def def_mat(i,m):
    arr = np.repeat(0,(m-1)/2)
    np.concatenate([arr, np.repeat(1,i),arr])
    
    
class Example(wx.Frame):
    def __init__(self, parent, title):
        super(Example, self).__init__(parent, title=title, 
            size=(250, 150))            
                
            
        self.Centre()
        self.Show()
        
        dc = wx.ClientDC(self)
        dc.SetMapMode(wx.MM_METRIC)
        
        start_x = self._convert_p_mm(25)
        start_y = self._convert_p_mm(25)
        
        # standard width and height which doesn't change
        w = math.ceil(self._convert_micron_mm(10400))
        h = math.ceil(self._convert_micron_mm(7520))
        
        
        first_row = True
        first_column = True
        
        arr = np.array(reticle_map)
        N = arr.max()
        nr = np.arange(N)
        diffs = (N - arr)//2
        wafer_map = (((arr + diffs)[:,None] > nr) & (diffs[:,None] <= nr)).astype(int)
        
        start_x = math.ceil(self._convert_p_mm(25))
        start_y = math.ceil(self._convert_p_mm(25))
        
        origin_x = start_x
        origin_y = start_y
        
        first = True
        
        self.DrawLine(dc)           
        
        
    def DrawLine(self, dc):
                
        start_x = math.ceil(self._convert_p_mm(25))
        start_y = math.ceil(self._convert_p_mm(25))
        
        origin_x = start_x
        origin_y = start_y
        
        #print start_x,start_y
        # w and h stay the same throughout
        w = math.ceil(self._convert_micron_mm(10400))
        h = math.ceil(self._convert_micron_mm(7520))
        
        #print w,h
        dc.DrawLine(start_x,start_y, start_x+w, start_y)
        dc.DrawLine(start_x+w,start_y, start_x+w, start_y+h)
        dc.DrawLine(start_x,start_y,start_x, start_y+h)
        dc.DrawLine(start_x,start_y+h, start_x+w, start_y+h)
        
        # Draw a rectangle next to it
        start_x = start_x+w
        start_y = start_y
        
        dc.DrawLine(start_x,start_y, start_x+w, start_y)
        dc.DrawLine(start_x+w,start_y, start_x+w, start_y+h)
        dc.DrawLine(start_x,start_y,start_x, start_y+h)
        dc.DrawLine(start_x,start_y+h, start_x+w, start_y+h)        
        
        # Draw a rectangle below it
        start_x = origin_x
        start_y = origin_y + h
        
        dc.DrawLine(start_x,start_y, start_x+w, start_y)
        dc.DrawLine(start_x+w,start_y, start_x+w, start_y+h)
        dc.DrawLine(start_x,start_y,start_x, start_y+h)
        dc.DrawLine(start_x,start_y+h, start_x+w, start_y+h)    
        
        # draw a rectangle below it to the left
        start_x = origin_x - w
        start_y = origin_y + h
        
        dc.DrawLine(start_x,start_y, start_x+w, start_y)
        dc.DrawLine(start_x+w,start_y, start_x+w, start_y+h)
        dc.DrawLine(start_x,start_y,start_x, start_y+h)
        dc.DrawLine(start_x,start_y+h, start_x+w, start_y+h)   
        
    def draw_rectangle(self,dc,x,y,w,h):                        
        # Need this method because DrawRectangle doesn't work correctly
        dc.DrawLine(x,y, x+w, y)
        dc.DrawLine(x+w,y, x+w, y+h)
        dc.DrawLine(x,y,x, y+h)
        dc.DrawLine(x,y+h, x+w, y+h)       
        
        
    def _convert_p_mm(self, p):
        return p*0.265
        
    def _convert_mm_micron(self, mm):
        return mm*1000
        
    def _convert_micron_mm(self, um):
        return um/float(1000)
        
    def draw_circle(self,x,y,radius):
        dc.DrawCircle(x,y,radius)

        
    

if __name__ == '__main__':
    app = wx.App()
    Example(None, 'Line')
    app.MainLoop()