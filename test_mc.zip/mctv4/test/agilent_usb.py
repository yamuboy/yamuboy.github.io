import visa
from instrument import timed_wait_ms
tmp = visa.ResourceManager()

def ask_if_done(pm):
    while True:
        timed_wait_ms(200)
        if int(pm.ask("*ESR?")) == 0:
            break 
            

def measure():
    t = tmp.list_resources()[0]
    pm = tmp.open_resource(t)
    
    pm.write("*RST;*CLS")
        
    pm.write("INIT1:CONT OFF")
    
    pm.write("*CLS")
    pm.write("*ESE 1;:INIT1:IMM;*OPC")
    ask_if_done(pm)    
    pm.ask("FETC1?")
    
             
if __name__ == "__main__":
    measure()
    