
import wx
import wx.wizard as wiz
from wxtestgui.worker import Worker,send_to_ui,EVT_WORKER_MESSAGE, EVT_WORKER_EXITING


class TitledPage(wiz.WizardPageSimple):
    
    #----------------------------------------------------------------------
    def __init__(self, parent, title,docstr,run_func):
        """Constructor"""
        wiz.WizardPageSimple.__init__(self, parent)
        
        self.run_func = run_func
 
        sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer = sizer
        self.SetSizer(sizer)
        
        # Place step information in multiline text
        step_desc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,value = docstr)
        
        self.status = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,value = "")
               
        title = wx.StaticText(self, -1, title)
        title.SetFont(wx.Font(18, wx.SWISS, wx.NORMAL, wx.BOLD))
        sizer.Add(title, 0, wx.ALIGN_CENTRE|wx.ALL, 5)
        sizer.Add(wx.StaticLine(self, -1), 0, wx.EXPAND|wx.ALL, 5)
        sizer.Add(step_desc,0,wx.EXPAND|wx.ALL, 5)
        sizer.Add(self.status,0,wx.EXPAND|wx.ALL, 5)        
    

class cal_main(wx.wizard.Wizard):
    # Main entry point for cal wizard
    def __init__(self,parent,title,cal_dict):
        # Use default bitmap for now
        super(cal_main,self).__init__(parent,-1,title,wx.NullBitmap)
        # Keep track of pages being used
        self.pages = []
        self.parent = parent
        self.cal_dict = cal_dict
        self.current_page = None
                        
        self.Bind(wx.wizard.EVT_WIZARD_PAGE_CHANGED,self.OnPageChanged)
        self.Bind(wx.wizard.EVT_PAGE_CHANGING,self.OnPageChanging)
        self.Bind(wx.wizard.EVT_WIZARD_CANCEL, self.OnCancel)
        self.Bind(wx.wizard.EVT_WIZARD_FINISHED, self.OnFinished)
        
        self.Bind(EVT_WORKER_MESSAGE,self.OnCalUpdate)
        
        self.next_button = self.FindWindowById(wx.ID_FORWARD)
        
        # cal data 
        self.cal_data = []
        
        self.init()
        
    def init(self):    
                
        self.add_pages(self.cal_dict)
        self.FitToPage(self.pages[0])                
        self.GetPageAreaSizer().Add(self.pages[0])
        self.RunWizard(self.pages[0])
        self.Destroy()
        
    def add_pages(self,cal_dict):
        for i,k in enumerate(cal_dict.iterkeys()):
            page = TitledPage(self,k,cal_dict[k].__doc__,cal_dict[k])
            self.pages.append(page)
            
        for i in range(len(self.pages)):
            if i != len(self.pages)-1:
                self.pages[i].SetNext(self.pages[i+1])
                
    def OnPageChanged(self,evt):
        # Run the function
        self.current_page = self.GetCurrentPage()
        self.next_button.Disable()
        
    def OnPageChanging(self,evt):
        
        self.new_worker = Worker(self,target = self.current_page.run_func)
        self.new_worker.start()
        
        
    def OnCancel(self,evt):
        self.parent.cal_completed = False
        
    def OnFinished(self,evt):
        self.parent.cal_completed = True        
        
    def OnCalUpdate(self,evt):
        
        self.current_page.status.SetValue(evt.msgtype)
        if evt.payload:
            self.cal_data.append[evt.payload]             
                        
    @property    
    def first_page(self):
        if len(self.pages):
            return self.pages[0]
            
    @property
    def last_page(self):
        return self.pages[-1]

    def current_page(self):
        return self.GetCurrentPage() 
     
