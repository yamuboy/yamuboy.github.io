"""
IP3 Software
"""

import wx, os, sys
from wxtestgui import ValidationError, TestParameters, Instr
from wxtestgui.edit_params import EditTestParamsDialog, EditNumberListDialog, EditOrderedListDialog
from wxtestgui.edit_instruments import InstrumentConfigDialog
from wxtestgui.worker import Worker, EVT_WORKER_MESSAGE, EVT_WORKER_EXITING
import logging
from routines.fet import ip3_full_module, ip3_test_module

logger = logging.getLogger(__name__)

class WxTextCtrlHandler(logging.Handler):
    def __init__(self, ctrl):
        logging.Handler.__init__(self)
        self.ctrl = ctrl

    def emit(self, record):
        s = self.format(record) + '\n'
        wx.CallAfter(self.ctrl.WriteText, s) 
        
        
def instrument_loader( instr_list, required = [], optional = [] ):
    "load instruments in a safe manner"
    intr = list(set(required).intersection(optional))
    
    if len(intr):
        raise ValueError("duplicate instrument names exist in `required` and `optional`: %s"%(', '.join(intr)))
    
    out = {}
    tmp = {}
    for instr in instr_list:
        tmp[instr.name] = instr 
                
    try:
        for name in required:
            if name not in tmp:
                raise ValueError("no definition for instrument '%s'"%name)
                
            try:
                out[name] = tmp[name].open_instrument()
                if out[name] is None:
                    raise ValueError('not configured')
            except Exception as e:
                 raise InstrumentLoadError("could not load required instrument '%s' -> %s"%(tmp[name].label,e))
        
        for name in optional:
            if name not in tmp:
                out[name] = None
            else:
                try:
                    out[name] = tmp[name].open_instrument()
                except Exception:
                    # optional instruments do not need to be loaded successfully
                    out[name] = None
    except Exception:
        # unload instruments when exceptions occur during loading
        instrument_unloader(out)
        raise
    
    return out

    
def instrument_unloader( instr ):
    "unload all open instruments"
    for i in instr_dict.values():
        if i:
            try:
                i.close()
            except Exception as e:
                logger.warning("error unloading instrument '%s' -> %s"%(i.name,e))
                
                



class IP3Main(wx.Frame):
    
    def __init__(self, *args, **kwargs):
        
        super(IP3Main, self).__init__(*args, **kwargs)
        
        self.Bind(EVT_WORKER_MESSAGE, self.OnWorkerUpdate)
        self.Bind(EVT_WORKER_EXITING, self.OnTestComplete)
        
        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow)
        
        #set_main_window(self)
        
        menubar = wx.MenuBar()
        
        self.SetupPanel = wx.Panel(self)
        
        self.controls = {}
        
        self.mode = "debug"
        
        if self.mode == "debug":
            self.instrs = ip3_test_module.INSTR_LIST
            self.params = ip3_test_module.TEST_PARAMS
        else:
            self.instrs = ip3_full_module.INSTR_LIST
            self.params = ip3_full_module.TEST_PARAMS
            
            
        self.test_params = TestParameters(self.params)
        
        
        #File Menu
        file_menu  = wx.Menu()
        file1 = file_menu.Append(wx.ID_OPEN,"Load Setup...")
        file2 = file_menu.Append(wx.ID_SAVE,"Save Setup...")
        file_menu.AppendSeparator()
        file4 = file_menu.Append(wx.ID_EXIT,"Exit", "Exit")
        
        #File Menu Action Handlers
        self.Bind(wx.EVT_MENU,self.OnLoadSetup,file1)
        self.Bind(wx.EVT_MENU,self.OnSaveSetup,file2)
        self.Bind(wx.EVT_MENU,self.OnExit,file4)
        
        # Cal menu items
        cal_menu = wx.Menu()
        self.save_cal = cal_menu.Append(wx.ID_ANY, "Save Cal...")
        self.recall_cal = cal_menu.Append(wx.ID_ANY,"Recall Cal...")
        self.clear_cal = cal_menu.Append(wx.ID_ANY,"Clear Cal...")
        self.Bind(wx.EVT_MENU,self.OnSaveCal, self.save_cal)
        self.Bind(wx.EVT_MENU,self.OnRecallCal, self.recall_cal)
        self.Bind(wx.EVT_MENU,self.OnClearCal, self.clear_cal)
        
        #Add Menus to Menubar
        menubar.Append(file_menu,"File")
        menubar.Append(cal_menu,"Cal")
        self.SetMenuBar(menubar)
        
        
        # Box to display the test module's docstring
        test_info_box = wx.StaticBox(self.SetupPanel, label = "Test Module Information")
        test_info_box_sizer = wx.StaticBoxSizer(test_info_box, wx.HORIZONTAL)
        self.controls['test_info'] = wx.TextCtrl(self.SetupPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        test_info_box_sizer.Add(self.controls['test_info'],1,wx.EXPAND,5)
        if self.mode == "debug":
            self.controls['test_info'].SetValue(ip3_test_module.__doc__.strip(" "))
        else:
            self.controls['test_info'].SetValue(ip3_full_module.__doc__.strip(" "))        
                                
        # Test Control buttons
        setup_box = wx.StaticBox(self.SetupPanel, label = "Setup Menu")
        setup_sizer = wx.StaticBoxSizer(setup_box,wx.VERTICAL)
        self.controls['instrument_setup'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Instruments")
        
        # Bind buttons to event handlers
        self.Bind(wx.EVT_BUTTON,self.OnInstrumentSetup,self.controls['instrument_setup'])
        
        setup_sizer.Add(self.controls['instrument_setup'],1, wx.CENTER,5)
        
        # Test Parameter buttons
        test_box = wx.StaticBox(self.SetupPanel, label = "Test Menu")
        test_sizer = wx.StaticBoxSizer(test_box, wx.VERTICAL )
        self.controls['edit_params'] = wx.Button(self.SetupPanel, wx.ID_ANY,"Edit Parameters")
        self.Bind(wx.EVT_BUTTON, self.OnEditParams, self.controls['edit_params'])
        self.controls['calibrate'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Calibrate")
        self.Bind(wx.EVT_BUTTON, self.OnCalibrate, self.controls['calibrate'])
        
        # Sizer for the Test parameters and calibrate options
        test_sizer.Add(self.controls['edit_params'],1, wx.CENTER,5)
        test_sizer.Add(self.controls['calibrate'],1, wx.CENTER,5)
        
        # Buttons for the run/abort buttons
        run_box = wx.StaticBox(self.SetupPanel, label = "Test Controller")
        run_sizer = wx.StaticBoxSizer(run_box, wx.VERTICAL)
        self.controls['run'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Run")
        self.Bind(wx.EVT_BUTTON,self.OnRunTest, self.controls['run'])
        self.controls['abort'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Abort")
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.controls['abort'])
        
        # Add run and abort to the sizer
        run_sizer.Add(self.controls['run'],1,wx.CENTER, 5)
        run_sizer.Add(self.controls['abort'],1,wx.CENTER, 5)
        
        # Set some colors for the run and abort button
        self.controls['run'].SetBackgroundColour(wx.GREEN)
        self.controls['abort'].SetBackgroundColour(wx.RED)
        
        # Text control for the logging utility
        logging_info_box = wx.StaticBox(self.SetupPanel, label = "Test Logger")
        logging_box_sizer = wx.StaticBoxSizer(logging_info_box, wx.HORIZONTAL)
        self.controls['test_logger'] = wx.TextCtrl(self.SetupPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        logging_box_sizer.Add(self.controls['test_logger'],1,wx.EXPAND,5)   
        handler = WxTextCtrlHandler(self.controls['test_logger'])
        logger.addHandler(handler)
        FORMAT = "%(asctime)s %(levelname)s %(message)s"
        handler.setFormatter(logging.Formatter(FORMAT))
        logger.setLevel(logging.DEBUG)
        
        main_button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        main_button_sizer.Add(setup_sizer, 1, wx.LEFT, 5)
        main_button_sizer.Add(test_sizer, 1, wx.CENTER, 5)
        main_button_sizer.Add(run_sizer, 1, wx.RIGHT, 5)
        
        setup_main_sizer = wx.BoxSizer(wx.VERTICAL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(test_info_box_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(main_button_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(logging_box_sizer,0,wx.EXPAND|wx.TOP)
        
        self.SetupPanel.SetSizer(setup_main_sizer)
        
        self.SetTitle("MTACS")
        
        self.SetSize((800,500))
        
        self.cal_done = False
        
        
    def OnInstrumentSetup(self,evt):
        # Bring up a dialog to set up the instruments
        dlg = InstrumentConfigDialog(self.instrs,parent = self)
        if dlg.ShowModal() == wx.ID_OK:
            self.test_instrs = {}
            for instr in self.instrs:
                self.test_instrs[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)
            logger.log(logging.INFO,"Instrument Information Entered")
            dlg.Destroy()
            
        print self.test_instrs
        
    def OnEditParams(self,evt):
        dlg = EditTestParamsDialog(self.test_params.get_dialog_list(),None,style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        if dlg.ShowModal() == wx.ID_OK:
            # Get the values of the changed parameters
            self.test_params = TestParameters(self.params)
            logger.log(logging.INFO, "Parameters Edited")
            dlg.Destroy()
        
    def OnCloseWindow(self,evt):
        self.Destroy()
        
    def OnAbort(self,evt):
        if self.new_worker:
            self.new_worker.comm.send_to_worker(msgtype = "Abort")
            
    def _input_cal(self):
        dlg = wx.MessageDialog(self,"Input Cal: Lift the Probes and disconnet the cable to the input probe \n Attach the power sensor A to the input coupler with all the necessary pads\n Attach power meter B in place of the DUT with no pads\n Press OK to continue","Cal",wx.OK)
        if dlg.ShowModal() == wx.ID_OK:            
            # disable all the buttons except for the Abort button
            for b in ['instrument_setup', 'edit_params', 'calibrate', 'run']:
                self.controls[b].Disable()  
                
            self.new_worker = Worker(self, target = ip3_test_module.input_cal, args = [self.test_params, self.cal_data, self.test_instrs])
            self.new_worker.start()            
        
    def _output_cal(self):
        dlg = wx.MessageDialog(self, "Output cal: Reconnect Power Meter B, Connect a Thru in place of the DUT", "Cal",wx.OK)
        if dlg.ShowModal() == wx.ID_OK:
            # Perform the output cal step     
            self.new_worker = Worker(self, target = ip3_test_module.output_cal, args = [self.test_params, self.cal_data, self.test_instrs])
            self.new_worker.start() 
            
        
    def OnCalibrate(self,evt):
        # check if cal data exists, if it does ask the user if fresh cal needed
        if self.cal_done:
            dlg = wx.MessageDialog(self, "Delete existing Cal and Continue?", "Warning",wx.YES_NO, wx.ICON_QUESTION)
            if dlg.ShowModal() == wx.ID_YES:
                self.cal_data = {}
                dlg.Destroy()
                self._run_cal()
            else:
                dlg.Destroy()
        else:
            self.cal_data = {}
            self._run_cal()
        
        # cal data only exists in main
        # the routine just executes the cal and returns the data        
        
    def _run_cal(self):
        if self.mode == "debug":
            self._input_cal()                                              
        else:
            if not(instruments_loaded):
                inst_dict = instrument_loader(self.test_instrs)
            self.new_worker = Worker(self,target = ip3_full_module.input_cal, args = [self.test_params, self.cal_data, self.test_instrs])
            self.new_worker.start()            
         
        
    def OnClearCal(self, evt):
        self.cal_data = {}
        self.cal_done = False

    def OnRunTest(self,evt):
        pass
        
    def OnWorkerUpdate(self,evt):
        if evt.msgtype == "cal_abort":
            wx.MessageBox(self, "Cal Aborted! User Must Re-Cal before Running the Test", wx.OK)
            if dialog.ShowModal() == wx.ID_OK:
                self.cal_data = {}
                self.cal_complete = False
        if evt.msgtype == "update":
            logger.log(logging.INFO, evt.payload)
        if evt.msgtype == "input_cal_done":
            logger.log(logging.INFO, "Input Cal Done")
            self.cal_data = evt.payload
            self.new_worker.join()
            self._output_cal()
        if evt.msgtype == "output_cal_done":
            logger.log(logging.INFO, "output cal done")
            self.cal_data = evt.payload
            self.new_worker.join()
            self.cal_done = True                
               
    def OnTestComplete(self, evt):
        pass
        
    def OnLoadSetup(self,evt):
        pass 
        
    def OnSaveSetup(self, evt):
        pass

    def OnExit(self, evt):
        self.Destroy()
        
    def OnSaveCal(self,evt):        
        pass
        
    def OnRecallCal(self, evt):
        # Get the saved cal parameters from the cal file
        pass 
        
        

        
if __name__ == "__main__": 
    app = wx.App(redirect=False) 
    frame_1 = IP3Main(None, -1) 
    app.SetTopWindow(frame_1) 
    frame_1.Show() 
    app.MainLoop()
        
        
        
        
        
        
            
    