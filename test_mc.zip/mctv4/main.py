

import wx



class mctMain(wx.Frame):
    """Main application window."""
    
    def __init__(self, *args, **kwargs):
        """Create the main windows."""
        wx.Frame.__init__(self, *args, **kwargs)
        
        ### create the menu bar and menus ###
        
        menubar = wx.MenuBar()
        
        filemenu = wx.Menu()
        item = filemenu.Append(wx.ID_EXIT, text="&Quit")
        self.Bind(wx.EVT_MENU, self.OnQuit, item)
        
        menubar.Append(filemenu, "&File")
        
        self.SetMenuBar(menubar)
        
        ### create the content of the main window ###
        self.Panel = mctMainPanel(self)
        
        ### create a status area at the bottom of the main page ###
        self.StatusBar = self.CreateStatusBar()
        
        self.Show()
        
    def OnQuit(self, event=None):
        """OnQuit event handler."""
        
        # TODO: throw up a dialog asking for confirmation
        
        self.Close()





class mctMainPanel(wx.Panel):
    """The main panel in the main application window."""
    
    def __init__(self, parent, *args, **kwargs):
        """Create the main panel."""
        wx.Panel.__init__(self, parent, *args, **kwargs)
        
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        txt1 = wx.StaticText(self, wx.ID_ANY, "Some text to display.")
        
        
        
        vbox.Add(txt1)
        
        
        
        # log area at the bottom
        
        
        self.SetSizer(vbox)
        
if __name__ == '__main__':
    app = wx.App(False)
    mctMain(None, title='New MCT', size=(250,200))
    app.MainLoop()
    
    
    