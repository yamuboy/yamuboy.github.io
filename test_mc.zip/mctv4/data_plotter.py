"""
This is a universal data plotter. 
It plots files of the following kind:
1. GaN downpoint files 
2. MCT DC files
3. MCT S-params file
4. MCT DC&S files
5. Noise params file
6. Pin-Pout files
"""

import modeling.mct_files as mct
import smithplot
from matplotlib import pyplot as pp
import wx
from mtacs_file_reader import MctDataFile
    

class help_dialog(wx.Dialog):
    def __init__(self, parent):
        super(help_dialog,self).__init__(parent)
        
        self.init()
        
    def init(self):
        pass 
        

def main_plotting_frame(wx.Frame):
    def __init__(self,*args,**kwargs):
        super(main_plotting_frame,self).__init__(*args,**kwargs)
        
        menubar = wx.MenuBar()
        
        file = wx.Menu()
        options = wx.Menu()
        help = wx.Menu()
        
        file1 = file.Append(wx.ID_ANY, "Add Datasets")
        file2 = file.Append(wx.ID_ANY, "Edit Datasets")
        file.AppendSeparator()
        file3 = file.Append(wx.ID_ANY, "Quit")
        
        self.Bind(wx.EVT_MENU, self.OnAddDataset, file1)
        self.Bind(wx.EVT_MENU, self.OnEditDataset, file2)
        self.Bind(wx.EVT_MENU, self.OnQuit, file3)
        
        option1 = options.Append(wx.ID_ANY, "Plot Options")
        self.Bind(wx.EVT_MENU, self.OnPlotOptions, option1)
        
        
        
    def OnAddDataset(self, evt):
        pass
        
    def OnEditDataset(self, evt):
        pass
        
    def OnQuit(self, evt):
        self.Close()
        
    
        
        
        
        
        
    


if __name__ == "__main__":
    main()
    
