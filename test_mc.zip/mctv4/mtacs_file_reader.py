import re, sys, os, os.path
import traceback
from StringIO import StringIO
from network_params import write_s2pmdif_block, Touchstone, DeembeddingUtil

number_re = re.compile(r'\s*(?:[+-]?[0-9]*\.?[0-9]+(?:e[+-]?[0-9]+)?|nan|[+-]?inf)\b',re.I)
bias_re = re.compile(r'\!\**BIAS:\s')
    
class MctDataBlock(object):
    "single data block in an MCT data file"
    
    def __init__(self, section):
        "initializer"
        
        self.data_lines = []
        self.__headers = []
        self.section = section
        self.__site = (-1,-1)
        self.__bias = {'v1':0.0, 'v2':0.0, 'i1':0.0, 'i2':0.0, 'valid':False}
    
    @property
    def data_type(self):
        "get the data type stored by this block"
        if not self.data_lines:
            return "unknown"
        
        n = len(self.data_lines[0].split())
        if n == 4:
            return 'dc'
        elif n == 3:
            return 'noise'
        elif n == 9:
            return 'sparams'
        else:
            return 'unknown'
    
    @property
    def isempty(self):
        "check to see if the block is empty"
        return not self.data_lines
    
    def process_header(self, line):
        "add headers to the block, ignoring those that should be ignored"
        if bias_re.match(line):
            try:
                x = line.split()
                bias = {}
                bias['v1'], bias['v2'] = float(x[11]), float(x[3])
                bias['i1'], bias['i2'] = float(x[15]), float(x[7])
                bias['valid'] = True
                self.__bias = bias
            except Exception:
                pass
            
            if line.startswith('!*'):
                # for !**BIAS lines, force creation of a new block
                self.__headers.append(line)
                raise NewBlock(discard=True)
                
        elif line.strip() == '!':
            return
        elif line.startswith('#'):
            return
        
        self.__headers.append(line)
        
    @property    
    def format_line(self):
        "get the format line"
        if self.data_type == 'sparams':
            return '# HZ S MA R 50'
        else:
            return ''
    
    @property
    def bias_line(self):
        "return the bias line"
        for h in self.__headers:
            if bias_re.match(h):
                return h
        return ''
    
    @property
    def headers(self):
        "get the block headers"
        return self.__headers[:]
    
    @property
    def v1(self):
        "port 1 voltage"
        return self.__bias['v1']

    @property
    def v2(self):
        "port 2 voltage"
        return self.__bias['v2']

    @property
    def i1(self):
        "port 1 current"
        return self.__bias['i1']
        
    @property
    def i2(self):
        "port 2 current"
        return self.__bias['i2']
    
    @property
    def bias_is_valid(self):
        "flag for a valid set of bias data"
        return self.__bias['valid']
    
    @property
    def site(self):
        "site ID (DC data files)"
        return self.__site
        
    
class NewBlock(Exception):
    "force creation of a new block"
    def __init__(self, *args, **kwargs):
        "initializer"
        self.discard = bool(kwargs.pop('discard',False))
        Exception.__init__(self,*args,**kwargs)
    
class DiscardLine(Exception):
    "discard the current parser line"
    pass
    
    
class MctDataFile(object):
    """Read a data file created by the test lab software MCT and
    parse it into data blocks
    """
    
    def __init__(self, fname=None):
        "initializer"
        if fname is not None:
            self.parse(fname)
        else:
            self._initvars()
            
    def _initvars(self):
        "initialize internal variables"
        self.__section = ''
        self.__blocklist = []
        self.__headers = []
        self.__filename = ''
        self.__type = 'generic'
    
    def parse(self, fname):
        "parse an MCT data file into blocks"
        # initialize for parsing
        self._initvars()
        
        # start reading the file
        ac = False
        if hasattr(fname,'readline') and hasattr(fname.readline,'__call__'):
            fp = fname
            if hasattr(fp,'filename'):
                self.__filename = fp.filename
            else:
                self.__filename = '<stream>'
        else:
            fp = open(fname,'r')
            self.__filename = fname
            ac = True
        
        try:
            # read header lines, detect file type, and get pattern lists
            pattern_list, line = self._detect_and_read_header(fp)
            
            if not line:
                line = fp.readline()
                
            cur_block = None
            while line:
                #### try to find pattern matches ####
                if number_re.match(line):
                    # this is a data-containing line, add it to the current block
                    if not cur_block:
                        # current block does not exist, need to create it
                        cur_block = self._newblock()
                    cur_block.data_lines.append(line)
                        
                else:
                    # not a data line, close the current block if it
                    # contains data lines
                    if cur_block and cur_block.data_lines:
                        cur_block = None
                    
                    # try to match non-data lines
                    try:
                        matched = False
                        for p in pattern_list:
                            m = p[0].match(line)
                            if m:
                                matched = True
                                if hasattr(p[1],'__call__'):
                                    p[1](m,cur_block,line,**p[2])
                                else:
                                    raise DiscardLine()
                                break
                                                    
                        # add the line to the block header
                        if not cur_block:
                            # need to create a new block
                            cur_block = self._newblock()
                        cur_block.process_header(line)
                    
                    except DiscardLine:
                        pass
                    except NewBlock, e:
                        # create a new data block
                        cur_block = self._newblock()
                        if not e.discard:
                            cur_block.process_header(line)
                                    
                line = fp.readline()
                
        finally:
            # parsing done, close file if necessary
            if ac:
                fp.close()
            
        
    def _detect_and_read_header(self, fp):
        "detect the file type and read the header"
        # base patterns that can be used by all file types
        patterns = None
        base_patterns = [
            (re.compile(r'\!\s+S-PARAMETERS'),None,{}),
        ]
        
        # read the header and determine the file type
        header = []
        patterns = []
        line = fp.readline()
        while line:            
            if not line.startswith('!'):
                break
            elif line.startswith('!biased_s'):
                self.__type = 'biased_s'
            elif line.startswith('!gan_downpoint'):
                self.__type = 'downpoint'
                patterns = [
                    (re.compile),
                    (re.compile)
                ]
            elif line.startswith('!noise'):
                self.__type = 'noise'
            elif line.find('DC FET PARAMETERS') > -1:
                self.__type = 'fet'
                patterns = [
                    (re.compile(r'\!\s+BREAKDOWN IV-CURVES'),self._set_section,{'section':'breakdown'}),
                    (re.compile(r'\!\s+FORWARD IV-CURVES'),self._set_section,{'section':'fwdiv'}),
                    (re.compile(r'\!\s+DC IV-CURVES'),self._set_section,{'section':'dciv'}),
                    (re.compile(r'\!\s+COLD FET'),self._set_section,{'section':'coldfet','multiblock':True}),
                    (re.compile(r'\!\s+FET S-PARAM'),self._set_section,{'section':'sparams','multiblock':True}),
                ]+base_patterns
                header.append(line)
                header.append(fp.readline())
                header.append('!'+fp.readline())
                line = None
                break
            elif line.find('DC BJT PARAMETERS') > -1:
                self.__type = 'bjt'
                patterns = [
                    (re.compile(r'\!\s+FORWARD GUM'),self._set_section,{'section':'fwdgum'}),
                    (re.compile(r'\!\s+REVERSE GUM'),self._set_section,{'section':'revgum'}),
                    (re.compile(r'\!\s+RE FLYBACK'),self._set_section,{'section':'flyback'}),
                    (re.compile(r'\!\s+DC IV-CURVES'),self._set_section,{'section':'dciv'}),
                    (re.compile(r'\!\s+COLD BJT'),self._set_section,{'section':'hotbjt','multiblock':True}),
                    (re.compile(r'\!\s+CBC BJT'),self._set_section,{'section':'cbc','multiblock':True}),
                    (re.compile(r'\!\s+CBE BJT'),self._set_section,{'section':'cbe','multiblock':True}),
                    (re.compile(r'\!\s+BJT S-PARAM'),self._set_section,{'section':'sparams','multiblock':True}),
                ]+base_patterns
                header.append(line)
                header.append(fp.readline())
                header.append('!'+fp.readline())
                line = None
                break
            elif line.startswith('!BIAS:') or line.find('S-PARAMETERS') > -1 or line.find('S11-Mag') > -1:
                break        
            elif line.startswith('!SITE:'):
                self.__type = 'dc'
                break
            
            header.append(line)
            line = fp.readline()
            
        header.append('!\n')
        
        self.__headers = header
        
        if not patterns:
            # use a set of generic patterns
            patterns = base_patterns
        
        return patterns, line
        
    def _newblock(self):
        "create a new data block based on the current state of the parser"
        b = MctDataBlock(self.__section)
        self.__blocklist.append(b)
        return b
    
    def _set_section(self, match, block, line, **kwargs):
        "set the file section"
        if 'section' not in kwargs:
            raise KeyError("the `section` keyword is required")
        self.__section = kwargs['section']
        
        # force a new block to be created
        raise NewBlock(discard=kwargs.get('multiblock',False))
    
    def blocks(self):
        "return the list of blocks"
        return self.__blocklist[:]
    
    def get_blocks_by_section(self, section):
        "get a list of blocks by section name"
        r = []
        for b in self.__blocklist:
            if b.section == section:
                r.append(b)
        return r
        
    def get_blocks_by_datatype(self, ty):
        "get a list of blocks by datatype"
        r = []
        for b in self.__blocklist:
            if b.data_type == ty:
                r.append(b)        
        return r
    
    @property
    def filename(self):
        "the name of the parsed MCT data file"
        return self.__filename
    
    @property
    def type(self):
        "the type of the parsed MCT data file"
        return self.__type
    
    @property
    def headers(self):
        "MCT data file headers"
        return self.__headers[:]
    
        
class FilenameGenerator(object):
    """generate filenames for MCT data files when splitting them"""

    def __init__(self, mctfile, **kwargs):
        "initializer"
        if not isinstance(mctfile,MctDataFile):
            raise TypeError("argument 1 must be an `MctDataFile` object")
        self._f = mctfile
        self._n = 1
        self._a = kwargs
        self._sf = None

    def __call__(self, block):
        "generate data file names when splitting files"
    
        if self._f.type == 'fet':
            secname = {'dciv':'dc','fwdiv':'fwd','breakdown':'vbr'}.get(block.section,None)
            if secname:
                # FWDIV, breakdown, and DCIV file names
                return self._a.get('sp_prefix','s')+secname+self._a.get('iv_suffix','.iv')
            else:
                spp = self._a.get('sp_prefix','s')
                sps = self._a.get('sp_suffix','.raw')
                if block.section == 'coldfet':                    
                    return spp+'000c'+('%03d'%int(round(10000.0*block.i1*self.sf)))+sps
                elif block.section == 'sparams':
                    return spp+self._vgvd_bias(block)+sps
                else:
                    # don't know which section, maybe noise data - use the datatype to decide
                    if block.data_type == 'noise':
                        return self._a.get('noi_prefix','s')+self._vgvd_bias(block)+self._a.get('noi_suffix','.nfig')
                    elif block.data_type == 'sparams':
                        return spp+self._vgvd_bias(block)+sps
                    else:
                        # create a generalized name
                        return self._generalized_name()
        
        elif self._f.type == 'bjt':
            secname = {'fwdgum':'fwdgummel','revgum':'revgummel','flyback':'flyback','dciv':'dccurves'}.get(block.section,None)
            if secname:
                # Gummel, flyback, and DC-IV 
                return secname+self._a.get('iv_suffix','.iv')
            else:
                spp = self._a.get('sp_prefix','s')
                sps = self._a.get('sp_suffix','.raw')            
                if block.section == 'hotbjt':
                    return spp+'000h'+('%03d'%int(round(1000.0*abs(block.i1)*self.sf)))+sps
                elif block.section == 'cbc':
                    v = block.v1 - block.v2
                    return spp+'cbc'+('%03d'%int(round(100.0*abs(v))))+sps
                elif block.section == 'cbe':
                    v = block.v1
                    return spp+'cbc'+('%03d'%int(round(100.0*abs(v))))+sps
                elif block.section == 'sparams':
                    return spp+self._icvc_bias(block)+sps
                else:
                    # don't know which section, maybe noise data - use the datatype to decide
                    if block.data_type == 'noise':
                        return self._a.get('noi_prefix','s')+self._icvc_bias(block)+self._a.get('noi_suffix','.nfig')
                    elif block.data_type == 'sparams':
                        return spp+self._icvc_bias(block)+sps
                    else:
                        # create a generalized name
                        return self._generalized_name()
        
        elif self._f.type == 'dc':
            return self._generalized_name()
        
        else:
            # generic files
            if block.data_type in ('noise','sparams'):
                if block.data_type == 'noise':
                    pre = self._a.get('noi_prefix','s')
                    suf = self._a.get('noi_suffix','.nfig')
                else:
                    pre = self._a.get('sp_prefix','s')
                    suf = self._a.get('sp_suffix','.raw')
            
                if self._a.get('use_ids',False):
                    # name files using I2/V2 (Ids/Vds) instead of V1/V2
                    return pre+('%03d'%int(round(10.0*abs(block.v2))))+'c'+('%03d'%int(round(1000.0*abs(block.i2))))+suf
                else:
                    return pre+self._vgvd_bias(block)+suf
            else:
                return self._generalized_name()
                
    @property
    def sf(self):
        "get the scaling factor for FET or BJT files"
        if self._sf is None:
            if self._f.type == 'fet':
                periph = 1000.0
                for line in self._f.headers:
                    if line.startswith('!GATE PERIPH'):
                        periph = float(line.split()[-1])
                        break
                self._sf = 1000.0 / periph
            
            elif self._f.type == 'bjt':
                area = 1000.0
                for d in state['header']:
                    if d.startswith('!EMITTER AREA'):
                        area = float(d.split()[-1])
                        break
                self._sf = 1000.0 / area
            
            else:
                self._sf = 1.0
        
        return self._sf
        
    def _vgvd_bias(self, block):
        "generate the portion of a filename used for Vg/Vd naming for FETs"
        s = 'p'
        if block.v1 < 0.0: s = 'm' 
        return ('%03d'%int(round(10.0*abs(block.v2))))+s+('%03d'%int(round(100.0*abs(block.v1))))   
        
    def _icvc_bias(self, block):
        "generate the portion of a filename used for Ic/Vc naming for BJTs"
        return ('%03d'%int(round(10.0*abs(block.v2))))+'c'+('%03d'%int(round(1000.0*abs(block.i2)*self.sf)))
        
    def _generalized_name(self):
        "create a generalized filename"
        fn = ('file%05d'%self._n)+'.aaa'
        self._n += 1
        return fn
    
def split_file( fname, working_path=None, **kwargs ):
    """
    Split an MCT-generated data file into individual data files
    

    sp_prefix='s', noi_prefix='s', dc_prefix='a',
    iv_suffix='.iv', sp_suffix='.raw', noi_suffix='.nfig', dc_suffix='.dc', use_ids=False,
    
    """
    if working_path:
        if not os.path.isdir(working_path):
            raise ValueError("'working_path' is not a valid directory")
    
    # parse the data file
    datafile = MctDataFile(fname)
    # create a filename generator
    gen = FilenameGenerator(datafile,**kwargs)
        
    # write the split data files
    for block in datafile.blocks():
        if block.isempty:
            continue
        
        outfname = gen(block)
        if working_path:
            fp = open(os.path.join(working_path,outfname),'w')
        else:
            fp = open(outfname,'w')
        
        # write file header
        fp.write(''.join(datafile.headers))
        
        # write block headers
        if block.format_line:
            fp.write(block.format_line+'\n')
        fp.write(''.join(block.headers))
        
        # write data
        # convert all data to tab-delimited
        for line in block.data_lines:
            fp.write('\t'.join(line.split())+'\n')
        
        fp.close()

def split_to_mdif( fname, prefix=None, working_path=None, deembedding_object=None, generic_indep_vars=None ):
    """split an MCT data file to one or more MDIF-formatted files,
    
    the MDIF file names are pre-defined for a given file type
    
    prefix               a string prefix that is prepended to each file name
    working_path         a filesystem path in which to write the output files
    deembedding_object   and instance of the `network_params.DeembeddingUtil` class set up to
                            deembed S-parameter data blocks
    generic_indep_vars   a list/tuple of independent variable names to use when splitting generic
                            MCT data files (containing S-parmater or noise data).  This option
                            overrides the default independent variable setting of ('v1','v2')
                            for generic files - it does not affect the processing of FET or BJT
                            files.
    
    """
    pth = ''
    if working_path:
        if not os.path.isdir(working_path):
            raise ValueError("'working_path' is not a valid directory")
        pth = working_path
    
    pre = ''
    if prefix:
        pre = str(prefix)
    
    # parse the data file
    datafile = MctDataFile(fname)
    
    if datafile.type == 'fet':
        indep_vars = {'dciv':('v1','v2'), 'fwdiv':('i1',), 'breakdown':('v2',), 'coldfet':('i1',), 'sparams':('v1','v2'), 'noise':('v1','v2')}
        # convert each possible type of FET data to an MDIF output
        for bn in ('dciv','fwdiv','breakdown'):
            blocks = datafile.get_blocks_by_section(bn)
            if blocks:
                if len(blocks) > 1:
                    raise ValueError("more than 1 block of type `%s` was found in '%s'"%(bn,fname))
                fpath = os.path.join(pth,pre+bn+'.mdf')         
                _write_dc_mdif_data(fpath,blocks[0],indep_vars[bn],''.join(datafile.headers))
        
        for bn in ('coldfet','sparams'):
            blocks = datafile.get_blocks_by_section(bn)
            if blocks:
                fpath = os.path.join(pth,pre+bn+'.mdf')         
                _write_sp_mdif_data(fpath,blocks,indep_vars[bn],''.join(datafile.headers),deembedding_object)
        
        blocks = datafile.get_blocks_by_datatype('noise')
        if blocks:
            fpath = os.path.join(pth,pre+'noise.mdf') 
            _write_noise_mdif_data(fpath,blocks,indep_vars['noise'],''.join(datafile.headers))
    
    elif datafile.type == 'bjt':
        raise NotImplemented('`bjt` data files cannot be converted to MDIF at this time')
    
    elif datafile.type == 'dc':
        raise NotImplemented('`dc` data files cannot be converted to MDIF at this time')
        
    else:
        # generic file
        blocks = datafile.blocks()
        if not blocks:
            raise ValueError('`generic` MCT data file `%s` contains no data'%fname)
        dt = blocks[0].data_type
        if dt not in ('noise','sparams'):
            raise NotImplemented('only generic files of `sparam` or `noise` data can be converted to MDIF')
        for b in blocks:
            if b.data_type != dt and not b.isempty:
                raise ValueError('`generic` MCT data file `%s` is not homogeneous (contains multiple data types)'%fname)
        
        if generic_indep_vars:
            valid_indeps = frozenset(['v1','v2','i1','i2'])
            if not isinstance(generic_indep_vars,(list,tuple)) or len(generic_indep_vars) not in (1,2):
                raise ValueError('`generic_indep_vars` must be a 1 or 2 element tuple/list')
            for i in generic_indep_vars:
                if i not in valid_indeps:
                    raise ValueError('`generic_indep_vars` contains an invalid value: "%s"'%i)
            indep_vars = generic_indep_vars
        else:
            indep_vars = ('v1','v2')
            
        # generate the output file name
        outfname = pre+os.path.splitext(os.path.basename(fname))[0]+'.mdf'
        fpath = os.path.join(pth,outfname)
        if fpath == os.path.realpath(fname):
            raise ValueError('MDIF file would overwrite original file: '+fname)
        
        if dt == 'noise':
            _write_noise_mdif_data(fpath,blocks,indep_vars,''.join(datafile.headers))            
        else:
            _write_sp_mdif_data(fpath,blocks,indep_vars,''.join(datafile.headers),deembedding_object)
        

class _blocksorter(object): 
    "class for sorting data blocks"
    
    def __init__(self, *args):
        "initializer"
        
        if not len(args):
            raise ValueError('at least 1 independent variable is required')
        self._ind = args
    
    def __call__(self, a, b):
        "sorting function"
        for s in self._ind:
            try:
                x = cmp(getattr(a,s),getattr(b,s))
            except AttributeError:
                try:
                    x = cmp(a[s],b[s])
                except TypeError:
                    raise TypeError("invalid sorting block type")
            
            if x != 0:
                return x
        
        return 0
        
        
def _write_dc_mdif_data(fpath, block, indep_vars, header, block_name='DCDATA'):
    "internal function for writing a DC data block into MDIF format"
    # convert the data into a form that can be worked with
    data = []
    for line in block.data_lines:
        vals = map(float,line.split())
        data.append({'v1':vals[2], 'v2':vals[0], 'i1':vals[3], 'i2':vals[1]})
    
    col_order = ['v1','v2','i1','i2']
        
    # write the output
    fp = open(fpath,'w')
    fp.write(header)
    # don't write block header due to confusion over
    # the contents of the header which conflict with
    # MDIF-formatted data
    #fp.write(''.join(block.headers))
    
    try:
        if len(indep_vars) == 2:
            ind1 = indep_vars[0]
            ind2 = indep_vars[1]
            sorter = _blocksorter(ind2)
            # get the set of outer independent values
            s = set()
            for d in data:
                v = d[ind1]
                if v not in s:
                    s.add(v)
            outer = list(s)
            outer.sort()
            
            # remove ind1 from the col_order and make sure ind2 is the first column
            del col_order[col_order.index(ind1)]
            if ind2 != col_order[0]:
                del col_order[col_order.index(ind2)]
                col_order.insert(0,ind2)
            
            for ov in outer:
                # grab all data items in which the outer independent matches
                # the one that we are currently writing
                ds = []
                for d in data:
                    if d[ind1] == ov:
                        ds.append(d)
                # sort the data
                ds.sort(sorter)
                
                # write the outer indep
                fp.write('!\n')
                fp.write('VAR %s(1) = %g\n'%(ind1,ov))
                
                # write the MDIF header
                fp.write('BEGIN '+block_name+'\n')
                fp.write('%')
                for c in col_order:
                    fp.write('\t'+c+'(1)')
                fp.write('\n')
                
                # write the data
                for d in ds:
                    for c in col_order:
                        fp.write('\t%g'%d[c])
                    fp.write('\n')
                fp.write('END\n')
        
        elif len(indep_vars) == 1:
            # all data will be written into a single MDIF block
            ind = indep_vars[0]
            sorter = _blocksorter(ind)
            if ind != col_order[0]:
                # rearrange column order so that the independent variable is
                # in the first data column
                del col_order[col_order.index(ind)]
                col_order.insert(0,ind)
            
            # sort the data
            data.sort(sorter)
            
            # write the MDIF header
            fp.write('!\nBEGIN '+block_name+'\n')
            fp.write('%')
            for c in col_order:
                fp.write('\t'+c+'(1)')
            fp.write('\n')
            
            # write the data
            for d in data:
                for c in col_order:
                    fp.write('\t%g'%d[c])
                fp.write('\n')
            fp.write('END\n')
        
        else:
            raise ValueError("there must be exactly 1 or 2 independent variables defined")
        
    finally:
        fp.close()
    

def _write_sp_mdif_data(fpath, blocks, indep_vars, header, deembedding_object):
    "internal function for writing S-param data blocks into S2PMDIF format"
    
    # sort the blocks list
    sorter = _blocksorter(*indep_vars)
    blocks.sort(sorter)

    # write the file
    fp = open(fpath,'w')
    fp.write(header)
    try:
        for b in blocks:
            if b.isempty:
                continue
                
            # create a temporary file-like object that can be passed
            # to the Touchstone class for reading the S-param data from
            # the block - this puts it into a format that can be easily
            # written back out again by the `write_s2pmdif_block` function
            ts_data = StringIO()
            ts_data.write(b.format_line+'\n')
            ts_data.write(''.join(b.data_lines))
            ts_data.seek(0)
            ts = Touchstone(ts_data)
            
            # apply deembedding if it is defined
            if deembedding_object:
                ts = deembedding_object.deembed(ts)
        
            # write independent variables
            if len(blocks) > 1:
                fp.write('!\n')
                for ind in indep_vars:
                    fp.write('VAR %s = %g\n'%(ind,getattr(b,ind)))     
                
            # write the block
            write_s2pmdif_block(fp,ts,block_header=b.bias_line)   

    finally:
        fp.close()
        
def _write_noise_mdif_data(fpath, blocks, indep_vars, header, block_name='MEASNOISE'):
    "internal function for writing noise data blocks into MDIF format"
    
    # sort the blocks list
    sorter = _blocksorter(*indep_vars)
    blocks.sort(sorter)

    # write the file
    fp = open(fpath,'w')
    fp.write(header)
    try:
        for b in blocks:
            if b.isempty:
                continue
        
            # write independent variables
            if len(blocks) > 1:
                fp.write('!\n')
                for ind in indep_vars:
                    fp.write('VAR %s(1) = %g\n'%(ind,getattr(b,ind)))     
                    
            # write the block header
            bl = b.bias_line
            if bl:
                fp.write(bl)
            
            # write the noise data block
            fp.write('BEGIN '+block_name+'\n')
            fp.write('%\tfreq(1)\tgain(1)\tnfig(1)\n')
            
            # write the data
            for line in b.data_lines:
                fp.write('\t'+('\t'.join(line.split()))+'\n')
            fp.write('END\n')

    finally:
        fp.close()
        

def _expand_files( flist ):
    "expand files passed from the command line"
    if sys.platform in ('winnt','win32','win64',):
        # wildcard expansion for Windows platforms
        import glob
        fl2 = []
        for fn in flist:
            fl2.extend(glob.glob(fn))
        return fl2
    return flist
    
    
def split_cl():
    """split files from the command line
    
    acts as a wrapper around 'split_file()' adding command-line
    parsing and looping
    """
    
    import optparse
    p = optparse.OptionParser(usage='%prog [options] file1 [file2 ...]',version='%prog 0.1')
    p.add_option('--spre','--sparam-prefix',dest='sp_prefix',metavar='PREFIX',help='Use PREFIX as the prefix for S-parameter files')
    p.add_option('--npre','--noise-prefix',dest='noi_prefix',metavar='PREFIX',help='Use PREFIX as the prefix for noise files')
    p.add_option('--dcpre','--dc-prefix',dest='dc_prefix',metavar='PREFIX',help='Use PREFIX as the prefix for DC files')
    p.add_option('--ssuf','--sparam-suffix',dest='sp_suffix',metavar='SUFFIX',help='Use SUFFIX as the suffix for S-parameter files')
    p.add_option('--nsuf','--noise-suffix',dest='noi_suffix',metavar='SUFFIX',help='Use SUFFIX as the suffix for noise files')
    p.add_option('--dcsuf','--dc-suffix',dest='dc_suffix',metavar='SUFFIX',help='Use SUFFIX as the suffix for DC files')
    p.add_option('--ivsuf','--iv-suffix',dest='iv_suffix',metavar='SUFFIX',help='Use SUFFIX as the suffix for I-V files')
    p.add_option('--ids',dest='use_ids',action='store_true',default=False,help='Use Ids as the secondary naming parameter for generic noise and S-parameter data files')
    p.add_option('--working-path',dest='working_path',default='',metavar='PATH',help='Use PATH as the target path for output data files')
    p.add_option('--create-subdirs',dest='subdirs',action='store_true',default=False,help='Attempt to automatically create subdirs')
    
    opts,files = p.parse_args()
    create_subdirs = opts.subdirs
    working_path = opts.working_path
    
    if not len(files):
        p.print_usage()
        sys.exit(1)

    files = _expand_files(files)
    
    # generate keywords
    del opts.subdirs
    del opts.working_path
    kw = {}
    for k,v in vars(opts).iteritems():
        if v is not None:
            kw[k] = v
    
    # split files
    for fn in files:
        print fn,'...'
        try:
            if create_subdirs:
                # determine the working path
                bfn = os.path.basename(fn)
                p = os.path.join(working_path,os.path.splitext(bfn)[0])
                if os.path.exists(p) and not os.path.isdir(p):
                    # append a '.d' to the directory name in cases where perhaps
                    # the filename had no extension
                    p += '.d'
                    
                if os.path.exists(p):
                    if not os.path.isdir(p):
                        raise ValueError("unable to create a directory named '%s' - name exists as a non-directory entry"%p)
                else:
                    # create the directory
                    os.mkdir(p)
                
                kw['working_path'] = p
            else:
                kw['working_path'] = working_path
        
            split_file(fn,**kw)
        except Exception, e:
            traceback.print_exc()

def make_dirs_and_files_cl():
    """split files from the command line, putting each file into a unique directory
    
    acts as a wrapper around 'split_cl()', adding the '--create-subdirs' argument
    to the sys.argv list if it is not present
    """
    if '--create-subdirs' not in sys.argv:
        sys.argv.insert(1,'--create-subdirs')
    split_cl()
            
def mdif_cl():
    """split files into MDIF from the command line
    
    acts as a wrapper around 'split_to_mdif()' adding command-line
    parsing and looping
    """
    
    import optparse
    p = optparse.OptionParser(usage='%prog [options] file1 [file2 ...]',version='%prog 0.1')
    p.add_option('-p','--prefix',dest='prefix',metavar='PREFIX',help='Use PREFIX as the prefix when naming output files')
    p.add_option('--working-path',dest='working_path',default='',metavar='PATH',help='Use PATH as the target path for output data files')
    p.add_option('--create-subdirs',action='store_true',default=False,dest='subdirs',help='Attempt to automatically create subdirs')
    p.add_option('--indeps',dest='indeps',help='comma-separated list of independent variables for generic files')
    p.add_option('-d','--deembed',action='store_true',dest='deembed',help='deembed fixtures from S2P data files')
    p.add_option('-e','--embed',action='store_true',dest='embed',help='embed fixtures onto S2P data files')
    p.add_option('-1','--fxa','--fixture1',dest='fxa',metavar='FILE',default='',help='use FILE as the port 1 fixture data (S2P data file)')
    p.add_option('-2','--fxb','--fixture2',dest='fxb',metavar='FILE',default='',help='use FILE as the port 2 fixture data (S2P data file)')
    p.add_option('--swap1',action='store_true',dest='swap1',default=False,help='swap the ports of the data used for fixture 1')
    p.add_option('--swap2',action='store_true',dest='swap2',default=False,help='swap the ports of the data used for fixture 2')
    
    opts,files = p.parse_args()
    create_subdirs = opts.subdirs
    working_path = opts.working_path
    if not working_path:
        working_path = os.getcwd()
    
    if not len(files):
        p.print_usage()
        sys.exit(1)

    files = _expand_files(files)
    
    # generate keywords
    kw = {}
    if opts.prefix is not None:
        kw['prefix'] = opts.prefix
    
    # set up de-embedding if any parameters were specified
    if opts.deembed or opts.embed or opts.fxa or opts.fxb:
        if opts.deembed and opts.embed:
            raise ValueError("cannot deembed and embed at the same time")
        
        dmb = True
        if opts.embed:
            dmb = False
        
        dmbkw = {
            'fname1':opts.fxa,
            'fname2':opts.fxb,
            'swap1':opts.swap1,
            'swap2':opts.swap2,
            'invert1':dmb,
            'invert2':dmb,
        }
        
        kw['deembedding_object'] = DeembeddingUtil(**dmbkw)
    
    # set up independent variables for generic files
    if opts.indeps:
        valid = frozenset(['v1','v2','i1','i2'])
        vals = [v.strip().lower() for v in opts.indeps.split(',')]
        for v in vals:
            if v not in valid:
                raise ValueError("invalid value found in --indeps: '%s' (only 'v1', 'v2', 'i1', or 'i2' are allowed)"%v)
        
        kw['generic_indep_vars'] = tuple(vals)
    
    # split files
    for fn in files:
        print fn,'...'
        try:
            if create_subdirs:
                # determine the working path
                bfn = os.path.basename(fn)
                p = os.path.join(working_path,os.path.splitext(bfn)[0])
                if os.path.exists(p) and not os.path.isdir(p):
                    # append a '.d' to the directory name in cases where perhaps
                    # the filename had no extension
                    p += '.d'
                    
                if os.path.exists(p):
                    if not os.path.isdir(p):
                        raise ValueError("unable to create a directory named '%s' - name exists as a non-directory entry"%p)
                else:
                    # create the directory
                    os.mkdir(p)
                
                kw['working_path'] = p
            else:
                kw['working_path'] = working_path
        
            split_to_mdif(fn,**kw)
        except Exception, e:
            traceback.print_exc()
            