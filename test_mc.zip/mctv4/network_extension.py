from network_params import Touchstone
import pylab as plb
import numpy as npy
import math

class new_touchstone(Touchstone):
    
    def __init__(self, fname = None, **kwargs):
        
        kwargs = self.config(**kwargs)
        super(new_touchstone,self).__init__(**kwargs)
        
        if fname is not None:
            self.read(fname)
            
    def plot_rectangular(x, y, x_label=None, y_label=None, title=None,show_legend=True, axis='tight', ax=None, *args, **kwargs):
        '''
        plots rectangular data and optionally label axes.

        Parameters
        ------------
        z : array-like, of complex data
            data to plot
        x_label : string
            x-axis label
        y_label : string
            y-axis label
        title : string
            plot title
        show_legend : Boolean
            controls the drawing of the legend
        ax : :class:`matplotlib.axes.AxesSubplot` object
            axes to draw on
        *args,**kwargs : passed to pylab.plot
        
        '''
        if ax is None:
            ax = plb.gca()

        my_plot = ax.plot(x, y, *args, **kwargs)

        if x_label is not None:
            ax.set_xlabel(x_label)

        if y_label is not None:
            ax.set_ylabel(y_label)

        if title is not None:
            ax.set_title(title)

        if show_legend:
            # only show legend if they provide a label
            if 'label' in kwargs:
                ax.legend()

        if axis is not None:
            ax.autoscale(True, 'x', True)
            ax.autoscale(True, 'y', False)
            
        if plb.isinteractive():
            plb.draw()
        
        return my_plot
        
    def plot_func(self):

        # plot s11 first
        s11_db = []
        for s11 in self.data:
            dat = s11[0,0]
            s11_db.append(math.log10(abs(dat)))
            
        x = npy.asarray(self.flist)
        y = npy.asarray(s11_db)        
        
        x_label = 'Frequency (Hz)'
        y_label = 'S11 (dB)'
        
        plt = self.plot_rectangular(x,y, x_label, y_label, 'Prelim Plot')
        plt.show()
        
if __name__ == "__main__":
    a = new_touchstone(fname = 'ntwk1.s2p')
    a.plot_func()
    
        
        
        
        