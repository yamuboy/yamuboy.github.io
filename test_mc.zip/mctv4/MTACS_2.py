"""
Modeling Test and Characterization Suite V 0.0

"""
import wx, os, sys
import logging, traceback
from data_structs import ApplicationPreferences
from test_module_loader_1 import test_mod_loader
try:
    from wx.lib.pubsub import Publisher
except ImportError:
    from wx.lib.pubsub import pub
from utils import MyExceptionHook, ExceptionDialog, file_header_gui, set_main_window, get_main_window
from data_display import DataFrame
from wxtestgui import ValidationError, TestParameters, Instr
from wxtestgui.edit_params import EditTestParamsDialog, EditNumberListDialog, EditOrderedListDialog
from wxtestgui.edit_instruments import InstrumentConfigDialog
from wxtestgui.worker import Worker, EVT_WORKER_MESSAGE, EVT_WORKER_EXITING
import re as _re

#about_info = wx.AboutDialogInfo()
#about_info.SetCopyright("MACOM 2016")
#about_info.SetDescription("Microwave test and characterization suite")
#about_info.SetName("MTACS")
#about_info.SetVersion("0.0")
#about_info.SetDevelopers(["Modeling Group",])

logger = logging.getLogger(__name__)

_valid_param_line = _re.compile(r'([a-zA-Z][a-zA-Z0-9_.]*)\s*=')
_valid_instrument_line = _re.compile(r'([a-zA-Z][a-zA-Z0-9_.]*)\s*:')

class WxTextCtrlHandler(logging.Handler):
    def __init__(self, ctrl):
        logging.Handler.__init__(self)
        self.ctrl = ctrl

    def emit(self, record):
        s = self.format(record) + '\n'
        wx.CallAfter(self.ctrl.WriteText, s)    

####   Simple Cal Gui #######
class CalMain(wx.Frame):
    def __init__(self,parent,id, cal_dict,params,instrs):
    
        super(CalMain,self).__init__(parent,id)
        # cal_dict is of the format {'step name':(function,test_params,instrs)}
        self.panel = wx.Panel(self)
        self.parent = parent
        pos_x = 100
        pos_y = 20
        self.cbs = []
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        self.cal_dict = cal_dict
        self.params = params
        self.instrs = instrs
        self.steps_done = []
        self.current_step = None
        self.new_worker = None
        
        for i in cal_dict.iterkeys():
            pos_y += 20
            cb = wx.CheckBox(self.panel, label = i, pos = (pos_x,pos_y))
            self.cbs.append((cb,i))
            
        self.statusbar = self.CreateStatusBar()
        
        self.Bind(EVT_WORKER_MESSAGE,self.OnWorkerUpdate)
        self.Bind(EVT_WORKER_EXITING,self.OnTestComplete)
        
        self.btn_box = wx.StaticBox(self.panel, label = "Cal Buttons")
        self.btn_sizer = wx.StaticBoxSizer(self.btn_box, wx.HORIZONTAL)        
        self.measure = wx.Button(self.panel, wx.ID_ANY, "Measure")
        self.Bind(wx.EVT_BUTTON,self.OnMeasure,self.measure)
        self.abort = wx.Button(self.panel, wx.ID_ANY, "Abort Step")
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.abort)
        self.cancel = wx.Button(self.panel, wx.ID_ANY, "Cancel")
        self.Bind(wx.EVT_BUTTON, self.OnCancel, self.cancel)
        self.finish = wx.Button(self.panel, wx.ID_ANY, "Finish")
        self.Bind(wx.EVT_BUTTON,self.OnFinish, self.finish)
        
        self.finish.Disable()
        
        self.btn_sizer.Add(self.measure,0,wx.ALL,5)
        self.btn_sizer.Add(self.abort,0,wx.ALL,5)
        self.btn_sizer.Add(self.cancel,0,wx.ALL,5)
        self.btn_sizer.Add(self.finish,0,wx.ALL,5)
        
        self.cb_box = wx.StaticBox(self.panel, label = "Cal Steps")
        self.cb_sizer = wx.StaticBoxSizer(self.cb_box, wx.VERTICAL)
        for i in self.cbs:
            self.cb_sizer.Add(i[0],1,wx.EXPAND)
            
        main_sizer.Add(self.cb_sizer,1,wx.ALL|wx.EXPAND)       
        main_sizer.Add((20,20))
        main_sizer.Add(self.btn_sizer,1,wx.ALL|wx.EXPAND)
        
        self.panel.SetSizer(main_sizer)
        self.SetSize((300,300))
        self.Layout()
        
    def OnFinish(self,evt):
        self.parent.cal_completed = True
        self.Destroy()        
        
    def OnMeasure(self,evt):
        arglist = [self.params, self.instrs]    
        for i in self.cbs:
            if i[0].GetValue() and i[1] not in self.steps_done:
                try:
                    self.current_step = i[1]                
                    self.steps_done.append(i[1])
                    self.new_worker = Worker(self,target = self.cal_dict[i[1]], args = arglist)
                    self.new_worker.start()
                except Exception:
                    raise Exception("Thread Error")
                finally:
                    i[0].SetBackgroundColour(wx.GREEN)
        self._update_ui()
        
    def _update_ui(self):
        if len(self.cal_dict) == len(self.steps_done):
            self.finish.SetBackgroundColour(wx.GREEN)
            self.finish.Enable()
        else:            
            self.finish.Disable()
                        
    def OnWorkerUpdate(self,evt):
        if evt.msgtype == 'update':
            self.statusbar.SetStatusText(evt.payload)        
         
    def OnAbort(self,evt): 
        self.statusbar.SetStatusText("Cal Step Aborted, Redo Step")    
        self.new_worker.comm.send_to_worker("cal abort")
        if self.current_step in self.steps_done:
            self.steps_done.pop(self.steps_done.index(self.current_step))
        for i in self.cbs:
            if i[0].GetValue() and i[1] == self.current_step:
                i[0].SetBackgroundColour(wx.NullColour)                    
        
    def OnTestComplete(self,evt):
        self.new_worker.join()
        self.new_worker = None   
            
        
    def OnCancel(self,evt):
        if self.new_worker:
            evt.Veto()
        else:
            evt.Skip()        
        self.Destroy()      
    
   
class mtacs_main(wx.Frame):
    '''
    The main window of MTACS. The application preferences file contains the following:
                            1. The setup file which was last used.
                               The setup file contains all the instrument and param information                             
                            2. Window size and plotting preferences (TBI)
    There are three tabs in the main window. The tabs are:
                    1. The module tab which lists out the modules for different device types.
                       Allows the user to load a module.
                    2. The main test tab which displays the module info., multisite controller
                       and allows the user to run a test, adjust the parameters, and display the results.
                    3. The Stand Specific information tab that displays the current stand config.                       
    '''    
    def __init__(self,*args,**kwargs):
                
        super(mtacs_main,self).__init__(*args,**kwargs)        
                       
        self.setup = ApplicationPreferences()
        self.test_params = TestParameters()
        
        # Make sure all exceptions are caught and displayed in a dialog        
        sys.excepthook = MyExceptionHook
        
        # Bind worker update events
        self.Bind(EVT_WORKER_MESSAGE, self.OnWorkerUpdate)
        self.Bind(EVT_WORKER_EXITING, self.OnTestComplete)
        
        # Bind main window close event
        self.Bind(wx.EVT_CLOSE,self.OnCloseWindow)
                
        self.current_test_setup = None              
                 
        # Create the test module loader object
        self.test_loader = test_mod_loader()
        self.module_loaded = False 
        self.cal_completed = False
        self.instruments_opened = False
        self.new_worker = None        
        
        set_main_window(self)                
                
        self.controls = {}
        self.current_test_selection = None
        self.CreateStatusBar(style = 0)
                
        pub.subscribe(self.change_status,'change status')
        self.timer = wx.Timer(self)
                
        self.Notebook = wx.Notebook(self,-1, style = 0)
        self.MainPanel = wx.Panel(self.Notebook, -1)
        self.SetupPanel = wx.Panel(self.Notebook, -1)
        self.StandSettings = wx.Panel(self.Notebook, -1)
                  
        # Setup the menu bar for the software main window
        menubar    = wx.MenuBar()
        
        #File Menu
        file_menu  = wx.Menu()
        file1 = file_menu.Append(wx.ID_OPEN,"Load Setup...")
        file2 = file_menu.Append(wx.ID_SAVE,"Save Setup...")
        file_menu.AppendSeparator()
        file4 = file_menu.Append(wx.ID_EXIT,"Exit", "Exit")
        
        #File Menu Action Handlers
        self.Bind(wx.EVT_MENU,self.OnLoadSetup,file1)
        self.Bind(wx.EVT_MENU,self.OnSaveSetup,file2)
        self.Bind(wx.EVT_MENU,self.OnExit,file4)
        
        # Cal menu items
        cal_menu = wx.Menu()
        self.save_cal = cal_menu.Append(wx.ID_ANY, "Save Cal...")
        self.recall_cal = cal_menu.Append(wx.ID_ANY,"Recall Cal...")
        self.clear_cal = cal_menu.Append(wx.ID_ANY,"Clear Cal...")
        self.Bind(wx.EVT_MENU,self.OnSaveCal, self.save_cal)
        self.Bind(wx.EVT_MENU,self.OnRecallCal, self.recall_cal)
        self.Bind(wx.EVT_MENU,self.OnClearCal, self.clear_cal)
        
        
        #Help Menu
        help_menu = wx.Menu()
        help1 = help_menu.Append(wx.ID_HELP,"Help")
        info1 = help_menu.Append(wx.ID_ANY, "About")
        #Help Menu Action Handlers
        self.Bind(wx.EVT_MENU,self.OnHelp,help1)
        self.Bind(wx.EVT_MENU,self.OnAbout,info1)
        
                
        #Add Menus to Menubar
        menubar.Append(file_menu,"File")
        menubar.Append(cal_menu,"Cal")
        menubar.Append(help_menu, "Help")
        self.SetMenuBar(menubar)
          
        # Create Tree control for loading test module   
        # The main page just has a list of tests and a description of the test
        # Create List of Test Names
        tree_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.controls['test_tree'] = wx.TreeCtrl(self.MainPanel,-1, style=wx.TR_HAS_BUTTONS|wx.TR_DEFAULT_STYLE|wx.SUNKEN_BORDER)
        
        module_dict = self.test_loader.get_modules()        
        root = self.controls['test_tree'].AddRoot("Routines")
        
        for i in module_dict.iterkeys():
            new_item = self.controls['test_tree'].AppendItem(root,i)
            for j in module_dict[i]:
                self.controls['test_tree'].AppendItem(new_item,j)
                
        self.Bind(wx.EVT_TREE_SEL_CHANGED,self.OnSelChanged,self.controls['test_tree'])        
        tree_sizer.Add(self.controls['test_tree'],1,wx.EXPAND, 5)
        
        load_btn_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.controls['load_module_button'] = wx.Button(self.MainPanel,wx.ID_ANY,"Load Test Module")
        self.Bind(wx.EVT_BUTTON, self.OnTestSelect, self.controls['load_module_button'])
        load_btn_sizer.Add(self.controls['load_module_button'], 1,wx.CENTER)
        
        mainwinsizer = wx.BoxSizer(wx.VERTICAL)
        mainwinsizer.Add(tree_sizer,1,wx.EXPAND|wx.ALL,5)
        mainwinsizer.Add(load_btn_sizer,1,wx.CENTER,5)
                
        # Code for the "Setup" page of the notebook
        
        # Box to display the test module's docstring
        test_info_box = wx.StaticBox(self.SetupPanel, label = "Test Module Information")
        test_info_box_sizer = wx.StaticBoxSizer(test_info_box, wx.HORIZONTAL)
        self.controls['test_info'] = wx.TextCtrl(self.SetupPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        test_info_box_sizer.Add(self.controls['test_info'],1,wx.EXPAND,5)        
                                
        # Test Control buttons
        setup_box = wx.StaticBox(self.SetupPanel, label = "Setup Menu")
        setup_sizer = wx.StaticBoxSizer(setup_box,wx.VERTICAL)
        self.controls['instrument_setup'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Instruments")
        self.controls['multisite_control'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Multisite Controller")
        # Bind buttons to event handlers
        self.Bind(wx.EVT_BUTTON,self.OnInstrumentSetup,self.controls['instrument_setup'])
        self.Bind(wx.EVT_BUTTON,self.OnMultisite, self.controls['multisite_control'])
        # Add buttons to the sizer
        setup_sizer.Add(self.controls['instrument_setup'],1, wx.CENTER,5)
        setup_sizer.Add(self.controls['multisite_control'],1, wx.CENTER,5)
        
        # Test Parameter buttons
        test_box = wx.StaticBox(self.SetupPanel, label = "Test Menu")
        test_sizer = wx.StaticBoxSizer(test_box, wx.VERTICAL )
        self.controls['edit_params'] = wx.Button(self.SetupPanel, wx.ID_ANY,"Edit Parameters")
        self.Bind(wx.EVT_BUTTON, self.OnEditParams, self.controls['edit_params'])
        self.controls['calibrate'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Calibrate")
        self.Bind(wx.EVT_BUTTON, self.OnCalibrate, self.controls['calibrate'])
        self.controls['validate'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Validate")
        # Sizer for the Test parameters and calibrate options
        test_sizer.Add(self.controls['edit_params'],1, wx.CENTER,5)
        test_sizer.Add(self.controls['calibrate'],1, wx.CENTER,5)
        test_sizer.Add(self.controls['validate'],1, wx.CENTER,5)
        
        # Buttons for the run/abort buttons
        run_box = wx.StaticBox(self.SetupPanel, label = "Test Controller")
        run_sizer = wx.StaticBoxSizer(run_box, wx.VERTICAL)
        self.controls['run'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Run")
        self.Bind(wx.EVT_BUTTON,self.OnRunTest, self.controls['run'])
        self.controls['abort'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Abort")
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.controls['abort'])
        self.controls['data_display'] = wx.Button(self.SetupPanel, wx.ID_ANY, "Data Display")
        self.Bind(wx.EVT_BUTTON, self.OnDataDisplay, self.controls['data_display'])
        # Add run and abort to the sizer
        run_sizer.Add(self.controls['run'],1,wx.CENTER, 5)
        run_sizer.Add(self.controls['abort'],1,wx.CENTER, 5)
        run_sizer.Add(self.controls['data_display'],1,wx.CENTER, 5)
        
        # Set some colors for the run and abort button
        self.controls['run'].SetBackgroundColour(wx.GREEN)
        self.controls['abort'].SetBackgroundColour(wx.RED)
        
        # Drop down combo-box for routine selection
        routine_box = wx.StaticBox(self.SetupPanel, label = "Select Routine")
        routine_sizer = wx.StaticBoxSizer(routine_box, wx.HORIZONTAL)
        # If the test module has routines, get it, else display nothing
        self.controls['routine_selection'] = wx.ComboBox(self.SetupPanel,choices = [''],style = wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX,self.OnRoutineSelect) 
        routine_sizer.Add(self.controls['routine_selection'],1,wx.CENTER, 5)        
        
        # Text control for the logging utility
        logging_info_box = wx.StaticBox(self.SetupPanel, label = "Test Logger")
        logging_box_sizer = wx.StaticBoxSizer(logging_info_box, wx.HORIZONTAL)
        self.controls['test_logger'] = wx.TextCtrl(self.SetupPanel, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        logging_box_sizer.Add(self.controls['test_logger'],1,wx.EXPAND,5)   
        handler = WxTextCtrlHandler(self.controls['test_logger'])
        logger.addHandler(handler)
        FORMAT = "%(asctime)s %(levelname)s %(message)s"
        handler.setFormatter(logging.Formatter(FORMAT))
        logger.setLevel(logging.DEBUG)
        
        main_button_sizer = wx.BoxSizer(wx.HORIZONTAL)
        main_button_sizer.Add(setup_sizer, 1, wx.LEFT, 5)
        main_button_sizer.Add(test_sizer, 1, wx.CENTER, 5)
        main_button_sizer.Add(run_sizer, 1, wx.RIGHT, 5)
                
        setup_main_sizer = wx.BoxSizer(wx.VERTICAL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(test_info_box_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(main_button_sizer, 0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(routine_sizer,0, wx.EXPAND|wx.ALL)
        setup_main_sizer.Add((-1,20))
        setup_main_sizer.Add(logging_box_sizer,0,wx.EXPAND|wx.TOP)
        
        # display the current stand configuration in the stand settings panel
        stand_info_box = wx.StaticBox(self.StandSettings, label = "Current Stand Settings")
        stand_info_sizer = wx.StaticBoxSizer(stand_info_box)
        self.controls['stand_settings_info'] = wx.TextCtrl(self.StandSettings, style=wx.TE_MULTILINE | wx.HSCROLL | wx.TE_READONLY,size=(100,100))
        stand_info_sizer.Add(self.controls['stand_settings_info'],1,wx.EXPAND,5)
                
        
        self.Notebook.AddPage(self.MainPanel, "Main")
        self.Notebook.AddPage(self.SetupPanel, "Setup")
        self.Notebook.AddPage(self.StandSettings, "Stand Settings")
        
        self.MainPanel.SetSizer(mainwinsizer)
        self.SetupPanel.SetSizer(setup_main_sizer)
        self.StandSettings.SetSizer(stand_info_sizer)
        
        if 'window_size' in self.setup:
            self.SetSize(self.setup.get('window_size'))
        else:
            self.SetSize((800,800))
        if 'window_position' in self.setup:
            self.SetPosition(self.setup.get('window_position'))
        else:
            self.SetPosition((200,200))
            
        self.SetTitle("MTACS")
        
        self.change_status("Preferences Module Loaded")
        
        if 'setup_file' in self.setup:
            # Load the default setup
            if os.path.exists(self.setup['setup_file']):
                self._load_stp(self.setup['setup_file'])
            else:
                self.change_status("Path to Default setup incorrectly specified")                
            
    def OnSaveCal(self,evt):
        # Just save the cal data in whatever format it exists
        if not self.cal_completed:
            wx.MessageBox("No Cal Data to Save. Perform Cal first","Warning",wx.OK)
        else:
            kw = {'style':wx.FD_SAVE}
            dlg = wx.FileDialog(self,'Save Current Cal',**kw)
            if dlg.ShowModal() == wx.ID_OK:
                fname = dlg.GetPath()
                dlg.Destroy()
                self._save_cal(fname)

    def _save_cal(self,cfname):
        # Get the cal data and just save it
        c_data = self.test_loader.mod_cal_data
        f = open(cfname, 'w')
        keys = c_data.keys()
        keys.sort()
        f.write("#Cal Data\n\n")
        try:
            for k in keys:
                v = c_data[k]
                wv = repr(v)
                
                f.write("%s = %s\n"%(k,wv))
        finally:
            f.close()
        logger.log(logging.INFO, "Cal Data Saved")
           
            
    def OnRecallCal(self,evt):
        kw = {'style':wx.FD_OPEN}
        dlg = wx.FileDialog(self,'Save Current Cal',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            dlg.Destroy()
        self._recall_cal(fname)
        
    def _recall_cal(self, fname):
        # Recall the cal and override the modules cal data dictionary
        c_data = {}
        execfile(fname,c_data)
        del c_data['__builtins__']
        self.cal_completed = True
        self.test_loader.clear_mod_cal(reset = False, c_dict = c_data)
        logger.log(logging.INFO,"Cal Data Recalled")
        
    def OnClearCal(self,evt):
        # Clears the cal and lets the user perform a fresh cal
        self.test_loader.clear_mod_cal(reset = True)
        self.cal_completed = False
        logger.log(logging.WARNING,"Cal Cleared. User must perform Cal before new test")        

       
    def OnMultisite(self,evt):
        # disable feature as it is undergoing testing
        dlg = wx.MessageBox('This Feature is Temporarily Unavailable','Info',wx.OK|wx.ICON_INFORMATION)
        #self.m_display = multisite_window(self)        
        #self.m_display.Show()

    def set_multisite_controller(self,m_control):
        # Not implemented till testing is completed
        """
        self.multisite_controller  =  m_control
        self.test_loader.set_multisite_controller(self.multisite_controller)
        self.set_multisite_enable(True)
        self.m_display.Close()
        """
        pass 
        
            
    def OnSelChanged(self, evt):
        self.tree_choice = evt.GetItem()
                
    def OnInstrumentSetup(self, evt):
        # Bring up a dialog to set up the instruments
        dlg = InstrumentConfigDialog(self.instrs,parent = self)
        if dlg.ShowModal() == wx.ID_OK:
            self.test_instrs = {}
            for instr in self.instrs:
                self.test_instrs[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)
            logger.log(logging.INFO,"Instrument Information Entered")
            dlg.Destroy()        
            
    def OnRoutineSelect(self,evt):
        self.test_routine = self.controls['routine_selection'].GetSelection()
        
    def change_status(self,message):
        self.SetStatusText(message)
        
    def OnEditParams(self, evt):
        dlg = EditTestParamsDialog(self.test_params.get_dialog_list(),None,style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)
        if dlg.ShowModal() == wx.ID_OK:
            # Get the values of the changed parameters
            self.test_params = TestParameters(self.params)
            logger.log(logging.INFO, "Parameters Edited")
            dlg.Destroy()
        
    def _update_gui(self):
        
        # First check if a module has been loaded. If it has, enable/disable buttons on page 2, else disable all
                   
        if self.module_loaded == False:
            self.change_status("No Module Loaded")
            for i in ['data_display','edit_params','calibrate','validate','run','abort','instrument_setup','routine_selection','multisite_control']:
                self.controls[i].Disable()
            self.controls['test_info'].SetValue(" ")
            self.controls['stand_settings_info'].SetValue(" ")
            self.save_cal.Enable(False)
            self.recall_cal.Enable(False)
            self.clear_cal.Enable(False)
            
        else:
            self.change_status('Module Loaded')
            self.controls['test_info'].SetValue(self.doc_str)
            # Tell the user how the stand is currently configured
            
            stand_str = "This stand is currently configured for {} testing\n".format(self.setup['device'])
            stand_str+= "The current test selection is : {}\n".format(self.setup['current_test_selection'])
            stand_str+= "The instruments settings for this stand are:\n"
            for i in self.instrs:
                stand_str+= "INSTRUMENT: {} \t DRIVER : {}\n".format(i.name, i.driver_name)
            self.controls['stand_settings_info'].SetValue(stand_str)            
            
            for i in ['data_display','edit_params','run','abort','instrument_setup','multisite_control']:
                self.controls[i].Enable()
            self.routines = self.test_loader.get_test_routines()
            if self.routines != None:
                self.controls['routine_selection'].Enable()
                for i in self.routines:
                    self.controls['routine_selection'].Append(i)                
            if self.test_loader.get_module_cal_flag() == False:
                self.controls['calibrate'].Disable()
                self.save_cal.Enable(False)
                self.recall_cal.Enable(False)
                self.clear_cal.Enable(False)
            else:
                self.controls['calibrate'].Enable()
                self.save_cal.Enable(True)
                self.recall_cal.Enable(True)
                self.clear_cal.Enable(True)
            
                
    def OnDataDisplay(self,evt):
        # Disable this feature till it is completely tested
        """
        self.test_data_dict = self.test_loader.get_test_data() 
        
        if self.test_data_dict:
            datadisp = DataFrame(self.test_data_dict)
            datadisp.Show()
        else:
            logger.log(logging.ERROR, "No Data to Display. Run the Test First")
        """
        dlg = wx.MessageBox('This Feature is Temporarily Unavailable','Info',wx.OK|wx.ICON_INFORMATION)

    def _load_stp(self, fname):
        # New setup loaded
        self.current_setup = fname
        f = open(fname, 'r')
        params = {}
        instrs = {}
        for line in f:
            m = _valid_param_line.match(line)
            i = _valid_instrument_line.match(line)
            if m:
                params[m.group(1)] = line[line.index('=')+1:].strip('\n')
            if i:
                instrs[i.group(1)] = eval(line[line.index(':')+1:].strip('\n'))
            if line.startswith('#Device'):
                self.setup['device'] = line[line.index(':')+1:].strip('\n')
            if line.startswith('#Test Selection'):
                self.setup['current_test_selection'] = line[line.index(':')+1:].strip('\n')
        f.close()
        
        try:
            self.test_loader.load_module(str(self.setup['device']), str(self.setup['current_test_selection']))
            self.doc_str = self.test_loader.get_module_docstr()
            self.cal_flag = self.test_loader.get_module_cal_flag()
            self.test_routine = self.test_loader.get_test_routines()
            self.params = self.test_loader.get_module_params()
            self.test_params = TestParameters(self.params)
            self.instrs = self.test_loader.get_module_instrs()
            self.module_loaded = True
            logger.log(logging.INFO, "Setup Loaded")
        except Exception,e:
            logger.log(logging.ERROR,"Error Loading Module")
            self.module_loaded = False
                                   
        for k,v in params.iteritems():
                if k in self.test_params._TestParameters__params:
                    self.test_params._TestParameters__params[k].value = eval(v)
        for k in instrs:
            for i in self.instrs:
                if k == i.name:
                    i.driver_name = instrs[k][0]
                    i.resource = instrs[k][1]
                    i.chan = instrs[k][2]
                    i.params = instrs[k][3]
                    
        # Create and update the test_instrs dict
        self.test_instrs = {}
        for instr in self.instrs:
            self.test_instrs[instr.name] = (instr.driver_name,instr.resource,instr.chan,instr.params)                    
            
        self._update_gui()            
        # update the main GUI    
        
        
    def OnLoadSetup(self, evt):
        kw = {'style':wx.FD_OPEN}
        dlg = wx.FileDialog(self,'Load Test Config',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            dlg.Destroy()
            self._load_stp(fname)                        
        
    def OnSaveSetup(self, evt):
        # Save the test configuration file
        kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT,'wildcard':"Test Setup Files (*.stp)|*.stp"}
        dlg = wx.FileDialog(self,'Save Test Config',**kw)
        if dlg.ShowModal() == wx.ID_OK:
            fname = dlg.GetPath()
            self.current_setup = fname
            keys = self.test_params._TestParameters__params.keys()
            keys.sort()
            f = open(fname,'w')
            f.write("#Test Parameters\n")
            for k in keys:
                p = self.test_params._TestParameters__params[k]
                v = p.value
                wv = repr(v)
                f.write("%s = %s\n"%(k,wv))
            f.write('\n')
            # Save instrument information to file            
            f.write("#Instruments\n")
            for inst in self.test_instrs:
                f.write("%s : %s\n"%(inst,repr(self.test_instrs[inst])))
            # Save module information to file
            f.write('#Device :%s\n'%self.setup['device'])
            f.write('#Test Selection :%s'%self.setup['current_test_selection'])            
            f.close()
            dlg.Destroy()
            logger.log(logging.INFO,"Config Saved")        
        
    def OnCalibrate(self, evt):
        if self.cal_completed:
            dlg = wx.MessageDialog(self, 'Cal Already Performed. Press YES to recalibrate, NO to Exit', 'Warning', wx.YES_NO|wx.ICON_WARNING)
            if dlg.ShowModal() == wx.ID_YES:
                dlg.Destroy()
                self.test_loader.clear_mod_cal(reset = True)
                self._run_cal()
        else:
            self._run_cal()
            
    def _run_cal(self):
                        
        logger.log(logging.INFO, "Running Calibration")
        cal_dict = self.test_loader.get_module_cal_dict()
                
        self.change_status("Running Cal....")
        self.opened_instrs = self.test_loader.load_instrs(self.instrs)
        self.instruments_opened = True
        # Hand the cal dict to the utility and let it do its thing
        cm = CalMain(self,-1, cal_dict,self.test_params.get_param_dict(),self.opened_instrs)
        cm.Show()        
                
    # This method is called when the File Exit button is clicked. It allows the user to exit the program
    def OnExit(self, evt):
        dlg = wx.MessageDialog(self, 'Are You Sure You Want To Exit?', 'Exit', wx.YES_NO|wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlg.Destroy()
            self.Close()
        else:
            dlg.Destroy()
            
    def OnHelp(self, evt):
        dlg = wx.MessageDialog(self, 'This Help menu is currently not implemented', 'Help')
        if dlg.ShowModal() == wx.ID_OK:
            dlg.Destroy()
            
    def OnAbout(self, evt):
        "show the program information dialog"
        wx.AboutBox(about_info)        
                
        
    def OnTestSelect(self, evt):
            
        # Loads the module
        logger.log(logging.INFO, "Loading the module")
        
        # Since the unload module button was removed check if there's a module already loaded first
        # If it is, unload it and then load a fresh module
        if self.module_loaded == True:
            self.UnloadModule()
            self._load_module()
            
        else:
            self._load_module()           
        
        
        
    def _load_module(self):
        self.module_loaded = True
        
        # Store the current test selection as a parameter, will be useful while loading/saving the setup
        self.current_test_selection = self.controls['test_tree'].GetItemText(self.tree_choice)
        self.setup['current_test_selection'] = self.current_test_selection
        
        # Store the current device type as a parameter
        parent = self.controls['test_tree'].GetItemParent(self.tree_choice)
        self.device = self.controls['test_tree'].GetItemText(parent)
        self.setup['device'] = self.device
        
        self.test_loader.load_module(self.device, self.current_test_selection)
        
        # Now get the module docstr and parameters
        self.doc_str = self.test_loader.get_module_docstr()
        self.params = self.test_loader.get_module_params()
        self.test_params = TestParameters(self.params)
        self.cal_flag = self.test_loader.get_module_cal_flag()
        self.instrs = self.test_loader.get_module_instrs()
        self.test_routine = self.test_loader.get_test_routines()
                
        self._update_gui()
        
    def OnRunTest(self,evt):
    
        if self.test_loader.get_module_cal_flag() and not self.cal_completed:
            wx.MessageBox("Perform Calibration First!","Warning",wx.OK)
            
        else:               
        
            dlg = file_header_gui(self.controls,parent = None )        
                    
            # Temporary dictionary that store the file header
            self.file_header = {}                        
                    
            if dlg.ShowModal() == wx.ID_OK:
                for i in ['wafer_name','process_name','device_name','cal_kit_name','temp','comments']:
                    self.file_header[i] = self.controls[i].GetValue()
                dlg.Destroy()
                
            kw = {'style':wx.FD_SAVE|wx.FD_OVERWRITE_PROMPT}
            dlg = wx.FileDialog(None,'Select output data location and file name',**kw)  
            if dlg.ShowModal() == wx.ID_OK:
                self.fname = dlg.GetPath()
                dlg.Destroy()
                
            logger.log(logging.INFO, "Running the Test")
            
            for i in ['run','instrument_setup','multisite_control','calibrate','edit_params','validate','data_display']:
                self.controls[i].Disable()
                
            # Check if instruments have already been opened for the cal
            if not self.instruments_opened:
                self.opened_instrs = self.test_loader.load_instrs(self.instrs)
            
            params = self.test_params.get_param_dict()
            arglist = [params,self.opened_instrs,self.fname,self.file_header,self.test_routine]
            self.new_worker = Worker(self, target = self.test_loader.run_func, args = arglist)
            self.new_worker.start()            
            
            
            self.change_status("Running Test. Please Be Patient or Press Abort!")
            
    def OnWorkerUpdate(self,evt):
        if evt.msgtype == 'update':
            logger.log(logging.INFO, evt.payload)
        # Future data plotting stuff
        if evt.msgtype == 'device fail':
            # Device has failed, get the failure type
            wx.MessageBox('Device Has Failed! %s'%evt.payload,'Error',wx.OK)            
        if evt.msgtype == 'test data':
            print evt.payload
        if evt.msgtype == 'spar data':
            # Get data payload and hand it to the plotter
            pass
        if evt.msgtype == 'dciv data':
            pass
        if evt.msgtype == 'dcs data':
            pass         
        

    def OnTestComplete(self,evt):
        logger.log(logging.INFO, "Test Complete")
        self.new_worker.join()
        self.new_worker = None        
        # Enable all the controls
        for i in ['run','instrument_setup','multisite_control','calibrate','edit_params','validate','data_display']:
            self.controls[i].Enable()
        self.change_status("Test Complete")            
        
                          
    def OnAbort(self,evt):
        self.new_worker.comm.send_to_worker("abort")    
        logger.log(logging.INFO,'Test Aborted!')
        # Re-enable all the controls that were disabled during the test
        for i in ['run','instrument_setup','multisite_control','calibrate','edit_params','validate','data_display']:
            self.controls[i].Enable()     

    def UnloadModule(self):
        self.module_loaded = False
        self.doc_str = None
        self.params = None
        self.cal_flag = None
        self.instrs = None
        self.routines = ['']

    def OnCloseWindow(self,evt):
        # Stuff to do before closing the software
        if self.new_worker:
            wx.MessageBox('Cannot exit while a test is running.Please abort the current test first.','Error',wx.OK)
            evt.Veto()
            return
        try:
            # first check if there is a preferences file
            default_dir = os.path.expanduser('~')
            if sys.platform == "win32":
                default_prefs_file = default_dir+"\\mtacs.prf"
            else:
                default_prefs_file = default_dir+"/mtacs.prf"
            if os.path.exists(default_prefs_file):
                # The default preferences file exists, check to see if the setup file field has been changed
                if self.current_setup != self.setup['setup_file']:
                    self.setup['setup_file'] = self.current_setup
            self.setup.save(fname = default_prefs_file)
        except Exception:
            logger.log(logging.ERROR, "Unable to Save preferences file")                                
                            

        self.Destroy()            

   
        
        