



class TestManager(object):
    """This class manages everything test routine related.  It loads test routines,
    saves test routine configurations, provides an API for modifying the
    parameters of test routines, manages the test controller, and runs test routines.
    
    """
    
    
    
    def __init__(self):
        """Create the test manager."""
        
        # initialize
        
        # test routine modules
        self.__loaded_routines = None
        self.__current_routine = None
        
        # test routine parameters
        self.__test_params = None
        
        
    def load_test_routine(self, routine_name):
        """Load a test routine module by searching for it in a set of
        predefined locations.
        """
        
        
        
        
        
        
    def load_configuration(self, cfgdata):
        """Load configuration data."""
        
        
        
        
        
        
        
        
        
    def save_configuration(self, cfgdata):
        """Save configuration data."""
        
        
        
    
    
    
    def get_parameters():
        """Get a list of parameters for the current test routine."""
        
        
        
        
        
        
    def set_parameters(self,data):
        """Update the test parameters with the passed dictionary."""
        
        
        
        
        
    def reset_parameters():
    

        
        
        
        
        
        
    
    
    
    def run_test():
        
        
        
        
        
        
        
        
    def 