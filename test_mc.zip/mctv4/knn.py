import numpy as np
import math, operator
# Simple K means clustering

def create_data_set(labels=None,data=None):
    # Create a dummy data set
    if labels == None:
        labels = ['a','a','b','b']
    if data == None:
        data = np.array([[1.0,1.0],[1.0,1.1],[0,0],[0,0.1]])
    return labels, data
    
def parse_data_set(f):
    fp = f.open(f,'r')
    flen = len(fp.readlines())
    
    
def classify(inX):
    # Classify incoming data into clusters
    labels,data = create_data_set()
    # Calculate distances
    mapping = []
    for i in range(len(data)):
        dist = math.sqrt((data[i][0]-inX[0])**2+(data[i][1]-inX[1])**2)
        mapping.append((dist,labels[i]))
    mapping.sort()
    # Pick the top two items - 2 cluster, get the class it belongs to
    classified_array = mapping[:2]
    print classified_array
    
def classify0(inX,dataset,labels,k):
    dataSetSize = dataset.shape[0]
    diffMat = np.tile(inX,(dataSetSize,1))-dataset
    sqdiffmat = diffMat**2
    sqdistances = sqdiffmat.sum(axis=1)
    distances = sqdistances**0.5
    sorteddist = distances.argsort()
    classcount = {}
    for i in range(k):
        votelabel = labels[sorteddist[i]]
        classcount[votelabel] = classcount.get(votelabel,0) +1
    sortedclasscount = sorted(classcount.iteritems(), key= operator.itemgetter(1),reverse=True)
    return sortedclasscount[0][0]
    
if __name__== "__main__":
    inX = np.array([1.0,1.5])
    print "Classify1 :\n"
    classify(inX)
    labels,group = create_data_set()
    print "Classify2 :\n"
    print classify0(inX,group,labels,2)
    
    