from mctv4.test_module_loader import register, test_mod_loader
import dc_params

register(dc_params,'MOSFET')