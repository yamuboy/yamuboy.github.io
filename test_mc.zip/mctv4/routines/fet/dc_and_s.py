
"""
This module allows the user to perform a set of DC and S measurements.
The device is biased at to get a full set of DC-IV data and at each bias point,
Full two port S-Parameters are taken. 
It is assumed that the VNA has already been calibrated with the right calibration standards.
Test routine choices are: 1. DC & S --> Exactly the same as MCT's DC&S
                          2. Biased S-Parameters --> S-Parameters taken at bias conditions specified 
                          3. S-Parameters --> No bias control. Just take S Pars off the VNA
                          4. DC Screen--> Exactly the same as MCT's DC Screen
                          5. Full DC Params--> Exactly the same as MCT.
"""
from wxtestgui import parm, ParamPage,ParamGroup, ValidationError, Instr
from instrument import timed_wait_ms
from datetime import datetime
import math
from network_params import Touchstone
from wxtestgui.worker import send_to_ui
from utils import UserAbort, DeviceFailedError, arange
from test_module_loader_1 import check_message_queue
from collections import OrderedDict

# Don't require the cal for this test
CAL_REQD = False
BIAS_WIZARD = False

TEST_PARAMS = [
    ParamPage('FET Parameters',
    ParamGroup('Device Params',
    parm('ngf','float',value = 2,label='Number of Gate Fingers'),
    parm('ugw','float',value = 100,label='Gate Width (um)'),
    parm('gate_length',value = 0.5, label = 'Gate Length (um)'),
    parm('gg_spacing',value = 0, label = 'Gate to Gate Spacing (um)'),
    parm('sd_spacing',value = 0, label = 'Source to Drain Spacing (um)'),
    ),
    ParamGroup('Max Ratings',
    parm('max_vds','float',value = 8.0, label = 'Max Drain Voltage (V)'),
    parm('max_power','float',value = 1,label = 'Max Power (W/mm)'),    
    parm('min_vgs','float', value = -3.0, label = 'Min Gate Voltage (V)'),
    parm('max_vgs','float',value = 2.0, label = 'Max Gate Voltage (V)'),
    parm('max_igs_mamm','float',value = 1.0, label = 'Max Gate Current for Idss(mA/mm)'),
    parm('max_ids_mamm','float',value = 5.0, label = 'Max Drain Current for Idss(mA/mm)'),
    ),
    ),
    ParamPage('DC Parameters',
    ParamGroup('Breakdown,Idss and, Pinchoff Params',
    parm('ibr_low_mamm','float',value = 0.1, label = 'Min Breakdown Current(mA/mm)'),
    parm('ibr_high_mamm','float',value = 1.0,label = 'Max Breakdown Current(mA/mm)'),
    parm('max_vbr','float',value = 10.0,label = 'Max breakdown Voltage(V)'),
    parm('vds_idss','float',value = 5.0,label = 'Drain Voltage for Idss (V)'),
    parm('vds_imax','float',value = 10,label = 'Vds for Imax measurement (V)'),
    parm('igs_imax_mamm','float',value = 1.0, label = 'Max Igs(mA/mm)'),
    parm('vpo_percent','float',value = 2.5, label = 'Vpo Percentage(%)'),
    parm('vpo_current_mamm','float',value = 1, label = 'Vpo Current(mA/mm)'),
    ),
    ),
    ParamPage('DC Parameters (2)',
    parm('fwd_iv_igs','float',value = 1.0, label = 'Forward I-V Max Igs (mA/mm)'),
    parm('coldfet_max_igs','float', value = 10, label = 'Coldfet Max Igs (mA/mm)'),
    parm('coldfet_numpoints','float', value = 5, label = 'Coldfet number of points'),
    parm('spar_vds_step','float', value = 1, label = 'S Param Vds Step (V)'),    
    parm('iv_meas_delay_ms','float', value = 50, label = 'DC-IV Measurement Delay (mS)'),   
    ),
    ParamPage('Enable Tests',
    parm('fwdiv_enable','choice',value = 'yes',choices = [('y','yes'),('n','no')], label = 'Enable FWD IV'),
    parm('ssb_enable','choice', value = 'yes',choices = [('y','yes'),('n','no')], label = 'Enable Single Sided Breakdown'),
    parm('three_term_breakdown_enable','choice', value = 'yes',choices = [('y','yes'),('n','no')], label = 'Enable Three Terminal Breakdown'),
    parm('DCIV_enable','choice',value = 'yes', choices = [('y','yes'),('n','no')], label = 'Enable DCIV'),    
    parm('DC_transfer_enable','choice',value = 'yes', choices = [('y','yes'),('n','no')], label = 'Enable DC Transfer Curve'), 
    parm('coldfet_sparams_enable','choice',value = 'yes', choices = [('y','yes'),('n','no')], label = 'Enable Coldfet S-Pars'),
    parm('active_spars_enable','choice',value = 'yes', choices = [('y','yes'),('n','no')], label = 'Enable Active S-Pars'),   
    ),
    ParamPage('Biased S-Parameters',
    ParamGroup('Gate,Drain Bias',
    parm('iv_gate_voltages','float_list',value = [-3.0,2.1,0.25], label = 'Gate Voltages(V)'),
    parm('iv_drain_voltages','float_list',value = [0.0,30.1, 0.25], label = 'Drain Voltages (V)'),
    parm('biaseds_meas_delay_ms','float', value = 50, label = 'Biased S-Pars Measurement Delay'),
    parm('gate_comp','float',value = 5e-3,label = 'Gate Compliance (mA)'),
    parm('drain_comp','float',value = 200e-3, label = 'Drain Compliance (mA)'),
    ),
   ),    
]

INSTR_LIST = [ 
   Instr('bias1','bias',label='Bias 1'),
   Instr('bias2','bias',label='Bias 2'),
   Instr('vna','vna',label='VNA'),
]

REQUIRED_INSTRS = ['bias1','bias2']
OPTIONAL_INSTRS = ['vna']

def write_header(fname, file_header, params):
    # Convenience method to write data to file
    # preserve the same file format as MCT
    f = open(fname, 'w')
    # Place a comment at the start to help the plotting utility identify the file type
    f.write("!FILE NAME: %s\n"%fname)
    f.write("!WAFER NUMBER: %s\n"%str(file_header['wafer_name']))
    f.write("!PROCESS NAME: %s\n"%str(file_header['process_name']))
    f.write("!DEVICE NAME: %s\n"%str(file_header['device_name']))
    f.write("!GATE PERIPHERY (um): %s\n"%str(periphery))
    f.write("!GATE LENGTH (um): %s\n"%str(params['gate_length']))
    f.write("!UNIT GATE WIDTH (um): %s\n"%str(params['ugw']))
    f.write("!NUMBER OF GATE FINGERS: %s\n"%str(params['ngf']))
    f.write("!GATE TO GATE SPACING (um): %s\n"%str(params['gg_spacing']))
    f.write("!SOURCE-DRAIN SPACING (um): %s\n"%str(params['sd_spacing']))
    f.write("!SOURCE-DRAIN SPACING (um): %s\n"%str(params['sd_spacing']))
    f.write("!CALKIT: %s\n"%str(file_header['cal_kit_name']))
    f.write("!TEMPERATURE (C): %s\n"%str(params['temp']))
    f.write("!DATE AND TIME: %s\n"%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write("!COMMENTS: %s\n"%file_header['comments'])
    return f        
    

### Main Run Function Definition ###
def run_test(params, instrs, fname , file_header, test_routine):
    # Run DC and S measurements
    gate = instrs['bias1']
    drain = instrs['bias2']
    
    
    # Create a mapping of tests and methods     
    t_map = OrderedDict({'ssb_enable':ss_vbr_curve, 'three_term_breakdown_enable': ds_vbr_curve, 
                         'fwdiv_enable': fwd_iv, 'DC_transfer_enable':dc_transfer_curve, 'DCIV_enable':dciv})   
        
    # Simple if else to check which routine the user wants to perform
    
    if test_routine == 'DC Screen':
        f = write_header(fname, file_header, params)
        dc_screen(params, gate, drain, f)
        
    if test_routine == 'Full DC Parameters':
    
        # perform all the dc tests in order staring with the dc screen
        
        f = write_header(fname, file_header, params)
        data = dc_screen(params, gate, drain, f)        
                 
        for test in t_map.iterkeys():
            if params[test] == 'yes':
                t_map[test](data, params, gate, drain, f)       
        
    if test_routine == 'DC and S':
    
        vna = instrs['vna']
        
        f = write_header(fname, file_header, params)
        data = dc_screen(params, gate, drain, f)                      
                 
        for test in t_map.iterkeys():
            if params[test] == 'yes':
                t_map[test](data, params, gate, drain, f)

        # Now perform the coldfet s-pars and full spars if specified
        if params['coldfet_sparams_enable'] == 'yes':
            coldfet_s_params(data, params, gate, drain, vna, f)
        if params['active_spars_enable'] == 'yes':
            fet_dc_and_spars(data, params, gate, drain, vna, f)
        
        
    if test_routine == 'S Parameters':
        
        f = write_header(fname, file_header, params)
        vna = instrs['vna']
        s_params(params, vna, f)
        
    if test_routine == 'Biased S Parameters':
    
        f = write_header(fname, file_header, params)    
        vna = instrs['vna']
        biased_spars(params, gate, drain, vna, f)
        
# Method for ids target search used by dc screen         
def ids_target_search(gate, drain, vds, target, vgstart, vgmin, vgmax, iglimit, idlimit, maxiter=20,
    stepfrac=0.15, successfrac=0.01, failfrac=0.05, stepadj=0.3, minstep=0.002, leaveon=False):
    """this routine targets a drain current for a given set of gate voltage criteria

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    vds - float, drain voltage
    target - float, target Ids current (amps)
    vgstart - float, starting value for Vg
    vgmin - float, minimum Vg limit
    vgmax - float, maximum Vg limit
    iglimit - float, Ig current limit (amps)
    idlimit - float, Id current limit (amps)
    maxiter - int, maximum number of iterations of the targetting loop
    stepfrac - float, fraction of the range (vgmax-vgmin) that is used for the initial step size
    successfrac - float, fraction of the target current that is considered a "success"
    failfrac - float, fraction of the target current that is considered "failure" at the end of
        the targeting loop
    stepadj - float, fraction by which the step size is reduced when the loop overshoots
    minstep - float, minimum Vg step size
    leaveon - bool, leave the gate and drain SMUs on 

    returns: gate voltage value (float)
    """
    if vgstart > vgmax or vgstart < vgmin or vgmin > vgmax:
        raise ValueError("'vgmin' <= 'vgstart' <= 'vgmax': not satisfied")
        
    step = stepfrac*(vgmax-vgmin)
    vg = vgstart

    gate.config(mode='V',vset=vg,ilimit=iglimit,state=1)
    timed_wait_ms(25)
    drain.config(mode='V',vset=vds,ilimit=idlimit,state=1)
    timed_wait_ms(100)
    idm = drain.measure()
    if idm > target:
        step = -step

    try:
        # start the search loop
        count=0
        while count < maxiter:
            if step > 0.0 and vg == vgmax:
                raise ValueError("'vg' is at 'vgmax' (Id_meas = %g, Target = %g)"%(idm,target))
            elif step < 0.0 and vg == vgmin:
                raise ValueError("'vg' is at 'vgmin' (Id_meas = %g, Target = %g)"%(idm,target))

            vg += step
            if vg > vgmax:
                vg = vgmax
            elif vg < vgmin:
                vg = vgmin

            gate.config(vset=vg)
            timed_wait_ms(50)
            idm = drain.measure()

            if abs(idm-target) <= successfrac*target:
                break

            # reduce step and reverse direction for certain conditions
            if (step < 0.0 and idm < target) or (step > 0.0 and idm > target):
                if abs(step) == minstep:
                    # already at min step, just break
                    break
                step *= -stepadj

            # force a minimum step size
            if abs(step) < minstep:
                if step < 0.0:
                    step = -minstep
                else:
                    step = minstep

            count += 1

        if abs(idm-target) > failfrac*target:
            # more than 5% error, raise error
            raise ValueError("current targeting failed (Vg = %g, Id = %g, Target = %g)"%(vg,idm,target))

        if not leaveon:
            timed_wait_ms(20)
            drain.config(state=0)
            timed_wait_ms(50)
            gate.config(state=0)
                
    except ValueError:
        timed_wait_ms(20)
        drain.config(state=0)
        timed_wait_ms(50)
        gate.config(state=0)        
        raise
        
    return vg
        
def dc_screen(params, gate, drain, f):
    # Perform the DC screen test
    data = {} 
        
    periphery = params['ugw'] * params['ngf']
    
    vgs_start = params['min_vgs']
    
        
    try:
        
        if params['three_term_breakdown_enable'] == 'yes':
        
            check_message_queue()
            
            ### Dual Sided Breakdown            
            
            send_to_ui("update","3-Terminal Breakdown")            
            
            drain.config(mode = 'v', vset = 0.0, ilimit =  params['ibr_high_mamm']*periphery*4.0e-6, resolution = 'high', state = 1)
            gate.config(mode = 'I', iset = -math.fabs(params['ibr_low_mamm']*1.0e-6*periphery), vlimit = params['max_vbr'], resolution = 'high', state = 1)
            
            data['vbr_ds_lo'] = gate.measure()
            
            gate.config(mode = 'I', iset = -math.fabs(params['ibr_high_mamm']*1.0e-6*periphery), vlimit = params['max_vbr'], resolution = 'high', state = 1)
            data['vbr_ds_hi'] = gate.measure()

            gate.config(state = 0)
            drain.config(state = 0)
            
            if vgs_start < 0.8*data['vbr_ds_hi']:
                vgs_start = 0.8*data['vbr_ds_hi']
                
                
        if params['ssb_enable'] == 'yes':
        
            check_message_queue()
        
            ### Single Sided Breakdown Test ###       
            gate_c = periphery * params['ibr_high_mamm']* 4.0e-6
            drain_c = params['max_vbr'] + params['min_vgs']
        
            
            send_to_ui("update","Performing Single Sided Breakdown")
            gate.config(mode='V',vset=params['min_vgs'],ilimit=gate_c,state=1,resolution='very high')
            timed_wait_ms(25)
            drain.config(mode='I',iset=params['ibr_low_mamm']*1.0e-6*periphery,vlimit=drain_c,state=1,resolution='very high')
            timed_wait_ms(1000)
            test_data['vbr_ss_low'] = params['min_vgs'] - drain.measure()

            drain.config(iset=params['ibr_high_mamm']*1e-6*periphery)
            timed_wait_ms(1000)
            data['vbr_ss_high'] = params['min_vgs'] - drain.measure()
            
            drain.set_state(0)
            timed_wait_ms(50)        
        
        ###Idss ###
        
        gate_c = params['max_igs_mamm']*1.0e-6*periphery
        drain_c = params['max_ids_mamm']*1.0e-6*periphery 
        
        send_to_ui("update","Idss Measurement")
        
        gate.config(vset=0.0,ilimit=gate_c)
        timed_wait_ms(25)
        drain.config(mode='V',vset=params['vds_idss'],ilimit=drain_c,state=1)
        timed_wait_ms(100)
        data['idss'] = drain.measure()
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)
        
        #### Imax / Vmax ####

        send_to_ui("update"," Imax Measurement ")
        gate.config(mode='I',iset=params['igs_imax_mamm']*1.0e-6*periphery,vlimit=params['max_vgs'],state=1)
        timed_wait_ms(25)
        drain.config(vset=params['vds_imax'],state=1)
        timed_wait_ms(100)
        data['vmax'] = gate.measure()
        data['imax'] = drain.measure()
        open_gate = gate.limiting
        shorted_chan = drain.limiting
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

        #### Checks for failed devices ####
        
        if open_gate:
            send_to_ui("device fail","gate is open-circuited")
            raise DeviceFailedError
        elif data['vmax'] < 0.5:
            send_to_ui("device fail","gate is short-circuited")
            raise DeviceFailedError
        elif data['imax'] < 10.0e-6*periphery:
            send_to_ui("device fail","channel is open-circuited")
            raise DeviceFailedError            
        elif shorted_chan:
            send_to_ui("device fail","channel is open-circuited")
            raise DeviceFailedError

        #### Vpo measurement ####
        
        check_message_queue()
        
        # Vpo - % of Idss (IMax for E-FET )
        
        send_to_ui("update"," Pinchoff measurement @ Vds for Idss")
        
        if data['idss'] < 0.05*data['imax']:
            target_ids = 0.01*params['vpo_percent']*data['imax']
        else:
            target_ids = 0.01*params['vpo_percent']*data['idss']
        
        gate.config(resolution='medium')
        drain.config(resolution='medium')
        data['vpo'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
            
        #### Vpo Measurement at Vds for IMax ####

        send_to_ui("update"," Pinchoff Measurement for Vds@ Imax...")    
        
        data['vpo_imax'] = ids_target_search(gate,drain,params['vds_imax'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
            
        #### Vpo measurement mA/mm ####

        send_to_ui("update"," Pinchoff Measurement mA/mm ")
        
        target_ids = params['vpo_current_mamm']*1e-6*periphery
        data['vpo_mamm'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
            
        ### Ron measurement ###
        check_message_queue()
        
        send_to_ui("update","Ron Measurement")
        if data['vpo'] < 0.0:
            # D-FET
            vset = 0.02
            gate.config(mode='V',vset=0.0,ilimit=gate_c,state=1,resolution='very high')
            timed_wait_ms(25)
            drain.config(mode='V',vset=vset,ilimit=drain_c,state=1,resolution='very high')
            timed_wait_ms(1000)
            data['ron'] = vset/drain.measure()
            drain.set_state(0)
            timed_wait_ms(25)
            gate.set_state(0)
            timed_wait_ms(10)
            
        else:
            # E-FET #
            # Set vgs = 0.7, vds = 0.02
            gate.config(mode='V',vset=0.7,ilimit=gate_c,state=1,resolution='very high')
            timed_wait_ms(25)
            drain.config(mode='V',vset= 0.02,ilimit=drain_c,state=1,resolution='very high')
            timed_wait_ms(1000)
            data['ron'] = 0.02/drain.measure()
            drain.set_state(0)
            timed_wait_ms(25)
            gate.set_state(0)
            timed_wait_ms(10)

        # Write the data, maintain the same format as MCT
        f.write("!\t\t\t\t\t DC FET PARAMETERS\n")
        f.write("!Vbr (%smA) \t Vbr (%smA) \t Idss (3V) \t Vpo (3V) \t Imax (1.5V) \t Vpo (1.5V) \t Vmax (1.5V) \t Vpo (1mA/mm) \t Ron (ohms)\n"%(params['ibr_low_mamm'],params['ibr_high_mamm']))
        params = ('vbr_ss_low','vbr_ss_high','idss','vpo','imax','vpo_imax','vmax','vpo_mamm','ron')
        vals = []
        for p in params:
            vals.append('%+.4e'%data.get(p,0.0))
        f.write("%s"%('\t'.join(vals)))
        f.write("\n")
        
        return data                
        
    except (UserAbort,DeviceFailedError,ValueError):
        pass 
        
    finally:
        timed_wait_ms(25)
        drain.config(state = 0)
        timed_wait_ms(25)
        gate.config(state = 0)
        timed_wait_ms(10)       


def dciv(data, params, gate, drain, f):
    # Perform the DCIV Test
    
    send_to_ui("update","I-V Curves")
    
    f.write("!\t\t\t DC IV-CURVES\n")
    f.write("!   Vds     Ids    Vgs     Igs \n")
    f.write("! (Volts) (Amps) (Volts) (Amps)\n")
    
    
    periphery = params['ugw'] * params['ngf']
    
    vgs_list = []
    vds_list = []
    step = 0.05*math.floor(2.0*(data['vmax'] - data['vpo'])+0.5)
    if step < 0.05:
        step = 0.05
    start = step*math.floor(data['vpo']/step - 3.0)
    stop = step*math.floor(data['vmax']/step + 0.01)
    
    # Vgs list    
    vg_points = 0
    vgs = start
    while vgs < stop:
        if vg_points >= 50:
            break
        vgs_list.append(vgs)
        vgs+= step
        vg_points+= 1
        
        
    # Vds list
    vds_list = [arange(0.0,1.01,0.1),arange(1.2,2.01,0.2)]
    vd_points = len(vds_list)
    vds = 2.5
    while vds < params['max_vds']+0.01:
        if vd_points >= 100:
            break 
        vds_list.append(vds)
        if vds < 5.0:
            step = 0.5
        else:
            step = 1.0
        vds+= step
        vd_points+= 1
        
    # perform IV curves sweep
    gate_c = params['max_igs_mamm']*1.0e-6*periphery
    drain_c = params['max_ids_mamm']*1.0e-6*periphery
    power_limit = params['max_power']
    
    gate.config(mode = 'v', ilimit = gate_c, resolution = 'medium', remote = True)
    drain.config(mode = 'v', ilimit = drain_c, resolution = 'medium', remote = True)
    
    try:    
    
        for gv in vgs_list:
            first = True
            check_message_queue()
            for dv in vds_list:
                # Compute power limit
                dv2 = abs(dv) + 0.001
                ilimp = power_limit / dv2
                ilim2 = drain_c
                if ilimp < drain_c:
                    ilim2 = ilimp
                    
                gate.config(vset = gv)
                drain.config(vset = dv, ilimit = ilim2)
                
                if first:
                    # turn on the supplies
                    gate.set_state(1)
                    timed_wait_ms(50)
                    drain.set_state(1)
                    first = False
                    
                timed_wait_ms(params['iv_meas_delay_ms'])
                gc = gate.measure()
                dc = drain.measure()
                
                # Check for limiting conditions
                if gate.ask_if_limiting():
                    continue
                if drain.ask_if_limiting():
                    break
                    
                f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(dv,dc,gv,gc))
            f.write("\n")         
        
                    
    except UserAbort:
        pass 
        
    finally:
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)
        
        
def fwd_iv(data, params, gate, drain, f):

    send_to_ui("update", "Forward I-V Curve")
    
    periphery = params["ugw"]*params["ngf"]
    
    stop = params["fwd_iv_igs"]*1.0e-6*periphery
    if stop > 0.1:
        stop = 0.1
    start = 0.001*stop
    start = math.log10(start)
    stop = math.log10(stop) + 0.1
    step = 0.25
    
    drain_c = params['fwd_iv_igs']*5.0e-6*periphery
    gate_c = params['max_vgs']
    
    drain.config(mode = 'v', vset = 0.0, ilimit = drain_c, resolution = 'high', remote = True, state = 1)
    timed_wait_ms(50)
    gate.config(mode = 'I', iset = 0.0, vlimit = gate_c, resolution = 'high', remote = True , state = 1)
    
    f.write("!\t\t\t FORWARD IV-CURVES \n")
    f.write("!   Vds     Ids      Vgs     Igs\n")
    f.write("! (Volts)  (Amps)  (Volts)  (Amps)\n")
            
    
    try:
        v = start
        while v < (stop + 0.1*step):
            check_message_queue()
            igs = 10**v           
            gate.config(iset = igs)
            if (v == start):
                timed_wait_ms(1000)
            v+= step
            ids = drain.measure()
            vgs = gate.measure()
            
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(0.0,ids,vgs,igs))
            
    except UserAbort:
        pass 
        
    finally:
        gate.set_state(0)
        timed_wait_ms(100)
        drain.set_state(0)

def ds_vbr_curve(data, params, gate, drain, f):

    ### Three terminal breakdown measurement ###
    
    send_to_ui("update", "3-Terminal Breakdown")
    
    stop = math.floor(10.0*data['vbr_ds_hi']*0.1)
    step = stop * 0.025
    stop += 0.5*step
    
    periphery = params['ugw']*params['ngf']
    
    gate_c = math.fabs(params['ibr_high_mamm'])*1.0e-6*periphery
    drain_c = 5.0*gate_c

    stop = math.floor(10.0*data['vbr_ds_hi'])*0.1
    step = stop * 0.025
    stop+= 0.5*step
    
    drain.config(mode = 'v', vset = 0.0, ilimit = drain_c, resolution = 'high', remote = True)
    timed_wait_ms(params['iv_meas_delay_ms'])
    gate.config(mode = 'v', vset = step, ilimit = gate_c, resolution = 'high', remote = True)

    f.write("!\t\t\t 3-TERMINAL BREAKDOWN IV-CURVES\n")
    f.write("!    Vds     Ids      Vgs     Igs\n")
    f.write("!  (Volts)  (Amps)  (Volts)  (Amps)\n")
        
        
    try:
        v = step
        while (v < stop):
            check_message_queue()
            drain.set_state(1)
            timed_wait_ms(100)
            gate.config(vset = v, state = 1)
            if drain.ask_if_limiting():
                break
            elif gate.ask_if_limiting():
                break
            ids = drain.measure()
            igs = gate.measure()
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(0.0,ids,v,igs))
            timed_wait_ms(params['iv_meas_delay_ms'])   

            v += step
                        
            
    except UserAbort:
        pass 
        
    finally:
        gate.set_state(0)
        timed_wait_ms(100)
        drain.set_state(0)
        
def ss_vbr_curve(data, params, gate, drain, f):
    
    ### SS Breakdown Curves ###
    send_to_ui("update","SS vbr curve")
    
    f.write("!\t\t\t BREAKDOWN IV-CURVES\n")
    f.write("!    Vds     Ids      Vgs     Igs\n")
    f.write("!  (Volts)  (Amps)  (Volts)  (Amps)\n")
    
    stop = 0.1*math.floor(10.0*math.fabs(data['vbr_ss_high']))
    step = stop * 0.025
    start = params['min_vgs'] + 0.5 - data['vpo_mamm']
    stop += params['min_vgs'] + 0.5*step
    
    periphery = params['ugw']*params['ngf']
    
    gate_c = math.fabs(params['ibr_high_mamm'])*1.0e-6*periphery
    drain_c = 10.0*gate_c
    
    v = start
    
    gate.config(mode = 'v', vset = params['min_vgs'], ilimit = gate_c, resolution = 'high', remote = True)
    timed_wait_ms(100)
    drain.config(mode = 'v', vset = v, ilimit = drain_c, resolution = 'high', remote = True)
    
    try:   
    
        while (v < stop):
            check_message_queue()
            gate.set_state(1)
            timed_wait_ms(100)
            drain.config(vset = v, state = 1)
            
            igs = gate.measure()
            ids = drain.measure()            
            
            if gate.ask_if_limiting(): 
                break
            elif drain.ask_if_limiting():
                break
                
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(v,ids,params['min_vgs'],igs))            
            v += step
            
    except UserAbort:
        pass 
        
    finally:
        drain.set_state(0)
        timed_wait_ms(100)
        gate.set_state(0)
        
def dc_transfer_curve(data, params, gate, drain, f):

    periphery = params['ugw']*params['ngf']
    
    gate_c = params['max_igs_mamm']*1.0e-6*periphery
    drain_c = params['max_ids_mamm']*1.0e-6*periphery
    
    v = params['min_vgs']
    
    step = 0.05
    
    gate.config(mode = 'v', vset = v, ilimit = gate_c, resolution = 'high', remote = True)
    timed_wait_ms(100)
    drain.config(mode = 'v', vset = params['vds_idss'], ilimit = drain_c, resolution = 'high', remote = True)
    
    f.write("!\t\t\t DC TRANSFER CURVES\n")
    f.write("!    Vds     Ids      Vgs     Igs\n")
    f.write("!  (Volts)  (Amps)  (Volts)  (Amps)\n")
        
    try:
        while (v < data['vmax']):
            check_message_queue()
            gate.config(vset = v, state = 1)
            timed_wait_ms(100)
            drain.config(state = 1)
            
            igs = gate.measure()
            ids = drain.measure()
            
            if gate.ask_if_limiting():
                break
            elif drain.ask_if_limiting():
                break 
            
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(params['vds_idss'],ids,v,igs))  
            v += step
            
    except UserAbort:
        pass 
        
    finally:
        drain.set_state(0)
        timed_wait_ms(100)
        gate.set_state(0)
        
def coldfet_s_params(data, params, gate, drain, vna, f):
    
    send_to_ui("update", "Cold -FET S-Parameters")
    
    periphery = params['ugw']*params['ngf']
    
    stop = params['coldfet_max_igs']*1.0e-6*periphery
    if stop > 0.1:
        stop = 0.1
    step = stop/ float(params['coldfet_numpoints'])
    
    drain_c = 5.0*stop
    gate_c = params['max_vgs']
    stop += 0.5*step
    
    f.write("!\t\t\t   COLD FET S-PARAMETERS\n")
    
    ig = step 
    
    drain.config(mode = 'V', vset = 0.0, ilimit = drain_c, resolution = 'high', remote = True)
    timed_wait_ms(100)
    gate.config(mode = 'I', iset = ig, vlimit = gate_c, resolution = 'high', remote = True)
    
    
    try:   
    
        while (ig < stop):
            drain.set_state(1)
            timed_wait_ms(100)
            gate.config(iset = ig, state = 1)
            
            vgs = gate.measure()
            ids = drain.measure()
            
            if gate.ask_if_limiting() or drain.ask_if_limiting():
                f.write("!**BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(0.0, ids, vgs, igs))
                break
            
            # Get the spars and write it to file
                
            ts = Touchstone()
            ts.header = '!BIAS: VDS = %0.3f Volts IDS = %0.4e Amps VGS = %0.3f Volts IGS = %0.4e Amps\n!\n'%(0.0,ids,vgs,ig)
            ts.format = '# s hz %s r 50'
            vna.initiate()
            vna.ask_if_done()
            f_list = vna.get_flist()
            data = vna.fetch()
            for i,f in enumerate(f_list):
                ts.insert(f,[data[0][i],data[1][i],data[2][i],data[3][i]])
            ts.write(f)
            f.flush()
            
            ig += step
            timed_wait_ms(params['iv_meas_delay_ms'])
                        
            
    except UserAbort:
        pass 
    
    finally:
        drain.set_state(0)
        timed_wait_ms(100)
        gate.set_state(0)

def fet_dc_and_spars(data, params, gate, drain, vna, f):

    vds_list = []
    
    if params['three_term_breakdown_enable'] == 'yes':
        min_v = 0.8*data['vbr_ds_lo']
    else:
        min_v = params['min_vgs']
        
    if min_v == params['min_vgs']:
        if params['ssb_enable'] == 'yes':
            min_v = 0.5*data['vbr_ss_low']
        else:
            min_v
            
    step = 0.025*math.floor(2.0*(data['vmax']-data['vpo']) + 0.5)
    if step < 0.025:
        step = 0.025
    start = step * math.floor(data['vpo']/step - 6.0)
    stop = step * math.floor(data['vmax']/step + 0.01)
    
    f.write("!\t\t\t\t   FET S-PARAMETERS\n")
    
    send_to_ui("update", "DC and S-Parameters")
    
    vds_list[0] = 0.0
    vds_list[1] = 0.5
    n_vds = 2
    vds = 1.0
    
    while (vds < (params['max_vds'] + 0.5*params['spar_vds_step'])):
        if n_vds >= 100:
            break 
        vds_list.append(vds)
        vds += params['spar_vds_step']
        n_vds += 1
        
    periphery = params['ugw']*params['ngf']
        
    max_pow = params['max_pow']*1.0e-3*periphery
    drain_c = params['max_ids_mamm']*1.0e-6*periphery
    gate_c = params['max_igs_mamm']*1.0e-6*periphery
    if params['ssb_enable'] == 'yes':
        max_vdg = 0.8*data['vbr_ss_high']
    else:
        max_vdg = 100.0
        
    step1 = 0.1*(start - min_v)
    if (step1 < 0.1):
        min_v = start - 1.0
        step1 = 0.1
        
        
    try:
        vg = min_v
        while (vg < start-0.5*step1):
            
            check_message_queue()
            
            send_to_ui("update", "Switch Mode ")
            
            gate.config(mode = 'v', vset = vg, ilimit = gate_c, resolution = 'high', remote = True, state = 1)
            timed_wait_ms(100)
            drain.config(mode = 'v', vset = 0.0, ilimit = drain_c, resolution = 'high', remote = True, state = 1)
            
            igs = gate.measure()
            ids = drain.measure()
            
            if gate.ask_if_limiting() or drain.ask_if_limiting():
                f.write("!**BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(0.0, ids, vg, igs))
                break
                
            ts = Touchstone()
            ts.header = '!BIAS: VDS = %0.3f Volts IDS = %0.4e Amps VGS = %0.3f Volts IGS = %0.4e Amps\n!\n'%(0.0,ids,vg,igs)
            ts.format = '# s hz %s r 50'
            vna.initiate()
            vna.ask_if_done()
            f_list = vna.get_flist()
            data = vna.fetch()
            for i,f in enumerate(f_list):
                ts.insert(f,[data[0][i],data[1][i],data[2][i],data[3][i]])
            ts.write(f)
            f.flush()
            
            vg += step1
            timed_wait_ms(params['iv_meas_delay_ms'])
            
    except UserAbort:
        pass 
        
    finally:
        gate.set_state(0)
        timed_wait_ms(100)
        drain.set_state(0)
        
    # Measure the bias plane
    vg_list = arange(start,stop+0.5*step,step)
    
    
    try:
        for gv in vg_list:
            check_message_queue()
            
            for dv in vd_list:
                send_to_ui("update", "active mode")
                
                if dv != 0.0:
                    drain_compl = max_pow/dv
                else:
                    drain_compl = 1.0e12
                    
                if drain_c < drain_compl:
                    drain_compl = drain_c
                    
                gate.config(mode = 'v', vset = gv, ilimit = gate_c, resolution = 'high', remote = True, state = 1)
                timed_wait_ms(100)
                drain.config(mode = 'v', vset = dv, ilimit = drain_compl, resolution = 'high', remote = True , state = 1)
                
                igs = gate.measure()
                ids = drain.measure()
                
                if gate.ask_if_limiting() or drain.ask_if_limiting():
                    f.write("!**BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(dv, ids, gv, igs))
                    
                if gate.ask_if_limiting():
                    continue
                    
                if drain.ask_if_limiting():
                    break
                    
                ts = Touchstone()
                ts.header = '!BIAS: VDS = %0.3f Volts IDS = %0.4e Amps VGS = %0.3f Volts IGS = %0.4e Amps\n!\n'%(dv,ids,gv,igs)
                ts.format = '# s hz %s r 50'
                vna.initiate()
                vna.ask_if_done()
                f_list = vna.get_flist()
                data = vna.fetch()
                for i,f in enumerate(f_list):
                    ts.insert(f,[data[0][i],data[1][i],data[2][i],data[3][i]])
                ts.write(f)
                f.flush()
                
                # 300ms delay after each sweep to allow devices that might have weak
                # oscillations to die out
                
                timed_wait_ms(300)
    
    except UserAbort:
        pass 
        
    finally:
        drain.set_state(0)
        timed_wait_ms(100)
        gate.set_state(0)
        
def s_params(params, vna, f):
    # Just perform simple s-params 
    # grab whatever's on the screen
    
    send_to_ui("update", "Generic S-Parameters")    
    
    ts = Touchstone()
    ts.header = '!\t\t S-Parameters'
    ts.format = '# s hz %s r 50'
    vna.initiate()
    vna.ask_if_done()
    f_list = vna.get_flist()
    data = vna.fetch()
    for i,f in enumerate(f_list):
        ts.insert(f,[data[0][i],data[1][i],data[2][i],data[3][i]])
    ts.write(f)
    f.flush()
    
def biased_spars(params, gate, drain, vna, f):
    # Just get the list of gate and drain voltages and limits from the params
    # and take s-par measurements
    
    send_to_ui("update", "Performing biased S-Parameters")
    
    gv_list = params['iv_gate_voltages']
    dv_list = params['iv_drain_voltages']
    
    f.write("!\t\t\t BIASED S-PARAMETERS\n")
    
    
    try:
        for gv in gv_list:
            check_message_queue()
            for dv in dv_list:
                gate.config(mode = 'v', vset = gv, ilimit = params['gate_comp'], resolution = 'high', remote = True, state = 1)
                timed_wait_ms(100)
                drain.config(mode = 'v', vset = dv, ilimit = params['drain_comp'], resolution = 'high', remote = True, state = 1)
                
                if gate.ask_if_limiting() or drain.ask_if_limiting():
                    break
                    
                igs = gate.measure()
                ids = drain.measure()
                    
                ts = Touchstone()
                ts.header = '!BIAS: VDS = %0.3f Volts IDS = %0.4e Amps VGS = %0.3f Volts IGS = %0.4e Amps\n!\n'%(dv,ids,gv,igs)
                ts.format = '# s hz %s r 50'
                vna.initiate()
                vna.ask_if_done()
                f_list = vna.get_flist()
                data = vna.fetch()
                for i,f in enumerate(f_list):
                    ts.insert(f,[data[0][i],data[1][i],data[2][i],data[3][i]])
                ts.write(f)
                f.flush()
                    
                    
                timed_wait_ms(params['biaseds_meas_delay_ms'])
                
    except UserAbort:
        pass
        
    finally:
        drain.set_state(0)
        timed_wait_ms(100)
        gate.set_state(0) 

    
    
RUN_FUNCTION = run_test
# Routines defined
ROUTINES = ['DC Screen','Full DC Parameters','DC and S','S Parameters','Biased S Parameters']
       
       
       
   
   
   

