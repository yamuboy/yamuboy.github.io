"""
This module performs a noise parameter measurement. 
It uses the PXA with the noise parameter option.
The user can perform a full noise params sweep or specify a set of bias points.
"""
from wxtestgui import parm, ParamPage,ParamGroup, ValidationError, Instr
from instrument import timed_wait_ms
from datetime import datetime
import math
from wxtestgui.worker import send_to_ui
from test_module_loader_1 import check_message_queue
from utils import UserAbort, arange

CAL_REQD = False
BIAS_WIZARD = False

TEST_PARAMS = [
    ParamPage('FET Parameters',
    ParamGroup('Device Params',
    parm('ngf','float',value = 2,label='Number of Gate Fingers'),
    parm('ugw','float',value = 100,label='Gate Width (um)'),
    parm('gate_length',value = 0.5, label = 'Gate Length (um)'),
    parm('gg_spacing',value = 0, label = 'Gate to Gate Spacing (um)'),
    parm('sd_spacing',value = 0, label = 'Source to Drain Spacing (um)'),
    ),
    ParamGroup('Max Ratings',
    parm('max_vds','float',value = 8.0, label = 'Max Drain Voltage (V)'),
    parm('max_power','float',value = 1,label = 'Max Power (W/mm)'),    
    parm('min_vgs','float', value = -3.0, label = 'Min Gate Voltage (V)'),
    parm('max_vgs','float',value = 2.0, label = 'Max Gate Voltage (V)'),
    parm('max_igs_mamm','float',value = 1.0, label = 'Max Gate Current for Idss(mA/mm)'),
    parm('max_ids_mamm','float',value = 5.0, label = 'Max Drain Current for Idss(mA/mm)'),
    ),
    ),
    ParamPage('DC Parameters',
    ParamGroup('Breakdown,Idss and, Pinchoff Params',
    parm('ibr_low_mamm','float',value = 0.1, label = 'Min Breakdown Current(mA/mm)'),
    parm('ibr_high_mamm','float',value = 1.0,label = 'Max Breakdown Current(mA/mm)'),
    parm('max_vbr','float',value = 10.0,label = 'Max breakdown Voltage(V)'),
    parm('vds_idss','float',value = 5.0,label = 'Drain Voltage for Idss (V)'),
    parm('vds_imax','float',value = 10,label = 'Vds for Imax measurement (V)'),
    parm('igs_imax_mamm','float',value = 1.0, label = 'Max Igs(mA/mm)'),
    parm('vpo_percent','float',value = 2.5, label = 'Vpo Percentage(%)'),
    parm('vpo_current_mamm','float',value = 1, label = 'Vpo Current(mA/mm)'),
    parm('fwd_iv_igs','float',value = 1.0, label = 'Forward I-V Max Igs (mA/mm)'),
    parm('noisepars_vds_step','float', value = 1, label = 'S Param Vds Step (V)'),        
    ),
    ),
    ParamPage('Biased Noise Parameters',
    ParamGroup('Gate,Drain Bias',
    parm('biased_noise_enable','choice',value = 'no', choices = [('y','yes'),('n','no')],label = 'Enable Biased Noise'),
    parm('gate_voltages','float_list',value = [-3.0,2.1,0.25], label = 'Gate Voltages(V)'),
    parm('drain_voltages','float_list',value = [0.0,30.1, 0.25], label = 'Drain Voltages (V)'),
    parm('noise_meas_delay_ms','float', value = 50, label = 'Biased S-Pars Measurement Delay'),
    parm('gate_comp','float',value = 5e-3,label = 'Gate Compliance (mA)'),
    parm('drain_comp','float',value = 200e-3, label = 'Drain Compliance (mA)'),
    ),
   ),    
]

INSTR_LIST = [
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('nfmeter','sa',label='Noise Figure Meter')
]

def write_header(fname, file_header, params):
    # Convenience method to write data to file
    # preserve the same file format as MCT
    f = open(fname, 'w')
    # Place a comment at the start to help the plotting utility identify the file type
    f.write("!FILE NAME: %s\n"%fname)
    f.write("!WAFER NUMBER: %s\n"%str(file_header['wafer_name']))
    f.write("!PROCESS NAME: %s\n"%str(file_header['process_name']))
    f.write("!DEVICE NAME: %s\n"%str(file_header['device_name']))
    f.write("!GATE PERIPHERY (um): %s\n"%str(periphery))
    f.write("!GATE LENGTH (um): %s\n"%str(params['gate_length']))
    f.write("!UNIT GATE WIDTH (um): %s\n"%str(params['ugw']))
    f.write("!NUMBER OF GATE FINGERS: %s\n"%str(params['ngf']))
    f.write("!GATE TO GATE SPACING (um): %s\n"%str(params['gg_spacing']))
    f.write("!SOURCE-DRAIN SPACING (um): %s\n"%str(params['sd_spacing']))
    f.write("!SOURCE-DRAIN SPACING (um): %s\n"%str(params['sd_spacing']))
    f.write("!CALKIT: %s\n"%str(file_header['cal_kit_name']))
    f.write("!TEMPERATURE (C): %s\n"%str(params['temp']))
    f.write("!DATE AND TIME: %s\n"%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write("!COMMENTS: %s\n"%file_header['comments'])
    return f   

def run_test(params, instrs, fname, file_header, routine):
    # Perform the noise figure measurement
    
    gate = instrs['gate']
    drain = instrs['drain']
    nfm = instrs['nfmeter']    
        
    if params['biased_noise_enable'] == 'yes':
        f = write_header(fname, file_header, params)
        biased_noise_params(params, gate, drain, nfm, f)
                
    else:
        # perform dc screen and then the full noise parameter sweep
        f = write_header(fname, file_header, params)
        data = dc_screen(params, gate, drain, f)
        fet_noise_figure_sweep(data, params, gate, drain, nfm, f)
                
        
# Method for ids target search used by dc screen         
def ids_target_search(gate, drain, vds, target, vgstart, vgmin, vgmax, iglimit, idlimit, maxiter=20,
    stepfrac=0.15, successfrac=0.01, failfrac=0.05, stepadj=0.3, minstep=0.002, leaveon=False):
    """this routine targets a drain current for a given set of gate voltage criteria

    gate - `instrument.GenericInstrument`-derived object, gate SMU
    drain - `instrument.GenericInstrument`-derived object, drain SMU
    vds - float, drain voltage
    target - float, target Ids current (amps)
    vgstart - float, starting value for Vg
    vgmin - float, minimum Vg limit
    vgmax - float, maximum Vg limit
    iglimit - float, Ig current limit (amps)
    idlimit - float, Id current limit (amps)
    maxiter - int, maximum number of iterations of the targetting loop
    stepfrac - float, fraction of the range (vgmax-vgmin) that is used for the initial step size
    successfrac - float, fraction of the target current that is considered a "success"
    failfrac - float, fraction of the target current that is considered "failure" at the end of
        the targeting loop
    stepadj - float, fraction by which the step size is reduced when the loop overshoots
    minstep - float, minimum Vg step size
    leaveon - bool, leave the gate and drain SMUs on 

    returns: gate voltage value (float)
    """
    if vgstart > vgmax or vgstart < vgmin or vgmin > vgmax:
        raise ValueError("'vgmin' <= 'vgstart' <= 'vgmax': not satisfied")
        
    step = stepfrac*(vgmax-vgmin)
    vg = vgstart

    gate.config(mode='V',vset=vg,ilimit=iglimit,state=1)
    timed_wait_ms(25)
    drain.config(mode='V',vset=vds,ilimit=idlimit,state=1)
    timed_wait_ms(100)
    idm = drain.measure()
    if idm > target:
        step = -step

    try:
        # start the search loop
        count=0
        while count < maxiter:
            if step > 0.0 and vg == vgmax:
                raise ValueError("'vg' is at 'vgmax' (Id_meas = %g, Target = %g)"%(idm,target))
            elif step < 0.0 and vg == vgmin:
                raise ValueError("'vg' is at 'vgmin' (Id_meas = %g, Target = %g)"%(idm,target))

            vg += step
            if vg > vgmax:
                vg = vgmax
            elif vg < vgmin:
                vg = vgmin

            gate.config(vset=vg)
            timed_wait_ms(50)
            idm = drain.measure()

            if abs(idm-target) <= successfrac*target:
                break

            # reduce step and reverse direction for certain conditions
            if (step < 0.0 and idm < target) or (step > 0.0 and idm > target):
                if abs(step) == minstep:
                    # already at min step, just break
                    break
                step *= -stepadj

            # force a minimum step size
            if abs(step) < minstep:
                if step < 0.0:
                    step = -minstep
                else:
                    step = minstep

            count += 1

        if abs(idm-target) > failfrac*target:
            # more than 5% error, raise error
            raise ValueError("current targeting failed (Vg = %g, Id = %g, Target = %g)"%(vg,idm,target))

        if not leaveon:
            timed_wait_ms(20)
            drain.config(state=0)
            timed_wait_ms(50)
            gate.config(state=0)
                
    except ValueError:
        timed_wait_ms(20)
        drain.config(state=0)
        timed_wait_ms(50)
        gate.config(state=0)        
        raise
        
    return vg
        
        
def dc_screen(params, gate, drain, f):
    # Perform the DC screen test
    data = {} 
        
    periphery = params['ugw'] * params['ngf']
    
    vgs_start = params['min_vgs']
    
        
    try:
        
        if params['three_term_breakdown_enable'] == 'yes':
        
            check_message_queue()
            
            ### Dual Sided Breakdown            
            
            send_to_ui("update","3-Terminal Breakdown")            
            
            drain.config(mode = 'v', vset = 0.0, ilimit =  params['ibr_high_mamm']*periphery*4.0e-6, resolution = 'high', state = 1)
            gate.config(mode = 'I', iset = -math.fabs(params['ibr_low_mamm']*1.0e-6*periphery), vlimit = params['max_vbr'], resolution = 'high', state = 1)
            
            data['vbr_ds_lo'] = gate.measure()
            
            gate.config(mode = 'I', iset = -math.fabs(params['ibr_high_mamm']*1.0e-6*periphery), vlimit = params['max_vbr'], resolution = 'high', state = 1)
            data['vbr_ds_hi'] = gate.measure()

            gate.config(state = 0)
            drain.config(state = 0)
            
            if vgs_start < 0.8*data['vbr_ds_hi']:
                vgs_start = 0.8*data['vbr_ds_hi']
                
                
        if params['ssb_enable'] == 'yes':
        
            check_message_queue()
        
            ### Single Sided Breakdown Test ###       
            gate_c = periphery * params['ibr_high_mamm']* 4.0e-6
            drain_c = params['max_vbr'] + params['min_vgs']
        
            
            send_to_ui("update","Performing Single Sided Breakdown")
            gate.config(mode='V',vset=params['min_vgs'],ilimit=gate_c,state=1,resolution='very high')
            timed_wait_ms(25)
            drain.config(mode='I',iset=params['ibr_low_mamm']*1.0e-6*periphery,vlimit=drain_c,state=1,resolution='very high')
            timed_wait_ms(1000)
            test_data['vbr_ss_low'] = params['min_vgs'] - drain.measure()

            drain.config(iset=params['ibr_high_mamm']*1e-6*periphery)
            timed_wait_ms(1000)
            data['vbr_ss_high'] = params['min_vgs'] - drain.measure()
            
            drain.set_state(0)
            timed_wait_ms(50)        
        
        ###Idss ###
        
        gate_c = params['max_igs_mamm']*1.0e-6*periphery
        drain_c = params['max_ids_mamm']*1.0e-6*periphery 
        
        send_to_ui("update","Idss Measurement")
        
        gate.config(vset=0.0,ilimit=gate_c)
        timed_wait_ms(25)
        drain.config(mode='V',vset=params['vds_idss'],ilimit=drain_c,state=1)
        timed_wait_ms(100)
        data['idss'] = drain.measure()
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)
        
        #### Imax / Vmax ####

        send_to_ui("update"," Imax Measurement ")
        gate.config(mode='I',iset=params['igs_imax_mamm']*1.0e-6*periphery,vlimit=params['max_vgs'],state=1)
        timed_wait_ms(25)
        drain.config(vset=params['vds_imax'],state=1)
        timed_wait_ms(100)
        data['vmax'] = gate.measure()
        data['imax'] = drain.measure()
        open_gate = gate.limiting
        shorted_chan = drain.limiting
        drain.set_state(0)
        timed_wait_ms(25)
        gate.set_state(0)
        timed_wait_ms(10)

        #### Checks for failed devices ####
        
        if open_gate:
            send_to_ui("device fail","gate is open-circuited")
            raise DeviceFailedError
        elif data['vmax'] < 0.5:
            send_to_ui("device fail","gate is short-circuited")
            raise DeviceFailedError
        elif data['imax'] < 10.0e-6*periphery:
            send_to_ui("device fail","channel is open-circuited")
            raise DeviceFailedError            
        elif shorted_chan:
            send_to_ui("device fail","channel is open-circuited")
            raise DeviceFailedError

        #### Vpo measurement ####
        
        check_message_queue()
        
        # Vpo - % of Idss (IMax for E-FET )
        
        send_to_ui("update"," Pinchoff measurement @ Vds for Idss")
        
        if data['idss'] < 0.05*data['imax']:
            target_ids = 0.01*params['vpo_percent']*data['imax']
        else:
            target_ids = 0.01*params['vpo_percent']*data['idss']
        
        gate.config(resolution='medium')
        drain.config(resolution='medium')
        data['vpo'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
            
        #### Vpo Measurement at Vds for IMax ####

        send_to_ui("update"," Pinchoff Measurement for Vds@ Imax...")    
        
        data['vpo_imax'] = ids_target_search(gate,drain,params['vds_imax'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
            
        #### Vpo measurement mA/mm ####

        send_to_ui("update"," Pinchoff Measurement mA/mm ")
        
        target_ids = params['vpo_current_mamm']*1e-6*periphery
        data['vpo_mamm'] = ids_target_search(gate,drain,params['vds_idss'],target_ids,
            params['min_vgs'],params['min_vgs'],data['vmax']-0.2,gate_c,drain_c)
            
        ### Ron measurement ###
        check_message_queue()
        
        send_to_ui("update","Ron Measurement")
        if data['vpo'] < 0.0:
            # D-FET
            vset = 0.02
            gate.config(mode='V',vset=0.0,ilimit=gate_c,state=1,resolution='very high')
            timed_wait_ms(25)
            drain.config(mode='V',vset=vset,ilimit=drain_c,state=1,resolution='very high')
            timed_wait_ms(1000)
            data['ron'] = vset/drain.measure()
            drain.set_state(0)
            timed_wait_ms(25)
            gate.set_state(0)
            timed_wait_ms(10)
            
        else:
            # E-FET #
            # Set vgs = 0.7, vds = 0.02
            gate.config(mode='V',vset=0.7,ilimit=gate_c,state=1,resolution='very high')
            timed_wait_ms(25)
            drain.config(mode='V',vset= 0.02,ilimit=drain_c,state=1,resolution='very high')
            timed_wait_ms(1000)
            data['ron'] = 0.02/drain.measure()
            drain.set_state(0)
            timed_wait_ms(25)
            gate.set_state(0)
            timed_wait_ms(10)

        # Write the data, maintain the same format as MCT
        f.write("!\t\t\t\t\t DC FET PARAMETERS\n")
        f.write("!Vbr (%smA) \t Vbr (%smA) \t Idss (3V) \t Vpo (3V) \t Imax (1.5V) \t Vpo (1.5V) \t Vmax (1.5V) \t Vpo (1mA/mm) \t Ron (ohms)\n"%(params['ibr_low_mamm'],params['ibr_high_mamm']))
        params = ('vbr_ss_low','vbr_ss_high','idss','vpo','imax','vpo_imax','vmax','vpo_mamm','ron')
        vals = []
        for p in params:
            vals.append('%+.4e'%data.get(p,0.0))
        f.write("%s"%('\t'.join(vals)))
        f.write("\n")
        
        return data                
        
    except (UserAbort,DeviceFailedError,ValueError):
        pass 
        
    finally:
        timed_wait_ms(25)
        drain.config(state = 0)
        timed_wait_ms(25)
        gate.config(state = 0)
        timed_wait_ms(10)       
        
        
def fet_noise_figure_sweep(data, params, gate, drain, nfm, f):
    
    send_to_ui("update","Noise Figure Sweep")
    
    step = 0.025*math.floor(2.0*data['vmax']-data['vpo']+0.5)
    if (step < 0.025):
        step = 0.025
        
    start = step*math.floor(data['vpo']/step - 6.0)
    stop = step*math.floor(data['vmax']/step + 0.01)
    
    periphery = params['ugw']*params['ngf']
    
    max_pow = params['max_power']*1.0e-3*periphery
    drain_c = params['max_ids_mamm']*1.0e-6*periphery
    gate_c = params['max_igs_mamm']*1.0e-6*periphery
    
    vg_list = arange(start, stop+0.5*step, step)
    vd_list = arange(1.0, params['max_vds']+0.5*params['noisepars_vds_step'], params['noisepars_vds_step'])
    
    try:
        for vg in vg_list:
            check_message_queue()
            for vd in vd_list:
                check_message_queue()
                # Fill this in 
                send_to_ui("update","Performing Point ...")
                if vd != 0.0:
                    drain_compl = max_pow/vd
                else:
                    drain_compl = 1.0e12
                    
                if drain_c < drain_compl:
                    drain_compl = drain_c
                    
                gate.config(mode = 'v', vset = vg, ilimit = gate_c, resolution = 'high', remote = True, state = 1)
                timed_wait_ms(100)
                drain.config(mode = 'v', vset = vd, ilimit = drain_compl, resolution = 'high', remote = True, state = 1)
                
                igs = gate.measure()
                ids = drain.measure()
                
                if gate.ask_if_limiting() or drain.ask_if_limiting():
                    f.write("!**BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(vd,ids,vg,igs))
                    
                if drain.ask_if_limiting():
                    break 
                elif gate.ask_if_limiting():
                    continue
                    
                f.write("!BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(vd,ids,vg,igs))
                
                # Write the noise data to the file
                f.write("! Freq (Hz)   Gain(dB)  Nfig(dB)\n")
                f_list,gain,nfig = nfm.read_noise_sweep()
                for data in range(len(f_list)):
                    f.write("%.5e\t%.5e\t%.5e\n"%(f_list[data],gain[data],nfig[data]))
                f.flush()
                
                #Put in a wait here between sweeps if necessary
                timed_wait_ms(params['noise_meas_delay_ms'])
                              
                
    except UserAbort:
        pass 
        
    finally:
        drain.set_state(0)
        timed_wait_ms(100)
        gate.set_state(0)
        
def biased_noise_params(params, gate, drain, nfm, f):
    # Simple biased noise params
    # take param sweeps at the bias points specified
    
    send_to_ui("update", "biased noise figure sweep")
    
    gate.config(mode = 'v', vset = params['gate_voltages'][0], ilimit = params['gate_comp'], resolution = 'high', remote = True, state = 0)
    timed_wait_ms(100)
    drain.config(mode = 'v', vset = params['drain_voltages'][0], ilimit = params['drain_comp'], resolution = 'high', remote = True, state = 0)
    
    try:
        for vg in params['gate_voltages']:
            check_message_queue()
            for vd in params['drain_voltages']:
                check_message_queue()
                
                # Turn on supplies
                gate.config(vset = vg, state = 1)
                timed_wait_ms(100)
                drain.config(vset = vd, state = 1)
                
                igs = gate.measure()
                ids = drain.measure()
                
                if gate.ask_if_limiting() or drain.ask_if_limiting():
                    f.write("!**BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(vd,ids,vg,igs))
                    
                # Brake in either case or continue if gate is limiting?
                    
                if drain.ask_if_limiting():
                    break 
                elif gate.ask_if_limiting():
                    break
                    
                f.write("!BIAS: VDS = %.5e Volts IDS = %.5e Amps VGS = %.5e Volts IGS = %.5e Amps\n"%(vd,ids,vg,igs))
                
                # Write the noise data to the file
                f.write("! Freq (Hz)   Gain(dB)   Nfig(dB)\n")
                f_list,gain,nfig = nfm.read_noise_sweep()
                for data in range(len(f_list)):
                    f.write("%.5e\t%.5e\t%.5e\n"%(f_list[data],gain[data],nfig[data]))
                f.flush()
                
                #Put in a wait here between sweeps if necessary
                timed_wait_ms(params['noise_meas_delay_ms'])
                
    except UserAbort:
        pass
        
    finally:
        gate.set_state(0)
        timed_wait_ms(100)
        drain.set_state(0)
            
    
RUN_FUNCTION = run_test

