"""
This module allows the user to perform a pre/post rf life test downpoint measurement.
The module performs DC measurements including forward IV curves, 
                             leakage,transfer curves, and DC-IV.
The Power test portion of the test uses an Anritsu.
The Anritsu must be calibrated by the user prior to the test.
"""
from wxtestgui import parm, ParamPage,parm_group, ValidationError, Instr
from instrument import timed_wait_ms
from datetime import datetime
from wxtestgui.worker import send_to_ui
from utils import UserAbort, DeviceFailedError
from test_module_loader_1 import check_message_queue
import math

CAL_REQD = False
BIAS_WIZARD = False

TEST_PARAMS = [
    ParamPage('DC Test Parameters',
    ParamGroup('Common Device Params',
    parm('ngf','float',value = 2,label='Number of Gate Fingers'),
    parm('ugw','float',value = 100,label='Gate Width(um)'),
    parm('gate_ilimit_mamm','float',value = 1.0,label='Gate Current Limit(mA/mm)'),
    parm('drain_ilimit_mamm','float',value = 1000.0, label = 'Drain Current Limit(mA/mm)'),
    parm('power_limit_wmm','float',value = 4.0, label = 'Power Limit(W/mm)'),
    ),
    ParamGroup('Forward IV Params',
    parm('fwd_ig_mamm', 'float', value = 10.0, label = 'Forward Curves Gate Current(mA/mm)'),
    parm('gate_vlimit','float', value = 3.0, label = 'Gate Voltage Limit(V)'),
    parm('fwd_orders','float',value = 6.0, label = 'Forward Curves Order'),
    parm('fwd_pts_per_order','float',value = 5, label = 'Forward Curves Points Per Order'),
    parm('fwd_meas_delay_ms','float',value = 50, label = 'Forward Curves Measurement Delay'),
    ),
    ParamGroup('Leakage Params',
    parm('leakage_gate_voltage','float',value = -8.0, label = 'Leakage Gate Voltage'),
    parm('leakage_drain_voltages','float_list', value = [0.0,70.1,1.0], label = 'Leakage Drain Voltages(V)'),
    parm('leakage_meas_delay_ms','float', value = 100.0, label = 'Leakage Measurement Delay'),
    ),
    ParamGroup('Transfer Params',
    parm('txfr_drain_voltage','float', value = 10.0, label = 'Transfer Curves Drain Voltage'),
    parm('txfr_gate_voltages','float_list', value = [-3.0,2.05,0.1], label = 'Transfer Curves Gate Voltages'),
    ),
    ParamGroup('DCIV Params',
    parm('iv_gate_voltages','float_list',value = [-3.0,2.1,0.25], label = 'DC-IV Gate Voltages(V)'),
    parm('iv_drain_voltages','float_list',value = [0.0,30.1, 0.25], label = 'DC-IV Drain Voltages'),
    parm('iv_meas_delay_ms','float', value = 50, label = 'DC-IV Measurement Delay'),
    ),
    ),
    ParamPage('Power Test Parameters',
    ParamGroup('Bias Conditions',
    parm('gate_v','float', value = -2.6, label = 'Test Gate Voltage(V)'),
    parm('drain_v','float', value = 50.0, label = 'Test Drain Voltage(V)'),
    parm('gate_current_limit','float', value = 4.0e-3, label = 'Gate Current Limit(A)'),
    parm('drain_current_limit','float', value = 0.2, label = 'Drain Current Limit(A)'),
    ),
    ParamGroup('Power Test Conditions',
    parm('start_power','float', value = -21.0, label = 'Start Power (dBm)'),
    parm('stop_power','float', value = -5.0, label = 'Stop Voltage (dBm)'),
    parm('power_step','float', value = 0.5, label = 'Power Step Size'),
    parm('compression_limit','float', value = 8.0, label = 'Power Compression Limit'),
    ),           
    ),    
]

# The instrument list just consists of two supplies    
INSTR_LIST = [
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('vna','vna',label = 'VNA')
]

REQUIRED_INSTRS = ['bias1','bias2']
OPTIONAL_INSTRS = ['vna']

def run_test(params, instrs, fname, file_header, test_routine = 'DC'):
    # Run function takes as its arguments a dictionary which contains the instruments and parameters
    # This is the main method of this test. This method calls the other DC measurements
    # Open a file to write data
    f = open(fname,'w')
    f.write('! GaN Downpoint Test\n')
    f.write('!\n')
    f.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write('!\n')
    f.write('! Settings:\n')
    for i in file_header.iterkeys():
        f.write('!%s: %s\n'%(i,file_header[i]))
    for k in ('ngf','ugw','gate_ilimit_mamm','drain_ilimit_mamm','power_limit_wmm','fwd_ig_mamm','gate_vlimit',):
        f.write('!    %s = %s\n'%(k,repr(params[k])))
    f.write('!\n')
    try:
        check_message_queue()
        if test_routine == 'DC':
            fwd_iv(f,params, instrs)
            leakage(f,params, instrs)
            dciv(f,params,instrs)
            txfr(f, params, instrs)
        elif test_routine == 'Power':
            power_sweep(f,params, instrs)
    except UserAbort:
        pass  
        
        
def power_sweep(f,params,instrs):
    # Perform the power sweep using the Anritsu
    gate = instrs['bias1']
    drain = instrs['bias2']
    vna = instrs['vna']
    
    points = int((params['stop_power']-params['start_power'])/params['power_step'] + 1.0)
    t = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
    f.write("!Downpoint Test \t%s\n"%(t))
    f.write("!Start Power: %.3f\n"%params['start_power'])
    f.write("!Stop Power: %.3f\n"%params['stop_power'])
    f.write("!Power Step: %.3f\n"%params['power_step'])
    f.write("!Num Points: %d\n"%points)
    f.write("!\n")
    f.write("!Pin\tPout\tGain\tV_out\tI_out\tV_in\tI_in\n")
    
    gate.config(mode = 'v', vset = params['gate_v'], ilimit = params['gate_current_limit'], remote = True, resolution = 'high')
    timed_wait_ms(50)
    gate.config(mode = 'v', vset = params['drain_v'], ilimit = params['drain_current_limit'], remote = True, resolution = 'high')
    timed_wait_ms(500)
    
    # Use a localinstrument for the power sweep
    try:
        timed_wait_ms(100)
        tmp_points = vna.get_points()
        tmp_start = vna.get_start_power()
        tmp_stop = vna.get_stop_power()
        
        if tmp_points!=points or tmp_start!=params['start_power'] or tmp_stop!=params['stop_power']:
            # Force the instrument to forget the channel data
            vna.set_start_power(params['start_power'])
            vna.set_stop_power(params['start_power']+0.01)
            
            #Reset the source data
            vna.set_points(2)
            vna.set_stop_power(params['stop_power'])
            vna.set_points(points)
            tmp = vna.get_points()
            
        vna.config(sweep = 'POIN', trig_source = 'REM')
        vna.ask_if_done()
        
        vna.config(trig_type = 'SING')
        vna.trigger()
        
        timed_wait_ms(1000)
        
        gate_v = []
        drain_v = []
        gate_curr = []
        drain_curr = []
        
        for i in range(points):
            check_message_queue()
            ig = gate.measure()
            idr = drain.measure()
            gate_curr.append(ig)
            drain_curr.append(idr)
            gate_v.append(params['gate_voltage'])
            drain_v.append(params['drain_voltage'])
            
            timed_wait_ms(400)
            
            vna.trigger()
            vna.ask_if_done()
            
            timed_wait_ms(100)
            p_out = vna.get_data(chan = 2)
            valid_pout = p_out[1:i+2]
            p_in = vna.get_data(chan = 1)
            valid_pin = p_in[1:i+2]
            
            gain0 = valid_pout[0] - valid_pin[0]
            gain = valid_pout[-1] - valid_pin[-1]
            
            if (gain0-gain >= comp_limit) or gate.limiting or drain.limiting:
                break
                
            f.write("%.4f\t%.4f\t%.4f\t%.3e\t%.3e\t%.3e\t%.3e\n"%(valid_pin[-1],valid_pout[-1],valid_pout[-1]-valid_pin[-1],params['drain_voltage'],idr,params['gate_voltage'],ig))
            f.flush()
            
        vna.config(trig_source = 'AUTO')
    except UserAbort:
        pass
        
    finally:
        f.close()
        gate.set_state(0)
        drain.set_state(0)
        
                    
    
def fwd_iv(f,params,instrs):
    # This method runs the forward iv curve
    # Give bias1 and bias2 easy to read names
    gate = instrs['bias1']
    drain = instrs['bias2']
    
    test_data = {'vds':[],'ids':[],'vgs':[],'igs':[]}
    
    
    f.write("! *********** Forward I-V ***********\n")
    f.write("!\n")
    f.write("!Vds\tIds\tVgs\tIgs\n")
    
    periph = params['ugw']*params['ngf']
    igmax = params['fwd_ig_mamm']*periph*1.0e-6
    idlim = igmax*4.0
    
    drain.config(mode='V',vset=0.0,state=1,ilimit=idlim,resolution='high',remote=True)
    timed_wait_ms(50)
    gate.config(mode='I',iset=0.0,state=1,vlimit=params['gate_vlimit'],resolution='high',remote=True)
    
    stop = math.log10(igmax)
    start = math.log10(igmax*(10.0**(-params['fwd_orders'])))
    step = 1.0 / float(params['fwd_pts_per_order'])
    
    # set the initial SMU range
    current_range = (10.0**start)*100.0
    gate.config(irange=current_range)    
    
    v = start
    try:    
        while v < (stop + 0.1*step):
            check_message_queue()                
            igs = 10.0**v
            # check for range changes
            if igs > current_range:
                current_range *= 100.0
                gate.config(irange=current_range)    
        
            gate.config(iset=igs)
            timed_wait_ms(params['fwd_meas_delay_ms'])
            vg = gate.measure()
            ids = drain.measure()
            
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(0.0,ids,vg,igs))
            test_data['vds'].append(0.0)
            test_data['ids'].append(ids)
            test_data['vgs'].append(vg)
            test_data['igs'].append(igs)
            
            f.flush()
            v += step
            
    except UserAbort:
        pass 
    finally:
        gate.set_state(0)
        timed_wait_ms(50)    
        drain.set_state(0)
        f.write('\n\n')
        
    
def leakage(f,params, instrs):
    # This method performs the leakage curve measurement
    # Give bias1 and bias2 easy to read names
    gate = instrs['bias1']
    drain = instrs['bias2']
    
    test_data = {'vds':[],'ids':[],'vgs':[],'igs':[]}
    
    
    "measure the leakage curve"
    f.write("! *********** Leakage I-V ***********\n")
    f.write("!\n")
    f.write("!Vds\tIds\tVgs\tIgs\n")
    
    periph = params['ugw']*params['ngf']
    iglim = params['gate_ilimit_mamm']*periph*1.0e-6
    idlim = iglim*4.0
    vgate = params['leakage_gate_voltage']
    
    gate.config(mode='V',vset=vgate,state=1,ilimit=iglim,resolution='high',remote=True)
    timed_wait_ms(50)
    drain.config(mode='V',vset=0.0,state=1,ilimit=idlim,resolution='high',remote=True)
    
    try:            
        for vd in params['leakage_drain_voltages']:
            check_message_queue()    
            drain.config(vset=vd)
            timed_wait_ms(params['leakage_meas_delay_ms'])
            igs = gate.measure()
            ids = drain.measure()        
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(vd,ids,vgate,igs))
            f.flush()
    except UserAbort:
        pass 
    finally:
        drain.set_state(0)
        timed_wait_ms(50)
        gate.set_state(0)
        f.write('\n\n')
        
def txfr(f,params, instrs):
    #This method performs the transfer curve measurement
    gate = instrs['bias1']
    drain = instrs['bias2']
    
    test_data = {'vds':[],'ids':[],'vgs':[],'igs':[]}
            
    f.write("! *********** Transfer I-V ***********\n")
    f.write("!\n")
    f.write("!Vds\tIds\tVgs\tIgs\n")
    
    periph = params['ugw']*params['ngf']
    iglim = params['gate_ilimit_mamm']*periph*1.0e-6
    idlim = params['drain_ilimit_mamm']*periph*1.0e-6
    vdrain = params['txfr_drain_voltage']
    power_limit = params['power_limit_wmm']*periph*1.0e-3
    idlimp = power_limit / vdrain 
    if idlimp < idlim:
        idlim = idlimp
    
    gate.config(mode='V',vset= params['txfr_gate_voltages'][0],state=1,ilimit=iglim,resolution='high',remote=True)
    timed_wait_ms(50)
    drain.config(mode='V',vset=vdrain,state=1,ilimit=idlim,resolution='high',remote=True)
    
    try:        
        for vg in params['txfr_gate_voltages']:
            check_message_queue()    
            gate.config(vset=vg)
            timed_wait_ms(params['iv_meas_delay_ms'])
            igs = gate.measure()
            ids = drain.measure()        
            f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(vdrain,ids,vg,igs))
            f.flush()
    except UserAbort:
        pass 
    finally:           
        drain.set_state(0)
        timed_wait_ms(50)
        gate.set_state(0)
        f.write('\n\n')
        
    
def dciv(f,params,instrs):
    # This method performs the DC-IV measurement
    gate = instrs['bias1']
    drain = instrs['bias2']
    
    test_data = {'vds':[],'ids':[],'vgs':[],'igs':[]}
        
    f.write("! *********** DC I-V ***********\n")
    f.write("!\n")
    f.write("!Vds\tIds\tVgs\tIgs\n")
    
    periph = params['ugw']*params['ngf']
    iglim = params['gate_ilimit_mamm']*periph*1.0e-6
    idlim = params['drain_ilimit_mamm']*periph*1.0e-6
               
    # set the initial gate and drain current limits
    gate.config(mode='V',ilimit=iglim,resolution='medium',remote=True)
    drain.config(mode='V',ilimit=idlim,resolution='medium',remote=True)
    power_limit = params['power_limit_wmm']*periph*1.0e-3
    
    try:   
        for gv in params['iv_gate_voltages']:
            check_message_queue()               
            first=True                    
            for dv in params['iv_drain_voltages']:
                # compute power limit
                dv2 = abs(dv) + 0.001
                ilimp = power_limit / dv2
                ilim2 = idlim
                if ilimp < idlim:
                    ilim2 = ilimp
                
                # set the voltages
                gate.config(vset=gv)
                drain.config(vset=dv,ilimit=ilim2)
                
                if first:
                    # turn on the supplies
                    gate.set_state(1)
                    timed_wait_ms(50)
                    drain.set_state(1)
                    first = False

                        
                timed_wait_ms(params['iv_meas_delay_ms'])
                gc = gate.measure()
                dc = drain.measure()
                
                # check for limiting conditions
                if gate.ask_if_limiting():
                    continue
                if drain.ask_if_limiting():
                    break
                
                # write the data
                f.write("%.4e\t%.4e\t%.4e\t%.4e\n"%(dv,dc,gv,gc))
                f.flush()            
            # line break between Vgs values
            f.write('\n')
    except UserAbort:
        pass 
    finally:
        drain.set_state(0)
        timed_wait_ms(50)
        gate.set_state(0)        
        f.write('\n\n')
    
RUN_FUNCTION = run_test
ROUTINES = ['DC','Power']
    
    

    






