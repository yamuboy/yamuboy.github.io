"""
documentation



"""


from test_routine_helpers import *
import math

## define parameters needed by this module ##
PARAMETERS = (
    ParmDef('fet.en_vbr', PT_BOOL, default=True, text='Enable breakdown test'),
    ParmDef('fet.ugw', PT_FLOAT, default=100.0, text='Unit Gate Width (um)'),
    ParmDef('fet.ngf', PT_INT, default=2, text='Number of Gate Fingers'),
    ParmDef('fet.vgs_min', PT_FLOAT, default=-5.0, text='Min Vgs (V)'),
    ParmDef('fet.vgs_max', PT_FLOAT, default=2.5, text='Max Vgs (V)'),
    ParmDef('fet.ig_max', PT_FLOAT, default=1.0, text='Max Ig (mA/mm)'),
    ParmDef('fet.id_max', PT_FLOAT, default=1000.0, text='Max Id (mA/mm)'),
    ParmDef('fet.ibr_low', PT_FLOAT, default=0.1, text='Low Breakdown Current (mA/mm)'),
    ParmDef('fet.ibr_high', PT_FLOAT, default=1.0, text='High Breakdown Current (mA/mm)'),
    ParmDef('fet.vbr_limit', PT_FLOAT, default=30.0, text='Max BV (V)'),
    ParmDef('fet.vds_for_idss', PT_FLOAT, default=3.0, text='Vds for Idss (V)'),
    ParmDef('fet.vds_for_imax', PT_FLOAT, default=1.5, text='Vds for Imax (V)'),
    ParmDef('fet.ig_for_imax', PT_FLOAT, default=1.0, text='Ig for Imax (mA/mm)'),
    ParmDef('fet.vds_for_vpo1', PT_FLOAT, default=3.0, text='Vds for Vpo1 (V)'),
    ParmDef('fet.vds_for_vpo2', PT_FLOAT, default=1.5, text='Vds for Vpo2 (V)'),
    ParmDef('fet.vds_for_vpo_mamm', PT_FLOAT, default=3.0, text='Vds for Vpo_mAmm (V)'),
    ParmDef('fet.vpo_percent_target', PT_FLOAT, default=2.5, text='% of Idss for Vpo1/Vpo2 (V)'),
    ParmDef('fet.vpo_mamm_target', PT_FLOAT, default=1.0, text='Ids for Vpo_mAmm (mA/mm)'),
    )

## define instruments needed by this module ##
INSTRUMENTS = (
    InstrDef('gate_bias', IT_BIAS),
    InstrDef('drain_bias', IT_BIAS),
    InstrDef('vna', IT_VNA, optional=True),    
    )

## define the name of the test routine function ##
FUNC_RUN = fet_dc_params



def fet_dc_params( f, params, instr, data ):
    """
    FET short DC routine.
    
    Default Parameters:
    -----------------------------------------
    f - a file-like object that is open for writing
    params - a dictionary of test routine parameters, this have and entry for
       each of the parameters that were defined in the PARAMETERS tuple of the
       test routine module
    instr - a dictionary of instrument objects, this have and entry for
       each of the instruments that was defined in the INSTRUMENTS tuple of the
       test routine module
    data - a dictionary of data that contains data defined by other routines
       such as calibration data (this will be empty unless a calibration routine
       or other routine supplies this data)
    """
    
    # get instruments
    gate = instr['gate_bias']
    drain = instr['drain_bias']
    vna = instr['vna']
    
    # create the test data dictionary that will be retured with
    # measured DC data - initialize it with all None values
    testdata = { 'vbr_low':None, 'vbr_high':None, 'imax':None, 'vmax':None, 
        'idss':None, 'ron':None, 'vpo1':None, 'vpo2':None, 'vpo_mamm':None }
    
    # compute periphery
    periphery = params['fet.ugw'] * params['fet.ngf']
    if periphery < 1.0:
        raise ValueError("Periphery (ugw*ngf) cannot be less than 1.")
        
    # if the VNA instrument exists, put it in HOLD
    if vna in not None:
        vna.set_blah_blah()
    
    
    ##### breakdown #####
    if params['fet.en_vbr']:
        # write a status message
        
        # compute the compliance
        ic = periphery * params['fet.ibr_high'] * 4.0e-6
        vc = params['fet.vbr_limit'] + params['fet.vgs_min']
        
        # measure vbr low
        gate.set_v( params['fet.vgs_min'], limit=ic )
        drain.set_i( periphery * params['fet.ibr_low'] * 1.0e-6, limit=vc )
        gate.state(1)
        delay_ms(10)
        drain.state(1)
        delay_ms(1000)  # wait 1s for the measurement to settle
        testdata['vbr_low'] = params['fet.vgs_min'] - drain.measure()
        
        # measure vbr high
        drain.set_i( periphery * params['fet.ibr_high'] * 1.0e-6, limit=vc )
        delay_ms(1000)  # wait 1s for the measurement to settle
        testdata['vbr_high'] = params['fet.vgs_min'] - drain.measure()
        
        # turn off
        drain.state(0)
        delay_ms(10)
        gate.state(0)
        
    gc = periphery * params['fet.ig_max'] * 1.0e-6  # gate current limit
    dc = periphery * params['fet.id_max'] * 1.0e-6  # drain current limit
    
    ##### idss #####
    gate.set_v( 0.0, limit=gc, state=1 )
    delay_ms(10)
    drain.set_v( params['fet.vds_for_idss'], limit=dc, state=1 )
    delay_ms(100)
    drain.trigger()
    testdata['idss'] = drain.measure()
    drain.state(0)
    delay_ms(10)
    gate.state(0)
    
    ##### imax #####
    gate.set_i( periphery * params['fet.ig_for_imax'] * 1.0e-6, limit=params['fet.vgs_max'], state=1 )
    delay_ms(10)
    drain.set_v( params['fet.vds_for_imax'], limit=dc, state=1 )
    delay_ms(100)
    drain.trigger()
    testdata['vmax'] = gate.measure()
    testdata['imax'] = drain.measure()
    drain.state(0)
    delay_ms(10)
    gate.state(0)
    
    ##### do some checks for bad devices #####
    
    
    
    
    ##### vpo1 #####
    if testdata['idss'] < testdata['imax']*0.05:
        # Idss is less than 5% of Imax, assume this is an E-FET
        # and use a percentage of Imax as the target current for Vpo
        target_i = params['fet.vpo_percent_target'] * testdata['imax'] * 0.01
    else:
        # D-FET, use a percentage of Imax as the target current for Vpo
        target_i = params['fet.vpo_percent_target'] * testdata['idss'] * 0.01
        
    testdata['vpo1'] = fet_pinchoff(gate, drain, params['fet.vds_for_vpo1'],
        params['fet.vgs_min'], testdata['vmax']*0.8, target_i, gc, dc)
    
    ##### vpo2 #####
    # same current target, different drain voltage
    testdata['vpo2'] = fet_pinchoff(gate, drain, params['fet.vds_for_vpo2'],
        params['fet.vgs_min'], testdata['vmax']*0.8, target_i, gc, dc)
    
    ##### vpo ma/mm #####
    target_i = params['fet.vpo_mamm_target'] * periphery * 1.0e-6
    testdata['vpo_mamm'] = fet_pinchoff(gate, drain, params['fet.vds_for_vpo_mamm'],
        params['fet.vgs_min'], testdata['vmax']*0.8, target_i, gc, dc)
    
    ##### ron #####
    if testdata['vpo_mamm'] is not None and testdata['vpo_mamm'] > -0.1:
        # this is an E-FET, use a positive gate voltage
        vg = 0.7
    else:
        # this is a D-FET, use Vgs=0
        vg = 0.0
    vd = 0.05
    gate.set_v(vg, limit=gc, state=1)
    delay_ms(10)
    drain.set_v(vd, limit=dc, state=1)
    delay_ms(1000)
    testdata['ron'] = vd / drain.measure()
    
    # done, return data
    return testdata
    
def fet_pinchoff( gate, drain, vds, vgmin, vgmax, target_i, gc_lim, dc_lim ):
    """Internal routine used to find the pinch-off voltage of the FET
    given a set of conditions.
    """
    # initial measurement of drain current
    gate.set_v(vgmin, limit=gc_lim, state=1)
    delay_ms(10)
    drain.set_v(vds, limit=dc_lim, state=1, resolution=MEDIUM_RES)
    i = drain.measure()[0]
    
    # see if the initial current is already above the target current
    if i > target_i:
        drain.state(0)
        delay_ms(10)
        gate.state(0)
        return None
    elif abs(i-target_i) < target_i*0.005:
        # pinch-off found at vgmin (this would be rare)
        drain.state(0)
        delay_ms(10)
        gate.state(0)
        return vgmin
    
    # start the pinchoff loop
    n=0
    step = (vgmax - vgmin) * 0.2
    vpo = None
    while n<20:
        n = n+1
        # take a step
        vg = last_v + step
        if vg > vgmax: vg = vgmax
        elif vg < vgmin: vg = vgmin
        gate.set_v(vg)
        delay_ms(10)
        i = drain.measure()
        
        # check if we found the target, looking for a match of
        # 0.5% difference or less
        if abs(i-target_i) < target_i*0.005:
            vpo = vg
            break
        
        # check the step size and direction
        if (i > target_i and step > 0.0) or (i < target_i and step < 0.0):
            # reverse the step direction and reduce the step size
            if abs(step) <= 0.0005:
                # can't reduce, already at the minimum step size
                # must be having trouble finding pinchoff
                break
            else:
                step *= -0.3
                if abs(step) <= 0.0005:
                    step = math.copysign(0.0005,step)
        
        # verify the state of the loop
        if vg == vgmax and step > 0.0 or vg == vgmin and step < 0.0:
            # pinch off cannot be found
            break
    
    drain.state(0)
    delay_ms(10)
    gate.state(0)
    
    if vpo is None:
        # either ran out of iterations, or had some other condition
        # that caused the pinch-off loop to end
        # see if "close enough" (within 1%) otherwise return None
        if abs(i-target_i) < target_i*0.01:
            vpo = vg
    
    return vpo
    


