"""
This test module allows the user to perform an IP3 test.
The calibration technique takes into account the reflected power.

"""
from wxtestgui import parm, ParamPage,parm_group, ValidationError, Instr
from random import randint
from instrument.utils import timed_wait_ms
from wxtestgui.worker import send_to_ui, get_next_message

class CalAbort(Exception):
    "Raised when the cal abort button is pressed"
    pass 

CAL_REQD = True
BIAS_WIZARD = False

# Cal data dictionary
 

def generate_sweeps( auto_test_data ):
    "generate sweep data"

    def _recurse( lvl, names, data, incoming ):
        "recursively generate sweep data"
        myname = names[lvl]
        mydata = data[lvl]
        next = lvl+1
        out = []
        for val in mydata:
            d = incoming.copy()
            d[myname] = val
            if next < len(names):
                out.extend(_recurse(next,names,data,d))
            else:
                out.append(d)
        return out
            
    mapping = {'power':'power_dbmv'}
    for b in 'bias1','bias2','bias3','bias4':
        mapping[b] = b+'_volts'
    
    names = []
    data = []
    for svar in reversed(auto_test_data['sweep_order']):
        sweep = auto_test_data[svar]
        if len(sweep):
            names.append(svar)
            data.append(sweep)
    
    return _recurse(0,names,data,{})
    
    
def check_message_queue(block=False):
    "check if an abort message is in the queue"
    try:
        msg = get_next_message(block)
        if msg.msgtype == 'Abort':
            raise CalAbort
        return msg
    except NoMessages:
        return None

TEST_PARAMS = [
    ParamPage('Test Parameters',
    parm('power','float_list',value=None,validator=None,label='Power (dBm)'),
    parm('frequency','float_list',value=None,validator=None, label='Frequency (MHz)'),
    parm('bias1','float_list',label='Bias 1 (V)'),
    parm('bias2','float_list',label='Bias 2 (V)'),
    parm('bias3','float_list',label='Bias 3 (V)'),
    parm('bias4','float_list',label='Bias 4 (V)'),
    parm('bias1_ilimit','float',value=100.0,label='Bias 1 Current Limit (mA)'),
    parm('bias2_ilimit','float',value=100.0,label='Bias 2 Current Limit (mA)'),
    parm('bias3_ilimit','float',value=100.0,label='Bias 3 Current Limit (mA)'),
    parm('bias4_ilimit','float',value=100.0,label='Bias 4 Current Limit (mA)'),
    parm('sweep_order','ordered_list',value=['power','frequency','bias1','bias2','bias3']),
    parm('bias_order','ordered_list',value=['bias1','bias2','bias3','bias4']),
    parm('input_loss','float',value=0.0,label='Input Loss (dB)'),
    parm('output_loss','float',value=0.0,label='Output Loss (dB)'),
    parm('cal_tolerance','float',value=0.1,label='Cal. Tolerance (dB)'),
    parm('cal_power','float',value=0.1,label='Calibration Power (dB)'),
    parm('cal_reference','choice',value='A',label='Cal Reference',choices=[('Input (A)','A'),('Output (B)','B')]),
    parm('max_compression','float',value=1,label='Max Compression Value'),
    parm('bias_delay','float',value=25,label='Bias Delay (ms)'),
    parm('meas_delay','float',value=50,label='Meas. Delay (ms)'),
    )          
]  
# instruments

INSTR_LIST = [
    Instr('siggen1','rfsource',label='Signal Generator 1'),
    Instr('siggen2','rfsource',label='Signal Generator 2'),
    Instr('specana','specana',label='Spec. Analyzer'),
    Instr('pmeter1','powermeter',label='Power Meter 1'),
    Instr('pmeter2','powermeter',label='power Meter 2'),
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('bias3','bias',label='Bias 3'),
    Instr('bias4','bias',label='Bias 4'),
    
]

BIAS_LIST = [
    ('bias1','Bias 1'),
    ('bias2','Bias 2'),
    ('bias3','Bias 3'),
    ('bias4','Bias 4'),
    ]

        
def run_test(params, instrs, fname, file_header, test_routine = None):
    # Run function for the test, takes as its argument a dictionary which contains the instruments and parameters
    try:
        # Force the filename to be a string
        f = open(fname,'w')
        f.write("! OIP3 Test\n")
        test_data = {'pin':[],'pout':[],'gain':[]}
        for i in file_header.iterkeys():
            f.write('!%s: %s\n'%(i,file_header[i]))
        f.write("! Pin\t Pout\n")
        for i in params['power']:
            send_to_ui("update","performing power step %d of %d"%(i,len(params['power'])))            
            f.write("%f\t%f\n"%(i,randint(i,i+5)))
            test_data['pin'].append(i)
            test_data['pout'].append(randint(i,i+5))
            test_data['gain'].append(abs(i-randint(i,i+5)))
            timed_wait_ms(1000)
    except CalAbort:
        send_to_ui("cal_abort","test aborted")
    finally:
        send_to_ui("test data",test_data)
        f.close()
    
def input_cal(params,cal_data,instrs):
    """
    Perform the source cal, connect sensor to input coupler 
    """
    cal_data['offset_A'] = []
    print params['power'].value
    try:    
        for i in params['power'].value:
            print i
            check_message_queue()
            cal_data['offset_A'].append(i + 0.5)             
    except CalAbort:
        send_to_ui("cal_abort", "Cal Aborted, Need to redo Cal")
    
        

def output_cal(params,cal_data,instrs):
    """
    Perform the Output cal, place Sensor B in place of the DUT
    """
    cal_data['offset_B'] = []
    try:
        for i in params['power'].value:
            check_message_queue()
            cal_data['offset_B'].append(i+ 0.4)                    
    except CalAbort:    
        send_to_ui("cal_abort", "Cal Aborted, Need to redo Cal")
              
    
RUN_FUNCTION = run_test
# This is a list of cal functions  
CAL_DICT = {'input cal': input_cal,'through cal':output_cal}


    

   

    

    
