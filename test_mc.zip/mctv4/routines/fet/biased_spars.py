"""
This module allows the user to perform a biased S-parameter measurement.
The user can enter gate and drain biases and a power limit in Watts/mm
The module performs S-parameter measurements at the biases specified and stops the test
    once the power limit is exceeded or if the gate or drain supplies hit compliance.
"""

from wxtestgui import parm, ParamPage,parm_group, ValidationError, Instr
from instrument import timed_wait_ms
from datetime import datetime
from utils import abort
from network_params import Touchstone


MODNAME = "Biased S Parameters"
CAL_REQD = False
BIAS_WIZARD = False

# Test parameters
TEST_PARAMS = [
    ParamPage('Test Parameters',
    parm('ngf','float',value = 2,label='Number of Gate Fingers'),
    parm('ugw','float',value = 100,label='Gate Width(um)'),
    parm('gate_ilimit','float',value = 1.0,label='Gate Current Limit(mA)'),
    parm('drain_ilimit','float',value = 600.0, label = 'Drain Current Limit(mA)'),
    parm('power_limit_wmm','float',value = 4.0, label = 'Power Limit(W/mm)'),
    parm('gate_voltages','float_list',value = [-3.0,2.1,0.25], label = 'DC-IV Gate Voltages(V)'),
    parm('drain_voltages','float_list',value = [0.0,30.1, 0.25], label = 'DC-IV Drain Voltages(V)'),
    parm('spar_mode','choice',value = 'S2P',choices = [('2 port','S2P'),('1 Port','S1P')],label = 'S-parameter mode'),
    parm('spar_format','choice',value = 'ma',choices = [('Mag Angle','ma'),('Real Imaginary','ri'),('dB','db')],label = 'S-parameter data format'),
    )
]

# List of instruments needed for the test, no optional instruments
INSTR_LIST = [
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('vna','vna',label='VNA'),
]

def run_test(**test_dict):

    gate = test_dict['instrs']['bias1']
    drain = test_dict['instrs']['bias2']
    vna = test_dict['instrs']['vna']
    
    # Open the data file for writing
    fo = open(str(test_dict['dfname']),'w')
    fo.write('! Biased S-Parameters \n')
    fo.write('! Test Date and Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    fo.write('!\n')
    for k in ('ngf','ugw','gate_ilimit','drain_ilimit','power_limit_wmm'):
        fo.write('!    %s = %s\n'%(k,repr(test_dict['test_params'][k].value)))
    
    periph = test_dict['test_params']['ugw'].value*test_dict['test_params']['ngf'].value
    p_limit = test_dict['test_params']['power_limit_wmm'].value*periph*1.0e-3
    
    iglim = test_dict['test_params']['gate_ilimit'].value*1e-3
    idlim = test_dict['test_params']['drain_ilimit'].value*1e-3
    
    gv = test_dict['test_params']['gate_voltages'].value
    dv = test_dict['test_params']['drain_voltages'].value
    
    # Configure the gate and drain voltages to safe levels before starting the test    
    gate.config(mode = 'v',vset = -3.0, ilimit = iglim, resolution ='medium',remote = True, state = 0)
    drain.config(mode = 'v',vset = 0.0, ilimit = idlim, resolution ='medium',remote = True, state = 0)
    
    vna.config(mode = test_dict['test_params']['spar_mode'].value)
    spar_format = test_dict['test_params']['spar_format'].value
    
    try:   
        for g in gv:
            # Check if abort button pressed
            if a.get_abort() == True:
                break			
            for d in dv:
                # Check if abort button pressed
                if a.get_abort() == True:
                    break
                gate.config(vset = g,state = 1)
                timed_wait_ms(50)
                drain.config(vset = d,state = 1)
                
                # Check power limit and compliance
                p_curr = drain.measure()*d
                if p_curr >= p_limit:
                    break
                    
                if gate.ask_if_limiting() or drain.ask_if_limiting():
                    break
                    
                # Device is fine, take S-pars
                ts = Touchstone()
                ts.header = '!BIAS: VDS = %0.3f Volts IDS = %0.4e Amps VGS = %0.3f Volts IGS = %0.4e Amps\n!\n'%(d,drain.measure(),g,gate.measure())
                ts.format = '# s hz %s r 50'%spar_format
                vna.initiate()
                f_list = vna.get_flist()
                data = vna.fetch()
                for i,f in enumerate(f_list):
                    ts.insert(f,[data[0][i],data[1][i],data[2][i],data[3][i]])
                ts.write(fo)
                fo.flush()
                
    except Exception:
        raise Exception('Test Exception')
        
    finally:
        drain.config(state = 0)
        timed_wait_ms(50)
        gate.config(state = 0)
        
RUN_FUNCTION = run_test
                
            
            
            
            
            
            
            
            
        
    
    
    
    
    