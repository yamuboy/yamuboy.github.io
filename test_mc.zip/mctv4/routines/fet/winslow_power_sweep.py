"""
This module allows the user to perform a pulsed power sweep.
This test requires three sensors.
This module does not currently employ a Oscilloscope.  
"""
from wxtestgui import parm, ParamPage, parm_group, Instr, ValidationError
from wxtestgui.worker import send_to_ui
from test_module_loader_1 import check_message_queue
from utils import CalAbort, PowerSearchError
 
CAL_REQD = True
BIAS_WIZARD = False

_cal_data = {'ref_source_pow':[],'offset_A':[],'offset_B':[],'offset_C':[]}

TEST_PARAMS = [
    ParamPage('Test Parameters',
    ParamGroup('Power and Frequency',
    parm('power','float_list',value=[0.0],validator=None,label='Power (dBm)'),
    parm('frequency','float_list',value=[0.0],validator=None, label='Frequency (MHz)'),
    ),
    ParamGroup('Bias',
    parm('bias1','float_list',label='Bias 1 (V)'),
    parm('bias2','float_list',label='Bias 2 (V)'),
    parm('bias3','float_list',label='Bias 3 (V)'),
    parm('bias4','float_list',label='Bias 4 (V)'),
    parm('bias1_ilimit','float',value=0.1,label='Bias 1 Current Limit (A)'),
    parm('bias2_ilimit','float',value=0.1,label='Bias 2 Current Limit (A)'),
    parm('bias3_ilimit','float',value=0.1,label='Bias 3 Current Limit (A)'),
    parm('bias4_ilimit','float',value=0.1,label='Bias 4 Current Limit (A)'),
    parm('bias_order','ordered_list',value=['bias1','bias2','bias3','bias4']),
    parm('bias_delay','float',value=25,label='Bias Delay (ms)'),
    ),
    ParamGroup('Cal Parameters',
    parm('cal_tolerance','float',value=0.1,label='Cal Tolerance (dB)'),
    parm('cal_power','float',value=0.1,label='Calibration Power (dB)'),
    parm('sweep_order','ordered_list',value=['power','frequency','bias1','bias2','bias3','bias4']),
    ),
    ParamGroup('Misc Test Prameters',
    parm('max_compression','float',value=1,label='Max Compression Value'),
    parm('meas_delay','float',value=50,label='Meas. Delay (ms)'),
    parm('amp_gain','float',value = 25, label='Amplfier Gain (dB)'),
    ),
    )    
]

INSTR_LIST = [
    Instr('siggen1','rfsource',label='Signal Generator 1'),
    Instr('pmeter1','powermeter',label='Power Meter 1'),
    Instr('pmeter2','powermeter',label='Power Meter 2'),
    Instr('pmeter3','powermeter',label = 'Power Meter 3'),
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('bias3','bias',label='Bias 3'),
    Instr('bias4','bias',label='Bias 4'),
    Instr('dmm1','dmm',label = 'Multimeter 1'),
    Instr('dmm2','dmm',label = 'Multimeter 2'),
    Instr('dmm3','dmm',label = 'Multimeter 3'),
    Instr('dmm4','dmm',label = 'Multimeter 4'),    
]

# Need at least 2 biases, all the dmm's are optional
REQUIRED_INSTRS = ['siggen1','pmeter1','pmeter2','pmeter3','bias1','bias2']
OPTIONAL_INSTRS = ['bias3','bias4','dmm1','dmm2','dmm3','dmm4']
 
def set_cal_data(reset = False, c_dict = None):
    global _cal_data
    if reset == True:
        _cal_data = {'ref_source_pow':[],'offset_A':[],'offset_B':[],'offset_C':[]}
    if not reset and c_dict:
        _cal_data = c_dict.copy()
    
def pow_search(pm1,source,target,freq,tol,amp_gain):
    # Routine to search the power level
    loop_counter = 0
    max_iterations = 25
    pm1.config(freq = freq)            
    source.config(plevel = -110, state = 1)
    timed_wait_ms(100)
    current_power = pm1.measure()
    try:
        while True:
            if loop_counter >= max_iterations:
                raise PowerSearchError                           
            p_out = pm1.measure()
            if ((target - tol)<= p_out) and (p_out<=(target + tol)):
                break
            else:          
                current_power = (target - p_out) + current_power
                # This is the max power that the source can provide
                if current_power >= 14.0:
                    current_power = 14.0
                source.config(plevel = current_power)
    except PowerSearchError:
        send_to_ui("Can't find power level, Max Iterations Exceeded")
    finally:
        source.config(state = 0, plevel = -110)
        return current_power

def generate_sweeps( auto_test_data ):
    "generate sweep data"

    def _recurse( lvl, names, data, incoming ):
        "recursively generate sweep data"
        myname = names[lvl]
        mydata = data[lvl]
        next = lvl+1
        out = []
        for val in mydata:
            d = incoming.copy()
            d[myname] = val
            if next < len(names):
                out.extend(_recurse(next,names,data,d))
            else:
                out.append(d)
        return out
            
    mapping = {'power':'power_dbmv'}
    for b in 'bias1','bias2','bias3','bias4':
        mapping[b] = b+'_volts'
    
    names = []
    data = []
    for svar in reversed(auto_test_data['sweep_order']):
        sweep = auto_test_data[svar]
        if len(sweep):
            names.append(svar)
            data.append(sweep)
    
    return _recurse(0,names,data,{})        
    
def input_cal(params,instrs):
    """
    Attach power sensor A to the input coupler with all the necessary padding.
    Attach power meter B in place of the DUT with no pads.
    """
    pm1 = instrs['pmeter1']
    pm2 = instrs['pmeter2']
    source1 = instrs['siggen1']
    
    pm1.config(offset = 0)
    timed_wait_ms(500)
    pm2.config(offset = 0)
    
    tol = params['cal_tolerance']
    target = params['cal_power']
    
    source1.config(state = 1, plevel = -110)
    max_iterations = 25
    
    # Multiplier for MHz
    freq_multiplier = 1e6
    
    try:   
        for i in params['frequency']:
            check_message_queue()
            source1.config(freq = i*freq_multiplier)
            send_to_ui("Performing Input Cal for Frequency %f"%i)
            p_out = pow_search(pm1,source1,target,tol)
            
            # Store a tuple of frequency and cal value
            _cal_data['ref_source_pow'].append((i,p_out))
            offs = pm1.measure() - pm2.measure()
            _cal_data['offset_A'].append((i,offs))
            
    except CalAbort:
        pass
    finally:
        source1.config(state = 0, plevel = -110)
    
def output_cal(params,instrs):
    """
    Reconnect power sensor B. Connect a Thru in place of the DUT.
    """
    pm1 = instrs['pmeter1']
    pm2 = instrs['pmeter2']
    source1 = instrs['siggen1']
    
    pm1.config(offset = 0 )
    source1.config(state = 1, plevel = -110)
    offset_A = _cal_data['offset_A']
    ref_sp = _cal_data['ref_source_pow']
    
    # Multiplier for MHz
    freq_multiplier = 1e6
    
    try:    
        for i in range(len(offset_A)):
            check_message_queue()
            source1.config(freq = offset_A[i][0]*freq_multiplier, plevel = ref_sp[i][1])
            send_to_ui("Performing output cal for frequency %f MHz"%offset_A[i][0])
            timed_wait_ms(500)
            pm1.config(freq = offset_A[i][0]*freq_multiplier, offset = offset_A[i][1])
            pm2.config(freq = offset_A[i][0]*freq_multiplier)            
            
            offs = abs(pm1.measure() - pm2.measure())
            _cal_data['offset_B'].append((offset_A[i][0],offs))
            
    except CalAbort:
        pass
    finally:
        source1.config(state = 0, plevel = -110)
    
def sensorc_cal(params,instrs):
    """
    Place a short in place of the DUT and attach sensor C to the input coupler.
    Attach sensor A at the appropriate location. 
    """
    pm1 = instrs['pmeter1']
    pm2 = instrs['pmeter2']
    pm3 = instrs['pmeter3']
    source1 = instrs['siggen1']    
    
    pm1.config(offset = 0 )
    source1.config(state =1, plevel = -110)
    ref_sp = _cal_data['ref_source_pow']
    
    pm3.config(offset = 0 )
    source1.config(state =1, plevel = -110)
    offset_A = _cal_data['offset_A']
    offset_B = _cal_data['offset_B']
    
    ref_sp = _cal_data['ref_source_pow']
    
    # Multiplier for MHz
    freq_multiplier = 1e6
    
    try:
        for i in range(len(offset_A)):
            check_message_queue()
            source1.config(freq = offset_A[i][0]*freq_multiplier, plevel = ref_sp[i][1])
            send_to_ui("Performing sensor C cal for frequency %f MHz"%offset_A[i][0])
            
            pm1.config(freq = offset_A[i][0]*freq_multiplier, offset = offset_A[i][1])
            pm2.config(freq = offset_B[i][0]*freq_multiplier, offset = offset_B[i][1])
            pm3.config(freq = offset_A[i][0]*freq_multiplier)
            
            offs = abs(pm1.measure() - pm3.measure())
            
            _cal_data['offset_C'].append((offset_A[i][0],offs))
            
    except CalAbort:
        pass
        
    finally:
        source1.config(state = 0, plevel = -110)
        
def run_test(params, instrs, fname, file_header, test_routine = None):
    
    pm1 = instrs['pmeter1']
    pm2 = instrs['pmeter2']
    pm3 = instrs['pmeter3']
    source1 = instrs['siggen1']
    
    # Get the params based on the sweep order
    
    
    
    
    
           
    
CAL_DICT = {'input cal':input_cal,'output cal':output_cal,'sensorc_cal':sensorc_cal}
RUN_FUNCTION = run_test
    
        
    
    
