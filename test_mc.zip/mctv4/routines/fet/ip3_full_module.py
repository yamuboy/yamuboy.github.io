"""
This test module allows the user to perform an IP3 test.
The calibration technique takes into account the reflected power.
The module must have a calibration dictionary that has as its keys the calibration step name, and as its value the method executing that cal step.
The module's cal functions are passed a cal dict that carries data needed for each cal step.
The module's run function is passed the cal dict.
"""
from wxtestgui import parm, ParamPage,parm_group, ValidationError, Instr
from utils import CalAbort
from instrument import timed_wait_ms
from datetime import datetime
from wxtestgui.worker import send_to_ui, get_next_message

# This module has some redundant data and code. Need to make it better and easier. 

MODNAME = "oip3"
CAL_REQD = True
BIAS_WIZARD = False

# instruments
INSTR_LIST = [
    Instr('siggen1','rfsource',label='Signal Generator 1'),
    Instr('siggen2','rfsource',label='Signal Generator 2'),
    Instr('specana','specana',label='Spec. Analyzer'),
    Instr('pmeter1','powermeter',label='Power Meter 1'),
    Instr('pmeter2','powermeter',label='Power Meter 2'),
    Instr('bias1','bias',label='Bias 1'),
    Instr('bias2','bias',label='Bias 2'),
    Instr('bias3','bias',label='Bias 3'),
    Instr('bias4','bias',label='Bias 4'),    
]

TEST_PARAMS = [
    ParamPage('Test Parameters',
    parm('power','float_list',value=[0.0],validator=None,label='Power (dBm)'),
    parm('frequency','float_list',value=[0.0],validator=None, label='Frequency (Hz)'),
    parm('bias1','float_list',label='Bias 1 (V)'),
    parm('bias2','float_list',label='Bias 2 (V)'),
    parm('bias3','float_list',label='Bias 3 (V)'),
    parm('bias4','float_list',label='Bias 4 (V)'),
    parm('bias1_ilimit','float',value=0.1,label='Bias 1 Current Limit (A)'),
    parm('bias2_ilimit','float',value=0.1,label='Bias 2 Current Limit (A)'),
    parm('bias3_ilimit','float',value=0.1,label='Bias 3 Current Limit (A)'),
    parm('bias4_ilimit','float',value=0.1,label='Bias 4 Current Limit (A)'),
    parm('sweep_order','ordered_list',value=['power','frequency','bias1','bias2','bias3','bias4']),
    parm('bias_order','ordered_list',value=['bias1','bias2','bias3','bias4']),
    parm('input_loss','float',value=0.0,label='Input Loss (dB)'),
    parm('output_loss','float',value=0.0,label='Output Loss (dB)'),
    parm('tone_spacing','float',value = 1e6, label = 'Tone Spacing (Hz)'),
    parm('cal_tolerance','float',value=0.1,label='Cal Tolerance (dB)'),
    parm('cal_power','float',value=0.1,label='Calibration Power (dB)'),
    parm('max_compression','float',value=1,label='Max Compression Value'),
    parm('bias_delay','float',value=25,label='Bias Delay (ms)'),
    parm('meas_delay','float',value=50,label='Meas. Delay (ms)'),
    )          
]

BIAS_LIST = [
    ('bias1','Bias 1'),
    ('bias2','Bias 2'),
    ('bias3','Bias 3'),
    ('bias4','Bias 4'),
    ]    
    
# Use this to generate sweeps based on the sweep order
def generate_sweeps( auto_test_data ):
    "generate sweep data"

    def _recurse( lvl, names, data, incoming ):
        "recursively generate sweep data"
        myname = names[lvl]
        mydata = data[lvl]
        next = lvl+1
        out = []
        for val in mydata:
            d = incoming.copy()
            d[myname] = val
            if next < len(names):
                out.extend(_recurse(next,names,data,d))
            else:
                out.append(d)
        return out
            
    mapping = {'power':'power_dbm'}
    for b in 'bias1','bias2','bias3','bias4':
        mapping[b] = b+'_volts'
    
    names = []
    data = []
    for svar in reversed(auto_test_data['sweep_order'].value):
        sweep = auto_test_data[svar].value
        if len(sweep):
            names.append(svar)
            data.append(sweep)
    
    return _recurse(0,names,data,{})
    
def measure_two_tone(sa,freq,offset):
    # Measure f1,f2, etc
    f = freq + (offset/2)
    span = abs(2*offset)
    
    sa.set_averages(0)
    sa.set_attn()
    sa.set_bandwidth()
    sa.set_marker(mode = "max")
    sa.sweep(type = 'SNGLS')
    
    sa.set_cf(f)
    sa.set_span(span)
    sa.optimize_ref_level()
    pk = sa.measure_marker()
    
    f1f2_span = span/2
    # Measure f1 now
    sa.set_cf(freq)
    sa.set_span(f1f2_span)
    sa.optimize_ref_level()
    sa.sweep()
    f1 = sa.measure_marker()
    
    # Measure f2 now
    f2 = freq + offset
    sa.set_cf(f2)
    sa.set_span(f1f2_span)
    sa.optimize_ref_level()
    sa.sweep()
    f2 = sa.measure_marker()
    
    # Measure prod_f1 now
    sa.set_cf(freq-offset)
    sa.set_span(1e3)
    sa.set_averages(0)
    sa.optimize_ref_level()
    sa.set_averages(3)
    sa.sweep()
    prod_f1 = sa.measure_marker()
    
    # Measure prod_f2 now
    sa.set_cf(f2 + offset)
    sa.set_span(1e3)
    sa.set_averages(0)
    sa.optimize_ref_level()
    sa.set_averages(3)
    prod_f2 = sa.measure_marker()
    
    return f1,f2,prod_f1,prod_f2
    
    
# power level search method used for input cal and during the test    
def rf_power_search(pm1,pm2,source,target,init,frequency,tol):
    # The maximum number of iterations is 25, if the power level isn't found within 25 iterations, raise an exception
    loop_counter = 0
    current_power = init
    max_iterations = 25
    source.config(plevel = current_power, state = 1)
    while True:
        if loop_counter >= max_iterations:
            raise 
            break  
                
        pm1.config(freq = frequency)
        pm2.config(freq = frequency)
        p_out = pm1.fetch()
        print "p_out %f"%p_out
        if ((target - tol)<= p_out) and (p_out<=(target + tol)):
            break
        else:          
            current_power = (target - p_out) + current_power
            # This is the max power that the source can provide
            if current_power >= 14.0:
                current_power = 14.0
            source.config(plevel = current_power)
            
    return current_power
    
    
        
def run_test(**test_dict):
    
    input_cal_data = test_dict['cal_data']['input cal']
    output_cal_data = test_dict['cal_data']['through cal']
    
    pm1 = test_dict['instrs']['pmeter1']
    pm2 = test_dict['instrs']['pmeter2']
    source1 = test_dict['instrs']['siggen1']
    source2 = test_dict['instrs']['siggen2']
    sa = test_dict['instrs']['specana']
    
    test_plan = generate_sweeps(test_dict['test_params'])
        
    # Run function for the test, takes as its argument a dictionary which contains the instruments and parameters
    f = open(str(test_dict['dfname']),'w')
    f.write("! OIP3 Test\n")
    f.write('!\n')
    f.write('! Test Date/Time: %s\n'%datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    f.write('!\n')
    f.write('!Cal Data\n')
    for info in test_dict['file_header']:
        f.write('! %s : %s\n'%(info,test_dict['file_header'][info]))
        
    f.write('! Frequency\tReference_Source_Power\tOffsetA\tOffsetB\tOffsetSA\n')
    
    for i in range(len(input_cal_data['frequency'])):
        f.write("%f\t%f\t%f\t%f\t%f\n"%(input_cal_data['frequency'][i],input_cal_data['ref_source_power'][i],input_cal_data['offset_a'][i],output_cal_data['offset_b'][i],output_cal_data['offset_sa'][i]))
    
    f.write('!\n')
    f.write('!Pin\tPout\tGain\tf1\tf2\tprod_f1\tprod_f2\tOIP3l\tOIP3h\tIIP3l\tIIP3h\t')
    
    b_names = []
    for bname in test_dict['test_params']['bias_order'].value:
        if bname in test_dict['instrs'] and bname in test_plan[0]:
            b_names.append(bname+'_volts',bname+'_ma')
            f.write('%s\t%s\t'%(bname+'_volts',bname+'_ma'))
    f.write('\n')   
    
    for i,tst in enumerate(test_plan):
    
        bias_data = {}
        
        # Get the index of the cal data corresponding to the frequency being tested
        cal_index = input_cal_data['frequency'].index(tst['frequency'])
        
        # Set the bias        
        for bname in test_dict['test_params']['bias_order'].value:
            if bname in test_dict['instrs'] and bname in tst:
                ilimit_var = bname+'_ilimit'
                test_dict['instrs'][bname].config(vset=swp[bname],state=1,ilimit=test_dict['test_params'][ilimit_val].value)
                bias_data[bname+'_volts'] = tst[bname]
                timed_wait_ms(test_dict['test_params']['bias_delay_ms'])
                
        source1.config(freq = tst['frequency'], state = 0)              
        source2.config(freq = tst['frequency']+test_dict['test_params']['tone_spacing'].value, state = 0)
        init_pwr = input_cal_data['ref_source_power'][cal_index] + (tst['power']-test_dict['test_params']['cal_power'].value)
        pm1.config(offset = input_cal_data['offset_a'][cal_index])
        pm2.config(offset = output_cal_data['offset_b'][cal_index])

        source1.config(plevel = init_pwr)
        rf_power_search(pm1,pm2,source1,tst['power'],init_pwr,tst['frequency'],test_dict['test_params']['cal_tolerance'].value)
        pm1.config(freq = tst['frequency'])
        pm2.config(freq = tst['frequency'])
        # Calculate the gain        
        pin = pm1.fetch()
        pout = pm2.fetch()
        gain = pin-pout 
        
        # Now move on to the IP3         
        source1.config(state = 0)
        source2.config(plevel = init_pwr, state = 1)        
        rf_power_search(pm1,pm2,source2,tst['power'],init_pwr,(tst['frequency']+test_dict['test_params']['tone_spacing'].value),test_dict['test_params']['cal_tolerance'].value)
        
        ref_level = pout - output_cal_data['offset_sa'][cal_index] + 6
        # Set the SA reference level
        sa.set_ref_level(ref_level)
        # sa_kwargs include span, rbw, vbw and marker settings
        f1, f2, prod_f1, prod_f2 = measure_two_tone(sa,freq = tst['frequency'],offset = test_dict['test_params']['tone_spacing'].value)
        
        ip = pout - gain
        # Calculate the ip3
        oip3l = (f1 - prod_f1)/2 + pout
        oip3h = (f2 - prod_f2)/2 + pout
        iip3l = (f1 - prod_f1)/2 + ip
        iip3h = (f2 - prod_f2)/2 + ip
        
        # Measure the current
        for bname in test_dict['test_params']['bias_order'].value:
            if bname in test_dict['instrs'] and bname in tst:
                bias_data[bname+'_ma'] = test_dict['instrs'][bname].measure()
                
        f.write("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t"%(pin,pout,gain,f1,f2,prod_f1,prod_f2,oip3l,oip3h,iip3l,iip3h))
        for bname in b_names:
            f.write("%f\t%f\t"%(bias_data[bname]))
            
        f.write('\n')
        
    source1.config(state = 0)
    source2.config(state = 0)
        
    f.close()
    
def input_cal(cal_params,cal_dict,instrs):
    """
    Lift the probes and disconnect the cable to the input probe. 
    Perform the input cal. Attach power sensor A to the input coupler with all the necessary padding. 
    Attach power meter B in place of the DUT with no pads.         
    """
    
    send_to_ui("cal_update","Starting Cal")   
    # get the instruments to be used for the input cal
    pm1 = instrs['pmeter1']
    pm2 = instrs['pmeter2']
    source1 = instrs['siggen1']
    source2 = instrs['siggen2']
    
    cal_success = 1
    
    pm1.config(offset = 0)
    timed_wait_ms(500)
    pm2.config(offset = 0)
    
    tol = cal_params['cal_tolerance'].value
    target = cal_params['cal_power'].value
    
    # This is the first step, so override the cal_dict
    # This step returns a cal_dict in the following format {'frequency':[1000,2000,3000],'ref_source_power':[x,x,x],'offset_a':[x,x,x]}
    cal_dict = {'frequency':[],'ref_source_power':[],'offset_a':[]}    
    
    source1.config(state =1, plevel = -110)
    timed_wait_ms(500)
    source2.config(state = 0)
           
    max_iterations = 20
    p_start = -110
    loop_counter = 0
    # Calibrate at a specific power level for all the frequencies listed
    cal_dict = {'ref_source_power':[],'frequency':[],'offset_a':[]}
    try:        
        for i in cal_params['frequency'].value:
            if get_next_message == "abort":
                raise CalAbort    
            
            source1.config(freq = i)
            
            p_out = rf_power_search(pm1,pm2,source1,target,p_start,i,tol)
            send_to_ui("Calibrating for Reference Power Level at Frequency:"%i)
            
            cal_dict['ref_source_power'].append(p_out)
            cal_dict['frequency'].append(i)
            cal_dict['offset_a'].append(abs(pm1.fetch()- pm2.fetch()))
    except CalAbort:
        send_to_ui("Cal Aborted")
        cal_success = 0
    finally:
        if cal_success:
            send_to_ui("Input Cal Completed")
            
        
    source1.config(state = 0)
    
    
    # Return an ack and the cal data               
    return cal_dict     

def output_cal(cal_params,cal_dict,instrs):
    """
    Perform the Output cal. 
    Reconnect power meter B. Connect a Thru in place of the DUT. 
    """
    
    pm1 = instrs['pmeter1']
    pm2 = instrs['pmeter2']
    source1 = instrs['siggen1']
    source2 = instrs['siggen2']
    sa = instrs['specana']
    
    pm1.config(offset = 0)
    timed_wait_ms(500)
    pm2.config(offset = 0)
    
    tmp_cal_dict = {'offset_b':[],'offset_sa':[]}
    # Setup the SA to measure the offset
    # Set the span to 100 KHz, RBW and VBW to auto, no averaging and marker type to peak
    sa.set_span(100e3)
    sa.set_averages(0)
    sa.set_attn()
    sa.set_bandwidth()
    sa.sweep(type = 'SNGLS')
    sa.set_marker(mode = "max")
    
    source1.config(state = 1, plevel = -110)
    # The cal dict has data from the previous cal step. It is in a dict with the key 'input cal'
    for i in range(len(cal_dict['input cal']['frequency'])):
        source1.config(freq = cal_dict['input cal']['frequency'][i],plevel = cal_dict['input cal']['ref_source_power'][i])
        pm1.config(offset = cal_dict['input cal']['offset_a'][i])
        timed_wait_ms(500)
        pm1.config(freq = cal_dict['input cal']['frequency'][i])
        pm2.config(freq = cal_dict['input cal']['frequency'][i])
        tmp_cal_dict['offset_b'].append(abs(pm1.fetch()-pm2.fetch()))
        
        # Get the spectrum analyzer offset
        sa.set_cf(cal_dict['input cal']['frequency'][i])
        sa.optimize_ref_level()
        pk = sa.measure_marker()
        tmp_cal_dict['offset_sa'].append(abs(pm1.fetch()-pk))
        
    source1.config(state = 0)
              
    print tmp_cal_dict
    return True, tmp_cal_dict
    
RUN_FUNCTION = run_test
# This is a list of cal functions  
CAL_DICT = {'input cal': input_cal,'through cal':output_cal}




    

   

    

    
