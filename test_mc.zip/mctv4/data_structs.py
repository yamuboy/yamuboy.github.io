from __future__ import with_statement
import threading as _threading
import os, os.path, sys, re
import datetime

# Default preferences file
_default_preferences = {
    'current_test_selection':'ip3_test_module.py',
    'device':'fet',
    'setup_file':'C:\\Users\\ma099737\\Desktop\\power_test.stp',
    'window_size':(800,800),
    'window_position':(200,200),    
}

PREFERENCES_FILE = os.path.expanduser('~/mtacs.prf')

_valid_preference = re.compile(r'^[a-zA-Z][a-zA-Z0-9_]*$')


class ApplicationPreferences(object):
    """Store application preferences
    
    This stores application preferences such as:
      - the last main window size/position
      - last used paths for file storage
      - last used test configuration
      - etc
      
    It is designed to be loaded at application startup, periodicially updated
    as the application is run, and then written back out to disc when the
    application is closed.
    """
    
    __shared = dict()
    
    def __init__(self):
        "initialize and try to load preferences from disk"
        self.__dict__ = self.__shared
    
        if '_ApplicationPreferences__prefs' not in self.__dict__:
            # this is the first instanciation of an object of this class
            # attempt to load preferences from disk, or if that fails
            # use the default preferences
            self.__prefs = dict()
            self._lock = _threading.RLock()
            try:
                self.load()
            except Exception:
                # file load failed, use default preferences
                with self._lock:
                    self.__prefs.update(_default_preferences)
    
    def load(self, fname=None):
        "load preferences from a file"
        if fname is None:
            fname = PREFERENCES_FILE
        
        cfg = {}
        execfile(fname,cfg)
        del cfg['__builtins__']
        with self._lock:
            self.__prefs.update(cfg)
        
    def save(self, fname=None):
        "save preferences to a file"
        if fname is None:
            fname = PREFERENCES_FILE
            
        with self._lock:
            keys = self.__prefs.keys()
            keys.sort()
            fp = open(fname,'w')
            fp.write("# MTACS application preferences\n#\n\n")
            try:
                for k in keys:
                    v = self.__prefs[k]
                    # check that the key is a valid Python identifier
                    if not _valid_preference.match(k):
                        continue
                    
                    # handle certain types specially, and for the rest just use repr
                    wv = repr(v)
                    
                    fp.write("%s = %s\n"%(k,wv))            
            finally:
                fp.close()
        
    def get(self, name, default=None):
        "get a preference value, or return the default value"
        return self.__prefs.get(name,default)        
        
    def __contains__(self, name):
        "check to see if the preference is set"
        return name in self.__prefs
    
    def __getitem__(self, name):
        "get a preference by name"
        return self.__prefs[name]
    
    def __setitem__(self, name, val):
        "set the preference value"
        with self._lock:
            self.__prefs[name] = val
        return val
    
    def __delitem__(self, name):
        "delete a preference"
        with self._lock:
            del self.__prefs[name]
    
    def __len__(self):
        "number of preferences"
        return len(self.__prefs)
       



        
        