
class TestSequencer:
    """A special test routine that sequences/controls a set
    of TestPackages."""
    
    
    
    
    
    
class TestPackage:
    """A set of TestRoutine objects that are executed in order."""
    
    # properties
    __routines = None
    
    
    
    def __init__(self):
        """Initialize the test package."""
        
        
        
        
    
    def verify(self):
        """Verify the configuration."""
        
        
        
        
        
        
    def execute(self, instr_mgr, global_dict=None):
        """This is the primary execution wrapper routine for all TestRoutine
        objects.
        
        This method has several key purposes:
         - keeping track of global variables that are passed to the test routines
         - keeping track of instrument mappings
         - perform error handling
         
        """
        
        
        
        
        # run the test routine
        
        
        
        
    
    def set_error_mode(self,
    
    
    
    

class TestRoutineManager:
    """The test routine manager is the global controller of all test routine
    related stuff, including execution, configuration, error handing, saving
    and restoring.  It is configured as a Singleton-like object in that the
    internal data is stored in an inner object of which there is only a single
    copy that is shared by all TestRoutineManager objects.
    """
    
    # this is a reference to the Singleton inner-object
    __m = None
    
    def __init__(self):
        """Initialize the singleton inner object."""
        
        
    
    class __TRM_singleton:
        """
        
        
        
        
        
        # class variables
        
        def __init__(self):
            """Initialize the global test routine manager object.
            
            This happens once, when the first """
            
            
            
        
        
        def load_configuration( self, filename, **kwargs ):
            """Load a configuration file."""
            pass
            
            
            
        def save_configuration( self, filename, **kwargs ):
            """Save the current configuration to a file."""
            pass
            
            
            
            
            
        def get_test_parameters( self, **kwargs ):
            """Get a tuple/list/something of test parameters for the current set of
            test routines."""
            
            
            
            
        def set_test_parameters( self, params, **kwargs ):
            """Apply a set of test parameters that was recieved from the
            get_test_parameters() method and modified."""
            
            
            
            
        def copy_test_parameter_configuration( self, filename, **kwargs ):
            """Read in the test parameters (and only the test parameters) from
            a configuration file and apply them to the current test configuration."""
            
            
            
            
    
    
    
    
    
    
    

