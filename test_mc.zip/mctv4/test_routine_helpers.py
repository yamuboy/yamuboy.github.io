
#### instrument types ####
IT_BIAS = 'bias'
IT_VNA = 'vna'
IT_PNA = IT_VNA
IT_SA = 'specana'
IT_SPECANA = IT_SA
IT_DCMETER = 'dcmeter'
IT_POWERMETER = 'powermeter'
IT_NOISETS = 'noisets'
IT_NFM = IT_NOISETS
IT_RFSWITCH = 'rfswitch'
IT_AUTOPROBER = 'autoprober'

#### parameter types ####
PT_FLOAT = 'float'
PT_INTEGER = 'int'
PT_INT = VT_INTEGER
PT_COMPLEX = 'complex'
PT_STRING = 'string'
PT_TUPLE = 'tuple'
PT_INTTUPLE = 'inttuple'
PT_FLOATTUPLE = 'floattuple'


# map instrument type strings to instrument objects in the
# instrument driver library
_instr_type_mapping = {
    IT_BIAS:None,
    IT_VNA:None,
    IT_SA:None,
    IT_DCMETER:None,
    IT_POWERMETER:None,
    IT_NOISETS:None,
    IT_RFSWITCH:None,
    IT_AUTOPROBER:None,
}

class InstrDef(object):
    """An instrument definition class to be used within test routines to
    define the instruments that they need.
    """
    
    def __init__(self,name,itype,**kwargs):
        """Create an instrument definition.
        
        name - (string) a unique name for the instrument within the scope of the
          test routine
        itype - (string) the type of instrument, which should be one of the
          IT_* constants defined in this module
        
        Keywords:
        ----------------------
        optional - (boolean) identify the instrument as optional such that a failed
          attempt to instantiate it is not a failure
        capabilties - (tuple of strings) a tuple of capabilities that the
          instrument must have. This is specific to the instrument type.
          See also:   xxxxxx
        """
        
        # check and save arguments
        pass
        
        
    
    def create_instrument(self, rsc_string, **kwargs):
        """Create an instrument object
        
        
        
        """
        raise NotImplemented
        
        
class ParmDef(object):
    """A parameter definition class to be used within test routines to
    define the parameters of the test routine.
    """
    
    def __init__(self,name,ptype,**kwargs):
        """Create an instrument definition.
        
        name - (string) a unique name for the parameter within the scope of the
          test routine
        ptype - (string) the type of parameter, which should be one of the
          PT_* constants defined in this module
        
        Keywords:
        ----------------------
        default - default value for the parameter, a type-specific default
          will automatically be determined if this is not supplied
        
        
        
        """
        
        pass
        
        
