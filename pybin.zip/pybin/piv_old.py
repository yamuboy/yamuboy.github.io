#!/usr/bin/env python
"""
Custom PIV program


"""
from __future__ import unicode_literals, absolute_import, division, print_function
import os, sys
import optparse
from testsoft.pivexe import main
      
if __name__ == '__main__':
    "direct call entry point"

    p = optparse.OptionParser(usage='%prog [options] [filename]')
    p.add_option('-c','--config',dest='config',metavar='FILE',help='use config file named FILE when reading configuration data')
    
    opts,args = p.parse_args()
    kw = {}
    if len(args):
        if len(args) > 1:
            sys.stderr.write("ERROR: only 1 filename argument my be specified on the command line\n")
            sys.exit(1)
        kw['fname'] = args[0]

    if opts.config:
        kw['cfg'] = opts.config
        
    main(**kw)

