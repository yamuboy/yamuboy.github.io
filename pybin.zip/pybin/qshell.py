#!/usr/bin/env python

import sys
import socket
import os.path
import os
import traceback
import getpass

from cdsqueue.client import QserveClient, DEFAULT_INET_PORT
from cdsqueue.client_errors import *

try:
    inpf = raw_input
except NameError:
    inpf = input

class QserveShell(QserveClient):
    """
    Simple shell-style interface to the Assura job queue
    
    """

    def __init__(self, sockpath='localhost:'+str(DEFAULT_INET_PORT), timeout=20.0):
        "Initialize the connection."
        # init the socket connection
        super(QserveShell,self).__init__(sockpath,timeout)
        # set state variables
        self.__getauth = False
        self.__uname = ''
        self.__storedcmd = ''
        
        
    def runshell(self):
        """Run the shell
        
        this is a blocking call that does not exit until
        a KeyboardInterrupt exception is raised or a socket.error
        causes the connection to close
        """
        while True:
            try:
                # prompt the user for input
                self.shellprompt()
            except socket.error:
                raise
            except CommunicationError:
                raise
            except KeyboardInterrupt:
                break
            except EOFError:
                break
            except AuthenticationError:
                print("*** invalid username or password ***")
            except PermissionError:
                print("*** insufficient priviledges ***")                    
            except Exception as e:
                traceback.print_exc()
    
    def shellprompt(self):
        "prompt for command input"
        
        if self.__getauth:
            # need to get authentication
            # prompt for a userID and password
            uname = self.__uname
            if not len(uname):
                try:
                    uname = inpf("Username: ").strip()
                    if len(uname):
                        self.__uname = uname
                except KeyboardInterrupt:
                    # allow keyboard interrupts to stop the authentication process
                    self.__getauth = False
                    print("*** user abort ***")
                    raise
            
            if not len(uname):
                return
                
            # prompt for a password
            try:
                pw = getpass.getpass('Password: ')
                if '\x03' in pw:
                    # ^C was pressed at the getpass prompt, but due to some
                    # buggy behavior in the termio settings it was not raised
                    # so raise in manually
                    raise KeyboardInterrupt()
            except KeyboardInterrupt:
                # allow keyboard interrupts to stop the authentication process
                self.__getauth = False
                self.__uname = ''
                print("*** user abort ***")
                raise

            if not len(pw):
                return
            
            # attempt to login
            self.login(uname,pw)
            self.__getauth = False
            
            # run the previously stored command
            if len(self.__storedcmd):
                c = self.__storedcmd
                self.__storedcmd = ''
                print(' -> {}'.format(c))
                print(self.command(c))
                
            return
            
        #
        # all other command fall into here
        #
        txt = '$'
        if self.current_user is not None:
            txt = '['+self.current_user+']#'
        cmd = inpf(txt+" ").strip()
        
        # no command, 
        if not len(cmd):
            return
            
        # trap authentication or exit commands
        d = cmd.split()
        c = d[0].upper()
        if c == 'LOGIN':
            if self.current_user is not None:
                print("*** already logged in ***")
                return
                
            # trap the username if it was specified
            if len(d) == 2:
                self.__uname = d[1]
            
            # get authentication
            self.__storedcmd = ''
            self.__getauth = True
            return
        elif c in ('AUTH','AUTHREQ'):
            print("*** Use of raw 'AUTH' or 'AUTHREQ' commands is not allowed ***")
            return
        elif c in ('EXIT','QUIT','Q'):
            # quit program
            sys.exit(0)
        
        # send the command
        try:
            print(self.command(cmd))
        except PermissionError:
            if self.response_code == 403:
                raise
            elif self.response_code == 601:
                print("--- authentication required ---")
                self.__storedcmd = cmd
                self.__getauth = True
            else:
                print("*** unexpected PermissionError exception ***")
                
                           
if __name__ == '__main__':
    if len(sys.argv) == 1:
        constr = inpf("Server to connect to [localhost:%s]? "%str(DEFAULT_INET_PORT)).strip()
        if constr:
            s = QserveShell(constr)
        else:
            s = QserveShell()
        s.runshell()
    elif len(sys.argv) == 2:
        s = QserveShell(sys.argv[1])
        s.runshell()
    else:
        print("%s [socket]"%sys.argv[0])


       