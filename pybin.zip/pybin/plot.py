#!/usr/bin/env python2.6

import sys
import argparse
from argparse import RawTextHelpFormatter
import os.path
import wx
#from testsoft.plotlib import WxPlotFrame
from macomplot import PlotlibFrame
from macomplot.base import PlotlibCanvasBase, get_all_canvas_types, get_canvas_by_name

if __name__ == '__main__':

    # command-line argument parser
    canvas_types = [str(x.pl_name) for x in get_all_canvas_types().values()]
    p = argparse.ArgumentParser(description="Generic Plotting Utility",formatter_class=RawTextHelpFormatter)
    p.add_argument('-c','--canvas-type',action='store',metavar='',dest='c_type',choices=canvas_types,help='Choose the starting canvas type.\r\nAvailable types:\r\n\t\t\t%s'%'\r\n\t\t\t'.join(canvas_types))
    args = p.parse_args()

    # parse canvas type argument
    if args.c_type is not None:
        canvas_type = get_canvas_by_name(args.c_type)
    else:
        canvas_type = None

    # create main frame
    app = wx.App()
    #root = PlotlibFrame(None, multiplot=True,canvas_class=canvas_type)
    root = PlotlibFrame(None)
    root.Show()
    app.MainLoop()