#!/usr/bin/env python
from __future__ import unicode_literals, absolute_import, division, print_function

import sys, os
import traceback
import math

from loadpull.ats_tuner_file import TunerFile
from loadpull.ats_tuner_control import Tuner, Controller, init_tuners
from network_params import Touchstone

try:
    inpf = raw_input
except NameError:
    inpf = input


def setup( fname ):
    """read in data files and do necessary setup"""
    data = {}
    
    # read config file
    cfg = {}
    with open(fname,'r') as fp:
        exec(compile(fp.read(),fname,'exec'),globals(),cfg)
    
    # read tuner file
    data['tuner_file'] = t = TunerFile(cfg['tuner_file'])    
    
    # read fixture file if defined
    f = cfg.get('fixture',None)
    if f:
        fixture = Touchstone(f)
    else:
        fixture = None
        
    # determine the side of the DUT we are on
    s = cfg.get('side','input').strip().lower()
    if s.startswith('i'):
        data['side'] = 1
    elif s.startswith('o'):
        data['side'] = 2
    else:
        raise ValueError("invalid value for 'side' in config file")
    
    # if more than 1 frequency is present in the tuner file
    # prompt for which frequency to use
    if t.num_freqs > 1:
        print('**** This tuner file contains multiple frequencies ****')
        print('  Please select one of the frequencies from the list below')
        print('')
        
        flist = t.freqs
        for i,f in enumerate(flist):
            print('  %d  - %.2f GHz'%(i+1,flist[i]*1.0e-9))
        print('')
        
        while True:
            try:
                i = int(inpf('? ')) - 1
                data['frequency'] = flist[i]
                break
            except Exception:
                print(' ** invalid selection **')
        
    else:
        data['frequency'] = t.freqs[0]
    
    fixture_s = None
    if fixture:
        fixture_s = fixture.extract_raw(data['frequency'])
        
    # prompt for the termination impedance
    term = prompt_for_impedance('Termination impedance (mag angle)? ')
    
    # compute the total termination impedance
    if fixture_s is not None:
        #if data['side'] == 2:
        #    # output side tuner
        #    data['term'] = fixture_s[1,1] + fixture_s[1,0]*fixture_s[0,1]*term / (1.0 - fixture_s[0,0]*term)
        #else:
        #    # input side tuner
        #    data['term'] = fixture_s[0,0] + fixture_s[1,0]*fixture_s[0,1]*term / (1.0 - fixture_s[1,1]*term)
        data['term'] = fixture_s[0,0] + fixture_s[1,0]*fixture_s[0,1]*term / (1.0 - fixture_s[1,1]*term)

    else:
        # no fixture, so the termination is as specified
        data['term'] = term
    
    print("Term R/I: (%.3f, %.3f)"%(data['term'].real,data['term'].imag))
    print("Term M/A: (%.4f < %.2f)"%(abs(data['term']),math.atan2(data['term'].imag,data['term'].real)*180/math.pi))
    
    # create and check the tuner controller and tuner
    data['controller'] = Controller(**cfg['controller_params'])
    data['tuner'] = data['controller'].add_tuner(**cfg['tuner_params'])
    data['controller'].check()
    
    # prompt to initialize tuners
    r = inpf('(re-)initialize tuner (y/N)? ').strip().lower()
    if r.startswith('y'):
        print('please wait, initializing tuner ...')
        init_tuners()
    
    return data
    

def prompt_for_impedance( prompt="Impedance (mag angle)? " ):
    "prompt the user for an impedance value"
    while True:
        try:
            r = inpf(prompt).strip().split()
            if len(r) != 2:
                raise ValueError()
            mag, ang = float(r[0]), float(r[1])
            
            if mag > 1.0 or mag < 0.0:
                raise ValueError()
            
            return complex(mag*math.cos(ang*math.pi/180.0),mag*math.sin(ang*math.pi/180.0))
        except KeyboardInterrupt:
            raise
        except Exception:
            print(" ** invalid entry **")
    
    
def tuning_loop( data ):
    """run the tuning loop where updates are made to tuner positions
    and the expected S-parameters of the system are calculated
    
    """
    
    print('In this tuning loop the program will ask for a magnitude')
    print('and angle to use in setting the tuner impedance - it will')
    print('then calculate the expected total impedance of the tuner,')
    print('fixture, and termination and print it.  The calcuated')
    print('S-parameters can then be compared to those measured on')
    print('a network analyzer.') 
    print('Press Ctrl-C to exit.')
    
    tf = data['tuner_file']
    tuner = data['tuner']
    fr = data['frequency']
    term = data['term']
    
    while True:
        try:
            imp = prompt_for_impedance('Tuner impedance (mag angle)? ')
            
            # find the closest impedance in the tuner file
            p = tf.find_nearest_position(imp,freq=fr,swapped=True)
            
            # move the tuner to that position
            print('moving tuner ...')
            tuner.move(*p.position)
            print('tuner position: {}'.format(tuner.position))
            
            # calculate the expected impedance
            s = p.spars[0]
            ic = s[1,1] + s[1,0]*s[0,1]*term / (1.0 - s[0,0]*term)
        
            if ic.real == 0.0 and ic.imag == 0.0:
                angc = 0.0
            else:
                angc = math.atan2(ic.imag,ic.real)*180.0/math.pi
            
            # print the impedance
            print('')
            print("R/I: (%.3f, %.3f)"%(ic.real,ic.imag))
            print("M/A: (%.4f < %.2f)"%(abs(ic),angc))
            print('')
        
        except KeyboardInterrupt:
            print('exiting...')
            break
        except Exception:
            traceback.print_exc()

def main():
    "entry point"
    
    if len(sys.argv) < 2:
        fname = inpf("Config file name? ").strip()
    elif len(sys.argv) > 2:
        print("USAGE: %s [configfile]"%sys.argv[0])
        sys.exit(1)
    else:
        fname = sys.argv[1]
    
    data = setup(fname)
    tuning_loop(data)
    
if __name__ == '__main__':
    main()
