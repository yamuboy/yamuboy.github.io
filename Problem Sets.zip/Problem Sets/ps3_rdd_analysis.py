"""
ECON 5193 - Problem Set 3: Regression Discontinuity Design
Complete Analysis Script
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# Load Data
# ============================================================
df = pd.read_csv('/mnt/user-data/uploads/scholarship_rdd_data.csv')
print("=" * 60)
print("DATA SUMMARY")
print("=" * 60)
print(f"Observations: {len(df)}")
print(f"\nVariable summary:\n{df.describe().round(3).to_string()}")
print(f"\nScholarship by cutoff:")
print(df.groupby(df['exam_score'] >= 50)['scholarship'].mean())

cutoff = 50

# ============================================================
# Question 4a: Scatter plot - exam_score vs years_education
# ============================================================
fig, ax = plt.subplots(figsize=(10, 6))

# Binned scatter
bins = np.arange(0, 101, 2)
df['score_bin'] = pd.cut(df['exam_score'], bins=bins, labels=False)
bin_means = df.groupby('score_bin').agg(
    score_mid=('exam_score', 'mean'),
    years_ed=('years_education', 'mean')
).dropna()

below = bin_means[bin_means['score_mid'] < cutoff]
above = bin_means[bin_means['score_mid'] >= cutoff]

ax.scatter(below['score_mid'], below['years_ed'], color='steelblue', alpha=0.7, s=40, label='Below cutoff')
ax.scatter(above['score_mid'], above['years_ed'], color='firebrick', alpha=0.7, s=40, label='Above cutoff')

# Fitted lines
for subset, color in [(df[df['exam_score'] < cutoff], 'steelblue'),
                       (df[df['exam_score'] >= cutoff], 'firebrick')]:
    X = sm.add_constant(subset['exam_score'])
    model = sm.OLS(subset['years_education'], X).fit()
    x_pred = np.linspace(subset['exam_score'].min(), subset['exam_score'].max(), 100)
    y_pred = model.predict(sm.add_constant(x_pred))
    ax.plot(x_pred, y_pred, color=color, linewidth=2)

ax.axvline(x=cutoff, color='black', linestyle='--', linewidth=1.5, label='Cutoff (50)')
ax.set_xlabel('Exam Score', fontsize=12)
ax.set_ylabel('Years of Education', fontsize=12)
ax.set_title('Figure 1: Years of Education by Exam Score', fontsize=14)
ax.legend(fontsize=10)
plt.tight_layout()
plt.savefig('/home/claude/fig1_years_education.png', dpi=150)
plt.close()
print("\nFigure 1 saved.")

# ============================================================
# Question 4b: Binned scatter - enrolled_secondary
# ============================================================
fig, ax = plt.subplots(figsize=(10, 6))

bins_enroll = np.arange(0, 101, 2)
df['score_bin2'] = pd.cut(df['exam_score'], bins=bins_enroll, labels=False)
bin_means2 = df.groupby('score_bin2').agg(
    score_mid=('exam_score', 'mean'),
    enrolled=('enrolled_secondary', 'mean')
).dropna()

below2 = bin_means2[bin_means2['score_mid'] < cutoff]
above2 = bin_means2[bin_means2['score_mid'] >= cutoff]

ax.scatter(below2['score_mid'], below2['enrolled'], color='steelblue', alpha=0.7, s=40, label='Below cutoff')
ax.scatter(above2['score_mid'], above2['enrolled'], color='firebrick', alpha=0.7, s=40, label='Above cutoff')

# Fitted lines
for subset, color in [(df[df['exam_score'] < cutoff], 'steelblue'),
                       (df[df['exam_score'] >= cutoff], 'firebrick')]:
    X = sm.add_constant(subset['exam_score'])
    model = sm.OLS(subset['enrolled_secondary'], X).fit()
    x_pred = np.linspace(subset['exam_score'].min(), subset['exam_score'].max(), 100)
    y_pred = model.predict(sm.add_constant(x_pred))
    ax.plot(x_pred, y_pred, color=color, linewidth=2)

ax.axvline(x=cutoff, color='black', linestyle='--', linewidth=1.5, label='Cutoff (50)')
ax.set_xlabel('Exam Score', fontsize=12)
ax.set_ylabel('Enrollment Rate', fontsize=12)
ax.set_title('Figure 2: Secondary School Enrollment by Exam Score (Binned Means)', fontsize=14)
ax.legend(fontsize=10)
plt.tight_layout()
plt.savefig('/home/claude/fig2_enrollment.png', dpi=150)
plt.close()
print("Figure 2 saved.")

# ============================================================
# Question 5a: McCrary density test / histogram
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Histogram
axes[0].hist(df['exam_score'], bins=50, color='steelblue', edgecolor='white', alpha=0.8)
axes[0].axvline(x=cutoff, color='red', linestyle='--', linewidth=2, label='Cutoff (50)')
axes[0].set_xlabel('Exam Score', fontsize=12)
axes[0].set_ylabel('Frequency', fontsize=12)
axes[0].set_title('Figure 3a: Distribution of Exam Scores', fontsize=13)
axes[0].legend()

# Finer bins near cutoff
near_cutoff = df[(df['exam_score'] >= 35) & (df['exam_score'] <= 65)]
axes[1].hist(near_cutoff['exam_score'], bins=30, color='steelblue', edgecolor='white', alpha=0.8)
axes[1].axvline(x=cutoff, color='red', linestyle='--', linewidth=2, label='Cutoff (50)')
axes[1].set_xlabel('Exam Score', fontsize=12)
axes[1].set_ylabel('Frequency', fontsize=12)
axes[1].set_title('Figure 3b: Density Near Cutoff (35-65)', fontsize=13)
axes[1].legend()

plt.tight_layout()
plt.savefig('/home/claude/fig3_density.png', dpi=150)
plt.close()

# Formal McCrary-style test: bin counts above vs below
bin_width = 1
bins_mccrary = np.arange(30, 71, bin_width)
counts, edges = np.histogram(df['exam_score'], bins=bins_mccrary)
bin_centers = (edges[:-1] + edges[1:]) / 2

below_counts = counts[bin_centers < cutoff]
above_counts = counts[bin_centers >= cutoff]

# Compare density just below and just above
just_below = df[(df['exam_score'] >= 45) & (df['exam_score'] < 50)]
just_above = df[(df['exam_score'] >= 50) & (df['exam_score'] < 55)]
density_ratio = len(just_above) / len(just_below)
# Chi-squared test on bins near cutoff
observed = np.array([len(just_below), len(just_above)])
expected = np.array([observed.sum()/2, observed.sum()/2])
chi2_stat = np.sum((observed - expected)**2 / expected)
chi2_p = 1 - stats.chi2.cdf(chi2_stat, df=1)

print("\n" + "=" * 60)
print("QUESTION 5a: DENSITY TEST")
print("=" * 60)
print(f"Students scoring 45-49.99: {len(just_below)}")
print(f"Students scoring 50-54.99: {len(just_above)}")
print(f"Density ratio (above/below): {density_ratio:.3f}")
print(f"Chi-squared test: stat = {chi2_stat:.3f}, p-value = {chi2_p:.4f}")

# ============================================================
# Question 5b: Covariate balance test
# ============================================================
print("\n" + "=" * 60)
print("QUESTION 5b: COVARIATE BALANCE (bandwidth = 10)")
print("=" * 60)

bw = 10
df_bw = df[(df['exam_score'] >= cutoff - bw) & (df['exam_score'] <= cutoff + bw)]
below_bw = df_bw[df_bw['exam_score'] < cutoff]
above_bw = df_bw[df_bw['exam_score'] >= cutoff]

covariates = ['female', 'parent_education', 'household_wealth', 'urban', 'distance_to_school']
balance_results = []

for cov in covariates:
    mean_below = below_bw[cov].mean()
    mean_above = above_bw[cov].mean()
    diff = mean_above - mean_below
    tstat, pval = stats.ttest_ind(above_bw[cov].dropna(), below_bw[cov].dropna())
    balance_results.append({
        'Variable': cov,
        'Mean Below': round(mean_below, 3),
        'Mean Above': round(mean_above, 3),
        'Difference': round(diff, 3),
        't-statistic': round(tstat, 3),
        'p-value': round(pval, 3)
    })

balance_df = pd.DataFrame(balance_results)
print(balance_df.to_string(index=False))

# ============================================================
# Question 5c: Placebo test - RDD with parent_education as outcome
# ============================================================
print("\n" + "=" * 60)
print("QUESTION 5c: PLACEBO TEST (outcome = parent_education)")
print("=" * 60)

df_placebo = df[(df['exam_score'] >= cutoff - bw) & (df['exam_score'] <= cutoff + bw)].copy()
df_placebo['D'] = (df_placebo['exam_score'] >= cutoff).astype(int)
df_placebo['X_c'] = df_placebo['exam_score_centered']
df_placebo['D_X_c'] = df_placebo['D'] * df_placebo['X_c']

X_placebo = sm.add_constant(df_placebo[['D', 'X_c', 'D_X_c']])
y_placebo = df_placebo['parent_education']
model_placebo = sm.OLS(y_placebo, X_placebo).fit(cov_type='HC1')
print(model_placebo.summary2().tables[1].to_string())

# ============================================================
# Question 6a: Main RDD - years_education, bw=10
# ============================================================
print("\n" + "=" * 60)
print("QUESTION 6a: RDD EFFECT ON YEARS OF EDUCATION (bw=10)")
print("=" * 60)

def run_rdd(data, outcome, bandwidth, covariates_list=None):
    """Run local linear RDD regression with different slopes on each side."""
    df_sub = data[(data['exam_score'] >= cutoff - bandwidth) & 
                  (data['exam_score'] <= cutoff + bandwidth)].copy()
    df_sub['D'] = (df_sub['exam_score'] >= cutoff).astype(int)
    df_sub['X_c'] = df_sub['exam_score_centered']
    df_sub['D_X_c'] = df_sub['D'] * df_sub['X_c']
    
    regressors = ['D', 'X_c', 'D_X_c']
    if covariates_list:
        regressors += covariates_list
    
    X = sm.add_constant(df_sub[regressors])
    y = df_sub[outcome]
    model = sm.OLS(y, X).fit(cov_type='HC1')
    return model, len(df_sub)

model_6a, n_6a = run_rdd(df, 'years_education', 10)
print(f"N = {n_6a}")
print(model_6a.summary2().tables[1].to_string())

# ============================================================
# Question 6b: Bandwidth sensitivity (5, 10, 15)
# ============================================================
print("\n" + "=" * 60)
print("QUESTION 6b: BANDWIDTH SENSITIVITY - YEARS OF EDUCATION")
print("=" * 60)

bw_results = []
for bw_val in [5, 10, 15]:
    m, n = run_rdd(df, 'years_education', bw_val)
    bw_results.append({
        'Bandwidth': bw_val,
        'Estimate (D)': round(m.params['D'], 4),
        'Std Error': round(m.bse['D'], 4),
        't-stat': round(m.tvalues['D'], 3),
        'p-value': round(m.pvalues['D'], 4),
        '95% CI Lower': round(m.conf_int().loc['D', 0], 4),
        '95% CI Upper': round(m.conf_int().loc['D', 1], 4),
        'N': n
    })

bw_df = pd.DataFrame(bw_results)
print(bw_df.to_string(index=False))

# ============================================================
# Question 6c: Effect on enrollment
# ============================================================
print("\n" + "=" * 60)
print("QUESTION 6c: RDD EFFECT ON ENROLLMENT (bw=10)")
print("=" * 60)

model_6c, n_6c = run_rdd(df, 'enrolled_secondary', 10)
print(f"N = {n_6c}")
print(model_6c.summary2().tables[1].to_string())

# Also OLS with LPM
print("\nEnrollment bandwidth sensitivity:")
enroll_bw_results = []
for bw_val in [5, 10, 15]:
    m, n = run_rdd(df, 'enrolled_secondary', bw_val)
    enroll_bw_results.append({
        'Bandwidth': bw_val,
        'Estimate (D)': round(m.params['D'], 4),
        'Std Error': round(m.bse['D'], 4),
        'p-value': round(m.pvalues['D'], 4),
        'N': n
    })
print(pd.DataFrame(enroll_bw_results).to_string(index=False))

# ============================================================
# Question 6d: With covariates
# ============================================================
print("\n" + "=" * 60)
print("QUESTION 6d: RDD WITH COVARIATES (bw=10)")
print("=" * 60)

covs = ['female', 'parent_education', 'household_wealth', 'urban', 'distance_to_school']
model_6d, n_6d = run_rdd(df, 'years_education', 10, covariates_list=covs)
print(f"N = {n_6d}")
print(model_6d.summary2().tables[1].to_string())

print(f"\nComparison:")
print(f"  Without controls: D = {model_6a.params['D']:.4f} (SE = {model_6a.bse['D']:.4f})")
print(f"  With controls:    D = {model_6d.params['D']:.4f} (SE = {model_6d.bse['D']:.4f})")

# ============================================================
# Additional: First stage check (sharp RD verification)
# ============================================================
print("\n" + "=" * 60)
print("FIRST STAGE CHECK: Scholarship receipt at cutoff")
print("=" * 60)
model_fs, n_fs = run_rdd(df, 'scholarship', 10)
print(f"N = {n_fs}")
print(model_fs.summary2().tables[1].to_string())

print("\n\nDONE - All analyses completed.")
