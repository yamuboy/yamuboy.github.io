

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "protos.h"
#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "neuron.h"


extern void Set_Up_Neural_Network(NeuralNet *, SETUP *, Cntrl *);

void Set_Up_Neural_Network(NeuralNet *NNet, SETUP *Parms, Cntrl *C)
{
   int i,j;
   
   NNet->Nlayers = 0 ;
   for (i=0;i<=MAX_Layers;i++)
   {
      if (C->NNpl[i] != 0)  
	  {
		  NNet->Nlayers++ ;
	  }
   }
   
   
   printf("====================================================\n");
   printf("ALLOCATING memory for Structuring the Neural Network\n");
   printf("====================================================\n");
   printf("\n\n");
   printf("   There are %d layers in the Network \n", NNet->Nlayers);
   

   NNet->Nl = ivector(1,NNet->Nlayers);
   NNet->Nmax = 0 ;
   j = 0;
   for (i=0;i<=MAX_Layers;i++)
   {
	  if (C->NNpl[i] != 0)  
	  {
         NNet->Nl[i+1] = C->NNpl[i] ;
		 if (NNet->Nl[i+1]>NNet->Nmax) NNet->Nmax = NNet->Nl[i+1] ;
         printf("   There are %3d Neurons in layer %3d.\n", NNet->Nl[i+1], i+1);
		 j = j + NNet->Nl[i+1]; 
	  }
   }
   NNet->Total_Neurons = j ;
   NNet->No = NNet->Nl[NNet->Nlayers] ;

   printf("\n");
   printf("=====>  The most Neurons in any layer = %3d \n", NNet->Nmax);
   printf("=====>  The TOTAL number of Neurons is = %3d \n", NNet->Total_Neurons);
   printf("\n\n");
   
   printf("DONE ALLOCATING memory for Neural Network\n");
   printf("=========================================\n");

}
