

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "protos.h"
#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "neuron.h"

extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *NNet);
extern void Update_Weights(NeuralNet *NNet);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);

void Save_Weights_To_File(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{ 
   int i,j,ic;
   
   C->Output  = fopen(C->Wfile,WRITE);

   printf("\n\n");
   printf("=====>>> Saving all Neural synaptic weights to file: %s \n", C->Wfile);
   printf("\n");
   
   for (i=1; i<=NNet->Nlayers; i++)
   {
      for (j=1; j<=NNet->Nl[i]; j++)
	  {
        if (i>1)
		{
		   for (ic=1; ic<=NNet->Nl[i-1]; ic++)
		   {
             fprintf(C->Output, "Layer = %d   Neuron = %d  Input = %d  Weight = %12.10f\n", 
				                         i,j,ic, NNet->Nron[i][j].w[ic]); 
		   }
		}
	    else
		{
		   for (ic=1; ic<=NNet->Ni; ic++)
		   {
 	          fprintf(C->Output, "Layer = %d   Neuron = %d  Input = %d  Weight = %12.10f\n", 
				                         i,j,ic, NNet->Nron[i][j].w[ic]); 
		   }
		}
	  }
   }

   fclose(C->Output);

}


void display_weights(NeuralNet NNet)
{ 
   int i,j,ic;

   
   printf("\n\n");
   printf("=======================================\n");
   printf("Displaying all Neural synaptic weights\n");
   printf("=======================================\n");

   printf("\n");
   
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
        if (i>1)
		{
		   for (ic=1; ic<=NNet.Nl[i-1]; ic++)
		   {
             printf("N[%2d][%2d].W[%2d] = %6f\n", i,j,ic, NNet.Nron[i][j].w[ic]); 
		   }
		}
	    else
		{
		   for (ic=1; ic<=NNet.Ni; ic++)
		   {
 	          printf("N[%2d][%2d].W[%2d] = %6f\n", i,j,ic, NNet.Nron[i][j].w[ic]); 
		   }
		}
	  }
   }
}


void display_outputs(NeuralNet NNet, SETUP Parms)
{ 
   int i,j;

   printf("\n");
 
   for (i=1; i<=NNet.Nlayers; i++)
   {
      for (j=1; j<=NNet.Nl[i]; j++)
	  {
         if (Parms.DB == 2 || Parms.DB == 21)
		 {
		    printf("N[%2d][%2d].o = %6f\n", i,j, NNet.Nron[i][j].o); 
		 }
		 else if (Parms.DB == 22)
		 {
			printf("N[%2d][%2d].e = %6f\n", i,j, NNet.Nron[i][j].e); 
		 }
		 else if (Parms.DB == 23)
		 {
			printf("N[%2d][%2d].dode = %6f\n", i,j, NNet.Nron[i][j].dode); 
		 }
	  }
   }

}




void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms)
{ 

	int ii, j; 

    printf("\n\n");
    printf("========================================\n");
    printf("======= Deallocating ALL Memory ========\n");
    printf("========================================\n");


    free_ivector(NNet->Nl, 1, NNet->Nlayers);
    free_Nmatrix(NNet->Nron,1,NNet->Nlayers, 1,NNet->Nmax);
    for (ii=1; ii<=NNet->Nlayers; ii++)
    {
       for (j=1; j<=NNet->Nl[ii]; j++)
	   {
	      if (ii>1)
		  {
	         free_dvector(NNet->Nron[ii][j].w, 1, NNet->Nl[ii-1]);
			 free_dvector(NNet->Nron[ii][j].wold, 1, NNet->Nl[ii-1]);
		  }
	      else
		  {
             free_dvector(NNet->Nron[ii][j].w, 1,NNet->Ni);
			 free_dvector(NNet->Nron[ii][j].wold, 1,NNet->Ni);
		  }
	   }
    }

    printf("\n======= DONE Deallocating Memory =======\n");

}


void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[])
{ 

	int i,j,ii;
	double y;

/* ----- Implement forward propagation ----- */  
//	   printf("\n\n============ Forward Propagation ===========\n");
       for (i=1; i<=NNet->Nlayers; i++)
	   {
          for (j=1; j<=NNet->Nl[i]; j++)
		  {
		     y = 0 ;
             if (i>1)
			 {
		        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
				{
                   y = y + NNet->Nron[i][j].w[ii] * NNet->Nron[i-1][ii].o;   
				}
				
			 }
	         else
			 {
		        for (ii=1; ii<=NNet->Ni; ii++)
				{
				   y = y + NNet->Nron[i][j].w[ii] * TD[ic].dT[ii];
//				   printf("        D%d  L%d  N%d  N%d%d.w%d = %f  TD[%d].dT%d=%f  TR[%d].dR%d=%f\n", 
//					   ic, i,j, i, j, ii, NNet.Nron[i][j].w[ii], 
//					   ic, ii, TD[ic].dT[ii], ic, ii, TD[ic].dR);
			    }
			 }
			 NNet->Nron[i][j].e  = y ;
			 NNet->Nron[i][j].o  = sigmoid(Parms->SLamda, y) ;
			 NNet->Nron[i][j].dode = Parms->SLamda*NNet->Nron[i][j].o*(1-NNet->Nron[i][j].o) ;
//			 printf("FP: ic=%3.1d   n%d%d.e= %5f   n%d%d.o = %5f  dode = %5f\n",
//					      ic, i,j, NNet.Nron[i][j].e, i,j, NNet.Nron[i][j].o, NNet.Nron[i][j].dode); 
		  }
       }

	   if (Parms->DB == 21 || Parms->DB == 22 || Parms->DB == 23) display_outputs(NNet, Parms);

/* 
* ----- Implement BACK propagation ----- 
* ----- Compute the derivitive Error terms -----
*/  
//	   printf("\n\n============ Error Calculation ===========\n");
	   for (i=NNet->Nlayers; i>0; i--)
	   {
          for (j=NNet->Nl[i]; j>0; j--)
		  { 

			 
             if (i==NNet->Nlayers)
			 {
                NNet->Nron[i][j].oerror = (TD[ic].dR - NNet->Nron[i][j].o)*NNet->Nron[i][j].dode;   
			 }
		     else
			 {
				y = 0;
				for (ii=1; ii<=NNet->Nl[i+1]; ii++)
				{
//					printf("         oooo ii = %d   NN.n = %d\n", ii, NNet.Nl[i+1]);
                   y = y + NNet->Nron[i+1][ii].oerror * NNet->Nron[i+1][ii].w[j];   
//				   printf("                        zz L%d N%d W%d %4f  %4f\n",i,j,ii,
//						                            NNet.Nron[i+1][ii].oerror,NNet.Nron[i+1][ii].w[j] );
				}
			    NNet->Nron[i][j].oerror = NNet->Nron[i][j].dode * y;
//				printf("XX L%d N%d W%d %4f\n",i,j,ii,NNet.Nron[i][j].oerror);
			 }
//			 printf("BP:     ic=%3.1d  n%d%d.oerror = %4f  \n",
//					      ic, i,j, NNet.Nron[i][j].oerror);

		  } 
	   }  

//	   if (Parms.DB == 22) display_errors(NNet);
	   
/* 
* ----- Update Weights ----- 
*/  
//	   printf("\n\n============ Weight Update ===========\n");
	   for (i=1; i<=NNet->Nlayers; i++)
	   {
          for (j=1; j<=NNet->Nl[i]; j++)
		  {
		     if (i>1)
			 {
		        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
				{
                   NNet->Nron[i][j].w[ii] = NNet->Nron[i][j].w[ii] + 
					     2*Parms->Eta*NNet->Nron[i][j].oerror*NNet->Nron[i][j].o;
  //                 printf("wu:            ic=%d   n%d%d.W%d = %6f \n", 
//					   ic, i, j, ii, NNet.Nron[i][j].w[ii]); 
				}
			 }
	         else
			 {
		        for (ii=1; ii<=NNet->Ni; ii++)
				{
				   NNet->Nron[i][j].w[ii] = NNet->Nron[i][j].w[ii] + 
					     2*Parms->Eta*NNet->Nron[i][j].oerror*TD[ic].dT[ii];
//				   printf("WU:            ic=%d   n%d%d.w%d = %6f DELterm=%f  TD = %f \n",
//					                         ic,    i,j, ii, NNet.Nron[i][j].w[ii],
//											 2*Parms.Eta*NNet.Nron[i][j].oerror*TD[ic].dT[ii],
//											 TD[ic].dT[ii]); 
			    }
			 }
 		  }
       }
       
	   if (Parms->DB == 22) display_weights(NNet);
	   if (Parms->DB == 2) display_outputs(NNet, Parms);
	   
	   
//-----------------end	

}




void Random_Init_Weights(long *rg, NeuralNet *NNet, SETUP *Parms)
{ 
   int ii, j, ic ;
   double rn, rw, rs ;
   long rgen = *rg;

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
		  if (ii>1)
		 {
	        for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
//			   rn = ran1(&rgen)-0.5;
//			   rw = Parms->WF*rs*ran1(&rgen);
               rn = (double)rand();
			   rs = 1;
			   if (rn<0.5*32767) rs = -1 ;
			   rw = Parms->WF*rs*rand()/32767;
			   NNet->Nron[ii][j].w[ic] = rw ;
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
//			   rn = ran1(&rgen)-0.5;
//			   rw = Parms->WF*rs*ran1(&rgen);
			   rn = (double)rand();
			   rs = 1;
			   if (rn<0.5*32767) rs = -1 ;
			   rw = Parms->WF*rs*rand()/32767;
	           NNet->Nron[ii][j].w[ic] = rw ;
			}
		 }
	  }
   }
   rg = &rgen;
}



#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define MASK 123459876

double ran0(long *idum)
{
	long k;
	double ans;

	*idum ^= MASK;
	k=(*idum)/IQ;
	*idum=IA*(*idum-k*IQ)-IR*k;
	if (*idum < 0) *idum += IM;
	ans=AM*(*idum);
	*idum ^= MASK;
	return ans;
}
#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef MASK

void Forward_Prop(int ic, NeuralNet *NNet, SETUP *Parms, Data *TD)
{ 

   int i,j,ii;
   double y;

   for (i=1; i<=NNet->Nlayers; i++)
   {
      for (j=1; j<=NNet->Nl[i]; j++)
	  {
	     y = 0 ;
         if (i>1)
		 {
	        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
			{
                y = y + NNet->Nron[i][j].w[ii] * NNet->Nron[i-1][ii].o;   
			}
		 }
	     else
		 {
	        for (ii=1; ii<=NNet->Ni; ii++)
			{
			   y = y + NNet->Nron[i][j].w[ii] * TD->dT[ic][ii];
		    }
		 }
		 NNet->Nron[i][j].o  = sigmoid(Parms->SLamda, y) ;
	  }
   }
}



void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[])
{ 

   int i,j,ii;
   double y;

   for (i=1; i<=NNet->Nlayers; i++)
   {
      for (j=1; j<=NNet->Nl[i]; j++)
	  {
	     y = 0 ;
         if (i>1)
		 {
	        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
			{
                y = y + NNet->Nron[i][j].w[ii] * NNet->Nron[i-1][ii].o;   
			}
		 }
	     else
		 {
	        for (ii=1; ii<=NNet->Ni; ii++)
			{
			   y = y + NNet->Nron[i][j].w[ii] * TD[ic].dT[ii];
		    }
		 }
		 NNet->Nron[i][j].o  = sigmoid(Parms->SLamda, y) ;
	  }
   }
}


void Store_Weights(NeuralNet *NNet)
{
   int j,ii,ic;	

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {   
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
  	     if (ii>1)
		 {
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   NNet->Nron[ii][j].wold[ic] = NNet->Nron[ii][j].w[ic];
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   NNet->Nron[ii][j].wold[ic] = NNet->Nron[ii][j].w[ic];
			}
		 }
	  }
   }
}


void Update_Weights(NeuralNet *NNet)
{
   int j,ii,ic;	

   for (ii=1; ii<=NNet->Nlayers; ii++)
   {   
      for (j=1; j<=NNet->Nl[ii]; j++)
	  {
  	     if (ii>1)
		 {
		    for (ic=1; ic<=NNet->Nl[ii-1]; ic++)
			{
			   NNet->Nron[ii][j].w[ic] = NNet->Nron[ii][j].wold[ic];
			}
		 }
	     else
		 {
		    for (ic=1; ic<=NNet->Ni; ic++)
			{
			   NNet->Nron[ii][j].w[ic] = NNet->Nron[ii][j].wold[ic];
			}
		 }
	  }
   }
}






void Weight_Correct(int ic, NeuralNet *NNet, SETUP *Parms, Data *TD)
{ 

	int i,j,ii;
	double y;

/* ----- Implement forward propagation ----- */  
//	   printf("\n\n============ Forward Propagation ===========\n");
       for (i=1; i<=NNet->Nlayers; i++)
	   {
          for (j=1; j<=NNet->Nl[i]; j++)
		  {
		     y = 0 ;
             if (i>1)
			 {
		        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
				{
                   y = y + NNet->Nron[i][j].w[ii] * NNet->Nron[i-1][ii].o;   
				}
				
			 }
	         else
			 {
		        for (ii=1; ii<=NNet->Ni; ii++)
				{
				   y = y + NNet->Nron[i][j].w[ii] * TD->dT[ic][ii];
//				   printf("        D%d  L%d  N%d  N%d%d.w%d = %f  TD[%d].dT%d=%f  TR[%d].dR%d=%f\n", 
//					   ic, i,j, i, j, ii, NNet.Nron[i][j].w[ii], 
//					   ic, ii, TD[ic].dT[ii], ic, ii, TD[ic].dR);
			    }
			 }
			 NNet->Nron[i][j].e  = y ;
			 NNet->Nron[i][j].o  = sigmoid(Parms->SLamda, y) ;
			 NNet->Nron[i][j].dode = Parms->SLamda*NNet->Nron[i][j].o*(1-NNet->Nron[i][j].o) ;
//			 printf("FP: ic=%3.1d   n%d%d.e= %5f   n%d%d.o = %5f  dode = %5f\n",
//					      ic, i,j, NNet.Nron[i][j].e, i,j, NNet.Nron[i][j].o, NNet.Nron[i][j].dode); 
		  }
       }

	   if (Parms->DB == 21 || Parms->DB == 22 || Parms->DB == 23) display_outputs(NNet, Parms);

/* 
* ----- Implement BACK propagation ----- 
* ----- Compute the derivitive Error terms -----
*/  
//	   printf("\n\n============ Error Calculation ===========\n");
	   for (i=NNet->Nlayers; i>0; i--)
	   {
          for (j=NNet->Nl[i]; j>0; j--)
		  { 

			 
             if (i==NNet->Nlayers)
			 {
                NNet->Nron[i][j].oerror = (TD->dR[ic][1] - NNet->Nron[i][j].o)*NNet->Nron[i][j].dode;   
			 }
		     else
			 {
				y = 0;
				for (ii=1; ii<=NNet->Nl[i+1]; ii++)
				{
//					printf("         oooo ii = %d   NN.n = %d\n", ii, NNet.Nl[i+1]);
                   y = y + NNet->Nron[i+1][ii].oerror * NNet->Nron[i+1][ii].w[j];   
//				   printf("                        zz L%d N%d W%d %4f  %4f\n",i,j,ii,
//						                            NNet.Nron[i+1][ii].oerror,NNet.Nron[i+1][ii].w[j] );
				}
			    NNet->Nron[i][j].oerror = NNet->Nron[i][j].dode * y;
//				printf("XX L%d N%d W%d %4f\n",i,j,ii,NNet.Nron[i][j].oerror);
			 }
//			 printf("BP:     ic=%3.1d  n%d%d.oerror = %4f  \n",
//					      ic, i,j, NNet.Nron[i][j].oerror);

		  } 
	   }  

//	   if (Parms.DB == 22) display_errors(NNet);
	   
/* 
* ----- Update Weights ----- 
*/  
//	   printf("\n\n============ Weight Update ===========\n");
	   for (i=1; i<=NNet->Nlayers; i++)
	   {
          for (j=1; j<=NNet->Nl[i]; j++)
		  {
		     if (i>1)
			 {
		        for (ii=1; ii<=NNet->Nl[i-1]; ii++)
				{
                   NNet->Nron[i][j].w[ii] = NNet->Nron[i][j].w[ii] + 
					     2*Parms->Eta*NNet->Nron[i][j].oerror*NNet->Nron[i][j].o;
  //                 printf("wu:            ic=%d   n%d%d.W%d = %6f \n", 
//					   ic, i, j, ii, NNet.Nron[i][j].w[ii]); 
				}
			 }
	         else
			 {
		        for (ii=1; ii<=NNet->Ni; ii++)
				{
				   NNet->Nron[i][j].w[ii] = NNet->Nron[i][j].w[ii] + 
					     2*Parms->Eta*NNet->Nron[i][j].oerror*TD->dT[ic][ii];
//				   printf("WU:            ic=%d   n%d%d.w%d = %6f DELterm=%f  TD = %f \n",
//					                         ic,    i,j, ii, NNet.Nron[i][j].w[ii],
//											 2*Parms.Eta*NNet.Nron[i][j].oerror*TD[ic].dT[ii],
//											 TD[ic].dT[ii]); 
			    }
			 }
 		  }
       }
       
	   if (Parms->DB == 22) display_weights(NNet);
	   if (Parms->DB == 2) display_outputs(NNet, Parms);
	   
	   
//-----------------end	

}


