

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "protos.h"
#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "neuron.h"


extern void Validate(NeuralNet NNet, SETUP Parms, TData TD[], Cntrl C);
extern void Validat(NeuralNet , SETUP , Data, Cntrl);

void Validate(NeuralNet NNet, SETUP Parms, TData TD[], Cntrl C)
{ 
   int ic, i, ii, j ;
   double y;

   printf("\nOpening Output Data File ===> %s \n\n",C.Dfile);
   C.Output = fopen(C.Outfile, WRITE);

   printf("\n\n============ Data Validation ===========\n");
   for (ic=1; ic<=Parms.DATAmax ; ic++)
   {
    
      for (i=1; i<=NNet.Nlayers; i++)
	  {
         for (j=1; j<=NNet.Nl[i]; j++)
		 {
		    y = 0 ;
            if (i>1)
			{
		       for (ii=1; ii<=NNet.Nl[i-1]; ii++)
			   {
                   y = y + NNet.Nron[i][j].w[ii] * NNet.Nron[i-1][ii].o;   
			   }
			   NNet.Nron[i][j].o  = sigmoid(Parms.SLamda, y) ;
			}
	        else
			{
		       for (ii=1; ii<=NNet.Ni; ii++)
			   {
				   y = y + NNet.Nron[i][j].w[ii] * TD[ic].dT[ii];
			   }
			   NNet.Nron[i][j].o  = sigmoid(Parms.SLamda, y);
			}
		 }
      }
       printf("DATA=%3.1d   %f  %f   %f  ==>  %f  \n",
					  ic, TD[ic].dT[1], TD[ic].dT[2], TD[ic].dR, NNet.Nron[NNet.Nlayers][1].o); 
	   fprintf(C.Output,"%d   %f  %f   %f  %f \n",
					  ic, TD[ic].dT[1], TD[ic].dT[2], TD[ic].dR, NNet.Nron[NNet.Nlayers][1].o);
   }
   fclose(C.Output);	
}




void Validat(NeuralNet NNet, SETUP Parms, Data TD, Cntrl C)
{ 
   int ic, i, ii, j ;
   double y;

   printf("\n\n============ Validate the Network ===========\n");
   printf("\nOpening Output Data File ===> %s \n\n",C.Dfile);
   
   C.Output = fopen(C.Outfile, WRITE);

   for (ic=1; ic<=Parms.DATAmax ; ic++)
   {
    
      for (i=1; i<=NNet.Nlayers; i++)
	  {
         for (j=1; j<=NNet.Nl[i]; j++)
		 {
		    y = 0 ;
            if (i>1)
			{
		       for (ii=1; ii<=NNet.Nl[i-1]; ii++)
			   {
                   y = y + NNet.Nron[i][j].w[ii] * NNet.Nron[i-1][ii].o;   
			   }
			   NNet.Nron[i][j].o  = sigmoid(Parms.SLamda, y) ;
			}
	        else
			{
		       for (ii=1; ii<=NNet.Ni; ii++)
			   {
				   y = y + NNet.Nron[i][j].w[ii] * TD.dT[ic][ii];
			   }
			   NNet.Nron[i][j].o  = sigmoid(Parms.SLamda, y);
			}
		 }
      }
      printf("DATA=%3.1d   %f  %f   %f  ==>  %f  \n",
					  ic, TD.dT[ic][1], TD.dT[ic][2], TD.dR[ic][1], NNet.Nron[NNet.Nlayers][1].o); 
      fprintf(C.Output,"%d   %f  %f   %f  %f \n",
					  ic, TD.dT[ic][1], TD.dT[ic][2], TD.dR[ic][1], NNet.Nron[NNet.Nlayers][1].o);
   }
   fclose(C.Output);	
}
