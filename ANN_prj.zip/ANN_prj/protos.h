
#ifndef _PROTO_H_
#define _PROTO_H_

/* ----- External Prototypes ----- */
extern double ran1(long *);
extern double neuron(int , double *, double *, double);
extern double sigmoid(double , double);
extern double ds_dx(double , double );

extern void display_weights(NeuralNet);
extern void display_outputs(NeuralNet, SETUP);
extern void display_errors(NeuralNet);


//extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
//extern void Validate(NeuralNet NNet, SETUP Parms, TData TD[]);
//extern void Parse_Infile(NeuralNet *, SETUP *, Cntrl *);

#endif
