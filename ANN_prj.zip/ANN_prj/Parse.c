

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "protos.h"
#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "neuron.h"


extern void Parse_Infile(NeuralNet *, SETUP *, Cntrl *);

void Parse_Infile(NeuralNet *NNet, SETUP *Parms, Cntrl *C)
{ 

	char sval[MAXLINELENGTH],seq[MAXLINELENGTH],svar[MAXLINELENGTH];
	int line=0,num_words, i, ni=0, no=0, nin[12], nout[12];
	char linebuffer[MAXLINELENGTH];

	int dline=0, caught = 0, DATAmax=0;
//    int Vg_col, Vd_col, Id_col;
//    int Ninputs, N1, N2, N3, N4, N5, N6; 

    
	for (i=1;i<=MAX_Layers;i++)
	{	        
       C->NNpl[i] = 0 ; 
	}

    strcpy(C->Outfile, "ANN_0.dat");

	C->Input  = fopen(C->Infile,READ);
    printf("\n\n\nOpening Input File ===> %s \n",C->Infile);
    printf("Default Output File ===> %s  \n\n\n", C->Outfile);
	
	printf("Printing input file parameters\n");
	printf("======================================\n");

    while (getline(C->Input,linebuffer,MAXLINELENGTH) > 0)
    {
        if ((linebuffer[0] != '#')||(linebuffer[0] != '!'))
        {
            line++;
	        num_words = count_words_o(linebuffer,MAXLINELENGTH);
	        for (i=1;i<num_words;i++)
			{
	            get_word_o(linebuffer,MAXLINELENGTH,i  ,seq );
	            get_word_o(linebuffer,MAXLINELENGTH,i-1,svar);
       	        get_word_o(linebuffer,MAXLINELENGTH,i+1,sval);

                if (!strcmp("=",seq))
				{
					if (!strcmp("in_col",svar))
					{
						ni++ ;
						nin[ni] = atoi(sval);
                        printf(" Input #%d in Column %d \n",ni,nin[ni]);
					}
					if (!strcmp("out_col",svar))
					{
						no++ ;
						nout[no] = atoi(sval);
                        printf("Output #%d in Column %d \n",no,nout[no]);
					}
					if (!strcmp("Output_File",svar))
					{
						strcpy(C->Outfile, sval);
                        printf("%s = %s\n",svar,C->Outfile);
                    }
					if (!strcmp("Weight_File",svar))
					{
						strcpy(C->Wfile, sval);
                        printf("%s = %s\n",svar,C->Wfile);
                    }
					if (!strcmp("MAX_Random_Inits",svar))
					{
                        Parms->MRI = atoi(sval);
                        printf("%s = %d \n",svar,Parms->MRI);
					}
					if (!strcmp("PercentErrorChange",svar))
					{
                        Parms->PEC = atof(sval)/100;
                        printf("%s = %6f Percent Change\n",svar,100*Parms->PEC);
					}
					if (!strcmp("WeightScale",svar))
					{
                        Parms->WF = atof(sval);
                        printf("%s = %6f\n",svar,Parms->WF);
					}					
					if (!strcmp("DEBUG",svar))
					{
                        Parms->DB = atoi(sval);
                        printf("%s = %d\n",svar,Parms->DB);
					}
					if (!strcmp("Vg_col",svar))
					{
                        C->Vg_col = atoi(sval);
                        printf("%s = %d\n",svar,C->Vg_col);
					}
					if (!strcmp("Vd_col",svar))
					{
                        C->Vd_col = atoi(sval);
	                    printf("%s = %d\n",svar,C->Vd_col);
					}
					if (!strcmp("Id_col",svar))
					{
                        C->Id_col = atoi(sval);
	                    printf("%s = %d\n",svar,C->Id_col);
					}
					if (!strcmp("Data_File",svar))
					{
                        strcpy( C->Dfile, sval);
                        printf("%s = %s\n",svar,C->Dfile);
					}
					if (!strcmp("N1",svar))
					{
                        C->N1 = atoi(sval);
	                    C->NNpl[0] = C->N1;
						printf("%s = %d\n",svar,C->NNpl[0]);
					}
					if (!strcmp("Ninputs",svar))
					{
                        C->Ninputs = atoi(sval);
	                    NNet->Ni = C->Ninputs;
						printf("%s = %d\n",svar,C->Ninputs);
					}
					if (!strcmp("N2",svar))
					{
                        C->N2 = atoi(sval);
	                    C->NNpl[1] = C->N2;
						printf("%s = %d\n",svar,C->NNpl[1]);
						
					}
					if (!strcmp("N3",svar))
					{
                        C->N3 = atoi(sval);
	                    C->NNpl[2] = C->N3;
						printf("%s = %d\n",svar,C->NNpl[2]);
						
					}
					if (!strcmp("N4",svar))
					{
                        C->N4 = atoi(sval);
	                    C->NNpl[3] = C->N4;
						printf("%s = %d\n",svar,C->NNpl[3]);
						
					}
					if (!strcmp("N5",svar))
					{
                        C->N5 = atoi(sval);
	                    printf("%s = %d\n",svar,C->N5);
						C->NNpl[4] = C->N5;
					}
					if (!strcmp("N6",svar))
					{
                        C->N6 = atoi(sval);
	                    printf("%s = %d\n",svar,C->N6);
						C->NNpl[5] = C->N6;
					}
					if (!strcmp("SigmoidLamda",svar))
					{
                        Parms->SLamda = atof(sval);
	                    printf("%s = %3f\n",svar,Parms->SLamda);
					}
					if (!strcmp("SigmoidEta",svar))
					{
                        Parms->Eta = atof(sval);
	                    printf("%s = %3f\n",svar,Parms->Eta);
					}
					if (!strcmp("minERROR",svar))
					{
                        Parms->minERROR = atof(sval);
	                    printf("%s = %3f\n",svar,Parms->minERROR);
					}
					if (!strcmp("nITER",svar))
					{
                        Parms->nITER = atoi(sval);
	                    printf("%s = %3d\n",svar,Parms->nITER);
					}
                 	if (!strcmp("MAX_Iterations",svar))
					{
                        Parms->MAXITER = atoi(sval);
	                    printf("%s = %3d\n",svar,Parms->MAXITER);
					}


                }
            }
        }
    }  
    fclose(C->Input);


	NNet->Ni = ni;
	NNet->No = no;
	NNet->Ni_col = ivector(1,ni);
	NNet->No_col = ivector(1,no);
	for (i=1 ; i<=NNet->Ni ; i++)
	{
		NNet->Ni_col[i] = nin[i] ;
		printf(" Input Column[%d] = %d\n", i, NNet->Ni_col[i]);
	}
	for (i=1 ; i<=NNet->No ; i++)
	{
		NNet->No_col[i] = nout[i] ;
		printf("Output Column[%d] = %d\n", i, NNet->No_col[i]);
	}


	printf("======================================\n");
    printf("End input file parameter Echo\n\n");

}
