
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "setup.h"
#include "protos.h"
#include "neuron.h"

#define NR_END 1
#define FREE_ARG char*
#define PI 3.14159265387


Data *Dalloc(long nl, long nh)
{
	Data *v;

	v=(Data *)malloc((size_t) ((nh-nl+1+1)*sizeof(Data)));
	return v-nl+1;
}

void free_Data(Data *v, long nl, long nh)
{
	free((char*) (v+nl-1));
}

double neuron(int n, double *W, double *x, double lamda)
{
	double output, h_neuron;
	int input=0 ;

    while (input < n)
	{
        h_neuron = h_neuron + W[input]*x[input] ;
		input ++ ;
	}

	output = sigmoid(h_neuron, lamda);

	return output;
}


Neuron *Nalloc(long nl, long nh)
{
	Neuron *v;

	v=(Neuron *)malloc((size_t) ((nh-nl+1+1)*sizeof(Neuron)));
	return v-nl+1;
}


void free_Neuron(Neuron *v, long nl, long nh)
{
	free((char*) (v+nl-1));
}

Neuron **Nmatrix(long nrl, long nrh, long ncl, long nch)
{
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
	Neuron **m;

	/* allocate pointers to rows */
	m=(Neuron **) malloc((size_t)((nrow+NR_END)*sizeof(Neuron*)));
	m += NR_END;
	m -= nrl;

	/* allocate rows and set pointers to them */
	m[nrl]=(Neuron *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(Neuron)));
	m[nrl] += NR_END;
	m[nrl] -= ncl;

	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;

	/* return pointer to array of pointers to rows */
	return m;
}

void free_Nmatrix(Neuron **m, long nrl, long nrh, long ncl, long nch)
{
	free((char*) (m[nrl]+ncl-NR_END));
	free((char*) (m+nrl-NR_END));
}
