

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "protos.h"
#include "neuron.h"

extern void Validate(NeuralNet NNet, SETUP Parms, TData TD[], Cntrl C);
extern void Parse_Infile(NeuralNet *, SETUP *, Cntrl *);
extern void Deallocate_Memory(NeuralNet *NNet, SETUP *Parms);
extern void Weight_Correction(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Random_Init_Weights(long *rgen, NeuralNet *NNet, SETUP *Parms);
extern double ran0(long *idum);
extern void Forward_Propagation(int ic, NeuralNet *NNet, SETUP *Parms, TData TD[]);
extern void Store_Weights(NeuralNet *);
extern void Update_Weights(NeuralNet *);
extern void Load_Data(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Validat(NeuralNet , SETUP , Data, Cntrl);
extern void Random_Initialization(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Allocate_Neural_Memory(NeuralNet *, SETUP *, Cntrl *);
extern void Set_Up_Neural_Network(NeuralNet *, SETUP *, Cntrl *);
extern void Save_Weights_To_File(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Train_Network(NeuralNet *, SETUP *, Data *, Cntrl *);



int main(int argc,char *argv[])
{
   char *nlist[10]={"0","1","2","3","4","5","6","7","8","9"};
      

   NeuralNet  NNet; 
   SETUP Parms;
   Cntrl C;
   Data TDat;

   if (argc < 2) 
   {
      fprintf(stderr,"Not enough command line parameters.\n");
      fprintf(stderr,"Usage: ANN infile \n");
      fprintf(stderr,"Enter input file name\n");
      fscanf(stdin,"%s",&C.Infile);
   }
   else 
   {
      strcpy(C.Infile, argv[1]);
   }

   	
/*
* ----- Initialize the number layers and number of neurons per layer to zero
*/

   Parse_Infile(&NNet, &Parms, &C);
  	
/*
* ----- Set up Neural Map from User Inputs
*/

   Set_Up_Neural_Network(&NNet, &Parms, &C);

/*
* ----- Allocate Main Memory Space for Neural Map
*/

   Allocate_Neural_Memory(&NNet, &Parms, &C);

/*
* ----- Display Initial Weights
*/
   display_weights(NNet);
   
/*
* ----- Open the input data file and construct the Inputs and Targets for the NET
*/
   
   Load_Data(&NNet, &Parms, &TDat,  &C);


/*
* ----- Use Random Initialization to Find Set of Optimum Weights before Training
*/

   Random_Initialization(&NNet, &Parms, &TDat, &C);


/*
* ----- Train Network Over All Data Sets - Implement Forward and Back Propagation
*/

   Train_Network(&NNet, &Parms, &TDat, &C);


/*
* ----- Send training data through the network to validate network
* ----- Save All data to output file for plotting
*/
	
   Validat(NNet, Parms, TDat, C);

/*
* ----- Display Final Weights
*/

   display_weights(NNet);

/*
* ----- Save ALL Final Weight to File
*/

   Save_Weights_To_File(&NNet, &Parms, &TDat, &C);

/*
* ----- Graph the output results
*/
//	system("notepad") ;
   system("p c:\\taw\\code\\ann_prj\\debug\\dplot") ;



/*
* ----- Deallocate all memory
*/

   Deallocate_Memory(&NNet, &Parms);

   printf("\n\n");
   printf("========================================\n");
   printf("============= EXIT PROGRAM =============\n");

/*
* ----- Exit main()
*/
   return 0;

}
