
#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "file.h"


int getline (FILE *infile, char *buffer, const int limit)
{
    int inchar, i;

    for (i=0 ; i<(limit-1) && (inchar=fgetc(infile)) != EOF && inchar != '\n' ; ++i) 
	{
        buffer[i] = inchar;
    }
    if ( inchar == '\n') 
	{
        buffer[i] = inchar;
        ++i;
    }
    buffer[i] = '\0';

    if (inchar == EOF) 
	{
        return EOF;
    }

    return i;
}


//========================  count_words() =================================
// Counts number of words in buffer. words are delimited by white space
// returns number of words counted.
//=========================================================================
int count_words(char delimiter,char *buffer,int limit)
{
    int state, i, num_words;

    state = NOT_IN_WORD;    /* initialize variables */
    i = 0;
    num_words = 0;

    while ((buffer[i] != '\0') && (buffer[i] != '\n') && (i<limit))
    {
	if ( buffer[i] == delimiter )
	    state = NOT_IN_WORD;
	else if (state == NOT_IN_WORD)
	{
	    state = IN_WORD;
	    num_words++;
	}
	i++;            /* increment to next letter */
    }
    return(num_words);
}


int count_words_o(char *buffer,int limit)
{
        int state, i, num_words;

        state = NOT_IN_WORD;	/* initialize variables */
        i = 0;
        num_words = 0;

        while ((buffer[i] != '\0') && (buffer[i] != '\n') && (i<limit))
                {
                if ( buffer[i] == ' ' || buffer[i] == '\t')
                        state = NOT_IN_WORD;
                else if (state == NOT_IN_WORD)
                        {
                        state = IN_WORD;
                        num_words++;
                        }
                i++;                            /* increment to next letter */
                }

        return(num_words);
}


//============ int search_string(char *, int, char *) ==================
// searches for a string within another string
// returns position of string withing other string or -1 if not found
//======================================================================
int search_string(char *buffer, char *pattern)
{
    int position = -1, i, j, pattern_len, buffer_len;

    pattern_len = strlen(pattern);
    buffer_len = strlen(buffer);

    for ( i=0 ; (i < buffer_len - pattern_len) && (position < 0) ; i++ )
    {
        for ( j=0 ; j < pattern_len ; j++)
            if (buffer[i+j] != pattern[j])
                break;
        if ( j == pattern_len)
        {
            position = i;
            break;
        }
    }

    return (position);
}


void uppercase(char *word)
{
    int i;

    for ( i=0 ; i < (int)strlen(word) ; i++ )
	word[i] = toupper(word[i]);

    return;
}


//================== get_word =============================
// get specified word number from string.
//=========================================================
void get_word(char delimiter, char *buffer, int limit, int word_num, char *word)
{
    int i=0, j=0, state=NOT_IN_WORD, num = 0;

    while ( (buffer[i] != '\0')&&(buffer[i] != '\n')&&(i < limit)&&(num != word_num) )
    {
	    if (buffer[i] == delimiter)
		{
	        state = NOT_IN_WORD;
			if (buffer[i+1] == delimiter)
			{
				state = IN_WORD;
				num++;
			}
		}
	    else if (state == NOT_IN_WORD)
		{
	        state = IN_WORD;
	        num++;
		}
	    i++;
    }
    i--;

    for (j=i;(j<limit)&&(buffer[j] != '\0')&&(buffer[j] != '\n')&&(buffer[j] != delimiter);j++)
	word[j-i] = buffer[j];

    word[j-i] = '\0';
	
	return;
}


void get_word_o(char *buffer, int limit, int word_num, char *word)
{
    int i=0, j, state=NOT_IN_WORD, num = 0;

    while ( (buffer[i] != '\0') && (buffer[i] != '\n') && (i < limit) && (num != word_num) )
        {
        if (buffer[i] == ' ' || buffer[i] == '\t')
            state = NOT_IN_WORD;
        else if (state == NOT_IN_WORD)
            {
            state = IN_WORD;
            num++;
            }
        i++;
        }
    i--;

    for ( j=i ; (j<limit) && (buffer[j] != '\0') && (buffer[j] != '\n') && (buffer[j] != ' ') ; j++)
        word[j-i] = buffer[j];

    word[j-i] = '\0';

    return;
}



//========================  skip_comment_lines()  ==========================================
//  This function reads in one line at a time and discards it until the first character
//    is not a comment character.  Comment characters are: '!', '/', '#'.  The final line
//    read in is not a comment line, and is passed back in the char * passed to the 
//    function.
//==========================================================================================
int skip_comment_lines(FILE *infile, char *linebuffer, int limit)
{
    int num_comment_lines=-1, numchars;

    do 
	{
        numchars = getline(infile,linebuffer,limit);
        num_comment_lines++;
    }
	while (((linebuffer[0] == '!') || (linebuffer[0] == '/') || (linebuffer[0] == '#')) && (numchars > 0));

    return(num_comment_lines);
}



//===================================================================================
//                             copy file
//===================================================================================
int copy_file(char *source, char *dest)
{
    FILE *infile, *outfile;
    char linebuffer[MAXLINELEN];

    outfile = open_file(dest,WRITE);
    infile = open_file(source,READ);

    while (getline(infile,linebuffer,MAXLINELEN) > 0) 
	{
        fprintf(outfile,linebuffer);
    }

    fclose(infile);
    fclose(outfile);

    return (1);
}



//===================================================================================
//                             append file
//===================================================================================
int append_file(char *source, char *dest)
{
    FILE *infile, *outfile;
    char linebuffer[MAXLINELEN];

    outfile = open_file(dest,APPEND);
    infile = open_file(source,READ);

    while (getline(infile,linebuffer,MAXLINELEN) > 0) 
	{
        fprintf(outfile,linebuffer);
    }

    fclose(infile);
    fclose(outfile);

    return (1);
}



//=============================  open_file()  =============================
//  function for opening files.  Used only to let code look cleaner.            
//  mode is either READ or WRITE                                               
//=========================================================================
FILE *open_file(char *filename, char *mode)
{
    FILE *fileptr;

    if ( (fileptr = fopen( (const char *)filename, (const char *)mode) ) == NULL)
    {
        fprintf(stderr,"Could not open %s for ",filename);
        if (mode = READ)
            fprintf(stderr,"read\n");
        else
            fprintf(stderr,"write\n");
        exit(1);
    }
    return(fileptr);
}



//=========================================================
//             remove commas from string
//=========================================================
void remove_commas (char *instring, int strlen)
{
	int i;
    
	for (i=0 ; i<strlen ; i++)
	{
		if (*(instring+i) == ',')
			*(instring+i) = ' ';
	}

	return;
}


//=========================================================
//             Round numbers
//=========================================================
double round(double num)
{
	if (num == fabs(num))	
	{
		if (floor(10*num) >= 5)
			num = ceil(num);
		else
			num = floor(num);
	}
	else 
	{
		if (floor(10*fabs(num)) >= 5)
			num = floor(num);
		else
			num = ceil(num);
	}
	return(num);
}

