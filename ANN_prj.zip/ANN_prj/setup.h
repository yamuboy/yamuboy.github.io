
#include "file.h"


#ifndef _ST_H_
#define _ST_H_

#define TRANSFORM(a,b,c) (asin(sqrt((a-b)/(c-b))))
#define UNTRANSFORM(a,b,c) ((b)+((c)-(b))*sin((a))*sin((a)))

#define MAXout 10 
#define MAXin 10
#define MAX_Neurons 400 
#define MAX_Inputs 400 
#define MAX_Outputs 400 
#define MAX_Layers 7
#define MAX_Data 400
#define zero 0


typedef struct 
{
	FILE *Input, *Output;
    char Infile[MAXLINELENGTH],Outfile[MAXLINELENGTH];
  	char Dfile[MAXLINELENGTH], Wfile[MAXLINELENGTH] ;
    
    char sval[MAXLINELENGTH],seq[MAXLINELENGTH],svar[MAXLINELENGTH];
    char delim ;
	double Vgs[MAX_Data], Vds[MAX_Data], Ids[MAX_Data];
	int Vg_col, Vd_col, Id_col;
	int Ninputs, N1, N2, N3, N4, N5, N6, NNpl[MAX_Layers]; 
} Cntrl;
 

typedef struct 
{
   double SLamda, Eta, minERROR;
   int nITER, MAXITER;
   int DB, DATAmax, MRI;
   double WF, PEC;

} SETUP;


typedef struct 
{
   int Layer, Index, Ninputs;
   double e, o, *w, dode, oerror, *wold;

} Neuron;


typedef struct 
{
   int Ni, No, Nmax, Nlayers, Total_Neurons;
   int *Nl, *Ni_col, *No_col;
   Neuron *N, **Nron;
   double **D, **R, Error;

} NeuralNet;

typedef struct 
{
   double dT[3], dR;

} TData;

typedef struct 
{
   double **dT, **dR;
   int NTsamples;

} Data;



#endif
