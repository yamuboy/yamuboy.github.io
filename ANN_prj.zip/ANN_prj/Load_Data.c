

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "protos.h"
#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "neuron.h"


extern void Load_Data(NeuralNet *, SETUP *, Data *, Cntrl *);

void Load_Data(NeuralNet *NNet, SETUP *Parms, Data *TD, Cntrl *C)
{ 
   int i,ic, num_words;
   char delim ;
   char linebuffer[MAXLINELENGTH];
   char sval[MAXLINELENGTH];

   delim      = ' ';
 	
   C->Input  = fopen(C->Dfile, READ);
   ic = 0 ;
   while (getline(C->Input,linebuffer,MAXLINELENGTH) > 0)
   {
		num_words = count_words(delim,linebuffer,MAXLINELENGTH);
        if (num_words != 0)
		{
           ic++ ; 
		}
   }
   TD->NTsamples = ic;
   fclose(C->Input);
   
   TD->dT = dmatrix(1, TD->NTsamples, 1, NNet->Ni);
   TD->dR = dmatrix(1, TD->NTsamples, 1, NNet->No);
   
   printf("==========================================================================\n");  
   printf("Opening Data File => %s <= for reading in TRAINING Data\n\n",C->Dfile);
   
   
   C->Input  = fopen(C->Dfile, READ);
   ic = 1 ;
   while (getline(C->Input,linebuffer,MAXLINELENGTH) > 0)
   {
		num_words = count_words(delim,linebuffer,MAXLINELENGTH);
        if (num_words != 0)
		{
		   for (i=1 ; i <= NNet->Ni ; i++)
		   {
		      get_word_o(linebuffer,MAXLINELENGTH,NNet->Ni_col[i],sval);
		      TD->dT[ic][i] = atof(sval);
			  printf("  I dT[%d,%d] = %f",ic,i,TD->dT[ic][i]);
		   }
		   for (i=1 ; i <= NNet->No ; i++)
		   {
		      get_word_o(linebuffer,MAXLINELENGTH,NNet->No_col[i],sval);
		      TD->dR[ic][i] = atof(sval);
			  printf("  O dR[%d,%d] = %f",ic,i,TD->dR[ic][i]);
		   }
           ic++ ; 
		   printf("\n"); 
		}
   }

   fclose(C->Input);
   Parms->DATAmax = ic-1;
   printf("There are %d training data elements in the Filename:  %s\n", TD->NTsamples, C->Dfile);

   printf("\n\n");
   printf("Finished Reading in Training Data\n");
   printf("=================================\n");



}
