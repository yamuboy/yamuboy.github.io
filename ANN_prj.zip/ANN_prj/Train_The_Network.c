

#include <signal.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>

#include "protos.h"
#include "file.h"
#include "nrutil.h"
#include "setup.h"
#include "neuron.h"

extern void Weight_Correct(int, NeuralNet *, SETUP *, Data *);
extern void Random_Initialization(NeuralNet *, SETUP *, Data *, Cntrl *);
extern void Random_Init_Weights(long *, NeuralNet *, SETUP *);
extern void Store_Weights(NeuralNet *);
extern void Update_Weights(NeuralNet *);
extern void Forward_Prop(int, NeuralNet *, SETUP *, Data *);
extern void Train_Network(NeuralNet *, SETUP *, Data *, Cntrl *);

void Train_Network(NeuralNet *NNet, SETUP *Parms, Data *TDat, Cntrl *C)
{
	double ERRORold, ERRORacc, ERRORdifference, temp ;
	int iter, niter, ic, k ;
	
    printf("\n\n============ Forward Propagation ===========\n");
    

	iter       = 0;
	niter      = 0;
	NNet->Error = 1e9;

    niter = 0;
    temp = Parms->WF ;
	NNet->Error = 100 ;
	ERRORold = 1e9 ;


	ERRORold = 0.0;
	ERRORacc = 0.0;
	ERRORdifference = 1000;

    while (NNet->Error > Parms->minERROR && niter < Parms->MAXITER && ERRORdifference > Parms->PEC)
	{
	   NNet->Error = 0 ;
	   for (ic=1; ic<=Parms->DATAmax ; ic++)
	   {
          Weight_Correct(ic, NNet, Parms, TDat);
	      for (k=1; k<=NNet->Nl[NNet->Nlayers]; k++)
		  {		 
			 NNet->Error = NNet->Error + sqr(TDat->dR[ic][1] - NNet->Nron[NNet->Nlayers][k].o);
		  }
	   }

       iter++ ;
       niter++ ;
       
	   NNet->Error = NNet->Error/(Parms->DATAmax*NNet->No);
	   ERRORold = ERRORacc ;
       ERRORacc = (NNet->Error + ERRORacc);
	   ERRORdifference = fabs((ERRORold - ERRORacc)/ERRORold) ;

       if (iter == Parms->nITER)
	   { 
	       iter = 0;
		   printf("Iteration: %4.4d   Error: %12.11f  ErrDIFF = %10.9f of %10.9f \n",
			                          niter, NNet->Error, ERRORdifference, Parms->PEC);
	   }
    }

}
