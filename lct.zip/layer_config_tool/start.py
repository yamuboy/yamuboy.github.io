import argparse
import mautils.cli_utils as cli_utils
import os
import sys
import wx

from layer_config_tool.LCTFrame import LCTFrame

def main(*args):
    ex = wx.App()

    # command-line argument parser
    p = argparse.ArgumentParser(prog='Layer Configuration Tool', description='GUI Utility to manage a complete process definition for ADS/MWOffice')
    p.add_argument('cfgfile', nargs='?', metavar='<.layercfg file>', help='Layer Configuration Tool data file', default=None)
    p.add_argument('layfile', nargs='?', metavar='<.lay file>', help='ADS2009 Layer File', default=None)
    p.add_argument('-d', '--debug', dest='debug', action='store_true', help='Run in debug mode (displays the wxWidgets debug window)')
    p.add_argument('-p', '--profile', dest='profile', action='store_true', help='Run in profiling mode (displays profiling statistics on program exit)')

    # extract arguments
    args = p.parse_args()

    cfgfile = None
    if args.cfgfile is not None:
        cfgfile = cli_utils.parse_existing_filepath(args.cfgfile)

    debug = args.debug
    profile = args.profile
    cfile = None
    lfile = None

    # check arguments
    if cfgfile:
        if os.path.splitext(cfgfile)[1] == '.layercfg':
            cfile = cfgfile
        elif os.path.splitext(cfgfile)[1] == '.lay':
            lfile = cfgfile
        else:
            print('Invalid Layer Configuration Tool/ADS2009 data file (looking for .layercfg or .lay)')
            sys.exit()

    frame = LCTFrame(None, debug=debug, cfgfile=cfile, layfile=lfile, profile=profile)
    frame.Show()
    ex.SetTopWindow(frame)
    ex.MainLoop()

if __name__ == '__main__':
    main(*sys.argv)