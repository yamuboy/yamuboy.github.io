# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version Feb  9 2019)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

from . import LCTCanvas
import wx
import wx.xrc
import wx.grid

###########################################################################
## Class LCTLayerListPanelBase
###########################################################################

class LCTLayerListPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.VERTICAL )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )

		self._label = wx.StaticText( self, wx.ID_ANY, u"Layer List", wx.DefaultPosition, wx.Size( -1,-1 ), 0 )
		self._label.Wrap( -1 )

		_sizer.Add( self._label, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 6 ), wx.ALIGN_CENTER|wx.ALL, 2 )

		_listboxChoices = []
		self._listbox = wx.ListBox( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, _listboxChoices, wx.LB_EXTENDED )
		_sizer.Add( self._listbox, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 6 ), wx.ALIGN_CENTER|wx.ALL|wx.EXPAND, 5 )

		self._add_lay_but = wx.Button( self, wx.ID_ANY, u"+", wx.DefaultPosition, wx.Size( 25,25 ), wx.BORDER_NONE )
		_sizer.Add( self._add_lay_but, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER, 1 )

		self._del_lay_but = wx.Button( self, wx.ID_ANY, u"-", wx.DefaultPosition, wx.Size( 25,25 ), wx.BORDER_NONE )
		self._del_lay_but.Enable( False )

		_sizer.Add( self._del_lay_but, wx.GBPosition( 2, 1 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER, 1 )

		self._lay_to_top_but = wx.Button( self, wx.ID_ANY, u"⇈", wx.DefaultPosition, wx.Size( 25,25 ), wx.BORDER_NONE )
		self._lay_to_top_but.Enable( False )

		_sizer.Add( self._lay_to_top_but, wx.GBPosition( 2, 2 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER, 1 )

		self._lay_up_but = wx.Button( self, wx.ID_ANY, u"↑", wx.DefaultPosition, wx.Size( 25,25 ), wx.BORDER_NONE )
		self._lay_up_but.Enable( False )

		_sizer.Add( self._lay_up_but, wx.GBPosition( 2, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER, 1 )

		self._lay_down_but = wx.Button( self, wx.ID_ANY, u"↓", wx.DefaultPosition, wx.Size( 25,25 ), wx.BORDER_NONE )
		self._lay_down_but.Enable( False )

		_sizer.Add( self._lay_down_but, wx.GBPosition( 2, 4 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER, 1 )

		self._lay_to_bot_but = wx.Button( self, wx.ID_ANY, u"⇊", wx.DefaultPosition, wx.Size( 25,25 ), wx.BORDER_NONE )
		self._lay_to_bot_but.Enable( False )

		_sizer.Add( self._lay_to_bot_but, wx.GBPosition( 2, 5 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER, 1 )


		_sizer.AddGrowableCol( 0 )
		_sizer.AddGrowableCol( 1 )
		_sizer.AddGrowableCol( 2 )
		_sizer.AddGrowableCol( 3 )
		_sizer.AddGrowableCol( 4 )
		_sizer.AddGrowableCol( 5 )
		_sizer.AddGrowableRow( 1 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self._listbox.Bind( wx.EVT_LISTBOX, self.onSelectLayer )
		self._listbox.Bind( wx.EVT_LISTBOX_DCLICK, self.onPreviewLayer )
		self._add_lay_but.Bind( wx.EVT_BUTTON, self.onAddLayerAbove )
		self._del_lay_but.Bind( wx.EVT_BUTTON, self.onDelLayer )
		self._lay_to_top_but.Bind( wx.EVT_BUTTON, self.onLayerToTop )
		self._lay_up_but.Bind( wx.EVT_BUTTON, self.onLayerUp )
		self._lay_down_but.Bind( wx.EVT_BUTTON, self.onLayerDown )
		self._lay_to_bot_but.Bind( wx.EVT_BUTTON, self.onLayerToBot )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onSelectLayer( self, event ):
		event.Skip()

	def onPreviewLayer( self, event ):
		event.Skip()

	def onAddLayerAbove( self, event ):
		event.Skip()

	def onDelLayer( self, event ):
		event.Skip()

	def onLayerToTop( self, event ):
		event.Skip()

	def onLayerUp( self, event ):
		event.Skip()

	def onLayerDown( self, event ):
		event.Skip()

	def onLayerToBot( self, event ):
		event.Skip()


###########################################################################
## Class LCTDispPanelBase
###########################################################################

class LCTDispPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.BoxSizer( wx.HORIZONTAL )

		self._ads_panel = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_ads_sizer = wx.BoxSizer( wx.VERTICAL )

		self._ads_label = wx.StaticText( self._ads_panel, wx.ID_ANY, u"Black Background (ADS)", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_CENTER_HORIZONTAL )
		self._ads_label.Wrap( -1 )

		_ads_sizer.Add( self._ads_label, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL|wx.EXPAND, 2 )

		self._canvas_size = (256, 256)
		self._ads_canvas = LCTCanvas.LCTCanvas(self._ads_panel, size=self._canvas_size)
		self._ads_canvas.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOW ) )

		_ads_sizer.Add( self._ads_canvas, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 2 )


		self._ads_panel.SetSizer( _ads_sizer )
		self._ads_panel.Layout()
		_ads_sizer.Fit( self._ads_panel )
		_sizer.Add( self._ads_panel, 1, wx.EXPAND|wx.ALL|wx.ALIGN_CENTER_VERTICAL, 2 )

		self._awr_panel = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_awr_sizer = wx.BoxSizer( wx.VERTICAL )

		self._awr_label = wx.StaticText( self._awr_panel, wx.ID_ANY, u"White Background (MWOffice)", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_CENTER_HORIZONTAL )
		self._awr_label.Wrap( -1 )

		_awr_sizer.Add( self._awr_label, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL|wx.EXPAND, 2 )

		self._canvas_size = (256, 256)
		self._awr_canvas = LCTCanvas.LCTCanvas(self._awr_panel, size=self._canvas_size)
		self._awr_canvas.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOW ) )

		_awr_sizer.Add( self._awr_canvas, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 2 )


		self._awr_panel.SetSizer( _awr_sizer )
		self._awr_panel.Layout()
		_awr_sizer.Fit( self._awr_panel )
		_sizer.Add( self._awr_panel, 1, wx.EXPAND |wx.ALL, 2 )


		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

	def __del__( self ):
		pass


###########################################################################
## Class LCTConfigPanelBase
###########################################################################

class LCTConfigPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.BOTH )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_NONE )

		self._name_lab = wx.StaticText( self, wx.ID_ANY, u"Name", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._name_lab.Wrap( -1 )

		_sizer.Add( self._name_lab, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 2 ), wx.LEFT|wx.TOP, 2 )

		self._name_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER )
		_sizer.Add( self._name_text, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 4 ), wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self._gds_lab = wx.StaticText( self, wx.ID_ANY, u"GDS Layer # (1-252)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._gds_lab.Wrap( -1 )

		_sizer.Add( self._gds_lab, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 2 ), wx.LEFT|wx.TOP, 2 )

		self._gds_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER )
		_sizer.Add( self._gds_text, wx.GBPosition( 3, 0 ), wx.GBSpan( 1, 1 ), wx.LEFT|wx.TOP, 2 )

		self._color_lab = wx.StaticText( self, wx.ID_ANY, u"Color", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_CENTER_HORIZONTAL )
		self._color_lab.Wrap( -1 )

		_sizer.Add( self._color_lab, wx.GBPosition( 2, 2 ), wx.GBSpan( 1, 2 ), wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self._color_ctrl = wx.ColourPickerCtrl( self, wx.ID_ANY, wx.BLACK, wx.DefaultPosition, wx.DefaultSize, wx.CLRP_SHOW_LABEL|wx.CLRP_USE_TEXTCTRL )
		_sizer.Add( self._color_ctrl, wx.GBPosition( 3, 2 ), wx.GBSpan( 1, 2 ), wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self._alpha_lab = wx.StaticText( self, wx.ID_ANY, u"Transparency (ADS Only)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._alpha_lab.Wrap( -1 )

		_sizer.Add( self._alpha_lab, wx.GBPosition( 4, 0 ), wx.GBSpan( 1, 3 ), wx.ALIGN_CENTER|wx.TOP, 2 )

		self._alpha_text = wx.TextCtrl( self, wx.ID_ANY, u"255", wx.DefaultPosition, wx.Size( 30,-1 ), wx.TE_PROCESS_ENTER )
		self._alpha_text.SetMaxLength( 3 )
		_sizer.Add( self._alpha_text, wx.GBPosition( 5, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_LEFT|wx.ALL, 5 )

		self._alpha_slider = wx.Slider( self, wx.ID_ANY, 0, 0, 255, wx.DefaultPosition, wx.DefaultSize, wx.SL_AUTOTICKS|wx.SL_BOTTOM|wx.SL_HORIZONTAL )
		_sizer.Add( self._alpha_slider, wx.GBPosition( 5, 0 ), wx.GBSpan( 1, 3 ), wx.EXPAND|wx.LEFT|wx.TOP, 5 )

		self._minw_lab = wx.StaticText( self, wx.ID_ANY, u"Min Width (µm)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._minw_lab.Wrap( -1 )

		_sizer.Add( self._minw_lab, wx.GBPosition( 6, 0 ), wx.GBSpan( 1, 1 ), wx.LEFT|wx.TOP, 2 )

		self._mins_lab = wx.StaticText( self, wx.ID_ANY, u"Min Spacing (µm)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._mins_lab.Wrap( -1 )

		_sizer.Add( self._mins_lab, wx.GBPosition( 6, 2 ), wx.GBSpan( 1, 1 ), wx.LEFT|wx.TOP, 2 )

		self._minw_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER )
		_sizer.Add( self._minw_text, wx.GBPosition( 7, 0 ), wx.GBSpan( 1, 1 ), wx.LEFT|wx.TOP, 2 )

		self._mins_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER )
		_sizer.Add( self._mins_text, wx.GBPosition( 7, 2 ), wx.GBSpan( 1, 1 ), wx.LEFT|wx.TOP, 2 )

		self._pat_lab = wx.StaticText( self, wx.ID_ANY, u"Pattern", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._pat_lab.Wrap( -1 )

		_sizer.Add( self._pat_lab, wx.GBPosition( 8, 0 ), wx.GBSpan( 1, 2 ), wx.LEFT|wx.TOP, 2 )

		_pat_comboChoices = []
		self._pat_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), _pat_comboChoices, wx.CB_READONLY|wx.TE_PROCESS_ENTER )
		self._pat_combo.SetSelection( 0 )
		_sizer.Add( self._pat_combo, wx.GBPosition( 9, 0 ), wx.GBSpan( 1, 4 ), wx.ALIGN_CENTER|wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self._linestyle_lab = wx.StaticText( self, wx.ID_ANY, u"Border Line Style", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._linestyle_lab.Wrap( -1 )

		_sizer.Add( self._linestyle_lab, wx.GBPosition( 10, 0 ), wx.GBSpan( 1, 2 ), wx.LEFT|wx.TOP, 2 )

		_linestyle_comboChoices = []
		self._linestyle_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), _linestyle_comboChoices, wx.CB_READONLY|wx.TE_PROCESS_ENTER )
		self._linestyle_combo.SetSelection( 0 )
		_sizer.Add( self._linestyle_combo, wx.GBPosition( 11, 0 ), wx.GBSpan( 1, 4 ), wx.ALIGN_CENTER|wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self.m_staticline5 = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_HORIZONTAL )
		_sizer.Add( self.m_staticline5, wx.GBPosition( 12, 0 ), wx.GBSpan( 1, 4 ), wx.EXPAND |wx.ALL, 5 )

		self._vis_checkbox = wx.CheckBox( self, wx.ID_ANY, u"Visible", wx.DefaultPosition, wx.DefaultSize, wx.CHK_3STATE|wx.TRANSPARENT_WINDOW )
		_sizer.Add( self._vis_checkbox, wx.GBPosition( 13, 0 ), wx.GBSpan( 1, 2 ), wx.ALIGN_CENTER|wx.ALIGN_TOP|wx.BOTTOM|wx.LEFT|wx.TOP, 5 )

		self._cloak_checkbox = wx.CheckBox( self, wx.ID_ANY, u"Cloaked (MWO Only)", wx.DefaultPosition, wx.DefaultSize, wx.CHK_3STATE|wx.TRANSPARENT_WINDOW )
		_sizer.Add( self._cloak_checkbox, wx.GBPosition( 13, 2 ), wx.GBSpan( 1, 2 ), wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.TOP, 5 )

		self.m_staticline1 = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_HORIZONTAL )
		_sizer.Add( self.m_staticline1, wx.GBPosition( 14, 0 ), wx.GBSpan( 1, 4 ), wx.ALL|wx.EXPAND, 5 )

		self._scale_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), 0 )
		_sizer.Add( self._scale_text, wx.GBPosition( 15, 0 ), wx.GBSpan( 1, 2 ), wx.ALIGN_CENTER|wx.LEFT|wx.TOP, 2 )

		self._scale_slider = wx.Slider( self, wx.ID_ANY, 100, 0, 200, wx.DefaultPosition, wx.DefaultSize, wx.SL_AUTOTICKS|wx.SL_BOTTOM|wx.SL_HORIZONTAL )
		_sizer.Add( self._scale_slider, wx.GBPosition( 15, 2 ), wx.GBSpan( 1, 2 ), wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self._scale_lab = wx.StaticText( self, wx.ID_ANY, u"Drawing Scale", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._scale_lab.Wrap( -1 )

		_sizer.Add( self._scale_lab, wx.GBPosition( 16, 1 ), wx.GBSpan( 1, 3 ), wx.ALIGN_CENTER, 0 )

		self._bind_lab = wx.StaticText( self, wx.ID_ANY, u"Layer Bindings", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._bind_lab.Wrap( -1 )

		_sizer.Add( self._bind_lab, wx.GBPosition( 0, 4 ), wx.GBSpan( 1, 1 ), wx.LEFT|wx.TOP, 2 )

		_bind_listboxChoices = []
		self._bind_listbox = wx.ListBox( self, wx.ID_ANY, wx.DefaultPosition, wx.Size( -1,-1 ), _bind_listboxChoices, wx.LB_EXTENDED )
		_sizer.Add( self._bind_listbox, wx.GBPosition( 1, 4 ), wx.GBSpan( 16, 3 ), wx.ALIGN_CENTER|wx.ALL|wx.EXPAND, 2 )

		self._apply_but = wx.Button( self, wx.ID_ANY, u"Apply Changes", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._apply_but.Enable( False )

		_sizer.Add( self._apply_but, wx.GBPosition( 17, 0 ), wx.GBSpan( 1, 7 ), wx.ALL|wx.EXPAND, 1 )


		_sizer.AddGrowableCol( 4 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self._name_text.Bind( wx.EVT_TEXT, self.onChange )
		self._name_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._gds_text.Bind( wx.EVT_TEXT, self.onChange )
		self._gds_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._color_ctrl.Bind( wx.EVT_COLOURPICKER_CHANGED, self.onChange )
		self._alpha_text.Bind( wx.EVT_TEXT, self.onAlphaTextChange )
		self._alpha_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._alpha_slider.Bind( wx.EVT_SCROLL, self.onAlphaSliderChange )
		self._minw_text.Bind( wx.EVT_TEXT, self.onChange )
		self._minw_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._mins_text.Bind( wx.EVT_TEXT, self.onChange )
		self._mins_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._pat_combo.Bind( wx.EVT_COMBOBOX, self.onChange )
		self._pat_combo.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._linestyle_combo.Bind( wx.EVT_COMBOBOX, self.onChange )
		self._linestyle_combo.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._vis_checkbox.Bind( wx.EVT_CHECKBOX, self.onChange )
		self._cloak_checkbox.Bind( wx.EVT_CHECKBOX, self.onChange )
		self._scale_text.Bind( wx.EVT_TEXT, self.onScaleTextChange )
		self._scale_slider.Bind( wx.EVT_LEFT_UP, self.onScaleSliderMouseUp )
		self._scale_slider.Bind( wx.EVT_SCROLL, self.onScaleSliderChange )
		self._bind_listbox.Bind( wx.EVT_LISTBOX, self.onChange )
		self._apply_but.Bind( wx.EVT_BUTTON, self.onApplyChanges )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onChange( self, event ):
		event.Skip()

	def onApplyChanges( self, event ):
		event.Skip()




	def onAlphaTextChange( self, event ):
		event.Skip()


	def onAlphaSliderChange( self, event ):
		event.Skip()











	def onScaleTextChange( self, event ):
		event.Skip()

	def onScaleSliderMouseUp( self, event ):
		event.Skip()

	def onScaleSliderChange( self, event ):
		event.Skip()




###########################################################################
## Class LCTMaterialPanelBase
###########################################################################

class LCTMaterialPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.BOTH )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self._name_lab = wx.StaticText( self, wx.ID_ANY, u"Name", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._name_lab.Wrap( -1 )

		_sizer.Add( self._name_lab, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 2 ), wx.LEFT|wx.TOP, 2 )

		self._name_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,-1 ), wx.TE_PROCESS_ENTER )
		self._name_text.Enable( False )

		_sizer.Add( self._name_text, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 5 ), wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, 2 )

		_mtype_radboxChoices = [ u"Conductor", u"Dielectric", u"Semiconductor" ]
		self._mtype_radbox = wx.RadioBox( self, wx.ID_ANY, u"Material Type", wx.DefaultPosition, wx.DefaultSize, _mtype_radboxChoices, 1, wx.RA_SPECIFY_COLS )
		self._mtype_radbox.SetSelection( 1 )
		self._mtype_radbox.Enable( False )

		_sizer.Add( self._mtype_radbox, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 2 ), wx.ALL|wx.EXPAND, 5 )

		_ctype_radboxChoices = [ u"Sheet", u"Bulk" ]
		self._ctype_radbox = wx.RadioBox( self, wx.ID_ANY, u"Conductor Type", wx.DefaultPosition, wx.DefaultSize, _ctype_radboxChoices, 1, wx.RA_SPECIFY_COLS )
		self._ctype_radbox.SetSelection( 1 )
		self._ctype_radbox.Enable( False )

		_sizer.Add( self._ctype_radbox, wx.GBPosition( 2, 2 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self._cond_lab = wx.StaticText( self, wx.ID_ANY, u"Sheet Resistance", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._cond_lab.Wrap( -1 )

		_sizer.Add( self._cond_lab, wx.GBPosition( 3, 0 ), wx.GBSpan( 1, 3 ), wx.EXPAND|wx.LEFT, 5 )

		self._cond_real_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._cond_real_text, wx.GBPosition( 4, 0 ), wx.GBSpan( 1, 1 ), wx.ALL, 5 )

		self._cond_j_lab = wx.StaticText( self, wx.ID_ANY, u" + j *", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._cond_j_lab.Wrap( -1 )

		_sizer.Add( self._cond_j_lab, wx.GBPosition( 4, 1 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL, 5 )

		self._cond_imag_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._cond_imag_text, wx.GBPosition( 4, 2 ), wx.GBSpan( 1, 1 ), wx.ALL, 5 )

		self._cond_unit_lab = wx.StaticText( self, wx.ID_ANY, u"Ohm/sq", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._cond_unit_lab.Wrap( -1 )

		_sizer.Add( self._cond_unit_lab, wx.GBPosition( 4, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.RIGHT, 5 )

		self._rrf_lab = wx.StaticText( self, wx.ID_ANY, u"Skin-effect Coefficient (R_rf)", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._rrf_lab.Wrap( -1 )

		_sizer.Add( self._rrf_lab, wx.GBPosition( 5, 0 ), wx.GBSpan( 1, 3 ), wx.EXPAND|wx.LEFT, 5 )

		self._rrf_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._rrf_text, wx.GBPosition( 6, 0 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self._rrf_unit_lab = wx.StaticText( self, wx.ID_ANY, u"Ohm/(sq*sqrt(f))", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._rrf_unit_lab.Wrap( -1 )

		_sizer.Add( self._rrf_unit_lab, wx.GBPosition( 6, 3 ), wx.GBSpan( 1, 2 ), wx.ALIGN_CENTER_VERTICAL, 5 )

		self._eps_lab = wx.StaticText( self, wx.ID_ANY, u"Relative Permittivity", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._eps_lab.Wrap( -1 )

		_sizer.Add( self._eps_lab, wx.GBPosition( 7, 0 ), wx.GBSpan( 1, 1 ), wx.LEFT, 5 )

		self._eps_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._eps_text, wx.GBPosition( 8, 0 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self._eps_unit_lab = wx.StaticText( self, wx.ID_ANY, u"F/m", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._eps_unit_lab.Wrap( -1 )

		_sizer.Add( self._eps_unit_lab, wx.GBPosition( 8, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL, 5 )

		self._mu_lab = wx.StaticText( self, wx.ID_ANY, u"Relative Permeability", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._mu_lab.Wrap( -1 )

		_sizer.Add( self._mu_lab, wx.GBPosition( 9, 0 ), wx.GBSpan( 1, 1 ), wx.LEFT, 5 )

		self._mu_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._mu_text, wx.GBPosition( 10, 0 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self._mu_unit_lab = wx.StaticText( self, wx.ID_ANY, u"H/m", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._mu_unit_lab.Wrap( -1 )

		_sizer.Add( self._mu_unit_lab, wx.GBPosition( 10, 3 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL, 5 )

		self._tand_lab = wx.StaticText( self, wx.ID_ANY, u"Loss Tangent", wx.DefaultPosition, wx.Size( -1,-1 ), wx.ALIGN_LEFT )
		self._tand_lab.Wrap( -1 )

		_sizer.Add( self._tand_lab, wx.GBPosition( 11, 0 ), wx.GBSpan( 1, 1 ), wx.LEFT, 5 )

		self._tand_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._tand_text, wx.GBPosition( 12, 0 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self._apply_but = wx.Button( self, wx.ID_ANY, u"Apply Changes", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._apply_but.Enable( False )

		_sizer.Add( self._apply_but, wx.GBPosition( 13, 0 ), wx.GBSpan( 1, 5 ), wx.ALL|wx.EXPAND, 5 )


		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self._name_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._mtype_radbox.Bind( wx.EVT_RADIOBOX, self.onMaterialTypeChange )
		self._ctype_radbox.Bind( wx.EVT_RADIOBOX, self.onConductorTypeChange )
		self._cond_real_text.Bind( wx.EVT_TEXT, self.validateConductivity )
		self._cond_real_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._cond_imag_text.Bind( wx.EVT_TEXT, self.validateConductivity )
		self._cond_imag_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._rrf_text.Bind( wx.EVT_TEXT, self.validateRrf )
		self._rrf_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._eps_text.Bind( wx.EVT_TEXT, self.validatePermittivity )
		self._eps_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._mu_text.Bind( wx.EVT_TEXT, self.validatePermeability )
		self._mu_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._tand_text.Bind( wx.EVT_TEXT, self.validateTand )
		self._tand_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._apply_but.Bind( wx.EVT_BUTTON, self.onApplyChanges )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onApplyChanges( self, event ):
		event.Skip()

	def onMaterialTypeChange( self, event ):
		event.Skip()

	def onConductorTypeChange( self, event ):
		event.Skip()

	def validateConductivity( self, event ):
		event.Skip()




	def validateRrf( self, event ):
		event.Skip()


	def validatePermittivity( self, event ):
		event.Skip()


	def validatePermeability( self, event ):
		event.Skip()


	def validateTand( self, event ):
		event.Skip()




###########################################################################
## Class LCTMaterialListPanelBase
###########################################################################

class LCTMaterialListPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.VERTICAL )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )

		self._label = wx.StaticText( self, wx.ID_ANY, u"Materials List", wx.DefaultPosition, wx.Size( -1,-1 ), 0 )
		self._label.Wrap( -1 )

		_sizer.Add( self._label, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 2 ), wx.ALIGN_CENTER|wx.ALL, 2 )

		_listboxChoices = []
		self._listbox = wx.ListBox( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, _listboxChoices, wx.LB_EXTENDED )
		_sizer.Add( self._listbox, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 2 ), wx.ALIGN_CENTER|wx.ALL|wx.EXPAND, 5 )

		self._add_mat_but = wx.Button( self, wx.ID_ANY, u"Add Material", wx.DefaultPosition, wx.Size( -1,-1 ), wx.BORDER_NONE )
		self._add_mat_but.SetMinSize( wx.Size( 85,-1 ) )

		_sizer.Add( self._add_mat_but, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER|wx.ALL|wx.EXPAND, 1 )

		self._del_mat_but = wx.Button( self, wx.ID_ANY, u"Delete Material(s)", wx.DefaultPosition, wx.Size( -1,-1 ), wx.BORDER_NONE )
		self._del_mat_but.Enable( False )
		self._del_mat_but.SetMinSize( wx.Size( 105,-1 ) )

		_sizer.Add( self._del_mat_but, wx.GBPosition( 2, 1 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER|wx.ALL|wx.EXPAND, 1 )


		_sizer.AddGrowableCol( 0 )
		_sizer.AddGrowableCol( 1 )
		_sizer.AddGrowableRow( 1 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self._listbox.Bind( wx.EVT_LISTBOX, self.onSelectMaterial )
		self._add_mat_but.Bind( wx.EVT_BUTTON, self.onAddMaterial )
		self._del_mat_but.Bind( wx.EVT_BUTTON, self.onDelMaterial )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onSelectMaterial( self, event ):
		event.Skip()

	def onAddMaterial( self, event ):
		event.Skip()

	def onDelMaterial( self, event ):
		event.Skip()


###########################################################################
## Class LCTSubstrateListPanelBase
###########################################################################

class LCTSubstrateListPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.VERTICAL )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )

		self._label = wx.StaticText( self, wx.ID_ANY, u"Substrates List", wx.DefaultPosition, wx.Size( -1,-1 ), 0 )
		self._label.Wrap( -1 )

		_sizer.Add( self._label, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 3 ), wx.ALIGN_CENTER|wx.ALL, 2 )

		_listboxChoices = []
		self._listbox = wx.ListBox( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, _listboxChoices, wx.LB_SORT )
		_sizer.Add( self._listbox, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 3 ), wx.ALL|wx.EXPAND, 5 )

		self._add_sub_but = wx.Button( self, wx.ID_ANY, u"Add\nSubstrate", wx.DefaultPosition, wx.Size( -1,-1 ), wx.BORDER_NONE )
		self._add_sub_but.SetMinSize( wx.Size( 60,-1 ) )

		_sizer.Add( self._add_sub_but, wx.GBPosition( 2, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 1 )

		self._dup_sub_but = wx.Button( self, wx.ID_ANY, u"Duplicate\nSubstrate", wx.DefaultPosition, wx.DefaultSize, wx.BORDER_NONE )
		self._dup_sub_but.Enable( False )
		self._dup_sub_but.SetMinSize( wx.Size( 60,-1 ) )

		_sizer.Add( self._dup_sub_but, wx.GBPosition( 2, 1 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 1 )

		self._del_sub_but = wx.Button( self, wx.ID_ANY, u"Delete\nSubstrate(s)", wx.DefaultPosition, wx.Size( -1,-1 ), wx.BORDER_NONE )
		self._del_sub_but.Enable( False )
		self._del_sub_but.SetMinSize( wx.Size( 70,-1 ) )

		_sizer.Add( self._del_sub_but, wx.GBPosition( 2, 2 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 1 )


		_sizer.AddGrowableCol( 0 )
		_sizer.AddGrowableCol( 1 )
		_sizer.AddGrowableCol( 2 )
		_sizer.AddGrowableRow( 1 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self._listbox.Bind( wx.EVT_LISTBOX, self.onSelectSubstrate )
		self._add_sub_but.Bind( wx.EVT_BUTTON, self.onAddSubstrate )
		self._dup_sub_but.Bind( wx.EVT_BUTTON, self.onDupSubstrate )
		self._del_sub_but.Bind( wx.EVT_BUTTON, self.onDelSubstrate )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onSelectSubstrate( self, event ):
		event.Skip()

	def onAddSubstrate( self, event ):
		event.Skip()

	def onDupSubstrate( self, event ):
		event.Skip()

	def onDelSubstrate( self, event ):
		event.Skip()


###########################################################################
## Class LCTSubstratePanelBase
###########################################################################

class LCTSubstratePanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.BOTH )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self._name_lab = wx.StaticText( self, wx.ID_ANY, u"Name", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._name_lab.Wrap( -1 )

		_sizer.Add( self._name_lab, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND|wx.LEFT|wx.TOP, 2 )

		self._name_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( -1,-1 ), wx.TE_PROCESS_ENTER )
		_sizer.Add( self._name_text, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.ALL|wx.EXPAND, 2 )

		_top_cover_radboxChoices = [ u"PEC", u"Open" ]
		self._top_cover_radbox = wx.RadioBox( self, wx.ID_ANY, u"Top Cover", wx.DefaultPosition, wx.DefaultSize, _top_cover_radboxChoices, 1, wx.RA_SPECIFY_ROWS )
		self._top_cover_radbox.SetSelection( 0 )
		_sizer.Add( self._top_cover_radbox, wx.GBPosition( 0, 1 ), wx.GBSpan( 3, 1 ), wx.ALL, 5 )

		_bot_cover_radboxChoices = [ u"PEC", u"Open" ]
		self._bot_cover_radbox = wx.RadioBox( self, wx.ID_ANY, u"Bottom Cover", wx.DefaultPosition, wx.DefaultSize, _bot_cover_radboxChoices, 1, wx.RA_SPECIFY_ROWS )
		self._bot_cover_radbox.SetSelection( 0 )
		_sizer.Add( self._bot_cover_radbox, wx.GBPosition( 0, 2 ), wx.GBSpan( 3, 1 ), wx.ALL, 5 )

		self._sub_panel = wx.ScrolledWindow( self, wx.ID_ANY, wx.DefaultPosition, wx.Size( -1,-1 ), wx.ALWAYS_SHOW_SB|wx.CLIP_CHILDREN|wx.HSCROLL|wx.VSCROLL )
		self._sub_panel.SetScrollRate( 5, 5 )
		_sub_sizer = wx.GridBagSizer( 0, 0 )
		_sub_sizer.SetFlexibleDirection( wx.HORIZONTAL )
		_sub_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_ALL )

		self._sub_canvas = LCTCanvas.LCTCanvas(self._sub_panel, size=(-1,-1))
		self._sub_canvas.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOW ) )

		_sub_sizer.Add( self._sub_canvas, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 1 ), wx.EXPAND, 0 )


		_sub_sizer.AddGrowableCol( 0 )
		_sub_sizer.AddGrowableRow( 0 )

		self._sub_panel.SetSizer( _sub_sizer )
		self._sub_panel.Layout()
		_sub_sizer.Fit( self._sub_panel )
		_sizer.Add( self._sub_panel, wx.GBPosition( 3, 0 ), wx.GBSpan( 8, 3 ), wx.EXPAND, 5 )

		self._separator = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_VERTICAL )
		_sizer.Add( self._separator, wx.GBPosition( 0, 3 ), wx.GBSpan( 11, 1 ), wx.EXPAND |wx.ALL, 5 )

		self._mat_lab = wx.StaticText( self, wx.ID_ANY, u"Material", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._mat_lab.Wrap( -1 )

		_sizer.Add( self._mat_lab, wx.GBPosition( 0, 4 ), wx.GBSpan( 1, 1 ), wx.ALIGN_BOTTOM|wx.TOP, 5 )

		_mat_comboChoices = []
		self._mat_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, _mat_comboChoices, wx.CB_READONLY|wx.CB_SORT )
		_sizer.Add( self._mat_combo, wx.GBPosition( 1, 4 ), wx.GBSpan( 1, 1 ), 0, 5 )

		self._lay_lab = wx.StaticText( self, wx.ID_ANY, u"Layer", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._lay_lab.Wrap( -1 )

		_sizer.Add( self._lay_lab, wx.GBPosition( 2, 4 ), wx.GBSpan( 1, 1 ), wx.TOP, 5 )

		_lay_comboChoices = []
		self._lay_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, _lay_comboChoices, wx.CB_READONLY|wx.CB_SORT )
		_sizer.Add( self._lay_combo, wx.GBPosition( 3, 4 ), wx.GBSpan( 1, 1 ), 0, 5 )

		self._extent_lab = wx.StaticText( self, wx.ID_ANY, u"Via Extent", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._extent_lab.Wrap( -1 )

		_sizer.Add( self._extent_lab, wx.GBPosition( 4, 4 ), wx.GBSpan( 1, 1 ), wx.TOP, 5 )

		_extent_comboChoices = []
		self._extent_combo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, _extent_comboChoices, wx.CB_READONLY )
		_sizer.Add( self._extent_combo, wx.GBPosition( 5, 4 ), wx.GBSpan( 1, 1 ), 0, 5 )

		self._thick_lab = wx.StaticText( self, wx.ID_ANY, u"Thickness [µm]", wx.DefaultPosition, wx.DefaultSize, wx.ALIGN_LEFT )
		self._thick_lab.Wrap( -1 )

		_sizer.Add( self._thick_lab, wx.GBPosition( 6, 4 ), wx.GBSpan( 1, 1 ), wx.TOP, 5 )

		self._thick_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_PROCESS_ENTER )
		_sizer.Add( self._thick_text, wx.GBPosition( 7, 4 ), wx.GBSpan( 1, 1 ), 0, 5 )

		self._sheet_checkbox = wx.CheckBox( self, wx.ID_ANY, u"Sheet Model", wx.DefaultPosition, wx.DefaultSize, wx.CHK_2STATE )
		_sizer.Add( self._sheet_checkbox, wx.GBPosition( 8, 4 ), wx.GBSpan( 1, 1 ), wx.ALL, 5 )

		self._apply_but = wx.Button( self, wx.ID_ANY, u"Apply Changes", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._apply_but.Enable( False )

		_sizer.Add( self._apply_but, wx.GBPosition( 9, 4 ), wx.GBSpan( 2, 1 ), wx.ALIGN_BOTTOM|wx.ALL, 5 )


		_sizer.AddGrowableCol( 0 )
		_sizer.AddGrowableRow( 9 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self.Bind( wx.EVT_SIZE, self.onSize )
		self._name_text.Bind( wx.EVT_TEXT, self.validateName )
		self._name_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._top_cover_radbox.Bind( wx.EVT_RADIOBOX, self.onChange )
		self._bot_cover_radbox.Bind( wx.EVT_RADIOBOX, self.onChange )
		self._sub_canvas.Bind( wx.EVT_LEFT_UP, self.onLClick )
		self._mat_combo.Bind( wx.EVT_COMBOBOX, self.onMaterialChange )
		self._lay_combo.Bind( wx.EVT_COMBOBOX, self.onLayerChange )
		self._extent_combo.Bind( wx.EVT_COMBOBOX, self.onExtentChange )
		self._thick_text.Bind( wx.EVT_TEXT, self.validateThickness )
		self._thick_text.Bind( wx.EVT_TEXT_ENTER, self.onApplyChanges )
		self._sheet_checkbox.Bind( wx.EVT_CHECKBOX, self.onSheetChange )
		self._apply_but.Bind( wx.EVT_BUTTON, self.onApplyChanges )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onSize( self, event ):
		event.Skip()

	def validateName( self, event ):
		event.Skip()

	def onApplyChanges( self, event ):
		event.Skip()

	def onChange( self, event ):
		event.Skip()


	def onLClick( self, event ):
		event.Skip()

	def onMaterialChange( self, event ):
		event.Skip()

	def onLayerChange( self, event ):
		event.Skip()

	def onExtentChange( self, event ):
		event.Skip()

	def validateThickness( self, event ):
		event.Skip()


	def onSheetChange( self, event ):
		event.Skip()



###########################################################################
## Class LCTInsetPanelBase
###########################################################################

class LCTInsetPanelBase ( wx.Panel ):

	def __init__( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.TAB_TRAVERSAL, name = wx.EmptyString ):
		wx.Panel.__init__ ( self, parent, id = id, pos = pos, size = size, style = style, name = name )

		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.HORIZONTAL )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self._grid = wx.grid.Grid( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )

		# Grid
		self._grid.CreateGrid( 1, 3 )
		self._grid.EnableEditing( True )
		self._grid.EnableGridLines( True )
		self._grid.EnableDragGridSize( False )
		self._grid.SetMargins( 0, 0 )

		# Columns
		self._grid.EnableDragColMove( False )
		self._grid.EnableDragColSize( True )
		self._grid.SetColLabelSize( 30 )
		self._grid.SetColLabelValue( 0, u"Layer 1" )
		self._grid.SetColLabelValue( 1, u"Layer 2" )
		self._grid.SetColLabelValue( 2, u"Inset [µm]" )
		self._grid.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Rows
		self._grid.EnableDragRowSize( False )
		self._grid.SetRowLabelSize( 20 )
		self._grid.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Label Appearance

		# Cell Defaults
		self._grid.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_CENTER )
		_sizer.Add( self._grid, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 4 ), wx.ALL|wx.EXPAND, 2 )

		self._derived_checkbox = wx.CheckBox( self, wx.ID_ANY, u"Display Derived Rules", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._derived_checkbox.SetForegroundColour( wx.Colour( 192, 0, 0 ) )

		_sizer.Add( self._derived_checkbox, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 1 ), wx.ALL, 5 )

		self._reciprocal_checkbox = wx.CheckBox( self, wx.ID_ANY, u"Display Reciprocal Rules", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._reciprocal_checkbox.SetForegroundColour( wx.Colour( 0, 192, 0 ) )

		_sizer.Add( self._reciprocal_checkbox, wx.GBPosition( 1, 1 ), wx.GBSpan( 1, 1 ), wx.ALL, 5 )


		_sizer.AddGrowableCol( 0 )
		_sizer.AddGrowableCol( 3 )
		_sizer.AddGrowableRow( 0 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		# Connect Events
		self._grid.Bind( wx.grid.EVT_GRID_CELL_CHANGED, self.onApplyChanges )
		self._derived_checkbox.Bind( wx.EVT_CHECKBOX, self.onDataChange )
		self._reciprocal_checkbox.Bind( wx.EVT_CHECKBOX, self.onDataChange )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onApplyChanges( self, event ):
		event.Skip()

	def onDataChange( self, event ):
		event.Skip()



