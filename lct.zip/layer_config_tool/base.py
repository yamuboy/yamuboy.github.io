# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version Feb  9 2019)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

from .panels.LCTLayerListPanel import LCTLayerListPanel
from .panels.LCTConfigPanel import LCTConfigPanel
from .panels.LCTDispPanel import LCTDispPanel
from .panels.LCTInsetPanel import LCTInsetPanel
from .panels.LCTMaterialListPanel import LCTMaterialListPanel
from .panels.LCTMaterialPanel import LCTMaterialPanel
from .panels.LCTSubstrateListPanel import LCTSubstrateListPanel
from .panels.LCTSubstratePanel import LCTSubstratePanel
import wx
import wx.xrc

###########################################################################
## Class LCTFrameBase
###########################################################################

class LCTFrameBase ( wx.Frame ):

	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Layer Configuration Tool", pos = wx.DefaultPosition, size = wx.Size( -1,-1 ), style = wx.DEFAULT_FRAME_STYLE|wx.CLIP_CHILDREN|wx.FULL_REPAINT_ON_RESIZE|wx.TAB_TRAVERSAL )

		self.SetSizeHints( wx.Size( -1,-1 ), wx.DefaultSize )
		self.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_MENU ) )

		self._menubar = wx.MenuBar( 0 )
		self._mb_filemenu = wx.Menu()
		self._mb_filemenu_new = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"New Configuration..."+ u"\t" + u"Ctrl+N", u"Create a Layer Configugation", wx.ITEM_NORMAL )
		self._mb_filemenu_new.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_NORMAL_FILE, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_new )

		self._mb_filemenu_open = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Open Configuration..."+ u"\t" + u"Ctrl+O", u"Open a Layer Config Tool File", wx.ITEM_NORMAL )
		self._mb_filemenu_open.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_open )

		self._mb_filemenu_save = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Save Configuration..."+ u"\t" + u"Ctrl+S", u"Save Configuration to a Layer Config Tool File", wx.ITEM_NORMAL )
		self._mb_filemenu_save.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_SAVE, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_save )

		self._mb_filemenu.AppendSeparator()

		self._mb_filemenu_ads = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Write ADS Config...", u"Write ADS Configuration", wx.ITEM_NORMAL )
		self._mb_filemenu_ads.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_ads )

		self._mb_filemenu_ads_abl = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Write ADS ABL File...", u"Write ADS ABL File", wx.ITEM_NORMAL )
		self._mb_filemenu_ads_abl.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_ads_abl )

		self._mb_filemenu_awr = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Write MWOffice Config...", u"Write Microwave Office Configuration", wx.ITEM_NORMAL )
		self._mb_filemenu_awr.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_awr )

		self._mb_filemenu_klay = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Write KLayout Config...", u"Write KLayout Config", wx.ITEM_NORMAL )
		self._mb_filemenu_klay.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_klay )

		self._mb_filemenu.AppendSeparator()

		self._mb_filemenu_ads_layfile_import = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Import ADS2009 .lay file", wx.EmptyString, wx.ITEM_NORMAL )
		self._mb_filemenu.Append( self._mb_filemenu_ads_layfile_import )

		self._mb_filemenu.AppendSeparator()

		self._mb_filemenu_quit = wx.MenuItem( self._mb_filemenu, wx.ID_ANY, u"Quit..."+ u"\t" + u"Alt+F4", u"Quit Layer Config Tool", wx.ITEM_NORMAL )
		self._mb_filemenu_quit.SetBitmap( wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_MENU ) )
		self._mb_filemenu.Append( self._mb_filemenu_quit )

		self._menubar.Append( self._mb_filemenu, u"File" )

		self.SetMenuBar( self._menubar )

		self._toolbar = self.CreateToolBar( wx.TB_HORIZONTAL, wx.ID_ANY )
		self._toolbar.SetToolBitmapSize( wx.Size( 16,16 ) )
		self._tb_new_config_but = self._toolbar.AddLabelTool( wx.ID_ANY, u"open", wx.ArtProvider.GetBitmap( wx.ART_NORMAL_FILE, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"New Layer Configuration", u"New Layer Configuration", None )

		self._tb_open_config_but = self._toolbar.AddLabelTool( wx.ID_ANY, u"open", wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"Open Layer Configuration", u"Open Layer Configuration", None )

		self._tb_save_config_but = self._toolbar.AddLabelTool( wx.ID_ANY, u"save", wx.ArtProvider.GetBitmap( wx.ART_FILE_SAVE, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"Save Layer Configuration", u"Save Layer Configuration", None )

		self._toolbar.AddSeparator()

		self._tb_write_ads_config_but = self._toolbar.AddLabelTool( wx.ID_ANY, u"ads", wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"Write ADS Configuration", u"Write ADS Configuration", None )

		self._tb_write_awr_config_but = self._toolbar.AddLabelTool( wx.ID_ANY, u"awr", wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"Write Microwave Office Configuration", u"Write Microwave Office Configuration", None )

		self._tb_write_klay_config_but = self._toolbar.AddLabelTool( wx.ID_ANY, u"klay", wx.ArtProvider.GetBitmap( wx.ART_FILE_OPEN, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"Write KLayout Configuration", u"Write KLayout Configuration", None )

		self._toolbar.Realize()

		self._statusbar = self.CreateStatusBar( 1, wx.STB_SIZEGRIP, wx.ID_ANY )
		_sizer = wx.GridBagSizer( 0, 0 )
		_sizer.SetFlexibleDirection( wx.BOTH )
		_sizer.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self._process_lab = wx.StaticText( self, wx.ID_ANY, u"Process Name: ", wx.DefaultPosition, wx.DefaultSize, 0 )
		self._process_lab.Wrap( -1 )

		self._process_lab.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_MENU ) )

		_sizer.Add( self._process_lab, wx.GBPosition( 0, 0 ), wx.GBSpan( 1, 1 ), wx.ALIGN_CENTER_VERTICAL|wx.ALL, 2 )

		self._process_text = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		_sizer.Add( self._process_text, wx.GBPosition( 0, 1 ), wx.GBSpan( 1, 1 ), wx.EXPAND|wx.RIGHT|wx.TOP, 5 )

		self._notebook = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.NB_TOP )
		self._layout_page = wx.Panel( self._notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_layout_sizer = wx.BoxSizer( wx.VERTICAL )

		self._layout_splitter = wx.SplitterWindow( self._layout_page, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.SP_3DSASH|wx.SP_LIVE_UPDATE )
		self._layout_splitter.Bind( wx.EVT_IDLE, self._layout_splitterOnIdle )
		self._layout_splitter.SetMinimumPaneSize( 250 )

		self._layout_listpanel = LCTLayerListPanel( self._layout_splitter, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self._layout_mainpanel = wx.Panel( self._layout_splitter, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_layout_mainpanel_sizer = wx.BoxSizer( wx.VERTICAL )

		self._layout_confpanel = LCTConfigPanel( self._layout_mainpanel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_layout_mainpanel_sizer.Add( self._layout_confpanel, 1, wx.EXPAND |wx.ALL, 5 )

		self._layout_disppanel = LCTDispPanel( self._layout_mainpanel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_layout_mainpanel_sizer.Add( self._layout_disppanel, 1, wx.EXPAND |wx.ALL, 5 )


		self._layout_mainpanel.SetSizer( _layout_mainpanel_sizer )
		self._layout_mainpanel.Layout()
		_layout_mainpanel_sizer.Fit( self._layout_mainpanel )
		self._layout_splitter.SplitVertically( self._layout_listpanel, self._layout_mainpanel, 250 )
		_layout_sizer.Add( self._layout_splitter, 1, wx.EXPAND, 5 )


		self._layout_page.SetSizer( _layout_sizer )
		self._layout_page.Layout()
		_layout_sizer.Fit( self._layout_page )
		self._notebook.AddPage( self._layout_page, u"Layout", True )
		self._insets_page = wx.Panel( self._notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_insets_sizer = wx.BoxSizer( wx.VERTICAL )

		self._insets_panel = LCTInsetPanel( self._insets_page, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_insets_sizer.Add( self._insets_panel, 1, wx.EXPAND |wx.ALL, 5 )


		self._insets_page.SetSizer( _insets_sizer )
		self._insets_page.Layout()
		_insets_sizer.Fit( self._insets_page )
		self._notebook.AddPage( self._insets_page, u"Global Insets", False )
		self._materials_page = wx.Panel( self._notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_materials_sizer = wx.BoxSizer( wx.VERTICAL )

		self._materials_splitter = wx.SplitterWindow( self._materials_page, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.SP_BORDER|wx.SP_LIVE_UPDATE )
		self._materials_splitter.Bind( wx.EVT_IDLE, self._materials_splitterOnIdle )

		self._materials_listpanel = LCTMaterialListPanel( self._materials_splitter, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self._materials_mainpanel = wx.Panel( self._materials_splitter, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_materials_mainpanel_sizer = wx.BoxSizer( wx.VERTICAL )

		self._materials_confpanel = LCTMaterialPanel( self._materials_mainpanel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_materials_mainpanel_sizer.Add( self._materials_confpanel, 1, wx.EXPAND |wx.ALL, 5 )


		self._materials_mainpanel.SetSizer( _materials_mainpanel_sizer )
		self._materials_mainpanel.Layout()
		_materials_mainpanel_sizer.Fit( self._materials_mainpanel )
		self._materials_splitter.SplitVertically( self._materials_listpanel, self._materials_mainpanel, 250 )
		_materials_sizer.Add( self._materials_splitter, 1, wx.EXPAND, 5 )


		self._materials_page.SetSizer( _materials_sizer )
		self._materials_page.Layout()
		_materials_sizer.Fit( self._materials_page )
		self._notebook.AddPage( self._materials_page, u"Materials", False )
		self._EM_page = wx.Panel( self._notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		_em_sizer = wx.BoxSizer( wx.VERTICAL )

		self._em_splitter = wx.SplitterWindow( self._EM_page, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.SP_3D )
		self._em_splitter.Bind( wx.EVT_IDLE, self._em_splitterOnIdle )
		self._em_splitter.SetMinimumPaneSize( 250 )

		self._sub_listpanel = LCTSubstrateListPanel( self._em_splitter, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self._sub_mainpanel = LCTSubstratePanel( self._em_splitter, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self._em_splitter.SplitVertically( self._sub_listpanel, self._sub_mainpanel, 250 )
		_em_sizer.Add( self._em_splitter, 1, wx.EXPAND, 5 )


		self._EM_page.SetSizer( _em_sizer )
		self._EM_page.Layout()
		_em_sizer.Fit( self._EM_page )
		self._notebook.AddPage( self._EM_page, u"EM Stackup", False )

		_sizer.Add( self._notebook, wx.GBPosition( 1, 0 ), wx.GBSpan( 1, 2 ), wx.EXPAND |wx.ALL, 2 )


		_sizer.AddGrowableCol( 1 )
		_sizer.AddGrowableRow( 1 )

		self.SetSizer( _sizer )
		self.Layout()
		_sizer.Fit( self )

		self.Centre( wx.BOTH )

		# Connect Events
		self.Bind( wx.EVT_MENU, self.onNewConfig, id = self._mb_filemenu_new.GetId() )
		self.Bind( wx.EVT_MENU, self.onOpenConfig, id = self._mb_filemenu_open.GetId() )
		self.Bind( wx.EVT_MENU, self.onSaveConfig, id = self._mb_filemenu_save.GetId() )
		self.Bind( wx.EVT_MENU, self.onWriteADSConfig, id = self._mb_filemenu_ads.GetId() )
		self.Bind( wx.EVT_MENU, self.onWriteADSABLConfig, id = self._mb_filemenu_ads_abl.GetId() )
		self.Bind( wx.EVT_MENU, self.onWriteAWRConfig, id = self._mb_filemenu_awr.GetId() )
		self.Bind( wx.EVT_MENU, self.onWriteKLayConfig, id = self._mb_filemenu_klay.GetId() )
		self.Bind( wx.EVT_MENU, self.onImportADSLayFile, id = self._mb_filemenu_ads_layfile_import.GetId() )
		self.Bind( wx.EVT_MENU, self.onQuit, id = self._mb_filemenu_quit.GetId() )
		self.Bind( wx.EVT_TOOL, self.onNewConfig, id = self._tb_new_config_but.GetId() )
		self.Bind( wx.EVT_TOOL, self.onOpenConfig, id = self._tb_open_config_but.GetId() )
		self.Bind( wx.EVT_TOOL, self.onSaveConfig, id = self._tb_save_config_but.GetId() )
		self.Bind( wx.EVT_TOOL, self.onWriteADSConfig, id = self._tb_write_ads_config_but.GetId() )
		self.Bind( wx.EVT_TOOL, self.onWriteAWRConfig, id = self._tb_write_awr_config_but.GetId() )
		self.Bind( wx.EVT_TOOL, self.onWriteKLayConfig, id = self._tb_write_klay_config_but.GetId() )
		self._process_text.Bind( wx.EVT_TEXT_ENTER, self.onProcessNameChange )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def onNewConfig( self, event ):
		event.Skip()

	def onOpenConfig( self, event ):
		event.Skip()

	def onSaveConfig( self, event ):
		event.Skip()

	def onWriteADSConfig( self, event ):
		event.Skip()

	def onWriteADSABLConfig( self, event ):
		event.Skip()

	def onWriteAWRConfig( self, event ):
		event.Skip()

	def onWriteKLayConfig( self, event ):
		event.Skip()

	def onImportADSLayFile( self, event ):
		event.Skip()

	def onQuit( self, event ):
		event.Skip()







	def onProcessNameChange( self, event ):
		event.Skip()

	def _layout_splitterOnIdle( self, event ):
		self._layout_splitter.SetSashPosition( 250 )
		self._layout_splitter.Unbind( wx.EVT_IDLE )

	def _materials_splitterOnIdle( self, event ):
		self._materials_splitter.SetSashPosition( 250 )
		self._materials_splitter.Unbind( wx.EVT_IDLE )

	def _em_splitterOnIdle( self, event ):
		self._em_splitter.SetSashPosition( 250 )
		self._em_splitter.Unbind( wx.EVT_IDLE )


