import copy
import jsonpickle
from .structures import defaults
from .structures import material
from . import utils
import os
import re

from collections import deque
from .structures.layer import Layer
from .structures.material import Material
from .structures.substrate import Substrate
from wx.lib.pubsub import pub


class LCTDataManager(object):
    def __init__(self, frame=None, *args, **kwargs):
        """
        Initializes the data manager to default values, or from the given configuration file if supplied.

        Keywords:
        path - filepath to a Layer Configuration Tool file
        """
        self.parent = frame
        self.initializeData()

        filepath = kwargs.pop('path', None)
        self.loadConfig(filepath)

    def initializeData(self):
        """
        Initialize all data to default values
        """
        self._process_name = 'Untitled_Process'
        self._lay_data = [ ]
        self._inset_data = { }
        self._mat_data = [ ]
        for mat in defaults._default_materials:
            self._mat_data.append({'Material':mat, 'Selected':False})
        self._sub_data = [ ]
        self._sub_selection = None
        self._modified = False

    def loadConfig(self, path):
        """
        Load the configuration from the file at the given path. The configuration file should be a pickled dictionary, with the following
        possible keys:
            'name' - String with the process name (alphanumeric and underscores only)
            'layers' - list of Layer objects
            'insets' - dict of dict of (float, calculated) tuples representing the 2D matrix of global inset rules
            'scales' - list of floats representing the drawing scale of each layer
            'materials' - list of Material objects
            'substrates' - list of Substrate objects

        The length of the layer list and the scale list should be identical.
        """

        # initialize and clear all UI elements
        self.initializeData()

        if path is not None:

            # load data from file
            with open(path, 'rb') as file:
                data = jsonpickle.decode(file.read())

            # unpack data
            name = data.get('name', 'Untitled Process')
            layers = data.get('layers', [ ])
            insets = data.get('insets', [ ])
            scales = data.get('scales', [ ])
            materials = data.get('materials', [ ])
            substrates = data.get('substrates', [ ])

            # if there are scales but the list isn't the same size as the layer list, create a default scales list
            if scales:
                if not len(layers) == len(scales):
                    scales = [1.0]*len(layers)

            # initialize process name to default in case imported data has an invalid process name
            self._process_name = 'Untitled Process'

            # update process name only if valid (use setter function)
            self.ProcessName = name

            # update data
            for layer, scale in zip(layers, scales):
                self._lay_data.append({'Layer':layer, 'Scale':scale, 'Display':False, 'Selected':False})

            self._inset_data = insets

            for mat in materials:
                if mat.Name not in self.MaterialNames:
                    self._mat_data.append({'Material':mat, 'Selected':False})

            for substrate in substrates:
                self._sub_data.append(substrate)

            # mark data as unmodified and update all displays
            self.processDataChange(layers=True, insets=True, materials=True, substrates=True, modified=False)

    def saveConfig(self, path):
        "Save the current configuration to the specified filepath"
        
        # pack data into dictionary
        data = {}
        data['name'] = self._process_name
        data['layers'] = self.Layers
        data['insets'] = self.Insets
        data['scales'] = self.Scales
        data['materials'] = self.Materials
        data['substrates'] = self.Substrates

        # write data to file
        with open(path, 'wb') as file:
            jsonpickle.set_encoder_options('simplejson', indent=4)
            file.write(jsonpickle.encode(data))

        # mark data as unmodified and update all displays
        self.processDataChange(layers=True, insets=True, materials=True, substrates=True, modified=False)

    def writeADSConfig(self, path):
        utils.write_ads_config('{}{}{}{}'.format(path, os.sep, self.ProcessName, os.sep), list(reversed(self.Layers)), substrates=self.Substrates)

    def writeADSABLConfig(self, path):
        all_layers = [defaults._default_ads_layers[0]] + list(reversed(self.Layers))
        all_layers = all_layers + defaults._default_ads_layers[1:]
        with open(path, 'w') as fp:
            utils.write_ads_abl_file(fp, self.ProcessName, all_layers, substrates=self.Substrates)

    def writeAWRConfig(self, path):
        library_path = '{}{}Library'.format(path, os.sep)
        xml_path = '{}{}XML'.format(path, os.sep)
        if not os.path.exists(library_path):
            os.mkdir(library_path)
        if not os.path.exists(xml_path):
            os.mkdir(xml_path)

        utils.write_awr_lpf('{}{}{}.lpf'.format(library_path, os.sep, self.ProcessName), self.Layers, substrates=self.Substrates)
        utils.write_awr_substrates('{}{}substrates.xml'.format(xml_path, os.sep), self.ProcessName, self.Substrates)

    def writeKLayoutConfig(self, path):
        utils.write_klayout_layer_prefs_file(path, self.Layers)

    def importADSLayFile(self, path):
        """
        Load the configuration from the ADS .lay file at the given path.
        """

        # initialize and clear all UI elements
        self.initializeData()

        if path is not None:

            # load data from file
            with open(path, 'r') as file:
                layers = utils.read_ads_layout_lay(file)

            # initialize name and scales
            name = os.path.basename(path)[:-4]
            scales = [1.0]*len(layers)

            # initialize process name to default in case imported data has an invalid process name
            self._process_name = 'Untitled Process'
            self.ProcessName = name

            # update layer data
            for layer, scale in zip(layers, scales):

                # create an entry in the global inset matrix for this layer
                rules = {}
                for lay_name in self.LayerNames:
                    rules[lay_name] = None

                # insert this layer into all other layers' dictionaries in the inset matrix
                for lay in self.LayerNames:
                    self._inset_data[lay][layer.name] = None
                self._inset_data[layer.name] = rules

                # add this layer to the configuration
                self._lay_data.append({'Layer':layer, 'Scale':scale, 'Display':False, 'Selected':False})

            # mark data as unmodified and update all displays
            self.processDataChange(layers=True, insets=True, materials=True, substrates=True, modified=False)

    def addLayer(self, pos=None):
        "Add a new layer to the layer list"
        # create the new layer
        layer = Layer(name=self.getNextLayerName(), pattern=defaults._default_patterns[0])

        # create an entry in the global inset matrix for this layer
        rules = {}
        for lay_name in self.LayerNames:
            rules[lay_name] = None

        # insert this layer into all other layers' dictionaries in the inset matrix
        for lay in self.LayerNames:
            self._inset_data[lay][layer.name] = None
        self._inset_data[layer.name] = rules

        # append to the end of the data list if there is no selection
        if not self.SelectedIndices or pos == -1:
            self._lay_data.append({'Layer':layer, 'Scale':1.0, 'Display':False, 'Selected':False})

        # insert above the first selected position if there is a selection
        elif pos is None:
            self._lay_data.insert(self.SelectedIndices[0], {'Layer':layer, 'Scale':1.0, 'Display':False, 'Selected':False})

        # insert at the specified position
        else:
            self._lay_data.insert(pos, {'Layer':layer, 'Scale':1.0, 'Display':False, 'Selected':False})

        # mark data as modified and update all displays
        self.processDataChange(layers=True, insets=True, modified=True)

    def addMaterial(self):
        "Add a new material to the material list"
        # create the new material
        matname = self.getNextMaterialName()
        mat = Material(Name=matname)

        # append material to list and sort list by name
        self._mat_data.append({'Material':mat, 'Selected':False})
        self._mat_data.sort(key=lambda x:x['Material'].Name)

        # if no/single material is currently selected, set selection to the newly created material
        if len(self.SelectedMaterials) < 2:
            self.selectMaterials(self.MaterialNames.index(matname))

        self.processDataChange(materials=True, modified=True)

    def addSubstrate(self):
        "Add a new substrate to the substrate list"
        # create the new substrate
        subname = self.getNextSubstrateName()
        substrate = Substrate(name=subname)

        # append substrate to list and sort list by name
        self._sub_data.append(substrate)
        self._sub_data.sort(key=lambda x:x.Name)

        # set selection to the newly created substrate
        self.selectSubstrate(len(self._sub_data) - 1)

        self.processDataChange(substrates=True, modified=True)

    def duplicateSubstrate(self):
        "Duplicate the selected substrate and add it to the substrate list"
        sub = self.SelectedSubstrate
        if sub:
            # copy selected substrate and change name
            subname = self.getNextSubstrateName()
            substrate = copy.deepcopy(sub)
            substrate.Name = subname

            # append substrate to list and sort list by name
            self._sub_data.append(substrate)
            self._sub_data.sort(key=lambda x:x.Name)

            # set selection to the newly created substrate
            self.selectSubstrate(len(self._sub_data) - 1)

            self.processDataChange(substrates=True, modified=True)

    def changeSubstrateName(self, name):
        "Change the name of the selected substrate if it's valid"
        sub = self.SelectedSubstrate
        if sub is not None:
            if utils.checkNameValidity(name):
                sub.Name = name
                self.processDataChange(substrates=True, modified=True)

    def changeSubstrateTopCover(self, cover):
        "Change the top cover of the selected substrate"
        sub = self.SelectedSubstrate
        if sub is not None:
            sub.TopCover = cover
            self.processDataChange(substrates=True, modified=True)

    def changeSubstrateBotCover(self, cover):
        "Change the bot cover of the selected substrate"
        sub = self.SelectedSubstrate
        if sub is not None:
            sub.BotCover = cover
            self.processDataChange(substrates=True, modified=True)

    def addSubstrateDielectric(self, index=None):
        "Add a new dielectric layer to the substrate. Index is relative to the currently selected dielectric index. Index of None adds to top"
        sub = self.SelectedSubstrate
        if sub is not None:
            if index is not None:
                # adding to bottom of stack
                if index == -1:
                    pos = 0
                # adding within stack
                else:
                    pos = sub.SelectedDielectricIndex + index
            # adding to top of stack
            else:
                pos = len(sub.DielectricLayers)
            
            # get first dielectric/semiconductor material, if it exists
            def_mat = None
            for mat in self.Materials:
                if mat.MatType in [material.MaterialType.DIELECTRIC, material.MaterialType.SEMICONDUCTOR]:
                    def_mat = mat
                    break

            if def_mat is None:
                pub.sendMessage('ui.warn',
                                title='Materials Required',
                                message=('No dielectric or semiconductor materials defined.\n' + 
                                         'Please define a valid material before creating any dielectric layers') )
                return

            sub.addDielectricLayer(material=def_mat, pos=pos)
            self.processDataChange(substrates=True, modified=True)

    def modifySubstrateDielectric(self, matname=None, thickness=None):
        "Modify the material or thickness of the selected substrate dielectric layer"
        sub = self.SelectedSubstrate
        if sub:
            if sub.SelectedDielectric:
                if matname in self.MaterialNames:
                    mat = self.Materials[self.MaterialNames.index(matname)]
                else:
                    mat = None

                sub.modifyDielectricLayer(material=mat, thickness=thickness)
        self.processDataChange(substrates=True, modified=True)

    def mapSubstrateLayer(self, layname=None, matname=None, sheet=None, index=None, thickness=None, extent=None):
        "Create or modify a layer mapped to an interface in the substrate. Index is relative to the currently selected dielectric index"
        sub = self.SelectedSubstrate
        if sub is not None:
            if layname is None:
                laynames = [x for x in self.LayerNames if x not in sub.MappedLayerNames]
                if not laynames:
                    pub.sendMessage('ui.warn', title='No Mappable Layers', message='No more layers to map. Create or unmap some layers first.')
                    return
                else:
                    layname = laynames[0]

            # if a material was passed in, assume it's valid 
            if matname in self.MaterialNames:
                mat = self.Materials[self.MaterialNames.index(matname)]

            # get first conductor material, if it exists
            else:
                mat = None
                for m in self.Materials:
                    if m.MatType in [material.MaterialType.CONDUCTOR]:
                        mat = m
                        break

            if index is not None:
                if (sub.SelectedDielectricIndex + index) in range(len(sub.DielectricLayers)):
                    pos = (sub.SelectedDielectricIndex + index)
                else:
                    pos = len(sub.DielectricLayers)
            else:
                pos = None

            sub.mapLayer(layname, material=mat, sheet=sheet, thickness=thickness, index=pos, extent=extent)
            self.processDataChange(substrates=True, modified=True)
    
    def convertLayerToVia(self):
        sub = self.SelectedSubstrate
        if sub is not None:
            sub.mapLayer(extent=1)

        self.processDataChange(substrates=True, modified=True)

    def convertViaToLayer(self):
        sub = self.SelectedSubstrate
        if sub is not None:
            sub.mapLayer(extent=-1)

        self.processDataChange(substrates=True, modified=True)

    def unmapSubstrateLayer(self):
        sub = self.SelectedSubstrate
        if sub is not None:
            sub.unmapLayer()

        self.processDataChange(substrates=True, modified=True)

    def removeLayer(self):
        "Remove any selected layers from the layer list"
        
        # iterate backwards over all selected layers
        for idx in reversed(self.SelectedIndices):
            remove = True

            # get this layer
            thisLayer = self.Layers[idx]
            for sub in self.Substrates:
                all_layers = sub.MappedLayerNames
                if thisLayer.name in all_layers:
                    pub.sendMessage('ui.warn',
                                    title='Layer in use',
                                    message='Can\'t remove layer "{}" since it is being used in substrate "{}"'.format(thisLayer.name, sub.Name)
                                    )
                    remove = False
                    break

            if remove:
                # remove this layer from all other layers' inset rules
                for layer in self.LayerNames:
                    if layer is not thisLayer.name:
                        del self.Insets[layer][thisLayer.name]

                # remove this layer from all other layers' bindings
                for layer in self.Layers:
                    if thisLayer in layer.binding:
                        layer.binding.remove(thisLayer)

                # remove this layer from the global insets matrix
                del self.Insets[thisLayer.name]

                # remove this layer from the list
                self._lay_data.pop(idx)
            else:
                break

        self.processDataChange(layers=True, insets=True, modified=True)

    def removeMaterial(self):
        "Remove any selected materials from the material list"
                  
        # iterate backwards over all selected materials
        for idx in reversed(self.SelectedMaterials):
            remove = True
            for sub in self.Substrates:
                all_mats = sub.AllMaterials
                mat = self.Materials[idx]
                if mat in all_mats:
                    pub.sendMessage('ui.warn',
                                    title='Material in use',
                                    message='Can\'t remove material "{}" since it is being used in substrate "{}"'.format(mat.Name, sub.Name)
                                    )
                    remove = False
                    
            if remove:
                # remove this layer from the list
                self._mat_data.pop(idx)
            else:
                break

        self.processDataChange(materials=True, modified=True)

    def removeSubstrate(self):
        "Remove the selected substrate from the substrate list"

        self._sub_data.pop(self.SelectedSubstrateIdx)
        self._sub_selection = None
        self.processDataChange(substrates=True, modified=True)

    def removeSubstrateDielectric(self):
        "Remove the selected dielectric from the substrate"
        sub = self.SelectedSubstrate
        if sub is not None:
            sub.removeDielectricLayer()
            self.processDataChange(substrates=True, modified=True)

    def moveLayers(self, moveType):
        "Update layer order in layer list"

        if self.SelectedIndices:

            # move selected layers to top
            if moveType == 'top':

                # for a single selection
                if len(self.SelectedIndices) == 1:
                    
                    idx = self.SelectedIndices[0]

                    # if selection isn't already at top of list
                    if not idx == 0:
                    
                        # modify list
                        prevItems = [x for x in self._lay_data[0:idx]]
                        curItem = [self._lay_data[idx]]
                        nextItems = [x for x in self._lay_data[idx+1:]]
                        
                        self._lay_data = curItem + prevItems + nextItems

                # for multiple selections
                else:
                    # modify layer, scale and display lists
                    new_list = [ ]
                    original_idx = [x for x in range(0, len(self._lay_data))]

                    # append selected layers to new list, in order, then remove them from the original list
                    for idx in self.SelectedIndices:
                        new_list.append(self._lay_data[idx])
                        original_idx.remove(idx)

                    # append remaining layers in original list, in order
                    for idx in original_idx:
                        new_list.append(self._lay_data[idx])

                    # replace the local list with the new list
                    self._lay_data = new_list


            # move selected layers up
            elif moveType == 'up':

                # for a single selection
                if len(self.SelectedIndices) == 1:

                    idx = self.SelectedIndices[0]

                    # if selection isn't already at top of list
                    if not idx == 0:

                        # swap selected layer and the layer before it
                        prevItems = [x for x in self._lay_data[0:idx-1]]
                        prevItem = [self._lay_data[idx - 1]]
                        curItem = [self._lay_data[idx]]
                        nextItems = [x for x in self._lay_data[idx+1:]]
                        self._lay_data = prevItems + curItem + prevItem + nextItems

                # for multiple selections
                else:
                    # if the first item in the list isn't selected
                    if not self.SelectedIndices[0] == 0:

                        new_list = [ ]
                        original_idx = [x for x in range(0, len(self._lay_data))]
                        selections_moved = [x - 1 for x in self.SelectedIndices]

                        for idx in range(0, len(self._lay_data)):
                            if idx in selections_moved:
                                new_list.append(self._lay_data[idx + 1])
                                original_idx.remove(idx + 1)
                            else:
                                new_list.append(self._lay_data[original_idx.pop(0)])

                        self._lay_data = new_list

            # move selected layers down
            elif moveType == 'down':

                # for a single selection
                if len(self.SelectedIndices) == 1:
                    
                    idx = self.SelectedIndices[0]

                    if not idx == (len(self._lay_data) - 1):
                        prevItems = [x for x in self._lay_data[0:idx]]
                        curItem = [self._lay_data[idx]]
                        nextItem = [self._lay_data[idx + 1]]
                        nextItems = [x for x in self._lay_data[idx+2:]]
                        self._lay_data = prevItems + nextItem + curItem + nextItems

                # for multiple selections
                else:
                    if not self.SelectedIndices[-1] == (len(self._lay_data) - 1):
                        new_list = [ ]
                        original_idx = [x for x in range(0, len(self._lay_data))]
                        selections_moved = [x + 1 for x in self.SelectedIndices]

                        for idx in reversed(range(0, len(self._lay_data))):
                            if idx in selections_moved:
                                new_list.insert(0, self._lay_data[idx - 1])
                                original_idx.pop(idx - 1)
                            else:
                                new_list.insert(0, self._lay_data[original_idx.pop(-1)])

                        self._lay_data = new_list

            # move selected layers to bottom
            elif moveType == 'bot':

                # for a single selection
                if len(self.SelectedIndices) == 1:
                    idx = self.SelectedIndices[0]
                    if not idx == (len(self._lay_data) - 1):
                        prevItems = [x for x in self._lay_data[0:idx]]
                        curItem = [self._lay_data[idx]]
                        nextItems = [x for x in self._lay_data[idx+1:]]

                        self._lay_data = prevItems + nextItems + curItem

                # for multiple selections
                else:
                    new_list = [ ]
                    original_idx = [x for x in range(0, len(self._lay_data))]

                    for idx in self.SelectedIndices:
                        new_list.append(self._lay_data[idx])
                        original_idx.remove(idx)

                    for idx in reversed(original_idx):
                        new_list.insert(0, self._lay_data[idx])

                    self._lay_data = new_list

            self.processDataChange(layers=True, modified=True)

    def selectLayers(self, indices):
        "Select layers specified by index list"
        # deselect all layers
        self.selectAllLayers(select=False, update=False)

        if isinstance(indices, list):
            # select the layers at the specified indices
            for idx in indices:
                self._lay_data[idx]['Selected'] = True
        elif isinstance(indices, int):
            self._lay_data[indices]['Selected'] = True

        self.processDataChange(layers=True)

    def selectMaterials(self, indices):
        "Select materials specified by index list"
        # deselect all materials
        self.selectAllMaterials(select=False, update=False)

        if isinstance(indices, list):
            # select the layers at the specified indices
            for idx in indices:
                self._mat_data[idx]['Selected'] = True
        elif isinstance(indices, int):
            self._mat_data[indices]['Selected'] = True

        self.processDataChange(materials=True)

    def selectSubstrate(self, index=None):
        "Select the substrate at the specified index"
        if index is not None:
            self._sub_selection = index
        else:
            self._sub_selection = None

        self.processDataChange(substrates=True)

    def selectSubstrateItem(self, index=None, sub_index=None):
        "Set the selected object for the currently selected substrate"
        sub = self.SelectedSubstrate
        if sub is not None:

            # deselect items
            sub.selectDielectric(None)
            sub.selectMappedLayer(None)

            # select a mapped layer/via
            if index is not None and sub_index is not None:
                sub.selectMappedLayer(index, sub_index)
            # select a dielectric layer
            elif index is not None:
                sub.selectDielectric(index)

            pub.sendMessage('substrates.preview.modified')

    def previewLayers(self, indices, preview = None):
        "Toggle preview on layers specified by index list"
        
        # multiple layers to be toggled/set
        if isinstance(indices, list):
            for idx in indices:
                if preview is None:
                    self._lay_data[idx]['Display'] = not self._lay_data[idx]['Display']
                else:
                    self._lay_data[idx]['Display'] = preview

        # single layer to be toggled/set
        elif isinstance(indices, int):
            if preview is None:
                self._lay_data[indices]['Display'] = not self._lay_data[indices]['Display']
            else:
                self._lay_data[indices]['Display'] = preview

        # only update preview elements to speed up UI
        pub.sendMessage('layers.preview.modified')

    def selectAllLayers(self, select=True, update=True):
        for item in self._lay_data:
            item['Selected'] = select

        if update:
            self.processDataChange(layers=True)

    def selectAllMaterials(self, select=True, update=True):
        for item in self._mat_data:
            item['Selected'] = select

        if update:
            self.processDataChange(materials=True)

    def previewAllLayers(self, preview=False):
        for item in self._lay_data:
            item['Display'] = preview

        self.processDataChange(layers=True)

    def getNextLayerName(self):
        "Generate a unique name for a new layer ensuring no collisions with any other layers"
        name = 'Layer_'
        number = 1
        string = name + str(number)

        # ensure no duplicates
        while string in self.LayerNames:
            number += 1
            string = name + str(number)

        return string

    def getNextMaterialName(self):
        "Generate a unique name for a new material ensuring no collisions with any other materials"
        name = 'Material'
        number = 1
        string = '{}_{:02d}'.format(name, number)

        # ensure no duplicates
        while string in self.MaterialNames:
            number += 1
            string = '{}_{:02d}'.format(name, number)

        return string

    def getNextSubstrateName(self):
        "Generate a unique name for a new substrate ensuring no collisions with any other materials"
        name = 'Substrate'
        number = 1
        string = '{}_{:02d}'.format(name, number)

        # ensure no duplicates
        while string in self.SubstrateNames:
            number += 1
            string = '{}_{:02d}'.format(name, number)

        return string

    def processDataChange(self, layers=False, insets=False, materials=False, substrates=False, modified=None):
        "Signal the main frame to update the indicated displayed data and optionally mark data as modified"
        if modified is not None:
            self._modified = modified

        pub.sendMessage('data.modified')

        if layers:
            pub.sendMessage('layers.data.modified')
            pub.sendMessage('layers.preview.modified')

        if insets:
            pub.sendMessage('insets.data.modified')

        if materials:
            pub.sendMessage('materials.data.modified')

        if substrates:
            pub.sendMessage('substrates.data.modified')
            pub.sendMessage('substrates.preview.modified')

    def modifyLayers(self, name=None, gds=None, color=None, alpha=None, minw=None, mins=None, pattern=None, style=None, visible=None, cloak=None, binding=None, material=None, em_index=None):
        "Modifies the selected layers with the given information"
        for idx in self.SelectedIndices:
            if name is not None:
                oldName = self._lay_data[idx]['Layer'].name

                # update all other layers to use the new name for this layer
                for key, val in [(x, y) for (x, y) in self._inset_data.iteritems() if not x == oldName]:
                    newVal = val.pop(oldName)
                    val[name] = newVal

                # update this layers key in the inset matrix
                self._inset_data[name] = self._inset_data.pop(oldName)

                self._lay_data[idx]['Layer'].name = name
            
            if gds is not None:
                self._lay_data[idx]['Layer'].gds = gds

            if color is not None:
                self._lay_data[idx]['Layer'].color = color

            if alpha is not None:
                self._lay_data[idx]['Layer'].alpha = alpha

            if minw is not None:
                if minw == defaults._no_value_str:
                    self._lay_data[idx]['Layer'].min_width = None
                else:
                    self._lay_data[idx]['Layer'].min_width = minw

            if mins is not None:
                if mins == defaults._no_value_str:
                    self._lay_data[idx]['Layer'].min_spacing = None
                else:
                    self._lay_data[idx]['Layer'].min_spacing = mins

            if pattern is not None:
                self._lay_data[idx]['Layer'].pattern = pattern
            
            if style is not None:
                self._lay_data[idx]['Layer'].style = style

            if visible is not None:
                self._lay_data[idx]['Layer'].visible = visible

            if cloak is not None:
                self._lay_data[idx]['Layer'].cloak = cloak

            if binding is not None:
                self._lay_data[idx]['Layer'].binding = binding

            if material is not None:
                self._lay_data[idx]['Layer'].material = material

            if em_index is not None:
                self._lay_data[idx]['Layer'].em_index = em_index

        self.processDataChange(layers=True, insets=True, materials=True, substrates=True, modified=True)

    def modifyInsets(self, layer1, layer2, value=None):
        "Modifies the global inset matrix given two layers and an inset value"

        # check if there is already an inset defined for layer1/layer2
        if self.Insets[layer1][layer2] is not None:
            insetValue = self.Insets[layer1][layer2][0]
            explicitInset = self.Insets[layer1][layer2][1]

            # ensure already defined inset is explicit and not derived
            if explicitInset:

                # changing an already existing inset rule
                if value is not None:

                    # change the inset value
                    self.Insets[layer1][layer2] = (value, True)
                    self.Insets[layer2][layer1] = (-value, True)

                    # get the subgraph of connected layers starting at layer1
                    connected_layers = self.determineInsetMatrixConnections(layer1)

                    # update implicit inset rules
                    self.updateInsetMatrixImplicitRules(connected_layers)
                                
                # removing an explicit inset rule
                else:
                    # remove the rule
                    self.Insets[layer1][layer2] = None
                    self.Insets[layer2][layer1] = None

                    # get subgraphs that were just disconnected
                    current_graph_1 = self.determineInsetMatrixConnections(layer1)
                    current_graph_2 = self.determineInsetMatrixConnections(layer2)

                    # remove any implicit rules defined between the now disconnected subgraphs
                    for lay1 in current_graph_1.keys():
                        for lay2 in current_graph_2.keys():
                            self.Insets[lay1][lay2] = None
                            self.Insets[lay2][lay1] = None

                self.processDataChange(insets=True, modified=True)

            # implicitly defined inset between layer1/layer2 already
            else:
                currentValue = self.Insets[layer1][layer2][0]
                pub.sendMessage('ui.warn',
                                title='Inset already defined',
                                message=('Inset between {} and {} already defined as {} \u00B5m'.format(layer1, layer2, str(currentValue))))
                self.processDataChange(insets=True, modified=False)


        # no rule defined between these layers already, so define one and update all insets
        elif value is not None:
            self.Insets[layer1][layer2] = (value, True)
            self.Insets[layer2][layer1] = (-value, True)
            connected_layers = self.determineInsetMatrixConnections(layer1)
            self.updateInsetMatrixImplicitRules(connected_layers)
            self.processDataChange(insets=True, modified=True)

    def determineInsetMatrixConnections(self, layer):
        """
        Determine the graph created by explicitly defined inset rules starting at the given layer. Returns a dict of connected layers and their distances from the given layer
        """

        # breadth-first search starting at the given layer
        visited = {}
        queue = deque()
        queue.append((layer, 0.0, None))

        while queue:
            currentNode = queue.popleft()
            currentLayer = currentNode[0]
            currentDistance = currentNode[1]
            currentParent = currentNode[2]

            # mark this layer as visited
            visited[currentLayer] = currentDistance

            # check for defined inset rules between the current layer and all other layers
            for childLayer, childInset in self.Insets[currentLayer].iteritems():

                # check if an inset is defined between the current layer and the current child
                if childInset is not None:

                    insetValue = childInset[0]
                    explicitInset = childInset[1]

                    # ensure the defined inset is explicit
                    if explicitInset:

                        # throw a warning if there's a cycle in the graph, and remove the cycle
                        if (not childLayer == currentParent) and (childLayer in visited.keys()):
                            self.Insets[currentLayer][childLayer] = None
                            self.Insets[childLayer][currentLayer] = None
                            pub.sendMessage('ui.warn',
                                            title='Invalid Inset Graph',
                                            message=('Cycle found in inset graph, removing explicit inset between layers "{}" and "{}"'.format(currentLayer, childLayer)))
                        # otherwise, add this child and its distance from the starting layer to the queue
                        elif not childLayer in visited.keys():
                            queue.append((childLayer, currentDistance + insetValue, currentLayer))

        # return dict of visited layers and their distances from the starting layer
        return visited

    def updateInsetMatrixImplicitRules(self, connected_layers):
        "Generate all implicit inset rules derived from explicit rules given a dictionary of connected layers and their distances from an arbitrary reference layer"

        # update the implicitly defined insets for all the connected layers
        for lay1 in connected_layers.keys():
            for lay2 in connected_layers.keys():

                # ignore defining an inset rule for a layer to itself
                if not lay1 == lay2:

                    # determine distance of lay1 inside of lay2
                    val = connected_layers[lay2] - connected_layers[lay1]

                    update = True

                    # if there's already an explicit rule defined between these layers, skip the update
                    if self.Insets[lay1][lay2] is not None:
                        explicit = self.Insets[lay1][lay2][1]
                        update = not explicit

                    # only update the rule if its implicit
                    if update:
                        self.Insets[lay1][lay2] = (val, False)
                        self.Insets[lay2][lay1] = (-val, False)

    def modifyScales(self, scale=None, update=False):
        if scale and isinstance(scale, float):
            for idx in self.SelectedIndices:
                if not self._lay_data[idx]['Scale'] == scale:
                    self._lay_data[idx]['Scale'] = scale
                    self._modified = True
        
        pub.sendMessage('layers.preview.modified')

        if update:
            self.processDataChange(layers=True, modified=True)

    def modifyMaterials(self, Name=None, MatType=None, CondType=None, CondReal=None, CondImag=None, Rrf=None, Epsilon=None, Mu=None, TanD=None):
        "Modifies the selected materials with the given information"
        for idx in self.SelectedMaterials:
            if Name is not None:
                self._mat_data[idx]['Material'].Name = Name

            if MatType is not None:
                self._mat_data[idx]['Material'].MatType = MatType

            if CondType is not None:
                self._mat_data[idx]['Material'].CondType = CondType

            if CondReal is not None:
                self._mat_data[idx]['Material'].CondReal = CondReal

            if CondImag is not None:
                self._mat_data[idx]['Material'].CondImag = CondImag

            if Rrf is not None:
                self._mat_data[idx]['Material'].Rrf = Rrf

            if Epsilon is not None:
                self._mat_data[idx]['Material'].Epsilon = Epsilon

            if Mu is not None:
                self._mat_data[idx]['Material'].Mu = Mu

            if TanD is not None:
                self._mat_data[idx]['Material'].TanD = TanD

        self.processDataChange(materials=True, modified=True)

    @property
    def isModified(self):
        "Boolean representing whether or not the data manager contains unsaved changes"
        return self._modified

    @property
    def ProcessName(self):
        return self._process_name

    @ProcessName.setter
    def ProcessName(self, str):
        # update process name only if valid
        if utils.checkNameValidity(str):
            self._process_name = str
            self.processDataChange(modified=True)

    @property
    def RawLayerData(self):
        """
        List of dicts that each store information about a layer and its current properties (whether or not it's selected or displayed, its scale...)

        Keys in each dict:
            'Layer' - Layer object of the given layer
            'Selected' - boolean indicating whether or not the current layer is selected
            'Display' - boolean indicating whether or not the current layer is displayed
            'Scale' - float representing the given layer's display scale
        """
        return self._lay_data

    @property
    def RawMaterialData(self):
        """
        List of dicts that each store information about a material and whether or not it's selected

        Keys in each dict:
            'Material' - Material object of the given material
            'Selected' - boolean indicating whether or not the current material is selected
        """
        return self._mat_data

    @property
    def Layers(self):
        "List of Layer objects representing all the layers"
        return [x['Layer'] for x in self._lay_data]

    @property
    def LayerNames(self):
        "List of strings representing all the layers' names"
        return [x['Layer'].name for x in self._lay_data]

    @property
    def Insets(self):
        "Dict of dicts of (float, calculated) tuples that represents the 2D matrix for all global layer insets"
        return self._inset_data

    @property
    def Materials(self):
        "List of Material objects representing all the materials"
        return [x['Material'] for x in self._mat_data]

    @property
    def MaterialNames(self):
        "List of strings representing all the materials' names"
        return [x['Material'].Name for x in self._mat_data]

    @property
    def Substrates(self):
        "List of Substrate objects representing all the substrates"
        return [x for x in self._sub_data]
    
    @property
    def SubstrateNames(self):
        "List of strings representing all the substrates' names"
        return [x.Name for x in self._sub_data]

    @property
    def Selections(self):
        "List of booleans representing all layers' current selection status"
        return [x['Selected'] for x in self._lay_data]

    @property
    def SelectedIndices(self):
        "List of integers indexing currently selected layers"
        layer_list = [ ]

        for idx, selected in enumerate([x['Selected'] for x in self._lay_data]):
            if selected:
                layer_list.append(idx)

        return layer_list

    @property
    def SelectedMaterials(self):
        "List of integers indexing currently selected materials"
        mats_list = [ ]

        for idx, selected in enumerate([x['Selected'] for x in self._mat_data]):
            if selected:
                mats_list.append(idx)

        return mats_list

    @property
    def SelectedSubstrate(self):
        "Returns the currently selected substrate"
        if self._sub_selection is not None:
            return self._sub_data[self._sub_selection]
        else:
            return None

    @property
    def SelectedSubstrateIdx(self):
        "Integer indexing the currently selected substrate"
        return self._sub_selection

    @property
    def DisplayedLayers(self):
        "List of booleans representing all layers' current display status"
        return [x['Display'] for x in self._lay_data]

    @property
    def DisplayedLayerIndices(self):
        "List of integers indexing layers that are currently being displayed"
        displayed_list = [ ]

        for idx, displayed in enumerate([x['Display'] for x in self._lay_data]):
            if displayed:
                displayed_list.append(idx)

        return displayed_list

    @property
    def Scales(self):
        "List of floats representing all layers' current scaling"
        return [x['Scale'] for x in self._lay_data]