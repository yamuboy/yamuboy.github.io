from __future__ import print_function

import argparse
from mautils import cli_utils
from . import utils
from .structures import defaults
import os
import sys

def convert_layout_lay_file(layfile_path, output_dir, reverse_order=True):
    """
    Convert an input layout.lay file into files necessary to create a corresponding technology in ADS2011+
    """
    fp = open(layfile_path, 'r')
    layers = utils.read_ads_layout_lay(fp)
    fp.close()
    
    # the utils.read_ads_layout_lay() call reverses the order of the
    # layers from the .lay file so if the 'reversed' flag is false
    # we need to undo this behavior
    if not reverse_order:
        layers = list(reversed(layers))
        
    # add the ADS default layers to the layer list
    layers = defaults._default_ads_layers[:1] + layers + defaults._default_ads_layers[1:]

    patterns = defaults._default_patterns

    # determine default visibility (hide EM layers, show layout layers)
    vis_list = []
    for i in range(0, len(layers)):
        if layers[i].name[0:3] == 'EM_':
            vis_list.append(False)
        else:
            vis_list.append(True)

    # write library.tech file
    with open(os.path.join(output_dir,'library.tech'), 'w') as fp:
        utils.write_ads_library_tech_file(fp, layers)

    # write display.tech file
    with open(os.path.join(output_dir,'display.tech'), 'w') as fp:
        utils.write_ads_display_tech_file(fp, layers)

    # write technology creation ael file
    with open(os.path.join(output_dir,'create_technology.ael'), 'w') as fp:
        utils.write_ads_create_tech_ael(fp, layers)
        print('rename(strcat("./", LIBRARY_NAME, "/eesof_lib.cfg"), strcat("./", LIBRARY_NAME, "/eesof_lib.cfg.bak"));', file=fp)

    # write layer-map for GDS import/export
    with open(os.path.join(output_dir,'LayerMap.map'), 'w') as fp:
        utils.write_ads_layer_map_file(fp, layers)

    # write eesof_lib.cfg
    with open(os.path.join(output_dir,'eesof_lib.cfg'), 'w') as fp:
        print('BOOT_AEL=create_technology.ael', file=fp)

if __name__ == '__main__':

    # command-line argument parser
    p = argparse.ArgumentParser(prog='ADS2009 Process File Conversion', description='Utility to convert a ADS2009 layout.lay file into the files'
                                + ' necessary to create a corresponding OA technology')
    p.add_argument('layfile', metavar='<layout.lay file>', help='ADS2009 layout.lay file')
    p.add_argument('-n', '--name', dest='name', help='Output directory name (by default outputs to "<layout.lay file name>_tech")')

    # if a file was passed in
    if sys.argv[1:]:
        args = p.parse_args()

        # extract arguments
        layfile = cli_utils.parse_existing_filepath(args.layfile)

        # check arguments
        if layfile and not os.path.splitext(layfile)[1] == '.lay':
            print('Invalid ADS2009 Process File (looking for .lay)')
            sys.exit()

        if args.name:
            output_path = os.path.join(os.getcwd(),args.name)
        else:
            output_path = os.path.join(os.getcwd(),os.path.basename(layfile)[:-4] + '_tech')

    else:
        layfile = cli_utils.prompt_input_file()
        output_path = os.getcwd() + os.sep + os.path.basename(layfile)[:-4] + '_tech' + os.sep

    if not os.path.lexists(output_path):
        os.mkdir(output_path)

    convert_layout_lay_file(layfile, output_path)