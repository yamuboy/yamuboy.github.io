from __future__ import print_function
try:
    _str_type = basestring
except NameError:
    _str_type = str

try:
    from enum import Enum
except ImportError as e:
    print('Missing module enum. Download the \'enum34\' package.')
    try:
        raw_input('Press Enter to exit')
    except NameError:
        input('Press Enter to exit')
    raise SystemExit
    
try:
    from wx.lib.pubsub import setupkwargs
except ImportError:
    # not necessarily required
    pass
