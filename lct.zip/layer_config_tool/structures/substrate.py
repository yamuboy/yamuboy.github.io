from enum import Enum

from .material import *
from .layer import *
from .. import _str_type

class CoverType(Enum):
    PEC     = 0
    OPEN    = 1

class Substrate(object):
    """
    General object that stores all the necessary information to define an EM substrate in both ADS and AWR

    Keywords:

    Name               - String defining the name of the substrate
    BotCover           - CoverType representing what type of cover the bottom of the substrate should be
    TopCover           - CoverType representing what type of cover the top of the substrate should be
    DielectricLayers   - list of dicts {'Material', 'Thickness'} representing the dielectric stackup of the entire substrate. The 0th
                            entry is the bottom of the stack. 'Material' is a Material object, 'Thickness' is a float representing the layer
                            thickness in meters
    MappedLayers       - dict of dict {'<layername>': {'Material', 'Thickness', 'Sheet', 'Index', 'Extent'}} representing mapped EM layers.
                            The outer dict is keyed by the name of the layer, the value of this key is an inner dict keyed as above.
                            'Material' is a material object.
                            'Sheet' is a boolean representing whether the layer is modeled as a sheet metal or a thick metal. Use 'None' for
                                layers mapped as a via.
                            'Thickness' is a float representing the layer thickness in meters. The thickness is used to calculate the loss
                                of the metal, if necessary. Use "None" for conductors that should be defined with sheet resistance instead
                                of conductivity.
                            'Index' is the index of the layer in the stack, i.e. 0 is the first dielectric interface.
                            'Extent' is used for mapped via layers to define how many dielectric layers the via crosses (must be >=1). For
                                non-via layers, this should be None.
    """

    def __init__(self, *args, **kwargs):
        "initializer"
        name = kwargs.pop('name', "")
        bot = kwargs.pop('BotCover', CoverType.PEC)
        top = kwargs.pop('TopCover', CoverType.OPEN)
        diel = kwargs.pop('DielectricLayers', [ ])
        layers = kwargs.pop('MappedLayers', { })

        # check kwargs
        if not isinstance(name, types.StringTypes):
            raise TypeError('\'name\' must be a string')

        if not isinstance(bot, CoverType):
            raise TypeError('\'BotCover\' must be a CoverType')

        if not isinstance(top, CoverType):
            raise TypeError('\'TopCover\' must be a CoverType')

        if not isinstance(diel, list):
            raise TypeError('\'DielectricLayers\' must be a list of dicts')

        if not isinstance(layers, dict):
            raise TypeError('\'MappedLayers\' must be a dict')

        # update properties
        self._name = name
        self._bot_cover = bot
        self._top_cover = top
        self._dielectric_layers = diel
        self._mapped_layers = layers

        self._mapped_layers_by_interface = [ ]
        self.generateMappedLayersByInterface()

        self._selected_dlayer = None
        self._selected_mlayer = None

    def addDielectricLayer(self, material=None, thickness=1e-6, pos=None):
        "Add a new dielectric layer to the dielectric layer stack, optionally setting its thickness and position in the stack"

        if material is not None:
            # dielectric layer cannot be a conductor
            if material.MatType == MaterialType.CONDUCTOR:
                raise ValueError('Dielectric layer must be a dielectric or semiconductor')
            else:
                dLayer = {'Material':material, 'Thickness':thickness}
        
                # insert layer at specified position
                if pos in range(len(self._dielectric_layers)):
                    self._dielectric_layers.insert(pos, dLayer)
                # if no specified position, add this layer to the top of the stack (end of list)
                else:
                    self._dielectric_layers.append(dLayer)

                self.generateMappedLayersByInterface()

                if self._selected_dlayer is not None:
                    if pos is not None:
                        if pos < self._selected_dlayer:
                            self._selected_dlayer += 1

    def modifyDielectricLayer(self, material=None, thickness=None):
        "Modify the currently selected dielectric layer"
        if self.SelectedDielectric is not None:
            newMat = self.SelectedDielectric['Material']
            newThickness = self.SelectedDielectric['Thickness']

            if material is not None:
                if not material.MatType == MaterialType.CONDUCTOR:
                    newMat = material
            if thickness is not None:
                newThickness = thickness

            self.SelectedDielectric['Material'] = newMat
            self.SelectedDielectric['Thickness'] = newThickness

    def removeDielectricLayer(self):
        "Remove the selected dielectric layer, along with any mapped layers above it"
        if self.SelectedDielectric is not None:
            # remove the specified dielectric layer
            self._dielectric_layers.pop(self.SelectedDielectricIndex)

            # shift any mapped layers above this dielectric layer down if possible, otherwise remove them
            for key, val in self._mapped_layers.items():
                if val['Index'] >= self.SelectedDielectricIndex:
                    newIdx = val['Index'] - 1

                    # handle a mapped layer
                    if val['Extent'] is None:
                        if newIdx > 0:
                            self._mapped_layers[key]['Index'] = newIdx
                        else:
                            del self._mapped_layers[key]
                
                    # handle a mapped via
                    else:
                        newExt = val['Extent'] - 1
                        if newIdx >= 0 and newExt >= 1:
                            self._mapped_layers[key]['Index'] = newIdx
                            self._mapped_layers[key]['Extent'] = newExt
                        else:
                            del self._mapped_layers[key]
            
            # clear selection
            self.selectDielectric()
            self.generateMappedLayersByInterface()

    def mapLayer(self, layer=None, material=None, sheet=None, thickness=None, index=None, extent=None):
        "Create a layer map for the specified layer, or modify the map for the selected layer. Use an extent of -1 to convert a via back to a layer"

        # changing an existing layer to a different layer
        if layer is not None and self.SelectedMappedLayerName is not None:
            if layer != self.SelectedMappedLayerName:
                self._mapped_layers[layer] = self._mapped_layers[self.SelectedMappedLayerName]
                del self._mapped_layers[self.SelectedMappedLayerName]
                self._selected_mlayer = layer
            layer = None

        # modifying the currently selected layer
        if layer is None:
            layer = self.SelectedMappedLayerName
            newMaterial = self._mapped_layers[layer].get('Material', None)
            newSheet = self._mapped_layers[layer].get('Sheet', None)
            newThickness = self._mapped_layers[layer].get('Thickness', None)
            newIndex = self._mapped_layers[layer].get('Index', len(self._dielectric_layers) - 1)
            newExtent = self._mapped_layers[layer].get('Extent', None)

        # initializing a new layer mapping
        else:
            newMaterial = None
            newSheet = None
            newThickness = None
            newIndex = len(self._dielectric_layers) - 1
            newExtent = None

        # if a material was passed in
        if material is not None:
            newMaterial = material

            # clear thickness for sheet conductors
            if newMaterial.CondType == ConductorType.SHEET:
                newThickness = None

            # set a default thickness if one isn't already defined for bulk conductors
            elif newMaterial.CondType == ConductorType.BULK:
                if thickness is not None:
                    newThickness = thickness
                elif newThickness is None:
                    newThickness = 1e-9

        # if an index was passed in
        if index is not None:
            if index in range(len(self._dielectric_layers)):
                newIndex = index
            # if the index doesn't lie within the bounds of the substrate
            else:
                newIndex = len(self._dielectric_layers) - 1

        # if an extent was passed in
        if extent is not None:
            # if converting a via into a layer
            if extent == -1:
                newExtent = None
            # if converting a layer into a via, or changing a via extent
            elif extent in range(1, newIndex + 2):
                newExtent = extent
            # if the extent exceeds the lower cover, just default to an extent of 1
            else:
                newExtent = 1

        # if a sheet/thick specification was passed in
        if sheet is not None:
            # ensure no specification for via layers
            newSheet = sheet if newExtent is None else None        

        # add this layer to the dictionary
        self._mapped_layers[layer] = {'Material':newMaterial, 'Sheet':newSheet, 'Thickness':newThickness, 'Index':newIndex, 'Extent':newExtent}
        self.generateMappedLayersByInterface()

    def unmapLayer(self):
        "Remove the currently selected layer from the mapped layer stack."
        if self.SelectedMappedLayer is not None:
            name = self.SelectedMappedLayerName
            self._selected_mlayer = None
            del self._mapped_layers[name]
            self.generateMappedLayersByInterface()

    def selectDielectric(self, pos=None):
        "Select a dielectric layer by index, or clear selection"

        if pos in range(len(self._dielectric_layers)):
            self._selected_dlayer = pos
        else:
            self._selected_dlayer = None

    def selectMappedLayer(self, index=None, subIndex=None):
        """
        Select a mapped layer by index (which dielectric boundary it resides on) and sub-index (the index of this layer in the alphabetized list of
        all layers on this dielectric boundary)
        """
        if index is not None and subIndex is not None:
            self._selected_mlayer = self.MappedLayersByInterface[index][subIndex][0]
        else:
            self._selected_mlayer = None

    def generateMappedLayersByInterface(self):
        'Generates a 2D list of mapped layers that can be indexed by [dielectric interface][drawing position]. List can contain "None" placeholders'

        numDLayers = len(self.DielectricLayers)
        mlayerList = [ ]

        # iterate over dielectric interfaces
        for idx in range(numDLayers):
            
            # separate lists for vias and layers
            viaList = [ ]

            # determine all vias in layer
            for key, val in self.MappedLayers.iteritems():

                # current item resides on this dielectric interface
                if val['Index'] == idx:

                    # current item is a via
                    if val['Extent'] is not None:

                        ext = val['Extent']

                        # check for the existence of any vias that this one will overlap with and pad the via list with Nones to offset this one
                        # iterate up stack starting at bottom of via and working up
                        if None in viaList:
                            padding = viaList.index(None)
                        else:
                            padding = len(viaList)

                        i = idx - ext + 1
                        while i <= idx:
                            if mlayerList:
                                i += 1
                                mlay = None
                                # for every layer at this padding position below the top of the via, check if there is an obstruction
                                if i - 1 < len(mlayerList):
                                    if padding < len(mlayerList[i - 1]):
                                        mlay = mlayerList[i - 1][padding]

                                # obstruction found, increase padding position by one and start from bottom of layer stack again
                                if mlay is not None and mlay[1]['Extent'] is not None:
                                    padding += 1
                                    i = idx - ext + 1
                            else:
                                break

                        # if there is space to place this via earlier in this via list
                        if padding < len(viaList) and viaList[padding] is None:
                            viaList[padding-len(viaList)] = (key, val)

                        # if this layer should be added to the end with determined padding
                        elif padding >= 0:
                            viaList += [None]*(padding-len(viaList))
                            viaList.append((key, val))

            # alphabetize list and append it to the final list
            mlayerList.append(viaList)

        # get maximum number of vias and extend all via lists to match this size
        maxVias = 0
        for vlist in mlayerList:
            maxVias = max(len(vlist), maxVias)
        for vlist in mlayerList:
            vlist.extend([None]*(maxVias - len(vlist)))

        # iterate over dielectric interfaces (after vias are defined)
        for idx in range(numDLayers):
            layerList = [ ]
            for key, val in self.MappedLayers.iteritems():
                # current item resides on this dielectric interface
                if val['Index'] == idx:
                        
                    # current item is a layer
                    if val['Extent'] is None:
                        layerList.append((key, val))

            layerList.sort(key=lambda x: x[0])
            mlayerList[idx] += layerList

        self._mapped_layers_by_interface = mlayerList

    @property
    def Name(self):
        return self._name

    @Name.setter
    def Name(self, str):
        if not isinstance(str, _str_type):
            raise TypeError('\'name\' must be a string')
        self._name = str

    @property
    def BotCover(self):
        return self._bot_cover

    @BotCover.setter
    def BotCover(self, bot):
        if not isinstance(bot, CoverType):
            raise TypeError('\'BotCover\' must be a CoverType')
        self._bot_cover = bot

    @property
    def TopCover(self):
        return self._top_cover

    @TopCover.setter
    def TopCover(self, top):
        if not isinstance(top, CoverType):
            raise TypeError('\'TopCover\' must be a CoverType')
        self._top_cover = top

    @property
    def DielectricLayers(self):
        return self._dielectric_layers

    @property
    def MappedLayersByInterface(self):
        'Generates a 2D list of mapped layers that can be indexed by [dielectric interface][drawing position]. List can contain "None" placeholders'
        return self._mapped_layers_by_interface

    @property
    def MappedLayers(self):
        return self._mapped_layers

    @property
    def MappedLayerNames(self):
        return self._mapped_layers.keys()

    @property
    def SelectedDielectric(self):
        "Returns the selected dielectric layer, or None if there is no selection"
        if self._selected_dlayer is not None:
            return self._dielectric_layers[self._selected_dlayer]
        else:
            return None

    @property
    def SelectedDielectricIndex(self):
        "Returns the index of the selected dielectric layer, or None if there is no selection"
        return self._selected_dlayer

    @property
    def SelectedMappedLayer(self):
        "Returns the information of the layer that is currently selected, or None if there is no selection"
        if self._selected_mlayer is not None:
            return self._mapped_layers[self._selected_mlayer]
        else:
            return None

    @property
    def SelectedMappedLayerName(self):
        "Returns the name of the layer that is currently selected, or None if there is no selection"
        return self._selected_mlayer

    @property
    def AllMaterials(self):
        "Returns an alphabetized list of all materials used in the substrate"
        mat_list = [ ]
        for dlayer in self.DielectricLayers:
            if dlayer['Material'] is not None:
                if mat_list.count(dlayer['Material']) == 0:
                    mat_list.append(dlayer['Material'])

        for key, val in self.MappedLayers.iteritems():
            if val['Material'] is not None:
                if mat_list.count(val['Material']) == 0:
                    mat_list.append(val['Material'])

        mat_list.sort(key=lambda x:x.Name)

        return mat_list
