from .. import _str_type
from enum import Enum

class MaterialType(Enum):
    CONDUCTOR       = 0
    DIELECTRIC      = 1
    SEMICONDUCTOR   = 2

class ConductorType(Enum):
    SHEET   = 0
    BULK    = 1

class Material(object):
    """
    General object that stores all the necessary information to define a material in both ADS and AWR

    All of the numerical parameters can be either a single number to define an isotropic property, or a 3-tuple of floats to define anisotropy, with
    the order of directionality as (x, y, z). In case of an anisotropic material, the "z" value will be used for ADS, and the "x" value will be used
    for the "X/Y" value in Sonnet.

    Keywords:

    Name        - String defining the Name of the material
    MatType     - MaterialType enum that defines whether the material is a conductor, dieletric or semiconductor (ADS types)
    CondType    - ConductorType enum that defines whether a conductor is a sheet (defined with sheet resistance) or bulk (defined with conductivity
                    and thickness). Use "None" for dielectrics/semiconductors
    CondReal    - float/3-tuple that defines this material's sheet resistance (in Ohm/sq) or conductivity (in S/m) (for a conductor), or its
                    resistivity (in Ohm-m) (for a semiconductor). Use "None" for dielectrics
    CondImag    - float/3-tuple that defines this material's surface reactance (in Ohm/sq) (for a sheet conductor). Use "None" for bulk conductors
                    and dielectrics/semiconductors
    Rrf         - float that defines this material's skin-effect coefficient (in Ohm/sq*sqrt(f)). Used in AWR for a sheet-type conductor.
                    Defaults to 0.0. Use "None" for dielectrics/semiconductors.
    Epsilon     - float/3-tuple that defines this material's relative permittivity. Use "None" for conductors
    Mu          - float/3-tuple that defines this material's relative permeability. Use "None" for conductors
    TanD        - float/3-tuple that defines this material's loss tangent. Use "None" for conductors
    """

    def __init__(self, *args, **kwargs):
        "initializer"
        name    = kwargs.pop('Name'     , "Gold")
        mtype   = kwargs.pop('MatType'  , MaterialType.CONDUCTOR)
        ctype   = kwargs.pop('CondType' , ConductorType.BULK)
        creal   = kwargs.pop('CondReal' , 4.0027e7)
        cimag   = kwargs.pop('CondImag' , None)
        rrf     = kwargs.pop('Rrf'      , None)
        eps     = kwargs.pop('Epsilon'  , None)
        mu      = kwargs.pop('Mu'       , None)
        tand    = kwargs.pop('TanD'     , None)

        # check kwargs
        if name:
            if not isinstance(name, _str_type):
                raise TypeError('\'Name\' must be a string')

        if mtype:
            if not isinstance(mtype, MaterialType):
                raise TypeError('\'MatType must be a valid MaterialType\'')

        if ctype:
            if not isinstance(ctype, ConductorType):
                raise TypeError('\'CondType must be a valid ConductorType\'')

        if creal:
            if not (isinstance(creal, float) or isinstance(creal, tuple)):
                raise TypeError('\'CondReal\' must be a float or a 3-tuple of floats')
            elif isinstance(creal, tuple) and not (len(creal) == 3):
                raise TypeError('\'CondReal\' must be a 3-tuple of floats if anisotropic')

        if cimag:
            if not isinstance(cimag, float):
                raise TypeError('\'CondImag\' must be a float')

        if rrf:
            if not (isinstance(rrf, float)):
                raise TypeError('\'Rrf\' must be a float')

        if eps:
            if not (isinstance(eps, float) or isinstance(eps, tuple)):
                raise TypeError('\'Epsilon\' must be a float or a 3-tuple of floats')
            elif isinstance(eps, tuple) and not (len(eps) == 3):
                raise TypeError('\'Epsilon\' epsst be a 3-tuple of floats if anisotropic')

        if mu:
            if not (isinstance(mu, float) or isinstance(mu, tuple)):
                raise TypeError('\'Mu\' must be a float or a 3-tuple of floats')
            elif isinstance(mu, tuple) and not (len(mu) == 3):
                raise TypeError('\'Mu\' must be a 3-tuple of floats if anisotropic')

        if tand:
            if not (isinstance(tand, float) or isinstance(tand, tuple)):
                raise TypeError('\'TanD\' must be a float or a 3-tuple of floats')
            elif isinstance(tand, tuple) and not (len(tand) == 3):
                raise TypeError('\'TanD\' must be a 3-tuple of floats if anisotropic')

        # update properties
        self._name = name
        self._mat_type = mtype
        self._cond_type = ctype
        self._cond_real = creal
        self._cond_imag = cimag
        self._r_rf = rrf
        self._epsilon = eps
        self._mu = mu
        self._tand = tand

    def convert_rsh_to_conductivity(self, thickness):
        """
        Convert a sheet-type conductor's sheet resistance into an equivalent conductivity. Returns a float with the equivalent conductivity in S/m.

        Arguments:
        thickness - float representing the thickness (in meters) of the equivalent sheet to calculate the conductivity with
        """

        if not self._cond_type == ConductorType.SHEET:
            raise TypeError('This material is not defined as a sheet conductor!')
        else:
            return 1.0/(self._cond_real*thickness)

    def convert_conductivity_to_rsh(self, thickness):
        """
        Convert a thick conductor's conductivity and thickness into an equivalent sheet resistance. Returns a float with the equivalent sheet
        resistance in Ohm/sq.

        Arguments:
        thickness - float representing the thickness (in meters) with which to calculate the equivalent sheet resistance
        """

        if not self._cond_type == ConductorType.BULK:
            raise TypeError('This material is not defined as a bulk conductor!')
        else:
            return 1.0/(self._cond_real*thickness)

    @property
    def Name(self):
        return self._name

    @Name.setter
    def Name(self, str):
        if not isinstance(str, _str_type):
            raise TypeError('\'Name\' must be a string')
        self._name = str

    @property
    def MatType(self):
        return self._mat_type
    
    @MatType.setter
    def MatType(self, mtype):
        if not isinstance(mtype, MaterialType):
            raise TypeError('\'MatType\' must be a valid MaterialType')
        self._mat_type = mtype

        # set the conductor type to None if not a conductor and set any unused parameters accordingly
        if not mtype == MaterialType.CONDUCTOR:
            self.CondType = None
            self.CondImag = None
            if mtype == MaterialType.DIELECTRIC:
                self.CondReal = None

        # if a conductor, set unused parameters
        else:
            self.Epsilon = None
            self.Mu = None
            self.TanD = None

            # if it is a bulk conductor or no conductor type has been set, initialize it to a bulk conductor and clear Rrf
            if self.CondType in [ConductorType.BULK, None]:
                self.CondType = ConductorType.BULK
                self.Rrf = None

    @property
    def CondType(self):
        return self._cond_type
    
    @CondType.setter
    def CondType(self, ctype):
        if ctype is not None:
            if not isinstance(ctype, ConductorType):
                raise TypeError('\'CondType\' must be a valid ConductorType')
        elif self.MatType == MaterialType.CONDUCTOR:
            raise ValueError('\'CondType\' must be defined for a conductor')

        self._cond_type = ctype

        if ctype == ConductorType.BULK:
            self.Rrf = None
            self.CondImag = None

    @property
    def CondReal(self):
        return self._cond_real
    
    @CondReal.setter
    def CondReal(self, creal):
        if self.MatType == MaterialType.DIELECTRIC:
            creal = None
        if creal is not None:
            if not (isinstance(creal, float) or isinstance(creal, tuple)):
                raise TypeError('\'CondReal\' must be a float or a 3-tuple of floats')
            elif isinstance(creal, tuple) and not (len(creal) == 3):
                raise TypeError('\'CondReal\' must be a 3-tuple of floats if anisotropic')
        elif self.MatType == MaterialType.CONDUCTOR:
            raise ValueError('\'CondReal\' must be defined for a conductor')
        elif self.MatType == MaterialType.SEMICONDUCTOR:
            raise ValueError('\'CondReal\' must be defined for a semiconductor')
        self._cond_real = creal

    @property
    def CondImag(self):
        return self._cond_imag
    
    @CondImag.setter
    def CondImag(self, cimag):
        if not self.MatType == MaterialType.CONDUCTOR or self.CondType == ConductorType.BULK:
            cimag = None
        if cimag is not None:
            if not isinstance(cimag, float):
                raise TypeError('\'CondImag\' must be a float')
        elif self.MatType == MaterialType.CONDUCTOR and self.CondType == ConductorType.SHEET:
            raise ValueError('\'CondImag\' must be defined for a sheet conductor')
        self._cond_imag = cimag

    @property
    def Rrf(self):
        return self._r_rf
    
    @Rrf.setter
    def Rrf(self, rrf):
        if not (self.MatType == MaterialType.CONDUCTOR and self.CondType == ConductorType.SHEET):
            rrf = None
        if rrf is not None:
            if not (isinstance(rrf, float)):
                raise TypeError('\'Rrf\' must be a float')
        elif self.MatType == MaterialType.CONDUCTOR and self.CondType == ConductorType.SHEET:
            raise ValueError('\'Rrf\' must be defined for a sheet conductor')
        self._r_rf = rrf

    @property
    def Epsilon(self):
        return self._epsilon
    
    @Epsilon.setter
    def Epsilon(self, eps):
        if self.MatType == MaterialType.CONDUCTOR:
            eps = None
        if eps is not None:
            if not (isinstance(eps, float) or isinstance(eps, tuple)):
                raise TypeError('\'Epsilon\' must be a float or a 3-tuple of floats')
            elif isinstance(eps, tuple) and not (len(eps) == 3):
                raise TypeError('\'Epsilon\' must be a 3-tuple of floats if anisotropic')
        elif self.MatType in [MaterialType.DIELECTRIC, MaterialType.SEMICONDUCTOR]:
            raise ValueError('\'Epsilon\' must be defined for a dielectric or semiconductor')
        self._epsilon = eps

    @property
    def Mu(self):
        return self._mu
    
    @Mu.setter
    def Mu(self, mu):
        if self.MatType == MaterialType.CONDUCTOR:
            mu = None
        if mu is not None:
            if not (isinstance(mu, float) or isinstance(mu, tuple)):
                raise TypeError('\'Mu\' must be a float or a 3-tuple of floats')
            elif isinstance(mu, tuple) and not (len(mu) == 3):
                raise TypeError('\'Mu\' must be a 3-tuple of floats if anisotropic')
        elif self.MatType in [MaterialType.DIELECTRIC, MaterialType.SEMICONDUCTOR]:
            raise ValueError('\'Mu\' must be defined for a dielectric or semiconductor')
        self._mu = mu

    @property
    def TanD(self):
        return self._tand
    
    @TanD.setter
    def TanD(self, tand):
        if self.MatType == MaterialType.CONDUCTOR:
            tand = None
        if tand is not None:
            if not (isinstance(tand, float) or isinstance(tand, tuple)):
                raise TypeError('\'TanD\' must be a float or a 3-tuple of floats')
            elif isinstance(tand, tuple) and not (len(tand) == 3):
                raise TypeError('\'TanD\' must be a 3-tuple of floats if anisotropic')
        elif self.MatType in [MaterialType.DIELECTRIC, MaterialType.SEMICONDUCTOR]:
            raise ValueError('\'TanD\' must be defined for a dielectric or semiconductor')
        self._tand = tand