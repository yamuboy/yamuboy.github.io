from .pattern import Pattern
from .style import LineStyle
from .. import _str_type

class Layer(object):
    """
    General object that stores all the necessary information to define a layer in both ADS and AWR

    Keywords:

    name        - String defining the name of the layer
    gds         - Integer defining the GDS layer number of the layer
    color       - either a hex string, an Integer representing a packed BGR value, or a 3-tuple of ints representing (Red, Green, Blue)
    alpha       - Integer in [0, 255] representing the transparency for the layer (0 = opaque, 255 = transparent)
    pattern     - Pattern type that stores the layer's fill pattern (see layer_config_tool.structures.pattern.Pattern). Set to "None" for no fill
    style       - LineStyle enum that defines the bounding line style of the layer. Set to None for no outline (ADS only, AWR will revert to solid)
    visible     - Boolean representing whether or not the layer is visible by default
    cloak       - Boolean representing whether or not the layer is hidden from the users's view by default (AWR only, ADS always shows all layers)
    binding     - List of Layers
    min_width   - Float representing the minimum width of the layer (None if not specified)
    min_spacing - Float representing the minimum notch spacing of this layer (None if not specified)
    """

    def __init__(self, *args, **kwargs):
        "initializer"
        nam = kwargs.pop('name', "")
        num = kwargs.pop('gds', 0)
        col = kwargs.pop('color', (0, 0, 0))
        alpha = kwargs.pop('alpha', 0)
        pat = kwargs.pop('pattern', None)
        ls = kwargs.pop('style', LineStyle.Solid)
        vis = kwargs.pop('visible', True)
        clk = kwargs.pop('cloak', False)
        bind = kwargs.pop('binding', [])
        minw = kwargs.pop('min_width', None)
        mins = kwargs.pop('min_spacing', None)

        # check kwargs
        if not isinstance(nam, _str_type):
            raise TypeError('\'name\' must be a string')

        if not isinstance(num, int):
            raise TypeError('\'gds\' must be an integer between 0-255')
        elif not 0 <= num <= 255:
            raise TypeError('\'gds\' must be an integer between 0-255')

        if not isinstance(col, (_str_type, int, tuple)):
            raise TypeError('\'color\' must be hex string, an Integer representing a packed RGB value, or a 3-tuple of ints representing (Red, Green, Blue)')
        elif isinstance(col, _str_type) and not int(col.lstrip('#'), 16):
            raise TypeError('Invalid color hex string')
        elif isinstance(col, tuple) and not all(isinstance(x, int) for x in col):
            raise TypeError('Invalid color RGB tuple')

        if not isinstance(alpha, int):
            raise TypeError('\'alpha\' must be an integer between 0-255')
        elif not 0 <= alpha <= 255:
            raise TypeError('\'alpha\' must be an integer between 0-255')

        if pat is not None and not isinstance(pat, Pattern):
            raise TypeError('\'pattern\' must be of type layer_config_tool.structures.pattern.Pattern')

        if ls is not None and not (isinstance(ls, LineStyle) or isinstance(ls, int)):
            raise TypeError('\'style\' must be a LineStyle or an int')

        if not isinstance(vis, bool):
            raise TypeError('\'visible\' must be a boolean')

        if not isinstance(clk, bool):
            raise TypeError('\'cloak\' must be a boolean')

        if not isinstance(bind, list):
            raise TypeError('\'binding\' must be a list of Layers')
        elif isinstance(bind, list):
            if not all(isinstance(x, Layer) for x in bind):
                raise TypeError('\'binding\' must be a list of Layers')

        if minw is not None:
            if not isinstance(minw, float):
                raise TypeError('\'min_width\' must be a float')

        if mins is not None:
            if not isinstance(mins, float):
                raise TypeError('\'min_width\' must be a float')

        # update properties
        self._name = nam
        self._gds = num

        if isinstance(col, _str_type):
            self._color = int(col.lstrip('#'), 16)
        elif isinstance(col, tuple):
            self._color = int("".join(map(chr, col)).encode('hex'), 16)
        elif isinstance(col, int):
            self._color = col

        self._alpha = alpha
        self._pattern = pat
        self._style = ls
        self._visible = vis
        self._cloak = clk
        self._binding = bind
        self._min_width = minw
        self._min_spacing = mins

    @property
    def name(self):
        try:
            name = self._name
        except AttributeError:
            self.name = 'Layer'
        return self._name

    @name.setter
    def name(self, str):
        if not isinstance(str, _str_type):
            raise TypeError('\'name\' must be a string')
        self._name = str

    @property
    def gds(self):
        try:
            gds = self._gds
        except AttributeError:
            self.gds = 0
        return self._gds

    @gds.setter
    def gds(self, num):
        if not isinstance(num, int):
            raise TypeError('\'gds\' must be an integer between 0-255')
        elif not 0 <= num <= 255:
            raise TypeError('\'gds\' must be an integer between 0-255')
        self._gds = num

    @property
    def color(self):
        "Returns color as a packed 24-bit BGR integer"
        try:
            color = self._color
        except AttributeError:
            self.color = 0
        return self._color

    @color.setter
    def color(self, col):
        if not isinstance(col, (_str_type, int, tuple)):
            raise TypeError('\'color\' must be hex string, an Integer representing a packed BGR value, or a 3-tuple of ints representing (Red, Green, Blue)')
        elif isinstance(col, _str_type) and not int(col.lstrip('#'), 16):
            raise TypeError('Invalid color hex string')
        elif isinstance(col, tuple) and not all(isinstance(x, int) for x in col):
            raise TypeError('Invalid color RGB tuple')

        if isinstance(col, _str_type):
            self._color = int(col.lstrip('#'), 16)
        elif isinstance(col, tuple):
            self._color = int("".join(map(chr, col)).encode('hex'), 16)
        elif isinstance(col, int):
            self._color = col

    @property
    def color_rgb(self):
        "Returns color as a packed 24-bit RGB integer"
        try:
            color = self._color
        except AttributeError:
            self.color = 0
        return (self.red << 16) + (self.green << 8) + self.blue

    @property
    def color_rgb_tuple(self):
        "Returns color as an integer (R, G, B) 3-tuple"
        try:
            color = self._color
        except AttributeError:
            self.color = 0
        return (self.red, self.green, self.blue)

    @property
    def red(self):
        try:
            color = self._color
        except AttributeError:
            self.color = 0
        return self._color & 0x0000FF

    @property
    def green(self):
        try:
            color = self._color
        except AttributeError:
            self.color = 0
        return (self._color & 0x00FF00) >> 8

    @property
    def blue(self):
        try:
            color = self._color
        except AttributeError:
            self.color = 0
        return (self._color & 0xFF0000) >> 16

    @property
    def alpha(self):
        try:
            alpha = self._alpha
        except AttributeError:
            self.alpha = 0
        return self._alpha

    @alpha.setter
    def alpha(self, num):
        if not isinstance(num, int):
            raise TypeError('\'alpha\' must be an integer between 0-255')
        elif not 0 <= num <= 255:
            raise TypeError('\'alpha\' must be an integer between 0-255')
        self._alpha = num

    @property
    def pattern(self):
        try:
            pattern = self._pattern
        except AttributeError:
            self.pattern = None
        return self._pattern

    @pattern.setter
    def pattern(self, pat):
        if pat is not None:
            if not isinstance(pat, Pattern):
                raise TypeError('\'pattern\' must be of type layer_config_tool.structures.pattern.Pattern')
            self._pattern = pat
        else:
            self._pattern = None

    @property
    def style(self):
        try:
            style = self._style
        except AttributeError:
            self.style = LineStyle.NoLine
        return self._style

    @style.setter
    def style(self, ls):
        if ls:
            if not (isinstance(ls, LineStyle) or isinstance(ls, int)):
                raise TypeError('\'style\' must be a LineStyle or an int')
            if isinstance(ls, LineStyle):
                self._style = ls
            else:
                self._style = LineStyle(ls)
        else:
            self._style = LineStyle.NoLine

    @property
    def visible(self):
        try:
            visible = self._visible
        except AttributeError:
            self.visible = True
        return self._visible

    @visible.setter
    def visible(self, vis):
        if not isinstance(vis, bool):
            raise TypeError('\'visible\' must be a boolean')
        self._visible = vis

    @property
    def cloak(self):
        try:
            cloak = self._cloak
        except AttributeError:
            self.cloak = False
        return self._cloak

    @cloak.setter
    def cloak(self, clk):
        if not isinstance(clk, bool):
            raise TypeError('\'cloak\' must be a boolean')
        self._cloak = clk

    @property
    def binding(self):
        try:
            binding = self._binding
        except AttributeError:
            self.binding = []
        return self._binding

    @binding.setter
    def binding(self, bind):
        if not isinstance(bind, list):
            raise TypeError('\'binding\' must be a list of Layers')
        elif isinstance(bind, list):
            if not all(isinstance(x, Layer) for x in bind):
                raise TypeError('\'binding\' must be a list of Layers')
        del self._binding
        self._binding = bind

    @property
    def min_width(self):
        try:
            min_width = self._min_width
        except AttributeError:
            self.min_width = 0.0
        return self._min_width

    @min_width.setter
    def min_width(self, minw):
        if minw is not None:
            if not isinstance(minw, float):
                raise TypeError('\'min_width\' must be a float')
            self._min_width = minw
        else:
            self._min_width = None

    @property
    def min_spacing(self):
        try:
            min_spacing = self._min_spacing
        except AttributeError:
            self.min_spacing = 0.0
        return self._min_spacing

    @min_spacing.setter
    def min_spacing(self, mins):
        if mins is not None:
            if not isinstance(mins, float):
                raise TypeError('\'min_spacing\' must be a float')
            self._min_spacing = mins
        else:
            self._min_spacing = None

    def __str__(self):
        return 'LAYER_{}'.format(self.name)