from __future__ import print_function

import re
import os
import struct
import sys

width_re = r'\#define .+_width (\d+)\n'
length_re = r'\#define .+_height (\d+)\n'
name_re = r'.+ (.+)_bits.+\n'
empty_text = 'No Fill'

class Pattern(object):
    """
    Class that encapsulates a fill pattern

    Members:
    _width - width of the pattern (int)
    _height - height of the pattern (int)
    _name - name of the pattern (str)
    _lines - list of list of booleans, where n is the width of the line
    """
    def __init__(self, filename=None, name=None, lines=None):
        """
        Initializer

        Keywords:

        filename - path to an ADS pattern file to initialize from. If this is passed in, all other keywords are ignored.
        name - name of the pattern. Must be passed in along with the lines kwarg to initialize properly
        lines - list of lists of booleans that store the pattern data. Must also pass in the name kwarg to initialize properly
        """

        # if a file is passed in, load from that
        if filename:
            self.read_ADS_pattern(filename)

        # if no file is passed in, but a name and lines are passed in
        elif (name and lines) and not filename:
            self._width = len(lines[0])
            self._height = len(lines)
            self._name = name
            self._lines = lines

        # default initialization
        else:
            self._width = 16
            self._height = 16
            self._name = empty_text
            self._lines =   [
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                               [False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
                            ]

    def __eq__(self, other):
        if other is not None and isinstance(other, Pattern):
            return self._name == other._name
        else:
            return False

    def print_pattern(self):
        "Prints the pattern to console"
        for line in self._lines:
            for bit in line:
                if bit:
                    print(u'\u2588', end="")
                else:
                    print(' ', end="")
            print()

    def generate_pattern_awr_lpf(self):
        """
        Generates a single string with the pattern in AWR LPF format
        """
        #   Sample AWR LPF pattern format
        #
        #   ( display forward_slash (
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #       ( 0 1 0 1 0 1 0 1 )
        #       ( 1 0 1 0 1 0 1 0 )
        #   ) )

        outStr = ''
        outStr += '( display {} (\n'.format(self._name)

        for line in self._lines:
            outStr += '  ( '

            for bit in line:
                outStr += '1 ' if bit else '0 '

            outStr += ')\n'

        outStr += ') )\n'

        return outStr

    def print_pattern_awr_lpf(self, stream=sys.stdout):
        """
        Prints pattern to the specified stream in AWR LPF format
        """

        print(self.generate_pattern_awr_lpf(), file=stream)

    def generate_pattern_klayout_lyp(self, index=0):
        """
        Generates a single string with the pattern in KLayout .lyp format
        """
        #   Sample KLayout pattern format
        #   <custom-dither-pattern>
        #    <pattern>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***.....***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>********************************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*.*..**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**......**..*...**......**...</line>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***...*.***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>***************.****************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*....**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**...*..**......**......**...</line>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***.....***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>********************************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*....**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**......**......**......**...</line>
        #     <line>.****.*..****.*..****.*..****.*.</line>
        #     <line>..***.....***.....***.....***...</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>********************************</line>
        #     <line>********************************</line>
        #     <line>...**.*....**.*....**.*....**.*.</line>
        #     <line>.*.**....*.**....*.**....*.**...</line>
        #     <line>...**......**......**......**...</line>
        #    </pattern>
        #    <order>1</order>
        #    <name/>
        #   </custom-dither-pattern>

        outStr = ''
        outStr += ' <custom-dither-pattern>\n'
        outStr += '  <pattern>\n'

        # KLayout uses 32x32, so must repeat patterns smaller than 32x32 accordingly
        j = 0
        while(j < 32):
            for line in self._lines:
                i = 0
                outStr += '   <line>'

                while(i < 32):
                    for bit in line:
                        outStr += '*' if bit else '.'
                        i += 1

                outStr += '</line>\n'

                j += 1

        outStr += '  </pattern>\n'
        outStr += '  <order>{:d}</order>\n'.format(index)
        outStr += '  <name>{}</name>\n'.format(self.name)
        outStr += ' </custom-dither-pattern>\n'

        return outStr

    def print_pattern_klayout_lyp(self, stream=sys.stdout, index=0):
        """
        Prints pattern to the specified stream in KLayout .lyp format
        """
        print(self.generate_pattern_klayout_lyp(index) , file=stream)

    def generate_pattern_ads(self):
        """
        Generates a single string with the pattern in ADS format
        """
        #   Sample ADS pattern format
        #
        #   #define pat1_width 16
        #   #define pat1_height 16
        #   static unsigned char pat1_bits[] = {
        #      0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa,
        #      0x7f, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa,
        #      0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa};

        outStr = ''
        outStr += '#define {}_width {}\n'.format(self._name, str(self.width))
        outStr += '#define {}_height {}\n'.format(self._name, str(self.height))
        outStr += 'static unsigned char {}_bits[] = {{'.format(self._name)

        idx = 0
        for line in self._lines:
            segments = [line[x:x + 8] for x in xrange(0, len(line), 8)]

            for segment in segments:
                bits = 0
                for bit in reversed(range(0, 8)):
                    if segment[bit]:
                        bits += 1 << (bit)

                if idx == 0:
                    outStr += '\n   0x{:02x}'.format(bits)
                elif not idx%12 and not idx == 0:
                    outStr += ',\n   0x{:02x}'.format(bits)
                else:
                    outStr += ', 0x{:02x}'.format(bits)

                idx += 1

        outStr += '};\n'

        return outStr

    def print_pattern_ads(self, stream=sys.stdout):
        """
        Prints pattern to the specified stream in ADS format
        """

        print(self.generate_pattern_ads(), file=stream)

    def read_ADS_pattern(self, filename):
        """
        Reads an ADS pattern file

        Arguments:

        filename - path to the "*.pattern" file

        """

        #   A sample ADS pattern file looks as follows:
        #
        #   #define pat1_width 16
        #   #define pat1_height 16
        #   static unsigned char pat1_bits[] = {
        #      0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa, 0x7f, 0x55, 0xaa, 0xaa,
        #      0x7f, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa,
        #      0x55, 0x55, 0xaa, 0xaa, 0x55, 0x55, 0xaa, 0xaa};
        #
        #   Extract width of pattern from line 0
        #   Extract height of pattern from line 1
        #   Extract name of pattern from filename
        #   Extract pattern lines from lines 3:

        fp = open(filename)
        lines = fp.readlines()

        # get pattern width, height, and name
        self._width = int(re.match(width_re, lines[0]).group(1))
        self._height = int(re.match(length_re, lines[1]).group(1))
        self._name = os.path.basename(filename).split('.')[-2]

        # parse pattern lines

        # combine all 8-bit segments into one string
        all_segments = "".join(lines[3:]).replace('\n', '')[:-2]

        # parse all 8-bit segments into list of bytes
        segments = [int(x.strip()[2:4], 16) for x in re.split(r',', all_segments)]

        # determine how many consecutive bytes make up one line
        segs_per_line = len(segments) / self._width

        patlines = [ ]

        # store lines
        # index over number of lines
        for i in range(0, len(segments), segs_per_line):

            line = [ ]

            # index over number of bytes in a line
            for j in range (0, segs_per_line):

                # index over bits in a byte
                for k in range (0, 8):

                    bit = ((segments[i + j] >> k) & 1) == 1
                    line.append(bit)

            patlines.append(line)

        self._lines = patlines

    @property
    def width(self):
        return self._width

    @property
    def height(self):
        return self._height

    @property
    def name(self):
        return self._name

    @property
    def lines(self):
        return self._lines

    @property
    def byte_array(self):
        flat_list = [bit for col in self._lines for bit in col]

        bool_array = (flat_list[pos:pos + 8] for pos in range(0, len(flat_list), 8))

        array = ''
        for bool_line in bool_array:
            line = 0
            for idx, bit in enumerate(bool_line):
                line |= 1 << idx if bit else 0

            array += struct.pack(">B", line)

        return array
