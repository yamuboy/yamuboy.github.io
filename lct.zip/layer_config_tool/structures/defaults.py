import re

from .layer import Layer
from .material import Material, MaterialType
from .pattern import Pattern
from .style import LineStyle

_mapped_layer_x_dim = 50
_mapped_layer_x_gap = 75
_thickness_text_x_dim = 100

_x_dim_pad = 50
_y_dim_pad = 50
_diel_y_dim = 50
_layer_y_dim = 15

_dielectric_color = (0, 128, 192)
_PEC_color = (192, 192, 192)
_open_color = (255, 255, 255)
_border_color = (0, 0, 0)
_selected_color = (255, 0, 0)
_layer_color = (192, 192, 0)
_interface_color = (128, 128, 128)
_reciprocal_rule_color = (0, 192, 0)
_derived_rule_color = (192, 0, 0)
_regular_rule_color = (0, 0, 0)

_re_name_invalid_chars = re.compile(r'[^\w_]')
#_no_fill_text = 'No Fill'
#_no_outline_text = 'No Outline'
_diff_multi_select_text = '***'
_diff_multi_select_text_verbose = '***Multiple Selections***'
_diff_multi_mats_selected_text = '***Multiple Material Types Selected - Re-select to modify***'
_diff_multi_conds_selected_text = '***Multiple Different Conductor Types Selected***'
_titlebar_text = 'Layer Configuration Tool'
_modified_str = '[*] '
_no_value_str = 'NONE'

_canvas_size = (256, 256)
_box_size = 128

_text_indent_amount = 4

_default_patterns = [
    Pattern(
	    name='No Fill',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='pat1',
	    lines=[
			    [ True , True , True , True , True , True , True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
	    ]
    ),
    Pattern(
	    name='pat2',
	    lines=[
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
	    ]
    ),
    Pattern(
	    name='pat3',
	    lines=[
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
	    ]
    ),
    Pattern(
	    name='pat4',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
	    ]
    ),
    Pattern(
	    name='pat5',
	    lines=[
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
	    ]
    ),
    Pattern(
	    name='pat6',
	    lines=[
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
			    [ False, False, True , False, False, True , False, False, True , False, False, True , False, False, True , False ],
			    [ False, True , False, False, True , False, False, True , False, False, True , False, False, True , False, False ],
			    [ True , False, False, True , False, False, True , False, False, True , False, False, True , False, False, True  ],
	    ]
    ),
    Pattern(
	    name='pat7',
	    lines=[
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
	    ]
    ),
    Pattern(
	    name='pat8',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='pat9',
	    lines=[
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
	    ]
    ),
    Pattern(
	    name='pat10',
	    lines=[
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
	    ]
    ),
    Pattern(
	    name='weave_light',
	    lines=[
			    [ True , False, False, False, False, True , False, False, True , False, False, False, False, True , False, False ],
			    [ False, True , False, False, True , False, False, False, False, True , False, False, True , False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, True , False, False, True , False, False, False, False, True , False, False, True , False, False, False ],
			    [ True , False, False, False, False, True , False, False, True , False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ True , False, False, False, False, True , False, False, True , False, False, False, False, True , False, False ],
			    [ False, True , False, False, True , False, False, False, False, True , False, False, True , False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, True , False, False, True , False, False, False, False, True , False, False, True , False, False, False ],
			    [ True , False, False, False, False, True , False, False, True , False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
	    ]
    ),
    Pattern(
	    name='geoa20',
	    lines=[
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
	    ]
    ),
    Pattern(
	    name='geof21',
	    lines=[
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, True , True , False, False, True , True , False, False, True , True  ],
			    [ True , True , False, False, True , True , False, False, True , True , False, False, True , True , False, False ],
	    ]
    ),
    Pattern(
	    name='circles_small',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='geoe20',
	    lines=[
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
	    ]
    ),
    Pattern(
	    name='geoe21',
	    lines=[
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
	    ]
    ),
    Pattern(
	    name='geod21',
	    lines=[
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
	    ]
    ),
    Pattern(
	    name='geoc21',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
	    ]
    ),
    Pattern(
	    name='solid',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
	    ]
    ),
    Pattern(
	    name='pyramid',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , False, False ],
			    [ False, True , False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , False, False, False, False ],
			    [ False, True , False, True , False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , True , False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , False, True , False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , True , False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , False, True , False, True , False, True , False, False, False, False ],
			    [ False, True , False, True , True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , False, True , False, True , False, True , False, True , False, True , False, False ],
			    [ False, True , True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='geoh40',
	    lines=[
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='geoh42',
	    lines=[
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='geoe40',
	    lines=[
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='geoe42',
	    lines=[
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='geob40',
	    lines=[
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='geob42',
	    lines=[
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='geoa40',
	    lines=[
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='geoa42',
	    lines=[
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='chain01',
	    lines=[
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='chain03',
	    lines=[
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, True , True , False, False, False, False, False, False, True  ],
			    [ False, True , False, False, False, False, True , False, False, True , False, False, False, False, True , False ],
			    [ False, False, True , False, False, True , False, False, False, False, True , False, False, True , False, False ],
			    [ False, False, False, True , True , False, False, False, False, False, False, True , True , False, False, False ],
	    ]
    ),
    Pattern(
	    name='geog40',
	    lines=[
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
	    ]
    ),
    Pattern(
	    name='geog42',
	    lines=[
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='geof40',
	    lines=[
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='geof42',
	    lines=[
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, True , True , False, False, False, False, False, False, True , True , False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , True , False, False, False, False, False, False, True , True  ],
	    ]
    ),
    Pattern(
	    name='med_dots_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='med_dots_2',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ True , True , False, False, False, False, False, False, True , True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
			    [ False, False, False, False, True , True , False, False, False, False, False, False, True , True , False, False ],
	    ]
    ),
    Pattern(
	    name='random_light',
	    lines=[
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='random_light2',
	    lines=[
			    [ False, False, True , False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, True , False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, True , False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, True , False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='random_light3',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='random_light4',
	    lines=[
			    [ False, False, False, True , False, False, False, True , False, False, False, False, False, True , False, False ],
			    [ False, True , False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, True , False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, True , False, False, True , False, True , False ],
			    [ False, False, True , False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, True , False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, True , False, False, False, False, True , False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='pat4a',
	    lines=[
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='pat4b',
	    lines=[
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='pat4c',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='pat4d',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='small_dots_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='small_dots_2',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='geod40',
	    lines=[
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
			    [ True , False, False, False, True , False, False, False, True , False, False, False, True , False, False, False ],
	    ]
    ),
    Pattern(
	    name='geod42',
	    lines=[
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
			    [ False, False, True , False, False, False, True , False, False, False, True , False, False, False, True , False ],
	    ]
    ),
    Pattern(
	    name='geoc40',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='geoc42',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='corner_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , True , True , True , False, False, False, False, True , True , True , True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , True , True , True , False, False, False, False, True , True , True , True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='corner_2',
	    lines=[
			    [ False, False, False, False, True , True , True , True , False, False, False, False, True , True , True , True  ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , True , True , True , False, False, False, False, True , True , True , True  ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_right_coarse_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_right_coarse_2',
	    lines=[
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_left_coarse_1',
	    lines=[
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_left_coarse_2',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_right_1',
	    lines=[
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_right_2',
	    lines=[
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='diag_left_1',
	    lines=[
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='diag_left_2',
	    lines=[
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='horz_zigzag_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='horz_zigzag_2',
	    lines=[
			    [ False, False, True , False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, True , False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='vert_zigzag_1',
	    lines=[
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='vert_zigzag_2',
	    lines=[
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, True  ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='dash_diag',
	    lines=[
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, True , False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, True  ],
			    [ False, False, False, False, False, False, True , False, False, False, False, False, False, False, True , False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, True , False, False, False, False ],
			    [ False, False, True , False, False, False, False, False, False, False, True , False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, True , False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='dash_vert_1',
	    lines=[
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, True , False, False, False, False, False, False, False, True , False, False, False, False, False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
			    [ False, False, False, False, False, True , False, False, False, False, False, False, False, True , False, False ],
	    ]
    ),
    Pattern(
	    name='dash_vert_2',
	    lines=[
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='dots_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='dots_2',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ True , False, False, True , True , False, False, True , True , False, False, True , True , False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, True , True , False, False, True , True , False, False, True , True , False, False, True , True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='horz_coarse',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='horz_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
	    ]
    ),
    Pattern(
	    name='horz_2',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='horz_vert_1',
	    lines=[
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
	    ]
    ),
    Pattern(
	    name='horz_vert_2',
	    lines=[
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
	    ]
    ),
    Pattern(
	    name='vert_coarse',
	    lines=[
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='vert_1',
	    lines=[
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='vert_2',
	    lines=[
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
	    ]
    ),
    Pattern(
	    name='shade_1',
	    lines=[
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='shade_2',
	    lines=[
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, False, False, False, False, False, False, True , False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, True , False, False, False, False, False, False, False, True , False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='shade_3',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='shade_4',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, False, False, True , False, False, False, True , False, False, False, True , False, False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, False, False, True , False, False, False, True , False, False, False, True , False, False, False, True  ],
	    ]
    ),
    Pattern(
	    name='shade_5_1',
	    lines=[
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ False, True , False, True , False, True , False, True , False, True , False, True , False, True , False, True  ],
	    ]
    ),
    Pattern(
	    name='shade_5_2',
	    lines=[
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
			    [ True , False, True , False, True , False, True , False, True , False, True , False, True , False, True , False ],
			    [ False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False ],
	    ]
    ),
    Pattern(
	    name='shade_9',
	    lines=[
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , False, True , True , True , False, True , True , True , False, True , True , True , False, True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , False, True , True , True , False, True , True , True , False, True , True , True , False, True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , False, True , True , True , False, True , True , True , False, True , True , True , False, True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , False, True , True , True , False, True , True , True , False, True , True , True , False, True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
			    [ True , True , True , True , True , True , True , True , True , True , True , True , True , True , True , True  ],
	    ]
    )
]

_default_materials = [
    Material(
                Name='Air',
                MatType=MaterialType.DIELECTRIC,
                CondType=None,
                CondReal=None,
                CondImag=None,
                Epsilon=1.0,
                Mu=1.0,
                TanD=0.0
            )
]

# based off of ADS 2009 color list
_default_colors_bgr = [
    #   Blue            Green           Red 
        (0   << 16) +   (0    << 8) +   0,      # 0:    black
        (0   << 16) +   (0    << 8) +   255,    # 1:    red
        (0   << 16) +   (255  << 8) +   255,    # 2:    yellow
        (0   << 16) +   (255  << 8) +   0,      # 3:    green
        (255 << 16) +   (255  << 8) +   0,      # 4:    cyan
        (255 << 16) +   (0    << 8) +   0,      # 5:    blue
        (255 << 16) +   (0    << 8) +   255,    # 6:    magenta
        (192 << 16) +   (192  << 8) +   192,    # 7:    gray
        (255 << 16) +   (255  << 8) +   255,    # 8:    white
        (205 << 16) +   (0    << 8) +   0,      # 9:    mediumblue
        (79  << 16) +   (79   << 8) +   47,     # 10:   DarkSlateGray
        (105 << 16) +   (105  << 8) +   105,    # 11:   DimGrey
        (144 << 16) +   (128  << 8) +   112,    # 12:   SlateGrey
        (112 << 16) +   (25   << 8) +   25,     # 13:   MidnightBlue
        (128 << 16) +   (0    << 8) +   0,      # 14:   NavyBlue
        (139 << 16) +   (61   << 8) +   72,     # 15:   DarkSlateBlue
        (205 << 16) +   (90   << 8) +   106,    # 16:   SlateBlue
        (238 << 16) +   (104  << 8) +   123,    # 17:   MediumSlateBlue
        (205 << 16) +   (0    << 8) +   0,      # 18:   mediumblue
        (225 << 16) +   (105  << 8) +   65,     # 19:   RoyalBlue
        (255 << 16) +   (0    << 8) +   0,      # 20:   blue
        (255 << 16) +   (144  << 8) +   30,     # 21:   DodgerBlue
        (180 << 16) +   (130  << 8) +   70,     # 22:   SteelBlue
        (0   << 16) +   (100  << 8) +   0,      # 23:   DarkGreen
        (47  << 16) +   (107  << 8) +   85,     # 24:   DarkOliveGreen
        (87  << 16) +   (139  << 8) +   46,     # 25:   SeaGreen
        (34  << 16) +   (139  << 8) +   34,     # 26:   ForestGreen
        (35  << 16) +   (142  << 8) +   107,    # 27:   OliveDrab
        (92  << 16) +   (92   << 8) +   205,    # 28:   IndianRed
        (19  << 16) +   (69   << 8) +   139,    # 29:   SaddleBrown
        (45  << 16) +   (82   << 8) +   160,    # 30:   sienna
        (34  << 16) +   (34   << 8) +   178,    # 31:   firebrick
        (42  << 16) +   (42   << 8) +   165,    # 32:   brown
        (0   << 16) +   (69   << 8) +   255,    # 33:   OrangeRed
        (0   << 16) +   (0    << 8) +   255,    # 34:   red
        (147 << 16) +   (20   << 8) +   255,    # 35:   DeepPink
        (96  << 16) +   (48   << 8) +   176,    # 36:   maroon
        (133 << 16) +   (21   << 8) +   199,    # 37:   MediumVioletRed
        (144 << 16) +   (32   << 8) +   208,    # 38:   VioletRed
        (255 << 16) +   (0    << 8) +   255,    # 39:   magenta
        (204 << 16) +   (50   << 8) +   153,    # 40:   DarkOrchid
        (250 << 16) +   (250  << 8) +   255,    # 41:   snow1
        (233 << 16) +   (233  << 8) +   238,    # 42:   snow2
        (219 << 16) +   (239  << 8) +   255,    # 43:   AntiqueWhite1
        (205 << 16) +   (250  << 8) +   255,    # 44:   LemonChiffon1
        (240 << 16) +   (255  << 8) +   255,    # 45:   ivory1
        (240 << 16) +   (255  << 8) +   240,    # 46:   honeydew1
        (245 << 16) +   (240  << 8) +   255,    # 47:   LavenderBlush1
        (229 << 16) +   (224  << 8) +   238,    # 48:   LavenderBlush2
        (225 << 16) +   (228  << 8) +   255,    # 49:   MistyRose1
        (210 << 16) +   (213  << 8) +   238,    # 50:   MistyRose2
        (255 << 16) +   (255  << 8) +   240,    # 51:   azure1
        (238 << 16) +   (238  << 8) +   224,    # 52:   azure2
        (238 << 16) +   (134  << 8) +   28,     # 53:   DodgerBlue2
        (255 << 16) +   (184  << 8) +   99,     # 54:   SteelBlue1
        (255 << 16) +   (191  << 8) +   0,      # 55:   DeepSkyBlue1
        (255 << 16) +   (206  << 8) +   135,    # 56:   SkyBlue1
        (255 << 16) +   (226  << 8) +   176,    # 57:   LightSkyBlue1
        (238 << 16) +   (211  << 8) +   185,    # 58:   SlateGray2
        (255 << 16) +   (225  << 8) +   202,    # 59:   LightSteelBlue1
        (255 << 16) +   (239  << 8) +   191,    # 60:   LightBlue1
        (255 << 16) +   (255  << 8) +   224,    # 61:   LightCyan1
        (255 << 16) +   (255  << 8) +   187,    # 62:   PaleTurquoise1
        (160 << 16) +   (158  << 8) +   95,     # 63:   CadetBlue
        (238 << 16) +   (229  << 8) +   142,    # 64:   CadetBlue2
        (255 << 16) +   (245  << 8) +   0,      # 65:   turquoise1
        (255 << 16) +   (255  << 8) +   0,      # 66:   cyan1
        (255 << 16) +   (255  << 8) +   151,    # 67:   DarkSlateGray1
        (198 << 16) +   (238  << 8) +   118,    # 68:   aquamarine2
        (193 << 16) +   (255  << 8) +   193,    # 69:   DarkSeaGreen1
        (180 << 16) +   (238  << 8) +   180,    # 70:   DarkSeaGreen2
        (159 << 16) +   (255  << 8) +   84,     # 71:   SeaGreen1
        (154 << 16) +   (255  << 8) +   154,    # 72:   PaleGreen1
        (127 << 16) +   (255  << 8) +   0,      # 73:   SpringGreen1
        (0   << 16) +   (255  << 8) +   0,      # 74:   green1
        (0   << 16) +   (255  << 8) +   127,    # 75:   chartreuse1
        (62  << 16) +   (255  << 8) +   192,    # 76:   OliveDrab1
        (112 << 16) +   (255  << 8) +   202,    # 77:   DarkOliveGreen1
        (143 << 16) +   (246  << 8) +   255,    # 78:   khaki1
        (139 << 16) +   (236  << 8) +   255,    # 79:   LightGoldenrod1
        (0   << 16) +   (255  << 8) +   255,    # 80:   yellow1
        (0   << 16) +   (215  << 8) +   255,    # 81:   gold1
        (37  << 16) +   (193  << 8) +   255,    # 82:   goldenrod1
        (66  << 16) +   (121  << 8) +   238,    # 83:   sienna2
        (174 << 16) +   (216  << 8) +   238,    # 84:   wheat2
        (36  << 16) +   (127  << 8) +   255,    # 85:   chocolate1
        (64  << 16) +   (64   << 8) +   255,    # 86:   brown1
        (122 << 16) +   (160  << 8) +   255,    # 87:   LightSalmon1
        (0   << 16) +   (165  << 8) +   255,    # 88:   orange1
        (80  << 16) +   (106  << 8) +   238,    # 89:   coral2
        (0   << 16) +   (0    << 8) +   238,    # 90:   red2
        (147 << 16) +   (20   << 8) +   255,    # 91:   DeepPink1
        (180 << 16) +   (110  << 8) +   255,    # 92:   HotPink1
        (197 << 16) +   (181  << 8) +   255,    # 93:   pink1
        (185 << 16) +   (174  << 8) +   255,    # 94:   LightPink1
        (171 << 16) +   (130  << 8) +   255,    # 95:   PaleVioletRed1
        (179 << 16) +   (52   << 8) +   255,    # 96:   maroon1
        (150 << 16) +   (62   << 8) +   255,    # 97:   VioletRed1
        (255 << 16) +   (0    << 8) +   255,    # 98:   magenta1
        (250 << 16) +   (131  << 8) +   255,    # 99:   orchid1
        (255 << 16) +   (187  << 8) +   255,    # 100:  plum1
        (255 << 16) +   (225  << 8) +   255,    # 101:  thistle1
        (133 << 16) +   (133  << 8) +   133,    # 102:  gray52
        (158 << 16) +   (158  << 8) +   158,    # 103:  gray62
        (184 << 16) +   (184  << 8) +   184,    # 104:  gray72
        (209 << 16) +   (209  << 8) +   209,    # 105:  gray82
]

_default_ads_layers = [
    Layer(
        name='default',
        gds=0,
        color=_default_colors_bgr[8],
        pattern=_default_patterns[0],
        style=LineStyle.Solid,
        visible=False
    ),
    Layer(
        name='silk_screen',
        gds=253,
        color=_default_colors_bgr[8],
        pattern=_default_patterns[19],
        style=LineStyle.Solid,
        visible=True
    ),
    Layer(
        name='silk_screen2',
        gds=254,
        color=_default_colors_bgr[80],
        pattern=_default_patterns[19],
        style=LineStyle.Solid,
        visible=True
    )
]