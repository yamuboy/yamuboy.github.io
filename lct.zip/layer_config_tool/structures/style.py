from enum import Enum

# based off of AWR dash-style indicies since they are more restrictive
class LineStyle(Enum):
    NoLine      = 0
    Solid       = 1
    Dashed      = 2
    Dotted      = 3
    DashDot     = 4
    #DashDotDot  = 5    #this seems to just draw a solid line in AWRv12, so ignoring it...

_linestyle_names = ['No Outline', 'Solid', 'Dashed', 'Dotted', 'DashDot']