from __future__ import print_function

try:
    from cStringIO import StringIO
except ImportError:
    from io import StringIO
import layer_config_tool.structures.defaults as defaults
import layer_config_tool.structures.material as material
import layer_config_tool.structures.substrate as substrate
import os
import re
import wx

from layer_config_tool.structures.layer import Layer
from layer_config_tool.structures.style import LineStyle
from layer_config_tool.structures.substrate import Substrate

def get_wx_penstyle(style=LineStyle.Solid):
    _pen_style_map = [
                        wx.PENSTYLE_TRANSPARENT,
                        wx.PENSTYLE_SOLID,
                        wx.PENSTYLE_SHORT_DASH,
                        wx.PENSTYLE_DOT,
                        wx.PENSTYLE_DOT_DASH
                    ]
    if style is None:
        return wx.PENSTYLE_TRANSPARENT
    elif isinstance(style, LineStyle):
        return _pen_style_map[style.value]
    elif isinstance(style, int):
        return _pen_style_map[(style)%4]
    else:
        raise ValueError

def get_ads_linestyle(style=LineStyle.Solid):
    "Returns the numerical index of the ADS linestyle that corresponds to the given LineStyle/int"
    _ads_linestyle_map =    [   0,  # ADS solid linestyle used for "No Line"
                                0,  # ADS solid linestyle
                                5,  # ADS long dash linestyle used for "Dashed"
                                3,  # ADS short dash linestyle used for "Dot"
                                4   # ADS short dash dot linestyle used for "DashDot"
                            ]

    if isinstance(style, LineStyle):
        return _ads_linestyle_map[style.value]
    elif isinstance(style, int):
        return _ads_linestyle_map[(style)%4]
    else:
        raise ValueError

def get_ads_linestyle_string(style=LineStyle.Solid):
    "Returns the string for ADS linestyle that corresponds to the given LineStyle/int"
    _ads_linestyle_string_map = [   'Solid',        # ADS solid linestyle used for "No Line"
                                    'Solid',        # ADS solid linestyle
                                    'Long Dash',    # ADS long dash linestyle used for "Dashed"
                                    'Short Dash',   # ADS short dash linestyle used for "Dot"
                                    'Long Dot Dash' # ADS short dash dot linestyle used for "DashDot"
                                ]
    if isinstance(style, LineStyle):
        return _ads_linestyle_string_map[style.value]
    elif isinstance(style, int):
        return _ads_linestyle_string_map[(style)%4]
    else:
        raise ValueError

def get_awr_linestyle(style=LineStyle.Solid):
    "Returns the numerical index of the AWR linestyle that corresponds to the given LineStyle/int"
    _awr_linestyle_map =    [   0,  # AWR solid linestyle used for "No Line"
                                0,  # AWR solid linestyle
                                1,  # AWR dashed linestyle
                                2,  # AWR dot linestyle
                                3   # AWR dash dot linestyle
                            ]

    if isinstance(style, LineStyle):
        return _awr_linestyle_map[style.value]
    elif isinstance(style, int):
        return _awr_linestyle_map[(style)%4]
    else:
        raise ValueError

def get_ads_layer_number(num):
    "Return a valid ADS layer number for a given integer input that avoids conflicts with reserved layer numbers (200-255)"
    if num in range(200, 256):
        return num + 56
    else:
        return num

def get_red_from_BGR(color):
    """
    Returns the red component of a packed 24-bit BGR color integer
    """
    return color & 0x0000FF

def get_green_from_BGR(color):
    """
    Returns the green component of a packed 24-bit BGR color integer
    """
    return (color & 0x00FF00) >> 8

def get_blue_from_BGR(color):
    """
    Returns the blue component of a packed 24-bit BGR color integer
    """
    return (color & 0xFF0000) >> 16

def get_red_from_RGB(color):
    """
    Returns the red component of a packed 24-bit RGB color integer
    """
    return (color & 0xFF0000) >> 16

def get_green_from_RGB(color):
    """
    Returns the green component of a packed 24-bit RGB color integer
    """
    return (color & 0x00FF00) >> 8

def get_blue_from_RGB(color):
    """
    Returns the blue component of a packed 24-bit RGB color integer
    """
    return color & 0x0000FF

def convert_BGR_to_RGB(color):
    """Converts a 24-bit packed BGR integer into a 24-bit packed RGB integer"""
    red = get_red_from_BGR(color)
    green = get_green_from_BGR(color)
    blue = get_blue_from_BGR(color)

    return (red << 16) + (green<<8) + blue

def convert_RGB_to_BGR(color):
    """Converts a 24-bit packed RGB integer into a 24-bit packed BGR integer"""
    red = get_red_from_BGR(color)
    green = get_green_from_BGR(color)
    blue = get_blue_from_BGR(color)

    return (blue << 16) + (green<<8) + red

def convert_RGB_to_hex(color):
    """Returns the hex code string of a 24-bit packed RGB integer"""
    red = get_red_from_RGB(color)
    green = get_green_from_RGB(color)
    blue = get_blue_from_RGB(color)

    return '%02x%02x%02x'%(red, green, blue)

def convert_BGR_to_hex(color):
    """Returns the hex code string of a 24-bit packed BGR integer"""
    red = get_red_from_BGR(color)
    green = get_green_from_BGR(color)
    blue = get_blue_from_BGR(color)

    return '%02x%02x%02x'%(red, green, blue)

def stackup_color_to_rgb(color):
    """Returns (hatch style index, blue, green, red)"""
    hatch = (color>>24)&(255)
    blue = (color>>16)&(255)
    green = (color>>8)&(255)
    red = color&(255)
    return (hatch, blue, green, red)

def stackup_rgb_to_color(hatch, blue, green, red):
    """Returns decimal combination of hatch style index and RGB color"""
    return (hatch<<24) + (blue<<16) + (green<<8) + red

def lpf_color_to_rgb(color):
    """Returns (blue, green, red)"""
    return stackup_color_to_rgb(color)[1:]

def lpf_rgb_to_color(blue, green, red):
    """Returns decimal combination of RGB color"""
    return (blue<<16) + (green<<8) + red

def checkNameValidity(str):
    """
    Check whether the input string is a valid process or layer name. Returns True if so, otherwise returns false

    Arguments:
    str - String input of the desired process name to check
    """

    # check string for any non-alphanumeric + underscore characters
    if re.search(defaults._re_name_invalid_chars, str) is None:
        return True
    else:
        return False

def validateControls(controls, valid=True):
    "Mark all the controls as valid or invalid"
    if isinstance(controls, list):
        for control in controls:
            if valid:
                control.SetBackgroundColour(wx.NullColour)
            else:
                control.SetBackgroundColour(wx.Colour(255, 128, 128))
            control.Refresh()
    elif isinstance(controls, wx.Control):
        if valid:
            controls.SetBackgroundColour(wx.NullColour)
        else:
            controls.SetBackgroundColour(wx.Colour(255, 128, 128))
        controls.Refresh()

def write_awr_substrates(filepath, lpfname, substrates):
    """
    Writes a complete XML library with STACKUP elements to the given filepath with the given list of Substrate objects. Requires the filename of the
    .lpf file with the corresponding EM mappings
    """

    # create directory if necessary
    if not os.path.exists(os.path.dirname(filepath)):
        os.makedirs(os.path.dirname(filepath))

    with open(filepath, 'w') as fp:
        fp.write(generate_awr_substrates(lpfname, substrates))

def generate_awr_substrates(lpfname, substrates):
    """
    Generates a complete AWR elements browser XML file for the given AXIEM substrates and returns it in a single string
    """

    outStr = StringIO()

    print('<?xml version="1.0"?>', file=outStr)
    print('<XML_COMPONENT_DATA>', file=outStr)
    print('', file=outStr)

    indent = 4
    for sub in substrates:
        indentStr = ' '*indent
        print(indentStr + '<COMPONENT Name="{}_AXIEM">'.format(sub.Name), file=outStr)

        indentStr = ' '*2*indent
        print(indentStr + '<MODEL>STACKUP</MODEL>', file=outStr)
        print(indentStr + '<DESC>{} AXIEM EM Stackup</DESC>'.format(sub.Name), file=outStr)
        print(indentStr + '<HELP></HELP>', file=outStr)
        print(indentStr + '<CELL></CELL>', file=outStr)
        print(indentStr + '<DATA DataType="awrmodel" Inline="yes">', file=outStr)

        indentStr = ' '*3*indent
        print(indentStr + '<PARAM Name="Name">{}_AXIEM</PARAM>'.format(sub.Name), file=outStr)
        print(indentStr, file=outStr)

        # offset complete material list by 4 to account for default materials built into AWR STACKUP component
        # ignore any "Air" material defined in the substrate and use the default AWR one instead
        sub_mats = [x for x in sub.AllMaterials if x.Name != 'Air']
        all_mats = [defaults._default_materials[0], None, None, None] + sub_mats
        all_mat_names = [defaults._default_materials[0].Name, None, None, None] + [x.Name for x in sub_mats]

        dlayers = list(reversed(sub.DielectricLayers))
        dlayer_mats = [x['Material'].Name for x in dlayers]
        dlayer_mat_lengths = [len(x) for x in dlayer_mats]

        # print dielectric layers section
        print(indentStr + '<!-- Dielectric Layer Definitions -->', file=outStr)
        idxStr      = '0          , '
        matNameStr  = 'Air        , '
        dieTStr     = '1e-06      , '
        dieIndStr   = '0          , '
        dScaleStr   = '1          , '
        blankStr    = '           , '
        for idx, length in enumerate(dlayer_mat_lengths):
            idxStr += '{:d}'.format(idx + 1).ljust(length + 8) + ', '
            matNameStr += '{}'.format(dlayer_mats[idx]).ljust(length + 8) + ', '
            dieTStr += '{:g}'.format(dlayers[idx]['Thickness']).ljust(length + 8) + ', '
            dieIndStr += '{:d}'.format(all_mat_names.index(dlayer_mats[idx])).ljust(length + 8) + ', '
            dScaleStr += '1'.ljust(length + 8) + ', '
            blankStr += ''.ljust(length + 8) + ', '

        print(indentStr + '<!-- Layer:'.ljust(28) + idxStr[:-2] + '-->', file=outStr)
        print(indentStr + '<!--'.ljust(28) + matNameStr[:-2] + '-->', file=outStr)
        print(indentStr + '<!-- Thickness'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="DieT">       { ' + dieTStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Material Index'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="DieInd">     { ' + dieIndStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Drawing Z-Scale'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="DScale">     { ' + dScaleStr[:-2] + '} </PARAM>', file=outStr)
        print('', file=outStr)
        print('', file=outStr)


        # print top/bot substrate cover section
        if sub.TopCover == substrate.CoverType.OPEN:
            topCoverStr = '2'
        elif sub.TopCover == substrate.CoverType.PEC:
            topCoverStr = '1'

        if sub.BotCover == substrate.CoverType.OPEN:
            botCoverStr = '2'
        elif sub.BotCover == substrate.CoverType.PEC:
            botCoverStr = '1'
        print(indentStr + '<!-- Ground Planes -->', file=outStr)
        print(indentStr + '<!-- Layer index for location in stackup -->', file=outStr)
        print(indentStr + '<PARAM Name="GndInd">     { ' + str(0) + ', ' + str(len(dlayers) + 1).ljust(4) + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Material Index -->', file=outStr)
        print(indentStr + '<PARAM Name="GndCond">    { ' + topCoverStr + ', ' + botCoverStr.ljust(4) + '} </PARAM>', file=outStr)
        print('', file=outStr)
        print('', file=outStr)

        # print metal layers section
        # TODO: implement sheet/thick metal model switch
        mlayers = sub.MappedLayers.items()
        mlayer_names = [x[0] for x in mlayers]
        mlayer_mats = [x[1]['Material'] for x in mlayers]
        mlayer_name_lengths = [len(x) for x in mlayer_names]
        print(indentStr + '<!-- Metal Layer Definitions -->', file=outStr)

        trcNameStr =    '"Perfect Conductor"      , '
        thicknessStr =  '0                        , '
        widthStr =      '40                       , '
        minWidthStr =   '0                        , '
        matIndStr =     '1                        , '
        tScaleStr =     '1                        , '
        etchAngStr =    '0                        , '
        surfStr =       '0                        , '
        blankStr =      '                         , '
        for idx, length in enumerate(mlayer_name_lengths):
            mat = mlayer_mats[idx]
            trcNameStr += '"{}"'.format(mlayer_names[idx]).ljust(length + 8) + ', '

            if mat.CondType == material.ConductorType.SHEET:
                thicknessStr += '0'.ljust(length + 8) + ', '
            elif mat.CondType == material.ConductorType.BULK:
                thicknessStr += '{:g}'.format(mlayers[idx][1]['Thickness']).ljust(length + 8) + ', '

            widthStr += '40'.ljust(length + 8) + ', '
            minWidthStr += '0'.ljust(length + 8) + ', '
            matIndStr += '{:d}'.format(all_mat_names.index(mat.Name)).ljust(length + 8) + ', '
            tScaleStr += '1'.ljust(length + 8) + ', '
            etchAngStr += '0'.ljust(length + 8) + ', '
            surfStr += '0'.ljust(length + 8) + ', '
            blankStr += ''.ljust(length + 8) + ', '

        print(indentStr + '<!-- Layer Name -->', file=outStr)
        print(indentStr + '<PARAM Name="TrcName">    { ' + trcNameStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Layer Thickness'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="T">          { ' + thicknessStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Default Widths'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="W">          { ' + widthStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Minimum Widths'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="MinW">       { ' + minWidthStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Material Index'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="MatInd">     { ' + matIndStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Drawing Z-Scale'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="TScale">     { ' + tScaleStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Etch Angle'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="EtchAng">    { ' + etchAngStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Surface Roughness'.ljust(28) + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="Surf">       { ' + surfStr[:-2] + '} </PARAM>', file=outStr)
        print('', file=outStr)
        print('', file=outStr)

        # print line type section
        print(indentStr + '<!-- Line Type Definitions -->', file=outStr)
        print(indentStr + '<PARAM Name="LTName">     {""}   </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="LayName">     ""    </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="LayInd">            </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="LtGInd">            </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="LtUInd">            </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TrcInd">            </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TrcUInd">           </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TrcGInd">           </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="LTFlags">    {""}   </PARAM>', file=outStr)
        print('', file=outStr)

        # print via section
        print(indentStr + '<PARAM Name="ViaCell">     ""    </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="VPName">      ""    </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="ViaLay">     {0}    </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="VProp">       ""    </PARAM>', file=outStr)
        print('', file=outStr)

        # print material definitions section
        print(indentStr + '<!-- Material Definitions -->', file=outStr)
        print(indentStr + '<!-- Material Types - 0 = conductor, 1 = dielectric, 2 = boundary, 3 = PEC, 4 = PMC, 5 = Approx Open, 6 = Inf WG -->', file=outStr)
        print(indentStr + '<!-- Color and Style Format - ((hatch style << 24) + (blue << 16) + (green << 8) + red) -->', file=outStr)
        print(indentStr + '<!-- Hatch styles - 00 = No Fill', file=outStr)
        print(indentStr + '                    01 = Solid Fill             02 = Small Dots               03 = Dense Small Dots         04 = Sparse Large Dots                        05 = Checkers', file=outStr)
        print(indentStr + '                    06 = Sparse Small Dots      07 = Solid Squares            08 = Dense Backslashes        09 = Dense Forwardslashes                     10 = Dense Horizontal Lines', file=outStr)
        print(indentStr + '                    11 = Thick Horizontal Lines 12 = Dense Vertical Lines     13 = Thick Vertical Lines     14 = Thin Horizontal Lines                    15 = Thin Vertical Lines', file=outStr)
        print(indentStr + '                    16 = Sparse Large Dots      17 = Brick                    18 = Hollow Squares           19 = Diamonds (alternating dense/sparse rows) 20 = Sparse Forwardslashes', file=outStr)
        print(indentStr + '                    21 = Sparse Backslashes     22 = Sparse Horizontal Lines  23 = Sparse Vertical Lines    24 = Grid                                     25 = Crosshatch', file=outStr)
        print(indentStr + '-->', file=outStr)

        idxStr      = '0           1                     2                   3           '
        matNameStr  = '"Air"     , "Perfect Conductor" , "Approx Open"     , "Inf WG"  , '
        matTypeStr  = '1         , 3                   , 5                 , 6         , '
        colorStr    = '16711680  , 37781888            , 255               , 65280     , '
        erZStr      = '1         , 1                   , 1                 , 1         , '
        erXStr      = '1         , 1                   , 1                 , 1         , '
        erYStr      = '1         , 1                   , 1                 , 1         , '
        urZStr      = '1         , 1                   , 1                 , 1         , '
        urXStr      = '1         , 1                   , 1                 , 1         , '
        urYStr      = '1         , 1                   , 1                 , 1         , '
        sigmaZStr   = '0         , 100.0e18            , 2.6525198938992e6 , 0         , '
        sigmaXStr   = '0         , 100.0e18            , 2.6525198938992e6 , 0         , '
        sigmaYStr   = '0         , 100.0e18            , 2.6525198938992e6 , 0         , '
        tanDZStr    = '0         , 0                   , 0                 , 0         , '
        tanDXStr    = '0         , 0                   , 0                 , 0         , '
        tanDYStr    = '0         , 0                   , 0                 , 0         , '
        tanMZStr    = '0         , 0                   , 0                 , 0         , '
        tanMXStr    = '0         , 0                   , 0                 , 0         , '
        tanMYStr    = '0         , 0                   , 0                 , 0         , '
        erZEQStr    = '""        , ""                  , ""                , ""        , '
        erXEQStr    = '""        , ""                  , ""                , ""        , '
        erYEQStr    = '""        , ""                  , ""                , ""        , '
        urZEQStr    = '""        , ""                  , ""                , ""        , '
        urXEQStr    = '""        , ""                  , ""                , ""        , '
        urYEQStr    = '""        , ""                  , ""                , ""        , '
        tanDEQZStr  = '""        , ""                  , ""                , ""        , '
        tanDEQXStr  = '""        , ""                  , ""                , ""        , '
        tanDEQYStr  = '""        , ""                  , ""                , ""        , '
        tanMEQZStr  = '""        , ""                  , ""                , ""        , '
        tanMEQXStr  = '""        , ""                  , ""                , ""        , '
        tanMEQYStr  = '""        , ""                  , ""                , ""        , '
        resSqStr    = '0         , 0                   , 377               , 0         , '
        resFStr     = '0         , 0                   , 0                 , 0         , '
        reactStr    = '0         , 0                   , 0                 , 0         , '
        resSqEQStr  = '""        , ""                  , ""                , ""        , '
        reactEQStr  = '""        , ""                  , ""                , ""        , '
        blankStr    = '          ,                     ,                   ,           , '

        all_mats_names_lengths = [len(x) for x in all_mat_names[4:]]

        for i, length in enumerate(all_mats_names_lengths):
            idx = i + 4
            mat = all_mats[idx]
            idxStr += '{:d}'.format(idx).ljust(length + 8) + ', '
            matNameStr += '"{}"'.format(all_mat_names[idx]).ljust(length + 8) + ', '

            if mat.MatType in [material.MaterialType.DIELECTRIC, material.MaterialType.SEMICONDUCTOR]:
                mtype = '1'
                color = stackup_rgb_to_color(1, defaults._dielectric_color[2], defaults._dielectric_color[1], defaults._dielectric_color[0])
            elif mat.MatType == material.MaterialType.CONDUCTOR:
                color = stackup_rgb_to_color(1, defaults._layer_color[2], defaults._layer_color[1], defaults._layer_color[0])
                if mat.CondType == material.ConductorType.BULK:
                    mtype= '0'
                elif mat.CondType == material.ConductorType.SHEET:
                    mtype = '2'
            matTypeStr += mtype.ljust(length + 8) + ', '
            colorStr += '{:d}'.format(color).ljust(length + 8) + ', '

            if mat.Epsilon:
                # isotropic
                if isinstance(mat.Epsilon, float):
                    erZStr += '{:g}'.format(mat.Epsilon).ljust(length + 8) + ', '
                    erXStr += '{:g}'.format(mat.Epsilon).ljust(length + 8) + ', '
                    erYStr += '{:g}'.format(mat.Epsilon).ljust(length + 8) + ', '
                # anisotropic
                elif isinstance(mat.Epsilon, tuple):
                    erZStr += '{:g}'.format(mat.Epsilon[2]).ljust(length + 8) + ', '
                    erXStr += '{:g}'.format(mat.Epsilon[0]).ljust(length + 8) + ', '
                    erYStr += '{:g}'.format(mat.Epsilon[1]).ljust(length + 8) + ', '
            else:
                erZStr += '1'.ljust(length + 8) + ', '
                erXStr += '1'.ljust(length + 8) + ', '
                erYStr += '1'.ljust(length + 8) + ', '

            if mat.Mu:
                # isotropic
                if isinstance(mat.Mu, float):
                    urZStr += '{:g}'.format(mat.Mu).ljust(length + 8) + ', '
                    urXStr += '{:g}'.format(mat.Mu).ljust(length + 8) + ', '
                    urYStr += '{:g}'.format(mat.Mu).ljust(length + 8) + ', '
                # anisotropic
                elif isinstance(mat.Mu, tuple):
                    urZStr += '{:g}'.format(mat.Mu[2]).ljust(length + 8) + ', '
                    urXStr += '{:g}'.format(mat.Mu[0]).ljust(length + 8) + ', '
                    urYStr += '{:g}'.format(mat.Mu[1]).ljust(length + 8) + ', '
            else:
                urZStr += '1'.ljust(length + 8) + ', '
                urXStr += '1'.ljust(length + 8) + ', '
                urYStr += '1'.ljust(length + 8) + ', '

            if mat.CondType or mat.MatType == material.MaterialType.SEMICONDUCTOR:
                # boundary definitions
                if mat.CondType == material.ConductorType.SHEET:
                    sigmaZStr += '100.0e18'.ljust(length + 8) + ', '
                    sigmaXStr += '100.0e18'.ljust(length + 8) + ', '
                    sigmaYStr += '100.0e18'.ljust(length + 8) + ', '
                # conductor definitions
                elif mat.CondType == material.ConductorType.BULK or mat.MatType == material.MaterialType.SEMICONDUCTOR:
                    if isinstance(mat.CondReal, float):
                        sigmaZStr += '{:g}'.format(mat.CondReal).ljust(length + 8) + ', '
                        sigmaXStr += '{:g}'.format(mat.CondReal).ljust(length + 8) + ', '
                        sigmaYStr += '{:g}'.format(mat.CondReal).ljust(length + 8) + ', '
                    elif isinstance(mat.CondReal, tuple):
                        sigmaZStr += '{:g}'.format(mat.CondReal[2]).ljust(length + 8) + ', '
                        sigmaXStr += '{:g}'.format(mat.CondReal[0]).ljust(length + 8) + ', '
                        sigmaYStr += '{:g}'.format(mat.CondReal[1]).ljust(length + 8) + ', '
            else:
                sigmaZStr += '0'.ljust(length + 8) + ', '
                sigmaXStr += '0'.ljust(length + 8) + ', '
                sigmaYStr += '0'.ljust(length + 8) + ', '

            if mat.TanD:
                # isotropic
                if isinstance(mat.TanD, float):
                    tanDZStr += '{:g}'.format(mat.TanD).ljust(length + 8) + ', '
                    tanDXStr += '{:g}'.format(mat.TanD).ljust(length + 8) + ', '
                    tanDYStr += '{:g}'.format(mat.TanD).ljust(length + 8) + ', '
                # anisotropic
                elif isinstance(mat.TanD, tuple):
                    tanDZStr += '{:g}'.format(mat.TanD[2]).ljust(length + 8) + ', '
                    tanDXStr += '{:g}'.format(mat.TanD[0]).ljust(length + 8) + ', '
                    tanDYStr += '{:g}'.format(mat.TanD[1]).ljust(length + 8) + ', '
            else:
                tanDZStr += '0'.ljust(length + 8) + ', '
                tanDXStr += '0'.ljust(length + 8) + ', '
                tanDYStr += '0'.ljust(length + 8) + ', '

            tanMZStr += '0'.ljust(length + 8) + ', '
            tanMXStr += '0'.ljust(length + 8) + ', '
            tanMYStr += '0'.ljust(length + 8) + ', '
            erZEQStr += '""'.ljust(length + 8) + ', '
            erXEQStr += '""'.ljust(length + 8) + ', '
            erYEQStr += '""'.ljust(length + 8) + ', '
            urZEQStr += '""'.ljust(length + 8) + ', '
            urXEQStr += '""'.ljust(length + 8) + ', '
            urYEQStr += '""'.ljust(length + 8) + ', '
            tanDEQZStr += '""'.ljust(length + 8) + ', '
            tanDEQXStr += '""'.ljust(length + 8) + ', '
            tanDEQYStr += '""'.ljust(length + 8) + ', '
            tanMEQZStr += '""'.ljust(length + 8) + ', '
            tanMEQXStr += '""'.ljust(length + 8) + ', '
            tanMEQYStr += '""'.ljust(length + 8) + ', '

            if mat.CondType and mat.CondType == material.ConductorType.SHEET:
                resSqStr += '{:g}'.format(mat.CondReal).ljust(length + 8) + ', '
                resFStr += '{:g}'.format(mat.Rrf).ljust(length + 8) + ', '
                reactStr += '{:g}'.format(mat.CondImag).ljust(length + 8) + ', '
            else:
                resSqStr += '0'.ljust(length + 8) + ', '
                resFStr += '0'.ljust(length + 8) + ', '
                reactStr += '0'.ljust(length + 8) + ', '

            resSqEQStr += '""'.ljust(length + 8) + ', '
            reactEQStr += '""'.ljust(length + 8) + ', '
            blankStr += ''.ljust(length + 8) + ', '

        print(indentStr + '<!-- Name           Index:    ' + idxStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="MatName">      { ' + matNameStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Type                     ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="MatType">      { ' + matTypeStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Color and style          ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="Color">        { ' + colorStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Relative permittivity    ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="ErZ">          { ' + erZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="ErX">          { ' + erXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="ErY">          { ' + erYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Relative permeability    ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="UrZ">          { ' + urZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="UrX">          { ' + urXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="UrY">          { ' + urYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Conductivity             ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="SigmaZ">       { ' + sigmaZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="SigmaX">       { ' + sigmaXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="SigmaY">       { ' + sigmaYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Electric Loss Tangent    ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="TanDZ">        { ' + tanDZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanDX">        { ' + tanDXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanDY">        { ' + tanDYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Magnetic Loss Tangent    ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="TanMZ">        { ' + tanMZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanMX">        { ' + tanMXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanMY">        { ' + tanMYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Eq. Defined Dependences  ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="ErZEQ">        { ' + erZEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="ErXEQ">        { ' + erXEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="ErYEQ">        { ' + erYEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="UrZEQ">        { ' + urZEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="UrXEQ">        { ' + urXEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="UrYEQ">        { ' + urYEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanDZEQ">      { ' + tanDEQZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanDXEQ">      { ' + tanDEQXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanDYEQ">      { ' + tanDEQYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanMZEQ">      { ' + tanMEQZStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanMXEQ">      { ' + tanMEQXStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="TanMYEQ">      { ' + tanMEQYStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!--  DC Resistance Boundary  ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<!--  Condition (Ohms/sq)     ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="ResSq">        { ' + resSqStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!--  RF Resistance Boundary  ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<!--  Condition (Ohms/(sq*sqrt(f)))' + blankStr[5:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="ResF">         { ' + resFStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Surface Reactance (j*Ohms/sq)' + blankStr[4:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="React">        { ' + reactStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<!-- Eq. Defined dependences  ' + blankStr[:-2] + '-->', file=outStr)
        print(indentStr + '<PARAM Name="ResSqEQ">      { ' + resSqEQStr[:-2] + '} </PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="ReactEQ">      { ' + reactEQStr[:-2] + '} </PARAM>', file=outStr)
        print('', file=outStr)
        print('', file=outStr)

        print(indentStr + '<PARAM Name="LpfName">      {{"{}.lpf"}}</PARAM>'.format(lpfname), file=outStr)
        print(indentStr + '<PARAM Name="emMapName">    {{"{}"}}</PARAM>'.format(sub.Name), file=outStr)
        print(indentStr + '<PARAM Name="SppRules">     ""</PARAM>', file=outStr)
        print(indentStr + '<PARAM Name="EnableRules">  0</PARAM>', file=outStr)

        indentStr = ' '*2*indent
        print(indentStr + '</DATA>', file=outStr)

        indentStr = ' '*indent
        print(indentStr + '</COMPONENT>', file=outStr)
        print('', file=outStr)

    print('</XML_COMPONENT_DATA>', file=outStr)

    return outStr.getvalue()

def generate_awr_lpf(layers, substrates=None):
    """
    Generates a complete AWR LPF file and returns it in a single string
    """
    # store all unqiue patterns from layer stack
    patterns = []
    for layer in layers:
        if not layer.pattern in patterns and layer.pattern is not None:
            patterns.append(layer.pattern)

    outStr = StringIO()

    print("$PROCESS_SETUP_BEGIN\n", file=outStr)

    # write default units
    units = {}
    write_awr_lpf_default_units(outStr, **units)

    print('', file=outStr)

    # write database units
    write_awr_lpf_database_units(outStr)

    print('', file=outStr)

    # write misc lines (unused)
    print(  '    !--- Register drawing utility function used for drawing airbridges ------',    file=outStr)
    print(  '    $BRIDGE_DRAW_BEGIN AWR_MMIC $BRIDGE_DRAW_END\n',                               file=outStr)
    print(  '    !--- Register cell to be used by default for route vias  ------',              file=outStr)
    print(  '    $ROUTE_VIA_CELL_BEGIN MMICROUTEVIA $ROUTE_VIA_CELL_END\n',                     file=outStr)
    print(  '    !--- DRC Rule deck (path relative to lpf file) ------',                        file=outStr)
    print(  '    $DRC_RULES_FILE_BEGIN "" $DRC_RULES_FILE_END\n',                               file=outStr)
    print(  '    !--- DRC engine: AWR, CALIBRE, ASSURA, CIRANOVA, or POLYTEDA ------',          file=outStr)
    print(  '    $DRC_ENGINE_BEGIN "AWR" $DRC_ENGINE_END\n',                                    file=outStr)

    # write connectivity rules
    write_awr_connectivity_rules(outStr, layers)

    print('', file=outStr)

    # write default values
    print(  '    !--- Default font used for layout ------',                                         file=outStr)
    print(  '    $DEFAULT_FONT_BEGIN "Arial"     20000    0    0     $DEFAULT_FONT_END\n',          file=outStr)
    print(  '    $PROPERTY_VALUES_BEGIN',                                                           file=outStr)
    print(  '    $PROPERTY_VALUES_END\n',                                                           file=outStr)
    print(  '    $DEFAULT_VALUES_BEGIN',                                                            file=outStr)
    print(  '        W        20      u',                                                           file=outStr)
    print(  '        L        40      u',                                                           file=outStr)
    print(  '        H        50      u',                                                           file=outStr)
    print(  '        T        2       u',                                                           file=outStr)
    print(  '        Er       11.6',                                                                file=outStr)
    print(  '        Rho      1',                                                                   file=outStr)
    print(  '        Tand     0',                                                                   file=outStr)
    print(  '        C        1       p',                                                           file=outStr)
    print(  '        Li       1       n',                                                           file=outStr)
    print(  '        Rad      20      u',                                                           file=outStr)
    print(  '        M        0.6',                                                                 file=outStr)
    print(  '        Cs       5       u',                                                           file=outStr)
    print(  '        Extn     200     u',                                                           file=outStr)
    print(  '    $DEFAULT_VALUES_END',                                                              file=outStr)

    print('\n$PROCESS_SETUP_END\n', file=outStr)

    # write layer setup heading
    print('!-------------- Drawing Layer Setup Defined Below ------------------------------',               file=outStr)
    print('!-----  Color Format    -    (Blue << 16) + (Green << 8) + Red (all 8-bit colors, i.e. 0-255)',  file=outStr)
    print('!-----', file=outStr)
    print('!-----  Hatch Styles    -   00 = No Fill',                                                                                                                                                       file=outStr)
    print('!-----                      01 = Solid Fill             02 = Small Dots               03 = Dense Small Dots         04 = Sparse Large Dots                        05 = Checkers',                file=outStr)
    print('!-----                      06 = Sparse Small Dots      07 = Solid Squares            08 = Dense Backslashes        09 = Dense Forwardslashes                     10 = Dense Horizontal Lines',  file=outStr)
    print('!-----                      11 = Thick Horizontal Lines 12 = Dense Vertical Lines     13 = Thick Vertical Lines     14 = Thin Horizontal Lines                    15 = Thin Vertical Lines',     file=outStr)
    print('!-----                      16 = Sparse Large Dots      17 = Brick                    18 = Hollow Squares           19 = Diamonds (alternating dense/sparse rows) 20 = Sparse Forwardslashes',   file=outStr)
    print('!-----                      21 = Sparse Backslashes     22 = Sparse Horizontal Lines  23 = Sparse Vertical Lines    24 = Grid                                     25 = Crosshatch',              file=outStr)
    print('!-----', file=outStr)
    print('!-----  Line Styles     -   0 (Solid)    1 (Dash)           2 (Dot)           3 (Dash Dot)               4 (Dash Dot Dot)',      file=outStr)
    print('!-----                      =====        == == == ==        =  =  =  =        ==  =  ==  =  ==  =        ==  =  =  ==  =  =\n',    file=outStr)

    print('$LAYER_SETUP_BEGIN\n', file=outStr)

    # write draw layers section
    write_awr_layer_setup(outStr, layers, patterns)

    print('\n$LAYERS_CONFIG_BEGIN\n', file=outStr)

    write_awr_layer_config(outStr, 'Default', layers, patterns)

    print('', file=outStr)

    # write EM layer config
    vis_list = []
    clk_list = []
    for i in range(0, len(layers)):
        if layers[i].name[0:3] == 'EM_':
            vis_list.append(True)
        else:
            vis_list.append(False)

        if layers[i].name[0:3] == 'EM_':
            clk_list.append(False)
        else:
            clk_list.append(True)
    write_awr_layer_config(outStr, 'EM', layers, patterns, vis_list, clk_list)

    print('', file=outStr)

    print('', file=outStr)

    print('\n$LAYERS_CONFIG_END\n', file=outStr)

    # write model layers
    write_awr_model_layer(outStr, layers)

    print('', file=outStr)

    # write EM mapping skeleton
    write_awr_em_mapping(outStr, layers, substrates)

    print('', file=outStr)

    # write GDS file export mapping
    write_awr_file_mapping(outStr, layers)

    print('', file=outStr)

    # write miscellanous portions
    print('$DRILL_TABLE_BEGIN', file=outStr)
    print('!drill_name drill_number drill_diameter', file=outStr)
    print('', file=outStr)
    print('$DRILL_TABLE_END', file=outStr)

    print('', file=outStr)

    write_awr_stipple_patterns(outStr, patterns)

    print('', file=outStr)

    print('$LAYER_SETUP_END', file=outStr)
    print('', file=outStr)
    print('$ROUTER_SETUP_BEGIN', file=outStr)
    print('', file=outStr)
    print('$LAYERS_BEGIN', file=outStr)
    print('!--------------------------------- Layer Entry Descriptions -----------------------------------------------------------', file=outStr)
    print('! layer_name <layer_type> <layer_dir> min_width min_spacing route_grid route_grid_offset', file=outStr)
    print('! <layer_type> = other, nwell, pwell, ndiff, pdiff, nimplant, pimplant, poly, cut, metal, non_contact_metal', file=outStr)
    print('!                diffusion, recognition', file=outStr)
    print('! <layer_dir> = none, horiz, vert', file=outStr)
    print('!----------------------------------------------------------------------------------------------------------------------', file=outStr)
    print('$LAYERS_END', file=outStr)
    print('', file=outStr)
    print('$CONNECT_LAYERS_BEGIN', file=outStr)
    print('!--------------------------------- Connect layer -----------------------------------------------------------', file=outStr)
    print('! <connect_type> <layer>', file=outStr)
    print('! <connect_type> = UNKNOWN CAP_TOP_PLATE CAP_BOTTOM_PLATE SPIRAL_EXIT SPIRAL_TURN RESISTOR RESISTOR_2 RESISTOR_3', file=outStr)
    print('!                 VIA_TOP VIA_BOTTOM DISABLED CAP_TOP_PLATE_2 CAP_BOTTOM_PLATE_2 CAP_TOP_PLATE_3 CAP_BOTTOM_PLATE_3 DEVICE', file=outStr)
    print('!                 DEVICE_2 DEVICE_3', file=outStr)
    print('!-----------------------------------------------------------------------------------------------------------', file=outStr)
    print('$CONNECT_LAYERS_END', file=outStr)
    print('', file=outStr)
    print('$ROUTER_SETUP_END', file=outStr)
    print('', file=outStr)
    print('', file=outStr)
    print('!------------- EM Simulation Setup Defined Below ----------------------------', file=outStr)
    print('', file=outStr)
    print('$EM_SETUP_BEGIN', file=outStr)
    print('    $DEFAULT_EM_ENCLOSURE_BEGIN', file=outStr)
    print('    !-----XDIM-----YDIM-----NX-----NY-----', file=outStr)
    print('    !      (m)      (m)', file=outStr)
    print('          0.001    0.001    1000   1000', file=outStr)
    print('    $DEFAULT_EM_ENCLOSURE_END', file=outStr)
    print('', file=outStr)
    print('    $DEFAULT_EM_LAYERS_BEGIN', file=outStr)
    print('    !    Hatch Patterns ------(0)  |||||(1)  \\\\\(2)  /////(3)  +++++(4)  xxxxx(5)', file=outStr)
    print('    !', file=outStr)
    print('    !-T---------Er-----Tand-----Sigma-----Scale-----CondHatch-----ViaHatch-----', file=outStr)
    print('    !(m)                        (S/m)                 (0-5)         (0-5)', file=outStr)
    print('      0.0001    1      0        0         1         5             1', file=outStr)
    print('      2.56e-006 1      0        0         1         4             2', file=outStr)
    print('      1e-007    6.9    0.001    0         1         3             3', file=outStr)
    print('      5e-008    6.9    0.001    0         1         2             4', file=outStr)
    print('      0.0001    12.9   0.001    0         1         1             5', file=outStr)
    print('    $DEFAULT_EM_LAYERS_END', file=outStr)
    print('', file=outStr)
    print('    $EM_CONDUCTORS_BEGIN', file=outStr)
    print('        $ELECTRICAL_SPEC_BEGIN', file=outStr)
    print('        !-----Name-------rDC-------rHF-------+jX-------Red------Green-----Blue------', file=outStr)
    print('        !              (ohm/sq)  (ohm/sq)  (ohm/sq)  <0-255>   <0-255>   <0-255>', file=outStr)
    print('        $ELECTRICAL_SPEC_END', file=outStr)
    print('', file=outStr)
    print('    $EM_CONDUCTORS_END', file=outStr)
    print('$EM_SETUP_END', file=outStr)

    return outStr.getvalue()

def write_awr_lpf(filepath, layers, substrates=None):
    """
    Writes a complete AWR file to the given filepath with the given list of Layer objects
    """

    # create directory if necessary
    if not os.path.exists(os.path.dirname(filepath)):
        os.makedirs(os.path.dirname(filepath))

    with open(filepath, 'w') as fp:
        fp.write(generate_awr_lpf(layers, substrates))

def generate_awr_lpf_default_units(**kwargs):
    """
    Generate a single string with a default units section of AWR LPF file. Defaults are marked with an asterisk

    Arguments:

    fp - valid file handle

    Keywords:

    len - SI prefix in ['f', 'p', 'n', 'u'*, 'm', 'c', 'none', 'k']
    freq - SI prefix in ['none', 'k', 'M', 'G'*, 'T']
    cap - SI prefix in ['f', 'p'*, 'n', 'u', 'm', 'none']
    ind - SI prefix in ['f', 'p', 'n'*, 'u', 'm', 'none', 'k', 'M', 'G', 'T']
    res - SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*, 'k', 'M', 'G', 'T']
    cond - SI prefix in [SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*]
    temp - Unit in ['DegC'*, 'DegK', 'DegF']
    ang - Unit in ['Deg'*, 'Rad']
    time - SI prefix in ['f', 'p', 'n'*, 'u', 'm', 'none', 'k', 'M', 'G', 'T']
    volt - SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*, 'k', 'M', 'G', 'T']
    cur - SI prefix in ['f', 'p', 'n', 'u', 'm'*, 'none', 'k', 'M', 'G', 'T']
    pwr - SI prefix in ['f', 'p', 'n', 'u', 'm'*, 'none', 'k', 'M', 'G', 'T']
    """

    len = kwargs.pop('len', 'u')
    freq = kwargs.pop('freq', 'G')
    cap = kwargs.pop('cap', 'p')
    ind = kwargs.pop('ind', 'n')
    res = kwargs.pop('res', 'none')
    cond = kwargs.pop('cond','none')
    temp = kwargs.pop('temp', 'DegC')
    ang = kwargs.pop('ang', 'Deg')
    time = kwargs.pop('time', 'n')
    volt = kwargs.pop('volt', 'none')
    cur = kwargs.pop('cur', 'm')
    pwr = kwargs.pop('pwr', 'm')

    outStr = ''
    outStr += '{}$DEFAULT_UNITS_BEGIN\n'.format(' '*4)
    outStr += '{}LEN  {}\n'.format(' '*8, len)
    outStr += '{}FREQ {}\n'.format(' '*8, freq)
    outStr += '{}CAP  {}\n'.format(' '*8, cap)
    outStr += '{}IND  {}\n'.format(' '*8, ind)
    outStr += '{}RES  {}\n'.format(' '*8, res)
    outStr += '{}COND {}\n'.format(' '*8, cond)
    outStr += '{}TEMP {}\n'.format(' '*8, temp)
    outStr += '{}ANG  {}\n'.format(' '*8, ang)
    outStr += '{}TIME {}\n'.format(' '*8, time)
    outStr += '{}VOLT {}\n'.format(' '*8, volt)
    outStr += '{}CUR  {}\n'.format(' '*8, cur)
    outStr += '{}PWR  {}\n'.format(' '*8, pwr)
    outStr += '{}$DEFAULT_UNITS_END\n'.format(' '*4)

    return outStr

def write_awr_lpf_default_units(fp, **kwargs):
    """
    Write default units section of AWR LPF file. Defaults are marked with an asterisk

    Arguments:

    fp - valid file handle

    Keywords:

    len - SI prefix in ['f', 'p', 'n', 'u'*, 'm', 'c', 'none', 'k']
    freq - SI prefix in ['none', 'k', 'M', 'G'*, 'T']
    cap - SI prefix in ['f', 'p'*, 'n', 'u', 'm', 'none']
    ind - SI prefix in ['f', 'p', 'n'*, 'u', 'm', 'none', 'k', 'M', 'G', 'T']
    res - SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*, 'k', 'M', 'G', 'T']
    cond - SI prefix in [SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*]
    temp - Unit in ['DegC'*, 'DegK', 'DegF']
    ang - Unit in ['Deg'*, 'Rad']
    time - SI prefix in ['f', 'p', 'n'*, 'u', 'm', 'none', 'k', 'M', 'G', 'T']
    volt - SI prefix in ['f', 'p', 'n', 'u', 'm', 'none'*, 'k', 'M', 'G', 'T']
    cur - SI prefix in ['f', 'p', 'n', 'u', 'm'*, 'none', 'k', 'M', 'G', 'T']
    pwr - SI prefix in ['f', 'p', 'n', 'u', 'm'*, 'none', 'k', 'M', 'G', 'T']
    """

    print(generate_awr_lpf_default_units(**kwargs), file=fp)

def generate_awr_lpf_database_units(draw_res=0.001, grid_spacing=0.01):
    """
    Generate a single string with the database units section of AWR LPF file. Arguments are in microns

    Arguments:
    fp - valid file handle
    draw_res - float representing database drawing resolution, in microns
    grid_spacing - float representing 1x grid spacing, in microns
    """
    outStr = ''
    outStr += '{}$DBASE_UNIT_BEGIN\n'.format(' '*4)
    outStr += '{}DRAW_RESOLUTION {}{}\n'.format(' '*8, str(draw_res).ljust(8), 'u')
    outStr += '{}GRID_SPACING    {}{}\n'.format(' '*8, str(grid_spacing).ljust(8), 'u')
    outStr += '{}$DBASE_UNIT_END\n'.format(' '*4)

    return outStr

def write_awr_lpf_database_units(fp, draw_res=0.001, grid_spacing=0.01):
    """
    Write database units section of AWR LPF file. Arguments are in microns

    Arguments:
    fp - valid file handle
    draw_res - float representing database drawing resolution, in microns
    grid_spacing - float representing 1x grid spacing, in microns
    """
    print(generate_awr_lpf_database_units(draw_res, grid_spacing=0.01), file=fp)

def generate_awr_connectivity_rules(layers):
    """
    Generate a single string with the connectivity rules section of AWR LPF file.

    Arguments:

    layers - list of Layer objects
    """

    outStr = ''

    local_layers = [x for x in layers]

    outStr += '{}!--- Used by Connectivity tracer ------\n'.format(' '*4)
    outStr += '{}$CONNECT_RULES_BEGIN\n'.format(' '*4)

    # connections is a dict with each layer as a key, and a list of Layers that is connected to by each key
    connections = {}
    connect_all = [ ]
    for layer in local_layers:
        # if length of layer binding is equal to total number of layers, assume a "Connect_All" rule is to be written
        if len(layer.binding) == len(local_layers):
            outStr += '{}Connect_All "{}"\n'.format(' '*8, layer.name)
            connect_all.append(layer)

            # remove this layer from other layer's connect rules, if it exists
            for other_layer in local_layers:
                if layer in other_layer.binding:
                    other_layer.binding.remove(layer)

        else:
            connections[layer.name] = [x for x in layer.binding]

    for key, val in connections.iteritems():
        # no rule written for layers with no bindings
        if val:
            for layer in val:
                # write connect rule
                outStr += '{}Connect "{}" To "{}"\n'.format(' '*8, key, layer.name)

                # remove this layer from other layer's connect rules, if it exists
                if key in [x.name for x in layer.binding]:
                    for i in range(0,len(connections[layer.name])):
                        if connections[layer.name][i].name == key:
                            connections[layer.name].pop(i)
                            break

    outStr += '{}$CONNECT_RULES_END\n'.format(' '*4)

    return outStr

def write_awr_connectivity_rules(fp, layers):
    """
    Write connectivity rules section of AWR LPF file.

    Arguments:

    fp - valid handle to file
    layers - list of Layer objects
    """

    print(generate_awr_connectivity_rules(layers), file=fp)

def generate_awr_layer_setup(layers, patterns):
    """
    Generate a single string with the Draw_Layers section of an AWR LPF file

    Arguments:

    layers - list of Layer objects
    patterns - list of unique Pattern objects that are used in the list of Layers
    """

    outStr = ''

    outStr += '$DRAW_LAYERS_BEGIN\n'
    outStr += '!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n'
    outStr += '! '
    outStr += 'Layer_Name'      .ljust(25)
    outStr += 'Line_Color'      .ljust(12)
    outStr += 'Fill_Color'      .ljust(12)
    outStr += 'Line_Style'      .ljust(12)
    outStr += 'Hatch_Style'     .ljust(12)
    outStr += 'Visible'         .ljust(8)
    outStr += 'Hatch_Visible'   .ljust(14)
    outStr += 'Frozen'          .ljust(8)
    outStr += '3D_Thickness'    .ljust(14)
    outStr += '3D_Z_Pos'        .ljust(10)
    outStr += 'Texture'         .ljust(8)
    outStr += 'Trans_Fill'      .ljust(12)
    outStr += 'Translucent'     .ljust(12)
    outStr += 'Texture_Scale'   .ljust(14)
    outStr += 'File_Layer'      .ljust(12)
    outStr += 'Options'         .ljust(8)
    outStr += 'Cloak'           .ljust(6)
    outStr += 'Hatch_Name'
    outStr += '\n!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n'

    outStr += '"Error"'.ljust(27)+'255'.ljust(12)+'255'.ljust(12)+'0'.ljust(12)+'16'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'0'.ljust(6)+'\n'
    outStr += '"RatsNest"'.ljust(27)+'255'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'0'.ljust(6)+'\n'
    outStr += '"EMSymbols"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'0'.ljust(6)+'\n'
    outStr += '"Default"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'0'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"SubcircuitAnnotation"'.ljust(27)+'4259648'.ljust(12)+'4259648'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"Annotation"'.ljust(27)+'16776960'.ljust(12)+'16776960'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"DrillHoles"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"ErrorHighlight"'.ljust(27)+'1113872'.ljust(12)+'1113872'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"Highlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"Selection"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"DimensionLines"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"SubSelection"'.ljust(27)+'4210943'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '"DynamicHighlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'2'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(14)+'0'.ljust(10)+'""'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(14)+'"Obsolete"'.ljust(12)+'0'.ljust(8)+'1'.ljust(6)+'\n'
    outStr += '\n'

    for layer in layers:
        name = '"{}"'.format(layer.name)

        # force pure white to draw as black instead
        if layer.color == int(wx.Colour(255, 255, 255).GetRGB()):
            color = str(lpf_rgb_to_color(0, 0, 0))
        else:
            color = str(lpf_rgb_to_color(layer.blue, layer.green, layer.red))

        if (layer.style is not None) and (not layer.style == LineStyle.NoLine):
            style = str(get_awr_linestyle(layer.style))
        else:
            style = '0'

        if (layer.pattern is not None) and (not layer.pattern == defaults._default_patterns[0]):
            fill_index = str(patterns.index(layer.pattern) + 26) # indices for custom-defined patterns starts at 26
            hatch_visible = '1'
            hatch_name = '"{}"'.format(layer.pattern.name)
        else:
            fill_index = '0'
            hatch_visible = '0'
            hatch_name = ''

        vis = '1' if layer.visible else '0'
        clk = '1' if layer.cloak else '0'

        outStr += name          .ljust(27)
        outStr += color         .ljust(12)
        outStr += color         .ljust(12)
        outStr += style         .ljust(12)
        outStr += fill_index    .ljust(12)
        outStr += vis           .ljust(8)
        outStr += hatch_visible .ljust(14)
        outStr += '0'           .ljust(8)
        outStr += '0'           .ljust(14)
        outStr += '0'           .ljust(10)
        outStr += '""'          .ljust(8)
        outStr += '0'           .ljust(12)
        outStr += '0.5'         .ljust(12)
        outStr += '0'           .ljust(14)
        outStr += '"Obsolete"'  .ljust(12)
        outStr += '0'           .ljust(8)
        outStr += clk           .ljust(6)
        outStr += hatch_name
        outStr += '\n'

    outStr += '\n$DRAW_LAYERS_END\n'

    return outStr

def write_awr_layer_setup(fp, layers, patterns):
    """
    Writes the Draw_Layers section of an AWR LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    patterns - list of unique Pattern objects that are used in the list of Layers
    """

    print(generate_awr_layer_setup(layers, patterns), file=fp)

def generate_awr_layer_config(config_name, layers, patterns, vis_list=None, clk_list=None):
    """
    Generates a single string with a layer config section of an AWR LPF file

    Arguments:

    config_name - a string with the name of the configuration
    layers - list of Layer objects
    patterns - list of unique Pattern objects that are used in the list of Layers
    vis_list - (optional) list of Booleans that determines whether the corresponding layer should be visible in this configuration
    clk_list - (optional) list of Booleans that determines whether the corresponding layer should be cloaked in this configuration

    layers, vis_list, and clk_list must be the same length!
    """

    outStr = ''

    if vis_list is None:
        vis_list = [layer.visible for layer in layers]
    if clk_list is None:
        clk_list = [layer.cloak for layer in layers]

    if not len(layers) == len(vis_list) or not len(layers) == len(clk_list):
        raise ValueError('layers, vis_list, and clk_list must be the same length!')

    outStr += '$CONFIG_NAME    "{}"\n'.format(config_name)

    outStr += '! '
    outStr += 'Layer_Name'.ljust(25)
    outStr += 'Line_Color'.ljust(12)
    outStr += 'Fill_Color'.ljust(12)
    outStr += 'Line_Style'.ljust(12)
    outStr += 'Hatch_Style'.ljust(12)
    outStr += 'Visible'.ljust(8)
    outStr += 'Hatch_Visible'.ljust(14)
    outStr += 'Frozen'.ljust(8)
    outStr += 'Trans_Fill'.ljust(12)
    outStr += 'Translucent'.ljust(12)
    outStr += 'Cloak'.ljust(6)
    outStr += '3D_Thickness'.ljust(14)
    outStr += '3D_Z_Pos'.ljust(10)
    outStr += '\n'

    outStr += '"Error"'.ljust(27)+'255'.ljust(12)+'255'.ljust(12)+'0'.ljust(12)+'16'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"RatsNest"'.ljust(27)+'255'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"EMSymbols"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'0'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"Default"'.ljust(27)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'0'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"SubcircuitAnnotation"'.ljust(27)+'4259648'.ljust(12)+'4259648'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"Annotation"'.ljust(27)+'16776960'.ljust(12)+'16776960'.ljust(12)+'2'.ljust(12)+'8'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"DrillHoles"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"ErrorHighlight"'.ljust(27)+'1113872'.ljust(12)+'1113872'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"Highlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'5'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"Selection"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"DimensionLines"'.ljust(27)+'2105376'.ljust(12)+'2105376'.ljust(12)+'0'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"SubSelection"'.ljust(27)+'4210943'.ljust(12)+'4210943'.ljust(12)+'0'.ljust(12)+'1'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '"DynamicHighlight"'.ljust(27)+'65535'.ljust(12)+'65535'.ljust(12)+'2'.ljust(12)+'0'.ljust(12)+'1'.ljust(8)+'1'.ljust(14)+'0'.ljust(8)+'0'.ljust(12)+'0.5'.ljust(12)+'1'.ljust(6)+'0'.ljust(14)+'0'.ljust(10)+'\n'
    outStr += '\n'

    for (layer, visible, cloak) in zip(layers, vis_list, clk_list):
        name = '"{}"'.format(layer.name)

        # force pure white to draw as black instead
        if layer.color == int(wx.Colour(255, 255, 255).GetRGB()):
            color = str(lpf_rgb_to_color(0, 0, 0))
        else:
            color = str(lpf_rgb_to_color(layer.blue, layer.green, layer.red))

        if (layer.style is not None) and (not layer.style == LineStyle.NoLine):
            style = str(get_awr_linestyle(layer.style))
        else:
            style = '0'

        if (layer.pattern is not None) and (not layer.pattern == defaults._default_patterns[0]):
            fill_index = str(patterns.index(layer.pattern) + 26) # indices for custom-defined patterns starts at 26
            hatch_visible = '1'
            hatch_name = '"' + layer.pattern.name + '"'
        else:
            fill_index = '0'
            hatch_visible = '0'
            hatch_name = ''

        vis = '1' if visible else '0'
        clk = '1' if cloak else '0'

        outStr += name          .ljust(27)
        outStr += color         .ljust(12)
        outStr += color         .ljust(12)
        outStr += style         .ljust(12)
        outStr += fill_index    .ljust(12)
        outStr += vis           .ljust(8)
        outStr += hatch_visible .ljust(14)
        outStr += '0'           .ljust(8)
        outStr += '0'           .ljust(12)
        outStr += '0.5'         .ljust(12)
        outStr += clk           .ljust(6)
        outStr += '0'           .ljust(14)
        outStr += '0'           .ljust(10)
        outStr += '\n'

    return outStr

def write_awr_layer_config(fp, config_name, layers, patterns, vis_list=None, clk_list=None):
    """
    Writes a layer config section of an AWR LPF file

    Arguments:

    fp - valid handle to file to be written to
    config_name - a string with the name of the configuration
    layers - list of Layer objects
    patterns - list of unique Pattern objects that are used in the list of Layers
    vis_list - (optional) list of Booleans that determines whether the corresponding layer should be visible in this configuration
    clk_list - (optional) list of Booleans that determines whether the corresponding layer should be cloaked in this configuration

    layers, vis_list, and clk_list must be the same length!
    """

    print(generate_awr_layer_config(config_name, layers, patterns, vis_list, clk_list), file=fp)

def generate_awr_model_layer(layers):
    """
    Generates a single string with the model layers section of the LPF file

    Arguments:

    layers - list of Layer objects
    """
    outStr = ''
    outStr += '$MODEL_LAYER_BEGIN\n\n'
    outStr += '{}{}\n'.format('$MAP_NAME'.ljust(30), '"GDS Map"')

    # print model layer -> model layer
    for layer in layers:
        string = '"{}"'.format(layer.name)
        outStr += '{}{}\n'.format(string.ljust(30), string)

    outStr += '\n'

    # print GDS number -> model layer
    for layer in layers:
        string1 = '"{}_0"'.format(str(layer.gds))
        string2 = '"{}"'.format(layer.name)
        outStr += '{}{}\n'.format(string1.ljust(30), string2)

    outStr += '\n'
    outStr += '"Default"                     "Default"\n'
    outStr += '"EMSymbols"                   "EMSymbols"\n'
    outStr += '"RatsNest"                    "RatsNest"\n'
    outStr += '"Error"                       "Error"\n'
    outStr += '"SubcircuitAnnotation"        "SubcircuitAnnotation"\n'
    outStr += '"Annotation"                  "Annotation"\n'
    outStr += '"DrillHoles"                  "DrillHoles"\n'
    outStr += '"ErrorHighlight"              "ErrorHighlight"\n'
    outStr += '"Highlight"                   "Highlight"\n'
    outStr += '"Selection"                   "Selection"\n'
    outStr += '"DimensionLines"              "DimensionLines"\n'
    outStr += '"SubSelection"                "SubSelection"\n'
    outStr += '"DynamicHighlight"            "DynamicHighlight"\n'
    outStr += '\n'
    outStr += '$MODEL_LAYER_END\n'

    return outStr

def write_awr_model_layer(fp, layers):
    """
    Writes the model layers section of the LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    """

    print(generate_awr_model_layer(layers), file=fp)

def generate_awr_em_mapping(layers, substrates):
    """
    Generates a single string with the EM mapping section of the LPF file

    Arguments:

    layers - list of Layer objects
    substrate - list of Substrate objects
    """

    outStr = ''
    outStr += '$EM_MAPPING_BEGIN\n\n'

    if substrates is not None:
        for sub in substrates:
            outStr += '$EM_MAP    "{}" !name\n'.format(sub.Name)
            outStr += '!layer_name                   em_layer    is_via  material            via_extent\n'

            for layer in layers:
                # if the layer is mapped in this substrate definition
                if layer.name in sub.MappedLayerNames:
                    nameStr = '"{}"'.format(layer.name)
                    # need to reverse index for AWR, also need to shift by 1 due to forcing an additional layer of air on top of the substrate
                    indexStr = str(len(sub.DielectricLayers) - sub.MappedLayers[layer.name]['Index'] + 1)
                    matStr = nameStr
                    extent = sub.MappedLayers[layer.name]['Extent']
                    if extent is not None:
                        viaStr = '1'
                        extStr = str(extent)
                    else:
                        viaStr = '0'
                        extStr = '1'

                # unmapped layers
                else:
                    nameStr = '"{}"'.format(layer.name)
                    indexStr = '0'
                    matStr = '""'
                    viaStr = '0'
                    extStr = '1'

                outStr += nameStr   .ljust(30)
                outStr += indexStr  .ljust(12)
                outStr += viaStr    .ljust(8)
                outStr += matStr    .ljust(20)
                outStr += extStr    .ljust(1)
                outStr += '\n'

            outStr += '\n'
            outStr += '"Default"'               .ljust(30) + '0           0       ""                  1\n'
            outStr += '"EMSymbols"'             .ljust(30) + '0           0       ""                  1\n'
            outStr += '"RatsNest"'              .ljust(30) + '0           0       ""                  1\n'
            outStr += '"Error"'                 .ljust(30) + '0           0       ""                  1\n'
            outStr += '"SubcircuitAnnotation"'  .ljust(30) + '0           0       ""                  1\n'
            outStr += '"Annotation"'            .ljust(30) + '0           0       ""                  1\n'
            outStr += '"DrillHoles"'            .ljust(30) + '0           0       ""                  1\n'
            outStr += '"ErrorHighlight"'        .ljust(30) + '0           0       ""                  1\n'
            outStr += '"Highlight"'             .ljust(30) + '0           0       ""                  1\n'
            outStr += '"Selection"'             .ljust(30) + '0           0       ""                  1\n'
            outStr += '"DimensionLines"'        .ljust(30) + '0           0       ""                  1\n'
            outStr += '"SubSelection"'          .ljust(30) + '0           0       ""                  1\n'
            outStr += '"DynamicHighlight"'      .ljust(30) + '0           0       ""                  1\n'
            outStr += '\n'

    outStr += '$EM_MAPPING_END\n'

    return outStr

def write_awr_em_mapping(fp, layers, substrates):
    """
    Writes the EM mapping section of the LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    substrate - list of Substrate objects
    """

    print(generate_awr_em_mapping(layers, substrates), file=fp)

def generate_awr_file_mapping(layers):
    """
    Generates a single string with the GDS export mapping section of the LPF file

    Arguments:

    layers - list of Layer objects
    """
    outStr = ''

    outStr += '$FILE_MAPPING_BEGIN\n'
    outStr += '$FILE_MAP    "GDSII" 0\n'
    outStr += '!layer_name                   file_layer  skip\n'

    for layer in layers:
        string1 = '"{}"'.format(layer.name)
        string2 = '"{}"'.format(str(layer.gds))
        string3 = '0'

        outStr += '{}{}{}\n'.format(string1.ljust(30), string2.ljust(12), string3)

    outStr += '\n'
    outStr += '"Default"'               .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"EMSymbols"'             .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"RatsNest"'              .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"Error"'                 .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"SubcircuitAnnotation"'  .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"Annotation"'            .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"DrillHoles"'            .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"ErrorHighlight"'        .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"Highlight"'             .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"Selection"'             .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"DimensionLines"'        .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"SubSelection"'          .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '"DynamicHighlight"'      .ljust(30) + '""'.ljust(12) + '1\n'
    outStr += '\n'
    outStr += '$FILE_MAPPING_END\n'

    return outStr

def write_awr_file_mapping(fp, layers):
    """
    Writes the GDS export mapping section of the LPF file

    Arguments:

    fp - valid handle to file to be written to
    layers - list of Layer objects
    """
    print(generate_awr_file_mapping(layers), file=fp)

def generate_awr_stipple_patterns(patterns):
    """
    Generates a single string with the custom stipple pattern section of the AWR LPF file

    Arguments:

    patterns - list of Pattern objects
    """

    outStr = ''
    outStr += '$LAYER_FILL_PATTERN_BEGIN\n\n'

    # custom stipple patterns start at index 26 after built-in AWR stipple patterns
    idx = 26
    for pattern in patterns:
        outStr += '! {}\n'.format(str(idx))
        outStr += pattern.generate_pattern_awr_lpf()
        outStr += '\n'
        idx += 1

    outStr += '$LAYER_FILL_PATTERN_END\n'

    return outStr

def write_awr_stipple_patterns(fp, patterns):
    """
    Writes the custom stipple pattern section of the AWR LPF file

    Arguments:

    fp - valid handle to file to be written to
    patterns - list of Pattern objects
    """

    print(generate_awr_stipple_patterns(patterns) , file=fp)

def write_ads_substrates(directory, layers, substrates):
    """
    Writes an ADS substrate .subst file for each substrate in the given list of substrates
    """

    layernames = [x.name for x in layers]

    # create directory if necessary
    if not os.path.exists(directory):
        os.makedirs(directory)

    for sub in substrates:
        with open(os.path.join(directory, '{}.subst'.format(sub.Name)), 'w') as fp:
            print('<!DOCTYPE Substrate>', file=fp)
            print('<SubstrateModel>', file=fp)

            indent = 4
            indentStr = ' '*indent

            print(indentStr + '<stack BAL_TYPE="NONE" BAL_NUM="{:d}">'.format(len(sub.DielectricLayers) + 3), file=fp)

            # print dielectric layers from bottom up
            indentStr = ' '*2*indent
            print(indentStr + '<material  materialname="AIR"                      BAL_TYPE="INHERIT"    BAL_NUM="0"/>', file=fp)
            print(indentStr + '<interface materialname="PERFECT_CONDUCTOR"        BAL_TYPE="NONE"       thick="0"      thickunit="micron" BAL_NUM="0" groundplane="1"/>', file=fp)

            # print dielectric layers section
            for layer in sub.DielectricLayers:
                materialnameStr = layer['Material'].Name
                thickStr = '{:g}'.format(layer['Thickness']*1e6)
                bal_typeStr = 'INHERIT'
                bal_numStr = '0'
                print(indentStr + '<material  materialname="', end='', file=fp)
                print('{}"'.format(materialnameStr).ljust(26), end='', file=fp)
                print('BAL_TYPE="INHERIT"    thick="', end='', file=fp)
                print('{}"'.format(thickStr).ljust(8), end='', file=fp)
                print('thickunit="micron" BAL_NUM="0"/>', file=fp)
                print(indentStr + '<interface materialname="' + '"'.ljust(26) + 'BAL_TYPE="INHERIT"    thick="' + '0"'.ljust(8) + 'thickunit="micron" BAL_NUM="0"/>', file=fp)

            print(indentStr + '<material  materialname="AIR"                      BAL_TYPE="INHERIT"    BAL_NUM="0"/>', file=fp)

            indentStr = ' '*indent
            print(indentStr + '</stack>', file=fp)

            # print mapped layers section

            print(indentStr + '<layers>', file=fp)

            indentStr = ' '*2*indent

            for key, val in sub.MappedLayers.iteritems():
                if val['Extent'] is None:
                    layer = layers[layernames.index(key)]
                    materialnameStr = val['Material'].Name
                    if val['Thickness'] is not None:
                        thickStr = '{:g}'.format(val['Thickness']*1e6)
                    else:
                        thickStr = '0.1'
                    layerStr = str(get_ads_layer_number(layer.gds))
                    indexStr = '{:d}'.format(val['Index'] + 1)

                    if val['Sheet']:
                        sheetStr = '1'
                        expandStr = '0'
                    else:
                        sheetStr = '0'
                        dielectricIdx = val['Index'] + 1 if val['Index'] + 1 < len(sub.DielectricLayers) else None
                        dielectricThickness = sub.DielectricLayers[dielectricIdx]['Thickness'] if dielectricIdx else None
                        
                        if dielectricThickness:
                            expandStr = '0' if val['Thickness'] < dielectricThickness else '1'
                        else:
                            expandStr = '0'                        

                    print(indentStr + '<layer materialname="', end='', file=fp)
                    print('{}"'.format(materialnameStr).ljust(26), end='', file=fp)
                    print('toprough="" pinsonly="0" bottomrough="" thick="', end='', file=fp)
                    print('{}"'.format(thickStr).ljust(8), end='', file=fp)
                    print('precedence="0" sheet="', end='', file=fp)
                    print('{}"'.format(sheetStr).ljust(3), end='', file=fp)
                    print('thickunit="micron" layer="', end='', file=fp)
                    print('{}"'.format(layerStr).ljust(8), end='', file=fp)
                    print('negative="0" subtype="0" expand="', end='', file=fp)
                    print('{}"'.format(expandStr).ljust(3), end='', file=fp)
                    print('index="', end='', file=fp)
                    print('{}"'.format(indexStr).ljust(4), end='', file=fp)
                    print('/>', file=fp)

            indentStr = ' '*indent
            print(indentStr + '</layers>', file=fp)

            # print mapped vias section

            print(indentStr + '<vias>', file=fp)

            indentStr = ' '*2*indent

            for key, val in sub.MappedLayers.iteritems():
                if val['Extent'] is not None:
                    layer = layers[layernames.index(key)]
                    materialnameStr = val['Material'].Name
                    if val['Thickness'] is not None:
                        thickStr = '{:g}'.format(val['Thickness']*1e6)
                    else:
                        thickStr = '0.1'
                    layerStr = str(get_ads_layer_number(layer.gds))

                    # bottom index of via is index1
                    index1Str = '{:d}'.format(val['Index'] + 1 - val['Extent'])
                    # top index of via is index2
                    index2Str = '{:d}'.format(val['Index'] + 1)

                    print(indentStr + '<via platingthickness="', end='', file=fp)
                    print('{}"'.format(thickStr).ljust(8), end='', file=fp)
                    print('layer="', end='', file=fp)
                    print('{}"'.format(layerStr).ljust(8), end='', file=fp)
                    print('materialname="', end='', file=fp)
                    print('{}"'.format(materialnameStr).ljust(26), end='', file=fp)
                    print('precedence="0" index2="', end='', file=fp)
                    print('{}"'.format(index2Str).ljust(4), end='', file=fp)
                    print('platingdielectricmaterial="AIR" rough="" index1="', end='', file=fp)
                    print('{}"'.format(index1Str).ljust(4), end='', file=fp)
                    print('platingenabled="1" subtype="0" platingthicknessunit="micron"/>', file=fp)

            indentStr = ' '*indent
            print(indentStr + '</vias>', file=fp)
            print(indentStr + '<substrates/>', file=fp)

            print('</SubstrateModel>', file=fp)

def generate_ads_materials(materials):
    """
    Generates a single string with the contents of an ADS .matdb file for the given materials

    Arguments:

    materials - list of Material objects
    """

    outStr = ''

    outStr += '<!DOCTYPE Materials>\n'
    outStr += '<Materials>\n'

    indent = 4

    conductors = [x for x in materials if x.MatType == material.MaterialType.CONDUCTOR]
    dielectrics = [x for x in materials if x.MatType == material.MaterialType.DIELECTRIC]
    semiconductors = [x for x in materials if x.MatType == material.MaterialType.SEMICONDUCTOR]

    # print conductors section
    indentStr = ' '*indent
    outStr += indentStr + '<Conductors>\n'

    indentStr = ' '*2*indent
    for mat in conductors:
        nameStr = mat.Name
        if mat.CondType == material.ConductorType.BULK:
            parmTypeStr = '1'
            realStr = '{:g} Siemens/m'.format(mat.CondReal)
            imagStr = ''
        elif mat.CondType == material.ConductorType.SHEET:
            parmTypeStr = '0'
            realStr = '{:g} Ohm/Sq'.format(mat.CondReal)
            if mat.CondImag:
                imagStr = '{:g} Ohm/Sq'.format(mat.CondImag)
            else:
                imagStr = ''
        murRealStr = '1'
        murImagStr = ''

        outStr += indentStr + '<Conductor parmtype="{}" mur_real="{}" '.format(parmTypeStr, murRealStr)
        outStr += 'imag="{}"'.format(imagStr).ljust(30)
        outStr += 'name="{}"'.format(nameStr).ljust(25)
        outStr += 'real="{}"'.format(realStr).ljust(30)
        outStr += 'mur_imag="{}"'.format(murImagStr) + '/>\n'

    indentStr = ' '*indent
    outStr += indentStr + '</Conductors>\n'

    # print dielectrics section
    indentStr = ' '*indent
    outStr += indentStr + '<Dielectrics>\n'

    indentStr = ' '*2*indent
    for mat in dielectrics:
        nameStr = mat.Name   

        
        # ignore anisotropy and use x-directed values
        if isinstance(mat.Epsilon, tuple):
            eps = mat.Epsilon[0]
        else:
            eps = mat.Epsilon
        errealStr = '{:g}'.format(eps)

        if isinstance(mat.Mu, tuple):
            mu = mat.Mu[0]
        else:
            mu = mat.Mu
        murrealStr = '{:g}'.format(mu)

        if isinstance(mat.TanD, tuple):
            tand = mat.TanD[0]
        else:
            tand = mat.TanD
        erlossStr = '{:g}'.format(tand)

        murImagStr = ''

        outStr += indentStr + '<Dielectric loss_type="0" '
        outStr += 'mur_real="{}"'.format(murrealStr).ljust(18)
        outStr += 'lowfreq="1 KHz" valuefreq="1 GHz" er_imag="" highfreq="1 THz" '
        outStr += 'er_loss="{}"'.format(erlossStr).ljust(18)
        outStr += 'name="{}"'.format(nameStr).ljust(25)
        outStr += 'er_real="{}"'.format(errealStr).ljust(18)
        outStr += 'mur_imag="{}"'.format(murImagStr).ljust(11)
        outStr += '/>\n'

    indentStr = ' '*indent
    outStr += indentStr + '</Dielectrics>\n'

    # print semiconductors section
    indentStr = ' '*indent
    outStr += indentStr + '<Semiconductors>\n'

    indentStr = ' '*2*indent
    for mat in semiconductors:
        nameStr = mat.Name

        # convert bulk conductivity of S/m into Ohm.cm
        resistivityStr = '{:g} Ohm.cm'.format(1/(mat.CondReal/100))

        # ignore anisotropy and use x-directed values
        if isinstance(mat.Epsilon, tuple):
            eps = mat.Epsilon[0]
        else:
            eps = mat.Epsilon
        errealStr = '{:g}'.format(eps)

        if isinstance(mat.Mu, tuple):
            mu = mat.Mu[0]
        else:
            mu = mat.Mu
        murrealStr = '{:g}'.format(mu)

        # ADS currently doesn't support loss tangent + resistivity for semiconductors
        #if isinstance(mat.TanD, tuple):
        #    tand = mat.TanD[0]
        #else:
        #    tand = mat.TanD
        #erlossStr = '{:g}'.format(tand)

        murImagStr = '0'

        outStr += indentStr + '<Semiconductor '
        outStr += 'mur_real="{}"'.format(murrealStr).ljust(18)
        outStr += 'resistivity="{}"'.format(resistivityStr).ljust(30)
        outStr += 'name="{}"'.format(nameStr).ljust(25)
        outStr += 'er_real="{}"'.format(errealStr).ljust(18)
        outStr += 'mur_imag="{}"'.format(murImagStr).ljust(11)
        outStr += '/>\n'

    indentStr = ' '*indent
    outStr += indentStr + '</Semiconductors>\n'

    outStr += indentStr + '<roughness/>\n'
    outStr += '</Materials>'

    return outStr

def write_ads_materials(fp, materials):
    "Write an ADS materials.matdb file for the given list of materials"

    print(generate_ads_materials(materials), file=fp)

def write_ads_config(rootDir, layers, substrates=None, OA=True, ABL=True, legacy=True):
    """
    Writes an ADS layout.lay file, ABL .xml file, and/or all the files necessary to create an OA technology
    """
    kitName = rootDir.split(os.sep)[-1]

    if not os.path.exists(rootDir):
        os.makedirs(rootDir)

    oa_dir = rootDir

    # create a 'tech' subdirectory only if writing OA and legacy formats
    if legacy and OA:
        oa_dir = os.path.join(rootDir, 'tech')
        if not os.path.exists(oa_dir):
            os.makedirs(oa_dir)

    all_layers = [defaults._default_ads_layers[0]] + layers
    all_layers = all_layers + defaults._default_ads_layers[1:]

    if legacy:
        # write .lay file
        with open(os.path.join(rootDir, 'layout.lay'), 'w') as fp:
            write_ads_layout_lay(fp, all_layers)

    # write library.tech file
    with open(os.path.join(oa_dir, 'library.tech'), 'w') as fp:
        write_ads_library_tech_file(fp, all_layers)

    # write display.tech file
    with open(os.path.join(oa_dir, 'display.tech'), 'w') as fp:
        write_ads_display_tech_file(fp, all_layers)

    # write technology creation ael file
    with open(os.path.join(oa_dir, 'create_technology.ael'), 'w') as fp:
        write_ads_create_tech_ael(fp, all_layers)

    with open(os.path.join(oa_dir, 'LayerMap.map'), 'w') as fp:
        write_ads_layer_map_file(fp, all_layers)

    if substrates:
        write_ads_substrates(oa_dir, all_layers, substrates)

        all_mats = [ ]
        for sub in substrates:
            for mat in sub.AllMaterials:
                if mat not in all_mats:
                    all_mats.append(mat)

        with open(os.path.join(oa_dir, 'materials.matdb'), 'w') as fp:
            write_ads_materials(fp, all_mats)

    if ABL:
        with open(os.path.join(rootDir, '{}.xml'.format(kitName)), 'w') as fp:
            write_ads_abl_file(fp, kitName, all_layers, substrates)

def write_ads_abl_file(fp, libname, layers, substrates=None):
    """
    Writes an ADS ABL .xml file for the given list of layers and substrates

    Arguments:

    fp - valid handle to output file to write
    libname - string containing the library name
    layers - list of Layer objects
    substrates - (Optional) list of Substrate objects
    """

    layernames = [x.name for x in layers]

    indent = ''
    indentAmt = defaults._text_indent_amount

    # print header
    print(indent + '<?xml version="1.0" encoding="UTF-8"?>', file=fp)
    print(indent + '<abl:ABLRoot xmlns:abl="http://keysight.com/eesof/abl" version="1.5" sourceName="ADS">', file=fp)

    indent = ' '*indentAmt
    # begin printing library configuration
    print(indent + '<abl:Library name="{}" sourcePath="./{}">'.format(libname, libname), file=fp)

    indent += ' '*indentAmt

    # begin printing technology
    print(indent + '<abl:Technology>', file=fp)

    indent += ' '*indentAmt

    # begin printing referenced technologies
    # print(indent + '<abl:ReferencedTechnologies>', file=fp)
    print(indent + '<abl:ReferencedTechnologies/>', file=fp)

    # indent += ' '*indentAmt

    # # print ads_schematic_layers technology info
    # _ads_schem_tech = '<abl:ReferencedTechnology referencedLibraryName="ads_schematic_layers">\n_INDENT_<abl:Technology>\n_INDENT__INDENT_<abl:TechUnits>\n_INDENT__INDENT__INDENT_<abl:SchematicUnits oaUserUnits="inch" userUnits="in" DBUperUU="160"/>\n_INDENT__INDENT__INDENT_<abl:SymbolUnits oaUserUnits="inch" userUnits="in" DBUperUU="160"/>\n_INDENT__INDENT__INDENT_<abl:LayoutUnits oaUserUnits="micron" userUnits="um" DBUperUU="1000"/>\n_INDENT__INDENT__INDENT_<abl:DefaultManufacturingGrid manufacturingGrid="0"/>\n_INDENT__INDENT_</abl:TechUnits>\n_INDENT__INDENT_<abl:Layers>\n_INDENT__INDENT__INDENT_<abl:Layer number="227" processRole="Not defined" name="ads_supply" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="222" processRole="Not defined" name="ads_unknown" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="221" processRole="Not defined" name="ads_unset" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="217" processRole="Not defined" name="ads_designFlow" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="220" processRole="Not defined" name="ads_changedLayer" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="238" processRole="Not defined" name="ads_marker" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="201" processRole="Not defined" name="ads_Row" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="202" processRole="Not defined" name="ads_Group" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="203" processRole="Not defined" name="ads_Cannotoccupy" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="204" processRole="Not defined" name="ads_Canplace" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="200" processRole="Not defined" name="ads_Unrouted" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="210" processRole="Not defined" name="ads_y3" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="211" processRole="Not defined" name="ads_y4" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="212" processRole="Not defined" name="ads_y5" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="213" processRole="Not defined" name="ads_y6" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="214" processRole="Not defined" name="ads_y7" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="215" processRole="Not defined" name="ads_y8" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="216" processRole="Not defined" name="ads_y9" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="253" processRole="Not defined" name="ads_hilite" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="239" processRole="Not defined" name="ads_select" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="226" processRole="Not defined" name="ads_drive" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="224" processRole="Not defined" name="ads_hiz" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="225" processRole="Not defined" name="ads_resist" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="223" processRole="Not defined" name="ads_spike" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="240" processRole="Not defined" name="ads_substrate" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="254" processRole="Not defined" name="ads_background" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="251" processRole="Not defined" name="ads_grid" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="237" processRole="Not defined" name="ads_annotate" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="236" processRole="Not defined" name="ads_instance" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="235" processRole="Not defined" name="ads_prBoundary" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="234" processRole="Not defined" name="ads_align" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="205" processRole="Not defined" name="ads_hardFence" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="231" processRole="Not defined" name="ads_device" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="228" processRole="Not defined" name="ads_wire" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="206" processRole="Not defined" name="ads_softFence" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="230" processRole="Not defined" name="ads_text" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="232" processRole="Not defined" name="ads_border" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="229" processRole="Not defined" name="ads_pin" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="252" processRole="Not defined" name="ads_axis" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="219" processRole="Not defined" name="ads_edgeLayer" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="233" processRole="Not defined" name="ads_snap" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="218" processRole="Not defined" name="ads_stretch" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="207" processRole="Not defined" name="ads_y0" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="208" processRole="Not defined" name="ads_y1" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="209" processRole="Not defined" name="ads_y2" manufacturingGrid="0"/>\n_INDENT__INDENT__INDENT_<abl:Layer number="255" processRole="DRC" name="ads_drc_error" manufacturingGrid="0"/>\n_INDENT__INDENT_</abl:Layers>\n_INDENT__INDENT_<abl:ReservedPurposes>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-1" type="drawing" name="drawing"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-2" type="fill" name="fill"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-3" type="slot" name="slot"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-4" type="OPCSerif" name="OPCSerif"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-5" type="OPCAntiSerif" name="OPCAntiSerif"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-6" type="annotation" name="annotation"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-7" type="gapFill" name="gapFill"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-8" type="redundant" name="redundant"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-9" type="oaAny" name="oaAny"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-10" type="oaNo" name="oaNo"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-11" type="oaFillOPC" name="oaFillOPC"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="-12" type="oaCustomFill" name="oaCustomFill"/>\n_INDENT__INDENT_</abl:ReservedPurposes>\n_INDENT__INDENT_<abl:Purposes>\n_INDENT__INDENT__INDENT_<abl:Purpose number="255" type="drawing" name="ads_all"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="254" type="drawing" name="ads_cell"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="253" type="drawing" name="ads_net"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="251" type="drawing" name="ads_pin"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="250" type="drawing" name="ads_boundary"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="249" type="drawing" name="ads_drawing9"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="248" type="drawing" name="ads_drawing8"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="247" type="drawing" name="ads_drawing7"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="246" type="drawing" name="ads_drawing6"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="245" type="drawing" name="ads_drawing5"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="244" type="drawing" name="ads_drawing4"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="243" type="drawing" name="ads_drawing3"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="242" type="drawing" name="ads_drawing2"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="241" type="drawing" name="ads_drawing1"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="240" type="drawing" name="ads_annotate"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="239" type="drawing" name="ads_error"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="238" type="drawing" name="ads_flight"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="237" type="drawing" name="ads_label"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="236" type="drawing" name="ads_tool0"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="235" type="drawing" name="ads_tool1"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="234" type="drawing" name="ads_warning"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="232" type="drawing" name="ads_fillOPC"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="231" type="drawing" name="ads_grid"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="229" type="drawing" name="ads_track"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="228" type="drawing" name="ads_info"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="227" type="drawing" name="ads_ackWarn"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="226" type="drawing" name="ads_soError"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="225" type="drawing" name="ads_soCritical"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="224" type="drawing" name="ads_critical"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="223" type="drawing" name="ads_fatal"/>\n_INDENT__INDENT__INDENT_<abl:Purpose number="230" type="drawing" name="ads_blockage"/>\n_INDENT__INDENT_</abl:Purposes>\n_INDENT__INDENT_<abl:DisplayProperties>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_instance" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="true" r="255" g="0" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_annotate" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="128" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_annotate" purpose="ads_drawing1" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="106" g="90" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_annotate" purpose="ads_drawing2" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_annotate" purpose="ads_drawing3" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_annotate" purpose="ads_drawing4" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_annotate" purpose="ads_drawing7" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="255" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_annotate" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="30" g="144" b="255" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_drawing1" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="106" g="90" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_drawing3" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="208" g="32" b="144" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_drawing4" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="1" g="0" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_drawing5" displayMode="Filled" lineType="Solid" fillType="18" visible="true" protected="false" r="0" g="0" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_drawing6" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="205" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_device" purpose="ads_drawing7" displayMode="Outlined" lineType="Solid" fillType="18" visible="true" protected="false" r="46" g="139" b="87" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_pin" purpose="ads_label" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="255" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_text" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="0" g="0" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_wire" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="199" g="21" b="133" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y7" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="30" g="144" b="255" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y8" purpose="drawing" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="255" g="145" b="67" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_wire" purpose="ads_label" displayMode="Outlined" lineType="Solid" fillType="0" visible="true" protected="false" r="199" g="21" b="133" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing1" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="255" g="165" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing2" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="255" g="0" b="255" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing3" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="0" g="0" b="255" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing4" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="107" g="142" b="35" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing5" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="0" g="0" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing6" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="255" g="69" b="0" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_y9" purpose="ads_drawing7" displayMode="Both" lineType="Solid" fillType="18" visible="true" protected="false" r="205" g="92" b="92" alpha="255"/>\n_INDENT__INDENT__INDENT_<abl:DisplayProperty layer="ads_drc_error" purpose="drawing" displayMode="Outlined" lineType="Solid" fillType="18" visible="true" protected="false" r="255" g="255" b="0" alpha="255"/>\n_INDENT__INDENT_</abl:DisplayProperties>\n_INDENT__INDENT_<abl:Materials/>\n_INDENT__INDENT_<abl:ViaDefinitions/>\n_INDENT__INDENT_<abl:LineTypes>\n_INDENT__INDENT__INDENT_<abl:LineItems/>\n_INDENT__INDENT__INDENT_<abl:DefaultLineItems/>\n_INDENT__INDENT_</abl:LineTypes>\n_INDENT_</abl:Technology>\n</abl:ReferencedTechnology>'
    # _ads_schem_tech_lines = _ads_schem_tech.replace('_INDENT_', ' '*indentAmt).split('\n')
    # for line in _ads_schem_tech_lines:
    #     print(indent + line, file=fp)
    # indent = indent[:-indentAmt]

    # # end printing referenced technologies
    # print(indent + '</abl:ReferencedTechnologies>', file=fp)

    # print technology units
    _ads_tech_units = '<abl:TechUnits>\n_INDENT_<abl:SchematicUnits oaUserUnits="inch" userUnits="in" DBUperUU="160"/>\n_INDENT_<abl:SymbolUnits oaUserUnits="inch" userUnits="in" DBUperUU="160"/>\n_INDENT_<abl:LayoutUnits oaUserUnits="micron" userUnits="um" DBUperUU="1000"/>\n_INDENT_<abl:DefaultManufacturingGrid manufacturingGrid="0"/>\n</abl:TechUnits>'
    _ads_tech_units_lines = _ads_tech_units.replace('_INDENT_', ' '*indentAmt).split('\n')
    for line in _ads_tech_units_lines:
        print(indent + line, file=fp)

    # print layer definitions

    print(indent + '<abl:Layers>', file=fp)
    indent += ' '*indentAmt

    for layer in layers:

        layerNumStr = str(get_ads_layer_number(layer.gds))
        bindings = [layer.name.lower()]

        # don't print a binding for a layer that is bound to every layer in the stack
        # this is used to determine a "Connect_All" rule in the AWR configuration, which has no analog in ADS
        if not len(layer.binding) == len(layers) - len(defaults._default_ads_layers):
            for bind in layer.binding:
                bindings.append(bind.name.lower())

        print(indent + '<abl:Layer processRole="Conductor" manufacturingGrid="0" number="{}" name="{}">'.format(layerNumStr, layer.name), file=fp)

        indent += ' '*indentAmt
        print(indent + '<abl:Bindings>', file=fp)

        indent += ' '*indentAmt

        for binding in bindings:
            print(indent + '<abl:BoundLayer name="{}"/>'.format(binding), file=fp)

        indent = indent[:-indentAmt]

        print(indent + '</abl:Bindings>', file=fp)

        indent = indent[:-indentAmt]

        print(indent + '</abl:Layer>', file=fp)

    indent = indent[:-indentAmt]
    print(indent + '</abl:Layers>', file=fp)

    # print reserved purposes
    _ads_reserved_purposes = '<abl:ReservedPurposes>\n_INDENT_<abl:Purpose number="-1" type="drawing" name="drawing"/>\n_INDENT_<abl:Purpose number="-2" type="fill" name="fill"/>\n_INDENT_<abl:Purpose number="-3" type="slot" name="slot"/>\n_INDENT_<abl:Purpose number="-4" type="OPCSerif" name="OPCSerif"/>\n_INDENT_<abl:Purpose number="-5" type="OPCAntiSerif" name="OPCAntiSerif"/>\n_INDENT_<abl:Purpose number="-6" type="annotation" name="annotation"/>\n_INDENT_<abl:Purpose number="-7" type="gapFill" name="gapFill"/>\n_INDENT_<abl:Purpose number="-8" type="redundant" name="redundant"/>\n_INDENT_<abl:Purpose number="-9" type="oaAny" name="oaAny"/>\n_INDENT_<abl:Purpose number="-10" type="oaNo" name="oaNo"/>\n_INDENT_<abl:Purpose number="-11" type="oaFillOPC" name="oaFillOPC"/>\n_INDENT_<abl:Purpose number="-12" type="oaCustomFill" name="oaCustomFill"/>\n</abl:ReservedPurposes>'
    _ads_reserved_purposes_lines = _ads_reserved_purposes.replace('_INDENT_', ' '*indentAmt).split('\n')
    for line in _ads_reserved_purposes_lines:
        print(indent + line, file=fp)

    # print layer display properties

    print(indent + '<abl:DisplayProperties>', file=fp)

    indent += ' '*indentAmt
    for layer in layers:

        # determine layer visibility string
        if layer.visible:
            visString = '"true"'
        else:
            visString = '"false"'

        # determine layer color strings
        # force pure black to draw as white instead
        if layer.color == int(wx.Colour(0, 0, 0).GetRGB()):
            color = int(wx.Colour(255, 255, 255).GetRGB())
        else:
            color = convert_BGR_to_RGB(layer.color)

        redString = '"{:<3d}"'.format(get_red_from_RGB(color))
        greenString = '"{:<3d}"'.format(get_green_from_RGB(color))
        blueString = '"{:<3d}"'.format(get_blue_from_RGB(color))

        alphaString = '"{:<3d}"'.format(255 - layer.alpha)

        # determine layer linestyle string
        if not layer.style == LineStyle.NoLine:
            styleString = '"{}"'.format(get_ads_linestyle_string(layer.style))
        else:
            styleString = '"{}"'.format(get_ads_linestyle_string(LineStyle.NoLine))

        # determine layer pattern string
        if layer.pattern is not None:
            fillString = '"{}"'.format(str(defaults._default_patterns.index(layer.pattern) - 1))
        else:
            fillString = '"0"'

        # determine layer name string
        nameString = '"{}"'.format(layer.name)

        # determine plot mode
        if not layer.style == LineStyle.NoLine and (not layer.pattern == defaults._default_patterns[0] and not layer.pattern is None):
            modeString = '"Both"'
        elif layer.style == LineStyle.NoLine:
            modeString = '"Filled"'
        elif layer.pattern == defaults._default_patterns[0] or layer.pattern is None:
            modeString = '"Outlined"'

        # print layer configuration
        print(indent + '<abl:DisplayProperty purpose="drawing" ', end='', file=fp)
        print('displayMode={:<11}'.format(modeString), end='', file=fp)
        print('lineType={:<16}'.format(styleString), end='', file=fp)
        print('fillType={:<6}'.format(fillString), end='', file=fp)
        print('visible={:<8}'.format(visString), end='', file=fp)
        print('protected="false" ', end='', file=fp)
        print('r={:<6}'.format(redString), end='', file=fp)
        print('g={:<6}'.format(greenString), end='', file=fp)
        print('b={:<6}'.format(blueString), end='', file=fp)
        print('alpha={:<3} '.format(alphaString), end='', file=fp)
        print('layer={}'.format(nameString), end='', file=fp)
        print('/>', file=fp)

    indent = indent[:-indentAmt]
    print(indent + '</abl:DisplayProperties>', file=fp)

    # print layer display order

    print(indent + '<abl:DisplayOrder currentLayerNumber="0" currentPurposeNumber="-1" reverseOrder="false">', file=fp)

    indent += ' '*indentAmt
    for layer in layers:
        print(indent + '<abl:LayerID layerNumber="' + (str(get_ads_layer_number(layer.gds)) + '"').ljust(6) + 'purposeNumber="-1"/>', file=fp)
    indent = indent[:-indentAmt]
    print(indent + '</abl:DisplayOrder>', file=fp)

    if substrates is not None:
        # print materials
        all_mats = [ ]
        for sub in substrates:
            for mat in sub.AllMaterials:
                if mat not in all_mats:
                    all_mats.append(mat)

        print(indent + '<abl:Materials>', file=fp)

        conductors = [x for x in all_mats if x.MatType == material.MaterialType.CONDUCTOR]
        dielectrics = [x for x in all_mats if x.MatType == material.MaterialType.DIELECTRIC]
        semiconductors = [x for x in all_mats if x.MatType == material.MaterialType.SEMICONDUCTOR]

        indent += ' '*indentAmt

        # print conductors section
        print(indent + '<abl:Conductors>', file=fp)

        indent += ' '*indentAmt
        for mat in conductors:
            nameStr = '"{}"'.format(mat.Name)
            if mat.CondType == material.ConductorType.BULK:
                parmTypeStr = '"Conductivity"'
                realStr = '"{:g} Siemens/m"'.format(mat.CondReal)
                imagStr = '""'
            elif mat.CondType == material.ConductorType.SHEET:
                parmTypeStr = '"Resistance"'
                realStr = '"{:g} Ohm/Sq"'.format(mat.CondReal)
                if mat.CondImag:
                    imagStr = '"{:g} Ohm/Sq"'.format(mat.CondImag)
                else:
                    imagStr = '""'
            murRealStr = '"1"'
            murImagStr = '""'

            print(indent + '<abl:Conductor     '.format(parmTypeStr), end='', file=fp)
            print('name={:<25}'.format(nameStr), end='', file=fp)
            print('muRel_real={:<15}'.format(murRealStr), end='', file=fp)
            print('muRel_imag={:<15}'.format(murImagStr), end='', file=fp)
            print('conductivitySpecifiedAs={:<15}'.format(parmTypeStr), end='', file=fp)
            print('real={:<25}'.format(realStr), end='', file=fp)
            print('imag={:<25}'.format(imagStr), end='', file=fp)
            print('/>', file=fp)

        indent = indent[:-indentAmt]
        print(indent + '</abl:Conductors>', file=fp)

        # print dielectrics section
        print(indent + '<abl:Dielectrics>', file=fp)

        indent += ' '*indentAmt
        for mat in dielectrics:
            nameStr = '"{}"'.format(mat.Name)

            # ignore anisotropy and use x-directed values
            if isinstance(mat.Epsilon, tuple):
                eps = mat.Epsilon[0]
            else:
                eps = mat.Epsilon
            errealStr = '"{:g}"'.format(eps)

            if isinstance(mat.Mu, tuple):
                mu = mat.Mu[0]
            else:
                mu = mat.Mu
            murrealStr = '"{:g}"'.format(mu)

            if isinstance(mat.TanD, tuple):
                tand = mat.TanD[0]
            else:
                tand = mat.TanD
            erlossStr = '"{:g}"'.format(tand)

            murImagStr = '""'

            print(indent + '<abl:Dielectric    ', end='', file=fp)
            print('name={:<25}'.format(nameStr), end='', file=fp)
            print('muRel_real={:<15}'.format(murrealStr), end='', file=fp)
            print('muRel_imag={:<15}'.format(murImagStr), end='', file=fp)
            print('epsRel_real={:<15}'.format(errealStr), end='', file=fp)
            print('epsRel_imag={:<15}'.format(errealStr), end='', file=fp)
            print('lossTangent={:<15}'.format(erlossStr), end='', file=fp)
            print('lossModel="Frequency Independent" lowFreq="1 KHz" lossTangentFreq="1 GHz" highFreq="1THz"', end='', file=fp)
            print('/>', file=fp)

        indent = indent[:-indentAmt]
        print(indent + '</abl:Dielectrics>', file=fp)

        # print semiconductors section
        print(indent + '<abl:Semiconductors>', file=fp)

        indent += ' '*indentAmt
        for mat in semiconductors:
            nameStr = '"{}"'.format(mat.Name)

            # convert bulk conductivity of S/m into Ohm.cm
            resistivityStr = '"{:g} Ohm.cm"'.format(1/(mat.CondReal/100))

            # ignore anisotropy and use x-directed values
            if isinstance(mat.Epsilon, tuple):
                eps = mat.Epsilon[0]
            else:
                eps = mat.Epsilon
            errealStr = '"{:g}"'.format(eps)

            if isinstance(mat.Mu, tuple):
                mu = mat.Mu[0]
            else:
                mu = mat.Mu
            murrealStr = '"{:g}"'.format(mu)

            # ADS currently doesn't support loss tangent + resistivity for semiconductors
            #if isinstance(mat.TanD, tuple):
            #    tand = mat.TanD[0]
            #else:
            #    tand = mat.TanD
            #erlossStr = '{:g}'.format(tand)

            murImagStr = '"0"'

            print(indent + '<abl:Semiconductor ', end='', file=fp)
            print('name={:<25}'.format(nameStr), end='', file=fp)
            print('muRel_real={:<15}'.format(murrealStr), end='', file=fp)
            print('muRel_imag={:<15}'.format(murImagStr), end='', file=fp)
            print('epsRel_real={:<15}'.format(errealStr), end='', file=fp)
            print('resistivity={:<25}'.format(resistivityStr), end='', file=fp)
            print('/>', file=fp)

        indent = indent[:-indentAmt]
        print(indent+ '</abl:Semiconductors>', file=fp)

        indent = indent[:-indentAmt]
        print(indent + '</abl:Materials>', file=fp)

        # print substrates
        print(indent + '<abl:Substrates>', file=fp)

        indent += ' '*indentAmt
        idx = 0
        idxStr = '"{:d}"'.format(idx)
        for sub in substrates:

            print(indent + '<abl:Substrate name="{}">'.format(sub.Name), file=fp)

            indent += ' '*indentAmt

            print(indent + '<abl:SubStack bal_type="NONE" bal_num="{:d}">'.format(len(sub.DielectricLayers) + 3), file=fp)

            # print dielectric layers from bottom up
            indent += ' '*indentAmt
            print(indent + '<abl:SubMaterial  id={:<4} thick="1000"   thickunit="micron" bal_type="INHERIT" bal_num="0" materialname="AIR"                                   />'.format(idxStr), file=fp)
            print(indent + '<abl:SubInterface id={:<4} thick="0"      thickunit="micron" bal_type="NONE"    bal_num="0" materialname="PERFECT_CONDUCTOR"      termination="0" groundplane="1"/>'.format(idxStr), file=fp)

            # print dielectric layers section
            for layer in sub.DielectricLayers:
                idx += 1
                idxStr = '"{:d}"'.format(idx)
                thickStr = '"{:g}"'.format(layer['Thickness']*1e6)
                thickUnitStr = '"micron"'
                bal_typeStr = '"INHERIT"'
                bal_numStr = '"0"'
                materialnameStr = '"{}"'.format(layer['Material'].Name)
                matArgs = [idxStr, thickStr, thickUnitStr, bal_typeStr, bal_numStr, materialnameStr]

                print(indent + '<abl:SubMaterial  id={:<4} thick={:<8} thickunit={:<8} bal_type={:<9} bal_num={:<3} materialname={:<40}/>'.format(*matArgs), file=fp)
                print(indent + '<abl:SubInterface id={:<4} thick=""       thickunit="micron" bal_type="NONE"    bal_num="0" materialname=""                       termination="0"/>'.format(idxStr), file=fp)

            idxStr = '"{:d}"'.format(idx + 1)
            print(indent + '<abl:SubMaterial  id={:<4} thick="1000"   thickunit="micron" bal_type="INHERIT" bal_num="0" materialname="AIR" />'.format(idxStr), file=fp)

            indent = indent[:-indentAmt]
            print(indent + '</abl:SubStack>', file=fp)

            # print mapped layers section
            print(indent + '<abl:SubLayers>', file=fp)

            indent += ' '*indentAmt

            for key, val in sub.MappedLayers.iteritems():
                if val['Extent'] is None:
                    layer = layers[layernames.index(key)]
                    materialnameStr = '"{}"'.format(val['Material'].Name)
                    if val['Thickness'] is not None:
                        thickStr = '"{:g}"'.format(val['Thickness']*1e6)
                    else:
                        thickStr = '"0.1"'
                    layerStr = '"{:d}"'.format(get_ads_layer_number(layer.gds))
                    indexStr = '"{:d}"'.format(val['Index'] + 1)
                    layerArgs = [thickStr, thickUnitStr, indexStr, layerStr, materialnameStr]

                    print(indent + '<abl:SubLayer thick={:<8} thickunit={:<8} index={:4} layer={:<5} materialname={:<25} angle="90" subtype="0" sheet="1" precedence="0" pinsOnly="0" negative="0" expand="0" toprough="" bottomrough=""/>'.format(*layerArgs), file=fp)

            indent = indent[:-indentAmt]
            print(indent + '</abl:SubLayers>', file=fp)

            # print mapped vias section

            print(indent + '<abl:SubVias>', file=fp)

            indent += ' '*indentAmt

            for key, val in sub.MappedLayers.iteritems():
                if val['Extent'] is not None:
                    layer = layers[layernames.index(key)]
                    materialnameStr = '"{}"'.format(val['Material'].Name)
                    if val['Thickness'] is not None:
                        thickStr = '"{:g}"'.format(val['Thickness']*1e6)
                    else:
                        thickStr = '"0.1"'
                    layerStr = '"{:d}"'.format(get_ads_layer_number(layer.gds))

                    # bottom index of via is index1
                    index1Str = '"{:d}"'.format(val['Index'] + 1 - val['Extent'])
                    # top index of via is index2
                    index2Str = '"{:d}"'.format(val['Index'] + 1)

                    viaArgs = [layerStr, index1Str, index2Str, materialnameStr]

                    # abl import doesn't currently support plated vias, it seems
                    print(indent + '<abl:SubVia layer={:<5} index1={:4} index2={:4} materialname={:<25} subtype="0"  precedence="0" rough=""/>'.format(*viaArgs), file=fp)

            indent = indent[:-indentAmt]
            print(indent + '</abl:SubVias>', file=fp)

            indent = indent[:-indentAmt]
            print(indent + '</abl:Substrate>', file=fp)

        indent = indent[:-indentAmt]
        print(indent + '</abl:Substrates>', file=fp)
    indent = indent[:-indentAmt]

    # print via definitions and linetypes section

    _ads_vialines = '_INDENT_<abl:ViaDefinitions/>\n_INDENT_<abl:LineTypes>\n_INDENT__INDENT_<abl:LineItems/>\n_INDENT__INDENT_<abl:DefaultLineItems/>\n_INDENT_</abl:LineTypes>'
    _ads_vialines_lines = _ads_vialines.replace('_INDENT_', ' '*indentAmt).split('\n')
    for line in _ads_vialines_lines:
        print(indent + line, file=fp)

    # close off file
    print(indent + '</abl:Technology>', file=fp)

    indent = indent[:-indentAmt]
    print(indent + '</abl:Library>', file=fp)

    indent = indent[:-indentAmt]
    print(indent + '</abl:ABLRoot>', file=fp)

def write_ads_layout_lay(fp, layers):
    """
    Writes an ADS layout.lay file for a given list of layers

    Arguments:

    fp - valid handle to output file to write
    layers - list of Layer objects
    """

    # print header
    print('CurrentLayer number = 0', file=fp)

    for layer in layers:
        name = layer.name
        numStr = 'number = ' + str(get_ads_layer_number(layer.gds))
        streamStr = 'stream = ' + str(layer.gds)
        igesStr = 'iges = ' + str(layer.gds)
        alphaStr = 'trans = ' + str(int((layer.alpha/255)*100))

        # force pure black to draw as white instead
        if layer.color == int(wx.Colour(0, 0, 0).GetRGB()):
            color = int(wx.Colour(255, 255, 255).GetRGB())
        else:
            color = layer.color

        # check to see if the color is in the default list, otherwise make it white
        if color in defaults._default_colors_bgr:
            colorIdx = str(defaults._default_colors_bgr.index(color))
        else:
            colorIdx = '8'

        if not layer.style == LineStyle.NoLine:
            style = str(get_ads_linestyle(layer.style))
        else:
            style = '0'

        if layer.pattern is not None:
            fill_index = str(defaults._default_patterns.index(layer.pattern) - 1)
        else:
            fill_index = '0'

        if layer.visible:
            vis = '1'
        else:
            vis = '0'

        print(name                      .ljust(18)  , end='', file=fp)
        print(numStr                    .ljust(15)  , end='', file=fp)
        print(streamStr                 .ljust(15)  , end='', file=fp)
        print(igesStr                   .ljust(15)  , end='', file=fp)
        print(('color = ' + colorIdx)   .ljust(12)  , end='', file=fp)
        print(('fill = ' + fill_index)  .ljust(12)  , end='', file=fp)
        print(('line = ' + style)       .ljust(9)  , end='', file=fp)
        print(', ', end='', file=fp)

        # determine and write plot mode
        if not layer.style is None and (layer.pattern not in [None, layer.pattern == defaults._default_patterns[0]]):
            print('2 ', end='', file=fp)
        elif layer.style in [None, LineStyle.NoLine]:
            print('1 ', end='', file=fp)
        elif layer.pattern in [None, defaults._default_patterns[0]]:
            print('0 ', end='', file=fp)

        print('0 ', end='', file=fp)        # protect flag
        print(vis + ', ', end='', file=fp)  # visible flag

        bindStr = '"' + layer.name.lower()

        # don't print a binding for a layer that is bound to every layer in the stack
        # this is used to determine a "Connect_All" rule in the AWR configuration, which has no analog in ADS
        if not len(layer.binding) == len(layers):
            for bind in layer.binding:
                bindStr = bindStr + ' ' + bind.name.lower()

        bindStr = bindStr + '"'

        print(bindStr.ljust(50), end=', ', file=fp)
        print('type = 1, dxf = ', end='', file=fp)

        dxfStr = '"' + layer.name.lower() + '"'

        print(dxfStr.ljust(26), end='', file=fp)
        print(alphaStr, file=fp)

def read_ads_layout_lay(fp):
    """
    Reads an ADS layout.lay file into a layer configuration

    Arguments:

    fp - valid handle to file to be read from
    """

    raw_layers = [ ]
    lines = fp.readlines()
    for line in lines:

        # skip the first line
        if re.match('CurrentLayer', line):
            continue

        # skip all hardcoded ADS layers (see defaults list)
        if re.match('|'.join([x.name for x in defaults._default_ads_layers]), line):
            continue

        # skip any line breaks
        if line == '\r\n' or line == '\n':
            continue

        # assuming any other line is a layer line
        else:
            name = re.search(r'(\w+)\s*number', line).groups()[0]
            gds = int(re.search(r'stream\s*=\s*(\d*)', line).groups()[0])
            color_idx = int(re.search(r'color\s*=\s*(\d*)', line).groups()[0])
            fill_idx = int(re.search(r'fill\s*=\s*(\d+)', line).groups()[0])
            line_idx = int(re.search(r'line\s*=\s*(\d+)', line).groups()[0])
            plotmode_idx = int(re.search(r',\s*(\d) \d \d,', line).groups()[0])
            visible = int(re.search(r',\s*\d \d (\d),', line).groups()[0]) == 1
            binding_str = re.search(r',\s*"(.*)"\s*,', line).groups()[0]
            alpha = int(int(re.search(r'trans\s*=\s*(\d*)', line).groups()[0])*0.01*255)

            # get color and pattern from defaults
            color = defaults._default_colors_bgr[color_idx]

            _linestyle_map = [LineStyle.Solid, LineStyle.Dotted, LineStyle.Dotted, LineStyle.Dashed, LineStyle.DashDot, LineStyle.Dashed, LineStyle.DashDot]

            # determine and write plot mode
            # 2 - both
            if plotmode_idx == 2:
                pattern = defaults._default_patterns[fill_idx + 1]
                style = _linestyle_map[line_idx]
            # 1 - filled only
            elif plotmode_idx == 1:
                pattern = defaults._default_patterns[fill_idx + 1]
                style = _linestyle_map[line_idx]
            # 0 - outlined only
            elif plotmode_idx == 0:
                pattern = defaults._default_patterns[0]
                style = _linestyle_map[line_idx]

            # create layer object
            layer = Layer(name=name, gds=gds, color=color, alpha=alpha, pattern=pattern, style=style, visible=visible, cloak=False)

            # insert layer object along with binding string into raw list
            raw_layers.append((layer, binding_str))

    layer_names = [x[0].name for x in raw_layers]
    for layer, bind_str in raw_layers:
        if bind_str == '*':
            layer.binding = [x[0] for x in raw_layers]
        else:
            bindings = bind_str.split()
            if bindings:
                for binding in bindings:
                    try:
                        layer.binding.append(raw_layers[layer_names.index(binding)][0])
                    except ValueError:
                        pass # skip this binding if it's not in the layers list

    layers = [x[0] for x in raw_layers]
    return list(reversed(layers))

def write_ads_color_file(fp, colors):
    """
    Writes an ADS color index file (a. la. hpeecolor.cfg)

    Arguments:

    fp - valid handle to file to be written to
    colors - list of RGB tuples (red, green, blue)
    """
    print('# red'.ljust(8), end='', file=fp)
    print('green'.ljust(6), end='', file=fp)
    print('blue'.ljust(6), end='', file=fp)
    print(': ', end='', file=fp)
    print('name'.ljust(12), end='', file=fp)
    print(': ', end='', file=fp)
    print('index', end='', file=fp)

    print('', file=fp)

    idx = 0
    for (red, green, blue) in colors:
        redStr = str(red).ljust(6)
        grnStr = str(green).ljust(6)
        bluStr = str(blue).ljust(6)
        nameStr = ('Color ' + str(idx)).ljust(12)
        idxStr = str(idx)

        print('  ' + redStr + grnStr + bluStr + ': ' + nameStr + ': ' + idxStr, file=fp)
        idx += 1

    print('', file=fp)

def write_ads_pattern_index_file(fp, patterns):
    """
    Writes an ADS fill index file (a. la. hpeefill.cfg)

    Arguments:

    fp - valid handle to file to be written to
    patterns - list of Pattern objects
    """

    # default HPGL/2 plotter string, should be unused
    # 2 - solid unidirectional fill, 0 - 0 point spacing, 45 - 45deg angle
    HPGL2Str = '2 0 45'

    for pattern in patterns:
        string = '/de/fill_patterns/' + pattern.name + '.pattern'
        print(string.ljust(75) + ': ' + HPGL2Str, file=fp)

def write_ads_library_tech_file(fp, layers):
    """
    Writes an ADS library.tech file for a given list of layers and visibilities

    Arguments:

    fp - valid handle to output file to write
    layers - list of Layer objects
    """

    # print header
    print('<!DOCTYPE Technology>', file=fp)
    print('<Lpp_List>', file=fp)

    for layer in layers:

        # determine layer visibility string
        if layer.visible:
            visString = 'visible="1"'
        else:
            visString = 'visible="0"'

        # determine layer color string

        # force pure black to draw as white instead
        if layer.color == int(wx.Colour(0, 0, 0).GetRGB()):
            color = int(wx.Colour(255, 255, 255).GetRGB())
        else:
            color = convert_BGR_to_RGB(layer.color)

        colorString = 'rgb="' + str(color) + '"'

        alphaString = 'alpha="' + str(255 - layer.alpha) + '"'

        # determine layer linestyle string
        if not layer.style == LineStyle.NoLine:
            styleString = 'line="' + str(get_ads_linestyle(layer.style)) + '"'
        else:
            styleString = 'line="0"'

        # determine layer pattern string
        if layer.pattern is not None:
            fillString = 'fill="' + str(defaults._default_patterns.index(layer.pattern) - 1) + '"'
        else:
            fillString = 'fill="-1"'

        # determine layer name string
        nameString = 'layer="' + layer.name + '"'

        # determine plot mode
        if not layer.style == LineStyle.NoLine and (not layer.pattern == defaults._default_patterns[0] and not layer.pattern is None):
            modeString = 'mode="2"/>'
        elif layer.style == LineStyle.NoLine:
            modeString = 'mode="1"/>'
        elif layer.pattern == defaults._default_patterns[0] or layer.pattern is None:
            modeString = 'mode="0"/>'

        # print layer configuration
        print('\t<LPP purpose="drawing"'    , end=' ', file=fp)
        print(visString                     .ljust(12), end='', file=fp)
        print(colorString                   .ljust(15), end='', file=fp)
        print(styleString                   .ljust(9),  end='', file=fp)
        print('protect="0"'                 .ljust(12), end='', file=fp)
        print(alphaString                   .ljust(12), end='', file=fp)
        print(fillString                    .ljust(10), end='', file=fp)
        print(nameString                    .ljust(25), end='', file=fp)
        print(modeString                    .ljust(10), file=fp)

    # print footer
    print('</Lpp_List>', file=fp)

def write_ads_display_tech_file(fp, layers):
    """
    Writes an ADS display.tech file for a given list of layers

    Arguments:

    fp - valid handle to output file to write
    layers - list of Layer objects
    """

    # print file header and default layer
    print('<!DOCTYPE Display>', file=fp)
    print('<Display>', file=fp)
    print('\t<Lpp_Display_Order order="0">', file=fp)

    # print process layers
    for layer in layers:
        print('\t\t<LPP name="' + layer.name + ':drawing"/>', file=fp)

    # print footer
    print('\t</Lpp_Display_Order>', file=fp)
    print('\t<Current_Lpp name="default:drawing"/>', file=fp)
    print('</Display>', file=fp)

def write_ads_create_tech_ael(fp, layers):
    """
    Writes an ael script that will create a technology for the process

    Arguments:

    fp - valid handle to the output file to write
    layers - list of Layer objects
    """

    kitNameStr = 'LIBRARY_NAME'

    # write header
    print('decl ' + kitNameStr + ' = designKitRecord[0];', file=fp)
    print('fputs(stderr, strcat("Creating ", ' + kitNameStr + ', " technology..."));\n', file=fp)

    # check if technology exists and create it if necessary
    print('if(!tech_technology_exists(' + kitNameStr + '))', file=fp)
    print('    tech_create_technology(' + kitNameStr + ');', file=fp)

    # open the technology in (over)write mode
    print('tech_open_technology(' + kitNameStr + ', "w");', file=fp)

    # write units, resolution, include ads_schematic_layers
    print('tech_set_layout_units(' + kitNameStr + ', "micron");', file=fp)
    print('tech_set_layout_resolution(' + kitNameStr + ', 1000);', file=fp)
    print('tech_set_libraries_used_by_technology(' + kitNameStr + ', list("ads_schematic_layers"));\n', file=fp)

    # write layer configuration
    for layer in layers:

        layerNameStr = '"' + layer.name + '"'
        layerNumStr = str(get_ads_layer_number(layer.gds))

        layerGDSStr = str(layer.gds)

        bindStr = '"' + layer.name.lower()

        # don't print a binding for a layer that is bound to every layer in the stack
        # this is used to determine a "Connect_All" rule in the AWR configuration, which has no analog in ADS
        if not len(layer.binding) == len(layers):
            for bind in layer.binding:
                bindStr = bindStr + ' ' + bind.name.lower()

        bindStr = bindStr + '"'

        # create physical layer
        print('tech_create_physical_layer('.ljust(27), end='', file=fp)
        print(kitNameStr,  end=', ', file=fp)                       # kit name
        print(layerNameStr.ljust(25), end=', ', file=fp)            # layer name
        print(layerNumStr   .ljust(4), end=', ', file=fp)           # layer number
        print(layerGDSStr   .ljust(4), end=', ',  file=fp)          # mask number
        print('PROCESS_ROLE_CONDUCTOR'.ljust(38), end='', file=fp)  # process role
        print(');', file=fp)

        # set layer binding
        print('tech_set_layer_binding('.ljust(27), end='', file=fp)
        print(kitNameStr    , end=', ', file=fp)            # kit name
        print(layerNameStr.ljust(25)  , end=', ', file=fp)  # layer name
        print(bindStr.ljust(50), end='', file=fp)           # layer binding
        print(');\n', file=fp)

    print('tech_save_technology(' + kitNameStr + ');', file=fp)

def write_ads_layer_map_file(fp, layers):
    """
    Writes an ADS layer map file for GDS export

    Arguments:
    fp - valid handle to the output file to write
    layers - list of Layer objects
    """

    print('# Layer'.ljust(25) + 'Purpose'.ljust(8) + 'GDSLayer'.ljust(9) + 'GDSPurpose', file=fp)

    for layer in layers:
        print(layer.name.ljust(25) + 'drawing '.ljust(8) + str(layer.gds).ljust(9) + '0', file=fp)

def write_klayout_layer_prefs_file(filepath, layers):
    """
    Writes a KLayout layer preference file

    Arguments:
    filepath - path to write the configuration to
    layers - list of Layer objects
    """

    patterns = []
    for layer in layers:
        if not layer.pattern in patterns and layer.pattern is not None:
            patterns.append(layer.pattern)

    # create directory if necessary
    if not os.path.exists(os.path.dirname(filepath)):
        os.makedirs(os.path.dirname(filepath))

    with open(filepath, 'wb') as fp:
        # print xml header
        print('<?xml version="1.0" encoding="utf-8"?>', file=fp)
        print('<layer-properties-tabs>', file=fp)
        print(' <layer-properties>', file=fp)

        # determine default visibility (hide EM layers, show layout layers)
        vis_list = []
        for i in range(0, len(layers)):
            if layers[i].name[0:3] == 'EM_':
                vis_list.append(False)
            else:
                vis_list.append(True)

        # print layer preferences
        for (layer, visible) in zip(layers, vis_list):

            # determine layer visibility string
            if visible:
                visString = 'true'
            else:
                visString = 'false'

            # determine layer color string

            # force pure white to draw as black instead
            if layer.color == int(wx.Colour(255, 255, 255).GetRGB()):
                color = int(wx.Colour(0, 0, 0).GetRGB())
            else:
                color = convert_BGR_to_RGB(layer.color)

            colorString = '#' + convert_RGB_to_hex(color)

            # determine layer linestyle string
            if layer.style is not None:
                styleString = '1'       # no dashed lines, use a 1px line for everything
            else:
                styleString = '0'       # if no outline, set to 0px

            # determine layer pattern string
            if layer.pattern is not None:
                fillString = 'C' + str(patterns.index(layer.pattern))
            else:
                fillString = 'I1'   # 'I1' is a no-fill

            # determine layer name string
            nameString = 'layer="' + layer.name + '"'

            print('  <properties>', file=fp)
            print('   <frame-color>' + colorString + '</frame-color>', file=fp)
            print('   <fill-color>' + colorString + '</fill-color>', file=fp)
            print('   <frame-brightness>' + '0' + '</frame-brightness>', file=fp)
            print('   <fill-brightness>' + '0' + '</fill-brightness>', file=fp)
            print('   <dither-pattern>' + fillString + '</dither-pattern>', file=fp)
            print('   <valid>' + 'true' + '</valid>', file=fp)
            print('   <visible>' + visString + '</visible>', file=fp)
            print('   <transparent>' + 'true' + '</transparent>', file=fp)
            print('   <width>' + styleString + '</width>', file=fp)
            print('   <marked>' + 'false' + '</marked>', file=fp)
            print('   <animation>' + '0' + '</animation>', file=fp)
            print('   <name>' + layer.name + '</name>', file=fp)
            print('   <source>' + (str(layer.gds) + '/0@1') + '</source>', file=fp)
            print('  </properties>', file=fp)

        print(' <name/>', file=fp)

        idx = 1

        # custom stipple patterns start at index 1 in the pattern section
        for pattern in patterns:
            pattern.print_pattern_klayout_lyp(fp, idx)
            idx += 1

        print(' </layer-properties>', file=fp)
        print('</layer-properties-tabs>', file=fp)

def write_png_for_layers(directory, layers, size, black_bg=True):
    """
    Writes a .png bitmap file depicting each layer to the given directory

    Arguments:
        directory           - string containing absolute path to output directory
        layers              - list of Layer objects
        size                - int depicting the width/length of the output bitmap
        black_bg (optional) - boolean, if true draws image with a black background, otherwise draws with white background
    """

    # initialize wx backend if necessary
    no_frontend = False

    if not wx.GetApp():
        no_frontend = True
        app = wx.App()

    if not os.path.isdir(directory):
        os.makedirs(directory)

    # initialize images
    dc = wx.MemoryDC()

    for layer in layers:

        pattern = layer.pattern
        style = layer.style
        color = layer.color

        # create black image
        mask = wx.Bitmap(wx.Image(pattern.width, pattern.height) if pattern is not None else wx.Image(8, 8))

        if pattern is not None:

            lines = pattern.lines

            # if the layer color is black, change it to white
            if color == 0x000000:
                color = 0xFFFFFF

            # draw pattern
            dc.SelectObject(mask)
            dc.SetPen(wx.Pen(wx.Colour(color)))
            dc.SetLogicalFunction(wx.COPY)

            x = 0
            y = 0

            for line in lines:
                for bit in line:
                    if bit:
                        dc.DrawPoint(x, y)
                    x += 1

                y += 1
                x = 0

            dc.SelectObject(wx.NullBitmap)

        # set the mask color
        mask.SetMaskColour(wx.Colour(0, 0, 0))

        x0 = 0.5*size
        y0 = 0.5*size

        box_size = size*0.75

        image = wx.Image(size, size)

        if not black_bg:
            image.Replace(0, 0, 0, 255, 255, 255)

        out_bmp = wx.Bitmap(image)

        dc.SelectObject(out_bmp)

        brush = wx.Brush('BLACK', style=wx.BRUSHSTYLE_TRANSPARENT)
        dc.SetBrush(brush)

        # black or white layers should draw as the opposite of the canvas
        if color in [0x000000, 0xFFFFFF]:
            function = wx.INVERT
        # all other colors draw as chosen
        else:
            function = wx.COPY
        dc.SetLogicalFunction(function)

        pen = wx.Pen(wx.Colour(color), style=get_wx_penstyle(style))
        dc.SetPen(pen)

        dc.DrawRectangle(x0 - 0.5*box_size, y0 - 0.5*box_size, box_size, box_size)

        if pattern is not None:

            width = mask.Width
            height = mask.Height
            dc.SetClippingRegion(x0 - 0.5*box_size, y0 - 0.5*box_size, box_size, box_size)
            for i in range(0, size / width):
                for j in range(0, size / height):
                    dc.Blit(x0 - 0.5*size + width*i, y0 - 0.5*size + height*j, width, height, wx.MemoryDC(mask), 0, 0, logicalFunc=function, useMask=True)
            dc.DestroyClippingRegion()

        dc.SelectObject(wx.NullBitmap)

        # write output file
        out_bmp.SaveFile(os.path.join(directory, layer.name + '.png'), wx.BITMAP_TYPE_PNG)

    dc.Destroy()

    # kill wx.App() if no frontend
    if no_frontend:
        del app