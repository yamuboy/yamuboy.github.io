"""
Replication of Dube & Vargas (2013) "Commodity Price Shocks and Civil Conflict"
Review of Economic Studies, 80(4), 1384-1421.

Python replication of Tables 2-6 using linearmodels.
"""

import pandas as pd
import numpy as np
from linearmodels.iv import IV2SLS
import warnings
warnings.filterwarnings('ignore')

DATA_DIR = "/mnt/user-data/uploads"

def load_violence_data():
    return pd.read_stata(f"{DATA_DIR}/origmun_violence_commodities.dta", convert_categoricals=False)

def load_wages_data():
    return pd.read_stata(f"{DATA_DIR}/origmun_wages_commodities.dta", convert_categoricals=False)

def load_hours_data():
    return pd.read_stata(f"{DATA_DIR}/origmun_hours_commodities.dta", convert_categoricals=False)

def load_migrant_data():
    return pd.read_stata(f"{DATA_DIR}/origmun_migrant_commodities.dta", convert_categoricals=False)

def get_year_dummies(df):
    return [c for c in df.columns if c.startswith('_Yyear_')]

def get_region_trends(df):
    return [c for c in df.columns if c.startswith('_Rregion_') or c.startswith('_RregXyear_')]

def get_origmun_fe(df):
    return [c for c in df.columns if c.startswith('_Oorigmun_')]


def partial_out(df, vars_to_partial, partial_vars):
    """
    Partial out (Frisch-Waugh) a set of variables from another set.
    Returns residualized versions of vars_to_partial.
    """
    df_out = df.copy()
    X_partial = df[partial_vars].values
    # Add constant for the partialling regression
    X_partial_c = np.column_stack([np.ones(len(X_partial)), X_partial])
    
    # Use least squares to partial out
    try:
        Q, R = np.linalg.qr(X_partial_c, mode='reduced')
        for v in vars_to_partial:
            y = df[v].values
            proj = Q @ (Q.T @ y)
            df_out[v] = y - proj
    except:
        # Fallback: use pseudoinverse
        pinv = np.linalg.pinv(X_partial_c)
        for v in vars_to_partial:
            y = df[v].values
            beta = pinv @ y
            df_out[v] = y - X_partial_c @ beta
    
    return df_out


def run_panel_iv_partial(df, depvar, endog, instruments, exog_of_interest,
                         partial_vars=None, fe_var='origmun', cluster_var='department'):
    """
    Run 2SLS IV with entity FE and partialling out of nuisance controls.
    
    Mimics Stata's: xtivreg2 Y X (endog=IV) controls, fe partial(controls) cluster(dept)
    
    Strategy:
    1. Demean everything by entity (within transformation = FE)
    2. Partial out year dummies and region trends from all remaining variables
    3. Run IV2SLS on the residualized data
    """
    # Collect all needed vars
    all_vars = [depvar] + endog + instruments + exog_of_interest + [fe_var, cluster_var]
    if partial_vars:
        all_vars += partial_vars
    all_vars = list(set(all_vars))
    
    df_reg = df.dropna(subset=[v for v in all_vars if v in df.columns]).copy()
    
    # Step 1: Within transformation (demean by entity = municipality FE)
    vars_to_demean = [depvar] + endog + instruments + exog_of_interest
    if partial_vars:
        vars_to_demean += partial_vars
    vars_to_demean = list(set(vars_to_demean))
    
    grouped = df_reg.groupby(fe_var)
    for v in vars_to_demean:
        if v in df_reg.columns:
            df_reg[v] = df_reg[v] - grouped[v].transform('mean')
    
    # Step 2: Partial out nuisance variables (year dummies, region trends, etc.)
    if partial_vars:
        vars_to_residualize = [depvar] + endog + instruments + exog_of_interest
        vars_to_residualize = list(set(vars_to_residualize))
        # Remove any partial_vars from the residualize list
        vars_to_residualize = [v for v in vars_to_residualize if v not in partial_vars]
        
        df_reg = partial_out(df_reg, vars_to_residualize, partial_vars)
    
    # Step 3: Run IV2SLS
    dep = df_reg[depvar]
    
    if endog and instruments:
        endog_df = df_reg[endog]
        instr_df = df_reg[instruments]
        if exog_of_interest:
            exog_df = df_reg[exog_of_interest]
            mod = IV2SLS(dep, exog_df, endog_df, instr_df)
        else:
            mod = IV2SLS(dep, None, endog_df, instr_df)
    else:
        exog_df = df_reg[exog_of_interest + endog]
        mod = IV2SLS(dep, exog_df, None, None)
    
    res = mod.fit(cov_type='clustered', clusters=df_reg[cluster_var])
    return res, len(df_reg)


def run_individual_iv(df, depvar, endog, instruments, exog_of_interest,
                      partial_vars=None, cluster_var='department', weight_var=None):
    """
    Run IV2SLS for individual-level data (wages, hours, migration).
    Uses origmun dummies as FE (already in data as _Oorigmun_*), partialled out.
    """
    all_vars = [depvar] + endog + instruments + exog_of_interest + [cluster_var]
    if partial_vars:
        all_vars += partial_vars
    if weight_var:
        all_vars += [weight_var]
    all_vars = list(set(all_vars))
    
    df_reg = df.dropna(subset=[v for v in all_vars if v in df.columns]).copy()
    
    # Partial out nuisance variables
    if partial_vars:
        vars_to_residualize = [depvar] + endog + instruments + exog_of_interest
        vars_to_residualize = list(set(vars_to_residualize))
        vars_to_residualize = [v for v in vars_to_residualize if v not in partial_vars]
        df_reg = partial_out(df_reg, vars_to_residualize, partial_vars)
    
    dep = df_reg[depvar]
    endog_df = df_reg[endog]
    instr_df = df_reg[instruments]
    exog_df = df_reg[exog_of_interest] if exog_of_interest else None
    
    mod = IV2SLS(dep, exog_df, endog_df, instr_df)
    
    if weight_var and weight_var in df_reg.columns:
        res = mod.fit(cov_type='clustered', clusters=df_reg[cluster_var])
    else:
        res = mod.fit(cov_type='clustered', clusters=df_reg[cluster_var])
    
    return res, len(df_reg)


def format_coef(res, var):
    """Format coefficient with stars and SE."""
    if var in res.params.index:
        coef = res.params[var]
        se = res.std_errors[var]
        pval = res.pvalues[var]
        stars = "***" if pval < 0.01 else "**" if pval < 0.05 else "*" if pval < 0.1 else ""
        return f"{coef:8.3f}{stars:3s}", f"({se:7.3f})"
    return "      N/A", ""


def print_results_table(results_dict, key_vars, dep_labels):
    """Print a formatted results table."""
    ncols = len(dep_labels)
    
    # Header
    header = f"{'':40s}"
    for i, lab in enumerate(dep_labels):
        header += f"  {f'({i+1})':>13s}"
    print(header)
    header2 = f"{'':40s}"
    for lab in dep_labels:
        header2 += f"  {lab[:13]:>13s}"
    print(header2)
    print("-" * (40 + 15 * ncols))
    
    for var in key_vars:
        # Coefficients
        row = f"  {var:38s}"
        for dv in results_dict:
            res, _ = results_dict[dv]
            coef_str, _ = format_coef(res, var)
            row += f"  {coef_str:>13s}"
        print(row)
        # SEs
        row_se = f"  {'':38s}"
        for dv in results_dict:
            res, _ = results_dict[dv]
            _, se_str = format_coef(res, var)
            row_se += f"  {se_str:>13s}"
        print(row_se)
    
    # Observations
    row_n = f"  {'Observations':38s}"
    for dv in results_dict:
        _, nobs = results_dict[dv]
        row_n += f"  {nobs:>13d}"
    print(row_n)


# ============================================================
# TABLE 2
# ============================================================

def replicate_table2():
    print("=" * 80)
    print("TABLE 2: The Effect of the Coffee and Oil Shocks on Violence")
    print("=" * 80)
    
    df = load_violence_data()
    year_dummies = get_year_dummies(df)
    region_trends = get_region_trends(df)
    partial_vars = year_dummies + region_trends + ['coca94indxyear', 'lpop']
    
    depvars = ['gueratt', 'paratt', 'clashes', 'casualties']
    dep_labels = ['Guer. att', 'Para. att', 'Clashes', 'Casualties']
    key_vars = ['cofintxlinternalp', 'oilprod88xlop']
    
    results = {}
    for dv in depvars:
        res, nobs = run_panel_iv_partial(
            df, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop'],
            partial_vars=partial_vars
        )
        results[dv] = (res, nobs)
    
    print_results_table(results, key_vars, dep_labels)
    
    print("\n  Paper reports:")
    print("  Coffee x Price: -0.611**, -0.160***, -0.712***, -1.828*")
    print("  Oil x Price:     0.700,    0.726***,  0.304,     1.526")
    print("  N = 17,604")
    
    return results


# ============================================================
# TABLE 3
# ============================================================

def replicate_table3():
    print("\n\n" + "=" * 80)
    print("TABLE 3: The Opportunity Cost and Rapacity Mechanisms")
    print("=" * 80)
    
    key_vars = ['cofintxlinternalp', 'oilprod88xlop']
    indiv_controls = ['gender', 'age', 'agesq', 'married', 'edyrs']
    
    # Column 1: Log wage
    print("\nColumn (1): Log wage")
    df_w = load_wages_data()
    partial_w = get_year_dummies(df_w) + get_region_trends(df_w) + get_origmun_fe(df_w) + ['coca94indxyear']
    
    res_w, n_w = run_individual_iv(
        df_w, 'lwage',
        endog=['cofintxlinternalp'],
        instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
        exog_of_interest=['oilprod88xlop'] + indiv_controls,
        partial_vars=partial_w
    )
    for v in key_vars:
        c, s = format_coef(res_w, v)
        print(f"  {v:40s}  {c}  {s}")
    print(f"  {'Observations':40s}  {n_w:>8d}")
    
    # Column 2: Log hours
    print("\nColumn (2): Log hours")
    df_h = load_hours_data()
    partial_h = get_year_dummies(df_h) + get_region_trends(df_h) + get_origmun_fe(df_h) + ['coca94indxyear']
    
    res_h, n_h = run_individual_iv(
        df_h, 'lhours',
        endog=['cofintxlinternalp'],
        instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
        exog_of_interest=['oilprod88xlop'] + indiv_controls,
        partial_vars=partial_h
    )
    for v in key_vars:
        c, s = format_coef(res_h, v)
        print(f"  {v:40s}  {c}  {s}")
    print(f"  {'Observations':40s}  {n_h:>8d}")
    
    # Columns 3-5: Panel data outcomes
    df = load_violence_data()
    year_dummies = get_year_dummies(df)
    region_trends = get_region_trends(df)
    partial_vars = year_dummies + region_trends + ['coca94indxyear', 'lpop']
    
    for dv, lab in [('lcaprev', 'Log capital revenue'), 
                    ('parkidpol', 'Para. kidnappings'),
                    ('guerkidpol', 'Guer. kidnappings')]:
        print(f"\n{lab}")
        res, nobs = run_panel_iv_partial(
            df, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop'],
            partial_vars=partial_vars
        )
        for v in key_vars:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")
    
    print("\n  Paper reports:")
    print("  Coffee: 0.371*, 0.286**, -0.787, 0.022, -0.060")
    print("  Oil:    1.230,  0.079,   0.419**, 0.168***, -0.066")


# ============================================================
# TABLE 4
# ============================================================

def replicate_table4():
    print("\n\n" + "=" * 80)
    print("TABLE 4: Alternative Accounts")
    print("=" * 80)
    
    key_vars = ['cofintxlinternalp', 'oilprod88xlop']
    indiv_controls = ['gender', 'age', 'agesq', 'married', 'edyrs']
    
    print("\n--- PANEL A ---")
    
    # Migration
    print("\nMigration")
    df_m = load_migrant_data()
    partial_m = get_year_dummies(df_m) + get_region_trends(df_m) + get_origmun_fe(df_m) + ['coca94indxyear']
    
    res_m, n_m = run_individual_iv(
        df_m, 'migrant',
        endog=['cofintxlinternalp'],
        instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
        exog_of_interest=['oilprod88xlop'] + indiv_controls,
        partial_vars=partial_m
    )
    for v in key_vars:
        c, s = format_coef(res_m, v)
        print(f"  {v:40s}  {c}  {s}")
    print(f"  {'Observations':40s}  {n_m:>8d}")
    
    # Gov attacks, massacres
    df = load_violence_data()
    year_dummies = get_year_dummies(df)
    region_trends = get_region_trends(df)
    partial_vars = year_dummies + region_trends + ['coca94indxyear', 'lpop']
    
    for dv, lab in [('govatt', 'Government attacks'), ('parmass', 'Para. massacres'), 
                    ('guermass', 'Guer. massacres')]:
        print(f"\n{lab}")
        res, nobs = run_panel_iv_partial(
            df, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop'],
            partial_vars=partial_vars
        )
        for v in key_vars:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")
    
    # Panel B: Political Collusion
    print("\n--- PANEL B: Political Collusion ---")
    df_b = df[df['year'] >= 1994].copy()
    key_vars_b = key_vars + ['yrsproparaxoil88xlop', 'yrsproparaxlop']
    
    for dv, lab in [('gueratt', 'Guer. att'), ('paratt', 'Para. att'),
                    ('clashes', 'Clashes'), ('casualties', 'Casualties')]:
        print(f"\n{lab}")
        res, nobs = run_panel_iv_partial(
            df_b, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop', 'yrsproparaxoil88xlop', 'yrsproparaxlop'],
            partial_vars=partial_vars
        )
        for v in key_vars_b:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")


# ============================================================
# TABLE 5
# ============================================================

def replicate_table5():
    print("\n\n" + "=" * 80)
    print("TABLE 5: Accounting for Coca")
    print("=" * 80)
    
    df = load_violence_data()
    year_dummies = get_year_dummies(df)
    region_trends = get_region_trends(df)
    key_vars = ['cofintxlinternalp', 'oilprod88xlop']
    
    # Panel A
    print("\n--- PANEL A: Coca substitution ---")
    partial_a = year_dummies + region_trends + ['lpop']
    
    print("\nCoca (dep var)")
    res, nobs = run_panel_iv_partial(
        df, 'coca',
        endog=['cofintxlinternalp'],
        instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
        exog_of_interest=['oilprod88xlop'],
        partial_vars=partial_a
    )
    for v in key_vars:
        c, s = format_coef(res, v)
        print(f"  {v:40s}  {c}  {s}")
    print(f"  {'Observations':40s}  {nobs:>8d}")
    
    # Violence in coca subsample
    df_coca = df[df['coca'].notna()].copy()
    partial_coca = year_dummies + region_trends + ['coca94indxyear', 'lpop']
    
    for dv in ['gueratt', 'paratt', 'clashes', 'casualties']:
        print(f"\n{dv}")
        res, nobs = run_panel_iv_partial(
            df_coca, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop'],
            partial_vars=partial_coca
        )
        for v in key_vars:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")
    
    # Panel B: coca94 x year interactions
    print("\n--- PANEL B: Coca intensity x year effects ---")
    df_b = df.copy()
    for yd in year_dummies:
        yr = yd.replace('_Yyear_', '')
        df_b[f'coca94x{yr}'] = df_b['coca94'] * df_b[yd]
    coca_yr = [c for c in df_b.columns if c.startswith('coca94x')]
    partial_b = year_dummies + region_trends + ['lpop'] + coca_yr
    
    for dv in ['gueratt', 'paratt', 'clashes', 'casualties']:
        print(f"\n{dv}")
        res, nobs = run_panel_iv_partial(
            df_b, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop'],
            partial_vars=partial_b
        )
        for v in key_vars:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")
    
    # Panel C: Remove coca municipalities
    print("\n--- PANEL C: No coca municipalities ---")
    df_c = df[df['evercoca'] == 0].copy()
    partial_c = year_dummies + region_trends + ['lpop']
    
    for dv in ['gueratt', 'paratt', 'clashes', 'casualties']:
        print(f"\n{dv}")
        res, nobs = run_panel_iv_partial(
            df_c, dv,
            endog=['cofintxlinternalp'],
            instruments=['rxltop3cof', 'txltop3cof', 'rtxltop3cof'],
            exog_of_interest=['oilprod88xlop'],
            partial_vars=partial_c
        )
        for v in key_vars:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")


# ============================================================
# TABLE 6
# ============================================================

def replicate_table6():
    print("\n\n" + "=" * 80)
    print("TABLE 6: Other Natural Resource Price Shocks")
    print("=" * 80)
    
    df = load_violence_data()
    year_dummies = get_year_dummies(df)
    region_trends = get_region_trends(df)
    partial_vars = year_dummies + region_trends + ['coca94indxyear', 'lpop']
    
    key_vars = ['oilprod88xlop', 'coalprod04xlcoalp', 'goldprod04xlgoldp']
    
    for dv, lab in [('gueratt', 'Guer. att'), ('paratt', 'Para. att'),
                    ('clashes', 'Clashes'), ('casualties', 'Casualties')]:
        print(f"\n{lab}")
        res, nobs = run_panel_iv_partial(
            df, dv,
            endog=['coalprod04xlcoalp', 'goldprod04xlgoldp'],
            instruments=['coalres78xltop3coal', 'mining78xlgoldp'],
            exog_of_interest=['oilprod88xlop', 'mining78xlsilverp', 'mining78xlplatp'],
            partial_vars=partial_vars
        )
        for v in key_vars:
            c, s = format_coef(res, v)
            print(f"  {v:40s}  {c}  {s}")
        print(f"  {'Observations':40s}  {nobs:>8d}")
    
    print("\n  Paper: Oil=0.689,0.723***,0.253,1.514 | Coal=0.128*,0.014,0.145**,0.392* | Gold=0.143**,-0.027,0.026,-0.234")


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    print("REPLICATION: Dube & Vargas (2013)")
    print("Commodity Price Shocks and Civil Conflict: Evidence from Colombia")
    print("Review of Economic Studies, 80(4), 1384-1421\n")
    
    replicate_table2()
    replicate_table3()
    replicate_table4()
    replicate_table5()
    replicate_table6()
    
    print("\n\n" + "=" * 80)
    print("NOTES")
    print("=" * 80)
    print("""
- Original uses Stata xtivreg2/ivreg2 with partial() option; this uses
  Python linearmodels IV2SLS with manual within-transformation + QR partialling.
- SEs clustered at department level.
- Small numerical differences expected; qualitative signs/significance should match.
- Key findings to verify:
  * Coffee x Price → NEGATIVE on violence (opportunity cost)
  * Oil x Price → POSITIVE on paramilitary attacks (rapacity)
""")
