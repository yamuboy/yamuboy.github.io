clear matrix
clear mata
clear
capture log close
set matsize 7000
set more off


glo dir "..."  /*directory to recover data*/

glo tab "..." /* directory to store tables*/
cd  "${tab}"


	
***********************************************************
* 	TABLE A.I: Summary Statistics of Additional Variables
***********************************************************

# delimit;
log using "Appendix_descriptive_statistics.log", replace; 

	# delimit;
	clear; 
	use "${dir}\origmun_violence_commodities_for_online_appendix"; 

	*** municipal level
	# delimit;
	univar  pipelen  sugar05 tobacco05  palm05 banana05  if year==1996, dec(3);

	*** annual level
	# delimit;
	univar  lpalmp  lbanp  lsugarp   ltobacp  if origmun==5002, dec(3);

	# delimit cr

cap log close


************************************************
* 	TABLE A.II: Robustness Across Samples
*************************************************

	***  Panel A: Eliminating earthquake-affected municipalities
	# delimit;
	clear;
	use "${dir}\origmun_violence_commodities_for_online_appendix"; 
	
	# delimit; 
	tsset origmun year, yearly; 
		xi: xtivreg2 gueratt    lpop    _Y*          _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof) 
		oilprod88xlop     
		if  earthquake==0 , cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab2a.xls, replace se  bdec(3) tdec(3) nocons nor noni; 

	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*        		_R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		 oilprod88xlop      
		if  earthquake==0 , cluster(department) partial(_R* _Y*)  fe ; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab2a.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 

	***  Panel B: Eliminating DMZ municipalities 
	# delimit; 
	tsset origmun year, yearly; 
		xi: xtivreg2 gueratt    lpop    _Y*          _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof) 
		oilprod88xlop     
		if  dmz==0 , cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab2b.xls, replace se  bdec(3) tdec(3) nocons nor noni; 

	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*        		_R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		 oilprod88xlop      
		if dmz==0  , cluster(department) partial(_R* _Y*)  fe ; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab2b.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 
	

***  Panel C : Eliminating municipalities with changing boundaries
	# delimit;
	clear; 
	use "${dir}\no_split_municipality_violence_commodities_for_online_appendix.dta"; 
	
	# delimit; 
	tsset municipality year, yearly; 
		xi: xtivreg2 gueratt    lpop    _Y*          _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof) 
		oilprod88xlop  
		  , cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop      using  apptab2c.xls, replace se  bdec(3) tdec(3) nocons nor noni; 
		
	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset municipality year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*        		_R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		 oilprod88xlop   
		  , cluster(department) partial(_R* _Y*)  fe ; 
		outreg2  cofintxlinternalp  oilprod88xlop      using  apptab2c.xls, se bdec(3) tdec(3) nocons nor noni; 
	};


************************************************************
* see below for  TABLE A.III code
************************************************************


*********************************************************************************
* TABLE A.IV: The Effect of the Coffee and Oil Shocks Including Oil Pipelines
*********************************************************************************

# delimit; 
	clear; 
	use "${dir}\origmun_violence_commodities_for_online_appendix.dta"; 
	set more off; 
	
	# delimit; 
	tsset origmun year, yearly; 
		xi: xtivreg2 gueratt    lpop    _Y*          _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof) 
		oilprod88xlop pipelenxlop    
		   , cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop      pipelenxlop    using  apptab4.xls, replace se  bdec(3) tdec(3) nocons nor noni; 

	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*        _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		 oilprod88xlop  pipelenxlop    
		   , cluster(department) partial(_R* _Y*)  fe ; 
		outreg2  cofintxlinternalp  oilprod88xlop      pipelenxlop    using  apptab4.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 


*********************************************************************
* TABLE A.V: The Effect of the Coffee, Oil and Coca Shocks on Violence
*********************************************************************

	clear; 
	use "${dir}\origmun_violence_commodities_for_online_appendix.dta"; 
	set more off; 
	
	# delimit;
	tsset origmun year, yearly;
		xi: xtivreg2 gueratt    lpop    _Y*          _R*  
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof)
		oilprod88xlop    
		coca94xpost94
		   , cluster(department) partial(_R* _Y*)  fe first;
		outreg2  cofintxlinternalp  oilprod88xlop   coca94xpost94      using  apptab5.xls, replace se  bdec(3) tdec(3) nocons nor noni;
	# delimit;
	foreach var of varlist paratt clashes casualties  {;
	tsset origmun year, yearly;
		xi: xtivreg2 `var'    lpop    _Y*                _R* 
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof )
		 oilprod88xlop
		 coca94xpost94
		   , cluster(department) partial(_R* _Y*)  fe ;
		outreg2  cofintxlinternalp  oilprod88xlop    coca94xpost94    using  apptab5.xls, se bdec(3) tdec(3) nocons nor noni;
	};


***********************************************************************************
* TABLE A.VI: Alternative Account: Spillovers Across Coffee and Oil Municipalities
***********************************************************************************

# delimit; 
	clear; 
	use "${dir}\origmun_violence_commodities_for_online_appendix.dta"; 
	set more off; 

	*** Panel A:  Excluding municipalities with coffee and oil 
	# delimit; 
	tsset origmun year, yearly; 
		xi: xtivreg2 gueratt    lpop    _Y*   _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof) 
		oilprod88xlop     
		    if cofoilprod==0, cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab6a.xls, replace se  bdec(3) tdec(3) nocons nor noni; 
	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*  _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		oilprod88xlop     
		     if  cofoilprod==0, cluster(department) partial(_R* _Y*)  fe ; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab6a.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 
	  
	*** Panel B: Excluding oil municipalities that neighbor coffee 
	# delimit; 
	tsset origmun year, yearly; 
		xi: xtivreg2 gueratt   lpop    _Y*        _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		      if   oilprod_with_coffee_neigh==0 & cofoilprod==0, cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab6b.xls, replace se bdec(3) tdec(3) nocons nor noni; 
	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*        _R*  coca94indxyear
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		      if   oilprod_with_coffee_neigh==0 & cofoilprod==0, cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab6b.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 

	*** Panel C: Excluding coffee municipalities that neightbor oil 
	# delimit; 
	tsset origmun year, yearly; 
		xi: xtivreg2 gueratt   lpop    _Y*     _R*  coca94indxyear 
		oilprod88xlop        
		      if  coffee_with_oilprod_neigh==0 & cofoilprod==0, cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab6c.xls, replace se bdec(3) tdec(3) nocons nor noni; 

	# delimit; 
	foreach var of varlist  paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*     _R*  coca94indxyear 
		oilprod88xlop        
		      if  coffee_with_oilprod_neigh==0 & cofoilprod==0, cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  oilprod88xlop         using  apptab6c.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 


****************************************************************************
* TABLE A.VII: The Effect of Other Agricultural Price Shocks on Violence
****************************************************************************

# delimit; 
	clear; 
	use "${dir}\origmun_violence_commodities_for_online_appendix.dta"; 
	set more off; 
	
	# delimit;
	tsset origmun year, yearly; 
		xi: xtivreg2  gueratt   lpop    _Y*      _R*  coca94indxyear 
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		sugar05xlsugarp  				  		banana05xlbanp 			palm05xlpalmp  tobacco05xltobacp
		      , cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  sugar05xlsugarp  	tobacco05xltobacp  	banana05xlbanp 	palm05xlpalmp  using apptab7.xls, replace se bdec(3) tdec(3) nocons nor noni; 

	# delimit; 
	foreach var of varlist paratt clashes casualties  {; 
	tsset origmun year, yearly; 
		xi: xtivreg2 `var'    lpop    _Y*      _R*  coca94indxyear 
		(cofintxlinternalp   = rxltop3cof txltop3cof  rtxltop3cof ) 
		sugar05xlsugarp  				  		banana05xlbanp 			palm05xlpalmp  tobacco05xltobacp
		      , cluster(department) partial(_R* _Y*)  fe first; 
		outreg2  cofintxlinternalp  sugar05xlsugarp  	tobacco05xltobacp  	banana05xlbanp 	palm05xlpalmp  using apptab7.xls, se bdec(3) tdec(3) nocons nor noni; 
	}; 

# delimit cr 



************************************************************
* 	TABLE A.III: Poisson Instrumental Variables Estimation
************************************************************

*** NOTE: origmun fixed effects pre-incorporated owing to nature of qvf command

	clear
	use "${dir}\origmun_violence_commodities_for_online_appendix"

	set more off
	egen mun2 = group(origmun)
	xi i.mun2, pre(_M)


	#delimit ;

	foreach var of varlist gueratt paratt clashes casualties {;
	qvf `var'  oilprod88xlop  lpop   coca94indxyear cofintxlinternalp
	_Mmun2_2
	_Mmun2_3
	_Mmun2_4
	_Mmun2_5
	_Mmun2_6
	_Mmun2_7
	_Mmun2_8
	_Mmun2_9
	_Mmun2_10
	_Mmun2_11
	_Mmun2_12
	_Mmun2_13
	_Mmun2_14
	_Mmun2_15
	_Mmun2_16
	_Mmun2_17
	_Mmun2_18
	_Mmun2_19
	_Mmun2_20
	_Mmun2_21
	_Mmun2_22
	_Mmun2_23
	_Mmun2_24
	_Mmun2_25
	_Mmun2_26
	_Mmun2_27
	_Mmun2_28
	_Mmun2_29
	_Mmun2_30
	_Mmun2_31
	_Mmun2_32
	_Mmun2_33
	_Mmun2_34
	_Mmun2_35
	_Mmun2_36
	_Mmun2_37
	_Mmun2_38
	_Mmun2_39
	_Mmun2_40
	_Mmun2_41
	_Mmun2_42
	_Mmun2_43
	_Mmun2_44
	_Mmun2_45
	_Mmun2_46
	_Mmun2_47
	_Mmun2_48
	_Mmun2_49
	_Mmun2_50
	_Mmun2_51
	_Mmun2_52
	_Mmun2_53
	_Mmun2_54
	_Mmun2_55
	_Mmun2_56
	_Mmun2_57
	_Mmun2_58
	_Mmun2_59
	_Mmun2_60
	_Mmun2_61
	_Mmun2_62
	_Mmun2_63
	_Mmun2_64
	_Mmun2_65
	_Mmun2_66
	_Mmun2_67
	_Mmun2_68
	_Mmun2_69
	_Mmun2_70
	_Mmun2_71
	_Mmun2_72
	_Mmun2_73
	_Mmun2_74
	_Mmun2_75
	_Mmun2_76
	_Mmun2_77
	_Mmun2_78
	_Mmun2_79
	_Mmun2_80
	_Mmun2_81
	_Mmun2_82
	_Mmun2_83
	_Mmun2_84
	_Mmun2_85
	_Mmun2_86
	_Mmun2_87
	_Mmun2_88
	_Mmun2_89
	_Mmun2_90
	_Mmun2_91
	_Mmun2_92
	_Mmun2_93
	_Mmun2_94
	_Mmun2_95
	_Mmun2_96
	_Mmun2_97
	_Mmun2_98
	_Mmun2_99
	_Mmun2_100
	_Mmun2_101
	_Mmun2_102
	_Mmun2_103
	_Mmun2_104
	_Mmun2_105
	_Mmun2_106
	_Mmun2_107
	_Mmun2_108
	_Mmun2_109
	_Mmun2_110
	_Mmun2_111
	_Mmun2_112
	_Mmun2_113
	_Mmun2_114
	_Mmun2_115
	_Mmun2_116
	_Mmun2_117
	_Mmun2_118
	_Mmun2_119
	_Mmun2_120
	_Mmun2_121
	_Mmun2_122
	_Mmun2_123
	_Mmun2_124
	_Mmun2_125
	_Mmun2_126
	_Mmun2_127
	_Mmun2_128
	_Mmun2_129
	_Mmun2_130
	_Mmun2_131
	_Mmun2_132
	_Mmun2_133
	_Mmun2_134
	_Mmun2_135
	_Mmun2_136
	_Mmun2_137
	_Mmun2_138
	_Mmun2_139
	_Mmun2_140
	_Mmun2_141
	_Mmun2_142
	_Mmun2_143
	_Mmun2_144
	_Mmun2_145
	_Mmun2_146
	_Mmun2_147
	_Mmun2_148
	_Mmun2_149
	_Mmun2_150
	_Mmun2_151
	_Mmun2_152
	_Mmun2_153
	_Mmun2_154
	_Mmun2_155
	_Mmun2_156
	_Mmun2_157
	_Mmun2_158
	_Mmun2_159
	_Mmun2_160
	_Mmun2_161
	_Mmun2_162
	_Mmun2_163
	_Mmun2_164
	_Mmun2_165
	_Mmun2_166
	_Mmun2_167
	_Mmun2_168
	_Mmun2_169
	_Mmun2_170
	_Mmun2_171
	_Mmun2_172
	_Mmun2_173
	_Mmun2_174
	_Mmun2_175
	_Mmun2_176
	_Mmun2_177
	_Mmun2_178
	_Mmun2_179
	_Mmun2_180
	_Mmun2_181
	_Mmun2_182
	_Mmun2_183
	_Mmun2_184
	_Mmun2_185
	_Mmun2_186
	_Mmun2_187
	_Mmun2_188
	_Mmun2_189
	_Mmun2_190
	_Mmun2_191
	_Mmun2_192
	_Mmun2_193
	_Mmun2_194
	_Mmun2_195
	_Mmun2_196
	_Mmun2_197
	_Mmun2_198
	_Mmun2_199
	_Mmun2_200
	_Mmun2_201
	_Mmun2_202
	_Mmun2_203
	_Mmun2_204
	_Mmun2_205
	_Mmun2_206
	_Mmun2_207
	_Mmun2_208
	_Mmun2_209
	_Mmun2_210
	_Mmun2_211
	_Mmun2_212
	_Mmun2_213
	_Mmun2_214
	_Mmun2_215
	_Mmun2_216
	_Mmun2_217
	_Mmun2_218
	_Mmun2_219
	_Mmun2_220
	_Mmun2_221
	_Mmun2_222
	_Mmun2_223
	_Mmun2_224
	_Mmun2_225
	_Mmun2_226
	_Mmun2_227
	_Mmun2_228
	_Mmun2_229
	_Mmun2_230
	_Mmun2_231
	_Mmun2_232
	_Mmun2_233
	_Mmun2_234
	_Mmun2_235
	_Mmun2_236
	_Mmun2_237
	_Mmun2_238
	_Mmun2_239
	_Mmun2_240
	_Mmun2_241
	_Mmun2_242
	_Mmun2_243
	_Mmun2_244
	_Mmun2_245
	_Mmun2_246
	_Mmun2_247
	_Mmun2_248
	_Mmun2_249
	_Mmun2_250
	_Mmun2_251
	_Mmun2_252
	_Mmun2_253
	_Mmun2_254
	_Mmun2_255
	_Mmun2_256
	_Mmun2_257
	_Mmun2_258
	_Mmun2_259
	_Mmun2_260
	_Mmun2_261
	_Mmun2_262
	_Mmun2_263
	_Mmun2_264
	_Mmun2_265
	_Mmun2_266
	_Mmun2_267
	_Mmun2_268
	_Mmun2_269
	_Mmun2_270
	_Mmun2_271
	_Mmun2_272
	_Mmun2_273
	_Mmun2_274
	_Mmun2_275
	_Mmun2_276
	_Mmun2_277
	_Mmun2_278
	_Mmun2_279
	_Mmun2_280
	_Mmun2_281
	_Mmun2_282
	_Mmun2_283
	_Mmun2_284
	_Mmun2_285
	_Mmun2_286
	_Mmun2_287
	_Mmun2_288
	_Mmun2_289
	_Mmun2_290
	_Mmun2_291
	_Mmun2_292
	_Mmun2_293
	_Mmun2_294
	_Mmun2_295
	_Mmun2_296
	_Mmun2_297
	_Mmun2_298
	_Mmun2_299
	_Mmun2_300
	_Mmun2_301
	_Mmun2_302
	_Mmun2_303
	_Mmun2_304
	_Mmun2_305
	_Mmun2_306
	_Mmun2_307
	_Mmun2_308
	_Mmun2_309
	_Mmun2_310
	_Mmun2_311
	_Mmun2_312
	_Mmun2_313
	_Mmun2_314
	_Mmun2_315
	_Mmun2_316
	_Mmun2_317
	_Mmun2_318
	_Mmun2_319
	_Mmun2_320
	_Mmun2_321
	_Mmun2_322
	_Mmun2_323
	_Mmun2_324
	_Mmun2_325
	_Mmun2_326
	_Mmun2_327
	_Mmun2_328
	_Mmun2_329
	_Mmun2_330
	_Mmun2_331
	_Mmun2_332
	_Mmun2_333
	_Mmun2_334
	_Mmun2_335
	_Mmun2_336
	_Mmun2_337
	_Mmun2_338
	_Mmun2_339
	_Mmun2_340
	_Mmun2_341
	_Mmun2_342
	_Mmun2_343
	_Mmun2_344
	_Mmun2_345
	_Mmun2_346
	_Mmun2_347
	_Mmun2_348
	_Mmun2_349
	_Mmun2_350
	_Mmun2_351
	_Mmun2_352
	_Mmun2_353
	_Mmun2_354
	_Mmun2_355
	_Mmun2_356
	_Mmun2_357
	_Mmun2_358
	_Mmun2_359
	_Mmun2_360
	_Mmun2_361
	_Mmun2_362
	_Mmun2_363
	_Mmun2_364
	_Mmun2_365
	_Mmun2_366
	_Mmun2_367
	_Mmun2_368
	_Mmun2_369
	_Mmun2_370
	_Mmun2_371
	_Mmun2_372
	_Mmun2_373
	_Mmun2_374
	_Mmun2_375
	_Mmun2_376
	_Mmun2_377
	_Mmun2_378
	_Mmun2_379
	_Mmun2_380
	_Mmun2_381
	_Mmun2_382
	_Mmun2_383
	_Mmun2_384
	_Mmun2_385
	_Mmun2_386
	_Mmun2_387
	_Mmun2_388
	_Mmun2_389
	_Mmun2_390
	_Mmun2_391
	_Mmun2_392
	_Mmun2_393
	_Mmun2_394
	_Mmun2_395
	_Mmun2_396
	_Mmun2_397
	_Mmun2_398
	_Mmun2_399
	_Mmun2_400
	_Mmun2_401
	_Mmun2_402
	_Mmun2_403
	_Mmun2_404
	_Mmun2_405
	_Mmun2_406
	_Mmun2_407
	_Mmun2_408
	_Mmun2_409
	_Mmun2_410
	_Mmun2_411
	_Mmun2_412
	_Mmun2_413
	_Mmun2_414
	_Mmun2_415
	_Mmun2_416
	_Mmun2_417
	_Mmun2_418
	_Mmun2_419
	_Mmun2_420
	_Mmun2_421
	_Mmun2_422
	_Mmun2_423
	_Mmun2_424
	_Mmun2_425
	_Mmun2_426
	_Mmun2_427
	_Mmun2_428
	_Mmun2_429
	_Mmun2_430
	_Mmun2_431
	_Mmun2_432
	_Mmun2_433
	_Mmun2_434
	_Mmun2_435
	_Mmun2_436
	_Mmun2_437
	_Mmun2_438
	_Mmun2_439
	_Mmun2_440
	_Mmun2_441
	_Mmun2_442
	_Mmun2_443
	_Mmun2_444
	_Mmun2_445
	_Mmun2_446
	_Mmun2_447
	_Mmun2_448
	_Mmun2_449
	_Mmun2_450
	_Mmun2_451
	_Mmun2_452
	_Mmun2_453
	_Mmun2_454
	_Mmun2_455
	_Mmun2_456
	_Mmun2_457
	_Mmun2_458
	_Mmun2_459
	_Mmun2_460
	_Mmun2_461
	_Mmun2_462
	_Mmun2_463
	_Mmun2_464
	_Mmun2_465
	_Mmun2_466
	_Mmun2_467
	_Mmun2_468
	_Mmun2_469
	_Mmun2_470
	_Mmun2_471
	_Mmun2_472
	_Mmun2_473
	_Mmun2_474
	_Mmun2_475
	_Mmun2_476
	_Mmun2_477
	_Mmun2_478
	_Mmun2_479
	_Mmun2_480
	_Mmun2_481
	_Mmun2_482
	_Mmun2_483
	_Mmun2_484
	_Mmun2_485
	_Mmun2_486
	_Mmun2_487
	_Mmun2_488
	_Mmun2_489
	_Mmun2_490
	_Mmun2_491
	_Mmun2_492
	_Mmun2_493
	_Mmun2_494
	_Mmun2_495
	_Mmun2_496
	_Mmun2_497
	_Mmun2_498
	_Mmun2_499
	_Mmun2_500
	_Mmun2_501
	_Mmun2_502
	_Mmun2_503
	_Mmun2_504
	_Mmun2_505
	_Mmun2_506
	_Mmun2_507
	_Mmun2_508
	_Mmun2_509
	_Mmun2_510
	_Mmun2_511
	_Mmun2_512
	_Mmun2_513
	_Mmun2_514
	_Mmun2_515
	_Mmun2_516
	_Mmun2_517
	_Mmun2_518
	_Mmun2_519
	_Mmun2_520
	_Mmun2_521
	_Mmun2_522
	_Mmun2_523
	_Mmun2_524
	_Mmun2_525
	_Mmun2_526
	_Mmun2_527
	_Mmun2_528
	_Mmun2_529
	_Mmun2_530
	_Mmun2_531
	_Mmun2_532
	_Mmun2_533
	_Mmun2_534
	_Mmun2_535
	_Mmun2_536
	_Mmun2_537
	_Mmun2_538
	_Mmun2_539
	_Mmun2_540
	_Mmun2_541
	_Mmun2_542
	_Mmun2_543
	_Mmun2_544
	_Mmun2_545
	_Mmun2_546
	_Mmun2_547
	_Mmun2_548
	_Mmun2_549
	_Mmun2_550
	_Mmun2_551
	_Mmun2_552
	_Mmun2_553
	_Mmun2_554
	_Mmun2_555
	_Mmun2_556
	_Mmun2_557
	_Mmun2_558
	_Mmun2_559
	_Mmun2_560
	_Mmun2_561
	_Mmun2_562
	_Mmun2_563
	_Mmun2_564
	_Mmun2_565
	_Mmun2_566
	_Mmun2_567
	_Mmun2_568
	_Mmun2_569
	_Mmun2_570
	_Mmun2_571
	_Mmun2_572
	_Mmun2_573
	_Mmun2_574
	_Mmun2_575
	_Mmun2_576
	_Mmun2_577
	_Mmun2_578
	_Mmun2_579
	_Mmun2_580
	_Mmun2_581
	_Mmun2_582
	_Mmun2_583
	_Mmun2_584
	_Mmun2_585
	_Mmun2_586
	_Mmun2_587
	_Mmun2_588
	_Mmun2_589
	_Mmun2_590
	_Mmun2_591
	_Mmun2_592
	_Mmun2_593
	_Mmun2_594
	_Mmun2_595
	_Mmun2_596
	_Mmun2_597
	_Mmun2_598
	_Mmun2_599
	_Mmun2_600
	_Mmun2_601
	_Mmun2_602
	_Mmun2_603
	_Mmun2_604
	_Mmun2_605
	_Mmun2_606
	_Mmun2_607
	_Mmun2_608
	_Mmun2_609
	_Mmun2_610
	_Mmun2_611
	_Mmun2_612
	_Mmun2_613
	_Mmun2_614
	_Mmun2_615
	_Mmun2_616
	_Mmun2_617
	_Mmun2_618
	_Mmun2_619
	_Mmun2_620
	_Mmun2_621
	_Mmun2_622
	_Mmun2_623
	_Mmun2_624
	_Mmun2_625
	_Mmun2_626
	_Mmun2_627
	_Mmun2_628
	_Mmun2_629
	_Mmun2_630
	_Mmun2_631
	_Mmun2_632
	_Mmun2_633
	_Mmun2_634
	_Mmun2_635
	_Mmun2_636
	_Mmun2_637
	_Mmun2_638
	_Mmun2_639
	_Mmun2_640
	_Mmun2_641
	_Mmun2_642
	_Mmun2_643
	_Mmun2_644
	_Mmun2_645
	_Mmun2_646
	_Mmun2_647
	_Mmun2_648
	_Mmun2_649
	_Mmun2_650
	_Mmun2_651
	_Mmun2_652
	_Mmun2_653
	_Mmun2_654
	_Mmun2_655
	_Mmun2_656
	_Mmun2_657
	_Mmun2_658
	_Mmun2_659
	_Mmun2_660
	_Mmun2_661
	_Mmun2_662
	_Mmun2_663
	_Mmun2_664
	_Mmun2_665
	_Mmun2_666
	_Mmun2_667
	_Mmun2_668
	_Mmun2_669
	_Mmun2_670
	_Mmun2_671
	_Mmun2_672
	_Mmun2_673
	_Mmun2_674
	_Mmun2_675
	_Mmun2_676
	_Mmun2_677
	_Mmun2_678
	_Mmun2_679
	_Mmun2_680
	_Mmun2_681
	_Mmun2_682
	_Mmun2_683
	_Mmun2_684
	_Mmun2_685
	_Mmun2_686
	_Mmun2_687
	_Mmun2_688
	_Mmun2_689
	_Mmun2_690
	_Mmun2_691
	_Mmun2_692
	_Mmun2_693
	_Mmun2_694
	_Mmun2_695
	_Mmun2_696
	_Mmun2_697
	_Mmun2_698
	_Mmun2_699
	_Mmun2_700
	_Mmun2_701
	_Mmun2_702
	_Mmun2_703
	_Mmun2_704
	_Mmun2_705
	_Mmun2_706
	_Mmun2_707
	_Mmun2_708
	_Mmun2_709
	_Mmun2_710
	_Mmun2_711
	_Mmun2_712
	_Mmun2_713
	_Mmun2_714
	_Mmun2_715
	_Mmun2_716
	_Mmun2_717
	_Mmun2_718
	_Mmun2_719
	_Mmun2_720
	_Mmun2_721
	_Mmun2_722
	_Mmun2_723
	_Mmun2_724
	_Mmun2_725
	_Mmun2_726
	_Mmun2_727
	_Mmun2_728
	_Mmun2_729
	_Mmun2_730
	_Mmun2_731
	_Mmun2_732
	_Mmun2_733
	_Mmun2_734
	_Mmun2_735
	_Mmun2_736
	_Mmun2_737
	_Mmun2_738
	_Mmun2_739
	_Mmun2_740
	_Mmun2_741
	_Mmun2_742
	_Mmun2_743
	_Mmun2_744
	_Mmun2_745
	_Mmun2_746
	_Mmun2_747
	_Mmun2_748
	_Mmun2_749
	_Mmun2_750
	_Mmun2_751
	_Mmun2_752
	_Mmun2_753
	_Mmun2_754
	_Mmun2_755
	_Mmun2_756
	_Mmun2_757
	_Mmun2_758
	_Mmun2_759
	_Mmun2_760
	_Mmun2_761
	_Mmun2_762
	_Mmun2_763
	_Mmun2_764
	_Mmun2_765
	_Mmun2_766
	_Mmun2_767
	_Mmun2_768
	_Mmun2_769
	_Mmun2_770
	_Mmun2_771
	_Mmun2_772
	_Mmun2_773
	_Mmun2_774
	_Mmun2_775
	_Mmun2_776
	_Mmun2_777
	_Mmun2_778
	_Mmun2_779
	_Mmun2_780
	_Mmun2_781
	_Mmun2_782
	_Mmun2_783
	_Mmun2_784
	_Mmun2_785
	_Mmun2_786
	_Mmun2_787
	_Mmun2_788
	_Mmun2_789
	_Mmun2_790
	_Mmun2_791
	_Mmun2_792
	_Mmun2_793
	_Mmun2_794
	_Mmun2_795
	_Mmun2_796
	_Mmun2_797
	_Mmun2_798
	_Mmun2_799
	_Mmun2_800
	_Mmun2_801
	_Mmun2_802
	_Mmun2_803
	_Mmun2_804
	_Mmun2_805
	_Mmun2_806
	_Mmun2_807
	_Mmun2_808
	_Mmun2_809
	_Mmun2_810
	_Mmun2_811
	_Mmun2_812
	_Mmun2_813
	_Mmun2_814
	_Mmun2_815
	_Mmun2_816
	_Mmun2_817
	_Mmun2_818
	_Mmun2_819
	_Mmun2_820
	_Mmun2_821
	_Mmun2_822
	_Mmun2_823
	_Mmun2_824
	_Mmun2_825
	_Mmun2_826
	_Mmun2_827
	_Mmun2_828
	_Mmun2_829
	_Mmun2_830
	_Mmun2_831
	_Mmun2_832
	_Mmun2_833
	_Mmun2_834
	_Mmun2_835
	_Mmun2_836
	_Mmun2_837
	_Mmun2_838
	_Mmun2_839
	_Mmun2_840
	_Mmun2_841
	_Mmun2_842
	_Mmun2_843
	_Mmun2_844
	_Mmun2_845
	_Mmun2_846
	_Mmun2_847
	_Mmun2_848
	_Mmun2_849
	_Mmun2_850
	_Mmun2_851
	_Mmun2_852
	_Mmun2_853
	_Mmun2_854
	_Mmun2_855
	_Mmun2_856
	_Mmun2_857
	_Mmun2_858
	_Mmun2_859
	_Mmun2_860
	_Mmun2_861
	_Mmun2_862
	_Mmun2_863
	_Mmun2_864
	_Mmun2_865
	_Mmun2_866
	_Mmun2_867
	_Mmun2_868
	_Mmun2_869
	_Mmun2_870
	_Mmun2_871
	_Mmun2_872
	_Mmun2_873
	_Mmun2_874
	_Mmun2_875
	_Mmun2_876
	_Mmun2_877
	_Mmun2_878
	_Mmun2_879
	_Mmun2_880
	_Mmun2_881
	_Mmun2_882
	_Mmun2_883
	_Mmun2_884
	_Mmun2_885
	_Mmun2_886
	_Mmun2_887
	_Mmun2_888
	_Mmun2_889
	_Mmun2_890
	_Mmun2_891
	_Mmun2_892
	_Mmun2_893
	_Mmun2_894
	_Mmun2_895
	_Mmun2_896
	_Mmun2_897
	_Mmun2_898
	_Mmun2_899
	_Mmun2_900
	_Mmun2_901
	_Mmun2_902
	_Mmun2_903
	_Mmun2_904
	_Mmun2_905
	_Mmun2_906
	_Mmun2_907
	_Mmun2_908
	_Mmun2_909
	_Mmun2_910
	_Mmun2_911
	_Mmun2_912
	_Mmun2_913
	_Mmun2_914
	_Mmun2_915
	_Mmun2_916
	_Mmun2_917
	_Mmun2_918
	_Mmun2_919
	_Mmun2_920
	_Mmun2_921
	_Mmun2_922
	_Mmun2_923
	_Mmun2_924
	_Mmun2_925
	_Mmun2_926
	_Mmun2_927
	_Mmun2_928
	_Mmun2_929
	_Mmun2_930
	_Mmun2_931
	_Mmun2_932
	_Mmun2_933
	_Mmun2_934
	_Mmun2_935
	_Mmun2_936
	_Mmun2_937
	_Mmun2_938
	_Mmun2_939
	_Mmun2_940
	_Mmun2_941
	_Mmun2_942
	_Mmun2_943
	_Mmun2_944
	_Mmun2_945
	_Mmun2_946
	_Mmun2_947
	_Mmun2_948
	_Mmun2_949
	_Mmun2_950
	_Mmun2_951
	_Mmun2_952
	_Mmun2_953
	_Mmun2_954
	_Mmun2_955
	_Mmun2_956
	_Mmun2_957
	_Mmun2_958
	_Mmun2_959
	_Mmun2_960
	_Mmun2_961
	_Mmun2_962
	_Mmun2_963
	_Mmun2_964
	_Mmun2_965
	_Mmun2_966
	_Mmun2_967
	_Mmun2_968
	_Mmun2_969
	_Mmun2_970
	_Mmun2_971
	_Mmun2_972
	_Mmun2_973
	_Mmun2_974
	_Mmun2_975
	_Mmun2_976
	_Mmun2_977
	_Mmun2_978
	_Mmun2_979
	_Mmun2_980
	_Mmun2_981
	_Mmun2_982
	_Mmun2_983
	_Mmun2_984
	_Mmun2_985
	_Mmun2_986
	_Mmun2_987
	_Mmun2_988
	_Mmun2_989
	_Mmun2_990
	_Mmun2_991
	_Mmun2_992
	_Mmun2_993
	_Mmun2_994
	_Mmun2_995
	_Mmun2_996
	_Mmun2_997
	_Mmun2_998

	_Yyear_1989
	_Yyear_1990
	_Yyear_1991
	_Yyear_1992
	_Yyear_1993
	_Yyear_1994
	_Yyear_1995
	_Yyear_1996
	_Yyear_1997
	_Yyear_1998
	_Yyear_1999
	_Yyear_2000
	_Yyear_2001
	_Yyear_2002
	_Yyear_2003
	_Yyear_2004
	_Yyear_2005

	 _Rregion_2
	 _Rregion_3
	 _Rregion_4 
	 _RregXyear_2 
	 _RregXyear_3 
	 _RregXyear_4
	 
	 
	(oilprod88xlop  lpop   coca94indxyear rxltop3cof txltop3cof  rtxltop3cof

	_Mmun2_2
	_Mmun2_3
	_Mmun2_4
	_Mmun2_5
	_Mmun2_6
	_Mmun2_7
	_Mmun2_8
	_Mmun2_9
	_Mmun2_10
	_Mmun2_11
	_Mmun2_12
	_Mmun2_13
	_Mmun2_14
	_Mmun2_15
	_Mmun2_16
	_Mmun2_17
	_Mmun2_18
	_Mmun2_19
	_Mmun2_20
	_Mmun2_21
	_Mmun2_22
	_Mmun2_23
	_Mmun2_24
	_Mmun2_25
	_Mmun2_26
	_Mmun2_27
	_Mmun2_28
	_Mmun2_29
	_Mmun2_30
	_Mmun2_31
	_Mmun2_32
	_Mmun2_33
	_Mmun2_34
	_Mmun2_35
	_Mmun2_36
	_Mmun2_37
	_Mmun2_38
	_Mmun2_39
	_Mmun2_40
	_Mmun2_41
	_Mmun2_42
	_Mmun2_43
	_Mmun2_44
	_Mmun2_45
	_Mmun2_46
	_Mmun2_47
	_Mmun2_48
	_Mmun2_49
	_Mmun2_50
	_Mmun2_51
	_Mmun2_52
	_Mmun2_53
	_Mmun2_54
	_Mmun2_55
	_Mmun2_56
	_Mmun2_57
	_Mmun2_58
	_Mmun2_59
	_Mmun2_60
	_Mmun2_61
	_Mmun2_62
	_Mmun2_63
	_Mmun2_64
	_Mmun2_65
	_Mmun2_66
	_Mmun2_67
	_Mmun2_68
	_Mmun2_69
	_Mmun2_70
	_Mmun2_71
	_Mmun2_72
	_Mmun2_73
	_Mmun2_74
	_Mmun2_75
	_Mmun2_76
	_Mmun2_77
	_Mmun2_78
	_Mmun2_79
	_Mmun2_80
	_Mmun2_81
	_Mmun2_82
	_Mmun2_83
	_Mmun2_84
	_Mmun2_85
	_Mmun2_86
	_Mmun2_87
	_Mmun2_88
	_Mmun2_89
	_Mmun2_90
	_Mmun2_91
	_Mmun2_92
	_Mmun2_93
	_Mmun2_94
	_Mmun2_95
	_Mmun2_96
	_Mmun2_97
	_Mmun2_98
	_Mmun2_99
	_Mmun2_100
	_Mmun2_101
	_Mmun2_102
	_Mmun2_103
	_Mmun2_104
	_Mmun2_105
	_Mmun2_106
	_Mmun2_107
	_Mmun2_108
	_Mmun2_109
	_Mmun2_110
	_Mmun2_111
	_Mmun2_112
	_Mmun2_113
	_Mmun2_114
	_Mmun2_115
	_Mmun2_116
	_Mmun2_117
	_Mmun2_118
	_Mmun2_119
	_Mmun2_120
	_Mmun2_121
	_Mmun2_122
	_Mmun2_123
	_Mmun2_124
	_Mmun2_125
	_Mmun2_126
	_Mmun2_127
	_Mmun2_128
	_Mmun2_129
	_Mmun2_130
	_Mmun2_131
	_Mmun2_132
	_Mmun2_133
	_Mmun2_134
	_Mmun2_135
	_Mmun2_136
	_Mmun2_137
	_Mmun2_138
	_Mmun2_139
	_Mmun2_140
	_Mmun2_141
	_Mmun2_142
	_Mmun2_143
	_Mmun2_144
	_Mmun2_145
	_Mmun2_146
	_Mmun2_147
	_Mmun2_148
	_Mmun2_149
	_Mmun2_150
	_Mmun2_151
	_Mmun2_152
	_Mmun2_153
	_Mmun2_154
	_Mmun2_155
	_Mmun2_156
	_Mmun2_157
	_Mmun2_158
	_Mmun2_159
	_Mmun2_160
	_Mmun2_161
	_Mmun2_162
	_Mmun2_163
	_Mmun2_164
	_Mmun2_165
	_Mmun2_166
	_Mmun2_167
	_Mmun2_168
	_Mmun2_169
	_Mmun2_170
	_Mmun2_171
	_Mmun2_172
	_Mmun2_173
	_Mmun2_174
	_Mmun2_175
	_Mmun2_176
	_Mmun2_177
	_Mmun2_178
	_Mmun2_179
	_Mmun2_180
	_Mmun2_181
	_Mmun2_182
	_Mmun2_183
	_Mmun2_184
	_Mmun2_185
	_Mmun2_186
	_Mmun2_187
	_Mmun2_188
	_Mmun2_189
	_Mmun2_190
	_Mmun2_191
	_Mmun2_192
	_Mmun2_193
	_Mmun2_194
	_Mmun2_195
	_Mmun2_196
	_Mmun2_197
	_Mmun2_198
	_Mmun2_199
	_Mmun2_200
	_Mmun2_201
	_Mmun2_202
	_Mmun2_203
	_Mmun2_204
	_Mmun2_205
	_Mmun2_206
	_Mmun2_207
	_Mmun2_208
	_Mmun2_209
	_Mmun2_210
	_Mmun2_211
	_Mmun2_212
	_Mmun2_213
	_Mmun2_214
	_Mmun2_215
	_Mmun2_216
	_Mmun2_217
	_Mmun2_218
	_Mmun2_219
	_Mmun2_220
	_Mmun2_221
	_Mmun2_222
	_Mmun2_223
	_Mmun2_224
	_Mmun2_225
	_Mmun2_226
	_Mmun2_227
	_Mmun2_228
	_Mmun2_229
	_Mmun2_230
	_Mmun2_231
	_Mmun2_232
	_Mmun2_233
	_Mmun2_234
	_Mmun2_235
	_Mmun2_236
	_Mmun2_237
	_Mmun2_238
	_Mmun2_239
	_Mmun2_240
	_Mmun2_241
	_Mmun2_242
	_Mmun2_243
	_Mmun2_244
	_Mmun2_245
	_Mmun2_246
	_Mmun2_247
	_Mmun2_248
	_Mmun2_249
	_Mmun2_250
	_Mmun2_251
	_Mmun2_252
	_Mmun2_253
	_Mmun2_254
	_Mmun2_255
	_Mmun2_256
	_Mmun2_257
	_Mmun2_258
	_Mmun2_259
	_Mmun2_260
	_Mmun2_261
	_Mmun2_262
	_Mmun2_263
	_Mmun2_264
	_Mmun2_265
	_Mmun2_266
	_Mmun2_267
	_Mmun2_268
	_Mmun2_269
	_Mmun2_270
	_Mmun2_271
	_Mmun2_272
	_Mmun2_273
	_Mmun2_274
	_Mmun2_275
	_Mmun2_276
	_Mmun2_277
	_Mmun2_278
	_Mmun2_279
	_Mmun2_280
	_Mmun2_281
	_Mmun2_282
	_Mmun2_283
	_Mmun2_284
	_Mmun2_285
	_Mmun2_286
	_Mmun2_287
	_Mmun2_288
	_Mmun2_289
	_Mmun2_290
	_Mmun2_291
	_Mmun2_292
	_Mmun2_293
	_Mmun2_294
	_Mmun2_295
	_Mmun2_296
	_Mmun2_297
	_Mmun2_298
	_Mmun2_299
	_Mmun2_300
	_Mmun2_301
	_Mmun2_302
	_Mmun2_303
	_Mmun2_304
	_Mmun2_305
	_Mmun2_306
	_Mmun2_307
	_Mmun2_308
	_Mmun2_309
	_Mmun2_310
	_Mmun2_311
	_Mmun2_312
	_Mmun2_313
	_Mmun2_314
	_Mmun2_315
	_Mmun2_316
	_Mmun2_317
	_Mmun2_318
	_Mmun2_319
	_Mmun2_320
	_Mmun2_321
	_Mmun2_322
	_Mmun2_323
	_Mmun2_324
	_Mmun2_325
	_Mmun2_326
	_Mmun2_327
	_Mmun2_328
	_Mmun2_329
	_Mmun2_330
	_Mmun2_331
	_Mmun2_332
	_Mmun2_333
	_Mmun2_334
	_Mmun2_335
	_Mmun2_336
	_Mmun2_337
	_Mmun2_338
	_Mmun2_339
	_Mmun2_340
	_Mmun2_341
	_Mmun2_342
	_Mmun2_343
	_Mmun2_344
	_Mmun2_345
	_Mmun2_346
	_Mmun2_347
	_Mmun2_348
	_Mmun2_349
	_Mmun2_350
	_Mmun2_351
	_Mmun2_352
	_Mmun2_353
	_Mmun2_354
	_Mmun2_355
	_Mmun2_356
	_Mmun2_357
	_Mmun2_358
	_Mmun2_359
	_Mmun2_360
	_Mmun2_361
	_Mmun2_362
	_Mmun2_363
	_Mmun2_364
	_Mmun2_365
	_Mmun2_366
	_Mmun2_367
	_Mmun2_368
	_Mmun2_369
	_Mmun2_370
	_Mmun2_371
	_Mmun2_372
	_Mmun2_373
	_Mmun2_374
	_Mmun2_375
	_Mmun2_376
	_Mmun2_377
	_Mmun2_378
	_Mmun2_379
	_Mmun2_380
	_Mmun2_381
	_Mmun2_382
	_Mmun2_383
	_Mmun2_384
	_Mmun2_385
	_Mmun2_386
	_Mmun2_387
	_Mmun2_388
	_Mmun2_389
	_Mmun2_390
	_Mmun2_391
	_Mmun2_392
	_Mmun2_393
	_Mmun2_394
	_Mmun2_395
	_Mmun2_396
	_Mmun2_397
	_Mmun2_398
	_Mmun2_399
	_Mmun2_400
	_Mmun2_401
	_Mmun2_402
	_Mmun2_403
	_Mmun2_404
	_Mmun2_405
	_Mmun2_406
	_Mmun2_407
	_Mmun2_408
	_Mmun2_409
	_Mmun2_410
	_Mmun2_411
	_Mmun2_412
	_Mmun2_413
	_Mmun2_414
	_Mmun2_415
	_Mmun2_416
	_Mmun2_417
	_Mmun2_418
	_Mmun2_419
	_Mmun2_420
	_Mmun2_421
	_Mmun2_422
	_Mmun2_423
	_Mmun2_424
	_Mmun2_425
	_Mmun2_426
	_Mmun2_427
	_Mmun2_428
	_Mmun2_429
	_Mmun2_430
	_Mmun2_431
	_Mmun2_432
	_Mmun2_433
	_Mmun2_434
	_Mmun2_435
	_Mmun2_436
	_Mmun2_437
	_Mmun2_438
	_Mmun2_439
	_Mmun2_440
	_Mmun2_441
	_Mmun2_442
	_Mmun2_443
	_Mmun2_444
	_Mmun2_445
	_Mmun2_446
	_Mmun2_447
	_Mmun2_448
	_Mmun2_449
	_Mmun2_450
	_Mmun2_451
	_Mmun2_452
	_Mmun2_453
	_Mmun2_454
	_Mmun2_455
	_Mmun2_456
	_Mmun2_457
	_Mmun2_458
	_Mmun2_459
	_Mmun2_460
	_Mmun2_461
	_Mmun2_462
	_Mmun2_463
	_Mmun2_464
	_Mmun2_465
	_Mmun2_466
	_Mmun2_467
	_Mmun2_468
	_Mmun2_469
	_Mmun2_470
	_Mmun2_471
	_Mmun2_472
	_Mmun2_473
	_Mmun2_474
	_Mmun2_475
	_Mmun2_476
	_Mmun2_477
	_Mmun2_478
	_Mmun2_479
	_Mmun2_480
	_Mmun2_481
	_Mmun2_482
	_Mmun2_483
	_Mmun2_484
	_Mmun2_485
	_Mmun2_486
	_Mmun2_487
	_Mmun2_488
	_Mmun2_489
	_Mmun2_490
	_Mmun2_491
	_Mmun2_492
	_Mmun2_493
	_Mmun2_494
	_Mmun2_495
	_Mmun2_496
	_Mmun2_497
	_Mmun2_498
	_Mmun2_499
	_Mmun2_500
	_Mmun2_501
	_Mmun2_502
	_Mmun2_503
	_Mmun2_504
	_Mmun2_505
	_Mmun2_506
	_Mmun2_507
	_Mmun2_508
	_Mmun2_509
	_Mmun2_510
	_Mmun2_511
	_Mmun2_512
	_Mmun2_513
	_Mmun2_514
	_Mmun2_515
	_Mmun2_516
	_Mmun2_517
	_Mmun2_518
	_Mmun2_519
	_Mmun2_520
	_Mmun2_521
	_Mmun2_522
	_Mmun2_523
	_Mmun2_524
	_Mmun2_525
	_Mmun2_526
	_Mmun2_527
	_Mmun2_528
	_Mmun2_529
	_Mmun2_530
	_Mmun2_531
	_Mmun2_532
	_Mmun2_533
	_Mmun2_534
	_Mmun2_535
	_Mmun2_536
	_Mmun2_537
	_Mmun2_538
	_Mmun2_539
	_Mmun2_540
	_Mmun2_541
	_Mmun2_542
	_Mmun2_543
	_Mmun2_544
	_Mmun2_545
	_Mmun2_546
	_Mmun2_547
	_Mmun2_548
	_Mmun2_549
	_Mmun2_550
	_Mmun2_551
	_Mmun2_552
	_Mmun2_553
	_Mmun2_554
	_Mmun2_555
	_Mmun2_556
	_Mmun2_557
	_Mmun2_558
	_Mmun2_559
	_Mmun2_560
	_Mmun2_561
	_Mmun2_562
	_Mmun2_563
	_Mmun2_564
	_Mmun2_565
	_Mmun2_566
	_Mmun2_567
	_Mmun2_568
	_Mmun2_569
	_Mmun2_570
	_Mmun2_571
	_Mmun2_572
	_Mmun2_573
	_Mmun2_574
	_Mmun2_575
	_Mmun2_576
	_Mmun2_577
	_Mmun2_578
	_Mmun2_579
	_Mmun2_580
	_Mmun2_581
	_Mmun2_582
	_Mmun2_583
	_Mmun2_584
	_Mmun2_585
	_Mmun2_586
	_Mmun2_587
	_Mmun2_588
	_Mmun2_589
	_Mmun2_590
	_Mmun2_591
	_Mmun2_592
	_Mmun2_593
	_Mmun2_594
	_Mmun2_595
	_Mmun2_596
	_Mmun2_597
	_Mmun2_598
	_Mmun2_599
	_Mmun2_600
	_Mmun2_601
	_Mmun2_602
	_Mmun2_603
	_Mmun2_604
	_Mmun2_605
	_Mmun2_606
	_Mmun2_607
	_Mmun2_608
	_Mmun2_609
	_Mmun2_610
	_Mmun2_611
	_Mmun2_612
	_Mmun2_613
	_Mmun2_614
	_Mmun2_615
	_Mmun2_616
	_Mmun2_617
	_Mmun2_618
	_Mmun2_619
	_Mmun2_620
	_Mmun2_621
	_Mmun2_622
	_Mmun2_623
	_Mmun2_624
	_Mmun2_625
	_Mmun2_626
	_Mmun2_627
	_Mmun2_628
	_Mmun2_629
	_Mmun2_630
	_Mmun2_631
	_Mmun2_632
	_Mmun2_633
	_Mmun2_634
	_Mmun2_635
	_Mmun2_636
	_Mmun2_637
	_Mmun2_638
	_Mmun2_639
	_Mmun2_640
	_Mmun2_641
	_Mmun2_642
	_Mmun2_643
	_Mmun2_644
	_Mmun2_645
	_Mmun2_646
	_Mmun2_647
	_Mmun2_648
	_Mmun2_649
	_Mmun2_650
	_Mmun2_651
	_Mmun2_652
	_Mmun2_653
	_Mmun2_654
	_Mmun2_655
	_Mmun2_656
	_Mmun2_657
	_Mmun2_658
	_Mmun2_659
	_Mmun2_660
	_Mmun2_661
	_Mmun2_662
	_Mmun2_663
	_Mmun2_664
	_Mmun2_665
	_Mmun2_666
	_Mmun2_667
	_Mmun2_668
	_Mmun2_669
	_Mmun2_670
	_Mmun2_671
	_Mmun2_672
	_Mmun2_673
	_Mmun2_674
	_Mmun2_675
	_Mmun2_676
	_Mmun2_677
	_Mmun2_678
	_Mmun2_679
	_Mmun2_680
	_Mmun2_681
	_Mmun2_682
	_Mmun2_683
	_Mmun2_684
	_Mmun2_685
	_Mmun2_686
	_Mmun2_687
	_Mmun2_688
	_Mmun2_689
	_Mmun2_690
	_Mmun2_691
	_Mmun2_692
	_Mmun2_693
	_Mmun2_694
	_Mmun2_695
	_Mmun2_696
	_Mmun2_697
	_Mmun2_698
	_Mmun2_699
	_Mmun2_700
	_Mmun2_701
	_Mmun2_702
	_Mmun2_703
	_Mmun2_704
	_Mmun2_705
	_Mmun2_706
	_Mmun2_707
	_Mmun2_708
	_Mmun2_709
	_Mmun2_710
	_Mmun2_711
	_Mmun2_712
	_Mmun2_713
	_Mmun2_714
	_Mmun2_715
	_Mmun2_716
	_Mmun2_717
	_Mmun2_718
	_Mmun2_719
	_Mmun2_720
	_Mmun2_721
	_Mmun2_722
	_Mmun2_723
	_Mmun2_724
	_Mmun2_725
	_Mmun2_726
	_Mmun2_727
	_Mmun2_728
	_Mmun2_729
	_Mmun2_730
	_Mmun2_731
	_Mmun2_732
	_Mmun2_733
	_Mmun2_734
	_Mmun2_735
	_Mmun2_736
	_Mmun2_737
	_Mmun2_738
	_Mmun2_739
	_Mmun2_740
	_Mmun2_741
	_Mmun2_742
	_Mmun2_743
	_Mmun2_744
	_Mmun2_745
	_Mmun2_746
	_Mmun2_747
	_Mmun2_748
	_Mmun2_749
	_Mmun2_750
	_Mmun2_751
	_Mmun2_752
	_Mmun2_753
	_Mmun2_754
	_Mmun2_755
	_Mmun2_756
	_Mmun2_757
	_Mmun2_758
	_Mmun2_759
	_Mmun2_760
	_Mmun2_761
	_Mmun2_762
	_Mmun2_763
	_Mmun2_764
	_Mmun2_765
	_Mmun2_766
	_Mmun2_767
	_Mmun2_768
	_Mmun2_769
	_Mmun2_770
	_Mmun2_771
	_Mmun2_772
	_Mmun2_773
	_Mmun2_774
	_Mmun2_775
	_Mmun2_776
	_Mmun2_777
	_Mmun2_778
	_Mmun2_779
	_Mmun2_780
	_Mmun2_781
	_Mmun2_782
	_Mmun2_783
	_Mmun2_784
	_Mmun2_785
	_Mmun2_786
	_Mmun2_787
	_Mmun2_788
	_Mmun2_789
	_Mmun2_790
	_Mmun2_791
	_Mmun2_792
	_Mmun2_793
	_Mmun2_794
	_Mmun2_795
	_Mmun2_796
	_Mmun2_797
	_Mmun2_798
	_Mmun2_799
	_Mmun2_800
	_Mmun2_801
	_Mmun2_802
	_Mmun2_803
	_Mmun2_804
	_Mmun2_805
	_Mmun2_806
	_Mmun2_807
	_Mmun2_808
	_Mmun2_809
	_Mmun2_810
	_Mmun2_811
	_Mmun2_812
	_Mmun2_813
	_Mmun2_814
	_Mmun2_815
	_Mmun2_816
	_Mmun2_817
	_Mmun2_818
	_Mmun2_819
	_Mmun2_820
	_Mmun2_821
	_Mmun2_822
	_Mmun2_823
	_Mmun2_824
	_Mmun2_825
	_Mmun2_826
	_Mmun2_827
	_Mmun2_828
	_Mmun2_829
	_Mmun2_830
	_Mmun2_831
	_Mmun2_832
	_Mmun2_833
	_Mmun2_834
	_Mmun2_835
	_Mmun2_836
	_Mmun2_837
	_Mmun2_838
	_Mmun2_839
	_Mmun2_840
	_Mmun2_841
	_Mmun2_842
	_Mmun2_843
	_Mmun2_844
	_Mmun2_845
	_Mmun2_846
	_Mmun2_847
	_Mmun2_848
	_Mmun2_849
	_Mmun2_850
	_Mmun2_851
	_Mmun2_852
	_Mmun2_853
	_Mmun2_854
	_Mmun2_855
	_Mmun2_856
	_Mmun2_857
	_Mmun2_858
	_Mmun2_859
	_Mmun2_860
	_Mmun2_861
	_Mmun2_862
	_Mmun2_863
	_Mmun2_864
	_Mmun2_865
	_Mmun2_866
	_Mmun2_867
	_Mmun2_868
	_Mmun2_869
	_Mmun2_870
	_Mmun2_871
	_Mmun2_872
	_Mmun2_873
	_Mmun2_874
	_Mmun2_875
	_Mmun2_876
	_Mmun2_877
	_Mmun2_878
	_Mmun2_879
	_Mmun2_880
	_Mmun2_881
	_Mmun2_882
	_Mmun2_883
	_Mmun2_884
	_Mmun2_885
	_Mmun2_886
	_Mmun2_887
	_Mmun2_888
	_Mmun2_889
	_Mmun2_890
	_Mmun2_891
	_Mmun2_892
	_Mmun2_893
	_Mmun2_894
	_Mmun2_895
	_Mmun2_896
	_Mmun2_897
	_Mmun2_898
	_Mmun2_899
	_Mmun2_900
	_Mmun2_901
	_Mmun2_902
	_Mmun2_903
	_Mmun2_904
	_Mmun2_905
	_Mmun2_906
	_Mmun2_907
	_Mmun2_908
	_Mmun2_909
	_Mmun2_910
	_Mmun2_911
	_Mmun2_912
	_Mmun2_913
	_Mmun2_914
	_Mmun2_915
	_Mmun2_916
	_Mmun2_917
	_Mmun2_918
	_Mmun2_919
	_Mmun2_920
	_Mmun2_921
	_Mmun2_922
	_Mmun2_923
	_Mmun2_924
	_Mmun2_925
	_Mmun2_926
	_Mmun2_927
	_Mmun2_928
	_Mmun2_929
	_Mmun2_930
	_Mmun2_931
	_Mmun2_932
	_Mmun2_933
	_Mmun2_934
	_Mmun2_935
	_Mmun2_936
	_Mmun2_937
	_Mmun2_938
	_Mmun2_939
	_Mmun2_940
	_Mmun2_941
	_Mmun2_942
	_Mmun2_943
	_Mmun2_944
	_Mmun2_945
	_Mmun2_946
	_Mmun2_947
	_Mmun2_948
	_Mmun2_949
	_Mmun2_950
	_Mmun2_951
	_Mmun2_952
	_Mmun2_953
	_Mmun2_954
	_Mmun2_955
	_Mmun2_956
	_Mmun2_957
	_Mmun2_958
	_Mmun2_959
	_Mmun2_960
	_Mmun2_961
	_Mmun2_962
	_Mmun2_963
	_Mmun2_964
	_Mmun2_965
	_Mmun2_966
	_Mmun2_967
	_Mmun2_968
	_Mmun2_969
	_Mmun2_970
	_Mmun2_971
	_Mmun2_972
	_Mmun2_973
	_Mmun2_974
	_Mmun2_975
	_Mmun2_976
	_Mmun2_977
	_Mmun2_978
	_Mmun2_979
	_Mmun2_980
	_Mmun2_981
	_Mmun2_982
	_Mmun2_983
	_Mmun2_984
	_Mmun2_985
	_Mmun2_986
	_Mmun2_987
	_Mmun2_988
	_Mmun2_989
	_Mmun2_990
	_Mmun2_991
	_Mmun2_992
	_Mmun2_993
	_Mmun2_994
	_Mmun2_995
	_Mmun2_996
	_Mmun2_997
	_Mmun2_998

	_Yyear_1989
	_Yyear_1990
	_Yyear_1991
	_Yyear_1992
	_Yyear_1993
	_Yyear_1994
	_Yyear_1995
	_Yyear_1996
	_Yyear_1997
	_Yyear_1998
	_Yyear_1999
	_Yyear_2000
	_Yyear_2001
	_Yyear_2002
	_Yyear_2003
	_Yyear_2004
	_Yyear_2005

	 _Rregion_2
	 _Rregion_3
	 _Rregion_4 
	 _RregXyear_2 
	 _RregXyear_3 
	 _RregXyear_4
	 
	), link(log) fam(poisson) cluster(department);
	eststo;
	};

	#delimit cr 

	* create table with std. errors.
	esttab using apptab3.csv, replace b( %9.3f) se( %9.3f) nodepvars nonotes keep(cofintxlinternalp oilprod88xlop)  stats(N) star(* 0.10 ** 0.05 *** 0.01)

