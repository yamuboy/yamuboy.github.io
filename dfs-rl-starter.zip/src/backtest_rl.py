
from __future__ import annotations
import pandas as pd
import numpy as np
from typing import List, Dict, Any
from .env import load_slates_csv, Slate
from .roster import TEMPLATES, RosterRules
from .features import player_feature_matrix
from .bandits import PositionBandits
from .optimizer import optimize_lineup

def attach_rules(slates: List[Slate], site: str, max_from_team: int | None = 4) -> List[Slate]:
    rules = TEMPLATES[site]().__class__(**TEMPLATES[site]().__dict__)  # new instance
    rules.max_from_team = max_from_team
    for s in slates:
        s.rules = rules
    return slates

def select_lineup_for_slate(slate: Slate, bandit: PositionBandits, strategy: str = "rl") -> pd.DataFrame:
    df = slate.df.copy().reset_index(drop=True)
    X = player_feature_matrix(df)
    if strategy == "rl":
        # Thompson-sampled utilities per position
        utilities = pd.Series(0.0, index=df.index)
        for pos, g in df.groupby("position"):
            scores = bandit.sample_scores(pos, X[g.index.values, :])
            utilities.loc[g.index] = scores
    elif strategy == "greedy":
        utilities = df["proj"]  # classic optimizer on projections
    elif strategy == "random":
        # small noise on proj
        utilities = df["proj"] + np.random.normal(scale=0.01, size=len(df))
    else:
        raise ValueError("Unknown strategy")

    lineup, _ = optimize_lineup(df, slate.rules, utilities, random_tiebreak=True)
    return lineup

def episode_reward(lineup: pd.DataFrame) -> float:
    return float(lineup["actual"].sum())

def bandit_update(bandit: PositionBandits, slate: Slate, lineup: pd.DataFrame):
    # Use selected players' features and actual points as feedback per position
    X_sel = player_feature_matrix(lineup)
    y_sel = lineup["actual"].to_numpy()
    for pos, g in lineup.groupby("position"):
        Xp = player_feature_matrix(g)
        yp = g["actual"].to_numpy()
        bandit.update(pos, Xp, yp)

def run_rl_backtest(csv_path: str, site: str = "DK", episodes: str = "all",
                    strategy: str = "rl", alpha: float = 1.0, lam: float = 1.0,
                    max_from_team: int | None = 4) -> Dict[str, Any]:
    slates = load_slates_csv(csv_path, site)
    slates = sorted(slates, key=lambda s: (s.date, s.slate_id))
    slates = attach_rules(slates, site, max_from_team=max_from_team)

    positions = sorted(slates[0].df["position"].unique())
    bandit = PositionBandits(positions=positions, d=4, alpha=alpha, lam=lam)

    records = []
    cum_reward = 0.0
    for s in slates:
        lineup = select_lineup_for_slate(s, bandit, strategy=strategy)
        r = episode_reward(lineup)
        cum_reward += r
        records.append({
            "slate_id": s.slate_id,
            "date": s.date,
            "strategy": strategy,
            "reward_points": r,
            "salary_used": int(lineup["salary"].sum())
        })
        # Update on chosen lineup outcomes (bandit feedback)
        if strategy == "rl":
            bandit_update(bandit, s, lineup)

    summary = pd.DataFrame(records)
    return {"lineups": None, "summary": summary, "records": records}

def run_compare(csv_path: str, site: str = "DK", episodes: str = "all",
                max_from_team: int | None = 4) -> Dict[str, Any]:
    out = {}
    for strategy in ["rl","greedy","random"]:
        res = run_rl_backtest(csv_path, site=site, episodes=episodes, strategy=strategy, max_from_team=max_from_team)
        out[strategy] = res["summary"]
    return out
