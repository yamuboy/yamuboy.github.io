
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Set

@dataclass
class Slot:
    name: str
    eligible: Set[str]

@dataclass
class RosterRules:
    site: str
    salary_cap: int
    slots: List[Slot]
    max_from_team: Optional[int] = None

    def all_eligible(self) -> Dict[str, Set[str]]:
        return {s.name: set(s.eligible) for s in self.slots}

def dk_nfl_rules(max_from_team: Optional[int] = 4) -> RosterRules:
    # DraftKings NFL Classic
    return RosterRules(
        site="DK",
        salary_cap=50000,
        slots=[
            Slot("QB", {"QB"}),
            Slot("RB1", {"RB"}),
            Slot("RB2", {"RB"}),
            Slot("WR1", {"WR"}),
            Slot("WR2", {"WR"}),
            Slot("WR3", {"WR"}),
            Slot("TE", {"TE"}),
            Slot("FLEX", {"RB","WR","TE"}),
            Slot("DST", {"DST"}),
        ],
        max_from_team=max_from_team
    )

TEMPLATES = {"DK": dk_nfl_rules}
