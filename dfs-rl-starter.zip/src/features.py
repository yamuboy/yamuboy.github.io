
from __future__ import annotations
import numpy as np
import pandas as pd

def player_feature_matrix(players: pd.DataFrame) -> np.ndarray:
    """Return X features for bandit: [proj, salary/1000, proj_per_$, bias]."""
    proj = players["proj"].astype(float).to_numpy()
    sal = players["salary"].astype(float).to_numpy()
    val = proj / np.maximum(sal, 1.0)
    bias = np.ones_like(proj)
    X = np.vstack([proj, sal/1000.0, val, bias]).T  # shape (N,4)
    return X
