
from __future__ import annotations
import pandas as pd
from typing import Dict, List, Optional, Tuple
import pulp
from .roster import RosterRules

def optimize_lineup(players: pd.DataFrame,
                    rules: RosterRules,
                    utilities: pd.Series,
                    random_tiebreak: bool = False) -> Tuple[pd.DataFrame, float]:
    """
    Solve lineup selection maximizing 'utilities' subject to roster rules.
    players: DataFrame with columns [player_id, position, team, salary, ...]
    utilities: Series aligned to players.index
    Returns (selected_players_df, objective_value)
    """
    players = players.copy()
    players["util"] = utilities
    idx = list(players.index)
    x = pulp.LpVariable.dicts("x", idx, lowBound=0, upBound=1, cat=pulp.LpBinary)
    prob = pulp.LpProblem("DFS_Lineup", pulp.LpMaximize)

    # Objective
    if random_tiebreak:
        # tiny jitter to break ties
        import numpy as np
        jitter = pd.Series(np.random.uniform(-1e-6,1e-6,len(idx)), index=idx)
        obj = pulp.lpSum((players.loc[i, "util"] + jitter[i]) * x[i] for i in idx)
    else:
        obj = pulp.lpSum(players.loc[i, "util"] * x[i] for i in idx)
    prob += obj

    # Salary cap
    prob += pulp.lpSum(players.loc[i, "salary"] * x[i] for i in idx) <= rules.salary_cap

    # Slots: exactly one per slot (with eligibility)
    for slot in rules.slots:
        elig_idx = [i for i in idx if players.loc[i, "position"] in slot.eligible]
        prob += pulp.lpSum(x[i] for i in elig_idx) >= 1, f"{slot.name}_min1"
    # Total players = #slots
    prob += pulp.lpSum(x[i] for i in idx) == len(rules.slots)

    # Team max constraint (optional)
    if rules.max_from_team is not None:
        for team, g in players.groupby("team"):
            prob += pulp.lpSum(x[i] for i in g.index) <= rules.max_from_team

    # Position lower bounds to avoid filling FLEX incorrectly
    # Enforce that we select at least the required non-FLEX slots per position
    req_counts = {}
    for slot in rules.slots:
        for p in slot.eligible:
            req_counts[p] = max(req_counts.get(p,0) + (1 if slot.eligible == {p} else 0), req_counts.get(p,0))
    for p, c in req_counts.items():
        elig_idx = [i for i in idx if players.loc[i, "position"] == p]
        prob += pulp.lpSum(x[i] for i in elig_idx) >= c

    # Solve
    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    chosen_idx = [i for i in idx if x[i].value() == 1]
    sel = players.loc[chosen_idx].copy()
    return sel, pulp.value(prob.objective)
