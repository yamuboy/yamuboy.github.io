#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MA Millionaire Surtax: Panel ETL + DiD/Event-Study Analysis

What this script does
---------------------
1) Builds a state-year panel (2013–2024) for Massachusetts (treatment) and control states
   (NH, VT, CT, RI, ME, NY).
2) Reads local CSV sources you provide (see /data/ files listed below).
3) Computes CPI-deflated revenue per capita, sets up DiD variables, and saves a final panel CSV.
4) Runs a two-way fixed effects DiD and an event-study, saves a figure, and prints regression tables.

How to use
----------
1) Prepare the following CSVs and place them in ./data (same folder as this script or edit DATA_DIR):
   - population.csv:           columns -> state,year,population
   - revenue.csv:              columns -> state,year,total_tax_revenue_nominal
                                (If your column name differs, set REVENUE_COLS below)
   - cpi_u.csv:                columns -> year,cpi
                                (Annual CPI-U, e.g., BLS average index; base year handled by script)
   - tax_rates.csv:            columns -> state,year,top_marginal_rate
                                (As a decimal, e.g., 0.09 for 9%)
   - acs_migration.csv (opt):  columns -> state,year,net_domestic_migration
                                (Counts; script will compute per 1,000 population if provided)
   - irs_migration.csv (opt):  columns -> state,year,net_migration_returns,net_migration_agi
                                (Net inflow of returns and AGI if available; optional)
2) Run:  python ma_did_panel_etl.py
3) Outputs (in ./data_out):
   - panel_final.csv
   - did_results.txt
   - event_study_results.txt
   - event_study_plot.png

Notes
-----
- This script does NOT fetch data from the web. It expects local CSVs.
- If a required file is missing, a *_template.csv will be generated to guide data prep.
- Rates should be decimals (e.g., 0.09 for 9%). Revenue should be nominal dollars.

Author: (Your name)
"""

import os
import sys
import math
import warnings
from typing import List, Dict, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.formula.api as smf

# ---------------- Configuration ----------------

STATES = ["MA", "NH", "VT", "CT", "RI", "ME", "NY"]
YEARS = list(range(2013, 2025))  # 2013–2024 inclusive
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
OUT_DIR  = os.path.join(os.path.dirname(__file__), "data_out")
os.makedirs(OUT_DIR, exist_ok=True)

# Expected filenames
FN_POP = "population.csv"
FN_REV = "revenue.csv"
FN_CPI = "cpi_u.csv"
FN_TAX = "tax_rates.csv"
FN_ACS = "acs_migration.csv"     # optional
FN_IRS = "irs_migration.csv"     # optional

# Column name fallbacks if your files use different headers
POP_COLS = dict(state="state", year="year", population="population")
REV_COLS = dict(state="state", year="year", revenue="total_tax_revenue_nominal")  # rename if needed
CPI_COLS = dict(year="year", cpi="cpi")
TAX_COLS = dict(state="state", year="year", top_rate="top_marginal_rate")
ACS_COLS = dict(state="state", year="year", net_mig="net_domestic_migration")
IRS_COLS = dict(state="state", year="year",
                net_returns="net_migration_returns",
                net_agi="net_migration_agi")

BASE_CPI_YEAR = 2024  # real dollars base year for deflation

# ---------------- Utilities ----------------

def _template_path(name: str) -> str:
    return os.path.join(DATA_DIR, name.replace(".csv", "_template.csv"))

def _ensure_csv_or_template(path: str, headers: List[str]) -> Optional[pd.DataFrame]:
    """
    Try reading CSV at path. If not found, create a template with the given headers.
    Return DataFrame or None if file didn't exist.
    """
    if os.path.exists(path):
        try:
            df = pd.read_csv(path)
            return df
        except Exception as e:
            print(f"[ERROR] Failed to read {path}: {e}")
            sys.exit(1)
    else:
        # create template
        tpath = _template_path(os.path.basename(path))
        if not os.path.exists(tpath):
            pd.DataFrame(columns=headers).to_csv(tpath, index=False)
        print(f"[MISSING] {os.path.basename(path)} not found. Created template at {tpath}")
        return None

def _harmonize(df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
    """
    Rename columns in df according to mapping if present.
    """
    col_map = {c: mapping.get(c, c) for c in df.columns}
    # Invert mapping if it's mapping logical->file columns
    inv = {}
    for logical, filecol in mapping.items():
        if filecol in df.columns:
            inv[filecol] = logical
    if inv:
        df = df.rename(columns=inv)
    return df

def _state_year_grid(states: List[str], years: List[int]) -> pd.DataFrame:
    return pd.MultiIndex.from_product([states, years], names=["state", "year"]).to_frame(index=False)

def _require_columns(df: pd.DataFrame, required: List[str], tag: str):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{tag} is missing required columns: {missing}. Found columns: {list(df.columns)}")

# ---------------- Load Inputs ----------------

def load_population() -> Optional[pd.DataFrame]:
    path = os.path.join(DATA_DIR, FN_POP)
    df = _ensure_csv_or_template(path, [POP_COLS["state"], POP_COLS["year"], POP_COLS["population"]])
    if df is None:
        return None
    df = _harmonize(df, POP_COLS)
    _require_columns(df, ["state","year","population"], "population.csv")
    df = df[df["state"].isin(STATES) & df["year"].between(min(YEARS), max(YEARS))]
    return df

def load_revenue() -> Optional[pd.DataFrame]:
    path = os.path.join(DATA_DIR, FN_REV)
    df = _ensure_csv_or_template(path, [REV_COLS["state"], REV_COLS["year"], REV_COLS["revenue"]])
    if df is None:
        return None
    df = _harmonize(df, REV_COLS)
    _require_columns(df, ["state","year","revenue"], "revenue.csv")
    df = df[df["state"].isin(STATES) & df["year"].between(min(YEARS), max(YEARS))]
    return df

def load_cpi() -> Optional[pd.DataFrame]:
    path = os.path.join(DATA_DIR, FN_CPI)
    df = _ensure_csv_or_template(path, [CPI_COLS["year"], CPI_COLS["cpi"]])
    if df is None:
        return None
    df = _harmonize(df, CPI_COLS)
    _require_columns(df, ["year","cpi"], "cpi_u.csv")
    df = df[df["year"].between(min(YEARS), max(YEARS))]
    return df

def load_tax_rates() -> Optional[pd.DataFrame]:
    path = os.path.join(DATA_DIR, FN_TAX)
    df = _ensure_csv_or_template(path, [TAX_COLS["state"], TAX_COLS["year"], TAX_COLS["top_rate"]])
    if df is None:
        return None
    df = _harmonize(df, TAX_COLS)
    _require_columns(df, ["state","year","top_rate"], "tax_rates.csv")
    df = df[df["state"].isin(STATES) & df["year"].between(min(YEARS), max(YEARS))]
    return df

def load_acs_migration() -> Optional[pd.DataFrame]:
    path = os.path.join(DATA_DIR, FN_ACS)
    df = _ensure_csv_or_template(path, [ACS_COLS["state"], ACS_COLS["year"], ACS_COLS["net_mig"]])
    if df is None:
        return None
    df = _harmonize(df, ACS_COLS)
    _require_columns(df, ["state","year","net_mig"], "acs_migration.csv")
    df = df[df["state"].isin(STATES) & df["year"].between(min(YEARS), max(YEARS))]
    return df

def load_irs_migration() -> Optional[pd.DataFrame]:
    path = os.path.join(DATA_DIR, FN_IRS)
    df = _ensure_csv_or_template(path, [IRS_COLS["state"], IRS_COLS["year"], IRS_COLS["net_returns"], IRS_COLS["net_agi"]])
    if df is None:
        return None
    df = _harmonize(df, IRS_COLS)
    _require_columns(df, ["state","year","net_returns","net_agi"], "irs_migration.csv")
    df = df[df["state"].isin(STATES) & df["year"].between(min(YEARS), max(YEARS))]
    return df

# ---------------- Build Panel ----------------

def build_panel(pop: pd.DataFrame,
                rev: pd.DataFrame,
                cpi: pd.DataFrame,
                tax: pd.DataFrame,
                acs: Optional[pd.DataFrame]=None,
                irs: Optional[pd.DataFrame]=None) -> pd.DataFrame:
    panel = _state_year_grid(STATES, YEARS)
    # Merge Population
    panel = panel.merge(pop, on=["state","year"], how="left")
    # Merge Revenue (nominal)
    panel = panel.merge(rev, on=["state","year"], how="left")
    # Merge CPI
    panel = panel.merge(cpi, on=["year"], how="left", suffixes=("","_cpi"))
    # Merge Tax Rates
    panel = panel.merge(tax, on=["state","year"], how="left")

    # Optional merges
    if acs is not None:
        panel = panel.merge(acs, on=["state","year"], how="left")
    if irs is not None:
        panel = panel.merge(irs, on=["state","year"], how="left")

    # Construct treatment/post
    panel["treatment"] = (panel["state"] == "MA").astype(int)
    panel["post"] = (panel["year"] >= 2023).astype(int)
    panel["did"] = panel["treatment"] * panel["post"]

    # CPI deflation to BASE_CPI_YEAR
    base_cpi_val = panel.loc[panel["year"]==BASE_CPI_YEAR, "cpi"].dropna().unique()
    if base_cpi_val.size == 0:
        warnings.warn(f"No CPI value for BASE_CPI_YEAR={BASE_CPI_YEAR}. Using max available year as base.")
        latest_yr = panel["year"].dropna().max()
        base_cpi_val = panel.loc[panel["year"]==latest_yr, "cpi"].dropna().unique()
    base_cpi = float(base_cpi_val[0])
    panel["revenue_real"] = panel["revenue"] * (base_cpi / panel["cpi"])

    # Per-capita metrics
    panel["rev_per_capita_real"] = panel["revenue_real"] / panel["population"]
    panel["rev_per_capita_nominal"] = panel["revenue"] / panel["population"]

    # Migration rate per 1,000 if net_mig present
    if "net_mig" in panel.columns:
        panel["net_mig_per_1k"] = (panel["net_mig"] / panel["population"]) * 1000.0

    return panel

# ---------------- DiD & Event Study ----------------

def run_did(panel: pd.DataFrame, out_txt: str) -> None:
    """
    Two-way fixed effects DiD on real revenue per capita.
    """
    df = panel.dropna(subset=["rev_per_capita_real"])
    # TWFE via OLS + dummies for state and year
    # Cluster by state
    formula = "rev_per_capita_real ~ did + C(state) + C(year)"
    model = smf.ols(formula, data=df).fit(cov_type='cluster', cov_kwds={'groups': df['state']})
    with open(out_txt, "w") as f:
        f.write(model.summary().as_text())
    print("[DiD] Results written to", out_txt)
    return

def run_event_study(panel: pd.DataFrame, out_txt: str, out_png: str,
                    window_pre: int=6, window_post: int=2) -> None:
    """
    Event study around 2023 (t=0). Creates leads/lags and excludes -1 as the omitted category.
    """
    df = panel.copy()
    df["event_time"] = df["year"] - 2023

    # Keep a symmetric-ish window
    df = df[(df["event_time"] >= -window_pre) & (df["event_time"] <= window_post)]

    # Create dummies for event_time except -1
    for k in range(-window_pre, window_post+1):
        if k == -1:
            continue
        df[f"et_{k}"] = (df["event_time"] == k).astype(int) * df["treatment"]  # interacted with treatment

    # Build formula: outcome ~ sum(et_k) + FE + cluster
    # Omit et_-1 (base period) by not including it.
    et_terms = " + ".join([f"et_{k}" for k in range(-window_pre, window_post+1) if k != -1])
    formula = f"rev_per_capita_real ~ {et_terms} + C(state) + C(year)"
    model = smf.ols(formula, data=df).fit(cov_type='cluster', cov_kwds={'groups': df['state']})

    with open(out_txt, "w") as f:
        f.write(model.summary().as_text())
    print("[Event Study] Results written to", out_txt)

    # Extract coefficients & CIs for plot
    coefs, lower, upper, es = [], [], [], []
    for k in range(-window_pre, window_post+1):
        if k == -1:
            continue
        term = f"et_{k}"
        if term in model.params.index:
            b = model.params[term]
            se = model.bse[term]
            coefs.append(b)
            lower.append(b - 1.96*se)
            upper.append(b + 1.96*se)
            es.append(k)
        else:
            # If term is missing due to collinearity, drop
            pass

    # Plot
    plt.figure(figsize=(7,4.5))
    plt.axhline(0, linestyle="--")
    plt.axvline(-1, linestyle=":")  # omitted/base period
    plt.errorbar(es, coefs, yerr=[np.array(coefs)-np.array(lower), np.array(upper)-np.array(coefs)],
                 fmt='o', capsize=3)
    plt.title("Event-Study: Effect on Real Revenue Per Capita (MA vs Controls)")
    plt.xlabel("Event time (years, 0 = 2023)")
    plt.ylabel("Treatment effect (relative to t=-1)")
    plt.tight_layout()
    plt.savefig(out_png, dpi=180)
    print("[Event Study] Plot saved to", out_png)

# ---------------- Main ----------------

def main():
    pop = load_population()
    rev = load_revenue()
    cpi = load_cpi()
    tax = load_tax_rates()
    acs = load_acs_migration()
    irs = load_irs_migration()

    missing_required = []
    if pop is None: missing_required.append(FN_POP)
    if rev is None: missing_required.append(FN_REV)
    if cpi is None: missing_required.append(FN_CPI)
    if tax is None: missing_required.append(FN_TAX)

    if len(missing_required) > 0:
        print("\n[SETUP NEEDED] The following required files are missing in ./data:")
        for fn in missing_required:
            print(" -", fn)
        print("Templates created in ./data for your convenience. Fill them and re-run.\n")
        # Still write an empty panel shell for reference
        panel_shell = _state_year_grid(STATES, YEARS)
        panel_shell.to_csv(os.path.join(OUT_DIR, "panel_shell.csv"), index=False)
        print("[INFO] Wrote empty panel shell to data_out/panel_shell.csv")
        sys.exit(0)

    panel = build_panel(pop, rev, cpi, tax, acs, irs)

    # Save final panel
    out_csv = os.path.join(OUT_DIR, "panel_final.csv")
    panel.to_csv(out_csv, index=False)
    print("[OK] Panel saved to", out_csv)

    # Quick pre-trend check plot (nominal revenues per capita) for visuals
    try:
        fig_path = os.path.join(OUT_DIR, "pretrends_revpc_real.png")
        pivot = panel.pivot_table(index="year", columns="state", values="rev_per_capita_real")
        plt.figure(figsize=(8,5))
        for s in STATES:
            if s in pivot.columns:
                plt.plot(pivot.index, pivot[s], label=s, linewidth=1.8)
        plt.title("Real Revenue per Capita (Pre & Post)")
        plt.xlabel("Year")
        plt.ylabel("Real $ per person (base {0})".format(BASE_CPI_YEAR))
        plt.legend(ncol=3, fontsize=8)
        plt.tight_layout()
        plt.savefig(fig_path, dpi=180)
        print("[Plot] Pretrend figure saved to", fig_path)
    except Exception as e:
        print("[WARN] Could not plot pretrends:", e)

    # Run DiD
    did_txt = os.path.join(OUT_DIR, "did_results.txt")
    run_did(panel, did_txt)

    # Run Event Study
    es_txt = os.path.join(OUT_DIR, "event_study_results.txt")
    es_png = os.path.join(OUT_DIR, "event_study_plot.png")
    run_event_study(panel, es_txt, es_png, window_pre=6, window_post=2)

if __name__ == "__main__":
    main()
