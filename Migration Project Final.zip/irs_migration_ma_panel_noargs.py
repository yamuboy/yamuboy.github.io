#!/usr/bin/env python3
"""
IRS Migration Panel Builder (Massachusetts, outflow + inflow, no arguments)

• Scans the directory where this script resides for:
    countyoutflow*.csv  and  countyinflow*.csv
  with filenames containing 4 digits like '1213' → start_year=2012, end_year=2013.

• Builds tidy panels and summaries focused on Massachusetts (FIPS 25):
  - Outflows: MA (origin) → other states
  - Inflows:  other states → MA (destination)
  - Net flows by state and by category (Neighbor / ZeroTax / Other)
  - County × state aggregates for both out and in

Outputs (written to ./out next to the script):
  - ma_outflows_panel.csv
  - ma_inflows_panel.csv
  - ma_state_year_flows.csv               (stacked Outflow / Inflow)
  - ma_state_year_net.csv                 (Inflow - Outflow, by state/year)
  - summary_endyear_category.csv          (Outflow / Inflow / Net by Neighbor/ZeroTax/Other)
  - county_to_neighbors_outflows.csv      (MA county → neighbor state × year)
  - county_to_zerotax_outflows.csv
  - county_from_neighbors_inflows.csv     (Neighbor state → MA county × year)
  - county_from_zerotax_inflows.csv

Notes:
  * IRS 'agi' is in THOUSANDS of dollars. We add 'agi_usd' = agi * 1000.
  * Removes "Total Migration" rows (county fips == 0).
  * Requires pandas installed:  pip install pandas
"""

import re
import sys
from pathlib import Path
import pandas as pd

# --- Config ---
MA_FIPS = 25
FIPS2ABBR = {
    1:"AL", 2:"AK", 4:"AZ", 5:"AR", 6:"CA", 8:"CO", 9:"CT", 10:"DE",
    11:"DC", 12:"FL", 13:"GA", 15:"HI", 16:"ID", 17:"IL", 18:"IN", 19:"IA",
    20:"KS", 21:"KY", 22:"LA", 23:"ME", 24:"MD", 25:"MA", 26:"MI", 27:"MN",
    28:"MS", 29:"MO", 30:"MT", 31:"NE", 32:"NV", 33:"NH", 34:"NJ", 35:"NM",
    36:"NY", 37:"NC", 38:"ND", 39:"OH", 40:"OK", 41:"OR", 42:"PA", 44:"RI",
    45:"SC", 46:"SD", 47:"TN", 48:"TX", 49:"UT", 50:"VT", 51:"VA", 53:"WA",
    54:"WV", 55:"WI", 56:"WY", 72:"PR"
}
ABBR2FIPS = {v:k for k,v in FIPS2ABBR.items()}

NEIGHBORS = {9:"CT", 33:"NH", 36:"NY", 44:"RI", 50:"VT"}
ZERO_TAX = {2:"AK", 12:"FL", 32:"NV", 46:"SD", 47:"TN", 48:"TX", 53:"WA", 56:"WY"}

REQ_OUT = ["y1_statefips","y1_countyfips","y2_statefips","y2_countyfips","n1","n2","agi"]
REQ_IN  = ["y2_statefips","y2_countyfips","y1_statefips","y1_countyfips","n1","n2","agi"]

# --- Helpers ---
def parse_years_from_name(name: str):
    m = re.search(r"(\d{4})", name)
    if not m:
        return (None, None)
    yy = m.group(1)
    return (int("20"+yy[:2]), int("20"+yy[2:]))

def read_csv_any(path: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(path)
    except UnicodeDecodeError:
        return pd.read_csv(path, encoding="latin1")

def add_years(df: pd.DataFrame, name: str) -> pd.DataFrame:
    s,e = parse_years_from_name(name)
    df = df.copy()
    df["start_year"] = s
    df["end_year"] = e
    return df

def ensure_cols(df: pd.DataFrame, required, ctx: str):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns {missing} in {ctx}")

def label_group(state_fips: int) -> str:
    if state_fips in NEIGHBORS: return "Neighbor"
    if state_fips in ZERO_TAX: return "ZeroTax"
    return "Other"

# --- Main ---
def main():
    here = Path(__file__).resolve().parent
    outdir = here / "out"
    outdir.mkdir(exist_ok=True)

    # Load and concat OUTFLOW files
    outflow_files = sorted(here.glob("countyoutflow*.csv"))
    out_frames = []
    for fp in outflow_files:
        df = read_csv_any(fp)
        ensure_cols(df, REQ_OUT, fp.name)
        df = add_years(df, fp.name)
        out_frames.append(df)
    out_all = pd.concat(out_frames, ignore_index=True) if out_frames else pd.DataFrame(columns=REQ_OUT+["start_year","end_year"])

    # Load and concat INFLOW files
    inflow_files = sorted(here.glob("countyinflow*.csv"))
    in_frames = []
    for fp in inflow_files:
        df = read_csv_any(fp)
        ensure_cols(df, REQ_IN, fp.name)
        df = add_years(df, fp.name)
        in_frames.append(df)
    in_all = pd.concat(in_frames, ignore_index=True) if in_frames else pd.DataFrame(columns=REQ_IN+["start_year","end_year"])

    if out_all.empty and in_all.empty:
        print("No countyinflow*.csv or countyoutflow*.csv files found next to the script.")
        sys.exit(1)

    # Clean: drop "Total Migration" summary rows where county fips == 0
    if not out_all.empty:
        out_all = out_all[(out_all["y1_countyfips"]>0) & (out_all["y2_countyfips"]>0)].copy()
    if not in_all.empty:
        in_all = in_all[(in_all["y1_countyfips"]>0) & (in_all["y2_countyfips"]>0)].copy()

    # --- OUTFLOWS from MA ---
    ma_out = out_all[out_all["y1_statefips"]==MA_FIPS].copy()
    if not ma_out.empty:
        ma_out["origin_fips"] = ma_out["y1_statefips"]*1000 + ma_out["y1_countyfips"]
        ma_out["dest_fips"]   = ma_out["y2_statefips"]*1000 + ma_out["y2_countyfips"]
        ma_out["agi_usd"]     = ma_out["agi"]*1000
        ma_out["group"]       = ma_out["y2_statefips"].apply(label_group)
        ma_out["dest_state"]  = ma_out["y2_statefips"].map(FIPS2ABBR)
        ma_out.to_csv(outdir/"ma_outflows_panel.csv", index=False)
    else:
        ma_out = pd.DataFrame(columns=REQ_OUT+["start_year","end_year","origin_fips","dest_fips","agi_usd","group","dest_state"])

    # --- INFLOWS to MA ---
    ma_in = in_all[in_all["y2_statefips"]==MA_FIPS].copy()
    if not ma_in.empty:
        ma_in["origin_fips"] = ma_in["y1_statefips"]*1000 + ma_in["y1_countyfips"]
        ma_in["dest_fips"]   = ma_in["y2_statefips"]*1000 + ma_in["y2_countyfips"]
        ma_in["agi_usd"]     = ma_in["agi"]*1000
        ma_in["group"]       = ma_in["y1_statefips"].apply(label_group)  # group by OTHER state (origin)
        ma_in["origin_state"] = ma_in["y1_statefips"].map(FIPS2ABBR)
        ma_in.to_csv(outdir/"ma_inflows_panel.csv", index=False)
    else:
        ma_in = pd.DataFrame(columns=REQ_IN+["start_year","end_year","origin_fips","dest_fips","agi_usd","group","origin_state"])

    # --- State/year stacked flows (Outflow vs Inflow) ---
    # Outflow: MA → other states (key by y2_statefips)
    out_state = (ma_out.groupby(["end_year","y2_statefips"])[["n1","n2","agi","agi_usd"]]
                      .sum().reset_index().rename(columns={"y2_statefips":"other_state_fips"}))
    out_state["other_state"] = out_state["other_state_fips"].map(FIPS2ABBR)
    out_state["flow"] = "Outflow"

    # Inflow: other states → MA (key by y1_statefips)
    in_state = (ma_in.groupby(["end_year","y1_statefips"])[["n1","n2","agi","agi_usd"]]
                    .sum().reset_index().rename(columns={"y1_statefips":"other_state_fips"}))
    in_state["other_state"] = in_state["other_state_fips"].map(FIPS2ABBR)
    in_state["flow"] = "Inflow"

    state_year = pd.concat([out_state, in_state], ignore_index=True, sort=False)
    if not state_year.empty:
        state_year.to_csv(outdir/"ma_state_year_flows.csv", index=False)

    # --- Net by state/year (Inflow - Outflow) ---
    if not state_year.empty:
        out_w = out_state.set_index(["end_year","other_state_fips"])[["n1","n2","agi","agi_usd"]]
        in_w  = in_state.set_index(["end_year","other_state_fips"])[["n1","n2","agi","agi_usd"]]
        # align and subtract
        net = in_w.reindex(in_w.index.union(out_w.index), fill_value=0) - out_w.reindex(in_w.index.union(out_w.index), fill_value=0)
        net = net.reset_index()
        net["other_state"] = net["other_state_fips"].map(FIPS2ABBR)
        net.rename(columns={"n1":"n1_net","n2":"n2_net","agi":"agi_net","agi_usd":"agi_usd_net"}, inplace=True)
        net = net.sort_values(["end_year","other_state"])
        net.to_csv(outdir/"ma_state_year_net.csv", index=False)

    # --- Category summaries (Neighbor / ZeroTax / Other) for Outflow / Inflow / Net ---
    def cat_sum(frame: pd.DataFrame, state_col: str, cols: list, label: str):
        if frame.empty: 
            return pd.DataFrame(columns=["end_year","group"]+cols+["flow"])
        tmp = frame.copy()
        tmp["group"] = tmp[state_col].apply(lambda s: label_group(int(s)))
        g = tmp.groupby(["end_year","group"])[cols].sum().reset_index()
        g["flow"] = label
        return g

    cols = ["n1","n2","agi","agi_usd"]
    cat_out = cat_sum(out_state, "other_state_fips", cols, "Outflow")
    cat_in  = cat_sum(in_state,  "other_state_fips", cols, "Inflow")

    # Net by category: compute out/in by category then subtract
    def to_cat_index(df):
        return df.set_index(["end_year","group"])[cols]
    if not cat_out.empty or not cat_in.empty:
        idx = to_cat_index(cat_out).index.union(to_cat_index(cat_in).index)
        out_i = to_cat_index(cat_out).reindex(idx, fill_value=0)
        in_i  = to_cat_index(cat_in).reindex(idx, fill_value=0)
        cat_net = (in_i - out_i).reset_index()
        cat_net["flow"] = "Net"
        cat_all = pd.concat([cat_out, cat_in, cat_net], ignore_index=True, sort=False)
        cat_all.to_csv(outdir/"summary_endyear_category.csv", index=False)

    # --- County × State aggregates ---
    # Out: MA county → neighbor/zero-tax states
    def county_by_bucket(df: pd.DataFrame, dest_state_col: str, county_col: str, bucket: dict, out_name: str):
        if df.empty:
            return
        sub = df[df[dest_state_col].isin(bucket.keys())]
        if sub.empty:
            return
        grp = (sub.groupby(["end_year", county_col, dest_state_col])[["n1","n2","agi","agi_usd"]]
                  .sum().reset_index()
                  .rename(columns={county_col:"ma_county_fips", dest_state_col:"dest_state_fips"}))
        grp["dest_state"] = grp["dest_state_fips"].map(FIPS2ABBR)
        grp.to_csv(outdir/out_name, index=False)

    county_by_bucket(ma_out, "y2_statefips", "y1_countyfips", NEIGHBORS, "county_to_neighbors_outflows.csv")
    county_by_bucket(ma_out, "y2_statefips", "y1_countyfips", ZERO_TAX,  "county_to_zerotax_outflows.csv")

    # In: neighbor/zero-tax states → MA county
    def county_from_bucket(df: pd.DataFrame, origin_state_col: str, county_col: str, bucket: dict, out_name: str):
        if df.empty:
            return
        sub = df[df[origin_state_col].isin(bucket.keys())]
        if sub.empty:
            return
        grp = (sub.groupby(["end_year", county_col, origin_state_col])[["n1","n2","agi","agi_usd"]]
                  .sum().reset_index()
                  .rename(columns={county_col:"ma_county_fips", origin_state_col:"origin_state_fips"}))
        grp["origin_state"] = grp["origin_state_fips"].map(FIPS2ABBR)
        grp.to_csv(outdir/out_name, index=False)

    county_from_bucket(ma_in, "y1_statefips", "y2_countyfips", NEIGHBORS, "county_from_neighbors_inflows.csv")
    county_from_bucket(ma_in, "y1_statefips", "y2_countyfips", ZERO_TAX,  "county_from_zerotax_inflows.csv")

    print(f"Done. Outputs written to: {outdir}")

if __name__ == "__main__":
    main()
