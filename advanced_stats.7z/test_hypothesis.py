# =============================================================================
# STEP 1: SETUP AND IMPORTS
# =============================================================================

# Import all the tools we'll need for this analysis
import pandas as pd
import numpy as np
import nfl_data_py as nfl
from scipy import stats # We need scipy for the t-test

# Set pandas to display all columns for better inspection
pd.set_option('display.max_columns', None)
print("Setup Complete.")

# =============================================================================
# STEP 2: GATHER DATA AND ENGINEER DEFENSIVE PERFORMANCE METRIC
# =============================================================================
print("\n--- Gathering Data and Engineering Defensive Metric ---")
# Define the seasons we want to analyze
years = range(2016, 2024)

# Fetch historical weekly player data
weekly_df = nfl.import_weekly_data(years)

# Filter for QB and WR positions only
skill_positions_df = weekly_df[weekly_df['position'].isin(['QB', 'WR'])].copy()

# Calculate the total fantasy points allowed by each defense to these positions each week
defense_skill_pts_df = skill_positions_df.groupby(['opponent_team', 'season', 'week']).agg(
    skill_pts_allowed=('fantasy_points', 'sum')
).reset_index()

print("Defensive performance metric calculated.")

# =============================================================================
# STEP 3: PREPARE DAK'S DATA AND MERGE WITH DEFENSIVE METRIC
# =============================================================================
print("\n--- Preparing Dak's Data and Merging ---")

# Isolate Dak's regular season games
dak_games_df = weekly_df[
    (weekly_df['player_display_name'] == 'Dak Prescott') &
    (weekly_df['season_type'] == 'REG')
][['season', 'week', 'opponent_team', 'fantasy_points']].copy()

# THIS IS THE CRITICAL STEP: We need to align Dak's game in week 't' with
# the opponent's defensive performance from week 't-1'.
# We create a 'lookup_week' in the defensive data to facilitate the merge.
defense_skill_pts_df['lookup_week'] = defense_skill_pts_df['week'] + 1

# Merge Dak's game log with his opponent's performance from the *previous* week
merged_df = pd.merge(
    dak_games_df,
    defense_skill_pts_df,
    left_on=['season', 'week', 'opponent_team'],
    right_on=['season', 'lookup_week', 'opponent_team'],
    how='left' # Use left merge to keep all of Dak's games
)

# Clean up the merged dataframe
merged_df = merged_df.drop(columns=['lookup_week', 'week_y']).rename(columns={'week_x': 'week'})
print("Data merged successfully.")

# =============================================================================
# STEP 4: DEFINE GROUPS AND HANDLE MISSING DATA
# =============================================================================
print("\n--- Defining 'Hot Defense' Group ---")

# Drop games where we have no prior-week defensive data (e.g., Week 1 games)
merged_df.dropna(subset=['skill_pts_allowed'], inplace=True)

# Define a "hot defense" as one that performed in the bottom 25th percentile
# (i.e., allowed the fewest points) in the prior week.
q1_threshold = merged_df['skill_pts_allowed'].quantile(0.25)

print(f"Defining a 'hot defense' as one allowing <= {q1_threshold:.2f} fantasy points to QBs/WRs.")

# Create a new column to identify which group each game belongs to
merged_df['is_vs_hot_defense'] = merged_df['skill_pts_allowed'] <= q1_threshold

# Create our two groups for the t-test
scores_vs_hot_def = merged_df[merged_df['is_vs_hot_defense'] == True]['fantasy_points']
scores_vs_other_def = merged_df[merged_df['is_vs_hot_defense'] == False]['fantasy_points']

print(f"Number of games against 'hot' defenses: {len(scores_vs_hot_def)}")
print(f"Number of games against 'other' defenses: {len(scores_vs_other_def)}")


# =============================================================================
# STEP 5: PERFORM THE STATISTICAL TEST AND INTERPRET
# =============================================================================
print("\n--- Performing Independent Samples t-test ---")

# Calculate the average scores for context
avg_vs_hot = scores_vs_hot_def.mean()
avg_vs_other = scores_vs_other_def.mean()

# Perform the t-test.
# We use alternative='less' because our hypothesis is that the 'hot defense' group has a LOWER mean.
# We use equal_var=False for Welch's t-test, which is more robust.
t_stat, p_value = stats.ttest_ind(
    scores_vs_hot_def,
    scores_vs_other_def,
    equal_var=False,
    alternative='less'
)

# --- Final Interpretation ---
print("\n" + "="*50)
print("       STATISTICAL HYPOTHESIS TEST RESULTS")
print("="*50)
print(f"\nHypothesis: Dak Prescott performs POORLY against defenses that had a shutdown performance the prior week.")
print(f"Null Hypothesis (H₀): There is no difference in performance.")
print(f"Alternative Hypothesis (H₁): Dak's average score is LOWER against these 'hot' defenses.")
print("-"*50)
print("\nRESULTS:\n")
print(f"Average Fantasy Score vs. 'Hot' Defenses:   {avg_vs_hot:.2f}")
print(f"Average Fantasy Score vs. 'Other' Defenses:  {avg_vs_other:.2f}")
print(f"\nTest Statistic (t-value): {t_stat:.4f}")
print(f"P-value: {p_value:.4f}")
print("-"*50)

print("\nCONCLUSION:\n")
# Set our significance level (alpha)
alpha = 0.05
if p_value < alpha:
    print(f"The p-value ({p_value:.4f}) is LESS than our significance level of {alpha}.")
    print("\nWe REJECT the null hypothesis.")
    print("\nThere is STRONG STATISTICAL EVIDENCE to support the claim that Dak Prescott performs significantly worse")
    print("against defenses that are coming off a top-tier performance against QBs and WRs.")
else:
    print(f"The p-value ({p_value:.4f}) is GREATER than our significance level of {alpha}.")
    print("\nWe FAIL TO REJECT the null hypothesis.")
    print("\nThere is NOT enough statistical evidence to support the claim that Dak Prescott's performance")
    print("is significantly worse against defenses coming off a hot week.")
print("="*50)