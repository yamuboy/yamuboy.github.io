# Import all the tools we'll need
# =============================================================================
# STEP 1: SETUP AND IMPORTS
# =============================================================================
# Install the necessary library in the Colab environment
# Import all the tools we'll need for this analysis
import pandas as pd
import numpy as np
import nfl_data_py as nfl
import statsmodels.api as sm

# Set pandas to display all columns for better inspection
pd.set_option('display.max_columns', None)
print("Setup Complete.")

# =============================================================================
# STEP 2: DATA GATHERING
# =============================================================================
print("\n--- Starting Data Gathering ---")
# Define the seasons we want to analyze
years = range(2016, 2024)

# Fetch weekly player-level data
print("Fetching weekly player data...")
weekly_df = nfl.import_weekly_data(years)

# Fetch game-level schedule data
print("Fetching game schedule data...")
schedule_df = nfl.import_schedules(years)

# We need roster data to reliably identify QBs
print("Fetching roster data...")
roster_df = nfl.import_rosters(years)
qb_ids = roster_df[roster_df['position'] == 'QB']['player_id'].unique()

print("Data Gathering Complete.")


# =============================================================================
# STEP 3: ENGINEER OPPONENT DEFENSIVE FEATURES
# =============================================================================
print("\n--- Engineering Opponent Defensive Features ---")

# Isolate stats for QB position only
weekly_qb_df = weekly_df[weekly_df['player_id'].isin(qb_ids)]

# Group by the defense (opponent_team) and aggregate stats allowed to QBs
defense_stats_allowed = weekly_qb_df.groupby(['opponent_team', 'season', 'week']).agg(
    qb_fantasy_points_allowed=('fantasy_points', 'sum'),
    qb_sacks_forced=('sacks', 'sum'),
    qb_interceptions_forced=('interceptions', 'sum')
).reset_index()

# Calculate the 4-week rolling average for these defensive stats
defense_stats_allowed = defense_stats_allowed.sort_values(by=['opponent_team', 'season', 'week'])

for stat in ['qb_fantasy_points_allowed', 'qb_sacks_forced', 'qb_interceptions_forced']:
    # The .shift(1) is CRITICAL to prevent data leakage. We need the defensive average *before* this week's game.
    defense_stats_allowed[f'rolling_4wk_avg_{stat}'] = defense_stats_allowed.groupby('opponent_team')[stat].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )

print("Defensive features engineered successfully.")


# =============================================================================
# STEP 4: PREPARE AND MERGE ALL DATA
# =============================================================================
print("\n--- Preparing and Merging All Data Sources ---")

# Isolate Dak's regular season games and sort chronologically
dak_df_raw = weekly_df[
    (weekly_df['player_display_name'] == 'Dak Prescott') &
    (weekly_df['season_type'] == 'REG')
].copy()
dak_df_raw = dak_df_raw.sort_values(by=['season', 'week']).reset_index(drop=True)

# Merge Dak's data with the engineered defensive stats of his opponent for each week
dak_df_merged = pd.merge(
    dak_df_raw,
    defense_stats_allowed[['season', 'week', 'opponent_team', 'rolling_4wk_avg_qb_fantasy_points_allowed', 'rolling_4wk_avg_qb_sacks_forced', 'rolling_4wk_avg_qb_interceptions_forced']],
    on=['season', 'week', 'opponent_team'],
    how='left'
)

# Now, merge the result with the game schedule information
dak_df_final = pd.merge(
    dak_df_merged,
    schedule_df[['season', 'week', 'roof', 'surface', 'div_game']],
    on=['season', 'week'],
    how='left'
)
print("All data merged successfully.")


# =============================================================================
# STEP 5: CREATE FINAL FEATURES AND MODELING DATAFRAME
# =============================================================================
print("\n--- Creating Final Features for the Model ---")

# Target Variable (Y): Next week's fantasy points
dak_df_final['target_next_week_fantasy_points'] = dak_df_final['fantasy_points'].shift(-1)

# Binary feature for playing indoors
dak_df_final['is_indoor'] = dak_df_final['roof'].apply(
    lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0
)
# Binary feature for playing on artificial turf
dak_df_final['is_artificial_turf'] = dak_df_final['surface'].apply(
    lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0
)
# Binary feature for a divisional rivalry game
dak_df_final['is_division_rival'] = dak_df_final['div_game'].astype(int)

# Define the final list of features for our model based on your request
feature_columns = [
    'rolling_4wk_avg_qb_fantasy_points_allowed',
    'is_indoor',
    'is_artificial_turf',
    'rolling_4wk_avg_qb_sacks_forced',       # Proxy for pressure
    'rolling_4wk_avg_qb_interceptions_forced', # Proxy for pressure
    'is_division_rival'
]

# Create the final modeling DataFrame
model_df = dak_df_final[['target_next_week_fantasy_points'] + feature_columns].copy()

# Drop any row with missing data (handles start of season and end of data)
model_df = model_df.dropna()

print(f"Final modeling DataFrame created with shape: {model_df.shape}")


# =============================================================================
# STEP 6: RUN MULTIPLE LINEAR REGRESSION AND INTERPRET
# =============================================================================
print("\n--- Running Multiple Linear Regression Analysis ---")

# Define Dependent (Y) and Independent (X) Variables
Y = model_df['target_next_week_fantasy_points']
X = model_df[feature_columns]

# The statsmodels library requires us to manually add the constant (intercept) term
X = sm.add_constant(X)

# Fit the Ordinary Least Squares (OLS) Model
model = sm.OLS(Y, X).fit()

# Print the detailed, interpretable model summary
print(model.summary())


