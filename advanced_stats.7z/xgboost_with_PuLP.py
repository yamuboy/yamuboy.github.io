# =============================================================================
# STEP 1: SETUP, IMPORTS, AND FULL DATA PREP FOR ALL QBs
# =============================================================================

# Import all the tools we'll need
import pandas as pd
import numpy as np
import nfl_data_py as nfl
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from pulp import LpProblem, LpVariable, LpMaximize, lpSum, LpStatus
import warnings
warnings.filterwarnings('ignore') # Suppress common warnings for cleaner output

print("Setup and Imports Complete.")

# --- Prepare data for ALL QBs from 2016-2023 ---
years = range(2016, 2024)
weekly_df_hist = nfl.import_weekly_data(years)
schedule_df_hist = nfl.import_schedules(years)
roster_df_hist = nfl.import_rosters(years)
qb_ids = roster_df_hist[roster_df_hist['position'] == 'QB']['player_id'].unique()

# --- Engineer Defensive Features (same as before) ---
weekly_qb_df_for_def = weekly_df_hist[weekly_df_hist['player_id'].isin(qb_ids)]
defense_stats_allowed = weekly_qb_df_for_def.groupby(['opponent_team', 'season', 'week']).agg(
    qb_fantasy_points_allowed=('fantasy_points', 'sum'),
    qb_sacks_forced=('sacks', 'sum'),
    qb_interceptions_forced=('interceptions', 'sum')
).reset_index()
defense_stats_allowed = defense_stats_allowed.sort_values(by=['opponent_team', 'season', 'week'])
for stat in ['qb_fantasy_points_allowed', 'qb_sacks_forced', 'qb_interceptions_forced']:
    defense_stats_allowed[f'rolling_4wk_avg_{stat}'] = defense_stats_allowed.groupby('opponent_team')[stat].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )

# --- Prepare the master QB training data ---
qb_df_raw = weekly_df_hist[(weekly_df_hist['player_id'].isin(qb_ids)) & (weekly_df_hist['season_type'] == 'REG')].copy()
qb_df_merged = pd.merge(qb_df_raw, defense_stats_allowed, on=['season', 'week', 'opponent_team'], how='left')
training_df = pd.merge(qb_df_merged, schedule_df_hist[['season', 'week', 'roof', 'surface', 'div_game']], on=['season', 'week'], how='left')

# --- Feature Engineering for all QBs ---
training_df['target_next_week_fantasy_points'] = training_df.groupby('player_id')['fantasy_points'].shift(-1)
training_df['is_indoor'] = training_df['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
training_df['is_artificial_turf'] = training_df['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
training_df['is_division_rival'] = training_df['div_game'].astype(int)
feature_columns = [
    'rolling_4wk_avg_qb_fantasy_points_allowed', 'is_indoor', 'is_artificial_turf',
    'rolling_4wk_avg_qb_sacks_forced', 'rolling_4wk_avg_qb_interceptions_forced', 'is_division_rival'
]
model_df = training_df[['player_id', 'target_next_week_fantasy_points'] + feature_columns].copy().dropna()
print(f"QB Training dataset prepared. Shape: {model_df.shape}")

# =============================================================================
# STEP 2: TRAIN THE MASTER XGBOOST MODEL FOR QBs
# =============================================================================
print("\n--- Training Master XGBoost Model for All QBs ---")
X = model_df[feature_columns]
y = model_df['target_next_week_fantasy_points']

# We train the final model on ALL available historical data to make it as smart as possible
xgb_master_model = XGBRegressor(n_estimators=100, random_state=42, n_jobs=-1)
xgb_master_model.fit(X, y)
print("Master QB prediction model trained successfully.")

# =============================================================================
# STEP 3: THE PREDICTION PIPELINE AND OPTIMIZER FUNCTIONS
# =============================================================================
def generate_projections_for_slate(season, week, model, full_weekly_data, defense_data, schedule_data):
    """
    Generates projections for a given week's slate of players.
    Uses a trained model for QBs and placeholder projections for others.
    """
    print(f"\n--- Generating Projections for {season} Week {week} ---")
    slate_df = full_weekly_data[(full_weekly_data['season'] == season) & (full_weekly_data['week'] == week)].copy()
    
    # --- Simulate DFS Salaries (as this data is not in the free package) ---
    # A simple but reasonable proxy: salary based on recent performance
    slate_df['salary'] = slate_df['fantasy_points'].shift(1).fillna(4000) * 200 + 4000
    slate_df['salary'] = slate_df['salary'].clip(3000, 9500).astype(int)

    # --- Feature Engineering for the Slate ---
    # Merge defensive and schedule info for this specific week
    slate_df = pd.merge(slate_df, defense_data, on=['season', 'week', 'opponent_team'], how='left')
    slate_df = pd.merge(slate_df, schedule_data[['season', 'week', 'roof', 'surface', 'div_game']], on=['season', 'week'], how='left')

    # Create the features
    slate_df['is_indoor'] = slate_df['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
    slate_df['is_artificial_turf'] = slate_df['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
    slate_df['is_division_rival'] = slate_df['div_game'].astype(int)
    
    # Filter for QBs to predict with our model
    qbs_in_slate = slate_df[slate_df['position'] == 'QB'].copy()
    
    # Handle cases where a QB might have missing historical data for features
    qbs_in_slate[feature_columns] = qbs_in_slate[feature_columns].fillna(qbs_in_slate[feature_columns].mean())
    
    # Predict for QBs
    if not qbs_in_slate.empty:
        qb_features = qbs_in_slate[feature_columns]
        qb_predictions = model.predict(qb_features)
        slate_df.loc[qbs_in_slate.index, 'projected_points'] = qb_predictions

    # Use a placeholder for other positions (e.g., their average score over the last 4 weeks)
    slate_df['projected_points'].fillna(slate_df['fantasy_points'].rolling(4, min_periods=1).mean().shift(1), inplace=True)
    slate_df['projected_points'].fillna(5, inplace=True) # Final fallback for players with no history

    return slate_df[['player_display_name', 'position', 'salary', 'projected_points']].dropna().reset_index(drop=True)

def solve_optimal_lineup(projections_df):
    """
    Takes a dataframe of projections and returns the optimal lineup.
    """
    print("\n--- Solving for Optimal Lineup using Integer Programming ---")
    SALARY_CAP = 50000
    POSITION_CONSTRAINTS = {'QB': 1, 'RB': 2, 'WR': 3, 'TE': 1, 'FLEX': 1, 'DST': 1}
    
    # Pre-processing for FLEX position
    projections_df['is_RB'] = (projections_df['position'] == 'RB').astype(int)
    projections_df['is_WR'] = (projections_df['position'] == 'WR').astype(int)
    projections_df['is_TE'] = (projections_df['position'] == 'TE').astype(int)
    
    model = LpProblem(name="DFS_Optimizer", sense=LpMaximize)
    player_vars = LpVariable.dicts("Player", projections_df.index, cat='Binary')

    model += lpSum(projections_df.loc[i, 'projected_points'] * player_vars[i] for i in projections_df.index)
    model += (lpSum(projections_df.loc[i, 'salary'] * player_vars[i] for i in projections_df.index) <= SALARY_CAP, "Salary_Constraint")
    
    for pos in ['QB', 'RB', 'WR', 'TE', 'DST']:
        model += (lpSum(player_vars[i] for i in projections_df.index if projections_df.loc[i, 'position'] == pos) >= POSITION_CONSTRAINTS[pos], f"Min_{pos}_Constraint")

    # FLEX constraint (sum of RB, WR, TE must be at least min_RB + min_WR + min_TE + min_FLEX)
    flex_players_sum = lpSum(projections_df.loc[i, 'is_RB'] * player_vars[i] + projections_df.loc[i, 'is_WR'] * player_vars[i] + projections_df.loc[i, 'is_TE'] * player_vars[i] for i in projections_df.index)
    total_flex_req = POSITION_CONSTRAINTS['RB'] + POSITION_CONSTRAINTS['WR'] + POSITION_CONSTRAINTS['TE'] + POSITION_CONSTRAINTS['FLEX']
    model += (flex_players_sum == total_flex_req, "Flex_Constraint")
    
    model.solve()
    
    print(f"Status: {LpStatus[model.status]}")
    if LpStatus[model.status] == 'Optimal':
        selected_indices = [i for i in projections_df.index if player_vars[i].varValue == 1]
        return projections_df.loc[selected_indices]
    return None

# =============================================================================
# STEP 4: CLOSE THE LOOP - RUN THE FULL PIPELINE FOR A SPECIFIC WEEK
# =============================================================================
# Let's run this for a sample week from last season, e.g., Week 5, 2023
TARGET_SEASON = 2023
TARGET_WEEK = 5

# 1. Generate projections using our custom model
final_projections = generate_projections_for_slate(
    season=TARGET_SEASON,
    week=TARGET_WEEK,
    model=xgb_master_model,
    full_weekly_data=weekly_df_hist,
    defense_data=defense_stats_allowed,
    schedule_data=schedule_df_hist
)

# 2. Feed the projections into the optimizer
optimal_lineup = solve_optimal_lineup(final_projections)

# 3. Display the result!
if optimal_lineup is not None:
    print("\n\n" + "="*50)
    print(f"   OPTIMAL LINEUP FOR {TARGET_SEASON} WEEK {TARGET_WEEK} (BASED ON OUR MODEL)")
    print("="*50)
    
    # Sort for readability
    pos_order = ['QB', 'RB', 'WR', 'TE', 'FLEX', 'DST']
    optimal_lineup['position_sort'] = pd.Categorical(optimal_lineup['position'], categories=pos_order, ordered=True)
    optimal_lineup = optimal_lineup.sort_values('position_sort')
    
    print(optimal_lineup[['player_display_name', 'position', 'salary', 'projected_points']].round(2).to_string(index=False))
    print("-"*50)
    print(f"Total Salary: {optimal_lineup['salary'].sum()} / 50000")
    print(f"Total Projected Points: {optimal_lineup['projected_points'].sum():.2f}")
    print("="*50)