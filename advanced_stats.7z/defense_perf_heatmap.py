# =============================================================================
# STEP 1: SETUP AND DATA LOADING (Using the Correct Function)
# =============================================================================

import pandas as pd
import numpy as np
import nfl_data_py as nfl
import seaborn as sns
import matplotlib.pyplot as plt

print("Setup and Imports Complete.")

# Load multiple seasons using the specified import_pbp_data method
years = range(2021, 2024)
print("Loading PBP data using nfl.import_pbp_data()...")
# This is the function we will use, as requested.
pbp_df = nfl.import_pbp_data(years)
weekly_df = nfl.import_weekly_data(years)

# Filter for regular season only
pbp_df = pbp_df[pbp_df['season_type'] == 'REG']
weekly_df = weekly_df[weekly_df['season_type'] == 'REG']
print("Data Loading Complete.")

# =============================================================================
# STEP 2: ENGINEER POSITION-SPECIFIC DEFENSIVE STATS
# =============================================================================
print("\n--- Engineering Position-Specific Defensive Stats ---")
pos_def_stats = weekly_df[['season', 'week', 'opponent_team', 'position', 'fantasy_points']].copy()
pos_def_stats['position'] = pos_def_stats['position'].replace({'TE': 'WR'})
pos_def_stats = pos_def_stats[pos_def_stats['position'].isin(['QB', 'RB', 'WR'])]
pts_allowed_df = pos_def_stats.groupby(['opponent_team', 'season', 'week', 'position'])['fantasy_points'].sum().reset_index()
pts_allowed_df = pts_allowed_df.sort_values(by=['opponent_team', 'position', 'season', 'week'])
pts_allowed_df['def_rolling_pts_allowed'] = pts_allowed_df.groupby(['opponent_team', 'position'])['fantasy_points'].transform(
    lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
)
def_vs_pos_df = pts_allowed_df.pivot_table(
    index=['opponent_team', 'season', 'week'],
    columns='position',
    values='def_rolling_pts_allowed'
).reset_index()
def_vs_pos_df.columns = ['opponent_team', 'season', 'week', 'def_vs_QB', 'def_vs_RB', 'def_vs_WR']
print("Defensive stats engineered.")

# =============================================================================
# STEP 3: ENGINEER ROLLING ADVANCED METRICS FROM AVAILABLE COLUMNS
# =============================================================================
print("\n--- Engineering Rolling Advanced Metrics for Players ---")

# --- QB Metrics: ANY/A and CPOE ---
# These can be calculated from the provided columns.
sacks_df = pbp_df[pbp_df['sack'] == 1]
sack_yards = sacks_df.groupby(['season', 'week', 'passer_player_id'])['yards_gained'].sum().reset_index().rename(columns={'yards_gained':'sack_yards_lost'})

weekly_qb_stats = pbp_df.groupby(['season', 'week', 'passer_player_id']).agg(
    attempts=('pass_attempt', 'sum'),
    completions=('complete_pass', 'sum'),
    pass_yards=('passing_yards', 'sum'),
    pass_tds=('pass_touchdown', 'sum'),
    ints=('interception', 'sum'),
    sacks=('sack', 'sum'),
    weekly_cpoe=('cpoe', 'mean') # CPOE is available
).reset_index()

weekly_qb_stats = pd.merge(weekly_qb_stats, sack_yards, on=['season','week','passer_player_id'], how='left').fillna(0)
weekly_qb_stats['weekly_any_a'] = (weekly_qb_stats['pass_yards'] + (20 * weekly_qb_stats['pass_tds']) - (45 * weekly_qb_stats['ints']) + weekly_qb_stats['sack_yards_lost']) / (weekly_qb_stats['attempts'] + weekly_qb_stats['sacks'])

# --- WR/TE Metrics: Target Share and Air Yards Share ---
# These can be calculated from the provided columns.
team_pass_attempts = pbp_df.groupby(['season', 'week', 'posteam'])['pass_attempt'].sum().reset_index().rename(columns={'pass_attempt': 'team_attempts'})
player_targets = pbp_df[pbp_df['pass_attempt']==1].groupby(['season', 'week', 'receiver_player_id', 'posteam']).agg(targets=('play_id','count')).reset_index()
weekly_target_share = pd.merge(player_targets, team_pass_attempts, on=['season', 'week', 'posteam'], how='left')
weekly_target_share['weekly_target_share'] = weekly_target_share['targets'] / weekly_target_share['team_attempts']

team_air_yards = pbp_df.groupby(['season', 'week', 'posteam'])['air_yards'].sum().reset_index().rename(columns={'air_yards': 'team_air_yards'})
player_air_yards = pbp_df[pbp_df['pass_attempt']==1].groupby(['season', 'week', 'receiver_player_id', 'posteam']).agg(air_yards=('air_yards','sum')).reset_index()
weekly_air_yards_share = pd.merge(player_air_yards, team_air_yards, on=['season', 'week', 'posteam'], how='left')
weekly_air_yards_share['weekly_air_yards_share'] = weekly_air_yards_share['air_yards'] / weekly_air_yards_share['team_air_yards']

# --- RB Metrics: YPC (Proxy for RYOE) ---
# RYOE is NOT available, so we use Yards Per Carry as our efficiency metric.
rushes = pbp_df[pbp_df['rush_attempt']==1]
weekly_rb_stats = rushes.groupby(['season', 'week', 'rusher_player_id']).agg(
    carries=('play_id', 'count'),
    rush_yards=('rushing_yards', 'sum')
).reset_index()
weekly_rb_stats['weekly_ypc'] = weekly_rb_stats['rush_yards'] / weekly_rb_stats['carries']

# --- Combine all metrics into a single player-centric DataFrame ---
weekly_qb_stats.rename(columns={'passer_player_id': 'player_id'}, inplace=True)
weekly_target_share.rename(columns={'receiver_player_id': 'player_id'}, inplace=True)
weekly_air_yards_share.rename(columns={'receiver_player_id': 'player_id'}, inplace=True)
weekly_rb_stats.rename(columns={'rusher_player_id': 'player_id'}, inplace=True)

# Merge all weekly metrics
metrics_df = pd.merge(weekly_qb_stats[['season', 'week', 'player_id', 'weekly_any_a', 'weekly_cpoe']],
                      weekly_target_share[['season', 'week', 'player_id', 'weekly_target_share']],
                      on=['season', 'week', 'player_id'], how='outer')
metrics_df = pd.merge(metrics_df, weekly_air_yards_share[['season', 'week', 'player_id', 'weekly_air_yards_share']],
                      on=['season', 'week', 'player_id'], how='outer')
metrics_df = pd.merge(metrics_df, weekly_rb_stats[['season', 'week', 'player_id', 'weekly_ypc']],
                      on=['season', 'week', 'player_id'], how='outer')

# --- Calculate Rolling Averages ---
metrics_df = metrics_df.sort_values(by=['player_id', 'season', 'week'])
cols_to_roll = ['weekly_any_a', 'weekly_cpoe', 'weekly_target_share', 'weekly_air_yards_share', 'weekly_ypc']
for col in cols_to_roll:
    new_col_name = f"rolling_{'_'.join(col.split('_')[1:])}"
    metrics_df[new_col_name] = metrics_df.groupby('player_id')[col].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )
print("Player rolling advanced metrics engineered.")

# =============================================================================
# STEP 4: BUILD MASTER ANALYSIS DATAFRAME AND VISUALIZE
# =============================================================================
print("\n--- Building Master DataFrame and Analyzing Correlations ---")
base_df = weekly_df[['player_id', 'player_display_name', 'position', 'season', 'week', 'opponent_team', 'fantasy_points']].copy()
base_df = base_df[base_df['position'].isin(['QB', 'RB', 'WR', 'TE'])]
master_df = pd.merge(base_df, def_vs_pos_df, on=['opponent_team', 'season', 'week'], how='left')
master_df = pd.merge(master_df, metrics_df, on=['player_id', 'season', 'week'], how='left')

def analyze_position(df, position, features):
    pos_df = df[df['position'] == position].copy()
    if position == 'WR':
        pos_df = df[df['position'].isin(['WR', 'TE'])].copy()

    corr_df = pos_df[features + ['fantasy_points']].dropna()
    correlation_matrix = corr_df.corr()

    plt.figure(figsize=(12, 9))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
    plt.title(f'Correlation Matrix for {position}s vs. Fantasy Points', fontsize=16)
    plt.show()

# Analyze QBs with both ANY/A and CPOE
qb_features = ['rolling_any_a', 'rolling_cpoe', 'def_vs_QB']
analyze_position(master_df, 'QB', qb_features)

# Analyze RBs
rb_features = ['rolling_ypc', 'def_vs_RB']
analyze_position(master_df, 'RB', rb_features)

# Analyze WRs/TEs with both Target Share and Air Yards Share
wr_features = ['rolling_target_share', 'rolling_air_yards_share', 'def_vs_WR']
analyze_position(master_df, 'WR', wr_features)