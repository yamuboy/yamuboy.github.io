# =============================================================================
# STEP 1: SETUP AND IMPORTS
# =============================================================================
# Import all the tools we'll need for this analysis
import pandas as pd
import numpy as np
import nfl_data_py as nfl
from sklearn.linear_model import LinearRegression

# Set pandas to display all columns for better inspection
pd.set_option('display.max_columns', None)
print("Setup Complete.")

# =============================================================================
# STEP 2: GATHER AND ENGINEER HISTORICAL DATA (2016-2023)
# =============================================================================
print("\n--- Gathering and Engineering Historical Data (2016-2023) ---")
# Define the historical seasons
years_historical = range(2016, 2024)

# Fetch historical weekly and schedule data
weekly_df_hist = nfl.import_weekly_data(years_historical)
schedule_df_hist = nfl.import_schedules(years_historical)
roster_df_hist = nfl.import_rosters(years_historical)
qb_ids = roster_df_hist[roster_df_hist['position'] == 'QB']['player_id'].unique()

# --- 2.1 Engineer Opponent Defensive Stats (Historical) ---
weekly_qb_df = weekly_df_hist[weekly_df_hist['player_id'].isin(qb_ids)]
defense_stats_allowed = weekly_qb_df.groupby(['opponent_team', 'season', 'week']).agg(
    qb_fantasy_points_allowed=('fantasy_points', 'sum'),
    qb_sacks_forced=('sacks', 'sum'),
    qb_interceptions_forced=('interceptions', 'sum')
).reset_index()

defense_stats_allowed = defense_stats_allowed.sort_values(by=['opponent_team', 'season', 'week'])

features_to_roll = ['qb_fantasy_points_allowed', 'qb_sacks_forced', 'qb_interceptions_forced']
for stat in features_to_roll:
    defense_stats_allowed[f'rolling_4wk_avg_{stat}'] = defense_stats_allowed.groupby('opponent_team')[stat].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )

# --- 2.2 Create the Historical Training DataFrame ---
dak_df_raw = weekly_df_hist[(weekly_df_hist['player_display_name'] == 'Dak Prescott') & (weekly_df_hist['season_type'] == 'REG')].copy()
dak_df_raw = dak_df_raw.sort_values(by=['season', 'week']).reset_index(drop=True)

dak_df_merged = pd.merge(
    dak_df_raw,
    defense_stats_allowed,
    on=['season', 'week', 'opponent_team'],
    how='left'
)
training_df = pd.merge(
    dak_df_merged,
    schedule_df_hist[['season', 'week', 'roof', 'surface', 'div_game']],
    on=['season', 'week'],
    how='left'
)

# --- 2.3 Engineer Final Features for Training Data ---
training_df['target_next_week_fantasy_points'] = training_df['fantasy_points'].shift(-1)
training_df['is_indoor'] = training_df['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
training_df['is_artificial_turf'] = training_df['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
training_df['is_division_rival'] = training_df['div_game'].astype(int)

# Define feature columns
feature_columns = [
    'rolling_4wk_avg_qb_fantasy_points_allowed',
    'is_indoor',
    'is_artificial_turf',
    'rolling_4wk_avg_qb_sacks_forced',
    'rolling_4wk_avg_qb_interceptions_forced',
    'is_division_rival'
]

model_df_train = training_df[['target_next_week_fantasy_points'] + feature_columns].copy().dropna()
print(f"Historical training data prepared. Shape: {model_df_train.shape}")


# =============================================================================
# STEP 3: PREPARE THE 2024 PREDICTION DATA
# =============================================================================
print("\n--- Preparing 2024 Prediction Data ---")

# --- 3.1 Get Final 2023 Defensive Quality as a Proxy ---
final_2023_def_stats = defense_stats_allowed[defense_stats_allowed['season'] == 2023]

# ******** THE FIX IS HERE ********
# Instead of a fragile slice, we explicitly list the columns we need.
defensive_proxy_cols = [
    'rolling_4wk_avg_qb_fantasy_points_allowed',
    'rolling_4wk_avg_qb_sacks_forced',
    'rolling_4wk_avg_qb_interceptions_forced'
]
# Get the last valid rolling average for each team from 2023 for our specified columns
final_2023_def_proxy = final_2023_def_stats.groupby('opponent_team')[defensive_proxy_cols].last()
# ***********************************

# --- 3.2 Get the 2024 Schedule for Dallas ---
schedule_2024 = nfl.import_schedules([2024])
schedule_2024_dal = schedule_2024[
    (schedule_2024['home_team'] == 'DAL') | (schedule_2024['away_team'] == 'DAL')
].copy()
schedule_2024_dal = schedule_2024_dal[schedule_2024_dal['game_type'] == 'REG']

schedule_2024_dal['opponent_team'] = np.where(schedule_2024_dal['home_team'] == 'DAL', schedule_2024_dal['away_team'], schedule_2024_dal['home_team'])

# --- 3.3 Build the 2024 Prediction DataFrame ---
predict_df_2024 = pd.merge(
    schedule_2024_dal,
    final_2023_def_proxy,
    left_on='opponent_team',
    right_index=True,
    how='left'
)

predict_df_2024['is_indoor'] = predict_df_2024['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
predict_df_2024['is_artificial_turf'] = predict_df_2024['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
predict_df_2024['is_division_rival'] = predict_df_2024['div_game'].astype(int)

# This fillna is now safe because all columns exist
predict_df_2024[feature_columns] = predict_df_2024[feature_columns].fillna(predict_df_2024[feature_columns].mean())
print("2024 prediction data prepared successfully.")


# =============================================================================
# STEP 4: TRAIN MODEL AND MAKE 2024 PREDICTIONS
# =============================================================================
print("\n--- Training Model and Predicting 2024 Season ---")

# --- 4.1 Define Training Data ---
X_train = model_df_train[feature_columns]
y_train = model_df_train['target_next_week_fantasy_points']

# --- 4.2 Define 2024 Data to Predict On ---
X_predict = predict_df_2024[feature_columns]

# --- 4.3 Train the Linear Regression Model ---
model = LinearRegression()
model.fit(X_train, y_train)
print("Model training complete.")

# --- 4.4 Make Predictions for the 2024 Season ---
predictions_2024 = model.predict(X_predict)
predict_df_2024['predicted_fantasy_points'] = predictions_2024

print("\n\n--- Dak Prescott 2024 Fantasy Football Forecast ---")
forecast_cols = ['week', 'opponent_team', 'predicted_fantasy_points']
final_forecast = predict_df_2024[forecast_cols].sort_values(by='week').set_index('week')

final_forecast['predicted_fantasy_points'] = final_forecast['predicted_fantasy_points'].round(2)
print(final_forecast)


# =============================================================================
# STEP 5: SEASON-LEVEL SUMMARY
# =============================================================================
total_predicted_points = final_forecast['predicted_fantasy_points'].sum()
average_predicted_points = final_forecast['predicted_fantasy_points'].mean()
best_game = final_forecast.loc[final_forecast['predicted_fantasy_points'].idxmax()]
worst_game = final_forecast.loc[final_forecast['predicted_fantasy_points'].idxmin()]

print("\n--- 2024 Season Summary ---")
print(f"Total Predicted Points: {total_predicted_points:.2f}")
print(f"Average Predicted Points per Game: {average_predicted_points:.2f}")
print(f"Best Predicted Game: Week {best_game.name} vs {best_game['opponent_team']} ({best_game['predicted_fantasy_points']:.2f} points)")
print(f"Worst Predicted Game: Week {worst_game.name} vs {worst_game['opponent_team']} ({worst_game['predicted_fantasy_points']:.2f} points)")