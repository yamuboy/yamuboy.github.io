# =============================================================================
# STEP 1: SETUP, IMPORTS, AND DATA PREP (Condensed)
# =============================================================================

# Import all the tools we'll need
import pandas as pd
import numpy as np
import nfl_data_py as nfl
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns

print("Setup and Imports Complete.")

# --- Use the exact same training data from our previous models ---
# (Including this condensed data prep code for a complete, runnable script)
years_historical = range(2016, 2024)
weekly_df_hist = nfl.import_weekly_data(years_historical)
schedule_df_hist = nfl.import_schedules(years_historical)
roster_df_hist = nfl.import_rosters(years_historical)
qb_ids = roster_df_hist[roster_df_hist['position'] == 'QB']['player_id'].unique()
weekly_qb_df = weekly_df_hist[weekly_df_hist['player_id'].isin(qb_ids)]
defense_stats_allowed = weekly_qb_df.groupby(['opponent_team', 'season', 'week']).agg(
    qb_fantasy_points_allowed=('fantasy_points', 'sum'),
    qb_sacks_forced=('sacks', 'sum'),
    qb_interceptions_forced=('interceptions', 'sum')
).reset_index()
defense_stats_allowed = defense_stats_allowed.sort_values(by=['opponent_team', 'season', 'week'])
for stat in ['qb_fantasy_points_allowed', 'qb_sacks_forced', 'qb_interceptions_forced']:
    defense_stats_allowed[f'rolling_4wk_avg_{stat}'] = defense_stats_allowed.groupby('opponent_team')[stat].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )
dak_df_raw = weekly_df_hist[(weekly_df_hist['player_display_name'] == 'Dak Prescott') & (weekly_df_hist['season_type'] == 'REG')].copy()
dak_df_raw = dak_df_raw.sort_values(by=['season', 'week']).reset_index(drop=True)
dak_df_merged = pd.merge(dak_df_raw, defense_stats_allowed, on=['season', 'week', 'opponent_team'], how='left')
training_df = pd.merge(dak_df_merged, schedule_df_hist[['season', 'week', 'roof', 'surface', 'div_game']], on=['season', 'week'], how='left')
training_df['target_next_week_fantasy_points'] = training_df['fantasy_points'].shift(-1)
training_df['is_indoor'] = training_df['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
training_df['is_artificial_turf'] = training_df['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
training_df['is_division_rival'] = training_df['div_game'].astype(int)
feature_columns = [
    'rolling_4wk_avg_qb_fantasy_points_allowed', 'is_indoor', 'is_artificial_turf',
    'rolling_4wk_avg_qb_sacks_forced', 'rolling_4wk_avg_qb_interceptions_forced', 'is_division_rival'
]
model_df = training_df[['target_next_week_fantasy_points'] + feature_columns].copy().dropna()
print(f"Full dataset prepared. Shape: {model_df.shape}")


# =============================================================================
# STEP 2: SPLIT DATA INTO TRAINING AND TESTING SETS
# =============================================================================
print("\n--- Splitting data into Training and Testing sets ---")
X = model_df[feature_columns]
y = model_df['target_next_week_fantasy_points']

# We'll use 80% of the data for training and 20% for testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"Training set size: {len(X_train)} games")
print(f"Testing set size: {len(X_test)} games")


# =============================================================================
# STEP 3: TRAIN ALL THREE MODELS
# =============================================================================
print("\n--- Training Linear Regression, Random Forest, and XGBoost models ---")

# 1. Linear Regression (our baseline)
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# 2. Random Forest
# n_estimators is the number of trees in the forest. random_state ensures reproducibility.
rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
rf_model.fit(X_train, y_train)

# 3. XGBoost
xgb_model = XGBRegressor(n_estimators=100, random_state=42, n_jobs=-1)
xgb_model.fit(X_train, y_train)

print("All models trained successfully.")


# =============================================================================
# STEP 4: EVALUATE MODELS ON THE UNSEEN TEST SET
# =============================================================================
print("\n--- Evaluating models on the unseen Test set ---")

# Make predictions with each model
lr_preds = lr_model.predict(X_test)
rf_preds = rf_model.predict(X_test)
xgb_preds = xgb_model.predict(X_test)

# Calculate performance metrics
models = ['Linear Regression', 'Random Forest', 'XGBoost']
predictions = [lr_preds, rf_preds, xgb_preds]
results = []

for model, preds in zip(models, predictions):
    mse = mean_squared_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    results.append({'Model': model, 'MSE': mse, 'R-squared': r2})

results_df = pd.DataFrame(results).set_index('Model')
print("\nModel Performance Comparison:")
print(results_df)


# =============================================================================
# STEP 5: ANALYZE FEATURE IMPORTANCE
# =============================================================================
print("\n--- Analyzing Feature Importance from Advanced Models ---")

# Get feature importances
rf_importances = pd.Series(rf_model.feature_importances_, index=feature_columns)
xgb_importances = pd.Series(xgb_model.feature_importances_, index=feature_columns)

# Create a DataFrame for plotting
importance_df = pd.DataFrame({
    'Random Forest': rf_importances,
    'XGBoost': xgb_importances
}).sort_values(by='XGBoost', ascending=False)

# Plot the feature importances
importance_df.plot(kind='bar', figsize=(14, 7))
plt.title('Feature Importance Comparison', fontsize=16)
plt.ylabel('Importance Score', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()