# =============================================================================
# STEP 1: SETUP, DATA GATHERING, AND MODEL TRAINING (Condensed from previous script)
# =============================================================================


# Import all the tools we'll need for this analysis
import pandas as pd
import numpy as np
import nfl_data_py as nfl
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import seaborn as sns

print("Setup and Imports Complete.")

# --- Define Years and Fetch Data ---
years_historical = range(2016, 2024)
weekly_df_hist = nfl.import_weekly_data(years_historical)
schedule_df_hist = nfl.import_schedules(years_historical)
roster_df_hist = nfl.import_rosters(years_historical)
qb_ids = roster_df_hist[roster_df_hist['position'] == 'QB']['player_id'].unique()

# --- Engineer Historical Data (condensed for brevity) ---
weekly_qb_df = weekly_df_hist[weekly_df_hist['player_id'].isin(qb_ids)]
defense_stats_allowed = weekly_qb_df.groupby(['opponent_team', 'season', 'week']).agg(
    qb_fantasy_points_allowed=('fantasy_points', 'sum'),
    qb_sacks_forced=('sacks', 'sum'),
    qb_interceptions_forced=('interceptions', 'sum')
).reset_index()
defense_stats_allowed = defense_stats_allowed.sort_values(by=['opponent_team', 'season', 'week'])
for stat in ['qb_fantasy_points_allowed', 'qb_sacks_forced', 'qb_interceptions_forced']:
    defense_stats_allowed[f'rolling_4wk_avg_{stat}'] = defense_stats_allowed.groupby('opponent_team')[stat].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )
dak_df_raw = weekly_df_hist[(weekly_df_hist['player_display_name'] == 'Dak Prescott') & (weekly_df_hist['season_type'] == 'REG')].copy()
dak_df_raw = dak_df_raw.sort_values(by=['season', 'week']).reset_index(drop=True)
dak_df_merged = pd.merge(dak_df_raw, defense_stats_allowed, on=['season', 'week', 'opponent_team'], how='left')
training_df = pd.merge(dak_df_merged, schedule_df_hist[['season', 'week', 'roof', 'surface', 'div_game']], on=['season', 'week'], how='left')
training_df['target_next_week_fantasy_points'] = training_df['fantasy_points'].shift(-1)
training_df['is_indoor'] = training_df['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
training_df['is_artificial_turf'] = training_df['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
training_df['is_division_rival'] = training_df['div_game'].astype(int)

feature_columns = [
    'rolling_4wk_avg_qb_fantasy_points_allowed', 'is_indoor', 'is_artificial_turf',
    'rolling_4wk_avg_qb_sacks_forced', 'rolling_4wk_avg_qb_interceptions_forced', 'is_division_rival'
]
model_df_train = training_df[['target_next_week_fantasy_points'] + feature_columns].copy().dropna()

# --- Train the Regression Model ---
X_train = model_df_train[feature_columns]
y_train = model_df_train['target_next_week_fantasy_points']
model = LinearRegression()
model.fit(X_train, y_train)
print("Regression model trained successfully.")


# =============================================================================
# STEP 2: CALCULATE MODEL ERROR (VOLATILITY)
# =============================================================================
print("\n--- Calculating Model's Historical Error ---")

# Get the model's predictions on the data it was trained on
predictions_on_train_data = model.predict(X_train)

# Calculate the errors (residuals)
errors = y_train - predictions_on_train_data

# The standard deviation of these errors is our measure of volatility
stdev_of_error = errors.std()
print(f"Standard Deviation of Model Error (Volatility): {stdev_of_error:.2f} fantasy points")


# =============================================================================
# STEP 3: RUN MONTE CARLO SIMULATION FOR A 2024 GAME
# =============================================================================
print("\n--- Running Monte Carlo Simulation for a 2024 Matchup ---")

# Let's use the 2024 Week 1 matchup vs. CLE as our example
# (We need the feature values for this game, which we can get from our previous script's logic)
# For this example, let's assume we ran our previous prediction script and got these values:
example_game_features = {
    'rolling_4wk_avg_qb_fantasy_points_allowed': [17.5], # CLE's final 2023 avg
    'is_indoor': [0], # It's in Cleveland
    'is_artificial_turf': [0], # It's grass
    'rolling_4wk_avg_qb_sacks_forced': [2.8], # CLE's final 2023 avg
    'rolling_4wk_avg_qb_interceptions_forced': [0.9], # CLE's final 2023 avg
    'is_division_rival': [0]
}
example_game_df = pd.DataFrame(example_game_features)

# --- 3.1: Get the Mean Prediction from Regression ---
mean_prediction = model.predict(example_game_df)[0]
print(f"Regression Point Prediction (Mean): {mean_prediction:.2f} points")

# --- 3.2: Run the Simulation ---
num_simulations = 10000
simulated_scores = np.random.normal(
    loc=mean_prediction,           # The mean of the distribution
    scale=stdev_of_error,          # The standard deviation of the distribution
    size=num_simulations           # The number of simulations to run
)

print(f"{num_simulations} simulations complete.")

# =============================================================================
# STEP 4: ANALYZE AND VISUALIZE THE SIMULATION RESULTS
# =============================================================================
print("\n--- Analysis of Simulation Results ---")

# Create a plot
plt.figure(figsize=(12, 6))
sns.histplot(simulated_scores, kde=True, bins=50)
plt.title(f"Monte Carlo Simulation of Dak Prescott's Fantasy Score (vs CLE)", fontsize=16)
plt.xlabel("Simulated Fantasy Points", fontsize=12)
plt.ylabel("Frequency", fontsize=12)
plt.axvline(mean_prediction, color='red', linestyle='--', label=f'Mean Prediction: {mean_prediction:.2f}')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# Calculate key probabilities from the simulated data
prob_over_25_points = (simulated_scores > 25).mean() * 100
prob_over_30_points = (simulated_scores > 30).mean() * 100 # GPP winning upside
prob_under_15_points = (simulated_scores < 15).mean() * 100 # "Bust" potential

print("\nKey Probabilities:")
print(f"Median Simulated Score: {np.median(simulated_scores):.2f}")
print(f"Probability of scoring OVER 25 points (DFS value): {prob_over_25_points:.2f}%")
print(f"Probability of scoring OVER 30 points (GPP winner): {prob_over_30_points:.2f}%")
print(f"Probability of scoring UNDER 15 points (Bust risk): {prob_under_15_points:.2f}%")