# =============================================================================
# STEP 1: SETUP AND DATA PREPARATION (Condensed and assumes previous steps were run)
# =============================================================================

# Import all the tools we'll need
import pandas as pd
import numpy as np
import nfl_data_py as nfl
import pymc as pm
import arviz as az
import matplotlib.pyplot as plt
import seaborn as sns

print(f"Running on PyMC v{pm.__version__}")
print("Setup and Imports Complete.")

# --- Use the exact same training data from our previous model ---
# (Including this condensed data prep code for a complete, runnable script)
years_historical = range(2016, 2024)
weekly_df_hist = nfl.import_weekly_data(years_historical)
schedule_df_hist = nfl.import_schedules(years_historical)
roster_df_hist = nfl.import_rosters(years_historical)
qb_ids = roster_df_hist[roster_df_hist['position'] == 'QB']['player_id'].unique()
weekly_qb_df = weekly_df_hist[weekly_df_hist['player_id'].isin(qb_ids)]
defense_stats_allowed = weekly_qb_df.groupby(['opponent_team', 'season', 'week']).agg(
    qb_fantasy_points_allowed=('fantasy_points', 'sum'),
    qb_sacks_forced=('sacks', 'sum'),
    qb_interceptions_forced=('interceptions', 'sum')
).reset_index()
defense_stats_allowed = defense_stats_allowed.sort_values(by=['opponent_team', 'season', 'week'])
for stat in ['qb_fantasy_points_allowed', 'qb_sacks_forced', 'qb_interceptions_forced']:
    defense_stats_allowed[f'rolling_4wk_avg_{stat}'] = defense_stats_allowed.groupby('opponent_team')[stat].transform(
        lambda x: x.rolling(window=4, min_periods=1).mean().shift(1)
    )
dak_df_raw = weekly_df_hist[(weekly_df_hist['player_display_name'] == 'Dak Prescott') & (weekly_df_hist['season_type'] == 'REG')].copy()
dak_df_raw = dak_df_raw.sort_values(by=['season', 'week']).reset_index(drop=True)
dak_df_merged = pd.merge(dak_df_raw, defense_stats_allowed, on=['season', 'week', 'opponent_team'], how='left')
training_df = pd.merge(dak_df_merged, schedule_df_hist[['season', 'week', 'roof', 'surface', 'div_game']], on=['season', 'week'], how='left')
training_df['target_next_week_fantasy_points'] = training_df['fantasy_points'].shift(-1)
training_df['is_indoor'] = training_df['roof'].apply(lambda x: 1 if x in ['dome', 'closed', 'retractable'] else 0)
training_df['is_artificial_turf'] = training_df['surface'].apply(lambda x: 1 if 'turf' in str(x).lower() or 'fieldturf' in str(x).lower() or 'artifical' in str(x).lower() else 0)
training_df['is_division_rival'] = training_df['div_game'].astype(int)
feature_columns = [
    'rolling_4wk_avg_qb_fantasy_points_allowed', 'is_indoor', 'is_artificial_turf',
    'rolling_4wk_avg_qb_sacks_forced', 'rolling_4wk_avg_qb_interceptions_forced', 'is_division_rival'
]
model_df_train = training_df[['target_next_week_fantasy_points'] + feature_columns].copy().dropna()

# Prepare data for PyMC model
X = model_df_train[feature_columns].values
y = model_df_train['target_next_week_fantasy_points'].values
print("Data Preparation Complete.")

# =============================================================================
# STEP 2: DEFINE AND "TRAIN" THE BAYESIAN REGRESSION MODEL
# =============================================================================
print("\n--- Defining and Sampling from Bayesian Model ---")
# This process is called "sampling" not "training"
with pm.Model() as bayesian_model:
    # --- Priors for the model parameters ---
    # These are our "beliefs" before seeing the data. We use weakly informative priors.
    intercept = pm.Normal('intercept', mu=0, sigma=20)
    
    # One coefficient for each feature. The shape=X.shape[1] makes it the right size.
    coeffs = pm.Normal('coeffs', mu=0, sigma=10, shape=X.shape[1])
    
    # Prior for the model error/noise. It must be positive, so we use HalfNormal.
    sigma = pm.HalfNormal('sigma', sigma=10)
    
    # --- Likelihood of the data ---
    # This is the linear model equation
    mu = intercept + pm.math.dot(X, coeffs)
    
    # This says our observed 'y' values are normally distributed around our mean 'mu'
    y_obs = pm.Normal('y_obs', mu=mu, sigma=sigma, observed=y)
    
    # --- Run the MCMC Sampler ---
    # This is the core of Bayesian inference. It will explore the parameter space.
    # It's computationally intensive and may take a minute or two.
    idata = pm.sample(2000, tune=1000, cores=1)

print("MCMC Sampling Complete.")


# =============================================================================
# STEP 3: ANALYZE THE MODEL PARAMETERS (THE COEFFICIENTS)
# =============================================================================
print("\n--- Analysis of Model Parameters (Posterior Distributions) ---")

# Plot the posterior distributions for each parameter
az.plot_posterior(idata, var_names=['intercept', 'coeffs', 'sigma'])
plt.show()

# Print a summary table
summary = az.summary(idata, var_names=['intercept', 'coeffs'])
# Add feature names for clarity
summary.index = ['Intercept'] + feature_columns
print(summary)


# =============================================================================
# STEP 4: GENERATE PREDICTIONS (POSTERIOR PREDICTIVE DISTRIBUTION)
# =============================================================================
print("\n--- Generating Posterior Predictive Distribution (Bayesian Monte Carlo) ---")

# Let's use the same example game features from before
example_game_features = {
    'rolling_4wk_avg_qb_fantasy_points_allowed': [17.5], 'is_indoor': [0],
    'is_artificial_turf': [0], 'rolling_4wk_avg_qb_sacks_forced': [2.8],
    'rolling_4wk_avg_qb_interceptions_forced': [0.9], 'is_division_rival': [0]
}
X_predict = pd.DataFrame(example_game_features).values

# Generate new predictions using the trained model
with bayesian_model:
    # We pass in our new data point
    pm.set_data({'X_observed': X_predict})
    # This samples from the posterior to create a distribution of likely outcomes
    posterior_predictive = pm.sample_posterior_predictive(idata)

simulated_scores_bayesian = posterior_predictive.posterior_predictive['y_obs'].values.flatten()

# --- Visualize and Compare ---
plt.figure(figsize=(12, 6))
sns.histplot(simulated_scores_bayesian, kde=True, bins=50, label='Bayesian Simulation', color='skyblue')
plt.title(f"Bayesian Posterior Predictive Distribution for Dak's Score", fontsize=16)
plt.xlabel("Simulated Fantasy Points", fontsize=12)
plt.ylabel("Frequency", fontsize=12)
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# --- Calculate Key Probabilities ---
mean_pred_bayesian = simulated_scores_bayesian.mean()
prob_over_25_bayesian = (simulated_scores_bayesian > 25).mean() * 100
prob_under_15_bayesian = (simulated_scores_bayesian < 15).mean() * 100

print("\nKey Probabilities from Bayesian Simulation:")
print(f"Mean Predicted Score: {mean_pred_bayesian:.2f}")
print(f"Probability of scoring OVER 25 points: {prob_over_25_bayesian:.2f}%")
print(f"Probability of scoring UNDER 15 points: {prob_under_15_bayesian:.2f}%")